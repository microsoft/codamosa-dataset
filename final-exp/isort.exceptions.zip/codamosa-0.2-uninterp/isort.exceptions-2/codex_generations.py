

# Generated at 2022-06-17 21:28:43.872027
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("/path/to/file").settings_path == "/path/to/file"


# Generated at 2022-06-17 21:28:52.277226
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1, b = 2")
    except AssignmentsFormatMismatch as e:
        assert str(e) == ("isort was told to sort a section of assignments, however the given code:\n\n"
            "a = 1, b = 2\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n")
        assert e.code == "a = 1, b = 2"


# Generated at 2022-06-17 21:28:54.693636
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("test_file_path")
    except FileSkipComment as e:
        assert e.file_path == "test_file_path"
        assert str(e) == "test_file_path contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:28:58.066808
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"

# Generated at 2022-06-17 21:29:00.789166
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_file_path"
    file_skip_setting = FileSkipSetting(file_path)
    assert file_skip_setting.file_path == file_path
    assert file_skip_setting.message == f"{file_path} was skipped as it's listed in 'skip' setting" \
                                        " or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-17 21:29:03.930314
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"


# Generated at 2022-06-17 21:29:07.317424
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test_file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test_file_path"

# Generated at 2022-06-17 21:29:12.088857
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"


# Generated at 2022-06-17 21:29:19.583168
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"
        assert str(e) == "Found import_module import while parsing, but section was not included " \
                         "in the `sections` setting of your config. Please add it before continuing\n" \
                         "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                         "for more info."

# Generated at 2022-06-17 21:29:22.818881
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "unsupported_setting": {"value": "some_value", "source": "some_source"}
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings