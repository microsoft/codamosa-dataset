

# Generated at 2022-06-17 21:29:19.126393
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "unsupported_setting": {"value": "value", "source": "source"},
        "unsupported_setting2": {"value": "value2", "source": "source2"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:22.185326
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"


# Generated at 2022-06-17 21:29:27.158555
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "foo": {"value": "bar", "source": "config"},
        "baz": {"value": "qux", "source": "cli"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:29.978634
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"


# Generated at 2022-06-17 21:29:32.997868
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/test.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/test.cfg"


# Generated at 2022-06-17 21:29:36.092276
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test.py"
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test.py."

# Generated at 2022-06-17 21:29:39.012884
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"

# Generated at 2022-06-17 21:29:43.644143
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("[1,2,3]", Exception("test exception"))
    except LiteralParsingFailure as e:
        assert e.code == "[1,2,3]"
        assert e.original_error.args[0] == "test exception"


# Generated at 2022-06-17 21:29:45.521355
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 21:29:48.993245
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test_file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test_file_path"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test_file_path."
