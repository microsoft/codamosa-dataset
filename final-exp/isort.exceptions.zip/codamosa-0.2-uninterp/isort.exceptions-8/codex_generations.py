

# Generated at 2022-06-17 21:29:09.169113
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "1"
    original_error = Exception("test")
    exception = LiteralParsingFailure(code, original_error)
    assert exception.code == code
    assert exception.original_error == original_error

# Generated at 2022-06-17 21:29:11.478764
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"


# Generated at 2022-06-17 21:29:15.608401
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"

# Generated at 2022-06-17 21:29:18.239818
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test"


# Generated at 2022-06-17 21:29:20.825161
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"


# Generated at 2022-06-17 21:29:24.165173
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"


# Generated at 2022-06-17 21:29:26.454411
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("file_path").file_path == "file_path"

# Generated at 2022-06-17 21:29:30.537776
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "unsupported_setting": {"value": "value", "source": "source"}
    }
    exception = UnsupportedSettings(unsupported_settings)
    assert exception.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:32.829270
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert str(e) == "test"

# Generated at 2022-06-17 21:29:35.066456
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test.py"