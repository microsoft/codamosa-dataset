

# Generated at 2022-06-17 21:28:46.683463
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("settings_path")
    except InvalidSettingsPath as e:
        assert e.settings_path == "settings_path"


# Generated at 2022-06-17 21:29:00.033504
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:03.667958
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"

# Generated at 2022-06-17 21:29:05.644847
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("test")
    except AssignmentsFormatMismatch as e:
        assert e.code == "test"

# Generated at 2022-06-17 21:29:07.313917
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "message"
    file_path = "file_path"
    file_skipped = FileSkipped(message, file_path)
    assert file_skipped.message == message
    assert file_skipped.file_path == file_path

# Generated at 2022-06-17 21:29:12.628900
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("[1, 2, 3]", SyntaxError("invalid syntax"))
    except LiteralParsingFailure as e:
        assert e.code == "[1, 2, 3]"
        assert e.original_error.msg == "invalid syntax"


# Generated at 2022-06-17 21:29:15.963012
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test")
    except UnsupportedEncoding as e:
        assert e.filename == "test"
        assert str(e) == "Unknown or unsupported encoding in test"

# Generated at 2022-06-17 21:29:18.493039
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("test").message == "test was skipped as it's listed in 'skip' setting" \
                                              " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-17 21:29:20.995955
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/isort.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/isort.cfg"


# Generated at 2022-06-17 21:29:23.977359
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    exception = MissingSection(import_module, section)
    assert exception.import_module == import_module
    assert exception.section == section

# Generated at 2022-06-17 21:29:35.377526
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:39.054793
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"

# Generated at 2022-06-17 21:29:42.937734
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("code", Exception("original_error"))
    except LiteralParsingFailure as e:
        assert e.code == "code"
        assert e.original_error.args[0] == "original_error"

# Generated at 2022-06-17 21:29:45.897246
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=int, expected_kind=str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str

# Generated at 2022-06-17 21:29:47.943726
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.txt")
    except UnsupportedEncoding as e:
        assert e.filename == "test.txt"

# Generated at 2022-06-17 21:29:52.707898
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-17 21:30:00.340580
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"
        assert e.args[0] == "Specified profile of test does not exist. Available profiles: black,pep8,pycharm,google,grayscale,hacker,jupyter,mypy,pybuilder,pycharm,pytest,spacy,vscode,yapf."


# Generated at 2022-06-17 21:30:02.668650
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"

# Generated at 2022-06-17 21:30:07.081157
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("code", Exception("original_error"))
    except LiteralParsingFailure as e:
        assert e.code == "code"
        assert e.original_error.args[0] == "original_error"


# Generated at 2022-06-17 21:30:11.966797
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    exception = MissingSection(import_module, section)
    assert exception.args[0] == f"Found {import_module} import while parsing, but {section} was not included " \
                                "in the `sections` setting of your config. Please add it before continuing\n" \
                                "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                                "for more info."

# Generated at 2022-06-17 21:30:19.401475
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("code", Exception("original_error"))
    except LiteralParsingFailure as e:
        assert e.code == "code"
        assert e.original_error.args[0] == "original_error"

# Generated at 2022-06-17 21:30:21.260360
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test"


# Generated at 2022-06-17 21:30:25.952307
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "unsupported_setting": {"value": "value", "source": "source"}
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:30:30.265736
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("[1, 2, 3]", ValueError("Invalid literal"))
    except LiteralParsingFailure as e:
        assert e.code == "[1, 2, 3]"
        assert e.original_error.args[0] == "Invalid literal"


# Generated at 2022-06-17 21:30:34.372926
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as e:
        assert e.kind == str
        assert e.expected_kind == int
        assert str(e) == "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>."

# Generated at 2022-06-17 21:30:35.934253
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 21:30:38.768497
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test_file")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test_file"

# Generated at 2022-06-17 21:30:41.400786
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test"
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test."


# Generated at 2022-06-17 21:30:44.492368
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test"


# Generated at 2022-06-17 21:30:53.008291
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2\n")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2\n"
        assert str(e) == "isort was told to sort a section of assignments, however the given code:\n\n" \
                         "a = 1\nb = 2\n\n" \
                         "Does not match isort's strict single line formatting requirement for assignment " \
                         "sorting:\n\n" \
                         "{variable_name} = {value}\n" \
                         "{variable_name2} = {value2}\n" \
                         "...\n\n"