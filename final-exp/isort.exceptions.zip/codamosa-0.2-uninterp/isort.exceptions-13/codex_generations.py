

# Generated at 2022-06-17 21:29:19.126088
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("test.py")
    except FileSkipComment as e:
        assert e.file_path == "test.py"
        assert str(e) == "test.py contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:29:23.759779
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str
        assert str(e) == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>."


# Generated at 2022-06-17 21:29:28.109811
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test_file")
    except UnsupportedEncoding as e:
        assert e.filename == "test_file"
        assert str(e) == "Unknown or unsupported encoding in test_file"

# Generated at 2022-06-17 21:29:31.697716
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test_file.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test_file.py"
        assert str(e) == "Unknown or unsupported encoding in test_file.py"

# Generated at 2022-06-17 21:29:34.073483
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("test_settings_path")
    except InvalidSettingsPath as e:
        assert e.settings_path == "test_settings_path"


# Generated at 2022-06-17 21:29:40.111401
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "foo": {"value": "bar", "source": "baz"},
        "baz": {"value": "bar", "source": "baz"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:49.111769
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:52.168169
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"option": {"value": "value", "source": "source"}}
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:55.771451
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test_file"
    file_skip_comment = FileSkipComment(file_path)
    assert file_skip_comment.file_path == file_path
    assert file_skip_comment.message == f"{file_path} contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:29:59.279767
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("[1, 2, 3]", Exception("SyntaxError"))
    except LiteralParsingFailure as e:
        assert e.code == "[1, 2, 3]"
        assert e.original_error.args[0] == "SyntaxError"
