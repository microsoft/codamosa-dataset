

# Generated at 2022-06-17 21:29:01.397990
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"foo": {"value": "bar", "source": "baz"}}
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:03.004697
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:04.870482
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as e:
        assert e.kind == str
        assert e.expected_kind == int

# Generated at 2022-06-17 21:29:06.486832
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/test.py")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/test.py"


# Generated at 2022-06-17 21:29:11.018753
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str
        assert str(e) == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>.\n"

# Generated at 2022-06-17 21:29:16.017717
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"

# Generated at 2022-06-17 21:29:18.574576
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("file_path")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "file_path"

# Generated at 2022-06-17 21:29:21.653490
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/isort/isort.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/isort/isort.cfg"


# Generated at 2022-06-17 21:29:31.698523
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"
        assert str(e) == "isort was told to sort a section of assignments, however the given code:\n\n" \
                         "a = 1\nb = 2\n\n" \
                         "Does not match isort's strict single line formatting requirement for assignment " \
                         "sorting:\n\n" \
                         "{variable_name} = {value}\n" \
                         "{variable_name2} = {value2}\n" \
                         "...\n\n"



# Generated at 2022-06-17 21:29:34.366349
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "file_path"
