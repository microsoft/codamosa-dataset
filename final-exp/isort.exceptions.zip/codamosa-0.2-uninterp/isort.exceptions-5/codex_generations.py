

# Generated at 2022-06-17 21:29:18.784565
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test_file_path"
    exception = FileSkipComment(file_path)
    assert exception.file_path == file_path
    assert str(exception) == f"{file_path} contains an file skip comment and was skipped."

# Generated at 2022-06-17 21:29:22.385494
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test.py")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test.py"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test.py."


# Generated at 2022-06-17 21:29:33.520630
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:35.954675
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-17 21:29:39.771509
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("/home/user/test.py")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "/home/user/test.py"


# Generated at 2022-06-17 21:29:44.310254
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("[1,2,3]", Exception("error"))
    except LiteralParsingFailure as e:
        assert e.code == "[1,2,3]"
        assert e.original_error.args[0] == "error"


# Generated at 2022-06-17 21:29:47.033540
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/test.py")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/test.py"


# Generated at 2022-06-17 21:29:50.520509
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test"

# Generated at 2022-06-17 21:29:56.654490
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"
        assert str(e) == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."


# Generated at 2022-06-17 21:29:59.526285
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("code", Exception("original_error"))
    except LiteralParsingFailure as e:
        assert e.code == "code"
        assert e.original_error.args[0] == "original_error"

# Generated at 2022-06-17 21:30:10.413547
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:30:13.925678
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"test": {"value": "test", "source": "test"}}
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:30:18.577390
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = b\nc = d")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = b\nc = d"

# Generated at 2022-06-17 21:30:20.591282
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test.py"

# Generated at 2022-06-17 21:30:24.881330
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert str(e) == "test"



# Generated at 2022-06-17 21:30:27.370286
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"
        assert str(e) == "Unknown or unsupported encoding in test.py"

# Generated at 2022-06-17 21:30:31.238070
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("test_file")
    except FileSkipComment as e:
        assert e.file_path == "test_file"
        assert str(e) == "test_file contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:30:35.562979
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_file_path"
    file_skip_setting = FileSkipSetting(file_path)
    assert file_skip_setting.file_path == file_path
    assert file_skip_setting.message == f"{file_path} was skipped as it's listed in 'skip' setting" \
                                        " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-17 21:30:40.589191
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"
        assert str(e) == "Found import_module import while parsing, but section was not included " \
                         "in the `sections` setting of your config. Please add it before continuing\n" \
                         "See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-17 21:30:51.138483
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"