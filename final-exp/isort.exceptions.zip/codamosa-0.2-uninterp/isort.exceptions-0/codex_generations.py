

# Generated at 2022-06-17 21:29:01.398047
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "unsupported_setting": {"value": "value", "source": "source"},
        "another_unsupported_setting": {"value": "value", "source": "source"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:03.668018
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test"

# Generated at 2022-06-17 21:29:07.997034
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test_file")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test_file"
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test_file."


# Generated at 2022-06-17 21:29:10.485043
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-17 21:29:12.832389
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 1\nb = 2"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert e.code == code


# Generated at 2022-06-17 21:29:17.006439
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("test", Exception("test"))
    except LiteralParsingFailure as e:
        assert e.code == "test"
        assert e.original_error.args[0] == "test"


# Generated at 2022-06-17 21:29:23.510613
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=str, expected_kind=int)
    except LiteralSortTypeMismatch as e:
        assert e.kind == str
        assert e.expected_kind == int
        assert str(e) == "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>."


# Generated at 2022-06-17 21:29:28.655267
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test_file_path"
    file_skip_comment = FileSkipComment(file_path)
    assert file_skip_comment.file_path == file_path
    assert file_skip_comment.message == f"{file_path} contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:29:37.317740
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:39.277231
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"