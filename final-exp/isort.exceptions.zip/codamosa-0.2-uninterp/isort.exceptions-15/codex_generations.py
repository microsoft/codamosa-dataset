

# Generated at 2022-06-17 21:29:18.784730
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError.__init__.__annotations__ == {'self': ISortError, 'message': str}


# Generated at 2022-06-17 21:29:22.720407
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test_file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test_file_path"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test_file_path."


# Generated at 2022-06-17 21:29:26.601345
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/isort.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/isort.cfg"



# Generated at 2022-06-17 21:29:29.789585
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"


# Generated at 2022-06-17 21:29:35.451573
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"
        assert str(e) == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."


# Generated at 2022-06-17 21:29:46.167982
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:54.523433
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:57.148536
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("Test")
    except ISortError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-17 21:29:59.092096
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"

# Generated at 2022-06-17 21:30:05.793056
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"
        assert str(e) == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-17 21:30:11.083203
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("[1, 2, 3]", SyntaxError("invalid syntax"))
    except LiteralParsingFailure as e:
        assert e.code == "[1, 2, 3]"
        assert e.original_error.msg == "invalid syntax"

# Generated at 2022-06-17 21:30:13.245094
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 21:30:18.287549
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "option_name": {"value": "option_value", "source": "option_source"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:30:21.375923
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test_file")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test_file"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test_file."


# Generated at 2022-06-17 21:30:22.559041
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 21:30:25.714753
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"key": {"value": "value", "source": "source"}}
    exception = UnsupportedSettings(unsupported_settings)
    assert exception.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:30:29.363319
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/isort/settings.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/isort/settings.cfg"


# Generated at 2022-06-17 21:30:35.012287
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    exception = MissingSection(import_module, section)
    assert exception.import_module == import_module
    assert exception.section == section
    assert str(exception) == f"Found {import_module} import while parsing, but {section} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-17 21:30:37.381718
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/settings.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/settings.cfg"


# Generated at 2022-06-17 21:30:39.703059
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/settings.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/settings.cfg"
