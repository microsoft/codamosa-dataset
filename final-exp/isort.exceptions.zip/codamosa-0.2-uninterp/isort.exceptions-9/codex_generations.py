

# Generated at 2022-06-17 21:29:01.397992
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("test")
    except FileSkipComment as e:
        assert e.file_path == "test"
        assert str(e) == "test contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:29:04.194474
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-17 21:29:05.878310
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/isort.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/isort.cfg"


# Generated at 2022-06-17 21:29:09.210911
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"

# Generated at 2022-06-17 21:29:18.505064
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:24.897261
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"
        assert str(e) == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-17 21:29:29.346967
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:32.731977
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"


# Generated at 2022-06-17 21:29:33.734714
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test.py")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test.py"

# Generated at 2022-06-17 21:29:36.857768
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_file"
    error = FileSkipSetting(file_path)
    assert error.file_path == file_path
    assert error.message == f"{file_path} was skipped as it's listed in 'skip' setting" \
                            " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-17 21:29:40.345800
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 1\nb = 2\nc = 3"
    error = AssignmentsFormatMismatch(code)
    assert error.code == code

# Generated at 2022-06-17 21:29:43.809067
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "file_path"


# Generated at 2022-06-17 21:29:46.346178
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-17 21:29:49.109883
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test_file_path"
    error = FileSkipComment(file_path)
    assert error.file_path == file_path
    assert str(error) == f"{file_path} contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:29:54.380617
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"


# Generated at 2022-06-17 21:29:58.779958
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str

# Generated at 2022-06-17 21:30:01.668586
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "file_path"


# Generated at 2022-06-17 21:30:04.573838
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"foo": {"value": "bar", "source": "baz"}}
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:30:08.724711
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "formatter"
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == formatter
        assert str(e) == f"Specified formatting plugin of {formatter} does not exist. "


# Generated at 2022-06-17 21:30:11.106708
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/settings.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/settings.cfg"
