

# Generated at 2022-06-17 21:29:19.136438
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_file_path"
    message = "test_message"
    file_skip_setting = FileSkipSetting(file_path)
    assert file_skip_setting.file_path == file_path
    assert file_skip_setting.message == message

# Generated at 2022-06-17 21:29:22.571511
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of test does not exist. "
        assert e.formatter == "test"


# Generated at 2022-06-17 21:29:27.530744
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test.py")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test.py"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test.py."


# Generated at 2022-06-17 21:29:32.411679
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_file_path"
    error = FileSkipSetting(file_path)
    assert error.file_path == file_path
    assert error.message == f"{file_path} was skipped as it's listed in 'skip' setting" \
                            " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-17 21:29:34.685426
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "test.py"
    exception = UnsupportedEncoding(filename)
    assert exception.filename == filename
    assert str(exception) == "Unknown or unsupported encoding in test.py"

# Generated at 2022-06-17 21:29:37.108734
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/isort.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/isort.cfg"


# Generated at 2022-06-17 21:29:39.461340
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"


# Generated at 2022-06-17 21:29:44.034990
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test_file_path"
    file_skip_comment = FileSkipComment(file_path)
    assert file_skip_comment.file_path == file_path
    assert file_skip_comment.message == f"{file_path} contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:29:46.244939
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError:
        assert True
    else:
        assert False


# Generated at 2022-06-17 21:29:48.775089
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("code", Exception("original_error"))
    except LiteralParsingFailure as e:
        assert e.code == "code"
        assert e.original_error.args[0] == "original_error"

# Generated at 2022-06-17 21:29:55.167712
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("formatter")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "formatter"


# Generated at 2022-06-17 21:29:58.917174
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"

# Generated at 2022-06-17 21:30:01.814435
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test_file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test_file_path"


# Generated at 2022-06-17 21:30:04.731074
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("test", "test")
    except FileSkipped as e:
        assert e.message == "test"
        assert e.file_path == "test"


# Generated at 2022-06-17 21:30:07.922187
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"

# Generated at 2022-06-17 21:30:10.432107
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/settings.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/settings.cfg"


# Generated at 2022-06-17 21:30:14.311196
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"
        assert str(e) == "Unknown or unsupported encoding in test.py"

# Generated at 2022-06-17 21:30:18.138595
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test"

# Generated at 2022-06-17 21:30:19.195213
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 21:30:20.861777
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 21:30:26.234552
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"

# Generated at 2022-06-17 21:30:30.645851
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "file_path"
    file_skip_comment = FileSkipComment(file_path)
    assert file_skip_comment.file_path == file_path
    assert file_skip_comment.message == f"{file_path} contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:30:33.422288
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(int, str).__str__() == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>."

# Generated at 2022-06-17 21:30:35.601430
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test"


# Generated at 2022-06-17 21:30:37.665528
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"


# Generated at 2022-06-17 21:30:39.993856
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as e:
        assert e.kind == str
        assert e.expected_kind == int

# Generated at 2022-06-17 21:30:44.068813
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"
        assert str(e) == "Found import_module import while parsing, but section was not included " \
                         "in the `sections` setting of your config. Please add it before continuing\n" \
                         "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                         "for more info."

# Generated at 2022-06-17 21:30:48.070594
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"

# Generated at 2022-06-17 21:30:58.177516
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"
        assert str(e) == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-17 21:31:02.568419
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test_file.py")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test_file.py"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test_file.py."


# Generated at 2022-06-17 21:31:12.239440
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test"

# Generated at 2022-06-17 21:31:14.837989
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"

# Generated at 2022-06-17 21:31:20.071921
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"

# Generated at 2022-06-17 21:31:23.730980
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "option1": {"value": "value1", "source": "source1"},
        "option2": {"value": "value2", "source": "source2"},
    }
    exception = UnsupportedSettings(unsupported_settings)
    assert exception.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:31:26.263441
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped = FileSkipped("message", "file_path")
    assert file_skipped.message == "message"
    assert file_skipped.file_path == "file_path"

# Generated at 2022-06-17 21:31:32.725820
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:31:37.201770
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test"
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test."


# Generated at 2022-06-17 21:31:39.684332
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:31:41.453174
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test_file_path"
    assert FileSkipComment(file_path).file_path == file_path


# Generated at 2022-06-17 21:31:44.938798
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "unsupported_setting": {"value": "value", "source": "source"},
        "unsupported_setting2": {"value": "value2", "source": "source2"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings