

# Generated at 2022-06-17 21:29:20.529988
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('import_module', 'section')
    except MissingSection as e:
        assert e.import_module == 'import_module'
        assert e.section == 'section'
        assert str(e) == 'Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'

# Generated at 2022-06-17 21:29:22.672855
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"

# Generated at 2022-06-17 21:29:26.545591
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"

# Generated at 2022-06-17 21:29:32.955786
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=str, expected_kind=int)
    except LiteralSortTypeMismatch as e:
        assert e.kind == str
        assert e.expected_kind == int
        assert str(e) == (
            "isort was told to sort a literal of type <class 'int'> but was given "
            "a literal of type <class 'str'>."
        )


# Generated at 2022-06-17 21:29:35.183090
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"


# Generated at 2022-06-17 21:29:39.054993
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "file_path"


# Generated at 2022-06-17 21:29:42.383666
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "file_path"


# Generated at 2022-06-17 21:29:45.003987
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {'foo': {'value': 'bar', 'source': 'baz'}}
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:47.466503
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-17 21:29:49.470316
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"