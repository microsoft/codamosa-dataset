

# Generated at 2022-06-17 21:28:43.369092
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test.py"
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test.py."


# Generated at 2022-06-17 21:28:46.681972
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # pylint: disable=protected-access
    assert UnsupportedSettings({"foo": {"value": "bar", "source": "baz"}}).unsupported_settings == {
        "foo": {"value": "bar", "source": "baz"}
    }

# Generated at 2022-06-17 21:28:51.046142
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"


# Generated at 2022-06-17 21:28:59.151199
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test_file.py")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test_file.py"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test_file.py."


# Generated at 2022-06-17 21:29:10.974451
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:15.044639
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("test_file.py")
    except FileSkipComment as e:
        assert e.file_path == "test_file.py"
        assert str(e) == "test_file.py contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:29:18.452052
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"


# Generated at 2022-06-17 21:29:22.771435
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "./test.py"
    exception = FileSkipSetting(file_path)
    assert exception.file_path == file_path
    assert str(exception) == f"{file_path} was skipped as it's listed in 'skip' setting" \
                             " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-17 21:29:26.979445
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 1\nb = 2\n"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert e.code == code


# Generated at 2022-06-17 21:29:30.592440
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"
