

# Generated at 2022-06-17 21:29:09.170374
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"

# Generated at 2022-06-17 21:29:10.419718
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"

# Generated at 2022-06-17 21:29:12.319788
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"

# Generated at 2022-06-17 21:29:15.560240
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("settings_path")
    except InvalidSettingsPath as e:
        assert e.settings_path == "settings_path"


# Generated at 2022-06-17 21:29:20.045800
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_file"
    file_skip_setting = FileSkipSetting(file_path)
    assert file_skip_setting.file_path == file_path
    assert file_skip_setting.message == f"{file_path} was skipped as it's listed in 'skip' setting" \
                                        f" or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-17 21:29:22.137484
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert str(e) == "test"

# Generated at 2022-06-17 21:29:27.106876
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "foo": {"value": "bar", "source": "config"},
        "baz": {"value": "qux", "source": "cli"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:31.199415
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("code", Exception("original_error"))
    except LiteralParsingFailure as e:
        assert e.code == "code"
        assert e.original_error.args[0] == "original_error"


# Generated at 2022-06-17 21:29:32.546790
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("file_path").file_path == "file_path"

# Generated at 2022-06-17 21:29:34.820619
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"
