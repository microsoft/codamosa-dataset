

# Generated at 2022-06-17 21:28:41.620049
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:28:44.375460
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("test")
    except FileSkipComment as e:
        assert e.file_path == "test"
        assert str(e) == "test contains an file skip comment and was skipped."


# Generated at 2022-06-17 21:28:46.985479
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as e:
        assert e.kind == str
        assert e.expected_kind == int

# Generated at 2022-06-17 21:28:53.194374
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"

# Generated at 2022-06-17 21:28:59.606643
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_file_path"
    exception = FileSkipSetting(file_path)
    assert exception.file_path == file_path
    assert exception.message == f"{file_path} was skipped as it's listed in 'skip' setting" \
                                " or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-17 21:29:03.578216
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-17 21:29:05.302635
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"

# Generated at 2022-06-17 21:29:06.870476
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"

# Generated at 2022-06-17 21:29:08.746117
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"

# Generated at 2022-06-17 21:29:15.106946
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"
        assert str(e) == "Found import_module import while parsing, but section was not included " \
                         "in the `sections` setting of your config. Please add it before continuing\n" \
                         "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                         "for more info."

# Generated at 2022-06-17 21:29:19.474784
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/isort.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/isort.cfg"


# Generated at 2022-06-17 21:29:29.347530
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"
        assert str(e) == "Specified profile of test does not exist. Available profiles: black,pycharm,google,pep8,pyupgrade,vulture,yapf,mypy,flake8,pylint,pycodestyle,pyflakes,bandit,prospector,pydocstyle,flake8-bugbear,flake8-comprehensions,flake8-docstrings,flake8-import-order,flake8-quotes,mccabe,pyroma,radon,vulture,wemake-python-styleguide."


# Generated at 2022-06-17 21:29:30.677619
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("file_path").file_path == "file_path"

# Generated at 2022-06-17 21:29:32.912069
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test")
    except UnsupportedEncoding as e:
        assert e.filename == "test"

# Generated at 2022-06-17 21:29:35.743341
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"
        assert str(e) == "Unknown or unsupported encoding in test.py"

# Generated at 2022-06-17 21:29:39.639616
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"


# Generated at 2022-06-17 21:29:43.515314
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test"
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test."

# Generated at 2022-06-17 21:29:46.696257
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("code", Exception("original_error"))
    except LiteralParsingFailure as e:
        assert e.code == "code"
        assert e.original_error.args[0] == "original_error"


# Generated at 2022-06-17 21:29:48.932720
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user/isort.cfg")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/home/user/isort.cfg"


# Generated at 2022-06-17 21:29:53.171827
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "foo": {"value": "bar", "source": "config"},
        "baz": {"value": "qux", "source": "runtime"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings