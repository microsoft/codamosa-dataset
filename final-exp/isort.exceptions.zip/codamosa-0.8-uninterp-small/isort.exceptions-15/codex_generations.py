

# Generated at 2022-06-25 19:31:53.501869
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message_0 = "d"
    str_0 = ""
    file_skipped_0 = FileSkipped(message_0, str_0)
    # message_0 should be "d"
    assert str(file_skipped_0.message) == "d"
    # file_path_0 should be ""
    assert str(file_skipped_0.file_path) == ""
    # str_0 should be ""
    assert str(file_skipped_0.file_path) == ""


# Generated at 2022-06-25 19:31:58.057698
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Create an UnsupportedEncoding instance
    str_0 = "9tsh"
    path_0 = Path(str_0)
    unsupported_encoding_0 = UnsupportedEncoding(path_0)
    unsupported_encoding_1 = UnsupportedEncoding(str_0)


# Generated at 2022-06-25 19:32:04.488924
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = "tr6\u2029\u2022\u2028"
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    str_1 = introduced_syntax_errors_0.file_path

# Generated at 2022-06-25 19:32:07.904231
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    int_0 = 8
    int_1 = 3
    FormattingPluginDoesNotExist_0 = FormattingPluginDoesNotExist(int_0)
    FormattingPluginDoesNotExist_1 = FormattingPluginDoesNotExist(int_1)

# Generated at 2022-06-25 19:32:10.906624
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = "\x0c|3'4%k"
    # Instantiate an ExistingSyntaxErrors with an argument
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    str_1 = existing_syntax_errors_0.file_path
    assert str_1 == str_0


# Generated at 2022-06-25 19:32:21.319087
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = "n[v+'&$-"

# Generated at 2022-06-25 19:32:25.498707
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Test of attributes
    str_0 = "\x0c|3'4%k"
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    assert existing_syntax_errors_0.file_path == str_0
    # Test of constructor call
    str_0 = "\x0c|3'4%k"
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:32:30.597020
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = "8`5%yb"
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert isinstance(invalid_settings_path_0, ISortError) == True
    assert invalid_settings_path_0.settings_path == str_0


# Generated at 2022-06-25 19:32:40.147904
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = "\x0c|3'4%k"
    str_1 = "\x0c|3'4%k"
    file_skipped_0 = FileSkipped(str_0, str_1)
    str_2 = "l\u0014\u001d\u0018\u0017B\u001e\u001a\u0017"
    assert file_skipped_0.message == str_2, "'Message' is unexpected value"
    str_3 = "\x0c|3'4%k"
    assert file_skipped_0.file_path == str_3, "'FilePath' is unexpected value"


# Generated at 2022-06-25 19:32:45.570758
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # arrangement
    int_1 = 6
    tuple_0 = (int_1,)
    try:
        # action
        literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(int_1, tuple_0)
    except:
        # action
        literal_sort_type_mismatch_0 = None

    # assertion
    assert literal_sort_type_mismatch_0 is not None


# Generated at 2022-06-25 19:32:51.140610
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    test_case_0()
    try:
        raise FormattingPluginDoesNotExist('yaml')
    except FormattingPluginDoesNotExist:
        assert True


# Generated at 2022-06-25 19:32:51.838963
# Unit test for constructor of class MissingSection
def test_MissingSection():
    test_case_0()


# Generated at 2022-06-25 19:32:55.610924
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception_instance = UnsupportedEncoding("e=`8yL-O|x4")
    assert type(exception_instance) == UnsupportedEncoding
    assert str(exception_instance.filename) == "e=`8yL-O|x4"


# Generated at 2022-06-25 19:33:05.837081
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = "SETTINGS"
    str_1 = "ISortError"
    str_2 = "C:/Users/kiris/AppData/Local/Programs/Python/Python37/Lib/site-packages/isort/cli.py"
    str_3 = "HelpView(sorted_imports, 'C:/Users/kiris/AppData/Local/Programs/Python/Python37/Lib/site-packages/isort/cli.py', 'SETTINGS')"
    str_4 = "'HelpView' object has no attribute 'file_path'"
    instance_0 = FileSkipped(str_0, str_2)
    # noinspection PyBroadException

# Generated at 2022-06-25 19:33:06.759814
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("str_0")

# Generated at 2022-06-25 19:33:12.325957
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = "n[v+'&$-"
    str_1 = "r/"
    str_2 = "s/"
    str_3 = "q/"
    str_4 = "r/"
    str_5 = "r/"
    str_6 = "r/"
    test = MissingSection(str_0, str_1)
    assert test.import_module == "n[v+'&$-"
    assert test.section == "r/"


# Generated at 2022-06-25 19:33:19.742570
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        g = IntroducedSyntaxErrors
        g('/home/nguyen/Python-2.7.17rc2/bin/python2.7')
    except IntroducedSyntaxErrors as e:
        assert(str(e) == "isort introduced syntax errors when attempting to sort the imports contained within /home/nguyen/Python-2.7.17rc2/bin/python2.7.")
        assert(e.file_path == "/home/nguyen/Python-2.7.17rc2/bin/python2.7")

# Generated at 2022-06-25 19:33:22.394021
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = "n[v+'&$-"
    ret_0 = MissingSection(str_0, str_0)
    assert type(ret_0) == MissingSection


# Generated at 2022-06-25 19:33:24.304477
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("foo")
    except FormattingPluginDoesNotExist:
        assert True
    else:
        assert False

# Generated at 2022-06-25 19:33:26.349668
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    test = LiteralSortTypeMismatch(str, int)


# Generated at 2022-06-25 19:33:29.929027
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert hasattr(UnsupportedEncoding, "__init__")



# Generated at 2022-06-25 19:33:31.184296
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:33:38.470879
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    tests = []
    tests.append(test_case_0)
    test_results = []
    for test in tests:
        try:
            test()
        except Exception as exc:
            test_results.append(True)
        else:
            test_results.append(False)
    if test_results.count(True) == 0:
        print("profile.ProfileDoesNotExist constructor test successful")
    else:
        print("profile.ProfileDoesNotExist constructor test failed")


# Generated at 2022-06-25 19:33:39.877597
# Unit test for constructor of class ISortError
def test_ISortError():
    with raises(Exception):
        ISortError(str_0)


# Generated at 2022-06-25 19:33:43.751920
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        # Test for MissingSection exception.
        raise MissingSection(isort.MissingSection, "yn")
    except Exception:
        assert False


# Test fixture for UnsupportedEncoding

# Generated at 2022-06-25 19:33:46.264229
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "./test_data/test_10.txt"
    fsc = FileSkipComment(file_path)
    assert fsc.file_path == file_path


# Generated at 2022-06-25 19:33:48.948382
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        test_case_0()
        assert False
    except NameError as e:
        instance_0 = LiteralParsingFailure('', e)
        assert isinstance(instance_0, LiteralParsingFailure)
        assert instance_0.args == ('', e)

# Generated at 2022-06-25 19:33:53.974138
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message_0 = "message"
    file_path_0 = "file_path"
    try:
        FileSkipped(message_0, file_path_0)
    except Exception as e:
        print(e)
        return False
    else:
        return True


# Generated at 2022-06-25 19:33:57.656978
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = test_case_0()
    expected_kind = test_case_0()
    assert LiteralSortTypeMismatch(kind, expected_kind).kind == kind
    assert LiteralSortTypeMismatch(kind, expected_kind).expected_kind == expected_kind

# Generated at 2022-06-25 19:34:01.242743
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = "n[v+'&$-"
    # UT for ProfileDoesNotExist with profile
    try:
        raise ProfileDoesNotExist(str_0)
    except Error as e:
        print(e)


# Generated at 2022-06-25 19:34:07.538911
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_1 = 'dist-packages'
    str_2 = 'dist-packages'
    missing_section_0 = MissingSection(str_1, str_2)
    assert missing_section_0.import_module == 'dist-packages'
    assert missing_section_0.section == 'dist-packages'



# Generated at 2022-06-25 19:34:10.141683
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'battery'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert invalid_settings_path_0.settings_path == str_0


# Generated at 2022-06-25 19:34:12.862521
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
	from pathlib import Path
	
	settings_path_0 = Path('/')
	invalid_settings_path_0 = InvalidSettingsPath(settings_path_0)

test_InvalidSettingsPath()

# Generated at 2022-06-25 19:34:15.225755
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("/home/kaituo/project/isort")
    except UnsupportedEncoding as e:
        if e.file_path == "/home/kaituo/project/isort":
            return 1
    return 0


# Generated at 2022-06-25 19:34:16.475096
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = 'dist-packages'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)

# Generated at 2022-06-25 19:34:18.285096
# Unit test for constructor of class ISortError
def test_ISortError():
    str_1 = 'dist-packages'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_1)


# Generated at 2022-06-25 19:34:21.167091
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'dist-packages'
    isort_error_0 = ISortError(str_0)
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, isort_error_0)


# Generated at 2022-06-25 19:34:29.030768
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    dict_0 = dict()
    dict_1 = dict()
    dict_0['true'] = 'null'
    dict_1['key'] = dict_0
    unsupported_settings_0 = dict()
    unsupported_settings_0['key'] = dict_0
    unsupported_settings_0['key'] = dict_1
    unsupported_settings_0['key'] = dict_1
    unsupported_settings_0['key'] = dict_1
    unsupported_settings_0['key'] = dict_0
    unsupported_settings_0['key'] = dict_0
    unsupported_settings_0['key'] = dict_0
    unsupported_settings_0['true'] = dict_0
    unsupported_settings_0['key'] = dict_0
    unsupported_settings_0['true'] = dict_1
    unsupported_settings_0['true']

# Generated at 2022-06-25 19:34:33.982313
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    test_case_1() # File test_file_3 is used for testing
    test_case_2() # File test_file_4 is used for testing
    test_case_3() # File test_file_5 is used for testing


# Generated at 2022-06-25 19:34:40.797165
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'dist-packages'
    str_1 = 'dist-packages'
    str_2 = 'dist-packages'
    str_3 = 'dist-packages'
    file_skipped_0 = FileSkipped(str_0, str_1)
    file_skipped_1 = FileSkipped(str_2, str_3)
    file_skipped_0.message
    file_skipped_0.file_path
    file_skipped_1.file_path
    file_skipped_1.message


# Generated at 2022-06-25 19:34:50.059393
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    # test constructor
    str_0 = 'dist-packages'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    # test class member variable 'file_path'
    str_1 = introduced_syntax_errors_0.file_path
    assert str_1 == 'dist-packages'



# Generated at 2022-06-25 19:34:52.057177
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = '/etc/passwd'
    except_obj = UnsupportedEncoding(filename)
    assert except_obj.filename == filename


# Generated at 2022-06-25 19:34:59.710903
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'dist-packages'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, introduced_syntax_errors_0)
    assert literal_parsing_failure_0.code == 'dist-packages'
    assert literal_parsing_failure_0.original_error == introduced_syntax_errors_0


# Generated at 2022-06-25 19:35:01.405736
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile__0 = ''
    profile_does_not_exist_0 = ProfileDoesNotExist(profile__0)


# Generated at 2022-06-25 19:35:05.603494
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'dist-packages'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    assert introduced_syntax_errors_0.file_path == str_0


# Generated at 2022-06-25 19:35:09.599566
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'dist-packages'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert_equals(invalid_settings_path_0.settings_path, str_0)


# Generated at 2022-06-25 19:35:14.989728
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    expected_kind = str
    kind = str
    kind = sorted(kind)
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(expected_kind, kind)
    assert literal_sort_type_mismatch_0.kind is kind
    assert literal_sort_type_mismatch_0.expected_kind is expected_kind
    assert isinstance(literal_sort_type_mismatch_0, ISortError)
    assert isinstance(literal_sort_type_mismatch_0, Exception)


# Generated at 2022-06-25 19:35:17.787446
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = 'dist-packages'
    file_skip_comment_0 = FileSkipComment(str_0)


# Generated at 2022-06-25 19:35:20.640245
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'dist-packages'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    test_case_0()


# Generated at 2022-06-25 19:35:24.759559
# Unit test for constructor of class ISortError
def test_ISortError():
    # To check if error is raised for invalid format of setting path for constructor of class ISortError
    if (isinstance(InvalidSettingsPath.__init__, object)):
        assert True
    else:
        assert False


# Generated at 2022-06-25 19:35:33.246665
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():

    fileSkipComment = FileSkipComment(str_0)
    assert fileSkipComment != None


# Generated at 2022-06-25 19:35:33.993301
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    test_case_0()

# Generated at 2022-06-25 19:35:36.780883
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist, match='Specified profile of profile does not exist'):
        test_case_0()


# Generated at 2022-06-25 19:35:39.698204
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = 'SyntaxError'
    original_error = 'SyntaxError'
    obj = LiteralParsingFailure(code, original_error)
    assert obj.code == code
    assert obj.original_error == original_error


# Generated at 2022-06-25 19:35:45.268430
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()


# Generated at 2022-06-25 19:35:48.008782
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = 'dist-packages'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    print(existing_syntax_errors_0.file_path)


# Generated at 2022-06-25 19:35:50.664172
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'dist-packages'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    str_1 = ''
    isort_error_0 = ISortError(str_1)


# Generated at 2022-06-25 19:35:53.352893
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = 'dist-packages'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    str_1 = existing_syntax_errors_0.file_path
    assert str_1 is str_0


# Generated at 2022-06-25 19:35:58.155119
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Test with real data
    str_0 = '/'
    file_skip_setting_0 = FileSkipSetting(str_0)
    assert file_skip_setting_0.message == "/ was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert file_skip_setting_0.file_path == str_0

    # Test without data
    str_1 = None
    file_skip_setting_1 = FileSkipSetting(str_1)
    assert file_skip_setting_1.message == "None was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert file_skip_setting_1.file_path == str_1


# Generated at 2022-06-25 19:36:04.049423
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'import_module'
    section = 'section'
    test_MissingSection = MissingSection(import_module, section)
    assert test_MissingSection.import_module == 'import_module'
    assert test_MissingSection.section == 'section'


# Generated at 2022-06-25 19:36:19.362646
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    obj = UnsupportedSettings(unsupported_settings ={})


# Generated at 2022-06-25 19:36:23.339076
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = 'dist-packages'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:36:25.638912
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = '~/.isort.cfg'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert str_0 == invalid_settings_path_0.settings_path


# Generated at 2022-06-25 19:36:27.086848
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist.__init__(1) == 1

# Generated at 2022-06-25 19:36:29.327798
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'dist-packages'

    # Validate classes constructor method is not raising an exception
    instance01 = FileSkipped(str_0, str_0)
    assert not isinstance(instance01, ISortError)


# Generated at 2022-06-25 19:36:31.127923
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    str_0 = 'dist-packages'
    file_skip_setting_0 = FileSkipSetting(str_0)
    assert file_skip_setting_0.file_path == 'dist-packages'

# Generated at 2022-06-25 19:36:33.246436
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = '__pycache__/data/test_existing_syntax_errors.pyc'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    assert existing_syntax_errors_0.file_path == str_0



# Generated at 2022-06-25 19:36:35.231075
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = '__pycache__'
    exception = UnsupportedEncoding(filename)
    assert exception.filename == '__pycache__'



# Generated at 2022-06-25 19:36:39.016984
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_0 = '__main__'
    profile_does_not_exist_0 = ProfileDoesNotExist(profile_0)
    assert profile_does_not_exist_0.profile == profile_0


# Generated at 2022-06-25 19:36:42.406386
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        str_0 = 'dist-packages'
        str_1 = 'dist-packages'
        file_skipped_0 = FileSkipped(str_0, str_1)
        assert file_skipped_0.file_path == str_1
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 19:37:16.731727
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = '/usr/bin'
    exception_0 = InvalidSettingsPath(str_0)
    str_1 = 'thunder-bolt'
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, exception_0)
    assert literal_parsing_failure_0.code == str_0
    assert literal_parsing_failure_0.original_error == exception_0


# Generated at 2022-06-25 19:37:18.872841
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    str_0 = 'dist-packages'
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(str_0, str_0)
    print(literal_sort_type_mismatch_0)


# Generated at 2022-06-25 19:37:23.406832
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'dist-packages'
    str_1 = 'dist-packages'
    file_skipped_0 = FileSkipped(str_0, str_1)
    str_2 = file_skipped_0.file_path
    assert str_2 == str_1


# Generated at 2022-06-25 19:37:25.150823
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():

    str_0 = '3.7.3'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:37:29.183132
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'out of range'
    index_error_0 = IndexError(str_0)
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, index_error_0)

# Generated at 2022-06-25 19:37:31.375311
# Unit test for constructor of class ISortError
def test_ISortError():
    isort_error_0 = ISortError()  # Constructor __init__ testing
    assert isort_error_0


# Generated at 2022-06-25 19:37:32.822820
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_1 = 'dist-packages'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_1)

# Generated at 2022-06-25 19:37:36.331865
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    introduced_syntax_errors_0 = IntroducedSyntaxErrors('dist-packages')
    # Test constructor.
    try:
        literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(type, type)
    except:
        assert False


# Generated at 2022-06-25 19:37:38.472037
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # LiteralSortTypeMismatch has two parameter and constructor of the class is
    # called below.
    object_test = LiteralSortTypeMismatch(type, type)
    assert object_test


# Generated at 2022-06-25 19:37:39.825459
# Unit test for constructor of class MissingSection
def test_MissingSection():
    t1 = test_case_0()
    str_0 = 'dist-packages'
    assert IntroducedSyntaxErrors(str_0) is not None

# Generated at 2022-06-25 19:38:40.835541
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = 'test1.py'
    file_skip_comment_0: FileSkipComment = FileSkipComment(str_0)


# Generated at 2022-06-25 19:38:45.337816
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert type(InvalidSettingsPath('settings_path_0')) == InvalidSettingsPath
    assert InvalidSettingsPath('settings_path_0').settings_path == 'settings_path_0'


# Generated at 2022-06-25 19:38:48.554942
# Unit test for constructor of class ISortError
def test_ISortError():
    # Constructing object of class InvalidSettingsPath with arguments
    str_1 = 'dist-packages'
    invalid_settings_path_0 = InvalidSettingsPath(str_1)



# Generated at 2022-06-25 19:38:51.360185
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename_0 = 'No such file or directory'
    unsupported_encoding_0 = UnsupportedEncoding(filename_0)
    assert unsupported_encoding_0.filename == filename_0


# Generated at 2022-06-25 19:38:55.703727
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # str_0 = 'dist-packages'
    # str_1 = 'dist-packages'
    # missing_section_0 = MissingSection(str_0, str_1)
    assert True

# Generated at 2022-06-25 19:39:02.376904
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # Creating a new class object
    assignments_format_mismatch_0 = AssignmentsFormatMismatch('^(?:from\\s+(\\w+)(?:\\s+import\\s+(.+))?|import\\s+(.+))$')
    assert assignments_format_mismatch_0.code == '^(?:from\\s+(\\w+)(?:\\s+import\\s+(.+))?|import\\s+(.+))$'


# Generated at 2022-06-25 19:39:06.856201
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_1 = 'dist-packages'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_1)
    assert existing_syntax_errors_0.file_path == 'dist-packages'


# Generated at 2022-06-25 19:39:09.581487
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = 'dist-packages'
    str_1 = 'dist-packages'
    missing_section_0 = MissingSection(str_0,str_1)


# Generated at 2022-06-25 19:39:16.250049
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path_0 = 'j+w*d`z'
    file_skipped_0 = FileSkipped(file_path_0, file_path_0)
    file_path_1 = 'c%3K8:l'
    file_skipped_1 = FileSkipped(file_path_1, file_path_1)
    file_path_2 = 'L-7(X|='
    file_skipped_2 = FileSkipped(file_path_2, file_path_2)
    file_path_3 = 'nTQ,i%E'
    file_skipped_3 = FileSkipped(file_path_3, file_path_3)
    file_path_4 = 'z$D.pI\''

# Generated at 2022-06-25 19:39:20.047159
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'dist-packages'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    str_1 = invalid_settings_path_0.settings_path


# Generated at 2022-06-25 19:41:17.871217
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    str_0 = 'dist-packages'
    str_1 = 'dist-packages'
    exception_class_0 = LiteralSortTypeMismatch(str_0, str_1)


# Generated at 2022-06-25 19:41:20.699183
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'dist-packages'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    str_1 = '{code}'
    value_0 = introduced_syntax_errors_0
    literal_parsing_failure_0 = LiteralParsingFailure(str_1, value_0)


# Generated at 2022-06-25 19:41:22.802259
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Generate a string
    str_0 = 'dist-packages'
    # Generate an exception
    unsupported_encoding_0 = UnsupportedEncoding(str_0)
    assert unsupported_encoding_0.filename == 'dist-packages'


# Generated at 2022-06-25 19:41:27.172588
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # setup
    test_Profile_DoesNot_Exist_0 = 'isort'
    profile_does_not_exist_0 = ProfileDoesNotExist(test_Profile_DoesNot_Exist_0)
    # verify
    assert str(profile_does_not_exist_0) == "Specified profile of isort does not exist. Available profiles: black, google, pycharm, sphinx, vscode, pyup, google_multi_line, google_py2, google_py3, pycharm_multi_line, pycharm_py2, pycharm_py3, sphinx_multi_line, sphinx_py2, sphinx_py3, vscode_py2, vscode_py3."
    assert profile_does_not_exist_0.profile == 'isort'
   

# Generated at 2022-06-25 19:41:30.004622
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    introduced_syntax_errors_0 = IntroducedSyntaxErrors('dist-packages')
    unsupported_encoding_0 = UnsupportedEncoding(introduced_syntax_errors_0)
    UnsupportedEncoding(unsupported_encoding_0)
    try:
        UnsupportedEncoding(str)
    except TypeError as e:
        print(e.args)


# Generated at 2022-06-25 19:41:35.389506
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = 'dist-packages'
    skip_comment = FileSkipComment(path)
    assert skip_comment.file_path == 'dist-packages'
    assert skip_comment.message == 'dist-packages contains an file skip comment and was skipped.'


# Generated at 2022-06-25 19:41:37.913107
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = 'dist-packages'
    str_1 = 'usr'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)
    also_false_cond = ((assignments_format_mismatch_0.code == str_1) or (not str_1))
    assert also_false_cond


# Generated at 2022-06-25 19:41:40.108796
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_11 = 'dist-packages'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_11)
    str_12 = existing_syntax_errors_0.file_path
    str_13 = 'dist-packages'
    str_14 = str_12 == str_13
    str_15 = 'str_12 == str_13'



# Generated at 2022-06-25 19:41:41.229816
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        test_case_0()
    except:
        return False
    return True


# Generated at 2022-06-25 19:41:45.658709
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():

    message = "Invalid setting: ['aa']"
    class_name = "UnsupportedSettings"
    unsupported_settings = {"aa": {"value": "test0", "source": "test1"}}
    test_instance = UnsupportedSettings(unsupported_settings)

    # Assert for the constructor for the class obj
    assert isinstance(test_instance, UnsupportedSettings)
    assert test_instance.args[0] == message
    assert test_instance.__class__.__name__ == class_name
    assert test_instance.unsupported_settings == unsupported_settings

