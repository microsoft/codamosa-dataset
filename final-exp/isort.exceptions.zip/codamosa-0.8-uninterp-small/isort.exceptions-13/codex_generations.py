

# Generated at 2022-06-25 19:31:55.813273
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'S6<-b7\n{6}T?'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    str_1 = 's<O-={p~\n{'
    invalid_settings_path_1 = InvalidSettingsPath(str_1)
    str_2 = 's<O-={p~\n{'
    invalid_settings_path_2 = InvalidSettingsPath(str_2)
    str_3 = 's<O-={p~\n{'
    invalid_settings_path_3 = InvalidSettingsPath(str_3)


# Generated at 2022-06-25 19:31:57.686830
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'Y-> SBc\n\tg7a{y'
    file_skipped_0 = FileSkipped(str_0, str_0)
    assert file_skipped_0.__init__(str_0, str_0) == None


# Generated at 2022-06-25 19:32:00.188973
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = '@'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)


# Generated at 2022-06-25 19:32:04.339119
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = '---a'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    assert isinstance(existing_syntax_errors_0, ISortError)


# Generated at 2022-06-25 19:32:15.328070
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    type_0 = type(str_0)
    type_1 = type(str_1)
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(type_0, type_1)
    str_2 = 'n4n'
    str_3 = '8Wz'
    str_4 = 'R5B'
    str_5 = '_e{'
    str_6 = '6Mj'
    str_7 = 'U6J'
    str_8 = 'H(k'
    str_9 = '8rv'
    str_10 = 'f5P'
    str_11 = 'n3q'
    str_12 = '6Dj'
    str_13 = 'U6J'
    str_14 = 'PS!'
    str_15

# Generated at 2022-06-25 19:32:18.293622
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # TODO: remove the below line once test is complete
    assert False == True, "Stub Call"


# Generated at 2022-06-25 19:32:26.134639
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'S5\n\t#'
    exception_0 = Exception()
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, exception_0)
    str_1 = '#'
    literal_parsing_failure_1 = LiteralParsingFailure(str_1, exception_0)
    str_2 = 'N'
    literal_parsing_failure_2 = LiteralParsingFailure(str_2, exception_0)
    str_3 = 'G'
    literal_parsing_failure_3 = LiteralParsingFailure(str_3, exception_0)
    str_4 = 'U'
    literal_parsing_failure_4 = LiteralParsingFailure(str_4, exception_0)


# Generated at 2022-06-25 19:32:28.273995
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert str(UnsupportedEncoding('test')) == 'Unknown or unsupported encoding in test'


# Generated at 2022-06-25 19:32:31.011773
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'Y> SBc\n\tg|vx<'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)


# Generated at 2022-06-25 19:32:42.302939
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = ';-_!(,0$'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert invalid_settings_path_0.settings_path == str_0
    str_1 = '40t8Q'
    file_skip_setting_0 = FileSkipSetting(str_1)
    assert file_skip_setting_0.file_path == str_1
    file_skip_comment_0 = FileSkipComment(str_0)
    assert file_skip_comment_0.file_path == str_0
    str_2 = 'rG-pX$jln= ?\x12'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_2)
    assert profile_does_not_exist_0.profile == str_2
    str

# Generated at 2022-06-25 19:32:48.742656
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = str
    expected_kind = str
    literal_sort_type_mismatch = LiteralSortTypeMismatch(kind, expected_kind)
    return literal_sort_type_mismatch

# Generated at 2022-06-25 19:32:51.898299
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist("Profile").profile == "Profile"

if __name__ == '__main__':
    # test_case_0()
    test_ProfileDoesNotExist()

# Generated at 2022-06-25 19:32:53.986513
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = ''
    message = ''
    obj = FileSkipped(message, file_path)
    assert obj != None


# Generated at 2022-06-25 19:32:58.027599
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'W'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)



# Generated at 2022-06-25 19:33:02.977332
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path_str = 's'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path_str)
    file_path_str_1 = introduced_syntax_errors_0.file_path
    assert file_path_str == file_path_str_1


# Generated at 2022-06-25 19:33:06.981959
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'W'
    str_1 = 'M'
    file_skipped_0 = FileSkipped(str_0, str_1)
    # Assert
    assert file_skipped_0.file_path == str_1
    # Assert
    assert file_skipped_0.message == str_0


# Generated at 2022-06-25 19:33:12.695996
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # Default
    settings_path = '/8i/'
    assert InvalidSettingsPath(settings_path).settings_path == settings_path
    # Default
    settings_path = 'f#G'
    assert InvalidSettingsPath(settings_path).settings_path == settings_path
    # Default
    settings_path = 'eo>'
    assert InvalidSettingsPath(settings_path).settings_path == settings_path


# def test_case_1():
#     str_0 = 'r'
#     str_1 = '`f`'
#     existing_syntax_errors_0 = ExistingSyntaxErrors(str_0, str_1)


# Generated at 2022-06-25 19:33:15.156395
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Create instance of class ProfileDoesNotExist
    profile_does_not_exist_0 = ProfileDoesNotExist('A')


# Generated at 2022-06-25 19:33:17.696557
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'import_module'
    section = 'section'
    missing_section_0 = MissingSection(import_module, section)



# Generated at 2022-06-25 19:33:23.178392
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path: str = 'file_path'
    # check whether the constructor is initialized properly
    file_skip_setting = FileSkipSetting(file_path)
    assert file_skip_setting.__init__(file_path) == "isort was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert file_skip_setting.file_path == file_path


# Generated at 2022-06-25 19:33:29.497074
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # Test the constructor of FileSkipComment
    str_0 = 'W'
    file_skipped_0 = FileSkipComment(str_0)


# Generated at 2022-06-25 19:33:32.760842
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # Pass in a string and a exception
    str_0 = 'W'
    exception_0 = ExistingSyntaxErrors(str_0)
    AssignmentsFormatMismatch(str_0, exception_0)


# Generated at 2022-06-25 19:33:38.819311
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        str_0 = 'W'
        IndexError_0 = IndexError()
        LiteralParsingFailure_0 = LiteralParsingFailure(str_0, IndexError_0)
        LiteralParsingFailure_0.code
        LiteralParsingFailure_0.original_error
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 19:33:41.759828
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'E'
    file_skip_setting_0 = FileSkipSetting(file_path)


# Generated at 2022-06-25 19:33:44.448024
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        LiteralSortTypeMismatch(type, type)
    except Exception as e:
        print("LiteralSortTypeMismatch:", e)



# Generated at 2022-06-25 19:33:46.264327
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'L'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)


# Generated at 2022-06-25 19:33:56.773986
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # Testing constructor with argument 1
    with pytest.raises(AssignmentsFormatMismatch) as excinfo:
        AssignmentsFormatMismatch("a = b")
    assert str(excinfo.value) == "isort was told to sort a section of assignments, however the given code:\n\n" \
                                 "a = b\n\n" \
                                 "Does not match isort's strict single line formatting requirement for assignment " \
                                 "sorting:\n\n" \
                                 "{variable_name} = {value}\n" \
                                 "{variable_name2} = {value2}\n" \
                                 "...\n\n"
    assert excinfo.value.code == "a = b"


# Generated at 2022-06-25 19:34:03.480897
# Unit test for constructor of class FileSkipSetting

# Generated at 2022-06-25 19:34:08.146202
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter_0 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.!@#$%^&*()-=_+[]{}|:;\'"<>?,./'
    syntax_error_0 = FormattingPluginDoesNotExist(formatter_0)


# Generated at 2022-06-25 19:34:10.054937
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = 's'
    file_skip_comment_0 = FileSkipComment(str_0)


# Generated at 2022-06-25 19:34:21.661318
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Testing the constructor of class UnsupportedEncoding
    str_0 = 'W'
    unsupported_encoding_0 = UnsupportedEncoding('W')
    # Testing the method that returns a string representation of this object
    str_1 = unsupported_encoding_0.__str__()
    str_2 = unsupported_encoding_0.__repr__()


# Generated at 2022-06-25 19:34:26.541258
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    str_0 = 'H'
    type_0 = type(str_0)
    str_1 = ''
    type_1 = type(str_1)
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(type_0, type_1)
    assert literal_sort_type_mismatch_0.kind == type_0
    assert literal_sort_type_mismatch_0.expected_kind == type_1


# Generated at 2022-06-25 19:34:37.428028
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    str_0 = ';'
    str_1 = 'T'
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(object, str)
    literal_sort_type_mismatch_1 = LiteralSortTypeMismatch(str, str)
    literal_sort_type_mismatch_2 = LiteralSortTypeMismatch(str, object)
    literal_sort_type_mismatch_3 = LiteralSortTypeMismatch(object, str)
    literal_sort_type_mismatch_4 = LiteralSortTypeMismatch(str, str)
    literal_sort_type_mismatch_5 = LiteralSortTypeMismatch(object, str)
    literal_sort_type_mismatch_6 = LiteralSortTypeMismatch(str, object)

# Generated at 2022-06-25 19:34:40.294823
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # Constructor signature: FileSkipComment(file_path: str) -> None
    str_0 = 'x'
    file_skip_comment_0: FileSkipComment = FileSkipComment(str_0)


# Generated at 2022-06-25 19:34:43.266625
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path_0 = 'cfg'
    file_skip_comment_0 = FileSkipComment(file_path_0)


# Generated at 2022-06-25 19:34:53.137915
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Create a dictionary to represent the settings passed to isort
    settings_dict = {"skip_glob": ["*tests.py"], "skip": ["migrations/*"]}

    # Instantiate an instance of the class to be tested
    file_skipped_0 = FileSkipSetting('/path/to/file/my_file.py')

    # Compare each attribute's expected and actual values
    compare_attr(file_skipped_0, file_skipped_0, 'message', 'my_file.py was skipped as it\'s listed '
                'in \'skip\' setting or matches a glob in \'skip_glob\' setting')
    compare_attr(file_skipped_0, file_skipped_0, 'file_path', '/path/to/file/my_file.py')


# Generated at 2022-06-25 19:35:00.209770
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'W'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert str(invalid_settings_path_0) == "isort was told to use the settings_path: W as the base directory or file that represents the starting point of config file discovery, but it does not exist."
    assert invalid_settings_path_0.settings_path == str_0


# Generated at 2022-06-25 19:35:04.045807
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = int
    expected_kind = str
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind, expected_kind)


# Generated at 2022-06-25 19:35:06.959263
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fileSkip = FileSkipped('test', 'test.txt')
    assert fileSkip.file_path == 'test.txt'



# Generated at 2022-06-25 19:35:15.229839
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # setup
    err_msg = 'isort was provided settings that it doesn\'t support:'
    # test case
    unsupported_settings_str = {
        'not_exist_setting_1': {'type': 'file', 'source': 'file.py'},
        'not_exist_setting_2': {'type': 'cli', 'source': 'file.py'},
        'not_exist_setting_3': {'type': 'config', 'source': 'file.py'}
    }

# Generated at 2022-06-25 19:35:35.449672
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Constructor without parameter
    # str_0 = 'W'
    # invalid_settings_path_0 = InvalidSettingsPath(str_0)
    # expected = invalid_settings_path_0

    # Constructor with parameter
    str_1 = 'data_0'
    file_skip_setting_0 = FileSkipSetting(str_1)
    assert file_skip_setting_0.__init__(str_1) == 0



# Generated at 2022-06-25 19:35:44.495072
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings_0 = {
        'str': {
            'source': 'str',
            'value': 'str'
        }
    }
    unsupported_settings_1 = {
        'list': {
            'source': 'list',
            'value': 'list'
        }
    }
    unsupported_settings_2 = {
        'dict': {
            'source': 'dict',
            'value': 'dict'
        }
    }
    unsupported_settings_3 = {
        'int': {
            'source': 'int',
            'value': 'int'
        }
    }
    unsupported_settings_4 = {
        'None': {
            'source': 'None',
            'value': 'None'
        }
    }

# Generated at 2022-06-25 19:35:48.692617
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    str_0 = 'require'
    str_1 = 'package'
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(str_0, str_1)
    str_0 = literal_sort_type_mismatch_0.kind
    str_1 = literal_sort_type_mismatch_0.expected_kind


# Generated at 2022-06-25 19:35:50.996828
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = 'A'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)
    print(profile_does_not_exist_0)


# Generated at 2022-06-25 19:35:52.163809
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path_0 = "file_path"
    fileskipsetting_0 = FileSkipSetting(file_path_0)
    assert(fileskipsetting_0.file_path == 'file_path')


# Generated at 2022-06-25 19:35:53.624279
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    message = 'Specified formatt'
    FormattingPluginDoesNotExist_0 = FormattingPluginDoesNotExist(message)



# Generated at 2022-06-25 19:35:55.013470
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
	str_0 = 'W'
	assignments_format_mismatch = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:35:56.680742
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    str_0 = 'aA'
    file_skip_setting_0 = FileSkipSetting(str_0)


# Generated at 2022-06-25 19:36:02.119060
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str0 = 'W'
    assignments_format_mismatch0 = AssignmentsFormatMismatch(str0)
    assert assignments_format_mismatch0.code == str0


# Generated at 2022-06-25 19:36:03.990032
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = 'U'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    

# Generated at 2022-06-25 19:36:40.566281
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    literal_0 = '(x for x in range(10))'
    exception_0 = LiteralParsingFailure(literal_0, ISortError)
    kind_0 = type(exception_0)
    exception_1 = LiteralSortTypeMismatch(kind_0, type(list(range(10))))
    print(exception_1.__class__)

# Generated at 2022-06-25 19:36:42.174320
# Unit test for constructor of class ISortError
def test_ISortError():
    exception_object = ISortError()
    assert(exception_object.args == ('Exception of type ISortError was not raised',))


# Generated at 2022-06-25 19:36:42.680925
# Unit test for constructor of class MissingSection
def test_MissingSection():
    test_case_0()


# Generated at 2022-06-25 19:36:43.795630
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = 'test_case'
    UnsupportedEncoding_0 = UnsupportedEncoding(filename)

# Generated at 2022-06-25 19:36:48.798845
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():

    str_0 = 'H'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:36:49.707421
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert settings_path == settings_path


# Generated at 2022-06-25 19:36:58.650242
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # This should be invalid for both cases (otherwise a SyntaxError is raised)
    code_0 = 'a = 1 a = 2'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code_0)
    code_1 = 'a = 1\n a = 2'
    assignments_format_mismatch_1 = AssignmentsFormatMismatch(code_1)
    code_2 = 'a = 1 \na = 2'
    assignments_format_mismatch_2 = AssignmentsFormatMismatch(code_2)
    code_3 = 'a = 1 \r a = 2'
    assignments_format_mismatch_3 = AssignmentsFormatMismatch(code_3)


# Generated at 2022-06-25 19:37:01.811388
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = 'A'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:37:03.855197
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'W'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)


# Generated at 2022-06-25 19:37:09.822327
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'W'
    str_1 = 'W'
    exception_0 = Exception()
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, exception_0)
    str_2 = literal_parsing_failure_0.code
    bool_0 = literal_parsing_failure_0.args
    str_3 = str(literal_parsing_failure_0)
    assert str_2 == str_0
    assert bool_0 == bool()
    assert str_3 == str_1
    exception_1 = literal_parsing_failure_0.original_error
    assert exception_1 == exception_0


# Generated at 2022-06-25 19:38:15.375525
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
 
    # Create a new object from the class UnsupportedEncoding
    unsupported_encoding_1 = UnsupportedEncoding("filename")

    # Test the attributes of the class UnsupportedEncoding
    if (unsupported_encoding_1.filename != "filename"):
        raise AssertionError("Attribute 'filename' of class 'UnsupportedEncoding' doesn't contain the given value!")


# Generated at 2022-06-25 19:38:16.994233
# Unit test for constructor of class MissingSection
def test_MissingSection():
    section = 'O'
    import_module = 'D'
    missing_section_0 = MissingSection(import_module, section)


# Generated at 2022-06-25 19:38:18.244217
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        test_case_0()
    except ISortError:
        print("Failure.")
    else:
        print("Success.")




# Generated at 2022-06-25 19:38:19.955107
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = str
    expected_kind = list
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind, expected_kind)



# Generated at 2022-06-25 19:38:21.462973
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = 'W'
    str_1 = 'I'
    missing_section_0 = MissingSection(str_0, str_1)


# Generated at 2022-06-25 19:38:23.337898
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "test.py"
    obj = IntroducedSyntaxErrors(file_path)
    assert(obj.file_path == file_path)


# Generated at 2022-06-25 19:38:24.439612
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_1 = 't'
    invalid_settings_path_1 = InvalidSettingsPath(str_1)

# Generated at 2022-06-25 19:38:26.408724
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'W'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    str_1 = 'W'
    file_skipped_0 = FileSkipped(str_1, str_0)


# Generated at 2022-06-25 19:38:29.719681
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    str_0 = 'x'
    file_skip_setting_0 = FileSkipSetting(str_0)
    assert file_skip_setting_0.file_path == str_0


# Generated at 2022-06-25 19:38:35.737397
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    str_0 = "Hi"
    str_1 = "Hello"
    str_2 = "Howdy"
    dict_0 = {}
    dict_0['a'] = {'b': 'c'}
    dict_0['b'] = {'b': 'c'}
    dict_0['c'] = {'b': 'c'}
    try:
        UnsupportedSettings(dict_0)
    except UnsupportedSettings as e:
        print(e)
    except:
        print("Unexpected error")
    try:
        UnsupportedSettings(dict_0)
    except UnsupportedSettings as e:
        print(e)
    except:
        print("Unexpected error")


# Generated at 2022-06-25 19:40:40.616296
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'sys'
    section = 'FUTURE'
    MissingSection_class = MissingSection(import_module, section)

# Generated at 2022-06-25 19:40:43.346117
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():

    # Check for any attributes assigned
    str_0 = '!'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert invalid_settings_path_0.settings_path == str_0


# Generated at 2022-06-25 19:40:45.258594
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = 'dummy'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path)


# Generated at 2022-06-25 19:40:46.727096
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'W'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:40:47.969910
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert isinstance(LiteralSortTypeMismatch(None, None), ISortError)

# Generated at 2022-06-25 19:40:52.555188
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Init a str to use in a ExistingSyntaxErrors instance
    str_0 = 'O'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    assert 'O' == existing_syntax_errors_0.file_path


# Generated at 2022-06-25 19:40:53.416855
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({"a": 1})

# Generated at 2022-06-25 19:40:56.403376
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    test_case_0()

# Generated at 2022-06-25 19:40:58.292513
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'W'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:41:01.112047
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Test with a valid file.
    file_path = __file__
    try:
        syntax_errors = ExistingSyntaxErrors(file_path)
    except:
        syntax_errors = None
    assert syntax_errors is not None
