

# Generated at 2022-06-25 19:31:49.807358
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter_0 = ''
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(formatter_0)
    assert formatting_plugin_does_not_exist_0.formatter == formatter_0


# Generated at 2022-06-25 19:31:52.449681
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    # no instance is created for abstract class
    with pytest.raises(TypeError):
        IntroducedSyntaxErrors()

# Generated at 2022-06-25 19:31:54.095110
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = ''
    UnsupportedEncoding(filename)


# Generated at 2022-06-25 19:31:57.236637
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = '`5n`{*\x19)&\n+l^#'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:32:01.174803
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = '\r)(Bp!\n\tQWOO>\rjP]Qy'
    missing_section_0 = MissingSection(str_0, str_0)
    var_1 = missing_section_0.import_module
    assert str_0 is var_1


# Generated at 2022-06-25 19:32:04.003679
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = '\r)(Bp!\n\tQWOO>\rjP]Qy'
    missing_section_0 = MissingSection(str_0, str_0)


# Generated at 2022-06-25 19:32:06.642158
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # Test if it raises an exception when called
    try:
        raise UnsupportedSettings("test")
    except UnsupportedSettings:
        pass


# Generated at 2022-06-25 19:32:13.461582
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    test_str = "foo = bar, baz = hey"
    # Test Case 0:
    try:
        test_case_0()
        test_result = "Fail"
        status = 1
    except ISortError:
        test_result = "Pass"
        status = 0
    assert (test_result == "Pass"), "Test Case: " + str(0) + " " + str(status) + " " + "actual: " + str(test_result) + " " + "expected: " + "Pass"
    # Test Case 1:
    try:
        AssignmentsFormatMismatch(test_str)
        test_result = "Pass"
        status = 0
    except ISortError:
        test_result = "Fail"
        status = 1
    except Exception:
        test_result = "Fail"

# Generated at 2022-06-25 19:32:23.419901
# Unit test for constructor of class FormattingPluginDoesNotExist

# Generated at 2022-06-25 19:32:29.416974
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    unsupported_settings_0 = UnsupportedSettings(dict_0)


# Generated at 2022-06-25 19:32:42.608677
# Unit test for constructor of class UnsupportedSettings

# Generated at 2022-06-25 19:32:45.478543
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "file_path"
    fileSkipSetting = FileSkipSetting(file_path)
    assert fileSkipSetting.file_path == "file_path"


# Generated at 2022-06-25 19:32:49.621247
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assignments_format_mismatch = AssignmentsFormatMismatch("error")
    assert assignments_format_mismatch.code=="error"


# Generated at 2022-06-25 19:32:52.370177
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assignments_format_mismatch = AssignmentsFormatMismatch("123")
    assert assignments_format_mismatch.code == "123"

# Generated at 2022-06-25 19:32:56.324516
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    introduced_syntax_errors_0 = IntroducedSyntaxErrors()
    assert introduced_syntax_errors_0.__class__ == IntroducedSyntaxErrors
    assert introduced_syntax_errors_0.__init__ == IntroducedSyntaxErrors.__init__
    assert introduced_syntax_errors_0.__init__ == IntroducedSyntaxErrors.__init__


# Generated at 2022-06-25 19:32:59.628410
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert_attr_equal(InvalidSettingsPath(settings_path="dummy_string"),
        settings_path="dummy_string")


# Generated at 2022-06-25 19:33:02.527146
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    introduced_syntax_errors = IntroducedSyntaxErrors("file_path")
    assert introduced_syntax_errors.file_path == "file_path"


# Generated at 2022-06-25 19:33:03.873532
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped('test_message', 'test_file_path')


# Generated at 2022-06-25 19:33:05.150885
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    with pytest.raises(Exception):
        UnsupportedSettings(None)

# Generated at 2022-06-25 19:33:07.757792
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'black'
    assert (str(FormattingPluginDoesNotExist(formatter)) == "Specified formatting plugin of " + formatter + " does not exist. ")


# Generated at 2022-06-25 19:33:13.439193
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skip_comment = FileSkipComment("numbers.py")
    assert file_skip_comment


# Generated at 2022-06-25 19:33:16.395556
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = "profile"
    try:
        raise ProfileDoesNotExist(profile)
    except ProfileDoesNotExist as e:
        assert e.profile == profile



# Generated at 2022-06-25 19:33:20.606635
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    _unsupported_settings = {"line_length": {"value": "70", "source": "isort 5.5.4"}}

    _unsupported_settings_class = UnsupportedSettings(_unsupported_settings)
    assert _unsupported_settings_class.unsupported_settings == _unsupported_settings



# Generated at 2022-06-25 19:33:21.854798
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    UnsupportedEncoding(filename="test_file")


# Generated at 2022-06-25 19:33:24.392548
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        assignments_format_mismatch_0 = AssignmentsFormatMismatch('ip_address = "127.0.0.0"')
    except AssignmentsFormatMismatch as err:
        print(err)



# Generated at 2022-06-25 19:33:26.028135
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    LiteralSortTypeMismatch(int, str)

# Generated at 2022-06-25 19:33:28.543604
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    instance_0 = LiteralSortTypeMismatch(int, float)
    assert instance_0.kind == int
    assert instance_0.expected_kind == float


# Generated at 2022-06-25 19:33:33.713178
# Unit test for constructor of class ISortError
def test_ISortError():
    isorterror_1 = ISortError()
    assert hasattr(isorterror_1, 'args')
    assert hasattr(isorterror_1, '__cause__')
    assert hasattr(isorterror_1, '__context__')
    assert hasattr(isorterror_1, 'with_traceback')


# Generated at 2022-06-25 19:33:35.888175
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        InvalidSettingsPath()
        assert False, "Did not raise expected exception!"
    except BaseException:
        pass


# Generated at 2022-06-25 19:33:37.929982
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist("object").formatter == "object"
