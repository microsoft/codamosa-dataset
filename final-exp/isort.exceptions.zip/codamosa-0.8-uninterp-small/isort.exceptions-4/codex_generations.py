

# Generated at 2022-06-25 19:31:49.007617
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = '# isort: unique-tuple'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)

    str_1 = '# isort: unique-tuple'
    literal_parsing_failure_0 = LiteralParsingFailure(str_1, profile_does_not_exist_0)


# Generated at 2022-06-25 19:31:50.729630
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
  assert True # TODO: implement your test here


# Generated at 2022-06-25 19:31:54.358790
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        str_0 = '# isort: unique-tuple'
        raise ExistingSyntaxErrors(str_0)
    except ExistingSyntaxErrors:
        pass


# Generated at 2022-06-25 19:31:56.358612
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'bar'
    invalidSettingsPath = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:31:59.458213
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"key1": "value1"}
    obj = UnsupportedSettings(unsupported_settings)
    assert(obj.unsupported_settings == unsupported_settings)


# Generated at 2022-06-25 19:32:04.298052
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = '# isort: unique-tuple'
    file_skip_comment_0 = FileSkipComment(str_0)
    assert file_skip_comment_0.file_path == str_0


# Generated at 2022-06-25 19:32:15.331477
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assert AssignmentsFormatMismatch.__doc__ == 'Raised when isort is told to sort assignments but the format of the assignment section\ndoesn\'t match isort\'s expectation.\n    '
    assert AssignmentsFormatMismatch.__init__.__doc__ == 'Raised when isort is told to sort assignments but the format of the assignment section\ndoesn\'t match isort\'s expectation.\n    '
    
    # Init an object with string code
    code_0 = 'a = 0'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code_0)

    # Assertion of AssignmentsFormatMismatch.code
    assert assignments_format_mismatch_0.code == code_0

    # Assertion of AssignmentsFormatMismatch.__

# Generated at 2022-06-25 19:32:23.660994
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    # Init
    str_0 = '# isort: unique-tuple'
    exception_0 = Exception("parsing exception")
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, exception_0)
    literal_parsing_failure_0.original_error
    literal_parsing_failure_0.code
    # Test
    assert str(literal_parsing_failure_0) == ("isort failed to parse the given literal "
                                              "# isort: unique-tuple. It's important to note "
                                              "that isort literal sorting only supports simple "
                                              "literals parsable by ast.literal_eval which ga"
                                              "ve the exception of parsing exception.")


# Generated at 2022-06-25 19:32:32.516521
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = '# isort: unique-tuple'
    file_skip_comment_0 = FileSkipComment(str_0)
    assert file_skip_comment_0.message == '# isort: unique-tuple contains an file skip comment and was skipped.'
    assert file_skip_comment_0.file_path == '# isort: unique-tuple'
    assert file_skip_comment_0.args == ('# isort: unique-tuple contains an file skip comment and was skipped.',)


# Generated at 2022-06-25 19:32:35.495870
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = '0.0'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    assert (introduced_syntax_errors_0.file_path == '0.0')


# Generated at 2022-06-25 19:32:42.557344
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    # create the FileSkipped object
    message = "Sample Message"
    file_path = "File Skipped"
    file_skipped_0 = FileSkipped(message, file_path)

    # test assertions
    assert file_skipped_0.message is message
    assert file_skipped_0.file_path == file_path

# Generated at 2022-06-25 19:32:44.551282
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path_0 = None
    file_skip_comment_0 = FileSkipComment(file_path_0)


# Generated at 2022-06-25 19:32:47.510123
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = None
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)



# Generated at 2022-06-25 19:32:50.617517
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist
    except FormattingPluginDoesNotExist as error:
        print(error)


# Generated at 2022-06-25 19:32:54.616250
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = None
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert type(invalid_settings_path_0) is InvalidSettingsPath
    assert invalid_settings_path_0.settings_path is None


# Generated at 2022-06-25 19:32:58.637725
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path = "test"
    instance = InvalidSettingsPath(settings_path)
    assert settings_path == instance.settings_path


# Generated at 2022-06-25 19:33:04.665683
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Arrange
    name = "name"
    available_profiles = ["available_profiles_0", "available_profiles_1", "available_profiles_2"]
    expected = f"Specified profile of {name} does not exist. Available profiles: {','.join(available_profiles)}."
    # Act
    result = ProfileDoesNotExist(name)
    # Assert
    assert result.args == (expected,)
    assert result.profile == name



# Generated at 2022-06-25 19:33:06.982200
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = None
    expected_kind = None
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind, expected_kind)



# Generated at 2022-06-25 19:33:11.008908
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    """
    Testing constructor for FileSkipSetting
    """
    file_path = "tests/test_file_skip_setting.py"
    file_skip_setting_0 = FileSkipSetting(file_path)
    assert file_skip_setting_0.file_path == "tests/test_file_skip_setting.py"


# Generated at 2022-06-25 19:33:12.833878
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = None
    # Instantiate object
    test_object =  UnsupportedEncoding(filename)

# Generated at 2022-06-25 19:33:18.156168
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path_0 = None
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path_0)


# Generated at 2022-06-25 19:33:20.474962
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = None
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)


# Generated at 2022-06-25 19:33:21.524093
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = " import_module "
    section = " section "
    missing_section_0 = MissingSection(import_module, section)

# Generated at 2022-06-25 19:33:24.150469
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    exc = FormattingPluginDoesNotExist('test_mod.py')
    assert exc.formatter == 'test_mod.py'
    assert 'Specified formatting plugin of test_mod.py does not exist. ' == str(exc)

# Generated at 2022-06-25 19:33:26.995267
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path_1 = 'file_path_1'
    FileSkipComment_1 = FileSkipComment(file_path_1)


# Generated at 2022-06-25 19:33:29.404026
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = '$'
    test_FileSkipped_0 = FileSkipped(str_0, str_0)


# Generated at 2022-06-25 19:33:31.558964
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = None
    formattingplugindoesnotexist_0 = FormattingPluginDoesNotExist(str_0)


# Generated at 2022-06-25 19:33:32.941367
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("file_path")


# Generated at 2022-06-25 19:33:36.705310
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = None
    str_1 = "yXlv1yM6"
    str_2 = "1Z2F"
    assert FileSkipped(str_0, str_1).file_path == str_1
    assert FileSkipComment(str_0).message == '{str_0} contains an file skip comment and was skipped.'.format(str_0=str_0)
    assert FileSkipSetting(str_0).message == '{str_0} was skipped as it\'s listed in \'skip\' setting or matches a glob in \'skip_glob\' setting'.format(str_0=str_0)


# Generated at 2022-06-25 19:33:38.640374
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = None
    file_skipped_0 = FileSkipped(str_0, str_0)


# Generated at 2022-06-25 19:33:47.756783
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter_0 = None
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(formatter_0)


# Generated at 2022-06-25 19:33:49.240087
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = '__main__'
    assert isinstance(FormattingPluginDoesNotExist(formatter), ISortError)


# Generated at 2022-06-25 19:33:59.031544
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'black'
    formatting_plguin_does_not_exist_0 = FormattingPluginDoesNotExist(formatter)
    assert formatting_plguin_does_not_exist_0.formatter == formatter
    formatter = 'isort'
    formatting_plguin_does_not_exist_1 = FormattingPluginDoesNotExist(formatter)
    assert formatting_plguin_does_not_exist_1.formatter == formatter
    formatter = 'autopep8'
    formatting_plguin_does_not_exist_2 = FormattingPluginDoesNotExist(formatter)
    assert formatting_plguin_does_not_exist_2.formatter == formatter


# Generated at 2022-06-25 19:34:02.714462
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    item = {
        'abc': {'value': 1, 'source': 'cli'},
        'def': {'value': 2, 'source': 'config'}
    }
    UnsupportedSettings(item)
    return



# Generated at 2022-06-25 19:34:06.267711
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path: str = 'Y2F0Y2hfdGhpcy4=\n'
    invalid_settings_path: InvalidSettingsPath = InvalidSettingsPath(settings_path)
    assert settings_path == invalid_settings_path.settings_path


# Generated at 2022-06-25 19:34:08.059287
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = None
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:34:11.127031
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = None
    str_1 = 'test string'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    isort_error_0 = ISortError(str_1)


# Generated at 2022-06-25 19:34:17.830522
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = 'C:\\Users\\dell\\.isort.cfg'
    exception = UnsupportedEncoding(filename)
    if exception.filename == 'C:\\Users\\dell\\.isort.cfg':
        assert True
    else:
        assert False


# Generated at 2022-06-25 19:34:19.610675
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path_0 = None
    file_skip_comment_0 = FileSkipComment(file_path_0)


# Generated at 2022-06-25 19:34:21.308546
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = None
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
