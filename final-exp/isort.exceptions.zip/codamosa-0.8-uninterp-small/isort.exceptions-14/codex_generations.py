

# Generated at 2022-06-25 19:31:48.625859
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Expected Exception:
    try:
        filename_0 = ['i', 'sort', 'it', 'out']
        unsupported_encoding_0 = UnsupportedEncoding(filename_0)
        error_exception = False
    except:
        error_exception = True
    assert error_exception
    # Expected Exception:
    try:
        filename_0 = ['i', 'sort', 'it', 'out']
        unsupported_encoding_0 = UnsupportedEncoding(filename_0)
        error_exception = False
    except:
        error_exception = True
    assert error_exception
    # Expected Exception:

# Generated at 2022-06-25 19:31:53.722507
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "crap"
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of crap does not exist. "
        assert e.formatter == "crap"


# Generated at 2022-06-25 19:31:55.688714
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(Exception):
        ISortError.__init__()


# Generated at 2022-06-25 19:31:57.292865
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = 'path'
    i_sort_error_1 = ExistingSyntaxErrors(file_path)
    assert i_sort_error_1.file_path == file_path


# Generated at 2022-06-25 19:31:58.458951
# Unit test for constructor of class ISortError
def test_ISortError():
    i_sort_error_1 = ISortError()
    assert isinstance(i_sort_error_1, ISortError)


# Generated at 2022-06-25 19:32:00.238268
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = "profile"
    i_sort_error_0 = ProfileDoesNotExist(profile)


# Generated at 2022-06-25 19:32:03.339611
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    try:
        raise UnsupportedSettings("")
    except UnsupportedSettings as e:
        assert type(e) == UnsupportedSettings

# Generated at 2022-06-25 19:32:06.997834
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment_0 = FileSkipComment("README.rst")
    assert file_skip_comment_0.message.startswith("README.rst contains an file skip comment and was skipped.")


# Generated at 2022-06-25 19:32:14.948659
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error = LiteralParsingFailure('TestString',"TestError")
    assert(str(error) == 'isort failed to parse the given literal TestString. It\'s important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of TestError.')
    assert(error.code == 'TestString')
    assert(error.original_error == 'TestError')


# Generated at 2022-06-25 19:32:20.239399
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path_0 = "test_file_skipped.py"

    file_skipped_0 = FileSkipComment(file_path_0)

    assert isinstance(file_skipped_0, FileSkipped)
    assert file_skipped_0.message == file_path_0 + " contains an file skip comment and was skipped."
    assert file_skipped_0.file_path == "test_file_skipped.py"



# Generated at 2022-06-25 19:32:28.616030
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("file_path")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "file_path"


# Generated at 2022-06-25 19:32:30.597699
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_does_not_exist_0 = ProfileDoesNotExist(str())


# Generated at 2022-06-25 19:32:31.671212
# Unit test for constructor of class ISortError
def test_ISortError():
    assert (isinstance(ISortError(), Exception))



# Generated at 2022-06-25 19:32:33.138685
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting("")


# Generated at 2022-06-25 19:32:36.662431
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    ese1 = ExistingSyntaxErrors("no_such_file.py")
    assert ese1.file_path == "no_such_file.py"
    assert ese1.args == ("isort was told to sort imports within code that contains syntax errors: no_such_file.py.",)


# Generated at 2022-06-25 19:32:39.994691
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "file_path"
    file_skip_comment_0 = FileSkipComment(file_path)


# Generated at 2022-06-25 19:32:41.457716
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError().__str__() == ''



# Generated at 2022-06-25 19:32:43.615121
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("abc", "abc")
    except MissingSection as e:
        assert e.args == ()


# Generated at 2022-06-25 19:32:48.687978
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = '/Users/apple/Documents/ISort.py'
    i_sort_error_1 = FileSkipSetting(file_path)
    assert i_sort_error_1.file_path == file_path


# Generated at 2022-06-25 19:32:53.142863
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = 'tests/indent_test.py'
    try:
        raise FileSkipComment(path)
    except FileSkipComment as fsc_0:
        if fsc_0.file_path != path:
            return False
    return True


# Generated at 2022-06-25 19:33:03.076444
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist
    except FormattingPluginDoesNotExist:
        pass


# Generated at 2022-06-25 19:33:05.355702
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist(formatter='html')
    except FormattingPluginDoesNotExist as fpdne:
        pass



# Generated at 2022-06-25 19:33:06.982569
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_skip_setting_0 = FileSkipSetting("\t"), "\t"


# Generated at 2022-06-25 19:33:08.834940
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = ""
    i_sort_error_1 = IntroducedSyntaxErrors(file_path)


# Generated at 2022-06-25 19:33:10.084544
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profileDoesNotExist = ProfileDoesNotExist("string")

# Generated at 2022-06-25 19:33:16.876092
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = '''
        a = a + b
        c = b / c
        d = a - c
        e = a * b
        f = d / e
        g = e - f
    '''
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        # Test
        assert e.code == code, "code expected to be '{}', but it's '{}'".format(code, e.code)


# Generated at 2022-06-25 19:33:20.733611
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('csv')
    except FormattingPluginDoesNotExist as ex:
        assert ex.formatter == 'csv'
        assert str(ex) == 'Specified formatting plugin of csv does not exist.'


# Generated at 2022-06-25 19:33:23.814090
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure(code="test_code", original_error="test_error")
    except LiteralParsingFailure as e:
        assert e.code == "test_code"
        assert e.original_error == "test_error"



# Generated at 2022-06-25 19:33:35.435998
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    dict_0 = {"unsupported_settings": {"section": "section"}}
    dict_1 = {"unsupported_settings": {"section": "section"}}
    dict_1["unsupported_settings"]["section"] = "section"
    dict_2 = {"unsupported_settings": {"section": "section"}}
    dict_2["unsupported_settings"]["section"] = "section"
    dict_2["unsupported_settings"]["section"] = "section"
    dict_3 = {"unsupported_settings": {"section": "section"}}
    dict_3["unsupported_settings"]["section"] = "section"
    dict_3["unsupported_settings"]["section"] = "section"
    dict_3["unsupported_settings"]["section"] = "section"

# Generated at 2022-06-25 19:33:41.695533
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "foo.py"
    file_skip_setting_0 = FileSkipSetting(file_path=file_path)
    assert file_skip_setting_0.file_path == "foo.py"
    assert file_skip_setting_0.args[0] == "foo.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-25 19:33:53.046991
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'section output options'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    assert introduced_syntax_errors_0.file_path == str_0


# Generated at 2022-06-25 19:33:54.978167
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert isinstance(FormattingPluginDoesNotExist('formatter: str').args[0], str)


# Generated at 2022-06-25 19:33:55.956934
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch.__init__

# Generated at 2022-06-25 19:34:04.957509
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    type_0 = type
    type_1 = type
    assert issubclass(LiteralSortTypeMismatch, ISortError)
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(type_0, type_1)
    assert literal_sort_type_mismatch_0.kind == type_0
    assert literal_sort_type_mismatch_0.expected_kind == type_1
    assert not isinstance(literal_sort_type_mismatch_0, KeyError)
    assert str(literal_sort_type_mismatch_0)[0:11] == 'isort was to'

# Special test case for '__init__' method of class LiteralSortTypeMismatch

# Generated at 2022-06-25 19:34:07.059153
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'section output options'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:34:15.096465
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    message_0 = 'vaxyaW . '
    file_path_0 = 'txywyuf'
    file_skip_setting_0 = FileSkipSetting(message_0, file_path_0)
    assert message_0 == file_skip_setting_0.message
    message_0 = 'fjd'
    file_path_0 = 'jd'
    file_skip_setting_0 = FileSkipSetting(message_0, file_path_0)
    assert message_0 == file_skip_setting_0.message
    message_0 = 'ffj'
    file_path_0 = 'jd'
    file_skip_setting_0 = FileSkipSetting(message_0, file_path_0)
    assert message_0 == file_skip_setting_0.message

# Generated at 2022-06-25 19:34:16.545352
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path_0 = 'test_file_path'
    # Pass
    file_skip_comment_0 = FileSkipComment(file_path_0)


# Generated at 2022-06-25 19:34:18.981184
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'Exception message text'
    isort_error_0 = ISortError(str_0)
    assert isort_error_0.args[0] == 'Exception message text'


# Generated at 2022-06-25 19:34:21.399161
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
	str_0 = 'module_path'
	str_1 = 'filename'
	unsupported_encoding_0 = UnsupportedEncoding(str_1)


if __name__ == '__main__':
    import sys
    import logging

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    test_UnsupportedEncoding()

# Generated at 2022-06-25 19:34:24.588380
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'InvalidSettingsPath'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    str_0 = introduced_syntax_errors_0.file_path
    assert_equal(str_0, 'InvalidSettingsPath')


# Generated at 2022-06-25 19:34:43.240095
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_1 = 'profile'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_1)
    str_0 = profile_does_not_exist_0.profile
    assert str_0 == str_1

    str_1 = 'profile'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_1)



# Generated at 2022-06-25 19:34:45.387930
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = 'section output options'
    file_skip_comment_0 = FileSkipComment(str_0)


# Generated at 2022-06-25 19:34:50.069378
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = 'section output options'
    missing_section_0 = MissingSection(str_0, str_0)
    assert missing_section_0.import_module == str_0
    assert missing_section_0.section == str_0


# Generated at 2022-06-25 19:35:00.953699
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = 'test'
    test_object = ProfileDoesNotExist(profile)
    print(test_object.__str__())
    profile = 'black'
    test_object = ProfileDoesNotExist(profile)
    print(test_object.__str__())
    profile = 'test'
    test_object = ProfileDoesNotExist(profile)
    print(test_object.__str__())
    profile = 'test'
    test_object = ProfileDoesNotExist(profile)
    print(test_object.__str__())
    profile = 'test'
    test_object = ProfileDoesNotExist(profile)
    print(test_object.__str__())
    profile = 'test'
    test_object = ProfileDoesNotExist(profile)
    print(test_object.__str__())
   

# Generated at 2022-06-25 19:35:03.212455
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'file_path'
    file_skip_setting = FileSkipSetting(file_path)
    file_path_val = file_skip_setting.file_path
    assert file_path_val == file_path


# Generated at 2022-06-25 19:35:05.808472
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = 'section output options'
    assert ProfileDoesNotExist(str_0).profile == str_0


# Generated at 2022-06-25 19:35:09.784813
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'hello world'
    exception_0 = ValueError('hello world')
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, exception_0)

# Generated at 2022-06-25 19:35:13.295440
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("error message", "file")
    except FileSkipped as e:
        assert e.file_path == "file"
        assert e.message == "error message"
        assert e.args == ("error message",)


# Generated at 2022-06-25 19:35:25.231604
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = ''
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)
    profile_does_not_exist_0.profile = str_0
    assert profile_does_not_exist_0.profile == str_0
    str_0 = str_0
    profile_does_not_exist_1 = ProfileDoesNotExist(str_0)
    profile_does_not_exist_1.profile = str_0
    assert profile_does_not_exist_1.profile == str_0
    str_0 = ' '
    profile_does_not_exist_2 = ProfileDoesNotExist(str_0)
    profile_does_not_exist_2.profile = str_0
    assert profile_does_not_exist_2.profile == str_0
    str_0

# Generated at 2022-06-25 19:35:30.833414
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    dict_0 = {
        'key101': {
            'value101': 'value101',
            'value102': 'value101',
        },
        'key103': {
            'value101': 'value101',
            'value102': 'value101',
        },
        'key102': {
            'value101': 'value101',
            'value102': 'value101',
        },
    }
    unsupported_settings_0 = UnsupportedSettings(dict_0)

# Generated at 2022-06-25 19:36:03.395803
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'import_module'
    section = 'section'
    missing_section = MissingSection(import_module, section)
    assert missing_section


# Generated at 2022-06-25 19:36:06.984339
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    dict_0 = dict()
    dict_1 = dict()
    dict_0['bar'] = dict_1
    dict_1['source'] = 'source_0'
    dict_1['value'] = 'moo'
    dict_0['foo'] = dict_1
    dict_1['source'] = 'source_0'
    dict_1['value'] = 'moo'

    unsupported_settings_0 = UnsupportedSettings(dict_0)


# Generated at 2022-06-25 19:36:07.849442
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = 'section output options'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:36:09.665580
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'section output options'
    obj = FormattingPluginDoesNotExist(str_0)
    assert isinstance(obj, FormattingPluginDoesNotExist)
    assert obj.formatter == str_0


# Generated at 2022-06-25 19:36:10.928184
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = 'test0.py'
    existing_syntax_errors_0 = ExistingSyntaxErrors(file_path)


# Generated at 2022-06-25 19:36:16.602227
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    string_0 = '4.Q'
    try:
        int(string_0)
    except ValueError as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        literal_parsing_failure_0 = LiteralParsingFailure(string_0, e)


# Generated at 2022-06-25 19:36:18.522752
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'file_skip_comment'
    test_case_FileSkipComment_0(file_path)


# Generated at 2022-06-25 19:36:21.265949
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'section output options'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)



# Generated at 2022-06-25 19:36:24.199027
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    temp_str = 'test'
    temp_ex = Exception()
    temp_test = LiteralParsingFailure(temp_str, temp_ex)


# Generated at 2022-06-25 19:36:27.911555
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'section output options'
    str_1 = 'section output options'
    file_skipped_0 = FileSkipped(str_0, str_1)
    assert file_skipped_0.message == str_0
    assert file_skipped_0.file_path == str_1


# Generated at 2022-06-25 19:37:29.935543
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
  file_path = "MyDirectory/MyFile.txt"
  file_skip_comment_0 = IntroducedSyntaxErrors(file_path)


# Generated at 2022-06-25 19:37:33.454018
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'test'
    file_skip_comment = FileSkipComment(file_path)
    assert file_skip_comment.file_path == file_path
    assert file_skip_comment.message == "{file_path} contains an file skip comment and was skipped.".format(file_path=file_path)
    assert file_skip_comment.args == ('{file_path} contains an file skip comment and was skipped.'.format(file_path=file_path),)


# Generated at 2022-06-25 19:37:36.512676
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Test method invoke with required parameter
    kind_0 = type
    expected_kind_0 = type
    test_case_0 = LiteralSortTypeMismatch(kind_0, expected_kind_0)


# Generated at 2022-06-25 19:37:39.535204
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'dummy_string'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    assert formatting_plugin_does_not_exist_0.formatter == str_0
    print('Test passed')

test_case_0()
test_FormattingPluginDoesNotExist()

# Generated at 2022-06-25 19:37:40.929027
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    string_0 = "dummy.py"
    exception_0 = FileSkipSetting(string_0)


# Generated at 2022-06-25 19:37:43.908345
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = 'data'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)


# Generated at 2022-06-25 19:37:46.179630
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'section output options'
    str_1 = str(0)
    assert isinstance(LiteralParsingFailure(str_0, str_1), LiteralParsingFailure)


# Generated at 2022-06-25 19:37:49.474996
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'section output options'
    file_skipped_0 = FileSkipped(str_0, str_0)
    str_1 = file_skipped_0.message



# Generated at 2022-06-25 19:37:53.170028
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    literal_sort_type_mismatch_type_0 = type(None)
    literal_sort_type_mismatch_type_1 = type(None)
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(literal_sort_type_mismatch_type_0,
                                                           literal_sort_type_mismatch_type_1)


# Generated at 2022-06-25 19:37:58.400393
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'span'
    str_1 = 'hump#'
    file_skipped_0 = FileSkipped(str_0, str_1)
    assert isinstance(file_skipped_0.message, str)
    assert file_skipped_0.file_path == str_1


# Generated at 2022-06-25 19:40:00.162039
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message_0 = 'isort was told to sort imports within code that contains syntax errors'
    file_path_0 = 'file path'
    FileSkipped_obj = FileSkipped(message_0, file_path_0)


# Generated at 2022-06-25 19:40:02.059666
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = 'section output options'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    assert existing_syntax_errors_0.file_path == str_0


# Generated at 2022-06-25 19:40:03.194288
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_1 = 'section output options'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_1)


# Generated at 2022-06-25 19:40:05.337105
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'section output options'
    test_FormattingPluginDoesNotExist_instance_0 = FormattingPluginDoesNotExist(str_0)
    assert test_FormattingPluginDoesNotExist_instance_0.formatter == str_0


# Generated at 2022-06-25 19:40:05.980624
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped != None


# Generated at 2022-06-25 19:40:07.342452
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
	pathname = "abcd"
	assert UnsupportedEncoding(pathname).filename == pathname

# Generated at 2022-06-25 19:40:09.233673
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind_0 = dict
    expected_kind_0 = dict
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind_0, expected_kind_0)


# Generated at 2022-06-25 19:40:12.212224
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'section output options'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    assert formatting_plugin_does_not_exist_0.formatter == str_0

# Generated at 2022-06-25 19:40:13.904248
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch.__doc__ == "Raised when an isort literal sorting comment is used, with a type that doesn't match the supplied data structure's type."

# Generated at 2022-06-25 19:40:17.268823
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('profile')
    except ProfileDoesNotExist as e:
        assert str(e) == 'Specified profile of profile does not exist. Available profiles: black,pep8,pycharm,google,appnexus,blueprints,vendor,thirdparty,wemake,isort.'
        assert e.profile == 'profile'
