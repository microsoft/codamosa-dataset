

# Generated at 2022-06-25 19:31:46.198072
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert isinstance(LiteralSortTypeMismatch(str, bytes), LiteralSortTypeMismatch)


# Generated at 2022-06-25 19:31:48.738344
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    str_0 = '4,bf~dxFi4\x0c[X'
    exception_0 = UnsupportedEncoding(str_0)


# Generated at 2022-06-25 19:31:52.965593
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'v-z\x0b5X'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert invalid_settings_path_0.settings_path == str_0


# Generated at 2022-06-25 19:32:02.207168
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    str_0 = '^\x12\x0f\x04\x0c'
    set_0 = set()
    str_1 = 'op[dP\x0f=\x0c!\x0e>'
    dict_0 = dict()
    # State 0
    # Positive test of class LiteralSortTypeMismatch, with argument 'set'
    try:
        raise LiteralSortTypeMismatch(type(set_0), type(str_0))
    except LiteralSortTypeMismatch:
        pass
    # State 1
    # Positive test of class LiteralSortTypeMismatch, with argument 'dict'
    try:
        raise LiteralSortTypeMismatch(type(dict_0), type(str_1))
    except LiteralSortTypeMismatch:
        pass
   

# Generated at 2022-06-25 19:32:08.664548
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    e0 = None
    expect = 'isort failed to parse the given literal None. It\'s important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of .'

    obj_LiteralParsingFailure = LiteralParsingFailure(e0, e0)
    actual = str(obj_LiteralParsingFailure)
    assert actual == expect, "Expected: %s, but got: %s" % (expect, actual)
    return



# Generated at 2022-06-25 19:32:10.358912
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code_0 = 'my_var = 5'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code_0)
    assert assignments_format_mismatch_0 is not None


# Generated at 2022-06-25 19:32:12.129736
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('import_module', 'section')


# Generated at 2022-06-25 19:32:14.399785
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():

    str_0 = '-8s'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:32:17.484705
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = '4,bf~dxFi4\x0c[X'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:32:18.355805
# Unit test for constructor of class MissingSection
def test_MissingSection():
    test_case_0()


# Generated at 2022-06-25 19:32:21.781864
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    UnsupportedEncoding('/dev/null')


# Generated at 2022-06-25 19:32:22.997178
# Unit test for constructor of class ISortError
def test_ISortError():
    assert isinstance(ISortError(), ISortError)


# Generated at 2022-06-25 19:32:26.117202
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting("test")


# Generated at 2022-06-25 19:32:32.604747
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"setting1": {"value": "value1", "source": "source1"}}
    option = {"value": "value1", "source": "source1"}
    assert UnsupportedSettings._format_option("setting1", option ) == (
        '\t- setting1 = {value: value1, source: source1}'
    )
    assert (
        UnsupportedSettings(unsupported_settings).unsupported_settings
        == unsupported_settings
    )


# Generated at 2022-06-25 19:32:34.909288
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    path_name = "test_file"
    fs = FileSkipSetting(path_name)
    assert fs.file_path == path_name


# Generated at 2022-06-25 19:32:38.000980
# Unit test for constructor of class ISortError
def test_ISortError():
    i_sort_error_0 = ISortError()
    assert i_sort_error_0.args is None


# Generated at 2022-06-25 19:32:43.960689
# Unit test for constructor of class MissingSection
def test_MissingSection():
    section = 'isort'
    import_module = 'isort'
    i_sort_error_0 = MissingSection(import_module, section)
    i_sort_error_0.import_module = "pathlib"
    i_sort_error_0.section = "  'isort',\n"
    i_sort_error_0.args = ("isort", "'isort',\n")


# Generated at 2022-06-25 19:32:45.791035
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped_0 = FileSkipped()
    assert file_skipped_0.file_path is None

# Generated at 2022-06-25 19:32:49.561043
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("hello")
    except AssignmentsFormatMismatch as e:
        pass


# Generated at 2022-06-25 19:32:54.492983
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    filename = "pyfile.py"
    try:
        raise FileSkipComment(filename)
    except FileSkipComment as e:
        print("0 Passed")
    except:
        print("0 Failed")
    if e.file_path != filename:
        print("1 Failed")
    else:
        print("1 Passed")
