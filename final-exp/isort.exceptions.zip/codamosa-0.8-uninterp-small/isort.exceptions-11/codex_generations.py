

# Generated at 2022-06-25 19:31:42.845114
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings_0 = dict()
    UnsupportedSettings(unsupported_settings_0)


# Generated at 2022-06-25 19:31:44.152021
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors('/test')
    assert err.file_path == '/test'


# Generated at 2022-06-25 19:31:50.215930
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # Test with correct data
    unused_dict_0 = {'asd': {'value': 'val', 'source': 'isort.config'}}
    unused_UnsupportedSettings_0 = UnsupportedSettings(unused_dict_0)

    # Test with wrong data
    try:
        UnsupportedSettings('')
    except:
        pass
    else:
        raise Exception("Invalid input must raise exception")


# Generated at 2022-06-25 19:31:56.460178
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(ISortError) as excinfo:
        raise LiteralSortTypeMismatch(str, int)

    assert str(excinfo.value) == 'isort was told to sort a literal of type <class \'int\'> but was given a literal of type <class \'str\'>.'
    assert excinfo.value.kind == str
    assert excinfo.value.expected_kind == int

# Generated at 2022-06-25 19:32:01.373159
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'str'
    str_0 = 'B\x17\x1e\x1e\x1fo\x1a\x1c\x1f\x15'
    missing_section_0 = MissingSection(import_module, str_0)
    assert missing_section_0.import_module == import_module
    assert missing_section_0.section == str_0


# Generated at 2022-06-25 19:32:04.041741
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    output = "Unknown or unsupported encoding in file1"
    ex_0 = UnsupportedEncoding('file1')
    assert ex_0.args[0] == output
    assert ex_0.filename == 'file1'

# Generated at 2022-06-25 19:32:07.373073
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = 'A = B'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code)
    assert assignments_format_mismatch_0.code == code


# Generated at 2022-06-25 19:32:14.591834
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    message = 'test message'
    file_path = 'test file_path'
    file_skip_setting_0 = FileSkipSetting(message)
    assert file_skip_setting_0.file_path == message
    file_skip_setting_1 = FileSkipSetting(file_path)
    assert file_skip_setting_1.file_path == file_path



# Generated at 2022-06-25 19:32:16.097911
# Unit test for constructor of class AssignmentsFormatMismatch

# Generated at 2022-06-25 19:32:23.662282
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    class_dict_0 = {'__name__': 'LiteralSortTypeMismatch', '__init__': __init___0, '__module__': 'isort.exceptions'}
    #
    # The __init__ method of the object.
    #
    # Args:
    #   self: The object pointer.
    #   kind: Describe what the parameter does
    #   expected_kind: Describe what the parameter does
    #
    def __init___0(self, kind, expected_kind):
        LiteralParsingFailure_0 = LiteralParsingFailure
        str_0 = 'isort was told to sort a literal of type %s but was given '
        str_1 = 'a literal of type %s.'