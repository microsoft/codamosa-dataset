

# Generated at 2022-06-25 19:31:50.217910
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = 'wj[`zx[Ua8'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)
    str_0 = profile_does_not_exist_0.missing_profile
    str_1 = profile_does_not_exist_0.profile
    assert str_0 == str_1


# Generated at 2022-06-25 19:31:53.885153
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'abc'
    section = 'def'
    assert MissingSection(import_module, section).import_module == import_module
    assert MissingSection(import_module, section).section == section

# Generated at 2022-06-25 19:31:59.129660
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'wj[`zx[Ua8'
    file_path_1 = 'wj[`zx[Ua8'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path_1)
    isort_error_0 = ISortError(str_0)


# Generated at 2022-06-25 19:32:00.655742
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Check if constructor of given class is throwing exception or not
    try:
        literal_parsing_failure_0 = LiteralParsingFailure(str, Exception)
    except Exception:
        pass



# Generated at 2022-06-25 19:32:04.897522
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error0 = Exception()
    str_0 = 'wj[`zx[Ua8'
    # Create a LiteralParsingFailure object
    literal_parsing_failure = LiteralParsingFailure(str_0, error0)


# Generated at 2022-06-25 19:32:11.933456
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    str_0 = '2'
    dict_0 = {}
    dict_1 = {'dict_1': dict_0}
    # Create a new UnsupportedSettings object
    unsupported_settings = UnsupportedSettings(dict_1)
    # Verify that __init__() raises the exception
    with pytest.raises(Exception) as exception_info:
        unsupported_settings = UnsupportedSettings(dict_1)
    assert str(exception_info.value) == str_0

# Generated at 2022-06-25 19:32:15.286630
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    path = '/path/to/file'
    message = 'Skip {file} for any reason'
    file_skipped = FileSkipped(message, path)
    assert file_skipped.file_path == path


# Generated at 2022-06-25 19:32:20.798417
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    test_dict = { 'u' : { 'name': 'u', 'value': 'u', 'source': 'u' }}
    test_obj = UnsupportedSettings(test_dict)
    assert test_obj.unsupported_settings == test_dict

# Generated at 2022-06-25 19:32:23.113451
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'vF8mY>4~4uO'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)


# Generated at 2022-06-25 19:32:26.103760
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    test_case_0()

# Generated at 2022-06-25 19:32:30.166707
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = 'x{Z\x7f\x7f|DsD'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    assert existing_syntax_errors_0.file_path == str_0


# Generated at 2022-06-25 19:32:41.354010
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = 'xr[`xr[Ua8'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)

    str_1 = 'wj[`zx[Ua8'
    assignments_format_mismatch_1 = AssignmentsFormatMismatch(str_1)
    str_2 = 'BW[`ZW[Ua8'
    assignments_format_mismatch_2 = AssignmentsFormatMismatch(str_2)
    assignments_

# Generated at 2022-06-25 19:32:43.896614
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_1 = 'lk '
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_1)


# Generated at 2022-06-25 19:32:47.382924
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = '_Mf"5z`e5h'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)


# Generated at 2022-06-25 19:32:52.920759
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Constructor should successfully initialize when valid parameters are passed in.
    existing_syntax_errors_0 = ExistingSyntaxErrors('wj[`zx[Ua8')

    assert existing_syntax_errors_0.file_path == 'wj[`zx[Ua8'


# Generated at 2022-06-25 19:32:54.535012
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped('xyz', 'xyz').file_path == 'xyz'


# Generated at 2022-06-25 19:32:57.158677
# Unit test for constructor of class ISortError
def test_ISortError():
    test_case_0()

# Generated at 2022-06-25 19:33:01.066683
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    #Testing for constructor of class FileSkipSetting
    str_0 = 'h>;$"'
    file_skip_setting_0 = FileSkipSetting(str_0)
    assert file_skip_setting_0.file_path == str_0


# Generated at 2022-06-25 19:33:04.175837
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_1 = 'wj[`zx[Ua8'
    formatting_plugin_does_not_exist_1 = FormattingPluginDoesNotExist(str_1)


# Generated at 2022-06-25 19:33:05.107306
# Unit test for constructor of class ISortError
def test_ISortError():
    test_case_0()


# Generated at 2022-06-25 19:33:08.365266
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = 'file_path'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path)


# Generated at 2022-06-25 19:33:18.381185
# Unit test for constructor of class UnsupportedSettings

# Generated at 2022-06-25 19:33:21.037004
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    i_sort_error_0 = InvalidSettingsPath()
    try:
        InvalidSettingsPath(settings_path=3)
    except TypeError:
        pass


# Generated at 2022-06-25 19:33:22.916312
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path_0 = "G"
    i_sort_error_0 = ExistingSyntaxErrors(file_path_0)


# Generated at 2022-06-25 19:33:26.230213
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path_0 = "/"
    i_sort_error_0 = InvalidSettingsPath(settings_path_0)


# Generated at 2022-06-25 19:33:27.978856
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    i_sort_error_1 = FileSkipped('FileSkipped', 'FileSkipped')


# Generated at 2022-06-25 19:33:29.498532
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert not InvalidSettingsPath(settings_path=None)


# Generated at 2022-06-25 19:33:30.826721
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    UnsupportedEncoding("some_file_name.py")


# Generated at 2022-06-25 19:33:32.633448
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment_0 = FileSkipComment("/tmp/example.py")


# Generated at 2022-06-25 19:33:35.338808
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    except_object = UnsupportedEncoding(filename = 'terry')
    assert except_object.filename == 'terry'


# Generated at 2022-06-25 19:33:41.903348
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "message"
    file_path = "file_path"
    file_skipped_0 = FileSkipped(message, file_path)
    file_skipped_1 = FileSkipped(message, file_path)


# Generated at 2022-06-25 19:33:44.139727
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    literal_sort_type_mismatch = LiteralSortTypeMismatch(
        kind = 'list', expected_kind = 'set')


# Generated at 2022-06-25 19:33:45.996572
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "/path/to/file"
    i_sort_error_0 = UnsupportedEncoding(filename)


# Generated at 2022-06-25 19:33:52.401362
# Unit test for constructor of class MissingSection
def test_MissingSection():
    section = 'stdlib'
    import_module = 'os'
    exception = MissingSection(import_module, section)
    assert exception.args[0] == ("Found "+import_module+" import while parsing, but "+section+" was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.")

# Generated at 2022-06-25 19:33:56.310833
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    message = 'Invalid formatter'
    formattingPluginDoesNotExist_0 = FormattingPluginDoesNotExist(message)
    message_getter = formattingPluginDoesNotExist_0.args[0]
    # AssertionError
    assert message_getter == message

# Generated at 2022-06-25 19:33:57.533908
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "test.txt"
    UnsupportedEncoding(filename)


# Generated at 2022-06-25 19:34:01.109532
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    existing_syntax_errors_0 = ExistingSyntaxErrors("__init__.py")
    existing_syntax_errors_0._formatted_message()
    existing_syntax_errors_0._get_message()


# Generated at 2022-06-25 19:34:03.444190
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert invalid_settings_path_0.settings_path == str_0


# Generated at 2022-06-25 19:34:06.605226
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    test_case_0 = FormattingPluginDoesNotExist(
        "Specified formatting plugin of {formatter} does not exist. "
    )
    assert test_case_0.formatter == "{formatter}"


# Generated at 2022-06-25 19:34:11.777145
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        # Exception should be raise because the given file path is not valid 
        raise IntroducedSyntaxErrors("/home/test/test_file.py")
    except Exception as e:
        assert e.args[0] == "isort introduced syntax errors when attempting to sort the imports contained within /home/test/test_file.py."
        assert e.file_path == "/home/test/test_file.py"


# Generated at 2022-06-25 19:34:18.537012
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    introduced_syntax_errors_0 = IntroducedSyntaxErrors("test.py")


# Generated at 2022-06-25 19:34:20.806493
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        UnsupportedEncoding(filename= "test.py")
    except UnsupportedEncoding as err:
        assert err.filename == "test.py"

test_UnsupportedEncoding()

# Generated at 2022-06-25 19:34:23.611035
# Unit test for constructor of class MissingSection
def test_MissingSection():
    print("Testing the constructor of MissingSection class.")
    missing_section_0 = MissingSection(import_module = 'import_module_0', 
                                       section = 'section_0')
    print("Test passed.")


# Generated at 2022-06-25 19:34:25.372936
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_does_not_exist_0 = ProfileDoesNotExist("profile_does_not_exist_0")


# Generated at 2022-06-25 19:34:28.495139
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch("string", "string")
    assert literal_sort_type_mismatch_0.kind == "string"
    assert literal_sort_type_mismatch_0.expected_kind == "string"


# Generated at 2022-06-25 19:34:30.154747
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    lpf_0 = LiteralParsingFailure('print(1)', SyntaxError())


# Generated at 2022-06-25 19:34:36.451009
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'isort was given a file path that is a directory. All options besides --recursive '
    file_path = '/a/b/c/d'
    file_skipped = FileSkipped(message, file_path)
    assert file_skipped.file_path == '/a/b/c/d'


# Generated at 2022-06-25 19:34:42.913637
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    print("Testing FileSkipComment")
    file = '/home/monty/Desktop/isort/isort/mpath/__init__.py'
    try:
        FileSkipComment(file)
    except Exception as ex:
        assert str(ex) == "isort/mpath/__init__.py contains an file skip comment and was skipped."
        # assert ex.file_path == file
        print("Exception handled in function test_FileSkipComment()\n")
    else:
        assert False
    finally:
        print("Execution of function test_FileSkipComment() completed.\n")


# Generated at 2022-06-25 19:34:48.870940
# Unit test for constructor of class MissingSection
def test_MissingSection():
    error = MissingSection('test', 'test1')
    assert error.args[0] == 'Found test import while parsing, but test1 was not included ' \
                            'in the `sections` setting of your config. Please add it before continuing\n' \
                            'See https://pycqa.github.io/isort/#custom-sections-and-ordering ' \
                            'for more info.'

# Generated at 2022-06-25 19:34:58.060834
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_skip_setting_0 = FileSkipSetting("qhqXNp6dK")
    assert file_skip_setting_0.file_path == "qhqXNp6dK"
    assert file_skip_setting_0.args == ("qhqXNp6dK was skipped as it's listed in 'skip' setting"
                                       " or matches a glob in 'skip_glob' setting",)
    assert str(file_skip_setting_0) == ("qhqXNp6dK was skipped as it's listed in 'skip' setting"
                                        " or matches a glob in 'skip_glob' setting")


# Generated at 2022-06-25 19:35:12.951527
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type("type1")
    expected_kind = type("type2")
    literal_sort_type_mismatch = LiteralSortTypeMismatch(kind, expected_kind)
    assert literal_sort_type_mismatch.kind == kind and literal_sort_type_mismatch.expected_kind == expected_kind

# Generated at 2022-06-25 19:35:15.374849
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch_0 = AssignmentsFormatMismatch("code_0")


# Generated at 2022-06-25 19:35:20.395722
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile: str = "test"
    i_sort_error_0 = ProfileDoesNotExist(profile)
    profile = i_sort_error_0.profile
    str_0 = str(i_sort_error_0)
    str_1 = str(i_sort_error_0)


# Generated at 2022-06-25 19:35:23.969614
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_does_not_exist_0 = ProfileDoesNotExist("profile_0")
    profile_does_not_exist_0.profile


# Generated at 2022-06-25 19:35:27.591408
# Unit test for constructor of class ISortError
def test_ISortError():
    i_sort_error_0 = ISortError()
    assert str(i_sort_error_0) == ''


# Generated at 2022-06-25 19:35:31.206922
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    print("Testing constructor of ExistingSyntaxErrors...")
    i_sort_error_0 = ExistingSyntaxErrors('test/path/file.txt')
    assert i_sort_error_0.file_path == 'test/path/file.txt'
    print("ExistingSyntaxErrors passed")
    print()


# Generated at 2022-06-25 19:35:32.531419
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    existing_syntax_errors_0 = ExistingSyntaxErrors("m45kt")


# Generated at 2022-06-25 19:35:38.047616
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    i_sort_error_1 = IntroducedSyntaxErrors("C:\\Test\\File_path.py")
    assert (i_sort_error_1.args[0] == "isort introduced syntax errors when attempting to sort the imports contained within C:\\Test\\File_path.py.")
    assert (i_sort_error_1.file_path == "C:\\Test\\File_path.py")
    assert (isinstance(i_sort_error_1, ISortError))


# Generated at 2022-06-25 19:35:42.192197
# Unit test for constructor of class MissingSection
def test_MissingSection():
    section = 'section'
    import_module = 'import_module'
    missing_section_0 = MissingSection(import_module, section)
    missing_section_0.__str__()
    missing_section_0.__repr__()


# Generated at 2022-06-25 19:35:43.458791
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped_0 = FileSkipped()


# Generated at 2022-06-25 19:35:58.612825
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert issubclass(MissingSection, ISortError)
    assert MissingSection.__doc__ == "Raised when isort encounters an import that matches a section that is not defined"
    if __name__ == "__main__":
        try:
            raise MissingSection("import_module", "section")
        except MissingSection as error:
            assert error.import_module == "import_module"
            assert error.section == "section"
            assert error.args == ('Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.',)
            assert error.__init__.__annotations__ == {'import_module': str, 'section': str}

test_case_

# Generated at 2022-06-25 19:36:05.485648
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():

    file_skip_setting_0 = FileSkipSetting('file_path_0')
    assert file_skip_setting_0.file_path == 'file_path_0'

    actual = str(file_skip_setting_0)
    expected = f"{'file_path_0'} was skipped as it's listed in 'skip' setting" + \
        " or matches a glob in 'skip_glob' setting"
    assert actual == expected


# Generated at 2022-06-25 19:36:06.777282
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "file_path"
    excp_1 = ExistingSyntaxErrors(file_path)
    file_path_0 = excp_1.file_path
    assert file_path_0 == file_path


# Generated at 2022-06-25 19:36:09.754958
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "x = 'import'\n" + "a = 10\n"
    try:
        assignments_format_mismatch_0 = AssignmentsFormatMismatch(code)
    except:
        assignments_format_mismatch_0 = None
    # Run constructor test
    assert assignments_format_mismatch_0 is not None
    assert assignments_format_mismatch_0.code == code


# Generated at 2022-06-25 19:36:10.590763
# Unit test for constructor of class ISortError
def test_ISortError():
    i_sort_error_0 = ISortError()


# Generated at 2022-06-25 19:36:12.664273
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(int, str)
    literal_sort_type_mismatch_1 = LiteralSortTypeMismatch(str, dict)



# Generated at 2022-06-25 19:36:14.487291
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    i_sort_error_0 = IntroducedSyntaxErrors(
        'shlkjfhlsdf'
    )


# Generated at 2022-06-25 19:36:15.292320
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    a = UnsupportedSettings({'x': {}})

# Generated at 2022-06-25 19:36:18.485114
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Init
    file_skip_setting_0 = FileSkipSetting("/home/test.py")
    # Verification
    assert file_skip_setting_0.file_path == "/home/test.py"


# Generated at 2022-06-25 19:36:22.700676
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path_0 = "./test_files/test_file_1.py"
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path_0)


# Generated at 2022-06-25 19:36:48.848359
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = '../isort/foo.py'
    introduced_syntax_errors_1 = IntroducedSyntaxErrors(file_path)


# Generated at 2022-06-25 19:36:49.706231
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('import_module', 'section')

# Generated at 2022-06-25 19:36:53.520669
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    type_0 = str
    type_1 = int
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(type_0, type_1) # Expect no exceptions to be raised

# Generated at 2022-06-25 19:36:56.110500
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped_0 = FileSkipped(message='message', file_path='file_path')
    str(file_skipped_0)
    file_skipped_0.args


# Generated at 2022-06-25 19:36:57.148807
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist("pep8")

# Generated at 2022-06-25 19:37:08.092929
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Test case class
    class UnsupportedEncoding_test_case(Exception):
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2
        
    # Test case with only argument filename
    try:
        raise UnsupportedEncoding_test_case(1,2)
    except UnsupportedEncoding_test_case as e:
        assert e.arg1 + e.arg2 == 3
    
    # Test case with two arguments
    try:
        raise UnsupportedEncoding_test_case(1,'test')
    except UnsupportedEncoding_test_case as e:
        assert e.arg1 == 1
        assert e.arg2 == 'test'

# Generated at 2022-06-25 19:37:13.483677
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"wrong_option": {"value": "something", "source": "config"}}
    # Verify that UnsupportedSettings() throws an exception
    try:
        unsupported_settings_0 = UnsupportedSettings(unsupported_settings)
    except:
        return
    raise Exception # Fail



# Generated at 2022-06-25 19:37:17.899798
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path_str = r"C:\Windows\Profiles"
    settings_path_obj = Path(settings_path_str)
    settings_path_str_empty = ""
    i_sort_error_1 = InvalidSettingsPath(settings_path_str)
    i_sort_error_2 = InvalidSettingsPath(settings_path_obj)
    i_sort_error_3 = InvalidSettingsPath(settings_path_str_empty)


# Generated at 2022-06-25 19:37:18.789479
# Unit test for constructor of class ISortError
def test_ISortError():
    assert type(i_sort_error_0) == ISortError


# Generated at 2022-06-25 19:37:21.107900
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    existing_syntax_errors_0 = ExistingSyntaxErrors(file_path = 'foo.txt')
