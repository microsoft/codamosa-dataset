

# Generated at 2022-06-25 19:31:48.740340
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    print("Testing LiteralParsingFailure class")
    code = "None"
    original_error = Exception()
    literal_parsing_failure_0 = LiteralParsingFailure(code, original_error)
    print("Test complete")



# Generated at 2022-06-25 19:31:50.416777
# Unit test for constructor of class ISortError
def test_ISortError():
    assert issubclass(ISortError, Exception)

# Generated at 2022-06-25 19:31:54.042969
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    existing_syntax_errors_0 = ExistingSyntaxErrors(__name__)
    assert existing_syntax_errors_0.__class__.__name__ == "ExistingSyntaxErrors"


# Generated at 2022-06-25 19:31:57.191967
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with raises(ExistingSyntaxErrors) as ex:
        raise ExistingSyntaxErrors("file_path_0")
    assert ex.value.file_path == "file_path_0"


# Generated at 2022-06-25 19:31:58.782927
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    existing_syntax_errors_0 = ExistingSyntaxErrors(file_path="arg_0")
    assert existing_syntax_errors_0.file_path == 'arg_0'


# Generated at 2022-06-25 19:31:59.731179
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    a = InvalidSettingsPath("DIR")
    assert isinstance(a, InvalidSettingsPath), "Invalid Settings"

# Generated at 2022-06-25 19:32:04.950604
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure(2, 3)
    except LiteralParsingFailure as e:
        assert isinstance(e, LiteralParsingFailure)
        assert e.code == 2
        assert e.original_error == 3


# Generated at 2022-06-25 19:32:07.703770
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # create instance of UnsupportedSettings
    err = UnsupportedSettings({})
    # check if UnsupportedSettings is an instance of ISortError
    assert(isinstance(err, ISortError))

# Generated at 2022-06-25 19:32:11.784590
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("test")
    except InvalidSettingsPath:
        print ("InvalidSettingsPath constructor works as expected")


# Generated at 2022-06-25 19:32:13.145787
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    file_name = 'filename.py'
    UnsupportedEncoding_0 = UnsupportedEncoding(file_name)
    assert UnsupportedEncoding_0.filename == file_name

# Generated at 2022-06-25 19:32:18.705001
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(Exception):
        ExistingSyntaxErrors("FilePath")


# Generated at 2022-06-25 19:32:20.687977
# Unit test for constructor of class ISortError
def test_ISortError():
    assert isinstance(ISortError(), ISortError)


# Generated at 2022-06-25 19:32:23.555743
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    original_error = Exception('Error')
    code = 'int'
    # Constructor of class LiteralParsingFailure
    literal_parsing_failure_0 = LiteralParsingFailure(code, original_error)


# Generated at 2022-06-25 19:32:35.577788
# Unit test for constructor of class UnsupportedSettings

# Generated at 2022-06-25 19:32:38.840395
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "abc.py"
    ue = UnsupportedEncoding(filename)
    assert ue.filename == filename

# Generated at 2022-06-25 19:32:47.709692
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path: str = './test1.py'
    file_skip_setting: FileSkipSetting = FileSkipSetting(file_path)
    assert(isinstance(file_skip_setting, FileSkipSetting))
    assert(isinstance(file_skip_setting, ISortError))
    assert(file_skip_setting.file_path == file_path)
    assert(file_skip_setting.message == f'{file_path} was skipped as it\'s listed in \'skip\' setting'
                                        f' or matches a glob in \'skip_glob\' setting')
    assert(file_skip_setting.__repr__() == f'<FileSkipSetting: {file_path} was skipped as it\'s listed in \'skip\' setting'
                                           f' or matches a glob in \'skip_glob\' setting>')
   

# Generated at 2022-06-25 19:32:53.485493
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        u_n_readable_file_error_0 = UnsupportedEncoding('test_value_0')
        raise Exception(u_n_readable_file_error_0)
    except UnsupportedEncoding as exc_obj:
        assert str(exc_obj) == "Unknown or unsupported encoding in test_value_0"


# Generated at 2022-06-25 19:32:55.058042
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'black'
    exception_object = FormattingPluginDoesNotExist(formatter)



# Generated at 2022-06-25 19:33:05.514670
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    opts = {
        'name_of_the_option_1': 3,
        'name_of_the_option_2': "a string"
    }
    us = UnsupportedSettings(opts)
    assert (
        us.__str__() ==
        "isort was provided settings that it doesn't support:\n\n"
        "\t- name_of_the_option_1 = 3  (source: 'unspecified')\n"
        "\t- name_of_the_option_2 = a string  (source: 'unspecified')\n\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n")

# Generated at 2022-06-25 19:33:10.922523
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Test 0
    profile_does_not_exist_0 = ProfileDoesNotExist("profile_does_not_exist_0")
    assert profile_does_not_exist_0.profile == "profile_does_not_exist_0"
    # Test 1
    profile_does_not_exist_1 = ProfileDoesNotExist("profile_does_not_exist_1")
    assert profile_does_not_exist_1.profile == "profile_does_not_exist_1"

# Generated at 2022-06-25 19:33:19.932397
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    lit_sort_type_mismatch = LiteralSortTypeMismatch(1, (1, 2))

# Generated at 2022-06-25 19:33:22.230148
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    introducedSyntaxErrors = IntroducedSyntaxErrors('main.py')
    assert introducedSyntaxErrors.file_path == 'main.py'


# Generated at 2022-06-25 19:33:23.951344
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    exception_obj = FileSkipSetting('FileSkipSettingtest')
    exception_obj_test = FileSkipSetting('test')



# Generated at 2022-06-25 19:33:25.935669
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    InvalidSettingsPath('/abc/')


# Generated at 2022-06-25 19:33:28.438696
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    invalid_settings_path_0 = InvalidSettingsPath('settings_path')
    assert invalid_settings_path_0.settings_path == 'settings_path'


# Generated at 2022-06-25 19:33:31.460280
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    LiteralParsingException = LiteralParsingFailure('str', 'str')
    assert LiteralParsingException.original_error == 'str'
    assert LiteralParsingException.code == 'str'

# Generated at 2022-06-25 19:33:34.239904
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        MissingSection("test_module", "test_section")
    except Exception as er:
        print(er)


# Generated at 2022-06-25 19:33:36.412320
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    u_e = UnsupportedEncoding(filename='./test_error.py')
    assert u_e.filename == './test_error.py'

# Generated at 2022-06-25 19:33:38.733194
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    invalid_settings_path_0 = InvalidSettingsPath("",)
    invalid_settings_path_0.settings_path


# Generated at 2022-06-25 19:33:41.629373
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_does_not_exist_0 = ProfileDoesNotExist("asdf")
    profile_does_not_exist_0.profile


# Generated at 2022-06-25 19:33:59.229465
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        file_path = "test.py"
        existing_syntax_errors_0 = ExistingSyntaxErrors(file_path)
        assert existing_syntax_errors_0.file_path == file_path
    except:
        assert 1 == 0

# Generated at 2022-06-25 19:34:01.489637
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = '42, a : int\n23, b : int'
    AssignmentsFormatMismatch(code)

# Generated at 2022-06-25 19:34:06.065789
# Unit test for constructor of class IntroducedSyntaxErrors

# Generated at 2022-06-25 19:34:09.215749
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "D:\ML_p\isort\isort\file.py"
    
    existing_syntax_errors_obj = ExistingSyntaxErrors(file_path = file_path)


# Generated at 2022-06-25 19:34:14.002654
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        super().__init__(
            f"Found import while parsing, but  was not included "
            "in the `sections` setting of your config. Please add it before continuing\n"
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
            "for more info."
        )
    except AttributeError:
        pass
    except Exception:
        pass


# Generated at 2022-06-25 19:34:15.968126
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    my_invalid_settings_path = InvalidSettingsPath("C:\\Users\\user\\Desktop\\settings.txt")
    assert my_invalid_settings_path.settings_path == "C:\\Users\\user\\Desktop\\settings.txt"


# Generated at 2022-06-25 19:34:18.352860
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path_0: str = "test"
    try:
        raise FileSkipComment(file_path=file_path_0)
    except FileSkipped:
        pass


# Generated at 2022-06-25 19:34:20.367603
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    # One object of the class
    e = FormattingPluginDoesNotExist("markdown")
    # Test attribute
    assert e.formatter == "markdown"


# Generated at 2022-06-25 19:34:24.438157
# Unit test for constructor of class MissingSection
def test_MissingSection():
   try:
      raise MissingSection('asdf','sdfs')
   except MissingSection as e:
      assert(str(e) == "Found asdf import while parsing, but sdfs was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.")

# Generated at 2022-06-25 19:34:25.511130
# Unit test for constructor of class ISortError
def test_ISortError():
    assert_equal(str(ISortError()), "")


# Generated at 2022-06-25 19:35:00.665113
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    class ExistingSyntaxErrors():
        def __init__(self):
            self.file_path = 'test.py'
            self.args = ISortError(self.file_path)
            self.file_path = 'test.py'
            self.args = (self.file_path)

    e_s_e_0 = ExistingSyntaxErrors()


# Generated at 2022-06-25 19:35:03.947630
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    expected = "isort introduced syntax errors when attempting to sort the imports contained within " \
               "test_UnsupportedEncoding.py."

    # Check if the exception is as expected
    try:
        raise UnsupportedEncoding("test_UnsupportedEncoding.py")
    except UnsupportedEncoding as e:
        assert str(e) == expected

if __name__ == "__main__":
    test_UnsupportedEncoding()

# Generated at 2022-06-25 19:35:07.261647
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file1 = "/home/carl/Documents/PycharmProjects/isort/isort.py"

    IntroducedSyntaxErrors(file1)


# Generated at 2022-06-25 19:35:10.228699
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_0 = "profile_0"
    try:
        raise ProfileDoesNotExist(profile_0)
    except ProfileDoesNotExist:
        pass


# Generated at 2022-06-25 19:35:13.128631
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = "abc"
    try:
        raise ProfileDoesNotExist(profile)
    except ProfileDoesNotExist as e:
        assert e.profile == profile
    except:
        assert False

# Generated at 2022-06-25 19:35:18.426183
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    path = '/home/dwijesh/PycharmProjects/pydev/isort/skipped.py'
    f_skipped_0 = FileSkipped('skipped', path)
    print(f_skipped_0.message, f_skipped_0.file_path)


# Generated at 2022-06-25 19:35:20.555226
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    i_sort_error_1: IntroducedSyntaxErrors = IntroducedSyntaxErrors('test')


# Generated at 2022-06-25 19:35:24.973974
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment_0 = FileSkipComment("tests/test_basic.py")
    file_skip_comment_1 = FileSkipComment("tests/test_basic.py")
    file_skip_comment_2 = FileSkipComment("tests/test_basic.py")


# Generated at 2022-06-25 19:35:26.554203
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError()


# Generated at 2022-06-25 19:35:28.361368
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    with pytest.raises(AttributeError):
        UnsupportedSettings(unsupported_settings = {3: "Test"})


# Generated at 2022-06-25 19:36:01.773790
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    i_sort_error_0 = FileSkipped("message", "file_path")


# Generated at 2022-06-25 19:36:02.783531
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    i_sort_error_0 = ProfileDoesNotExist('test_profile_name')

# Generated at 2022-06-25 19:36:04.047129
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    var_0 = type(lambda: None)()
    var_1 = type(lambda: None)()
    test_case_LiteralSortTypeMismatch = LiteralSortTypeMismatch(var_0, var_1)


# Generated at 2022-06-25 19:36:04.964566
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert type(ISortError) == type(InvalidSettingsPath())


# Generated at 2022-06-25 19:36:08.333715
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = "black"
    profile_does_not_exist_0 = ProfileDoesNotExist(profile)
    assert profile_does_not_exist_0.profile == "black"
    assert profile_does_not_exist_0.args == (
        "Specified profile of black does not exist. Available profiles: black, pyup, google, "
        "pep8, pycharm, nimbus, openstack, google, pep8-naming"
    )


# Generated at 2022-06-25 19:36:10.591787
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code_0 = (
        "x = 1\n"
        "y = 2\n"
        "z = 3\n"
    )
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code_0)


# Generated at 2022-06-25 19:36:12.096626
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "test.py"
    result = UnsupportedEncoding(filename).filename == filename
    print("Test case 0 " + "passed" if result else "failed")


# Generated at 2022-06-25 19:36:13.861412
# Unit test for constructor of class ISortError
def test_ISortError():
    # Test type of variable of class ISortError
    x = ISortError()
    assert type(x) == ISortError


# Generated at 2022-06-25 19:36:14.766568
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert (ISortError())

# Generated at 2022-06-25 19:36:18.599696
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    from isort.exceptions import ProfileDoesNotExist
    from isort.profile._dict_format import profiles_dictionary
    profile_0 = profiles_dictionary.get('default')
    with raises(ProfileDoesNotExist):
        ProfileDoesNotExist('prof_abc')


# Generated at 2022-06-25 19:37:18.731799
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        e_s_e = ExistingSyntaxErrors("/path/to/file")
    except ISortError as e:
        assert "ExistingSyntaxErrors" in str(e)



# Generated at 2022-06-25 19:37:22.126500
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "a"
    section = "b"
    ms = MissingSection(import_module, section)
    assert ms.__init__(import_module, section) == None


# Generated at 2022-06-25 19:37:23.727351
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_skip_setting_0 = FileSkipSetting("file_path")

# ==================

# Generated at 2022-06-25 19:37:30.008772
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        assignments_format_mismatch = AssignmentsFormatMismatch("")
    except ISortError as isort_error_0:
        i_sort_error_0 = ISortError()
        if (
            i_sort_error_0
            == isort_error_0
        ):
            return
    # If AssignmentsFormatMismatch is defined correctly,
    # then the program should not reach this point
    assert False


# Generated at 2022-06-25 19:37:30.956287
# Unit test for constructor of class ISortError
def test_ISortError():
    pass


# Generated at 2022-06-25 19:37:35.189078
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    exception_0: Exception = Exception()
    literal_parsing_failure_0 = LiteralParsingFailure("c", exception_0)
    # Unit test for ISortError.__del__
    try:
        del literal_parsing_failure_0.code
        del literal_parsing_failure_0
    except:
        pass

# Generated at 2022-06-25 19:37:37.225412
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_arg = 'foobar'
    i_sort_error_0 = ProfileDoesNotExist(profile_arg)
    assert i_sort_error_0.profile == profile_arg




# Generated at 2022-06-25 19:37:38.005385
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch("Example")


# Generated at 2022-06-25 19:37:39.369567
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("temp1.py")
    except UnsupportedEncoding:
        return True
    return False


# Generated at 2022-06-25 19:37:40.223102
# Unit test for constructor of class MissingSection
def test_MissingSection():
    with pytest.raises(Exception):
        MissingSection("abc","abc")

# Generated at 2022-06-25 19:38:42.190266
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path_11_0 = '/home/siddhant/Documents/./../isort/isort/tests/test_case_str.py::test_case_0'
    existing_syntax_errors_0 = ExistingSyntaxErrors(file_path_11_0)
    file_path_11 = '/home/siddhant/Documents/./../isort/isort/tests/test_case_str.py::test_case_0'
    existing_syntax_errors_1 = ExistingSyntaxErrors(file_path_11)
    assert existing_syntax_errors_1.file_path == file_path_11


# Generated at 2022-06-25 19:38:47.943982
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    option_name_0 = 'kwarg'
    value_0 = 'utility'
    source_0 = 'module'
    unsupported_settings_0 = UnsupportedSettings({option_name_0: {'source': source_0, 'value': value_0}})


# Generated at 2022-06-25 19:38:50.512319
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "tests/test_file.py"
    file_skip_comment_0 = FileSkipComment(file_path)


# Generated at 2022-06-25 19:38:56.432246
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message_0 = "YeXg'(C*m^_F[&p.b"
    file_path_0 = "/GhH`CQ]9 m*|~Wn"
    File_skipped_0 = FileSkipped(message_0, file_path_0)


# Generated at 2022-06-25 19:39:01.195633
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = Object()
    file_path = Object()
    instance = FileSkipped(message, file_path)

    assert isinstance(instance, FileSkipped)
    assert isinstance(instance, ISortError)
    assert isinstance(instance, Exception)


# Generated at 2022-06-25 19:39:02.703620
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "file"
    file_skip_comment_0 = FileSkipComment(file_path)


# Generated at 2022-06-25 19:39:08.702770
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('/home/vagrant/isort/tests/test_data/error_tests/unsupported_encoding.py')
    except Exception as e:
        assert e.filename == '/home/vagrant/isort/tests/test_data/error_tests/unsupported_encoding.py'


# Generated at 2022-06-25 19:39:12.010279
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'test_path'
    result = FileSkipComment(file_path)
    assert result.message == f'{file_path} contains an file skip comment and was skipped.'
    assert result.file_path == 'test_path'


# Generated at 2022-06-25 19:39:13.141964
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('import_module', 'section')



# Generated at 2022-06-25 19:39:15.713710
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings_0 = {"skip_glob": "*"}
    UnsupportedSettings(unsupported_settings_0)
