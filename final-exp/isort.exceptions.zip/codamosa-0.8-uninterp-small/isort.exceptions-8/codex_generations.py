

# Generated at 2022-06-25 19:31:49.007368
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'P\\5@\\zC)lB`Z'
    isort_error_0 = ISortError(str_0)
    str_1 = 'P\\5@\\zC)lB`Z'
    isort_error_1 = ISortError(str_1)


# Generated at 2022-06-25 19:31:54.149920
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'jn<b[1'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    assert isinstance(formatting_plugin_does_not_exist_0, FormattingPluginDoesNotExist)


# Generated at 2022-06-25 19:31:56.901271
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = ')^s(+z4B4o'
    file_skip_comment_1 = FileSkipComment(str_0)


# Generated at 2022-06-25 19:31:58.594493
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    unused_str_0 = 'neV`C{h'
    profile_does_not_exist_0 = ProfileDoesNotExist(unused_str_0)



# Generated at 2022-06-25 19:31:59.910745
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str = '%G$>7u{Mr+B'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str)


# Generated at 2022-06-25 19:32:03.638811
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = '%G$>7u{Mr+B'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)


# Generated at 2022-06-25 19:32:08.285803
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    str_0 = 'L|`D^\pI`z'
    kind_0 = {}
    expected_kind_0 = 'w"Zz\x1c'
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind_0, expected_kind_0)


# Generated at 2022-06-25 19:32:12.122982
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = '/jOUNu*&'
    str_1 = 'N_dB'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)
    str_2 = "<class 'isort.exceptions.AssignmentsFormatMismatch'>"
    assert type(assignments_format_mismatch_0).__name__ == str_1
    assert str(type(assignments_format_mismatch_0)) == str_2
    assert assignments_format_mismatch_0.code == str_0


# Generated at 2022-06-25 19:32:17.938264
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = '%G$>7u{Mr+B'
    file_skipped_0 = FileSkipped('%G$>7u{Mr+B', str_0)
    assert isinstance(file_skipped_0, FileSkipped)
    assert file_skipped_0.message == '%G$>7u{Mr+B'
    assert file_skipped_0.file_path == str_0


# Generated at 2022-06-25 19:32:22.339085
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # ensure that ProfileDoesNotExist.__init__() didn't change its signature
    # nor behaviour
    str_0 = 'a'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)
    assert profile_does_not_exist_0 is not None


# Generated at 2022-06-25 19:32:26.669711
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    test_case_0()



# Generated at 2022-06-25 19:32:30.511549
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path_0 = 'n#Y*bH=i8F>W:MvA{0NU!N'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path_0)


# Generated at 2022-06-25 19:32:33.595534
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    str_0 = '-<?.jOy'
    file_skip_setting_0 = FileSkipSetting(str_0)
    assert file_skip_setting_0.file_path == str_0



# Generated at 2022-06-25 19:32:35.577827
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_1 = 'PPfk4D4>|'
    file_skip_comment_1 = FileSkipComment(str_1)


# Generated at 2022-06-25 19:32:40.601981
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'module_dummy'
    section = 'section_dummy'
    try:
        MissingSection(import_module, section)
    except ValueError:
        return
    raise RuntimeError('ValueError not raised')


# Generated at 2022-06-25 19:32:48.344558
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = 'J@{y2f0y0}'
    file_skip_comment_0 = FileSkipComment(str_0)
    assert len(file_skip_comment_0.args) == 1
    assert isinstance(file_skip_comment_0.args[0], str)
    str_1 = file_skip_comment_0.args[0]
    assert not str_1.isidentifier()
    assert isinstance(file_skip_comment_0.file_path, str)
    assert file_skip_comment_0.file_path.startswith("J@{y2f0y0} contains an file skip comment")


# Generated at 2022-06-25 19:32:51.140890
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    str_0 = '6"YUc%'
    file_skip_setting_0 = FileSkipSetting(str_0)


# Generated at 2022-06-25 19:32:54.899795
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module_0 = '%G$>7u{Mr+B'
    section_0 = '%G$>7u{Mr+B'
    missing_section_0 = MissingSection(import_module_0, section_0)


# Generated at 2022-06-25 19:32:58.701235
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    # Testing if the exception is raised
    try:
        raise IntroducedSyntaxErrors
    except IntroducedSyntaxErrors:
        assert True


# Generated at 2022-06-25 19:33:04.169777
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    str_1 = '5g5BT5]e8W'
    existing_syntax_errors_1 = ExistingSyntaxErrors(str_1)
    # AssertionError: Passing test
    # assert(existing_syntax_errors_0 != existing_syntax_errors_1)


# Generated at 2022-06-25 19:33:07.763053
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path_0 = 'Yd\n'
    file_skip_setting_0 = FileSkipSetting(
        file_path=file_path_0)


# Generated at 2022-06-25 19:33:15.300073
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        str_0 = '5%<`3q}&{0'
        exception_0 = None
        exception_1 = SyntaxError('Sl0pw}aT$T')
        try:
            literal_parsing_failure_0 = LiteralParsingFailure(str_0, exception_0)
            assert False
        except Exception as exc:
            exception_2 = exc
            literal_parsing_failure_0 = LiteralParsingFailure(str_0, exception_1)
            assert True
    except:
        assert False


# Generated at 2022-06-25 19:33:20.777046
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # Test for constructor of class MissingSection
    # Example: "Found {import_module} import while parsing, but {section} was not included in the `sections` setting of your config. Please add it before continuing. See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
    assert len(str(MissingSection('import_module_0', 'str_0'))) > 0

# Generated at 2022-06-25 19:33:23.778418
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try :
        test_case_0()
    except Exception as err:
        if str(err) != 'isort was told to use the settings_path: 6kqGpl_n>{_ as the base directory or file that represents the starting point of config file discovery, but it does not exist.':
            raise Exception('Failed test')


# Generated at 2022-06-25 19:33:30.950245
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'E\x19\x1f\x06\x07\x14\n\x0e\x07`\x1a'
    str_1 = '\t\x1d\x1b\x17\x1a\r\r \x1d\x0c\x1a\x19\n\x00'
    file_skipped_0 = FileSkipped(str_0, str_1)


# Generated at 2022-06-25 19:33:34.100380
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'Hj+{Oxs'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)

# Generated at 2022-06-25 19:33:36.725372
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = '_G4y4C(zg^*p'
    obj = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:33:41.762075
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = '../test_data/test_a.py'
    message = 'message'
    file_skipped = FileSkipped(message, file_path)
    assert file_skipped.message == message
    assert file_skipped.file_path == file_path


# Generated at 2022-06-25 19:33:42.994638
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    test_FileSkipSetting_0()

# Generated at 2022-06-25 19:33:45.613778
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """
    Test that a class is thrown if kind != expected_kind
    """
    kind = 0
    expected_kind = 1
    sort_type = LiteralSortTypeMismatch(kind, expected_kind)

# Generated at 2022-06-25 19:33:50.729161
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, int)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 19:33:54.451930
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = '6kqGpl_n>{_'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert invalid_settings_path_0.settings_path == str_0



# Generated at 2022-06-25 19:33:57.073810
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = '6kqGpl_n>{_'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:34:00.979098
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {}
    unsupported_settings['indent'] = {'value': 4, 'source': 'CLI'}
    UnsupportedSettings0 = UnsupportedSettings(unsupported_settings)
    assert UnsupportedSettings0.unsupported_settings == unsupported_settings


# Generated at 2022-06-25 19:34:03.302437
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    test_case_0()

# ----------------------------------TESTS FOR ISorter()--------------------------------------------
from isort import Settings, SortImports, SortType, api
from isort.settings import Config

# Generated at 2022-06-25 19:34:06.163371
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_1 = 'O6a4|"`%'
    invalid_settings_path_1 = InvalidSettingsPath(str_1)
    assert invalid_settings_path_1.settings_path == str_1



# Generated at 2022-06-25 19:34:07.195827
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    test_case_0()

# Generated at 2022-06-25 19:34:09.841445
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = ''
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)
    assert profile_does_not_exist_0.profile == ''



# Generated at 2022-06-25 19:34:13.146706
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Create an instance of ProfileDoesNotExist
    profile_does_not_exist = ProfileDoesNotExist('profile_does_not_exist')
    # Validate that instance was created successfully
    assert isinstance(profile_does_not_exist, ProfileDoesNotExist)


# Generated at 2022-06-25 19:34:14.768096
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = '5udN$5^]_W_'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:34:21.124016
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'H6=55st1"Kx1'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:34:24.041683
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code_0 = '```[isort assignment]\nx = "some_code"\n```\n'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code_0)


# Generated at 2022-06-25 19:34:25.948924
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = 'n8E$^A$h@Jn'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)


# Generated at 2022-06-25 19:34:29.409964
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = "'u<A1%4w"
    str_1 = 'hv\~]S9'
    missing_section_0 = MissingSection(str_0, str_1)
    assert missing_section_0.import_module == str_0 and missing_section_0.section == str_1


# Generated at 2022-06-25 19:34:33.980466
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # "tests/test_data/inputs/invalid_imports.py"

    assert MissingSection.__doc__ is not None

    assert MissingSection.__init__.__doc__ is not None



# Generated at 2022-06-25 19:34:37.525921
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    str_0 = '`]T'
    str_1 = 'i:%d-h'
    dic_0 = {str_1: str_0}
    unsupported_settings_0 = UnsupportedSettings(dic_0)


# Generated at 2022-06-25 19:34:43.579722
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    str_0 = '{'
    int_0 = 28
    dict_0 = {str_0: int_0}
    unsupported_settings_0 = UnsupportedSettings(dict_0)
    str_1 = '{'
    int_1 = 32
    dict_1 = {str_1: int_1}
    unsupported_settings_1 = UnsupportedSettings(dict_1)
    str_2 = '{'
    int_2 = 9
    dict_2 = {str_2: int_2}
    unsupported_settings_2 = UnsupportedSettings(dict_2)


# Generated at 2022-06-25 19:34:54.235045
# Unit test for constructor of class MissingSection
def test_MissingSection():
    from tempfile import NamedTemporaryFile
    import os
    import shutil
    import isort.main


# Generated at 2022-06-25 19:35:03.287809
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = '6kqGpl_n>{_'
    expected_result = 'isort failed to parse the given literal 6kqGpl_n>{_. It\'s important ' \
                      'to note that isort literal sorting only supports simple literals ' \
                      'parsable by ast.literal_eval which gave the exception of LiteralSortType' \
                      'Mismatch: isort was told to sort a literal of type \'\' but was given a' \
                      ' literal of type <class \'str\'>.'
    literal = LiteralSortTypeMismatch('', str)
    actual_result = LiteralParsingFailure(str_0, literal).__str__()
    assert expected_result == actual_result


# Generated at 2022-06-25 19:35:07.597255
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Initialization of str
    str_0 = '4qJJ|'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)
    # Accessing instance attribute 'profile'
    profile_does_not_exist_0.profile


# Generated at 2022-06-25 19:35:18.634195
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    # TODO: Test has not been implemented yet...
    pass


# Generated at 2022-06-25 19:35:20.885710
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = Path('/home/janakiram')
    UnsupportedEncoding(filename)



# Generated at 2022-06-25 19:35:24.054737
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'wYk5'
    assert FormattingPluginDoesNotExist(formatter).formatter == formatter


# Generated at 2022-06-25 19:35:29.713717
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = '6kqGpl_n>{_'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    assert formatting_plugin_does_not_exist_0.formatter == str_0
    assert formatting_plugin_does_not_exist_0.args == (str_0,)


# Generated at 2022-06-25 19:35:37.955764
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_2 = 'G'
    str_3 = 'ZXf<'
    str_4 = 'p&=z}'
    str_5 = 'r%r'
    str_6 = 'Rm?o'
    str_0 = ';jz=f'
    str_1 = 'P9sO*'
    missing_section_0 = MissingSection(str_0, str_1)
    missing_section_1 = MissingSection(str_2, str_3)
    missing_section_2 = MissingSection(str_4, str_5)
    missing_section_3 = MissingSection(str_4, str_6)
    missing_section_4 = MissingSection(str_5, str_6)
    missing_section_5 = MissingSection(str_6, str_3)

# Unit

# Generated at 2022-06-25 19:35:47.777419
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'nvL?VC~'
    str_1 = 'w`4;4'
    isort_error_0 = ISortError(str_0)
    isort_error_0.args = (
        str_0,
    )
    isort_error_0.message = str_0
    str_2 = 'Pv{zWb!8Zi'
    invalid_settings_path_0 = InvalidSettingsPath(str_1)
    invalid_settings_path_0.settings_path = str_0
    invalid_settings_path_0.args = (
        invalid_settings_path_0.__doc__,
        invalid_settings_path_0.settings_path,
    )

# Generated at 2022-06-25 19:35:54.878771
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    existing_syntax_errors_0 = ExistingSyntaxErrors('4>0')
    try:
        test_case_0()
    except Exception as exc:
        if not isinstance(exc, ISortError):
            print("FAIL: Constructor of class FormattingPluginDoesNotExist did not produce "
                  "ISortError. Instead produced " + str(type(exc).__name__))
            return
        if str(exc) != 'Specified formatting plugin of ':
            print("FAIL: Constructor of class FormattingPluginDoesNotExist did not produce "
                  "correct string. Instead produced: ")
            print(str(exc))
            return

# Generated at 2022-06-25 19:35:57.277823
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Creation of a string object
    string_0 = 'z>$'
    # Creation of an ExistingSyntaxErrors object
    existing_syntax_errors_0 = ExistingSyntaxErrors(string_0)


# Generated at 2022-06-25 19:36:05.340535
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = '6kqGpl_n>{_'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)

    code_0 = '[datetime.datetime.today(), (datetime.datetime.today().year, datetime.datetime.today().year + 1, datetime.datetime.today().year + 2)]'
    literal_parsing_failure_0 = LiteralParsingFailure(code_0, invalid_settings_path_0)



# Generated at 2022-06-25 19:36:06.800846
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path_0 = 'jw!I_'
    file_skip_comment_0 = FileSkipComment(file_path_0)


# Generated at 2022-06-25 19:36:28.738422
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter_0 = 'Hd'
    test_FormattingPluginDoesNotExist_0 = FormattingPluginDoesNotExist(formatter_0)


# Generated at 2022-06-25 19:36:30.323377
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = str
    expected_kind = int
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind, expected_kind)


# Generated at 2022-06-25 19:36:33.957187
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind_0 = type('dummySymbolTable', (), {'__repr__': lambda self: 'dummySymbolTable'})
    expected_kind_0 = type('dummySymbolTable', (), {'__repr__': lambda self: 'dummySymbolTable'})
    if not (isinstance(LiteralSortTypeMismatch(kind_0, expected_kind_0), ISortError)):
        raise RuntimeError('Expected instance type: ISortError')
    if __name__ == '__main__':
        test_case_0()



# Generated at 2022-06-25 19:36:39.224030
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = '6kqGpl_n>{_'
    key_error_0 = KeyError(str_0)
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, key_error_0)
    # del str_0
    # del key_error_0
    # del literal_parsing_failure_0


# Generated at 2022-06-25 19:36:42.141004
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = '6kqGpl_n>{_'
    with pytest.raises(ISortError) as err_0:
        InvalidSettingsPath(str_0)

# Generated at 2022-06-25 19:36:43.849564
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = '6kqGpl_n>{_'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:36:49.864223
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    test_file = "test.py"
    test_code = '{"test": "test"}'
    literal_parsing_failure_obj = LiteralParsingFailure(test_code,test_file)
    assert literal_parsing_failure_obj.code == test_code
    assert literal_parsing_failure_obj.original_error == test_file

# Generated at 2022-06-25 19:36:55.456206
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = '6kqGpl_n>{_'
    str_1 = '$ys]H~rq&!'

    file_skipped_0 = FileSkipped(str_0, str_1)
    assert file_skipped_0.message == str_0
    assert file_skipped_0.file_path == str_1


# Generated at 2022-06-25 19:36:57.947852
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment('').file_path == '', "Assertion failed."
    assert FileSkipComment('test').file_path == 'test', "Assertion failed."


# Generated at 2022-06-25 19:37:02.072855
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = 'E:\\pycharm\\test_create_file.t'
    UnsupportedEncoding_0 = UnsupportedEncoding(filename)


# Generated at 2022-06-25 19:37:43.644398
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch('test')


# Generated at 2022-06-25 19:37:45.676770
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = '=H]`b|%&j'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:37:46.525383
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting(str)


# Generated at 2022-06-25 19:37:49.951280
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = "settings_path"
    str_1 = '6kqGpl_n>{_'
    invalid_settings_path_0 = InvalidSettingsPath(str_1)
    test_case_0()


# Generated at 2022-06-25 19:37:53.321685
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    string_0 = ''
    path_0 = Path(string_0)
    try:
        unsupported_encoding_0 = UnsupportedEncoding(path_0)
    except Exception as except_0:
        string_1 = ''
        class_0 = str(except_0)
        if string_1 != class_0:
            raise RuntimeError(class_0)



# Generated at 2022-06-25 19:37:58.157488
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    print('Testing constructor')
    str_0 = "a9p+=>/bJ-H"
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert invalid_settings_path_0.settings_path == "a9p+=>/bJ-H"


# Generated at 2022-06-25 19:38:00.994283
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = '6kqGpl_n>{_'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    assert str_0 == formatting_plugin_does_not_exist_0.formatter


# Generated at 2022-06-25 19:38:02.469334
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'test_path'
    fileskipcomment_0 = FileSkipComment(file_path)


# Generated at 2022-06-25 19:38:05.079168
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    str_0_1 = '2zKF}(!|\x0b'
    path_0_0 = Path(str_0_1)
    unsupported_encoding_0 = UnsupportedEncoding(path_0_0)
    assert unsupported_encoding_0.filename == path_0_0


# Generated at 2022-06-25 19:38:05.996603
# Unit test for constructor of class ISortError
def test_ISortError():
    assert type(ISortError()) == ISortError


# Generated at 2022-06-25 19:39:31.652895
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    test_str = "abc"
    test_introduced_syntax_errors = IntroducedSyntaxErrors(test_str)
    assert test_introduced_syntax_errors.file_path == test_str


# Generated at 2022-06-25 19:39:34.912588
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = '6kqGpl_n>{_'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    assert((existing_syntax_errors_0.args[0] == 'isort was told to sort imports within code that contains syntax errors: 6kqGpl_n>{_.'))


# Generated at 2022-06-25 19:39:36.845421
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    str_0 = '9!zg&Z]L3H'
    file_skip_setting_0 = FileSkipSetting(str_0)


# Generated at 2022-06-25 19:39:42.121660
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = '6kqGpl_n>{_'
    str_1 = 'yNDI9Jr(nFn'
    missing_section_0 = MissingSection(str_0, str_1)
    temp = missing_section_0.import_module
    temp = missing_section_0.section
    # test __init__(self: ISortError, *args: Any, **kwargs: Any)
    str_1 = '6kqGpl_n>{_'
    try:
        raise Exception(str_1)
    except Exception as e:
        isort_error_0 = ISortError(*[str_1])
        temp = e.args
