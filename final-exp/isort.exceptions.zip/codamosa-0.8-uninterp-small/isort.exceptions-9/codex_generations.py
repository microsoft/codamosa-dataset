

# Generated at 2022-06-25 19:31:45.824715
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    type_kind = type(type)
    kind_0 = type
    expected_kind = type
    literal_sort_type_mismatch = LiteralSortTypeMismatch(kind_0, expected_kind)

    assert type_kind == type(LiteralSortTypeMismatch.kind) and \
           type_kind == type(LiteralSortTypeMismatch.expected_kind)


# Generated at 2022-06-25 19:31:48.780829
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    existing_syntax_errors_0 = ExistingSyntaxErrors("C:\\Users\\awang\\AppData\\Local\\")
    i_sort_error_0 = ISortError()


# Generated at 2022-06-25 19:31:53.501922
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment_0 = FileSkipComment("")
    assert file_skip_comment_0.message.__contains__
    assert file_skip_comment_0.message.__contains__("contains an file skip comment and was skipped.")



# Generated at 2022-06-25 19:31:55.891318
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(Exception):
        existing_syntax_errors_0 = ExistingSyntaxErrors("")


# Generated at 2022-06-25 19:31:57.530321
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "var = val"
    assignments_format_mismatch = AssignmentsFormatMismatch(code)
    # Check if the AssignmentsFormatMismatch object is created properly
    assert assignments_format_mismatch.code == code

# Generated at 2022-06-25 19:31:59.516061
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    LiteralParsingFailure_0 = LiteralParsingFailure()


# Generated at 2022-06-25 19:32:03.299988
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_does_not_exist_obj = ProfileDoesNotExist("foo")
    assert profile_does_not_exist_obj.profile == "foo"

# Generated at 2022-06-25 19:32:06.954754
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Try to instantiate instance of FileSkipSetting
    try:
        file_skip_setting_0 = FileSkipSetting("test")
    # If the exception is raised, pass the test
    except:
        pass


# Generated at 2022-06-25 19:32:12.128782
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    i_sort_error_1 = LiteralParsingFailure(code)
    assert hasattr(i_sort_error_1,"code")


# Generated at 2022-06-25 19:32:14.779593
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path_0 = 'Kj'
    try:
        IntroducedSyntaxErrors(file_path_0)
    except:
         assert False



# Generated at 2022-06-25 19:32:22.661629
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("")
    except IntroducedSyntaxErrors as e:
        assert str(
            e
        ) == "isort introduced syntax errors when attempting to sort the imports contained within "



# Generated at 2022-06-25 19:32:27.739629
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('C:/Users/vinay/isort/settings')
    except InvalidSettingsPath as e:
        print(e)
    else:
        assert False



# Generated at 2022-06-25 19:32:33.299314
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped_0 = FileSkipped("message", "file_path")
    file_skipped_1 = FileSkipped("message", file_path="file_path_1")
    file_skipped_2 = FileSkipped("message", file_path="file_path_2")
    file_skipped_3 = FileSkipped("message", file_path="file_path_3")


# Generated at 2022-06-25 19:32:40.193845
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # str, str -> ISortError
    def literal_sort_type_mismatch(kind: type, expected_kind: type) -> ISortError:
        return LiteralSortTypeMismatch(kind, expected_kind)
    # Test on valid input
    try:
        assert isinstance(literal_sort_type_mismatch(type('a'), type('b')), ISortError)
    except AssertionError:
        raise
    # Test on invalid input of kind=(1,2,3) and expected_kind='a'
    try:
        literal_sort_type_mismatch(type((1,2,3)), type('a'))
    except:
        pass
    else:
        raise Exception("Invalid input to LiteralSortTypeMismatch() in 'test_case_1' is valid")
    #

# Generated at 2022-06-25 19:32:43.658826
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped_0 = FileSkipped("message", "file_path")
    # Check if the string representation of the instance is the same as the expected one
    assert str(FileSkipped_0) == "message"


# Generated at 2022-06-25 19:32:47.642991
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = 'C:/Users/Lenovo/code/isort/isort/tests/test_resource/test_resource/test_file'
    invalid_settings_path_0 = InvalidSettingsPath(path)


# Generated at 2022-06-25 19:32:53.142517
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message_0 = "Test_case_0"
    Path_0 = Path("/tests/test_error.py")
    file_skipped_0 = FileSkipped(message_0, Path_0)
    assert file_skipped_0.file_path == Path_0.absolute()


# Generated at 2022-06-25 19:32:56.579709
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fs_0 = FileSkipSetting("path/to/file.txt")
    assert fs_0.file_path == "path/to/file.txt"
    assert fs_0.message == "path/to/file.txt was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-25 19:32:58.288017
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert str(ExistingSyntaxErrors("F:/git/isort/isort/readme.md")) == "isort was told to sort imports within code that contains syntax errors: F:/git/isort/isort/readme.md."


# Generated at 2022-06-25 19:33:00.223393
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert issubclass(MissingSection, ISortError)


# Generated at 2022-06-25 19:33:06.087274
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = "/root/test/settings_path.json"
    invalidSettingsPath_0 = InvalidSettingsPath(path)
    assert type(invalidSettingsPath_0.args[0]) == str


# Generated at 2022-06-25 19:33:08.752129
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "x = 1"
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code)
    assert assignments_format_mismatch_0.code == code


# Generated at 2022-06-25 19:33:10.710251
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("abc")
    except IntroducedSyntaxErrors as err:
        assert err.file_path == "abc"

# Generated at 2022-06-25 19:33:12.886027
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
        file_skip_comment_0 = FileSkipComment(
            file_path = 'jfzj.txt',
        )


# Generated at 2022-06-25 19:33:14.968093
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist):
        raise FormattingPluginDoesNotExist("formatter")

# Generated at 2022-06-25 19:33:16.822751
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    literal_parsing_failure_0 = LiteralParsingFailure('Aa0', Exception())


# Generated at 2022-06-25 19:33:18.973066
# Unit test for constructor of class ISortError
def test_ISortError():
    i_sort_error_0 = ISortError()
    assert (i_sort_error_0 is not None)



# Generated at 2022-06-25 19:33:20.907726
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("MyTestFilePath").file_path == "MyTestFilePath"


# Generated at 2022-06-25 19:33:22.797478
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # test case 0
    existing_SyntaxErrors_0 = ExistingSyntaxErrors(".py")


# Generated at 2022-06-25 19:33:30.194601
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = 'not_in_dict'
    profiles = ['google', 'notgoogle']
    profile_does_not_exist = ProfileDoesNotExist(profile)
    assert profile_does_not_exist.profile == 'not_in_dict' and \
           profile_does_not_exist.message == f"Specified profile of {profile} does not exist. " \
                                             f"Available profiles: {','.join(profiles)}."


# Generated at 2022-06-25 19:33:44.490928
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        file_skip_setting_0 = FileSkipSetting("", "")
    except:
        assert(False)
    file_path = "tests/example.py"
    file_skip_setting_0 = FileSkipSetting(file_path)
    assert(file_skip_setting_0.file_path == file_path)
    assert(file_skip_setting_0.args[0] == "tests/example.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting")


# Generated at 2022-06-25 19:33:45.692912
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment_0 = FileSkipComment('test_path')


# Generated at 2022-06-25 19:33:47.884594
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = __file__
    existing_syntax_errors_0 = ExistingSyntaxErrors(file_path)
    existing_syntax_errors_0.file_path


# Generated at 2022-06-25 19:33:49.651748
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assignments_format_mismatch_0 = AssignmentsFormatMismatch("abc")


# Generated at 2022-06-25 19:33:52.796271
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "C:/Users/abc/Desktop/MergeSort_Code.py"
    UnsupportedEncoding(filename)


# Generated at 2022-06-25 19:33:57.945896
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'This is a test message'
    file_path = 'test_file.py'
    file_skipped = FileSkipped(message, file_path)
    message2 = file_skipped.args[0]
    file_path2 = file_skipped.file_path
    assert(message == message2)
    assert(file_path == file_path2)


# Generated at 2022-06-25 19:33:59.474195
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assignments_format_mismatch_0 = AssignmentsFormatMismatch("")


# Generated at 2022-06-25 19:34:05.450851
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = 'example/path'

    try:  # Raises exception of type IntroducedSyntaxErrors
        raise IntroducedSyntaxErrors(file_path)
    except IntroducedSyntaxErrors as error:  # Raises no exception
        assert isinstance(error, IntroducedSyntaxErrors)
        assert str(error) == f"isort introduced syntax errors when attempting to sort the imports contained within {file_path}."


# Generated at 2022-06-25 19:34:07.657176
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path: str = "dummy_filePath"
    file_skip_comment_0 = FileSkipComment(file_path)

# Generated at 2022-06-25 19:34:10.766136
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = "This file contains an isort skip file comment and was skipped."
    test_fs_cmt = FileSkipComment(str_0)
    assert test_fs_cmt.message == str_0


# Generated at 2022-06-25 19:34:25.475484
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "black"
    i_sort_error_1 = FormattingPluginDoesNotExist(formatter)


# Generated at 2022-06-25 19:34:27.085576
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "variable_name = value"
    assignments_format_mismatch = AssignmentsFormatMismatch(code)


# Generated at 2022-06-25 19:34:29.085548
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "/test/test.py"
    ue = UnsupportedEncoding(filename)
    filename_out = ue.filename
    assert filename_out == filename



# Generated at 2022-06-25 19:34:30.519145
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_skip_setting = FileSkipSetting('file_path')


# Generated at 2022-06-25 19:34:33.879436
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    path = 'filename'
    i_sort_error_0 = FileSkipSetting(path)


# Generated at 2022-06-25 19:34:38.686580
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Arrange
    kind = type
    expected_kind = type
    # Act
    literal_sort_type_mismatch = LiteralSortTypeMismatch(kind, expected_kind)
    # Assert
    assert literal_sort_type_mismatch.kind == kind
    assert literal_sort_type_mismatch.expected_kind == expected_kind

# Generated at 2022-06-25 19:34:42.579873
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        str_0 = "import urllib3"
        str_1 = "TEST"
        missing_section = MissingSection(str_0, str_1)
        if missing_section is not None:
            print("Exception")
            assert False
        else:
            assert True
    except:
        assert True

# Generated at 2022-06-25 19:34:43.748499
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert isinstance(UnsupportedSettings(), ISortError)

# Generated at 2022-06-25 19:34:49.629061
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    f_skip_setting_0 = FileSkipSetting("hu_0.py")
    assert f_skip_setting_0.file_path == "hu_0.py"
    assert f_skip_setting_0.message == "hu_0.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-25 19:34:58.950579
# Unit test for constructor of class ISortError
def test_ISortError():
    i_sort_error_0 = ISortError()
    assert not hasattr(i_sort_error_0, 'code')
    import io
    import sys
    from contextlib import contextmanager
    @contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old
    with stdoutIO() as f:
        i_sort_error_0.__str__()
        assert f.getvalue() == '\n'


# Generated at 2022-06-25 19:35:20.385308
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert(UnsupportedEncoding(Path('/home/user/PycharmProjects/isort/isort/tests/test_file.py')).filename == Path('/home/user/PycharmProjects/isort/isort/tests/test_file.py'))
    assert(UnsupportedEncoding('/home/user/PycharmProjects/isort/isort/tests/test_file.py').filename == '/home/user/PycharmProjects/isort/isort/tests/test_file.py')

# Generated at 2022-06-25 19:35:22.026234
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    i_sort_error_1 = LiteralParsingFailure()


# Generated at 2022-06-25 19:35:24.408875
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    e_s_e = ExistingSyntaxErrors("a.py")


# Generated at 2022-06-25 19:35:29.333406
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch("list", "tuple")
    except LiteralSortTypeMismatch as e:
        assert isinstance(e, LiteralSortTypeMismatch)
        assert e.expected_kind == "tuple"
        assert e.kind == "list"
        return
    assert False



# Generated at 2022-06-25 19:35:31.440508
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        UnsupportedEncoding("/home/path")
    except Exception as e:
        assert type(e) == UnsupportedEncoding


# Generated at 2022-06-25 19:35:32.772742
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_does_not_exist_0 = ProfileDoesNotExist('test_string_0')


# Generated at 2022-06-25 19:35:37.512449
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
  litSortTypeMismatch = LiteralSortTypeMismatch("int", "string")

InvalidSettingsPath("fixture/bad/settings_path/isort.cfg")
import ast
with open("fixture/good/multiline_literal/literal_sort.py", "r") as literal_sort:
    code = literal_sort.read()
    ast.literal_eval(code)

# Generated at 2022-06-25 19:35:42.341770
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "test.py"
    msg = "isort introduced syntax errors when attempting to sort the imports contained within test.py."
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path)
    assert introduced_syntax_errors_0.args[0] == msg, "test_IntroducedSyntaxErrors"


# Generated at 2022-06-25 19:35:43.154624
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection is ISortError


# Generated at 2022-06-25 19:35:44.884179
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    existing_error = ExistingSyntaxErrors('file path')
    assert repr(existing_error) == 'file path'

# Generated at 2022-06-25 19:36:04.993834
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = 'HTMLParser(check_in_module)'
    str_1 = '[]'
    missing_section_0 = MissingSection(str_0, str_1)

if __name__ == '__main__':
    # Unit test for constructor of class LiteralSortTypeMismatch
    test_case_0()
    # Unit test for constructor of class MissingSection
    test_MissingSection()

# Generated at 2022-06-25 19:36:06.061202
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    obj = LiteralSortTypeMismatch(None, None)
    assert obj


# Generated at 2022-06-25 19:36:08.140242
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'import a # isort: imports-from'
    str_1 = 'import b # isort: imports-from'
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, str_1)


# Generated at 2022-06-25 19:36:10.968896
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_3 = 'html'
    str_4 = '5'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_3)
    str_6 = 'html'
    str_7 = '6'
    introduced_syntax_errors_1 = IntroducedSyntaxErrors(str_6)
    str_5 = 'hello'
    introduced_syntax_errors_2 = IntroducedSyntaxErrors(str_5)


# Generated at 2022-06-25 19:36:17.197383
# Unit test for constructor of class FileSkipComment

# Generated at 2022-06-25 19:36:18.944194
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = 'HTMLParser'
    file_skip_comment_0 = FileSkipComment(str_0)


# Generated at 2022-06-25 19:36:24.512245
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'HTMLParser'
    str_1 = '8M\n$v'
    file_skipped_0 = FileSkipped(str_0, str_1)
    assert file_skipped_0.message == str_0
    assert file_skipped_0.file_path == str_1


# Generated at 2022-06-25 19:36:26.276995
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    syntax_err_msg = 'Syntax Error'
    assert IntroducedSyntaxErrors(syntax_err_msg).__str__() == syntax_err_msg


# Generated at 2022-06-25 19:36:28.823325
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = '1'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)
    assert(profile_does_not_exist_0 is not None)


# Generated at 2022-06-25 19:36:31.062300
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'j_f8'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    assert formatting_plugin_does_not_exist_0.formatter == 'j_f8'



# Generated at 2022-06-25 19:37:00.743364
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_does_not_exist_0 = ProfileDoesNotExist('abc')


# Generated at 2022-06-25 19:37:04.559464
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter_0 = 'formatter_0'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(formatter_0)
    # fmt: off
    assert formatting_plugin_does_not_exist_0.formatter == formatter_0
    # fmt: on


# Generated at 2022-06-25 19:37:07.526959
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    file_skipped_0 = FileSkipped(".", ".")
    assignments_format_mismatch_0 = AssignmentsFormatMismatch("\t")


# Generated at 2022-06-25 19:37:12.201651
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    if __debug__:
        str_0 = 'test_case_0'
        assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:37:17.466176
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'HTMLParser'
    str_1 = '8M\n$v'
    exception_0 = FileSkipped(str_0, str_1)
    literal_parsing_failure_0 = LiteralParsingFailure('!\x0b', exception_0)
    str_2 = literal_parsing_failure_0.code
    str_3 = literal_parsing_failure_0.original_error.message


# Generated at 2022-06-25 19:37:18.761736
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'HTMLParser'
    isort_error_0 = ISortError(str_0)


# Generated at 2022-06-25 19:37:29.260582
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['source'] = 'file: .isort.cfg'
    dict_1['value'] = 'A'
    dict_0['default_section'] = dict_1
    dict_2 = dict()
    dict_2['source'] = 'file: .isort.cfg'
    dict_2['value'] = 'y'
    dict_0['known_future_library'] = dict_2
    dict_3 = dict()
    dict_3['source'] = 'file: .isort.cfg'
    dict_3['value'] = 'B'
    dict_0['known_first_party'] = dict_3
    dict_4 = dict()
    dict_4['source'] = 'file: .isort.cfg'

# Generated at 2022-06-25 19:37:32.678484
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    str_0 = 'namedtuple'
    str_1 = 'frozenset'
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(str_0, str_1)
    # print(literal_sort_type_mismatch_0.expected_kind)


# Generated at 2022-06-25 19:37:36.691776
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('HTMLParser', '8M\n$v').__str__() == 'Found HTMLParser import while parsing, but 8M\n$v was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'


# Generated at 2022-06-25 19:37:39.482205
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'HTMLParser'
    str_1 = '8M\n$v'
    file_skipped_0 = FileSkipped(str_0, str_1)
    assert str_0 == file_skipped_0.message
    assert str_1 == file_skipped_0.file_path

# Generated at 2022-06-25 19:38:37.907997
# Unit test for constructor of class UnsupportedSettings

# Generated at 2022-06-25 19:38:41.082071
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    str_0 = 'file.txt'
    obj_0 = UnsupportedEncoding(str_0)
    exception_1 = obj_0
    assert type(str_0) is str
    assert exception_1 is obj_0


# Generated at 2022-06-25 19:38:43.634463
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped_0 = FileSkipped('foo', 'foo')
    assert file_skipped_0.file_path == 'foo'



# Generated at 2022-06-25 19:38:47.842705
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    filename = 'test/test_case.py'
    file_skipped = FileSkipped('', filename)
    assert file_skipped.file_path == 'test/test_case.py'


# Generated at 2022-06-25 19:38:52.343490
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = '<string>'
    file_skip_comment_0 = FileSkipComment(str_0)
    str_1 = "file_path contains an file skip comment and was skipped."
    str_2 = "file_path"
    assert file_skip_comment_0.message == str_1
    assert file_skip_comment_0.file_path == str_2

# Generated at 2022-06-25 19:38:55.277423
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'F6?\"m6i'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:38:57.261801
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = 'HTMLParser'
    str_1 = '8M\n$v'
    file_skip_comment_0 = FileSkipComment(str_1)
test_case_0()
test_FileSkipComment()


# Generated at 2022-06-25 19:39:04.941192
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'HTMLParser'
    str_1 = '8M\n$v'
    file_skipped_0 = FileSkipped(str_0, str_1)
    instance_of(file_skipped_0, FileSkipped, "Expected file_skipped_0 to be instance of FileSkipped, but got", file_skipped_0)
    str_2 = 'HTMLParser'
    equal(str_2, file_skipped_0.message, "Expected file_skipped_0.message to be equal to str_2, but got", file_skipped_0.message, str_2)
    str_3 = '8M\n$v'

# Generated at 2022-06-25 19:39:07.872578
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = 'profile'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)


# Generated at 2022-06-25 19:39:12.413526
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Get str from test case
    str_0 = 'HTMLParser'
    str_1 = '8M\n$v'
    # Set expected output
    expected_output = UnsupportedEncoding(str_0)

    # Get output
    output = UnsupportedEncoding(str_0)
    # Compare output to expected output
    assert output.filename == expected_output.filename


# Generated at 2022-06-25 19:40:57.946703
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    a = 1
    b = 2
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(a)
    assignments_format_mismatch_1 = AssignmentsFormatMismatch(b)


# Generated at 2022-06-25 19:41:00.202464
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'HTMLParser'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)


# Generated at 2022-06-25 19:41:02.019966
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = 'HTMLParser'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    str_1 = existing_syntax_errors_0.file_path
    assert str_1 == str_0


# Generated at 2022-06-25 19:41:05.664442
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Create a new instance of UnsupportedEncoding
    str_0 = 'HTMLParser'
    str_1 = '8M\n$v'
    unsupported_encoding_0 = UnsupportedEncoding(str_1)
    print(unsupported_encoding_0.filename)


# Generated at 2022-06-25 19:41:10.856725
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():

    file_path = '/home/georgia/isort/isort'

    try:
        raise IntroducedSyntaxErrors(file_path)
    except IntroducedSyntaxErrors as introduced_syntax_errors:
        assert introduced_syntax_errors.file_path == file_path


# Generated at 2022-06-25 19:41:14.706428
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    type_0 = type
    type_1 = type
    for i in range(0, 1):
        str_0 = 'HTMLParser'
        str_1 = '8M\n$v'
        literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(type_0, type_1)



# Generated at 2022-06-25 19:41:15.973456
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    file_path = 'isort/settings.py'
    error_0 = UnsupportedEncoding(file_path)


# Generated at 2022-06-25 19:41:18.918901
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = 'test_case_0.py'
    file_skip_comment_0 = FileSkipComment(str_0)
    str_1 = 'file_skip_comment_0.file_path'
    assert (getattr(file_skip_comment_0, str_1) == str_0)

# Generated at 2022-06-25 19:41:20.873185
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_file_path = '%KWo|'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_file_path)
    assert existing_syntax_errors_0.file_path == str_file_path


# Generated at 2022-06-25 19:41:22.172917
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = 'x = 1\n'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code)
