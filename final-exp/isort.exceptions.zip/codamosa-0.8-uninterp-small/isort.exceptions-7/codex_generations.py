

# Generated at 2022-06-25 19:31:48.300331
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    string_0 = 'T:2k^`T'
    invalid_settings_path_0 = InvalidSettingsPath(string_0)
    assert (
        invalid_settings_path_0.settings_path
        == 'T:2k^`T'
    ), 'isort.exceptions.InvalidSettingsPath.settings_path == \'T:2k^`T\''

# Generated at 2022-06-25 19:31:54.554877
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = 'NjpP%5`'
    message = 'NjpP%5`'
    file_skipped_0 = FileSkipped(message, file_path)
    str_0 = ')'
    # Exception handling code
    try:
        file_skipped_0 = FileSkipped(str_0, file_path)
    except TypeError as e:
        pass


# Generated at 2022-06-25 19:32:00.299338
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = 'test'
    message = 'Message'
    fileskipped_0 = FileSkipped(message, file_path)
    assert isinstance(fileskipped_0, FileSkipped)
    str_0 = 'test'
    fileskipped_1 = FileSkipped(message, str_0)
    assert isinstance(fileskipped_1, FileSkipped)


# Generated at 2022-06-25 19:32:02.677423
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(str, str)


# Generated at 2022-06-25 19:32:05.148134
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = str_0
    message = str_0
    file_skipped_0 = FileSkipped(message, file_path)


# Generated at 2022-06-25 19:32:08.513429
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    int_0 = 7
    str_0 = 'NjpP%5`'
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(int_0, str_0)


# Generated at 2022-06-25 19:32:11.784560
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'd1Z'
    invalid_settings_path_0 = InvalidSettingsPath('d1Z')



# Generated at 2022-06-25 19:32:14.050535
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = "test"
    profile_does_not_exist_0 = ProfileDoesNotExist(profile)
    if profile_does_not_exist_0.profile is not None:
        print("Profile: ", profile_does_not_exist_0.profile)


# Generated at 2022-06-25 19:32:15.987150
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'g8/'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:32:18.715242
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = 'NjpP%5`'
    existing_syntax_errors_0 = ExistingSyntaxErrors(file_path)

# Generated at 2022-06-25 19:32:23.077238
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        str_0 = 'NjpP%5`'
        file_skipped_0 = FileSkipped('file_path', str_0)
    except:
        file_skipped_0 = None
    assert file_skipped_0 is not None


# Generated at 2022-06-25 19:32:29.461556
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    int_0 = 3889
    int_1 = 603
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(int_0, int_1)
    str_0 = 'c%~2!e'


# Generated at 2022-06-25 19:32:40.552837
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'ﾏ'
    str_1 = '((ZHV'
    file_skip_comment_0 = FileSkipComment(str_0)
    isort_error_0 = ISortError()
    isort_error_1 = ISortError()
    isort_error_0.__init__()
    isort_error_1.__init__(str_1)
    str_2 = 'Bh'
    str_3 = 'Z+)'
    str_4 = 'f'
    str_5 = '9'
    str_6 = 'B'
    str_7 = 'D]`Y'
    str_8 = '@L'
    str_9 = '@L'
    str_10 = '@L'
    str_11 = '@L'
    str_

# Generated at 2022-06-25 19:32:48.626835
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'NjpP%5`'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    assert isinstance(introduced_syntax_errors_0, IntroducedSyntaxErrors)
    assert isinstance(introduced_syntax_errors_0, ISortError)
    assert introduced_syntax_errors_0.file_path == str_0
    str_0 = '~oQOmOU'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    assert isinstance(introduced_syntax_errors_0, IntroducedSyntaxErrors)
    assert isinstance(introduced_syntax_errors_0, ISortError)
    assert introduced_syntax_errors_0.file_path == str_0

# Generated at 2022-06-25 19:32:55.423885
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'MtpWgQv_'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, invalid_settings_path_0)


if __name__ == '__main__':
    test_case_0()
    test_LiteralParsingFailure()

# Generated at 2022-06-25 19:32:59.572253
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'NjpP%5`'
    file_skipped_0 = FileSkipped(str_0, str_0)


# Generated at 2022-06-25 19:33:05.207979
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path_0 = 'd%S\x00'
    file_skip_comment_0 = FileSkipComment(file_path_0)
    file_path_1 = 'xA|'
    file_skip_comment_1 = FileSkipComment(file_path_1)
    file_skip_comment_0.file_path
    file_skip_comment_0.message
    file_skip_comment_1.file_path
    file_skip_comment_1.message


# Generated at 2022-06-25 19:33:07.159447
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    test_FileSkipped_0()
    test_FileSkipped_1()
    test_FileSkipped_2()


# Generated at 2022-06-25 19:33:09.761516
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    str_0 = '9a$1_sY'
    file_skip_setting_0 = FileSkipSetting(str_0)
    assert file_skip_setting_0 != None


# Generated at 2022-06-25 19:33:18.431188
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_1 = 'aD]s`Z-'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_1)
    str_2 = f'{str_1}_{str_1}'
    str_3 = f'${str_2}'
    str_4 = f'{str_1}|{str_2}'

    # check if type of variable is AssignmentsFormatMismatch
    assert isinstance(assignments_format_mismatch_0, AssignmentsFormatMismatch)

    # check if variable is equal
    assert assignments_format_mismatch_0.code == str_4



# Generated at 2022-06-25 19:33:20.816256
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = ISortError
    formatter_object = FormattingPluginDoesNotExist(formatter)


# Generated at 2022-06-25 19:33:22.394418
# Unit test for constructor of class ISortError
def test_ISortError():
    ISortError_instance = ISortError()
    assert ISortError_instance is not None


# Generated at 2022-06-25 19:33:29.243137
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    from typing import List
    # From vscode-python
    code = (
        "array = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])\n"
        "transposed = array.transpose()\n"
        "x = transposed[1]\n"
    )
    exception = AssignmentsFormatMismatch(code=code)
    assert exception.code == code


# Generated at 2022-06-25 19:33:31.054975
# Unit test for constructor of class ISortError
def test_ISortError():
    assert isinstance(ISortError(), Exception)
    assert isinstance(ISortError(), ISortError)


# Generated at 2022-06-25 19:33:32.504129
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    checker = ProfileDoesNotExist("profile")


# Generated at 2022-06-25 19:33:35.997674
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "value = 3"
    try:
        assignments_format_mismatch_0 = AssignmentsFormatMismatch(code)
    except ISortError:
        pass



# Generated at 2022-06-25 19:33:38.024540
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection("testImport","testSection").__init__("testImport","testSection") == None

# Generated at 2022-06-25 19:33:47.849957
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment_0 = FileSkipComment('/home/benjamin/Dropbox/School/'
                                          'Spring 2018/CSE 535/public/group_05/project_2/src/compile.py')
    file_skip_comment_1 = FileSkipComment('/home/benjamin/Dropbox/School/'
                                          'Spring 2018/CSE 535/public/group_05/project_2/src/compile.py')
    file_skip_comment_2 = FileSkipComment('test_0.py')
    file_skip_comment_3 = FileSkipComment('test_1.py')
    file_skip_comment_4 = FileSkipComment('test_2.py')
    file_skip_comment_5 = FileSkipComment('test_3.py')
    file_skip_comment_

# Generated at 2022-06-25 19:33:49.225926
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_not_exist = ProfileDoesNotExist("black")


# Generated at 2022-06-25 19:33:55.999985
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    i_sort_error_1 = FormattingPluginDoesNotExist("xyz")
    assert isinstance(i_sort_error_1, ISortError)
    assert isinstance(i_sort_error_1, Exception)
    assert str(i_sort_error_1) == "Specified formatting plugin of xyz does not exist. "
    assert i_sort_error_1.formatter == "xyz"


# Generated at 2022-06-25 19:34:00.846631
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = UnsupportedSettings({})
    assert unsupported_settings.unsupported_settings == {}


# Generated at 2022-06-25 19:34:02.552911
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assignments_format_mismatch_0 = AssignmentsFormatMismatch("messages.json")


# Generated at 2022-06-25 19:34:05.695679
# Unit test for constructor of class ISortError
def test_ISortError():
    # Create ISortError object
    i_sort_error = ISortError()

    # Assert that i_sort_error is an instance of ISortError
    assert isinstance(i_sort_error, ISortError)



# Generated at 2022-06-25 19:34:08.273039
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "./test_file.py"
    error = ExistingSyntaxErrors(file_path)
    error.file_path
    error.message


# Generated at 2022-06-25 19:34:11.316824
# Unit test for constructor of class MissingSection
def test_MissingSection():
    o = MissingSection.__init__
    o.__annotations__ = {'import_module': str, 'section': str}
    assert o.__annotations__ == {'import_module': str, 'section': str}


# Generated at 2022-06-25 19:34:16.731973
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist(formatter="auto")
    except FormattingPluginDoesNotExist:
        pass


# Generated at 2022-06-25 19:34:21.166989
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    with pytest.raises(Exception) as info:
        literal_parsing_failure_0 = LiteralParsingFailure("", Exception("from_exception"))
    assert info.type == ISortError
    with pytest.raises(Exception) as info:
        literal_parsing_failure_1 = LiteralParsingFailure("from_code", Exception(""))
    assert info.type == ISortError


# Generated at 2022-06-25 19:34:22.816872
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assignments_format_mismatch_0 = AssignmentsFormatMismatch("a = 1")


# Generated at 2022-06-25 19:34:24.868827
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_0 = 'profile_0'
    with raises(ISortError):
        profile_does_not_exist_0 = ProfileDoesNotExist(profile_0)


# Generated at 2022-06-25 19:34:26.231863
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # No assertion is needed
    unsupported_encoding_0 = UnsupportedEncoding("foo")


# Generated at 2022-06-25 19:34:36.497671
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "value1 = 'foo'\nvalue2 = 'bar'\n"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        print(e.args)

test_AssignmentsFormatMismatch()

# Generated at 2022-06-25 19:34:41.040254
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 123"
    try:
        assignmentsFormatMismatch_1 = AssignmentsFormatMismatch(code)
    except Exception as e:
        assignmentsFormatMismatch_1 = e
    if not isinstance(assignmentsFormatMismatch_1, AssignmentsFormatMismatch):
        raise RuntimeError("Error in constructing an object of an incorrect type")

# Generated at 2022-06-25 19:34:48.442753
# Unit test for constructor of class ISortError
def test_ISortError():
    error = ISortError()
    assert isinstance(error, Exception)
    assert hasattr(error, "args")

    error = ISortError("test")
    assert isinstance(error, ISortError)
    assert "test" in error.args[0]

    error = ISortError("test", "test2")
    assert isinstance(error, ISortError)
    assert "test" in error.args[0]
    assert "test2" in error.args[1]



# Generated at 2022-06-25 19:34:50.900543
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    i_sort_error_2 = IntroducedSyntaxErrors("file.py")
    assert i_sort_error_2.file_path == "file.py"


# Generated at 2022-06-25 19:34:58.019958
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        # TypeError is raised when constructor input type is not valid
        ISortError(1)
    except TypeError:
        pass
    else:
        raise Exception('Failed to raise TypeError')
    try:
        # expected TypeError is not raised
        ISortError('something')
    except TypeError:
        raise Exception('Unexpected TypeError is raised')

# TypeError is raised when class method is called with invalid input(s)

# Generated at 2022-06-25 19:34:59.147240
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings({})


# Generated at 2022-06-25 19:35:02.164691
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        code = 'a = 1\n2 = 3'
        raise AssignmentsFormatMismatch(code)
    except ISortError as e:
        assert type(e) is AssignmentsFormatMismatch
        assert e.code == code



# Generated at 2022-06-25 19:35:06.279941
# Unit test for constructor of class ISortError
def test_ISortError():
    i_sort_error = ISortError()
    assert type(i_sort_error) == ISortError
    assert i_sort_error.__init__() is None

if __name__ == "__main__":
    test_ISortError()

# Generated at 2022-06-25 19:35:09.738226
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # No exception raised for instantiation
    file_skip_setting = FileSkipSetting("file.txt")
    assert file_skip_setting.file_path == "file.txt"


# Generated at 2022-06-25 19:35:10.965579
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section_0 = MissingSection('','')


# Generated at 2022-06-25 19:35:27.968937
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    import sys
    import os
    import subprocess
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    config_file = os.path.join(temp_dir.name, "isort.cfg")
    with open(config_file, "w") as f:
        f.write("[settings]\n")
        f.write("unsupported_setting = false\n")

    file_path = os.path.join(temp_dir.name, "test.py")
    with open(file_path, "w") as f:
        f.write("import os\n")


# Generated at 2022-06-25 19:35:29.303905
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting('path/to/file')

# vim: ts=4 sw=4 expandtab

# Generated at 2022-06-25 19:35:31.440299
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_object_0 = "/home/legac/.isort.cfg"
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_object_0)


# Generated at 2022-06-25 19:35:33.651328
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section_0 = MissingSection ("import_module_0", "section_0")
    missing_section_1 = MissingSection ("import_module_1", "section_1")


# Generated at 2022-06-25 19:35:36.177448
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    file_path = 'file_path'
    invalid_settings_path_0 = InvalidSettingsPath(file_path)


# Generated at 2022-06-25 19:35:37.191360
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    f_0 = FileSkipComment("./file.py")


# Generated at 2022-06-25 19:35:38.438801
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fss = FileSkipSetting("test_file")

# Generated at 2022-06-25 19:35:43.109732
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # Case 0
    try:
        string0 = "Test String"
        invalid_settings_path_0 = InvalidSettingsPath(string0)
        assert invalid_settings_path_0.settings_path == string0
    except Exception as exception:
        assert False, "An exception was thrown: " + str(exception)


# Generated at 2022-06-25 19:35:45.397463
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section_0 = MissingSection(
        "numpy", "FUTURE",
    )

    assert missing_section_0 is not None


# Generated at 2022-06-25 19:35:46.489562
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    i_sort_error_0 = InvalidSettingsPath("")

# Generated at 2022-06-25 19:36:08.166522
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = ""
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code)


# Generated at 2022-06-25 19:36:10.591669
# Unit test for constructor of class ISortError
def test_ISortError():
    # Test that class ISortError is correctly constructed
    try:
        ISortError()
    except Exception:
        print("Constructor of class ISortError not working correctly")
        print("======================= ISortError =======================\n")
        raise
    else:
        pass


# Generated at 2022-06-25 19:36:11.456739
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    i_sort_error_0 = FileSkipped("", "")


# Generated at 2022-06-25 19:36:14.834266
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = 'testCode'
    original_error = Exception()
    i_sort_error = LiteralParsingFailure(code, original_error)
    assert isinstance(i_sort_error, ISortError)
    assert i_sort_error.code == code
    assert i_sort_error.original_error == original_error

# Generated at 2022-06-25 19:36:17.720528
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = '1.2'
    original_error = ast.literal_eval('a')
    literal_parsing_failure_0 = LiteralParsingFailure(code, original_error)


# Generated at 2022-06-25 19:36:18.905586
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    i_sort_error_1 = FileSkipComment("test_path")


# Generated at 2022-06-25 19:36:22.397214
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    result = FileSkipped(message="message", file_path="file_path")
    assert result is not None


# Generated at 2022-06-25 19:36:24.875359
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    d = {'a': 1, 'b': 2, 'c': 3}
    temp = UnsupportedSettings(d)
    assert temp.unsupported_settings == d, 'UnsupportedSettings constructor error'


# Generated at 2022-06-25 19:36:26.978788
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    path = "foo.py"
    obj = FileSkipSetting(path)
    assert obj.file_path == path


# Generated at 2022-06-25 19:36:28.510525
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "test_message"
    file_path = "test_file_path"
    FileSkipped(message, file_path)


# Generated at 2022-06-25 19:37:12.201317
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped(message = "The file is skipped", file_path = "skipped")


# Generated at 2022-06-25 19:37:15.414198
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "code_file_with_syntax_error"
    exception = IntroducedSyntaxErrors(file_path)
    assert exception.file_path == file_path


# Generated at 2022-06-25 19:37:18.022495
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_skip_setting = FileSkipSetting('/home/codefundo/project/')
    assert file_skip_setting.message == '/home/codefornoob/project/ was skipped as it\'s listed in \'skip\' setting or matches a glob in \'skip_glob\' setting'


# Generated at 2022-06-25 19:37:19.700155
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    i_sort_error_1 = FileSkipComment('isort_error.py')
    assert i_sort_error_1.file_path == 'isort_error.py' 


# Generated at 2022-06-25 19:37:22.250478
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'test.py'
    FileSkipSetting(file_path)


# Generated at 2022-06-25 19:37:32.018610
# Unit test for constructor of class UnsupportedSettings

# Generated at 2022-06-25 19:37:35.158597
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "formatter"
    formatting_plugin_does_not_exist = FormattingPluginDoesNotExist(formatter)
    print("printing __init__")
    # Output: printing __init__


# Generated at 2022-06-25 19:37:37.161287
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "abc"
    i_sort_error_1 = FormattingPluginDoesNotExist(formatter)
    assert i_sort_error_1.formatter == "abc"


# Generated at 2022-06-25 19:37:40.304216
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Case
    expected_kind = class_0
    kind = class_1
    # Test
    try:
        LiteralSortTypeMismatch(kind, expected_kind)
    except LiteralSortTypeMismatch as instance_LiteralSortTypeMismatch:
        i_sort_error_0 = instance_LiteralSortTypeMismatch

# Generated at 2022-06-25 19:37:42.137503
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {'foo': {'value': 'bar'}}
    UnsupportedSettings(unsupported_settings)

# Generated at 2022-06-25 19:39:08.634413
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path_0 = 'version'
    existing_syntax_errors_0 = ExistingSyntaxErrors(file_path_0)


# Generated at 2022-06-25 19:39:11.415037
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    testString = "test"
    testError = Exception()
    result = LiteralParsingFailure(testString, testError)
    assert result.__class__ == LiteralParsingFailure


# Generated at 2022-06-25 19:39:12.671137
# Unit test for constructor of class MissingSection
def test_MissingSection():
    MissingSection_0 = MissingSection(import_module='import_module_0', section='section_0')

# Generated at 2022-06-25 19:39:20.662051
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped_0 = FileSkipped('message', 'file_path')
    assert file_skipped_0.message == 'message'
    assert file_skipped_0.file_path == 'file_path'
    file_skipped_0.message = 'message_0'
    file_skipped_0.file_path = 'file_path_0'
    assert file_skipped_0.message == 'message_0'
    assert file_skipped_0.file_path == 'file_path_0'


# Generated at 2022-06-25 19:39:23.253986
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    error_occurred = True
    try:
        code = "x = 1\ny = 2"
        raise AssignmentsFormatMismatch(code)
    except ISortError:
        error_occurred = False
    assert error_occurred


# Generated at 2022-06-25 19:39:25.257607
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection("import_module", "section")


# Generated at 2022-06-25 19:39:27.537582
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = "java.io.IOException"
    result = UnsupportedSettings(unsupported_settings)
    if result == UnsupportedSettings:
        print("Success")
    else:
        print("Failure")

# Generated at 2022-06-25 19:39:30.510259
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_does_not_exist = ProfileDoesNotExist('test_profile')


# Generated at 2022-06-25 19:39:32.517000
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formattingPluginDoesNotExist = FormattingPluginDoesNotExist(formatter = 'black')


# Generated at 2022-06-25 19:39:34.780968
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Test for user defined message
    i_sort_error_0 = ProfileDoesNotExist("PROFILE_DOES_NOT_EXIST")
    # Test for default message
    i_sort_error_1 = ProfileDoesNotExist()
