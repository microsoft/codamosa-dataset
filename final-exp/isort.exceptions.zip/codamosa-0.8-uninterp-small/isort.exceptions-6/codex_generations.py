

# Generated at 2022-06-25 19:31:50.730527
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    message_arg_val = "message"
    file_path_arg_val = "file_path"
    temp_0 = FileSkipSetting(file_path_arg_val)
    assert hasattr(temp_0, 'message')
    assert hasattr(temp_0, 'file_path')
    assert temp_0.message == "file_path was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert temp_0.file_path == file_path_arg_val


# Generated at 2022-06-25 19:31:56.100906
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    TestExistingSyntaxErrors = ExistingSyntaxErrors("TestHelper.py")
    assert TestExistingSyntaxErrors.args[0] == "isort was told to sort imports within code that contains syntax errors: TestHelper.py."
    assert TestExistingSyntaxErrors.file_path == "TestHelper.py"



# Generated at 2022-06-25 19:31:57.095209
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    test_case_0()


# Generated at 2022-06-25 19:32:01.174454
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    filename = str()
    try:
        intrd_syntax_errors_0 = IntroducedSyntaxErrors(filename)
    except Exception:
        pass
    try:
        intrd_syntax_errors_1 = IntroducedSyntaxErrors(filename)
    except Exception:
        pass


# Generated at 2022-06-25 19:32:02.293642
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    test_case_0()

# Generated at 2022-06-25 19:32:04.164415
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = ''
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)


# Generated at 2022-06-25 19:32:07.168184
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    exc_type_0 = Exception
    settings_path_0 = '99'
    invalid_settings_path_0 = InvalidSettingsPath(settings_path_0)


# Generated at 2022-06-25 19:32:11.784718
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = '/path/to/file'
    obj_FileSkipSetting = FileSkipSetting(file_path)



# Generated at 2022-06-25 19:32:14.399053
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'str'
    str_1 = 'str'
    file_skipped_0 = FileSkipped(str_0, str_1)


# Generated at 2022-06-25 19:32:17.484361
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = ''
    str_1 = ''
    isort_error_0 = ISortError(str_0)
    isort_error_0 = ISortError(str_1)

# Generated at 2022-06-25 19:32:21.705448
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        test_case_0()
    except ISortError:
        return
    assert False



# Generated at 2022-06-25 19:32:22.920287
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assignments_format_mismatch = AssignmentsFormatMismatch()


# Generated at 2022-06-25 19:32:27.689513
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    i_sort_error_1 = IntroducedSyntaxErrors("File 1")
    assert i_sort_error_1.file_path == "File 1"



# Generated at 2022-06-25 19:32:31.879162
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_0: str = "Javascript"
    profile_does_not_exist_0: ProfileDoesNotExist = ProfileDoesNotExist(profile_0)
    assert profile_does_not_exist_0.profile == "Javascript"


# Generated at 2022-06-25 19:32:35.689850
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "pycodestyle"
    formatting_plugin_does_not_exist = FormattingPluginDoesNotExist(formatter)
    assert formatting_plugin_does_not_exist.formatter == formatter


# Generated at 2022-06-25 19:32:38.475673
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting("a/b/c")


# Generated at 2022-06-25 19:32:41.719365
# Unit test for constructor of class ISortError
def test_ISortError():
    # verify if an object of class ISortError can be created
    assert isinstance(i_sort_error_0, ISortError)
    assert isinstance(ISortError(), ISortError)



# Generated at 2022-06-25 19:32:44.832368
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "test"
    original_error = Exception()
    assert LiteralParsingFailure(code, original_error).code == "test"
    assert LiteralParsingFailure(code, original_error).original_error == Exception()



# Generated at 2022-06-25 19:32:48.812337
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    i_sort_error_1 = InvalidSettingsPath("test_file_path")
    assert i_sort_error_1.settings_path == "test_file_path"


# Generated at 2022-06-25 19:32:52.474244
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch) as excinfo:
        raise LiteralSortTypeMismatch(kind=True, expected_kind=3)


# Generated at 2022-06-25 19:32:58.560661
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    i_sort_error_0 = UnsupportedEncoding("")


test_case_0()
test_UnsupportedEncoding()

# Generated at 2022-06-25 19:33:00.389807
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment_0 = FileSkipComment("")


# Generated at 2022-06-25 19:33:05.397994
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    literal_parsing_failure_0 = LiteralParsingFailure('code', ValueError('ValueError'))
    assert literal_parsing_failure_0.code == 'code'
    assert literal_parsing_failure_0.original_error.__class__.__name__ == 'ValueError'


# Generated at 2022-06-25 19:33:08.013580
# Unit test for constructor of class MissingSection
def test_MissingSection():
    i_sort_error_1 = MissingSection("test", "test")
    return str(i_sort_error_1)


if __name__ == "__main__":
    test_MissingSection()

# Generated at 2022-06-25 19:33:09.255054
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    i_sort_error_0 = InvalidSettingsPath("InvalidSettingsPath")


# Generated at 2022-06-25 19:33:10.540028
# Unit test for constructor of class ISortError
def test_ISortError():
    assert isinstance(ISortError(), BaseException)


# Generated at 2022-06-25 19:33:13.081590
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings.__init__(UnsupportedSettings, {'line_length': {'value': 79, 'source': 'config'}})


# Generated at 2022-06-25 19:33:16.050294
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = int
    expected_kind = str
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind, expected_kind)


# Generated at 2022-06-25 19:33:22.955148
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # Arrange
    module_name = "isort"
    section = "FUTURE"

    # Act
    actual = MissingSection(module_name, section)

    # Assert
    assert actual.__str__() == f"Found {module_name} import while parsing, but {section} was not included "

# Generated at 2022-06-25 19:33:25.593240
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    a = AssignmentsFormatMismatch("abcd")


# Generated at 2022-06-25 19:33:30.743783
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch()


# Generated at 2022-06-25 19:33:32.547563
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    introduced_syntax_errors_0 = IntroducedSyntaxErrors('test_case_0')


# Generated at 2022-06-25 19:33:38.944493
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    i_sort_error_2 = ExistingSyntaxErrors(file_path='/home/isort/tests/file.py')
    if i_sort_error_2.file_path != '/home/isort/tests/file.py':
        print('BAD FILEPATH')
    if 'isort was told to sort imports' not in i_sort_error_2.args[0]:
        print('BAD ARGS')


# Generated at 2022-06-25 19:33:42.912100
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    i_sort_error_0=LiteralParsingFailure("hi","hello")
    i_sort_error_1=LiteralParsingFailure(3,4)


# Generated at 2022-06-25 19:33:44.902949
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'message'
    file_path = 'file_path'
    fileSkipped = FileSkipped(message, file_path)


# Generated at 2022-06-25 19:33:46.337524
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment_0 = FileSkipComment(file_path="")


# Generated at 2022-06-25 19:33:49.611305
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert hasattr(LiteralParsingFailure('code_0', Exception()), 'code')
    assert hasattr(LiteralParsingFailure('code_1', Exception()), 'original_error')


# Generated at 2022-06-25 19:33:55.349014
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        def sample_existing_syntax_errors():
            raise ExistingSyntaxErrors()

        assert True
    except ExistingSyntaxErrors as e:
        assert isinstance(e, ISortError)
        assert e.__class__.__name__ == "ExistingSyntaxErrors"


# Generated at 2022-06-25 19:34:02.430841
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = 'file1'
    # Check if exception is raised if file_path is not a str
    with pytest.raises(TypeError):
        existingSyntaxErrors = ExistingSyntaxErrors(1)
    # Check if exception is raised if file_path does not exist in FileSystem
    with pytest.raises(ISortError) as excinfo:
        existingSyntaxErrors = ExistingSyntaxErrors(file_path)
    assert str(excinfo.value) == "isort was told to sort imports within code that contains syntax errors: file1."


# Generated at 2022-06-25 19:34:04.245055
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    existing_syntax_errors_0 = ExistingSyntaxErrors("")


# Generated at 2022-06-25 19:34:09.256622
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = 'a'
    test_AssignmentsFormatMismatch_0 = AssignmentsFormatMismatch(code)


# Generated at 2022-06-25 19:34:14.988236
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # Invalid test case

    str_0 = ''
    str_1 = ''
    missing_section_0 = MissingSection(str_0, str_1)
    assert missing_section_0.args == (str_0, str_1)


# Generated at 2022-06-25 19:34:16.254719
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = ''
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:34:18.353396
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = ''
    Exception_0 = Exception()
    assert isinstance(LiteralParsingFailure(str_0, Exception_0), ISortError)


# Generated at 2022-06-25 19:34:20.809467
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = ''
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    str_1 = ''
    invalid_settings_path_1 = InvalidSettingsPath(str_1)
    assert invalid_settings_path_0.settings_path == str_0
    assert invalid_settings_path_1.settings_path == str_1


# Generated at 2022-06-25 19:34:21.718847
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Test for type
    assert isinstance(UnsupportedEncoding(), ISortError)



# Generated at 2022-06-25 19:34:23.321908
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = './test_file_skip_setting'
    FileSkipSetting(file_path)


# Generated at 2022-06-25 19:34:25.914623
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    string0 = ''
    existing_syntax_errors = ExistingSyntaxErrors(string0)
    # Test getter of property file_path
    assert existing_syntax_errors.file_path == string0



# Generated at 2022-06-25 19:34:27.256942
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_1 = ''
    invalid_settings_path_1 = InvalidSettingsPath(str_1)


# Generated at 2022-06-25 19:34:28.983762
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = ''
    existing_syntax_errors_0 = ExistingSyntaxErrors(file_path)


# Generated at 2022-06-25 19:34:37.599859
# Unit test for constructor of class MissingSection
def test_MissingSection():
    str_0 = ''
    str_1 = ''
    missing_section_0 = MissingSection(str_0, str_1)

# Generated at 2022-06-25 19:34:41.324049
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename_0 = str()
    # TypeError
    try:
        # Call the constructor
        assert UnsupportedEncoding(filename_0)
    except TypeError as err:
        # Check the error message
        assert err.args[0] == "object of type 'str' has no len()"


# Generated at 2022-06-25 19:34:43.448478
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = ''
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:34:46.993673
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = ''
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    str_1 = 'i'
    introduced_syntax_errors_1 = IntroducedSyntaxErrors(str_1)


# Generated at 2022-06-25 19:34:52.961589
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # first check if there is argument missing in the constructor
    try:
        AssignmentsFormatMismatch()
    except TypeError:
        print("TEST PASSED")
    # then check if the type of arguments are correct.
    str_0 = ''
    try:
        assignmentsFormatMismatch_0 = AssignmentsFormatMismatch(str_0)
    except TypeError:
        print("TEST FAILED")


# Generated at 2022-06-25 19:34:56.013782
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = ''
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:35:00.171587
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Verify that is raised when the profile does not exist
    try:
        ProfileDoesNotExist('This profile does not exist')
    except ProfileDoesNotExist:
        pass
    else:
        assert False



# Generated at 2022-06-25 19:35:12.739978
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    import_module = 'import_module'
    section = 'section'
    str_0 = ''
    str_1 = ''
    str_2 = ''
    type_0 = type(str_1)
    type_1 = type(str_2)
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(type_0, type_1)
    assert str(literal_sort_type_mismatch_0) == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'str'>. "
    #assert literal_sort_type_mismatch_0.file_path is str_0
    #assert literal_sort_type_mismatch_0.message is str_1
    assert literal_sort_type_mismatch_0

# Generated at 2022-06-25 19:35:24.944319
# Unit test for constructor of class ISortError
def test_ISortError():
    class_0 = ISortError()
    assert class_0
    str_0 = ''
    assert str_0
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    assert invalid_settings_path_0
    str_1 = ''
    assert str_1
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_1)
    assert existing_syntax_errors_0
    str_2 = ''
    assert str_2
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_2)
    assert introduced_syntax_errors_0
    str_3 = ''
    assert str_3
    str_4 = ''
    assert str_4
    file_skipped_0 = FileSkipped(str_3, str_4)
    assert file_

# Generated at 2022-06-25 19:35:33.617630
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = ''
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = ''
    str_16 = ''
    str_17 = ''
    str_18 = ''
    str_19 = ''
    str_20 = ''
    str_21 = ''
    str_22 = ''
    str_23 = ''
    str_24 = ''
    str_25 = ''
    str_26 = ''
    str_27 = ''
    str_

# Generated at 2022-06-25 19:35:47.937034
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = ''
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, IndexError())



# Generated at 2022-06-25 19:35:49.656839
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = ''
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:35:51.477873
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = ''
    UnsupportedEncoding_0 = UnsupportedEncoding(filename)

test_case_0()
test_UnsupportedEncoding()

# Generated at 2022-06-25 19:35:53.712783
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'file_path'
    try:
        file_skip_comment_0 = FileSkipComment(file_path)
    except:
        file_skip_comment_0 = None
    assert file_skip_comment_0


# Generated at 2022-06-25 19:35:55.065146
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = ''
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:35:56.737258
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = ''
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)

# Generated at 2022-06-25 19:36:03.867945
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # tests invalid file
    filename = ''
    unsupported_encoding = UnsupportedEncoding(filename)
    filename = 'temp_file'
    unsupported_encoding = UnsupportedEncoding(filename)
    unsupported_encoding.filename
    filename = Path(filename)
    unsupported_encoding = UnsupportedEncoding(filename)
    unsupported_encoding.filename


# Generated at 2022-06-25 19:36:08.218318
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    # New object
    param1 = 'foo'
    param2 = 'bar'
    obj = FormattingPluginDoesNotExist(param1)
    # Delete object
    del obj
    # Test invalid type for param1 name
    try:
        obj = FormattingPluginDoesNotExist(param2)
        raise Exception('Exception not thrown')
    except TypeError:
        pass
    # Test invalid type for param2 name
    try:
        obj = FormattingPluginDoesNotExist(param1, param1)
        raise Exception('Exception not thrown')
    except TypeError:
        pass


# Generated at 2022-06-25 19:36:09.777083
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = ''
    base_exception_0 = BaseException()
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, base_exception_0)


# Generated at 2022-06-25 19:36:11.037009
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = ['']
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code)


# Generated at 2022-06-25 19:36:37.275745
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = ''
    FileSkipSetting(file_path)



# Generated at 2022-06-25 19:36:41.152074
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    # Create an instance of class FileSkipped
    file_path_0 = ''
    message_0 = ''
    file_skipped_0 = FileSkipped(message_0, file_path_0)

    # Check if constructor has successfully initialised all the attributes of an instance:
    assert file_skipped_0.file_path is file_path_0


# Generated at 2022-06-25 19:36:41.921408
# Unit test for constructor of class MissingSection
def test_MissingSection():
    test_case_0()

# Generated at 2022-06-25 19:36:45.527972
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'test_module'
    section = 'test_section'
    missing_section = MissingSection(import_module, section)
    assert missing_section.message == "Found {} import while parsing, but {} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.".format(import_module, section)


# Generated at 2022-06-25 19:36:56.918613
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    str_0 = ''
    unsupported_encoding_0 = UnsupportedEncoding(str_0)
    str_1 = ''
    unsupported_encoding_1 = UnsupportedEncoding(str_1)
    assert unsupported_encoding_1.filename == str_0
    # str_2 = ''
    # unsupported_encoding_2 = UnsupportedEncoding(str_2)
    # str_3 = ''
    # unsupported_encoding_3 = UnsupportedEncoding(str_3)
    # str_4 = ''
    # unsupported_encoding_4 = UnsupportedEncoding(str_4)
    # str_5 = ''
    # unsupported_encoding_5 = UnsupportedEncoding(str_5)
    # str_6 = ''
    # unsupported_encoding_6 = UnsupportedEncoding(str_6)

# Generated at 2022-06-25 19:37:02.721356
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = 'Lianjia, Inc.;Copyright (c) 2019 Lianjia, Inc. All Rights Reserved;'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:37:04.624394
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = ''
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)


# Generated at 2022-06-25 19:37:07.348918
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = ''
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:37:16.335675
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Try constructor without assert
    try:
        LiteralSortTypeMismatch(1, 1.0)
    except AssertionError as ex:
        assert("kind should be of type <class 'type'>") in str(ex)
    except Exception as ex:
        print("exception: ", type(ex))
    # Try constructor with assert
    with assert_raises(AssertionError) as ex:
        LiteralSortTypeMismatch(1, 1.0)
    assert("kind should be of type <class 'type'>") in str(ex.value)


# Generated at 2022-06-25 19:37:17.972561
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_str = ''
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_str)


# Generated at 2022-06-25 19:38:08.891623
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = { 'str_0': { 'str_1': 'str_2', 'str_3': 'str_4' } }
    unsupported_settings_0 = UnsupportedSettings(unsupported_settings)



# Generated at 2022-06-25 19:38:10.474931
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_0 = {'option': {'value': 2, 'source': 'default'}, 'option1': {'value': 5, 'source': 'default'}}
    UnsupportedSettings(unsupported_0)

# Generated at 2022-06-25 19:38:11.800601
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = str
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(formatter)


# Generated at 2022-06-25 19:38:12.387853
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings('')


# Generated at 2022-06-25 19:38:13.599484
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = ''
    profile_does_not_exist = ProfileDoesNotExist(str_0)


# Generated at 2022-06-25 19:38:16.875793
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = ''
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    str_1 = 'inv'
    invalid_settings_path_1 = InvalidSettingsPath(str_1)
    str_2 = 'in'
    invalid_settings_path_2 = InvalidSettingsPath(str_2)


# Generated at 2022-06-25 19:38:17.915195
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code_0 = ''
    test_0 = AssignmentsFormatMismatch(code_0)

# Generated at 2022-06-25 19:38:19.530384
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # Test Code
    import_module = 'import_module'
    section = 'section'
    missing_section_0 = MissingSection(import_module, section)


# Generated at 2022-06-25 19:38:20.836197
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_1 = ''
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_1)


# Generated at 2022-06-25 19:38:22.958975
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = ''
    file_skipped_0 = FileSkipped(str_0, str_0)
    assert str_0 == file_skipped_0.file_path
