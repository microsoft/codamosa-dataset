

# Generated at 2022-06-25 19:31:44.429587
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type
    expected_kind = type
    try:
        raise LiteralSortTypeMismatch(kind, expected_kind)
    except LiteralSortTypeMismatch as e:
        assert e.kind == kind
        assert e.expected_kind == expected_kind


# Generated at 2022-06-25 19:31:50.578468
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    literal = "import test"
    exception = f"Exception {literal}"
    assert str(LiteralParsingFailure(literal, exception)) == \
           f"isort failed to parse the given literal {literal}. It's important to note " \
           "that isort literal sorting only supports simple literals parsable by " \
           f"ast.literal_eval which gave the exception of {exception}."


# Generated at 2022-06-25 19:31:53.773484
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise ValueError('LiteralParsingFailure')
    except ValueError as exc:
        LiteralParsingFailure('test', exc)


# Generated at 2022-06-25 19:31:56.553935
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        if ISortError is ISortError:
            assert True
        else:
            assert False
    except:
        assert False


# Generated at 2022-06-25 19:32:00.431198
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "Black"
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "Black"



# Generated at 2022-06-25 19:32:04.002585
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    invalid_settings_path_0 = InvalidSettingsPath("nfjftbvxo")
    str(invalid_settings_path_0)
    invalid_settings_path_0.settings_path


# Generated at 2022-06-25 19:32:06.642554
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    s = FileSkipComment("/Users/ashok/Desktop/CompilerDesign/isort/setup.cfg")
    print(s)


# Generated at 2022-06-25 19:32:11.379766
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    i_sort_error_1 = ProfileDoesNotExist(profile = "test")


# Generated at 2022-06-25 19:32:15.161636
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'This file is skipped.'
    file_path = 'test_isort.py'

    obj = FileSkipped(message, file_path)
    assert str(obj) == message
    assert obj.file_path == file_path


# Generated at 2022-06-25 19:32:18.663809
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = b b = c\nc = d\n")
    except AssignmentsFormatMismatch:
        pass


# Generated at 2022-06-25 19:32:23.660276
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "test.py"
    # Call the constructor of the class UnsupportedEncoding
    UnsupportedEncoding_instance_0 = UnsupportedEncoding(filename)
    UnsupportedEncoding_instance_0.filename


# Generated at 2022-06-25 19:32:29.552429
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Argument str
    filename = "test_some_file_here"
    # Call the constructor
    unsupport_encoding = UnsupportedEncoding(filename)
    # Check the exception message
    print(unsupport_encoding)
    assert True



# Generated at 2022-06-25 19:32:32.009640
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = 'thug.py'
    str_0 = "Unknown or unsupported encoding in "
    unsupported_encoding_0 = UnsupportedEncoding(filename)


# Generated at 2022-06-25 19:32:36.188381
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors('ERROR')
    except ExistingSyntaxErrors as e:
        assert e.args[0] == "isort was told to sort imports within code that contains syntax errors: ERROR."
        assert e.file_path == 'ERROR'


# Generated at 2022-06-25 19:32:38.950633
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    import ast
    lit = ast.literal_eval('[1, 2, 3]')
    kind = list
    expected_kind = dict
    literal_sort_type_mismatch = LiteralSortTypeMismatch(kind, expected_kind)


# Generated at 2022-06-25 19:32:42.607694
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = '--single-version-externally-managed'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    assert existing_syntax_errors_0.file_path == str_0


# Generated at 2022-06-25 19:32:44.591582
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'append_const'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:32:49.962517
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    from builtins import type
    
    kind_0 = type(2)
    expected_kind_0 = type('')
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind_0, expected_kind_0)


# Generated at 2022-06-25 19:32:52.735439
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'append_const'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)

# Generated at 2022-06-25 19:32:55.019412
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # Parametrize the test
    str_0 = 'test_isort_error'
    test_FileSkipComment_0 = FileSkipComment(str_0)


# Generated at 2022-06-25 19:33:04.404828
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path_0 = 'append_const'
    invalid_settings_path_0 = InvalidSettingsPath(settings_path_0)
    assert invalid_settings_path_0.settings_path == settings_path_0
    assert invalid_settings_path_0.__str__() == "isort was told to use the settings_path: append_const as the base directory or file that represents the starting point of config file discovery, but it does not exist."


# Generated at 2022-06-25 19:33:09.132212
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    d_0 = {'hello': None}
    un_0 = UnsupportedSettings(d_0)
    d_1 = {'hello': None}
    un_1 = UnsupportedSettings(d_1)
    assert un_0 != un_1
    str_0 = 'append_const'
    file_skip_setting_0 = FileSkipSetting(str_0)


# Generated at 2022-06-25 19:33:12.284829
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module_0 = '1'
    section_0 = 'a'
    Exception_MissingSection_0 = MissingSection(import_module_0, section_0)
    str_0 = str(Exception_MissingSection_0)


# Generated at 2022-06-25 19:33:22.475614
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    from types import ModuleType
    from typing import Any, Type
    kind_0 = ModuleType('qwerty')
    expected_kind_0 = ModuleType('qwerty')
    try:
        literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind_0, expected_kind_0)
        raise AssertionError("expected exception LiteralSortTypeMismatch to be thrown")
    except LiteralSortTypeMismatch as exception:
        assert isinstance(exception, LiteralSortTypeMismatch)
        assert isinstance(exception.kind, ModuleType)
        assert isinstance(exception.expected_kind, ModuleType)
        assert str(exception) == 'isort was told to sort a literal of type <class \'type\'> but was given a literal of type <class \'type\'>.'

# Generated at 2022-06-25 19:33:26.473708
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = 'str_0'
    original_error_0 = ISortError()
    literal_parsing_failure_0 = LiteralParsingFailure(code, original_error_0)


# Generated at 2022-06-25 19:33:30.786489
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = 'test_profile'
    profiles = ['available_profiles']
    test_profile_does_not_exist_0 = ProfileDoesNotExist(profile)
    str_0 = 'Specified profile of test_profile does not exist. Available profiles: available_profiles.'


# Generated at 2022-06-25 19:33:36.673197
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_1 = 'append_parent'
    str_2 = 'append_parent'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_1)
    # AssertionError: Specified formatting plugin of append_parent does not exist.  != append_parent
    assert str_2 == formatting_plugin_does_not_exist_0.formatter


# Generated at 2022-06-25 19:33:47.018313
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = "Unsupported settings:\n\t- this_is_a_setting = False  (source: 'command-line')\n"
    unsupported_settings_0 = {}
    unsupported_settings_0['this_is_a_setting'] = {}
    unsupported_settings_0['this_is_a_setting']['False'] = 'command-line'
    unsupported_settings_0['this_is_a_setting']['source'] = 'command-line'
    unsupported_settings_1 = unsupported_settings_0
    unsupported_settings_0['this_is_a_setting']['value'] = 'False'
    unsupported_settings_0['this_is_a_setting']['name'] = 'this_is_a_setting'

# Generated at 2022-06-25 19:33:47.780327
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    test_case_0()

# Generated at 2022-06-25 19:33:50.770035
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # 'tuple' is our subject for the test case
    tuple_0 = (1, 2, 3)
    kind_0 = type(tuple_0)
    expected_kind_0 = type(tuple_0)
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(kind_0, expected_kind_0)


# Generated at 2022-06-25 19:34:01.279900
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = 'append_const'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:34:03.862105
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'test_case_0'
    file_path = 'append_const'
    assert FileSkipped(message, file_path)


# Generated at 2022-06-25 19:34:06.066153
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    if __name__ == '__main__':
        str_0 = 'myfile.py'
        file_skip_comment_0 = FileSkipComment(str_0)


# Generated at 2022-06-25 19:34:14.559747
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # directory_0 should be a valid directory
    directory_0 = str(Path('tests/test_paths').resolve())
    # file_0 should be a valid file
    file_0 = str(Path('tests/test_paths/pyproject.toml').resolve())
    # nonexistent_file_0 does not exist
    nonexistent_file_0 = str(Path('tests/test_paths/nonexistent_file.txt').resolve())

    # use the file_0 and directory_0 as the settings_path
    exception_0 = InvalidSettingsPath(file_0)
    exception_1 = InvalidSettingsPath(directory_0)
    # use the nonexistent_file_0 as the settings_path
    exception_2 = InvalidSettingsPath(nonexistent_file_0)


# Generated at 2022-06-25 19:34:16.279175
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'append_const'
    str_1 = 'append_const'
    file_skipped_0 = FileSkipped(str_0, str_1)


# Generated at 2022-06-25 19:34:17.757552
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert (isinstance(UnsupportedEncoding('/home/joe/example.py').filename, Path))



# Generated at 2022-06-25 19:34:20.401730
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'append_const'
    syntax_error_0 = SyntaxError('missing ) in parenthetical')
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, syntax_error_0)


# Generated at 2022-06-25 19:34:22.109877
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str0 = "Test string"
    introduced_syntax_errors0 = IntroducedSyntaxErrors(str0)


# Generated at 2022-06-25 19:34:30.160740
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # This test is for Exception and not for UnsupportedSettings
    assert_exception_message(
        'isort was provided settings that it doesn\'t support:\n\n',
        UnsupportedSettings({})
    )

    # This test is for Exception and not for UnsupportedSettings
    assert_exception_message(
        'isort was provided settings that it doesn\'t support:\n\n'
        '\t- append_const = whatever  (source: \'config\')',
        UnsupportedSettings({'append_const': {'value': 'whatever', 'source': 'config'}})
    )

    # This test is for Exception and not for UnsupportedSettings

# Generated at 2022-06-25 19:34:37.191943
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    print('All test cases done!')
