

# Generated at 2022-06-25 19:31:48.245650
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        assignmentsformatmismatch_0 = AssignmentsFormatMismatch("")
    except:
        assert False


# Generated at 2022-06-25 19:31:51.089603
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        test_string = "unittest"
        invalidSettingsPath_0 = InvalidSettingsPath(test_string)
    except:
        pass



# Generated at 2022-06-25 19:31:52.449681
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    test_case_0()

# Generated at 2022-06-25 19:31:54.902707
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(FileSkipped, match=".*"):
        raise FileSkipped("message", "file_path")



# Generated at 2022-06-25 19:31:59.371135
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    type_0 = type()
    type_1 = type()
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(type_0, type_1)
    pass


# Generated at 2022-06-25 19:32:02.293731
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    test_case_0()

# Generated at 2022-06-25 19:32:03.178447
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    test_case_0()

# Generated at 2022-06-25 19:32:06.450197
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped_0 = FileSkipped(message="message", file_path="file_path")
    assert file_skipped_0.file_path == "file_path"


# Generated at 2022-06-25 19:32:11.784449
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist("No error").__repr__() == "Specified formatting plugin of No error does not exist. "


# Generated at 2022-06-25 19:32:12.363317
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # No use case tested.
    pass

# Generated at 2022-06-25 19:32:15.683168
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_0 = 'n'
    profile_does_not_exist_0 = ProfileDoesNotExist(profile_0)
    assert profile_does_not_exist_0.profile == 'n', 'Failed: Constructor'


# Generated at 2022-06-25 19:32:19.297398
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'source_vx8Wk3l'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    assert formatting_plugin_does_not_exist_0.formatter == str_0



# Generated at 2022-06-25 19:32:23.665755
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = 'code'

    # Act
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(code)

    str_0 = assignments_format_mismatch_0.code
    str_1 = assignments_format_mismatch_0.__class__.__doc__


# Generated at 2022-06-25 19:32:26.669987
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(type, type)

# Generated at 2022-06-25 19:32:30.097005
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = 'n'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)
    assert profile_does_not_exist_0.profile == str_0


# Generated at 2022-06-25 19:32:33.212505
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'n'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    str_1 = introduced_syntax_errors_0.message
    assert str_1 == str_0


# Generated at 2022-06-25 19:32:35.156977
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_1 = 'n'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_1)
    

# Generated at 2022-06-25 19:32:41.771798
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = 'n'
    str_1 = 'n'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)
    str_2 = assignments_format_mismatch_0.code
    print(assignments_format_mismatch_0.code)
    return str_2 == str_1


# Generated at 2022-06-25 19:32:49.279748
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'n'
    str_1 = 'n'
    str_2 = str_1
    str_3 = 'n'
    str_4 = str_3
    str_5 = 'n'
    str_6 = str_5
    str_7 = str_6
    str_8 = str_7
    str_9 = str_8
    str_10 = str_9
    str_11 = str_10
    str_12 = str_11
    str_13 = str_12
    str_14 = str_13
    str_15 = str_14
    str_16 = str_15
    str_17 = str_16
    str_18 = str_17
    str_19 = str_18
    str_20 = str_19
    str_21 = str_20
   

# Generated at 2022-06-25 19:32:52.875482
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'n'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    assert introduced_syntax_errors_0.file_path == str_0



# Generated at 2022-06-25 19:33:00.715456
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'n'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    str_1 = invalid_settings_path_0.settings_path
    assert isinstance(str_1, str)



# Generated at 2022-06-25 19:33:06.892440
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'n'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)
    str_0 = 'r'
    invalid_settings_path_1 = InvalidSettingsPath(str_0)
    str_0 = 'h'
    invalid_settings_path_2 = InvalidSettingsPath(str_0)
    str_0 = 'j'
    invalid_settings_path_3 = InvalidSettingsPath(str_0)


# Generated at 2022-06-25 19:33:16.739366
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    # Try to instantiate with a string value for formatter
    formatter = 'json'
    format_plugin_error = FormattingPluginDoesNotExist(formatter)
    assert isinstance(format_plugin_error, FormattingPluginDoesNotExist)
    # Try to instantiate with a dict value for formatter
    formatter = {'format_name': 'json'}
    format_plugin_error = FormattingPluginDoesNotExist(formatter)
    assert isinstance(format_plugin_error, FormattingPluginDoesNotExist)
    # Try to instantiate with a list value for formatter
    formatter = ['json']
    format_plugin_error = FormattingPluginDoesNotExist(formatter)
    assert isinstance(format_plugin_error, FormattingPluginDoesNotExist)
    # Try to instantiate with an int

# Generated at 2022-06-25 19:33:19.886999
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
        # Create instance of class and test if types of arguments are correct
        file_skip_setting_0 = FileSkipSetting('n')
        assert type(file_skip_setting_0.file_path) is str

# Generated at 2022-06-25 19:33:21.864994
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_0 = 'n'
    profile_does_not_exist_0 = ProfileDoesNotExist(profile_0)


# Generated at 2022-06-25 19:33:25.778653
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = 'xyz'
    profile_does_not_exist_0 = ProfileDoesNotExist(profile)
    assert profile_does_not_exist_0.profile == profile


# Generated at 2022-06-25 19:33:29.100398
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'n'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    assert formatting_plugin_does_not_exist_0.formatter == str_0



# Generated at 2022-06-25 19:33:32.503379
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path_1 = 'n'
    file_skip_setting_1 = FileSkipSetting(file_path_1)
    assert file_skip_setting_1.file_path == file_path_1


# Generated at 2022-06-25 19:33:36.412467
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    str_0 = 'e'
    profile_does_not_exist_0 = ProfileDoesNotExist(str_0)
    # instance attributes
    assert profile_does_not_exist_0.profile == 'e'



# Generated at 2022-06-25 19:33:40.905217
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'n'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    # assert introduced_syntax_errors_0.args[0] == \
    #     'isort introduced syntax errors when attempting to sort the imports contained within n.'


# Generated at 2022-06-25 19:33:58.025906
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path_0 = "6NcZ6UdV"
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path_0)
    assert introduced_syntax_errors_0.file_path == "6NcZ6UdV"
    assert introduced_syntax_errors_0.args[0] == 'isort introduced syntax errors when attempting to sort the imports contained within 6NcZ6UdV.'
    str_0 = 'n'
    introduced_syntax_errors_1 = IntroducedSyntaxErrors(str_0)
    assert introduced_syntax_errors_1.file_path == 'n'
    assert introduced_syntax_errors_1.args[0] == 'isort introduced syntax errors when attempting to sort the imports contained within n.'


# Generated at 2022-06-25 19:34:00.602930
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    str_0 = 'n'
    invalid_settings_path_0 = InvalidSettingsPath(str_0)



# Generated at 2022-06-25 19:34:02.632939
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('NO_EXCEPT_HERE')
    except UnsupportedEncoding:
        pass


# Generated at 2022-06-25 19:34:04.117847
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment('test').file_path == 'test'


# Generated at 2022-06-25 19:34:09.018142
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    str_0 = 'n'
    formatting_plugin_does_not_exist_0 = FormattingPluginDoesNotExist(str_0)
    str_1 = formatting_plugin_does_not_exist_0.formatter
    assert str_1 == str_0
    assert not hasattr(formatting_plugin_does_not_exist_0, 'formatter_0')


# Generated at 2022-06-25 19:34:14.091792
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'move'
    isort_error_0 = ISortError(str_0)
    assert isort_error_0 != 0
    assert isort_error_0 != 1
    assert isort_error_0 != 2
    assert isort_error_0 != 3
    assert isort_error_0 != 4
    assert isort_error_0 != 5
    assert isort_error_0 != 6
    assert isort_error_0 != 7


# Generated at 2022-06-25 19:34:18.019634
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path_0 = "w"
    file_skip_setting_0 = FileSkipSetting(file_path_0)
    file_path_1 = "l"
    file_skip_setting_1 = FileSkipSetting(file_path_1)
    file_path_2 = "2"
    file_skip_setting_2 = FileSkipSetting(file_path_2)
    file_path_3 = "c"
    file_skip_setting_3 = FileSkipSetting(file_path_3)
    file_path_4 = "."
    file_skip_setting_4 = FileSkipSetting(file_path_4)

# Generated at 2022-06-25 19:34:20.165902
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    original_err = Exception()
    code = "code"
    literal_parsing_failure_0 = LiteralParsingFailure(code, original_err)
    print(literal_parsing_failure_0.code)
    print(literal_parsing_failure_0.original_error)

# Generated at 2022-06-25 19:34:22.289720
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'n'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    assert introduced_syntax_errors_0.file_path == str_0
    assert introduced_syntax_errors_0.message == 'isort introduced syntax errors when attempting to sort the imports contained within n.' # noqa


# Generated at 2022-06-25 19:34:23.576110
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert (MissingSection.__init__.__doc__ is not None)

# Generated at 2022-06-25 19:34:44.464724
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    dict_11 = dict()
    dict_12 = dict()
    dict_12['option'] = 'place_module_top'
    dict_12['source'] = 'config'
    dict_11['skip_comments'] = dict_12
    dict_13 = dict()
    dict_13['source'] = 'config'
    dict_11['comments'] = dict_13
    dict_14 = dict()
    dict_14['source'] = 'config'
    dict_11['comments_after_imports'] = dict_14
    dict_15 = dict()
    dict_15['source'] = 'config'
    dict_11['comments_before_imports'] = dict_15
    dict_16 = dict()
    dict_16['source'] = 'config'
    dict_11['force_adds'] = dict_16


# Generated at 2022-06-25 19:34:49.808553
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = 'X+1'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)
    str_1 = 'p'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_1)


# Generated at 2022-06-25 19:34:52.475410
# Unit test for constructor of class ISortError
def test_ISortError():
    str_0 = 'n'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    assert introduced_syntax_errors_0 is not None


# Generated at 2022-06-25 19:34:57.040797
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment_0 = FileSkipComment('n')
    file_path = file_skip_comment_0.file_path
    assert file_path == 'n'
    assert isinstance(file_path, str)


# Generated at 2022-06-25 19:35:00.172345
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():

    # source: R2/class.py
    # We construct the object using the class's constructor
    literal_parsing_failure_0 = LiteralParsingFailure('n', 'n')



# Generated at 2022-06-25 19:35:02.383701
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    str_0 = 'n'
    encoded_file_0 = IOError()
    literal_parsing_failure_0 = LiteralParsingFailure(str_0, encoded_file_0)


# Generated at 2022-06-25 19:35:04.395021
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    str_0 = 'n'
    file_skipped_0 = FileSkipped(str_0, str_0)


# Generated at 2022-06-25 19:35:06.227095
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    test_case_0()


# Generated at 2022-06-25 19:35:08.631099
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = 'n'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)


# Generated at 2022-06-25 19:35:10.475745
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = 'n'
    unsupported_encoding_0 = UnsupportedEncoding(filename)


# Generated at 2022-06-25 19:35:38.960211
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    str_0 = 'n'
    assignments_format_mismatch_0 = AssignmentsFormatMismatch(str_0)


# Generated at 2022-06-25 19:35:41.635389
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    str_0 = 'n'
    file_skip_comment_0 = FileSkipComment(str_0)


# Generated at 2022-06-25 19:35:44.136683
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    str_1 = 'n'
    file_skip_setting_0 = FileSkipSetting(str_1)
    str_2 = file_skip_setting_0.file_path


# Generated at 2022-06-25 19:35:47.625301
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
	# Constructor 1
	path_0 = '/home/ubuntu/workspace/test/test_file'
	path_0 = Path(path_0)
	test_case_0 = UnsupportedEncoding(path_0)
	isinstance(test_case_0, ISortError)

# Generated at 2022-06-25 19:35:50.596890
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str_0 = '/c'
    existing_syntax_errors_0 = ExistingSyntaxErrors(str_0)
    assert existing_syntax_errors_0.file_path == '/c', 'Expect file_path is /c'



# Generated at 2022-06-25 19:35:52.795989
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    str_0 = 'n'
    introduced_syntax_errors_0 = IntroducedSyntaxErrors(str_0)
    assert introduced_syntax_errors_0.file_path == str_0


# Generated at 2022-06-25 19:35:53.262999
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    UnsupportedEncoding()

# Generated at 2022-06-25 19:35:55.315040
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    obj = UnsupportedSettings({"key": {"value": "val", "source": "src"}})
    assert obj.unsupported_settings == {"key": {"value": "val", "source": "src"}}



# Generated at 2022-06-25 19:35:56.967438
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = Path('subprocess.py')

    test_FileSkipSetting_0 = FileSkipSetting(file_path)

test_FileSkipSetting()

# Generated at 2022-06-25 19:36:02.499265
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path_0 = 'e9V'
    message_0 = ','
    file_skipped_0 = FileSkipped(message_0, file_path_0)
