

# Generated at 2022-06-25 19:31:44.476252
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_skip_setting_0 = FileSkipSetting('A')
    assert file_skip_setting_0.file_path == 'A'
    assert file_skip_setting_0.args[0] == 'A was skipped as it\'s listed in \'skip\' setting or matches a glob in \'skip_glob\' setting'


# Generated at 2022-06-25 19:31:46.075785
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(Exception):
        ISortError()


# Generated at 2022-06-25 19:31:57.236314
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code_0 = "isort was told to sort a literal of type"
    original_error_0 = "isort was told to sort a literal of type"
    literal_parsing_failure_0 = LiteralParsingFailure(code_0, original_error_0)
    # Exception getter for: code
    # Type is: <class 'str'>
    code_0 = literal_parsing_failure_0.code
    # Exception getter for: original_error
    # Type is: <class 'Exception'>
    original_error_0 = literal_parsing_failure_0.original_error
    # Exception message getter
    # Type is: <class 'str'>
    message_str_0 = literal_parsing_failure_0.message
    # Exception message getter
    # Type is

# Generated at 2022-06-25 19:32:01.077614
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    literal_sort_type_mismatch_0 = LiteralSortTypeMismatch(int, str)
    literal_sort_type_mismatch_1 = LiteralSortTypeMismatch(str, str)
    literal_sort_type_mismatch_0.kind
    literal_sort_type_mismatch_0.expected_kind
    literal_sort_type_mismatch_1.kind
    literal_sort_type_mismatch_1.expected_kind

    literal_sort_type_mismatch_1.kind = int
    literal_sort_type_mismatch_1.expected_kind = int


# Generated at 2022-06-25 19:32:04.003851
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    invalid_settings_path_0 = InvalidSettingsPath("settings_path")
    #TODO: Create test with -> assert isinstance(invalid_settings_path_0, ISortError)


# Generated at 2022-06-25 19:32:06.648388
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    test_dict = {'dummy': {'value': 'dummy', 'source': 'dummy'}}
    UnsupportedSettings(test_dict)

# Generated at 2022-06-25 19:32:09.419477
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 19:32:12.284819
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formattingPluginDoesNotExist1 = FormattingPluginDoesNotExist("formatter")


# Generated at 2022-06-25 19:32:13.761445
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    exception_0 = LiteralSortTypeMismatch(TypeError, str)

# Generated at 2022-06-25 19:32:15.756198
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    pass
    #introduced_syntax_errors_0 = IntroducedSyntaxErrors(file_path=str())
