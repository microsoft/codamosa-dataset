

# Generated at 2022-06-21 14:56:11.194728
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    skip_comment=FileSkipComment("D:\\PythonProject\\PythonProject\\Code\\isort\\isort\\tests\\skip_comment")
    assert skip_comment.file_path == "D:\\PythonProject\\PythonProject\\Code\\isort\\isort\\tests\\skip_comment"

# Generated at 2022-06-21 14:56:13.554634
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    error = FormattingPluginDoesNotExist('my-plugin')
    assert str(error) == "Specified formatting plugin of my-plugin does not exist. "

# Generated at 2022-06-21 14:56:18.542444
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    msg = "this is a test"
    file_path = "path/to/file"
    e = FileSkipComment(file_path)
    assert e.message == msg
    assert e.file_path == file_path
    assert e.args[0] == msg



# Generated at 2022-06-21 14:56:21.560902
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    isortException = ExistingSyntaxErrors("file_path")
    assert isortException
    assert isortException.file_path == "file_path"


# Generated at 2022-06-21 14:56:23.258147
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("test_msg", "test_file")
    except ISortError:
        pass



# Generated at 2022-06-21 14:56:27.676684
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors('existingSyntaxErrors.py').args[0] == 'isort was told to sort imports within code that contains syntax errors: ' \
                                                                      'existingSyntaxErrors.py.'
    assert ExistingSyntaxErrors('existingSyntaxErrors.py').file_path == 'existingSyntaxErrors.py'

# Generated at 2022-06-21 14:56:29.563362
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception = IntroducedSyntaxErrors("test")
    assert exception.file_path == "test"

# Generated at 2022-06-21 14:56:33.188266
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"foo": "bar"}
    test_exc = UnsupportedSettings(unsupported_settings)
    assert test_exc.unsupported_settings == unsupported_settings

# Generated at 2022-06-21 14:56:40.334998
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        import ast
        ast.literal_eval("err")
    except Exception as e:
        error = LiteralParsingFailure("err", e)

    assert str(error) == ('isort failed to parse the given literal err. '
                          'It\'s important to note that isort literal sorting '
                          'only supports simple literals parsable by '
                          'ast.literal_eval which gave the exception of '
                          '<class \'ValueError\'>: malformed string')
    assert error.code == 'err'
    assert isinstance(error.original_error, ValueError)

# Generated at 2022-06-21 14:56:44.623251
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(list, dict)
    except LiteralSortTypeMismatch as error:
        assert error.kind == list
        assert error.expected_kind == dict

# Generated at 2022-06-21 14:56:50.677159
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings(
        unsupported_settings={
            "name1": {"value": "value1", "source": "source1"},
            "name2": {"value": "value2", "source": "source2"},
        }
    )

# Generated at 2022-06-21 14:56:58.098841
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    import ast
    for code in ['[a,b]']:
        try:
            ast.literal_eval(code)
        except SyntaxError as err:
            try:
                # Should not raise TestFailedError:
                raise LiteralParsingFailure(code, err)
            except LiteralParsingFailure as lpf:
                # Check lpf message
                msg = lpf.__str__()
                assert 'isort failed to parse' in msg
                # Check lpf.code
                assert lpf.code == code
                assert isinstance(lpf.original_error, SyntaxError)
                assert lpf.original_error.msg == err.msg
                assert lpf.original_error.lineno == err.lineno

# Generated at 2022-06-21 14:57:00.223101
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("Test")
    except ProfileDoesNotExist as e:
        assert e.profile == "Test"

# Generated at 2022-06-21 14:57:01.361320
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert str(FormattingPluginDoesNotExist('Test')) == 'Specified formatting plugin of Test does not exist. '

# Generated at 2022-06-21 14:57:04.196925
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("import os")
    except AssignmentsFormatMismatch as e:
        assert type(e) is AssignmentsFormatMismatch
        assert e.code == "import os"


# Generated at 2022-06-21 14:57:09.089253
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors) as e:
        file_path = "./com"
        raise IntroducedSyntaxErrors(file_path)
    assert str(e.value) == "isort introduced syntax errors when attempting to sort the imports contained within ./com."
    assert e.value.file_path == "./com"


# Generated at 2022-06-21 14:57:10.194766
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    IntroducedSyntaxErrors("test")

# Generated at 2022-06-21 14:57:14.123967
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    exception = FileSkipSetting("D:/Users/sarra/Desktop/project/test_file")
    assert exception.file_path == "D:/Users/sarra/Desktop/project/test_file"


# Generated at 2022-06-21 14:57:16.191800
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
        test_object = ExistingSyntaxErrors("test_file")
        assert test_object.file_path == "test_file"

# Generated at 2022-06-21 14:57:17.433103
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch('x = 4')

