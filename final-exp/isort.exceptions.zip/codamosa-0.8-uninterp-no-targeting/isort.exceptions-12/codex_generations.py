

# Generated at 2022-06-21 14:56:09.951000
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings._format_option("foo", "bar", "baz")

# Generated at 2022-06-21 14:56:17.021127
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    msg = "isort was told to sort a literal of type int but was given a literal of type str."
    kind = type("")
    expected_kind = int

    assert LiteralSortTypeMismatch(kind, expected_kind).args[0] == msg
    assert LiteralSortTypeMismatch(kind, expected_kind).kind == kind
    assert LiteralSortTypeMismatch(kind, expected_kind).expected_kind == expected_kind

# Generated at 2022-06-21 14:56:25.541824
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert "isort was told to use the settings_path: /home/abc as the base directory or " \
            "file that represents the starting point of config file discovery, but it does not " \
            "exist." == InvalidSettingsPath("/home/abc").__init__("/home/abc")
    assert "isort was told to use the settings_path: /home/abc as the base directory or " \
            "file that represents the starting point of config file discovery, but it does not " \
            "exist." == InvalidSettingsPath("/home/abc").message
    assert "settings_path" == InvalidSettingsPath("/home/abc").settings_path


# Generated at 2022-06-21 14:56:31.838716
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """Testing constructor of class LiteralSortTypeMismatch"""
    with pytest.raises(LiteralSortTypeMismatch) as err:
        raise LiteralSortTypeMismatch(kind=false, expected_kind=True)
    assert err.value.kind is False
    assert err.value.expected_kind is True
    assert str(err.value) == "isort was told to sort a literal of type <class 'bool'> but was given a literal of type <class 'bool'>."
    assert repr(err.value) == "<LiteralSortTypeMismatch: isort was told to sort a literal of type <class 'bool'> but was given a literal of type <class 'bool'>."

# Generated at 2022-06-21 14:56:35.252315
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("file_name")
    except UnsupportedEncoding as e:
        assert e.args[0] == "Unknown or unsupported encoding in file_name"

# Generated at 2022-06-21 14:56:44.339525
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    from pytest import raises
    with raises(AssignmentsFormatMismatch) as excinfo:
        raise AssignmentsFormatMismatch('x = 1\ny = 2')
    assert str(excinfo.value) == (
        'isort was told to sort a section of assignments, however the given code:\n\n'
        'x = 1\ny = 2\n\n'
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        '{variable_name} = {value}\n'
        '{variable_name2} = {value2}\n'
        '...\n\n')

# Generated at 2022-06-21 14:56:45.796494
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(kind=int, expected_kind=str) != None

# Generated at 2022-06-21 14:56:48.122291
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    obj = ExistingSyntaxErrors("/test.py")
    assert obj.file_path == "/test.py"

# Generated at 2022-06-21 14:56:51.649329
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "1"
    original_error = Exception("Oops")
    exception = LiteralParsingFailure(code, original_error)
    assert exception.code == code
    assert exception.original_error == original_error

# Generated at 2022-06-21 14:56:53.931086
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    exc = ExistingSyntaxErrors("/tmp/spam.py")
    assert exc.file_path == "/tmp/spam.py"



# Generated at 2022-06-21 14:57:00.518225
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    syntax_error = IntroducedSyntaxErrors("test.py")
    assert syntax_error.file_path == "test.py"

# Generated at 2022-06-21 14:57:03.360667
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=dict, expected_kind=set)
    except LiteralSortTypeMismatch as e:
        assert e.kind == dict
        assert e.expected_kind == set

# Generated at 2022-06-21 14:57:06.948027
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch) as exc_info:
        raise LiteralSortTypeMismatch(str, int)
    assert str(exc_info.value) == 'isort was told to sort a literal of type <class \'int\'> ' \
                                 'but was given a literal of type <class \'str\'>.'

# Generated at 2022-06-21 14:57:09.045781
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    exc = LiteralSortTypeMismatch(set, dict)
    assert exc.kind == set
    assert exc.expected_kind == dict


# Generated at 2022-06-21 14:57:11.063361
# Unit test for constructor of class ISortError
def test_ISortError():
    err = ISortError("This is a test error.")
    assert err.__str__() == "This is a test error."

# Generated at 2022-06-21 14:57:19.145033
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = 'C:\\Users\\dell\\Desktop\\x.py'
    try:
        f = open(file_path, 'r+')
        f.write("""import sys
print("Hello World!!")
      """)
    except Exception as e:
        print("File cannot be opened")
    else:
        try:
            raise IntroducedSyntaxErrors(file_path)
        except IntroducedSyntaxErrors as e:
            assert isinstance(e, IntroducedSyntaxErrors)
            print("File {0} contains syntax errors.".format(file_path))
            print("{0} ".format(e))



# Generated at 2022-06-21 14:57:31.146540
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(
            "var1=5\nvar2=5"
            "\nvar3=5"
            "\nvar4=5"
            "\nvar5=5"
            "\nvar6=5"
            "\nvar7=5"
            "\nvar8=5"
            "\nvar9=5"
            "\nvar10=5"
            "\nvar11=5"
            "\nvar12=5"
            "\nvar13=5"
            "\nvar14=5"
            "\nvar15=5"
            "\nvar16=5\n"
        )
    except AssignmentsFormatMismatch as e:
        assert e.message
        assert isinstance(e, AssignmentsFormatMismatch)

# Generated at 2022-06-21 14:57:37.519615
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("tests/code/file_with_syntax_error.py")
    except ExistingSyntaxErrors as e:
        assert isinstance(e, ISortError)
        assert e.file_path == "tests/code/file_with_syntax_error.py"


# Generated at 2022-06-21 14:57:41.141593
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    message = f"{file_path} was skipped as it's listed in 'skip' setting" \
              " or matches a glob in 'skip_glob' setting"
    file_path = "test_files/a.py"
    assert FileSkipSetting(file_path=file_path).message == message

# Generated at 2022-06-21 14:57:43.480342
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("bogus.txt")
    except UnsupportedEncoding as e:
        assert str(e) == "Unknown or unsupported encoding in bogus.txt"

# Generated at 2022-06-21 14:57:50.991456
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection(
            import_module="math", section="FIRSTPARTY"
        )
    except MissingSection:
        pass



# Generated at 2022-06-21 14:57:57.667655
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Tests the string representation of the exception message;
    # The message should be composed of the exception type and the exception text
    assert str(LiteralSortTypeMismatch) == "isort.exceptions.LiteralSortTypeMismatch: isort was told to sort a literal of type {expected_kind} but was given a literal of type {kind}."
    assert str(LiteralSortTypeMismatch.__init__) == str(LiteralSortTypeMismatch(str, str))

# Generated at 2022-06-21 14:58:06.336174
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"option1": "value1"}
    error_message = "isort was provided settings that it doesn't support:\n\n"
    error_message += "\t- option1 = value1  (source: 'unknown')\n\n"
    error_message += "For a complete and up-to-date listing of supported settings see: "
    error_message += "https://pycqa.github.io/isort/docs/configuration/options/.\n"

    assert str(UnsupportedSettings(unsupported_settings)) == error_message

# Generated at 2022-06-21 14:58:07.709867
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist('foo').profile == 'foo'


# Generated at 2022-06-21 14:58:11.999038
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    actual = ExistingSyntaxErrors(file_path="test.py")
    expected = ("isort was told to sort imports within code that contains syntax errors: "
                "test.py.")
    assert expected == actual.args[0]

# Generated at 2022-06-21 14:58:13.450408
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    FormattingPluginDoesNotExist("my_plugin")

# Generated at 2022-06-21 14:58:15.198020
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    e = ISortError.UnsupportedEncoding('test.py')
    assert e.filename == 'test.py'

# Generated at 2022-06-21 14:58:18.732562
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    msg = "Here's a message."
    path = "./files/test.py"
    exception = FileSkipped(msg, path)
    assert exception.file_path == path
    assert str(exception) == f"{msg} File path: {path}"

# Generated at 2022-06-21 14:58:21.321540
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("argonaut")
    except ProfileDoesNotExist:
        raise Exception("Something has gone horribly wrong")

# Generated at 2022-06-21 14:58:25.767621
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"test_setting1": {"value": "test_value1", "source": "test_source1"}}
    us = UnsupportedSettings(unsupported_settings)

    assert us.unsupported_settings == unsupported_settings