

# Generated at 2022-06-21 14:56:04.946405
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist, match="Specified profile of fake does not exist"):
        raise ProfileDoesNotExist("fake")

# Generated at 2022-06-21 14:56:08.885222
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path = "settings_path"
    try:
        raise InvalidSettingsPath(settings_path)
    except InvalidSettingsPath as e:
        assert(e.settings_path == settings_path)


# Generated at 2022-06-21 14:56:10.840469
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch

# Generated at 2022-06-21 14:56:13.554634
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("message", "file_path").file_path == "file_path"
    assert FileSkipped("message", "file_path").message == "message"

# Generated at 2022-06-21 14:56:17.127192
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 1"
    expected_code = "a = 1"
    obj = AssignmentsFormatMismatch(code)
    assert obj.code == expected_code

# Generated at 2022-06-21 14:56:20.152444
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    exception = InvalidSettingsPath('hello.py')
    assert exception.settings_path == 'hello.py'
    assert 'hello.py' in str(exception)


# Generated at 2022-06-21 14:56:30.445804
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("testprofile")
    except:
        exception = ISortError

# Generated at 2022-06-21 14:56:38.927724
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    import sys
    exception = LiteralSortTypeMismatch(int, str)
    print(str(exception))
    expected_output = (
        "isort was told to sort a literal of type <class 'str'> but was given "
        "a literal of type <class 'int'>.\n"
    )
    assert str(exception) == expected_output
    assert exception.kind == int
    assert exception.expected_kind == str
# End of test

if __name__ == "__main__":
    import sys
    test_LiteralSortTypeMismatch()
    sys.exit()

# Generated at 2022-06-21 14:56:43.984245
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    class test_ExistingSyntaxErrors:
        def __init__(self):
            self.file_path = "test"
    
    test = test_ExistingSyntaxErrors()
    assert test.file_path == "test"


# Generated at 2022-06-21 14:56:49.167622
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'message'
    file_path = 'file_path'
    file_skipped = FileSkipped(message, file_path)
    assert message == file_skipped.__str__()
    assert message == file_skipped.message
    assert file_path == file_skipped.file_path



# Generated at 2022-06-21 14:56:54.398568
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    arg1 = "message"
    arg2 = "filepath"
    file_skipped = FileSkipped(arg1, arg2)
    assert file_skipped.message == arg1
    assert file_skipped.file_path == arg2

# Generated at 2022-06-21 14:56:57.061316
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "black"
    formatter_error = FormattingPluginDoesNotExist(formatter)
    assert formatter == formatter_error.formatter

# Generated at 2022-06-21 14:56:58.379515
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    LiteralSortTypeMismatch(2, 3)

# Generated at 2022-06-21 14:57:01.094969
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert (
        FileSkipSetting("/path/to/test.py").file_path
        == "/path/to/test.py"
    )


# Generated at 2022-06-21 14:57:04.359569
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding(filename="test_file.py")
    except UnsupportedEncoding as ex:
        assert ex.filename == "test_file.py"
    else:
        # If a matched exception is not raised, test will fail
        assert False

# Generated at 2022-06-21 14:57:06.980129
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("myprofile")
    except ProfileDoesNotExist:
        assert True
    else:
        assert False


# Generated at 2022-06-21 14:57:13.634782
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assert AssignmentsFormatMismatch("v=8").args[0] == "isort was told to sort a section of assignments, however the given code:\n\n"
    "v=8\n\n"
    "Does not match isort's strict single line formatting requirement for assignment sorting:\n\n"
    "{variable_name} = {value}\n"
    "{variable_name2} = {value2}\n"
    "...\n\n"

# Generated at 2022-06-21 14:57:16.099789
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "file_path"

# Generated at 2022-06-21 14:57:18.302808
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    m = FileSkipped("message", r"D:\test.py")
    assert m.message == "message"
    assert m.file_path == r"D:\test.py"

# Generated at 2022-06-21 14:57:20.906378
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    from . import ISortError
    from . import UnsupportedEncoding

    assert issubclass(UnsupportedEncoding, ISortError)

# Generated at 2022-06-21 14:57:27.985649
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors, match=r"isort was told to sort imports within code that contains syntax errors"):
        raise ExistingSyntaxErrors("")


# Generated at 2022-06-21 14:57:29.972878
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    err = ExistingSyntaxErrors('path')
    assert err.file_path == 'path'


# Generated at 2022-06-21 14:57:33.781099
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(type('a'), type('b'))
    except LiteralSortTypeMismatch as e:
        assert e.kind is str
        assert e.expected_kind is str


# Generated at 2022-06-21 14:57:37.322125
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    """Unit test for constructor of class ProfileDoesNotExist"""
    assert ProfileDoesNotExist("blah")



# Generated at 2022-06-21 14:57:43.160480
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # Pre-condition: Settings that are not supported are added
    unsupported_settings = {
        "option1": {
            "value": "foo",
            "source": "my_config.py",
        },
        "option2": {
            "value": "bar",
            "source": "command_line",
        },
    }

    # Action: The constructor is called
    exception = UnsupportedSettings(unsupported_settings)

    # Post-condition: The provided settings are represented correctly in the exception
    assert unsupported_settings == exception.unsupported_settings

# Generated at 2022-06-21 14:57:46.267116
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "Test_File"
    try:
        raise IntroducedSyntaxErrors(file_path)
    except IntroducedSyntaxErrors as e:
        assert e.file_path == file_path
        assert str(file_path) in str(e)



# Generated at 2022-06-21 14:57:53.233350
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting('test')
        assert False, 'No exception raised'
    except Exception as e: 
        assert e.file_path == 'test'
        assert str(e) == 'test was skipped as it\'s listed in \'skip\' setting' \
                         ' or matches a glob in \'skip_glob\' setting'


# Generated at 2022-06-21 14:57:59.864373
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    a = {
        "unsupported_settings": [
            {
                "name": "a",
                "value": "b",
                "source": "c",
            }
        ]
    }
    b = UnsupportedSettings(a)
    assert b.unsupported_settings == a
    assert str(b) == "isort was provided settings that it doesn't support:\n\n\t- a = b  (source: 'c')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"


# Generated at 2022-06-21 14:58:05.259519
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # Arrange
    code = "a = 1\n"
    # Act
    # Passes in the code and the type of exception that is expected
    with pytest.raises(ISortError) as info:
        AssignmentsFormatMismatch(code)
    # Assert
    # Checks if the code passed in is in the message
    assert code in info.value.args[0]


# Generated at 2022-06-21 14:58:07.285656
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    """Tests that an instance of FileSkipComment can be created"""
    FileSkipComment("/path/to/file.py")