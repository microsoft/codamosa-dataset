

# Generated at 2022-06-21 14:56:12.186615
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors, match='isort'):
        raise IntroducedSyntaxErrors('test')


# Generated at 2022-06-21 14:56:13.192472
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist

# Generated at 2022-06-21 14:56:19.007607
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(
            "a = 1\n"
            "b = 2\nc = 3"
        )
    except AssignmentsFormatMismatch as e:
        assert (
            e.code
            == "a = 1\n"
            "b = 2\nc = 3"
        )

# Generated at 2022-06-21 14:56:24.892872
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'dir/dir2/dir3/dir4/dir5/dir6/dir7/dir8/dir9/dir10/dir11/dir12'
    expected_message = "{} was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting".format(file_path)
    assert FileSkipSetting(file_path).args[0] == expected_message


# Generated at 2022-06-21 14:56:29.731215
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    from isort.settings import Section

    assert FileSkipped('message1', 'file_path1').args[0] == 'message1'
    assert FileSkipped('message1', 'file_path1').args[1] == 'file_path1'

# Generated at 2022-06-21 14:56:32.897150
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({"this": {"value": 5, "source": "test"}})

    # if exception raised, then test is successful
    assert True

# Generated at 2022-06-21 14:56:35.774090
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = object()
    expected_kind = object()
    literal = LiteralSortTypeMismatch(kind, expected_kind)
    assert literal.kind == kind
    assert literal.expected_kind == expected_kind

# Generated at 2022-06-21 14:56:40.656540
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(type(""), type(""))
    except LiteralSortTypeMismatch as e:
        assert str(e) == "isort was told to sort a literal of type <class ''> but was given " \
            "a literal of type <class ''>."
        # assert e.kind == type("")
        # assert e.expected_kind == type("")
    finally:
        pass


# Generated at 2022-06-21 14:56:44.702582
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fs = FileSkipped('Example message', 'Example path')
    assert fs.message == 'Example message'
    assert fs.file_path == 'Example path'



# Generated at 2022-06-21 14:56:48.208131
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({"setting_one": {"value": 1, "source": "cli"},
                         "setting_two": {"value": True, "source": "user_config"}})

