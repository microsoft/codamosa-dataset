

# Generated at 2022-06-21 14:56:11.562286
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        r = AssignmentsFormatMismatch("hi")
    except:
        return None


# Generated at 2022-06-21 14:56:17.274057
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "some_file_path.py"
    exception = FileSkipSetting(file_path=file_path)
    assert exception.message == f"{file_path} was skipped as it's listed in 'skip' setting" \
                                " or matches a glob in 'skip_glob' setting"
    assert exception.file_path == file_path

# Generated at 2022-06-21 14:56:20.855080
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "x=3\n"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert e.code == code


# Generated at 2022-06-21 14:56:24.174331
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("some file")
    except UnsupportedEncoding as e:
        assert e.args[0] == "Unknown or unsupported encoding in some file"
        assert e.filename == "some file"

# Generated at 2022-06-21 14:56:28.739879
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure(code="[1, 2, 3, 4,]", original_error=IndexError("index out of range"))
    except LiteralParsingFailure as error:
        print(error)
        # isort was told to sort a literal of type list but was given a literal of type tuple.


# Generated at 2022-06-21 14:56:33.236132
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("file_path")
    except IntroducedSyntaxErrors as e:
        assert e.args[0] == 'isort introduced syntax errors when attempting to sort the imports contained within file_path.'


# Generated at 2022-06-21 14:56:36.645792
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        a = LiteralSortTypeMismatch(1, 2)
        assert a.kind == 1
        assert a.expected_kind == 2
    except Exception:
        assert False
        #print("Exception was raised inside LiteralSortTypeMismatch")

# Generated at 2022-06-21 14:56:38.580807
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    exception = InvalidSettingsPath('test')
    assert exception.settings_path == 'test'


# Generated at 2022-06-21 14:56:40.748535
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"



# Generated at 2022-06-21 14:56:43.940269
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    error = AssignmentsFormatMismatch("mock_code")
    assert error.code == "mock_code"

# Generated at 2022-06-21 14:56:50.547366
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch) as excinfo:
        raise LiteralSortTypeMismatch(1, 2)
    assert str(excinfo.value) == "isort was told to sort a literal of type 2 but was given a literal of type 1."


# Generated at 2022-06-21 14:56:52.504558
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist("formatter").formatter == "formatter"



# Generated at 2022-06-21 14:56:57.356714
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    import pytest
    from isort.exceptions import FormattingPluginDoesNotExist

    with pytest.raises(FormattingPluginDoesNotExist) as exc:
        raise FormattingPluginDoesNotExist("test")

    assert exc.value.formatter == "test"

# Generated at 2022-06-21 14:57:00.685393
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("ram")
    except IntroducedSyntaxErrors as e:
        print("Pass:")
        print(e)
        assert True


# Generated at 2022-06-21 14:57:04.283164
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Creating object of class FileSkipSetting
    obj = FileSkipSetting("tests.py")
    # Asserting the message
    assert "tests.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting" == obj.args[0]


# Generated at 2022-06-21 14:57:12.982237
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    exception = MissingSection(import_module=import_module, section=section)

    assert exception.args == (
        f"Found {import_module} import while parsing, but {section} was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info.",
    )
    assert exception.import_module == import_module
    assert exception.section == section



# Generated at 2022-06-21 14:57:15.517325
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("Invalid settings path")
    except ISortError as e:
        assert str(e) == "Invalid settings path"


# Generated at 2022-06-21 14:57:17.792893
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    e = UnsupportedEncoding("/foo/bar")
    assert e.filename == "/foo/bar"
    assert e.args == ("Unknown or unsupported encoding in /foo/bar",)

# Generated at 2022-06-21 14:57:23.216060
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("test_file")
    except Exception as e:
        message=str(e)
        assert message == "test_file was skipped as it's listed in 'skip' setting" \
                          " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-21 14:57:29.150608
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    obj = LiteralSortTypeMismatch('a', '1')
    assert isinstance(obj, ISortError)
    assert str(obj) == "isort was told to sort a literal of type 1 but was given a literal of type a."
    assert isinstance(obj.kind, str)
    assert isinstance(obj.expected_kind, str)


# Generated at 2022-06-21 14:57:33.681852
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('')
    except Exception as e:
        assert e.__str__() != ''
        assert e.profile != ''

# Generated at 2022-06-21 14:57:37.612776
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    exception = InvalidSettingsPath("D:\Repo\isort\isort")
    assert exception.settings_path == "D:\Repo\isort\isort"


# Generated at 2022-06-21 14:57:39.905799
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    skip = FileSkipSetting("foo.py")
    assert skip.file_path == "foo.py"
    assert "foo.py" in str(skip)



# Generated at 2022-06-21 14:57:42.367670
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors(file_path="/home/user/example.py")
    except Exception as e:
        assert e.file_path == "/home/user/example.py"

# Generated at 2022-06-21 14:57:46.300591
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped_instance = FileSkipped("message", "file_path")

    assert file_skipped_instance.file_path == "file_path"
    assert file_skipped_instance.args[0] == "message"
    assert isinstance(file_skipped_instance, ISortError)
    assert isinstance(file_skipped_instance, Exception)


# Generated at 2022-06-21 14:57:51.040615
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding(filename="foo.py")
    except UnsupportedEncoding as error:
        assert str(error) == "Unknown or unsupported encoding in foo.py"
        assert error.filename == "foo.py"

# Generated at 2022-06-21 14:57:53.481643
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    e = ExistingSyntaxErrors("file_path")
    assert e.file_path == "file_path"

# Generated at 2022-06-21 14:57:55.235638
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "a"
    original_error = 1
    try:
        raise LiteralParsingFailure(code, original_error)
    except LiteralParsingFailure as e:
        assert e.code == "a"
        assert e.original_error == 1


# Generated at 2022-06-21 14:57:57.493693
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    obj = InvalidSettingsPath("some thing")
    assert isinstance(obj, ISortError)
    assert obj.settings_path == "some thing"


# Generated at 2022-06-21 14:58:01.077380
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    LiteralSortTypeMismatch(type([1, 2, 3]), type(set))

# Generated at 2022-06-21 14:58:05.967950
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with raises(AssignmentsFormatMismatch):
        raise AssignmentsFormatMismatch("foo")
test_AssignmentsFormatMismatch()

# Generated at 2022-06-21 14:58:08.324217
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except Exception as e:
        assert str(e) == "test"


# Generated at 2022-06-21 14:58:10.074261
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "file_path"
        

# Generated at 2022-06-21 14:58:13.169742
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors):
        f = IntroducedSyntaxErrors("code.py")
        assert f.file_path == "code.py"
        raise f

# Generated at 2022-06-21 14:58:15.980125
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("setings_path")
    except InvalidSettingsPath as e:
        assert e.settings_path == "setings_path"



# Generated at 2022-06-21 14:58:18.239306
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('test')
    except ProfileDoesNotExist as e:
        assert str(e)[:18] == 'Specified profile'

# Generated at 2022-06-21 14:58:21.687419
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors("Error message")
    assert err.file_path == "Error message"
    assert str(err) == "isort introduced syntax errors when attempting to sort the imports contained within Error message."


# Generated at 2022-06-21 14:58:26.311358
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("local")
    except ProfileDoesNotExist as error:
        assert error.profile == "local"
        assert error.args[0].startswith("Specified profile of local does not exist")

# Generated at 2022-06-21 14:58:29.229048
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except ISortError:
        assert True


# Generated at 2022-06-21 14:58:34.631465
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error_message = "error message"
    message = "isort was told to sort imports within code that contains syntax errors: \"%s\"." % \
              error_message
    obj = ExistingSyntaxErrors(error_message)
    assert obj.__str__() == message
    assert obj.file_path == error_message

# Generated at 2022-06-21 14:58:38.213970
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('x', 'y')


# Generated at 2022-06-21 14:58:39.130410
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    raise UnsupportedEncoding('fileName')

# Generated at 2022-06-21 14:58:41.247068
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'test'
    formatter_e = FormattingPluginDoesNotExist(formatter)
    assert formatter_e.formatter == 'test'

# Generated at 2022-06-21 14:58:43.449878
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors('')
    except ExistingSyntaxErrors as e:
        print(e.file_path)
        assert not e.file_path

# Generated at 2022-06-21 14:58:53.099170
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"
        assert e.args[0] == \
            "Specified profile of test does not exist. " \
            "Available profiles: black, pycharm, google, isort/config.cfg, jupyter_notebook, " \
            "grpc, pyproject, django, open_stack, pytest, google_py36, open_source, " \
            "google_py27, google_py37, atom, vscode, pycharm_djanio, pep8, hacking, " \
            "pycharm_pytest."

# Generated at 2022-06-21 14:58:55.621932
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors.__doc__ is not None
    assert IntroducedSyntaxErrors.__init__.__doc__ is not None

# Generated at 2022-06-21 14:58:58.673546
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("C:\fakepath")
    except InvalidSettingsPath as e:
        assert isinstance(e, Exception)
        assert isinstance(e, ISortError)
        assert e.settings_path == "C:\fakepath"


# Generated at 2022-06-21 14:59:01.719345
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors("path/file.py")
    assert error.file_path == "path/file.py"


# Generated at 2022-06-21 14:59:08.225970
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.__doc__ == ProfileDoesNotExist.__doc__
        assert str(e) == f"Specified profile of test does not exist. Available profiles: black,pep8,google,grisou,pycharm,junit,vscode,visual_studio,atom,hacking,unittest_formatting,yapf,dummy"
        assert e.profile == "test"

# Generated at 2022-06-21 14:59:13.482566
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist(profile='django')

# Generated at 2022-06-21 14:59:16.561910
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting("isort failed")


# Generated at 2022-06-21 14:59:19.022179
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors('tmp/file.py')
    assert "isort was told to sort imports within code that contains syntax errors: tmp/file.py." == error.__str__()

# Generated at 2022-06-21 14:59:20.497063
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = 'filename'
    obj = UnsupportedEncoding(filename)
    assert obj != None

# Generated at 2022-06-21 14:59:23.533578
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        formatter = "dfgdsfg"
        raise FormattingPluginDoesNotExist(formatter)
    except ISortError as e:
        assert str(e) == f"Specified formatting plugin of {formatter} does not exist. "



# Generated at 2022-06-21 14:59:25.171408
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    f = FileSkipped("message", "file_path")
    assert f.message == "message"
    assert f.file_path == "file_path"

# Generated at 2022-06-21 14:59:26.153544
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fs = FileSkipped("")
    assert fs is not None


# Generated at 2022-06-21 14:59:30.600356
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath) as error:
        raise InvalidSettingsPath("Invalid settings path")
    assert str(error.value) == "isort was told to use the settings_path: Invalid settings path as the base directory or file that represents the starting point of config file discovery, but it does not exist."



# Generated at 2022-06-21 14:59:32.113015
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist('pytest')
    assert error.profile == 'pytest'

# Generated at 2022-06-21 14:59:36.305809
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist("test profiles")
    assert error.profile == "test profiles"

#Unit test for constructor of class FormattingPluginDoesNotExist

# Generated at 2022-06-21 14:59:38.136070
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    my_exception = IntroducedSyntaxErrors("file_path")
    assert my_exception.file_path == "file_path"


# Generated at 2022-06-21 14:59:46.288196
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'test.py'
    message = f"{file_path} contains an file skip comment and was skipped."
    error = FileSkipComment(file_path=file_path)
    assert(error.message == message)

# Generated at 2022-06-21 14:59:47.456371
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError()

# Generated at 2022-06-21 14:59:50.187481
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("filepath")
    except InvalidSettingsPath as e:
        assert e.settings_path == "filepath"



# Generated at 2022-06-21 14:59:53.632269
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('Test')
    except ProfileDoesNotExist as pe:
        assert pe.profile == 'Test'


# Generated at 2022-06-21 14:59:57.537699
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"blah": {"value": True, "source": "cli"}}
    exception = UnsupportedSettings(unsupported_settings)
    filtered_error = (exception.message.split("\n")[2].split(" ")[1])
    assert ("'blah'" == filtered_error)

# Generated at 2022-06-21 15:00:01.441989
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    #Input: file_path = "test.py"
    #Output: isort introduced syntax errors when attempting to sort the imports contained within test.py.
    assert IntroducedSyntaxErrors("test.py").__str__() == "isort introduced syntax errors when attempting to sort the imports contained within test.py."

# Generated at 2022-06-21 15:00:09.793785
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        int("some_bad_literal")
    except ValueError as e:
        exception = LiteralParsingFailure(
            code="some_bad_literal",
            original_error=e,
        )
        assert str(exception) == ("isort failed to parse the given literal "
                                  "some_bad_literal. It's important to note "
                                  "that isort literal sorting only supports "
                                  "simple literals parsable by ast.literal_eval "
                                  "which gave the exception of invalid literal "
                                  "for int() with base 10: 'some_bad_literal'.")
        assert exception.code == "some_bad_literal"
        assert exception.original_error == e

# Generated at 2022-06-21 15:00:14.772310
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    error = InvalidSettingsPath('file_path')
    assert error.args[0] == "isort was told to use the settings_path: file_path as the base directory or " \
                            "file that represents the starting point of config file discovery, but it does not " \
                            "exist."
    assert error.settings_path == "file_path"


# Generated at 2022-06-21 15:00:15.629786
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch('code')

# Generated at 2022-06-21 15:00:19.109055
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        ISortError()
    except:
        print('test ISortError() pass')
    else:
        print('test ISortError() fail')

#test_ISortError()
