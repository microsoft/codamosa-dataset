

# Generated at 2022-06-21 14:56:09.368281
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    expected = ISortError
    actual = ProfileDoesNotExist("test").__class__.__bases__
    assert expected == actual

# Generated at 2022-06-21 14:56:16.915961
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("test_code", ValueError("value error"))
    except LiteralParsingFailure as exception:
        assert str(exception) == (
            "isort failed to parse the given literal test_code. It's important to note "
            "that isort literal sorting only supports simple literals parsable by "
            "ast.literal_eval which gave the exception of value error."
        )

# Generated at 2022-06-21 14:56:20.903585
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "non-existent plugin"
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == formatter



# Generated at 2022-06-21 14:56:23.151255
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "one = 2\ntwo = 3"
    assignments = AssignmentsFormatMismatch(code)
    assert assignments.code == code

# Generated at 2022-06-21 14:56:25.541109
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors('file_path')
    assert err.file_path == 'file_path'
    assert isinstance(err, ISortError)


# Generated at 2022-06-21 14:56:28.808990
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch(): 
    x = AssignmentsFormatMismatch("assignments")

# Generated at 2022-06-21 14:56:35.862779
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    with pytest.raises(UnsupportedSettings, match=r"isort was provided settings that it doesn't support:\n\n\t- foo = bar  \(source: 'command_line'\)\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"):
        raise UnsupportedSettings({"foo": {"value": "bar", "source": "command_line"}})

# Generated at 2022-06-21 14:56:37.077331
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert(
        type(ISortError) is ExistingSyntaxErrors('123').__class__.__bases__[0]
    )

# Generated at 2022-06-21 14:56:40.192922
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    some_error = UnsupportedSettings({"black": {"value": "here", "source": "where"}})
    assert some_error.unsupported_settings == {"black": {"value": "here", "source": "where"}}

# Generated at 2022-06-21 14:56:41.821972
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    test = ExistingSyntaxErrors("file_path")
    assert test.file_path == "file_path"