

# Generated at 2022-06-21 14:56:14.943367
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as ex:
        assert str(ex).startswith("Found import_module import while parsing, but section was not included in the `sections")
#

# Generated at 2022-06-21 14:56:17.804607
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    class_tester = ExistingSyntaxErrors('test.txt')
    assert class_tester.file_path == 'test.txt'

# Generated at 2022-06-21 14:56:28.452572
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("django")
    except ProfileDoesNotExist as exception:
        assert isinstance(exception, ISortError)

# Generated at 2022-06-21 14:56:33.346051
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    test_mismatch = LiteralSortTypeMismatch(type("a","b"), type("c","d"))
    assert test_mismatch.kind == type("a","b")
    assert test_mismatch.expected_kind == type("c","d")

# Generated at 2022-06-21 14:56:36.405305
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("C:/isort_test_tests/test.txt")
    except InvalidSettingsPath as e:
        assert e.settings_path == "C:/isort_test_tests/test.txt"


# Generated at 2022-06-21 14:56:39.448261
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.args == ('message',)
        assert e.file_path == 'file_path'

# Generated at 2022-06-21 14:56:41.783083
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    plugin_name = 'asd'
    formatter = FormattingPluginDoesNotExist(plugin_name)
    assert formatter.formatter == plugin_name


# Generated at 2022-06-21 14:56:44.247336
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist('isort')

# Generated at 2022-06-21 14:56:45.303236
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    FormattingPluginDoesNotExist("test")

# Generated at 2022-06-21 14:56:47.262383
# Unit test for constructor of class ISortError
def test_ISortError():
	e = ISortError()
	assert e.args == tuple()

# Generated at 2022-06-21 14:56:51.885871
# Unit test for constructor of class ISortError
def test_ISortError():
    x = ISortError()
    assert x.args == ()
    x = ISortError('test')
    assert x.args == ('test',)
    assert str(x) == 'test'

# Generated at 2022-06-21 14:56:57.834992
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert str(FileSkipped("test message", "test_path")) == "test message"
    assert str(FileSkipped('test', 'test_path')) == 'test'
    assert str(FileSkipped(2, 'test_path')) == '2'
    assert str(FileSkipped(None, 'test_path')) == 'None'


# Generated at 2022-06-21 14:57:00.900257
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "test"
    exception = FormattingPluginDoesNotExist(formatter)
    assert str(exception) == f"Specified formatting plugin of {formatter} does not exist. "

# Generated at 2022-06-21 14:57:02.774633
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    skip_msg = 'my test message'
    FileSkipped(message=skip_msg, file_path='tests/test.py')

# Generated at 2022-06-21 14:57:05.561359
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = 'foo'
    original_error = Exception('error')

    actual = LiteralParsingFailure(code, original_error)

    assert actual.code == code
    assert actual.original_error == original_error

# Generated at 2022-06-21 14:57:08.150574
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('test')
    except Exception as e:
        assert str(e) == 'test'


# Generated at 2022-06-21 14:57:10.834803
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('settings.py')
    except InvalidSettingsPath as e:
        assert e.settings_path == 'settings.py'


# Generated at 2022-06-21 14:57:14.256741
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist, match=r"Specified profile of test does not exist"):
        raise ProfileDoesNotExist("test")

# Generated at 2022-06-21 14:57:15.879572
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as err:
        assert str(err) == (
            f"Specified profile of test does not exist. "
            f"Available profiles: {','.join(profiles)}."
        )
        assert err.profile == "test"

# Generated at 2022-06-21 14:57:20.024700
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "{'a': 'b', 'c', 'd'}"
    original_error = "ValueError: malformed node or string: <_ast.Dict object at 0x10e2e7908> "
    assert f"isort failed to parse the given literal {code}. It's important to note " in str(LiteralParsingFailure(code, original_error))


# Generated at 2022-06-21 14:57:30.207330
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "flask"
    section_setting = "FLASK_IMPORT"
    exception_code = MissingSection(import_module, section_setting)

    assert str(exception_code.args[0]) == (
        f"Found {import_module} import while parsing, but {section_setting} was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info."
    )

# Generated at 2022-06-21 14:57:33.253953
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "ExistingSyntaxErrors"
    error = ExistingSyntaxErrors(file_path)
    assert error.file_path == file_path


# Generated at 2022-06-21 14:57:35.907614
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError()


# Generated at 2022-06-21 14:57:37.321427
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting('file_path')

# Generated at 2022-06-21 14:57:46.061984
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class test_exception(Exception):
        def __init__(self):
            pass
    test_code = "code"
    test_exception_msg = "msg"
    try:
        raise test_exception()
    except test_exception as err:
        err_msg = str(err)

    try:
        raise LiteralParsingFailure(test_code, test_exception(test_exception_msg))
    except LiteralParsingFailure as err:
        err_msg = str(err)

    assert err_msg == "isort failed to parse the given literal code. It's important to note " \
                      "that isort literal sorting only supports simple literals parsable by " \
                      f"ast.literal_eval which gave the exception of {test_exception_msg}."

# Generated at 2022-06-21 14:57:48.172858
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    comment = FileSkipComment("/tmp/test.py")
    assert comment.file_path == "/tmp/test.py"
    assert comment.message == "/tmp/test.py contains an file skip comment and was skipped."

# Generated at 2022-06-21 14:57:54.660009
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting(file_path = 'a.py')
    except FileSkipped as f:
        assert f.file_path == 'a.py'
        assert f.message == 'a.py was skipped as it\'s listed in \'skip\' setting' \
                            ' or matches a glob in \'skip_glob\' setting'


# Generated at 2022-06-21 14:57:56.090792
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist("gtest").profile == "gtest"


# Generated at 2022-06-21 14:57:57.457367
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    with pytest.raises(FileSkipSetting):
        raise FileSkipSetting('a.py')

# Generated at 2022-06-21 14:58:02.872256
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    a = FileSkipped("message","file_path")
    assert a.args[0] == "message"
    assert a.file_path == "file_path"


# Generated at 2022-06-21 14:58:08.358475
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("file_path.py")
    except FileSkipComment as e:
        assert e.file_path == "file_path.py"

# Generated at 2022-06-21 14:58:12.049000
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # given
    section = 'APP'
    import_module = 'import_module'

    # when
    msg = MissingSection(import_module, section)
    
    # then
    assert msg is not None

# Generated at 2022-06-21 14:58:15.044670
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    exception = LiteralParsingFailure('test_code', 'original_error')
    assert exception.code == 'test_code'
    assert exception.original_error == 'original_error'

# Generated at 2022-06-21 14:58:24.302983
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment('/Users/kevinyang/Desktop/isort-4.3.21-py3-none-any.whl/isort/__init__.py')
    except FileSkipComment as e:
        assert str(e) == '/Users/kevinyang/Desktop/isort-4.3.21-py3-none-any.whl/isort/__init__.py contains' \
                        ' an file skip comment and was skipped.'
        assert e.file_path == '/Users/kevinyang/Desktop/isort-4.3.21-py3-none-any.whl/isort/__init__.py'


# Generated at 2022-06-21 14:58:27.878866
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('file1.py')
    except Exception as e:
        assert e.file_path == 'file1.py'

# Generated at 2022-06-21 14:58:29.513602
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError("isort.py")


# Generated at 2022-06-21 14:58:33.844506
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    # GIVEN
    file_path = "test_file"

    # WHEN
    error = IntroducedSyntaxErrors(file_path)

    # THEN
    assert error.file_path == file_path

# Generated at 2022-06-21 14:58:40.083403
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    """Tests constructor of class ExistingSyntaxErrors"""

    exception = ExistingSyntaxErrors("some_file.py")
    assert exception.file_path == "some_file.py"
    assert str(exception) == "isort was told to sort imports within code that contains syntax errors: some_file.py."
    assert repr(exception) == "ExistingSyntaxErrors('isort was told to sort imports within code that contains syntax errors: some_file.py.')"


# Generated at 2022-06-21 14:58:42.831995
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist) as error:
        raise ProfileDoesNotExist("fake profile")

    assert "Specified profile of fake profile does not exist." in str(error.value)

# Generated at 2022-06-21 14:58:47.932987
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch("foo", "bar")
    except LiteralSortTypeMismatch as e:
        assert e.kind == "foo"
        assert e.expected_kind == "bar"

    assert str(e) == "isort was told to sort a literal of type bar but was given a literal of type foo."

# Generated at 2022-06-21 14:58:54.390276
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting('path')
    except FileSkipSetting as e:
        assert(str(e) == 'path was skipped as it\'s listed in \'skip\' setting or matches a glob in \'skip_glob\' setting')
        assert(e.file_path == 'path')


# Generated at 2022-06-21 14:59:00.444987
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("D:/Documents/Github/isort/src")
    except InvalidSettingsPath as e:
        assert e.settings_path == "D:/Documents/Github/isort/src"
        assert "settings_path" in repr(e)
    try:
        raise InvalidSettingsPath("D:/Documents/Github/isort/src")
    except InvalidSettingsPath as e:
        assert e.settings_path == "D:/Documents/Github/isort/src"
        assert "settings_path" in str(e)


# Generated at 2022-06-21 14:59:02.585703
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"


# Generated at 2022-06-21 14:59:06.865490
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = """
w = 1
x = 2
y = 3
    """
    try: AssignmentsFormatMismatch(code=code)
    except AssignmentsFormatMismatch as e:
        assert(code == e.code)
        

# Generated at 2022-06-21 14:59:07.893326
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    expected = "Unknown or unsupported encoding in test.py"
    actual = str(UnsupportedEncoding("test.py"))
    assert actual == expected

# Generated at 2022-06-21 14:59:13.349170
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist("my_profile")
    assert error.profile == "my_profile"
    assert str(error) == \
            "Specified profile of my_profile does not exist. " \
            "Available profiles: black,google,grumpy,pycharm,pep8,vertical,vim,jupyter,pyz"

# Generated at 2022-06-21 14:59:18.252774
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch) as exc_info:
        raise LiteralSortTypeMismatch(1, "1")
    assert exc_info.type is LiteralSortTypeMismatch
    assert exc_info.value.kind == int
    assert exc_info.value.expected_kind == str
    assert exc_info.value.args[0] == int
    assert exc_info.value.args[1] == str

# Generated at 2022-06-21 14:59:19.756134
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    exception = AssignmentsFormatMismatch("I love my country")
    assert exception.code == "I love my country"

# Generated at 2022-06-21 14:59:25.547049
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    from isort._errors import UnsupportedSettings
    from isort import SortImports
    import os

    filename = "test/test_errors.py"
    sort_import = SortImports(
        file_contents="import os",
        filename=filename,
        known_imports=[],
        default_sections=[],
        settings_path=os.getcwd(),
    )
    assert sort_import.config.unsupported_settings
    assert (
        UnsupportedSettings(sort_import.config.unsupported_settings).unsupported_settings
        == sort_import.config.unsupported_settings
    )

# Generated at 2022-06-21 14:59:27.385326
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    obj = FileSkipComment(file_path='test_file')
    assert obj.message == 'test_file contains an file skip comment and was skipped.'
    assert obj.file_path == 'test_file'



# Generated at 2022-06-21 14:59:37.316466
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as err:
        assert str(err) == "Specified formatting plugin of test does not exist. "
    assert err.formatter == "test"

# Generated at 2022-06-21 14:59:40.603132
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors, match="1.txt"):
        raise IntroducedSyntaxErrors("1.txt")
        # error.file_path == "1.txt"
        # error.message == "isort introduced syntax errors when attempting to sort the imports contained within 1.txt."


# Generated at 2022-06-21 14:59:45.548630
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    tcase = {"t1" : {"value" : "val1", "source" : "cli"},
             "t2" : {"value" : "val2", "source" : "config file"}}

    error = UnsupportedSettings(tcase)
    assert error.unsupported_settings == tcase
    assert "UnsupportedSettings" in str(error)
    assert "t1" in str(error)

# Generated at 2022-06-21 14:59:46.789635
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors("file_path").file_path == "file_path"

# Generated at 2022-06-21 14:59:50.425916
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("file_path")
    except FileSkipComment as e:
        assert e.file_path == 'file_path'
        assert str(e) == "'file_path' contains an file skip comment and was skipped."


# Generated at 2022-06-21 14:59:51.533544
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting('test.py')



# Generated at 2022-06-21 14:59:52.513268
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    ExistingSyntaxErrors("something")

# Generated at 2022-06-21 14:59:59.698291
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    from .settings import DEFAULT

    try:
        raise UnsupportedEncoding(filename='test_filename.py')
    except UnsupportedEncoding as e:
        assert e.filename == 'test_filename.py'
    else:
        assert False, "Did not raise UnsupportedEncoding"

    try:
        DEFAULT.read_file('test_filename.py')
    except UnsupportedEncoding as e:
        assert e.filename == 'test_filename.py'
    else:
        assert False, "Did not raise UnsupportedEncoding"

# Generated at 2022-06-21 15:00:01.722904
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('filename')
    except UnsupportedEncoding as exception:
        t = exception.filename
        assert t == 'filename'

# Generated at 2022-06-21 15:00:03.713536
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped = FileSkipped("message", "file_path")
    assert file_skipped.args[0] == "message"
    assert file_skipped.file_path