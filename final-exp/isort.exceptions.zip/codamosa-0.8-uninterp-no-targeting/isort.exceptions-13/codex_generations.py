

# Generated at 2022-06-21 14:56:12.959001
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        try:
            a = int("a")
        except ValueError:
            raise ISortError("test")
    except ISortError as e:
        assert e.args[0] == "test"

# Generated at 2022-06-21 14:56:17.805096
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    msg = "testing the function"
    file_path = "test_file.py"
    try:
        raise FileSkipSetting(file_path)
    except FileSkipSetting as err:
        assert str(err) == msg
        assert err.file_path == file_path

# Generated at 2022-06-21 14:56:21.045354
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # FileSkipComment(file_path: str)
    o = FileSkipComment("/fakefile")
    assert o.file_path == "/fakefile"

# Generated at 2022-06-21 14:56:25.032510
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    from unittest import mock
    from isort.exceptions import UnsupportedSettings

    with mock.patch("isort.exceptions.UnsupportedSettings.__init__") as constructor_mock:
        instance = UnsupportedSettings({})

    assert constructor_mock.call_count == 1
    assert constructor_mock.call_args[0][0] == {}

# Generated at 2022-06-21 14:56:29.382806
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("abc", "abc")
    except MissingSection as error:
        assert error.import_module == "abc"
        assert error.section == "abc"

# Generated at 2022-06-21 14:56:35.003220
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    exc = UnsupportedSettings({"test": {"source": "test", "value": "test"}})
    assert not hasattr(exc, "test")
    assert not hasattr(exc, "source")
    assert not hasattr(exc, "value")
    assert exc.unsupported_settings == {"test": {"source": "test", "value": "test"}}

# Generated at 2022-06-21 14:56:37.541828
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code="a = 1\nb = 2"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch:
        print("AssignmentsFormatMismatch: test passed")

# Generated at 2022-06-21 14:56:44.339494
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Arrange
    filePath = "path/to/file"
    expectedMessage = f"isort was told to sort imports within code that contains syntax errors: {filePath}."

    # Act
    actualException = ExistingSyntaxErrors(filePath)

    # Assert
    assert actualException.message == expectedMessage
    assert actualException.filepath == filePath


# Generated at 2022-06-21 14:56:47.504478
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist:
        assert True
    else:
        assert False


# Generated at 2022-06-21 14:56:52.226800
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """Test the constructor of the class LiteralParsingFailure by raising an Exception
    and passing it to the class.
    """
    try:
        raise AssertionError
    except AssertionError as e:
        raise LiteralParsingFailure("Hello World", e)
