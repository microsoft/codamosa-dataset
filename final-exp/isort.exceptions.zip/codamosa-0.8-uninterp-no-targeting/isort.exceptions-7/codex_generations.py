

# Generated at 2022-06-21 14:56:12.715774
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("Folder_Name")
    except InvalidSettingsPath as error:
        assert (error.settings_path) == "Folder_Name"


# Generated at 2022-06-21 14:56:19.543103
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        x = a
    except NameError as e:
        e = e
    lpf = LiteralParsingFailure(code='a', original_error=e)
    assert lpf.code == 'a'
    assert lpf.original_error == e
    assert type(lpf) == LiteralParsingFailure
    return test_LiteralParsingFailure

# Generated at 2022-06-21 14:56:21.227972
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    f = FormattingPluginDoesNotExist("")
    assert f.formatter == ""

# Generated at 2022-06-21 14:56:23.309401
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        test_profileDoesNotExist = ProfileDoesNotExist('testprofile')

# Generated at 2022-06-21 14:56:26.751379
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """Unit test for constructor of class UnsupportedEncoding"""
    try:
        raise UnsupportedEncoding("test")
    except UnsupportedEncoding as e:
        assert e.filename == "test"
    else:
        fail("UnsupportedEncoding exception not raised")

# Generated at 2022-06-21 14:56:30.942602
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    error = UnsupportedSettings({"unsupported_setting": {"value": "whatever", "source": "none"}})
    assert error.unsupported_settings == {"unsupported_setting": {"value": "whatever", "source": "none"}}

# Generated at 2022-06-21 14:56:34.169306
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist(profile="abc")
    except ProfileDoesNotExist as e:
        assert(e.profile == "abc")

# Generated at 2022-06-21 14:56:37.531420
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # Given
    code = """
a = b
b = c
c = a
"""

    # When
    exception = AssignmentsFormatMismatch(code)

    # Then
    assert exception.code == code

# Generated at 2022-06-21 14:56:39.326008
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        FileSkipSetting("test")
    except ISortError as e:
        print(e.file_path)

# Generated at 2022-06-21 14:56:41.082294
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    obj=InvalidSettingsPath("C:/Users/Dhananjay/Desktop/isort/isort")
    assert obj