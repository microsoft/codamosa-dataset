

# Generated at 2022-06-21 14:56:16.493757
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    from pytest import raises
    from . import ISortError
    from . import LiteralSortTypeMismatch
    class a:
        def __init__(self):
            x = 1
    class b:
        def __init__(self):
            x = 1
    with raises(ISortError) as err:
        raise LiteralSortTypeMismatch(type(a), type(b))

# Generated at 2022-06-21 14:56:18.542799
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("test_file").file_path == "test_file"


# Generated at 2022-06-21 14:56:22.763158
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
	try:
		raise InvalidSettingsPath("/home/ajay/isort/.isort.cfg")
	except InvalidSettingsPath as error:
		print(error)
		print(error.args)
		print(error.settings_path)


# Generated at 2022-06-21 14:56:24.045665
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped('message', 'file_path')

# Generated at 2022-06-21 14:56:31.528211
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch('x=1')
    except AssignmentsFormatMismatch as exception:
        code = str(exception)
        code_lines = code.splitlines()
        assert code_lines[0] == 'isort was told to sort a section of assignments, however the given code:'
        assert code_lines[1] == 'x=1'
        assert code_lines[2] == 'Does not match isort\'s strict single line formatting requirement for assignment sorting:'
        assert code_lines[3] == '{variable_name} = {value}'

# Generated at 2022-06-21 14:56:36.691122
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test/file.txt"
    error = FileSkipSetting(file_path)
    assert error.message == (f"{file_path} was skipped as it's listed in 'skip' setting "
                             "or matches a glob in 'skip_glob' setting")
    assert error.file_path == file_path

# Generated at 2022-06-21 14:56:39.017779
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    err = UnsupportedEncoding("/file/name/here")
    assert str(err) == 'Unknown or unsupported encoding in /file/name/here'

# Generated at 2022-06-21 14:56:41.781819
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    test = LiteralParsingFailure('output', Exception('error'))
    assert test.code == 'output'
    assert test.original_error.args == ('error',)


# Generated at 2022-06-21 14:56:45.433288
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    obj = FileSkipped("file Skipped message.", "filename")
    assert obj.__class__ == FileSkipped


# Generated at 2022-06-21 14:56:48.386999
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test item")
        assert False  # in the event that a unit test fails, the rest of the tests will not run
    except ExistingSyntaxErrors as exception:
        assert str(exception) == "isort was told to sort imports within code that contains syntax errors: test item."
        assert exception.file_path == "test item"


# Generated at 2022-06-21 14:56:55.875748
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # Arrange
    code = "a = 1\nb = 2\n"
    # Act
    e = AssignmentsFormatMismatch(code)
    # Assert
    assert e.code == code

# Generated at 2022-06-21 14:56:57.399639
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors('some_file').file_path == 'some_file'

# Generated at 2022-06-21 14:57:00.132635
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception = IntroducedSyntaxErrors("SystemReport.py")
    assert exception.__str__() == "isort introduced syntax errors when attempting to sort the imports contained within SystemReport.py."

# Generated at 2022-06-21 14:57:02.268836
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert LiteralParsingFailure("test", SyntaxError).__str__() == "test"
    assert LiteralParsingFailure("test", SyntaxError).original_error.__str__() == "test"


# Generated at 2022-06-21 14:57:03.122942
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError


# Generated at 2022-06-21 14:57:05.467087
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("this is an unit test")
    except ProfileDoesNotExist as e:
        assert e.profile == "this is an unit test"


# Generated at 2022-06-21 14:57:09.427338
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fss = FileSkipSetting("testing.py")
    assert fss.file_path == "testing.py"
    assert fss.message == "testing.py was skipped as it's listed in 'skip' setting " \
                          "or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-21 14:57:14.303993
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    test_message = "testing"
    test_file_path = "file_path"
    returned_value = FileSkipped(test_message, test_file_path)
    assert returned_value.message == test_message
    assert returned_value.file_path == test_file_path

# Generated at 2022-06-21 14:57:21.226764
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    class ExistingSyntaxErrors(ISortError):
        """Raised when isort is told to sort imports within code that has existing syntax errors"""

        def __init__(self, file_path: str):
            super().__init__(
                f"isort was told to sort imports within code that contains syntax errors: "
                f"{file_path}."
            )
            self.file_path = file_path

    try:
        raise ExistingSyntaxErrors(file_path=r"C:\Users\User\AppData\Local\Programs\Python\Python37\Lib\site-packages\isort")
    except ExistingSyntaxErrors as e:
        print(e.msg)
        print(e.file_path)


# Generated at 2022-06-21 14:57:29.201237
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch('a = 1\nb = 2')
    except ISortError as e:
        assert e.__class__.__name__ == 'AssignmentsFormatMismatch'
        assert e.__doc__ == "Raised when isort is told to sort assignments but the format of the assignment section\ndoesn't match isort's expectation.\n"
        assert isinstance(e, ISortError)
    else:
        assert False

# Generated at 2022-06-21 14:57:43.159201
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Test the constructor of class UnsupportedSettings"""

# Generated at 2022-06-21 14:57:46.099407
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # Arrange
    settings_path = '~/settings_path_test.cfg'
    # Act
    invalid_settings_path = InvalidSettingsPath(settings_path)
    # Assert
    assert invalid_settings_path.settings_path == settings_path


# Generated at 2022-06-21 14:57:48.680885
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("message", "/tmp/file").file_path == "/tmp/file"

# Generated at 2022-06-21 14:57:51.989135
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    """Test for constructor of class ExistingSyntaxErrors"""
    error = ExistingSyntaxErrors(file_path = 'test.py')
    assert error.file_path == 'test.py'


# Generated at 2022-06-21 14:57:55.124866
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    error = InvalidSettingsPath('/a/b/c')
    assert error.settings_path == '/a/b/c'


# Generated at 2022-06-21 14:57:57.384763
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fs = FileSkipped('Test Message', 'file/path')
    assert fs.args == ('Test Message',)
    assert fs.file_path == 'file/path'

# Generated at 2022-06-21 14:58:03.189953
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("somefile.py")
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within somefile.py."


# Generated at 2022-06-21 14:58:06.269810
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "file.py"
    message = f"Unknown or unsupported encoding in {filename}"
    exc_obj = UnsupportedEncoding(filename)
    assert str(exc_obj) == message
    assert exc_obj.filename == filename

# Generated at 2022-06-21 14:58:11.140783
# Unit test for constructor of class MissingSection
def test_MissingSection():
    msg = MissingSection("import_module", "section").message
    assert msg == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-21 14:58:15.085615
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment('/tmp/test')
    except FileSkipComment as e:
        assert e.file_path == '/tmp/test'
        assert e.message == '/tmp/test contains an file skip comment and was skipped.'


# Generated at 2022-06-21 14:58:26.250937
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    x = MissingSection(import_module, section)
    assert x.import_module == import_module
    assert x.section == section

# Generated at 2022-06-21 14:58:27.832278
# Unit test for constructor of class ISortError
def test_ISortError():
    foo = ISortError()
    print(foo)


# Generated at 2022-06-21 14:58:30.108855
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError as e:
        pass


# Generated at 2022-06-21 14:58:34.027095
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('g')
    except FormattingPluginDoesNotExist as e:
        assert str(e) == 'Specified formatting plugin of g does not exist. '

# Generated at 2022-06-21 14:58:36.360679
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    f = FormattingPluginDoesNotExist('formatter')
    assert f.formatter == 'formatter'


# Generated at 2022-06-21 14:58:38.164552
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "test"
    file_path = "test"
    FileSkipped(message, file_path)

# Generated at 2022-06-21 14:58:41.588611
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    # Some random formatter
    formatter = "ams"
    error = FormattingPluginDoesNotExist(formatter)
    assert error.formatter == formatter
    assert str(error).startswith("Specified formatting plugin of ") and error.formatter in str(error)


# Generated at 2022-06-21 14:58:46.757769
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    def _test_InvalidSettingsPath(settings_path: str) -> bool:
        try:
            raise InvalidSettingsPath(settings_path)
        except InvalidSettingsPath as e:
            return settings_path == e.settings_path
        except Exception:
            return False
        return True

    assert _test_InvalidSettingsPath("test.toml")



# Generated at 2022-06-21 14:58:49.426830
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    print (AssignmentsFormatMismatch.__doc__)
    print (AssignmentsFormatMismatch.__init__.__doc__)


# Generated at 2022-06-21 14:58:52.883162
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    my_file = FileSkipped("This is a test", "test file")
    assert my_file.file_path == "test file"
    assert my_file.message == "This is a test"


# Generated at 2022-06-21 14:59:09.011263
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("not exits")
    except ProfileDoesNotExist as e:
        assert e.profile == "not exits"

# Generated at 2022-06-21 14:59:14.529060
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    """Raised when isort is told to sort imports within code that has existing syntax errors"""
    test = "Raised when isort is told to sort imports within code that has existing syntax errors"
    try:
        raise ExistingSyntaxErrors(test)
    except ExistingSyntaxErrors: 
        print("\n test_ExistingSyntaxErrors test passed")


# Generated at 2022-06-21 14:59:17.103437
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("")
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within ."

# Generated at 2022-06-21 14:59:17.978128
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting("file_name.py")

# Generated at 2022-06-21 14:59:21.324278
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = 'profile'
    exception = ProfileDoesNotExist(profile)
    assert exception.profile == profile
    assert str(exception) == f"Specified profile of {profile} does not exist. " \
                             f"Available profiles: {','.join(profiles)}."


# Generated at 2022-06-21 14:59:23.709276
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding("my file.py")
    assert error.filename == "my file.py"
    assert error.__str__() == "Unknown or unsupported encoding in my file.py"

# Generated at 2022-06-21 14:59:25.749060
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    msg = "message"
    file_path = "file_path"
    ex = FileSkipped(msg, file_path)
    assert ex.message == msg
    assert ex.file_path == file_path

# Generated at 2022-06-21 14:59:28.624274
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {"name": "value", "name2": "value2"}
    unsupported_settings = UnsupportedSettings(settings)
    assert unsupported_settings.unsupported_settings == settings

# Generated at 2022-06-21 14:59:30.388430
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    e = IntroducedSyntaxErrors(file_path="abc")
    assert e.file_path == "abc"

# Generated at 2022-06-21 14:59:32.267253
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("Test Exception")
    except Exception as e:
        assert str(e) == "Test Exception"


# Generated at 2022-06-21 15:00:02.190167
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    exception = LiteralParsingFailure("code", Exception("syntax error"))
    assert exception.code == "code"
    assert exception.original_error.args[0] == "syntax error"

# Generated at 2022-06-21 15:00:03.763512
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    set = InvalidSettingsPath('test')
    assert set.settings_path == 'test'


# Generated at 2022-06-21 15:00:04.915442
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    LiteralSortTypeMismatch(kind = dict, expected_kind = int)

# Generated at 2022-06-21 15:00:09.672249
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    class_names = [
        FileSkipComment("/foo/bar"), FileSkipSetting("/baz/qux"),
    ]
    for class_name in class_names:
        assert(isinstance(class_name.message, str))
        assert(isinstance(class_name.file_path, str))


# Generated at 2022-06-21 15:00:10.784371
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment('test')

# Generated at 2022-06-21 15:00:13.789080
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    path = "/a/b/c"
    isort_error = ExistingSyntaxErrors(file_path=path)
    assert isort_error.file_path == path



# Generated at 2022-06-21 15:00:20.442040
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    message = "isort failed to parse the given literal a. It's important to note "
    message += "that isort literal sorting only supports simple literals parsable by "
    message += "ast.literal_eval which gave the exception of a."
    try:
        raise LiteralParsingFailure("a", "a")
    except LiteralParsingFailure as e:
        assert str(e) == message
        assert e.code == "a"
        assert e.original_error == "a"


# Generated at 2022-06-21 15:00:22.280423
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist("abc")

# Testing for the constructor of FileSkipSetting

# Generated at 2022-06-21 15:00:25.253015
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    test_file_path = "FileSkipComment.py"
    test_message = "test_message"
    FileSkipped(test_message, test_file_path)
    FileSkipComment(test_file_path)
    FileSkipSetting(test_file_path)

# Generated at 2022-06-21 15:00:30.830471
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "./test_dir/test.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write("# -*- coding: utf-8 -*-\n")
    a = UnsupportedEncoding(filename)
    assert "Unknown or unsupported encoding in ./test_dir/test.txt" in a.__str__()
    assert a.filename == "./test_dir/test.txt"
    with open(filename, "r", encoding="utf-8") as f:
        text = f.read()
        f.close()
    assert text == "# -*- coding: utf-8 -*-\n"

# Generated at 2022-06-21 15:01:29.464853
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "x = 1"
    assert AssignmentsFormatMismatch(code).code == code

# Generated at 2022-06-21 15:01:34.371887
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as error:
        assert error.message == "message"
        assert error.file_path == "file_path"


# Generated at 2022-06-21 15:01:35.247869
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment("isort.py")

# Generated at 2022-06-21 15:01:39.861715
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    expected_error = ValueError("Expected error")
    try:
        raise LiteralParsingFailure(
            code="some code",
            original_error=expected_error
        )
    except LiteralParsingFailure as e:
        assert str(e).startswith("isort failed to parse the given literal some code")
        assert e.original_error is expected_error



# Generated at 2022-06-21 15:01:42.308721
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    """Test class IntroducedSyntaxErrors"""
    with pytest.raises(
        IntroducedSyntaxErrors,
        match="isort introduced syntax errors when attempting to sort the imports contained within",
    ):
        raise IntroducedSyntaxErrors("/home/hello")

# Generated at 2022-06-21 15:01:44.140963
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('foo')
    except ProfileDoesNotExist as e:
        exception_string = str(e)
        assert 'foo' in exception_string
        assert 'Available profiles: ' in exception_string

# Generated at 2022-06-21 15:01:46.767767
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test.py")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test.py"

# Generated at 2022-06-21 15:01:49.512275
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    comment_FileSkipComment = FileSkipComment(file_path="test.py")
    assert comment_FileSkipComment.file_path == "test.py"

# Generated at 2022-06-21 15:01:51.373826
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    file_name = "foo.txt"
    error_msg = f"Unknown or unsupported encoding in {file_name}"
    assert error_msg == repr(UnsupportedEncoding(file_name))

# Generated at 2022-06-21 15:01:56.873936
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('tests/test_introduced_syntax.py')
    except ISortError as exc:
        assert str(exc) == ('isort introduced syntax errors when attempting to sort the '
                            'imports contained within tests/test_introduced_syntax.py.')
        assert exc.file_path == 'tests/test_introduced_syntax.py'

# Generated at 2022-06-21 15:03:51.826917
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert isinstance(
        UnsupportedSettings({"test": {"value": "test", "source": "test"}}),
        UnsupportedSettings,
    )

# Generated at 2022-06-21 15:03:53.333504
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    x = AssignmentsFormatMismatch(code="a=1")
    assert x.code == "a=1"

# Generated at 2022-06-21 15:03:55.015150
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test_file")
    except IntroducedSyntaxErrors as error:
        assert error.file_path == "test_file"

# Generated at 2022-06-21 15:03:59.759452
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "./test"
    output = FileSkipSetting(file_path)
    assert type(output) == FileSkipSetting
    assert str(output) == ("isort was told to sort imports within code that contains "
                           + "syntax errors: ./test.")
    assert output.file_path == file_path

# Generated at 2022-06-21 15:04:07.561845
# Unit test for constructor of class MissingSection
def test_MissingSection():
    from .imports import Import
    from .parse import module_key
    import_ = Import("mylib", "mylib")
    section: str = module_key(import_)
    exception = MissingSection(import_, section)
    assert exception.import_module == 'mylib'
    assert exception.section == 'mylib'
    assert str(exception) == "Found mylib import while parsing, but mylib was not included " \
                             "in the `sections` setting of your config. Please add it before continuing\n" \
                             "See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-21 15:04:13.716055
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(
            """
        a = 1
        b = 2
        c = 3
        d = "abc"
        e = "def"
        """
        )
    except AssignmentsFormatMismatch as e:
        assert e.code == """
        a = 1
        b = 2
        c = 3
        d = "abc"
        e = "def"
        """
    else:
        assert False, "Did not raise"



# Generated at 2022-06-21 15:04:17.516989
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    test_filename = "tests/python_files/unsupported_encoding.py"
    try:
        with open(test_filename, "r") as file_ob:
            file_ob.read()
    except UnicodeDecodeError as e:
        assert isinstance(e, UnsupportedEncoding)

# Generated at 2022-06-21 15:04:26.279256
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {'spaces_before_comment': {'value': 2, 'source': 'filename'}}
    unsupported = UnsupportedSettings(settings)
    assert unsupported.unsupported_settings == settings
    assert unsupported.__str__() == ("isort was provided settings that it doesn't "
                                     "support:\n\n\t- spaces_before_comment = 2  "
                                     "(source: 'filename')\n\n"
                                     "For a complete and up-to-date listing of "
                                     "supported settings see: https://pycqa.github.io/isort/docs/"
                                     "configuration/options/.\n")


# Generated at 2022-06-21 15:04:28.942641
# Unit test for constructor of class MissingSection
def test_MissingSection():
    m = MissingSection("haha", "bye")
    assert m.import_module == "haha"
    assert m.section == "bye"

# Generated at 2022-06-21 15:04:32.225501
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Strictly, "foo", "bar" and "split" are not profiles in code, but play their roles and it should be OK
    for profile in ["foo", "bar", "split"]:
        try:
            raise ProfileDoesNotExist(profile)
        except ProfileDoesNotExist as e:
            assert profile == e.profile