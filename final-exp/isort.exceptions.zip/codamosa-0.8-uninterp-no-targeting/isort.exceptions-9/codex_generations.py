

# Generated at 2022-06-21 14:56:11.723149
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"
        assert str(e) == "Specified formatting plugin of test does not exist. "
    else:
        assert False


# Generated at 2022-06-21 14:56:14.781792
# Unit test for constructor of class ISortError
def test_ISortError():
    msg = "This is a test"
    with pytest.raises(ISortError, match=msg):
        raise ISortError(msg)


# Generated at 2022-06-21 14:56:19.789599
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """Unit test for constructor of class UnsupportedEncoding"""
    filename = "example_file.py"
    utest_ob = UnsupportedEncoding(filename)
    assert str(utest_ob) == f"Unknown or unsupported encoding in {filename}"
    assert utest_ob.filename == filename

# Generated at 2022-06-21 14:56:22.419885
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    exception = FormattingPluginDoesNotExist('fake_formatter')
    assert str(exception) == 'Specified formatting plugin of fake_formatter does not exist. '
    assert exception.formatter == 'fake_formatter'

# Generated at 2022-06-21 14:56:25.895146
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    from .formatting_plugin_does_not_exist import FormattingPluginDoesNotExist
    exception = FormattingPluginDoesNotExist("TestPlugin")
    assert exception.formatter == "TestPlugin"
    assert str(exception) == "Specified formatting plugin of TestPlugin does not exist. "

# Generated at 2022-06-21 14:56:29.561660
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "You"
    call_msg = f"Specified formatting plugin of {formatter} does not exist. "
    assert FormattingPluginDoesNotExist(formatter).__str__() == call_msg

# Generated at 2022-06-21 14:56:30.992391
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("file_path").file_path == "file_path"

# Generated at 2022-06-21 14:56:33.346016
# Unit test for constructor of class ISortError
def test_ISortError():
    assert str(ISortError("testing")) == "testing"



# Generated at 2022-06-21 14:56:36.077100
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        x = LiteralSortTypeMismatch(int, str)
    except Exception as err:
        assert "isort was told to sort a literal of type <class 'str'> but was given" in str(err)

# Generated at 2022-06-21 14:56:43.659521
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # Test not passing source
    unsupported_settings = {"custom_setting": {"value": "something unknown"}}

    exception = UnsupportedSettings(unsupported_settings)
    expected_message = ("isort was provided settings that it doesn't support:\n\n"
                        "\t- custom_setting = something unknown  (source: '')\n\n"
                        "For a complete and up-to-date listing of supported settings see: "
                        "https://pycqa.github.io/isort/docs/configuration/options/.\n")

    assert exception.unsupported_settings == unsupported_settings
    assert str(exception) == expected_message

    # Test passing source
    unsupported_settings = {"custom_setting": {"value": "something unknown", "source": "myconfig.cfg"}}

    exception = UnsupportedSettings(unsupported_settings)


# Generated at 2022-06-21 14:56:48.338764
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch, match="dict"):
        raise LiteralSortTypeMismatch(int, dict)

# Generated at 2022-06-21 14:56:50.868141
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    test_filename = 'filename'
    error = UnsupportedEncoding(test_filename)

    assert error.filename == test_filename

# Generated at 2022-06-21 14:56:53.454856
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist) as excinfo:
        raise ProfileDoesNotExist("pep8")
    assert excinfo.value.profile == "pep8"

# Generated at 2022-06-21 14:56:58.139676
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("value", ValueError("Literal Error"))
    except LiteralParsingFailure as e:
        assert e.code == "value"
        assert e.original_error.args == ("Literal Error",)


# Generated at 2022-06-21 14:57:02.212292
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Exercise
    literalSortTypeMismatch = LiteralSortTypeMismatch(int, float)

    # Verify
    assert literalSortTypeMismatch.kind == int
    assert literalSortTypeMismatch.expected_kind == float
    assert LiteralSortTypeMismatch.__base__ == ISortError

# Generated at 2022-06-21 14:57:06.786796
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section = MissingSection('my_import', 'unused_imports')
    assert missing_section is not None
    assert str(missing_section) == \
            "Found my_import import while parsing, but unused_imports was not included " \
            "in the `sections` setting of your config. Please add it before continuing\n" \
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-21 14:57:10.790424
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("test", Exception("this is error"))
    except LiteralParsingFailure as e:
        assert e.code == "test"
        assert e.original_error.args[0] == "this is error"


# Generated at 2022-06-21 14:57:13.546044
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    a = FileSkipSetting("file_path")
    print("Message: " + a.message)

# Generated at 2022-06-21 14:57:18.926233
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    from io import StringIO
    from string import ascii_uppercase
    from isort import UnsupportedSettings, isort
    config = StringIO()
    config.write("\n".join([f"{x}=1" for x in ascii_uppercase]))
    config.seek(0)
    isort_settings = isort.Config(file_contents=config.read())
    assert isort_settings.check_config() == UnsupportedSettings

# Generated at 2022-06-21 14:57:28.526876
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Expected
    expected_message = "some_file.py was skipped as it's listed in 'skip' setting" +\
                       " or matches a glob in 'skip_glob' setting"
    expected_file_path = "some_file.py"
    
    # Code under test
    instance = FileSkipSetting(file_path=expected_file_path)
    
    # Assert
    assert expected_message == instance.__str__() 
    assert expected_message == instance.args[0] 
    assert expected_file_path == instance.file_path
    

# Generated at 2022-06-21 14:57:37.135906
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = "file_path"
    with pytest.raises(FileSkipComment) as exc_info:
        raise FileSkipComment(file_path=path)
    assert exc_info.value.file_path == path



# Generated at 2022-06-21 14:57:41.321464
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("profile")
    except ProfileDoesNotExist as exc:
        assert exc.args[0] == \
        "Specified profile of profile does not exist. " \
        "Available profiles: " + ", ".join(profiles) + "."
        assert exc.profile == "profile"

# Generated at 2022-06-21 14:57:44.879230
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error = LiteralParsingFailure("test", NameError("test", "test"))
    assert str(error) == "isort failed to parse the given literal test. It's important to note " \
                         "that isort literal sorting only supports simple literals parsable by " \
                         "ast.literal_eval which gave the exception of name 'test' is not defined"

# Generated at 2022-06-21 14:57:45.653840
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    pass


# Generated at 2022-06-21 14:57:48.832742
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fs = FileSkipped("message", "file_path")
    fs.message
    fs.file_path

# Unit tests for class FileSkipComment

# Generated at 2022-06-21 14:57:56.294779
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # test type mismatch
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str

    # test value mismatch
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as e:
        assert e.kind == str
        assert e.expected_kind == int

# Generated at 2022-06-21 14:57:57.668109
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("file_1.py").file_path == "file_1.py"


# Generated at 2022-06-21 14:58:02.917702
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors(file_path="new_file.txt")
    assert error.__str__() == f"isort was told to sort imports within code that contains syntax errors: new_file.txt."

# Generated at 2022-06-21 14:58:05.611774
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'testfile'
    try:
        raise FileSkipSetting(file_path=file_path)
    except FileSkipSetting as error:
        assert error.file_path == file_path


# Generated at 2022-06-21 14:58:06.718179
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError

test_ISortError()


# Generated at 2022-06-21 14:58:14.008012
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting('filename')
    except FileSkipSetting as exception:
        assert str(exception) == "filename was skipped as it's listed in 'skip' setting" \
                                 " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-21 14:58:18.640508
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error_message = "Raised when isort is told to sort imports within code that has existing syntax errors"
    file_path = "D:\\GithubRepository\\isort\\README.md"
    obj = ExistingSyntaxErrors(file_path)

    assert obj.__repr__() == f"{error_message} {file_path}"


# Generated at 2022-06-21 14:58:27.079629
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    literalParsingFailure = LiteralParsingFailure("code", "original_error")
    assert literalParsingFailure.code == "code"
    assert literalParsingFailure.original_error == "original_error"
    assert literalParsingFailure.__str__() == (
        "isort failed to parse the given literal code. It's important to note "
        "that isort literal sorting only supports simple literals parsable by "
        "ast.literal_eval which gave the exception of original_error."
    )


# Generated at 2022-06-21 14:58:29.417274
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    exception = InvalidSettingsPath('foo')
    assert exception.settings_path == 'foo'


# Generated at 2022-06-21 14:58:33.402411
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    ex = LiteralParsingFailure("", Exception(""))
    assert ex.code == ""
    assert str(ex.original_error) == ""
    assert str(ex) == ""

# Generated at 2022-06-21 14:58:34.669904
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert hasattr(FormattingPluginDoesNotExist, 'formatter')


# Generated at 2022-06-21 14:58:37.274076
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "test_path"
    error = IntroducedSyntaxErrors(file_path)
    assert error.file_path == file_path



# Generated at 2022-06-21 14:58:39.970615
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'testFormatter'
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except Exception as e:
        assert str(e) == 'Specified formatting plugin of testFormatter does not exist. '
        assert e.formatter == formatter


# Generated at 2022-06-21 14:58:42.294133
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind = type(None), expected_kind = type({}))
    except LiteralSortTypeMismatch:
        pass

# Generated at 2022-06-21 14:58:45.447074
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    plugin = FormattingPluginDoesNotExist('black')
    assert str(plugin) == 'Specified formatting plugin of black does not exist. '
    assert plugin.formatter == 'black'


# Generated at 2022-06-21 14:59:00.008415
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    err = InvalidSettingsPath("/no/such/file.py")
    assert str(err) == "isort was told to use the settings_path: /no/such/file.py as the base " \
        "directory or file that represents the starting point of config file discovery, but it " \
        "does not exist."

    # Verify that the message field is deprecated
    assert err.message == ("isort was told to use the settings_path: /no/such/file.py "
                           "as the base directory or file that represents the starting point "
                           "of config file discovery, but it does not exist.")
    assert err.settings_path == "/no/such/file.py"

# Generated at 2022-06-21 14:59:02.406025
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("message", "filepath").message == "message"
    assert FileSkipped("message", "filepath").file_path == "filepath"



# Generated at 2022-06-21 14:59:08.060412
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('test')
    except ProfileDoesNotExist as e:
        assert e.profile == 'test'
        assert e.__str__() == "ISortError: Specified profile of test does not exist. Available " \
                              "profiles: black,flake8,google,pep8,pycharm,vscode,vscode_noconflict."

# Generated at 2022-06-21 14:59:12.815515
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "foo"
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as e:
        assert formatter == e.formatter
        assert str(e) == "Specified formatting plugin of foo does not exist. "


# Generated at 2022-06-21 14:59:18.739895
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    import pytest
    # Mock the file_path
    file_path = "/path/to/file.py"
    # Create an object of FileSkipComment
    obj_FileSkipComment = FileSkipComment(file_path)
    # Check type of the object
    assert type(obj_FileSkipComment) == FileSkipComment
    # Check the text of the exception caught
    with pytest.raises(FileSkipComment) as excinfo:
        raise FileSkipComment(file_path)
    assert excinfo.value.file_path == file_path

# Generated at 2022-06-21 14:59:21.137426
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist('abc').__str__() == 'Specified formatting plugin of abc does not exist.'
    assert FormattingPluginDoesNotExist('abc').formatter == 'abc'

# Generated at 2022-06-21 14:59:22.868752
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('abc')
    except ISortError as e:
        print(e)
        pass

# Generated at 2022-06-21 14:59:23.689367
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist("someformatter")

# Generated at 2022-06-21 14:59:24.203978
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    pass

# Generated at 2022-06-21 14:59:25.814443
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    f = FileSkipComment("skipped_file")
    assert f.message == "skipped_file contains an file skip comment and was skipped."


# Generated at 2022-06-21 14:59:42.171742
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    error = FormattingPluginDoesNotExist('abc')
    assert str(error) == 'Specified formatting plugin of abc does not exist. '



# Generated at 2022-06-21 14:59:45.624326
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("Testing the constructor of ISortError")
    except ISortError as e:
        assert str(e) == "Testing the constructor of ISortError"
    except:
        assert False



# Generated at 2022-06-21 14:59:50.228292
# Unit test for constructor of class FileSkipped
def test_FileSkipped():

    test_message = "test message"
    test_file_path = "test/test_file_path.py"

    test_file_skipped_object = FileSkipped(test_message, test_file_path)

    assert test_file_skipped_object.message is test_message
    assert test_file_skipped_object.file_path is test_file_path

# Generated at 2022-06-21 14:59:54.406584
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert str(InvalidSettingsPath('/a/path')) == "isort was told to use the settings_path: /a/path as the base directory or file that represents the starting point of config file discovery, but it does not exist."


# Generated at 2022-06-21 15:00:03.378450
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    from isort import UnsupportedSettings
    from tests import callback_factory
    from unittest import mock  # type: ignore
    from unittest.mock import MagicMock

    # Mock Settings class and get instance
    mock_settings = MagicMock()
    mock_settings.values = MagicMock(return_value={"section_a": {"option": "value"}})
    mock_settings.__contains__ = MagicMock(return_value=True)
    mock_settings.get_source_of = MagicMock(return_value="src")
    mock_settings.__iter__ = MagicMock()
    mock_settings.__iter__.return_value = iter([("section_a", "option")])
    mock_settings.__getitem__ = MagicMock()

# Generated at 2022-06-21 15:00:07.062294
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    err = LiteralParsingFailure('my code', Exception('Fake exception'))
    assert err.code == 'my code'
    assert err.original_error.args[0] == 'Fake exception'
    assert str(err) == err.__str__()

# Generated at 2022-06-21 15:00:10.493966
# Unit test for constructor of class FileSkipComment

# Generated at 2022-06-21 15:00:18.892355
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "x = 1\ny = 2\n"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert str(e) == "isort was told to sort a section of assignments, however the given code:\n\nx = 1\ny = 2\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"
        assert e.code == "x = 1\ny = 2\n"



# Generated at 2022-06-21 15:00:21.838594
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    import pytest
    with pytest.raises(ProfileDoesNotExist) as excinfo:
        raise ProfileDoesNotExist("fake_profile")
    assert excinfo.value.profile == "fake_profile"


# Generated at 2022-06-21 15:00:23.089365
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment(file_path="test").message == "test contains an file skip comment and was skipped."
    assert FileSkipComment(file_path="test").file_path == "test"

# Generated at 2022-06-21 15:00:56.814345
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch("no", 2)
    except LiteralSortTypeMismatch as e:
        print("test passed")
        print("kind:")
        print(e.kind)
        print("expected_kind:")
        print(e.expected_kind)

if __name__ == "__main__":
    test_LiteralSortTypeMismatch()

# Generated at 2022-06-21 15:01:00.157040
# Unit test for constructor of class MissingSection
def test_MissingSection():
    #Arrange
    import_module = "import module"
    section = "section"

    # Act
    with pytest.raises(MissingSection):
        MissingSection(import_module, section)


# Generated at 2022-06-21 15:01:01.129389
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    LiteralParsingFailure("code", Exception())

# Generated at 2022-06-21 15:01:04.447925
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    t = LiteralSortTypeMismatch(list, tuple)
    assert t.__str__()=="isort was told to sort a literal of type <class 'tuple'> but was given a literal of type <class 'list'>.\n"

# Generated at 2022-06-21 15:01:13.350091
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    profile = "default"
    # case 1: filename.py skipped
    file_path = "filename.py"
    target_error = FileSkipSetting(file_path)
    assert target_error.file_path == file_path
    assert target_error.__str__() == f"{file_path} was skipped as it's listed in 'skip' setting" +\
           " or matches a glob in 'skip_glob' setting"
    # case 2: .cache/index.py skipped
    file_path = ".cache/index.py"
    target_error = FileSkipSetting(file_path)
    assert target_error.file_path == file_path

# Generated at 2022-06-21 15:01:14.466262
# Unit test for constructor of class ISortError
def test_ISortError():
    x = ISortError('test')
    assert x.message == 'test'

# Generated at 2022-06-21 15:01:24.653639
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("black")
    except ProfileDoesNotExist as e:
        assert e.profile == "black"
        assert e.args[0] == "Specified profile of black does not exist. Available profiles: py27,py33,py34,py35,py36,py37,py38,py39,google,pep8,facebook,discover,numpy,importmagic,chromium,django,mccabe,typing,pycharm,pydocstyle,wemake,twine,pytest,flake8,nox,pyupgrade,yapf,bandit,junit-xml,wakatime,vscode,mypy,tests,pycodestyle,pylint,pyproject,trivia,nox-py37,nox-py38,nox-py39."

# Generated at 2022-06-21 15:01:28.948068
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    obj = IntroducedSyntaxErrors("path/to/file.py")
    assert isinstance(obj, ISortError)
    assert isinstance(obj, IntroducedSyntaxErrors)
    assert obj.file_path == "path/to/file.py"
    assert obj.__str__() == (
        "isort introduced syntax errors when attempting to sort the imports contained within "
        "path/to/file.py."
    )


# Generated at 2022-06-21 15:01:31.528050
# Unit test for constructor of class MissingSection
def test_MissingSection():
    class_obj = MissingSection('import_module', 'section')


# Generated at 2022-06-21 15:01:33.636385
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    s = FileSkipComment('testFile')
    assert s.file_path == 'testFile'

# Generated at 2022-06-21 15:02:32.032211
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
	filename = "Testfile.py"
	a = UnsupportedEncoding(filename)
	assert a.filename == filename

# Generated at 2022-06-21 15:02:35.449070
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    exc_FileSkipped = FileSkipped("Expected <class 'tests.extra.test_exceptions.FileSkipped'> as \
                                   FileSkipped exception", "some_file.py")
    assert exc_FileSkipped.args == ("Expected <class 'tests.extra.test_exceptions.FileSkipped'> as \
                                     FileSkipped exception", "some_file.py")



# Generated at 2022-06-21 15:02:44.743380
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        print(e)
        assert str(e) == (
        "isort was told to sort a section of assignments, however the given code:\n\n"
        "a = 1\nb = 2\n\n"
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
    )
        pass


# Generated at 2022-06-21 15:02:48.350073
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "file_path_val"
    file_skipped = FileSkipComment(file_path=file_path)
    assert str(file_skipped) == "file_path_val contains an file skip comment and was skipped."
    assert file_skipped.file_path == "file_path_val"


# Generated at 2022-06-21 15:02:51.210343
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
        code = "MyNumber = 1, \nMySecondNumber = 2\nMyThirdNumber = 3\n"
        a = AssignmentsFormatMismatch(code)
        assert a
        test_UnsupportedSettings()

#Unit test for constructor of class UnsupportedSettings

# Generated at 2022-06-21 15:02:55.683971
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest.raises(AssignmentsFormatMismatch) as error:
        AssignmentsFormatMismatch("")
    assert str(error.value) == AssignmentsFormatMismatch.__doc__
    assert isinstance(error.value.code, str)
    assert error.value.code == ""

# Generated at 2022-06-21 15:02:56.618506
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    FormattingPluginDoesNotExist('test')

# Generated at 2022-06-21 15:03:02.809025
# Unit test for constructor of class ISortError
def test_ISortError():
    # ISortError
    with pytest.raises(ISortError, match='Eggs'):
        raise ISortError('Eggs')

    with pytest.raises(ISortError, match='bacon'):
        try:
            raise ISortError('Spam')
        except ISortError as e:
            e.args = ('bacon',)
            raise


# Generated at 2022-06-21 15:03:05.529410
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    file_path = 'test1.py'
    try:
        raise FormattingPluginDoesNotExist(file_path)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == file_path


# Generated at 2022-06-21 15:03:07.225849
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fss = FileSkipSetting('foo')
    assert fss.file_path == 'foo'

# Generated at 2022-06-21 15:05:07.386723
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("Example code.")
    except ISortError as exception:
        assert str(exception) == \
            "isort was told to sort a section of assignments, however the given code:\n\n" \
            "Example code.\n\n" \
            "Does not match isort's strict single line formatting requirement for assignment " \
            "sorting:\n\n" \
            "{variable_name} = {value}\n" \
            "{variable_name2} = {value2}\n" \
            "...\n\n"

# Generated at 2022-06-21 15:05:09.569794
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    e = ExistingSyntaxErrors(file_path='a')
    assert e.file_path == 'a'

# Generated at 2022-06-21 15:05:13.353365
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "test"
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as error:
        assert str(error) == f"Specified formatting plugin of {formatter} does not exist. "
        assert error.formatter == formatter

# Generated at 2022-06-21 15:05:15.504618
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("module", "section")
    except MissingSection as e:
        assert e.import_module == "module"
        assert e.section == "section"

# Generated at 2022-06-21 15:05:16.703081
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    encoding = UnsupportedEncoding("test.py")
    assert encoding.filename == "test.py"


# Generated at 2022-06-21 15:05:17.405531
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("message", "file path")

# Generated at 2022-06-21 15:05:18.821148
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("c:\\temp\\folder\\")
    except InvalidSettingsPath as e:
        assert True


# Generated at 2022-06-21 15:05:23.061854
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("[1,2,3,4]", SyntaxError("illegal character in identifier"))
    except LiteralParsingFailure as e:
        assert e.code == "[1,2,3,4]"
        assert e.original_error.msg == "illegal character in identifier"
    else:
        assert False

# Generated at 2022-06-21 15:05:27.529530
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    not_exist_formatter = 'non-existing-formatter'
    try:
        raise FormattingPluginDoesNotExist(not_exist_formatter)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == not_exist_formatter


if __name__ == "__main__":
    test_FormattingPluginDoesNotExist()

# Generated at 2022-06-21 15:05:29.839621
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings._format_option(
        "some option", "some value", "some source"
    ) == "\t- some option = some value  (source: 'some source')"