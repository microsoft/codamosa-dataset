

# Generated at 2022-06-21 14:56:09.759835
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file = FileSkipSetting('')
    assert file.file_path == ''
    assert file.message == ''


# Generated at 2022-06-21 14:56:11.834546
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    a = ValueError()
    b = LiteralParsingFailure('code', a)
    assert(b.code == 'code')
    assert(b.original_error == a)


# Generated at 2022-06-21 14:56:19.381754
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/does/not/exist")
    except InvalidSettingsPath as e:
        assert e.__class__.__name__ == "InvalidSettingsPath"
        assert e.__str__() == "isort was told to use the settings_path: /does/not/exist as the base directory or file that represents the starting point of config file discovery, but it does not exist."
        assert e.settings_path == "/does/not/exist"

# Generated at 2022-06-21 14:56:23.018724
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=int, expected_kind=str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str

# Generated at 2022-06-21 14:56:25.027933
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    f = UnsupportedEncoding('test')
    assert isinstance(f, UnsupportedEncoding)
    assert f.filename == 'test'


# Generated at 2022-06-21 14:56:30.169672
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    f1 = FileSkipped("message", "file_path")
    assert f1.message == "message"
    assert f1.file_path == "file_path"

# Generated at 2022-06-21 14:56:31.628598
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    print(IntroducedSyntaxErrors("FilePath"))

# Generated at 2022-06-21 14:56:35.494908
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    e = FileSkipped("message", "file_path")
    assert e.message == "message"
    assert e.file_path == "file_path"
    assert str(e) == 'FileSkipped: message'

# Generated at 2022-06-21 14:56:37.723381
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "Test message"
    file_path = "test_path"
    file_skipped = FileSkipped(message, file_path)
    assert file_skipped.message == message
    assert file_skipped.file_path == file_path

# Generated at 2022-06-21 14:56:43.600624
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("Test File")
    except IntroducedSyntaxErrors as err:
        assert(err.file_path == "Test File")
        assert(err.__str__() == "isort introduced syntax errors when attempting to sort the imports contained within Test File.")



# Generated at 2022-06-21 14:56:49.298141
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped('message', 'file_path')
    except FileSkipped as e:
        assert hasattr(e, 'message')
        assert hasattr(e, 'file_path')

# Generated at 2022-06-21 14:56:53.970278
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        1/0
    except Exception as e:
        literal_parsing_failure = LiteralParsingFailure("code", e)
        assert literal_parsing_failure.code == "code"
        assert isinstance(literal_parsing_failure.original_error, ZeroDivisionError)
    else:
        assert False


# Generated at 2022-06-21 14:56:59.013116
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    e = UnsupportedEncoding(filename='a.py')
    assert str(e) == 'UnsupportedEncoding'
    assert repr(e) == 'UnsupportedEncoding(Unknown or unsupported encoding in a.py)'
    assert isinstance(e, ISortError)
    assert isinstance(e, UnsupportedEncoding)

# Generated at 2022-06-21 14:57:01.640878
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    fail = LiteralSortTypeMismatch(type(10), type("string"))
    assert fail.kind == type(10)
    assert fail.expected_kind == type("string")

# Generated at 2022-06-21 14:57:05.805697
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Test with valid profile
    try:
        raise ProfileDoesNotExist("not_a_profile")
    except ProfileDoesNotExist as e:
        assert str(e) == f"Specified profile of not_a_profile does not exist. Available profiles: {','.join(profiles)}."
        assert e.profile == "not_a_profile"


# Generated at 2022-06-21 14:57:10.392758
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    msg = "test message"
    file_path = "test/file/path"
    try:
        raise FileSkipped(msg, file_path)
    except FileSkipped as e:
        assert (str(e) == msg)
        assert (e.file_path == file_path)

# Generated at 2022-06-21 14:57:13.921860
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path = "/home/user/nofile.ext"
    exception = InvalidSettingsPath(settings_path)
    assert exception.settings_path == settings_path


# Generated at 2022-06-21 14:57:16.372566
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("scode")
    except ExistingSyntaxErrors as ex:
        assert ex.file_path == "scode"

# Generated at 2022-06-21 14:57:18.817828
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    format_class="str"
    try:
        raise FormattingPluginDoesNotExist(format_class)
    except FormattingPluginDoesNotExist as e:
        assert  e.formatter == format_class

# Generated at 2022-06-21 14:57:24.030761
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings_dict = {"dummy_setting": {"value": "dummy", "source": "dummy"}}
    ex = UnsupportedSettings(settings_dict)
    assert "dummy_setting = dummy  (source: 'dummy')" in ex.__str__()