

# Generated at 2022-06-21 14:56:10.661733
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError()

# Generated at 2022-06-21 14:56:14.497808
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {
        "test": {
            "name": "2",
            "value": "1",
            "source": "3",
        },
    }
    obj = UnsupportedSettings(settings)
    assert obj.unsupported_settings == settings

# Generated at 2022-06-21 14:56:22.412540
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    e = UnsupportedSettings({"a": 1})
    assert str(e) == "isort was provided settings that it doesn't support:\n\n\t- a = 1  (source: '')\n\n" \
                     "For a complete and up-to-date listing of supported settings see: " \
                     "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    assert e.unsupported_settings == {"a": 1}

# Generated at 2022-06-21 14:56:23.734315
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("dummy").settings_path == "dummy"


# Generated at 2022-06-21 14:56:32.468949
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """
    LiteralParsingFailure.__init__
    """
    code = 'x = "some_value"'
    original_error = Exception('some error')
    ex = LiteralParsingFailure(code, original_error)
    assert str(ex) == 'isort failed to parse the given literal x = "some_value". It\'s important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of some error.'
    assert type(ex) == LiteralParsingFailure
    assert ex.code == 'x = "some_value"'
    assert ex.original_error == 'some error'

# Generated at 2022-06-21 14:56:37.897803
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        a=None
        a = []
        a[0]
    except Exception as e:
        print(e)
        try:
            raise LiteralParsingFailure("['a', 'b', 'c']",e)
        except LiteralParsingFailure as e:
            print(e)


if __name__ == "__main__":
    test_LiteralParsingFailure()

# Generated at 2022-06-21 14:56:38.877711
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting('../test/test_file.py')

# Generated at 2022-06-21 14:56:41.960959
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message="test message"
    file_path = "test/test.py"
    exception = FileSkipped(message, file_path)
    assert exception.message == message
    assert exception.file_path == file_path
    assert str(exception) == "{message}".format(message=message)

# Generated at 2022-06-21 14:56:45.482156
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding("dummy_file.py")
    assert str(error) == "Unknown or unsupported encoding in dummy_file.py"

# Generated at 2022-06-21 14:56:49.522178
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    ue = UnsupportedEncoding("file")
    assert ue.filename == "file"
    assert str(ue) == "UnsupportedEncoding: Unknown or unsupported encoding in file"


# Generated at 2022-06-21 14:56:53.013535
# Unit test for constructor of class ISortError
def test_ISortError():
    x = ISortError("error")

# Run the test (expected: no output, PASS)
test_ISortError()

# Generated at 2022-06-21 14:56:56.022512
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    err = UnsupportedEncoding(filename="filename")
    assert err.filename == "filename", "Wrong filename returned"



# Generated at 2022-06-21 14:57:02.966991
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    """This test is the unit test for class FormattingPluginDoesNotExist"""
    s0 = 'TestFormatter'
    try:
        raise FormattingPluginDoesNotExist(s0)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == s0, 'Invalid formatter'
    try:
        raise FormattingPluginDoesNotExist('notExistingFormatter')
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == 'notExistingFormatter', 'Invalid formatter'


# Generated at 2022-06-21 14:57:06.884868
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = "./app/app.py"
    message = f"{file_path} was skipped as it's listed in 'skip' setting " \
              "or matches a glob in 'skip_glob' setting"

    error = FileSkipped(message, file_path)
    assert error.message == message
    assert error.file_path == file_path

# Generated at 2022-06-21 14:57:14.395856
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'DateTime'
    section = 'FUTURE'
    ex = MissingSection(import_module, section)
    assert ex.import_module == import_module
    assert ex.section == section
    assert str(ex) == f"Found {import_module} import while parsing, but {section} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-21 14:57:18.121385
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors(file_path="test_file_path")
    assert error.args[0] == (
            f"isort introduced syntax errors when attempting to sort the imports contained within "
            f"test_file_path."
    )
    assert error.file_path == "test_file_path"

# Generated at 2022-06-21 14:57:22.119348
# Unit test for constructor of class ISortError
def test_ISortError():
    
    try:
        a = 1
        b = 2
        if a > b:
            raise ISortError
    except ISortError:
        print ("Exception Handled")
    

# Generated at 2022-06-21 14:57:24.619116
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist.__doc__ == '''Raised when a formatting plugin is set by the user that doesn't exist'''

# Generated at 2022-06-21 14:57:26.972498
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors('test.py')
    assert error.file_path == 'test.py'

# Generated at 2022-06-21 14:57:31.633091
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('settings_path')
        assert False
    except InvalidSettingsPath as e:
        assert str(e) == 'isort was told to use the settings_path: settings_path as the base ' \
                         'directory or file that represents the starting point of config file ' \
                         'discovery, but it does not exist.'


# Generated at 2022-06-21 14:57:37.322098
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("/foo/bar/baz/quux.py").message == "Unknown or unsupported encoding in /foo/bar/baz/quux.py"


# Generated at 2022-06-21 14:57:40.756280
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment('file_path')
    except FileSkipComment as e:
        assert e.message == 'file_path contains an file skip comment and was skipped.'
        assert e.file_path == 'file_path'


# Generated at 2022-06-21 14:57:46.452383
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        t = MissingSection("project_a", "not_defined")
        assert False
    except MissingSection as e:
        assert e.import_module == "project_a"
        assert e.section == "not_defined"
        assert str(e) == "Found project_a import while parsing, but not_defined was not included " \
            "in the `sections` setting of your config. Please add it before continuing\n" \
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
            "for more info."

# Generated at 2022-06-21 14:57:50.427019
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    filename = "example.py"
    error = ExistingSyntaxErrors(filename)
    assert isinstance(error, ISortError) is True
    assert isinstance(error, Exception) is True


# Generated at 2022-06-21 14:57:55.325157
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding) as e:
        raise UnsupportedEncoding("filename")
    assert "Unknown or unsupported encoding in filename" in str(e)
    assert e.type is UnsupportedEncoding
    assert e.value.filename == "filename"

# Generated at 2022-06-21 14:57:57.838965
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ISortError as e:
        assert e.profile == "test"
        assert "does not exist" in e.args[0]


# Generated at 2022-06-21 14:58:03.063613
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("A")
    except FileSkipComment as e:
        assert e.file_path == "A"
        assert e.args[0] == "A contains an file skip comment and was skipped."

# Generated at 2022-06-21 14:58:06.607819
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting('test_file')
    except FileSkipSetting as ex:
        assert str(ex) == "test_file was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
        assert ex.file_path == 'test_file'

# Generated at 2022-06-21 14:58:16.406430
# Unit test for constructor of class ProfileDoesNotExist

# Generated at 2022-06-21 14:58:23.300646
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("[1, 2, 3", ImportError)
    except ISortError as e:
        assert str(e) == "isort failed to parse the given literal [1, 2, 3. It's important to " \
                         "note that isort literal sorting only supports simple literals " \
                         "parsable by ast.literal_eval which gave the exception of ImportError."

        assert e.code == "[1, 2, 3"
        assert isinstance(e.original_error, ImportError)

# Generated at 2022-06-21 14:58:29.901814
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    test_1 = ExistingSyntaxErrors("file_path")
    assert test_1.file_path == "file_path"
    assert str(test_1) == "isort was told to sort imports within code that contains syntax errors: file_path."


# Generated at 2022-06-21 14:58:32.907364
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding(filename="filename")
    except UnsupportedEncoding:
        pass

# Generated at 2022-06-21 14:58:37.856814
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    a = LiteralSortTypeMismatch(type(1), str)

    # Exercise
    exception_raised = False
    try:
        raise a
    except LiteralSortTypeMismatch as e:
        # Confirm
        assert e.kind == type(1)
        assert e.expected_kind == str
        exception_raised = True
    assert exception_raised

# Generated at 2022-06-21 14:58:38.754408
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError is not None


# Generated at 2022-06-21 14:58:39.997123
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding(filename='test/test.py')

# Generated at 2022-06-21 14:58:45.217402
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest.raises(AssignmentsFormatMismatch) as exc_info:
        raise AssignmentsFormatMismatch(
            "testAssignmentsFormatMismatch"
            )
    assert exc_info.match(
        'isort was told to sort a section of assignments, however the given code:\n\n'
        'testAssignmentsFormatMismatch\n\n'
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
    )


# Generated at 2022-06-21 14:58:48.072224
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test image")
    except ExistingSyntaxErrors as e1:
        assert e1.file_path == "test image"


# Generated at 2022-06-21 14:58:54.729293
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'module'
    section = 'first_section'
    msg = 'Found {0} import while parsing, but {1} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'.format(import_module, section)

    try:
        raise MissingSection(import_module, section)
    except MissingSection as e:
        assert e.__str__() == msg

# Generated at 2022-06-21 14:58:58.466773
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    """Unit test for constructor of class FormattingPluginDoesNotExist"""
    try:
        raise FormattingPluginDoesNotExist("my_formatter")
    except FormattingPluginDoesNotExist as err:
        assert err.formatter == "my_formatter"

# Generated at 2022-06-21 14:59:09.253337
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Testing the constructor of class UnsupportedSettings"""
    errors = {
        'my_option': {
            'value': 'my_value',
            'source': 'computed'
        },
        'your_option': {
            'value': 'your_value',
            'source': 'provided'
        }
    }
    with pytest.raises(UnsupportedSettings) as e:
        raise UnsupportedSettings(unsupported_settings=errors)
    assert 'isort was provided settings that it doesn\'t support:' in str(e)
    assert '- your_option = your_value  (source: \'provided\')' in str(e)
    assert 'isort was provided settings that it doesn\'t support:' in str(e)