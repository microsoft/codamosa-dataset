

# Generated at 2022-06-21 14:56:08.890905
# Unit test for constructor of class ISortError
def test_ISortError():
    ISortError()

# Generated at 2022-06-21 14:56:14.448587
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "test"
    with pytest.raises(FormattingPluginDoesNotExist) as excinfo:
        raise FormattingPluginDoesNotExist(formatter="test")
    assert str(excinfo.value) == f"Specified formatting plugin of {formatter} does not exist. "

# Generated at 2022-06-21 14:56:16.180260
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("test","test").file_path == "test"


# Generated at 2022-06-21 14:56:21.055311
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors) as _excinfo:
        raise IntroducedSyntaxErrors("../test-data/introduced_syntax_error.py")

    assert _excinfo.value.file_path == "../test-data/introduced_syntax_error.py"


# Generated at 2022-06-21 14:56:24.516137
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    try:
        raise UnsupportedSettings({"skip": {"value": True, "source":"config"}})
    except UnsupportedSettings as error:
        assert error.unsupported_settings == {"skip": {"value": True, "source":"config"}}

# Generated at 2022-06-21 14:56:28.352590
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("formatter")
    except FormattingPluginDoesNotExist as e:
        assert str(e)=="Specified formatting plugin of formatter does not exist. "


test_FormattingPluginDoesNotExist()

# Generated at 2022-06-21 14:56:31.115569
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('test.py')
    except ISortError as e:
        print(e.filename)
        print(e)



# Generated at 2022-06-21 14:56:33.896940
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment.__init__(FileSkipComment, "z:\\" + "test.py")

# Generated at 2022-06-21 14:56:38.435425
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("file_path")
    except FileSkipComment as e:
        assert e.message == "file_path contains an file skip comment and was skipped."



# Generated at 2022-06-21 14:56:40.642495
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    with pytest.raises(FileSkipSetting, match="was skipped as it's listed"):
        raise FileSkipSetting(file_path="file_path")

