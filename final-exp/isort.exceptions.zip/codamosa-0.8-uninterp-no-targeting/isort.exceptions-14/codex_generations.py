

# Generated at 2022-06-21 14:56:13.253914
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors("file_path")
    assert "isort introduced syntax errors when attempting to sort the imports contained within " \
           "file_path." == error.args[0]
    assert "file_path" == error.file_path

# Generated at 2022-06-21 14:56:16.865857
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test_profile_1")
    except ProfileDoesNotExist as error:
        assert error.profile == "test_profile_1"

# Generated at 2022-06-21 14:56:20.865058
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("file_path")
    except FileSkipComment as e:
        assert str(e) == "file_path contains an file skip comment and was skipped."
        assert e.file_path == "file_path"

# Generated at 2022-06-21 14:56:23.123395
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
  try:
    # Invalid argument
    LiteralSortTypeMismatch('int', 'str')
  except ISortError as e:
    assert 'isort was told to sort a literal' in str(e)

# Generated at 2022-06-21 14:56:26.446163
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():  # noqa: D103
    try:
        raise LiteralParsingFailure(1, ValueError('some error'))
    except LiteralParsingFailure as e:
        assert e.code == 1
        assert str(e) == (
            'isort failed to parse the given literal 1. It\'s important to note '
            'that isort literal sorting only supports simple literals parsable by '
            'ast.literal_eval which gave the exception of some error.'
        )



# Generated at 2022-06-21 14:56:30.545866
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding('unknown_encoding.txt')
    assert str(error) == 'Unknown or unsupported encoding in unknown_encoding.txt'
    assert error.filename == 'unknown_encoding.txt'

# Generated at 2022-06-21 14:56:40.843277
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings_dict = {
        "variable_name": {"value": "variable value", "source": "source value"},
        "variable_name2": {"value": "variable value2", "source": "source value2"},
        "variable_name3": {"value": "variable value3", "source": "source value3"},
    }

# Generated at 2022-06-21 14:56:41.705152
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("A")


# Generated at 2022-06-21 14:56:45.747106
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist.__name__ == "ProfileDoesNotExist"
    assert ProfileDoesNotExist.__doc__ is not None



# Generated at 2022-06-21 14:56:48.857479
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # stub isort error
    with pytest.raises(Exception):
        raise ProfileDoesNotExist("This is not a real profile")

# Generated at 2022-06-21 14:56:57.334774
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():

    # Missing set of file_path variable
    try:
        raise ExistingSyntaxErrors()
    except TypeError as e:
        assert type(e) == TypeError

    # File_path variable is correct
    try:
        raise ExistingSyntaxErrors("testfile.py")
    except ExistingSyntaxErrors as e:
        assert e.args[0] == (
            "isort was told to sort imports within code that contains syntax errors: testfile.py."
        )
        assert e.file_path == "testfile.py"
        assert str(e) == (
            "isort was told to sort imports within code that contains syntax errors: testfile.py."
        )



# Generated at 2022-06-21 14:57:00.092248
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment('/path/to/file')
    except FileSkipComment as e:
        assert e.file_path == '/path/to/file'

# Generated at 2022-06-21 14:57:01.273452
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("file/path").file_path == "file/path"



# Generated at 2022-06-21 14:57:06.581081
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    import inspect
    import sys
    test_object = FileSkipSetting("test1.py")
    assert test_object.message == "test1.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert inspect.getdoc(FileSkipSetting) == None
    assert inspect.ismethod(FileSkipSetting.__init__) == True
    assert inspect.getfile(sys.modules[__name__]) == inspect.getfile(FileSkipSetting)


# Generated at 2022-06-21 14:57:12.239739
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors) as e:
        raise IntroducedSyntaxErrors("somefile.py")
    assert str(e.value) == "isort introduced syntax errors when attempting to sort the imports contained within somefile.py."
    assert e.value.file_path == "somefile.py"


# Generated at 2022-06-21 14:57:14.909388
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('test')
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == 'test'

# Generated at 2022-06-21 14:57:21.992874
# Unit test for constructor of class ProfileDoesNotExist

# Generated at 2022-06-21 14:57:23.734366
# Unit test for constructor of class MissingSection
def test_MissingSection():
    MissingSection("test_import_module", "test_section")

# Generated at 2022-06-21 14:57:28.848864
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("file.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "file.py"
        assert str(e) == \
            "isort introduced syntax errors when attempting to sort the imports contained within file.py."



# Generated at 2022-06-21 14:57:32.465128
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "test_file_path"
    try:
        raise IntroducedSyntaxErrors(file_path)
    except IntroducedSyntaxErrors as err:
        assert err.file_path == file_path
        assert str(err) == (
            "isort introduced syntax errors when attempting to sort the imports contained within "
            f"{file_path}."
        )



# Generated at 2022-06-21 14:57:43.827449
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit test for constructor of class UnsupportedSettings"""
    unsupported_settings = {
        'unknown_setting': {'value': True, 'source': 'unittest_isort_error.py'}
    }
    exc = UnsupportedSettings(unsupported_settings)

    assert exc.unsupported_settings == unsupported_settings
    assert (
        str(exc)
        == f"isort was provided settings that it doesn't support:\n\n\t- unknown_setting = True  (source: 'unittest_isort_error.py')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )

# Generated at 2022-06-21 14:57:45.619696
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except ISortError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 14:57:46.700118
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    filePath = "C:\ "
    FileSkipComment(filePath)

# Generated at 2022-06-21 14:57:48.235010
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    err = ExistingSyntaxErrors('file.py')
    assert err.file_path == 'file.py'


# Generated at 2022-06-21 14:57:58.638729
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    import filecmp
    import os

    case_dir = os.path.dirname(__file__)
    example_file = os.path.join(case_dir, '..', 'examples', 'legacy_import', 'example.txt')
    output_file = os.path.join(case_dir, "out.txt")

    # Set the skip_glob
    os.environ['ISORT_SKIP_GLOB'] = "examples/*"

    # Get the instance
    #instance = FileSkipSetting(example_file)
    with FileSkipSetting(example_file) as inst:
        # Write the output file
        fout = open(output_file, "w")
        fout.write("%s\n" % inst.message)

# Generated at 2022-06-21 14:57:59.423548
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment("filepath")

# Generated at 2022-06-21 14:58:04.104675
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    import_module = "InvalidSettingsPath"
    settings_path = "InvalidSettingsPath"
    try:
        raise InvalidSettingsPath(settings_path)
    except InvalidSettingsPath as e:
        assert import_module in str(e)
        assert settings_path in str(e)
        print('OK')


# Generated at 2022-06-21 14:58:04.998632
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment.__init__


# Generated at 2022-06-21 14:58:08.312560
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist,
                        match="Specified profile of profile_test does not exist. Available profiles: ."):
        raise ProfileDoesNotExist("profile_test")


# Generated at 2022-06-21 14:58:10.601855
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("ISortError")
    except ISortError:
        assert True
    finally:
        assert True

