

# Generated at 2022-06-21 14:56:14.943105
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("dummy")
    except IntroducedSyntaxErrors as exc:
        assert str(exc) == f"isort introduced syntax errors when attempting to sort the imports contained within dummy."
        assert exc.file_path == 'dummy'

# Generated at 2022-06-21 14:56:18.448408
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting(file_path='file_path')
    except FileSkipSetting as exc:
        assert isinstance(exc, ISortError)


# Generated at 2022-06-21 14:56:24.472137
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    def __init__(self, message: str, file_path: str):
        super().__init__(message)
        self.file_path = file_path
    msg="asdasdadasd"
    file_path="asdasdasdasd"
    skipped=FileSkipped(msg,file_path)
    assert skipped.message==msg
    assert skipped.file_path==file_path


# Generated at 2022-06-21 14:56:35.576225
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    from ast import literal_eval

    code = "// isort: off\n"
    code += "'''\n"
    code += "Hello World\n"
    code += "''' // isort: on"
    try:
        literal_eval(code)
    except Exception as original_error:
        assert str(LiteralParsingFailure(code, original_error)) == (
            "isort failed to parse the given literal // isort: off\n"
            "'''\n"
            "Hello World\n"
            "''' // isort: on. It's important to note that isort literal sorting "
            "only supports simple literals parsable by ast.literal_eval which "
            "gave the exception of {0!r}.".format(original_error)
        )

# Generated at 2022-06-21 14:56:41.013780
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(ISortError) as excinfo:
        raise InvalidSettingsPath('/dev/null')
    assert excinfo.type is InvalidSettingsPath
    assert str(excinfo.value) == ("isort was told to use the settings_path: /dev/null as the base "
                                  "directory or file that represents the starting point of config "
                                  "file discovery, but it does not exist.")


# Generated at 2022-06-21 14:56:43.600252
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert issubclass(FormattingPluginDoesNotExist, ISortError)

# Generated at 2022-06-21 14:56:46.168228
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "test.py"
    with pytest.raises(ISortError):
        raise ExistingSyntaxErrors(file_path=file_path)


# Generated at 2022-06-21 14:56:52.887158
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    fake_profile = 'fake_profile'
    try:
        raise ProfileDoesNotExist(fake_profile)
    except ProfileDoesNotExist as e:
        assert str(e) == f"Specified profile of fake_profile does not exist. Available profiles: black, google, pycharm, vscode, vim, atom, jupyter, travis, gitlab, github"
        assert e.profile == fake_profile


# Generated at 2022-06-21 14:56:59.853548
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'import_module'
    section = 'section'
    try:
        raise MissingSection(import_module, section)
    except Exception as err:
        assert err.args[0] == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."



# Generated at 2022-06-21 14:57:03.331539
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("something")
    except ProfileDoesNotExist as e:
        assert str(e) == (
            "Specified profile of something does not exist. "
            "Available profiles: black, py37, py38, google, xcode."
        )

# Generated at 2022-06-21 14:57:08.065161
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch('name = value\n')
        assert False
    except AssignmentsFormatMismatch as ex:
        assert(ex.code == 'name = value\n')

# Generated at 2022-06-21 14:57:10.195836
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """Test the implementation of constructor of class LiteralParsingFailure"""
    LiteralParsingFailure("parser-error-code", "original-error")

# Generated at 2022-06-21 14:57:14.487144
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    try:
        raise UnsupportedSettings({"sort_within_sections": {"value": None, "source": "default"}})
    except TypeError:
        return
    raise AssertionError("UnsupportedSettings constructor doesn't accept just one argument")

# Generated at 2022-06-21 14:57:16.550962
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    error = LiteralSortTypeMismatch('a', 'b')
    assert error.kind == 'a'
    assert error.expected_kind == 'b'

# Generated at 2022-06-21 14:57:18.378974
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    g = LiteralSortTypeMismatch(True, False)
    assert g.kind == True
    assert g.expected_kind == False


# Generated at 2022-06-21 14:57:22.475972
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("/tmp/does_not_exist.py")
    except ExistingSyntaxErrors as exception:
        assert isinstance(exception, ISortError)



# Generated at 2022-06-21 14:57:27.509562
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    """This is a test checking if IntroducedSyntaxErrors is correctly raised"""
    with pytest.raises(IntroducedSyntaxErrors) as excp:
        raise IntroducedSyntaxErrors('test')
    assert str(excp.value) == 'isort introduced syntax errors when attempting to sort the imports contained within test.'

# Generated at 2022-06-21 14:57:32.807419
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "modules"
    section = "SECTIONS"
    missing_section = MissingSection(import_module, section)
    assert missing_section.args == ("Found modules import while parsing, but SECTIONS was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.",)
    assert missing_section.import_module == "modules"
    assert missing_section.section == "SECTIONS"

# Generated at 2022-06-21 14:57:38.217130
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        ast.literal_eval('{"test": 1]')
    except ValueError as err:
        try:
            raise LiteralParsingFailure('{"test": 1]', err)
        except LiteralParsingFailure as err:
            assert type(err) is LiteralParsingFailure


# Generated at 2022-06-21 14:57:40.821147
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test_plugin")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test_plugin"
    else:
        assert False