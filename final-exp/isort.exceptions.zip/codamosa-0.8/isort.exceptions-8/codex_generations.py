

# Generated at 2022-06-12 00:46:34.010118
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('mypackage', 'FUTURE') == 'Found mypackage import while parsing, but FUTURE was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'

# Generated at 2022-06-12 00:46:36.626492
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    p = InvalidSettingsPath('/path/to/where')
    assert p.settings_path == '/path/to/where'


# Generated at 2022-06-12 00:46:41.031417
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("Formatter")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of Formatter does not exist. "
        assert type(e) == FormattingPluginDoesNotExist
        assert e.formatter == "Formatter"
test_FormattingPluginDoesNotExist()


# Generated at 2022-06-12 00:46:43.942679
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("/home/user/testing.py")
    except ExistingSyntaxErrors as e:
        print(e)


# Generated at 2022-06-12 00:46:45.882124
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert issubclass(ExistingSyntaxErrors, ISortError)
    assert ExistingSyntaxErrors("file.py").file_path == "file.py"


# Generated at 2022-06-12 00:46:51.717171
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    filename = "file1.py"
    exception = FileSkipComment(filename)
    assert exception.file_path == "file1.py"
    assert exception.args[0] == "file1.py contains an file skip comment and was skipped."

# Generated at 2022-06-12 00:46:58.778224
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    s = FileSkipSetting("/path/to/file")
    assert s.file_path == "/path/to/file"
    assert s.message == "/path/to/file was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert s.__str__() == "/path/to/file was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-12 00:46:59.617278
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    encoding = UnsupportedEncoding("test.txt")

# Generated at 2022-06-12 00:47:08.365329
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    import json
    
    settings = {
        'array_import_names': {
            'value': 'a,b,c',
            'source': 'CLI'
        },
        'out_style': {
            'value': 'black',
            'source': 'config'
        }
    }
    
    err = UnsupportedSettings(settings)
    
    assert err.unsupported_settings == json.loads(json.dumps(settings))

# Generated at 2022-06-12 00:47:10.916162
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section_exception = MissingSection("django.db.models", "DJANGO")
    assert missing_section_exception
    assert isinstance(missing_section_exception, ISortError)