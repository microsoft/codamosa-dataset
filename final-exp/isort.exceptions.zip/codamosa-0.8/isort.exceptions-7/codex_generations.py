

# Generated at 2022-06-12 00:46:17.308474
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    variable = 'C:\\Users\\surya\\Documents\\GitHub\\isort'
    temp_object = InvalidSettingsPath(variable)
    assert hasattr(temp_object, 'settings_path')


# Generated at 2022-06-12 00:46:17.839479
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert False

# Generated at 2022-06-12 00:46:20.753616
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    s = "a = 1\nb = 2\n"
    error = AssignmentsFormatMismatch(s)
    assert error.code == s

# Generated at 2022-06-12 00:46:31.165882
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    import io
    from isort.settings import DEFAULT_SECTION

    filename = io.StringIO("codigoenutf-8españa")
    assert filename.encoding == 'utf-8'
    encoding = "latin-1"
    sections = DEFAULT_SECTION
    tab_width = 8
    case_sensitive = True
    line_width = 79
    use_parentheses = True
    spaced_comment = True
    lines_after_imports = 2
    default_section = 'FIRSTPARTY'
    indent = 4
    multi_line_output = 3
    wrap_length = 0
    balanced_wrapping = True
    known_future_library = False
    known_standard_library = False
    known_third_party = False
    known_first_party = False
    trailing_comma = False


# Generated at 2022-06-12 00:46:39.928403
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # Arrange
    tester = UnsupportedSettings({'foo': {'value': 'bar'}})

    # Act & Assert
    assert tester.unsupported_settings == {'foo': {'value': 'bar'}}
    assert str(tester) == "isort was provided settings that it doesn't support:\n\n\t- foo = bar  (source: '')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"


# Generated at 2022-06-12 00:46:42.698262
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings(
            unsupported_settings={"test_key": {"value": "test_value", "source": "test_source"}}
    )

# Generated at 2022-06-12 00:46:44.544771
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test."
        assert e.file_path == "test"

# Generated at 2022-06-12 00:46:47.697521
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # check if object FileSkipSetting is created
    expected = 'file.py was skipped as it\'s listed in \'skip\' setting ' \
               'or matches a glob in \'skip_glob\' setting'
    assert FileSkipSetting('file.py').__str__() == expected


# Generated at 2022-06-12 00:46:52.058945
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    args = "abc", ValueError("abc")
    assert LiteralParsingFailure(*args).args == args
    assert LiteralParsingFailure(*args).code == "abc"
    assert LiteralParsingFailure(*args).original_error == ValueError("abc")


# Generated at 2022-06-12 00:46:55.142391
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert isinstance(InvalidSettingsPath("a"), ISortError)
    assert InvalidSettingsPath("a").settings_path == "a"

