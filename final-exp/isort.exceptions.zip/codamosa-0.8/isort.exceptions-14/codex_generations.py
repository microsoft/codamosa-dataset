

# Generated at 2022-06-12 00:46:11.994161
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("abc")
    except AssignmentsFormatMismatch as e:
        assert issubclass(AssignmentsFormatMismatch, ISortError)
        assert str(e) == 'isort was told to sort a section of assignments, however the given code:\n\nabc\n\n'\
                         'Does not match isort\'s strict single line formatting requirement for assignment '\
                         'sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n'
        assert e.code == "abc"

# Generated at 2022-06-12 00:46:13.395341
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():  # pragma: no cover
    error = IntroducedSyntaxErrors("error test")
    assert error.file_path == "error test"

# Generated at 2022-06-12 00:46:19.466561
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error = Exception("foo")
    try:
        raise LiteralParsingFailure("bar", error)
    except LiteralParsingFailure as e:
        assert str(e) == (
            "isort failed to parse the given literal bar. It's important to note that "
            "isort literal sorting only supports simple literals parsable by "
            "ast.literal_eval which gave the exception of Exception('foo',)."
        )
        assert e.code == "bar"
        assert e.original_error == error

# Generated at 2022-06-12 00:46:21.882094
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = '/some/path/to/settings'
    error = InvalidSettingsPath(path)
    assert isinstance(error, InvalidSettingsPath)
    assert isinstance(error, ISortError)

# Generated at 2022-06-12 00:46:25.251097
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    filename = 'some/filename.py'
    with pytest.raises(IntroducedSyntaxErrors):
        raise IntroducedSyntaxErrors(file_path=filename)

# Unit test that check that the message is composed correctly

# Generated at 2022-06-12 00:46:28.879432
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as e:
        raise ExistingSyntaxErrors("file_path")
    assert "isort was told to sort imports within code that contains syntax errors: file_path." in str(e)


# Generated at 2022-06-12 00:46:33.653420
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = '/Users/asdafafs/isort/src/'
    message = f"{file_path} contains an file skip comment and was skipped."
    file = FileSkipComment('/Users/asdafafs/isort/src/')
    assert file.file_path == file_path
    assert repr(file) == message

# Generated at 2022-06-12 00:46:34.589172
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    raise InvalidSettingsPath("123")

# Generated at 2022-06-12 00:46:43.744783
# Unit test for constructor of class MissingSection
def test_MissingSection():
    from isort.utils.string import truncate_left
    import_module = "hello"
    section = "goodbye"
    msg = "Found hello import while parsing, but goodbye was not included "
    msg += "in the `sections` setting of your config. Please add it before continuing\n"
    msg += "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
    msg += "for more info."

    try:
        raise MissingSection(import_module, section)
    except MissingSection as ms:
        assert truncate_left(ms.args[0], len(msg)) == msg
        assert ms.import_module == import_module
        assert ms.section == section

# Generated at 2022-06-12 00:46:53.685080
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    from pathlib import Path
    from typing import Any, Dict, Union
    
    class ISortError(Exception):
        """Base isort exception object from which all isort sourced exceptions should inherit"""
    
    class InvalidSettingsPath(ISortError):
        """Raised when a settings path is provided that is neither a valid file or directory"""
    
        def __init__(self, settings_path: str):
            super().__init__(
                f"isort was told to use the settings_path: {settings_path} as the base directory or "
                "file that represents the starting point of config file discovery, but it does not "
                "exist."
            )
            self.settings_path = settings_path
    
    
    #Insert test here

# Generated at 2022-06-12 00:46:57.518602
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('Error')
    except ISortError:
        assert True

# Generated at 2022-06-12 00:47:04.582683
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("some_formatter")
    except FormattingPluginDoesNotExist as err:
        assert err.args[0] == "Specified formatting plugin of some_formatter does not exist. "
    else:
        raise Exception("Expected FormattingPluginDoesNotExist exception")


if __name__ == "__main__":
    import sys

    sys.exit(pytest.main(["-q", __file__]))

# Generated at 2022-06-12 00:47:09.153249
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test"
    e = FileSkipSetting(file_path)
    assert file_path == e.file_path
    assert str(e) == "test was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-12 00:47:12.657005
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    with pytest.raises(FileSkipSetting, match="as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"):
        raise FileSkipSetting('file_path')

# Generated at 2022-06-12 00:47:16.571985
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(FileSkipped) as e:
        raise FileSkipped(message="message", file_path="file_path")
    assert e.value.message == "message"
    assert e.value.file_path == "file_path"

# Generated at 2022-06-12 00:47:19.838808
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest .raises(AssignmentsFormatMismatch) as excinfo:
        AssignmentsFormatMismatch()
    assert excinfo.value.code == "code"

# Generated at 2022-06-12 00:47:28.773804
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Specify file paths to be checked
    dummy_paths = ['foo.py', 'bar.py']

    # Check if instance of FileSkipSetting class is created with correct details
    for dummy_path in dummy_paths:
        exception = FileSkipSetting(dummy_path)
        assert isinstance(exception, FileSkipped)
        assert exception.file_path == dummy_path
        assert isinstance(exception, FileSkipSetting)
        assert exception.__class__.__name__ == 'FileSkipSetting'
        assert exception.__class__.__doc__.startswith(
            'Raised when an entire file is skipped due to provided isort settings')



# Generated at 2022-06-12 00:47:29.971283
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    a = FileSkipSetting("file_path")
    assert a.file_path == "file_path"

# Generated at 2022-06-12 00:47:31.807717
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("TestFile.py")
    except Exception as e:
        assert type(e) == IntroducedSyntaxErrors
        assert e.file_path == "TestFile.py"

# Generated at 2022-06-12 00:47:33.570185
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        LiteralSortTypeMismatch(str, int)
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-12 00:47:39.114882
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    f = FileSkipComment(file_path='')
    assert f.message == ''
    assert f.file_path == ''

# Generated at 2022-06-12 00:47:42.149534
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("")
    except Exception as e:
        assert e
        assert e.code == ""

# Generated at 2022-06-12 00:47:44.910398
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('invalid_settings_path')
    except InvalidSettingsPath as ex:
        assert ex.settings_path == 'invalid_settings_path'

# Generated at 2022-06-12 00:47:48.028752
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    info = ExistingSyntaxErrors("/home/users/test.py")
    assert info.file_path == "/home/users/test.py"


# Generated at 2022-06-12 00:47:51.254270
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    e = ExistingSyntaxErrors('test_file')
    assert e.file_path == 'test_file'
    assert str(e) == 'isort was told to sort imports within code that contains syntax errors: test_file.'

# Generated at 2022-06-12 00:47:54.150613
# Unit test for constructor of class ISortError
def test_ISortError():
    error = ISortError("error message")
    assert error.args[0] == "error message"

# Generated at 2022-06-12 00:47:56.536241
# Unit test for constructor of class ISortError
def test_ISortError():
    """Test the constructor of class ISortError"""
    try:
        raise ISortError()
    except ISortError:
        assert True

# Generated at 2022-06-12 00:48:01.257691
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(type(1), type('a'))
    except LiteralSortTypeMismatch as error:
        assert error.expected_kind == str
        assert error.kind == int
        assert error.__class__ == LiteralSortTypeMismatch



# Generated at 2022-06-12 00:48:03.934901
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Missing the file_path
    try:
        raise ExistingSyntaxErrors("")
    except ExistingSyntaxErrors as e:
        filename = e.file_path
    assert filename == ""

# Generated at 2022-06-12 00:48:07.801974
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("somefile")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "somefile"
        assert str(e) != "ExistingSyntaxErrors"
    else:
        assert False, "ExistingSyntaxErrors not raised"


# Generated at 2022-06-12 00:48:16.656642
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError("ISortError")


# Generated at 2022-06-12 00:48:19.141678
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    test = str(AssignmentsFormatMismatch(code='test_code'))
    assert 'isort' in test
    assert 'code' in test
    assert 'test_code' in test

# Generated at 2022-06-12 00:48:21.353693
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    with pytest.raises(FileSkipComment) as exception:
        raise FileSkipComment("test")
    assert exception.value.file_path == "test"


# Generated at 2022-06-12 00:48:24.803918
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "not-a-setting": {"value": "not a real setting", "source": "some-command-line-flag"}
    }
    config = UnsupportedSettings(unsupported_settings)
    assert config.unsupported_settings == unsupported_settings

# Generated at 2022-06-12 00:48:29.843075
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    error = UnsupportedSettings({"asdf": {"value": "asdf", "source": "asdf"}})
    assert "isort was provided settings that it doesn't support:" in error.args[0]
    assert "\t- asdf = asdf  (source: 'asdf')" in error.args[0]
    assert "\n\n" in error.args[0]

# Generated at 2022-06-12 00:48:32.658027
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    t = InvalidSettingsPath("test_InvalidSettingsPath")
    assert t.settings_path == "test_InvalidSettingsPath"


# Generated at 2022-06-12 00:48:34.221237
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = FormattingPluginDoesNotExist("test")
    assert formatter.formatter == "test"

# Generated at 2022-06-12 00:48:36.744052
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():

    try:
        raise IntroducedSyntaxErrors("hello")
    except IntroducedSyntaxErrors as err:
        assert str(err) == "isort introduced syntax errors when attempting to sort the imports contained within hello."
        assert err.file_path == "hello"

# Generated at 2022-06-12 00:48:44.883002
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    variable_name = "test"
    variable_value = 123
    variable_value1 = 456
    variable_value2 = 789

    try:
        raise IntroducedSyntaxErrors(variable_name)
    except IntroducedSyntaxErrors as e:
        assert variable_name == e.file_path

    try:
        raise MissingSection(variable_value, variable_value1)
    except MissingSection as e:
        assert variable_value == e.import_module
        assert variable_value1 == e.section


# Generated at 2022-06-12 00:48:50.149862
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    class TempClass(FileSkipped):
        def __init__(self, file_path: str):
            super().__init__(message="This is a test message", file_path=file_path)
    file_path = "test/test_file"
    obj = TempClass(file_path=file_path)
    assert obj.file_path == file_path
    assert obj.message == "This is a test message"