

# Generated at 2022-06-12 00:46:15.731260
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("test")

# Generated at 2022-06-12 00:46:20.080249
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    e = ProfileDoesNotExist("bad_profile")
    assert str(e) == "Specified profile of bad_profile does not exist. " \
                     "Available profiles: black, black_py35, black_py36, " \
                     "black_py37, black_py38, google, vogel, vogel_py27, " \
                     "vogel_py35, vogel_py36, vogel_py37, vogel_py38."
    assert e.profile == "bad_profile"

# Generated at 2022-06-12 00:46:23.941815
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test.py")
    except ExistingSyntaxErrors as e:
        assert (
            str(e)
            == "isort was told to sort imports within code that contains syntax errors: test.py."
        )
        assert e.file_path == "test.py"

# Generated at 2022-06-12 00:46:25.708622
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('test')
    except IntroducedSyntaxErrors as ex:
        assert(ex.file_path == 'test')

# Generated at 2022-06-12 00:46:29.837249
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import", "section")
    except MissingSection as e:
        assert e.args[0] == "Found import import while parsing, but section was not included in the `sections` setting of your config. " \
                             "Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        assert e.import_module == "import"
        assert e.section == "section"

# Generated at 2022-06-12 00:46:33.361853
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(Exception):
        raise ExistingSyntaxErrors("./data/ExistingSyntaxErrors.py")


# Generated at 2022-06-12 00:46:35.935062
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "\n".join(["a = 1", "b = 2", "class b:", "pass"])
    AssignmentsFormatMismatch(code)  # no exception

# Generated at 2022-06-12 00:46:37.189905
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
  ExistingSyntaxErrors("file_path")

# Generated at 2022-06-12 00:46:40.001712
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert(IntroducedSyntaxErrors('test').__init__())


# Generated at 2022-06-12 00:46:47.315675
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    import_name = "InvalidSettingsPath"
    expected = [
        "InvalidSettingsPath(ISortError)",
        "InvalidSettingsPath(ISortError)",
        "InvalidSettingsPath(ISortError)",
        "InvalidSettingsPath(ISortError)",
    ]
    actual = [
        str(InvalidSettingsPath),
        str(InvalidSettingsPath),
        str(InvalidSettingsPath),
        str(InvalidSettingsPath),
    ]
    assert expected == actual, "{} failed!".format(import_name)
    print("{} passed!".format(import_name))


if __name__ == '__main__':
    test_InvalidSettingsPath()



# Generated at 2022-06-12 00:47:00.793037
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try: 
        raise MissingSection("module1", "section1")
    except MissingSection as error:
        assert error.args[0] == "Found module1 import while parsing, but section1 was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        assert error.import_module == "module1"
        assert error.section == "section1"
        # Test that the object has a string representation
        error_str = str(error)
        assert isinstance(error_str, str)
        assert len(error_str) > 0

# Generated at 2022-06-12 00:47:03.685857
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("/path/to/file")
    except ExistingSyntaxErrors as e:
        assert (e.file_path) == ("/path/to/file")


# Generated at 2022-06-12 00:47:05.395607
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({'settings': {'value': 'missing_setting', 'source': 'not_supported'}})

# Generated at 2022-06-12 00:47:08.731982
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    from pytest import raises

    code = "a, b"
    original_error = ValueError()
    with raises(LiteralParsingFailure) as e:
        raise LiteralParsingFailure(code, original_error)
    assert e.value.code == code
    assert e.value.original_error == original_error

# Generated at 2022-06-12 00:47:17.030172
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    import pytest
    from mypy import build
    from mypy.api import Options
    from mypy.errors import CompileError

    options = Options()
    options.silent_imports = True
    options.mypy_path = "/tmp"
    source = "foo = 0\nbar = 'baz"
    errors = build.BuildManager(options, None, "/tmp", False).errors_cache

    with pytest.raises(ExistingSyntaxErrors):
        err: CompileError = errors.clear()[source]
        raise ExistingSyntaxErrors(err.file)

# Generated at 2022-06-12 00:47:18.286080
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment("file_path")

# Generated at 2022-06-12 00:47:23.703556
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors(file_path="test")
    except IntroducedSyntaxErrors as e:
        assert str(e) == (
            "isort introduced syntax errors when attempting to sort the imports contained within "
            "test."
        )
        assert e.file_path == "test"
    else:
        assert False, "No error raised"



# Generated at 2022-06-12 00:47:28.015843
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "Test message"
    file_path = "testfile.py"
    f_s = FileSkipped(message, file_path)
    assert f_s.message == message
    assert f_s.file_path == file_path


# Generated at 2022-06-12 00:47:30.544250
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors) as error:
        raise IntroducedSyntaxErrors("testfile.py")
    assert error.value.file_path == "testfile.py"

# Generated at 2022-06-12 00:47:33.348244
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    exc = ExistingSyntaxErrors("Some message")
    assert exc.file_path == "Some message"
    assert str(exc) == exc.__repr__()

if __name__ == "__main__":
    test_ExistingSyntaxErrors()