

# Generated at 2022-06-12 00:46:11.211385
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    skip_filepath = 'skip_filepath'
    fail_msg = 'Incorrect file path from FileSkipSetting exception.'
    assert FileSkipSetting(skip_filepath).file_path == skip_filepath, fail_msg

# Generated at 2022-06-12 00:46:12.960315
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "C:\\Users\Krissy\\Desktop\\Test\\test.txt"
    assert FileSkipSetting(file_path).file_path == file_path

# Generated at 2022-06-12 00:46:16.872226
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "fake_formatter"
    a = FormattingPluginDoesNotExist(formatter)
    assert a.formatter == "fake_formatter"

# Generated at 2022-06-12 00:46:18.414371
# Unit test for constructor of class MissingSection
def test_MissingSection():
    a = MissingSection("import_module","section")
    assert a.import_module == "import_module"
    assert a.section == "section"

# Generated at 2022-06-12 00:46:25.282683
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert (
        UnsupportedSettings(
            {
                "unsupported setting": {
                    "value": "test",
                    "source": "test source",
                }
            }
        ).message
        == "isort was provided settings that it doesn't support:\n\n\t- unsupported setting = test  "
        "(source: 'test source')\n\nFor a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )

# Generated at 2022-06-12 00:46:29.562990
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(type(2), type(""))
    except LiteralSortTypeMismatch as e: 
        assert e.kind is type(2), "LiteralSortTypeMismatch.kind incorrect"
        assert e.expected_kind is type(""), "LiteralSortTypeMismatch.expected_kind incorrect"


# Generated at 2022-06-12 00:46:38.537854
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    import unittest
    import isort
    class class_test(isort.ISortError):
        def __init__(self, filename):
            isort.ISortError.__init__(self, 'Unknown or unsupported encoding in ' + filename)
            self.filename = filename
            
    class TestStringMethods(unittest.TestCase):
        def test_UnsupportedEncoding(self):
            # Unit test for constructor of class UnsupportedEncoding
            obj = class_test("file.txt")
            self.assertEqual(obj.filename, "file.txt")
            
    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-12 00:46:43.097466
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = '/User/test.py'
    test = FileSkipComment(path)
    assert test.__str__() == '<FileSkipped: /User/test.py contains an file skip comment and was skipped.>'


# Generated at 2022-06-12 00:46:48.048452
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("Invalid Code")
    except ISortError as e:
        assert str(e) == (
            "isort was told to sort a section of assignments, however the given code:\n\n"
            "Invalid Code\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n"
        )

# Generated at 2022-06-12 00:46:51.815205
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("foo")
    except IntroducedSyntaxErrors as inst:
        assert inst.file_path == "foo"
        assert str(inst) == "isort introduced syntax errors when attempting to sort the imports contained within foo."