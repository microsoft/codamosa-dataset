

# Generated at 2022-06-12 00:46:33.433453
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    """Test for constructor of class FileSkipComment"""
    try:
        raise FileSkipComment("file_path")
    except FileSkipComment as ex:
        assert ex.file_path == "file_path"

# Generated at 2022-06-12 00:46:35.140585
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("/path/to/file.py").file_path == "/path/to/file.py"

# Generated at 2022-06-12 00:46:44.478138
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    try:
        raise UnsupportedSettings({"foo": {"value": "bar", "source": "config"}})
    except UnsupportedSettings as error:
        assert error.__str__() == (
            "isort was provided settings that it doesn't support:\n\n"
            "\t- foo = bar  (source: 'config')\n\n"
            "For a complete and up-to-date listing of supported settings see: "
            "https://pycqa.github.io/isort/docs/configuration/options/.\n"
        )
        assert error.unsupported_settings == {"foo": {"value": "bar", "source": "config"}}
        return
    raise AssertionError("UnsupportedSettings should be raised")

# Generated at 2022-06-12 00:46:45.279244
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment("test.py")

# Generated at 2022-06-12 00:46:47.797567
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = 'fake/path'
    e = FileSkipComment(path)
    assert e.message == f"{path} contains an file skip comment and was skipped."
    assert e.file_path == path


# Generated at 2022-06-12 00:46:49.447955
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert isinstance(ExistingSyntaxErrors("path"), ExistingSyntaxErrors)

# Generated at 2022-06-12 00:46:52.315704
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("Message", "path_file").message == "Message"
    assert FileSkipped("Message", "path_file").file_path == "path_file"


# Generated at 2022-06-12 00:46:55.892892
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {'a': {'value': '1', 'source': 'config'}}
    with pytest.raises(ISortError):
        UnsupportedSettings(settings)

# Generated at 2022-06-12 00:47:00.478934
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test")
    except UnsupportedEncoding as e:
        assert e.filename == "test"


# Generated at 2022-06-12 00:47:03.046202
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    fname = "file1.txt"
    message = "foo"
    e = FileSkipComment(fname)
    assert e.file_path == fname
    assert e.message == message