

# Generated at 2022-06-12 00:46:17.627914
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist("Error")


# Generated at 2022-06-12 00:46:20.158899
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('default')
    except Exception as e:
        print(e.profile)

# Generated at 2022-06-12 00:46:27.935919
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "{{'dict': 1}}"
    original_error = SyntaxError()
    exception = LiteralParsingFailure(code, original_error)

    assert isinstance(exception, LiteralParsingFailure)
    assert exception.code == code
    assert exception.original_error == original_error

# Generated at 2022-06-12 00:46:29.510918
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting(file_path = "test.py")

# Generated at 2022-06-12 00:46:31.335244
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as ex:
        assert ex.profile == "test"

# Generated at 2022-06-12 00:46:35.362818
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path = "dummy path"
    ex = InvalidSettingsPath(settings_path)
    assert ex.settings_path == settings_path


# Generated at 2022-06-12 00:46:38.257383
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = 'test'
    error = UnsupportedEncoding(filename)
    assert str(error) == f'Unknown or unsupported encoding in {filename}'
    assert error.filename == filename

# Generated at 2022-06-12 00:46:42.260533
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path="./path"
    error=FileSkipComment(path)
    assert error.file_path==path
    assert isinstance(error, ISortError)


# Generated at 2022-06-12 00:46:43.123268
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection(import_module="abc", section="section")


# Generated at 2022-06-12 00:46:45.296931
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        print(1 + 'foo')
    except TypeError as e:
        err = LiteralParsingFailure('1 + "foo"', e)
        assert err.code == '1 + "foo"'
        assert isinstance(err.original_error, TypeError)



# Generated at 2022-06-12 00:46:50.105306
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    f = FileSkipSetting("somefile.py")
    assert f.file_path == "somefile.py"
    assert f.message.startswith("somefile.py")

# Generated at 2022-06-12 00:46:51.209412
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist('formatter')

# Generated at 2022-06-12 00:46:53.278128
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "code.py"
    ExistingSyntaxErrors(file_path)

# Generated at 2022-06-12 00:46:58.202739
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as ex:
        raise ExistingSyntaxErrors("test/test.py")
    assert isinstance(ex.value, ExistingSyntaxErrors)
    assert ex.value.file_path == "test/test.py"


# Generated at 2022-06-12 00:47:00.764718
# Unit test for constructor of class MissingSection
def test_MissingSection():
    obj = MissingSection("import_module", "section")
    assert "Found import_module import while parsing, but section was not included " in str(obj)


# Generated at 2022-06-12 00:47:10.572513
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    from isort.settings import DEFAULT_CONFIG
    from textwrap import dedent

    options = {
        'unknown_option': {
            'value': 'something',
            'source': 'default'
        },
        'config_file': {
            'value': '~/.config/isort/isort.cfg',
            'source': 'default'
        }
    }
    result = UnsupportedSettings(options)

# Generated at 2022-06-12 00:47:16.780099
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("/home/user/test.txt")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "/home/user/test.txt"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: /home/user/test.txt."


# Generated at 2022-06-12 00:47:19.138107
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "abc"
    instance = FormattingPluginDoesNotExist(formatter)
    assert formatter == instance.formatter

# Generated at 2022-06-12 00:47:22.225121
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("ISortError")
    except ISortError as e:
        assert str(e) == "ISortError"



# Generated at 2022-06-12 00:47:24.412516
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('test.py')
    except UnsupportedEncoding as error:
        assert error.filename == 'test.py'