

# Generated at 2022-06-12 00:46:07.729617
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure('a', SyntaxError('invalid'));
    except ISortError:
        raise;

# Generated at 2022-06-12 00:46:11.175761
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():  # noqa: D103
    obj = LiteralSortTypeMismatch(str, int)
    # Test for instantiation
    assert obj
    # Test for class attributes
    assert obj.kind == str
    assert obj.expected_kind == int
    # Test for class string representation
    assert str(obj)


# Generated at 2022-06-12 00:46:12.686293
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("test")
    except FileSkipSetting as err:
        assert err.file_path == "test"



# Generated at 2022-06-12 00:46:17.521854
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'abc'
    exception = FormattingPluginDoesNotExist(formatter)
    assert exception.formatter == formatter
    assert exception.args[0] == f"Specified formatting plugin of {formatter} does not exist. "

# Generated at 2022-06-12 00:46:19.550772
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert LiteralParsingFailure.__init__

# Generated at 2022-06-12 00:46:21.419442
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("something wrong!")
    except ISortError as err:
        assert str(err) == "something wrong!"


# Generated at 2022-06-12 00:46:24.730705
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "aaa.py"
    instance = IntroducedSyntaxErrors(file_path)
    assert isinstance(instance, IntroducedSyntaxErrors)
    assert isinstance(instance, ISortError)

# Generated at 2022-06-12 00:46:28.161519
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "howdy"
    exception = FormattingPluginDoesNotExist(formatter)
    assert exception.formatter == formatter
    assert str(exception) == "Specified formatting plugin of howdy does not exist."


# Generated at 2022-06-12 00:46:34.183487
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("test")
    except InvalidSettingsPath as e:
        message = e.args[0]
        assert "isort was told to use the settings_path: test as the base directory or" \
               "file that represents the starting point of config file discovery, but it" \
               "does not exist." == message
        assert "test" == e.settings_path


# Generated at 2022-06-12 00:46:37.538877
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """Tests the constructor of class UnsupportedEncoding"""
    error = UnsupportedEncoding('file_name')
    assert error.__str__() == "Unknown or unsupported encoding in file_name", error.__str__()

# Generated at 2022-06-12 00:46:46.327928
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    from isort.app import NotInSettings
    file_path = 'some_file_path.py'
    f = FileSkipSetting(file_path=file_path)
    assert(f.file_path == file_path)
    assert(str(f) == 'some_file_path.py was skipped as it\'s listed in \'skip\' setting or matches a glob in \'skip_glob\' setting')


# Generated at 2022-06-12 00:46:50.860778
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("file_pkg")
    except Exception as e:
        assert(e.__class__ == FormattingPluginDoesNotExist)

# Generated at 2022-06-12 00:46:56.836683
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with open("file.txt", "w", encoding="UTF-8") as f:
        f.write("In file.txt")
    err = UnsupportedEncoding(r"C:\Users\User\Desktop\Python_project\Python-Isort\file.txt")
    assert err.filename == r'C:\Users\User\Desktop\Python_project\Python-Isort\file.txt'

# Generated at 2022-06-12 00:46:59.914155
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("test").file_path == "test"

# Generated at 2022-06-12 00:47:09.817677
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    from isort._sorter import SortFailed
    from isort.settings import Config

    try:
        raise LiteralParsingFailure("invalid literal", SortFailed("'invalid literal'", 1, 0))
    except LiteralParsingFailure as e:
        assert str(e) == \
            "isort failed to parse the given literal 'invalid literal'. It's important to note " \
            "that isort literal sorting only supports simple literals parsable by " \
            "ast.literal_eval which gave the exception of 'invalid literal' (line number: 1, " \
            "column number: 0)."

# Generated at 2022-06-12 00:47:17.262350
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    class ProfileDoesNotExist(ISortError):
        """Raised when a profile is set by the user that doesn't exist"""

        def __init__(self, profile: str):
            super().__init__(
                f"Specified profile of {profile} does not exist. "
                f"Available profiles: {','.join(profiles)}."
            )
            self.profile = profile

    assert isinstance(ProfileDoesNotExist('test'), ISortError)



# Generated at 2022-06-12 00:47:20.546678
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/tmp")
    except InvalidSettingsPath as err:
        assert err.settings_path == "/tmp"



# Generated at 2022-06-12 00:47:21.572781
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except ISortError:
        assert True
    assert False


# Generated at 2022-06-12 00:47:24.674984
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    skipped_file_object=FileSkipped("message","file_path")

    assert skipped_file_object.message=="message"
    assert skipped_file_object.file_path=="file_path"

# Generated at 2022-06-12 00:47:25.601387
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting("FileName")

# Generated at 2022-06-12 00:47:34.973965
# Unit test for constructor of class MissingSection
def test_MissingSection():
    from isort import exceptions
    #
    # test_case 1
    import_module = "random"
    section = "PYTHON STDLIB"
    #
    ex = exceptions.MissingSection(import_module, section)
    assert str(ex) == f"Found {import_module} import while parsing, but {section} was not included " \
                      "in the `sections` setting of your config. Please add it before continuing\n" \
                      "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                      "for more info."
    assert ex.import_module == "random"
    assert ex.section == "PYTHON STDLIB"
    #
    # test_case 2
    import_module = "locale"
    section = "THIRDPARTY"

# Generated at 2022-06-12 00:47:37.330213
# Unit test for constructor of class ISortError
def test_ISortError():
  try:
    raise ISortError("error") 
  except ISortError as e:
    assert e.__str__() == "error"

# Generated at 2022-06-12 00:47:38.762777
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError().__str__() == ""


# Generated at 2022-06-12 00:47:50.366782
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit test for constructor of class UnsupportedSettings"""
    unsupported_settings = {
        "unsupported_option_1": {
            "value": "val",
            "source": "source"
        },
        "unsupported_option_2": {
            "value": "val",
            "source": "source"
        },
    }
    exception = UnsupportedSettings(unsupported_settings)
    assert exception.unsupported_settings == unsupported_settings

# Generated at 2022-06-12 00:48:00.768917
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    """
    isort introduced syntax errors when attempting to sort the imports contained within
    /Users/galith.mudith/Desktop/machiavelli-app/.isort.cfg.
    """
    err = IntroducedSyntaxErrors("/Users/galith.mudith/Desktop/machiavelli-app/.isort.cfg")
    assert str(err) == "isort introduced syntax errors when attempting to sort the imports contained " \
                       "within /Users/galith.mudith/Desktop/machiavelli-app/.isort.cfg."
    assert err.file_path == "/Users/galith.mudith/Desktop/machiavelli-app/.isort.cfg"


# Generated at 2022-06-12 00:48:04.132498
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fs = FileSkipSetting("test.py")
    assert fs.file_path == "test.py"
    assert fs.args == ("test.py was skipped as it's listed in 'skip' setting"
                       " or matches a glob in 'skip_glob' setting",)

# Generated at 2022-06-12 00:48:05.940740
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise ValueError(4)
    except ValueError as err:
        LiteralParsingFailure("", err)

# Generated at 2022-06-12 00:48:08.836947
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings({
        "bad_option": {"value": "value", "source": "source"},
    }).unsupported_settings == {
        "bad_option": {"value": "value", "source": "source"},
    }

# Generated at 2022-06-12 00:48:11.730046
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    x = ExistingSyntaxErrors('A')
    try:
        raise x
    except ISortError as e:
        assert str(x) == e.message


# Generated at 2022-06-12 00:48:14.076849
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'message'
    file_path = 'file_path'
    e = FileSkipped(message, file_path)
    assert e.message == message
    assert e.file_path == file_path