

# Generated at 2022-06-12 00:46:35.450424
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)  # type: ignore
    except LiteralSortTypeMismatch as e:
        assert isinstance(e, ISortError)
        assert e.kind == int
        assert e.expected_kind == str
        assert (
            str(e)
            == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>.\n"
        )
        raise e

# Generated at 2022-06-12 00:46:38.339030
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    exc = FormattingPluginDoesNotExist(formatter="my_formatter")
    assert str(exc) == "Specified formatting plugin of my_formatter does not exist. "

# Generated at 2022-06-12 00:46:43.097274
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'os'
    section = 'THIRDPARTY'
    myexc = MissingSection(import_module, section)
    assert myexc.import_module == import_module
    assert myexc.section == section

# Generated at 2022-06-12 00:46:44.520214
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    msg = "testing constructor"
    err = LiteralSortTypeMismatch(int, tuple)
    assert err.message == msg, "Wrong error message"


# Generated at 2022-06-12 00:46:46.110975
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors("error")
    assert err.file_path == "error"

# Generated at 2022-06-12 00:46:50.368152
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    a = LiteralSortTypeMismatch(1, 2)
    assert a.kind == 1
    assert a.expected_kind == 2

# Generated at 2022-06-12 00:46:52.252944
# Unit test for constructor of class ISortError
def test_ISortError():
    e = ISortError('test')
    assert e.args[0] == 'test'


# Generated at 2022-06-12 00:46:58.006067
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    from ast import literal_eval
    class test(Exception):
        pass
    data= "abcd"
    try:
        literal_eval(data)
    except Exception as err:
        obj=LiteralParsingFailure(data,err)
    assert obj.code == data
    assert obj.original_error == err


# Generated at 2022-06-12 00:47:00.764693
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("RenJie")
    except ProfileDoesNotExist as e:
        assert e.profile == "RenJie"


# Generated at 2022-06-12 00:47:02.386301
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('test')
    except Exception as ex:
        assert str(ex) == "Unknown or unsupported encoding in test"
        assert ex.filename == 'test'

# Generated at 2022-06-12 00:47:06.206895
# Unit test for constructor of class ISortError
def test_ISortError():
	try:
		raise ISortError("testing")
	except Exception as e:
		assert(str(e) == "testing")



# Generated at 2022-06-12 00:47:09.202419
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert 'isa' == 'isa'
    #assert InvalidSettingsPath('isa') ==  InvalidSettingsPath('isa')
    #assert InvalidSettingsPath('isa') !=  InvalidSettingsPath('isa2')
    #assert InvalidSettingsPath('isa').settings_path ==  'isa'

test_InvalidSettingsPath()

# Generated at 2022-06-12 00:47:21.055015
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # Test UnsupportedSettings initialization with one option
    option = {"name": "forced_separate", "value": "value of forced_separate", "source": "file"}
    setting = UnsupportedSettings({option["name"]: option})
    assert setting.unsupported_settings == {"forced_separate": option}
    # Test UnsupportedSettings initialization with more than one option
    setting = UnsupportedSettings(
        {
            "forced_separate": option,
            "combine_as_imports": {
                "name": "combine_as_imports",
                "value": "value of combine_as_imports",
                "source": "file",
            },
        }
    )

# Generated at 2022-06-12 00:47:25.979477
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    class Foo:
        pass

    class Bar:
        pass

    f = Foo()
    b = Bar()
    with pytest.raises(LiteralSortTypeMismatch, match = "isort was told to sort a literal of type .* but was given a literal of type .*."):
        LiteralSortTypeMismatch(type(f), type(b))

# Generated at 2022-06-12 00:47:31.247623
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"key": {"value": "value", "source": "source"}}
    try:
        raise UnsupportedSettings(unsupported_settings)
    except UnsupportedSettings as e:
        assert e.unsupported_settings == unsupported_settings
        assert "isort was provided settings that it doesn't support:" in str(e)
        assert "key = value  (source: 'source')" in str(e)

# Generated at 2022-06-12 00:47:36.151630
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class InvalidAst(Exception):
        pass

    try:
        raise InvalidAst()
    except Exception as e:
        exception = LiteralParsingFailure(code='', original_error=e)

    assert exception.code == ''
    assert exception.original_error.__class__.__name__ == 'InvalidAst'

# Generated at 2022-06-12 00:47:38.594364
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    a = LiteralSortTypeMismatch(kind=float, expected_kind=int)
    assert a.kind == float
    assert a.expected_kind == int

# Generated at 2022-06-12 00:47:40.063705
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("c:\\file.py")

# Generated at 2022-06-12 00:47:41.653040
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    LiteralSortTypeMismatch([], str)

# Generated at 2022-06-12 00:47:43.917908
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    err = InvalidSettingsPath('settings_path: str')
    assert err.settings_path=='settings_path: str'
