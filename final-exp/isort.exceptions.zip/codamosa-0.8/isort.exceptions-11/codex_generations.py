

# Generated at 2022-06-12 00:46:32.320774
# Unit test for constructor of class MissingSection
def test_MissingSection():
    with should_raise(MissingSection) as e:
        raise MissingSection("foo", "bar")
    assert e.import_module == "foo"
    assert e.section == "bar"

# Generated at 2022-06-12 00:46:35.362829
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("test")
    except AssignmentsFormatMismatch as e:
        assert e.code == "test"


# Generated at 2022-06-12 00:46:38.578389
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # FileSkipSetting should raise an error if file_path is not a valid path
    try:
        FileSkipSetting("./wrongpath/wrongfile.py")
        assert True
    except:
        assert False

# Generated at 2022-06-12 00:46:40.663963
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    encoding_error = UnsupportedEncoding("test1.py")
    assert encoding_error.filename == "test1.py"
    assert encoding_error.args[0] == "Unknown or unsupported encoding in test1.py"

# Generated at 2022-06-12 00:46:44.813635
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("file_path")
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within file_path."
        assert e.file_path == "file_path"
    else:
        assert False

# Generated at 2022-06-12 00:46:46.415711
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
	assert str(FileSkipComment("a/b.py")) == 'a/b.py contains an file skip comment and was skipped.'

# Generated at 2022-06-12 00:46:53.821912
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path="/Users/roopesh/Documents/code/isort/isort/main.py"
    file_skip_setting=FileSkipSetting(file_path)
    assert file_skip_setting.message==f"{file_path} was skipped as it's listed in 'skip' setting"
    assert file_skip_setting.file_path==file_path

# Generated at 2022-06-12 00:46:57.924232
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("file.txt")
    except UnsupportedEncoding as exception:
        assert exception.filename == "file.txt"
        assert str(exception) == "Unknown or unsupported encoding in file.txt"

# Generated at 2022-06-12 00:47:01.066258
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    expected_output = "test.txt was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting" 
    assert str(FileSkipSetting("test.txt")) == expected_output

# Generated at 2022-06-12 00:47:02.299493
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert isinstance(FileSkipSetting("test"), ISortError)


# Generated at 2022-06-12 00:47:05.928212
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    exc = InvalidSettingsPath("settings_path")
    assert exc.settings_path == "settings_path"


# Generated at 2022-06-12 00:47:07.370878
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors('test.py')
    assert(error.file_path == 'test.py')

# Generated at 2022-06-12 00:47:10.006169
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipComment("foo.py").file_path == "foo.py"


# Generated at 2022-06-12 00:47:14.414970
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
  try:
    raise UnsupportedEncoding("../Show-on-a-map/data/business.json")
  except UnsupportedEncoding as e:
    assert e.filename == "../Show-on-a-map/data/business.json"

# Generated at 2022-06-12 00:47:22.268595
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("flask", "FLASK")
    except MissingSection as e:
        assert isinstance(e, MissingSection)
        assert str(e) == "Found flask import while parsing, but FLASK was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        assert e.import_module == "flask"
        assert e.section == "FLASK"



# Generated at 2022-06-12 00:47:25.898702
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = 'no_such_file'
    try:
        raise UnsupportedEncoding(filename)
    except ISortError as e:
        assert e.args[0] == f"Unknown or unsupported encoding in {filename}"
        assert e.filename == filename


# Generated at 2022-06-12 00:47:32.706289
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings(): # type: ignore
    unsupported_settings = {'fake_option': {'value': 'true', 'source': 'fake_source'}}
    err = UnsupportedSettings(unsupported_settings)
    assert str(err) == "isort was provided settings that it doesn't support:\n\n\t- fake_option = " \
                       "true  (source: 'fake_source')\n\nFor a complete and up-to-date listing " \
                       "of supported settings see: https://pycqa.github.io/isort/docs/configuration/" \
                       "options/.\n"

# Generated at 2022-06-12 00:47:36.705566
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('hello.py')
    except IntroducedSyntaxErrors as err:
        msg = "isort introduced syntax errors when attempting to sort the imports contained within hello.py."
        assert err.args[0] == msg

# Generated at 2022-06-12 00:47:38.808994
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('Default')
    except FormattingPluginDoesNotExist:
        print('passed')

# Generated at 2022-06-12 00:47:42.213183
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    with pytest.raises(LiteralParsingFailure):
        isort.api.sort_imports("__future__", "from __future__ import braces")

