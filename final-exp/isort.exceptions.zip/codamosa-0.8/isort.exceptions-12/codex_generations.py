

# Generated at 2022-06-12 00:46:12.127123
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch()
    except AssignmentsFormatMismatch:
        pass
    except :
        raise Exception('AssignmentsFormatMismatch not raised')

if __name__ == '__main__':
    test_AssignmentsFormatMismatch()

# Generated at 2022-06-12 00:46:13.508176
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(str, int).kind == str
    assert LiteralSortTypeMismatch(str, int).expected_kind == int

# Generated at 2022-06-12 00:46:16.281731
# Unit test for constructor of class ISortError
def test_ISortError():
    exception_class: ISortError = ISortError("test")
    assert exception_class.message == "test"

# Generated at 2022-06-12 00:46:18.155860
# Unit test for constructor of class MissingSection
def test_MissingSection():
    with pytest.raises(MissingSection):
        raise MissingSection('tensorflow', 'THIRDPARTY')


# Generated at 2022-06-12 00:46:23.438362
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting(file_path="file_path")
    except ISortError as e:
        assert e.file_path == "file_path"
        assert str(e) == "file_path was skipped as it's listed in 'skip' setting " \
                         "or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-12 00:46:25.322312
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("test_file")
    assert FileSkipComment("test_file").file_path == "test_file"



# Generated at 2022-06-12 00:46:27.506666
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    message="Invalid syntax"
    file_path="example.py"
    IntroducedSyntaxErrors(message,file_path)

# Generated at 2022-06-12 00:46:34.636369
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("numpy", "third_party")
    except MissingSection as exception:
        assert exception.args[0] == (
            f"Found numpy import while parsing, but third_party was not included "
            "in the `sections` setting of your config. Please add it before continuing\n"
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
            "for more info."
        )



# Generated at 2022-06-12 00:46:37.622078
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("PyKafka2")
    except ProfileDoesNotExist as e:
        assert "PyKafka2" in str(e)

# Generated at 2022-06-12 00:46:40.870382
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'Skip this file'
    file_path = 'test_file'
    file_skipped = FileSkipped(message, file_path)
    assert file_skipped.file_path == file_path


# Generated at 2022-06-12 00:46:44.776470
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath) as error:
        raise InvalidSettingsPath("hi")
    assert error.value.settings_path == "hi"


# Generated at 2022-06-12 00:46:47.237335
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    obj = IntroducedSyntaxErrors('path')
    assert obj.file_path == 'path'
    assert str(obj) == 'isort introduced syntax errors when attempting to sort the imports contained within path.'

# Generated at 2022-06-12 00:46:52.107692
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert (
        str(LiteralSortTypeMismatch(Path(), str))
        == "isort was told to sort a literal of type <class 'str'> but was given a literal of "
        "type <class 'pathlib.PosixPath'>"
    )

# Generated at 2022-06-12 00:46:55.705708
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    class_instance = UnsupportedEncoding("filename")
    assert class_instance.filename == "filename"
    assert class_instance.message == "Unknown or unsupported encoding in filename"

# Generated at 2022-06-12 00:47:01.040595
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert LiteralParsingFailure("test", Exception("test")).code == "test"
    assert isinstance(LiteralParsingFailure("test", Exception("test")).original_error, Exception)


# Generated at 2022-06-12 00:47:03.056340
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    """Test FileSkipComment"""
    file_path = "simon_isort_test.py"
    FileSkipComment(file_path=file_path)

# Generated at 2022-06-12 00:47:06.872093
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    from ast import literal_eval

    try:
        literal_eval("(a, b)")
    except ValueError as error:
        exception = LiteralParsingFailure("(a, b)", error)
    assert str(exception) == LiteralParsingFailure.__doc__



# Generated at 2022-06-12 00:47:13.604843
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    bad_code = "goofy = 'you are so silly'\n"
    with pytest.raises(AssignmentsFormatMismatch) as excinfo:
        AssignmentsFormatMismatch(bad_code)
    expected_message = """isort was told to sort a section of assignments, however the given code:

    {bad_code}

Does not match isort's strict single line formatting requirement for assignment sorting:

    {variable_name} = {value}
    {variable_name2} = {value2}
    ...

""".format(
        bad_code=bad_code, variable_name="", value="", variable_name2=""
    )
    assert expected_message in str(excinfo.value)

# Generated at 2022-06-12 00:47:18.189032
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    obj = FileSkipSetting("test_FileSkipSetting.txt")
    assert obj.file_path == "test_FileSkipSetting.txt"
    assert obj.message == "test_FileSkipSetting.txt was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-12 00:47:20.074599
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(str, str).__str__()

# Generated at 2022-06-12 00:47:24.769888
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    encodingerror = UnsupportedEncoding(filename="test.py")
    assert encodingerror.filename == "test.py"
    assert encodingerror.args == ["Unknown or unsupported encoding in test.py"]
    return

# Generated at 2022-06-12 00:47:27.845065
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path="file_path"
    with pytest.raises(FileSkipSetting, match=file_path):
        raise FileSkipSetting(file_path)

# Generated at 2022-06-12 00:47:29.816684
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test_message")
    except FormattingPluginDoesNotExist as e:
        assert e.args == ("test_message",)
        assert e.formatter == "test_message"

# Generated at 2022-06-12 00:47:33.081208
# Unit test for constructor of class MissingSection
def test_MissingSection():
    message = "Found {import_module} import while parsing, but {section} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
    assert message == MissingSection.__init__.__doc__

# Generated at 2022-06-12 00:47:35.564451
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('example')
    except ISortError:
        pass


# Generated at 2022-06-12 00:47:40.064727
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "formatter"
    formatted_string = f"Specified formatting plugin of {formatter} does not exist. "
    exception = FormattingPluginDoesNotExist(formatter)
    assert(exception.formatter == formatter)
    assert(formatted_string == str(exception))


# Generated at 2022-06-12 00:47:48.425303
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"asd": {"value": "asd1", "source": "asd2"}}
    ex = UnsupportedSettings(unsupported_settings)
    assert ex.unsupported_settings == unsupported_settings
    assert (
        ex.args[0]
        == """isort was provided settings that it doesn't support:

	- asd = asd1  (source: 'asd2')

For a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.
"""
    )

# Generated at 2022-06-12 00:47:50.245959
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError:
        pass
    else:
        assert False



# Generated at 2022-06-12 00:47:53.038503
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors("Test_File.py")
    assert(err.file_path == "Test_File.py")
    assert(err.__str__() == "isort introduced syntax errors when attempting to sort the imports contained within Test_File.py.")


# Generated at 2022-06-12 00:47:59.208868
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    filename = "my_file.py"
    assert ISortError.__init__(
        FileSkipComment,
        # ISortError.__init__(self, message: str, file_path: str):
        f"{filename} contains an file skip comment and was skipped.",
        file_path=filename,
    ) == FileSkipComment(file_path=filename)

