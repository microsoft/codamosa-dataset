

# Generated at 2022-06-12 00:46:08.600949
# Unit test for constructor of class MissingSection
def test_MissingSection():
    message = "Found sys import while parsing, but THIRDPARTY was not included in the `sections` setting of your config. Please add it.\n"\
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
    try:
        raise MissingSection('sys','THIRDPARTY')
    except MissingSection as error:
        assert error.args[0] == message


# Generated at 2022-06-12 00:46:12.062892
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    fp = "../test/test-input/test_input/test.py"
    try:
        raise IntroducedSyntaxErrors(fp)
    except ISortError as e:
        assert e.file_path == fp
        assert e.__class__.__name__ == "IntroducedSyntaxErrors"



# Generated at 2022-06-12 00:46:12.990697
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    isort.errors.UnsupportedEncoding("test_filename")

# Generated at 2022-06-12 00:46:18.509680
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    # Arrange
    code = 'This is literal'
    original_error = ValueError('This is original error')

    # Act
    literal_parsing_failure = LiteralParsingFailure(code, original_error)

    # Assert
    assert literal_parsing_failure.code == code
    assert literal_parsing_failure.original_error == original_error

# Generated at 2022-06-12 00:46:28.626360
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(InvalidSettingsPath) as e:
        raise InvalidSettingsPath('invalid')
    with pytest.raises(ExistingSyntaxErrors) as e:
        raise ExistingSyntaxErrors('file_path')
    with pytest.raises(IntroducedSyntaxErrors) as e:
        raise IntroducedSyntaxErrors('file_path')
    with pytest.raises(FileSkipped) as e:
        raise FileSkipped('message','file_path')
    with pytest.raises(FileSkipComment) as e:
        raise FileSkipComment('file_path')
    with pytest.raises(FileSkipSetting) as e:
        raise FileSkipSetting('file_path')

# Generated at 2022-06-12 00:46:30.953899
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(dict, str)
    except LiteralSortTypeMismatch as e:
        assert str(e)


# Generated at 2022-06-12 00:46:35.363908
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        a = LiteralSortTypeMismatch(0, 1)
        raise Exception(a)
    except Exception as e:
        print(e)


# Generated at 2022-06-12 00:46:40.119959
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    expected_error = "Unknown or unsupported encoding in test_file"
    expected_filename = "test_file"
    try:
        raise UnsupportedEncoding("test_file")
    except UnsupportedEncoding as e:
        assert str(e) == expected_error
        assert e.filename == expected_filename

# Unit tests for the constructor of class InvalidSettingsPath

# Generated at 2022-06-12 00:46:44.212976
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = f"{__name__} contains an file skip comment and was skipped."
    file_path = __name__
    actual = FileSkipped(message, file_path)
    assert actual.file_path == file_path
    assert actual.args[0] == message


# Generated at 2022-06-12 00:46:47.029631
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert(FormattingPluginDoesNotExist("plugin") == FormattingPluginDoesNotExist("plugin"))
    assert(
        str(FormattingPluginDoesNotExist("plugin")) ==
        "Specified formatting plugin of plugin does not exist. "
    )

# Generated at 2022-06-12 00:46:56.147021
# Unit test for constructor of class ISortError
def test_ISortError():
    class ISortError_Test(ISortError):
        def __init__(self, param):
            super().__init__(param)
    assert ISortError_Test(param = 'param_test').__str__() == 'param_test'


# Generated at 2022-06-12 00:47:00.478590
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
   filename= "Test.txt"
   exception = UnsupportedEncoding(filename) 
   assert exception.filename == filename


# Generated at 2022-06-12 00:47:03.725536
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors) as exception_info:
        raise IntroducedSyntaxErrors('')
    assert str(exception_info.value) == "isort introduced syntax errors when attempting to sort the imports contained within ."


# Generated at 2022-06-12 00:47:04.963618
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist("Test")

# Generated at 2022-06-12 00:47:08.136951
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    from isort import FileSkipComment
    assert isinstance(FileSkipComment("abc.py"), FileSkipComment)
    assert FileSkipComment("abc.py").message == "abc.py contains an file skip comment and was skipped."
    assert FileSkipComment("abc.py").file_path == "abc.py"


# Generated at 2022-06-12 00:47:11.445566
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error = ValueError("invalid literal for int() with base 10: 'foo'")
    lpe = LiteralParsingFailure("foo", error)
    assert lpe.code == "foo"
    assert lpe.original_error == error


# Generated at 2022-06-12 00:47:14.708396
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("/foo/bar/baz.py").file_path == "/foo/bar/baz.py"

# Generated at 2022-06-12 00:47:22.182818
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=str, expected_kind=int)
    except LiteralSortTypeMismatch as e:
        assert e.kind is str
        assert e.expected_kind is int
        assert (
            e.__str__()
            == "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>."
        )
    # END try
# END test_LiteralSortTypeMismatch

# Generated at 2022-06-12 00:47:24.770256
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("file.py")
    except ISortError as e:
        assert "Unknown or unsupported encoding in file.py" in str(e)

# Generated at 2022-06-12 00:47:33.631478
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    from ast import literal_eval
    from isort.exceptions import LiteralParsingFailure
    from ast.types.parsed_literal import ParsedLiteral
    code = "[a, 1, {'a': 1}]"
    new_code = "[1, 2, 3, 4, 5]"
    code_failed = "";

# Generated at 2022-06-12 00:47:43.135158
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('abc')
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == 'abc'


# Generated at 2022-06-12 00:47:45.106015
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception = UnsupportedEncoding("filename")
    assert str(exception) == "Unknown or unsupported encoding in filename"

# Generated at 2022-06-12 00:47:49.574505
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    import pytest
    test_file_path = "test.py"
    with pytest.raises(FileSkipSetting) as excInfo:
        raise FileSkipSetting(test_file_path)
    assert excInfo.value.file_path == test_file_path

# Generated at 2022-06-12 00:47:51.141334
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError("ISortError").__str__() == "ISortError"


# Generated at 2022-06-12 00:47:55.647289
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'file.py'
    exception = FileSkipComment(file_path)
    assert exception.message == f'{file_path} contains an file skip comment and was skipped.'
    assert exception.file_path == file_path

# Generated at 2022-06-12 00:48:00.363423
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    e = LiteralSortTypeMismatch(str, dict)
    assert str(e) == "isort was told to sort a literal of type {expected_kind} but was given a literal of type {kind}."
    assert e.kind == str
    assert e.expected_kind == dict

# Generated at 2022-06-12 00:48:01.671562
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    error = FormattingPluginDoesNotExist('foo')
    assert error.formatter == 'foo'


# Generated at 2022-06-12 00:48:03.370689
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
	exc = ExistingSyntaxErrors("ciao")
	assert exc.file_path == "ciao"

# Generated at 2022-06-12 00:48:09.415697
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {'foo': {'value': 'bar', 'source': 'baz'}}
    e = UnsupportedSettings(settings)

    assert e.unsupported_settings == settings
    assert str(e) == (
        "isort was provided settings that it doesn't support:\n\n"
        "\t- foo = bar  (source: 'baz')\n\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )


# Generated at 2022-06-12 00:48:12.507610
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped('aaa', pathlib.Path('bbb'))
    except FileSkipped as e:
        assert e.message == 'aaa'
        assert e.file_path == pathlib.Path('bbb')
