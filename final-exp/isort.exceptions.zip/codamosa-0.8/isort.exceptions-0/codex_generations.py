

# Generated at 2022-06-12 00:46:32.320885
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting("test_file/test.py")



# Generated at 2022-06-12 00:46:34.231673
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding(filename="filename")
    assert error.filename == "filename"

# Generated at 2022-06-12 00:46:43.414923
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(
            """a = 1
b = 2
c = 3
d = 4""",
        )
    except AssignmentsFormatMismatch as e:
        e_str = e.__str__()
        assert (
            e_str
            == """isort was told to sort a section of assignments, however the given code:\n\n{}\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n""".format(
                """a = 1
b = 2
c = 3
d = 4""",
            )
        )

# Generated at 2022-06-12 00:46:48.057404
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():

    # Test string 1
    code1 = "a = 1\nb = 2\n"

    # Test string 2
    code2 = "a = 1\n b = 2\n"

    # Test string 3
    code3 = "a = 1\n\n b = 2\n"

    # Test string 4
    code4 = "a = 1\na = 2\n"

    # Test exceptional invocation
    testCases = [code1, code2, code3, code4]

    # Test if the constructor is working as expected
    def test_is_AssignmentsFormatMismatch_exception():

        # Call the constructor
        for code in testCases:
            with pytest.raises(AssignmentsFormatMismatch):
                isort.code(code, assignments=True)

    return test_is_Assign

# Generated at 2022-06-12 00:46:51.015758
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    instance = ExistingSyntaxErrors('sample.py')
    assert isinstance(instance, ISortError)
    assert isinstance(instance, ExistingSyntaxErrors)

# Generated at 2022-06-12 00:46:54.163980
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist) as e:
        raise ProfileDoesNotExist("TEST")
    assert e.value.profile == "TEST"

# Generated at 2022-06-12 00:46:55.709634
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch('')

# Generated at 2022-06-12 00:47:00.517001
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist(profile="not_exist")
    assert error.profile == "not_exist"


# Generated at 2022-06-12 00:47:01.485417
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert bool(ExistingSyntaxErrors("file_path"))


# Generated at 2022-06-12 00:47:09.772857
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        float('hello')
    except ValueError as exc:
        error = LiteralParsingFailure('hello', exc)

    assert error.code == 'hello'
    assert error.original_error.args[0] == 'could not convert string to float: \'hello\''
    assert error.__str__() == 'isort failed to parse the given literal hello. It\'s important to note ' \
                              'that isort literal sorting only supports simple literals parsable by ' \
                              'ast.literal_eval which gave the exception of could not convert string to float: ' \
                              '\'hello\'.'



# Generated at 2022-06-12 00:47:17.025616
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    """Unit test for constructor of class AssignmentsFormatMismatch"""
    code = "x = 1\n"
    actual = AssignmentsFormatMismatch(code)
    expected = AssignmentsFormatMismatch(code)
    assert actual.code == expected.code
    assert actual.message == expected.message

# Generated at 2022-06-12 00:47:18.284197
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("filename").filename == "filename"

# Generated at 2022-06-12 00:47:20.937097
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 1, b = 2"
    exception = AssignmentsFormatMismatch(code)
    assert exception.code == code


# Generated at 2022-06-12 00:47:23.921359
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors("foo.py")
    assert error.args[0] == "isort was told to sort imports within code that contains syntax " \
                            "errors: foo.py."



# Generated at 2022-06-12 00:47:24.988655
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings.__init__

# Generated at 2022-06-12 00:47:29.412996
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding('/path/to/file')
    assert error.filename == '/path/to/file'
    assert str(error) == "Unknown or unsupported encoding in /path/to/file"
    assert repr(error) == "UnsupportedEncoding('/path/to/file',)"

# Generated at 2022-06-12 00:47:31.978235
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'test_formatter'
    msg = f'Specified formatting plugin of {formatter} does not exist.'
    test_exception = FormattingPluginDoesNotExist(formatter)
    assert test_exception.formatter == formatter
    assert str(test_exception) == msg

# Generated at 2022-06-12 00:47:40.109060
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        1/0
    except Exception as e:
        test_object = LiteralParsingFailure("TestObject", e)
        assert str(test_object) == "isort failed to parse the given literal TestObject. " \
                                   "It's important to note that isort literal sorting only " \
                                   "supports simple literals parsable by ast.literal_eval " \
                                   "which gave the exception of division by zero."
        assert test_object.code == "TestObject"
        assert str(test_object.original_error) == "division by zero"

# Generated at 2022-06-12 00:47:42.625968
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("")
    except InvalidSettingsPath as error:
        assert error.settings_path == ""



# Generated at 2022-06-12 00:47:43.720674
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    encoding_instance = UnsupportedEncoding("badfile")
    assert hasattr(encoding_instance, "filename")
    assert encoding_instance.filename == "badfile"

# Generated at 2022-06-12 00:47:50.910481
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = '/home/username/isort.cfg'
    obj = InvalidSettingsPath(path)
    assert obj.settings_path == path
    assert str(obj) == 'isort was told to use the settings_path: /home/username/isort.cfg as the base directory or file that represents the starting point of config file discovery, but it does not exist.'


# Generated at 2022-06-12 00:47:53.703634
# Unit test for constructor of class ISortError
def test_ISortError():
    e = ISortError("MyError")
    assert e.args[0] == "MyError"

# Generated at 2022-06-12 00:47:56.448623
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("abc.txt")
    except InvalidSettingsPath as e:
        assert e.settings_path == "abc.txt"


# Generated at 2022-06-12 00:47:59.261666
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("")
    except UnsupportedEncoding as e:
        assert e.args == ("Unknown or unsupported encoding in ",)

# Generated at 2022-06-12 00:47:59.993594
# Unit test for constructor of class ISortError
def test_ISortError():
    ISortError()
    assert True

# Generated at 2022-06-12 00:48:01.781519
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch('test')
    except AssignmentsFormatMismatch as e:
        assert e.code == 'test'

# Generated at 2022-06-12 00:48:04.797260
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors("test").file_path == "test"
    assert ExistingSyntaxErrors("test").__str__() == "isort was told to sort imports within code that contains syntax errors: test."


# Generated at 2022-06-12 00:48:10.493910
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('MissingSection', 'MissingSection')
    except MissingSection as e:
        assert str(e) == (
            "Found MissingSection import while parsing, but MissingSection was not included "
            "in the `sections` setting of your config. Please add it before continuing\n"
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
            "for more info."
        )
        assert e.section == 'MissingSection'
        assert e.import_module == 'MissingSection'

test_MissingSection()

# Generated at 2022-06-12 00:48:19.217435
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    class Settings:
        """Settings to test the constructor"""

        def __init__(self, settings: Dict[str, Dict[str, str]]):
            self.settings = settings

        def items(self) -> Any:
            return self.settings.items()

    settings_dict = {
        "foo": {"name": "foo", "value": "bar", "source": "config"},
        "baz": {"name": "baz", "value": "quux", "source": "arguments"},
    }
    settings = Settings(settings_dict)
    try:
        UnsupportedSettings(settings)
    except UnsupportedSettings as exception:
        assert exception.unsupported_settings == settings_dict

# Generated at 2022-06-12 00:48:22.069669
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-12 00:48:31.295451
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("blah", ValueError)
    except LiteralParsingFailure as error:
        assert str(error) == (
            "isort failed to parse the given literal blah. It's important to note that isort "
            "literal sorting only supports simple literals parsable by ast.literal_eval which "
            "gave the exception of ValueError."
        )

# Generated at 2022-06-12 00:48:35.866242
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try: 
        raise MissingSection("test","test")
    except MissingSection as msg:
        assert msg.args[0] == "Found test import while parsing, but test was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."


# Generated at 2022-06-12 00:48:38.513738
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    # Arrange
    msg = "message"
    file_path = "file_path"

    # Act
    obj = FileSkipped(msg, file_path)

    # Assert
    assert obj.args[0] == msg
    assert obj.file_path == file_path



# Generated at 2022-06-12 00:48:47.207131
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('foobar')
    except ProfileDoesNotExist as e:
        assert str(e) == (
            "Specified profile of foobar does not exist. "
            "Available profiles: black, google, google-py3, pycharm, "
            "mypy, pytest, sphinx, travis, nano, pep8, py34, mccabe, vscode, "
            "py2, py27, py33, py35, py36, py37, py38, pydev, jython, "
            "jupyter, ipython, hacking, cloud, gfw, mkdocs, flake8"
        )
        assert e.profile == 'foobar'

# Generated at 2022-06-12 00:48:50.267063
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure(
            "['a',b][/]", Exception("Expected a dict or list literal, got str")
        )
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-12 00:48:51.964576
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    encoding_error = UnsupportedEncoding("File.py")
    assert repr(encoding_error) == "File.py"

# Generated at 2022-06-12 00:48:58.908747
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # TypeError is not defined, but the class is used in LiteralSortTypeMismatch,
    # so a dummy TypeError is needed in order to create the object
    class TypeError(Exception):
        """This is a dummy TypeError class for unit test."""

    test_data = [(str, TypeError), (str, TypeError)]

    for data in test_data:
        try:
            # Calling the constructor, since this should raise an exception
            # pylint: disable=unused-variable
            test_exception = LiteralSortTypeMismatch(data[0], data[1])
        except ISortError:

            # If we reach this point, the test succeeded
            return True

    # We shouldn't reach this point, so the test failed
    return False


# Generated at 2022-06-12 00:49:00.705619
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('test')
    except ISortError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 00:49:04.783840
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    options = {'implicit_namespaces': {'value': True, 'source': 'config'}}

    exception = UnsupportedSettings(unsupported_settings=options)
    assert exception.unsupported_settings == options
    assert isinstance(exception, ISortError)

# Generated at 2022-06-12 00:49:07.666117
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as exception:
        assert exception.import_module == "import_module"
        assert exception.section == "section"
