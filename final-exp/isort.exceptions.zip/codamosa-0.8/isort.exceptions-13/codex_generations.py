

# Generated at 2022-06-12 00:46:08.568963
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist('my_profile')
    assert error.profile == 'my_profile'

# Generated at 2022-06-12 00:46:14.388571
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """

    :return:
    """
    try:
        raise LiteralParsingFailure('3+3', ValueError)
    except LiteralParsingFailure as exception:
        assert str(exception) ==\
            "isort failed to parse the given literal 3+3. It's important to note that isort " \
            "literal sorting only supports simple literals parsable by ast.literal_eval which " \
            "gave the exception of invalid literal for int() with base 10: '3+3'."
        assert exception.code == '3+3'
        assert exception.original_error.args == ('invalid literal for int() with base 10: '
                                                 "'3+3'",)



# Generated at 2022-06-12 00:46:15.809134
# Unit test for constructor of class AssignmentsFormatMismatch

# Generated at 2022-06-12 00:46:21.245622
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(code="a=1, b=2")
    except ISortError as e:
        assert e.code == "a=1, b=2"
        assert str(e) == "isort was told to sort a section of assignments, however the given code:\n\n" \
                         "a=1, b=2\n\n" \
                         "Does not match isort's strict single line formatting requirement for assignment " \
                         "sorting:\n\n" \
                         "{variable_name} = {value}\n" \
                         "{variable_name2} = {value2}\n" \
                         "...\n\n"
    else:
        assert False

# Generated at 2022-06-12 00:46:24.731258
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "2 + 3"
    with pytest.raises(LiteralParsingFailure, match="isort failed"):
        raise LiteralParsingFailure(code, Exception("failed"))

# Generated at 2022-06-12 00:46:28.455371
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "test message"
    file_path = "test path"
    try:
        raise FileSkipped(message, file_path)
    except FileSkipped as e:
        assert e.message == message
        assert e.file_path == file_path

# Generated at 2022-06-12 00:46:30.579444
# Unit test for constructor of class ISortError
def test_ISortError():
    a = ISortError()
    assert str(a) == 'Base isort exception object from which all isort sourced exceptions should inherit'


# Generated at 2022-06-12 00:46:33.362017
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors
    except IntroducedSyntaxErrors as e:
        assert isinstance(e, IntroducedSyntaxErrors)

# Generated at 2022-06-12 00:46:35.408373
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("foobar")
    except ProfileDoesNotExist as e:
        assert e.profile == "foobar"

# Generated at 2022-06-12 00:46:39.848785
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """
    The constructor of class LiteralParsingFailure
    """
    code = '"test_LiteralParsingFailure"'
    original_error = "Error"
    exc1 = LiteralParsingFailure(code, original_error)
    assert exc1.code == code
    assert exc1.original_error == original_error


# Generated at 2022-06-12 00:46:43.299149
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    instance = LiteralSortTypeMismatch(dict, str)
    assert instance.kind == dict
    assert instance.expected_kind == str

# Unit tests for constructor of class AssignmentsFormatMismatch

# Generated at 2022-06-12 00:46:45.882169
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'myFormatter'
    symbol = ':'
    message = 'Formatter not found'
    e = FormattingPluginDoesNotExist(formatter)
    assert str(e) == message
    assert e.formatter == formatter

# Generated at 2022-06-12 00:46:49.874025
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    a = FormattingPluginDoesNotExist("abc")
    assert a.formatter == "abc"


# Generated at 2022-06-12 00:46:53.965216
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('formatPlugin')
    except FormattingPluginDoesNotExist as error:
        assert str(error) == "Specified formatting plugin of formatPlugin does not exist. "


# Generated at 2022-06-12 00:47:00.501233
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, list)
    except LiteralSortTypeMismatch as exception:
        assert exception.kind == str
        assert exception.expected_kind == list
        parsed_message = str(exception).split("\n")[0]
        assert parsed_message == "isort was told to sort a literal of type <class 'list'>" \
            " but was given a literal of type <class 'str'>"



# Generated at 2022-06-12 00:47:05.032824
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(FileSkipped) as excinfo:
        # Create the exception object
        FileSkipped("Test message", "testfile.txt")
    assert str(excinfo.value) == "Test message"
    assert excinfo.value.file_path == "testfile.txt"
    assert isinstance(excinfo.value, FileSkipped)


# Generated at 2022-06-12 00:47:06.169338
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    _ = FileSkipped("message", "file_path")


# Generated at 2022-06-12 00:47:08.336779
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist) as error:
        raise ProfileDoesNotExist('reorder_python_imports')
    assert error.value.profile == 'reorder_python_imports'

# Generated at 2022-06-12 00:47:10.828198
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    err = InvalidSettingsPath("invalid_settings_path")
    assert hasattr(err, 'settings_path')
    assert err.settings_path == "invalid_settings_path"


# Generated at 2022-06-12 00:47:14.121090
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    ISortError_obj = ProfileDoesNotExist("Google")
    assert ISortError_obj.profile == "Google"


# Generated at 2022-06-12 00:47:18.772231
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding('filename') is not None

# Generated at 2022-06-12 00:47:20.318161
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("filename")

# Generated at 2022-06-12 00:47:22.642078
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors("algogenetic.py")
    assert err.file_path == "algogenetic.py"

# Generated at 2022-06-12 00:47:31.892560
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    try:
        raise UnsupportedSettings(
            {"lazy_order_by_type": {"value": True, "source": "configuration"}}
        )
    except UnsupportedSettings as error:
        assert str(error) == (
            "isort was provided settings that it doesn't support:\n\n"
            "\t- lazy_order_by_type = True  (source: 'configuration')\n\n"
            "For a complete and up-to-date listing of supported settings see: "
            "https://pycqa.github.io/isort/docs/configuration/options/.\n"
        )
        assert error.unsupported_settings == {
            "lazy_order_by_type": {"value": True, "source": "configuration"}
        }

# Generated at 2022-06-12 00:47:33.963979
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        error = ISortError()
        assert issubclass(ISortError, Exception) is True
        assert isinstance(error, ISortError) is True
    except:
        print("Exception occurred while trying to create ISortError object")
        assert False


# Generated at 2022-06-12 00:47:36.622081
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath) as e:
        raise InvalidSettingsPath("test")
    assert e.value.settings_path == 'test'

# Generated at 2022-06-12 00:47:38.721966
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    test_case = ProfileDoesNotExist("test")
    assert test_case.profile == "test" == "test"


# Generated at 2022-06-12 00:47:42.497795
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    error = UnsupportedSettings({"foo": {"value": "bar", "source": "bang"}})
    assert error.unsupported_settings == {"foo": {"value": "bar", "source": "bang"}}

# Generated at 2022-06-12 00:47:52.324463
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assignment = 'x = "foo"'
    assignments = 'x = "foo", y = "bar"'

    # Test constructor with single assignment
    try:
        raise AssignmentsFormatMismatch(assignment)
    except AssignmentsFormatMismatch as e:
        assert assignment == e.code

    # Test constructor with more than one assignment
    try:
        raise AssignmentsFormatMismatch(assignments)
    except AssignmentsFormatMismatch as e:
        assert assignments == e.code

    # Test constructor with invalid input
    try:
        invalid_assignment = 'x = "foo"'
        raise AssignmentsFormatMismatch(invalid_assignment)
    except AssignmentsFormatMismatch as e:
        assert invalid_assignment != e.code

# Generated at 2022-06-12 00:47:54.150448
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError(0)