

# Generated at 2022-06-12 00:46:07.521668
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    plugin = FormattingPluginDoesNotExist('some_data')
    assert plugin.formatter == 'some_data'

# Generated at 2022-06-12 00:46:10.056347
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist) as excinfo:
        raise FormattingPluginDoesNotExist("Test")
    assert excinfo.value.formatter == "Test"

# Generated at 2022-06-12 00:46:11.451876
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors("thisFile")
    assert error.file_path == "thisFile"

# Generated at 2022-06-12 00:46:16.372888
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    # These values are only for readability
    expected_msg = (
        f"Found {import_module} import while parsing, but {section} was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info."
    )
    expected_import_module = "import_module"
    expected_section = "section"

    try:
        raise MissingSection(import_module, section)
    except MissingSection as e:
        assert str(e) == expected_msg
        assert e.import_module == expected_import_module
        assert e.section == expected_section

# Generated at 2022-06-12 00:46:18.413750
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    err = AssignmentsFormatMismatch("a = b\nc = d\n")
    assert err.code == "a = b\nc = d\n"

# Generated at 2022-06-12 00:46:20.385259
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(int, int)


# Generated at 2022-06-12 00:46:28.788858
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    path = "test_FileSkipSetting"
    try:
        raise FileSkipSetting(path)
    except FileSkipSetting as err:
        assert err.message == f"{path} was skipped as it's listed in 'skip' setting" \
            " or matches a glob in 'skip_glob' setting"
        assert err.file_path == path
    else:
        raise Exception("Exception not raised.")

# Generated at 2022-06-12 00:46:32.972259
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("META-INF/MANIFEST.MF", file_path="META-INF/MANIFEST.MF").message == "META-INF/MANIFEST.MF was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-12 00:46:36.296911
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('import_module', 'section')
    except MissingSection as e:
        assert e.import_module == 'import_module'
        assert e.section == 'section'

# Generated at 2022-06-12 00:46:38.423735
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter_obj = FormattingPluginDoesNotExist('formatter')
    assert formatter_obj.formatter == 'formatter'

# Generated at 2022-06-12 00:46:43.658695
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings({'known_standard_library': {'source': 'cli', 'value': 'public'}})



# Generated at 2022-06-12 00:46:48.713789
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Arrange
    profile = "foo"
    error_message = "Specified profile of foo does not exist. Available profiles: black, " \
                    "google, pep8, mccabe, pycharm, pycharm-defaults, vscode, bandit, vscode, " \
                    "flake8, hack, jupytext, yapf, " \
                    "jupyter, sphinx, tests."
    # Act
    error = ProfileDoesNotExist(profile)
    # Assert
    assert error.message == error_message
    assert error.profile == profile

# Generated at 2022-06-12 00:46:52.206203
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    import types
    myprofile = ProfileDoesNotExist('woohoo')
    assert type(myprofile) == types.InstanceType
    assert myprofile.profile == 'woohoo'

# Generated at 2022-06-12 00:46:59.180783
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert "Found import_module import while parsing, but section was not included " \
               "in the `sections` setting of your config. Please add it before continuing\n" \
               "See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info." == str(e)


# Generated at 2022-06-12 00:47:05.722756
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # Invalid code
    code = 'invalid_code'
    expected_error = f"isort was told to sort a section of assignments, however the given code:\n\n{code}\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert e.args[0] == expected_error

# Generated at 2022-06-12 00:47:08.012486
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    filename = "test.txt"
    with pytest.raises(FileSkipSetting) as excinfo:
        raise FileSkipSetting(file_path=filename)
    assert excinfo.value.file_path == filename

# Generated at 2022-06-12 00:47:10.464231
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("testfile")
    except FileSkipComment as e:
        assert e.file_path == "testfile"

# Generated at 2022-06-12 00:47:12.997070
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings(
        unsupported_settings={"name": "value", "name1": "value1"}
    )

# Generated at 2022-06-12 00:47:15.353197
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "foo"
    section = "bar"
    print(MissingSection(import_module, section))



# Generated at 2022-06-12 00:47:20.777557
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise SyntaxError("invalid syntax")
    except:
        syntax_error = SyntaxError("invalid syntax")
        error_obj = LiteralParsingFailure(code="code", original_error=syntax_error)
        assert error_obj.code == "code" and error_obj.original_error == syntax_error