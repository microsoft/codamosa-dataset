

# Generated at 2022-06-12 00:46:16.984578
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a b"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert e.code == code

# Generated at 2022-06-12 00:46:21.856913
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    exception = LiteralParsingFailure("my_code", Exception("my_original_error"))
    assert 'my_code' in exception.args
    assert 'my_original_error' in exception.args
    assert exception.code == 'my_code'
    assert exception.original_error.args[0] == 'my_original_error'

# Generated at 2022-06-12 00:46:24.614315
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('python')
    except ProfileDoesNotExist as e:
        pass
    else:
        assert False, 'ProfileDoesNotExist exception raised'

# Generated at 2022-06-12 00:46:29.743380
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    a = LiteralSortTypeMismatch(str, Dict)
    b = LiteralSortTypeMismatch(int, str)
    assert str(a) == "isort was told to sort a literal of type <class 'dict'> but was given a literal of type <class 'str'>.\n"
    assert str(b) == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>.\n"


# Generated at 2022-06-12 00:46:34.949143
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("test.py")
    except FileSkipSetting as err:
        assert str(err) == "test.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
        assert err.file_path == "test.py"
        assert isinstance(err.file_path, str)

# Generated at 2022-06-12 00:46:36.208917
# Unit test for constructor of class ISortError
def test_ISortError():
    assert str(ISortError()) == "ISortError"

# Generated at 2022-06-12 00:46:37.412623
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    e = FileSkipComment("File.py")

# Generated at 2022-06-12 00:46:44.087183
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    s = [
        ("nonsense_setting1", {"value": "nonsense1", "source": "nonsense_path1"}),
        ("nonsense_setting2", {"value": "nonsense2", "source": "nonsense_path2"}),
    ]
    d = UnsupportedSettings({s[0][0]: s[0][1], s[1][0]: s[1][1]})

# Generated at 2022-06-12 00:46:46.303425
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    check=IntroducedSyntaxErrors("test.py")
    assert isinstance(check, ISortError)
    assert isinstance(check, IntroducedSyntaxErrors)


# Generated at 2022-06-12 00:46:56.670066
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    error = AssignmentsFormatMismatch("testing")
    assert error.code == "testing"
    assert error.__str__() == "isort was told to sort a section of assignments, however the given code:\n\n"\
                              "testing\n\n"\
                              "Does not match isort's strict single line formatting requirement for assignment "\
                              "sorting:\n\n"\
                              "{variable_name} = {value}\n"\
                              "{variable_name2} = {value2}\n"\
                              "...\n\n"

# Generated at 2022-06-12 00:47:09.260225
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "blah": {
            "value": "blah",
            "source": "CLI",
        },
        "blah2": {
            "value": "blah2",
            "source": "Config",
        },
    }
    exception = UnsupportedSettings(unsupported_settings)
    assert exception.unsupported_settings == unsupported_settings
    assert str(exception).startswith("isort was provided settings that it doesn't support:\n\n")
    assert "blah" in str(exception)
    assert "blah2" in str(exception)
    assert "For a complete and up-to-date listing" in str(exception)


# Generated at 2022-06-12 00:47:21.096539
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # invalid constructor arguments
    assert UnsupportedSettings(None).message == 'isort was provided settings that it doesn\'t support:\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n'
    assert UnsupportedSettings(None).unsupported_settings is None
    assert UnsupportedSettings({}).message == 'isort was provided settings that it doesn\'t support:\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n'
    assert UnsupportedSettings({}).unsupported_settings == {}

    # all valid

# Generated at 2022-06-12 00:47:23.038604
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("invalid_settings_path").settings_path == "invalid_settings_path"


# Generated at 2022-06-12 00:47:28.415319
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = '/home/saraf/Desktop/hello'
    x = FileSkipSetting(file_path)
    assert x.message == '{} was skipped as it\'s listed in \'skip\' setting or ' \
                        'matches a glob in \'skip_glob\' setting'.format(file_path)
    assert x.file_path == file_path


# Generated at 2022-06-12 00:47:34.360580
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    class TestException:
        def __init__(self, kind, expected_kind):
            self.kind = kind
            self.expected_kind = expected_kind

    try:
        raise LiteralSortTypeMismatch(kind=1, expected_kind=2)
    except Exception as e:
        try:
            raise TestException(kind=1, expected_kind=2)
            assert False
        except TestException as test:
            assert e.kind == 1
            assert e.expected_kind == 2
            assert e.__str__() == test.__str__()
            assert str(e) == str(test)
            assert e.__class__ == test.__class__
            assert e.__class__ == LiteralSortTypeMismatch
            assert e.__repr__() == test.__repr__()

#

# Generated at 2022-06-12 00:47:37.452300
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    print(InvalidSettingsPath)
    print(InvalidSettingsPath.__mro__)
    print(InvalidSettingsPath.mro())
    print(InvalidSettingsPath.__bases__)
    assert True



# Generated at 2022-06-12 00:47:41.106041
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """Test constructor of UnsupportedEncoding class"""
    try:
        raise UnsupportedEncoding("abc.txt")
    except UnsupportedEncoding as e:
        assert e.filename == "abc.txt"

# Generated at 2022-06-12 00:47:44.221722
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    f = FileSkipComment(file_path="test/test_FileSkipComment.txt")
    assert str(f) == "test/test_FileSkipComment.txt contains an file skip comment and was skipped."

# Generated at 2022-06-12 00:47:46.762806
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    introduced_syntax_errors = IntroducedSyntaxErrors("introduced_syntax_errors")
    assert introduced_syntax_errors.file_path == "introduced_syntax_errors"

# Generated at 2022-06-12 00:47:50.572085
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    message = "Specified formatting plugin of {formatter} does not exist."
    assert message == f"{message}. ".rstrip('.')
    assert message == FormattingPluginDoesNotExist("wrap_length").__str__()