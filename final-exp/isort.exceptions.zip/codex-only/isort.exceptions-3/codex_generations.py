

# Generated at 2022-06-23 20:12:30.435938
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError.__init__.__doc__ == "Base isort exception object from which all isort sourced exceptions should inherit"

# Generated at 2022-06-23 20:12:34.892825
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    from isort.exceptions import FileSkipped
    test = FileSkipped("test failed", "test.py")
    assert test.message == "test failed"
    assert test.file_path == "test.py"


# Generated at 2022-06-23 20:12:37.285659
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test_FileSkipComment.py"
    exception = FileSkipComment(file_path)
    assert exception.file_path == file_path


# Generated at 2022-06-23 20:12:42.173220
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, tuple)
    except LiteralSortTypeMismatch as e:
        assert isinstance(e, ISortError)
        assert e.kind == str
        assert e.expected_kind == tuple



# Generated at 2022-06-23 20:12:43.537651
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError("HI")

# Generated at 2022-06-23 20:12:47.516108
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors(file_path="tests/test_errors.py")
    except ExistingSyntaxErrors as inst:
        assert inst.file_path == "tests/test_errors.py"

# Generated at 2022-06-23 20:12:53.496354
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "variable1, variable2 = 1, 2"
    error = AssignmentsFormatMismatch(code)

    assert (str)(error) == "isort was told to sort a section of assignments, however the given code:\n\n" + code + "\n\n" + "Does not match isort's strict single line formatting requirement for assignment sorting:\n\n" + "{variable_name} = {value}\n" + "{variable_name2} = {value2}\n" + "...\n\n"

    assert error.code == code


# Generated at 2022-06-23 20:12:55.685613
# Unit test for constructor of class ISortError
def test_ISortError():
  # pylint: disable=missing-docstring
  try:
    ISortError()
  except ISortError:
    print("Inside the Exception handler")
  finally:
    print("Finally block executed")

# Generated at 2022-06-23 20:12:57.226470
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({'a': 'b'})



# Generated at 2022-06-23 20:13:01.530257
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    # test default value
    with pytest.raises(FileSkipped) as fs:
        raise FileSkipped("msg", "file_path")
    assert str(fs.value) == "msg"
    assert fs.value.file_path == "file_path"

test_FileSkipped()

# Generated at 2022-06-23 20:13:05.251012
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_path"
    file_skipped = FileSkipSetting(file_path)
    assert file_skipped.file_path == file_path
    assert file_skipped.message == ("test_path was skipped as it's listed in 'skip' setting"
                                    " or matches a glob in 'skip_glob' setting")

# Generated at 2022-06-23 20:13:11.533769
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    """Test constructor of class ProfileDoesNotExist"""
    profile = "test"
    profile_does_not_exist = ProfileDoesNotExist(profile)
    assert profile_does_not_exist.profile == profile
    assert (
        profile_does_not_exist.__str__()
        == f"Specified profile of test does not exist. "
        f"Available profiles: {','.join(profiles)}"
    )

# Generated at 2022-06-23 20:13:14.048266
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors("a")
    assert str(err) == "isort introduced syntax errors when attempting to sort the imports contained within a."
    assert err.file_path == "a"


# Generated at 2022-06-23 20:13:21.205346
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise Exception()
    except Exception as e:
        try:
            raise LiteralParsingFailure(code='', original_error=e)
        except LiteralParsingFailure as c:
            assert c.code == ''
            assert c.original_error == e
            assert str(c) == (
                "isort failed to parse the given literal . It's important to note "
                "that isort literal sorting only supports simple literals parsable by "
                "ast.literal_eval which gave the exception of Exception()."
            )

# Generated at 2022-06-23 20:13:22.723922
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped.__name__ == "FileSkipped"

# Generated at 2022-06-23 20:13:23.745466
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError("exception")


# Generated at 2022-06-23 20:13:27.658620
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    f = FileSkipSetting(file_path="test_file.py")
    assert f.file_path == "test_file.py"
    assert f.message == "test_file.py was skipped as it's listed in 'skip' setting " \
        "or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:13:34.157313
# Unit test for constructor of class MissingSection

# Generated at 2022-06-23 20:13:36.320798
# Unit test for constructor of class ISortError
def test_ISortError():
    """Unit test for constructor of class ISortError"""
    try:
        raise ISortError()
    except ISortError:
        pass



# Generated at 2022-06-23 20:13:40.862702
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    instance = FileSkipSetting("/home/some/dir/foo.py")
    assert instance.file_path == '/home/some/dir/foo.py'
    assert instance.message == "/home/some/dir/foo.py was skipped as it's listed in 'skip' setting" \
                               " or matches a glob in 'skip_glob' setting"



# Generated at 2022-06-23 20:13:42.206201
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as exc:
        assert exc.profile == "test"
        assert isinstance(exc, ISortError)


# Generated at 2022-06-23 20:13:45.760368
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fileskipped = FileSkipped("", "")
    assert fileskipped.file_path == ""


# Generated at 2022-06-23 20:13:50.793322
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # Test attribute: message
    message = "this is a test message"
    file_path = "test_path"
    obj = FileSkipComment(file_path)
    assert isinstance(obj, Exception)
    assert obj.message == f"{file_path} contains an file skip comment and was skipped."
    # Test attribute: file_path
    assert obj.file_path == file_path



# Generated at 2022-06-23 20:13:54.958411
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "foo"
    msg = "Specified formatting plugin of " + formatter + " does not exist. "
    exception = FormattingPluginDoesNotExist(formatter)
    assert (str(exception) == msg)


# Generated at 2022-06-23 20:13:57.256343
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-23 20:14:00.320054
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    filePath = "/Users/jeff/Library/Preferences/PyCharmCE2019.3/scratches/file.py"
    ee = ExistingSyntaxErrors(filePath)
    assert ee.file_path == filePath

# Generated at 2022-06-23 20:14:03.484141
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("first.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "first.py"
    else:
        assert False

# Generated at 2022-06-23 20:14:04.351190
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assert AssignmentsFormatMismatch.__init__

# Generated at 2022-06-23 20:14:06.786457
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("foo.py")
    except FileSkipped as e:
        assert e.file_path == "foo.py"

# Generated at 2022-06-23 20:14:10.257299
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch('a', 'b')
    except LiteralSortTypeMismatch as e:
        assert(e.kind == 'a')
        assert(e.expected_kind == 'b')

test_LiteralSortTypeMismatch()

# Generated at 2022-06-23 20:14:13.307393
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('./settings_path/')
    except Exception as error:
        assert(error.file_path== './settings_path/')


# Generated at 2022-06-23 20:14:17.085290
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist(formatter="No_Formatter")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of No_Formatter does not exist. "
        assert e.formatter == "No_Formatter"



# Generated at 2022-06-23 20:14:23.031091
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    path = 'test/file/path'
    result = FileSkipSetting(path)
    assert result.file_path == path
    assert str(result) == f"{path} was skipped as it's listed in 'skip' setting " \
                          f"or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:14:25.432528
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = "test"
    invalid_settings_path = InvalidSettingsPath(path)
    assert invalid_settings_path.settings_path == path


# Generated at 2022-06-23 20:14:33.320120
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a=b\nc=d\n e=f")
    except AssignmentsFormatMismatch as e:
        assert str(e) == (
            "isort was told to sort a section of assignments, however the given code:\n\n"
            "a=b\nc=d\n e=f\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n"
        )
        assert e.code == "a=b\nc=d\n e=f"

# Generated at 2022-06-23 20:14:39.731778
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest.raises(AssignmentsFormatMismatch) as exception:
        raise AssignmentsFormatMismatch("this is a single line")
    assert str(exception.value) == """isort was told to sort a section of assignments, however the given code:\n\nthis is a single line\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"""


# Generated at 2022-06-23 20:14:43.918389
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("./file_path")
    except FileSkipComment as e:
        assert e.file_path == "./file_path"
        assert str(e) == "./file_path contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:14:46.326651
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    exception = FileSkipped("message", "path")
    assert "message" == exception.args[0]
    assert "path" == exception.file_path



# Generated at 2022-06-23 20:14:51.135053
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "foo"
    section = "bar"
    msg = f"Found {import_module} import while parsing, but {section} was not included "
    msg += "in the `sections` setting of your config. Please add it before continuing\n"
    msg += "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
    msg += "for more info."
    assert msg == str(MissingSection(import_module, section))



# Generated at 2022-06-23 20:14:55.672878
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('test')
    except ProfileDoesNotExist as e:
        assert str(e) == "Specified profile of test does not exist. Available profiles: black,pep8,google,facebook,pycharm,pylint,test,test_pypackaging,default,doc8,makefile,appveyor,travis,mypy,twine."

# Generated at 2022-06-23 20:14:59.644996
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist("py3")


# Generated at 2022-06-23 20:15:02.319362
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors(file_path="foo.bar")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "foo.bar"

# Generated at 2022-06-23 20:15:07.684438
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    str1 = "isort was told to sort imports within code that contains syntax errors:"
    str2 = "/home/sokrates/Code/github/exjobb/isort/isort/tests/main_tests/test.py"
    str = str1 + " " + str2 + "."
    err = ExistingSyntaxErrors(str2)
    assert(str == err.__str__())

# Generated at 2022-06-23 20:15:10.470731
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = "./"
    class_object = FileSkipComment(path)
    assert class_object.message == f"{path} contains an file skip comment and was skipped."
    assert class_object.file_path == path

# Generated at 2022-06-23 20:15:15.276332
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = '["a", "b", "c"]'
    original_error = Exception("exception message")
    exception = LiteralParsingFailure(code=code, original_error=original_error)
    assert exception.code == '["a", "b", "c"]'
    assert exception.original_error == Exception("exception message")
    assert str(exception) == "isort failed to parse the given literal ['a', 'b', 'c']. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of exception message."


# Generated at 2022-06-23 20:15:17.559307
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(FileSkipped):
        raise FileSkipped()

# Generated at 2022-06-23 20:15:27.606031
# Unit test for constructor of class ISortError
def test_ISortError():
    import pytest
    from types import TracebackType

    # object ISortError correctness
    class TestError0(ISortError):
        pass
    err0 = TestError0()
    assert err0.__class__ == TestError0  # type: ignore
    assert err0.args == ()
    assert err0.__str__() is None  # type: ignore
    assert err0.__repr__() is None  # type: ignore
    assert err0.__traceback__ is None  # type: ignore
    with pytest.raises(TestError0):
        raise err0

    class TestError1(ISortError):
        def __init__(self, msg: str):
            super().__init__()
            self.msg = msg

    err1 = TestError1("err_msg")
    assert err1.msg

# Generated at 2022-06-23 20:15:37.705972
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
  try:
    raise AssignmentsFormatMismatch("(1 and False) or True")
  except AssignmentsFormatMismatch as e:
    assert str(e) == (
        "isort was told to sort a section of assignments, however the given code:\n\n"
        "(1 and False) or True\n\n"
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
    )

# Generated at 2022-06-23 20:15:42.117947
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    message = "isort was told to sort a literal of type int but was given a literal of type str."
    obj = LiteralSortTypeMismatch(kind=str, expected_kind=int)
    assert obj.args[0] == message


# Generated at 2022-06-23 20:15:44.974364
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as error:
        assert str(error) == "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>."

# Generated at 2022-06-23 20:15:47.636504
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "test"
    exception = FormattingPluginDoesNotExist(formatter)
    assert exception.formatter == formatter

# Generated at 2022-06-23 20:15:52.660230
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    """Unit test for constructor of class IntroducedSyntaxErrors"""
    file_path = "test_input/file_with_introduced_syntax_errors.py"

    er = IntroducedSyntaxErrors(file_path)
    assert isinstance(er, ISortError)
    assert er.file_path == file_path
    assert isinstance(er.args, tuple)
    assert len(er.args) == 1
    assert er.args[0] == (
        f"isort introduced syntax errors when attempting to sort the imports contained within "
        f"{file_path}."
    )

    return



# Generated at 2022-06-23 20:15:58.830422
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "foo/bar/something/to/skip.py"

    try:
        raise FileSkipComment(file_path=file_path)
    except FileSkipComment as ex:
        assert str(ex) == f"{file_path} contains an file skip comment and was skipped."
        assert ex.file_path == file_path
    else:
        assert False, "This should not happen!"


# Generated at 2022-06-23 20:16:08.094861
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    class1 = AssignmentsFormatMismatch("a = 1\nx*y")
    assert str(class1) == ("isort was told to sort a section of assignments, however the given code:\n\n"
            "a = 1\nx*y\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n")
    assert class1.code == "a = 1\nx*y"


# Generated at 2022-06-23 20:16:10.689670
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert e.import_module == "import_module"
        assert e.section == "section"



# Generated at 2022-06-23 20:16:15.495054
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("temp.py")
    except FileSkipSetting as e:
        assert e.message == "temp.py was skipped as it's listed in 'skip' setting" \
            " or matches a glob in 'skip_glob' setting"
        assert e.file_path == "temp.py"
    else:
        assert False

# Generated at 2022-06-23 20:16:18.380189
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'formatter'
    instance = FormattingPluginDoesNotExist(formatter)
    assert isinstance(instance, ISortError)
    assert instance.formatter == formatter


# Generated at 2022-06-23 20:16:19.320579
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    IntroducedSyntaxErrors("test.py")

# Generated at 2022-06-23 20:16:22.168353
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test.txt")
    except IntroducedSyntaxErrors as error:
        assert error.file_path == "test.txt"



# Generated at 2022-06-23 20:16:25.751745
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    new_object = LiteralSortTypeMismatch(str, int)
    assert new_object.kind == str
    assert new_object.expected_kind == int



# Generated at 2022-06-23 20:16:29.250913
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'This is message'
    file_path = 'path/to/file'

    file_skipped = FileSkipped(message, file_path)
    assert file_skipped.message == message
    assert file_skipped.file_path == file_path


# Generated at 2022-06-23 20:16:30.766379
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    a = AssignmentsFormatMismatch("p")
    assert a.code == "p"

# Generated at 2022-06-23 20:16:33.709779
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    tfs = FileSkipped('message', 'file_path')
    assert tfs.message == "message"
    assert tfs.file_path == "file_path"

# Generated at 2022-06-23 20:16:35.684252
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assert hasattr(AssignmentsFormatMismatch, "__init__")
    assert callable(AssignmentsFormatMismatch.__init__)


# Generated at 2022-06-23 20:16:37.607522
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception = IntroducedSyntaxErrors('file_path')
    assert exception.file_path == 'file_path'

# Generated at 2022-06-23 20:16:39.671400
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test/test_test.py")
    except IntroducedSyntaxErrors as e:
        assert str(e.file_path) == "test/test_test.py"



# Generated at 2022-06-23 20:16:43.723371
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(
            "line 1\nline 2\nline 3\nline 4\nline 5\nline 6\nline 7\nline 8\n"
            "line 9\nline 10\nline 11\nline 12\nline 13\nline 14\n"
        )
    except AssignmentsFormatMismatch:
        pass



# Generated at 2022-06-23 20:16:48.968745
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("testing/test.py")
    except UnsupportedEncoding as e:
        assert str(e) == "Unknown or unsupported encoding in testing/test.py"
        assert e.filename == "testing/test.py"
    else:
        assert False

# Generated at 2022-06-23 20:16:55.056224
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'test_class_FileSkipSetting'
    try:
        raise FileSkipSetting(file_path)
    except FileSkipped as e:
        assert e.file_path == file_path
        assert str(e) == f"{file_path} was skipped as it's listed in 'skip' setting" \
            " or matches a glob in 'skip_glob' setting"
    except:
        assert False

# Generated at 2022-06-23 20:17:00.402679
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('test')
    except FormattingPluginDoesNotExist as e:
        assert str(e) == 'Specified formatting plugin of test does not exist. '
        assert e.formatter == 'test'



# Generated at 2022-06-23 20:17:03.400210
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    error = FileSkipped('message', 'file_path')
    assert error.message == 'message'
    assert error.file_path == 'file_path'



# Generated at 2022-06-23 20:17:06.666306
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "message"
    file_path = "file_path"
    e = FileSkipped(message, file_path)
    assert e.file_path == file_path
    assert str(e) == message



# Generated at 2022-06-23 20:17:09.094124
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    f = FileSkipped("Cannot import this file", "file_skip.py")
    assert f.message == "Cannot import this file"
    assert f.file_path == "file_skip.py"



# Generated at 2022-06-23 20:17:14.101556
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("six", "THIRDPARTY")
    except MissingSection as ex:
        assert ex.import_module == "six"
        assert ex.section == "THIRDPARTY"
        assert str(ex) == (
            "Found six import while parsing, but THIRDPARTY was not included in the "
            "`sections` setting of your config. Please add it before continuing\n"
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        )


# Generated at 2022-06-23 20:17:21.195302
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("Profile1")
    except ProfileDoesNotExist as e:
        assert e.profile == "Profile1"
        assert profiles != None
        msg = "The available profiles can be found at " + "https://github.com/timothycrosley/isort/tree/master/isort/profiles"
        assert msg in str(e)
    else:
        assert False, 'Exception was not raised'

# Generated at 2022-06-23 20:17:24.652757
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("This exception is raised when isort is told to sort imports "
                                   "within code that has existing syntax errors.")
    except ExistingSyntaxErrors:
        assert 1
    else:
        assert 0



# Generated at 2022-06-23 20:17:26.556453
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    result = ProfileDoesNotExist("deprecated-profile")
    assert result.profile == "deprecated-profile"



# Generated at 2022-06-23 20:17:29.845362
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Make instance of ProfileDoesNotExist
    profile = 'foo'
    p = ProfileDoesNotExist(profile)

    # Assert instance attributes
    assert p.profile == profile
    assert str(p) == f"Specified profile of foo does not exist. Available profiles: black,pyup."


# Generated at 2022-06-23 20:17:33.984594
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    from .importsort import UnsupportedEncoding
    with open('filename.txt', 'wb') as file:
        file.write(b'\xFF')
    try:
        UnsupportedEncoding('filename.txt')
    finally:
        f.close()

# Generated at 2022-06-23 20:17:35.907714
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():

    d = {'unsupported_settings': {'test': {'value': 'test', 'source': 'test'}}}
    UnsupportedSettings(**d)

# Generated at 2022-06-23 20:17:38.445233
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError:
        return True
    else:
        return False

# Generated at 2022-06-23 20:17:39.248603
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    LiteralSortTypeMismatch(45, str)

# Generated at 2022-06-23 20:17:42.467951
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("test_path")
    except InvalidSettingsPath as err:
        assert err.settings_path == "test_path"


# Generated at 2022-06-23 20:17:44.113132
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped(message="message", file_path="file_path")


# Generated at 2022-06-23 20:17:46.378965
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    """Test constructor"""
    formatter = "test/test"
    error = FormattingPluginDoesNotExist(formatter)
    assert error.formatter == formatter

# Generated at 2022-06-23 20:17:49.523208
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "Raised when an entire file is skipped due to provided isort settings"
    file_path = "skipped"
    file = FileSkipped(message, file_path)
    assert file.message == message
    assert file.file_path == file_path

# Generated at 2022-06-23 20:17:56.368224
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error = LiteralParsingFailure(
        "syntax error",
        InvalidSettingsPath(settings_path="/Users/zainkhalid/isort"),
    )
    assert error.args == (
        "isort failed to parse the given literal syntax error. It's important to note that isort "
        "literal sorting only supports simple literals parsable by ast.literal_eval which gave "
        "the exception of /Users/zainkhalid/isort does not exist.",
    )
    assert isinstance(error.code, str)
    assert isinstance(error.original_error, InvalidSettingsPath)
    assert error.code == "syntax error"
    assert error.original_error.settings_path == "/Users/zainkhalid/isort"



# Generated at 2022-06-23 20:18:02.772386
# Unit test for constructor of class MissingSection
def test_MissingSection():
    test_section = 'VARIABLES'
    test_import_module = 'astropy.table'
    test_obj = MissingSection(test_import_module, test_section)
    test_str = "Found " + test_import_module + " import while parsing, but " + \
        test_section + " was not included in the `sections` setting of your config. "
    assert str(test_obj).startswith(test_str)

# Generated at 2022-06-23 20:18:06.763661
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("File is skipped.", "a.py")
    except FileSkipped as e:
        assert "File is skipped." == e.args[0]
        assert "a.py" == e.file_path

# Generated at 2022-06-23 20:18:08.402261
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise(FormattingPluginDoesNotExist('test'))
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-23 20:18:13.627400
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # pylint: disable=W0212
    exception = ProfileDoesNotExist('profile')
    assert str(exception) == 'Specified profile of profile does not exist. ' \
                             'Available profiles: black,black-straight,google,pep8,pycharm,vscode.'
    assert exception.profile == 'profile'

# Generated at 2022-06-23 20:18:19.120946
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch( str, int )
    except Exception as e:
        assert( isinstance(e, ISortError))
        assert( str(e)=="isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>.")
        assert( e.kind==str )
        assert( e.expected_kind==int )


# Generated at 2022-06-23 20:18:23.135207
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    expected = """isort was told to sort a literal of type <class 'str'> but was given 
a literal of type <class 'dict'>."""
    error = LiteralSortTypeMismatch({}, "")
    assert str(error) == expected

# Generated at 2022-06-23 20:18:27.855411
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    """
    Unit test for constructor of class FileSkipSetting
    """
    obj = FileSkipSetting("foo.py")
    assert obj.args[0] == "foo.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert obj.file_path == "foo.py"

# Generated at 2022-06-23 20:18:34.773857
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"avoided_classes": {"value": "x, y", "source": "config"}}
    exception = UnsupportedSettings(unsupported_settings)
    message = 'isort was provided settings that it doesn\'t support:\n\n\t- avoided_classes = x, y  (source: \'config\')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.'
    assert exception.unsupported_settings == unsupported_settings
    assert exception.__str__() == message

# Generated at 2022-06-23 20:18:40.207815
# Unit test for constructor of class ISortError
def test_ISortError():
    e = ISortError("hello world", arg1=3, arg2=4, arg3=5)
    assert str(e) == "hello world"
    assert e.args == ("hello world",)
    assert e.__getattribute__("arg1") == 3
    assert e.__getattribute__("arg2") == 4
    assert e.__getattribute__("arg3") == 5

# Generated at 2022-06-23 20:18:41.458191
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped("Message", "path")

# Generated at 2022-06-23 20:18:44.476665
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert LiteralParsingFailure('', ValueError).original_error == ValueError
    assert LiteralParsingFailure('', ValueError).code == ''



# Generated at 2022-06-23 20:18:50.689345
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure('a', Exception('Test Exception'))
    except LiteralParsingFailure as e:
        assert isinstance(e, LiteralParsingFailure)
        assert str(e) == "isort failed to parse the given literal a. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of Test Exception."
        assert e.code == 'a'
        assert isinstance(e.original_error, Exception)
        assert str(e.original_error) == 'Test Exception'

# Test for constructor of class UnsupportedSettings

# Generated at 2022-06-23 20:18:53.979593
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    construct_err = FileSkipComment("src")
    assert construct_err.message == "src contains an file skip comment and was skipped."
    assert construct_err.file_path == "src"


# Generated at 2022-06-23 20:18:55.693821
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment('__init__.py').file_path == '__init__.py'

# Generated at 2022-06-23 20:18:59.867828
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    s = UnsupportedSettings({ 'MISSING_OPTION': { 'value': 'unrecognized', 'source': 'passed to CLI' }})
    assert(s.unsupported_settings == {'MISSING_OPTION': {'value': 'unrecognized', 'source': 'passed to CLI'}})


# Generated at 2022-06-23 20:19:01.722459
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("test").message == "test contains an file skip comment and was skipped."
    assert FileSkipComment("test").file_path == "test"


# Generated at 2022-06-23 20:19:07.137827
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    err = FileSkipSetting("settings.py")

    assert isinstance(err, ISortError)
    assert isinstance(err, FileSkipped)
    assert str(err) == "settings.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert err.file_path == "settings.py"

# Generated at 2022-06-23 20:19:10.340742
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('foo')
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within foo."
        assert e.file_path == 'foo'


# Generated at 2022-06-23 20:19:14.012822
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/william/Documents/")
        assert False
    except Exception as e:
        assert e.settings_path == "/home/william/Documents/"

# Generated at 2022-06-23 20:19:15.224460
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors('test_file').file_path == 'test_file'

# Generated at 2022-06-23 20:19:22.872086
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    str = "This is a string"
    int = 1
    float = 1.0
    list = [1, 2, 3, 4, 5]
    dict = {1: 1, 2: 2}
    tuple = (1, 2, 3, 4, 5)

    assert str.__class__ == 'str'.__class__

# Generated at 2022-06-23 20:19:32.673654
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    import ast

    # [class: LiteralParsingFailure]
    # [method: __init__(self, code: str, original_error: Exception) -> None]
    # [import ast]
    # [assertLiteralParsingFailure(code: str, original_error: Exception) -> None]
    def assertLiteralParsingFailure(code: str, original_error: Exception):
        error = LiteralParsingFailure(code, original_error)
        assert error.code == code
        assert error.original_error == original_error

    # [assertLiteralParsingFailure('1b', ValueError('invalid literal for int() with base 10: '1b''))]

# Generated at 2022-06-23 20:19:34.755849
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception = UnsupportedEncoding("test")
    assert exception.filename == "test"



# Generated at 2022-06-23 20:19:38.987355
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():

    try:
        raises(LiteralSortTypeMismatch(int, str))
    except ISortError as e:
        assert str(e) == (
            "isort was told to sort a literal of type <class 'str'> but was given "
            "a literal of type <class 'int'>.\n"
        )
        assert e.kind is int
        assert e.expected_kind is str


# Generated at 2022-06-23 20:19:39.917475
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment('test_file')


# Generated at 2022-06-23 20:19:40.877247
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("some path")



# Generated at 2022-06-23 20:19:43.713368
# Unit test for constructor of class ISortError
def test_ISortError():
    pass


# Generated at 2022-06-23 20:19:45.006884
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError


# Generated at 2022-06-23 20:19:48.496417
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(Exception) as FileSkipped:
        assert FileSkipped.__init__.__doc__
        assert FileSkipped.__init__.__name__
        assert FileSkipped.__init__.__call__(FileSkipped)

# Generated at 2022-06-23 20:19:49.519391
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding('filename')

# Generated at 2022-06-23 20:19:53.390318
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """ Unit test for instance creation of class LiteralSortTypeMismatch """
    # Arrange
    kind = str
    expected_kind = int

    # Act
    instance = LiteralSortTypeMismatch(kind, expected_kind)

    # Assert
    assert instance is not None
    assert instance.kind is kind
    assert instance.expected_kind is expected_kind

# Generated at 2022-06-23 20:19:54.414820
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file = FileSkipSetting("test")
    assert file.file_path == "test"

# Generated at 2022-06-23 20:19:57.380621
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    
    def fn():
        raise LiteralSortTypeMismatch("str","str")

    assert fn() == ISortError


# Generated at 2022-06-23 20:19:59.924640
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        # Note: this line is required to be sufficient coverage
        # Warning: This is not a valid line
        raise ISortError()
    except ISortError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:20:02.639184
# Unit test for constructor of class MissingSection
def test_MissingSection():
    with pytest.raises(MissingSection) as excinfo:
        raise MissingSection('import_module', 'section')
    assert excinfo.value.import_module == 'import_module'
    assert excinfo.value.section == 'section'

# Generated at 2022-06-23 20:20:04.272086
# Unit test for constructor of class ISortError
def test_ISortError():
    test_error = ISortError("test error message")
    assert test_error.__str__() == "test error message"



# Generated at 2022-06-23 20:20:06.848424
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    from .sort_imports import handle_skip_file_comment
    from .settings import Config
    sorted_imports = handle_skip_file_comment("f.py", Config({"skip": True}, ""), "")
    assert sorted_imports == None

# Generated at 2022-06-23 20:20:14.920570
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """
    Test for class UnsupportedSettings.

    See https://github.com/timothycrosley/isort/pull/1275/pullrequest/detail.
    """

    exception = UnsupportedSettings({
        "unsupported": {
            "description": "This settings is not supported.",
            "source": "config",
        }
    })

    # Check exception message
    assert str(exception) == (
        "isort was provided settings that it doesn't support:\n\n"
        "\t- unsupported = {'description': 'This settings is not supported.', 'source': 'config'}  (source: 'config')\n\n"
        "For a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )

# Generated at 2022-06-23 20:20:16.157413
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("Test\n")
    except ISortError as ise:
        assert str(ise) == "Test\n"

# Generated at 2022-06-23 20:20:17.534183
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch('a = 1\nb = 2')

# Generated at 2022-06-23 20:20:20.734317
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    error = UnsupportedSettings({"force_adds": {"value": "", "source": "CLI"}})
    assert error.unsupported_settings == {"force_adds": {"value": "", "source": "CLI"}}

# Generated at 2022-06-23 20:20:23.364739
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped('test', 'file')
    except FileSkipped as exc:
        assert exc.message == 'test'
        assert exc.file_path == 'file'



# Generated at 2022-06-23 20:20:24.114594
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    pass

# Generated at 2022-06-23 20:20:26.823880
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception = IntroducedSyntaxErrors("test")
    assert exception.file_path == "test"
    assert exception.args[0] == "isort introduced syntax errors when attempting to sort the imports contained within test."


# Generated at 2022-06-23 20:20:32.294559
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/test")
    except Exception as ex:
        assert ex.__str__() == "isort was told to use the settings_path: /home/test as the base " \
            "directory or file that represents the starting point of config file discovery, but " \
            "it does not exist."
        assert ex.settings_path == "/home/test"
    finally:
        pass


# Generated at 2022-06-23 20:20:34.009084
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert isinstance(FormattingPluginDoesNotExist("formatter"), FormattingPluginDoesNotExist)



# Generated at 2022-06-23 20:20:35.777731
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath):
        path = "nonexisting"
        raise InvalidSettingsPath(path)


# Generated at 2022-06-23 20:20:37.817108
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "file_path"
    error = FileSkipSetting(file_path)
    assert error.file_path == file_path

# Generated at 2022-06-23 20:20:41.861758
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'failed to run'
    file_path = 'failed to run'
    a = FileSkipped(message, file_path)
    assert a.message == message
    assert a.file_path == file_path
    assert str(a) == message
    return

# Generated at 2022-06-23 20:20:48.993834
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    ac = AssignmentsFormatMismatch("  var1 =  1\n var2 = 2")
    assert ac.code == "  var1 =  1\n var2 = 2"
    assert str(ac) == ("isort was told to sort a section of assignments, however the given code:\n\n"
                       "  var1 =  1\n var2 = 2\n\n"
                       "Does not match isort's strict single line formatting requirement for assignment sorting:\n\n"
                       "{variable_name} = {value}\n"
                       "{variable_name2} = {value2}\n"
                       "...\n\n")

# Generated at 2022-06-23 20:20:50.504633
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "path")
    except FileSkipped as err:
        assert err.message == "message"
        assert err.file_path == "path"

# Generated at 2022-06-23 20:20:57.905186
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "skipped_file.py"
    expected_message = f"{file_path} was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    exception = FileSkipSetting(file_path)
    assert str(exception) == expected_message
    assert exception.file_path == file_path


# Generated at 2022-06-23 20:21:02.019589
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        file_path = f"{isort}/test/test_introduced_syntax_errors.py"
        raise IntroducedSyntaxErrors(file_path)
    except IntroducedSyntaxErrors as err:
        assert err.file_path == file_path

# Generated at 2022-06-23 20:21:06.198530
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    err = ExistingSyntaxErrors("./example.py")

    assert repr(err) == "ExistingSyntaxErrors('./example.py')"
    assert str(err) == ("isort was told to sort imports within code that contains syntax errors: "
                        "./example.py.")
    assert err.file_path == "./example.py"


# Generated at 2022-06-23 20:21:07.035636
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("filepath") == IntroducedSyntaxErrors("filepath")

# Generated at 2022-06-23 20:21:08.307967
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    test_FileSkipComment = FileSkipComment(file_path = "")
    assert test_FileSkipComment.file_path == ""


# Generated at 2022-06-23 20:21:17.492181
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    setting = {
        'foo': 'bar',
        'baz': 'qux',
    }
    source = {
        'foo': 'bar',
        'baz': 'qux',
    }
    errors = "\n".join(
        UnsupportedSettings._format_option(name, **option)
        for name, option in setting.items()
    )
    assert errors == "\t- foo = bar  (source: 'bar')\n\t- baz = qux  (source: 'qux')"



# Generated at 2022-06-23 20:21:18.536277
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    a=FileSkipped()

# Generated at 2022-06-23 20:21:22.430291
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("file").file_path == "file"
    assert FileSkipComment("file").args[0] == "file contains an file skip comment and was skipped."
    assert FileSkipComment("file").__class__.__name__ == "FileSkipComment"

# Generated at 2022-06-23 20:21:24.325813
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("test message", "test/path").__str__() == "test message"

# Generated at 2022-06-23 20:21:26.054944
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    x = UnsupportedEncoding("test")
    assert x.filename == "test"

# Generated at 2022-06-23 20:21:27.278125
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    filename = "test.py"
    test = ExistingSyntaxErrors(filename)
    assert test.file_path == filename

# Generated at 2022-06-23 20:21:33.381607
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = os.path.abspath("/usr/")
    err = FileSkipSetting(file_path)
    # test for exception message
    assert err.file_path == file_path
    assert str(err) == f"{file_path} was skipped as it's listed in 'skip' setting" \
                       " or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-23 20:21:36.644544
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        UnsupportedEncoding('C:\\Users\\Administrator\\Desktop\\isort-temp\\test.txt')
        assert True
    except:
        assert False

# Generated at 2022-06-23 20:21:40.096719
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    exception_instance = LiteralParsingFailure('code', ValueError())
    assert exception_instance.code == 'code'
    assert isinstance(exception_instance.original_error, ValueError)


# Generated at 2022-06-23 20:21:41.197220
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist('bla')

# Generated at 2022-06-23 20:21:45.588889
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("abc", "abc")
    except MissingSection as e:
        assert isinstance(e, MissingSection)
        assert hasattr(e, "import_module"), "MissingSection missing required field 'import_module'"
        assert hasattr(e, "section"), "MissingSection missing required field 'section'"


# Generated at 2022-06-23 20:21:48.750734
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors("File.py")
    assert str(error) == "isort was told to sort imports within code that contains syntax errors: File.py."
    assert error.file_path == "File.py"


# Generated at 2022-06-23 20:21:54.719821
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    from collections import namedtuple
    from unittest.mock import MagicMock

    log = MagicMock()
    result = namedtuple("result", "skipped")

    msg = "skipped: ['requirements.txt'] (skipped setting)"

    log_result = log(msg)
    result.skipped = ["requirements.txt"]

    log_result.skipped.assert_called_once()
    assert result.skipped == ["requirements.txt"]

# Generated at 2022-06-23 20:22:00.040592
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors('File1.py')
    except ExistingSyntaxErrors as e:
        #print(f'Error name is {e.__class__.__name__}')
        assert hasattr(e,'file_path')
        assert hasattr(e,'__str__')
test_ExistingSyntaxErrors()


# Generated at 2022-06-23 20:22:01.948593
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist(profile="fake")
    try:
        raise ProfileDoesNotExist(profile="fake")
    except ProfileDoesNotExist as e:
        assert e.profile == "fake"

# Generated at 2022-06-23 20:22:04.949801
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise NameError
    except NameError as ex:
        lpf = LiteralParsingFailure("code", ex)
        assert lpf.code == "code"
        assert lpf.original_error is ex


# Generated at 2022-06-23 20:22:07.554941
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert str(IntroducedSyntaxErrors("/path/to/file.py")) == (
        "isort introduced syntax errors when attempting to sort the "
        "imports contained within /path/to/file.py."
    )

# Generated at 2022-06-23 20:22:12.729204
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as missing_section:
        assert str(missing_section) == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        assert missing_section.import_module == "import_module"
        assert missing_section.section == "section"


# Generated at 2022-06-23 20:22:18.402442
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    # When the formatting plugin does not exist
    formatter = "tester"
    try:
        # Then an error message should be raised
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as err:
        assert err.formatter == formatter
        assert str(err) == "Specified formatting plugin of tester does not exist. "


# Generated at 2022-06-23 20:22:22.476175
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure(code = 'a:b:c:1', original_error = 'blah')
    except LiteralParsingFailure as e:
        assert e.code == 'a:b:c:1'
        assert e.original_error == 'blah'



# Generated at 2022-06-23 20:22:29.382013
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class MyError(Exception):
        pass
    try:
        raise MyError("I'm your error")
    except MyError as my_error:
        try:
            raise LiteralParsingFailure("I'm your code", my_error)
        except LiteralParsingFailure as my_literal_parsing_failure:
            assert type(my_literal_parsing_failure.original_error) == type(my_error)
            assert my_literal_parsing_failure.code == "I'm your code"
