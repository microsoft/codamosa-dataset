

# Generated at 2022-06-23 20:12:35.397062
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist(profile="arbitrary_profile")
    except ProfileDoesNotExist as error:
        assert error.profile == "arbitrary_profile"
        assert "Specified profile of arbitrary_profile does not exist" in str(error)

# Generated at 2022-06-23 20:12:38.361946
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # pylint: disable=unused-variable
    (name, formatter, source) = ('name', 'formatter', 'source')
    UnsupportedSettings({'foo': {'name': name, 'formatter': formatter, 'source': source}})

# Generated at 2022-06-23 20:12:40.782449
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert (IntroducedSyntaxErrors('a').__str__() == 'isort introduced syntax errors when attempting to sort the imports contained within a.')


# Generated at 2022-06-23 20:12:43.504275
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # file_path = '/etc/passwd'
    try:
        raise InvalidSettingsPath('/etc/passwd')
    except InvalidSettingsPath as err:
        print('File error:', str(err))
    

# Generated at 2022-06-23 20:12:49.168415
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("x = 1; y = 2;")
    except AssignmentsFormatMismatch as e:
        assert "isort was told to sort a section of assignments" in str(e)
        assert "x = 1; y = 2;" in str(e)
        assert "does not match isort's strict single line formatting requirement" in str(e)


# Generated at 2022-06-23 20:12:53.476447
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    err = FileSkipComment("/home/hien/PythonProjects/isort/isort.py")
    assert str(err) == ("/home/hien/PythonProjects/isort/isort.py "
                        "contains an file skip comment and was skipped.")

# Generated at 2022-06-23 20:13:00.889851
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    new_ExistingSyntaxErrors = ExistingSyntaxErrors(
        "/home/mike/PycharmProjects/isort/tests/section/assignment/multi_as_single"
    )
    assert str(new_ExistingSyntaxErrors) == (
        "/home/mike/PycharmProjects/isort/tests/section/assignment/multi_as_single: "
        "ExistingSyntaxErrors: isort was told to sort imports within code that contains syntax "
        "errors: /home/mike/PycharmProjects/isort/tests/section/assignment/multi_as_single."
    )
    asser

# Generated at 2022-06-23 20:13:05.003070
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """Test code for constructor of class LiteralSortTypeMismatch"""
    instance = LiteralSortTypeMismatch(int, float)
    assert str(instance) == "isort was told to sort a literal of type <class 'float'> but was given a literal of type <class 'int'>"
    assert instance.kind == int
    assert instance.expected_kind == float

# Generated at 2022-06-23 20:13:07.967170
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    ex = ExistingSyntaxErrors('file_path')
    assert ex.file_path == 'file_path'


# Generated at 2022-06-23 20:13:09.518089
# Unit test for constructor of class ISortError
def test_ISortError():
    assert isinstance(ISortError(), ISortError)



# Generated at 2022-06-23 20:13:11.414615
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("file.py").message == "isort introduced syntax errors when attempting to sort the imports contained within file.py."

# Generated at 2022-06-23 20:13:12.542043
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors("test").file_path == "test"

# Generated at 2022-06-23 20:13:13.207700
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    LiteralSortTypeMismatch(3, 5)

# Generated at 2022-06-23 20:13:15.679588
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    exception = ExistingSyntaxErrors('file_path')
    assert exception.__str__() == "isort was told to sort imports within code that contains syntax errors: file_path."
    assert exception.file_path == 'file_path'


# Generated at 2022-06-23 20:13:18.059339
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    error = FormattingPluginDoesNotExist("formatter")
    assert str(error) == "Specified formatting plugin of formatter does not exist. "
    assert error.formatter == "formatter"


# Generated at 2022-06-23 20:13:19.600291
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = 'some_profile'
    error = ProfileDoesNotExist(profile)
    assert error.profile == profile

# Generated at 2022-06-23 20:13:24.373020
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist) as e_info:
        raise ProfileDoesNotExist("my_profile")
    assert e_info.value.profile == "my_profile"
    assert isinstance(e_info.value.profile, str)

# Generated at 2022-06-23 20:13:26.413718
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(1, 2).kind == 1 and LiteralSortTypeMismatch(1, 2).expected_kind == 2

# Generated at 2022-06-23 20:13:29.410490
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors) as err_info:
        raise IntroducedSyntaxErrors('test.py')
    assert err_info.value.file_path == 'test.py'


# Generated at 2022-06-23 20:13:34.257214
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch) as e:
        raise LiteralSortTypeMismatch(kind=tuple, expected_kind=dict)
    assert e.value.kind == tuple
    assert e.value.expected_kind == dict


# Generated at 2022-06-23 20:13:37.976884
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("util.py")
    except FileSkipSetting as e:
        assert e.__str__() == '''util.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting'''

# Generated at 2022-06-23 20:13:47.161192
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    msg = "Raised when isort is told to sort imports within code that has existing syntax errors"
    file_path = "test.py"
    try:
        raise ExistingSyntaxErrors(file_path)
    except ExistingSyntaxErrors as e:
        assert isinstance(e.args[0], str)
        assert e.args[0] == msg
    else:
        assert False
    try:
        raise ExistingSyntaxErrors(file_path) from None
    except ExistingSyntaxErrors as e:
        assert isinstance(e.args[0], str)
        assert e.args[0] == msg
    else:
        assert False

# Generated at 2022-06-23 20:13:49.200158
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = FormattingPluginDoesNotExist("formatter")
    assert formatter.formatter == "formatter"


# Generated at 2022-06-23 20:13:52.719854
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class Dummy(Exception):
        pass
    i = LiteralParsingFailure("test", Dummy())
    assert i.code == "test"
    assert isinstance(i.original_error, Dummy)



# Generated at 2022-06-23 20:13:55.818528
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    this = InvalidSettingsPath("/this/is/a/path")

    assert this.settings_path == "/this/is/a/path"


# Generated at 2022-06-23 20:13:58.377148
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    a_str = 'a_str'
    error = InvalidSettingsPath(a_str)
    assert error.settings_path == a_str


# Generated at 2022-06-23 20:14:08.041270
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """To avoid printing the error message directly, we can test the class by checking if the
    error message is built correctly, which reflect the information in the dict passed into the
    class constructor.
    """
    dict_test = {
        "variable_one": {"value": "first", "source": "config"},
        "variable_two": {"value": "second", "source": "runtime"},
    }
    error = UnsupportedSettings(dict_test)

# Generated at 2022-06-23 20:14:15.179376
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """Unit test for constructor of class LiteralSortTypeMismatch

    Args:
        kind (type): the type of the literal provided in the code.
        expected_kind (type): the type of the literal that isort was told to sort.
        code (str): the code that isort failed to parse.
        original_error (Exception): the original exception that isort failed with.
    """


if __name__ == "__main__":
    test_LiteralSortTypeMismatch()

# Generated at 2022-06-23 20:14:19.341088
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest.raises(AssignmentsFormatMismatch):
        raise AssignmentsFormatMismatch(
            "v1 = 1\nv2 = 2\n" "v3 = 3, v4 = 4\n" "\n" "v5 = 5\n" "v6 = 6\n"
        )



# Generated at 2022-06-23 20:14:21.541090
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    actual_exception_message = str(FormattingPluginDoesNotExist("abc"))
    expected_message = "Specified formatting plugin of abc does not exist. "
    assert actual_exception_message == expected_message

# Generated at 2022-06-23 20:14:25.243833
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = '/home/john/settings.cfg'
    settings_path = InvalidSettingsPath(path)
    assert settings_path.settings_path == path


# Generated at 2022-06-23 20:14:28.543993
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('test')
    except UnsupportedEncoding as error:
        assert error.filename == 'test'


# Generated at 2022-06-23 20:14:31.690671
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting('test')
        assert False
    except Exception as e:
        assert str(e) == "test was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-23 20:14:34.194301
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('Test')
    except IntroducedSyntaxErrors:
        pass



# Generated at 2022-06-23 20:14:38.104177
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("bad_file.py")
    except ISortError as err:
        assert str(err) == "isort introduced syntax errors when attempting to sort the imports contained within bad_file.py."
    else:
        raise AssertionError("Failed to raise introduced syntax error")

# Generated at 2022-06-23 20:14:45.780513
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    
    tempfilename = "test_UnsupportedEncoding.py"
    with open(tempfilename, 'w', encoding='utf-8') as file:
        file.write("# -*- coding: utf-8 -*-")

    unsuppenc = "ute-8"
    with open(tempfilename, 'w', encoding=unsuppenc) as file:
        file.write("# -*- coding: utf-8 -*-")
        assert UnsupportedEncoding(filename=tempfilename).filename == tempfilename
        assert UnsupportedEncoding(filename=tempfilename).filename == tempfilename

# Generated at 2022-06-23 20:14:49.833589
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    e = TypeError('example error')
    with pytest.raises(ISortError):
        raise LiteralParsingFailure('[1,2,3]', e)



# Generated at 2022-06-23 20:14:52.962973
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = 'PATH'
    try:
        raise InvalidSettingsPath(path)
    except InvalidSettingsPath as e:
        assert e.settings_path == path


# Generated at 2022-06-23 20:15:00.949777
# Unit test for constructor of class ProfileDoesNotExist

# Generated at 2022-06-23 20:15:01.848691
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    InvalidSettingsPath('asdf')
    

# Generated at 2022-06-23 20:15:05.607139
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("Error", "file")
    except FileSkipped as exception:
        assert "Error" == exception.args[0]
        assert "file" == exception.file_path
        assert "Error in file" == str(exception)

# Generated at 2022-06-23 20:15:08.984365
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment('test.py')
    except FileSkipComment as e:
        # Skip the first line which contains the timestamp and test the exception message
        assert str(e).split('\n', 1)[1] == (
            "test.py contains an file skip comment and was skipped."
        )

# Generated at 2022-06-23 20:15:10.563443
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist('mypy')



# Generated at 2022-06-23 20:15:13.309464
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("wrong_formatter")
    except FormattingPluginDoesNotExist as err:
        assert str(err) == "Specified formatting plugin of wrong_formatter does not exist. "
        assert err.formatter == "wrong_formatter"

# Generated at 2022-06-23 20:15:22.943445
# Unit test for constructor of class MissingSection
def test_MissingSection():
    """
        Tests the constructor of class MissingSection
        Returns:
            True -- if the constructor works properly
    """
    try:
        e = MissingSection("import_module", "section")
        if (str(e) == 'Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.' and
            type(e).__name__ == "MissingSection"):
            return True
        else:
            return False
    except:
        return False


# Generated at 2022-06-23 20:15:27.324064
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path = "./isort"
    try:
        raise InvalidSettingsPath(settings_path)
    except InvalidSettingsPath as exception:
        assert (
            str(exception) == "isort was told to use the settings_path: ./isort as the base directory or "
            "file that represents the starting point of config file discovery, but it does not "
            "exist."
        )
        assert (
            exception.settings_path == "./isort"
        )  # Check the attribute settings_path has been correctly set



# Generated at 2022-06-23 20:15:34.820788
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    message = "Specified formatting plugin of {formatter} does not exist. "
    formatter = 'test'
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as e:
        assert e.message == message.format(formatter=formatter)
        assert e.formatter == formatter

test_FormattingPluginDoesNotExist()

# Generated at 2022-06-23 20:15:41.779999
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({})
    UnsupportedSettings({"legacy_sort": {"value": "True", "source": "config"}})
    UnsupportedSettings({"imports": {"value": "True", "source": "config"}})
    UnsupportedSettings({"black_line_length": {"value": "120", "source": "config"}})
    UnsupportedSettings(
        {"imports": {"value": "True", "source": "config"}, "legacy_sort": {"value": "True", "source": "command"}}
    )

# Generated at 2022-06-23 20:15:43.470467
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as inst:
        assert inst.formatter == "test"


# Generated at 2022-06-23 20:15:46.397340
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment.__init__.__annotations__['file_path'] == str


# Generated at 2022-06-23 20:15:52.104643
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    import_error = FileSkipComment("/path/to/skipped/file/skipped_file.py")
    assert import_error.message == "/path/to/skipped/file/skipped_file.py contains an file skip comment and was skipped."
    assert import_error.file_path == "/path/to/skipped/file/skipped_file.py"


# Generated at 2022-06-23 20:15:56.085009
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist(formatter="reorganize_imports")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "reorganize_imports"

# Generated at 2022-06-23 20:15:59.333321
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_does_not_exist_obj: ProfileDoesNotExist = ProfileDoesNotExist('abc')
    assert profile_does_not_exist_obj.profile == 'abc'



# Generated at 2022-06-23 20:16:02.822746
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "six"
    form = FormattingPluginDoesNotExist(formatter)
    assert form.formatter == formatter

# Generated at 2022-06-23 20:16:04.285055
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    e = ProfileDoesNotExist('foo')
    assert e.profile == 'foo'

# Generated at 2022-06-23 20:16:09.627552
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "tests"
    section = "FUTURE"

    assert MissingSection(import_module, section).args == (
        "Found tests import while parsing, but FUTURE was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info.",
    )

# Generated at 2022-06-23 20:16:10.231545
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({})

# Generated at 2022-06-23 20:16:13.833953
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = "test_files/test.py"
    message = "message"
    error = FileSkipped(message, file_path)
    assert error.message == message
    assert error.file_path == file_path

# Generated at 2022-06-23 20:16:17.201731
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("data", "Exception")
    except LiteralParsingFailure as e:
        assert e.code == "data"
        assert e.original_error == "Exception"


# Generated at 2022-06-23 20:16:19.521022
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "./isort/file_skip_comment.py"
    raise FileSkipComment(file_path=file_path)


# Generated at 2022-06-23 20:16:21.226606
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("filename").filename == "filename"


# Generated at 2022-06-23 20:16:24.980858
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    exception = FileSkipSetting('file_path')

    # check the exception message
    assert exception.message == (
        "file_path was skipped as it's listed in 'skip' setting"
        " or matches a glob in 'skip_glob' setting"
    )

    # check the exception file_path
    assert exception.file_path == 'file_path'



# Generated at 2022-06-23 20:16:36.920009
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    exception = AssignmentsFormatMismatch(
        code="some_var = 'value'\nsome_var2 = 'value2'  # comment"
    )
    assert exception.code == "some_var = 'value'\nsome_var2 = 'value2'  # comment"
    assert str(exception) == (
        "isort was told to sort a section of assignments, however the given code:\n\n"
        "some_var = 'value'\nsome_var2 = 'value2'  # comment\n\n"
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
    )


# Generated at 2022-06-23 20:16:39.629336
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding('abc')
    assert error.filename == 'abc'

    path = Path('abc')
    error = UnsupportedEncoding(path)
    assert error.filename == 'abc'

# Generated at 2022-06-23 20:16:42.255442
# Unit test for constructor of class MissingSection
def test_MissingSection():
    _ = MissingSection(import_module="m", section="s")
    assert _.args == ('Found m import while parsing, but s was not included in the `sections` setting of your config. Please add it before continuing\n'
 'See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.',)

# Generated at 2022-06-23 20:16:45.338632
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Parameterized test for constructor of class FileSkipSetting
    class TestFileSkipSetting(FileSkipSetting):
        def __init__(self, a, b):
            super().__init__(a, b)
            self.first = a
            self.second = b

    assert TestFileSkipSetting('test', 'test').file_path == 'test'

# Generated at 2022-06-23 20:16:48.066746
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test"

# Generated at 2022-06-23 20:16:50.423941
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("file.py")
    except FileSkipComment as e:
        assert e.file_path == "file.py"
        assert str(e) == "file.py contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:16:52.752051
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'test_file_path'
    test = FileSkipComment(file_path)
    assert test.file_path == file_path
    assert test.args == (f"{file_path} contains an file skip comment and was skipped.",)


# Generated at 2022-06-23 20:16:54.920255
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'autopep8'
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as err:
        assert err.formatter == 'autopep8'

# Generated at 2022-06-23 20:17:00.700469
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "foo": {"value": "bar", "source": "config"},
        "baz": {"value": "blub", "source": "command line"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:17:04.510876
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test_file"
    assert FileSkipComment(file_path=file_path).message == f"{file_path} contains an file skip comment and was skipped."
    assert FileSkipComment(file_path=file_path).file_path == file_path

# Generated at 2022-06-23 20:17:12.673427
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    good_code = "a = b\n"

    bad_code = "a = b\nc = d"
    expected_error_message = "isort was told to sort a section of assignments, however the given code:\n\n" \
                             f"{bad_code}\n\n" \
                             "Does not match isort's strict single line formatting requirement for assignment " \
                             "sorting:\n\n" \
                             "{variable_name} = {value}\n" \
                             "{variable_name2} = {value2}\n" \
                             "...\n\n"

    with pytest.raises(AssignmentsFormatMismatch) as exc_info:
        AssignmentsFormatMismatch(bad_code)
    assert str(exc_info.value) == expected_error_message
   

# Generated at 2022-06-23 20:17:17.749402
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    t = FileSkipSetting(file_path = "file")
    assert t.message == "file was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert t.file_path == "file"


# Generated at 2022-06-23 20:17:20.738962
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test/test.txt")
    except UnsupportedEncoding as e:
        assert e.args[0] == "Unknown or unsupported encoding in test/test.txt"

# Generated at 2022-06-23 20:17:24.009701
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = '/User/XXX/isort/settings.py'

    error = FormattingPluginDoesNotExist(formatter)
    assert str(error) == 'Specified formatting plugin of /User/XXX/isort/settings.py does not exist. '
    assert error.formatter == formatter

# Generated at 2022-06-23 20:17:25.286885
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    s = InvalidSettingsPath("InvalidSettingsPath")
    assert s.settings_path == "InvalidSettingsPath"


# Generated at 2022-06-23 20:17:28.987586
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding(filename="test.py")
    except UnsupportedEncoding as e:
        assert e.args[0] == "Unknown or unsupported encoding in test.py"
        assert e.filename == "test.py"

# Generated at 2022-06-23 20:17:39.827456
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    import os
    import sys
    # Testcase 1
    # Test with a valid input for File Skip Setting 
    file_path = os.path.join(sys.executable, "isort", "/home/my_file.py")
    assert FileSkipSetting.__init__(file_path) == "home/my_file.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    # Testcase 2
    # Test with a invalid input for File Skip Setting 
    file_path = os.path.join(sys.executable, "isort")
    assert FileSkipSetting.__init__(file_path) == "None was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-23 20:17:42.039167
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist.__init__(ISortError, "")

# Generated at 2022-06-23 20:17:45.105957
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(str, list).__str__() == (
        "isort was told to sort a literal of type <class 'list'> but was given "
        "a literal of type <class 'str'>."
    )

# Generated at 2022-06-23 20:17:50.163038
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("Some.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "Some.py"

# Generated at 2022-06-23 20:17:53.375575
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    expected = "Unknown or unsupported encoding in file"
    error = UnsupportedEncoding("file")
    assert error.args[0] == expected
    assert error.filename == "file"


# Generated at 2022-06-23 20:18:03.324538
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # Tests whether constructor of class MissingSection is working properly
    # Create object as in argument of these using key values pairs
    # Then, call methods to check for exception handling
    # If assertion passed, then the test case is passed
    import_module = "test"
    section = "test"

    # Error message
    exception_message = "Found test import while parsing, but test was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."  # noqa: E501

    # Assignment operator to compare the actual result with the expected
    # result. If the condition is true, then the test case is passed.
    error = MissingSection(import_module, section)
    assert error.args[0] == exception_message

# Generated at 2022-06-23 20:18:06.536509
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("settings_path")
        assert False
    except Exception as error:
        if not isinstance(error, InvalidSettingsPath):
            assert False


# Generated at 2022-06-23 20:18:12.307137
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():

    # Arrange
    invalid_settings_path = 'some/invalid/settings/path'

    # Action
    error = InvalidSettingsPath(
        invalid_settings_path)

    # Assert
    assert str(error) == (
        f'isort was told to use the settings_path: {invalid_settings_path} as the base directory or '
        'file that represents the starting point of config file discovery, but it does not exist.'
    )
    assert error.settings_path == invalid_settings_path

# Generated at 2022-06-23 20:18:14.548807
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "message"
    file_path = "file_path"
    FileSkipComment(message, file_path)

# Generated at 2022-06-23 20:18:18.510001
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # test if default value of FileSkipSetting is initialized correctly
    assert FileSkipSetting("somefile").file_path == "somefile"
    # test if default value of FileSkipSetting is initialized correctly
    assert FileSkipSetting("somefile").message == (
        "somefile was skipped as it's listed in 'skip' setting"
        " or matches a glob in 'skip_glob' setting"
    )

# Generated at 2022-06-23 20:18:20.594287
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"key1": {"value": 1, "source": "config"}}
    err = UnsupportedSettings(unsupported_settings)
    assert err.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:18:23.326512
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "False"
    original_error = Exception("Some error")
    lit_parse_failure = LiteralParsingFailure(code, original_error)
    assert lit_parse_failure.original_error == original_error
    assert lit_parse_failure.code == code

# Generated at 2022-06-23 20:18:24.501758
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert ISortError
    assert InvalidSettingsPath
    assert InvalidSettingsPath('test')



# Generated at 2022-06-23 20:18:28.231915
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    import ast
    try:
        ast.literal_eval("Random String")
    except Exception as err:
        assert str(LiteralParsingFailure("Random String", err)) == (
            "isort failed to parse the given literal Random String. It's important to note that "
            "isort literal sorting only supports simple literals parsable by ast.literal_eval "
            "which gave the exception of malformed node or string: Random String."
        )

# Generated at 2022-06-23 20:18:31.803778
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():

    with pytest.raises(FileSkipSetting) as excinfo:
        raise FileSkipSetting('test path')

    assert excinfo.type is FileSkipSetting
    assert 'test path' in str(excinfo.value)


# Generated at 2022-06-23 20:18:34.657251
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    actual_err = ExistingSyntaxErrors("test")
    expected_err = "isort was told to sort imports within code that contains syntax errors: test."
    assert str(actual_err) == expected_err


# Generated at 2022-06-23 20:18:42.379342
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type(1)
    exp_type = type('1')
    test_LiteralSortTypeMismatch = LiteralSortTypeMismatch(kind, exp_type)
    assert isinstance(test_LiteralSortTypeMismatch, LiteralSortTypeMismatch)
    assert test_LiteralSortTypeMismatch.kind == kind
    assert test_LiteralSortTypeMismatch.expected_kind == exp_type
    assert not isinstance(test_LiteralSortTypeMismatch, ISortError)

# Generated at 2022-06-23 20:18:44.369879
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError as eeee:
        print(eeee)



# Generated at 2022-06-23 20:18:50.313789
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    option = {
        "name": "bad_option",
        "value": "bad_value",
        "source": "bad_source",
    }
    unsupported_settings = {
        "bad_option": option,
    }
    expected=f"isort was provided settings that it doesn't support:\n\n\t- {option['name']} = {option['value']}  (source: '{option['source']}')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"
    actual = UnsupportedSettings(unsupported_settings)

    assert(expected == actual.args[0])


# Generated at 2022-06-23 20:18:51.364697
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped("message", "file_path")

# Generated at 2022-06-23 20:18:53.835818
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings(
        unsupported_settings={"not_a_setting": {"value": "example", "source": "runtime"}}
    )

# Generated at 2022-06-23 20:18:58.057739
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=int, expected_kind=str)
    except LiteralSortTypeMismatch as error:
        assert str(error) == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>.\n"

# Generated at 2022-06-23 20:19:00.391380
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    t = FormattingPluginDoesNotExist("goodPlugin")
    assert t.formatter == "goodPlugin"

# Generated at 2022-06-23 20:19:10.228859
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path="../../pyproject.toml"
    err = InvalidSettingsPath(settings_path)
    # Ensure the error str returns the proper message
    assert err.message == "isort was told to use the setttings_path: ../../pyproject.toml as the base directory or file that represents the starting point of config file discovery, but it does not exist."
    assert err.settings_path == settings_path
    # Ensure the error returns the proper message on repr
    assert repr(err) == "InvalidSettingsPath(\"isort was told to use the setttings_path: ../../pyproject.toml as the base directory or file that represents the starting point of config file discovery, but it does not exist.\",)"


# Generated at 2022-06-23 20:19:12.576322
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding(filename="filename")
    except UnsupportedEncoding as err:
        assert err.filename == "filename"

# Generated at 2022-06-23 20:19:14.781799
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist("foo").args[0] == "Specified profile of foo does not exist. Available profiles: "

# Generated at 2022-06-23 20:19:16.441611
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    check = UnsupportedEncoding('/home/test.py')
    assert check.filename == '/home/test.py'

# Generated at 2022-06-23 20:19:23.289681
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = '((0, 1, 2), 3, 4)'
    original_error = ValueError('raw read error')

    try:
        raise LiteralParsingFailure(code, original_error)
    except ISortError as e:
        assert e.code == code
        assert e.original_error == original_error
        assert str(e) == 'isort failed to parse the given literal ((0, 1, 2), 3, 4). It\'s important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of ValueError(\'raw read error\',).'

# Generated at 2022-06-23 20:19:25.733591
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = '''
        first_variable = 1
        second_variable = 2
    '''
    isort_exception = AssignmentsFormatMismatch(code)

    assert isort_exception.code == code

# Generated at 2022-06-23 20:19:27.676249
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"



# Generated at 2022-06-23 20:19:35.344342
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'string'
    section = 'string'
    # Test for function MissingSection
    try:
        raise MissingSection(import_module,section)
    except MissingSection as err:
        assert err.args[0] == \
            f"Found {import_module} import while parsing, but {section} was not included " \
            "in the `sections` setting of your config. Please add it before continuing\n" \
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
            "for more info."
        assert err.import_module == import_module
        assert err.section == section

# Generated at 2022-06-23 20:19:38.095429
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    path = "abc/abc.py"
    message = "abc/abc.py contains an file skip comment and was skipped."
    assert FileSkipped(message, path).file_path == path


# Generated at 2022-06-23 20:19:40.940137
# Unit test for constructor of class MissingSection
def test_MissingSection():
    with pytest.raises(MissingSection) as err:
        raise MissingSection('my_module', 'MY_SECTION')
    assert 'Found my_module import' in str(err)

# Generated at 2022-06-23 20:19:47.053017
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "careerjet_api_client.Client"
    section = "CAREERJET_API"
    try:
        raise MissingSection(import_module, section)
    except MissingSection as e:
        assert e.import_module == import_module
        assert e.section == section

# Generated at 2022-06-23 20:19:48.146645
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings.__new__
    assert UnsupportedSettings.__init__

# Generated at 2022-06-23 20:19:51.909580
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        'exists_in_file': {
            'value': 'value',
            'source': 'package.cfg'
        }
    }
    with pytest.raises(UnsupportedSettings) as exception:
        raise UnsupportedSettings(unsupported_settings)

    assert unsupported_settings == exception.value.unsupported_settings

# Generated at 2022-06-23 20:19:53.040836
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("Hello.txt")

# Generated at 2022-06-23 20:19:55.388452
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    actual = FileSkipComment("://")
    expected = ":// contains an file skip comment and was skipped."
    assert actual.args[0] == expected



# Generated at 2022-06-23 20:19:57.045603
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    setting = {"k": 1}
    exception = UnsupportedSettings(setting)
    assert exception.unsupported_settings == setting

# Generated at 2022-06-23 20:20:01.738597
# Unit test for constructor of class MissingSection
def test_MissingSection():
    message = "Found {import_module} import while parsing, but {section} was not included " \
              "in the `sections` setting of your config. Please add it before continuing\n" \
              "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
              "for more info."
    assert message == MissingSection.__init__.__doc__

# Generated at 2022-06-23 20:20:03.006253
# Unit test for constructor of class ISortError
def test_ISortError():
    a = ISortError()
    assert str(a) == ''


# Generated at 2022-06-23 20:20:04.571042
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError

if __name__ == "__main__":
    test_ISortError()

# Generated at 2022-06-23 20:20:09.940528
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "\n\ndeep_nested_list = [[1]]\n"
    exception = SyntaxError("original_exception")
    err = LiteralParsingFailure(code, exception)

    assert isinstance(err, ISortError)
    assert err.code == code
    assert err.original_error == exception

# Generated at 2022-06-23 20:20:14.479584
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    message = 'Specified formatting plugin of spacy does not exist.'
    formatter = 'spacy'
    should_be = {'message': message,
                'formatter': formatter}
    test = FormattingPluginDoesNotExist(formatter)
    assert test.__getattr__('formatter') ==  should_be['formatter']
    assert test.__getattr__('message') ==  should_be['message']
    print ('Unit test for formatting plugin does not exist is passed')

# Generated at 2022-06-23 20:20:19.034483
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path = "sample_settings_path"
    # Call the constructor of class InvalidSettingsPath
    invalid_settings_path = InvalidSettingsPath(settings_path)
    # Check if the value of attribute 'settings_path' is equal to the given value
    assert(invalid_settings_path.settings_path == settings_path)


# Generated at 2022-06-23 20:20:24.732519
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    options = {"something": {"value": "value", "source": ""}}
    expected = (
        "isort was provided settings that it doesn't support:\n\n"
        "\t- something = value  (source: '')\n\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )
    assert UnsupportedSettings(options).args[0] == expected

# Generated at 2022-06-23 20:20:27.950855
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("c:\\temp\\invalid.py")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "c:\\temp\\invalid.py"
        assert str(e).startswith("isort was told to sort imports within code that contains syntax errors:")

# Generated at 2022-06-23 20:20:30.477366
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test_file")
    except UnsupportedEncoding as e:
        assert str(e) == "Unknown or unsupported encoding in test_file"
        assert e.filename == "test_file"

# Generated at 2022-06-23 20:20:36.004752
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    test_file_path = "tests.test_isort_error.test_ExistingSyntaxErrors"
    try:
        raise ExistingSyntaxErrors(file_path=test_file_path)
    except ExistingSyntaxErrors as e:
        assert str(e) == (
            f"isort was told to sort imports within code that contains syntax errors: "
            f"{test_file_path}."
        )



# Generated at 2022-06-23 20:20:38.966829
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("file.txt")
    except UnsupportedEncoding as e:
        assert isinstance(e, ISortError)
        assert e.filename == "file.txt"

# Generated at 2022-06-23 20:20:42.106291
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():

    file_path = 'test.py'
    try:
        raise IntroducedSyntaxErrors(file_path)
    except IntroducedSyntaxErrors as e:
        assert e.file_path == file_path

# Generated at 2022-06-23 20:20:43.879044
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError


# Generated at 2022-06-23 20:20:44.616701
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError()



# Generated at 2022-06-23 20:20:46.602394
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    '''test case for constructor of class AssignmentsFormatMismatch'''
    code = 'test code'
    e = AssignmentsFormatMismatch(code)
    assert e.code == code


# Generated at 2022-06-23 20:20:48.994557
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    exception = FileSkipSetting("/path/to/file")
    assert str(exception) == "/path/to/file was skipped as it's listed in 'skip' setting"\
        " or matches a glob in 'skip_glob' setting"
    assert exception.file_path == "/path/to/file"

# Generated at 2022-06-23 20:20:50.785324
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    exception = FileSkipComment(file_path="foo")
    assert str(exception) == "foo contains an file skip comment and was skipped."



# Generated at 2022-06-23 20:20:53.682002
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test.java")
    except Exception as e:
        assert e.file_path == "test.java"
        assert str(e) == ("isort was told to sort imports within code that contains syntax "
            "errors: test.java.")


# Generated at 2022-06-23 20:21:03.002089
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error_message = "Error message"
    # Fail to parse the string format
    try:
        test_code = "a,b,c"
        literal_parsing_failure_object = LiteralParsingFailure(test_code, test_code)
        assert str(literal_parsing_failure_object) == error_message
    except Exception as e:
        assert str(e) == error_message
    
    # Fail to parse the number format
    try:
        test_code = 1.0
        literal_parsing_failure_object = LiteralParsingFailure(test_code, test_code)
        assert str(literal_parsing_failure_object) == error_message
    except Exception as e:
        assert str(e) == error_message

# Generated at 2022-06-23 20:21:06.122216
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    fsc = FileSkipComment(file_path = "test/test_file_skip")
    assert fsc.file_path == "test/test_file_skip"
    assert str(fsc) == "test/test_file_skip contains an file skip comment and was skipped."

# Generated at 2022-06-23 20:21:08.510967
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    comment = FileSkipComment("file/path.py")
    assert comment.file_path == "file/path.py"
    assert comment.args[0] == "file/path.py contains an file skip comment and was skipped."



# Generated at 2022-06-23 20:21:12.503303
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    class TestClass:
        def func(self):
            unsupported_settings = {"x": "y"}
            UnsupportedSettings(unsupported_settings)

# Generated at 2022-06-23 20:21:17.542114
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    filename = "test.py"
    file_skip_comment_obj = FileSkipComment(filename)

    # Test __str__() method
    assert str(file_skip_comment_obj) == f"{filename} contains an file skip comment and was skipped."
    # Test file_path property
    assert file_skip_comment_obj.file_path == filename

# Generated at 2022-06-23 20:21:22.642316
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        int('a')
    except ValueError as e:
        exception = LiteralParsingFailure("a", e)
        assert exception.code == "a"
        assert exception.original_error == e
    else:
        raise AssertionError("test_LiteralParsingFailure failed")


# Generated at 2022-06-23 20:21:24.561163
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    error = FormattingPluginDoesNotExist('foo')
    assert error.formatter == 'foo'

# Generated at 2022-06-23 20:21:28.337742
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    """Unit test for constructor of class FormattingPluginDoesNotExist"""
    formatter = "grep"
    exception = FormattingPluginDoesNotExist(formatter)
    assert str(exception) == "Specified formatting plugin of grep does not exist. "
    assert exception.formatter == "grep"

# Generated at 2022-06-23 20:21:32.364566
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("~")
    except InvalidSettingsPath as e:
        # Unit test for value of InvalidSettingsPath.message
        assert e.message == "isort was told to use the settings_path: ~ as the base directory or file that represents the starting point of config file discovery, but it does not exist."
        # Unit test for value of InvalidSettingsPath.settings_path
        assert e.settings_path == "~"


# Generated at 2022-06-23 20:21:38.016432
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    from ast import literal_eval
    code = "raise Foo()"
    original_error = AssertionError

    try:
        literal_eval(code)
    except SyntaxError as err:
        with pytest.raises(ISortError):
            raise LiteralParsingFailure(code, err)



# Generated at 2022-06-23 20:21:48.233861
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    class ParentClass:
        pass

    class ChildClass(ParentClass):
        pass

    class_instance = ChildClass()

    # Raises a ValueError
    try:
        raise LiteralSortTypeMismatch(ChildClass, ParentClass)
    except LiteralSortTypeMismatch as error:
        assert error.kind == ChildClass
        assert error.expected_kind == ParentClass

    # Raises a ValueError
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as error:
        assert error.kind == str
        assert error.expected_kind == int

    # Raises a ValueError

# Generated at 2022-06-23 20:21:51.486137
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('Test')
    except ISortError as e:
        e1 = e
    
    assert str(e1) == 'Test'

# Generated at 2022-06-23 20:21:53.042024
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "filepath")
    except FileSkipped as e:
        assert e.file_path == "filepath"
        assert str(e) == "message"

# Generated at 2022-06-23 20:21:56.847166
# Unit test for constructor of class MissingSection
def test_MissingSection():
    class TestException(MissingSection):
        def __init__(self, import_module: str, section: str):
            super().__init__(import_module, section)

    assert TestException.__init__(import_module="import_module", section="section")

# Generated at 2022-06-23 20:21:57.472837
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    pass

# Generated at 2022-06-23 20:21:58.579231
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment('file_path')

# Generated at 2022-06-23 20:22:00.586465
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors):
        raise ExistingSyntaxErrors("Fileabcd")

# Generated at 2022-06-23 20:22:04.608353
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, float)
    except LiteralSortTypeMismatch as e:
        assert (
            str(e) == "isort was told to sort a literal of type <class 'float'> but was given a literal of type <class 'int'>"
        )



# Generated at 2022-06-23 20:22:06.024730
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    with pytest.raises(FileSkipSetting):
        raise FileSkipSetting(file_path='/file/path')

# Generated at 2022-06-23 20:22:11.007168
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(code)
    except Exception as e:
        assert str(e) == """isort was told to sort a section of assignments, however the given code:\n\nimport foo\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"""
        return True
    return False

# Generated at 2022-06-23 20:22:12.804762
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    err = AssignmentsFormatMismatch("a, b = 0, 1")
    assert err.code == "a, b = 0, 1"

# Generated at 2022-06-23 20:22:16.086713
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding) as execinfo:
        raise UnsupportedEncoding(filename="dummy")
    assert execinfo.value.filename == "dummy"

# Generated at 2022-06-23 20:22:22.762018
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """Unit test for constructor of class LiteralParsingFailure"""
    class ExpectedException(Exception):
        pass

    try:
        raise LiteralParsingFailure("some_code", ExpectedException("some_error"))
    except LiteralParsingFailure as e:
        assert str(e) == (
            "isort failed to parse the given literal some_code. "
            "It's important to note that isort literal sorting only supports simple literals "
            "parsable by ast.literal_eval which gave the exception of some_error."
        )
        assert e.code == "some_code"
        assert e.original_error.args[0] == "some_error"
    else:
        assert False, "LiteralParsingFailure not raised"



# Generated at 2022-06-23 20:22:26.823891
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath, match = "isort was told to use the settings_path: /foo/bar as the base directory or file that represents the starting point of config file discovery, but it does not exist."):
        raise InvalidSettingsPath("/foo/bar")


# Generated at 2022-06-23 20:22:28.366548
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert str(UnsupportedEncoding("somefile.py")) == "Unknown or unsupported encoding in somefile.py"

# Generated at 2022-06-23 20:22:31.919764
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("no_such_profile")
    except ISortError as e:
        assert str(e) == (
            "Specified profile of no_such_profile does not exist. "
            "Available profiles: black, pep8, google, pep257, pycharm."
        )
        assert e.profile == "no_such_profile"
    else:
        assert False, "ISortError not caught"