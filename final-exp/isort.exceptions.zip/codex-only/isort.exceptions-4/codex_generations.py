

# Generated at 2022-06-23 20:12:26.576082
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    skipped_file = FileSkipComment(file_path=".isort.cfg")
    assert skipped_file.file_path == ".isort.cfg"
    assert skipped_file.args == (
        ".isort.cfg contains an file skip comment and was skipped.",
    )

# Generated at 2022-06-23 20:12:29.060773
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('First ISortError message')
    except Exception as e:
        assert str(e) == 'First ISortError message'


# Generated at 2022-06-23 20:12:32.806796
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "x"
    original_error = "y"
    LiteralParsingFailure(code, original_error)


# Generated at 2022-06-23 20:12:39.786167
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("traceback info")
    except AssignmentsFormatMismatch as e:
        assert str(e) == "isort was told to sort a section of assignments, however the given code:\n\n" \
                         "traceback info\n\n" \
                         "Does not match isort's strict single line formatting requirement for assignment " \
                         "sorting:\n\n" \
                         "{variable_name} = {value}\n" \
                         "{variable_name2} = {value2}\n" \
                         "...\n\n"
        assert e.code == "traceback info"


# Generated at 2022-06-23 20:12:42.124408
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(ISortError):
        assert InvalidSettingsPath


# Generated at 2022-06-23 20:12:44.852009
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """UnsupportedEncoding constructor should set filename attribute"""
    filename = "test.py"
    unsupported_encoding_error = UnsupportedEncoding(filename)
    assert unsupported_encoding_error.filename == filename



# Generated at 2022-06-23 20:12:47.254388
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as exception:
        assert exception.message == "message"
        assert exception.file_path == "file_path"

# Generated at 2022-06-23 20:12:51.782628
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("./README.md")
    except ExistingSyntaxErrors as e:
        assert str(e) == "isort was told to sort imports within code that contains " +\
            "syntax errors: ./README.md."
        assert e.file_path == "./README.md"



# Generated at 2022-06-23 20:12:56.035720
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("imports.py")
    except IntroducedSyntaxErrors as e0:
        assert e0.file_path == "imports.py"

# Generated at 2022-06-23 20:13:03.863982
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    # FileSkipped
    with pytest.raises(FileSkipped):
        FileSkipped.__init__(FileSkipped, message="test", file_path="test.py")

    # FileSkipComment
    with pytest.raises(FileSkipComment):
        FileSkipComment.__init__(FileSkipComment, file_path="test.py")

    # FileSkipSetting
    with pytest.raises(FileSkipSetting):
        FileSkipSetting.__init__(FileSkipSetting, file_path="test.py")

    # ======== check variables of FileSkipped ========
    assert FileSkipped.file_path == "test.py"

# Generated at 2022-06-23 20:13:06.930433
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    fileSkipComment = FileSkipComment("test_path")
    assert fileSkipComment.file_path == "test_path"


# Generated at 2022-06-23 20:13:11.454485
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as err:
        assert err.file_path == "file_path"
        assert "file_path" in str(err)
        assert "message" in str(err)


# Unit tests for constructor of class ProfileDoesNotExist

# Generated at 2022-06-23 20:13:17.306748
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # Arrange
    import_module = 'PyQt5'
    section = 'Qt imports'
    # Act
    ms = MissingSection(import_module, section)
    # Assert
    assert ms.import_module == 'PyQt5'
    assert ms.section == 'Qt imports'
    assert str(ms) == (
        'Found PyQt5 import while parsing, but Qt imports was not included '
        'in the `sections` setting of your config. Please add it before continuing\n'
        'See https://pycqa.github.io/isort/#custom-sections-and-ordering '
        'for more info.')

# Generated at 2022-06-23 20:13:18.380470
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({})
    UnsupportedSettings({"a": {"value": "b", "source": "c"}})

# Generated at 2022-06-23 20:13:22.509694
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
	obj1 = FileSkipSetting("FileNotFoundError")
	assert obj1.file_path == "FileNotFoundError"
	assert obj1.message == "FileNotFoundError was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
	assert "FileSkipSetting" in str(obj1)
	
if __name__ == "__main__":
	test_FileSkipSetting()

# Generated at 2022-06-23 20:13:25.470321
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    with pytest.raises(LiteralParsingFailure):
        raise LiteralParsingFailure("{frozenset(): 'import', frozenset(): ['import']}",SyntaxError())


# Generated at 2022-06-23 20:13:27.655758
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # noinspection PyRedundantParentheses
    error = LiteralSortTypeMismatch(str, int)
    assert error.kind == str
    assert error.expected_kind == int

# Generated at 2022-06-23 20:13:29.651245
# Unit test for constructor of class ISortError
def test_ISortError():
    exception = ISortError("foo")
    assert(repr(exception) == "foo")


# Generated at 2022-06-23 20:13:32.525328
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError.__init__(ISortError, 'Error').args[0] == 'Error'

# Generated at 2022-06-23 20:13:34.697787
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fs = FileSkipped("message", "file_path")
    assert fs.message == "message"
    assert fs.file_path == "file_path"

# Generated at 2022-06-23 20:13:41.488502
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class Error(Exception):
        pass

    try:
        raise Error
    except Exception as original_error:
        try:
            raise LiteralParsingFailure("string", original_error)
        except Exception as error:
            assert error.args[0] == "isort failed to parse the given literal string. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of <class 'test_exceptions.Error'>"
            assert error.code == "string"
            assert error.original_error == Error



# Generated at 2022-06-23 20:13:45.443449
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "message"
    file_path = "file_path"
    # Test FileSkipped
    file_skipped = FileSkipped(message, file_path)
    assert file_skipped.message == message
    assert file_skipped.file_path == file_path
    # Test __str__
    assert str(file_skipped) == f"message: {file_path}"

# Generated at 2022-06-23 20:13:47.198131
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist.__doc__ == \
           "Raised when a formatting plugin is set by the user that doesn't exist"

# Generated at 2022-06-23 20:13:48.889658
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    a = ProfileDoesNotExist('a')
    assert a.profile == 'a'


# Generated at 2022-06-23 20:13:54.188061
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment(): 
    message = './tests/test_data/not_formatted/import_a.py contains an file skip comment and was skipped.'
    file_path = './tests/test_data/not_formatted/import_a.py'
    assert FileSkipComment(file_path).__str__() == message
    

# Generated at 2022-06-23 20:14:01.910334
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    from .profiles import get_profile
    from .settings import DEFAULT_SECTIONS, DEFAULT_SETTINGS
    from .utils import file_exists

    settings = get_profile(DEFAULT_SETTINGS, DEFAULT_SECTIONS)
    settings.update(settings)
    settings.update(settings)
    settings['line_length']=80
    settings['indent']='    '
    settings.pop('multi_line_output', None)
    settings.pop('use_parentheses', None)
    settings.pop('use_parentheses', None)
    settings.pop('use_parentheses', None)
    settings.pop('use_parentheses', None)
    settings.pop('use_parentheses', None)
    settings.pop('use_parentheses', None)

# Generated at 2022-06-23 20:14:05.981768
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist(40)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == 40


# Generated at 2022-06-23 20:14:08.788232
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    a = InvalidSettingsPath("/wrong/settings")
    assert a.settings_path == "/wrong/settings"


# Generated at 2022-06-23 20:14:15.222667
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():

    # Arrange
    test_formatter = "abcde"
    expected_msg = f"Specified formatting plugin of {test_formatter} does not exist. "

    # Act
    raised_exception = FormattingPluginDoesNotExist(test_formatter)

    # Assert
    assert raised_exception.formatter == test_formatter
    assert raised_exception.__str__() == expected_msg


# Generated at 2022-06-23 20:14:17.118068
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "nadim.py"
    assert FileSkipSetting(file_path).file_path == "nadim.py"

# Generated at 2022-06-23 20:14:20.143863
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    x = IntroducedSyntaxErrors("/abc")
    assert x.file_path == "/abc"

# Generated at 2022-06-23 20:14:23.217555
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("Hello World!")
    except ISortError as e:
        assert str(e) == "Hello World!"


# Generated at 2022-06-23 20:14:31.250947
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'import_module'
    section = 'section'
    ms = MissingSection(import_module, section)
    assert ms.args[0] == (
        f"Found {import_module} import while parsing, but {section} was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info."
    )

# Generated at 2022-06-23 20:14:36.474201
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("My_settings")
    except InvalidSettingsPath as e:
        assert str(e) == "isort was told to use the settings_path: My_settings as the base " \
                         "directory or file that represents the starting point of config file "\
                         "discovery, but it does not exist."
    else:
        assert False


# Generated at 2022-06-23 20:14:39.235681
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("hello")
    except AssignmentsFormatMismatch as e:
        assert e.code == "hello"

# Generated at 2022-06-23 20:14:41.275916
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding):
        raise UnsupportedEncoding("filename")


# Generated at 2022-06-23 20:14:44.388199
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    s = AssignmentsFormatMismatch("one = 1, two = 2, three = 3")
    assert s != None
    assert s.code != None # noqa: S101


# Generated at 2022-06-23 20:14:45.716893
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
	assert FormattingPluginDoesNotExist("Test")

# Generated at 2022-06-23 20:14:47.278594
# Unit test for constructor of class ISortError
def test_ISortError():
    err = ISortError('Error: some message')
    assert str(err) == 'Error: some message'

# Generated at 2022-06-23 20:14:48.216020
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath(settings_path='/invalid/path')

# Generated at 2022-06-23 20:14:50.229448
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    fs = FileSkipComment("test_file.py")
    assert fs.message == "test_file.py contains an file skip comment and was skipped."



# Generated at 2022-06-23 20:14:51.874600
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError().args

# Generated at 2022-06-23 20:14:53.952576
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    e = ExistingSyntaxErrors('file_path')
    assert e.file_path == 'file_path'


# Generated at 2022-06-23 20:14:55.994008
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("1, 2", Exception("abc"))
    except LiteralParsingFailure as e:
        assert isinstance(e.code, str)
        assert isinstance(e.original_error, Exception)

# Generated at 2022-06-23 20:14:59.644643
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding) as e:
        UnsupportedEncoding(None)
    assert UnsupportedEncoding(None) == e

# Generated at 2022-06-23 20:15:04.852866
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "abc: 123\ndef: 456"
    exception = AssignmentsFormatMismatch(code)
    assert exception.code == code
    assert not exception.args
    assert exception.__str__() == "isort was told to sort a section of assignments, however the given code:\n\nabc: 123\ndef: 456\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert e.code == code

# Generated at 2022-06-23 20:15:07.045719
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except Exception as e:
        assert e.file_path == "file_path"

# Generated at 2022-06-23 20:15:12.798760
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("hello world")
    except AssignmentsFormatMismatch as e:
        assert(str(e) == "isort was told to sort a section of assignments, however the given code:\n\nhello world\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n")


# Generated at 2022-06-23 20:15:13.616452
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message= FileSkippe

# Generated at 2022-06-23 20:15:16.190515
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as e:
        print(e.file_path)

# Generated at 2022-06-23 20:15:19.061104
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped(message="message", file_path="path").message == "message"


# Generated at 2022-06-23 20:15:21.317149
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_FileSkipSetting"
    file = FileSkipSetting(file_path)
    assert(file.file_path == file_path)

# Generated at 2022-06-23 20:15:22.943423
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except ISortError:
        pass

# Generated at 2022-06-23 20:15:23.721365
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("filename")
    except:
        pass

# Generated at 2022-06-23 20:15:25.259865
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    error = FileSkipComment("file.py")
    assert str(error) == "file.py contains an file skip comment and was skipped."
    assert error.file_path == "file.py"


# Generated at 2022-06-23 20:15:26.227541
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"type_comment": "value"}
    UnsupportedSettings(unsupported_settings)

# Generated at 2022-06-23 20:15:31.834447
# Unit test for constructor of class ISortError
def test_ISortError():
    e = ISortError()
    assert e.args == ()
    e = ISortError('Test')
    assert e.args == ('Test',)
    e = ISortError('Test', {}, ())
    assert e.args == ('Test', {}, ())


# Generated at 2022-06-23 20:15:41.077348
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    import unittest

    class TestUnsupportedSettings(unittest.TestCase):
        def test_format_option(self):
            from isort import exceptions

            test_cases = [
                {"name": "hello", "value": 1, "source": "foo", "expected": "\t- hello = 1  (source: 'foo')"},
                {"name": "1234", "value": "foo", "source": "bar", "expected": "\t- 1234 = foo  (source: 'bar')"},
            ]

            for test_case in test_cases:
                with self.subTest(test_case=test_case):
                    self.assertEqual(
                        exceptions.UnsupportedSettings._format_option(
                            **test_case
                        ), test_case["expected"]
                    )


# Generated at 2022-06-23 20:15:43.538958
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as error:
        assert error.file_path == "file_path"

# Generated at 2022-06-23 20:15:51.913767
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    """Asserts that FileSkipComment is constructed correctly"""
    from .errors import FileSkipComment
    from pathlib import Path
    given_path = "test_path"
    expected_message = f"{given_path} contains an file skip comment and was skipped."
    exception = FileSkipComment(given_path)
    assert str(exception) == expected_message
    assert isinstance(exception.file_path, Path)
    assert exception.file_path.name == given_path



# Generated at 2022-06-23 20:15:57.033161
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assignment_line = "ABC = 123"
    # Contains correct assignment format
    assert AssignmentsFormatMismatch(assignment_line)
    # Contains incorrect assignment format
    assignment_line = "ABC= 123"
    assert not AssignmentsFormatMismatch(assignment_line)


# Generated at 2022-06-23 20:15:58.776002
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    a = UnsupportedEncoding("file.txt")
    assert str(a) == "Unknown or unsupported encoding in file.txt"
    assert a.filename == "file.txt"


# Generated at 2022-06-23 20:16:04.233303
# Unit test for constructor of class ISortError
def test_ISortError():
    from .isort import isort

    f = isort.settings.config_file_path
    assert ISortError is not None
    assert isinstance(ISortError.__doc__, str)
    assert ISortError.__init__ is not object.__init__
    assert isinstance(f,  Path)

# Generated at 2022-06-23 20:16:06.388381
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "/Users/jason/workspace/isort/isort/README.md"
    UnsupportedEncoding(filename)

# Generated at 2022-06-23 20:16:08.780044
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise ValueError
    except ValueError as e:
        try:
            raise LiteralParsingFailure(None, e)
        except ISortError:
            pass

# Generated at 2022-06-23 20:16:14.624856
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        a = AssignmentsFormatMismatch('a=b')
    except AssignmentsFormatMismatch as afm :
        assert str(afm) == "isort was told to sort a section of assignments, however the given code:\n\n"
        "a=b\n\n"
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
        assert afm.code == 'a=b'


# Generated at 2022-06-23 20:16:17.771040
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    filename = "test.py"
    e = IntroducedSyntaxErrors(filename)
    assert str(e) == f"isort introduced syntax errors when attempting to sort the imports contained within {filename}."

# Generated at 2022-06-23 20:16:21.462096
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test"
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test."



# Generated at 2022-06-23 20:16:25.356674
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath(".")
    except InvalidSettingsPath as err:
        assert str(err) == "isort was told to use the settings_path: . as the base directory or " \
               "file that represents the starting point of config file discovery, but it does not " \
               "exist."
    else:
        assert False, "Failed to throw an ISortError"


# Generated at 2022-06-23 20:16:27.242059
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    assert AssignmentsFormatMismatch("x = 1\ny = 2").code == "x = 1\ny = 2"

# Generated at 2022-06-23 20:16:30.191959
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('wrong_module', 'SECTION_NAME')
    except MissingSection as e:
        assert 'wrong_module' in e.__str__()
        assert 'SECTION_NAME' in e.__str__()

# Generated at 2022-06-23 20:16:34.029095
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(FileSkipped) as excinfo:
        raise FileSkipped("missing file", "file")
    assert str(excinfo.value) == "missing file"
    assert excinfo.value.file_path == "file"

# Generated at 2022-06-23 20:16:38.929535
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        if isinstance("a", str):
            raise MissingSection("No module","No section")
    except MissingSection as error:
        assert error.__str__() == "Found No module import while parsing, but No section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:16:40.474108
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("/home/user/test_isort.py")
        pass
    except FileSkipSetting:
        pass


# Generated at 2022-06-23 20:16:43.684836
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    self = UnsupportedSettings({'test': {'value': 'to test class', 'source': 'test'}})
    assert self.unsupported_settings['test']['value'] == 'to test class'
    assert self.unsupported_settings['test']['source'] == 'test'

# Generated at 2022-06-23 20:16:46.580826
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    error = FormattingPluginDoesNotExist(formatter="format")
    assert error.formatter == "format"

# Generated at 2022-06-23 20:16:49.731168
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test_profile")
    except ProfileDoesNotExist as e:
        assert e.profile == "test_profile"

# Generated at 2022-06-23 20:16:55.837360
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "colorama"
    section = "FIRSTPARTY"
    section_class = MissingSection(import_module, section)
    assert section_class.args[0] == "Found colorama import while parsing, but FIRSTPARTY was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:16:59.704152
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding("test")
    assert error.filename == "test"
    assert error.__str__() == "Unknown or unsupported encoding in test"

# Generated at 2022-06-23 20:17:02.756697
# Unit test for constructor of class MissingSection
def test_MissingSection(): 
    p = MissingSection('numpy', 'Django imports')
    assert p.import_module == 'numpy'
    assert p.section == 'Django imports'

# Generated at 2022-06-23 20:17:05.708033
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    lpf = LiteralParsingFailure(code='ddd', original_error='ee')
    assert lpf.code == 'ddd'
    assert lpf.original_error == 'ee'

# Generated at 2022-06-23 20:17:09.769649
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/opt/file")
    except Exception as e:
        assert isinstance(e, ISortError)
        assert isinstance(e, InvalidSettingsPath)
        assert "isort was told to use the settings_path: /opt/file as the base directory or " \
               "file that represents the starting point of config file discovery, but it does not " \
               "exist." in e.__str__()


# Generated at 2022-06-23 20:17:11.785622
# Unit test for constructor of class MissingSection
def test_MissingSection():
    class TEST_MissingSection(MissingSection):
        def __init__(self, import_module: str, section: str):
            super().__init__(import_module, section)



# Generated at 2022-06-23 20:17:15.725530
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors("")
    assert error.args == (
        'isort introduced syntax errors when attempting to sort the imports contained within .',
    )
    assert error.file_path == ""

# Generated at 2022-06-23 20:17:21.383691
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    import sys
    exception = UnsupportedEncoding('Not a file')
    assert isinstance(exception, ISortError)
    assert exception.filename == 'Not a file'
    if sys.version_info.major == 2:
        assert str(exception) == 'Unknown or unsupported encoding in Not a file'
    else:
        assert str(exception) == 'Unknown or unsupported encoding in Not a file'

# Generated at 2022-06-23 20:17:25.712259
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    """Test for contructor of class InvalidSettingsPath"""
    try:
        raise InvalidSettingsPath("src/__init__.py")
    except InvalidSettingsPath as err:
        assert str(err) == "isort was told to use the settings_path: src/__init__.py as the base directory or \
file that represents the starting point of config file discovery, but it does not exist."
        assert err.settings_path == "src/__init__.py"


# Generated at 2022-06-23 20:17:28.534048
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        a = FormattingPluginDoesNotExist("abc")
    except FormattingPluginDoesNotExist as fnf_error:
        print(fnf_error)
        print(repr(fnf_error))


# Generated at 2022-06-23 20:17:33.041321
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert (
        FileSkipComment("hello/world.py").message
        == "hello/world.py contains an file skip comment and was skipped."
    )
    assert FileSkipComment("hello/world.py").file_path == "hello/world.py"


# Generated at 2022-06-23 20:17:36.544490
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(str, dict).__str__() ==\
           "isort was told to sort a literal of type <class 'dict'> but was given " \
           "a literal of type <class 'str'>."

# Generated at 2022-06-23 20:17:39.883371
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = b\nc = d")
    except AssignmentsFormatMismatch as e:
        assert isinstance(e, ISortError)
        assert e.code == "a = b\nc = d"

# Generated at 2022-06-23 20:17:45.967554
# Unit test for constructor of class MissingSection
def test_MissingSection():
    err_msg = "Found {import_module} import while parsing, but {section} was not included " \
            "in the `sections` setting of your config. Please add it before continuing\n" \
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
            "for more info."
    assert str(MissingSection('foo', 'bar')) == err_msg.format(import_module='foo', section='bar')

# Generated at 2022-06-23 20:17:48.850841
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    FormattingPluginDoesNotExist("formatter")

# Generated at 2022-06-23 20:17:53.017506
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"foo": "bar"}
    error = UnsupportedSettings(unsupported_settings)
    assert str(error) == (
        "isort was provided settings that it doesn't support:\n\n"
        "\t- foo = bar  (source: '<runtime>')\n\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:17:55.646923
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    comment = "FileSkipComment"
    path = "path"
    assert comment in str(FileSkipComment(path))
    assert path in str(FileSkipComment(path))

# Generated at 2022-06-23 20:17:58.967189
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "[\n [],\n []\n]"
    original_error = Exception
    error = LiteralParsingFailure(code, original_error)

    assert error.code == code
    assert error.original_error == original_error

# Generated at 2022-06-23 20:18:01.456310
# Unit test for constructor of class ISortError
def test_ISortError():
    assert str(ISortError()) == ''
    assert str(ISortError('error!!')) == 'error!!'
    assert not isinstance(ISortError('msg'), Exception)

# Generated at 2022-06-23 20:18:04.420568
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():

    unsupported_settings = {
        "invalid": {"value": "invalid", "source": "test"},
    }
    try:
        raise UnsupportedSettings(unsupported_settings)
    except UnsupportedSettings as e:
        assert e.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:18:09.473099
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    expected_message = "message"
    expected_file = "file"
    actual = FileSkipped(expected_message, expected_file)

    actual_message = actual.args[0]
    assert expected_message == actual_message

    actual_file = actual.file_path
    assert expected_file == actual_file


# Generated at 2022-06-23 20:18:18.317483
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings({"spam": {"value": 42, "source": "eggs"}})
    UnsupportedSettings({"spam": {"value": {}, "source": "eggs"}})
    UnsupportedSettings({"spam": {"value": [], "source": "eggs"}})
    UnsupportedSettings({"spam": {"value": None, "source": "eggs"}})
    UnsupportedSettings({"spam": {"value": "string", "source": "eggs"}})
    UnsupportedSettings({"spam": {"value": True, "source": "eggs"}})

# Generated at 2022-06-23 20:18:20.210812
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    e = AssignmentsFormatMismatch("{key} = {value}")
    assert e.code == "{key} = {value}"



# Generated at 2022-06-23 20:18:26.238200
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    err = UnsupportedSettings({"test": {"value": 1, "source": "test"}})
    assert str(err) == "isort was provided settings that it doesn't support:\n\n\t- test = 1  (source: 'test')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"

# Generated at 2022-06-23 20:18:26.617787
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert True

# Generated at 2022-06-23 20:18:28.077253
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    a = AssignmentsFormatMismatch("a = b")
    assert a.code == "a = b"

# Generated at 2022-06-23 20:18:31.972093
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "sample.py"
    assert (
        ExistingSyntaxErrors(file_path).__str__()
        == f"isort was told to sort imports within code that contains syntax errors: "
        f"{file_path}."
    )


# Generated at 2022-06-23 20:18:33.199788
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    exception= ProfileDoesNotExist('profile')
    assert exception.profile == 'profile'

# Generated at 2022-06-23 20:18:36.681647
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors, match="isort introduced syntax errors when attempting to sort the imports contained within sample.py."):
        raise IntroducedSyntaxErrors("sample.py")

# Generated at 2022-06-23 20:18:41.408728
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = "test"
    profiles = ["test1", "test2"]
    profile_inst = ProfileDoesNotExist(profile)
    assert (profile_inst.profile == profile)
    assert (profile_inst.__str__() == "Specified profile of test does not exist. Available profiles: test1,test2.")

# Generated at 2022-06-23 20:18:42.901342
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    from isort.main import UnsupportedSettings
    UnsupportedSettings()

# Generated at 2022-06-23 20:18:44.848972
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    exc = LiteralSortTypeMismatch(int, str)
    assert exc.kind == int
    assert exc.expected_kind == str

# Generated at 2022-06-23 20:18:48.179587
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    test_message = 'test message'
    try:
        raise ExistingSyntaxErrors(test_message)
    except Exception as e:
        assert ExistingSyntaxErrors is type(e)
        assert test_message == e.file_path
        assert test_message == str(e)

# Generated at 2022-06-23 20:18:52.785629
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit test for constructor of class UnsupportedSettings"""
    unsupported_settings = {
        "option1": "value1",
        "option2": "value2",
    }
    exception = UnsupportedSettings(unsupported_settings)
    assert exception.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:18:54.210298
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError.__init__ is not Exception.__init__

# Generated at 2022-06-23 20:18:55.961929
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    e = UnsupportedEncoding('/path/to/file')
    assert e.filename == '/path/to/file'
    assert str(e) == "Unknown or unsupported encoding in /path/to/file"

# Generated at 2022-06-23 20:18:56.986858
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():

    FileSkipSetting("FileSkipSetting")

# Generated at 2022-06-23 20:19:00.864326
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("Demo")
    except Exception as e:
        assert e.file_path == "Demo"
    
#Unit Test for constructor of class UnsupportedEncoding

# Generated at 2022-06-23 20:19:07.627421
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("this_is_an_unsupported_encoding.txt")
    except ISortError as e:
        assert str(e) == "Unknown or unsupported encoding in this_is_an_unsupported_encoding.txt"
        assert e.filename == "this_is_an_unsupported_encoding.txt"
    else:
        raise AssertionError("ISortError was not properly raised.")

# Generated at 2022-06-23 20:19:12.751501
# Unit test for constructor of class MissingSection
def test_MissingSection():
    error = MissingSection('boto3', 'FUTURE')
    assert error.args == ('Found boto3 import while parsing, but FUTURE was not included '
            'in the `sections` setting of your config. Please add it before continuing\n'
            'See https://pycqa.github.io/isort/#custom-sections-and-ordering '
            'for more info.',)

# Generated at 2022-06-23 20:19:13.843227
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding('filename').filename == 'filename'

# Generated at 2022-06-23 20:19:17.549899
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(5, str)
    except Exception as e:
        assert str(e) == "isort was told to sort a literal of type <class 'object'> but was given " \
                         "a literal of type <class 'int'>."
# EOF

# Generated at 2022-06-23 20:19:21.244261
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = InvalidSettingsPath(settings_path = 'C:\\Users\\Dell\\AppData\\Local\\Programs\\Python\\Python38-32\\python.exe')
    assert path.settings_path == 'C:\\Users\\Dell\\AppData\\Local\\Programs\\Python\\Python38-32\\python.exe'


# Generated at 2022-06-23 20:19:23.667118
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("Test")
    except AssignmentsFormatMismatch as e:
        assert e.code == "Test"
    else:
        raise AssertionError("Class AssignmentsFormatMismatch not raised")

# Generated at 2022-06-23 20:19:24.597018
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("test")


# Generated at 2022-06-23 20:19:26.872524
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """Unit test that UnsupportedEncoding correctly assigns properties"""
    error = UnsupportedEncoding('test.py')
    assert error.args == (
        "Unknown or unsupported encoding in test.py",
    )
    assert error.filename == 'test.py'

# Generated at 2022-06-23 20:19:30.585775
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    test = LiteralParsingFailure('(1, 2)', Exception)
    assert "isort failed to parse the given literal (1, 2). It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of <class 'Exception'>" == test.args[0]
    assert "(1, 2)" == test.code
    assert Exception == test.original_error



# Generated at 2022-06-23 20:19:33.521559
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    f = FileSkipped("message ", "file_path")
    assert f.message == "message" and f.file_path == "file_path"

# Generated at 2022-06-23 20:19:35.197691
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    dict_settings = {"key": "value"}
    UnsupportedSettings(dict_settings)

# Generated at 2022-06-23 20:19:37.348020
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath('/toto/settings_path').settings_path == '/toto/settings_path'



# Generated at 2022-06-23 20:19:40.832556
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("foo = 10")
    except AssignmentsFormatMismatch as e:
        assert "isort was told to sort a section of assignments, however the given code:" in str(
            e
        )


# Generated at 2022-06-23 20:19:44.873853
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    msg = "This is a custom error message"
    class_def = {"__init__": "__init__(self, msg, original_error)", "__qualname__": "LiteralParsingFailure"}
    obj = LiteralParsingFailure(msg, class_def)
    assert obj.code == msg
    assert obj.original_error == class_def



# Generated at 2022-06-23 20:19:47.359591
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("code")
    except AssignmentsFormatMismatch as e:
        assert e.code == "code"

# Generated at 2022-06-23 20:19:49.099740
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "test : test"
    error = AssignmentsFormatMismatch(code)
    assert error.code == code


# Generated at 2022-06-23 20:19:52.892151
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(str, int).kind is str
    assert LiteralSortTypeMismatch(str, int).expected_kind is int
    assert LiteralSortTypeMismatch(str, int).args[0] == "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>"

# Generated at 2022-06-23 20:19:57.443229
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    test_code = "test_code"
    original_error = Exception("test_error")
    test_literal_error = LiteralParsingFailure(test_code, original_error)
    assert test_literal_error.code == test_code
    assert test_literal_error.original_error == original_error



# Generated at 2022-06-23 20:19:59.122394
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    exc = FormattingPluginDoesNotExist("None")
    assert str(exc) == "Specified formatting plugin of None does not exist. "

# Generated at 2022-06-23 20:20:01.242718
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    option = dict(name="strict_wrap", source="user", value=False)
    with UnsupportedSettings({"strict_wrap": option}):
        assert True


# Generated at 2022-06-23 20:20:02.917574
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    exception = InvalidSettingsPath("/")
    assert exception.settings_path == "/"



# Generated at 2022-06-23 20:20:06.024094
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert LiteralParsingFailure("error", Exception).args == \
        ("isort failed to parse the given literal error. It's important to note that "
         "isort literal sorting only supports simple literals parsable by ast.literal_eval "
         "which gave the exception of Exception.",)

# Generated at 2022-06-23 20:20:11.241500
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting(file_path="file_path")
    except FileSkipSetting as e:
        assert e.message == "file_path was skipped as it's listed in 'skip' setting" \
            " or matches a glob in 'skip_glob' setting"
        assert e.file_path == "file_path"

# Generated at 2022-06-23 20:20:17.499590
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('arg', 'arg_section')
    except ISortError as e:
        assert str(e) == 'Found arg import while parsing, but arg_section was not included '\
                'in the `sections` setting of your config. Please add it before continuing\n'\
                'See https://pycqa.github.io/isort/#custom-sections-and-ordering '\
                'for more info.'

# Generated at 2022-06-23 20:20:26.103520
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported = dict()
    unsupported["test1"] = dict()
    unsupported["test1"]["value"] = "testvalue1"
    unsupported["test1"]["source"] = "testsource1"
    unsupported["test2"] = dict()
    unsupported["test2"]["value"] = "testvalue2"
    unsupported["test2"]["source"] = "testsource2"
    errors = "\n".join(
        UnsupportedSettings._format_option(name, **option) for name, option in unsupported.items()
    )


# Generated at 2022-06-23 20:20:29.200118
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "test_formatter"
    exception = FormattingPluginDoesNotExist(formatter)
    assert exception.formatter == formatter
    assert str(exception) == "Specified formatting plugin of test_formatter does not exist. "


# Generated at 2022-06-23 20:20:37.080584
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = 'a = 1\nb = 2\nc = 3'
    ASFM = AssignmentsFormatMismatch(code)
    expected_code = 'a = 1\nb = 2\nc = 3\n'
    assert ASFM.code == expected_code
    assert ASFM.__str__() == "isort was told to sort a section of assignments, however the given code:\n\n" \
                             f"{expected_code}\n\n" \
                             "Does not match isort's strict single line formatting requirement for assignment " \
                             "sorting:\n\n" \
                             "{variable_name} = {value}\n" \
                             "{variable_name2} = {value2}\n" \
                             "...\n\n"

# Generated at 2022-06-23 20:20:40.342996
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section = MissingSection(import_module="test_module", section="test_section")
    assert missing_section.import_module == "test_module"
    assert missing_section.section == "test_section"

# Generated at 2022-06-23 20:20:45.486884
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    import ast
    import random
    import string
    random_chars = [random.choice(string.ascii_letters) for i in range(10)]
    code = "".join(random_chars)
    original_error = ast.parse(code)
    exception = LiteralParsingFailure(code, original_error)
    assert exception.code == code
    assert exception.original_error == original_error

# Generated at 2022-06-23 20:20:48.068511
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    error = LiteralSortTypeMismatch("str", "int")
    assert isinstance(error, ISortError)
    assert error.kind == "str"
    assert error.expected_kind == "int"

# Generated at 2022-06-23 20:20:49.541393
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("file_path")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "file_path"

# Generated at 2022-06-23 20:20:53.172727
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("random formatter")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "random formatter"
        assert len(e.args) == 1
        assert e.args[0] == "Specified formatting plugin of random formatter does not exist. "

# unit test for constructor of class UnsupportedSettings

# Generated at 2022-06-23 20:20:54.869443
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist(formatter = "test").formatter == "test"

# Generated at 2022-06-23 20:20:58.124045
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"option": {"value": "value", "source": "source"}}
    error = UnsupportedSettings(unsupported_settings)
    assert error


# Generated at 2022-06-23 20:20:59.963341
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment('/path/to/skip').file_path == '/path/to/skip'

# Generated at 2022-06-23 20:21:01.147590
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    f = AssignmentsFormatMismatch("hello world")


# Generated at 2022-06-23 20:21:05.138243
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    message = "isort was told to use the settings_path: / as the base directory or " \
              "file that represents the starting point of config file discovery, but it does not exist."
    with pytest.raises(InvalidSettingsPath, match=rf".*{message}.*"):
        raise InvalidSettingsPath('/')


# Generated at 2022-06-23 20:21:15.444483
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'import_module'
    section = 'section'
    expected_error_message = "Found " + import_module + " import while parsing, but " + section + " was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
    try:
        raise MissingSection(import_module, section)
    except MissingSection as e:
        assert str(e) == expected_error_message
        assert e.import_module == import_module
        assert e.section == section
        assert type(e) == MissingSection

# Generated at 2022-06-23 20:21:19.969229
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("foo", "bar")
    except MissingSection as E:
        msg = "Found foo import while parsing, but bar was not included in the `sections` setting of your config. Please add it before continuing\n" \
              "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
              "for more info."
        assert msg == str(E)
        assert "bar" == E.import_module
        assert "foo" == E.section

# Generated at 2022-06-23 20:21:22.026630
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist):
        raise FormattingPluginDoesNotExist('abc')

# Generated at 2022-06-23 20:21:23.719608
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        FileSkipSetting
    except Exception as e:
        assert False, f"An exception was raised: {e}"
test_FileSkipSetting()

# Generated at 2022-06-23 20:21:27.632208
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting(file_path="C:\\Users")
    except FileSkipSetting as e:
        assert (str(e)) == "C:\\Users was skipped as it's listed in 'skip' setting " \
                           "or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:21:30.090896
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("/path/to/settings").settings_path == "/path/to/settings"


# Generated at 2022-06-23 20:21:35.921398
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    """Unit test for constructor of class InvalidSettingsPath"""
    with pytest.raises(InvalidSettingsPath) as exception_info:
        raise InvalidSettingsPath("test")
    assert str(exception_info.value) == "isort was told to use the settings_path: test as the base directory or " \
                                        "file that represents the starting point of config file discovery, but " \
                                        "it does not exist."
    assert exception_info.value.settings_path == "test"


# Generated at 2022-06-23 20:21:40.900939
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure(): 
    try: 
        b = 1
        a = 1/0 
    except Exception as e:
        assert LiteralParsingFailure("some_code", e).code == "some_code"
        assert LiteralParsingFailure("some_code", e).original_error == e


# Generated at 2022-06-23 20:21:42.856141
# Unit test for constructor of class ISortError
def test_ISortError():
    e = ISortError("Test")
    assert str(e) == "Test"


# Generated at 2022-06-23 20:21:45.455811
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("/home/user/")
    except FileSkipSetting as e:
        assert e.file_path == "/home/user/"


# Generated at 2022-06-23 20:21:46.033365
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    pass

# Generated at 2022-06-23 20:21:47.807104
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    class A:
        pass
    with pytest.raises(ISortError):
        LiteralSortTypeMismatch(A, dict)

# Generated at 2022-06-23 20:21:51.251254
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error_message = "This is the error message"
    filename = "Test File"
    error = ExistingSyntaxErrors(filename)

    assert str(error) == error_message
    assert error.file_path == filename

# Generated at 2022-06-23 20:21:54.932676
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "black"
    with pytest.raises(FormattingPluginDoesNotExist) as e:
        FormattingPluginDoesNotExist(formatter)
    assert e.match(f"Specified formatting plugin of {formatter} does not exist. ")

# Generated at 2022-06-23 20:21:56.986446
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    path = "example.txt"
    error = IntroducedSyntaxErrors(path)
    assert error.file_path == path

# Generated at 2022-06-23 20:21:58.923446
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "../../file_name.txt"
    comment = FileSkipComment(file_path)
    assert comment.file_path == file_path
    assert isinstance(comment, FileSkipped)
    assert isinstance(comment, ISortError)
    assert isinstance(comment, Exception)

# Generated at 2022-06-23 20:22:06.471545
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as ex:
        assert ex.profile == "test"
        assert str(ex) == (
            "Specified profile of test does not exist. "
            "Available profiles: black, py38, py37, google, py36, py27, py35, py34, py33, py26, "
            "py32, py31, py30, py3, py2, py25, py24, py23, py22, py21, py20, future, stdlib, "
            "gvr"
        )

# Generated at 2022-06-23 20:22:08.605193
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "django.db"
    section = "DJANGO"
    assert MissingSection(import_module, section).args == (import_module, section, )

# Generated at 2022-06-23 20:22:10.734144
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist) as e:
        raise ProfileDoesNotExist('My Profile')
    assert e.value.profile == 'My Profile'


# Generated at 2022-06-23 20:22:13.395289
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("abc")
    except Exception as exp:
        if exp.file_path == "abc":
            print("test ExistingSyntaxErrors successful")
            return
    assert False


# Generated at 2022-06-23 20:22:15.530574
# Unit test for constructor of class MissingSection
def test_MissingSection():
    error = MissingSection("test","test_section")
    assert error.import_module == "test"
    assert error.section == "test_section"

# Generated at 2022-06-23 20:22:17.127724
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    exception = FileSkipped("message", "file_path")
    assert exception.args == "message"
    assert exception.file_path == "file_path"

# Generated at 2022-06-23 20:22:19.775088
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class CustomException(ISortError):
        pass
    test_object = LiteralParsingFailure("code", CustomException("message"))
    assert test_object.code == "code"
    assert test_object.original_error.args[0] == "message"



# Generated at 2022-06-23 20:22:25.218907
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # GIVEN
    file_path = "hello/world/file.py"

    # WHEN
    actual = FileSkipComment(file_path=file_path)

    # THEN
    assert actual.file_path == file_path
    assert actual.message == f"{file_path} contains an file skip comment and was skipped."