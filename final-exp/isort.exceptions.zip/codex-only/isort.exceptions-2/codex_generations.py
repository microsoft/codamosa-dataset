

# Generated at 2022-06-23 20:12:36.980230
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import mylib"
    section = "mylib"
    ex = MissingSection(import_module=import_module, section=section)
    assert str(ex) == ("Found {} import while parsing, but {} was not included "
            "in the `sections` setting of your config. Please add it before continuing\n"
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
            "for more info.").format(import_module, section)
    assert ex.import_module == import_module
    assert ex.section == section


# Generated at 2022-06-23 20:12:40.457987
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    ob1 = FileSkipSetting('sadad')
    ob2 = FileSkipSetting('sadad')
    assert ob1.file_path == ob2.file_path


# Generated at 2022-06-23 20:12:42.452221
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    print(LiteralSortTypeMismatch.__init__.__doc__)

# Generated at 2022-06-23 20:12:45.290105
# Unit test for constructor of class ISortError
def test_ISortError():
    ISortError()


# Generated at 2022-06-23 20:12:47.589999
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    e = LiteralSortTypeMismatch(list, tuple)
    assert e.kind == list
    assert e.expected_kind == tuple



# Generated at 2022-06-23 20:12:50.018086
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("myplugin")
    except FormattingPluginDoesNotExist:
        print("Formatting plugin exception still works!")


# Generated at 2022-06-23 20:12:55.604175
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    class TestError(UnsupportedEncoding):
        pass
    try:
        raise TestError
    except TestError:
        pass

# Generated at 2022-06-23 20:12:58.279917
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'file_path'
    error = FileSkipComment(file_path)
    assert str(error) == f"{file_path} contains an file skip comment and was skipped."
    assert error.file_path == file_path

# Generated at 2022-06-23 20:13:04.634724
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("/home/path")
    except IntroducedSyntaxErrors as e:
        msg = str(e)
        file_path = e.file_path
    assert msg == "/home/path introduced syntax errors when attempting to sort the imports contained within /home/path."
    assert file_path == "/home/path"

# Generated at 2022-06-23 20:13:06.815832
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment("testDir/test.py")


# Generated at 2022-06-23 20:13:09.071746
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    exception = FileSkipped("message", "path")

    assert exception.message == "message"
    assert exception.file_path == "path"

# Generated at 2022-06-23 20:13:16.992434
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit test for constructor of class UnsupportedSettings"""
    settings_name = 'test_settings1'
    settings_value = 'test_settings_value1'
    settings_source = 'test_settings_source1'
    unsupported_settings = {settings_name: {'value': settings_value, 'source': settings_source}}
    with pytest.raises(UnsupportedSettings) as error:
        raise UnsupportedSettings(unsupported_settings)
    exceptions_lines = error.value.args[0].split('\n')
    assert 'isort was provided settings that it doesn\'t support:' in exceptions_lines[0]
    assert f'\t- {settings_name} = {settings_value}  (source: \'{settings_source}\')' == exceptions_lines[1]

# Generated at 2022-06-23 20:13:19.173317
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    x=AssignmentsFormatMismatch("x=y")
    assert x.code == "x=y"


# Generated at 2022-06-23 20:13:24.372415
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    new_LiteralSortTypeMismatch = LiteralSortTypeMismatch(kind=type(dict()), expected_kind=type(list()))
    assert new_LiteralSortTypeMismatch.kind == type(dict())
    assert new_LiteralSortTypeMismatch.expected_kind == type(list())

# Generated at 2022-06-23 20:13:25.909940
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist("test_profile").profile == "test_profile"

# Generated at 2022-06-23 20:13:28.043892
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    fsc = FileSkipComment(file_path="path/to/file.py")
    assert fsc.file_path == "path/to/file.py"


# Generated at 2022-06-23 20:13:32.814577
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        i = IntroducedSyntaxErrors("__init__.py")
    except Exception as exception:
        assert exception.args[0] == "isort introduced syntax errors when attempting to sort the imports contained within __init__.py."



# Generated at 2022-06-23 20:13:35.343161
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError) as exc:
        raise ISortError("Create new ISortError")
    assert exc.value.args == ("Create new ISortError",)

# Generated at 2022-06-23 20:13:39.744897
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'test'
    section = 'test'
    message = 'Found {0} import while parsing, but {1} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'.format(import_module, section)
    try:
        raise MissingSection(import_module, section)
    except MissingSection as e:
        assert e.import_module == import_module
        assert e.section == section
        assert e.message == message

# Generated at 2022-06-23 20:13:41.966464
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("hello", "world")
    except FileSkipped as exc:
        assert exc.message == "hello"
        assert exc.file_path == "world"

# Generated at 2022-06-23 20:13:43.533721
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    p1 = InvalidSettingsPath(settings_path="s1")
    assert p1.settings_path == "s1"

# Generated at 2022-06-23 20:13:47.440122
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type(0)
    expected_kind = type(1)
    obj = LiteralSortTypeMismatch(kind, expected_kind)
    assert obj.kind == kind
    assert obj.expected_kind == expected_kind



# Generated at 2022-06-23 20:13:48.275592
# Unit test for constructor of class ISortError
def test_ISortError():
    raise ISortError("hello")


# Generated at 2022-06-23 20:13:52.930404
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type(42)
    expected_kind = int
    exception = LiteralSortTypeMismatch(kind, expected_kind)
    assert str(exception) == "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'int'>." # noqa


# Generated at 2022-06-23 20:13:56.870833
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = "test_path"
    exception = FileSkipComment(file_path = path)
    assert exception.file_path == path
    assert exception.message == f"{path} contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:13:59.622250
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("/home/arush/foo.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "/home/arush/foo.py"

# Generated at 2022-06-23 20:14:00.529093
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist("plugin")

# Generated at 2022-06-23 20:14:03.703690
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as error:
        raise ExistingSyntaxErrors('file path')
    assert error.value.file_path == 'file path'


# Generated at 2022-06-23 20:14:06.027344
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    path = "file_path"
    file_skip_setting = FileSkipSetting(path)
    assert file_skip_setting.file_path == path

# Generated at 2022-06-23 20:14:13.209103
# Unit test for constructor of class MissingSection
def test_MissingSection():
    section = "Library imports first"
    import_module = "import requests"
    error = MissingSection(import_module, section)
    assert error.args[0] == \
        f"Found {import_module} import while parsing, but {section} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:14:14.246433
# Unit test for constructor of class ISortError
def test_ISortError():
    ISortError()

test_ISortError()

# Generated at 2022-06-23 20:14:16.416124
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        fs = FileSkipSetting("test")
    except FileSkipSetting:
        fs = None

    assert fs is None

# Generated at 2022-06-23 20:14:20.755173
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    err = UnsupportedEncoding(filename="test_filename")
    assert err.filename == "test_filename"
    assert str(err) == "Unknown or unsupported encoding in test_filename"

# Generated at 2022-06-23 20:14:30.189861
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        # noinspection PyUnresolvedReferences
        """raise LiteralParsingFailure(file_path='0123', original_error=KeyError(1,2,3))"""
        """raise LiteralParsingFailure('0123', KeyError(1,2,3))"""
        raise LiteralParsingFailure('0123', KeyError(1,2,3))

    except LiteralParsingFailure as error:
        assert str(error) == """isort failed to parse the given literal 0123. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of 'dict' object is not callable."""
        assert error.code == '0123'
        assert error.original_error.args == (1, 2, 3)
        assert error.original_

# Generated at 2022-06-23 20:14:33.006265
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    # Create the object IntroducedSyntaxErrors
    object_IntroducedSyntaxErrors = IntroducedSyntaxErrors("Test_file_path.py")
    # Unit test to ascertain the value of object
    assert object_IntroducedSyntaxErrors.file_path == "Test_file_path.py"

# Generated at 2022-06-23 20:14:35.745516
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        1/0
    except ZeroDivisionError:
        raise IntroducedSyntaxErrors(file_path = "some_file_path")


# Generated at 2022-06-23 20:14:39.079017
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("Failed")
    except:
        print("Error: ", sys.exc_info()[0]) 
        


# Generated at 2022-06-23 20:14:42.755444
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    """Performs unit test for constructor of class InvalidSettingsPath"""

    settings_path = "my/settings/path"
    actual = InvalidSettingsPath(settings_path)

    assert settings_path == actual.settings_path



# Generated at 2022-06-23 20:14:44.204955
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fil = FileSkipSetting("test")
    assert fil.file_path == "test"

# Generated at 2022-06-23 20:14:45.159094
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert True



# Generated at 2022-06-23 20:14:46.787215
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file = 'isort/cli.py'
    assert file == FileSkipComment(file).file_path


# Generated at 2022-06-23 20:14:51.503401
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    expected_kind = 'int'
    actual_kind = 'str'
    try:
        raise LiteralSortTypeMismatch(expected_kind, actual_kind)
    except LiteralSortTypeMismatch as e:
        assert str(e) == f"isort was told to sort a literal of type {expected_kind} but was given a literal of type {actual_kind}."
        assert e.kind == 'str'
        assert e.expected_kind == 'int'

# Generated at 2022-06-23 20:14:54.974714
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = str(Path("file_path"))
    exception = FileSkipComment(file_path)
    assert exception.file_path == file_path
    assert str(exception) == f"{file_path} contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:14:56.653897
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    with pytest.raises(FileSkipComment) as exception:
        raise FileSkipComment("test_path")
    assert str(exception.value) == "test_path contains an file skip comment and was skipped."

# Generated at 2022-06-23 20:14:59.146446
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('test_formatter')
    except FormattingPluginDoesNotExist as f:
        assert f.formatter == 'test_formatter'


# Generated at 2022-06-23 20:15:01.613941
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    print("Testing class ProfileDoesNotExist")
    profile = "yapf"
    err = ProfileDoesNotExist(profile)
    assert str(err) == f"Specified profile of {profile} does not exist. " \
                f"Available profiles: {','.join(profiles)}."
    print("Test passed!")

# Generated at 2022-06-23 20:15:04.326573
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('test1')
    except ProfileDoesNotExist as exception:
        assert exception.profile == 'test1'

# Generated at 2022-06-23 20:15:06.678738
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception = IntroducedSyntaxErrors(file_path="example.py")
    assert exception.file_path == "example.py"

# Generated at 2022-06-23 20:15:10.088742
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("abc", SyntaxError("abc"))
    except LiteralParsingFailure as e:
        assert e.code == "abc"
        assert e.original_error.msg == "abc"


# Generated at 2022-06-23 20:15:12.959438
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch('OK', 'ZE')
    except LiteralSortTypeMismatch as e:
        assert(e.kind == 'OK')
        assert(e.expected_kind == 'ZE')

# Generated at 2022-06-23 20:15:15.337684
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('CrazyFomat')
    except FormattingPluginDoesNotExist as e:
        assert str(e) == 'Specified formatting plugin of CrazyFomat does not exist. '

# Generated at 2022-06-23 20:15:24.858677
# Unit test for constructor of class MissingSection
def test_MissingSection():
    section = 'firstparty'
    import_module = 'test.test_test'
    try:
        raise MissingSection(import_module, section)
    except MissingSection as e:
        assert e.message == 'Found test.test_test import while parsing, but firstparty was not included ' \
            'in the `sections` setting of your config. Please add it before continuing\n' \
            'See https://pycqa.github.io/isort/#custom-sections-and-ordering ' \
            'for more info.'
        assert e.section == 'firstparty'
        assert e.import_module == 'test.test_test'

# Generated at 2022-06-23 20:15:30.851555
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = """a = 1
    b = 2"""
    exception = AssignmentsFormatMismatch(code)
    actual_message = exception.__str__()
    expected_message = (
        "isort was told to sort a section of assignments, however the given code:\n\n"
        f"{code}\n\n"
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
    )
    assert actual_message == expected_message
    assert exception.code == code

# Generated at 2022-06-23 20:15:32.328531
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert isinstance(FileSkipSetting("test_FileSkipSetting"), FileSkipped)

# Generated at 2022-06-23 20:15:34.212207
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert isinstance(LiteralSortTypeMismatch(1, 2), LiteralSortTypeMismatch)

# Generated at 2022-06-23 20:15:39.167892
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = "../test.py"
    exception = InvalidSettingsPath(path)
    assert str(exception) == f"isort was told to use the settings_path: {path} as the base " \
        "directory or file that represents the starting point of config file discovery, " \
        "but it does not exist."
    assert exception.settings_path == path

# Generated at 2022-06-23 20:15:41.246221
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # create object of class InvalidSettingsPath
    assert ISortError


# Generated at 2022-06-23 20:15:43.072227
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("ISortError")
    except ISortError as err:
        pass

# Generated at 2022-06-23 20:15:48.911094
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("this is a message", "file_path")
    except FileSkipped as err:
        assert str(err) == "this is a message"
        assert err.file_path == "file_path"
    else:
        assert False, "FileSkipped has not been raised"

# Generated at 2022-06-23 20:15:52.901223
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind="int"
    expected_kind="str"
    exp = "isort was told to sort a literal of type str but was given a literal of type int."
    assert str(LiteralSortTypeMismatch(kind, expected_kind)) == exp

# Generated at 2022-06-23 20:15:56.657019
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'message'
    file_path = 'file_path'
    f_skip = FileSkipped(message, file_path)
    assert f_skip.message == message
    assert f_skip.file_path == file_path

# Generated at 2022-06-23 20:16:00.516623
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    filepath = 'working.py'
    with pytest.raises(ExistingSyntaxErrors) as excinfo:
        raise ExistingSyntaxErrors(filepath)
    assert str(excinfo.value) == "isort was told to sort imports within code that contains syntax errors: working.py."

# Generated at 2022-06-23 20:16:03.252677
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test")
    except UnsupportedEncoding as e:
        assert e.filename == "test"


# Generated at 2022-06-23 20:16:06.245582
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    obj = UnsupportedEncoding(filename=b'\xc3\x83\xc2\xa9coute')
    assert obj.filename == b'\xc3\x83\xc2\xa9coute'

# Generated at 2022-06-23 20:16:10.321916
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test/test_file"
    skip_setting = FileSkipSetting(file_path)
    assert skip_setting.file_path == file_path
    assert skip_setting.message == f"{file_path} was skipped as it's listed in 'skip' setting " \
                                   "or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:16:11.684310
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('not-exist-path')
    except ISortError as e:
        assert e.settings_path == 'not-exist-path'


# Generated at 2022-06-23 20:16:14.074544
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    instance = LiteralSortTypeMismatch(1, 2)
    assert isinstance(instance, LiteralSortTypeMismatch)


# Generated at 2022-06-23 20:16:17.561664
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    # class under test instantiation
    try:
        raise FormattingPluginDoesNotExist("")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == ""



# Generated at 2022-06-23 20:16:19.719819
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-23 20:16:22.200209
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "../test"
    try:
        raise FileSkipComment(file_path)
    except FileSkipComment as e:
        assert e.file_path == file_path

# Generated at 2022-06-23 20:16:24.209591
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    obj = InvalidSettingsPath("test")


# Generated at 2022-06-23 20:16:26.313243
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = 'a, b'
    original_error = "SyntaxError"
    exception = LiteralParsingFailure(code, original_error)
    assert(exception.code == code)
    assert(exception.original_error == original_error)

# Generated at 2022-06-23 20:16:28.418023
# Unit test for constructor of class ISortError
def test_ISortError():
    # Act
    error = ISortError("The error message")

    # Assert
    assert error.args == ("The error message",)

# Generated at 2022-06-23 20:16:32.251409
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {'unsupported_setting': {'value': 'unsupported_value', 'source': '.'}}
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:16:37.004403
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(1, 'str')
    except LiteralSortTypeMismatch as e:
        assert str(e) == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>.\n"
        assert e.kind == 1
        assert e.expected_kind == 'str'

# Generated at 2022-06-23 20:16:39.250586
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit tests for UnsupportedSettings class"""
    # Test UnsupportedSettings constructor
    UnsupportedSettings({"test": {"value": 2, "source": "test"}})

# Generated at 2022-06-23 20:16:41.020865
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("hello")
    except Exception as err:
        assert err.file_path == "hello", err

# Generated at 2022-06-23 20:16:42.865452
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    with pytest.raises(UnsupportedSettings):
        UnsupportedSettings({"a": {"value": 1, "source": "some source"}})

# Generated at 2022-06-23 20:16:46.294761
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError) as error:
        raise ISortError("Test")

    assert "Test" == error.value.args[0]

# Generated at 2022-06-23 20:16:50.402322
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("this is a test", "/tmp/test.py")
    except FileSkipped as e:
        assert e.message == "this is a test"
        assert e.file_path == "/tmp/test.py"

# Generated at 2022-06-23 20:16:53.820744
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    from .settings import DEFAULT_CONFIG, Config

    unsupported = Config("iosrt", "root", DEFAULT_CONFIG)
    with pytest.raises(UnsupportedSettings):
        raise UnsupportedSettings(unsupported)

# Generated at 2022-06-23 20:16:55.851063
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("a")
    except ProfileDoesNotExist as error:
        assert error.profile == "a"

# Generated at 2022-06-23 20:17:02.375104
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    def _format_option(name: str, value: Any, source: str) -> str:
        return f"\t- {name} = {value}  (source: '{source}')"

    assert UnsupportedSettings._format_option("something", "something", "something") == "\t- something = something  (source: 'something')"

# Generated at 2022-06-23 20:17:08.631901
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    import pytest

    class UserError(Exception):
        """Exception raised for errors in the input.

        Attributes:
            message -- explanation of the error
        """

        def __init__(self, message):
            self.message = message

    with pytest.raises(LiteralSortTypeMismatch) as excinfo:
        raise LiteralSortTypeMismatch(
            kind=int, expected_kind=str
        )
    assert "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>" in str(excinfo.value)


# Generated at 2022-06-23 20:17:13.734902
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Test normal usage (should not raise an error or return a value)
    try:
        raise LiteralSortTypeMismatch(kind=str, expected_kind=int)
    except LiteralSortTypeMismatch as exception:
        assert str(exception) == r"isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>.\n"
        assert exception.kind == str
        assert exception.expected_kind == int
    else:
        raise AssertionError()


# Generated at 2022-06-23 20:17:18.756934
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a=1b=2"
    exception = AssignmentsFormatMismatch(code)
    assert isinstance(exception, ISortError)
    assert isinstance(exception, AssignmentsFormatMismatch)
    assert exception.code == code 
    return

# Generated at 2022-06-23 20:17:21.102375
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {"a": 1, "b": "2", "c": 3}
    assert UnsupportedSettings(settings) is not None



# Generated at 2022-06-23 20:17:22.585904
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    ue = UnsupportedEncoding('my.py')
    assert ue.filename == 'my.py'

# Generated at 2022-06-23 20:17:24.310199
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped('message', 'file_path').message == 'message'
    assert FileSkipped('message', 'file_path').file_path == 'file_path'

# Generated at 2022-06-23 20:17:35.838254
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Test for UnsupportedSettings constructor."""
    unsupported_settings = {
        "also_make_glob": {"value": "*", "source": "config"},
        "known_standard_library": {"value": "std", "source": "settings"},
    }
    excpt = UnsupportedSettings(unsupported_settings)
    assert excpt.unsupported_settings["known_standard_library"] == unsupported_settings["known_standard_library"]
    assert excpt.unsupported_settings["also_make_glob"] == unsupported_settings["also_make_glob"]

# Generated at 2022-06-23 20:17:39.321689
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    class_instance = LiteralSortTypeMismatch(1, 'a')
    assert f"isort was told to sort a literal of type str but was given a literal of type int." in class_instance.__str__()

# Generated at 2022-06-23 20:17:42.622512
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    exception = FormattingPluginDoesNotExist("formatter")
    assert str(exception) == "Specified formatting plugin of formatter does not exist. "
    assert exception.formatter == "formatter"

# Generated at 2022-06-23 20:17:45.969264
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {
        'known_first_party': {'value': 'test', 'source': 'test_source'}
    }

    error = UnsupportedSettings(settings)

    assert error.unsupported_settings == settings
    assert 'known_first_party' in error.__str__()

# Generated at 2022-06-23 20:17:49.580812
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():

    obj = FileSkipComment('a.py')
    assert obj.file_path == 'a.py'


# Generated at 2022-06-23 20:17:52.059159
# Unit test for constructor of class MissingSection
def test_MissingSection():
    obj = MissingSection("import_module", "section")
    assert hasattr(obj, 'import_module')
    assert hasattr(obj, 'section')


# Generated at 2022-06-23 20:17:55.402317
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist("profile")
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist("profile")


# Generated at 2022-06-23 20:17:57.696480
# Unit test for constructor of class ISortError
def test_ISortError():
    instance = ISortError('error')
    assert isinstance(instance, Exception)
    assert isinstance(instance, ISortError)


# Generated at 2022-06-23 20:17:59.396230
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    err:InvalidSettingsPath = InvalidSettingsPath("/tmp")
    assert err.settings_path == "/tmp"


# Generated at 2022-06-23 20:18:02.890047
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Tests that constructor of `UnsupportedSettings` class raises TypeError when incorrect
    argument is passed, e.g. list instead of dictionary.
    """
    with pytest.raises(TypeError):
        UnsupportedSettings([])

# Generated at 2022-06-23 20:18:05.647417
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'hello.py'
    err = FileSkipSetting(file_path=file_path)
    assert err.file_path == file_path

# Generated at 2022-06-23 20:18:09.169681
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "abc.py"
    ue = UnsupportedEncoding(filename)
    assert ue.filename == "abc.py"
    assert str(ue) == "Unknown or unsupported encoding in abc.py"



# Generated at 2022-06-23 20:18:14.450716
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    test_code = "test_code"
    test_error = "test_error"
    literal_failure = LiteralParsingFailure(test_code, test_error)
    assert literal_failure.code == test_code
    assert literal_failure.original_error == test_error


# Generated at 2022-06-23 20:18:16.278348
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("/my/file/path").file_path == "/my/file/path"


# Generated at 2022-06-23 20:18:19.384380
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    from .utils import format_code

    test_code = """a = 1
b = 2"""

    formatted_code = format_code(test_code, line_length=80)
    assert formatted_code == test_code

# Generated at 2022-06-23 20:18:24.155364
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    import ast
    expr = '{"sort_this": "yep"}'
    test = ast.literal_eval(expr)
    assert isinstance(test, dict)
    assert type(test) is dict
    assert LiteralSortTypeMismatch.__init__(dict, str)

# Generated at 2022-06-23 20:18:27.120736
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings(
        {
            "frobnicate": {
                "value": "hitch",
                "source": "tests/settings.py",
            },
        }
    )

# Generated at 2022-06-23 20:18:29.731364
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch([1,2],str)
    except ISortError as e:
        assert e.__class__ == LiteralSortTypeMismatch
        assert e.expected_kind == str
        assert e.kind == list
        assert issubclass(e.__class__,ISortError)


# Generated at 2022-06-23 20:18:32.014486
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    encoding = UnsupportedEncoding("/etc/passwd")
    assert encoding.__str__() == "Unknown or unsupported encoding in /etc/passwd"

# Generated at 2022-06-23 20:18:35.150882
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test_file")
    except ExistingSyntaxErrors as e:
        assert str(e) == (
            "isort was told to sort imports within code that contains syntax errors: "
            "test_file."
        )

# Generated at 2022-06-23 20:18:38.935108
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fs=FileSkipped("test_message","test_path")
    assert fs.message=="test_message", 'FileSkipped::message'
    assert fs.file_path=="test_path", 'FileSkipped::file_path'


# Generated at 2022-06-23 20:18:43.031494
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "message"
    file_path = "file_path"
    try:
        raise FileSkipped(message, file_path)
    except FileSkipped as fs:
        assert fs.args[0] == message
        assert fs.args[1] == file_path

# Generated at 2022-06-23 20:18:45.635824
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as error:
        assert error.kind == str
        assert error.expected_kind == int

# Generated at 2022-06-23 20:18:46.400472
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch

# Generated at 2022-06-23 20:18:49.951391
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('foo', 'bar').args[0] == (
        'Found foo import while parsing, but bar was not included in the '
        '`sections` setting of your config. Please add it before continuing\n'
        'See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'
    )

# Generated at 2022-06-23 20:18:52.836928
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding) as exc:
        UnsupportedEncoding(1)
    assert str(exc) == "Unknown or unsupported encoding in 1"


# Generated at 2022-06-23 20:18:53.836394
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    ExistingSyntaxErrors("The file path")

# Generated at 2022-06-23 20:18:57.325597
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # test UnsupportedEncoding class
    print('Testing UnsupportedEncoding class...')
    file_name = 'isort'
    try:
        raise UnsupportedEncoding(file_name)
    except UnsupportedEncoding as e:
        assert e.filename == file_name
    print('UnsupportedEncoding class unit test passed!')


# Generated at 2022-06-23 20:19:00.686942
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("test")
    except AssignmentsFormatMismatch as e:
        assert e.code == "test"

# Generated at 2022-06-23 20:19:07.184770
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """
    Check for a constructed instance of the class LiteralParsingFailure
    """
    my_code = "my code"
    my_original_error = Exception("original error")
    my_obj = LiteralParsingFailure(my_code, my_original_error)
    assert my_obj.code == my_code
    assert my_obj.original_error == my_original_error

# Generated at 2022-06-23 20:19:08.758809
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    err = AssignmentsFormatMismatch('a')
    assert err.code == 'a'

# Generated at 2022-06-23 20:19:10.551043
# Unit test for constructor of class ISortError
def test_ISortError():
    error_obj = ISortError("This is ISortError.")
    assert error_obj.args[0] == "This is ISortError."

# Generated at 2022-06-23 20:19:12.922750
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = FormattingPluginDoesNotExist("formatter")
    assert isinstance(formatter, FormattingPluginDoesNotExist)

# Generated at 2022-06-23 20:19:15.001075
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(1,2) == LiteralSortTypeMismatch(kind = 1,expected_kind = 2)
    
    

# Generated at 2022-06-23 20:19:16.435455
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError('Fix this')


# Generated at 2022-06-23 20:19:20.291507
# Unit test for constructor of class MissingSection
def test_MissingSection():
    test_import_module = 'os'
    test_section = 'FUTURE'
    try:
        MissingSection(test_import_module, test_section)
    except MissingSection as exception:
        assert exception.import_module == test_import_module
        assert exception.section == test_section
        return
    assert False


# Generated at 2022-06-23 20:19:21.977091
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("file.txt")
    except UnsupportedEncoding as exc:
        assert exc.filename == "file.txt"

# Generated at 2022-06-23 20:19:24.301813
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding):
        raise UnsupportedEncoding("filename")

# Generated at 2022-06-23 20:19:30.000644
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    """
    test IntroducedSyntaxErrors

    test the constructor for class IntroducedSyntaxErrors execute
    with input file_path and test the attributes of it

    Returns:
        true if the attributes is equal and the type is correct
    """
    try:
        a = IntroducedSyntaxErrors("a.py")
        assert a.file_path == "a.py"
        assert a.__str__ == """
            isort introduced syntax errors when attempting to sort the imports contained within 
            a.py.
            """
        return True
    except:
        return False


# Generated at 2022-06-23 20:19:31.088950
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("test").file_path == "test"

# Generated at 2022-06-23 20:19:34.703461
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    x = """string"""
    class TestException(Exception):
        pass
    try:
        raise TestException("Error")
    except TestException as e:
        LiteralParsingFailure(x, e)

# Generated at 2022-06-23 20:19:36.528872
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception = UnsupportedEncoding("test.py")
    assert exception.filename == "test.py"

# Generated at 2022-06-23 20:19:45.181298
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    name = "test_name"
    value = "test_value"
    source = "test_source"
    unsupported_settings = {"test_name": {"value": "test_value", "source": "test_source"}}
    error = UnsupportedSettings(unsupported_settings)
    assert (
        error.__str__() == f"isort was provided settings that it doesn't support:\n\n\t- {name} = {value}  (source: '{source}')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )
    assert error.unsupported_settings == {"test_name": {"value": "test_value", "source": "test_source"}}

# Generated at 2022-06-23 20:19:47.075839
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = UnsupportedSettings({"settings_file_paths": {"value": "a"}}).unsupported_settings
    assert unsupported_settings == {"settings_file_paths" : {"value": "a"}}

# Generated at 2022-06-23 20:19:47.869226
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError


# Generated at 2022-06-23 20:19:50.003544
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """Unit test for constructor of class LiteralSortTypeMismatch"""
    t = LiteralSortTypeMismatch
    t("str", "int")


# Generated at 2022-06-23 20:19:51.094491
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped("Test", "test")

# Generated at 2022-06-23 20:19:55.257942
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise InvalidSettingsPath('test')
    except InvalidSettingsPath as exception:
        assert isinstance(exception, ISortError)
        assert str(exception) == 'isort was told to use the settings_path: test as the base ' \
                             'directory or file that represents the starting point of config' \
                             ' file discovery, but it does not exist.'
        assert exception.settings_path == 'test'


# Generated at 2022-06-23 20:20:03.888006
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    import ast

    ast.parse("a = 'aa' + b")
    a = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.BinOp(left=ast.Str(s='aa'), op=ast.Add(), right=ast.Name(id='b', ctx=ast.Load())))
    a.value = ast.Str(s="")

    source_code = "a = 'aa' + b"
    code_object = compile(source_code, filename='<ast>', mode='exec')
    module = ast.Module(body=[a])
    code = ast.increment_lineno(module, lineno=1)
    co = compile(code, filename='<ast>', mode='exec')


# Generated at 2022-06-23 20:20:06.279283
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    f = FileSkipped(message="message", file_path="file_path")
    assert f.message=="message"
    assert f.file_path=="file_path"


# Generated at 2022-06-23 20:20:08.678938
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test plugin")
        assert False
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test plugin"

# Generated at 2022-06-23 20:20:12.329083
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    test_obj = UnsupportedEncoding("test.py")
    assert test_obj.args[0] == "Unknown or unsupported encoding in test.py", test_obj.args[0]
    assert test_obj.filename == "test.py"



# Generated at 2022-06-23 20:20:13.949007
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors("/foo/bar")


# Generated at 2022-06-23 20:20:17.895996
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("formatter")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of formatter does not exist."
        assert e.formatter == "formatter"


# Generated at 2022-06-23 20:20:20.580024
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("hello")
    except ISortError as e:
        assert "hello" == str(e)
    else:
        assert False, "cannot get here"


# Generated at 2022-06-23 20:20:22.328257
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('Message')
    except Exception as e:
        assert str(e) == 'Message'



# Generated at 2022-06-23 20:20:29.419144
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # GIVEN
    test_settings = {
        "fake_setting1":   {"value": "fake_value", "source": "fake_source"},
        "fake_setting2":   {"value": "fake_value", "source": "fake_source"},
        "fake_setting3":   {"value": "fake_value", "source": "fake_source"},
    }
    # WHEN
    test_us = UnsupportedSettings(test_settings)
    # THEN
    assert test_us.unsupported_settings == test_settings

# Generated at 2022-06-23 20:20:33.068911
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("Standard")
    except ProfileDoesNotExist as e1:
        assert e1.profile == "Standard"
        assert str(e1) == "Specified profile of Standard does not exist. Available profiles: " +\
            ", ".join(profiles) + "."

# Generated at 2022-06-23 20:20:38.551915
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "'hello','world'"
    original_error = ISortError("Test")
    literal_parsing_failure = LiteralParsingFailure(code, original_error)
    assert (
        literal_parsing_failure._message ==
        "isort failed to parse the given literal 'hello','world'. It's important to note "
        "that isort literal sorting only supports simple literals parsable by "
        "ast.literal_eval which gave the exception of Test."
    )
    assert literal_parsing_failure.code == code
    assert literal_parsing_failure.original_error == original_error


# Generated at 2022-06-23 20:20:43.308710
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    f1 = FileSkipSetting('path_to_file')
    assert f1.file_path == 'path_to_file'
    assert str(f1) == 'path_to_file was skipped as it\'s listed in \'skip\' setting ' \
                      'or matches a glob in \'skip_glob\' setting'


# Generated at 2022-06-23 20:20:45.926243
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profiles_list = profiles()
    error = ProfileDoesNotExist('test')
    assert 'test' == error.profile
    assert 'Specified profile of test does not exist. Available profiles: ' + \
        ', '.join(profiles_list) == str(error)

# Generated at 2022-06-23 20:20:46.799054
# Unit test for constructor of class ISortError
def test_ISortError():
    error = ISortError()
    return error

# Generated at 2022-06-23 20:20:48.845372
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist):
        raise FormattingPluginDoesNotExist('')


# Generated at 2022-06-23 20:20:51.558411
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter="hello"
    exception=FormattingPluginDoesNotExist(formatter)
    assert exception.formatter == formatter
    assert str(exception) == f"Specified formatting plugin of {formatter} does not exist. "

# Generated at 2022-06-23 20:20:53.407058
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    "check length of error message when initializing UnsupportedEncoding"
    unsupported = UnsupportedEncoding("test")
    assert len(unsupported.args[0]) == 34


# Generated at 2022-06-23 20:20:54.954451
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("settings.py")


# Generated at 2022-06-23 20:20:55.742338
# Unit test for constructor of class ISortError
def test_ISortError():
    err = ISortError()
    assert isinstance(err, Exception) is True

# Generated at 2022-06-23 20:20:57.599734
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    raise ProfileDoesNotExist("test")

# Generated at 2022-06-23 20:21:00.006214
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("file_path")
    except FileSkipComment as e:
        assert e.file_path == "file_path"

# Generated at 2022-06-23 20:21:04.174500
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert str(
        UnsupportedSettings({"blah": {"value": "blah", "source": "blah"}})
    ) == "isort was provided settings that it doesn't support:\n\n\t- blah = blah  (source: 'blah')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"



# Generated at 2022-06-23 20:21:06.929706
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    class ExistingSyntaxErrors(ISortError):
        """Raised when isort is told to sort imports within code that has existing syntax errors"""

        def __init__(self, file_path: str):
            super().__init__(file_path)

    try:
        raise ExistingSyntaxErrors(file_path='test_path')
    except ExistingSyntaxErrors as e:
        assert e.file_path == 'test_path'

# Generated at 2022-06-23 20:21:07.942523
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath(settings_path="settings").settings_path == "settings"


# Generated at 2022-06-23 20:21:12.829328
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = 'file_path'
    message = 'message'
    skipped = FileSkipped(message, file_path)
    assert skipped.message == message
    assert skipped.file_path == file_path

# Generated at 2022-06-23 20:21:14.918526
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    "unit test for constructor of class AssignmentsFormatMismatch."
    AssignmentsFormatMismatch('')

# Generated at 2022-06-23 20:21:17.234357
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    a = InvalidSettingsPath("/home/test")
    assert a.args[0] == "/home/test"

# Generated at 2022-06-23 20:21:20.439286
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as ex:
        assert (ex.kind == str)
        assert (ex.expected_kind == int)

# Generated at 2022-06-23 20:21:27.157352
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert (
        str(LiteralSortTypeMismatch(kind=int, expected_kind=str))
        == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>.\n"
        "CRITICAL: isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>.\n"
        "Please report this error to https://github.com/timothycrosley/isort/"
    )

# Generated at 2022-06-23 20:21:29.314480
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors, match = "does not exist."):
        raise ExistingSyntaxErrors("/Users/John/test")


# Generated at 2022-06-23 20:21:35.216619
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"section_name": "import name"}
    example = UnsupportedSettings(unsupported_settings)
    assert example.unsupported_settings == unsupported_settings
    assert example.__str__() == f"isort was provided settings that it doesn't support:\n\n\t- section_name = import name  (source: 'default')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"

# Generated at 2022-06-23 20:21:37.760315
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    with pytest.raises(FileSkipSetting):
        raise FileSkipSetting("path/to/file")

# Generated at 2022-06-23 20:21:42.945401
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("foo/bar.py")
    except ExistingSyntaxErrors as err:
        assert str(err) == "isort was told to sort imports within code that contains syntax errors: foo/bar.py."
        assert err.file_path == "foo/bar.py"


# Generated at 2022-06-23 20:21:46.925812
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    import pytest
    from .core.exceptions import FileSkipSetting
    with pytest.raises(FileSkipSetting) as e:
        raise FileSkipSetting("/Users/bibinbin/Workspace/python-isort/isort/core/exceptions.py")

# Generated at 2022-06-23 20:21:50.004304
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test/test_file.py"
    exception = FileSkipComment(file_path)
    assert exception.message == f"{file_path} contains an file skip comment and was skipped."
    assert exception.file_path == "test/test_file.py"

# Generated at 2022-06-23 20:22:00.675606
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"setting1": {"value": "val1", "source": "s1"},
                            "setting2": {"value": "val2", "source": "s2"}}
    with pytest.raises(UnsupportedSettings) as e:
        raise UnsupportedSettings(unsupported_settings)
    assert e.value.unsupported_settings == unsupported_settings
    assert ("isort was provided settings that it doesn't support:\n\n"
            "\t- setting1 = val1  (source: 's1')\n"
            "\t- setting2 = val2  (source: 's2')\n\n"
            "For a complete and up-to-date listing of supported settings see: "
            "https://pycqa.github.io/isort/docs/configuration/options/.\n"
            )

# Generated at 2022-06-23 20:22:07.821529
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # Arrange
    settings_path = 'test_files/test_err_config.yaml'

    # Act
    with pytest.raises(InvalidSettingsPath) as exception:
        raise InvalidSettingsPath('test')

    # Assert
    assert str(exception.value) == 'isort was told to use the settings_path: test as the base directory or ' \
                                   'file that represents the starting point of config file discovery, but it does not ' \
                                   'exist.'



# Generated at 2022-06-23 20:22:08.941376
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting(file_path = "test.py")


# Generated at 2022-06-23 20:22:11.930962
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    literal_parsing_failure = LiteralParsingFailure("code", Exception())
    assert literal_parsing_failure.code == "code"
    assert isinstance(literal_parsing_failure.original_error, Exception)

# Generated at 2022-06-23 20:22:15.443369
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("test/test_isort")
    except InvalidSettingsPath as e:
        assert e.settings_path == "test/test_isort"


# Generated at 2022-06-23 20:22:23.159165
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    from .line import Line
    from .section import Section
    from .utils import load_settings
    line = Line("a", True, Section("", "", "", "", "", ""), 0, load_settings())
    # Asserting the parameter Line
    assert isinstance(line, Line) 
    # Asserting the method Line.__str__
    assert isinstance(str(line), str)
    # Asserting the method Line.__bool__
    assert bool(line) 
    # Asserting the method Line.__eq__
    assert not (line == "")
    # Asserting the method Line.__repr__
    assert isinstance(repr(line), str)
    # Asserting the method Line.__hash__    
    assert isinstance(hash(line), int)
    # Asserting the

# Generated at 2022-06-23 20:22:25.299263
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors('liu')
    assert error.file_path == 'liu'


# Generated at 2022-06-23 20:22:27.499989
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError as e:
        assert str(e) == 'None'


# Generated at 2022-06-23 20:22:28.820682
# Unit test for constructor of class ISortError
def test_ISortError():
    myerror = ISortError()
    assert myerror != None