

# Generated at 2022-06-23 20:12:30.435944
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # setting variables
    settings_path = 'abs'
    # calling constructor
    invalid_settings_path = InvalidSettingsPath(settings_path)
    # checking results
    assert invalid_settings_path.settings_path == settings_path


# Generated at 2022-06-23 20:12:37.744729
# Unit test for constructor of class MissingSection
def test_MissingSection():
    """Unit test for constructor of class MissingSection"""

    expected_msg = """Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing
See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."""
    exc = MissingSection('import_module', 'section')
    assert exc.__class__.__name__ == 'MissingSection'
    assert str(exc) == expected_msg


# Generated at 2022-06-23 20:12:42.716343
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting(file_path='/abc/file')
    except FileSkipSetting as e:
        assert str(e) == "/abc/file was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
        assert e.file_path == '/abc/file'

# Generated at 2022-06-23 20:12:47.203378
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    plugin = 'nvim'
    try:
        raise FormattingPluginDoesNotExist(plugin)
    except FormattingPluginDoesNotExist as err:
        assert err.formatter == plugin


# Generated at 2022-06-23 20:12:48.809813
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("test message", "test path")


# Generated at 2022-06-23 20:12:49.900913
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    LiteralParsingFailure("my_code", "my_error")

# Generated at 2022-06-23 20:12:55.604321
# Unit test for constructor of class ISortError
def test_ISortError():
    # Arrange
    actual = ISortError("test")

    # Assert
    assert actual.message == "test"



# Generated at 2022-06-23 20:12:57.533658
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, dict)
    except Exception:
        pass

# Generated at 2022-06-23 20:13:01.136007
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        try:
            raise UnsupportedEncoding("test.py")
        except UnsupportedEncoding as e:
            print(e.args[0])
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-23 20:13:04.631971
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    import_Module_invalid = FileSkipSetting('/path/to/file')
    expected_str = "/path/to/file was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert str(import_Module_invalid) == expected_str

# Generated at 2022-06-23 20:13:09.263497
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'test.py'
    file_skip_comment = FileSkipComment(file_path)
    assert file_skip_comment.message == 'test.py contains an file skip comment and was skipped.'
    assert file_skip_comment.file_path == file_path

# Generated at 2022-06-23 20:13:11.526169
# Unit test for constructor of class ISortError
def test_ISortError():
    a=ISortError("test")
    assert a.message=="test"
    assert isinstance(a, ISortError)
    assert isinstance(a, Exception)
    assert str(a)=="test"


# Generated at 2022-06-23 20:13:12.968965
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("/test")


# Generated at 2022-06-23 20:13:19.503358
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a=1, b=2")
    except AssignmentsFormatMismatch as error:
        assert str(error) == "isort was told to sort a section of assignments, however the given code:\n\n" \
                     f"a=1, b=2\n\n" \
                     "Does not match isort's strict single line formatting requirement for assignment " \
                     "sorting:\n\n" \
                     "{variable_name} = {value}\n" \
                     "{variable_name2} = {value2}\n" \
                     "...\n\n"
        assert error.code == "a=1, b=2"


# Generated at 2022-06-23 20:13:24.953956
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    """Unit test for constructor of class ProfileDoesNotExist"""
    with pytest.raises(ProfileDoesNotExist) as exception_info:
        raise ProfileDoesNotExist("foo")
    assert str(exception_info.value) == (
        "Specified profile of foo does not exist. " "Available profiles: default"
    )

# Generated at 2022-06-23 20:13:29.995469
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors('C:\\Users\\daniel.donath\\Desktop\\Python\\IsortAufgabe\\Sortierungsfehler')
    except ISortError as e:
        assert e.file_path == 'C:\\Users\\daniel.donath\\Desktop\\Python\\IsortAufgabe\\Sortierungsfehler'
        assert isinstance(e,ISortError)


# Generated at 2022-06-23 20:13:35.889319
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    # GIVEN
    file_path = 'test.txt'
    # WHEN
    result = IntroducedSyntaxErrors(file_path)
    # THEN
    assert result.file_path == file_path
    assert result.args == (
        f"isort introduced syntax errors when attempting to sort the imports contained within "
        f"{file_path}.",
    )


# Generated at 2022-06-23 20:13:36.969862
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test"
    assert FileSkipSetting(file_path=file_path).file_path == file_path

# Generated at 2022-06-23 20:13:40.453864
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment(file_path = "a.py")
    except FileSkipComment as exception:
        assert exception.message == "a.py contains an file skip comment and was skipped."
        assert exception.file_path == "a.py"


# Generated at 2022-06-23 20:13:44.363958
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    error = LiteralSortTypeMismatch(tuple, list)
    assert error.kind is tuple
    assert error.expected_kind is list
    assert str(error) == ("isort was told to sort a literal of type <class 'list'> but was "
                          "given a literal of type <class 'tuple'>.")


# Generated at 2022-06-23 20:13:50.185282
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        a = int("abc")
    except ValueError as e:
        try:
            raise ExistingSyntaxErrors("test_file.py") from e
        except ExistingSyntaxErrors as e:
            assert e.file_path == "test_file.py"
            assert str(e) == ("isort was told to sort imports within code that contains syntax "
                              "errors: test_file.py.")

# Generated at 2022-06-23 20:13:52.137781
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath) as error:
        raise InvalidSettingsPath("hola")


# Generated at 2022-06-23 20:13:55.760008
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported = UnsupportedSettings(unsupported_settings=dict(name=dict(value=1, source='a')))
    assert unsupported.unsupported_settings == dict(name=dict(value=1, source='a'))

# Generated at 2022-06-23 20:13:59.031261
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(FileSkipped) as info:
        raise FileSkipped('skipped','skipped')
    assert str(info.value) == 'skipped'
    assert info.value.file_path == 'skipped'

# Generated at 2022-06-23 20:14:04.194951
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # GIVEN
    file_path = '/home/user/file.py'
    # WHEN
    e = FileSkipSetting(file_path)
    # THEN
    assert e.file_path == file_path
    assert str(e) == "FileSkipSetting(file_path=%r)" % file_path

# Generated at 2022-06-23 20:14:09.307238
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # Get the class by name
    klass = globals()["AssignmentsFormatMismatch"]
    # Instantiate the class
    ins = klass("a = 1\nb = 2\n\n")
    # Assert the class name
    assert ins.__class__.__name__ == "AssignmentsFormatMismatch"
    # Assert the error message
    assert ins.args[0].startswith("isort was told to sort a section of assignments, however the given code:")


# Generated at 2022-06-23 20:14:12.845454
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'formatter'
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except ISortError as e:
        assert e.formatter == formatter


# Generated at 2022-06-23 20:14:15.489567
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    # empty list of code
    code = []
    original_error = ValueError("ValueError")
    LiteralParsingFailure(code, original_error)



# Generated at 2022-06-23 20:14:19.880108
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    test_file = "test_file.txt"
    try:
        raise UnsupportedEncoding(test_file)
    except UnsupportedEncoding as e:
        assert e.msg == f"Unknown or unsupported encoding in {test_file}"
        assert e.filename == test_file
        assert e.args[0] == f"Unknown or unsupported encoding in {test_file}"

# Generated at 2022-06-23 20:14:23.725494
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    """This function tests the constructor of the class AssignmentsFormatMismatch """
    err = AssignmentsFormatMismatch(code="a = b\nc = d")
    assert err.code == "a = b\nc = d"

# Generated at 2022-06-23 20:14:27.639119
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "message"
    file_path = "file_path"
    FileSkipped(message=message, file_path=file_path)


# Generated at 2022-06-23 20:14:30.996787
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("profile")
    except Exception as ex:
        assert str(ex) == "Specified profile of profile does not exist. Available profiles: " \
               "black, github, google, pycharm, vint, vscode, trailblazer, django, " \
               "flask, kedro, hug, bandit, pytest, atom, vscode_pytest, vscode_black, " \
               "vscode_mccabe, vscode_radon, vscode_pytype, vscode_bandit."



# Generated at 2022-06-23 20:14:35.887337
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("<file_path>")
    except FileSkipSetting as e:
        assert e.file_path == "<file_path>"
        assert str(e) == "<file_path> was skipped as it's listed in 'skip' setting " \
                         "or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-23 20:14:38.534573
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    l = ExistingSyntaxErrors("readme.md")
    assert isinstance(l, ISortError)


# Generated at 2022-06-23 20:14:41.958801
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = "FilePath"
    message = "Message"
    obj = FileSkipped(message, file_path)
    assert obj.file_path == file_path
    assert obj.message == message

# Generated at 2022-06-23 20:14:44.201608
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    exception = LiteralSortTypeMismatch(int, float)
    assert exception.kind == int
    assert exception.expected_kind == fl

# Generated at 2022-06-23 20:14:49.287423
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('file_path')
        assert False
    except IntroducedSyntaxErrors as e:
        assert e.file_path == 'file_path'
    print("test_IntroducedSyntaxErrors Pass!")


# Generated at 2022-06-23 20:14:50.768520
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    error = FileSkipped("message", "path")
    assert error.file_path=="path"
    return error

# Generated at 2022-06-23 20:14:54.487556
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('modules', 'section')
    except MissingSection as instance:
        assert 'Found modules import while parsing' in str(instance)
        assert 'but section was not included in the `sections` setting of your config' in str(instance)



# Generated at 2022-06-23 20:14:58.999719
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("abc,abc")
        assert False
    except ProfileDoesNotExist as e:
        assert str(e) == (
            "Specified profile of abc,abc does not exist. "
            f"Available profiles: {','.join(profiles)}."
        )
        assert e.profile == "abc,abc"
    else:
        assert True



# Generated at 2022-06-23 20:15:00.618607
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    x = FileSkipComment("test")
    assert x.file_path=="test"


# Generated at 2022-06-23 20:15:06.991632
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """Unit test for constructor of class LiteralParsingFailure"""
    code = "[]]"
    original_error = SyntaxError("mismatched input")
    error = LiteralParsingFailure(code, original_error)
    assert error is not None
    assert error.code == code
    assert error.original_error == original_error
    assert str(error) == (
        f"isort failed to parse the given literal {code}. It's important to note "
        "that isort literal sorting only supports simple literals parsable by "
        f"ast.literal_eval which gave the exception of {original_error}."
    )



# Generated at 2022-06-23 20:15:12.433740
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Set up test object with valid inputs
    filename = "file.py"

    test_object = ExistingSyntaxErrors(filename)

    # Check that the class variables are set properly
    assert test_object.file_path == filename
    # Check that the message is set properly with valid inputs
    assert test_object.args[0] == \
      f"isort was told to sort imports within code that contains syntax errors: " \
      f"{filename}."

# Generated at 2022-06-23 20:15:14.466669
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("TestException")
    except ProfileDoesNotExist as e:
        assert e.profile is not None
        assert e.profile == "TestException"

# Generated at 2022-06-23 20:15:18.696641
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    f = FormattingPluginDoesNotExist("yapf")
    assert(f.formatter == "yapf")
    assert(f.__class__.__name__ == "FormattingPluginDoesNotExist")

# Generated at 2022-06-23 20:15:24.676103
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise ValueError("Test")
    except Exception as exception:
        try:
            raise LiteralParsingFailure("{foo}", exception)
        except LiteralParsingFailure as literal_parsing_failure:
            assert literal_parsing_failure.code == "{foo}"
            assert literal_parsing_failure.original_error == exception
        else:
            assert False



# Generated at 2022-06-23 20:15:29.426596
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    ms = MissingSection(import_module, section)
    assert ms.args[0] == f"Found {import_module} import while parsing, but {section} was not included "
    "in the `sections` setting of your config. Please add it before continuing\n"
    "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
    "for more info."

# Generated at 2022-06-23 20:15:34.260069
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    """
    Test the constructor of ProfileDoesNotExist class.
    """
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"


# Generated at 2022-06-23 20:15:38.522530
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = 'a = b\n'
    error = AssignmentsFormatMismatch(code)
    assert error.code == code
    assert 'isort was told to sort a section of assignments, however the given code:\n' in str(error)



# Generated at 2022-06-23 20:15:43.268735
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("function_name")
    except FormattingPluginDoesNotExist as inst:
        assert inst.args[0] == "Specified formatting plugin of function_name does not exist. "
        assert inst.formatter == "function_name"


# Generated at 2022-06-23 20:15:47.102118
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    pf = InvalidSettingsPath('/home/facundo/Desktop/Test')
    assert pf.settings_path == '/home/facundo/Desktop/Test'


# Generated at 2022-06-23 20:15:53.118401
# Unit test for constructor of class MissingSection
def test_MissingSection():
    msg = 'Found foo.bar import while parsing, but FUTURE was not included ' \
          'in the `sections` setting of your config. Please add it before continuing\n' \
          'See https://pycqa.github.io/isort/#custom-sections-and-ordering ' \
          'for more info.'
    assert str(MissingSection('foo.bar', 'FUTURE')) == msg


# Generated at 2022-06-23 20:15:57.511632
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("file_path")
    except FileSkipSetting as e:
        assert e.message == "file_path was skipped as it's listed in 'skip' setting" \
                            " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:16:04.696054
# Unit test for constructor of class AssignmentsFormatMismatch

# Generated at 2022-06-23 20:16:09.010941
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
  try:
    raise IntroducedSyntaxErrors()
  except IntroducedSyntaxErrors as err:
    assert err.__class__.__name__ == 'IntroducedSyntaxErrors'
    assert str(err) == 'isort introduced syntax errors when attempting to sort the imports contained within .'
test_IntroducedSyntaxErrors()


# Generated at 2022-06-23 20:16:10.513059
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error: ProfileDoesNotExist = ProfileDoesNotExist("test")
    assert error.profile == "test"

# Generated at 2022-06-23 20:16:13.155345
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped('abc', 'abc.py')
    except Exception as e:
        assert isinstance(e, FileSkipped)


# Generated at 2022-06-23 20:16:16.360934
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Test
    message = "file was skipped"
    file_path = "path_1"
    expected_message = f"path_1 was skipped as it's listed in 'skip' setting" \
        " or matches a glob in 'skip_glob' setting"
    expected_file_path = "path_1"

    # Execution
    exception = FileSkipSetting(message, file_path)

    # Validation
    assert exception.message == expected_message
    assert exception.file_path == expected_file_path

# Generated at 2022-06-23 20:16:18.640488
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("Forgot to put a newline")
    except AssignmentsFormatMismatch:
        pass

# Generated at 2022-06-23 20:16:19.880653
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped('Test message', 'file/path').message == 'Test message'

# Generated at 2022-06-23 20:16:24.504713
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection(import_module="requests", section="first_party")
    except ISortError as err:
        assert err.args[0] == "Found requests import while parsing, but first_party was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:16:26.781222
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    testClass = FileSkipped("message", "path")
    assert testClass
    assert testClass.file_path == "path"

# Generated at 2022-06-23 20:16:31.131031
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "file.py"
    with pytest.raises(IntroducedSyntaxErrors) as exception:
        raise IntroducedSyntaxErrors(file_path)
    assert str(exception) == (
        "isort introduced syntax errors when attempting to sort the imports contained within "
        f"{file_path}."
    )
    assert exception.file_path == file_path

# Generated at 2022-06-23 20:16:34.706415
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    class_obj = UnsupportedSettings({'name1': {'value': 2, 'source': 'config'}})
    assert class_obj.unsupported_settings['name1'] == {'value': 2, 'source': 'config'}

# Generated at 2022-06-23 20:16:36.622223
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test_ISortError")
    except ISortError as e:
        assert e.args[0] == "test_ISortError"
    else:
        assert False


# Generated at 2022-06-23 20:16:39.209729
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('/home/usr/filename.py')
    except UnsupportedEncoding:
        pass
    except Exception as e:
        raise(e)



# Generated at 2022-06-23 20:16:45.942862
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({'errors-only': {'value': True, 'source': 'command line'},
                        'skip': {'value': ['tests'], 'source': 'command line'},
                        'config_file': {'value': True, 'source': 'command line'},
                        'src_paths': {'value': ['.'], 'source': 'command line'},
                        'check-only': {'value': True, 'source': 'command line'},
                        'root': {'value': '.', 'source': 'command line'},
                        'py-path': {'value': '.', 'source': 'command line'},})


# Generated at 2022-06-23 20:16:49.987543
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("1 + 1", ValueError("Error"))
    except LiteralParsingFailure as instance:
        assert instance.code == "1 + 1"
        assert isinstance(instance.original_error, ValueError)

# Generated at 2022-06-23 20:16:55.013455
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
  message = "This is a test message to test the FileSkipped class"
  file_path = "C:\\Test\\file_skipped.py"
  exception: FileSkipped = FileSkipped(message, file_path)
  assert(exception.args[0] == message)
  assert(exception.file_path == file_path)

# Generated at 2022-06-23 20:17:01.825032
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise InvalidSettingsPath("settings")
    except InvalidSettingsPath as e:
        assert str(e) == "isort was told to use the settings_path: settings as the base directory or" \
                         " file that represents the starting point of config file discovery, " \
                         "but it does not exist."
        assert e.settings_path == "settings"



# Generated at 2022-06-23 20:17:04.329450
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("profile_name")
    except ProfileDoesNotExist as e:
        print(e)


# Generated at 2022-06-23 20:17:06.498160
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    test = LiteralSortTypeMismatch(str, int)
    assert test.kind == str
    assert test.expected_kind == int

# Generated at 2022-06-23 20:17:12.208478
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class ExceptionMock(Exception):
        pass

    e = ExceptionMock("foo bar")

    try:
        raise LiteralParsingFailure("foo bar", e)
    except LiteralParsingFailure as ex:
        assert str(ex) == "isort failed to parse the given literal foo bar. It's important to note " \
                          "that isort literal sorting only supports simple literals parsable by ast.literal_eval " \
                          "which gave the exception of foo bar."
        assert ex.code == "foo bar"
        assert ex.original_error == e

# Generated at 2022-06-23 20:17:14.020414
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError


# Generated at 2022-06-23 20:17:19.066602
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("skipped_message", "skipped_file_path")
    except FileSkipped as e:
        assert e.args[0] == "skipped_message"
        assert e.file_path == "skipped_file_path"

# Generated at 2022-06-23 20:17:20.451599
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    FormattingPluginDoesNotExist('test_plugin')


# Generated at 2022-06-23 20:17:22.302846
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    err = UnsupportedEncoding("foo.txt")
    assert err.filename == "foo.txt"


# Generated at 2022-06-23 20:17:23.233938
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    FormatingPluginDoesNotExist()

# Generated at 2022-06-23 20:17:24.009770
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    ProfileDoesNotExist("base")

# Generated at 2022-06-23 20:17:25.264274
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting(file_path="foo").file_path == "foo"

# Generated at 2022-06-23 20:17:27.143745
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors("some_file")
    assert error.file_path == "some_file"


# Generated at 2022-06-23 20:17:30.834890
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("missing_module", "example_section")
    except MissingSection as e:
        assert e.args[0] == "Found missing_module import while parsing, but example_section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:17:33.743556
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('test.py')
    except UnsupportedEncoding as e:
        assert e.filename == 'test.py'


# Generated at 2022-06-23 20:17:35.728314
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-23 20:17:39.286188
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch("string", "list")
    except LiteralSortTypeMismatch as error:
        assert error.kind == "string"
        assert error.expected_kind == "list"

# Generated at 2022-06-23 20:17:43.387144
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    # create instance of class SkipFile:
    object_name = FileSkipped("a message","a file_path")

    # Check if exception was raised for an object with message and file_path
    assert object_name.message == "a message"
    assert object_name.file_path == "a file_path"

# Generated at 2022-06-23 20:17:47.434988
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    # class LiteralParsingFailure(ISortError):
    # """Raised when one of isorts literal sorting comments is used but isort can't parse the
    # the given data structure.
    # """
    # def __init__(self, code: str, original_error: Exception):
    code='[1,2,3,4]'
    original_error='Exception'
    literal_parsing_failure=LiteralParsingFailure(code, original_error)
    print(literal_parsing_failure)


# Generated at 2022-06-23 20:17:51.416240
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    instance = MissingSection(import_module, section)

    assert instance.args == (
        f"Found {import_module} import while parsing, but {section} was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info.",
    )

# Generated at 2022-06-23 20:17:52.383001
# Unit test for constructor of class ISortError
def test_ISortError():
    error = ISortError()
    assert error

# Generated at 2022-06-23 20:17:56.132405
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    obj = IntroducedSyntaxErrors('c:/path/to/file/test.py')
    assert type(obj) == IntroducedSyntaxErrors
    assert obj.file_path == 'c:/path/to/file/test.py'
    assert str(obj) == f"isort introduced syntax errors when attempting to sort the imports contained within c:/path/to/file/test.py."



# Generated at 2022-06-23 20:17:58.967301
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting('file.txt').message == 'file.txt was skipped as it\'s listed in \'skip\' setting or matches a glob in \'skip_glob\' setting'

# Generated at 2022-06-23 20:18:04.156852
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'my_dir'
    error = FileSkipSetting(file_path=file_path)
    assert error.file_path is not None
    assert error.file_path == file_path
    assert error.__str__() is not None
    assert error.__str__() == 'my_dir was skipped as it\'s listed in \'skip\' setting or matches a glob in \'skip_glob\' setting'
    
    

# Generated at 2022-06-23 20:18:08.093156
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("kang")
    except Exception as e:
        assert str(e) == "Specified formatting plugin of kang does not exist. "
        assert e.formatter == "kang"


# Generated at 2022-06-23 20:18:11.837531
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("test.py")
    except FileSkipSetting as e:
        assert e.file_path == "test.py"
        assert "was skipped as it's listed in 'skip' setting" in str(e) or \
               "matches a glob in 'skip_glob' setting" in str(e)

# Generated at 2022-06-23 20:18:14.549308
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('just testing')
    except ISortError as e:
         assert str(e) == 'just testing'

# Generated at 2022-06-23 20:18:15.949309
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "file_path"
    IntroducedSyntaxErrors(file_path)

# Generated at 2022-06-23 20:18:19.080675
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type(None)
    expected_kind = type([])
    exception: LiteralSortTypeMismatch = LiteralSortTypeMismatch(kind, expected_kind)
    assert exception.kind == kind
    assert exception.expected_kind == expected_kind

# Generated at 2022-06-23 20:18:26.999083
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("Testing skipped", "/file/path").file_path == "/file/path"
    assert FileSkipped("Testing skipped", "/file/path").args == ("Testing skipped",)
    assert FileSkipSetting("/file/path").args == ("/file/path was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting",)
    assert isinstance(FileSkipSetting("/file/path"), ISortError)
    assert isinstance(FileSkipped("msg", "/file/path"), FileSkipped)


# Generated at 2022-06-23 20:18:27.908027
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist('profile').profile == 'profile'


# Generated at 2022-06-23 20:18:36.618220
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """Unit test for constructor of class LiteralParsingFailure"""
    from collections import namedtuple
    from textwrap import dedent

    class MyException(Exception):
        def __init__(self):
            super().__init__("my_exception")

    test_case = namedtuple("test_case", "test_code original_error expected_code")


# Generated at 2022-06-23 20:18:37.974651
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert hasattr(LiteralParsingFailure('code', Exception()), 'code')
    assert hasattr(LiteralParsingFailure('code', Exception()), 'original_error')

# Generated at 2022-06-23 20:18:39.960261
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    f = FileSkipped('test msg', 'test.txt')
    assert f.__str__() == 'test msg'

# Generated at 2022-06-23 20:18:42.894840
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    import ast
    s = "a=1\nb=2\nc=3"
    p = ast.parse(s)
    AssignmentsFormatMismatch(p)

# Generated at 2022-06-23 20:18:45.681188
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("class A", "FIRST PARTY")
    except (MissingSection) as e:
        assert e.import_module == "class A"
        assert e.section == "FIRST PARTY"


# Generated at 2022-06-23 20:18:49.162979
# Unit test for constructor of class MissingSection
def test_MissingSection():
    expected_message = (
        "Found SomeTestModule import while parsing, but TestSection was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info."
    )
    assert MissingSection("SomeTestModule", "TestSection").message == expected_message



# Generated at 2022-06-23 20:18:50.984374
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {"foo": "bar"}
    e = UnsupportedSettings(settings)
    assert e is not None

# Generated at 2022-06-23 20:18:51.898688
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("test_message", "test_path")


# Generated at 2022-06-23 20:18:56.602343
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "/home/user/test.py"
    message = f"{file_path} was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert FileSkipSetting(file_path).message == message
    assert FileSkipSetting(file_path).file_path == file_path

# Generated at 2022-06-23 20:18:58.399294
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    val = 'testfile.txt'
    e = UnsupportedEncoding(val)
    assert e.filename == val

# Generated at 2022-06-23 20:19:00.304787
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    IntroducedSyntaxErrors("test_file.py")


# Generated at 2022-06-23 20:19:07.185058
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    expected = "isort was told to use the settings_path: /path/to/settings.cfg as the base directory or file that represents the starting point of config file discovery, but it does not exist."
    actual = InvalidSettingsPath("/path/to/settings.cfg")
    assert str(actual) == expected
    assert actual.settings_path == "/path/to/settings.cfg"


# Unit tests for constructor of class ExistingSyntaxErrors

# Generated at 2022-06-23 20:19:08.476646
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("hello")
    except FileSkipComment as error:
        assert error.file_path == "hello"

# Generated at 2022-06-23 20:19:09.997989
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError:
        print('pass')

# Generated at 2022-06-23 20:19:16.296914
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    x = FileSkipComment(file_path="/home/hamza/gitHub/isort/isort/imports/__init__.py")
    assert x.message == "/home/hamza/gitHub/isort/isort/imports/__init__.py contains an file skip comment and was skipped."
    assert x.file_path == "/home/hamza/gitHub/isort/isort/imports/__init__.py"



# Generated at 2022-06-23 20:19:19.871698
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "message"
    file_path = "file_path"
    fileSkipped = FileSkipped(message, file_path)
    print(fileSkipped.__dict__)
    assert fileSkipped.message == message and fileSkipped.file_path == file_path


# Generated at 2022-06-23 20:19:21.277281
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    a = IntroducedSyntaxErrors("file_path")
    assert a.file_path == "file_path"

# Generated at 2022-06-23 20:19:30.244570
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "imports_outside_sections": {
            "value": True,
            "source": "config/cli/runtime",
        },
        "default_section": {
            "value": "FIRSTPARTY",
            "source": "config/cli/runtime",
        },
        "forced_separate": {
            "value": "module",
            "source": "config/cli/runtime",
        },
    }
    error = UnsupportedSettings(unsupported_settings)

# Generated at 2022-06-23 20:19:32.629507
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    comment = FileSkipComment("file_path")
    assert comment.file_path == "file_path"

# Generated at 2022-06-23 20:19:37.398584
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # 'file_path' parameter is required
    expected = "myFilePath.py contains an file skip comment and was skipped."
    observed = FileSkipComment("myFilePath.py")
    assert expected == str(observed)
    assert expected == str(observed.args[0])
    assert "myFilePath.py" == observed.file_path

# Generated at 2022-06-23 20:19:38.678103
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(FileSkipped):
        raise FileSkipped("Testing", "test.py")

# Generated at 2022-06-23 20:19:42.268779
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("123", Exception("test"))
    except LiteralParsingFailure as e:
        assert e.code == "123"
        assert e.original_error.args[0] == "test"



# Generated at 2022-06-23 20:19:48.214262
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(str, int)
    except LiteralSortTypeMismatch as e:
        if not isinstance(e, LiteralSortTypeMismatch):
            raise AssertionError()
        if e.expected_kind != int:
            raise AssertionError()
        if e.kind != str:
            raise AssertionError()


# Generated at 2022-06-23 20:19:51.679409
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = """\
    variable = "test"
    variable2 = "test"\
    """
    with pytest.raises(AssignmentsFormatMismatch, match=r"^isort was told to sort a section of assignments"):
        raise AssignmentsFormatMismatch(code)

# Generated at 2022-06-23 20:19:52.892115
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist


# Generated at 2022-06-23 20:19:58.475671
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    def init_IntroducedSyntaxErrors(self, file_path: str):
        super().__init__(
            f"isort introduced syntax errors when attempting to sort the imports contained within "
            f"{file_path}."
        )
        self.file_path = file_path

    e = IntroducedSyntaxErrors("filetest")
    init_IntroducedSyntaxErrors(e, "filetest")
    assert "filetest" == e.file_path

# Generated at 2022-06-23 20:20:00.886459
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
	try:
		e = UnsupportedEncoding('/home/nikhil/Desktop/file.txt')
	except:
		raise Exception('Unknown or unsupported encoding')


# Generated at 2022-06-23 20:20:03.299066
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    exception = FileSkipComment('haha')
    assert exception.file_path == 'haha'
    assert str(exception) == 'haha contains an file skip comment and was skipped.'


# Generated at 2022-06-23 20:20:06.848396
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("/test/path")
    except IntroducedSyntaxErrors as exception:
        assert str(exception) == (
            "isort introduced syntax errors when attempting to sort the imports "
            "contained within /test/path."
        )
        assert exception.file_path == "/test/path"

# Generated at 2022-06-23 20:20:08.147377
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fss = FileSkipSetting("~/work/test.py")

# Generated at 2022-06-23 20:20:11.878285
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "D:\Thesis\Kivy-Samples\examples\demo\main.py"
    new_exception = IntroducedSyntaxErrors(file_path)
    assert new_exception.file_path == file_path
    

    

# Generated at 2022-06-23 20:20:16.052685
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class TestError(Exception):
        """Test exception"""

    e = TestError("Test error")

    exception = LiteralParsingFailure("test code", e)

    assert exception.code == "test code"
    assert exception.original_error == e


# Generated at 2022-06-23 20:20:18.760101
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('file.py')
    except IntroducedSyntaxErrors as error:
        assert error.file_path == 'file.py'

# Generated at 2022-06-23 20:20:21.250377
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "file_path"
    file_skip_setting = FileSkipSetting(file_path)
    assert file_skip_setting.file_path == file_path

# Generated at 2022-06-23 20:20:22.919856
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    ISortError.__init__(kind=type, expected_kind=type)

# Generated at 2022-06-23 20:20:25.800248
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    # Arrange
    formatter = 'dummy-formatter'
    # Act
    exception = FormattingPluginDoesNotExist(formatter)
    # Assert
    assert exception.formatter == formatter

# Generated at 2022-06-23 20:20:29.395583
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    # Test constructor with given parameters
    code = "(a, b, c)"
    original_error = Exception("There was a error")
    literal_parsing_failure = LiteralParsingFailure(code, original_error)
    assert literal_parsing_failure.code == "(a, b, c)"
    assert literal_parsing_failure.original_error == Exception("There was a error")

# Generated at 2022-06-23 20:20:31.713579
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test_profile")
    except ProfileDoesNotExist as e:
        assert e.profile == "test_profile"

# Generated at 2022-06-23 20:20:35.577142
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = "file_path"
    message = f"{file_path} contains an file skip comment and was skipped."
    test_file_skip = FileSkipped(message, file_path)
    assert test_file_skip.message == message
    assert test_file_skip.file_path == file_path

# Generated at 2022-06-23 20:20:37.576182
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('foo')
    except ProfileDoesNotExist as e:
        assert e.profile == 'foo'

# Generated at 2022-06-23 20:20:40.442238
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "../files"
    file_skip = FileSkipSetting(file_path)
    print(file_skip.file_path)


# Generated at 2022-06-23 20:20:44.151448
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "message"
    file_path = "file_path"

    try:
        raise FileSkipped(message, file_path)
    except FileSkipped as raised_error:
        assert file_path == raised_error.file_path


# Generated at 2022-06-23 20:20:45.992542
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    x = LiteralParsingFailure("code", SyntaxError("failed"))
    assert x.code == "code"
    assert x.original_error == SyntaxError("failed")

# Generated at 2022-06-23 20:20:47.398193
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert LiteralParsingFailure("test", SyntaxError)



# Generated at 2022-06-23 20:20:52.276314
# Unit test for constructor of class MissingSection
def test_MissingSection():
    message = f"Found {'import_module'} import while parsing, but {'section'} was not included " \
              f"in the `sections` setting of your config. Please add it before continuing\n" \
              f"See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
              f"for more info."
    assert MissingSection('import_module', 'section').args[0] == message


# Generated at 2022-06-23 20:20:54.952154
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist(profile="test")
    except Exception as e:
        assert e.profile == "test"

# Generated at 2022-06-23 20:20:58.867203
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = 'a = 1\nb = 2'
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert isinstance(e, AssignmentsFormatMismatch)
        assert e.code == code

# Generated at 2022-06-23 20:21:07.673019
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # rb_profile is not a valid profile
    with pytest.raises(ProfileDoesNotExist) as error:
        raise ProfileDoesNotExist('rb_profile')

# Generated at 2022-06-23 20:21:15.825771
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("__init__.py")
    except InvalidSettingsPath as ies:
        assert str(ies) == "isort was told to use the settings_path: __init__.py as the " \
                           "base directory or file that represents the starting point of config " \
                           "file discovery, but it does not exist."
        assert ies.settings_path == "__init__.py"


# Generated at 2022-06-23 20:21:18.925148
# Unit test for constructor of class ISortError
def test_ISortError():
    e = ISortError("message")
    assert repr(e) == "<ISortError message>"
    assert str(e) == "message"
    assert e.__str__() == "message"

# Generated at 2022-06-23 20:21:22.024854
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    print("test class InvalidSettingsPath")
    assert InvalidSettingsPath("/a/b/c").settings_path == "/a/b/c"


# Generated at 2022-06-23 20:21:25.429428
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = "file.txt"
    message = "isort was told to use the settings_path: file.txt as the base directory or " \
              "file that represents the starting point of config file discovery, but it does not " \
              "exist."

    assert message == ISortError.__init__(InvalidSettingsPath, path)


# Generated at 2022-06-23 20:21:26.255960
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    x = AssignmentsFormatMismatch('a = b\nc = d\n')

# Generated at 2022-06-23 20:21:30.552653
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors("")
    assert error.__class__.__name__ == "ExistingSyntaxErrors"
    assert error.__doc__ == "Raised when isort is told to sort imports within code " \
        "that has existing syntax errors"
    assert error.__str__() == "isort was told to sort imports within code that contains " \
        "syntax errors: ."


# Generated at 2022-06-23 20:21:34.428782
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "/path/to/file/test.py"
    obj = FileSkipSetting(file_path)
    assert obj.file_path == file_path
    assert obj.message == "test.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:21:38.912941
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("")
    except ISortError as exception:
        assert str(exception) == "Specified formatting plugin of  does not exist. "
        assert exception.formatter == ""


# Generated at 2022-06-23 20:21:46.989934
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(
            """\
var1 = value1
var2 = value2\
"""
        )
    except AssignmentsFormatMismatch as e:
        assert str(
            e
        ) == """isort was told to sort a section of assignments, however the given code:\n\nvar1 = value1\nvar2 = value2\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"""
        assert e.code == """\
var1 = value1
var2 = value2\
"""

# Generated at 2022-06-23 20:21:51.764945
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("""var1 = value1
            var2 = value2
            var3 = value3
            var4 = [v for v in range(4)]
            var5 = {"a": 1, "b": 2, "c": 3}
            var6 = (1, 2, {"a": 1, "b": 2})
            var7 = {1, 2, 3, 4}""")
    except AssignmentsFormatMismatch as e:
        pass

# Generated at 2022-06-23 20:21:52.760779
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
	pass


# Generated at 2022-06-23 20:21:54.736660
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors(file_path='foo.txt').file_path == 'foo.txt'


# Generated at 2022-06-23 20:21:57.559173
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("invalid.profile")
    except ProfileDoesNotExist as e:
        assert e.profile == "invalid.profile"



# Generated at 2022-06-23 20:22:01.710019
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = '/path/to/file'
    file_skipped = FileSkipped('This is a test', file_path)
    assert isinstance(file_skipped, FileSkipped)
    assert file_skipped.file_path == file_path


# Generated at 2022-06-23 20:22:05.796928
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("testing_profile")
    except ProfileDoesNotExist as e:
        assert str(e) == (
            f"Specified profile of testing_profile does not exist. "
            f"Available profiles: {','.join(profiles)}."
        )
        assert e.profile == "testing_profile"

# Generated at 2022-06-23 20:22:10.957360
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("test", Exception("test"))
    except Exception as e:
        assert e.code == "test"
        assert isinstance(e.original_error, Exception)
        assert e.original_error.args == ("test",)
        assert str(e) == "isort failed to parse the given literal test. It's important to note that " \
                         "isort literal sorting only supports simple literals parsable by ast.literal_eval " \
                         "which gave the exception of test."



# Generated at 2022-06-23 20:22:12.397043
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    md = ProfileDoesNotExist('atest')
    assert md.profile == 'atest'

# Generated at 2022-06-23 20:22:14.207516
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    from filecmp import cmp

# Generated at 2022-06-23 20:22:19.119610
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("A")
    except ISortError as e:
        assert str(e) == "isort was told to use the settings_path: A as the base directory or file that represents the starting point of config file discovery, but it does not exist."
        assert type(e) == InvalidSettingsPath
        assert e.settings_path == "A"


# Generated at 2022-06-23 20:22:25.029295
# Unit test for constructor of class MissingSection
def test_MissingSection():
    a = MissingSection('a', 'b')
    assert(a.import_module == 'a')
    assert(a.section == 'b')
    assert(a.args[0] == f"Found a import while parsing, but b was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.")

# Generated at 2022-06-23 20:22:27.540345
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("django")
    except:
        pass
    # this step works
    assert(profiles == ["django"])
