

# Generated at 2022-06-23 20:12:33.117999
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    ex = ExistingSyntaxErrors("test.py")
    assert ex.file_path == "test.py"
    assert ex.message == "isort was told to sort imports within code that contains syntax errors: test.py."


# Generated at 2022-06-23 20:12:38.063701
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert str(UnsupportedSettings({'unsupported': {'value': 'val', 'source': 'src'}})) == "isort was provided settings that it doesn't support:\n\n\t- unsupported = val  (source: 'src')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"

# Generated at 2022-06-23 20:12:41.864683
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'message'
    fpath = '../path'
    file = FileSkipped(message, fpath)
    assert file.message == message
    assert file.file_path == fpath


# Generated at 2022-06-23 20:12:42.873303
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    IntroducedSyntaxErrors("test.py")

# Generated at 2022-06-23 20:12:44.856751
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding(filename='filename.py')
    assert hasattr(error, 'filename'), "UnsupportedEncoding class should have filename attribute."


# Generated at 2022-06-23 20:12:48.071582
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    # construct an object of class FileSkipped
    _Fileskipped = FileSkipped("skiped", "file_path")

    # assert that attributes of the object are set properly
    assert _Fileskipped.message == "skiped"
    assert _Fileskipped.file_path == "file_path"


# Generated at 2022-06-23 20:12:51.441049
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    with pytest.raises(FileSkipComment) as error:
        raise FileSkipComment("fdfdf")
    assert str(error.value) == "fdfdf contains an file skip comment and was skipped."
    assert error.value.file_path == "fdfdf"

# Generated at 2022-06-23 20:12:54.112607
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "test.txt"
    exception = UnsupportedEncoding(filename)
    assert exception.filename == filename
    try:
        raise exception
    except UnsupportedEncoding as actual:
        assert actual.filename == filename

# Generated at 2022-06-23 20:12:57.398189
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Arrange
    kind = type(1)
    expected_kind = type(2)

    # Act
    err = LiteralSortTypeMismatch(kind, expected_kind)

    # Assert
    assert err.kind == kind
    assert err.expected_kind == expected_kind

# Generated at 2022-06-23 20:12:59.647616
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('test')
    except ISortError as err:
        assert err.args == ('test',)

# Generated at 2022-06-23 20:13:01.863053
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "black"
    assert FormattingPluginDoesNotExist(formatter).formatter == formatter

# Generated at 2022-06-23 20:13:03.512119
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    IntroducedSyntaxErrors("test file")

# Generated at 2022-06-23 20:13:04.565320
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    LiteralSortTypeMismatch(str, dict)

# Generated at 2022-06-23 20:13:08.107911
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    obj = FileSkipped("test_message", "test_file")
    assert obj.message == "test_message"
    assert obj.file_path == "test_file"

# Generated at 2022-06-23 20:13:10.758429
# Unit test for constructor of class ISortError
def test_ISortError():
    e = ISortError("test exception")
    assert str(e) == "test exception"
    assert e.__class__.__name__ == "ISortError"


# Generated at 2022-06-23 20:13:14.305898
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        exception = AssignmentsFormatMismatch("str")
    except AssignmentsFormatMismatch:
        return
    
    raise AssertionError("AssignmentsFormatMismatch exception must be raised.")

# Generated at 2022-06-23 20:13:16.555368
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    e = LiteralSortTypeMismatch(kind=int, expected_kind=dict)
    assert e.kind is int
    assert e.expected_kind is dict

# Generated at 2022-06-23 20:13:23.342082
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("test_AssignmentsFormatMismatch")
    except AssignmentsFormatMismatch as e:
        assert e.args[0] == "isort was told to sort a section of assignments, however the given code:\n\n" \
            "test_AssignmentsFormatMismatch\n\n" \
            "Does not match isort's strict single line formatting requirement for assignment " \
            "sorting:\n\n" \
            "{variable_name} = {value}\n" \
            "{variable_name2} = {value2}\n" \
            "...\n\n"

# Generated at 2022-06-23 20:13:26.861947
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure(code='test', original_error='test')
    except LiteralParsingFailure as e:
        assert e.code == 'test'
        assert e.original_error == 'test'
    else:
        assert False


# Generated at 2022-06-23 20:13:27.831292
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    raise UnsupportedEncoding("hello")

# Generated at 2022-06-23 20:13:32.118838
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit test for exception constructor"""
    options = {"custom_setting1": {"value": True, "source": "command line"}}
    exc = UnsupportedSettings(options)
    assert exc.unsupported_settings == options

# Generated at 2022-06-23 20:13:33.525048
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    LiteralParsingFailure("code", Exception("original_error"))

# Generated at 2022-06-23 20:13:38.232516
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("abc")
    except AssignmentsFormatMismatch as e:
        assert "isort was told to sort a section of assignments, however the given code:\n\n" in str(e)
        assert "\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n" in str(e)
        assert "{variable_name} = {value}\n" in str(e)
        assert "{variable_name2} = {value2}\n" in str(e)
        assert "abc" in str(e)

# Generated at 2022-06-23 20:13:40.183506
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    filename = "test_name"
    test_case = FileSkipComment(filename)
    assert test_case.file_path == filename


# Generated at 2022-06-23 20:13:40.815929
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting('file_path=123')

# Generated at 2022-06-23 20:13:43.158548
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError("test_message")

if __name__ == "__main__":
    test_ISortError()

# Generated at 2022-06-23 20:13:45.224421
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    e = UnsupportedEncoding("/Users/example/test.py")
    assert e.filename == "/Users/example/test.py"
    assert e.args[0] == "Unknown or unsupported encoding in /Users/example/test.py"

# Generated at 2022-06-23 20:13:50.636665
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    new = FileSkipComment(r"C:\Users\Quentin\dev\isort\hooks\pre-commit.sample")
    assert new.message == r"C:\Users\Quentin\dev\isort\hooks\pre-commit.sample contains an file skip comment and was skipped."
    assert new.file_path == r"C:\Users\Quentin\dev\isort\hooks\pre-commit.sample"


# Generated at 2022-06-23 20:13:54.744512
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error = LiteralParsingFailure(code="'test'[0]", original_error=SyntaxError)
    assert error.code == "'test'[0]"
    assert error.original_error == SyntaxError



# Generated at 2022-06-23 20:13:57.060392
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "dummy"
    ex = FormattingPluginDoesNotExist(formatter)
    
    assert ex.formatter == formatter

# Generated at 2022-06-23 20:13:58.422556
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipSetting("test").file_path == "test"

# Generated at 2022-06-23 20:14:02.357825
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test_filename")
    except IntroducedSyntaxErrors as e:
        print(e)
        print(e.file_path)
    else:
        assert False



# Generated at 2022-06-23 20:14:03.568314
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    encoding = ISortError("filename")


# Generated at 2022-06-23 20:14:05.026627
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath):
        raise InvalidSettingsPath("path")

# Generated at 2022-06-23 20:14:08.414031
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "dictionary"
    original_error = "error"
    error = LiteralParsingFailure(code, original_error)
    assert error.code == code
    assert error.original_error == original_error



# Generated at 2022-06-23 20:14:16.016802
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """
    Test for constructor of class LiteralSortTypeMismatch
    """
    kind = str
    expected_kind = int
    try:
        raise LiteralSortTypeMismatch(kind, expected_kind)
    except LiteralSortTypeMismatch as exc:
        assert exc.kind == kind
        assert exc.expected_kind == expected_kind
        assert str(exc) == (
            "isort was told to sort a literal of type <class 'int'> but was given "
            "a literal of type <class 'str'>."
        )

# Generated at 2022-06-23 20:14:21.970643
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("TestReason", "TestFilePath")
    except FileSkipped as e:
        assert e.file_path == "TestFilePath"
        assert e.message == "TestReason"
        return True
    return False

# Generated at 2022-06-23 20:14:24.775520
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("abc.py")
    except InvalidSettingsPath as ins:
        print("DEBUG: Error : ", ins)
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:14:26.803341
# Unit test for constructor of class ISortError
def test_ISortError():
    I = ISortError()
    print(I)


# Generated at 2022-06-23 20:14:29.717525
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exc = UnsupportedEncoding(filename="invalid_char.py")
    assert str(exc) == "UnsupportedEncoding: Unknown or unsupported encoding in invalid_char.py"

# Generated at 2022-06-23 20:14:32.738936
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    class Test:
        def test1(self):
            assert "isort introduced syntax errors when attempting to sort the imports contained" in IntroducedSyntaxErrors("test").__str__()


# Generated at 2022-06-23 20:14:36.958211
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    isortError = LiteralParsingFailure('code', Exception('original_error'))
    assert isortError.code == 'code'
    assert isortError.original_error == Exception('original_error')

if __name__ == "__main__":
    test_LiteralParsingFailure()

# Generated at 2022-06-23 20:14:41.380456
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("")
    except IntroducedSyntaxErrors as error:
        assert error.file_path == ""
        assert error.__class__.__name__ == "IntroducedSyntaxErrors"


# unit test for constructor of class ExistingSyntaxErrors

# Generated at 2022-06-23 20:14:49.405868
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    expected = "isort was told to sort a section of assignments, however the given code:\n\n" \
    "    import foo\n\n" \
    "Does not match isort's strict single line formatting requirement for assignment "\
    "sorting:\n\n" \
    "{variable_name} = {value}\n" \
    "{variable_name2} = {value2}\n" \
    "...\n\n"

    assert str(AssignmentsFormatMismatch("    import foo")) == expected

# Generated at 2022-06-23 20:14:52.313051
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:14:56.022660
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as err:
        assert str(err) == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        assert err.import_module == "import_module"
        assert err.section == "section"


# Generated at 2022-06-23 20:15:02.611928
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # empty filename
    try:
        raise UnsupportedEncoding(filename='')
    except UnsupportedEncoding as e:
        assert e.filename == ''
    except Exception as e:
        assert False
    # plain filename
    try:
        raise UnsupportedEncoding(filename='foo')
    except UnsupportedEncoding as e:
        assert e.filename == 'foo'
    except Exception as e:
        assert False
    # filename with pathlib.Path
    try:
        raise UnsupportedEncoding(filename=Path('foo'))
    except UnsupportedEncoding as e:
        assert e.filename == 'foo'
    except Exception as e:
        assert False
    # filename with pathlib.Path (windows)

# Generated at 2022-06-23 20:15:05.100383
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("")
        assert False
    except FileSkipComment as e:
        assert e.message == " contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:15:07.255389
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('test')
    except ProfileDoesNotExist as e:
        assert e.profile == 'test'

# Generated at 2022-06-23 20:15:10.001359
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("C:\\Users\\Murch\\PycharmProjects\\pycharm\\files")
    except IntroducedSyntaxErrors as error:
        assert error.file_path == "C:\\Users\\Murch\\PycharmProjects\\pycharm\\files"

# Generated at 2022-06-23 20:15:11.910426
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(FileSkipped):
        raise FileSkipped("message", "file_path")



# Generated at 2022-06-23 20:15:14.756219
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    className = 'ProfileDoesNotExist'
    error = ProfileDoesNotExist('Nonexistent')
    assert className == type(error).__name__
    assert 'Specified profile of Nonexistent does not exist. ' == str(error)[:47]

# Generated at 2022-06-23 20:15:18.374498
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("This is a test exception.")
    except ISortError as error:
        assert error.args[0] == "This is a test exception."

# Generated at 2022-06-23 20:15:19.372709
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    e = UnsupportedEncoding("Test.java")
    assert e.filename == "Test.java"

# Generated at 2022-06-23 20:15:24.057684
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = 'test.py'
    try:
        raise IntroducedSyntaxErrors(file_path)
    except IntroducedSyntaxErrors as e:
        assert e.file_path == file_path
        assert str(e) == 'isort introduced syntax errors when attempting to sort the imports contained within test.py.'
    else:
        assert False

# Generated at 2022-06-23 20:15:26.712428
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    class_name = AssignmentsFormatMismatch.__name__
    try:
        raise AssignmentsFormatMismatch
    except TypeError:
        print('{} is a valid class type'.format(class_name))
    except Exception as e:
        print('{} is not a valid class type: {}'.format(class_name, e))

test_AssignmentsFormatMismatch()


# Generated at 2022-06-23 20:15:32.367089
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('test')
    except ProfileDoesNotExist as error:
        assert error.profile == 'test'
        assert error.args[0] == 'Specified profile of test does not exist. Available profiles: black,py37,pep8,py38.'

# Generated at 2022-06-23 20:15:33.526745
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError.__init__ is not Exception.__init__


# Generated at 2022-06-23 20:15:39.542823
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    """Unit test function for ExistingSyntaxErrors error object"""
    error = ExistingSyntaxErrors("path/to/file.py")
    assert error.__str__() == (
        "isort was told to sort imports "
        "within code that contains syntax errors: path/to/file.py."
    )
    assert error.file_path == "path/to/file.py"



# Generated at 2022-06-23 20:15:41.588178
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert isinstance(FileSkipComment('test/test_file.py'), FileSkipComment)

# Generated at 2022-06-23 20:15:44.140600
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist) as e:
        # raises error because formatter is not defined
        raise FormattingPluginDoesNotExist(formatter="my_formatter")



# Generated at 2022-06-23 20:15:46.552843
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception = UnsupportedEncoding("test")
    assert exception.filename == "test"


# Generated at 2022-06-23 20:15:50.315080
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    with pytest.raises(FileSkipComment, match="testfile.py contains an file skip comment and was skipped."):
        raise FileSkipComment(file_path="testfile.py")



# Generated at 2022-06-23 20:15:52.482548
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest.raises(AssignmentsFormatMismatch):
        raise AssignmentsFormatMismatch('one, two, three')

# Generated at 2022-06-23 20:15:54.758094
# Unit test for constructor of class ISortError
def test_ISortError():
    err = ISortError()
    assert str(err) == "Exception in isort"



# Generated at 2022-06-23 20:15:58.215253
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath) as e:
        raise InvalidSettingsPath("settings_path")
    assert e.value.settings_path == "settings_path"


# Generated at 2022-06-23 20:15:59.199069
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    f = FormattingPluginDoesNotExist('dummy')

# Generated at 2022-06-23 20:16:03.996373
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("/abc/def")
    except UnsupportedEncoding as e:
        assert str(e) == "Unknown or unsupported encoding in /abc/def"
        assert e.filename == "/abc/def"

# Generated at 2022-06-23 20:16:06.157450
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath):
        raise InvalidSettingsPath("invalid_settings_path")


# Generated at 2022-06-23 20:16:09.904984
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    err = ExistingSyntaxErrors("/path/to/file")
    assert isinstance(err, ExistingSyntaxErrors)
    assert isinstance(err, ISortError)
    assert isinstance(err, Exception)
    assert err.file_path == "/path/to/file"



# Generated at 2022-06-23 20:16:11.759048
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('b')
    except:
        assert True


# Generated at 2022-06-23 20:16:15.315053
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError(1.0)
    except ISortError as e:
        assert e.args[0] == 1.0
    else:
        assert False, "Should have raised an ISortError"


# Generated at 2022-06-23 20:16:18.173590
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("error message")
    except ISortError as e:
        assert e.args == ('error message',)



# Generated at 2022-06-23 20:16:20.596093
# Unit test for constructor of class InvalidSettingsPath

# Generated at 2022-06-23 20:16:24.056471
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings(unsupported_settings={
        "testing": {"value": "this is a test", "source": "test"},
        "other": {"value": "this is a test", "source": "test"},
        "another": {"value": "this is a test", "source": "test"},
    })

# Generated at 2022-06-23 20:16:29.250552
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Function to test constructor of class FileSkipSetting:
    # comment = f"{file_path} was skipped as it's listed in 'skip' setting" +
    #           " or matches a glob in 'skip_glob' setting"
    file_path = "test_path"
    except_obj = FileSkipSetting(file_path)
    assert except_obj.file_path == file_path



# Generated at 2022-06-23 20:16:31.029520
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
	file_path = "file_path"
	FileSkipSetting(file_path)

# Generated at 2022-06-23 20:16:34.713431
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    for (profile, err) in [['Python', 'Python'], ['Python2', 'Python2'], ['Python3', 'Python3']]:
        try:
            raise ProfileDoesNotExist(profile)
        except ProfileDoesNotExist as e:
            # ProfileDoesNotExist class should have profile variable.
            assert str(e.profile) == err


# Generated at 2022-06-23 20:16:43.321028
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    class Foo():
        def __init__(self, name, kind, source):
            self.supported_settings = {
                'test1': {'kind': 'string', 'source': 'test', 'default': 'test'},
                'test2': {'kind': 'list', 'source': 'test', 'default': []},
                'test3': {'kind': 'dict', 'source': 'test', 'default': {}}
            }
            try:
                self.supported_settings[name]['source'] == source
                self.supported_settings[name]['kind'] == kind
            except KeyError:
                raise UnsupportedSettings({
                    name: {'kind': kind, 'source': source}
                })


# Generated at 2022-06-23 20:16:46.155456
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath):
        raise InvalidSettingsPath("InvalidSettingsPath")

# Generated at 2022-06-23 20:16:47.772389
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    filename = '/tmp/test.py'
    FileSkipComment(filename)

# Generated at 2022-06-23 20:16:49.373695
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("filename")
    except UnsupportedEncoding as e:
        assert e.args[0] == 'Unknown or unsupported encoding in filename'


# Generated at 2022-06-23 20:16:53.728892
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    """Unit test for constructor of class ExistingSyntaxErrors"""
    #I assume that __str__() function is implemented in base class
    assert str(ExistingSyntaxErrors('')) == 'isort was told to sort imports within code that contains syntax errors: .'


# Generated at 2022-06-23 20:16:56.375281
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    msg = 'message'
    file_path = 'file_path'
    file_ski = FileSkipped(msg, file_path)
    assert file_ski.file_path == file_path

# Generated at 2022-06-23 20:17:00.503830
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section = MissingSection("import", "section")
    expected = "Found import import while parsing, but section was not included in the " \
               "`sections` setting of your config. Please add it before continuing\n" \
               "See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
    assert (str(missing_section) == expected) # nosec

# Generated at 2022-06-23 20:17:07.155096
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    item = "test item"
    error_message = "test error message"
    error_message_expected = "isort was provided settings that it doesn't support:\n\n\t- test item  (source: 'test error message')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"
    with pytest.raises(UnsupportedSettings, match=error_message_expected):
        raise UnsupportedSettings({item: {"value": item, "source": error_message}})

# Generated at 2022-06-23 20:17:12.177016
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    class CustomSyntaxError(ISortError):
        """Raised when isort has introduced a syntax error in the process of sorting imports"""

        def __init__(self, file_path: str):
            super().__init__(
                f"isort introduced syntax errors when attempting to sort the imports contained within "
                f"{file_path}."
            )
            self.file_path = file_path

    test = CustomSyntaxError("test.py")
    assert test.file_path == "test.py"

# Generated at 2022-06-23 20:17:14.814827
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors):
        raise IntroducedSyntaxErrors(file_path="test_path")

# Generated at 2022-06-23 20:17:18.106548
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test.txt"
    error = FileSkipComment(file_path)
    assert error.file_path == "test.txt"


# Generated at 2022-06-23 20:17:21.612688
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    
    formatter = 'formatter'
    fmt_plugin = FormattingPluginDoesNotExist(formatter)
    assert fmt_plugin.formatter == 'formatter'

   # Unit test for constructor of ISortError class

# Generated at 2022-06-23 20:17:23.292166
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception_object = UnsupportedEncoding(filename="name")
    assert exception_object.filename == "name"

# Generated at 2022-06-23 20:17:25.605392
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding(filename="test")
    except ISortError as err:
        assert type(err) == UnsupportedEncoding
        assert err.filename == "test"

# Generated at 2022-06-23 20:17:30.550083
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("test/test_skip_comment.py")
    except FileSkipComment as e:
        assert e.file_path == "test/test_skip_comment.py"
        assert e.args[0] == "test/test_skip_comment.py contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:17:34.252658
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'invalid'
    exc = FormattingPluginDoesNotExist(formatter)
    assert exc.args[0] == f'Specified formatting plugin of {formatter} does not exist. '
    assert exc.formatter == formatter

# Generated at 2022-06-23 20:17:39.099898
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(ISortError) as excinfo:
        raise LiteralSortTypeMismatch(kind=int, expected_kind=str)
    assert 'isort was told to sort a literal of type <' in str(excinfo.value)
    assert 'but was given a literal of type <' in str(excinfo.value)

# Generated at 2022-06-23 20:17:42.322096
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    comment = FileSkipComment("test")
    assert comment.message == "test contains an file skip comment and was skipped."
    assert comment.file_path == "test"

# Generated at 2022-06-23 20:17:43.171222
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    test = UnsupportedEncoding("testfile")
    assert test.filename == "testfile"

# Generated at 2022-06-23 20:17:44.439772
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "file.py"
    e = UnsupportedEncoding(filename)
    assert e.filename == filename

# Generated at 2022-06-23 20:17:46.839939
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    import sys
    rv = sys.getrefcount(UnsupportedEncoding("/dev/null"))
    assert rv == 2



# Generated at 2022-06-23 20:17:49.368766
# Unit test for constructor of class ISortError
def test_ISortError():
    success = True
    try:
        raise ISortError("test message")
    except ISortError:
        success = True

    assert success == True
    raise ISortError("test message")


# Generated at 2022-06-23 20:17:52.892571
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("some code")
    except AssignmentsFormatMismatch as e:
        assert str(e)  # noQA:WPS421
        assert e.code == "some code"



# Generated at 2022-06-23 20:17:56.312202
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    my_object = FileSkipComment("path/file.py")
    assert "path/file.py contains" in str(my_object)
    assert my_object.file_path == "path/file.py"


# Generated at 2022-06-23 20:18:02.425010
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {"missing_from_config": {"value": 1, "source": "config"},
                "missing_from_cli": {"value": 2, "source": "cli"},
                "missing_from_runtime": {"value": 3, "source": "runtime"}}
    unsupported_settings = {}
    for name, param in settings.items():
        unsupported_settings[name] = param
    uss = UnsupportedSettings(unsupported_settings)
    assert uss.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:18:06.207034
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        pass
    assert e.message == "message"
    assert e.file_path == "file_path"


# Generated at 2022-06-23 20:18:10.600353
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting('foo.py')
    except FileSkipSetting as e:
        assert e.message == "foo.py was skipped as it's listed in 'skip' setting" \
            " or matches a glob in 'skip_glob' setting"
        assert e.file_path == 'foo.py'



# Generated at 2022-06-23 20:18:12.110294
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError.__init__



# Generated at 2022-06-23 20:18:14.400676
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    class_type = ProfileDoesNotExist('profile')
    assert class_type.profile == 'profile'

# Generated at 2022-06-23 20:18:21.615230
# Unit test for constructor of class IntroducedSyntaxErrors

# Generated at 2022-06-23 20:18:24.882976
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    msg = 'Formatting Plugin Does Not Exist'
    try:
        raise FormattingPluginDoesNotExist('test')
    except FormattingPluginDoesNotExist as e:
        assert str(e) == msg
        assert e.formatter == 'test'
        assert isinstance(e, ISortError)
        assert issubclass(FormattingPluginDoesNotExist, ISortError)

# Generated at 2022-06-23 20:18:28.615517
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    exception = ProfileDoesNotExist('test')
    assert isinstance(exception, ISortError)
    assert exception.profile == 'test'
    assert (
        str(exception)
        == "Specified profile of test does not exist. Available profiles: black,pep8,py37."
    )


# Generated at 2022-06-23 20:18:32.551020
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "README.md"
    f = FileSkipSetting(file_path)
    assert f.message == f"{file_path} was skipped as it's listed in 'skip' setting" \
        " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:18:34.417805
# Unit test for constructor of class ISortError
def test_ISortError():
    x=ISortError(message="hehe")
    assert x.message=="hehe"

#unit test for constructor of class InvalidSettingsPath

# Generated at 2022-06-23 20:18:36.243236
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath()
    except Exception as e:
        assert e is not None


# Generated at 2022-06-23 20:18:43.073450
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    test = FileSkipSetting("")
    messages = "FileSkipSetting: <file_path> contains an file skip comment and was skipped." \
               ", <file_path> was skipped as it's listed in 'skip' setting" \
               " or matches a glob in 'skip_glob' setting"
    assert test.__str__() == messages
    assert test.__repr__() == messages
    assert test.__doc__ == "Should be raised when a file is skipped for any reason."

# Generated at 2022-06-23 20:18:44.583803
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("file_path")
    except FileSkipComment as e:
        assert isinstance(e.file_path, str) and e.file_path == "file_path"

# Generated at 2022-06-23 20:18:46.469436
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors('test.py')
    except ExistingSyntaxErrors as e:
        assert e.file_path == 'test.py'



# Generated at 2022-06-23 20:18:53.225368
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("not_a_real_file.py")
    except IntroducedSyntaxErrors as ise:
        assert str(ise).startswith("isort introduced syntax errors when attempting to sort "
                                   "the imports contained within not_a_real_file.py.")
        assert ise.file_path == "not_a_real_file.py"

# Generated at 2022-06-23 20:18:56.192580
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skip_obj = FileSkipped("message", "file")
    assert file_skip_obj.message == "message"
    assert file_skip_obj.file_path == "file"



# Generated at 2022-06-23 20:18:58.731949
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test_filename")
    except UnsupportedEncoding as e:
        assert e.filename == "test_filename"


# Generated at 2022-06-23 20:19:02.973275
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    exception = ExistingSyntaxErrors('file_path')
    assert "isort was told to sort imports within code that contains syntax errors: file_path" == exception.__str__()
    assert "file_path" == exception.file_path

# Generated at 2022-06-23 20:19:06.082406
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
   formatter = "exception"
   try:
       raise FormattingPluginDoesNotExist(formatter)
   except FormattingPluginDoesNotExist as e:
       assert str(e) == (f"Specified formatting plugin of {formatter} does not exist. ")
       assert e.formatter == formatter

# Generated at 2022-06-23 20:19:07.585166
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("some_file.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "some_file.py"

# Generated at 2022-06-23 20:19:08.210393
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch("test")

# Generated at 2022-06-23 20:19:10.247022
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    FormattingPluginDoesNotExist("blank_line_before")

# Generated at 2022-06-23 20:19:15.893717
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    from isort.api import file_skip_setting
    file_path = "file_path"
    message = "File " + file_path + " was skipped as it's listed in 'skip' setting"
    try:
        raise file_skip_setting(file_path)
    except FileSkipSetting as e:
        assert e.message == message
        assert e.file_path == file_path


# Generated at 2022-06-23 20:19:17.855134
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch( '"asd";asd' )
    except AssignmentsFormatMismatch:
        return True

# Generated at 2022-06-23 20:19:19.417431
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors("/file.py")
    assert error.file_path == "/file.py"

# Generated at 2022-06-23 20:19:20.950188
# Unit test for constructor of class ISortError
def test_ISortError():
    ISortError('test')

if __name__ == '__main__':
    test_ISortError()

# Generated at 2022-06-23 20:19:22.615198
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"name": {"value": "value", "source": "source"}}
    instance = UnsupportedSettings(unsupported_settings)
    assert unsupported_settings == instance.unsupported_settings

# Generated at 2022-06-23 20:19:23.352435
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment('test.py')



# Generated at 2022-06-23 20:19:28.062043
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    import sys
    import os
    import inspect

    # Get current location
    file_loc = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))

    # Create an instance
    obj = FileSkipSetting(file_path = file_loc)

    # Check that the instance has a file_path attribute
    assert hasattr(obj, "file_path")
    assert obj.file_path == file_loc



# Generated at 2022-06-23 20:19:33.850484
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert str(FileSkipped("this is a message", "file")) == "this is a message"

# TODO: Figure out why this test isn't working. Maybe we should test __eq__ or __hash__ or something
# # Unit test for constructor of class ExistingSyntaxErrors
# def test_ExistingSyntaxErrors():
#     assert ExistingSyntaxErrors("file") == Exception(
#         f"isort was told to sort imports within code that contains syntax errors: "
#         f"{file_path}.")


# Generated at 2022-06-23 20:19:43.320737
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    class Mock:
        def __init__(self, n):
            self.n = n

    class BadSettings:
        def __init__(self, str, dict_of_dicts):
            self.str = str
            self.dict_of_dicts = dict_of_dicts

    # Test for bad inputs
    assert(unicode(UnsupportedSettings({'foo': {'value': 'a', 'source': 'bar'}})) ==
           u'isort was provided settings that it doesn\'t support:\n\n'
           u'\t- foo = a  (source: \'bar\')\n\n'
           u'For a complete and up-to-date listing of supported settings see: '
           u'https://pycqa.github.io/isort/docs/configuration/options/.\n')

   

# Generated at 2022-06-23 20:19:45.784320
# Unit test for constructor of class ISortError
def test_ISortError():
    ex = ISortError("This is an error message.")
    assert ex.args[0] == "This is an error message."



# Generated at 2022-06-23 20:19:47.829371
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    if __name__ == '__main__':
        ExistingSyntaxErrors.__init__(["file.py"])


# Generated at 2022-06-23 20:19:51.487234
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    pdn = ProfileDoesNotExist("profile")
    assert pdn.profile == "profile"
    assert str(pdn) == "Specified profile of profile does not exist. " \
                       "Available profiles: .vscode, black, defaults, google, pycharm, " \
                       "pycharm-default, short."


# Generated at 2022-06-23 20:19:53.816851
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Create class instance
    obj = ExistingSyntaxErrors("file_path")

    # Check if attributes are set properly
    assert obj.file_path == "file_path"
    assert obj.args == ("isort was told to sort imports within code that contains syntax errors: file_path.",)

# Generated at 2022-06-23 20:19:56.492546
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("examples.py").message == \
        f"isort introduced syntax errors when attempting to sort the imports contained within " \
        f"examples.py."
    assert IntroducedSyntaxErrors("examples.py").file_path == "examples.py"



# Generated at 2022-06-23 20:19:59.255217
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    solution = "Error: isort was told to sort a literal of type tuple but was given a literal of type list."
    result = LiteralSortTypeMismatch(list, tuple)
    assert str(result) == solution

# Generated at 2022-06-23 20:20:04.168373
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist(profile="1")
    except ProfileDoesNotExist as exception:
        assert str(exception) == (
            "Specified profile of 1 does not exist. Available profiles: black, "
            "google, isort, pep8, pycharm, vint, yapf"
        )
        assert exception.profile == "1"
    else:
        raise AssertionError



# Generated at 2022-06-23 20:20:09.907118
# Unit test for constructor of class InvalidSettingsPath

# Generated at 2022-06-23 20:20:13.528196
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a,b = a,b")
    except AssignmentsFormatMismatch as a:
        assert a.code == "a,b = a,b"



# Generated at 2022-06-23 20:20:15.076303
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    s = LiteralSortTypeMismatch(1, 2)
    assert (s.kind == 1)
    assert (s.expected_kind == 2)


# Generated at 2022-06-23 20:20:16.102637
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors('test_file')
    assert error.file_path == 'test_file'

# Generated at 2022-06-23 20:20:21.208334
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    filename = "test/file.py"
    e = ExistingSyntaxErrors(filename)
    assert str(e) == (
        "isort was told to sort imports within code that contains syntax errors: "
        f"{filename}"
    )
    assert e.file_path == filename
    assert repr(e) == f"<{e.__class__.__name__}: {filename}>"


# Generated at 2022-06-23 20:20:23.377123
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped = FileSkipped("message", "path")
    assert file_skipped.message == "message"
    assert file_skipped.file_path == "path"

# Generated at 2022-06-23 20:20:25.795720
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    obj = FileSkipComment(file_path="test_path")
    assert obj.file_path == "test_path"
    assert obj.message == "test_path contains an file skip comment and was skipped."

# Generated at 2022-06-23 20:20:27.155519
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("test").file_path == "test"

# Generated at 2022-06-23 20:20:29.511466
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("message")
    except ISortError as e:
        assert str(e) == "message"


# Generated at 2022-06-23 20:20:31.393502
# Unit test for constructor of class MissingSection
def test_MissingSection():
    """Unit test for constructor of class MissingSection"""
    MissingSection("import_module", "section")


# Generated at 2022-06-23 20:20:36.647616
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert str(
        UnsupportedSettings({"use_parentheses": {"value": "True", "source": "runtime"}})
    ) == (
        "isort was provided settings that it doesn't support:\n\n"
        "\t- use_parentheses = True  (source: 'runtime')\n\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )

# Generated at 2022-06-23 20:20:40.243387
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(TypeError) as excinfo:
        ISortError()
    assert (
        "Can't instantiate abstract class ISortError with abstract methods __init__"
    ) in str(excinfo.value)

# Generated at 2022-06-23 20:20:46.718668
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('test')
    except ProfileDoesNotExist as e:
        assert e.profile == 'test'
        assert str(e) == f"Specified profile of {e.profile} does not exist. Available profiles: black."
    try:
        raise ProfileDoesNotExist('fake')
    except ProfileDoesNotExist as e:
        assert e.profile == 'fake'
        assert str(e) == f"Specified profile of {e.profile} does not exist. Available profiles: black."


# Generated at 2022-06-23 20:20:51.596905
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    exc = AssignmentsFormatMismatch('hello')
    assert exc.code == 'hello'
    assert exc.args[0] == "isort was told to sort a section of assignments, however the given code:\n\nhello\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"


# Generated at 2022-06-23 20:20:57.363728
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    message = "file_path contains an file skip comment and was skipped."
    file_path = "file_path"
    try:
        raise FileSkipComment(file_path)
    except FileSkipComment as e:
        assert e.message == message
        assert e.file_path == file_path

# Generated at 2022-06-23 20:20:59.401046
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    s = FileSkipComment("skip_file")
    assert "skip_file" in s.message



# Generated at 2022-06-23 20:21:02.100666
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('wrong')
    except ProfileDoesNotExist as e:
        assert e.profile == 'wrong'



# Generated at 2022-06-23 20:21:05.969139
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    exception = FileSkipSetting("path/to/file.py")
    assert str(exception) == (
        "path/to/file.py was skipped as it's listed in 'skip' setting"
        " or matches a glob in 'skip_glob' setting"
    )
    assert exception.file_path == "path/to/file.py"

# Generated at 2022-06-23 20:21:07.328640
# Unit test for constructor of class MissingSection
def test_MissingSection():
    with pytest.raises(MissingSection):
        raise MissingSection("import_module", "section")

# Generated at 2022-06-23 20:21:13.158486
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    import warnings
    warnings.filterwarnings("ignore")
    with pytest.raises(FileSkipComment) as e:
        raise FileSkipComment("test/test.py")
    assert e.value.file_path == "test/test.py"


# Generated at 2022-06-23 20:21:15.578472
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        a = 4 / 0
    except ZeroDivisionError:
        raise ISortError("my message")


# Generated at 2022-06-23 20:21:17.888429
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding("abc.txt")
    assert hasattr(error, "filename") and error.filename == "abc.txt"


# Generated at 2022-06-23 20:21:19.961598
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    e = FileSkipComment("file")
    assert e.file_path == "file"


# Generated at 2022-06-23 20:21:24.072511
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    for name, value, source in [
        ("fake_option", "fake_value", "fake_source"),
        ("fake_option2", "fake_value2", "fake_source2"),
    ]:
        assert (
            UnsupportedSettings({name: {"value": value, "source": source}}).unsupported_settings
            == {name: {"value": value, "source": source}}
        )

# Generated at 2022-06-23 20:21:27.881744
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    test_file_path = "test/error_file.py"
    err = IntroducedSyntaxErrors(test_file_path)
    assert str(err) == f"isort introduced syntax errors when attempting to sort the imports contained within {test_file_path}."
    assert err.file_path == test_file_path

# Generated at 2022-06-23 20:21:30.213395
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """ Test to ensure UnsupportedEncoding exception is raised
    """
    filename="example.py"
    with pytest.raises(UnsupportedEncoding):
        raise UnsupportedEncoding(filename)

# Generated at 2022-06-23 20:21:34.154712
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test.py")
    except ExistingSyntaxErrors as  e:
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test.py."
        assert e.file_path == "test.py"

# Generated at 2022-06-23 20:21:37.912623
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("iSort")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of iSort does not exist."

# Generated at 2022-06-23 20:21:39.602623
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("numpy", "FUTURE")
    except MissingSection:
        pass



# Generated at 2022-06-23 20:21:45.004917
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # GIVEN
    file_path = "file_path"
    
    # WHEN
    actual = ExistingSyntaxErrors(file_path=file_path)

    # THEN
    assert actual.file_path == file_path
    assert str(actual) == f"isort was told to sort imports within code that contains syntax errors: " \
                          f"{file_path}."


# Generated at 2022-06-23 20:21:47.326304
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = b\nb = c")
    except:
        pass
    

# Generated at 2022-06-23 20:21:52.393389
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("non-existing-profile")
    except ProfileDoesNotExist as e:
        assert "Specified profile of non-existing-profile does not exist. Available profiles: " \
               "black, google, pyup, google-py2, imports, facebook, vint, chromium, pycharm, " \
               "mozilla, openstack, gnome, kde, py-twosix, py-threetwo, open-source, " \
               "python-next, importmagic, isort." == str(e)



# Generated at 2022-06-23 20:21:54.737003
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure()
    except LiteralParsingFailure as exception:
        assert exception.code is None
        assert exception.original_error is None

# Generated at 2022-06-23 20:21:57.176967
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
        exception = InvalidSettingsPath("mock_settings_path")
        assert exception.settings_path == "mock_settings_path"


# Generated at 2022-06-23 20:22:02.091686
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert str(InvalidSettingsPath("settings_path")) == \
           "isort was told to use the settings_path: settings_path as the base directory or file " \
           "that represents the starting point of config file discovery, but it does not exist."
    assert InvalidSettingsPath("settings_path").settings_path == "settings_path"

# Generated at 2022-06-23 20:22:04.049708
# Unit test for constructor of class ISortError
def test_ISortError():
    test = ISortError("Test ISortError")
    assert test.args[0] == "Test ISortError"



# Generated at 2022-06-23 20:22:07.348574
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(FileSkipped) as exc_info:
        raise FileSkipped("hello", "world")
    assert exc_info.value.message == "hello"
    assert exc_info.value.file_path == "world"


# Generated at 2022-06-23 20:22:09.977843
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment('skipped.py')
    except FileSkipComment as e:
        assert e.file_path == 'skipped.py'
        print('test_FileSkipComment passed.')


# Generated at 2022-06-23 20:22:13.517835
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(str, int).kind == str
    assert LiteralSortTypeMismatch(str, int).expected_kind == int
    assert LiteralSortTypeMismatch(str, int).args[0] == 'isort was told to sort a literal of type <class \'int\'> but was given a literal of type <class \'str\'>.'

# Generated at 2022-06-23 20:22:14.951639
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(kind=1, expected_kind=2)

# Generated at 2022-06-23 20:22:17.732342
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    setting_path = "test_path"
    setting_comment = "test_comment"

    assert FileSkipComment(setting_path, comment=setting_comment).file_path == setting_path


# Generated at 2022-06-23 20:22:20.329701
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    e = InvalidSettingsPath('test/test_settings/non-existent-settings-file')
    assert e.settings_path == 'test/test_settings/non-existent-settings-file'


# Generated at 2022-06-23 20:22:27.006547
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # Tests for missing path
    try:
        raise InvalidSettingsPath("dummy_path")
    except Exception as e:
        assert e.__str__() == ("isort was told to use the settings_path: dummy_path as the base "
                               "directory or file that represents the starting point of config "
                               "file discovery, but it does not exist.")
        assert e.settings_path == "dummy_path"


# Generated at 2022-06-23 20:22:28.179879
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    e = UnsupportedEncoding("test.py")
    assert str(e) == "Unknown or unsupported encoding in test.py"

# Generated at 2022-06-23 20:22:29.282668
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
  err = UnsupportedEncoding("test_file.txt")
  assert(err.filename == "test_file.txt")

# Generated at 2022-06-23 20:22:30.703674
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    string = "x = [1, 2, 3]\ny = [1, 2, 3]\n"
    AssignmentsFormatMismatch(string)

# Generated at 2022-06-23 20:22:35.252934
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    message = "The specified formatter 'yapf' is not found. Please run 'isort --list-formatters' " \
              "to see the list of supported formatters."
    isorterror = FormattingPluginDoesNotExist("mock_formatter")
    assert isorterror.formatter == "mock_formatter"
    assert str(isorterror) == message
# End unit test