

# Generated at 2022-06-23 20:12:37.287062
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    err = InvalidSettingsPath("settings_path")
    assert str(err) == ("isort was told to use the settings_path: settings_path as the base "
                        "directory or file that represents the starting point of config file "
                        "discovery, but it does not exist.")
    assert err.settings_path == "settings_path"


# Generated at 2022-06-23 20:12:40.074077
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    test_UnsupportedEncoding = UnsupportedEncoding("filename")
    assert test_UnsupportedEncoding.filename == "filename"


# Generated at 2022-06-23 20:12:44.373360
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = int
    expected_kind = list
    with pytest.raises(LiteralSortTypeMismatch) as e:
        raise LiteralSortTypeMismatch(kind , expected_kind)
    assert e.value.kind == kind
    assert e.value.expected_kind == expected_kind


# Generated at 2022-06-23 20:12:47.548390
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "The specified file..."
    file_path = "test_path"
    caught_error = FileSkipped(message, file_path)
    assert caught_error.message == message
    assert caught_error.file_path == file_path

# Generated at 2022-06-23 20:12:50.811603
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'test_file_path'
    file_skipped = FileSkipComment(file_path)

    assert str(file_skipped) == f'{file_path} contains an file skip comment and was skipped.'
    assert file_skipped.file_path == file_path


# Generated at 2022-06-23 20:12:54.899631
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
	raise ExistingSyntaxErrors("file_path")


# Generated at 2022-06-23 20:12:59.181623
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection("foo", "bar").args[0] == \
           "Found foo import while parsing, but bar was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:13:02.989811
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped('testing', 'file')
    except FileSkipped as e:
        assert str(e) == 'testing'
        assert e.file_path == 'file'

# Generated at 2022-06-23 20:13:09.638292
# Unit test for constructor of class MissingSection
def test_MissingSection():
    """Test for constructor of class MissingSection.
    This test is for coverage only.
    """
    s = MissingSection('foo', 'bar')
    assert str(s) == 'Found foo import while parsing, but bar was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'
    return

# Generated at 2022-06-23 20:13:11.849788
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test"


# Generated at 2022-06-23 20:13:17.312841
# Unit test for constructor of class MissingSection
def test_MissingSection():
    m = MissingSection("test_module", "FUTURE")
    assert m.args[0] == "Found test_module import while parsing, but FUTURE was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
    assert m.import_module == "test_module"
    assert m.section == "FUTURE"

# Generated at 2022-06-23 20:13:26.025435
# Unit test for constructor of class ISortError
def test_ISortError():
    from isort.main import ISORT_VERSION
    from isort.settings import Config
    import pytest

    argparse_options = {"force_single_line": True, "version": True, "settings_path": '.'}
    profile_settings, settings = Config(**argparse_options).get_config(force_py36=True)
    op = ISortError(profile_settings, settings)
    op.isort(force_single_line=True)
    with pytest.raises(ISortError):
        op.isort(force_single_line=False)
    op.isort(settings)
    assert op.__exit__() is None
    assert op.__str__() is not None
    assert op.__str__() == ''

# Generated at 2022-06-23 20:13:28.183992
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("abc")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "abc"


# Generated at 2022-06-23 20:13:30.650891
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        UnsupportedEncoding("teest")
    except:
        pass
    pass

# Generated at 2022-06-23 20:13:33.198710
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    from .version import __version__
    assert AssignmentsFormatMismatch(__version__)



# Generated at 2022-06-23 20:13:34.200147
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting("test")



# Generated at 2022-06-23 20:13:43.154100
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = """
    from module import Class
    from module2 import Class2
    myVariable = Class()
    anotherOne = Class2()
    """

    import unittest
    # try except to handle exception

# Generated at 2022-06-23 20:13:46.633545
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit test for constructor of class UnsupportedSettings"""
    unsupported_settings = {'invalid_setting': {'value': 'foo', 'source': 'runtime'}}
    with pytest.raises(UnsupportedSettings) as error:
        raise UnsupportedSettings(unsupported_settings)
    assert error.value.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:13:48.746838
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
      raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
      assert e.profile == "test"


# Generated at 2022-06-23 20:13:53.759264
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("folder/file.py")
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within folder/file.py."
        assert e.file_path == "folder/file.py"


# Generated at 2022-06-23 20:13:57.354991
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    themis = LiteralSortTypeMismatch(type(234), type([]))
    assert isinstance(themis, LiteralSortTypeMismatch)
    assert themis.kind == int
    assert themis.expected_kind == list

# Generated at 2022-06-23 20:14:01.036657
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_name = "test_import"
    section_name = "fake_section"
    exception = MissingSection(import_name, section_name)
    assert exception.args[0] == exception.__str__()
    assert exception.import_module == import_name
    assert exception.section == section_name

# Generated at 2022-06-23 20:14:03.441918
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    f = FileSkipped("message", "file_path")
    assert f.message == "message"
    assert f.file_path == "file_path"

# Generated at 2022-06-23 20:14:04.519399
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = "path"
    FileSkipComment(path)

# Generated at 2022-06-23 20:14:07.675463
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(ISortError) as exc:
        FileSkipped('hehe', 'hehe')
    assert str(exc.value) == 'hehe'


# Generated at 2022-06-23 20:14:14.322346
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise TypeError("hello")
    except TypeError as e:
        try:
            raise LiteralParsingFailure("testcode", e)
        except ISortError as err:
            assert err.code == "testcode"
            assert err.original_error == e
        else:
            raise IOError("LiteralParsingFailure is not raised")
    else:
        raise IOError("TypeError is not raised")

# Generated at 2022-06-23 20:14:19.047921
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test."
        assert repr(e) == "isort was told to sort imports within code that contains syntax errors: test."

# Generated at 2022-06-23 20:14:22.613299
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    e = ExistingSyntaxErrors("./test/test_files/syntax_error.py")
    assert(e.file_path == "./test/test_files/syntax_error.py")

# Generated at 2022-06-23 20:14:27.781539
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    expected = str(FileSkipSetting('fileskiptesting.py'))
    assert expected == "fileskiptesting.py was skipped as it's listed in 'skip' setting" \
                       " or matches a glob in 'skip_glob' setting."

# Generated at 2022-06-23 20:14:35.883926
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    from ast import literal_eval
    from .config import Config
    from .sorting import SortImports

    cfg = Config()
    code = "a=1; b=2; c=3"
    code = SortImports(
        file_contents=code,
        file_path="test.py",
        config=cfg,
    ).output
    print(code)

    code = "a=10; b=20; c=30"
    code = SortImports(
        file_contents=code,
        file_path="test.py",
        config=cfg,
    ).output
    print(code)
# End of unit test

# Generated at 2022-06-23 20:14:40.110879
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Create object using LiteralSortTypeMismatch
    isort_type_mismatch = LiteralSortTypeMismatch(str, bool)

    # Assert error message
    assert (
        str(isort_type_mismatch)
        == "isort was told to sort a literal of type <class 'bool'> but was given a literal of type <class 'str'>."
    )

# Generated at 2022-06-23 20:14:45.371899
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    """Test the constructor for the FileSkipSetting class."""
    x = FileSkipSetting("file_path")
    assert x.args[0] == "file_path was skipped as it's listed in 'skip' setting"\
                        " or matches a glob in 'skip_glob' setting"
    assert x.file_path == "file_path"



# Generated at 2022-06-23 20:14:48.568818
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=int, expected_kind=str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


test_LiteralSortTypeMismatch()

# Generated at 2022-06-23 20:14:49.503539
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped('abc', 'abc').file_path == 'abc'

# Generated at 2022-06-23 20:14:51.397292
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test.py")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test.py"



# Generated at 2022-06-23 20:14:58.851708
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    class_ = FileSkipSetting
    file_path = "test"
    # Default constructor
    try:
        inst = class_(file_path)
    except Exception:
        assert False, "Unexpected exception"
    assert inst.message == f"{file_path} was skipped as it's listed in 'skip' setting"\
                            " or matches a glob in 'skip_glob' setting"
    assert inst.file_path == file_path
    # Constructor with message
    try:
        inst = FileSkipSetting(file_path, "msg")
    except Exception:
        assert False, "Unexpected exception"
    assert inst.message == "msg"


# Generated at 2022-06-23 20:15:00.843282
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"1": {"value": 1, "source": "test"}}
    assert UnsupportedSettings(unsupported_settings) != None

# Generated at 2022-06-23 20:15:08.693996
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("illegal_code")
    except ISortError as err:
        assert (
            f"isort was told to sort a section of assignments, however the given code:\n\n"
            f"{'illegal_code'}\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n"
            == str(err)
        )

# Generated at 2022-06-23 20:15:10.640552
# Unit test for constructor of class MissingSection
def test_MissingSection():
    x = MissingSection('import_module', 'section')
    assert x.import_module == 'import_module'
    assert x.section == 'section'

# Generated at 2022-06-23 20:15:14.718849
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    f1=FileSkipComment("test/test.py")
    f2=FileSkipComment("test/test1.py")
    assert f1.message=='test/test.py contains an file skip comment and was skipped.'
    assert f1.file_path=='test/test.py'
    assert f2.message=='test/test1.py contains an file skip comment and was skipped.'
    assert f2.file_path=='test/test1.py'

# Generated at 2022-06-23 20:15:19.838466
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("dummy_file_path")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "dummy_file_path"
        print(f"test Passed: {__file__}")



# Generated at 2022-06-23 20:15:25.615932
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
	# single file only
	file = "test.py"
	e = UnsupportedEncoding(file)
	assert(e.filename == file)
	# directory case
	import pathlib
	p = pathlib.Path("testFolder")
	# create folder
	p.mkdir()
	e = UnsupportedEncoding(p)
	# delete folder
	p.rmdir()
	assert(e.filename == p)

# Generated at 2022-06-23 20:15:26.806314
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert "skipped" in str(FileSkipComment("filename.py"))

# Generated at 2022-06-23 20:15:33.764251
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('/Users/sam/Desktop/isort-config/')
        print('Error: failed to raise InvalidSettingsPath exception')
    except InvalidSettingsPath as e:
        print('Success: raised InvalidSettingsPath exception')
        assert e.settings_path == '/Users/sam/Desktop/isort-config/'

test_InvalidSettingsPath()


# Generated at 2022-06-23 20:15:36.974806
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    class _UnsupportedSettings(UnsupportedSettings):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

# Generated at 2022-06-23 20:15:41.030433
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_skip_setting = FileSkipSetting('/Users/kimtaehyun/Desktop/isort-4.3.21/isort/settings.py')
    assert 'was skipped as it\'s listed in \'skip\' setting or matches a glob in \'skip_glob\'' in file_skip_setting.args[0]

# Generated at 2022-06-23 20:15:42.481605
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped("message", "file_path")



# Generated at 2022-06-23 20:15:44.974858
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "x = 1\ny = 2"

    raised = False
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch:
        raised = True
    assert raised



# Generated at 2022-06-23 20:15:53.667760
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    expected_message = "isort was told to sort a section of assignments, however the given code:\n\n" \
                       "code\n\nDoes not match isort's strict single line formatting requirement for assignment " \
                       "sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"
    try:
        raise AssignmentsFormatMismatch("code")
    except AssignmentsFormatMismatch as e:
        assert str(e) == expected_message


# Unit tests for constructor of class LiteralSortTypeMismatch

# Generated at 2022-06-23 20:15:59.279433
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "test"
    try:
        raise IntroducedSyntaxErrors(file_path)
    except IntroducedSyntaxErrors as e:
        assert e.file_path == file_path
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test."
    else:
        assert False, "Error not successfully raised"

# Generated at 2022-06-23 20:16:04.049691
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception = IntroducedSyntaxErrors(file_path="test_file_path")
    message = str(exception)
    assert "isort introduced syntax errors when attempting to sort the imports contained within test_file_path." in message


# Generated at 2022-06-23 20:16:08.399402
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        int('a')
    except Exception as e:
        try:
            raise LiteralParsingFailure('test', e)
        except LiteralParsingFailure as e:
            print(e)


if __name__ == '__main__':
    test_LiteralParsingFailure()

# Generated at 2022-06-23 20:16:11.092993
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except ISortError:
        pass


# Generated at 2022-06-23 20:16:14.838154
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    err = LiteralParsingFailure(code='dict(abc=abc)', original_error=ValueError('dict(abc'))
    assert(err.code == 'dict(abc=abc)' and err.original_error.message == 'dict(abc')

# Generated at 2022-06-23 20:16:16.840405
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(ISortError):
        LiteralSortTypeMismatch(1, int)

# Generated at 2022-06-23 20:16:19.154038
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors):
        raise ExistingSyntaxErrors("test_file_path")



# Generated at 2022-06-23 20:16:21.635261
# Unit test for constructor of class ISortError
def test_ISortError():
  try:
    raise ISortError("test")
  except ISortError:
    assert True
  else:
    assert False


# Generated at 2022-06-23 20:16:26.953612
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profiles_list = ['django', 'black', 'google', 'pycharm', 'jupyter', 'spyder', 'future', 'timemachine', 'virtualenv', 'mamba', 'custom', 'discover', 'example_profile']
    value = 'test'
    with raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist(profile=value)
    assert ProfileDoesNotExist(profile=value).profile == value
    assert ProfileDoesNotExist(profile=value).args[0] == f'Specified profile of {value} does not exist. Available profiles: {",".join(profiles_list)}.'

# Generated at 2022-06-23 20:16:34.997768
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("E:\\Projects\\Repo\\test.py")
    except ISortError as e:
        if str(e) != "isort was told to sort imports within code that contains syntax errors: E:\\Projects\\Repo\\test.py.":
            assert False
        assert e.file_path == "E:\\Projects\\Repo\\test.py"
        assert e.__class__ == ExistingSyntaxErrors

# Generated at 2022-06-23 20:16:36.206354
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert bool(FileSkipped("message", "test_file.py")) == True

# Generated at 2022-06-23 20:16:38.969655
# Unit test for constructor of class ISortError
def test_ISortError():
    """Is ISortError instantiating as expected?"""
    try:
        raise ISortError('Just checking')
    except ISortError as i:
        assert str(i) == 'Just checking'

# Generated at 2022-06-23 20:16:40.062912
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert isinstance(LiteralSortTypeMismatch(str, int), LiteralSortTypeMismatch)

# Generated at 2022-06-23 20:16:42.227802
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped = FileSkipped('Test message.', 'Test File')
    assert file_skipped.message == 'Test message.'
    assert file_skipped.file_path == 'Test File'
    assert file_skipped.args == ('Test message.',)


# Generated at 2022-06-23 20:16:44.327847
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('import', 'section')
    except MissingSection as err:
        assert 'import' == err.import_module
        assert 'section' == err.section

# Generated at 2022-06-23 20:16:48.395635
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = '/test/test.test'
    try:
        # raise the exception
        raise UnsupportedEncoding(filename)
    except UnsupportedEncoding as e:
        # check if the exception was raised
        assert e.filename == filename

# Generated at 2022-06-23 20:16:51.330820
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist):
        raise FormattingPluginDoesNotExist("abc")


# Generated at 2022-06-23 20:16:52.693204
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("", SyntaxError())
    except LiteralParsingFailure:
        pass

# Generated at 2022-06-23 20:16:58.276474
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(b"a=b,c=d")
    except AssignmentsFormatMismatch as e:
        assert isinstance(e, AssignmentsFormatMismatch)
        assert str(e) =="""isort was told to sort a section of assignments, however the given code:


Does not match isort's strict single line formatting requirement for assignment sorting:

{variable_name} = {value}
{variable_name2} = {value2}
...


"""
        assert e.code == "a=b,c=d"


# Generated at 2022-06-23 20:17:07.453742
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit test for constructor of class UnsupportedSettings"""
    setting1 = {'value': '3', 'source': 'CommandLine'}
    setting2 = {'value': 'True', 'source': 'ConfigFile'}
    unsupported_settings = {'line_length': setting1, 'allow_multiline_calls': setting2}
    assert unsupported_settings['line_length']['value'] == '3'
    assert unsupported_settings['line_length']['source'] == 'CommandLine'
    assert unsupported_settings['allow_multiline_calls']['value'] == 'True'
    assert unsupported_settings['allow_multiline_calls']['source'] == 'ConfigFile'

    # Unsupported settings raise UnsupportedSettings Exception

# Generated at 2022-06-23 20:17:09.261306
# Unit test for constructor of class ISortError
def test_ISortError():
    obj = ISortError()
    assert obj

if __name__ == "__main__":
    test_ISortError()

# Generated at 2022-06-23 20:17:10.866610
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist('profile')
    assert 'Specified profile' in str(error)


# Generated at 2022-06-23 20:17:11.965617
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped('message', 'file_path')

# Generated at 2022-06-23 20:17:17.301741
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    # mocks
    file_path = "my/file/path"
    message = "File skipped"

    # call
    skip_exception = FileSkipped(message, file_path)

    # assert
    assert skip_exception.message == message
    assert skip_exception.file_path == file_path

# Generated at 2022-06-23 20:17:20.354837
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-23 20:17:22.211495
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    x = ExistingSyntaxErrors("/var/lib/sorted.py")
    return x


# Generated at 2022-06-23 20:17:25.944978
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("file_path")
    except ExistingSyntaxErrors as e:
        assert str(e) == (
            "isort was told to sort imports within code that contains syntax errors: file_path."
        )
        assert e.file_path == "file_path"

# Generated at 2022-06-23 20:17:27.687627
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "smth"
    error = UnsupportedEncoding(filename)
    assert error.filename == filename
    assert error.__str__() == f"Unknown or unsupported encoding in {filename}"

# Generated at 2022-06-23 20:17:29.705713
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("")
    except FormattingPluginDoesNotExist:
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:17:34.252456
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(expected_kind=dict, kind=list)
    except LiteralSortTypeMismatch as e:
        assert str(e) == 'isort was told to sort a literal of type dict but was given ' \
                         'a literal of type list.'

# Generated at 2022-06-23 20:17:36.049023
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("hello").file_path == "hello"

# Generated at 2022-06-23 20:17:37.660178
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("foo").file_path == "foo"

# Generated at 2022-06-23 20:17:41.854005
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('file.py')
    except UnsupportedEncoding as e:
        assert e.args[0] == 'Unknown or unsupported encoding in file.py'

# Generated at 2022-06-23 20:17:44.943989
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    exc = ProfileDoesNotExist("test")
    assert exc.profile == "test"
    assert exc.args == ("Specified profile of test does not exist. "
                        "Available profiles: test,test2.",)


# Generated at 2022-06-23 20:17:47.499910
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = """
A = 1
B = 2
"""
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert e.code == code

# Generated at 2022-06-23 20:17:49.411304
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("unittest","section")
    except MissingSection as error:
        assert error.import_module == "unittest"
        assert error.section == "section"

# Generated at 2022-06-23 20:17:50.145588
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('A', 'B')

# Generated at 2022-06-23 20:17:52.878973
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("my_formatter")
    except FormattingPluginDoesNotExist as exception:
        assert str(exception) == "Specified formatting plugin of my_formatter does not exist."
        assert exception.formatter == "my_formatter"

# Generated at 2022-06-23 20:17:53.926852
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting(file_path="abc.txt")

# Generated at 2022-06-23 20:17:59.875101
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    ex = LiteralSortTypeMismatch(kind=list, expected_kind=dict)
    assert isinstance(ex, ISortError)
    assert repr(ex) == "kind=<class 'list'>, expected_kind=<class 'dict'>"
    assert str(ex) == "isort was told to sort a literal of type <class 'dict'>" \
                      " but was given a literal of type <class 'list'>."



# Generated at 2022-06-23 20:18:02.598173
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        file_skipped = FileSkipped("message","path")
    except Exception as e:
        pass
    else:
        raise AssertionError("Expected Exception was not raised")


# Generated at 2022-06-23 20:18:04.195434
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert isinstance(ExistingSyntaxErrors("abc.py"), ExistingSyntaxErrors)

# Generated at 2022-06-23 20:18:08.139819
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    traceback = "Traceback"
    message = "message"
    e = LiteralParsingFailure(traceback, message)
    assert e.code == traceback
    assert e.original_error == message



# Generated at 2022-06-23 20:18:12.201357
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("1+1", "test")
    except LiteralParsingFailure as e:
        assert str(e) == "isort failed to parse the given literal 1+1. It's important to note " \
            "that isort literal sorting only supports simple literals parsable by " \
            "ast.literal_eval which gave the exception of test."

# Generated at 2022-06-23 20:18:15.237239
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors("test.py")
    assert (str(error) == "isort was told to sort imports within code that contains syntax errors: test.py.")

# Generated at 2022-06-23 20:18:18.088074
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # arrange
    file_path = "path\\to\\file"
    f = FileSkipSetting(file_path)
    # act
    # assert
    assert f.file_path == file_path

# Generated at 2022-06-23 20:18:22.665984
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # Settings is a dictionary of dictionaries where the top level key is the name of
    # the unsupported setting and the inner dictionary contains the value of the setting and
    # the source that the setting was set from.
    settings: Dict[str, Dict[str, str]] = {"break_length": {"value": "80", "source": "user"}}
    assert str(UnsupportedSettings(settings)).endswith(
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )

# Generated at 2022-06-23 20:18:28.573844
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=int, expected_kind=str)
    except LiteralSortTypeMismatch as e:
        assert str(e) == (
            "isort was told to sort a literal of type <class 'str'> but was given "
            "a literal of type <class 'int'>. "
        )
        assert e.kind == int
        assert e.expected_kind == str



# Generated at 2022-06-23 20:18:36.392324
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # type: () -> None
    """Test for the constructor of class UnsupportedSettings"""
    unsupported_settings = {"custom_sections": {"source": "config file"}}
    exception = UnsupportedSettings(unsupported_settings)

    assert exception.unsupported_settings == unsupported_settings
    assert (
        str(exception) == "isort was provided settings that it doesn't support:\n\n"
        "\t- custom_sections = {'source': 'config file'}  (source: 'config file')\n\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )

# Generated at 2022-06-23 20:18:44.594388
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():

    u = UnsupportedSettings({'a': {'value': 1, 'source': 'a'}})

    assert u.unsupported_settings == {'a': {'value': 1, 'source': 'a'}}
    assert str(u) == "isort was provided settings that it doesn't support:\n\n" \
                     "\t- a = 1  (source: 'a')\n\n" \
                     "For a complete and up-to-date listing of supported settings see: " \
                     "https://pycqa.github.io/isort/docs/configuration/options/.\n"

# Generated at 2022-06-23 20:18:50.252422
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type(first=1)
    expected_kind = type(second=2)
    instance = LiteralSortTypeMismatch(kind, expected_kind)
    assert instance.kind == kind
    assert instance.expected_kind == expected_kind

# Generated at 2022-06-23 20:18:54.685756
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath) as invalid_settings_path:
        raise InvalidSettingsPath("/path/that/doesnt/exist.yml")
    assert invalid_settings_path.value.settings_path == "/path/that/doesnt/exist.yml"



# Generated at 2022-06-23 20:18:56.144780
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    obj = UnsupportedEncoding("file")
    assert obj.filename == "file"

# Generated at 2022-06-23 20:18:59.017077
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "something.py"
    error = UnsupportedEncoding(filename)
    assert error.filename == filename
    assert "Unknown or unsupported encoding in something.py" in str(error)

test_UnsupportedEncoding()

# Generated at 2022-06-23 20:19:04.019997
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = 'another_dict = BASE_DICT'
    original_error = 'exception'
    obj = LiteralParsingFailure(code, original_error)
    assert obj.code == code
    assert obj.original_error == original_error
    assert str(obj) == "isort failed to parse the given literal {}. It's important to note " \
                       "that isort literal sorting only supports simple literals parsable by " \
                       "ast.literal_eval which gave the exception of {}.".format(code,original_error)


# Generated at 2022-06-23 20:19:06.669728
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    x = FileSkipped("test message", "test file path")
    assert x.__str__() == "test message"
    assert x.file_path == "test file path"

# Generated at 2022-06-23 20:19:08.371898
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    plugin = "foo"
    try:
        raise FormattingPluginDoesNotExist(plugin)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "foo"

# Generated at 2022-06-23 20:19:11.321900
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_file"
    assert FileSkipSetting(file_path).message == f"{file_path} was skipped as it's listed in 'skip' setting" \
                                                f" or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-23 20:19:13.594692
# Unit test for constructor of class ISortError
def test_ISortError():
    t = InvalidSettingsPath('settings_path')
    assert t.settings_path == 'settings_path'

if __name__ == '__main__':
    test_ISortError()

# Generated at 2022-06-23 20:19:15.117894
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('test')
    except Exception as e:
        print(e)


# Generated at 2022-06-23 20:19:16.987350
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('top')
    except ProfileDoesNotExist as exception:
        profile = exception.profile
    assert profile == 'top'

# Generated at 2022-06-23 20:19:20.110810
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    # Create a file skipped object
    FileSkipped("message", "dir/file")
    # Assert that the file path is the same as the provided one
    assert FileSkipped.file_path == "dir/file"

# Generated at 2022-06-23 20:19:20.911673
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    UnsupportedEncoding("filename")

# Generated at 2022-06-23 20:19:23.143718
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({
        'a': {'value': "'c'", 'option_source': 'config'},
        'b': {'value': "'f'", 'option_source': 'config'}})

# Generated at 2022-06-23 20:19:24.446477
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist("testing")
    assert error.profile == "testing"

# Generated at 2022-06-23 20:19:27.289184
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'test/isort/test_FileSkipComment'
    msg = f"{file_path} contains an file skip comment and was skipped."
    assert FileSkipComment(file_path).file_path == file_path
    assert FileSkipComment(file_path).message == msg

# Generated at 2022-06-23 20:19:28.466403
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert "FileSkipComment" in str(FileSkipComment)

# Generated at 2022-06-23 20:19:31.972681
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    expected_msg = 'isort was told to sort imports within code that contains syntax errors: /path/to/file.py.'
    with pytest.raises(ExistingSyntaxErrors) as ex:
        raise ExistingSyntaxErrors('/path/to/file.py')

    assert type(ex.value) is ExistingSyntaxErrors
    assert ex.value.args == (expected_msg,)
    assert ex.value.file_path == '/path/to/file.py'

# Generated at 2022-06-23 20:19:34.400079
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("test")
    except ISortError as e:
        assert str(e) == "test"

# Generated at 2022-06-23 20:19:38.455502
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    expected_message = "FileSkipped test message"
    expected_file_path = "FileSkipped test path"
    file_skipped = FileSkipped(expected_message, expected_file_path)
    assert file_skipped.message == expected_message
    assert file_skipped.file_path == expected_file_path

# Generated at 2022-06-23 20:19:46.459070
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = "str"
    expected_kind = "int"
    a1 = LiteralSortTypeMismatch(kind, expected_kind)
    kind = "str"
    expected_kind = 1
    a2 = LiteralSortTypeMismatch(kind, expected_kind)
    kind = "str"
    expected_kind = 1.0
    a3 = LiteralSortTypeMismatch(kind, expected_kind)
    kind = 1
    expected_kind = 1.0
    a4 = LiteralSortTypeMismatch(kind, expected_kind)
    kind = "str"
    expected_kind = True
    a5 = LiteralSortTypeMismatch(kind, expected_kind)
    kind = "str"
    expected_kind = False

# Generated at 2022-06-23 20:19:48.720347
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(1, "int")
    except LiteralSortTypeMismatch as e:
        assert e.expected_kind == "int"
        assert e.kind == 1

# Generated at 2022-06-23 20:19:51.219326
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("foo.py")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "foo.py"


# Generated at 2022-06-23 20:19:52.997954
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    obj = ExistingSyntaxErrors("test.py")
    assert obj.file_path == "test.py"

# Generated at 2022-06-23 20:19:56.376374
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("dummy_formatter")
    except FormattingPluginDoesNotExist as usage:
        assert usage.formatter == "dummy_formatter"

# Generated at 2022-06-23 20:19:58.588037
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "testformatter"
    assert FormattingPluginDoesNotExist(formatter)

# Generated at 2022-06-23 20:20:04.249591
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # normal
    test_obj = MissingSection('import_module', 'section')
    assert test_obj.import_module == 'import_module'
    assert test_obj.section == 'section'
    assert test_obj.args == (
        "Found import_module import while parsing, but section was not included in the "
        "'sections' setting of your config. Please add it before continuing\nSee "
        "https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.", 
    )

# Generated at 2022-06-23 20:20:06.633185
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    x = ProfileDoesNotExist("Testing")
    assert x.profile == "Testing"

# Generated at 2022-06-23 20:20:08.676425
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("")
    except AssignmentsFormatMismatch as e:
        assert True

# Generated at 2022-06-23 20:20:09.731943
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    InvalidSettingsPath("toto")


# Generated at 2022-06-23 20:20:13.309359
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('unsupported_encoding.file')
    except Exception as e:
        assert e.__str__() == "Unknown or unsupported encoding in unsupported_encoding.file"

# Generated at 2022-06-23 20:20:17.320923
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    fc = AssignmentsFormatMismatch("def a():\n\n    a = 1\n    b = 2\n        ")
    assert (fc.code == "def a():\n\n    a = 1\n    b = 2\n        ")


# Generated at 2022-06-23 20:20:22.266558
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    from expecter import expect

    class FakeFile:
        @staticmethod
        def read():
            return "hello"

    fake_file = FakeFile()
    unsupported_settings = {"hello": {"value": "hello", "source": fake_file}}

    exception = UnsupportedSettings(unsupported_settings)

    expect(exception) == UnsupportedSettings
    expect(exception.unsupported_settings) == unsupported_settings

# Generated at 2022-06-23 20:20:26.592319
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """
    >>> test_UnsupportedEncoding()
    """
    try:
        raise UnsupportedEncoding(filename="test.py")
    except UnsupportedEncoding as ex:
        assert ex.filename == "test.py"
        assert str(ex) == "Unknown or unsupported encoding in test.py"


# Generated at 2022-06-23 20:20:30.112956
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "foo"
    original_error = Exception("test")
    literal_parsing_failure = LiteralParsingFailure(code, original_error)

    assert literal_parsing_failure.code == code
    assert literal_parsing_failure.original_error == original_error

if __name__ == "__main__":
    test_LiteralParsingFailure()

# Generated at 2022-06-23 20:20:34.308708
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = "a"
    expected_kind = "tuple"
    test = LiteralSortTypeMismatch(kind, expected_kind)
    assert (isinstance(test, ISortError))
    assert (test.kind == kind)
    assert (test.expected_kind == expected_kind)

test_LiteralSortTypeMismatch()

# Generated at 2022-06-23 20:20:36.172800
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert not FileSkipComment(__file__).args
    assert FileSkipComment(__file__).file_path == __file__


# Generated at 2022-06-23 20:20:40.878612
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = '/Users/Desktop/Test.py'
    x = InvalidSettingsPath(path)
    assert str(x) == f"isort was told to use the settings_path: {path} as the base directory or file that represents the starting point of config file discovery, but it does not exist."
    assert x.settings_path == path



# Generated at 2022-06-23 20:20:43.464514
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    class_instance = IntroducedSyntaxErrors("dummy_file_path")
    assert class_instance.file_path == "dummy_file_path"

# Generated at 2022-06-23 20:20:44.419762
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    IntroducedSyntaxErrors("test")

# Generated at 2022-06-23 20:20:46.015122
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    my_profile = ProfileDoesNotExist("my profile")
    assert my_profile.profile == "my profile"

# Generated at 2022-06-23 20:20:49.561118
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert str(InvalidSettingsPath("x")) == \
    "isort was told to use the settings_path: x as the base directory or file that represents the starting point of config file discovery, but it does not exist."
    assert InvalidSettingsPath("x").settings_path == "x"


# Generated at 2022-06-23 20:20:50.696945
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    e = UnsupportedEncoding("test_file")
    assert e.filename == "test_file"

# Generated at 2022-06-23 20:20:53.280761
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "FormattingPluginDoesNotExist"
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == formatter


# Generated at 2022-06-23 20:20:54.934681
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(Exception):
        raise InvalidSettingsPath("C:/Users/user/PycharmProjects/isort/iplugin.py")

# Generated at 2022-06-23 20:20:57.474655
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment('/file/path').file_path == '/file/path'


# Generated at 2022-06-23 20:20:59.157558
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("abc") == IntroducedSyntaxErrors("abc")

# Generated at 2022-06-23 20:21:06.198521
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    msg = (
        "isort was provided settings that it doesn't support:\n\n"
        "\t- yapf_style = {some: 'settings'}  (source: 'provided')\n\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )
    assert str(
        UnsupportedSettings(unsupported_settings={"yapf_style": {"value": "{some: 'settings'}", "source": "provided"}})
    ) == msg

# Generated at 2022-06-23 20:21:08.833643
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fs = FileSkipSetting('some_path')
    assert fs.file_path == 'some_path'
    assert isinstance(fs, FileSkipped)
    assert isinstance(fs, ISortError)


# Generated at 2022-06-23 20:21:13.101530
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("abc")
    except ProfileDoesNotExist as e:
        assert e.profile == "abc"


# Generated at 2022-06-23 20:21:15.611045
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception = UnsupportedEncoding("filename")
    assert exception.filename == "filename"
    assert str(exception) == "Unknown or unsupported encoding in filename"

# Generated at 2022-06-23 20:21:16.486636
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding.__init__(UnsupportedEncoding, "filename")

# Generated at 2022-06-23 20:21:20.149108
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    exception = ExistingSyntaxErrors("test")
    assert str(exception) == "isort was told to sort imports within code that contains syntax errors: test."
    assert exception.file_path == "test"



# Generated at 2022-06-23 20:21:22.786234
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    a=InvalidSettingsPath("/path/to/file.py")
    assert a.__class__.__name__=="InvalidSettingsPath"
    assert a.settings_path=="/path/to/file.py"


# Generated at 2022-06-23 20:21:23.895785
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    err = LiteralSortTypeMismatch(tuple, list)



# Generated at 2022-06-23 20:21:27.071896
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type(10)
    expected_kind = type(10)
    ex = LiteralSortTypeMismatch(kind, expected_kind)
    assert ex.kind == kind
    assert ex.expected_kind == expected_kind

# Generated at 2022-06-23 20:21:29.543758
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind=1
    expected_kind=type(0)
    error=LiteralSortTypeMismatch(kind,expected_kind)
    assert error.kind==kind
    assert error.expected_kind==expected_kind

# Generated at 2022-06-23 20:21:33.576068
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    obj = LiteralSortTypeMismatch(list, dict)
    assert obj.kind == list
    assert obj.expected_kind == dict
    assert str(obj) == "isort was told to sort a literal of type <class 'dict'> but was given a literal of type <class 'list'>.\n"


# Generated at 2022-06-23 20:21:37.263763
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # When the function is called with a file_path
    with pytest.raises(FileSkipSetting, match="was skipped as it's listed in 'skip' setting"):
        FileSkipSetting("test")


# Generated at 2022-06-23 20:21:39.942873
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    e = IntroducedSyntaxErrors('test')
    assert e.message == 'isort introduced syntax errors when attempting to sort the imports contained within test.'

# Generated at 2022-06-23 20:21:43.455498
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "string"
    e = FileSkipSetting(file_path)
    assert isinstance(e, ISortError) is True
    assert e.file_path == file_path
    assert isinstance(e, FileSkipped) is True

# Generated at 2022-06-23 20:21:49.789693
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        'invalid_setting': {
            'value': 'i should be ignored',
            'source': 'cli'
        },
    }

    # Invalid argument (<class 'isort.errors.ISortError'>,)
    with pytest.raises(TypeError) as e:
        raise UnsupportedSettings
    assert e.value.args == ("missing required positional argument: 'unsupported_settings'",)

    # Invalid argument (<class 'isort.errors.ISortError'>, <class 'dict'>)
    with pytest.raises(TypeError) as e:
        raise UnsupportedSettings(unsupported_settings)
    assert e.value.args == ("argument 1 must be 'unsupported_settings', not 'dict'",)

    # Pass

# Generated at 2022-06-23 20:21:53.535627
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "file.py"
    try:
        raise FileSkipSetting(file_path)
    except FileSkipSetting as e:
        assert e.file_path == file_path
        assert str(e).startswith(file_path)



# Generated at 2022-06-23 20:21:56.985818
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    class_test = ProfileDoesNotExist
    error_test = class_test('test')
    assert error_test.args[0] == "Specified profile of test does not exist. Available profiles: black, pycharm, grum"


# Generated at 2022-06-23 20:21:58.374357
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(ISortError):
        IntroducedSyntaxErrors("test")

# Generated at 2022-06-23 20:22:00.406962
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist("test-profile")
    assert error.profile == "test-profile"

# Generated at 2022-06-23 20:22:01.556950
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch


# Generated at 2022-06-23 20:22:06.025361
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors("test_string")
    assert error.file_path == "test_string"
    assert str(error) == "isort introduced syntax errors when attempting to sort the imports contained within test_string."


# Generated at 2022-06-23 20:22:09.752413
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = '"Test"'
    line = 0
    column = 0
    original_error = SyntaxError()
    literal_parsing_failure = LiteralParsingFailure(code, original_error)
    assert literal_parsing_failure.code == code
    assert literal_parsing_failure.original_error == original_error


# Generated at 2022-06-23 20:22:10.925957
# Unit test for constructor of class ISortError
def test_ISortError():
	assert ISortError("small")
	assert ISortError("big")


# Generated at 2022-06-23 20:22:16.720641
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    obj = AssignmentsFormatMismatch("a = 1, b = 2")
    assert obj.code == "a = 1, b = 2"
    assert (
        str(obj) == "isort was told to sort a section of assignments, however the given code:\n\n"
        "a = 1, b = 2\n\n"
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
    )



# Generated at 2022-06-23 20:22:23.500383
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    mm = "isort was told to sort a section of assignments, however the given code:\n\n" \
         "if __name__ == '__main__':\n" \
         "    print('Hello World')\n\n" \
         "Does not match isort's strict single line formatting requirement for" \
         " assignment sorting:\n\n" \
         "{variable_name} = {value}\n" \
         "{variable_name2} = {value2}\n" \
         "...\n\n"
    mm_isort = AssignmentsFormatMismatch("if __name__ == '__main__':\n"
                                         "    print('Hello World')\n")
    assert mm == mm_isort.__str__()

# Generated at 2022-06-23 20:22:30.054088
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = """
    a = b
    c = d
    """
    e = AssignmentsFormatMismatch(code)
    correct_msg = """isort was told to sort a section of assignments, however the given code:
    
    a = b
    c = d
    
    Does not match isort's strict single line formatting requirement for assignment sorting:
    
    {variable_name} = {value}
    {variable_name2} = {value2}
    ...
    
    """
    assert e.code == code
    assert e.__str__() == correct_msg

# Generated at 2022-06-23 20:22:31.737711
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'C:\\Users\\rajpa\\OneDrive\\Documents\\Test\\a.txt'
    obj = FileSkipSetting(file_path)
    assert obj.file_path == file_path

# Generated at 2022-06-23 20:22:33.371615
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    a = InvalidSettingsPath("something")
    assert a.settings_path == "something"
