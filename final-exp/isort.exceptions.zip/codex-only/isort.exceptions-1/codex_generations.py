

# Generated at 2022-06-23 20:12:26.575851
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class MyException(Exception):
        pass

    exception = LiteralParsingFailure('test_code', MyException('test_error'))
    assert exception.code == 'test_code'
    assert exception.original_error == MyException('test_error')


# Generated at 2022-06-23 20:12:32.655061
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    """Unit test for class FileSkipSetting"""
    try:
        raise FileSkipSetting("this")
    except FileSkipSetting as exception:
        assert str(exception) == "this was skipped as it's listed in 'skip' setting" \
                                 " or matches a glob in 'skip_glob' setting"
        assert exception.file_path == "this"

# Generated at 2022-06-23 20:12:36.628676
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type(1.0)
    expected_kind = type(1)
    try:
        raise LiteralSortTypeMismatch(kind, expected_kind)
    except LiteralSortTypeMismatch as error:
        assert error.kind == kind
        assert error.expected_kind == expected_kind



# Generated at 2022-06-23 20:12:46.974146
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("abc")
    except ProfileDoesNotExist as e:
        # tests if isort has indeed raised ProfileDoesNotExist
        assert str(e) == "Specified profile of abc does not exist. Available profiles: black,vulture,google,yapf,pyupgrade,mypy,pylint,pep8,pycodestyle,pyflakes,flake8,pydocstyle,bandit,flake8-bandit,flake8-import-order,flake8-bugbear,hacking."
        # tests if isort has indeed raised ProfileDoesNotExist with "abc"
        assert e.profile == "abc"
        return None
    raise AssertionError("test_ProfileDoesNotExist() failed")


# Generated at 2022-06-23 20:12:52.163172
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    exc = ProfileDoesNotExist("xyz")
    assert exc.profile == "xyz"
    assert exc.__str__() == "Specified profile of xyz does not exist. " \
                            "Available profiles: black, pycodestyle, google, pep8, " \
                            "pyupgrade, hacking, mypy, cpp, boost, clang, openframeworks, " \
                            "qt, tidelift."

# Generated at 2022-06-23 20:12:56.756398
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = UnsupportedSettings({'name': {'value': 1, 'source': 'config'}})
    assert unsupported_settings.unsupported_settings == {'name': {'value': 1, 'source': 'config'}}



# Generated at 2022-06-23 20:12:58.982929
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    a = FileSkipped("FileSkipped", "test.py")
    assert a.message == "FileSkipped"
    assert a.file_path == "test.py"

# Generated at 2022-06-23 20:13:01.586790
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist('formatter').formatter == 'formatter'

# Generated at 2022-06-23 20:13:04.324827
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    test_obj = FileSkipSetting("test_file.txt")
    assert isinstance(test_obj, FileSkipped)


# Generated at 2022-06-23 20:13:10.965281
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # Arrange
    import_module = "os"
    section = "sys"
    
    # Act
    message = MissingSection(import_module, section)

    # Assert
    assert message == "Found os import while parsing, but sys was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:13:16.190653
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    import random
    import string
    def genString(stringLength=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(stringLength))
    filename = genString()
    error = ExistingSyntaxErrors(filename)
    assert filename == error.file_path

# Generated at 2022-06-23 20:13:20.867976
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    import unittest

    class UnsupportedEncodingTestCase(unittest.TestCase):
        def test_unsupported_encoding_constructor(self):
            filename = "hello.py"
            exception: UnsupportedEncoding = UnsupportedEncoding(filename)
            assert exception.args[0] == f"Unknown or unsupported encoding in {filename}"

    unittest.main()

# Generated at 2022-06-23 20:13:26.768317
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "{variable_name} = {value}\n"
    assert str(AssignmentsFormatMismatch(code)) == (
        "isort was told to sort a section of assignments, however the given code:\n\n"
        f"{code}\n\n"
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
    )

# Generated at 2022-06-23 20:13:28.401365
# Unit test for constructor of class MissingSection
def test_MissingSection():
    val = 'test_module'
    section = 'OTHER_SECTION'
    MissingSection(val, section)

# Generated at 2022-06-23 20:13:33.525575
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path = "./isort/tests/sample_py/invalid_settings/"
    invalid_settings_path = InvalidSettingsPath(settings_path)
    assert invalid_settings_path.settings_path == settings_path, "Settings path is wrong"


# Generated at 2022-06-23 20:13:35.743381
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('test')
    except ISortError as err:
        assert err.args[0] == 'test'

# Generated at 2022-06-23 20:13:39.326109
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class_object = LiteralParsingFailure("code", "original_error")
    assert class_object.code == "code", "Attribute code not created and set"
    assert class_object.original_error == "original_error", "Attribute original_error not created and set"


# Generated at 2022-06-23 20:13:42.974416
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    class UnsupportedEncoding(ISortError):
        """Raised when isort encounters an encoding error while trying to read a file"""

        def __init__(self, *args, **kwargs):
            pass

    assert (True, True) == (True, True)

# Generated at 2022-06-23 20:13:46.607816
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "(1,2,3)"
    original_error = Exception("Invalid syntax")
    raise LiteralParsingFailure(code=code, original_error=original_error)

# Generated at 2022-06-23 20:13:48.453359
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist(profile = "test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-23 20:13:53.372252
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise SyntaxError("foo")
    except SyntaxError as e:
        error = LiteralParsingFailure("a = 1", e)
        assert error.args == (
            "isort failed to parse the given literal a = 1. It's important to note "
            "that isort literal sorting only supports simple literals parsable by "
            "ast.literal_eval which gave the exception of foo.",
        )



# Generated at 2022-06-23 20:13:56.407458
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    # define test data
    code = ["test"]  # type: str
    original_error = Exception("test")  # type: Exception
    expected_error = LiteralParsingFailure(code, original_error)
    print(expected_error)

# Generated at 2022-06-23 20:13:59.183252
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
   try:
       raise LiteralParsingFailure('code','original_error')
   except LiteralParsingFailure as error:
       assert error.code == 'code'
       assert error.original_error == 'original_error'
       print('Test passed')


# Generated at 2022-06-23 20:14:01.823171
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    name = "test.py"
    try:
        raise UnsupportedEncoding(name)
    except UnsupportedEncoding as e:
        if name in str(e):
            return True
        else:
            return False

# Generated at 2022-06-23 20:14:07.632978
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    error = InvalidSettingsPath("/path")
    assert error.settings_path == "/path"
    assert str(error) == "isort was told to use the settings_path: /path as the base directory or " \
                         "file that represents the starting point of config file discovery, but it " \
                         "does not exist."

# Generated at 2022-06-23 20:14:10.887699
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("This is a test")
    except ISortError as e:
        assert str(e) == "This is a test"



# Generated at 2022-06-23 20:14:15.837434
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = type(1)
    expected_kind = type("a")
    error = LiteralSortTypeMismatch(kind, expected_kind)
    assert error.kind == kind
    assert error.expected_kind == expected_kind
    assert str(error) == (
        "isort was told to sort a literal of type <class 'str'> "
        "but was given a literal of type <class 'int'>."
    )
    assert repr(error) == (
        "LiteralSortTypeMismatch(kind=<class 'int'>, "
        "expected_kind=<class 'str'>)"
    )

# Generated at 2022-06-23 20:14:21.330155
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    """
    Method to test the constructor of FormattingPluginDoesNotExist class
    """

    err = FormattingPluginDoesNotExist("formatter")
    assert err.formatter == "formatter"

# Generated at 2022-06-23 20:14:23.725353
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    test_file_path = "test_file_path"
    assert FileSkipComment(test_file_path).file_path == test_file_path

# Generated at 2022-06-23 20:14:30.556674
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class TestClass(ISortError):
        def __init__(self, x, y):
            super().__init__(f"{x} {y}")
            self.x = x
            self.y = y
        
    a = TestClass("Hello", "World")
    print(a.__doc__)
    print(a.x, a.y)
    print(a)


# Generated at 2022-06-23 20:14:32.486748
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist('xyz')

# Generated at 2022-06-23 20:14:40.623479
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("{a, b} = [1, 2]\n{a1, b1} = [3, 4]")
    except AssignmentsFormatMismatch as e:
        assert e.code == "{a, b} = [1, 2]\n{a1, b1} = [3, 4]"

    try:
        raise AssignmentsFormatMismatch("{a, b} = [1, 2]\n{c, d} = [3, 4]")
    except AssignmentsFormatMismatch as e:
        assert e.code == "{a, b} = [1, 2]\n{c, d} = [3, 4]"

# Generated at 2022-06-23 20:14:44.391153
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert UnsupportedSettings({'setting': 'setting_info'}) == {'setting': 'setting_info'}
    assert UnsupportedSettings({'setting': 'setting_info'}) != {'other_setting': 'other_setting_info'}

# Generated at 2022-06-23 20:14:44.917836
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert True

# Generated at 2022-06-23 20:14:48.760328
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    test_path = 'test_file_path'
    test_err = ExistingSyntaxErrors(test_path)
    assert test_err.file_path == test_path
    assert str(test_err) == 'isort was told to sort imports within code that contains syntax errors: ' + test_path + '.'


# Generated at 2022-06-23 20:14:50.516919
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding("filename")
    assert isinstance(error, ISortError)
    assert error.filename == "filename"
    assert str(error) == "Unknown or unsupported encoding in filename"

# Generated at 2022-06-23 20:14:53.609807
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert (
        str(LiteralSortTypeMismatch(kind=list, expected_kind=set))
        == "isort was told to sort a literal of type <class 'set'> but was given "
        "a literal of type <class 'list'>.\n"
    )

# Generated at 2022-06-23 20:14:55.234468
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist("abc")
    assert FormattingPluginDoesNotExist("abc").formatter == "abc"
    assert FormattingPluginDoesNotExist("abc").args == ("abc",)

# Generated at 2022-06-23 20:14:57.946877
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('hello world')
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == 'hello world'
        assert str(e) == 'Specified formatting plugin of hello world does not exist. '
        assert repr(e) == 'Specified formatting plugin of hello world does not exist. '



# Generated at 2022-06-23 20:15:00.706449
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    """Unit test to check constructor of class ExistingSyntaxErrors"""
    obj = ExistingSyntaxErrors('sample.py')
    assert obj.file_path == 'sample.py'

# Generated at 2022-06-23 20:15:05.199499
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    # Arrange
    formatter = "import_order_style"
    error = FormattingPluginDoesNotExist(formatter)

    # Act
    message = error.args[0]

    # Assert
    expected_message = "Specified formatting plugin of import_order_style does not exist. "
    assert message == expected_message

# Generated at 2022-06-23 20:15:07.944859
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fileskipped = FileSkipped("message", "filepath")
    assert fileskipped.message == "message"
    assert fileskipped.file_path == "filepath"



# Generated at 2022-06-23 20:15:10.039952
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    exception = FileSkipped("Test", "File")
    assert exception.message == "Test"
    assert exception.file_path == "File"

# Generated at 2022-06-23 20:15:11.956054
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Create object
    err = ProfileDoesNotExist("test")

    # Check that object is created
    assert err



# Generated at 2022-06-23 20:15:14.375918
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    err = ExistingSyntaxErrors("a_file_path")
    assert isinstance(err, ISortError)
    assert err.file_path == "a_file_path"



# Generated at 2022-06-23 20:15:18.321378
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"



# Generated at 2022-06-23 20:15:24.462771
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise SyntaxError
    except SyntaxError as e:
        try:
            raise LiteralParsingFailure('test', e)
        except LiteralParsingFailure as f:
            assert str(f) == """isort failed to parse the given literal test. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of <class 'SyntaxError'>."""

# Generated at 2022-06-23 20:15:26.089041
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    test0 = AssignmentsFormatMismatch("code")
    assert test0.code == "code"

# Generated at 2022-06-23 20:15:32.420706
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test_file.py")
    except IntroducedSyntaxErrors as e:
        assert (
            str(e)
            == "isort introduced syntax errors when attempting to sort the imports contained within test_file.py."
        )
        assert e.file_path == "test_file.py"

# Generated at 2022-06-23 20:15:36.227631
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting.__doc__ == "Raised when an entire file is skipped due to provided isort settings"
    assert FileSkipSetting("asd").message == "asd was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:15:39.148627
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('test_header.txt')
    except UnsupportedEncoding as error:
        assert error.filename == 'test_header.txt'

# Generated at 2022-06-23 20:15:41.779600
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("abc.py")
    except UnsupportedEncoding as e:
        assert e.filename == "abc.py"
    else:
        assert False



# Generated at 2022-06-23 20:15:43.789175
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("Test")
    except Exception as e:
        assert e.formatter == "Test"


# Generated at 2022-06-23 20:15:47.741509
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    under_test = LiteralParsingFailure( 'code', Exception('exception_message'))
    assert under_test.original_error == Exception('exception_message')
    assert under_test.code == 'code'

# Generated at 2022-06-23 20:15:49.401284
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(Exception, dict).__init__(Exception, dict)

# Generated at 2022-06-23 20:15:59.005137
# Unit test for constructor of class AssignmentsFormatMismatch

# Generated at 2022-06-23 20:16:02.480298
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("A")
    except ISortError as e:
        assert e.args[0] == "A"

# Generated at 2022-06-23 20:16:04.329257
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        x = 4 / 0
    except Exception:
        LiteralParsingFailure("code","error")

# Generated at 2022-06-23 20:16:07.621429
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'spam'
    section = 'import_section'
    ms = MissingSection(import_module, section)
    assert import_module in ms.args[0]
    assert section in ms.args[0]


# Generated at 2022-06-23 20:16:09.546027
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "test = None"
    e = AssignmentsFormatMismatch(code)
    assert e.code == code


# Generated at 2022-06-23 20:16:13.858547
# Unit test for constructor of class MissingSection
def test_MissingSection():
    """junit test"""
    import_module = "import_module"
    section = "section"
    ms = MissingSection(import_module, section)

    assert ms.args[0] == f"Found {import_module} import while parsing, but {section} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:16:15.213153
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "./isort/"
    print(FileSkipSetting(file_path))

if __name__ == "__main__":
    test_FileSkipSetting()

# Generated at 2022-06-23 20:16:18.968521
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("~/foo/bar.py", "BAR")
    except MissingSection as e:
        assert e.import_module == "~/foo/bar.py"
        assert e.section == "BAR"



# Generated at 2022-06-23 20:16:22.880812
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest.raises(AssignmentsFormatMismatch) as e:
        code = 'a, b, c = [1, 2, 3]'
        raise AssignmentsFormatMismatch(code)
    assert e.value.code == code


# Generated at 2022-06-23 20:16:26.736607
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    error = FileSkipComment("test.py")
    # test for exception type
    assert isinstance(error, FileSkipped)
    # test for values of private fields
    assert error.file_path == "test.py"


# Generated at 2022-06-23 20:16:33.939226
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ExistingSyntaxErrors as e:
        assert e.message == "isort was told to sort imports within code that contains syntax errors: test."
        assert str(e) == e.message
        assert e.file_path == "test"
        assert e.args[0] == e.message

# Generated at 2022-06-23 20:16:36.179034
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = {"test": "test"}

    try:
        raise LiteralParsingFailure(code, Exception())
    except LiteralParsingFailure as e:
        assert e.code == code
        assert e.original_error

# Generated at 2022-06-23 20:16:38.018596
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath(settings_path='path/to/settings.cfg')
    except InvalidSettingsPath as e:
        assert e.settings_path == 'path/to/settings.cfg'


# Generated at 2022-06-23 20:16:39.155431
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    print(FormattingPluginDoesNotExist.__init__.__code__)


# Generated at 2022-06-23 20:16:41.622303
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist) as e:
        raise ProfileDoesNotExist("abc")
    assert e.value.profile == "abc"

# Generated at 2022-06-23 20:16:42.999708
# Unit test for constructor of class MissingSection
def test_MissingSection():
    instance = MissingSection("import_module", "section")
    assert instance.import_module == "import_module"



# Generated at 2022-06-23 20:16:45.283107
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    raise ExistingSyntaxErrors("bad_file.py")


# Generated at 2022-06-23 20:16:50.142887
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {"unknown_setting": "value"}

# Generated at 2022-06-23 20:16:55.797719
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('collections.abc', 'LOCALFOLDER')
    except MissingSection as err:
        assert str(err) == 'Found collections.abc import while parsing, but LOCALFOLDER was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.' # noqa

# Generated at 2022-06-23 20:17:00.068419
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Should raise an exception
    with pytest.raises(ISortError):
        raise LiteralSortTypeMismatch(kind=1, expected_kind=str)


# Generated at 2022-06-23 20:17:02.797577
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = FormattingPluginDoesNotExist('myformatter')
    assert str(formatter).startswith('Specified formatting plugin of myformatter does not exist')

# Generated at 2022-06-23 20:17:06.454425
# Unit test for constructor of class MissingSection
def test_MissingSection():
    with pytest.raises(MissingSection) as error:
        raise MissingSection('boto3', 'THIRDPARTY')

    assert error.value.import_module == 'boto3'
    assert error.value.section == 'THIRDPARTY'

# Generated at 2022-06-23 20:17:08.663401
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    message = 'hello world'
    file_path = '/some/file/path'
    obj = FileSkipSetting(file_path)
    assert obj.file_path == file_path

# Generated at 2022-06-23 20:17:11.088313
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    msg = "isort was told to sort imports within code that contains syntax errors: /a/b/c."
    err = ExistingSyntaxErrors("/a/b/c")
    assert err.message == msg
    assert err.file_path == "/a/b/c"

# Generated at 2022-06-23 20:17:13.172526
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("1.py")
    except FileSkipComment as e:
        assert e.file_path == "1.py"


# Generated at 2022-06-23 20:17:24.087321
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(
            "abcd = 1234, dcba = 4321 # {assignments}\n"
        )
    except AssignmentsFormatMismatch as e:
        assert (
            str(e) == "isort was told to sort a section of assignments, however the given code:\n\nabcd = 1234, dcba = 4321 # {assignments}\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"
        )
        assert (
            e.code == "abcd = 1234, dcba = 4321 # {assignments}\n"
        )

# Generated at 2022-06-23 20:17:30.400918
# Unit test for constructor of class MissingSection
def test_MissingSection():
    from isort.settings import Config

    assert (
        MissingSection("foo", "bar").message
        == "Found foo import while parsing, but bar was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
    )

    custom_config = Config(sections=["foo"], add_imports=[("bar", "bar")])
    assert (
        MissingSection("bar", "foo").message
        == "Found bar import while parsing, but foo was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
    )

# Generated at 2022-06-23 20:17:35.212820
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test_file.py")
    except IntroducedSyntaxErrors as error:
        assert error.file_path == "test_file.py"
        assert str(error) == "isort introduced syntax errors when attempting to sort the imports contained within test_file.py."
    else:
        assert False

# Generated at 2022-06-23 20:17:37.236573
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("Skipped", "ABC/abc.py")
        assert False
    except FileSkipped as e:
        assert e.message == "Skipped"
        assert e.file_path == "ABC/abc.py"



# Generated at 2022-06-23 20:17:39.751081
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = FormattingPluginDoesNotExist('isort')

# Generated at 2022-06-23 20:17:42.482898
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception = UnsupportedEncoding("testfile.py")
    assert str(exception) == "Unknown or unsupported encoding in testfile.py"

# Generated at 2022-06-23 20:17:44.821876
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    exc = ProfileDoesNotExist("lily")
    print(exc)
    assert exc.profile == "lily"


# Generated at 2022-06-23 20:17:49.403739
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    s = "Unsupported Encoding"
    ue = UnsupportedEncoding(s)
    assert ue.filename is s

# Generated at 2022-06-23 20:17:51.856382
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    Err = ExistingSyntaxErrors('./example/settings.py')
    assert (Err.file_path) == './example/settings.py'


# Generated at 2022-06-23 20:17:53.194884
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors('test_file_path').file_path == 'test_file_path'

# Generated at 2022-06-23 20:17:57.356710
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    my_exception = IntroducedSyntaxErrors(file_path="my_path")
    assert str(my_exception) == "isort introduced syntax errors when attempting to sort the imports contained within my_path."
    assert my_exception.file_path == "my_path"


# Generated at 2022-06-23 20:18:02.998952
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    def create():
        raise FileSkipComment("FileA.py")
    longMessage = False
    try:
        create()
    except FileSkipComment as e:
        assert e.file_path == "FileA.py"
        assert e.message == "FileA.py contains an file skip comment and was skipped."
        assert "FileA.py contains an file skip comment and was skipped." in str(e)
        assert not longMessage
    else:
        assert False, "Expected exception"

# Generated at 2022-06-23 20:18:06.107603
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ExistingSyntaxErrors as err:
        assert "test" in err.__str__()

# Generated at 2022-06-23 20:18:10.623029
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    invalid_config = {
        'bad_var': {'value': 'bad', 'source': 'very bad'}
    }
    try:
        raise UnsupportedSettings(invalid_config)
    except UnsupportedSettings as e:
        assert e.args[0] == "isort was provided settings that it doesn't support:\n\n" \
                "\t- bad_var = bad  (source: 'very bad')\n\n" \
                "For a complete and up-to-date listing of supported settings see: " \
                "https://pycqa.github.io/isort/docs/configuration/options/.\n"
        assert e.unsupported_settings == invalid_config


# Generated at 2022-06-23 20:18:18.358699
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"force_single_line": {"source": "config", "value": True}}
    exception = UnsupportedSettings(unsupported_settings)
    expected_errors_message = """isort was provided settings that it doesn't support:
	- force_single_line = True  (source: 'config')

For a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"""
    assert expected_errors_message == exception.__str__()

# Generated at 2022-06-23 20:18:20.585031
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors(file_path="testing")
    except ExistingSyntaxErrors as error:
        assert error.file_path == "testing"


# Generated at 2022-06-23 20:18:21.960864
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath):
        raise InvalidSettingsPath("test")



# Generated at 2022-06-23 20:18:26.283553
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = """
    a = t.Bar()
    b = t.Bar()
    """

    with pytest.raises(AssignmentsFormatMismatch) as excinfo:
        raise AssignmentsFormatMismatch(code)
    assert excinfo.value.code == code

# Generated at 2022-06-23 20:18:28.781722
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # create new object of class LiteralSortTypeMismatch
    test = LiteralSortTypeMismatch(kind=type(1), expected_kind=type(1))
    # test the values to check if they equal
    assert test.kind == type(1)
    assert test.expected_kind == type(1)

# Generated at 2022-06-23 20:18:31.720055
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist) as exc:
        raise ProfileDoesNotExist('hello')
    assert exc.value.profile == 'hello'

# Generated at 2022-06-23 20:18:35.187685
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("test.py")
    except FileSkipped as e:
        assert "was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting" in str(e)
        assert "test.py" in str(e)


# Generated at 2022-06-23 20:18:39.373973
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "indent": {"value": 4, "source": "arguments"},
        "wrap_length": {"value": 1000, "source": "arguments"},
    }
    assert UnsupportedSettings(unsupported_settings).unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:18:42.305028
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    skip = FileSkipped("test_message", "test_path")
    assert skip.message == "test_message"
    assert skip.file_path == "test_path"

# Generated at 2022-06-23 20:18:46.626952
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        'option1': {
            'value': "foo",
            'source': "bar",
        },
        'option2': {
            'value': "foo",
            'source': "bar",
        },
    }
    test_case = UnsupportedSettings(unsupported_settings)
    assert test_case.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:18:48.747196
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    fsc = FileSkipComment("fileskipcomment.py")
    assert fsc.file_path == "fileskipcomment.py"
    assert fsc.message == "fileskipcomment.py contains an file skip comment and was skipped."

# Generated at 2022-06-23 20:18:53.934575
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('foo', 'bar').args == (
        "Found foo import while parsing, but bar was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info.",
    )

# Generated at 2022-06-23 20:18:55.263718
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    # import isort.Main
    assert FormattingPluginDoesNotExist("test")
    assert FormattingPluginDoesNotExist.formatter == "test"

# Generated at 2022-06-23 20:18:57.085739
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors('test')
    assert error.file_path == 'test'

# Generated at 2022-06-23 20:19:05.752276
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('math', 'STDLIB')
    except MissingSection as e:
        assert 'Found math import while parsing, but STDLIB was not included in the ' \
               '`sections` setting of your config. Please add it before continuing\n' \
               'See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.' == str(e)
        assert 'math' == e.import_module
        assert 'STDLIB' == e.section

# Generated at 2022-06-23 20:19:06.829239
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    a = ExistingSyntaxErrors('/foo/bar')
    assert a.file_path == '/foo/bar'

# Generated at 2022-06-23 20:19:11.232679
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("x = 1, y = 2")
    except AssignmentsFormatMismatch as exc:
        assert exc.code == "x = 1, y = 2"
        assert str(exc) == (
            "isort was told to sort a section of assignments, however the given code:\n\n"
            "x = 1, y = 2\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n"
        )

# Generated at 2022-06-23 20:19:16.559061
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "json"
    try:
        raise FormattingPluginDoesNotExist(f"Specified formatting plugin of {formatter} does not exist. ")
    except:
        assert True

    formatter = "yaml"
    try:
        raise FormattingPluginDoesNotExist(f"Specified formatting plugin of {formatter} does not exist. ")
    except:
        assert True



# Generated at 2022-06-23 20:19:19.139030
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("/Users/user/Desktop/file.py")
    except FileSkipComment as e:
        assert e.file_path == "/Users/user/Desktop/file.py"

# Generated at 2022-06-23 20:19:21.883322
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert e.filename == "test.py"
        assert str(e) == "Unknown or unsupported encoding in test.py"


# Generated at 2022-06-23 20:19:23.694561
# Unit test for constructor of class ISortError
def test_ISortError():
    # test ISortError
    try:
        raise ISortError()
    except ISortError as err:
        print(err.args)


# Generated at 2022-06-23 20:19:26.971244
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = "something"
    message = "some message"
    err = FileSkipped(message, file_path)
    assert issubclass(type(err), ISortError)
    assert err.file_path == file_path
    assert str(err) == message


# Generated at 2022-06-23 20:19:28.712142
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("Invalid file")
    except ExistingSyntaxErrors as err:
        assert err.file_path == "Invalid file"


# Generated at 2022-06-23 20:19:34.126287
# Unit test for constructor of class ISortError
def test_ISortError():
    print("ISortError: " + str(ISortError))
    print("ISortError: " + ISortError.__doc__)
    print("InvalidSettingsPath: " + InvalidSettingsPath.__doc__)
    print("ExistingSyntaxErrors: " + ExistingSyntaxErrors.__doc__)
    print("IntroducedSyntaxErrors: " + IntroducedSyntaxErrors.__doc__)
    print("FileSkipComment: " + FileSkipComment.__doc__)
    print("FileSkipSetting: " + FileSkipSetting.__doc__)
    print("ProfileDoesNotExist: " + ProfileDoesNotExist.__doc__)
    print("FormattingPluginDoesNotExist: " + FormattingPluginDoesNotExist.__doc__)

# Generated at 2022-06-23 20:19:37.076839
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        'bad_setting': {
            'value': 'bad',
            'source': 'runtime',
        }
    }
    UnsupportedSettings(unsupported_settings)

# Generated at 2022-06-23 20:19:41.260123
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    object = FileSkipped("Skipped", r"C:\Users\jeste_000\isort\isort\__init__.py")
    print(object)
    print(FileSkipped.__init__(object, "Skipped", r"C:\Users\jeste_000\isort\isort\__init__.py"))


# Generated at 2022-06-23 20:19:46.690482
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    fpath = "filepath"
    ese = ExistingSyntaxErrors(fpath)
    assert ExistingSyntaxErrors.__str__(ese) == f"isort was told to sort imports within code that contains syntax errors: {fpath}."


# Generated at 2022-06-23 20:19:49.392455
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as exc_info:
        raise ExistingSyntaxErrors('file.py')

    assert exc_info.value.file_path == 'file.py'


# Generated at 2022-06-23 20:19:52.687835
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "unittest"
    section = "THIRDPARTY"
    try:
        raise MissingSection(import_module=import_module, section=section)
    except MissingSection as e:
        assert e.import_module == import_module
        assert e.section == section

# Generated at 2022-06-23 20:19:55.595294
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('test')
    except ProfileDoesNotExist as e:
        assert e.profile == 'test'
        assert e.args[0] == 'Specified profile of test does not exist. Available profiles: black,test,pep8_based,gofmt,zen.'

# Generated at 2022-06-23 20:19:57.670191
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    exc = LiteralSortTypeMismatch(None, None)
    assert exc.kind is None
    assert exc.expected_kind is None

# Generated at 2022-06-23 20:19:59.615001
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    text = "a = 2, b = 2"
    exception = AssignmentsFormatMismatch(text)
    assert exception is not None
    assert text in str(exception)

# Generated at 2022-06-23 20:20:03.048659
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors("").__str__() == "isort was told to sort imports within code that contains syntax errors: ."
    assert ExistingSyntaxErrors("filea.txt").__str__() == "isort was told to sort imports within code that contains syntax errors: filea.txt."

# Generated at 2022-06-23 20:20:03.851945
# Unit test for constructor of class ISortError
def test_ISortError():
    a = ISortError()
    assert a is not None

# Generated at 2022-06-23 20:20:07.842821
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    f = FileSkipComment("test")
    assert f.args[0] == "test contains an file skip comment and was skipped."
    assert f.file_path == "test"

# Generated at 2022-06-23 20:20:15.318031
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("module", "section")
    except MissingSection as e:
        assert e.import_module == 'module'
        assert e.section == 'section'
        assert 'section was not included in the `sections` setting of your config' in str(e)
        assert 'See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.' in str(e)
    else:
        assert False, 'Should have raised MissingSection'

# Generated at 2022-06-23 20:20:22.919330
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    invalid_settings_path = InvalidSettingsPath("test_path")

    # The following code is responsible for the error message of this type of exception, and it
    # should not be changed.
    assert str(invalid_settings_path) == "isort was told to use the settings_path: test_path as " \
                                        "the base directory or file that represents the starting " \
                                        "point of config file discovery, but it does not exist."
    # The following code is responsible for the attribute of this type of exception, and it
    # should not be changed.
    assert invalid_settings_path.settings_path == "test_path"



# Generated at 2022-06-23 20:20:30.144280
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    class My_Exception(Exception):
        def __init__(self, file_path: str):
            super().__iniit__(f"in {file_path} file, sytax error")
            self.file_path=file_path
    try:
        raise My_Exception("test file")
    except My_Exception:
        print("This is error from ExistingSyntaxError")
        return 1
    finally:
        print("This is not error from ExistingSyntaxError")
        return 0

if __name__ == "__main__":
    test_ExistingSyntaxErrors()

# Generated at 2022-06-23 20:20:31.414374
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors('filepath').file_path == 'filepath'

# Generated at 2022-06-23 20:20:33.683587
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    with pytest.raises(FileSkipSetting) as excinfo:
        raise FileSkipSetting("test_filename")



# Generated at 2022-06-23 20:20:34.851073
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    t = LiteralSortTypeMismatch(3, 3)

# Generated at 2022-06-23 20:20:37.865412
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as err:
        assert f"Specified profile of test does not exist. Available profiles: {','.join(profiles)}." == err.__str__()

# Generated at 2022-06-23 20:20:40.731684
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    err = AssignmentsFormatMismatch("a = 1, b = 2\n")
    assert(err.code == "a = 1, b = 2\n")

# Generated at 2022-06-23 20:20:41.765581
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("filename").filename == "filename"

# Generated at 2022-06-23 20:20:43.177890
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("foo", "bar").file_path == "bar"

# Generated at 2022-06-23 20:20:44.854920
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors("abc").file_path == "abc"


# Generated at 2022-06-23 20:20:48.110548
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "test message"
    file_path = "test/file.py"

    test_class = FileSkipped(message, file_path)

    assert(test_class.message == message)
    assert(test_class.file_path == file_path)

# Generated at 2022-06-23 20:20:51.607052
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """Tests the UnsupportedEncoding exception class constructor to ensure it raises the
    correct error messages.
    """
    filename = "test_file.txt"
    try:
        raise UnsupportedEncoding(filename)
    except UnsupportedEncoding as e:
        assert e.args[0] == f"Unknown or unsupported encoding in {filename}"

# Generated at 2022-06-23 20:20:54.681353
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except ISortError as e:
        print('Test ISortError passed!')

# Generated at 2022-06-23 20:20:59.862835
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors('test_file.py')
    except ExistingSyntaxErrors as error:
        assert error.file_path == 'test_file.py'
    except Exception as error:
        print('Unexpected exception raised', error)
        raise error
    else:
        print('Expected exception not raised')
        assert False


# Generated at 2022-06-23 20:21:04.294060
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "['a', 'b']"
    original_error = Exception("ERROR")
    exception = LiteralParsingFailure(code, original_error)
    assert (
        exception.__str__()
        == f"isort failed to parse the given literal {code}. It's important to note "
        "that isort literal sorting only supports simple literals parsable by "
        f"ast.literal_eval which gave the exception of {original_error}."
    )



# Generated at 2022-06-23 20:21:05.575465
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    x = AssignmentsFormatMismatch("{variable1} = {value1}\n")
    assert x.code == "{variable1} = {value1}\n"


# Generated at 2022-06-23 20:21:06.223620
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    raise LiteralParsingFailure("code", IOError())

# Generated at 2022-06-23 20:21:07.800027
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    with pytest.raises(ISortError):
        raise LiteralParsingFailure('ab', SyntaxError('...'))


# Generated at 2022-06-23 20:21:20.621023
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    exception = ProfileDoesNotExist("lalala")

# Generated at 2022-06-23 20:21:23.619570
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('test_ISortError')
    except ISortError as e:
        assert str(e) == 'test_ISortError'



# Generated at 2022-06-23 20:21:26.099501
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped('message','filepath').file_path=='filepath'
    assert FileSkipped('message','filepath').message=='message'


# Generated at 2022-06-23 20:21:29.010605
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "from_first": {"value": 100, "source": "runtime"},
        "use_parentheses": {"value": True, "source": "from_isort_cfg"},
    }
    UnsupportedSettings(unsupported_settings)

# Generated at 2022-06-23 20:21:32.771406
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    message = "Specified formatting plugin of bad_formatter_name does not exist. "
    err = FormattingPluginDoesNotExist("bad_formatter_name")
    assert err.formatter == "bad_formatter_name"
    assert str(err) == message

# Generated at 2022-06-23 20:21:38.913982
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "Foo = bar"
    original_error = Exception("Foo")
    lpf = LiteralParsingFailure(code, original_error)
    assert lpf.code == code
    # Can't assert identical objects, so just making sure it's the same class
    assert type(lpf.original_error) == type(original_error)


# Generated at 2022-06-23 20:21:41.997698
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("Input Message", "Input Path")
    except FileSkipped as e:
        assert e.args[0] == "Input Message"
        assert e.file_path == "Input Path"

# Generated at 2022-06-23 20:21:48.870988
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section_exception = MissingSection('import_module', 'section')
    assert missing_section_exception.import_module == 'import_module'
    assert missing_section_exception.section == 'section'
    assert missing_section_exception.args[0] == \
        'Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'

# Generated at 2022-06-23 20:21:54.242599
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except Exception as e:
        assert str(e) == (
            "Specified profile of test does not exist. "
            "Available profiles: black, pep8, google, pyvirtuso. Top of file isort, section [settings] "
            "pyvirtuso, black, pep8, google."
        )
    return True


# Generated at 2022-06-23 20:21:57.368781
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    literal_sort = LiteralSortTypeMismatch(kind = int, expected_kind = set)
    assert literal_sort.kind == int
    assert literal_sort.expected_kind == set
    

# Generated at 2022-06-23 20:22:00.131213
# Unit test for constructor of class MissingSection
def test_MissingSection():
    my_obj = MissingSection("import_module", "section")
    assert my_obj.import_module == "import_module"
    assert my_obj.section == "section"

# Generated at 2022-06-23 20:22:01.839048
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('a')
    except IntroducedSyntaxErrors as e:
        assert(e.file_path=='a')


# Generated at 2022-06-23 20:22:07.225728
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("module name", "section name")
    except ISortError as e:
        assert e.args[0] == "Found module name import while parsing, but section name was not included " \
                            "in the `sections` setting of your config. Please add it before continuing\n" \
                            "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                            "for more info."



# Generated at 2022-06-23 20:22:10.213946
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped = FileSkipped('Unknown reason for skipping', 'test_skip.py')
    assert str(file_skipped) == "Unknown reason for skipping"
    assert file_skipped.file_path == 'test_skip.py'


# Generated at 2022-06-23 20:22:12.918123
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    instance = LiteralSortTypeMismatch(int, str)
    assert isinstance(instance, LiteralSortTypeMismatch)
    assert instance.kind == int
    assert instance.expected_kind == str
    
    

# Generated at 2022-06-23 20:22:16.608741
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert LiteralParsingFailure('Literal', ValueError('error')).code == 'Literal'
    assert LiteralParsingFailure('Literal', ValueError('error')).original_error == ValueError('error')

# Generated at 2022-06-23 20:22:21.539794
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "/home/uyu/projects/isort-examples/python/__init__.py"
    exc = FileSkipSetting(file_path)
    assert type(exc) == FileSkipSetting
    assert exc.file_path == file_path
    assert str(exc) == "'/home/uyu/projects/isort-examples/python/__init__.py' was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:22:29.729952
# Unit test for constructor of class ISortError
def test_ISortError():
	nome = "ISortError"
	nome_errado = "ISortErrorr"
	mensagem = "Erro de teste"
	mensagem_errada = "Erro de testee"
	assert(ISortError(mensagem).__str__() == mensagem);
	assert(ISortError(mensagem).__class__.__name__ == nome);
	assert(ISortError(mensagem).__class__.__name__ != nome_errado);
	assert(ISortError(mensagem).__str__() == mensagem);
	assert(ISortError(mensagem).__str__() != mensagem_errada);



