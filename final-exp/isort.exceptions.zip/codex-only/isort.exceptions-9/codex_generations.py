

# Generated at 2022-06-23 20:12:30.435913
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "File skipped for test"
    file_path = "file_skipped_for_test"

    instance = FileSkipped(message, file_path)
    assert type(instance) is ISortError
    assert type(instance) is FileSkipped
    assert instance.message == message
    assert instance.file_path == file_path

# Generated at 2022-06-23 20:12:38.063061
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    from ast import literal_eval
    # Sample values
    test_code = "[('a',1) , ('b', 2)]"
    expected_kind = list
    try:
        kind = literal_eval(test_code).__class__
    except Exception as e:
        kind = literal_eval(test_code)
    # Test the class constructor
    assert LiteralSortTypeMismatch(kind,expected_kind).kind == kind
    assert LiteralSortTypeMismatch(kind,expected_kind).expected_kind == expected_kind

# Generated at 2022-06-23 20:12:47.085844
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {
        "foo": {"value": 1, "source": "default"},
        "bar": {"value": 2, "source": "config"},
        "baz": {"value": 3, "source": "cli"},
    }
    error = UnsupportedSettings(settings)
    assert settings == error.unsupported_settings
    assert (
        repr(error)
        == 'UnsupportedSettings(unsupported_settings={\n'
        '\t- foo = 1  (source: \'default\')\n'
        '\t- bar = 2  (source: \'config\')\n'
        '\t- baz = 3  (source: \'cli\')\n'
        '})'
    )



# Generated at 2022-06-23 20:12:49.475721
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error = LiteralParsingFailure('123', Exception('Original error'))
    assert error.code == '123'
    assert error.original_error.args[0] == 'Original error'



# Generated at 2022-06-23 20:12:52.972292
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception = UnsupportedEncoding(filename = "file.py")
    assert exception.filename == "file.py"
    assert str(exception) == "Unknown or unsupported encoding in file.py"

# Generated at 2022-06-23 20:12:54.737339
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('test')
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == 'test'



# Generated at 2022-06-23 20:12:55.610722
# Unit test for constructor of class ISortError
def test_ISortError():
    assert hasattr(ISortError, "__init__")

# Generated at 2022-06-23 20:12:59.181397
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test_existing_syntax_error")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test_existing_syntax_error"


# Generated at 2022-06-23 20:13:03.204819
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = "test"
    error = ProfileDoesNotExist(profile)
    assert str(error) == f"Specified profile of {profile} does not exist. " + f"Available profiles: {','.join(profiles)}."

# Generated at 2022-06-23 20:13:06.307479
# Unit test for constructor of class ISortError
def test_ISortError():
    message= 'Custom error'
    err = ISortError(message)
    assert err.args[0] == message


# Generated at 2022-06-23 20:13:09.523304
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "foobar"
    original_error = Exception()
    exception = LiteralParsingFailure(code, original_error)
    assert exception.code == code
    assert exception.original_error == original_error

# Generated at 2022-06-23 20:13:19.012289
# Unit test for constructor of class ProfileDoesNotExist

# Generated at 2022-06-23 20:13:23.165581
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str



# Generated at 2022-06-23 20:13:26.413712
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    msg = "Unknown or unsupported encoding in filename"
    filename = "filename"
    unsupportedEncoding = UnsupportedEncoding(filename)
    assert unsupportedEncoding.filename == filename
    assert str(unsupportedEncoding) == msg


# Generated at 2022-06-23 20:13:28.485505
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('test_ISortError')
    except ISortError as e:
        assert str(e) == 'test_ISortError'

# Generated at 2022-06-23 20:13:30.902943
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(type(1), type('1'))
    except LiteralSortTypeMismatch as e:
        assert e.kind is int and e.expected_kind is str

test_LiteralSortTypeMismatch()

# Generated at 2022-06-23 20:13:33.647314
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    f = "file_path"
    e = FileSkipSetting(f)
    assert e.file_path == f
    assert str(e) == "file_path was skipped as it's listed in 'skip' setting" \
                     " or matches a glob in 'skip_glob' setting"



# Generated at 2022-06-23 20:13:35.444092
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting('file_path').file_path == 'file_path'


# Generated at 2022-06-23 20:13:36.457083
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("raises")

# Generated at 2022-06-23 20:13:39.970052
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    plugin_name = 'test'
    err = FormattingPluginDoesNotExist(plugin_name)
    expected = f"Specified formatting plugin of {plugin_name} does not exist. "
    assert str(err) == expected
    assert err.formatter == plugin_name

# Generated at 2022-06-23 20:13:42.455127
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str


# Generated at 2022-06-23 20:13:48.084423
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # GIVEN
    from isort.settings.base_settings import BASE_SETTINGS
    mark_errors = [("unknown_option", {"value": "unknown"})]
    # THEN
    assert UnsupportedSettings(mark_errors).unsupported_settings == {
        "unknown_option": {"value": "unknown"}
    }

# Generated at 2022-06-23 20:13:50.514430
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("test_module", "test_section")
    except Exception as e:
        assert "test_module" in str(e)


# Generated at 2022-06-23 20:13:58.279469
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "abc"
    section = "xyz"
    try:
        raise MissingSection(import_module, section)
    except MissingSection as e:
        assert e.args[0] == f"Found {import_module} import while parsing, but {section} was not included " \
                            f"in the `sections` setting of your config. Please add it before continuing\n" \
                            "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                            "for more info."

# Generated at 2022-06-23 20:14:01.146878
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with AssertRaisesRegex(AssignmentsFormatMismatch, "Does not match"):
        AssignmentsFormatMismatch("foo")

# Generated at 2022-06-23 20:14:04.544718
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
#    assert str(FormattingPluginDoesNotExist("simple")) == "Specified formatting plugin of simple does not exist. "
    assert str(FormattingPluginDoesNotExist("simple")) != "Specified formatting plugin of simple does not exist."

# Generated at 2022-06-23 20:14:07.833738
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('file1.py')
    except IntroducedSyntaxErrors as e:
        assert e.args[0] == 'isort introduced syntax errors when attempting to sort the imports contained within file1.py.'
        assert e.file_path == 'file1.py'


# Generated at 2022-06-23 20:14:12.166587
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    import isort
    filename = "x.py"
    try:
        raise isort.UnsupportedEncoding(filename)
    except isort.UnsupportedEncoding as e:
        assert e.filename == "x.py"


# Generated at 2022-06-23 20:14:17.903101
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped(
            message="test message", file_path="/Users/volodymyr/Workspace/isort/isort/tests/test_file.py")
    except FileSkipped as err:
        assert str(err).startswith("test message")
        assert err.file_path == "/Users/volodymyr/Workspace/isort/isort/tests/test_file.py"


# Generated at 2022-06-23 20:14:21.329881
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    f = FileSkipComment("test.py")
    assert f.message == "test.py contains an file skip comment and was skipped."
    assert f.file_path == "test.py"

# Generated at 2022-06-23 20:14:26.247930
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    string = "\"Hello, World!\""
    error = LiteralSortTypeMismatch(kind=str, expected_kind=lit)

    return error.kind == str and error.expected_kind == lit


# Generated at 2022-06-23 20:14:29.489845
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"

# Generated at 2022-06-23 20:14:30.593915
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    f = ExistingSyntaxErrors("/etc/isort.cfg")
    f

# Generated at 2022-06-23 20:14:35.455861
# Unit test for constructor of class ISortError
def test_ISortError():
    import sys
    import pytest
    import mock
    with pytest.raises(ISortError):
        mock.MagicMock(raise_exception=ISortError('what is error'))
    with pytest.raises(Exception):
        mock.MagicMock(raise_exception=ISortError('what is error'))

# Generated at 2022-06-23 20:14:39.166229
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    test_FS = FileSkipSetting("test")
    assert str(test_FS).__eq__("test was skipped as it's listed in 'skip' setting"
                               " or matches a glob in 'skip_glob' setting")
    assert test_FS.file_path.__eq__("test")

# Generated at 2022-06-23 20:14:41.126757
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    import pytest
    with pytest.raises(ExistingSyntaxErrors):
        raise ExistingSyntaxErrors("/path/to/file")


# Generated at 2022-06-23 20:14:43.513006
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'abc'
    error = FormattingPluginDoesNotExist(formatter)
    assert error.formatter == formatter

# Generated at 2022-06-23 20:14:44.853662
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath("test").settings_path == "test"


# Generated at 2022-06-23 20:14:48.416173
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('invalid_encoding_file.txt')
    except UnsupportedEncoding as e:
        assert e.filename == 'invalid_encoding_file.txt'
# test case for constructor of class UnsupportedEncoding
test_UnsupportedEncoding()


# Generated at 2022-06-23 20:14:50.995749
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    exception = LiteralParsingFailure("this is a test", "Invalid literal for int()")
    assert exception.code == "this is a test"
    assert exception.original_error == "Invalid literal for int()"


# Generated at 2022-06-23 20:14:53.445696
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    dummy_file_path = "/dummy/file/path"
    fss = FileSkipSetting(dummy_file_path)
    assert fss.file_path == dummy_file_path

# Generated at 2022-06-23 20:14:55.107302
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding):
        UnsupportedEncoding("test_file.py")

# Generated at 2022-06-23 20:14:59.499258
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class DerivedException(Exception):
        def __init__(self, message: str):
            super().__init__(message)
    # for comparing values
    derived_exception = DerivedException("some message")
    instance = LiteralParsingFailure("some code", derived_exception)
    assert instance.code == "some code"
    assert instance.original_error == derived_exception


# Generated at 2022-06-23 20:15:00.212101
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError('test')


# Generated at 2022-06-23 20:15:06.293026
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class TestException(Exception):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    t = TestException(1, 2)
    try:
        raise LiteralParsingFailure('test', t)
    except Exception as e:
        assert e.code == 'test'
        assert e.original_error.a == 1
        assert e.original_error.b == 2

# Generated at 2022-06-23 20:15:09.399341
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        assert(False)
    except:
        exc = "MissingSection(import_module='f1', section='f2').__init__()"
        assert(exc == "MissingSection('f1', 'f2').__init__()")


# Generated at 2022-06-23 20:15:11.320150
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path1 = "test"
    fss = FileSkipSetting(file_path1)
    assert fss.file_path == "test"

# Generated at 2022-06-23 20:15:15.571334
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test-profile")
    except Exception as exc:
        assert exc.__str__() == "Specified profile of test-profile does not exist. Available profiles: black,flake8,google,grumpy,horizontal,isort,junit,liatrio,mccabe,mozilla,mypy,numpy,pep8,pycodestyle,pyflakes,pyroma,vulture,yapf,test-profile."

# Generated at 2022-06-23 20:15:20.147675
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as error:
        ExistingSyntaxErrors("test_file.py")
    assert error.value.file_path == "test_file.py"



# Generated at 2022-06-23 20:15:25.530882
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    class_name = 'FileSkipSetting'
    message = 'message'
    file_path = 'file_path'
    actual = FileSkipSetting(file_path)
    assert isinstance(actual, FileSkipped)
    assert hasattr(actual, 'message')
    assert hasattr(actual, 'file_path')
    assert actual.message == message
    assert actual.file_path == class_name

# Generated at 2022-06-23 20:15:30.622897
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
	settings = {
		'a': 1,
		'b': 2,
	}
	error = UnsupportedSettings(settings)
	assert error.unsupported_settings == settings
	assert error.message == 'isort was provided settings that it doesn\'t support:\n\n\t- a = 1  (source: \'\')\n\t- b = 2  (source: \'\')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n'
	return

# Generated at 2022-06-23 20:15:34.778932
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = 'data/IntroducedSyntaxErrors'
    with pytest.raises(IntroducedSyntaxErrors) as exinfo:
        raise IntroducedSyntaxErrors(file_path)
    assert exinfo.value.file_path == file_path



# Generated at 2022-06-23 20:15:36.974902
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding):
        raise UnsupportedEncoding("foo")

# Generated at 2022-06-23 20:15:43.686312
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = 'test_module'
    section = 'test_section'
    m = MissingSection(import_module, section)
    assert isinstance(m, ISortError)
    assert m.args[0] == f"Found {import_module} import while parsing, but {section} was not included " \
           "in the `sections` setting of your config. Please add it before continuing\n" \
           "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
           "for more info."
    assert m.import_module == import_module
    assert m.section == section

# Generated at 2022-06-23 20:15:46.451314
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """
    >>> test_UnsupportedEncoding()
    """
    UnsupportedEncoding("file1.py")

# Generated at 2022-06-23 20:15:48.863172
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'test_formatter'
    test = FormattingPluginDoesNotExist(formatter)
    assert test.formatter == formatter

# Generated at 2022-06-23 20:15:52.668477
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    check_settings = {
        "settings": "asdasd",
        "settings1": "asdasd",
    }
    error = UnsupportedSettings(check_settings)
    assert error.unsupported_settings == check_settings

# Generated at 2022-06-23 20:15:58.406100
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding) as excinfo:
        raise UnsupportedEncoding("C:\\Users\\Aldob\\Desktop\\ISort\\tests\\test_imports.py")
    assert str(excinfo.value) == "Unknown or unsupported encoding in C:\\Users\\Aldob\\Desktop\\ISort\\tests\\test_imports.py"

# Generated at 2022-06-23 20:16:06.061276
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("""a;
b;
c;""")
    except AssignmentsFormatMismatch as e:
        assert str(e) == """isort was told to sort a section of assignments, however the given code:

a;
b;
c;

Does not match isort's strict single line formatting requirement for assignment sorting:

{variable_name} = {value}
{variable_name2} = {value2}
...

"""

# Generated at 2022-06-23 20:16:09.171524
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = 'base'
    req = FormattingPluginDoesNotExist(formatter)
    assert req.formatter == formatter
    assert req.args == ("Specified formatting plugin of base does not exist. ",)


# Generated at 2022-06-23 20:16:12.787441
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    object1 = LiteralSortTypeMismatch(int, str)
    assert object1.kind == int
    assert object1.expected_kind == str
    assert object1.__str__() == "isort was told to sort a literal of type " \
                                "<class 'str'> but was given a literal of type <class 'int'>."

# Generated at 2022-06-23 20:16:16.090127
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors("/test.py")
    assert err.file_path == "/test.py"
    assert str(err) == "/test.py introduced syntax errors when attempting to sort the imports"

# Generated at 2022-06-23 20:16:21.994730
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    """Should return the correct message and file path for file skipped for setting"""
    file_skipped_obj = FileSkipSetting(file_path="/home/project/isort.py")
    assert str(file_skipped_obj) == "/home/project/isort.py was skipped as it's listed in 'skip' setting" \
                                    " or matches a glob in 'skip_glob' setting"
    assert file_skipped_obj.file_path == "/home/project/isort.py"

# Generated at 2022-06-23 20:16:24.514182
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    exception = FileSkipSetting("test.py")
    assert str(exception) == "test.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert exception.file_path == "test.py"

# Generated at 2022-06-23 20:16:26.402586
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors(file_path="/tmp/a.py")


# Generated at 2022-06-23 20:16:29.181337
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    with pytest.raises(FileSkipComment) as excinfo:
        raise FileSkipComment("Skip comment")
    assert excinfo.value.file_path == "Skip comment"



# Generated at 2022-06-23 20:16:34.747052
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    """Implements test for constructor of class FormattingPluginDoesNotExist"""
    try:
        raise FormattingPluginDoesNotExist("isort_test")
    except FormattingPluginDoesNotExist as e:
        assert (
            str(e) == "Specified formatting plugin of isort_test does not exist. "
        )
        assert e.formatter == "isort_test"

# Generated at 2022-06-23 20:16:37.651190
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped(message='test', file_path='test').message == 'test'
    assert FileSkipped(message='test', file_path='test').file_path == 'test'


# Generated at 2022-06-23 20:16:39.009436
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exc = UnsupportedEncoding("test.py")
    assert exc.__str__() == "Unknown or unsupported encoding in test.py"

# Generated at 2022-06-23 20:16:40.397346
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    print(FormattingPluginDoesNotExist.__doc__)

# Generated at 2022-06-23 20:16:41.263710
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(kind=int, expected_kind=str)

# Generated at 2022-06-23 20:16:45.200211
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"key": {"value": "value", "source": "source"}}
    not_existed_settings = UnsupportedSettings(unsupported_settings)

    assert not_existed_settings.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:16:49.067752
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    """
    >>> FileSkipSetting('/home/ivan/project/app.py')
    '/home/ivan/project/app.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting'
    """

# Generated at 2022-06-23 20:16:51.833437
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path="path"
    message="message"
    fileskipped=FileSkipped(message, file_path)
    assert fileskipped.file_path=="path"
    assert fileskipped.message=="message"


# Generated at 2022-06-23 20:16:56.580590
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors) as exception_info:
        raise IntroducedSyntaxErrors("file_path")
    assert exception_info.match(".*") #Tests If a pattern matches a string
    assert str(exception_info) == "isort introduced syntax errors when attempting to sort the imports contained within file_path."


# Generated at 2022-06-23 20:16:59.571975
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist(profile=None)

    expected = "isort was told to use the settings_path: a as the base directory or file that represents the starting point of config file discovery, but it does not exist."

    assert error.profile == None
    assert str(error) == expected


# Generated at 2022-06-23 20:17:04.052387
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    msg = 'message'
    file_path = 'file_path'
    file_skipped = FileSkipped(msg, file_path)
    assert file_skipped.message == msg
    assert file_skipped.file_path == file_path
    assert file_skipped.args == (msg,)

# Generated at 2022-06-23 20:17:06.585405
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding) as exc:
        raise UnsupportedEncoding("filename")
    assert str(exc.value) == "Unknown or unsupported encoding in filename"

# Generated at 2022-06-23 20:17:08.780117
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("Test", "./test.txt")
    except Exception as e:
        assert isinstance(e, FileSkipped)
        assert e.file_path == "./test.txt"

# Generated at 2022-06-23 20:17:11.929693
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    instance = FileSkipSetting('file skipped')
    assert isinstance(instance, FileSkipped)
    assert instance.file_path == 'file skipped'
    assert str(instance) == "file skipped was skipped as it's listed in 'skip' " \
                            "setting' or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:17:20.452162
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest.raises(AssignmentsFormatMismatch) as e:
        raise AssignmentsFormatMismatch("test")
    assert "isort was told to sort a section of assignments, however the given code:\n\n" \
           "test\n\n" \
           "Does not match isort's strict single line formatting requirement for assignment " \
           "sorting:\n\n" \
           "{variable_name} = {value}\n" \
           "{variable_name2} = {value2}\n" \
           "...\n\n" in str(e)

# Generated at 2022-06-23 20:17:25.305552
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    from textwrap import dedent

    try:
        raise FileSkipSetting("README.md")
    except FileSkipSetting as e:
        assert str(e) == dedent("""
            README.md was skipped as it's listed in 'skip' setting
            or matches a glob in 'skip_glob' setting
        """).strip()
        assert e.file_path == "README.md"

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 20:17:28.987063
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("spam")
    except IntroducedSyntaxErrors as ex:
        assert ex.file_path == "spam"
    else:
        assert False, "No exception raised"



# Generated at 2022-06-23 20:17:30.389946
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    raise FileSkipSetting('test_path')

# Generated at 2022-06-23 20:17:35.171557
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    filename = 'FileSkipped'
    message = 'Raised when a file is skipped for any reason'
    assert str(FileSkipped(message, filename)) == 'FileSkipped: Raised when a file is skipped for any reason'
    assert FileSkipped(message, filename).file_path == 'FileSkipped'


# Generated at 2022-06-23 20:17:43.129526
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        x = AssignmentsFormatMismatch("a=3")
    except AssignmentsFormatMismatch as e:
        assert "isort was told to sort a section of assignments, however the given code:\n\n" \
               "a=3\n\n" \
               "Does not match isort's strict single line formatting requirement for assignment " \
               "sorting:\n\n" \
               "{variable_name} = {value}\n" \
               "{variable_name2} = {value2}\n" \
               "...\n\n" == str(e)
    except:
        assert False

# Generated at 2022-06-23 20:17:45.116293
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        UnsupportedEncoding("test123")
        AssertionError("Expected exception of type UnsupportedEncoding not raised")
    except UnsupportedEncoding as ex:
        assert ex.filename == "test123"

# Generated at 2022-06-23 20:17:50.510490
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        print(e)
        assert e.import_module == "import_module"
        assert e.section == "section"

# Generated at 2022-06-23 20:17:53.375487
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
  unsupport = UnsupportedEncoding("E:/documents/test.txt")
  assert unsupport.filename =="E:/documents/test.txt"


# Generated at 2022-06-23 20:17:54.402653
# Unit test for constructor of class ISortError
def test_ISortError():
    assert issubclass(ISortError, Exception)


# Generated at 2022-06-23 20:17:58.141873
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as excinfo:
        raise ExistingSyntaxErrors('test_file_path')

    assert 'test_file_path' in str(excinfo.value)
    assert 'test_file_path' in str(excinfo.value)


# Generated at 2022-06-23 20:18:03.198761
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    plugin_name = "DUMMY"

    error = FormattingPluginDoesNotExist(plugin_name)
    assert error.args[0] == f"Specified formatting plugin of {plugin_name} does not exist. "
    assert error.message == f"Specified formatting plugin of {plugin_name} does not exist. "
    assert error.formatter == "DUMMY"


# Generated at 2022-06-23 20:18:05.641621
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    expectedMsg = f"isort was told to sort imports within code that contains syntax errors: {file_path}."
    assert ExistingSyntaxErrors(file_path).__str__() == expectedMsg

# Generated at 2022-06-23 20:18:06.813115
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped("a", "b")


# Generated at 2022-06-23 20:18:10.174532
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch("int", ["dictionary"])
    except LiteralSortTypeMismatch as e:
        assert e.kind == "int"
        assert e.expected_kind == ["dictionary"]

# Generated at 2022-06-23 20:18:15.667845
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        message = "This is a FileSkipped test."
        file_path = "file_path"
        raise FileSkipped(message, file_path)
    except FileSkipped as exception:
        assert exception.args[0] == message
        assert exception.file_path == file_path



# Generated at 2022-06-23 20:18:21.107098
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """
    Function tests if the constructor of the custom class
    LiterlParsingFailure works
    """
    try:
        raise LiteralParsingFailure("a", "b")
    except ISortError as exception:
        assert isinstance(exception, ISortError)
        assert isinstance(exception, LiteralParsingFailure)
        assert exception.args[0] == "a"
        assert exception.args[1] == "b"


# Generated at 2022-06-23 20:18:26.547204
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    from .config import Config
    config = Config()
    config.config_file = "isort.cfg"
    config.formatter = "foo"
    import isort

    with pytest.raises(isort.FormattingPluginDoesNotExist) as f:
        config.run(False)
    assert f.value.formatter == "foo"

# Generated at 2022-06-23 20:18:28.573285
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    expected_kind_str = "str"
    kind_str = "str"
    assert LiteralSortTypeMismatch(kind_str, expected_kind_str)


# Generated at 2022-06-23 20:18:31.848062
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fileSkipped = FileSkipped(message="message", file_path="test_file_path")
    assert fileSkipped.message == "message"
    assert fileSkipped.file_path == "test_file_path"

# Generated at 2022-06-23 20:18:34.668925
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "my_var = {'a': 'b'}"
    isinstance(LiteralParsingFailure(code, ValueError), LiteralParsingFailure)

# Generated at 2022-06-23 20:18:36.119071
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding(filename="my_file.py")

# Generated at 2022-06-23 20:18:40.252756
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    message = "Unable to find packages, isort is glitched"
    file_path = "path"

    e1 = InvalidSettingsPath(file_path)

    assert e1.settings_path == file_path
    assert str(e1) == message


# Generated at 2022-06-23 20:18:46.547370
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        # code that raises 'Invalid literal for int() with base 10: '2.0' error
        a = int("2.0")
    except Exception as e:
        assert str(LiteralParsingFailure("2.0", e)) == "isort failed to parse the given literal 2.0. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of invalid literal for int() with base 10: '2.0'\n"

# Generated at 2022-06-23 20:18:47.647769
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
	profile = "default"
	ISortError.__init__(profile)

# Generated at 2022-06-23 20:18:50.658123
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    import ast
    from isort.exceptions import LiteralParsingFailure
    try:
        a = ast.literal_eval("1+2")
    except ValueError as e:
        raise LiteralParsingFailure("1+2", e)
test_LiteralParsingFailure()

# Generated at 2022-06-23 20:18:53.933556
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """
    Test to check the constructor of class UnsupportedEncoding.
    """
    test_object = UnsupportedEncoding("test filename")
    assert isinstance(test_object, UnsupportedEncoding)

# Generated at 2022-06-23 20:18:57.762038
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("/tmp/test.py")
    except ExistingSyntaxErrors as e:
        assert e.args[0].endswith("/tmp/test.py.")
        assert e.file_path == "/tmp/test.py"

# Generated at 2022-06-23 20:19:03.959073
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    options = {
        "asdf": {"value": 1, "source": "asdf"},
        "qwer": {"value": 2, "source": "qwer"},
        "zxcv": {"value": 3, "source": "zxcv"},
    }

    error = UnsupportedSettings(options)
    assert error.unsupported_settings == options

# Generated at 2022-06-23 20:19:08.718303
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    """
    Unit test for constructor of class FileSkipped
    """
    try:
        raise FileSkipComment("file_path")
    except FileSkipComment as e:
        assert e.file_path == "file_path"
        assert e.message == 'file_path contains an file skip comment and was skipped.'
        assert e.__class__ == FileSkipComment


# Generated at 2022-06-23 20:19:11.321633
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "variable_name = value\nvariable_name2 = value2"
    exception = AssignmentsFormatMismatch(code)
    assert exception.code == "variable_name = value\nvariable_name2 = value2"



# Generated at 2022-06-23 20:19:13.595153
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    string = "This is an existing Syntax Error"
    a = ExistingSyntaxErrors(string)
    assert a.file_path == string


# Generated at 2022-06-23 20:19:16.190819
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    # Arrange and act
    actual = ProfileDoesNotExist('foo')

    # Assert
    assert hasattr(actual, 'profile')
    assert actual.profile == 'foo'

# Generated at 2022-06-23 20:19:18.956201
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    cls=IntroducedSyntaxErrors("file_path")
    assert cls.file_path=="file_path"


# Generated at 2022-06-23 20:19:20.148155
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert isinstance(InvalidSettingsPath("test"), ISortError)


# Generated at 2022-06-23 20:19:23.256759
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("")
    except ISortError as e:
        print(f"ISortError: {e}")
    finally:
        print("Test Finished!")


if __name__ == "__main__":
    test_FormattingPluginDoesNotExist()

# Generated at 2022-06-23 20:19:26.765577
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding) as exc_info:
        raise UnsupportedEncoding(filename="test.py")
    assert "test.py" in str(exc_info.value)
    assert "Unknown or unsupported encoding in test.py" in str(exc_info.value)

# Generated at 2022-06-23 20:19:29.715440
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("pytest", "TEST")
    except MissingSection as err:
        assert str(err) == "Found pytest import while parsing, but TEST was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:19:33.001399
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("test").file_path == "test"
    assert IntroducedSyntaxErrors("test").__str__() == "isort introduced syntax errors when attempting to sort the imports contained within test."

# Generated at 2022-06-23 20:19:34.656068
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert "Unknown or unsupported encoding in test" == UnsupportedEncoding("test").__str__()

# Generated at 2022-06-23 20:19:39.040634
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(type(1), type(1.1))

    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == float


if __name__ == "__main__":
    test_LiteralSortTypeMismatch()

# Generated at 2022-06-23 20:19:41.387969
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a=2")
    except AssignmentsFormatMismatch:
        print("You got an exception")


# Generated at 2022-06-23 20:19:48.734541
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("a", "b")
    except MissingSection as e:
        assert e.args[0] == "Found a import while parsing, but b was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        assert e.import_module == "a"
        assert e.section == "b"



# Generated at 2022-06-23 20:19:53.890795
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class TestException(Exception):
        pass
    test_literal_parsing_failure = LiteralParsingFailure('10', TestException("This is a test"))
    assert test_literal_parsing_failure.code == '10'
    assert test_literal_parsing_failure.original_error.args[0] == "This is a test"
    assert isinstance(test_literal_parsing_failure.original_error, TestException)


# Generated at 2022-06-23 20:19:56.337218
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("test").message == "test contains an file skip comment and was skipped."

# Generated at 2022-06-23 20:19:59.806959
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Arrange
    file_path = "test/test_files/test_file.py"

    # Act
    exception = ExistingSyntaxErrors(file_path)

    # Assert
    assert exception.file_path == file_path



# Generated at 2022-06-23 20:20:01.431696
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise Exception("what is going on")
    except Exception as e:
        LiteralParsingFailure("this is an error", e)

# Generated at 2022-06-23 20:20:03.144802
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = "file"
    error = FileSkipComment(path)
    assert error.file_path == path

# Generated at 2022-06-23 20:20:06.492502
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Arrange
    # Action
    lStypeMismatch = LiteralSortTypeMismatch(type("String"), type("List"))
    # Assert
    assert lStypeMismatch.kind == type("String")
    assert lStypeMismatch.expected_kind == type("List")

# Generated at 2022-06-23 20:20:11.775865
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "README.md"
    message = f"{file_path} was skipped as it's listed in 'skip' setting" \
              " or matches a glob in 'skip_glob' setting"
    file_skip_setting = FileSkipSetting(file_path)
    assert file_skip_setting.message == message
    assert file_skip_setting.file_path == file_path

# Generated at 2022-06-23 20:20:15.530039
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("False", SyntaxError("Invalid literal"))
    except LiteralParsingFailure as e:
        assert e.code == "False"
        assert e.original_error.msg == "Invalid literal"

# Generated at 2022-06-23 20:20:23.072439
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    """Test of constructor of class AssignmentsFormatMismatch"""
    code = "abc =\nabc = 'abc'"
    error = AssignmentsFormatMismatch(code)
    assert str(error) == (
        "isort was told to sort a section of assignments, however the given code:\n\n"
        f"{code}\n\n"
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
    )

# Generated at 2022-06-23 20:20:25.637394
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist(): 
    formatter = "nonexist"
    formatter_error = FormattingPluginDoesNotExist(formatter)
    assert formatter_error.formatter == "nonexist"

# Generated at 2022-06-23 20:20:34.818790
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """
    Main testing function for the class UnsupportedSettings
    """
    import unittest
    import json
    import collections

    class TestUnsupportedSettings(unittest.TestCase):
        """
        Class containing tests for UnsupportedSettings
        """

        def test_unsupported_settings(self):
            """
            Test UnsupportedSettings class function
            """
            filename = "test_unsupported_settings.json"
            with open(filename, "w") as test_unsupported_settings_file:
                test_unsupported_settings_file.write(
                    '{"unsupported_settings":{"name":{"value":"value","source":"source"}}}'
                )
            with open(filename, "r") as test_unsupported_settings_file:
                json_file = json.load(test_unsupported_settings_file)
                #

# Generated at 2022-06-23 20:20:36.345935
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch) as excinfo:
        assert excinfo.value.message

# Generated at 2022-06-23 20:20:40.684387
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # For a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.
    code = 't_var = val\n\n'
    a = AssignmentsFormatMismatch(code)
    assert a.code == code

# Generated at 2022-06-23 20:20:45.072388
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped = FileSkipped(file_path=__file__, message='skipped this file!')
    assert file_skipped.file_path == __file__
    assert file_skipped.message == 'skipped this file!'
    assert str(file_skipped) == 'skipped this file!'


# Generated at 2022-06-23 20:20:48.098865
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    x = FileSkipSetting('test')
    assert x.message == "test was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert x.file_path == 'test'


# Generated at 2022-06-23 20:20:49.600090
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError()


# Generated at 2022-06-23 20:20:52.050817
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    message = "Specified formatting plugin of xxx does not exist. "
    e = FormattingPluginDoesNotExist("xxx")
    assert str(e) == message
    assert e.formatter == "xxx"

# Generated at 2022-06-23 20:20:54.774182
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest.raises(ISortError):
        AssignmentsFormatMismatch("a = 5")


# Generated at 2022-06-23 20:20:59.374576
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection("import_module", "section").args == ('Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.',)

# Generated at 2022-06-23 20:21:03.588579
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("hello")
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within hello."
        assert e.file_path == "hello"


# Generated at 2022-06-23 20:21:04.779231
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding):
        raise UnsupportedEncoding("myfile.txt")

# Generated at 2022-06-23 20:21:08.383355
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    print("Start test test_UnsupportedSettings:")
    errors = {
        "fake_option": {"value": "fake", "source": "config"},
        "another_fake_option": {"value": "another", "source": "CLI"},
    }
    unsuppored_settings = UnsupportedSettings(errors)
    print(unsuppored_settings.__repr__())

# Generated at 2022-06-23 20:21:09.791260
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "test"
    error = FormattingPluginDoesNotExist(formatter)
    assert formatter == error.formatter

# Generated at 2022-06-23 20:21:11.074169
# Unit test for constructor of class ISortError
def test_ISortError():
    assert True

# Generated at 2022-06-23 20:21:14.387026
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    expected_message = "isort was told to sort imports within code that contains syntax errors: aaa."
    assert ExistingSyntaxErrors("aaa").args[0] == expected_message, "Unexpected message"

# Generated at 2022-06-23 20:21:20.710306
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("~/bogus/path")
    except InvalidSettingsPath as exception:
        assert str(exception) == "isort was told to use the settings_path: ~/bogus/path as the base directory or " \
                                 "file that represents the starting point of config file discovery, but it does not exist."
        assert exception.settings_path == "~/bogus/path"



# Generated at 2022-06-23 20:21:27.930369
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
   try:
      raise AssignmentsFormatMismatch(
                    "isort was told to sort a section of assignments, however the given code:\n\n"
            f"{code}\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n"
                    )
   except AssignmentsFormatMismatch as error:
      assert error.code == "isort was told to sort a section of assignments, however the given code:\n\n"

# Generated at 2022-06-23 20:21:30.783561
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("hello world", Exception("literal parsing failed"))
    except LiteralParsingFailure as e:
        assert e.code == "hello world"
        assert str(e.original_error) == "literal parsing failed"


# Generated at 2022-06-23 20:21:36.907106
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    actual = LiteralSortTypeMismatch(str, int)
    assert actual.kind == str
    assert actual.expected_kind == int
    expected = "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>."
    assert actual.args[0] == expected


# Generated at 2022-06-23 20:21:39.942634
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    e = ExistingSyntaxErrors("file_path")
    assert e.args[0] == ("file_path")
    assert e.file_path == ("file_path")

# Generated at 2022-06-23 20:21:43.111877
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    error = LiteralParsingFailure(code="1", original_error="actual error")
    assert error.code == "1"
    assert error.original_error == "actual error"


# Generated at 2022-06-23 20:21:44.517973
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
  # Setting message as error message
  assert InvalidSettingsPath("/path").message == "/path"

# Generated at 2022-06-23 20:21:46.555122
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    obj = FileSkipSetting("filepath")
    assert obj.file_path == "filepath"

# Generated at 2022-06-23 20:21:49.068596
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    exception = LiteralSortTypeMismatch(int, str)
    assert type(exception.kind) == type(int)
    assert type(exception.expected_kind) == type(str)

# Generated at 2022-06-23 20:21:52.889675
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    with pytest.raises(ValueError):
        raise LiteralParsingFailure(
            code="(1, 2, 'c')",
            original_error=ValueError('malformed string'),
        )


# Generated at 2022-06-23 20:21:54.567448
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    prof = ProfileDoesNotExist("default")
    assert prof.profile == "default"


# Generated at 2022-06-23 20:21:56.987127
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    """Unit test for constructor of class FileSkipComment"""
    assert FileSkipComment("file.py").file_path == "file.py"

# Generated at 2022-06-23 20:21:59.696043
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "unsupported setting": {
            "value": "value",
            "source": "source",
        }
    }

    error = UnsupportedSettings(unsupported_settings)

    assert unsupported_settings == error.unsupported_settings



# Generated at 2022-06-23 20:22:01.236049
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    exception = FormattingPluginDoesNotExist(formatter = "formatter")

# Generated at 2022-06-23 20:22:03.313285
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-23 20:22:07.633495
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("a")
        assert False
    except UnsupportedEncoding as e:
        assert e.__class__.__name__ == "UnsupportedEncoding"
        assert e.__context__ == None
        assert str(e) == "Unknown or unsupported encoding in a"
        assert e.filename == "a"


# Generated at 2022-06-23 20:22:09.670097
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        path = "config.cfg"
        FileSkipped(file_path="config.cfg")
    except Exception as e:
        assert e.file_path == path

# Generated at 2022-06-23 20:22:11.874738
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "http"
    section = "FIRSTPARTY"

    m = MissingSection(import_module, section)

    assert m.import_module == import_module
    assert m.section == section

# Generated at 2022-06-23 20:22:13.563146
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("/my/path")
    except UnsupportedEncoding as err:
        assert "/my/path" == err.filename

# Generated at 2022-06-23 20:22:17.902877
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # GIVEN
    literal_kind = type('dict')
    literal_expected_kind = type('tuple')

    # WHEN
    error = LiteralSortTypeMismatch(literal_kind, literal_expected_kind)

    # THEN
    assert error.kind == literal_kind
    assert error.expected_kind == literal_expected_kind

# Generated at 2022-06-23 20:22:19.977426
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as err:
        assert err.formatter == "test"

# Generated at 2022-06-23 20:22:24.525798
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=str, expected_kind=int)
    except LiteralSortTypeMismatch as e:
        assert e.expected_kind == int
        assert e.kind == str

# Generated at 2022-06-23 20:22:26.931942
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("formatter_name")
    except FormattingPluginDoesNotExist as error:
        assert error.formatter == "formatter_name"