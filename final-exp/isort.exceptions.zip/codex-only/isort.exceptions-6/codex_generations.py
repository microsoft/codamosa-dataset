

# Generated at 2022-06-23 20:12:32.704530
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist('bad_profile')

# Generated at 2022-06-23 20:12:33.436324
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped('message', 'filepath')

# Generated at 2022-06-23 20:12:38.580467
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    import sys
    if sys.version_info < (3, 6):
        assert False
    else:
        try:
            raise UnsupportedEncoding("test.py")
        except Exception as e:
            assert e.__class__.__name__ == 'UnsupportedEncoding'
            assert e.args[0] == 'Unknown or unsupported encoding in test.py'
            assert e.filename == 'test.py'
            assert True

# Generated at 2022-06-23 20:12:39.182479
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError


# Generated at 2022-06-23 20:12:41.751443
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as instance:
        assert instance.profile == "test"

# Generated at 2022-06-23 20:12:47.643044
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    className = "AssignmentsFormatMismatch"
    code = "a = 5"
    exception = AssignmentsFormatMismatch(code)
    assert str(exception) == className
    assert exception.code == code

# Generated at 2022-06-23 20:12:49.728269
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    obj = InvalidSettingsPath('test_settings_path')
    assert obj.settings_path == 'test_settings_path'


# Generated at 2022-06-23 20:12:56.498794
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "C:\\Users\\amitd\\Desktop\\isorttemp\\temp\\2.py"
    expected_message = f"{file_path} was skipped as it's listed in 'skip' setting" \
                       " or matches a glob in 'skip_glob' setting"
    expected_filepath = file_path
    skipped_file = FileSkipSetting(file_path)
    assert skipped_file.message == expected_message
    assert skipped_file.file_path == expected_filepath

# Generated at 2022-06-23 20:12:59.604165
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/path/to/file.py")
    except InvalidSettingsPath as error:
        assert error.settings_path == "/path/to/file.py"



# Generated at 2022-06-23 20:13:02.262189
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError) as exception_info:
        raise ISortError('Exception raised')
    assert exception_info.value.args[0] == 'Exception raised'

# Generated at 2022-06-23 20:13:09.476482
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("fakeimport", "Fake")
    except MissingSection as error:
        assert (
            str(error)
            == "Found fakeimport import while parsing, but Fake was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        )



# Generated at 2022-06-23 20:13:14.217805
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(
        kind=1, expected_kind=2
    ).__str__() == "isort was told to sort a literal of type 2 but was given a literal of type 1."  # noqa: E501 pylint: disable=no-member

# Generated at 2022-06-23 20:13:16.475813
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    from isort import exceptions

    exception = exceptions.LiteralSortTypeMismatch(float, int)

    assert exception.kind == float
    assert exception.expected_kind == int

# Generated at 2022-06-23 20:13:19.106988
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    obj = LiteralSortTypeMismatch(kind=str, expected_kind=int)
    assert obj.kind == str
    assert obj.expected_kind == int



# Generated at 2022-06-23 20:13:24.373887
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    with pytest.raises(FileSkipSetting) as excinfo:
        raise FileSkipSetting("test_file")
    assert 'test_file was skipped as it\'s listed in \'skip\' setting or ' \
           'matches a glob in \'skip_glob\' setting' == str(excinfo.value)

# Generated at 2022-06-23 20:13:26.970679
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        UnsupportedEncoding("./mypy.py")
    except UnsupportedEncoding:
        pass
    except Exception:
        assert False
    assert True

# Generated at 2022-06-23 20:13:37.325336
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    from isort.settings import DEFAULT_CONFIG

    def get_supported_settings():
        for k, v in DEFAULT_CONFIG.items():
            if v is not None:
                yield k

    expected = {
        "foo": {"value": "bar", "source": "from_config"},
        "bar": {"value": "baz", "source": "from_config"},
        "baz": {"value": "foo", "source": "from_config"},
    }
    supported = set(get_supported_settings())
    unsupported = set(expected.keys()) - supported

    try:
        raise UnsupportedSettings(expected)
    except UnsupportedSettings as exc:
        assert unsupported == set(exc.unsupported_settings.keys())

# Generated at 2022-06-23 20:13:40.100001
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("some_error_message")
    except ISortError as e:
        assert e.args[0] == "some_error_message"



# Generated at 2022-06-23 20:13:43.115935
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    from isort.exceptions import FileSkipComment
    #create a test instance of that
    test = FileSkipComment(file_path='/test')
    test1 = str(test)
    assert test1 == "/test contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:13:46.606570
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    ue = UnsupportedEncoding("test_data/yaml_files/config.yaml")
    assert ue.filename == 'test_data/yaml_files/config.yaml'

# Generated at 2022-06-23 20:13:49.066808
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    err = LiteralParsingFailure("[]", Exception("error"))
    assert err.code == "[]"
    assert err.original_error.args[0] == "error"

# Generated at 2022-06-23 20:13:51.795515
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    instance = LiteralSortTypeMismatch(tuple, list)
    assert instance.kind == tuple
    assert instance.expected_kind == list



# Generated at 2022-06-23 20:13:54.081607
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("test_path").file_path == "test_path"


# Generated at 2022-06-23 20:13:56.021834
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors("file_path")
    assert isinstance(err, IntroducedSyntaxErrors)

# Generated at 2022-06-23 20:13:57.825313
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    with pytest.raises(ISortError):
        raise LiteralParsingFailure("test", Exception("test"))

# Generated at 2022-06-23 20:14:03.319019
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipComment("a.py").message == \
        "a.py contains an file skip comment and was skipped."
    assert FileSkipSetting("a.py").message == \
        "a.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:14:04.869795
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("FileSkipSetting.py")


# Generated at 2022-06-23 20:14:07.289905
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    x = FileSkipSetting("tests/files/source.py")
    assert x.file_path == "tests/files/source.py"

# Generated at 2022-06-23 20:14:09.865605
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("")
    except ProfileDoesNotExist as e:
        assert isinstance(e, ProfileDoesNotExist)

# Generated at 2022-06-23 20:14:14.101341
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("aaa")
    except ProfileDoesNotExist as e:
        assert str(e) == (
            "Specified profile of aaa does not exist. "
            f"Available profiles: {','.join(profiles)}."
        )

# Generated at 2022-06-23 20:14:17.422327
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as e:
        raise ExistingSyntaxErrors("ExistingSyntaxErrors_file.py")
    assert "ExistingSyntaxErrors_file.py" in str(e)


# Generated at 2022-06-23 20:14:19.340400
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except ISortError:
        pass



# Generated at 2022-06-23 20:14:21.434506
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("/test/file.py").file_path == "/test/file.py"

# Generated at 2022-06-23 20:14:25.242301
# Unit test for constructor of class MissingSection
def test_MissingSection():
    def test_throws_missing_section():
        raise MissingSection(section='test_section', import_module='test_import')

    assert test_throws_missing_section



# Generated at 2022-06-23 20:14:31.206672
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "tensorflow"
    section = "TENSORFLOW"
    e = MissingSection(import_module, section)
    assert e.import_module == import_module
    assert e.section == section
    assert str(e) == (
        f"Found {import_module} import while parsing, but {section} was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info."
    )

# Generated at 2022-06-23 20:14:34.089695
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "/test.py"
    error = FileSkipComment(file_path)
    assert error.file_path == file_path


# Generated at 2022-06-23 20:14:36.608327
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    """Unit test for constructor of class InvalidSettingsPath"""
    error = InvalidSettingsPath("a.b")
    assert error.settings_path == "a.b"



# Generated at 2022-06-23 20:14:40.164893
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "test"
    file_path = "test_file"
    e = FileSkipped(message, file_path)
    assert message == str(e)
    assert message == e.message
    assert file_path == e.file_path

# Generated at 2022-06-23 20:14:43.562585
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    fsc = FileSkipComment("FileSkipComment")
    assert(fsc.file_path == "FileSkipComment")
    assert(issubclass(fsc.__class__, FileSkipped))



# Generated at 2022-06-23 20:14:47.036795
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        print("Testing class ExistingSyntaxErrors")
        raise ExistingSyntaxErrors("test_file")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test_file"
        print("Test case passed!")


# Generated at 2022-06-23 20:14:49.928270
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """
    Constructors of LiteralSortTypeMismatch
    """
    assert LiteralSortTypeMismatch(1, 2).kind == 1
    assert LiteralSortTypeMismatch(1, 2).expected_kind == 2
    assert LiteralSortTypeMismatch(1, 2).args == (1, 2)


# Generated at 2022-06-23 20:14:53.053054
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
        fskip = FileSkipped("msg", "fpath")
        assert fskip.message == "msg"
        assert fskip.file_path == "fpath"

# Generated at 2022-06-23 20:14:55.415116
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist) as e:
        raise ProfileDoesNotExist(profile="random")
    assert e.value.profile == 'random'

# Generated at 2022-06-23 20:15:01.022743
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        # Try creating a profile
        error = ProfileDoesNotExist("test")
        assert False # Should not get here
    except ISortError:
        # The code should throw an error when
        # a profile is not found
        assert True


# Generated at 2022-06-23 20:15:05.670797
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "unknown_setting": {"value": "not usable", "source": "config"},
        "known_setting": {"value": "not usable", "source": "config"},
    }

    with open("unsupported.txt", "w", encoding="utf-8") as file:
        file.write(str(unsupported_settings))


if __name__ == "__main__":
    test_UnsupportedSettings()

# Generated at 2022-06-23 20:15:09.329018
# Unit test for constructor of class MissingSection
def test_MissingSection():
    exc = MissingSection("foo", "bar")
    expected_message = """\
Found foo import while parsing, but bar was not included in the `sections` setting of your config. Please add it before continuing
See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."""
    assert str(exc) == expected_message

# Generated at 2022-06-23 20:15:10.632247
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors("test_path")
    assert error.file_path == "test_path"

# Generated at 2022-06-23 20:15:13.160045
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    x = FileSkipSetting('test.py')
    assert x.message == 'test.py was skipped as it\'s listed in \'skip\' setting' \
                        ' or matches a glob in \'skip_glob\' setting'

# Generated at 2022-06-23 20:15:18.484436
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("test_code")
    except AssignmentsFormatMismatch as exc:
        message = str(exc)
        expected_message = (
            "isort was told to sort a section of assignments, however the given code:\n\n"
            "test_code\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n"
        )
        assert message == expected_message, "Unexpected exception message."



# Generated at 2022-06-23 20:15:20.503471
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = """\
        a = 1
        b = 2
    """
    test_AssignmentsFormatMismatch = AssignmentsFormatMismatch(code)
    assert test_AssignmentsFormatMismatch.code == code

#Unit test for constructor of class FileSkipComment

# Generated at 2022-06-23 20:15:22.728484
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert(ExistingSyntaxErrors('somewhere/file_path').file_path == 'somewhere/file_path')

# Generated at 2022-06-23 20:15:26.372460
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert('<class \'str\'>' == LiteralSortTypeMismatch('a', 'b').kind)
    assert('<class \'str\'>' == LiteralSortTypeMismatch('a', 'b').expected_kind)

# Unit test constructor of class UnsupportedSettings

# Generated at 2022-06-23 20:15:34.820779
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    exception = MissingSection(import_module, section)

    assert exception.args[0] == (
        f"Found {import_module} import while parsing, but {section} was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info."
    )



# Generated at 2022-06-23 20:15:35.711772
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment(file_path="test.py")

# Generated at 2022-06-23 20:15:39.117731
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit test for constructor of class UnsupportedSettings"""
    from unittest.mock import Mock
    from .isort import UnsupportedSettings

    unsupported_settings = Mock()
    assert UnsupportedSettings(unsupported_settings).unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:15:42.836409
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("example/file")
    except ExistingSyntaxErrors as existing_syntax_error:
        assert existing_syntax_error.file_path == "example/file"

# Generated at 2022-06-23 20:15:50.573719
# Unit test for constructor of class MissingSection
def test_MissingSection():
    err = MissingSection(import_module='module', section='Section')
    assert err.args == [
        'Found module import while parsing, but Section was not included in the '
        '`sections` setting of your config. Please add it before continuing\n'
        'See https://pycqa.github.io/isort/#custom-sections-and-ordering '
        'for more info.'
    ]

# Generated at 2022-06-23 20:15:54.723425
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors) as excinfo:
        raise IntroducedSyntaxErrors("mock_file.py")
    assert issubclass(IntroducedSyntaxErrors, ISortError)
    assert excinfo.value.file_path == "mock_file.py"

# Generated at 2022-06-23 20:15:58.167232
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as error:
        assert error.import_module == "import_module"
        assert error.section == "section"



# Generated at 2022-06-23 20:15:59.772517
# Unit test for constructor of class ISortError
def test_ISortError():
    err = ISortError('test_ISortError')
    err.args
    str(err)


# Generated at 2022-06-23 20:16:01.737294
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    from ast import literal_eval
    test_code = '[1, 2, 3]'
    try:
        literal_eval(test_code)
    except ValueError as e:
        raise LiteralParsingFailure(test_code, e)

# Generated at 2022-06-23 20:16:06.002922
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        x = [1, 2, 'foo']
    except ValueError as e:
        assert LiteralParsingFailure("x", e).code == "x"
        assert LiteralParsingFailure("x", e).original_error is e
    else:
        assert False, "unexpected success"

# Generated at 2022-06-23 20:16:11.545027
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section_error = MissingSection("pylint", "BAD_SECTIONS")
    assert str(missing_section_error) == ("Found pylint import while parsing, but BAD_SECTIONS "
        "was not included in the `sections` setting of your config. Please add it before "
        "continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info.")

# Generated at 2022-06-23 20:16:13.028939
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exc = IntroducedSyntaxErrors("/tmp/dir/file")
    assert exc.file_path == "/tmp/dir/file"

# Generated at 2022-06-23 20:16:16.782925
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("some_code", ValueError("some_error"))
    except LiteralParsingFailure as error:
        assert repr(
            error
        ) == "isort failed to parse the given literal some_code. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of some_error."
        assert error.code == 'some_code'
        assert isinstance(error.original_error, ValueError)
        assert error.original_error.args == ('some_error',)

# Generated at 2022-06-23 20:16:19.112844
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    args = {
        "apodname": "mani",
        "date": "2020-01-21"
    }
    UnsupportedSettings(args)

# Generated at 2022-06-23 20:16:22.942753
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    """Raises the exception"""
    try:
        raise FileSkipped("The file was skipped", "filepath")
    except FileSkipped as error:
        assert error.args[0] == "The file was skipped"
        assert error.file_path == "filepath"


# Generated at 2022-06-23 20:16:27.846548
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    exception = LiteralSortTypeMismatch(str, int)
    assert str(exception).startswith("isort was told to sort a literal of type ")
    assert str(exception).endswith(" but was given a literal of type <class 'str'>.\n")
    assert exception.kind == str
    assert exception.expected_kind == int

# Generated at 2022-06-23 20:16:29.783917
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception = IntroducedSyntaxErrors("/path/to/file")
    assert exception.file_path == "/path/to/file"

# Generated at 2022-06-23 20:16:30.968094
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert ExistingSyntaxErrors("test.py")


# Generated at 2022-06-23 20:16:32.085743
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    test_ExistingSyntaxErrors = ExistingSyntaxErrors()



# Generated at 2022-06-23 20:16:34.554623
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as e:
        raise ExistingSyntaxErrors("/path/test.py")
    assert e.value.file_path == "/path/test.py"


# Generated at 2022-06-23 20:16:36.393383
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist('test')

# Generated at 2022-06-23 20:16:40.999282
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    o = UnsupportedEncoding("C:\\documents\\fake_file.txt")
    assert o.filename == "C:\\documents\\fake_file.txt"
    assert o.__class__.__name__ == 'UnsupportedEncoding'
    assert o.__class__.__bases__[0].__name__ == 'ISortError'


# Generated at 2022-06-23 20:16:42.383978
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings = InvalidSettingsPath('x')
    assert settings.settings_path == 'x'



# Generated at 2022-06-23 20:16:45.217153
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        e = FileSkipComment(file_path="test_file")
    except Exception:
        return False
    assert str(e) == "test_file contains an file skip comment and was skipped."
    assert e.file_path == "test_file"
    assert type(e) == FileSkipComment
    return True

# Generated at 2022-06-23 20:16:56.262641
# Unit test for constructor of class ProfileDoesNotExist

# Generated at 2022-06-23 20:17:00.407168
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "/Users/ben_browne/Desktop/isort/isort/tests/main.py"
    FileSkipComment(file_path)



# Generated at 2022-06-23 20:17:04.009221
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("miss-file")
    except FileSkipComment as e:
        assert e.message.startswith("miss-file")
        assert e.file_path == "miss-file"


# Generated at 2022-06-23 20:17:06.542567
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    test_e = LiteralSortTypeMismatch(str, int)
    assert test_e.kind == str
    assert test_e.expected_kind == int

# Generated at 2022-06-23 20:17:08.749695
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath) as info:
        raise InvalidSettingsPath("Some path")
    assert "Some path does not exist." == str(info.value)



# Generated at 2022-06-23 20:17:11.669396
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors('')
    except IntroducedSyntaxErrors as e:
        assert e.file_path == ''
        assert str(e) == ("isort introduced syntax errors "
                          "when attempting to sort the imports contained within "
                          f"{e.file_path}.")


# Generated at 2022-06-23 20:17:18.606091
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("non-existent-profile")
    except ProfileDoesNotExist as ex:
        assert str(ex) == (
            "Specified profile of non-existent-profile does not exist. "
            "Available profiles: black, django, google, immer, pycharm, "
            "web, wikimedia"
        )
        assert ex.profile == "non-existent-profile"



# Generated at 2022-06-23 20:17:22.752998
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch.__doc__
    assert LiteralSortTypeMismatch.__init__.__doc__
    assert LiteralSortTypeMismatch(1, int).kind == 1
    assert LiteralSortTypeMismatch(1, int).expected_kind == int


# Generated at 2022-06-23 20:17:25.773037
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
	try:
		raise LiteralSortTypeMismatch
	except LiteralSortTypeMismatch as e:
		assert e.kind == 'type'
		assert e.expected_kind == 'type'


# Generated at 2022-06-23 20:17:31.315165
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    expected_message = (
        "isort was told to sort a section of assignments, however the given code:\n\n"
        "a = b, c\n\n"
        "Does not match isort's strict single line formatting requirement for assignment "
        "sorting:\n\n"
        "{variable_name} = {value}\n"
        "{variable_name2} = {value2}\n"
        "...\n\n"
    )
    message = AssignmentsFormatMismatch("a = b, c").args[0]
    assert message == expected_message


# Generated at 2022-06-23 20:17:33.797733
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.txt")
    except UnsupportedEncoding as error:
        print(error)

# Generated at 2022-06-23 20:17:39.326842
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    target = InvalidSettingsPath('/path/not/exist')
    assert target.args == (
        f"isort was told to use the settings_path: /path/not/exist as the base directory or "
        "file that represents the starting point of config file discovery, but it does not "
        "exist.",
    )
    assert target.settings_path == '/path/not/exist'

# Generated at 2022-06-23 20:17:44.634692
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    exception = ProfileDoesNotExist("test")
    assert str(exception) == "Specified profile of test does not exist. Available profiles: black,pep8,google,google_py3,pycharm,junit,gwtrc,twisted,legacy,vendor,cattrs,golint,hug,importmagic,vscode."

# Generated at 2022-06-23 20:17:45.894037
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    path = "mypath"
    except_instance = FileSkipSetting(file_path=path)
    assert path == except_instance.file_path

# Generated at 2022-06-23 20:17:47.123543
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(float, int)



# Generated at 2022-06-23 20:17:50.337758
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    class_ = UnsupportedEncoding
    filename = "foo.py"
    obj = class_("foo.py")
    assert obj.filename == filename
    assert obj.args == (filename,)

# Generated at 2022-06-23 20:17:53.176010
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors(file_path="./test.py")
    assert error.file_path == "./test.py"


# Generated at 2022-06-23 20:17:56.548652
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception = IntroducedSyntaxErrors('test.py')
    assert exception.file_path is 'test.py'
    assert exception.__str__() == "isort introduced syntax errors when attempting to sort the imports contained within test.py."

# Generated at 2022-06-23 20:17:59.465322
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('test')
    except ISortError as ex:
        assert str(ex) == 'test'
        assert ex.args[0] == 'test'



# Generated at 2022-06-23 20:18:04.284619
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        try:
            raise LiteralSortTypeMismatch("float", "string")
        except LiteralSortTypeMismatch as e:
            assert e.kind == "float"
            assert e.expected_kind == "string"
    except AssertionError:
        print("Incorrect values in LiteralSortTypeMismatch constructor")
        assert False
    else:
        assert True

# Generated at 2022-06-23 20:18:09.685871
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    msg = [
        "isort was told to use the settings_path: /tmp/doesnotexist as the base directory or ",
        "file that represents the starting point of config file discovery, but it does not ",
        "exist."
    ]
    assert InvalidSettingsPath("/tmp/doesnotexist").args[0] == ''.join(msg)



# Generated at 2022-06-23 20:18:15.618411
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    expected_msg = "some/path/file.txt was skipped as it's listed in 'skip' setting" \
                   " or matches a glob in 'skip_glob' setting"
    try:
        raise FileSkipSetting("some/path/file.txt")
    except FileSkipSetting as e:
        assert expected_msg == str(e)

# Generated at 2022-06-23 20:18:18.445246
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding(None)
    except UnsupportedEncoding as e:
        assert str(e) == "Unknown or unsupported encoding in None"
        assert e.filename is None


# Generated at 2022-06-23 20:18:22.690137
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    print("Testing constructor of class FormattingPluginDoesNotExist")
    dummy_formatter="dummy_formatter"
    try:
        raise FormattingPluginDoesNotExist(dummy_formatter)
    except FormattingPluginDoesNotExist:
        print("Raised a FormattingPluginDoesNotExist exception")
    else:
        print("This method has no assertion and shall always raise an exception")



# Generated at 2022-06-23 20:18:25.225186
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    skipped=FileSkipped("hello","world")
    assert skipped.message=="hello"
    assert skipped.file_path=="world"

# Generated at 2022-06-23 20:18:26.367980
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist(profile="easy_extension")

# Generated at 2022-06-23 20:18:30.040196
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist(profile='isort_test')
    except ProfileDoesNotExist as e:
        assert e.profile == 'isort_test'
        # assert f"Specified profile of {e.profile} does not exist. Available profiles: {','.join(profiles)}."


# Generated at 2022-06-23 20:18:34.927726
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("foo/bar.py")
    except IntroducedSyntaxErrors as e:
        assert str(e) == (
            "isort introduced syntax errors when attempting to sort the imports contained "
            "within foo/bar.py."
        )
        assert e.file_path == "foo/bar.py"
    else:
        assert False, "Exception not raised"


# Generated at 2022-06-23 20:18:38.742832
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("test")
    except AssignmentsFormatMismatch as e:
        code = e.code
    assert code == "test"

test_AssignmentsFormatMismatch()

# Generated at 2022-06-23 20:18:42.845729
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("formatter")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of formatter does not exist. "
        assert e.formatter == "formatter"



# Generated at 2022-06-23 20:18:44.107728
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("file.py").file_path == "file.py"

# Generated at 2022-06-23 20:18:45.717737
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('profile')
    except ProfileDoesNotExist:
        pass

# Generated at 2022-06-23 20:18:49.675387
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    test_variable = 5
    try:
        ast.literal_eval(test_variable)
    except Exception as e:
        assert type(e) == ValueError
        exception = LiteralParsingFailure(
            code='code', original_error=e
        )
        assert exception.code == 'code'
        assert exception.original_error == e


# Generated at 2022-06-23 20:18:51.503363
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("/test/file").file_path=="/test/file"

# Generated at 2022-06-23 20:18:54.689854
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(TypeError):
        UnsupportedEncoding(filename="utf-8")


# Unit test to check if MissingSection is raised when import_module/section is not defined

# Generated at 2022-06-23 20:18:55.592119
# Unit test for constructor of class ISortError
def test_ISortError():
    assert "isort" in str(ISortError("isort"))




# Generated at 2022-06-23 20:18:56.572314
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    x = ExistingSyntaxErrors("ABC")
    assert x.file_path == "ABC"



# Generated at 2022-06-23 20:18:59.017098
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file = FileSkipped("Test message", "Test file")
    assert file.args == ("Test message",)
    assert file.file_path == "Test file"


# Generated at 2022-06-23 20:19:01.550755
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    import ast
    from ast import literal_eval
    ast.literal_eval('"a')
    try:
        assert literal_eval('"a') == "a"
    except ValueError as e:
        raise LiteralParsingFailure

# Generated at 2022-06-23 20:19:02.924571
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist("my_profile")

# Generated at 2022-06-23 20:19:04.418057
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    UnsupportedEncoding("test")

# Generated at 2022-06-23 20:19:07.043211
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("hello")
    except ProfileDoesNotExist as e:
        assert e.profile == "hello"


# Generated at 2022-06-23 20:19:09.299374
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment('/path/to/file')
    except FileSkipComment as e:
        assert e.file_path == '/path/to/file'

# Generated at 2022-06-23 20:19:17.688960
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # test with one item
    unsupported_settings = { 
        'filename': {'value': "tata", 'source': 'cli'}
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings
    assert str(error) == (
        "isort was provided settings that it doesn't support:\n\n"
        "\t- filename = tata  (source: 'cli')\n\n"
        "For a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )
    # test with multiple items

# Generated at 2022-06-23 20:19:22.100473
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors(file_path=f"test/test_data/test_module.py")
    assert error.__str__() == "isort introduced syntax errors when attempting to sort the imports contained within " \
        "test/test_data/test_module.py."
    assert error.file_path == "test/test_data/test_module.py"



# Generated at 2022-06-23 20:19:28.280275
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    path = "skipped_file.py"
    skip = FileSkipComment(path)
    assert repr(skip) == (
        "FileSkipComment(message="
        f"'{path} contains an file skip comment and was skipped.', "
        "file_path='skipped_file.py')"
    )
    assert skip.file_path == path
    assert skip.args == ("skipped_file.py contains an file skip comment and was skipped.",)

# Generated at 2022-06-23 20:19:37.693300
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    test_setting = {
        "unsupported_settings": {
            "optionA": {
                "value": 1,
                "source": "config"
            },
            "optionB": {
                "value": True,
                "source": "cli"
            }
        }
    }

    us = UnsupportedSettings(**test_setting)

    expected_result = (
        "isort was provided settings that it doesn't support:\n\n"
        "\t- optionA = 1  (source: 'config')\n"
        "\t- optionB = True  (source: 'cli')\n\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )

   

# Generated at 2022-06-23 20:19:39.351736
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection
    except MissingSection as e:
        assert e.section
        assert e.import_module

# Generated at 2022-06-23 20:19:42.017845
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test")
    except ISortError as e:
        assert type(e) == ExistingSyntaxErrors
        assert e.file_path == "test"

# Generated at 2022-06-23 20:19:45.533120
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test."
        assert e.file_path == "test"
    else:
        assert False, "Did not raise exception"



# Generated at 2022-06-23 20:19:47.962494
# Unit test for constructor of class MissingSection
def test_MissingSection():
    error = MissingSection("import_module", "section")
    assert error.import_module == "import_module"
    assert error.section == "section"

# Generated at 2022-06-23 20:19:51.371563
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("/home/me")
    except ExistingSyntaxErrors as err:
        assert err.file_path == "/home/me"
    else:
        # Please see isort - see if the file path is the same as earlier
        assert False


# Generated at 2022-06-23 20:19:53.525959
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file = FileSkipped("message", "file")
    assert (file.message, file.file_path) == ("message", "file")

# Generated at 2022-06-23 20:19:58.078192
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path = "/root/test_file"
    with pytest.raises(InvalidSettingsPath, match=f'isort was told to use the settings_path: {settings_path} as the base directory or file that represents the starting point of config file discovery, but it does not exist.'):
        raise InvalidSettingsPath(settings_path)


# Generated at 2022-06-23 20:20:04.765842
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        import_module = "import_module"
        section = "section"
        raise MissingSection(import_module, section)
    except MissingSection as error:
        assert error.import_module == import_module
        assert error.section == section
        assert repr(error) == (
            "MissingSection('Found %s import while parsing, but %s was not included "
            "in the `sections` setting of your config. Please add it before continuing\n"
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
            "for more info.', 'import_module', 'section')" % (import_module, section,)
        )

# Generated at 2022-06-23 20:20:06.678405
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(1,2)


# Generated at 2022-06-23 20:20:08.108009
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors('abc').file_path == 'abc'

# Generated at 2022-06-23 20:20:11.184365
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("***")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "***"


# Generated at 2022-06-23 20:20:18.808659
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "pandas"
    section = "__future__"
    err = MissingSection(import_module=import_module, section=section)
    actual = "Found {import_module} import while parsing, but {section} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
    expected = actual.format(import_module=import_module, section=section)
    assert err.args[0] == expected

# Generated at 2022-06-23 20:20:21.635071
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("test", "test")
    except MissingSection as e:
        assert e.import_module == "test"
        assert e.section == "test"


# Generated at 2022-06-23 20:20:26.823008
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "/path/to/file"
    error = FileSkipSetting(file_path=file_path)
    assert isinstance(error, FileSkipSetting)
    assert error.file_path == file_path
    assert str(error) == f"{file_path} was skipped as it's listed in 'skip' setting" \
                         " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:20:27.729594
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    FileSkipComment(file_path="")

# Generated at 2022-06-23 20:20:32.329457
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist(profile="test")
    except ProfileDoesNotExist as e:
        assert str(e) == "Specified profile of test does not exist. Available profiles: black,jupyter,pycharm,google,vscode,atom,mypy,pycharm-django,pycharm-kotlin,pycharm-offline,pycharm-online,pycharm-full,pycharm-community,pycharm-professional,isort."
        assert e.profile == "test"

# Generated at 2022-06-23 20:20:34.695413
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("first second")
    except Exception as ex:
        assert str(ex) == "Specified formatting plugin of first second does not exist. "

# Generated at 2022-06-23 20:20:36.399909
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("filename")
    except UnsupportedEncoding as e:
        print(e)


# Generated at 2022-06-23 20:20:38.113271
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("file_path")
    except:
        assert True


# Generated at 2022-06-23 20:20:41.376565
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist) as ex:
        raise FormattingPluginDoesNotExist("formatter")
    assert ex.value.formatter == "formatter"


# Generated at 2022-06-23 20:20:43.561045
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "return_value"
    original_error = ZeroDivisionError()
    LiteralParsingFailure(code, original_error)

# Generated at 2022-06-23 20:20:46.557730
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("foo = bar = 1")
    except AssignmentsFormatMismatch as error:
        msg = str(error)
        assert "foo = bar = 1" in msg



# Generated at 2022-06-23 20:20:49.688534
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {"fake_setting": {"value": "this is a fake setting", "source": "CLI"}}
    raising_settings = UnsupportedSettings(unsupported_settings)
    assert raising_settings.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:20:51.234653
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {"setting1": {"value": 1, "source": "config"}}
    with pytest.raises(UnsupportedSettings):
        raise UnsupportedSettings(settings)

# Generated at 2022-06-23 20:20:57.992481
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    L1 = LiteralParsingFailure('literal', 'error')
    result = f"isort failed to parse the given literal literal. It's important to note "
    result += f"that isort literal sorting only supports simple literals parsable by ast.literal_eval"
    result += f"which gave the exception of error."

    assert repr(L1) == result

# Generated at 2022-06-23 20:21:01.339532
# Unit test for constructor of class MissingSection
def test_MissingSection():
    """
    Unit test for the constructor of MissingSection
    """
    error = MissingSection('foo', 'bar')
    assert error.import_module == 'foo'
    assert error.section == 'bar'


# Generated at 2022-06-23 20:21:03.482936
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "pycharm"
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == formatter

# Generated at 2022-06-23 20:21:06.492225
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # arrange
    f = FileSkipComment(file_path="test.py")

    # assert
    assert 'test.py' == f.file_path
    assert 'test.py contains an file skip comment and was skipped.' == str(f)


# Generated at 2022-06-23 20:21:09.558580
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("my_setting")
    except ProfileDoesNotExist as e:
        assert str(e) == "Specified profile of my_setting does not exist. Available profiles: " + \
                         ",".join(profiles) + "."
        assert e.profile == "my_setting"


# Generated at 2022-06-23 20:21:12.785485
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("error")
    except ISortError as e:
        assert str(e) == "error"

# Generated at 2022-06-23 20:21:13.697299
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped("This file was skipped.", "file_path")

# Generated at 2022-06-23 20:21:20.057501
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # This test file contains non-ascii characters
    # Therefore, the decoding will fail
    with open("../tests/test-unsupported-encoding.txt", "r") as fd:
        try:
            fd.read()
        except UnicodeDecodeError:
            pass
        else:
            raise AssertionError("Expected UnicodeDecodeError")

# Unit tests for exception UnsupportedEncoding
test_UnsupportedEncoding()

# Generated at 2022-06-23 20:21:23.816475
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {'firstOption': 'value1'}
    with pytest.raises(ISortError):
        unsupported_settings = UnsupportedSettings.__init__(settings)
    assert unsupported_settings == {'firstOption': 'value1'}

# Generated at 2022-06-23 20:21:26.281623
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting(file_path="my_path")
    except ISortError as exception:
        assert exception.file_path == "my_path"


# Generated at 2022-06-23 20:21:27.546498
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    x = AssignmentsFormatMismatch("a=2")


# Generated at 2022-06-23 20:21:31.138740
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_error = ProfileDoesNotExist("fake")
    assert profile_error.profile == "fake"
    assert isinstance(profile_error, ISortError)

# Generated at 2022-06-23 20:21:33.506271
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "tests/test_skip_file_comment"
    FileSkipComment(file_path=file_path)

# Generated at 2022-06-23 20:21:36.163549
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing_section = MissingSection('django', 'DJANGO')
    assert issubclass(missing_section.__class__, ISortError)

# Generated at 2022-06-23 20:21:39.477644
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    test_value = InvalidSettingsPath("Hello World")
    assert test_value.settings_path == "Hello World", "Expected to match Hello World"


# Generated at 2022-06-23 20:21:43.200570
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    test_obj = FileSkipComment("__init__.py")
    assert test_obj.file_path == "__init__.py"
    assert test_obj.message == "__init__.py contains an file skip comment and was skipped."



# Generated at 2022-06-23 20:21:46.604807
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    path = "path/to/file"
    exc = FileSkipSetting(path)
    assert str(exc) == f"{path} was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"  # noqa E501
    assert exc.file_path == path

# Generated at 2022-06-23 20:21:48.550330
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # Arrange
    code = 'a = 1\nb = 2\nc = 3'

    # Act
    actual = AssignmentsFormatMismatch(code)

    # Assert
    assert actual.code == code


# Generated at 2022-06-23 20:21:52.602773
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    original_error = Exception("It's a bad value")
    try:
        raise LiteralParsingFailure("value", original_error)
    except LiteralParsingFailure as e:
        assert e.code == "value"
        assert e.original_error == original_error

# Generated at 2022-06-23 20:21:54.567794
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    """Test constructor of class ExistingSyntaxErrors"""
    error = ExistingSyntaxErrors("foo")
    assert error.file_path == "foo"

# Generated at 2022-06-23 20:21:57.772514
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "test_ExistingSyntaxErrors"
    test_obj = ExistingSyntaxErrors(file_path)
    assert test_obj.file_path == file_path


# Generated at 2022-06-23 20:22:01.447619
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=int, expected_kind=list)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == list


# Generated at 2022-06-23 20:22:03.485846
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert 'Specified formatting plugin of test does not exist.' in str(FormattingPluginDoesNotExist('test'))


# Generated at 2022-06-23 20:22:07.790910
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    kind = object
    expected_kind = int
    exc = LiteralSortTypeMismatch(kind, expected_kind)
    assert str(exc) == "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'object'>."
    assert exc.kind is kind
    assert exc.expected_kind is expected_kind


# Generated at 2022-06-23 20:22:09.826709
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch):
        LiteralSortTypeMismatch(kind=1, expected_kind=int)


# Generated at 2022-06-23 20:22:13.172458
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    """Unit test for constructor of class AssignmentsFormatMismatch"""
    code = "name = 'Sriharsha'\n" \
           "address = 'Aeris\'s house'"
    err = AssignmentsFormatMismatch(code)
    assert err.code == code



# Generated at 2022-06-23 20:22:15.829728
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
  try:
    raise UnsupportedEncoding('file1.txt')
  except UnsupportedEncoding as error:
    assert error.filename == 'file1.txt'


# Generated at 2022-06-23 20:22:19.470584
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("")
    except ProfileDoesNotExist as e:
        error = str(e)
        print(error)
        assert e.profile is None
        assert error.startswith("Specified profile of  does not exist")


# Generated at 2022-06-23 20:22:23.549051
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    x = FileSkipSetting('file1')
    assert x.file_path == 'file1'
    assert x.message == 'file1 was skipped as it\'s listed in \'skip\' setting' \
                        ' or matches a glob in \'skip_glob\' setting'

# Generated at 2022-06-23 20:22:26.868657
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = '123'
    original_error = 'error'

    literal_parsing_failure = LiteralParsingFailure(code, original_error)

    assert literal_parsing_failure.code == code
    assert literal_parsing_failure.original_error == original_error


# Generated at 2022-06-23 20:22:28.103032
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    obj=LiteralSortTypeMismatch(str, int)

# Generated at 2022-06-23 20:22:29.993655
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors('example.txt')
    except ExistingSyntaxErrors as ese:
        assert ese.file_path == 'example.txt'

# Generated at 2022-06-23 20:22:32.913249
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "/path/to/my/file"
    error = FileSkipSetting(file_path)
    assert error.message == f"{file_path} was skipped as it's listed in 'skip' setting"
    assert error.file_path == file_path