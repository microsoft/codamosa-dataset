

# Generated at 2022-06-23 20:12:32.905221
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist("")

# Generated at 2022-06-23 20:12:35.815730
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    expected_error_message = "isort was told to sort imports within code that contains syntax errors: a.py."
    assert expected_error_message == str(ExistingSyntaxErrors("a.py"))

# Generated at 2022-06-23 20:12:37.663117
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch
    except LiteralSortTypeMismatch as error:
        assert error.kind is None
        assert error.expected_kind is None
    else:
        assert False

# Generated at 2022-06-23 20:12:40.927203
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath) as excinfo:
        raise InvalidSettingsPath("settings_path")
    assert excinfo.value.settings_path == "settings_path"



# Generated at 2022-06-23 20:12:50.565624
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    message = "f:\\PYTHON35-32\\Lib\\site-packages\\setuptools\\extern\\_bundle\\tests\\__init__.py  was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    fileSkipSetting = FileSkipSetting('f:\\PYTHON35-32\\Lib\\site-packages\\setuptools\\extern\\_bundle\\tests\\__init__.py')
    assert str(fileSkipSetting) == message

# Generated at 2022-06-23 20:12:59.788287
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    error = UnsupportedSettings({'key': {'value': 'value', 'source': 'source'}})
    assert error.unsupported_settings == {'key': {'value': 'value', 'source': 'source'}}
    assert error.args == ('isort was provided settings that it doesn\'t support:\n\n\t- key = value  (source: \'source\')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n',)

# Generated at 2022-06-23 20:13:01.853057
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    
    # Verify construction without exception
    inst = UnsupportedEncoding("test")



# Generated at 2022-06-23 20:13:06.306624
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('test_formatter')
    except FormattingPluginDoesNotExist as E:
        assert E.formatter == 'test_formatter'


# Generated at 2022-06-23 20:13:09.943072
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    m = "This is a message"
    f = "Test.py"
    d = {"message": m, "file_path": f}
    fs = FileSkipped(m, f)
    assert vars(fs) == d


# Generated at 2022-06-23 20:13:13.824464
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "path\\file.py"
    a = FileSkipSetting(file_path)
    assert a.args[0] == f"{file_path} was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"
    assert a.file_path == file_path


# Generated at 2022-06-23 20:13:15.773968
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {"name": "value"}
    exc = UnsupportedSettings(settings=settings)
    assert "name = value" in str(exc)



# Generated at 2022-06-23 20:13:17.866530
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/home/user")
    except InvalidSettingsPath:
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:13:19.829178
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except ISortError:
        print('Test for ISortError() constructor passed')



# Generated at 2022-06-23 20:13:22.478105
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert IntroducedSyntaxErrors("file/with/error.py").file_path == "file/with/error.py"

# Generated at 2022-06-23 20:13:25.045405
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('test')
    except UnsupportedEncoding as e:
        assert str(e) == 'Unknown or unsupported encoding in test'

# Generated at 2022-06-23 20:13:25.642278
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert True

# Generated at 2022-06-23 20:13:26.467083
# Unit test for constructor of class MissingSection
def test_MissingSection():
    #Normal
    assert MissingSection("name", "section")

# Generated at 2022-06-23 20:13:31.980044
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = '1 + 1'
    # Unit test for constructor of class AssignmentsFormatMismatch
    def test_AssignmentsFormatMismatch():
        code = '''
        1 + 1
        '''
        err = AssignmentsFormatMismatch(code)
        assert err.code == code
        assert str(err).startswith('isort was told to sort a section of assignments')
        assert 'literal of type int' in str(err)
        assert 'isort literal sorting' in str(err)


if __name__ == "__main__":
    # code here
    test_AssignmentsFormatMismatch()

# Generated at 2022-06-23 20:13:35.040103
# Unit test for constructor of class InvalidSettingsPath

# Generated at 2022-06-23 20:13:39.065598
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist) as exc_info:
        raise FormattingPluginDoesNotExist("test")
    assert exc_info.value.formatter == 'test'
    assert str(exc_info.value) == "Specified formatting plugin of test does not exist. "


# Generated at 2022-06-23 20:13:41.741603
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch('a=b\nc = d\ne = a')
    except AssignmentsFormatMismatch:
        pass

# Generated at 2022-06-23 20:13:44.551687
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of test does not exist. "
        assert e.formatter == "test"

# Generated at 2022-06-23 20:13:46.138365
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(int, float).kind == int

# Generated at 2022-06-23 20:13:50.793118
# Unit test for constructor of class MissingSection
def test_MissingSection():
    missing = MissingSection("foo", "bar")
    assert missing.__str__() == "Found foo import while parsing, but bar was not included in the `sections`" + \
        " setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-" + \
        "ordering for more info."



# Generated at 2022-06-23 20:13:59.245789
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
	letters = set('abcdefghijklmnopqrstuvwxyz')
	alphanumeric = set('0123456789abcdefghijklmnopqrstuvwxyz')
	symbols = set(r""" !"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~""")
	message = set(r""" !"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~""")
	file_path = set('abcdefghijklmnopqrstuvwxyz')

# Generated at 2022-06-23 20:14:03.650573
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
      raise FileSkipComment('tests/test_skipped_file.py')
    except FileSkipped as e:
      assert e.message == 'tests/test_skipped_file.py contains an file skip comment and was skipped.'
      assert e.file_path == 'tests/test_skipped_file.py'

# Generated at 2022-06-23 20:14:06.334176
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "test_path"
    test_obj = FileSkipComment(file_path)
    assert test_obj.file_path == file_path

# Generated at 2022-06-23 20:14:12.114464
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """
    Show that questionable settings get correctly formatted.
    """

    exception = UnsupportedSettings({"bogus": {"value": "useless", "source": "my config"}})
    assert exception.__str__() == (
        "isort was provided settings that it doesn't support:\n"
        "\t- bogus = useless  (source: 'my config')\n\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )

# Generated at 2022-06-23 20:14:17.083054
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """test for constructor of class UnsupportedSettings"""
    unsupported_settings = {
        "unspported_option": {"value": "some value", "source": "file"}
    }
    try:
        raise UnsupportedSettings(unsupported_settings)
    except UnsupportedSettings as e:
        assert e.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:14:20.559419
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    #FormattingPluginDoesNotExist constructor
    assert FormattingPluginDoesNotExist('formatter').formatter == 'formatter'

# Generated at 2022-06-23 20:14:23.265178
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    obj = FileSkipped("Message","Test")
    assert obj.message == "Message"
    assert obj.file_path == "Test"


# Generated at 2022-06-23 20:14:27.595489
# Unit test for constructor of class MissingSection
def test_MissingSection():
    ms1 = MissingSection('A', 'B')
    assert ms1.import_module == 'A'
    assert ms1.section == 'B'


# Generated at 2022-06-23 20:14:31.438325
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    try:
        unsupported_settings = {"imports_as_name": {"foo": "bar"}}
        raise UnsupportedSettings(unsupported_settings)
    except UnsupportedSettings as e:
        assert e.unsupported_settings["imports_as_name"]["foo"] == "bar"
        print(e)

# Generated at 2022-06-23 20:14:32.999456
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
  a = AssignmentsFormatMismatch('abc')
  assert a

# Generated at 2022-06-23 20:14:34.508947
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    FormattingPluginDoesNotExist("not_exist_class")

# Generated at 2022-06-23 20:14:37.679713
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fs = FileSkipSetting("test.py")
    assert fs.file_path == "test.py"
    assert str(fs) == "test.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:14:38.884717
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    UnsupportedEncoding('__init__.py')


# Generated at 2022-06-23 20:14:45.291879
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert issubclass(e.__class__, ISortError)
        assert isinstance(e, ISortError)
        assert isinstance(e, Exception)
        assert isinstance(e, BaseException)
        assert "Found import_module import" in str(e)
        assert "section" in str(e)
# end test_MissingSection


# Generated at 2022-06-23 20:14:47.557417
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    result = ExistingSyntaxErrors('/path/to/file.py')
    assert str(result) == '/path/to/file.py'



# Generated at 2022-06-23 20:14:49.897884
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        int("abc")
    except Exception as e:
        exception = LiteralParsingFailure("abc", e)
        assert exception.code == "abc"
        assert exception.original_error == e

# Generated at 2022-06-23 20:14:59.361655
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    import ast

    class RandomException(Exception):
        """Hello"""

    class TestLiteralParsingFailure(LiteralParsingFailure):
        """LiteralParsingFailure"""

        def __init__(self, code: str, original_error: RandomException):
            super().__init__(code, original_error)

    with pytest.raises(TestLiteralParsingFailure) as error:
        try:
            ast.literal_eval("{'a': 0")
        except SyntaxError as error:
            raise TestLiteralParsingFailure("{'a': 0", error)

    expected = TestLiteralParsingFailure.__doc__
    assert expected == error.value.__doc__
    assert issubclass(TestLiteralParsingFailure, ISortError)



# Generated at 2022-06-23 20:15:00.575678
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'test/test_file_skip_comment.py'
    FileSkipComment(file_path)

# Generated at 2022-06-23 20:15:10.688765
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 1\nb = 2"
    exception = AssignmentsFormatMismatch(code)
    assert str(exception) == "isort was told to sort a section of assignments, however the given code:\n\n{}\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n".format(code)
    code = "a = 1\nb = 2\nc = 3"
    exception = AssignmentsFormatMismatch(code)

# Generated at 2022-06-23 20:15:17.099752
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("foo", "bar")  # type: ignore
    except MissingSection as e:
        assert e.import_module == "foo"
        assert e.section == "bar"
        assert e.args[0] == "Found foo import while parsing, but bar was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        assert e.args[1] == "foo"
        assert e.args[2] == "bar"

# Generated at 2022-06-23 20:15:19.004917
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped("Message", "path")


# Generated at 2022-06-23 20:15:27.527391
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # Arrange
    file_path = 'test/file_path'
    expected_msg = '{} was skipped as it\'s listed in \'skip\' setting'.format(file_path) + \
                   ' or matches a glob in \'skip_glob\' setting'

    # Act
    exception = FileSkipSetting(file_path)

    # Assert
    assert hasattr(exception, 'file_path')
    assert hasattr(exception, '__str__')
    assert hasattr(exception, 'args')
    assert hasattr(exception, '__init__')
    assert exception.__str__() == expected_msg
    assert exception.file_path == file_path



# Generated at 2022-06-23 20:15:35.754340
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    settings_path = "./file_does_not_exist.py"
    try:
        raise InvalidSettingsPath(settings_path)
    except InvalidSettingsPath as e:
        assert e.settings_path == settings_path
        assert str(e) == f"isort was told to use the settings_path: {settings_path} as the base directory or " \
                         "file that represents the starting point of config file discovery, but it does not " \
                         "exist."


# Generated at 2022-06-23 20:15:40.060209
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    obj = LiteralParsingFailure(code = "test_code", original_error = "error")
    s = str(obj)
    assert s == "isort failed to parse the given literal test_code. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of error."


# Generated at 2022-06-23 20:15:44.989256
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # This test fails isort on the lines that use isortError, because the methods don't exist.
    # Commenting out the test while issue #8216 is unresolved.
    #
    # from isort.settings import config
    # if not config.running_under_test:
    #     raise isortError("This is only for testing isortError")

    # Make sure it does not raise an error itself
    InvalidSettingsPath("test")
    # Make sure it does not raise an error with a file
    InvalidSettingsPath("/file.py")
    # Make sure it does not raise an error with a directory
    InvalidSettingsPath("/dir")

# Generated at 2022-06-23 20:15:47.629238
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    new_LiteralSortTypeMismatch = LiteralSortTypeMismatch(1, "")
    assert new_LiteralSortTypeMismatch.kind == 1
    assert new_LiteralSortTypeMismatch.expected_kind == ""



# Generated at 2022-06-23 20:15:51.666042
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "file"
    exception = FileSkipComment(file_path)
    assert exception.file_path == file_path
    assert str(exception) == f"{file_path} contains an file skip comment and was skipped."

# Generated at 2022-06-23 20:15:53.027686
# Unit test for constructor of class ISortError
def test_ISortError():
    # pylint: disable=unused-variable
    ISortError()

# Generated at 2022-06-23 20:15:58.536866
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # Example of Constructor
    try:
        test_kind = str
        test_expected_kind = list
        raise LiteralSortTypeMismatch(test_kind, test_expected_kind)

    except LiteralSortTypeMismatch as myerror:
        assert myerror.kind == test_kind
        assert myerror.expected_kind == test_expected_kind


# Generated at 2022-06-23 20:16:03.007017
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    path = "./test/unsupported-encoding.txt"
    expected = "Unknown or unsupported encoding in ./test/unsupported-encoding.txt"
    assert expected == str(UnsupportedEncoding(path))

# Generated at 2022-06-23 20:16:07.179851
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    class FileSkipCommentTest(FileSkipComment):
        def __init__(self, file_path: str):
            super().__init__(file_path=file_path)

    test_comment = FileSkipCommentTest('test-file')
    assert test_comment.file_path == 'test-file'

# Generated at 2022-06-23 20:16:11.817298
# Unit test for constructor of class ISortError
def test_ISortError():
    def check_constructor(instance, message):
        assert instance.msg == message
        assert str(instance) == message

    check_constructor(ISortError("my message!"), "my message!")



# Generated at 2022-06-23 20:16:15.053810
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert str(ExistingSyntaxErrors(file_path="test")) == "isort was told to sort imports " \
                                                          "within code that contains syntax errors: test."



# Generated at 2022-06-23 20:16:18.421561
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    plugin_name = "plugin"
    try:
        raise FormattingPluginDoesNotExist(plugin_name)
    except FormattingPluginDoesNotExist as ex:
        assert ex.formatter == "plugin"

# Generated at 2022-06-23 20:16:22.815308
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    error = LiteralSortTypeMismatch(str, int)
    assert str(error) == "isort was told to sort a literal of type <class 'int'> but was given " \
                         "a literal of type <class 'str'>."
    assert error.kind == str
    assert error.expected_kind == int



# Generated at 2022-06-23 20:16:25.035176
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist):
        raise FormattingPluginDoesNotExist("tests")

# Generated at 2022-06-23 20:16:27.714548
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    obj = UnsupportedEncoding('filename')
    assert obj.filename == 'filename'
    assert obj.__class__.__name__ == 'UnsupportedEncoding'


# Generated at 2022-06-23 20:16:30.791197
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    e = ExistingSyntaxErrors('a.py')
    assert e.file_path == 'a.py'

# Generated at 2022-06-23 20:16:32.618593
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    exception = FileSkipComment("information")
    assert exception.file_path == "information"

# Generated at 2022-06-23 20:16:38.701871
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("bar")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of bar does not exist. "
        assert e.formatter == "bar"
    try:
        raise FormattingPluginDoesNotExist("baz")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of baz does not exist. "
        assert e.formatter == "baz"

# Generated at 2022-06-23 20:16:42.154157
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fs = FileSkipSetting('/test.py')
    assert fs.file_path == '/test.py'
    assert str(fs) == "/test.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-23 20:16:42.977739
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection("a", "b").__init__("c", "d") == None

# Generated at 2022-06-23 20:16:45.245116
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection("import_module", "section")


# Generated at 2022-06-23 20:16:46.873341
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    LiteralSortTypeMismatch(type(""), type(""))

# Generated at 2022-06-23 20:16:48.254816
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch('this-is-error')


# Generated at 2022-06-23 20:16:51.283035
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert (
        FormattingPluginDoesNotExist("test").formatter is "test"
    ) is True, "Testing exception handling"



# Generated at 2022-06-23 20:16:55.227606
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # Constructor is called
    exc = UnsupportedSettings({'line_length': {'value': 2, 'source': 'runtime'}})

    # Expected results
    assert exc.unsupported_settings == {'line_length': {'value': 2, 'source': 'runtime'}}

# Generated at 2022-06-23 20:17:02.671786
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("module", "section")
    except MissingSection as m:
        assert m.import_module == "module"
        assert m.section == "section"
        assert str(m) == "Found module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:17:04.725604
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "./tests/sample_files/string_encoding_error.py"
    assert UnsupportedEncoding(filename).filename == filename

# Generated at 2022-06-23 20:17:09.738968
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test_file.py")
    except IntroducedSyntaxErrors as err:
        assert repr(err) == 'IntroducedSyntaxErrors("test_file.py")'
        assert str(err) == (
            "isort introduced syntax errors when attempting to sort the imports "
            "contained within test_file.py."
        )
        assert err.file_path == "test_file.py"

# Generated at 2022-06-23 20:17:10.914428
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('use_black')
    except ProfileDoesNotExist:
        pass

# Generated at 2022-06-23 20:17:13.830460
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding(filename="test.py")
    except UnsupportedEncoding as e:
        assert str(e) == "Unknown or unsupported encoding in test.py"
        assert e.filename == "test.py"


# Generated at 2022-06-23 20:17:18.449829
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    """Raises:
    ISortError: if the passed settings path does not exist
    """
    isort_error=InvalidSettingsPath("settings_path")
    assert type(isort_error) == InvalidSettingsPath


# Generated at 2022-06-23 20:17:24.443848
# Unit test for constructor of class MissingSection
def test_MissingSection():
    
    # use import_module and section to call constructor
    obj = MissingSection("os", "IMPORTS")

    # get the raised exception obj.__str__()
    str = obj.__str__()

    # assert if str matches the expected string
    assert str == "Found os import while parsing, but IMPORTS was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:17:25.009940
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    UnsupportedSettings({})

# Generated at 2022-06-23 20:17:28.179380
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    """Test for constructor of class ProfileDoesNotExist"""
    assert ProfileDoesNotExist("asdf").profile == "asdf"
    assert ProfileDoesNotExist("asdf").args[0] == "Specified profile of asdf does not exist. Available profiles: "

# Generated at 2022-06-23 20:17:30.389394
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("path/to/file.py").filename == "path/to/file.py"

# Generated at 2022-06-23 20:17:32.786264
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    ex = FileSkipComment(file_path='./file_name')
    assert ex.file_path == './file_name'
    ex = FileSkipComment(file_path='../file_name')
    assert ex.file_path == '../file_name'


# Generated at 2022-06-23 20:17:37.600910
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {"key1": {"value": "value1", "source": "source1"}, "key2": {"value": "value2", "source": "source2"}}
    with pytest.raises(UnsupportedSettings):
        # pylint: disable=unexpected-keyword-arg
        UnsupportedSettings(settings)
        

# Generated at 2022-06-23 20:17:42.982951
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    with pytest.raises(UnsupportedSettings) as err:
        bad_params = {"bad_param": {"value": "bad", "source": "bad"}}
        UnsupportedSettings(bad_params)
    assert "bad_param = bad  (source: 'bad')" in str(err)

# Generated at 2022-06-23 20:17:45.289077
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        print(e.import_module)


# Generated at 2022-06-23 20:17:48.511407
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():

    # Create a dummy message and error object
    code = "ab=1\nac=2\nb=2"
    exception = AssignmentsFormatMismatch(code)

    # Check that the class instance was created correctly
    assert exception.code == code



# Generated at 2022-06-23 20:17:51.108155
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("code", "original_error")
    except LiteralParsingFailure as e:
        assert e.code == "code"
        assert e.original_error == "original_error"


# Generated at 2022-06-23 20:17:53.577447
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch):
        raise LiteralSortTypeMismatch(kind=str, expected_kind=int)

# Generated at 2022-06-23 20:17:58.822019
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection("a", "b").args[0] == ("Found a import while parsing, "
                                               "but b was not included in the "
                                               "`sections` setting of your "
                                               "config. Please add it before "
                                               "continuing\nSee "
                                               "https://pycqa.github.io/isort/#custom-sections-and-ordering "
                                               "for more info.")

# Generated at 2022-06-23 20:17:59.335820
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    print("hello")

# Generated at 2022-06-23 20:18:00.331361
# Unit test for constructor of class ISortError
def test_ISortError():
    assert ISortError()


# Generated at 2022-06-23 20:18:00.860227
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    FileSkipSetting('test')

# Generated at 2022-06-23 20:18:03.559866
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    assert (
        IntroducedSyntaxErrors("my_file.py")
        == "isort introduced syntax errors when attempting to sort the imports contained within my_file.py."
    )


# Generated at 2022-06-23 20:18:06.444763
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fileSkipped = FileSkipped("message", "file_path")
    assert fileSkipped.message == "message"
    assert fileSkipped.file_path == "file_path"

# Generated at 2022-06-23 20:18:08.445186
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError as e:
        assert True


# Generated at 2022-06-23 20:18:09.669103
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(Exception):
        raise ISortError("test")


# Generated at 2022-06-23 20:18:14.760971
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("file_path")
    except ISortError as ex:
        assert str(ex) == "isort introduced syntax errors when attempting to sort the imports contained within file_path."
        assert ex.file_path == "file_path"


# Generated at 2022-06-23 20:18:20.417531
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "import_module"
    section = "section"
    message = (
        f"Found {import_module} import while parsing, but {section} was not included "
        "in the `sections` setting of your config. Please add it before continuing\n"
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
        "for more info."
    )
    assert message == MissingSection(import_module, section).__str__()

# Generated at 2022-06-23 20:18:22.254137
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding('test.py')
    assert error.filename == 'test.py'


# Generated at 2022-06-23 20:18:25.881904
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("TestFormatter")
    except Exception as ex:
        assert ex.args[0] == "Specified formatting plugin of TestFormatter does not exist. "



# Generated at 2022-06-23 20:18:30.156220
# Unit test for constructor of class MissingSection
def test_MissingSection():
    section = "s"
    import_module = "m"
    mSection = MissingSection(import_module, section)
    if mSection.args[0] != "Found m import while parsing, but s was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.":
        raise Exception('TestFailed')


# Generated at 2022-06-23 20:18:32.430764
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(
        kind=str, expected_kind=list
    ).message == "isort was told to sort a literal of type <class 'list'> but was given a literal of type <class 'str'>."

LiteralSortTypeMismatch(kind=str, expected_kind=list)

# Generated at 2022-06-23 20:18:34.668724
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    ExistingSyntaxErrors("/home/user/test.txt")

# Generated at 2022-06-23 20:18:36.998383
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("an error message")
    except:
        assert True
        return
    assert False


# Generated at 2022-06-23 20:18:39.471086
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except Exception:
        assert True
    else:
        assert True


# Generated at 2022-06-23 20:18:42.800779
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    exception = LiteralSortTypeMismatch(kind=type(1), expected_kind=type(1))
    assert exception.kind == type(1)
    assert exception.expected_kind == type(1)

# Generated at 2022-06-23 20:18:50.749176
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("variable_name1 = value\nvariable_name2 = value2\n")
    except AssignmentsFormatMismatch as error:
        assert str(error) == (
            "isort was told to sort a section of assignments, however the given code:\n\n"
            "variable_name1 = value\n"
            "variable_name2 = value2\n\n"
            "Does not match isort's strict single line formatting requirement for"
            " assignment sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n"
        )
        assert error.code == "variable_name1 = value\nvariable_name2 = value2\n"

# Generated at 2022-06-23 20:18:55.559324
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    literal_parsing_failure = LiteralParsingFailure("None", Exception("Error"))
    assert literal_parsing_failure.code == "None"
    assert literal_parsing_failure.original_error.args[0] == "Error"

test_LiteralParsingFailure()


# Generated at 2022-06-23 20:19:03.781036
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(list, dict)
    except LiteralSortTypeMismatch as e:
        assert str(e) == (
            "isort was told to sort a literal of type <class 'dict'> but was given "
            "a literal of type <class 'list'>"
        )
        assert repr(type(e)) == "<class 'isort.exceptions.LiteralSortTypeMismatch'>"
        assert e.kind == list
        assert e.expected_kind == dict

# Generated at 2022-06-23 20:19:08.223669
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = 'test_code'
    original_error = Exception('test_error')
    literal_parsing_failure = LiteralParsingFailure(code, original_error)
    assert literal_parsing_failure.code == code
    assert literal_parsing_failure.original_error == original_error


# Generated at 2022-06-23 20:19:11.561991
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'test_path'
    exp = "test_path was skipped as it's listed in 'skip' setting or matches a glob in "
    exp += "'skip_glob' setting"
    an = FileSkipSetting(file_path).args[0]
    assert an == exp

# Generated at 2022-06-23 20:19:17.375283
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class TestException(Exception):
        pass
    code = "testcode"
    original_error = TestException("testmessage")
    error = LiteralParsingFailure(code, original_error)
    assert str(error) == "isort failed to parse the given literal testcode. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of testmessage."
    assert error.code == code
    assert error.original_error == original_error


# Generated at 2022-06-23 20:19:20.786209
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_skip_comment = FileSkipComment('test.py')
    assert isinstance(file_skip_comment, FileSkipComment)
    assert file_skip_comment.message == 'test.py contains an file skip comment and was skipped.'
    assert file_skip_comment.file_path == 'test.py'


# Generated at 2022-06-23 20:19:23.043097
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/blah")
    except InvalidSettingsPath as exception:
        assert "/blah" == exception.settings_path, "Expected /blah"

# Generated at 2022-06-23 20:19:25.854178
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    string = "a = 0\n"
    try:
        raise AssignmentsFormatMismatch(string)
    except AssignmentsFormatMismatch as e:
        assert e.code == string


# Generated at 2022-06-23 20:19:27.332458
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist("test")


# Generated at 2022-06-23 20:19:28.774129
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    a = LiteralSortTypeMismatch(type, str)
    assert a.kind == type
    assert a.expected_kind == str

# Generated at 2022-06-23 20:19:29.769349
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    from .isort import FileSkipComment
    FileSkipComment("file_name") # noqa

# Generated at 2022-06-23 20:19:36.159857
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert repr(e) == "Found import_module import while parsing, but section was not included " \
                       "in the `sections` setting of your config. Please add it before continuing\n" \
                       "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                       "for more info."



# Generated at 2022-06-23 20:19:38.590199
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == ""


# Generated at 2022-06-23 20:19:41.946195
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 1, b = 2"
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert e.code == code
    else:
        assert False

# Generated at 2022-06-23 20:19:45.638736
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('ascii')
    except UnsupportedEncoding as error:
        assert str(error) == 'Unknown or unsupported encoding in ascii'

# Generated at 2022-06-23 20:19:47.531708
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    with pytest.raises(UnsupportedEncoding):
        UnsupportedEncoding("file.txt")

# Generated at 2022-06-23 20:19:49.675522
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("File.py")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "File.py"



# Generated at 2022-06-23 20:19:51.510504
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    objError = ExistingSyntaxErrors('file_path.py')
    assert objError.file_path == 'file_path.py'

# Generated at 2022-06-23 20:19:55.453851
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped = FileSkipped("isort skipped {file_path}\n", file_path="hello")
    assert file_skipped.args == ("isort skipped {file_path}\n",)
    assert file_skipped.file_path == "hello"

# Generated at 2022-06-23 20:19:57.132956
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(ISortError):
        raise ISortError("Test")


# Generated at 2022-06-23 20:19:59.130609
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("text.txt")
    except UnsupportedEncoding as e:
        assert e.filename == "text.txt"

# Generated at 2022-06-23 20:20:00.995568
# Unit test for constructor of class ISortError
def test_ISortError():
    isortError = ISortError("IsortError")
    assert isortError.args[0] == "IsortError"


# Generated at 2022-06-23 20:20:03.917948
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("file_path")
    except FileSkipped as e1:
        assert e1.message == "file_path contains an file skip comment and was skipped."
        assert e1.file_path == "file_path"



# Generated at 2022-06-23 20:20:07.529105
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    e = FormattingPluginDoesNotExist('formatter')
    assert str(e) == "Specified formatting plugin of formatter does not exist. "

# Generated at 2022-06-23 20:20:10.562621
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_skipped = FileSkipped("message", "filepath")
    assert file_skipped.message == "message"
    assert file_skipped.file_path == "filepath"

# Generated at 2022-06-23 20:20:16.948368
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    exception = ProfileDoesNotExist(
        profile="this_profile_does_not_exist"
    )
    assert str(exception) == "Specified profile of this_profile_does_not_exist does not exist. Available profiles: black,pep8,google,pycharm,vscode,mypy,pytest,junit,agate,yapf,bar,foo."
    assert exception.profile == "this_profile_does_not_exist"

# Generated at 2022-06-23 20:20:18.728661
# Unit test for constructor of class ISortError
def test_ISortError():
    e = ISortError("Test")
    assert type(e.args) == tuple
    assert e.args[0] == "Test"
    assert e.args[0] == str(e)


# Generated at 2022-06-23 20:20:22.225214
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    x = LiteralSortTypeMismatch(int, float)
    assert x.message == "isort was told to sort a literal of type float but was given a literal of type int."
    assert x.kind == int
    assert x.expected_kind == float


# Generated at 2022-06-23 20:20:26.226527
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("formatter")
    except FormattingPluginDoesNotExist as e:
        assert "Specified formatting plugin of formatter does not exist." == str(e)
        assert "formatter" == e.formatter


# Generated at 2022-06-23 20:20:28.055431
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    a = FileSkipComment("/home/user/Desktop/a.py")
    assert a.file_path == '/home/user/Desktop/a.py'

# Generated at 2022-06-23 20:20:32.894344
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = 'file_path'
    message = "message"
    assert FileSkipComment(file_path).args[0] == f"{file_path} contains an file skip comment and was skipped."
    assert FileSkipComment(file_path).file_path == file_path
    assert FileSkipComment('', message).args[0] == message


# Generated at 2022-06-23 20:20:35.327735
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    msg = "This is an error message."
    path = "file_path"
    error = FileSkipped(msg,path)
    assert error.file_path == path
    assert error.msg == msg

# Generated at 2022-06-23 20:20:38.448300
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist) as ex:
        raise FormattingPluginDoesNotExist("formatter")
    assert str(ex.value) == "Specified formatting plugin of formatter does not exist."

# Generated at 2022-06-23 20:20:40.442415
# Unit test for constructor of class ISortError
def test_ISortError():
    """Function to test the constructor of class ISortError"""
    assert ISortError("Test")

# Generated at 2022-06-23 20:20:41.912896
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    class_instance = LiteralSortTypeMismatch(kind=list, expected_kind=tuple)
    assert class_instance.kind == list
    assert class_instance.expected_kind == tuple

# Generated at 2022-06-23 20:20:44.256428
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = "test"
    file_path = "test_file"
    file_skipped = FileSkipped(message, file_path)
    assert file_skipped.message == message
    assert file_skipped.file_path == file_path

# Generated at 2022-06-23 20:20:46.758740
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "test.txt"
    try:
        syntax_error = ExistingSyntaxErrors(file_path)
        assert syntax_error is not None
    except ISortError as e:
        assert e.file_path == file_path


# Generated at 2022-06-23 20:20:49.443166
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist(profile='abc')
    except ProfileDoesNotExist as e:
        assert 'abc' in str(e)
        assert e.profile == 'abc'



# Generated at 2022-06-23 20:20:51.219146
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = 'test/file/path.py'
    assert FileSkipSetting(file_path).file_path == file_path

# Generated at 2022-06-23 20:20:58.743778
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    a = AssignmentsFormatMismatch("var1 = 1\nvar2 = 2\nvar3 = 3")
    assert a.code == "var1 = 1\nvar2 = 2\nvar3 = 3"

assert (
    AssignmentsFormatMismatch.__doc__
    == "Raised when isort is told to sort assignments but the format of the assignment section\ndoesn't match isort's expectation."
)

# Generated at 2022-06-23 20:21:04.940965
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("CODE", "Error")

    except LiteralParsingFailure as e:
        print("========= Exception raised ========= ")
        assert e.code == "CODE"
        assert isinstance(e.original_error, str)
        assert str(e) == "isort failed to parse the given literal CODE. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of Error."



# Generated at 2022-06-23 20:21:06.821021
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("qwerty")
    except FormattingPluginDoesNotExist as error:
        assert str(error) == "Specified formatting plugin of qwerty does not exist. "
        return True
    else:
        return False

# Generated at 2022-06-23 20:21:09.305085
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('mymodule', 'mysection')
    except MissingSection as error:
        assert error.args[0] == f"Found mymodule import while parsing, but mysection was not included " \
            f"in the `sections` setting of your config. Please add it before continuing\n" \
            f"See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
            f"for more info."

# Generated at 2022-06-23 20:21:11.802962
# Unit test for constructor of class MissingSection
def test_MissingSection():
    MissingSection.__init__(MissingSection, "random_import", "optional_section")

# Generated at 2022-06-23 20:21:15.237397
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile_name:str="notprofile"
    try:
        raise ProfileDoesNotExist(profile_name)
    except ProfileDoesNotExist as e:
        assert e.profile=="notprofile"


# Generated at 2022-06-23 20:21:17.181133
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    lstm = LiteralSortTypeMismatch()
    assert "isort" in lstm.__str__()

# Generated at 2022-06-23 20:21:18.493676
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors("test_exception.py")
    assert error.file_path == "test_exception.py"

# Generated at 2022-06-23 20:21:20.586560
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    lpf = LiteralParsingFailure("code", "Exception")
    assert lpf.code == "code"
    assert lpf.original_error == "Exception"

# Generated at 2022-06-23 20:21:22.020616
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath(settings_path="abc").settings_path == "abc"


# Generated at 2022-06-23 20:21:25.465887
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("Black")
    except Exception as exception:
        assert 'Specified formatting plugin of Black' in str(exception)
        assert 'does not exist' in str(exception)
        return
    assert False

# Generated at 2022-06-23 20:21:26.310071
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("fil.e").file_path == "fil.e"

# Generated at 2022-06-23 20:21:30.107348
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    profile = 'non-existing-profile'
    try:
        raise ProfileDoesNotExist(profile)
    except ProfileDoesNotExist as e:
        assert e.args[0] == f"Specified profile of {profile} does not exist. Available profiles: black,google,pep8,pycharm,vscode,jupyter_notebook,atom,pycharm_test,vscode_test,jupyter_notebook_test."
        assert e.args[1] == ""
        assert e.__class__.__name__ == "ProfileDoesNotExist"
        assert e.args.__class__.__name__ == "tuple"
        assert e.profile == profile



# Generated at 2022-06-23 20:21:31.413150
# Unit test for constructor of class ISortError
def test_ISortError():
    error = ISortError()


# Generated at 2022-06-23 20:21:34.839666
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment('test.py')
    except FileSkipComment as err:
        assert err.file_path == 'test.py'

#Unit test for constructor of class InvalidSettingsPath

# Generated at 2022-06-23 20:21:40.655997
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("dir/file.py")
    except IntroducedSyntaxErrors as e:
        assert str(e) == \
            "isort introduced syntax errors when attempting to sort the imports contained within " \
            "dir/file.py."
        assert e.file_path == "dir/file.py"

# Generated at 2022-06-23 20:21:47.664698
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    file_path = "data/syntax_err.py"
    expected_message = (
        f"isort was told to sort imports within code that contains syntax errors: {file_path}."
    )
    assert ExistingSyntaxErrors(file_path).args[0] == expected_message
    assert ExistingSyntaxErrors(file_path).args[0] == expected_message
    assert ExistingSyntaxErrors(file_path).args[0] == expected_message
    assert ExistingSyntaxErrors(file_path).args[0] == expected_message
    assert ExistingSyntaxErrors(file_path).args[0] == expected_message



# Generated at 2022-06-23 20:21:50.301490
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    msg = FileSkipComment('example.py')
    assert msg.message == 'example.py contains an file skip comment and was skipped.'

# Generated at 2022-06-23 20:21:55.441727
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure(
            '"a_string"',
            ValueError('malformed string'))
    except LiteralParsingFailure as err:
        assert err.code == '"a_string"'
        assert repr(err.original_error) == repr(ValueError('malformed string'))
        assert str(err).endswith(
            'which gave the exception of malformed string: "'
            'a_string"')


# Generated at 2022-06-23 20:21:58.651915
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    a = "a"
    if getattr(a, "encode", None):  # is a str
        print(a.encode("ascii"))
    else:
        print(a)

# Generated at 2022-06-23 20:22:02.404707
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as e:
        raise ExistingSyntaxErrors('/path/to/file')

    assert e.file_path == '/path/to/file'


# Generated at 2022-06-23 20:22:06.634796
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    exception = ExistingSyntaxErrors("found.py")
    assert str(exception) == "isort was told to sort imports within code that contains" \
                             " syntax errors: found.py."
    assert exception.file_path == "found.py"


# Generated at 2022-06-23 20:22:09.497962
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    exception = UnsupportedEncoding("test_file.py")
    assert exception.filename == "test_file.py"
    assert isinstance(exception.args, tuple)
    assert exception.args[0] == "Unknown or unsupported encoding in test_file.py"


# Generated at 2022-06-23 20:22:10.966175
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    from pathlib import Path
    assert ISortError()
    assert FileSkipped("message", str(Path("/tmp")))

# Generated at 2022-06-23 20:22:18.604847
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    path = "leo.py"
    with pytest.raises(IntroducedSyntaxErrors) as excinfo:
        raise IntroducedSyntaxErrors(path)

    assert excinfo.value.file_path == path
    # Built-in function 'str'
    assert str(excinfo.value) == "isort introduced syntax errors when attempting to sort the " \
                                 "imports contained within leo.py."


if __name__ == "__main__":
    import sys
    import pytest

    sys.exit(pytest.main(["-v", "--capture=sys", __file__]))

# Generated at 2022-06-23 20:22:25.341429
# Unit test for constructor of class MissingSection
def test_MissingSection():
    ms = MissingSection("import_module", "section")
    assert ms.args[0] == "Found import_module import while parsing, but section was not included " \
                          "in the `sections` setting of your config. Please add it before continuing\n" \
                          "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                          "for more info."
    assert ms.import_module == "import_module"
    assert ms.section == "section"


# Generated at 2022-06-23 20:22:29.607203
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=str, expected_kind=dict)
    except LiteralSortTypeMismatch as e:
        assert e.kind == str
        assert e.expected_kind == dict
    else:
        raise Exception("test failed")

if __name__ == "__main__":
    test_LiteralSortTypeMismatch()

# Generated at 2022-06-23 20:22:30.789378
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except Exception as e:
        pass


# Generated at 2022-06-23 20:22:34.380524
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("exception")
    except ExistingSyntaxErrors as e:
        print(e.file_path)
        assert(e.file_path == "exception")
    else:
        assert(False)
    return