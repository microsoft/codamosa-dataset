

# Generated at 2022-06-23 20:12:33.441646
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    literal = '{"isort": "awesome"}'
    error = SyntaxError("invalid syntax")
    error.text = "error"
    e = LiteralParsingFailure(literal, error)
    # print message from constructor of LiteralParsingFailure
    print(e)

# Generated at 2022-06-23 20:12:34.992261
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("InvalidSettingsPath Exception")
    except InvalidSettingsPath as e:
        assert e.settings_path == "InvalidSettingsPath Exception"



# Generated at 2022-06-23 20:12:38.022955
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped('Exception message', 'Exception file path')
    except FileSkipped as skipped:
        assert skipped.file_path == 'Exception file path'
        assert skipped.message == 'Exception message'


# Generated at 2022-06-23 20:12:43.684231
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    # Create a mock exception
    class TestException(Exception):
        pass

    exception = LiteralParsingFailure("import foo", TestException("ImportError: cannot import name foo")
)
    # Assert if the exception is raised
    assert exception.code == "import foo"
    assert exception.original_error.args == ("ImportError: cannot import name foo",)


# Generated at 2022-06-23 20:12:46.435166
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    obj = ExistingSyntaxErrors("file.py")
    assert(obj.file_path == "file.py")

# Generated at 2022-06-23 20:12:48.436491
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as excinfo:
        raise ExistingSyntaxErrors('file_path')
    assert str(excinfo.value) == 'isort was told to sort imports within code that contains syntax errors: file_path.'



# Generated at 2022-06-23 20:12:52.926369
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # pylint: disable=unused-variable
    class TmpError(Exception):
        pass

    class TmpError2(TmpError):
        pass

    tmp = TmpError("tmp")
    tmp2 = TmpError2("tmp2")
    if not isinstance(tmp, TmpError2):
        pass
    try:
        raise TmpError("tmp")
    except TmpError:
        pass



# Generated at 2022-06-23 20:12:56.726192
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    exc = FileSkipSetting('file')
    assert exc.file_path == 'file'
    assert str(exc) == "file was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:12:58.682314
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch):
        raise LiteralSortTypeMismatch(int, float)


# Generated at 2022-06-23 20:13:04.215734
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings_list = [{'name':[{'value': 'name1', 'source': 'source1'}],
                     'name2':[{'value': 'name21', 'source': 'source21'}]}, 
                     {'name1':[{'value': 'name2', 'source': 'source2'},{'value': 'name3', 'source': 'source3'}]}]
    exception = UnsupportedSettings(settings_list)
    assert exception.unsupported_settings == settings_list

# Generated at 2022-06-23 20:13:09.476142
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    error = FileSkipSetting("test.py")
    assert error.file_path == 'test.py'
    assert type(error) == FileSkipSetting
    assert str(error) == "test.py was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:13:13.110571
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    x = LiteralSortTypeMismatch(str, int)
    assert x.kind == str
    assert x.expected_kind == int
    assert x.__str__() == "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>."

# Generated at 2022-06-23 20:13:17.671055
# Unit test for constructor of class MissingSection
def test_MissingSection():
    m = MissingSection("test_a", "FRONTEND")
    assert m.args[0] == f"Found test_a import while parsing, but FRONTEND was not included " \
                        f"in the `sections` setting of your config. Please add it before continuing\n" \
                        f"See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                        f"for more info."

# Generated at 2022-06-23 20:13:22.673953
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("Non Existent Path")
    except InvalidSettingsPath as e:
        assert e.settings_path == "Non Existent Path"
    else:
        assert False


# Generated at 2022-06-23 20:13:23.696941
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    LiteralParsingFailure('', Exception(''))

# Generated at 2022-06-23 20:13:26.499295
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    """IsortError"""
    filename = "test.py"
    try:
        raise UnsupportedEncoding(filename)
    except UnsupportedEncoding as error:
        assert error.filename == filename

# Generated at 2022-06-23 20:13:28.479109
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting("test.py")
    except FileSkipSetting as e:
        assert e.file_path == "test.py"

# Generated at 2022-06-23 20:13:32.322116
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('/home/user/isort/settings.cfg')
    except InvalidSettingsPath as e:
        print(e.settings_path)

# Generated at 2022-06-23 20:13:33.807731
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    e = LiteralParsingFailure("code", Exception())

    assert e.code == "code"
    assert isinstance(e.original_error, Exception)

# Generated at 2022-06-23 20:13:38.293927
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        file_path = '~/file1.py'
        message = 'file has been skipped.'
        raise FileSkipped(message, file_path)
    except FileSkipped as e:
        assert e.message == 'file has been skipped.'
        assert e.file_path == '~/file1.py'


# Generated at 2022-06-23 20:13:45.414535
# Unit test for constructor of class MissingSection
def test_MissingSection():
    section = 'missing-sections'
    try:
        raise MissingSection('abc', section)
    except MissingSection as e:
        # 'Found abc import while parsing, but missing-sections was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'
        expected_msg = f"Found abc import while parsing, but {section} was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."
        assert e.args[0] == expected_msg
        assert e.import_module == 'abc'
        assert e.section == section

# Generated at 2022-06-23 20:13:48.622966
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped('message','file_path').__class__ is FileSkipped
    assert FileSkipped('message','file_path').file_path == 'file_path'
    assert FileSkipped('message','file_path').message == 'message'

# Generated at 2022-06-23 20:13:51.603164
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    err = LiteralSortTypeMismatch(kind=None, expected_kind=None)
    assert type(err) == LiteralSortTypeMismatch
    assert type(err.kind) == None
    assert type(err.expected_kind) == None

# Generated at 2022-06-23 20:13:53.873296
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("")
    except FileSkipComment:
        pass



# Generated at 2022-06-23 20:13:57.449384
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    print(IntroducedSyntaxErrors("/usr/bin/test"))
    print(isinstance('/usr/bin/test', str))
# -------------------------------------------------


if __name__ == "__main__":
    test_IntroducedSyntaxErrors()

# Generated at 2022-06-23 20:14:04.273076
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try_profile = "unknown_profile"
    try:
        raise ProfileDoesNotExist(try_profile)
    except ProfileDoesNotExist as e:
        assert e.profile == try_profile
        assert str(e) == (
            f"Specified profile of {try_profile} does not exist. "
            f"Available profiles: {','.join(profiles)}."
        )


# Generated at 2022-06-23 20:14:05.408917
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped('message', 'file_path')

# Generated at 2022-06-23 20:14:07.974062
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist, match="Specified profile of Python does not exist. Available profiles: "):
        ProfileDoesNotExist("Python")

# Generated at 2022-06-23 20:14:09.484989
# Unit test for constructor of class ISortError
def test_ISortError():
    x = ISortError("some error message")
    assert x.args == ("some error message",)

# Generated at 2022-06-23 20:14:12.637810
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    message = "Error"
    try:
        raise InvalidSettingsPath(message)
    except Exception as e:
        assert e.settings_path == message

# Generated at 2022-06-23 20:14:16.854445
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
  settings_path = str()
  ex = InvalidSettingsPath(settings_path)
  assert str(ex) == 'isort was told to use the settings_path: ' + settings_path + ' as the base directory or file that represents the starting point of config file discovery, but it does not exist.'


# Generated at 2022-06-23 20:14:19.209383
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(type, type)

# Generated at 2022-06-23 20:14:29.007821
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    """Unit test that tests the constructor of the class UnsupportedSettings"""
    unsupported_settings = {
        "beep": {"value": "boop", "source": "beep_source"},
        "boop": {"value": "beep", "source": "boop_source"},
    }

    unsupported_settings_error = UnsupportedSettings(unsupported_settings)
    assert unsupported_settings_error.unsupported_settings == unsupported_settings

    # Test that message is formated correctly

# Generated at 2022-06-23 20:14:33.571923
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("wrong/path/file.py")
    except IntroducedSyntaxErrors as err:
        assert str(err) == 'isort introduced syntax errors when attempting to sort the imports contained within wrong/path/file.py.'
        assert err.file_path == "wrong/path/file.py"

# Generated at 2022-06-23 20:14:39.645478
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # Arrange
    settings_path = 'testFile'
    expected = "isort was told to use the settings_path: testFile as the base directory or file that represents the starting point of config file discovery, but it does not exist."
    
    # Act
    actual = InvalidSettingsPath(settings_path)
    
    # Assert
    assert str(actual) == expected



# Generated at 2022-06-23 20:14:43.860802
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('simple')
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of simple does not exist."
        assert e.formatter == 'simple'


# Generated at 2022-06-23 20:14:48.958887
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code='''a = 1
b = 2
c = 3'''
    with pytest.raises(AssignmentsFormatMismatch) as obj:
        raise AssignmentsFormatMismatch(code)

#Unit test for constructor of class UnsupportedSettings

# Generated at 2022-06-23 20:14:53.227036
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    error = UnsupportedSettings(unsupported_settings={"option": {"value": "value", "source": "source"}})
    assert error.unsupported_settings == {"option": {"value": "value", "source": "source"}}

# Generated at 2022-06-23 20:14:54.886513
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    x = FormattingPluginDoesNotExist()
    assert x.formatter == "failed to find"

# Generated at 2022-06-23 20:14:56.442904
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    e = FormattingPluginDoesNotExist('formater')
    assert e.formatter == 'formater'

# Generated at 2022-06-23 20:15:01.806064
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("sum('hello')", ValueError("invalid"))
    except LiteralParsingFailure as e:
        assert "invalid" in e.args[0]
        assert e.code == "sum('hello')"
        assert type(e.original_error) == ValueError


# Generated at 2022-06-23 20:15:07.139525
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = """
    def test(x):
        if x == 1:
            return
        def test1(y):
            if y == 1:
                return
            x = 1
        y = 2
    """
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        print(e.code)

test_AssignmentsFormatMismatch()

# Generated at 2022-06-23 20:15:09.522642
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('test')
    except ProfileDoesNotExist as e:
        assert e.profile == 'test'

# Generated at 2022-06-23 20:15:10.258195
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert FormattingPluginDoesNotExist('import magic')

# Generated at 2022-06-23 20:15:13.871319
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    """Unit test for constructor of class IntroducedSyntaxErrors"""
    # given
    file_path = '/usr/local/bin/foo.py'
    # when
    e = IntroducedSyntaxErrors(file_path)
    # then
    assert e.args[0] == f"isort introduced syntax errors when attempting to sort the imports contained within {file_path}."
    assert e.file_path == file_path

# Generated at 2022-06-23 20:15:16.139522
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch):
        raise LiteralSortTypeMismatch(list, tuple)

# Generated at 2022-06-23 20:15:21.123536
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("testException")
    except FormattingPluginDoesNotExist as inst:
        assert inst.formatter == "testException"

# Test to see if correct class is created by constructor of class FormattingPluginDoesNotExist

# Generated at 2022-06-23 20:15:25.005830
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    err = LiteralSortTypeMismatch(kind=str, expected_kind=str)
    assert err.kind == str
    assert err.expected_kind == str

if __name__ == "__main__":
    test_LiteralSortTypeMismatch()

# Generated at 2022-06-23 20:15:27.569918
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try:
        raise ExistingSyntaxErrors("test file path")
    except ExistingSyntaxErrors as e:
        assert e.file_path == "test file path"
        assert str(e) == "isort was told to sort imports within code that contains syntax errors: test file path."


# Generated at 2022-06-23 20:15:28.305759
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    i = IntroducedSyntaxErrors('sample')
    pass



# Generated at 2022-06-23 20:15:39.824483
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings: Dict[str, Dict[str, Any]] = {
        "sections": {
            "value": "[], [], []",
            "source": "example",
        },
        "multi_line_output": {"value": "4", "source": "example"},
        "length_sort": {"value": "True", "source": "example"},
    }
    exception = UnsupportedSettings(unsupported_settings)
    exception_message = exception.__str__()

# Generated at 2022-06-23 20:15:43.014409
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # Arguments
    file_path = "./isort/tests/code/syntax_errors.py"
    exception = ExistingSyntaxErrors(file_path)

    # Expected results
    message = (
        "isort was told to sort imports within code that contains syntax errors: "
        "./isort/tests/code/syntax_errors.py."
    )
    assert exception.message == message
    assert exception.file_path == file_path



# Generated at 2022-06-23 20:15:48.125611
# Unit test for constructor of class IntroducedSyntaxErrors

# Generated at 2022-06-23 20:15:56.052559
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection('pytest', 'TESTING')
    except MissingSection as missing_section:
        assert missing_section.import_module == 'pytest'
        assert missing_section.section == 'TESTING'
        assert str(missing_section) == (
            'Found pytest import while parsing, but TESTING was not included '
            'in the `sections` setting of your config. Please add it before continuing\n'
            'See https://pycqa.github.io/isort/#custom-sections-and-ordering '
            'for more info.'
        )



# Generated at 2022-06-23 20:16:00.165018
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    assert str(ExistingSyntaxErrors(file_path='file_path')) == 'isort was told to sort imports within code that contains syntax errors: file_path.'
    assert ExistingSyntaxErrors(file_path='file_path').file_path == 'file_path'



# Generated at 2022-06-23 20:16:02.572066
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors) as exc_info:
        raise ExistingSyntaxErrors("file path")
    assert exc_info.value.file_path == "file path"



# Generated at 2022-06-23 20:16:07.145121
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    u = UnsupportedSettings({'test': {'value': '1', 'source': 'cli'}})
    assert u.unsupported_settings == {'test': {'value': '1', 'source': 'cli'}}
    assert u.__str__() == "isort was provided settings that it doesn't support:\n\n\t- test = 1  (source: 'cli')\n\nFor a complete and up-to-date listing of supported settings see: https://pycqa.github.io/isort/docs/configuration/options/.\n"

# Generated at 2022-06-23 20:16:08.051634
# Unit test for constructor of class ISortError
def test_ISortError():
    ISortError(ISortError())

# Generated at 2022-06-23 20:16:13.737273
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    code = "sorted([([12,2],{'a': 'a'}),"
    original_error = Exception("exception")
    assert LiteralParsingFailure(code, original_error).code == code
    assert LiteralParsingFailure(code, original_error).original_error == original_error

# Generated at 2022-06-23 20:16:17.777447
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    setting = FileSkipSetting(file_path="file_path")
    assert setting.file_path == "file_path"
    assert str(setting) == "file_path was skipped as it's listed in 'skip' setting" \
                           " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:16:19.562112
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    x = FormattingPluginDoesNotExist("formatter")
    assert x.formatter == "formatter"

# Generated at 2022-06-23 20:16:24.994185
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("{", ValueError("test"))
    except LiteralParsingFailure as e:
        assert str(e) == (
            "isort failed to parse the given literal {. It's important to note "
            "that isort literal sorting only supports simple literals parsable by "
            "ast.literal_eval which gave the exception of test."
        )
        assert e.code == "{"
        assert e.original_error.args == ("test",)

# Generated at 2022-06-23 20:16:30.699280
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    import isort._py3compat as py3compat
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert e.args[0] == py3compat.cast("str", "Specified formatting plugin of test does not exist. ")

# Generated at 2022-06-23 20:16:33.601193
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    a = FileSkipped('a', 'b')
    assert a.file_path == 'b'
    assert a.message == 'a'

# Generated at 2022-06-23 20:16:36.207298
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped('message', 'file_path')
    except FileSkipped as e:
        assert e.args[0] == 'message'
        assert e.file_path == 'file_path'

# Generated at 2022-06-23 20:16:38.995231
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("foo")
    except ProfileDoesNotExist as e:
        assert e.message == "Specified profile of foo does not exist. Available profiles: black,pycharm."

# Generated at 2022-06-23 20:16:47.139401
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        # Test with valid input
        code = "{variable_name} = {value}\n{variable_name2} = {value2}\n..."
        raise AssignmentsFormatMismatch(code)
        assert False
    except AssignmentsFormatMismatch as e:
        # Test the output
        assert str(e) == (
            "isort was told to sort a section of assignments, however the given code:\n\n"
            f"{code}\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n"
        )
        assert e.code == code

# Generated at 2022-06-23 20:16:52.421880
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    """Unit test for constructor of class FileSkipSetting"""
    message = "Skipped File"
    file_path = "Test_File"
    file_skip_setting = FileSkipSetting(file_path)
    assert file_skip_setting.message == message
    assert file_skip_setting.file_path == file_path


# Generated at 2022-06-23 20:16:55.228255
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("test")
        assert False
    except InvalidSettingsPath as exception:
        assert exception.settings_path == "test"


# Generated at 2022-06-23 20:17:01.083381
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception = IntroducedSyntaxErrors('test/test_file.py')
    assert str(exception) == ('isort introduced syntax errors when attempting to sort the imports'
                              ' contained within test/test_file.py.')
    assert exception.file_path == 'test/test_file.py'

# Generated at 2022-06-23 20:17:03.127566
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("test").message == "test was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:17:05.157062
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    e = FormattingPluginDoesNotExist(formatter="Hi")
    assert e.formatter == "Hi"



# Generated at 2022-06-23 20:17:11.539531
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("variable_name=variable_value")
    except AssignmentsFormatMismatch as err:
        assert (
            str(err)
            == "isort was told to sort a section of assignments, however the given code:\n\n"
            "variable_name=variable_value\n\n"
            "Does not match isort's strict single line formatting requirement for assignment "
            "sorting:\n\n"
            "{variable_name} = {value}\n"
            "{variable_name2} = {value2}\n"
            "...\n\n"
        )

# Generated at 2022-06-23 20:17:13.123690
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    new_exception = ProfileDoesNotExist('test')
    assert new_exception.profile == 'test'


# Generated at 2022-06-23 20:17:20.637036
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    a = FileSkipSetting("temp.py")
    assert(isinstance(a, FileSkipped) == True)
    assert(isinstance(a, ISortError) == True)
    assert(isinstance(a, Exception) == True)

    assert(a.message == "temp.py was skipped as it's listed in 'skip' setting"
        " or matches a glob in 'skip_glob' setting")
    assert(a.file_path == "temp.py")

# Generated at 2022-06-23 20:17:28.253898
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
         raise AssignmentsFormatMismatch("foo = bar\nunsupported_settings = [1,2]")
    except AssignmentsFormatMismatch as inst:
        assert inst.code == "foo = bar\nunsupported_settings = [1,2]"
        assert inst.args == ("isort was told to sort a section of assignments, however the given code:\n\nfoo = bar\nunsupported_settings = [1,2]\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n",)

# Generated at 2022-06-23 20:17:39.357566
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    # test case#1
    filePath = "~/Desktop/Test_Case/isort/isort.py"
    # test case#2
    filePath1 = "~/Desktop"
    # test case#3
    filePath2 = "~/Desktop/Test_Case/isort/isort.py/filePath.txt"

    # test case#1 - expect "~/Desktop/Test_Case/isort/isort.py was skipped as it's listed in 'skip' setting"
    # "or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:17:43.459606
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():  # noqa # pragma: no cover
    try:
        InvalidSettingsPath("/tmp/settings_path/*.ini")
    except ISortError:
        pass
    else:
        raise Exception(
            "Test expected exception but did not get it."
        )  # pragma: no cover

# Generated at 2022-06-23 20:17:44.820820
# Unit test for constructor of class MissingSection
def test_MissingSection():
    raise MissingSection('import_module', 'section')

# Generated at 2022-06-23 20:17:49.773928
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("Cheese")
    except ProfileDoesNotExist as err:
        assert err.profile == "Cheese"

# Generated at 2022-06-23 20:17:52.243810
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    err = ExistingSyntaxErrors("test_path")
    assert isinstance(err, ISortError)
    assert err.file_path == "test_path"

# Generated at 2022-06-23 20:17:54.808486
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    error = IntroducedSyntaxErrors("file_path")
    assert error.file_path == "file_path"


# Generated at 2022-06-23 20:17:56.836166
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(kind=list, expected_kind=dict).kind == list
    assert LiteralSortTypeMismatch(kind=list, expected_kind=dict).expected_kind == dict



# Generated at 2022-06-23 20:17:59.679672
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fs = FileSkipped(message="test message", file_path="test file path")
    assert fs.message == "test message"
    assert fs.file_path == "test file path"

# Generated at 2022-06-23 20:18:02.423951
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    foobar = FormattingPluginDoesNotExist("foobar")
    assert foobar.formatter == "foobar"
    assert str(foobar) == "Specified formatting plugin of foobar does not exist. "

# Generated at 2022-06-23 20:18:04.361851
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "django"
    error = FormattingPluginDoesNotExist(formatter)
    assert error.formatter == formatter

# Generated at 2022-06-23 20:18:06.580889
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    errors = LiteralParsingFailure("test", Exception("test"))
    print(errors)


# Generated at 2022-06-23 20:18:07.429692
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert True

# Generated at 2022-06-23 20:18:09.850291
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # Test for None
    fn = FileSkipComment("file1")
    assert fn.message == "file1 contains an file skip comment and was skipped."



# Generated at 2022-06-23 20:18:12.158868
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(1, 1.0)


# Generated at 2022-06-23 20:18:16.371847
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "test.py"
    e = IntroducedSyntaxErrors(file_path)
    assert e.file_path == file_path
    assert str(e) == f"isort introduced syntax errors when attempting to sort the imports contained within {file_path}."

# Generated at 2022-06-23 20:18:18.447431
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    error: FormattingPluginDoesNotExist = FormattingPluginDoesNotExist('formatter')
    assert error.formatter == 'formatter'

# Generated at 2022-06-23 20:18:21.425450
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment("tests/fixtures/fileskip_comment.py").message == "tests/fixtures/fileskip_comment.py contains an file skip comment and was skipped."
    assert FileSkipComment("tests/fixtures/fileskip_comment.py").file_path == "tests/fixtures/fileskip_comment.py"


# Generated at 2022-06-23 20:18:23.513455
# Unit test for constructor of class MissingSection
def test_MissingSection():
    import_module = "Module"
    section = "Section"
    msg = MissingSection(import_module, section)
    assert msg.import_module == import_module
    assert msg.section == section

# Generated at 2022-06-23 20:18:24.705355
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    a = InvalidSettingsPath("testing")
    assert a.settings_path == "testing"


# Generated at 2022-06-23 20:18:26.104335
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError as e:
        assert str(e) == ""


# Generated at 2022-06-23 20:18:32.279567
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        'use_parentheses': {'value': False, 'source': 'isort_settings.py'},
        'default_section': {'value': 'FIRSTPARTY', 'source': 'isort_setting.py'}
    }
    error = UnsupportedSettings(unsupported_settings)
    errors = "\n".join(
        UnsupportedSettings._format_option(name, **option) for name, option in unsupported_settings.items()
    )

# Generated at 2022-06-23 20:18:38.742640
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch(  # noqa
            code='''{"a": 1, "b": 2, "c": 3}'''
        )
    except Exception as exc:
        if exc.__class__ is AssignmentsFormatMismatch:
            assert exc.code == '''{"a": 1, "b": 2, "c": 3}'''
        else:
            assert False

# Generated at 2022-06-23 20:18:41.595545
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped("test_FileSkipped", "test_FileSkipped").file_path == "test_FileSkipped"
    print("FileSkipped initialized successfully")


# Generated at 2022-06-23 20:18:43.706395
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    obj = FileSkipSetting("test")
    assert obj
    assert isinstance(obj, FileSkipped)

# Generated at 2022-06-23 20:18:45.636329
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors, match="test.py"):
        raise IntroducedSyntaxErrors("test.py")

# Generated at 2022-06-23 20:18:46.509114
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch("a = cat")

# Generated at 2022-06-23 20:18:55.514436
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """
    Test LiteralSortTypeMismatch class
    """
    test_LiteralSortTypeMismatch = LiteralSortTypeMismatch(kind=int, expected_kind=str)
    assert (
        str(test_LiteralSortTypeMismatch)
        == "isort was told to sort a literal of type <class 'str'> but was given a literal of type <class 'int'>"
    )
    assert test_LiteralSortTypeMismatch.kind == int
    assert test_LiteralSortTypeMismatch.expected_kind == str

# Generated at 2022-06-23 20:19:00.404395
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    ip=InvalidSettingsPath("E:\\PythonPractice\\settings_path")
    #assert ip.settings_path=="E:\\PythonPractice\\settings_path"
    assert str(ip)=="isort was told to use the settings_path: E:\\PythonPractice\\settings_path as the base directory or file that represents the starting point of config file discovery, but it does not exist."


# Generated at 2022-06-23 20:19:04.522533
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("test", "TEST")
    except FileSkipped as e:
        assert e.message == "test"
        assert e.file_path == "TEST"


# Generated at 2022-06-23 20:19:05.546952
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch("code")

# Generated at 2022-06-23 20:19:09.628829
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection(1, "Hint: Update your settings")
    except MissingSection as e:
        assert type(e.import_module) == str
        assert e.section == "Hint: Update your settings"
    else:
        raise TypeError(
            "constructor of class MissingSection encounters unknown error"
        )



# Generated at 2022-06-23 20:19:11.677803
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try: 
        raise MissingSection("testimport","testsection")
    except MissingSection:
        pass

# Generated at 2022-06-23 20:19:15.629173
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    exception_name = IntroducedSyntaxErrors(file_path="a")
    assert exception_name.file_path == "a"
    assert exception_name.__str__() == ("isort introduced syntax errors when attempting to "
                                        "sort the imports contained within a.")


# Generated at 2022-06-23 20:19:17.693966
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported = {"key1": "value1", "key2": "value2"}
    assert str(UnsupportedSettings(unsupported))

# Generated at 2022-06-23 20:19:20.443259
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped(message="Message", file_path="filepath.py")
    except Exception as e:
        assert str(e) == "Message"
        assert e.file_path == "filepath.py"


# Generated at 2022-06-23 20:19:21.893932
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    t1 = FileSkipped("assertion error", "test.txt")
    assert t1.message == "assertion error"
    assert t1.file_path == "test.txt"

# Generated at 2022-06-23 20:19:23.705572
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    assert FileSkipped('message', 'file_path').message == 'message'
    assert FileSkipped('message', 'file_path').file_path == 'file_path'

# Generated at 2022-06-23 20:19:30.408522
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure(code="['', '', '']", original_error=SyntaxError(
            "unexpected EOF while parsing", (None, 0, 0, None)
        ))
    except LiteralParsingFailure as error:
        assert error.code == "['', '', '']"
        assert error.original_error.msg == "unexpected EOF while parsing"
        assert error.original_error.filename == None
        assert error.original_error.lineno == 0
        assert error.original_error.offset == 0
        assert error.original_error.text == None
        return True
    return False


# Generated at 2022-06-23 20:19:36.416609
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("hello")
    except AssignmentsFormatMismatch as e:
        assert str(e) == "isort was told to sort a section of assignments, however the given code:\n\nhello\n\nDoes not match isort's strict single line formatting requirement for assignment sorting:\n\n{variable_name} = {value}\n{variable_name2} = {value2}\n...\n\n"

# Generated at 2022-06-23 20:19:40.218484
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        import ast
        ast.literal_eval('[1')
    except Exception as e:
        assert LiteralParsingFailure('[1', e)
        return
    assert False


if __name__ == "__main__":
    test_LiteralParsingFailure()

# Generated at 2022-06-23 20:19:44.309292
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    f = FileSkipSetting('s')
    assert f.file_path == 's'

# Generated at 2022-06-23 20:19:52.815101
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # Test for missing module name
    try:
        raise MissingSection('test_module_name', 'test_section')
    except MissingSection:
        raise AssertionError('MissingSection raised exception without module name.')
    # Test for missing section name
    try:
        raise MissingSection('test_module_name', '')
    except MissingSection:
        raise AssertionError('MissingSection raised exception without section name.')
    # Test for missing module and section names
    try:
        raise MissingSection('', '')
    except MissingSection:
        raise AssertionError('MissingSection raised exception without module and section names.')
    # Test for missing module name, but not section name

# Generated at 2022-06-23 20:19:57.355850
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    print('Testing class LiteralSortTypeMismatch')
    try:
        raise LiteralSortTypeMismatch('a', 'b')
    except LiteralSortTypeMismatch as e:
        assert e.kind == 'a'
        assert e.expected_kind == 'b'
        print("Test Passed!")



# Generated at 2022-06-23 20:19:59.005831
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    fsc = FileSkipComment('file')
    assert fsc.file_path == 'file'

# Generated at 2022-06-23 20:20:02.877349
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    expected_error_msg = 'isort was told to sort a literal of type a but was given a literal of type b.'
    try:
        raise LiteralSortTypeMismatch('a', 'b')
    except LiteralSortTypeMismatch as e:
        assert expected_error_msg == str(e)



# Generated at 2022-06-23 20:20:05.688640
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    '''This tests the methods inside InvalidSettingsPath class'''
    obj = InvalidSettingsPath("/usr/bin/python3") #constructor
    assert isinstance(obj.settings_path,"str") #assert data type of settings_path


# Generated at 2022-06-23 20:20:08.786276
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    error = ExistingSyntaxErrors('filename')
    assert str(error) == 'isort was told to sort imports within code that contains syntax errors: filename.'
    assert error.file_path == 'filename'


# Generated at 2022-06-23 20:20:13.626909
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "a"
    exc = FileSkipSetting(file_path)
    assert exc.file_path == file_path
    assert exc.args[0] == "'a' was skipped as it's listed in 'skip' setting or matches a glob " \
        "in 'skip_glob' setting"

# Generated at 2022-06-23 20:20:18.618997
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        expected = (
            "Specified profile of test does not exist. "
            "Available profiles: black, atom, vscode, intellij, google, python, "
            "gnu, pycharm, jupyter, google-python, ipython, yapf, pycodestyle, pep8, "
            "openstack, pybuilder, pylama, flake8, mccabe, bandit, darglint, prospector, "
            "pyreverse, dpep425, mypy."
        )
        assert str(e) == expected



# Generated at 2022-06-23 20:20:25.284214
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    from ast import literal_eval

    class SyntaxError(Exception):
        pass

    try:
        literal_eval('<invalid_literal>')
    except SyntaxError as e:
        exc = LiteralParsingFailure('<invalid_literal>', e)
    assert str(exc) == (
        "isort failed to parse the given literal <invalid_literal>. It's important to note "
        "that isort literal sorting only supports simple literals parsable by "
        "ast.literal_eval which gave the exception of bad string literal: <invalid_literal>"
    )



# Generated at 2022-06-23 20:20:28.435252
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "foo.py"
    error = FileSkipComment(file_path=file_path)
    assert file_path == error.file_path
    assert "file skip comment" in error.args[0]

# Generated at 2022-06-23 20:20:31.370609
# Unit test for constructor of class MissingSection
def test_MissingSection():
    im = MissingSection('pytorch', "torch")
    assert isinstance(im, MissingSection)
    assert im.import_module == 'pytorch'
    assert im.section == 'torch'

# Generated at 2022-06-23 20:20:33.640768
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    c = UnsupportedEncoding("test.py")
    assert c.args[0] == "Unknown or unsupported encoding in test.py"

# Generated at 2022-06-23 20:20:37.190002
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(1, 2)
    except LiteralSortTypeMismatch as e:
        assert e.kind == 1
        assert e.expected_kind == 2
        
if __name__ == '__main__':
    test_LiteralSortTypeMismatch()

# Generated at 2022-06-23 20:20:40.828476
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "C:\\pycharm\\workspaces\\project\\venv\\pyscripts\\isort_checker_handler.py"
    exception = IntroducedSyntaxErrors(file_path)
    assert exception.file_path == file_path

# Generated at 2022-06-23 20:20:42.257962
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert isinstance(FileSkipComment("test"),ISortError)

# Generated at 2022-06-23 20:20:43.649370
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch(int, str)



# Generated at 2022-06-23 20:20:47.281571
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("var1 = 1\n"
                                        "var2 = 2  # isort: +\n"
                                        "var3 = 3\n")
    except AssignmentsFormatMismatch as e:
        print(e)



# Generated at 2022-06-23 20:20:49.002096
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    err = ExistingSyntaxErrors("abc.py")
    assert err.file_path == "abc.py"

# Generated at 2022-06-23 20:20:51.083771
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    class_name = LiteralSortTypeMismatch(kind=str, expected_kind=int)
    assert class_name.kind == str
    assert class_name.expected_kind == int

# Generated at 2022-06-23 20:20:54.140930
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    e = FileSkipped("test", "file")
    assert e.file_path == "file"

# Generated at 2022-06-23 20:20:59.523131
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a=b\nc=d")
    except AssignmentsFormatMismatch as error:
        assert 'isort was told to sort a section of assignments, however the given code:' in str(error)
        assert 'does not match isort\'s strict single line formatting requirement for assignment sorting' in str(error)


# Generated at 2022-06-23 20:21:02.185509
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist('aaa')
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == 'aaa'

# Generated at 2022-06-23 20:21:03.521117
# Unit test for constructor of class ISortError
def test_ISortError():
    e = ISortError()
    assert str(e) == ""


# Generated at 2022-06-23 20:21:05.494092
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # GIVEN
    settings_path = "test_path"

    # WHEN
    exception = InvalidSettingsPath(settings_path)

    # THEN
    assert exception.settings_path == settings_path


# Generated at 2022-06-23 20:21:08.965050
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    message = "Testing literal parsing failure."
    code = "foo"
    original_error = ValueError("Something went wrong.")
    expected_msg = message + " " + code + str(original_error)

    actual_exception = LiteralParsingFailure(code, original_error)
    actual_msg = str(actual_exception)
    assert actual_msg == expected_msg

# Generated at 2022-06-23 20:21:11.415763
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file = "testfile.py"
    i = FileSkipComment(file)
    assert(i.message == f"{file} contains an file skip comment and was skipped.")
    assert(i.file_path == file)

# Generated at 2022-06-23 20:21:20.392863
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class LiteralParsingFailure(ISortError):
        """Raised when one of isorts literal sorting comments is used but isort can't parse the
        the given data structure.
        """

        def __init__(self, code: str, original_error: Exception):
            super().__init__(
                f"isort failed to parse the given literal {code}. It's important to note "
                "that isort literal sorting only supports simple literals parsable by "
                f"ast.literal_eval which gave the exception of {original_error}."
            )
            self.code = code
            self.original_error = original_error


# Generated at 2022-06-23 20:21:24.176785
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ISortError.ExistingSyntaxErrors) as pytest_wrapped_e:
        raise ISortError.ExistingSyntaxErrors("../test1/file_with_existing_syntax_errors.py")
    assert pytest_wrapped_e.type == ISortError.ExistingSyntaxErrors
#

# Generated at 2022-06-23 20:21:31.089388
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with open('test.cfg','w') as f:
        f.write('[tool.isort]\n'
                'known_first_party=isort\n'
                'known_third_party=pytest\n'
                'multi_line_output=3\n'
                'include_trailing_comma=True')

    import isort
    
    # Test with invalid filepath
    try:
        sorter = isort.SortImports('test.cfg', path='invalid.cfg', check=True)
        sorter.file_import_code_mapping
    except InvalidSettingsPath as e:
        assert str(e) == 'isort was told to use the settings_path: invalid.cfg as the base directory or file that represents the starting point of config file discovery, but it does not exist.'

    # Test

# Generated at 2022-06-23 20:21:34.289449
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    file_path = "/path/to/file.py"
    object_ = FileSkipComment(file_path=file_path)
    assert object_.file_path == file_path

# Generated at 2022-06-23 20:21:36.805809
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    temp_file = FileSkipComment("")
    assert temp_file.file_path == ""


# Generated at 2022-06-23 20:21:39.890296
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("test.py")
    except UnsupportedEncoding as e:
        assert str(e) == "Unknown or unsupported encoding in test.py"

# Generated at 2022-06-23 20:21:41.346907
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting('test.txt').__init__('test.txt')

# Generated at 2022-06-23 20:21:45.808032
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    # When
    error = ExistingSyntaxErrors("filepath")

    # Then
    assert error.file_path == "filepath"
    assert error.__str__() == "isort was told to sort imports within code that contains syntax errors: filepath."

# Generated at 2022-06-23 20:21:48.068846
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    expected_kind = [1,2,3,4]
    kind = [5,6,7,8]
    actual_error = LiteralSortTypeMismatch(kind, expected_kind)
    print(actual_error)
    print("\n")
   

# Generated at 2022-06-23 20:21:52.299582
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test_string")
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "test_string"
        return
    assert 0, "Should not reach this line"


# Generated at 2022-06-23 20:21:56.795360
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting(file_path="file_path")
    except FileSkipSetting as e:
        assert e.message == "file_path was skipped as it's listed in 'skip' setting" \
                            " or matches a glob in 'skip_glob' setting"
        assert e.file_path == "file_path"

# Generated at 2022-06-23 20:21:58.925707
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    filename='scr/src/manage.py'
    syntaxError = IntroducedSyntaxErrors(filename)
    assert syntaxError.file_path == filename

# Generated at 2022-06-23 20:22:00.978280
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {"key": {"value": "value", "source": "source"}, "key2": {"value": "value2", "source": "source2"}}
    UnsupportedSettings(settings)

# Generated at 2022-06-23 20:22:05.211355
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    msg = FileSkipSetting("test/test.py")
    assert msg.file_path == "test/test.py"
    assert msg.args[0] == "test/test.py was skipped as it's listed in 'skip' setting"\
        " or matches a glob in 'skip_glob' setting"


# Generated at 2022-06-23 20:22:06.810245
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    e = UnsupportedEncoding('file.py')
    assert e.filename == 'file.py'

# Generated at 2022-06-23 20:22:10.887802
# Unit test for constructor of class MissingSection
def test_MissingSection():
    msg = "Found {import_module} import while parsing, but {section} was not included "
    msg += "in the `sections` setting of your config. Please add it before continuing\n"
    msg += "See https://pycqa.github.io/isort/#custom-sections-and-ordering "
    msg += "for more info."
    assert msg == MissingSection.__init__.__doc__



# Generated at 2022-06-23 20:22:13.328772
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    
    # Test the constructor of class InvalidSettingPath
    try:
        raise InvalidSettingsPath('/invalid/path')
    except InvalidSettingsPath as e:
        assert e.settings_path == '/invalid/path'


# Generated at 2022-06-23 20:22:15.530551
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("x")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "x"

# Generated at 2022-06-23 20:22:17.948551
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    match = LiteralSortTypeMismatch(int, float)
    print(match)
    print(match.kind)
    print(match.expected_kind)


# Generated at 2022-06-23 20:22:19.503150
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    exception = InvalidSettingsPath("a_path")
    assert exception.settings_path == "a_path"


# Generated at 2022-06-23 20:22:23.898708
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        1 / 0
    except Exception as e:
        try:
            raise LiteralParsingFailure('test', e)
        except LiteralParsingFailure as e:
            assert e.code == 'test'
            assert e.original_error == e

# Generated at 2022-06-23 20:22:26.258579
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("f").filename == "f"
    assert UnsupportedEncoding("F").filename == "F"
    assert UnsupportedEncoding("X").filename == "X"


# Generated at 2022-06-23 20:22:28.213257
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    exc = ExistingSyntaxErrors("/tmp/filepath")
    assert exc.file_path == "/tmp/filepath"

# Generated at 2022-06-23 20:22:30.204423
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
        assert False
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test."
    return True

# Generated at 2022-06-23 20:22:32.702667
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath('/Users/bhanu/Desktop/ISort/test_isort.py')
        print("Invalid Settings path exception raised")
    except InvalidSettingsPath:
        print("Invalid Settings path exception raised")
