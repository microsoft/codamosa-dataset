

# Generated at 2022-06-23 20:12:33.477168
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    s = "The isort config path is not valid"

    ISortError.__init__(s)

# Generated at 2022-06-23 20:12:35.880482
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    ips = InvalidSettingsPath('Random String')
    assert ips.settings_path == "Random String"
    assert ips.args[0] == "isort was told to use the settings_path: Random String as the base directory or file that represents the starting point of config file discovery, but it does not exist."


# Generated at 2022-06-23 20:12:39.018457
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("asdf = sdfsdf")
    except AssignmentsFormatMismatch as e:
        assert isinstance(e, ISortError)
        assert e.code == "asdf = sdfsdf"


# Generated at 2022-06-23 20:12:43.537892
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert repr(LiteralSortTypeMismatch(kind=int, expected_kind=str)) == (
        f"<LiteralSortTypeMismatch: isort was told to sort a literal of type <class 'str'>"
        f" but was given a literal of type <class 'int'>>"
    )

# Generated at 2022-06-23 20:12:47.288590
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    assert LiteralSortTypeMismatch('type', 'expected_type').kind == 'type'
    assert LiteralSortTypeMismatch('type', 'expected_type').expected_kind == 'expected_type'

# Generated at 2022-06-23 20:12:52.330701
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("import_module", "section")
    except MissingSection as e:
        assert (
            str(e)
            == "Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."  # noqa: E501
        )
        assert e.import_module == "import_module"
        assert e.section == "section"



# Generated at 2022-06-23 20:12:53.534321
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    _test_exception_message(FileSkipped('message', 'path'), 'message')


# Generated at 2022-06-23 20:12:56.581434
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("test_message", "test_file_path")
    except FileSkipped as e:
        assert e.args[0] is "test_message"
        assert e.file_path is "test_file_path"



# Generated at 2022-06-23 20:12:59.688703
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("file/path").message == "file/path was skipped as it's listed in 'skip' setting"\
                                                   " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:13:03.591107
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection("foo", "bar").__str__() == "Found foo import while parsing, but bar " \
        "was not included in the `sections` setting of your config. Please add it before " \
        "continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."


# Generated at 2022-06-23 20:13:09.993266
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    # type: () -> ISortError
    try:
        raise LiteralSortTypeMismatch(kind=0, expected_kind=str)
    except LiteralSortTypeMismatch as e:
        assert str(e) == (
            "isort was told to sort a literal of type <class 'str'> but was given "
            "a literal of type <class 'int'>.\n"
        )

# Generated at 2022-06-23 20:13:11.163571
# Unit test for constructor of class ISortError
def test_ISortError():
    ISortError('')

# Generated at 2022-06-23 20:13:16.667979
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    with pytest.raises(TypeError) as excinfo:
        fskipped = FileSkipped(1, 1)
    assert excinfo.value.args[0] == "__init__() takes exactly 3 arguments (2 given)"
    fskipped = FileSkipped('msg', 'filepath')
    assert fskipped.message == 'msg'
    assert fskipped.file_path == 'filepath'

# Generated at 2022-06-23 20:13:19.214081
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist(profile="test")
    except ProfileDoesNotExist as profileDoesNotExist:
        assert profileDoesNotExist.profile == "test"

# Generated at 2022-06-23 20:13:20.677292
# Unit test for constructor of class ISortError
def test_ISortError():
    exc = ISortError()
    assert str(exc) == ''
    assert repr(exc) == 'ISortError()'

# Generated at 2022-06-23 20:13:23.696515
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = b")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = b"

# Generated at 2022-06-23 20:13:26.839316
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    try:
        raise FormattingPluginDoesNotExist("test")
    except FormattingPluginDoesNotExist as e:
        assert str(e) == "Specified formatting plugin of test does not exist. "
        assert e.formatter == "test"

# Generated at 2022-06-23 20:13:28.860783
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    with pytest.raises(AssignmentsFormatMismatch):
        AssignmentsFormatMismatch('test')

# Generated at 2022-06-23 20:13:31.657515
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # no exception should be raised
    UnsupportedEncoding('test.py')



# Generated at 2022-06-23 20:13:36.224002
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    error = AssignmentsFormatMismatch("a=1 b=1")
    assert error.code == "a=1 b=1"
    assert "isort was told to sort a section of assignments" in str(error)
    assert "does not match isort's strict single line formatting requirement" in str(error)


# Generated at 2022-06-23 20:13:37.399338
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    p = InvalidSettingsPath("abc")
    assert p.settings_path == "abc"


# Generated at 2022-06-23 20:13:39.795423
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(InvalidSettingsPath) as err:
        raise InvalidSettingsPath("invalid")
    assert err.value.settings_path == "invalid"


# Generated at 2022-06-23 20:13:40.856279
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert True

# Generated at 2022-06-23 20:13:43.921053
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert str(MissingSection("sys", "FUTURE")) == "Found sys import while parsing, but FUTURE was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info."

# Generated at 2022-06-23 20:13:47.680190
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    fs = FileSkipSetting("filePath1")
    assert fs.filePath == "filePath1"
    assert fs.message == "filePath1 was skipped as it's listed in 'skip' setting or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:13:49.077712
# Unit test for constructor of class ISortError
def test_ISortError():
    ISortError()


# Generated at 2022-06-23 20:13:54.244749
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("file")
    except IntroducedSyntaxErrors as err:
        filename = err.file_path
        if filename == "file":
            print("Passed")
        else:
            print("Failed")


if __name__ == "__main__":
    test_IntroducedSyntaxErrors()

# Generated at 2022-06-23 20:13:56.441349
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    actual = FormattingPluginDoesNotExist("my_new_plugin")
    assert actual.formatter == "my_new_plugin"

# Generated at 2022-06-23 20:14:00.843920
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('import_module', 'section').args == ('Found import_module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.',)
    assert MissingSection('import_module', 'section').import_module == 'import_module'
    assert MissingSection('import_module', 'section').section == 'section'

# Generated at 2022-06-23 20:14:02.925501
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    assert str(UnsupportedSettings({})) == "isort was provided settings that it doesn't support:"



# Generated at 2022-06-23 20:14:07.377265
# Unit test for constructor of class ISortError
def test_ISortError():
    # TODO: replace this test with a unit test
    try:
        raise ISortError("error")
    except ISortError as err:
        assert isinstance(err, ISortError)
        assert err.__str__() == "error"


# Generated at 2022-06-23 20:14:08.516177
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    UnsupportedEncoding("filename")

# Generated at 2022-06-23 20:14:13.877074
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    with pytest.raises(IntroducedSyntaxErrors) as exception_info:
        raise IntroducedSyntaxErrors("src")
    assert exception_info.type == IntroducedSyntaxErrors
    assert (
        str(exception_info.value)
        == "isort introduced syntax errors when attempting to sort the imports contained within src."
    )

# Generated at 2022-06-23 20:14:16.617290
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("/opt/file1.py")
    except InvalidSettingsPath as e:
        assert e.settings_path == "/opt/file1.py"

# Generated at 2022-06-23 20:14:20.804501
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1, \n2 = b")
    except AssignmentsFormatMismatch:
        pass



# Generated at 2022-06-23 20:14:22.701566
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    # TODO: test if IntroducedSyntaxErrors works correctly
    pass

# Generated at 2022-06-23 20:14:24.731898
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    AssignmentsFormatMismatch("puzzle = int(input('Enter a number for the guessing game: '))")



# Generated at 2022-06-23 20:14:27.534748
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    with pytest.raises(ProfileDoesNotExist):
        raise ProfileDoesNotExist("test")

# Generated at 2022-06-23 20:14:29.937934
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class CustomError(Exception):
        pass

    with pytest.raises(ISortError):
        raise LiteralParsingFailure("'import", CustomError("Invalid syntax"))

# Generated at 2022-06-23 20:14:32.589788
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    a = FileSkipped("message", "file_path")
    assert a.args[0] == "message"
    assert a.file_path == "file_path"



# Generated at 2022-06-23 20:14:38.886495
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding("/home/isort/myfile.txt")
    except UnsupportedEncoding as exception:
        assert str(exception) == "Unknown or unsupported encoding in /home/isort/myfile.txt"

    try:
        raise UnsupportedEncoding(Path("/home/isort/myfile.txt"))
    except UnsupportedEncoding as exception:
        assert str(exception) == "Unknown or unsupported encoding in /home/isort/myfile.txt"

# Generated at 2022-06-23 20:14:42.565614
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path='test/test.py'
    assert file_path in str(IntroducedSyntaxErrors(file_path))
    assert file_path in IntroducedSyntaxErrors(file_path).file_path


# Generated at 2022-06-23 20:14:44.805953
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    try:
        raise FileSkipSetting('path')
    except FileSkipSetting as e:
        print(e.file_path)


# Generated at 2022-06-23 20:14:49.290264
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    with pytest.raises(ISortError) as excinfo:
        InvalidSettingsPath("test")
    assert (
        excinfo.value.args[0]
        == "isort was told to use the settings_path: test as the base directory or file that represents the starting point of config file discovery, but it does not exist."
    )
    assert excinfo.value.settings_path == "test"


# Generated at 2022-06-23 20:14:51.238679
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    assert LiteralParsingFailure("code", "error").code == "code"
    assert LiteralParsingFailure("code", "error").original_error == "error"


# Generated at 2022-06-23 20:14:53.273889
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError()
    except ISortError as e:
        assert isinstance(e, ISortError)


# Generated at 2022-06-23 20:14:56.601013
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "option1": {"value": "test_value1", "source": "test_source1"},
        "option2": {"value": "test_value2", "source": "test_source2"},
    }
    UnsupportedSettings(unsupported_settings)

# Generated at 2022-06-23 20:15:00.751944
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path = "/tmp/foo.py"
    message = "Test message"
    e = FileSkipped(message=message, file_path=file_path)
    assert e.message == message
    assert e.file_path == file_path

# Generated at 2022-06-23 20:15:04.322550
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    with pytest.raises(UnsupportedSettings):
        unsupported_settings = {
            'name': {
                'value': 'val',
                'source': 'conf'
            }
        }
        UnsupportedSettings(unsupported_settings)


# Generated at 2022-06-23 20:15:12.879993
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code       = "a_long_variable_name_that_will_not_fit_on_a_single_line = [\n'string',\n'another_string'\n]"
    expected   = "isort was told to sort a section of assignments, however the given code:\n\n" + code + "\n\n" + "Does not match isort's strict single line formatting requirement for assignment sorting:\n\n" + "{variable_name} = {value}\n" + "{variable_name2} = {value2}\n" + "...\n\n"
    error = AssignmentsFormatMismatch(code)
    assert error.msg == expected
    assert error.code == code



# Generated at 2022-06-23 20:15:20.404243
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    test_kind = "3"
    test_expected_kind = "5"
    assert test_kind == "3"
    assert test_expected_kind == "5"
    test_LiteralSortTypeMismatch = LiteralSortTypeMismatch(test_kind, test_expected_kind)
    assert test_LiteralSortTypeMismatch.kind == test_kind
    assert test_LiteralSortTypeMismatch.expected_kind == test_expected_kind


# Generated at 2022-06-23 20:15:24.310322
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("/test/txt")
    except FileSkipComment as e:
        assert(e.file_path == "/test/txt")
        assert(e.message == "/test/txt contains an file skip comment and was skipped.")



# Generated at 2022-06-23 20:15:27.898336
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        # making sure that code has the right type
        assert type(e.code) == int
        assert type(e.expected_kind) == str


# Generated at 2022-06-23 20:15:33.252322
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    class_var = UnsupportedSettings({"w": {"value": 1, "source": "2"}})
    incorrect_type_result = isinstance(class_var, UnsupportedSettings)
    assert incorrect_type_result == True


# Generated at 2022-06-23 20:15:35.379808
# Unit test for constructor of class ISortError
def test_ISortError():
    error = ISortError("string")
    assert type(error) == ISortError
    assert str(error) == "string"


# Generated at 2022-06-23 20:15:40.029560
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("module", "section")
    except MissingSection as e:
        assert str(e) == "Found module import while parsing, but section was not included in the `sections` setting of your config. Please add it before continuing\n" \
            "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
            "for more info."

# Generated at 2022-06-23 20:15:40.799110
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert FileSkipComment.__init__

# Generated at 2022-06-23 20:15:43.613144
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        code = "import os\n"
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as e:
        assert e.code == "import os\n"

# Generated at 2022-06-23 20:15:48.280229
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("testFilePath")
    except Exception as e:
        assert e.file_path == "testFilePath"
        assert str(e) == "testFilePath contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:15:52.900818
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    filename = "filename"
    exc = SyntaxError(filename)
    code = "[ 1, 2, 3 ]"
    err = LiteralParsingFailure(code, exc)
    assert err.code == code
    assert err.original_error.filename == filename

# Generated at 2022-06-23 20:15:56.052639
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    """Unit test for constructor of class LiteralParsingFailure"""
    lpf = LiteralParsingFailure("foo", "bar")
    assert lpf.code == "foo"
    assert lpf.original_error == "bar"

# Generated at 2022-06-23 20:15:58.536237
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('object')
        assert False
    except ISortError as e:
        assert e.args[0] == 'object'

# Generated at 2022-06-23 20:16:00.525322
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    assert ProfileDoesNotExist("test")

# Generated at 2022-06-23 20:16:06.927407
# Unit test for constructor of class MissingSection
def test_MissingSection():
    try:
        raise MissingSection("my_import_module", "my_section")
    except MissingSection as e:
        assert e.import_module == "my_import_module"
        assert e.args == ('Found my_import_module import while parsing, but my_section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.',)
        assert str(e) == 'Found my_import_module import while parsing, but my_section was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'

# Generated at 2022-06-23 20:16:10.541687
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    obj = IntroducedSyntaxErrors("abc")
    assert obj.file_path == "abc"

# Generated at 2022-06-23 20:16:12.317615
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("foo")
    except ProfileDoesNotExist as e:
        assert e.profile == "foo"

# Generated at 2022-06-23 20:16:15.142830
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    exception = LiteralSortTypeMismatch(kind=int, expected_kind=str)
    assert exception.kind == int
    assert exception.expected_kind == str


# Generated at 2022-06-23 20:16:16.941524
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 1"
    error = AssignmentsFormatMismatch(code)
    assert error.code == code

# Generated at 2022-06-23 20:16:25.566600
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings_dict = {'x':1, 'y':2}
    with pytest.raises(ISortError) as excinfo:
        raise UnsupportedSettings(settings_dict)
    exception_msg = str(excinfo.value)
    exception_msg_lines = exception_msg.split('\n')
    expected_exception_msg = "isort was provided settings that it doesn't support:\n\n" \
                             "\t- x = 1  (source: 'unknown')\n" \
                             "\t- y = 2  (source: 'unknown')\n\n" \
                             "For a complete and up-to-date listing of supported settings see: " \
                             "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    expected_exception_msg_

# Generated at 2022-06-23 20:16:31.164474
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    with pytest.raises(LiteralParsingFailure) as context:
        raise LiteralParsingFailure("a = 1\n", ValueError("Bad stuff"))

    assert str(context.value) == (
        "isort failed to parse the given literal a = 1. It's important to note "
        "that isort literal sorting only supports simple literals parsable by ast.literal_eval "
        "which gave the exception of Bad stuff."
    )


# Generated at 2022-06-23 20:16:34.011566
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment("File Skip Comment")
    except FileSkipComment as err:
        assert str(err) == "File Skip Comment contains an file skip comment and was skipped."
        assert err.file_path == "File Skip Comment"


# Generated at 2022-06-23 20:16:36.393218
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    try:
        raise UnsupportedEncoding('myFile.txt')
    except UnsupportedEncoding as ue:
        assert ue.filename == 'myFile.txt'


# Generated at 2022-06-23 20:16:38.818006
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist('black')
    except ProfileDoesNotExist as err:
        assert err.profile == 'black'


# Generated at 2022-06-23 20:16:42.407584
# Unit test for constructor of class MissingSection
def test_MissingSection():
    section = "my_section"
    import_module = "my_module"
    exception = MissingSection(import_module, section)
    assert section in exception.args[0]
    assert import_module in exception.args[0]
    assert section in exception.__str__()
    assert import_module in exception.__str__()

# Generated at 2022-06-23 20:16:45.157456
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    FormattingPluginDoesNotExist("from_pyi")

if __name__ == "__main__":
    test_FormattingPluginDoesNotExist()

# Generated at 2022-06-23 20:16:50.091880
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "foo/bar"
    setting = FileSkipSetting(file_path)
    assert setting.file_path == file_path
    assert str(setting) == f"{file_path} was skipped as it's listed in 'skip' setting"
    " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-23 20:16:51.759352
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    att = UnsupportedEncoding("test")
    assert att.filename == "test"

# Generated at 2022-06-23 20:16:55.957644
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    message = 'hello'
    file_path = 'test.txt'
    file_skipped = FileSkipped(message=message, file_path=file_path)
    assert file_skipped.message == message
    assert file_skipped.file_path == file_path
    assert str(file_skipped) == message

# Generated at 2022-06-23 20:17:05.533884
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    import os
    test_path = os.path.join("tests")
    assert not (os.path.exists(test_path))
    try:
        raise InvalidSettingsPath(settings_path=test_path)
    except ISortError as e:
        assert isinstance(e, InvalidSettingsPath)
        assert e.settings_path == test_path
        assert e.args[0] == f"isort was told to use the settings_path: {test_path} as the base directory or " \
                             "file that represents the starting point of config file discovery, but it does not " \
                             "exist."

# Generated at 2022-06-23 20:17:09.406973
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    message = "isort was told to sort a literal of type {expected_kind} but was given " \
              "a literal of type {kind}."
    kind = 'str'
    expected_kind = 'list'
    exception = LiteralSortTypeMismatch(kind, expected_kind)
    assert(str(exception) == message.format(expected_kind=expected_kind, kind=kind))

# Generated at 2022-06-23 20:17:12.728128
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    try :
        raise ExistingSyntaxErrors("../tests/code/99_import_parse_error.py")
    except ExistingSyntaxErrors as e:
        assert "isort was told to sort imports within code that contains syntax errors: ../tests/code/99_import_parse_error.py." in e.args[0]

# Generated at 2022-06-23 20:17:16.998813
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    # Arrange
    filename = '../isort.py'

    # Act
    u = UnsupportedEncoding(filename)

    # Assert
    assert u.filename == '../isort.py'


# Generated at 2022-06-23 20:17:18.859143
# Unit test for constructor of class ISortError
def test_ISortError():
    exception = ISortError("Invalid")
    assert exception.args[0] == "Invalid"


# Generated at 2022-06-23 20:17:25.089665
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    expect_value = f"isort was told to use the settings_path: {settings_path} as the base directory or file that represents the starting point of config file discovery, but it does not exist."
    actual_value = InvalidSettingsPath('/temp/test')
    if actual_value.args[0] != expect_value:
        raise Exception("Expected constructor to set the value of args[0] to %s, but got %s" %(expect_value, actual_value.args[0]))


# Generated at 2022-06-23 20:17:27.630038
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "testfilename.txt"
    error = UnsupportedEncoding(filename)
    assert error.filename == filename
    assert error.args[0] == "Unknown or unsupported encoding in testfilename.txt"

# Generated at 2022-06-23 20:17:32.651760
# Unit test for constructor of class MissingSection
def test_MissingSection():
    # Given
    import_module = "import_module"
    section = "section"

    # When
    result = MissingSection(import_module, section)

    # Then
    expected_message = "Found {0} import while parsing, but {1} was not included in the `sections` setting of your config. Please add it before continuing\n" \
        "See https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.".format(
            import_module, section
        )
    assert result.args == (expected_message,)



# Generated at 2022-06-23 20:17:35.183083
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    with pytest.raises(FileSkipSetting) as excinfo:
        FileSkipSetting('hello.py')
    assert excinfo.value.file_path == 'hello.py'

# Generated at 2022-06-23 20:17:36.313274
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection('import_module', 'section')

# Generated at 2022-06-23 20:17:38.570205
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    with pytest.raises(FormattingPluginDoesNotExist):
        raise FormattingPluginDoesNotExist('xyz')



# Generated at 2022-06-23 20:17:46.418665
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    # unicode string
    assert (
        UnsupportedSettings({"test": {"value": "test", "source": "config file"}}).__str__()
        == "\n"
        "isort was provided settings that it doesn't support:\n"
        "\n"
        "\t- test = test  (source: 'config file')\n"
        "\n"
        "For a complete and up-to-date listing of supported settings see: "
        "https://pycqa.github.io/isort/docs/configuration/options/.\n"
    )



# Generated at 2022-06-23 20:17:50.782002
# Unit test for constructor of class MissingSection
def test_MissingSection():
  ms = MissingSection('my_module', 'my_section')
  assert ms.args[0] == f"Found my_module import while parsing, but my_section was not included " \
                       "in the `sections` setting of your config. Please add it before continuing\n" \
                       "See https://pycqa.github.io/isort/#custom-sections-and-ordering " \
                       "for more info."

# Generated at 2022-06-23 20:17:54.120410
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "isort.py"
    error = UnsupportedEncoding(filename)
    assert error.filename == filename
    assert str(error) == "Unknown or unsupported encoding in isort.py"

# Generated at 2022-06-23 20:17:55.094016
# Unit test for constructor of class MissingSection
def test_MissingSection():
    assert MissingSection("module", "section")


# Generated at 2022-06-23 20:17:56.836982
# Unit test for constructor of class ISortError
def test_ISortError():
    with pytest.raises(SyntaxError):
        # Raises an exception of type ISortError
        raise ISortError("This is a message")


# Generated at 2022-06-23 20:17:58.963755
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as error:
        print(f"\nLiteralSortTypeMismatch:\n\n{error}\n")

# Generated at 2022-06-23 20:18:01.725283
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    path = 'foo/bar.py'
    exception = InvalidSettingsPath(settings_path = path)
    
    assert exception.settings_path == path
    assert exception.__str__() == f'isort was told to use the settings_path: {path} as the base directory or file that represents the starting point of config file discovery, but it does not exist.'

# Generated at 2022-06-23 20:18:03.966979
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    # Resolve file path and create FileSkipComment exception
    file_path = os.path.realpath(__file__)
    exception = FileSkipComment(file_path)
    
    # Test constructor logic
    assert exception.file_path == file_path
    

# Generated at 2022-06-23 20:18:08.242444
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "formatter"
    exception = FormattingPluginDoesNotExist(formatter)
    assert(str(exception) == "Specified formatting plugin of formatter does not exist. ")
    assert(exception.formatter == formatter)


# Generated at 2022-06-23 20:18:11.080304
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    try:
        raise FileSkipComment(file_path="test-path")
    except FileSkipComment as e:
        assert e.file_path == "test-path"
        assert str(e)=="test-path contains an file skip comment and was skipped."

# Generated at 2022-06-23 20:18:14.659094
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "f"
    try:
        raise FormattingPluginDoesNotExist(formatter)
    except FormattingPluginDoesNotExist as e:
        assert e.formatter == "f"


# Generated at 2022-06-23 20:18:18.995712
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("my_profile")
    except ProfileDoesNotExist as e:
        assert e.profile == "my_profile"
        assert (
            str(e) == "Specified profile of my_profile does not exist. "
            "Available profiles: black,black_compatible,pep8,manual."
        )

# Generated at 2022-06-23 20:18:20.541729
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    assert (FileSkipComment("test").message == "test contains an file skip comment and was skipped.")



# Generated at 2022-06-23 20:18:22.482928
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    e=LiteralParsingFailure(code='a',original_error='b')
    assert e.code=='a'
    assert e.original_error=='b'

# Generated at 2022-06-23 20:18:27.320290
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    import pytest
    from isort.exceptions import FileSkipComment
    try:
        raise FileSkipComment("test.py")
    except FileSkipComment as e:
        assert e.file_path == "test.py"
        assert e.message == "test.py contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:18:31.091124
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert (InvalidSettingsPath('Unknown path',)
            == 'isort was told to use the settings_path: Unknown path as the base '
               'directory or file that represents the starting point of config file '
               'discovery, but it does not exist.')



# Generated at 2022-06-23 20:18:32.308818
# Unit test for constructor of class ISortError
def test_ISortError():
    error = ISortError()
    assert isinstance(error,Exception)


# Generated at 2022-06-23 20:18:33.108432
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    assert isinstance(FormattingPluginDoesNotExist('test'), ISortError)

# Generated at 2022-06-23 20:18:35.503932
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    exception = FormattingPluginDoesNotExist("formatter")
    assert exception.formatter == "formatter"
    assert exception.args[0] == "Specified formatting plugin of formatter does not exist. "


# Generated at 2022-06-23 20:18:39.510220
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    settings = {
        "a": {"value": "b", "source": "c"},
        "d": {"value": "e", "source": "f"},
    }
    error = UnsupportedSettings(settings)
    assert error.unsupported_settings == settings

# Generated at 2022-06-23 20:18:41.138765
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "good"
    e = FormattingPluginDoesNotExist(formatter)
    assert e.formatter == formatter
    assert str(e) == "Specified formatting plugin of good does not exist. "



# Generated at 2022-06-23 20:18:42.993079
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test."
test_IntroducedSyntaxErrors()

# Generated at 2022-06-23 20:18:43.535351
# Unit test for constructor of class ISortError
def test_ISortError():
    assert str(ISortError()) == 'base exception'

# Generated at 2022-06-23 20:18:47.088303
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        assert True("")
    except AssertionError as error:
        try:
            raise LiteralParsingFailure("abc", error)
        except LiteralParsingFailure as e:
            assert e.code == "abc"
            assert e.original_error == error



# Generated at 2022-06-23 20:18:48.267786
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    assert UnsupportedEncoding("test.py").filename == "test.py"



# Generated at 2022-06-23 20:18:50.203440
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    class ExpErr(Exception):
        pass
    assert ExpErr


# Generated at 2022-06-23 20:18:53.884090
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = '''x = "1"
y = "2"'''
    try:
        raise AssignmentsFormatMismatch(code)
    except AssignmentsFormatMismatch as expected:
        assert expected.code == code

# Generated at 2022-06-23 20:18:58.156947
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        # test default constructor
        LiteralSortTypeMismatch(kind = "test_kind", expected_kind = "test_expected_kind")
    except LiteralSortTypeMismatch as instance:
        assert instance.kind == "test_kind"
        assert instance.expected_kind == "test_expected_kind"
        assert str(instance) == "isort was told to sort a literal of type test_expected_kind but was given \
        a literal of type test_kind."
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)


# Generated at 2022-06-23 20:19:02.386509
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("dummy_file.py")
    except IntroducedSyntaxErrors as err:
        assert err.file_path == "dummy_file.py"

# Generated at 2022-06-23 20:19:06.294544
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "name": {
            "value": "value",
            "source": "source",
        }
    }
    err = UnsupportedSettings(unsupported_settings)
    assert err.unsupported_settings == unsupported_settings

# Generated at 2022-06-23 20:19:08.634453
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    ifsettings = InvalidSettingsPath('/home/akash/documents/')
    assert ifsettings.settings_path == '/home/akash/documents/'


# Generated at 2022-06-23 20:19:11.261521
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    file_path="test_file"
    message="message"
    test_fs=FileSkipped(message,file_path)
    assert test_fs.message==message
    assert test_fs.file_path==file_path


# Generated at 2022-06-23 20:19:14.802209
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    print("Testing FileSkipComment class constructor")
    assert FileSkipComment("/tmp/foo.py").message == "/tmp/foo.py contains an file skip comment and was skipped."
    assert FileSkipComment("/tmp/foo.py").file_path == "/tmp/foo.py"


# Generated at 2022-06-23 20:19:16.262975
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    error = UnsupportedEncoding("test.txt")
    assert error.filename == "test.txt"

# Generated at 2022-06-23 20:19:18.241115
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    obj = FileSkipped("message", "path")
    assert obj.message == "message"
    assert obj.file_path == "path"

# Generated at 2022-06-23 20:19:21.536318
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(42, str)
    except LiteralSortTypeMismatch as e:
        assert type(e) == LiteralSortTypeMismatch
        assert e.kind.__name__ == "int"
        assert e.expected_kind.__name__ == "str"

# Generated at 2022-06-23 20:19:28.391274
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure('code', RuntimeError('exception'))
    except LiteralParsingFailure as e:
        assert str(e) == ("isort failed to parse the given literal code. It's important to "
                          "note that isort literal sorting only supports simple literals parsable "
                          "by ast.literal_eval which gave the exception of exception.")
        assert e.code == 'code'
        assert str(e.original_error) == 'exception'



# Generated at 2022-06-23 20:19:30.519177
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    errorMsg = 'Unexpected encoding {0} for {1}'.format('ascii', 'fileName')
    assert UnsupportedEncoding('fileName').args[0] == errorMsg

# Generated at 2022-06-23 20:19:33.794841
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError("something wrong")
    except ISortError as e:
        assert str(e) == "something wrong"


# Generated at 2022-06-23 20:19:37.707679
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    msg = "test message"
    f = 'test_file'

    try:
        raise FileSkipped(msg, f)
    except FileSkipped as e:
        assert e.args[0] == msg
        assert e.file_path == f


# Generated at 2022-06-23 20:19:41.850813
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("../../examples/simple/bad_syntax.py")
    except IntroducedSyntaxErrors as err:
        assert err.args[
            0
        ] == "isort introduced syntax errors when attempting to sort the imports contained within ../../examples/simple/bad_syntax.py."

# Generated at 2022-06-23 20:19:45.976451
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    f = FileSkipComment("Example.py")
    assert f.file_path == "Example.py"
    assert f.message == "Example.py contains an file skip comment and was skipped."



# Generated at 2022-06-23 20:19:47.795872
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError('This is an error message')
    except ISortError as err:
        assert str(err) == 'This is an error message'


# Generated at 2022-06-23 20:19:53.397436
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    error = ProfileDoesNotExist('foo')
    assert error.profile == 'foo'
    assert str(error) == (
        "Specified profile of foo does not exist. "
        "Available profiles: black, black_bundled, google, pycharm, "
        "jupyter, vscode, kedro, flake8, sphinx, pylance, pyarrow, "
        "pytest, radon, rasa, red, dvc, isort."
    )

# Generated at 2022-06-23 20:19:57.945154
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    a = {}
    b = []
    c = ''
    assert LiteralSortTypeMismatch(type(a), type(b)).kind == dict
    assert LiteralSortTypeMismatch(type(a), type(b)).expected_kind == list
    assert LiteralSortTypeMismatch(type(a), type(c)).expected_kind == str

# Generated at 2022-06-23 20:19:59.047875
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    f = LiteralSortTypeMismatch(str, list)  # noqa

# Generated at 2022-06-23 20:20:00.922046
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    a = FileSkipped("message", "file_path")
    assert a.message == "message"
    assert a.file_path == "file_path"

# Generated at 2022-06-23 20:20:02.835911
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    f = IntroducedSyntaxErrors("abc.py")
    assert f.file_path == "abc.py"


# Generated at 2022-06-23 20:20:05.042941
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    fs = FileSkipped("message_test", "path_test")
    assert fs.file_path == "path_test"
    assert fs.message == "message_test"

# Generated at 2022-06-23 20:20:07.686417
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    # run
    try:
        raise AssignmentsFormatMismatch("")
    except AssignmentsFormatMismatch:
        pass

# Generated at 2022-06-23 20:20:11.184238
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    fsc = FileSkipComment("filepath")
    assert fsc.file_path == "filepath"
    assert fsc.__str__() == "filepath contains an file skip comment and was skipped."


# Generated at 2022-06-23 20:20:15.317054
# Unit test for constructor of class ISortError
def test_ISortError():
    msg= "This is a error message for testing"
    e = ISortError(msg)
    assert msg in str(e) and e.message == msg
    e.message = "This is a new message"
    assert str(e) == "This is a new message"


# Generated at 2022-06-23 20:20:16.358970
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    ski = FileSkipped(message="message", file_path="file_path")



# Generated at 2022-06-23 20:20:20.278385
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test.py")
    except IntroducedSyntaxErrors as e:
        return str(e) == "isort introduced syntax errors when attempting to sort the imports contained within test.py."

if __name__ == '__main__':
    print(test_IntroducedSyntaxErrors())

# Generated at 2022-06-23 20:20:21.931982
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    obj = FormattingPluginDoesNotExist('default')
    assert str(obj) == "Specified formatting plugin of default does not exist. "

# Generated at 2022-06-23 20:20:25.650361
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "/home/jj/workspace/IntroductionFile.py"
    e = IntroducedSyntaxErrors(file_path)
    assert str(e) == "isort introduced syntax errors when attempting to sort the imports contained within /home/jj/workspace/IntroductionFile.py."
    assert e.file_path == file_path

# Generated at 2022-06-23 20:20:29.509489
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise LiteralParsingFailure("", "")
    except LiteralParsingFailure as literal_parsing_error:
        assert literal_parsing_error.code == ""
        assert literal_parsing_error.original_error == ""

# Generated at 2022-06-23 20:20:32.813595
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    #Testing for and printing expected exception
    try:
        raise LiteralParsingFailure('[1, 2, 3, ]', SyntaxError('invalid syntax'))
    except LiteralParsingFailure as e:
        print(e)


# Generated at 2022-06-23 20:20:35.702676
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    msg = "I was skipped"
    path = "tests/test.py"
    f = FileSkipped(msg, path)
    assert f.file_path == "tests/test.py"
    assert f.args[0] == "I was skipped"

# Generated at 2022-06-23 20:20:38.494333
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    invalid_settings_path = InvalidSettingsPath("/a/b/c/d/e")
    assert invalid_settings_path.settings_path == "/a/b/c/d/e"


# Generated at 2022-06-23 20:20:42.839122
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    # Base code
    try:
        raise InvalidSettingsPath('xyz.cfg')
    except Exception as e:
        assert e.__class__ == InvalidSettingsPath
        assert e.settings_path == 'xyz.cfg'
    else:
        assert False, 'Did not raise expected exception'


# Generated at 2022-06-23 20:20:44.561124
# Unit test for constructor of class ISortError
def test_ISortError():
    try:
        raise ISortError
    except ISortError:
        assert True


# Generated at 2022-06-23 20:20:49.488522
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    class oops(Exception):
        def __init__(self, x, y):
            self.x = x
            self.y = y

    try:
        raise oops
    except oops as e:
        try:
            raise LiteralParsingFailure("test", e)
        except LiteralParsingFailure as e1:
            assert e1.code == "test"
            assert e1.original_error == e
            assert str(e1) == "isort failed to parse the given literal test. It's important to note that isort literal sorting only supports simple literals parsable by ast.literal_eval which gave the exception of oops"


# Generated at 2022-06-23 20:20:50.351532
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    assert FileSkipSetting("file_path")

# Generated at 2022-06-23 20:20:51.560331
# Unit test for constructor of class ISortError
def test_ISortError():
    error = ISortError('my_message')
    assert error.args[0] == 'my_message'



# Generated at 2022-06-23 20:20:53.247722
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    with pytest.raises(LiteralSortTypeMismatch):
        LiteralSortTypeMismatch("str", "int")


# Generated at 2022-06-23 20:20:58.289945
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    """Test constructor of class LiteralSortTypeMismatch"""
    literalsorttypemismatch = LiteralSortTypeMismatch(type(''), type(''))
    assert literalsorttypemismatch.kind == type('')
    assert literalsorttypemismatch.expected_kind == type('')


# Generated at 2022-06-23 20:21:00.822368
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    file_path = "my/path"
    error = IntroducedSyntaxErrors(file_path)
    assert error.file_path == file_path

# Generated at 2022-06-23 20:21:03.863184
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    testCode = '{"key": "value"}'
    testError = SyntaxError
    temp = LiteralParsingFailure(testCode, testError)
    assert temp.code == testCode
    assert temp.original_error == testError

# Generated at 2022-06-23 20:21:06.233354
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        print('Testing if ProfileDoesNotExist Error is thrown correctly')
        raise ProfileDoesNotExist('abc')
    except ProfileDoesNotExist as error:
        print('ProfileDoesNotExist Error thrown correctly')

# Generated at 2022-06-23 20:21:11.241023
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    t = IntroducedSyntaxErrors("/path/to/file.py")
    assert t.file_path == "/path/to/file.py"
    assert str(t) == "isort introduced syntax errors when attempting to sort the imports contained within /path/to/file.py."

# Generated at 2022-06-23 20:21:15.549262
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "from_first": {"value": True, "source": "from_first"},
        "from_first_comment": {"value": "#from_first", "source": "from_first_comment"},
    }
    UnsupportedSettings(unsupported_settings)

# Generated at 2022-06-23 20:21:21.356878
# Unit test for constructor of class MissingSection
def test_MissingSection():
    exc = MissingSection('a', 'b')
    assert str(exc) == 'Found a import while parsing, but b was not included in the `sections` setting of your config. Please add it before continuing\nSee https://pycqa.github.io/isort/#custom-sections-and-ordering for more info.'
    assert exc.import_module == 'a'
    assert exc.section == 'b'

# Generated at 2022-06-23 20:21:24.132105
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        raise SyntaxError()
    except Exception as e:
        raise LiteralParsingFailure('a = 1\n'
                                    'b = 2', e)

# Generated at 2022-06-23 20:21:27.964516
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(bytes, str)
    except LiteralSortTypeMismatch as e:
        assert str(e) == (
            "isort was told to sort a literal of type <class 'str'> but was given "
            "a literal of type <class 'bytes'>"
        )

# Generated at 2022-06-23 20:21:33.261416
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    fpath = 'abc.py'
    msg = f"isort was told to sort imports within code that contains syntax errors: {fpath}."
    try:
        raise ExistingSyntaxErrors(fpath)
    except ExistingSyntaxErrors as e:
        assert e.file_path == fpath
        assert str(e) == msg


# Generated at 2022-06-23 20:21:37.814150
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    import os
    try:
        raise IntroducedSyntaxErrors(os.path.realpath("test_IntroducedSyntaxErrors"))
    except IntroducedSyntaxErrors as e:
        print(e.file_path)
    else:
        assert (False)


# Generated at 2022-06-23 20:21:42.632016
# Unit test for constructor of class FileSkipComment
def test_FileSkipComment():
    """Unit test for constructor of class FileSkipComment"""
    file_path = "test_file_path"
    exception_object = FileSkipComment(file_path=file_path)
    assert exception_object is not None
    assert exception_object.message == file_path + " contains an file skip comment and was skipped."

# Generated at 2022-06-23 20:21:49.967832
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    code = "a = 1\nb = 2"
    expected_msg = "isort was told to sort a section of assignments, however the given code:\n\n" \
                   f"{code}\n\n" \
                   "Does not match isort's strict single line formatting requirement for assignment " \
                   "sorting:\n\n" \
                   "{variable_name} = {value}\n" \
                   "{variable_name2} = {value2}\n" \
                   "...\n\n"

    error = AssignmentsFormatMismatch(code=code)
    assert error.msg == expected_msg

# Generated at 2022-06-23 20:21:51.823430
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    err = IntroducedSyntaxErrors("file_path")
    assert err.file_path == "file_path"

# Generated at 2022-06-23 20:21:55.606625
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(4, '4')
    except LiteralSortTypeMismatch as instance:
        assert instance.kind == 4
        assert instance.expected_kind == '4'
        assert str(instance) == (
            "isort was told to sort a literal of type 4 but was given "
            "a literal of type 4."
        )

# Generated at 2022-06-23 20:21:57.493137
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
  code = " a=1\nb=2\n"
  AssignmentsFormatMismatch(code)

# Generated at 2022-06-23 20:21:58.879988
# Unit test for constructor of class MissingSection
def test_MissingSection():
    error = MissingSection('import_module', 'section')
    assert error.import_module == 'import_module'
    assert error.section == 'section'

# Generated at 2022-06-23 20:22:01.501979
# Unit test for constructor of class FormattingPluginDoesNotExist
def test_FormattingPluginDoesNotExist():
    formatter = "black"
    error = FormattingPluginDoesNotExist(formatter)
    assert error.formatter == formatter

# Generated at 2022-06-23 20:22:02.885186
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    FileSkipped('msg', 'file_path')


# Generated at 2022-06-23 20:22:05.513671
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    raised = False
    try:
        raise LiteralParsingFailure("", ValueError("Something went wrong"))
    except LiteralParsingFailure:
        raised = True
    assert raised


# Generated at 2022-06-23 20:22:07.429996
# Unit test for constructor of class UnsupportedEncoding
def test_UnsupportedEncoding():
    filename = "file_name.py"

    # No exception
    exp = UnsupportedEncoding(filename)
    assert exp.filename == filename

# Generated at 2022-06-23 20:22:12.602710
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    opts = {
        "show_log_file_and_line": {"value": None, "source": "Config"},
        "from_first": {"value": None, "source": "Config"},
        "skip_glob": {"value": None, "source": "Config"},
        "skip": {"value": None, "source": "Config"},
    }
    err = UnsupportedSettings(opts)
    print(err.unsupported_settings)
    print(err)


if __name__ == "__main__":
    test_UnsupportedSettings()

# Generated at 2022-06-23 20:22:16.000930
# Unit test for constructor of class MissingSection
def test_MissingSection():

    import_module = 'module'
    section = 'section'
    exception = MissingSection(import_module, section)

    assert exception.import_module == import_module
    assert exception.section == section

# Generated at 2022-06-23 20:22:18.072791
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    e = FileSkipped("message", "path")
    assert e.message == "message"
    assert e.file_path == "path"

# Generated at 2022-06-23 20:22:20.001317
# Unit test for constructor of class MissingSection
def test_MissingSection():
    m = MissingSection('import_module', 'section')
    assert m.import_module == 'import_module'
    assert m.section == 'section'

# Generated at 2022-06-23 20:22:23.899168
# Unit test for constructor of class ExistingSyntaxErrors
def test_ExistingSyntaxErrors():
    with pytest.raises(ExistingSyntaxErrors, match='contains an file skip comment '
                                                   'and was skipped.'):
        raise ExistingSyntaxErrors(file_path="test")

# Generated at 2022-06-23 20:22:25.883280
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    assert InvalidSettingsPath('settings_path')
    assert InvalidSettingsPath('settings_path').settings_path == 'settings_path'


# Generated at 2022-06-23 20:22:29.314263
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = b + 1\nc = d + 2\n")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = b + 1\nc = d + 2\n"

# Generated at 2022-06-23 20:22:32.133197
# Unit test for constructor of class LiteralParsingFailure
def test_LiteralParsingFailure():
    try:
        error = SyntaxError("error")
        LiteralParsingFailure("code", error)
    except Exception as e:
        assert str(e) == "isort failed to parse the given literal code. It's important to note " \
                         "that isort literal sorting only supports simple literals parsable by " \
                         "ast.literal_eval which gave the exception of error."