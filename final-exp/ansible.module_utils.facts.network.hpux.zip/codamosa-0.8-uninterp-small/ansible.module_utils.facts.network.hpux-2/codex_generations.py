

# Generated at 2022-06-24 22:50:29.354744
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0._get_default_interfaces() == {
        'default_gateway': '10.0.0.1', 'default_interface': 'lan0'
    }


# Generated at 2022-06-24 22:50:32.953032
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.facts == {}

# Generated at 2022-06-24 22:50:34.373749
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

# Generated at 2022-06-24 22:50:40.152735
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Initialize a HPUXNetwork object
    h_p_u_x_network_0 = HPUXNetwork()
    # Test with a mock data set
    test_params = {'default_interface': 'lan0',
                   'default_gateway': '192.168.0.1'}
    h_p_u_x_network_0.collect(test_params)


# Generated at 2022-06-24 22:50:46.415554
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    assert h_p_u_x_network_0.provider == 'HP-UX'
    assert h_p_u_x_network_0.provider == 'HP-UX'


# Generated at 2022-06-24 22:50:49.868197
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:50:53.426022
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_default_interfaces() == {'default_interface': 'lan1', 'default_gateway': '10.45.87.1'}


# Generated at 2022-06-24 22:50:58.554339
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Test when command returns a zero exit status
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network.module.exit_json = exit_json
    h_p_u_x_network.module.run_command = run_command
    out, err = h_p_u_x_network.get_interfaces_info()
    assert err is None
    assert out == 'out'


# Generated at 2022-06-24 22:51:06.540011
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(None)
    result = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:51:12.579037
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network = HPUXNetwork(None, 'h_p_u_x_network')
    h_p_u_x_network_populate_result = h_p_u_x_network.populate()
    if h_p_u_x_network_populate_result.get('interfaces') == ['lan0']:
        pass
    elif "lan0" in h_p_u_x_network_populate_result.get('interfaces'):
        pass
    else:
        pass


# Generated at 2022-06-24 22:51:23.544004
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0, "default          10.128.10.1       UG        0        0        lan0", ""))
    h_p_u_x_network_0_return = h_p_u_x_network_0.get_interfaces_info()
    assert h_p_u_x_network_0_return == {}
    

# Generated at 2022-06-24 22:51:26.117303
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    assert type(h_p_u_x_network_0.get_interfaces_info()) == dict


# Generated at 2022-06-24 22:51:28.509299
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()


# Generated at 2022-06-24 22:51:35.000004
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux.network import HPUXNetwork

    h_p_u_x_network_0 = HPUXNetwork()

    assert h_p_u_x_network_0.get_default_interfaces() == {'default_interface': 'lan1', 'default_gateway': '192.0.2.1'}


# Generated at 2022-06-24 22:51:41.026094
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_1._fact_class == HPUXNetwork, 'AssertionError'


# Generated at 2022-06-24 22:51:45.726403
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()
    assert h_p_u_x_network is not None


# Generated at 2022-06-24 22:51:47.623779
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork()

# Generated at 2022-06-24 22:51:54.396360
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    output = h_p_u_x_network_0.get_interfaces_info()
    assert output == {'lan2': {'ipv4': {'address': 'fe80::21b:cbff:feae:8a93/64', 'network': 'fe80/64', 'interface': 'lan2'}, 'device': 'lan2'}}

# Generated at 2022-06-24 22:51:57.619594
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()
    assert(h_p_u_x_network_0.facts == {})


# Generated at 2022-06-24 22:51:59.939214
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_net = HPUXNetwork({})
    result = h_p_u_x_net.populate()
    assert result is not None


# Generated at 2022-06-24 22:52:11.338265
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()


# Generated at 2022-06-24 22:52:14.452130
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()



# Generated at 2022-06-24 22:52:21.913827
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = HPUXNetwork(module=None)

    h_p_u_x_network_collector_0.collect(h_p_u_x_network_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 22:52:24.209939
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    try:
        test_case_0()
    except Exception as err:
        print('FAILURE: HP-UX network collection unit test failed: {}'.format(err))



# Generated at 2022-06-24 22:52:29.231062
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """Test get_default_interfaces"""
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    assert h_p_u_x_network_0.get_default_interfaces() == {'default_interface': 'lo0',
                                                         'default_gateway': '127.0.0.1'}


# Generated at 2022-06-24 22:52:31.920958
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()
    assert h_p_u_x_network.get_default_interfaces() is not None, "constructor of class 'HPUXNetwork' is broken"


# Generated at 2022-06-24 22:52:42.698212
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    get_default_interfaces() returns a dictionary of default interface information
    """
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = AnsibleModuleMock()
    h_p_u_x_network_0.module.run_command = MagicMock()
    h_p_u_x_network_0.module.run_command.return_value = (0,
        "default:\n"
        "default  ip.ip.ip.ip   ip.ip.ip.ip   UGS\n"
        "ip.ip.ip.ip   0.0.0.0         UH", "")

    default_interfaces = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:52:45.072498
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert h_p_u_x_network_collector is not None


# Generated at 2022-06-24 22:52:49.447625
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:52:57.497438
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module.run_command = Mock(return_value=(0, '', ''))
    assert h_p_u_x_network_0.get_interfaces_info() == {}
    h_p_u_x_network_0.module.run_command = Mock(return_value=(2, 'out', 'err'))
    assert h_p_u_x_network_0.get_interfaces_info() == {}
    h_p_u_x_network_0.module.run_command = Mock(return_value=(0, 'lan0:', ''))
    assert h_p_u_x_network_0.get_interfaces_info() == {}
    h_p_u

# Generated at 2022-06-24 22:53:22.035235
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork({})
    assert h_p_u_x_network_0.get_default_interfaces() == {
        'default_gateway': '10.9.134.1',
        'default_interface': 'lan0'}


# Generated at 2022-06-24 22:53:22.955902
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:53:31.118007
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():

    # This class is a subclass of NetworkCollector
    #         | NetworkCollector
    #         | |
    #         | |
    #         | |
    #         | |
    #         | |
    #         | |
    #         | |
    #         | |
    #         | |
    #         | |
    #         | |
    #   _fact_class should be HPUXNetwork
    assert issubclass(HPUXNetworkCollector._fact_class, Network) is True, \
        '_fact_class of class HPUXNetworkCollector should be subclass ' \
        'class HPUXNetwork'

    #   _platform should be "HP-UX"

# Generated at 2022-06-24 22:53:33.426776
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = AnsibleModule(
        argument_spec={})
    h_p_u_x_network_0.module.run_command = mock.Mock(return_value=(0, '', ''))
    rc, out, err = h_p_u_x_network_0.get_interfaces_info()



# Generated at 2022-06-24 22:53:34.589373
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.platform == 'HP-UX'

# Generated at 2022-06-24 22:53:40.984386
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    # test for instantiation of class HPUXNetworkCollector
    assert type(h_p_u_x_network_collector_0) == HPUXNetworkCollector


# Generated at 2022-06-24 22:53:45.355267
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'
    assert h_p_u_x_network_collector_0._non_expandables == ['interfaces']

# Generated at 2022-06-24 22:53:46.494689
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()

# Generated at 2022-06-24 22:53:54.431514
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    h_p_u_x_net_facts = net.populate()

    assert(net.platform == 'HP-UX')
    assert(h_p_u_x_net_facts['default_interface'] == 'lan100')
    assert(h_p_u_x_net_facts['default_gateway'] == '172.16.1.1')

    assert(h_p_u_x_net_facts['interfaces'] == ['lan100'])

    assert(h_p_u_x_net_facts['lan100']['device'] == 'lan100')
    assert(h_p_u_x_net_facts['lan100']['ipv4']['address'] == '172.16.1.98')

# Generated at 2022-06-24 22:53:56.569018
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert False

# Generated at 2022-06-24 22:54:41.743021
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    if h_p_u_x_network_collector_0._collector is 'HPUXNetwork':
        print('pass')
        print(h_p_u_x_network_collector_0._collector)
    else:
        print('fail')
        print(h_p_u_x_network_collector_0._collector)



# Generated at 2022-06-24 22:54:47.292283
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:54:51.666341
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'



# Generated at 2022-06-24 22:54:54.231483
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    HPUXNetwork.populate(h_p_u_x_network_0)


# Generated at 2022-06-24 22:54:58.460161
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces_facts = h_p_u_x_network_0.get_default_interfaces()
    assert (default_interfaces_facts['default_interface'] != '' or
            default_interfaces_facts['default_gateway'] != '')


# Generated at 2022-06-24 22:55:02.871724
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:55:12.160980
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    result = h_p_u_x_network_0.get_interfaces_info()
    assert result['lan0'] == {'device': 'lan0', 'ipv4': {'address': '11.1.1.1', 'network': '11.0.0.0', 'interface': 'lan0'}}
    assert result['lan1'] == {'device': 'lan1', 'ipv4': {'address': '11.1.1.1', 'network': '11.0.0.0', 'interface': 'lan1'}}


# Generated at 2022-06-24 22:55:15.669611
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0._platform is not None

# Generated at 2022-06-24 22:55:17.450857
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:55:25.883448
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    # Test 0: Get default interfaces on HPUX
    h_p_u_x_network_0 = HPUXNetwork(dict())
    h_p_u_x_network_0.module = MagicMock()

# Generated at 2022-06-24 22:57:12.547503
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:57:19.199742
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_network = HPUXNetwork()

    hpux_network.module.run_command = run_command_result_0
    hpux_network.get_interfaces_info = get_interfaces_info_result_0

    hpux_network.populate()



# Generated at 2022-06-24 22:57:21.674717
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.populate() is not None


# Generated at 2022-06-24 22:57:28.896089
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network = HPUXNetwork()
    out = h_p_u_x_network.get_default_interfaces()
    assert type(out) is dict
    assert 'default_gateway' in out
    assert out['default_gateway'] == '10.33.0.1'
    assert 'default_interface' in out
    assert out['default_interface'] == 'lan2'


# Generated at 2022-06-24 22:57:33.276397
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = h_p_u_x_network_collector_0._fact_class()
    out = h_p_u_x_network_0.get_default_interfaces()
    print(out)


# Generated at 2022-06-24 22:57:37.334301
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()



# Generated at 2022-06-24 22:57:39.009933
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:57:46.021797
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()

# Generated at 2022-06-24 22:57:50.284106
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork


# Generated at 2022-06-24 22:57:56.669720
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network.module = MockModule()

# Generated at 2022-06-24 23:00:00.633580
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    int_0 = 1
    str_0 = 'uMo>&F'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    try:
        h_p_u_x_network_0.get_interfaces_info()
        assert False
    except (AttributeError, NameError, TypeError):
        assert True



# Generated at 2022-06-24 23:00:05.069033
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'd4kDD'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 23:00:10.671504
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'


# Generated at 2022-06-24 23:00:20.355739
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0, "default 192.168.1.1 UGS", ""))
    h_p_u_x_network_0.get_interfaces_info = MagicMock(return_value={
        'lan0': {
            'ipv4': {
                'interface': 'lan0',
                'address': '192.168.1.2',
                'network': '192.168.1.0'},
            'device': 'lan0'
            }
        })
    var_1 = h_p_u_x_network_0.populate()
    var_2 = var_1['default_interface']
    assert var_