

# Generated at 2022-06-24 22:50:30.810756
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork({"ansible_facts": {"ansible_net_interfaces": ["lan0"]}})
    assert h_p_u_x_network_0.populate() == {'default_interface': None, 'default_gateway': None, 'interfaces': ['lan0'], 'lan0': {'device': 'lan0', 'ipv4': {'network': '192.168.202.0', 'interface': 'lan0', 'address': '192.168.202.199'}}}


# Generated at 2022-06-24 22:50:35.954477
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network.module.run_command = MagicMock(side_effect=lambda x: (0, '', ''))
    h_p_u_x_network.module.get_bin_path = MagicMock(return_value=False)

    h_p_u_x_network.populate()


# Generated at 2022-06-24 22:50:42.349125
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Unit test to get default interfaces
    h_p_u_x_network = HPUXNetwork()
    result = h_p_u_x_network.get_default_interfaces()
    assert len(result) > 0
    assert 'default_interface' in result


# Generated at 2022-06-24 22:50:47.856321
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces_facts = h_p_u_x_network_0.get_default_interfaces()
    assert default_interfaces_facts is not None


# Generated at 2022-06-24 22:50:50.872045
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:50:58.968649
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.running = False
    h_p_u_x_network_0.changed = False
    h_p_u_x_network_0.failed = False
    h_p_u_x_network_0.module = None
    h_p_u_x_network_0.warnings = []
    h_p_u_x_network_0.no_log_values = []
    h_p_u_x_network_0.check_mode = False
    expected = {'default_gateway': '192.168.1.1', 'default_interface': 'lan0'}
    actual = h_p_u_x_network_0.get_default_interfaces()
   

# Generated at 2022-06-24 22:51:01.013396
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert not HPUXNetwork(None)

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork()

# Generated at 2022-06-24 22:51:04.430329
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:06.204753
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:51:07.771736
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:14.588327
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:51:19.782033
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert isinstance(h_p_u_x_network_collector_0,NetworkCollector)



# Generated at 2022-06-24 22:51:22.016667
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate({})


# Generated at 2022-06-24 22:51:23.309991
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:51:30.111637
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_1._fact_class is HPUXNetwork
    assert h_p_u_x_network_collector_1._platform is 'HP-UX'
    assert h_p_u_x_network_collector_1._network_class_map is {}
    assert h_p_u_x_network_collector_1._fact_class_map is {}


# Generated at 2022-06-24 22:51:33.434688
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network = HPUXNetwork()
    default_result = h_p_u_x_network.get_default_interfaces()
    assert 'default_interface' in default_result
    assert 'default_gateway' in default_result


# Generated at 2022-06-24 22:51:39.698153
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Test 1
    h_p_u_x_network_0 = HPUXNetwork()
    network_facts = h_p_u_x_network_0.populate()
    # The following check needs to be improved, as eth0 is not always the default interface
    # assert network_facts['default_interface'] == 'lan0'

test_case_0()
test_HPUXNetwork_populate()

# Generated at 2022-06-24 22:51:43.782873
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert h_p_u_x_network_collector_0._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_0._fact_class is not HPUXNetwork
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'
    assert h_p_u_x_network_collector_0._platform is not 'HP-UX'

# Generated at 2022-06-24 22:51:46.760964
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    assert HPUXNetwork().get_interfaces_info() == {'lan0': {'device': 'lan0', 'ipv4': {'address': '10.100.100.50', 'network': '10.100.100.0', 'interface': 'lan0'}}}


# Generated at 2022-06-24 22:51:47.995028
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)

# Generated at 2022-06-24 22:51:57.269158
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:52:03.061844
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    result = h_p_u_x_network_0.get_interfaces_info()
    assert result is not None


# Generated at 2022-06-24 22:52:07.974090
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\x1c\x9b'
    float_0 = 0.04750388
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    assert h_p_u_x_network_0.get_interfaces_info() == {}


# Generated at 2022-06-24 22:52:11.910506
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    print(var_0)


# Generated at 2022-06-24 22:52:16.411090
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    h_p_u_x_network_1 = HPUXNetwork(bytes_0, float_0)
    h_p_u_x_network_1.facts = {}
    var_0 = h_p_u_x_network_1.populate()


# Generated at 2022-06-24 22:52:21.825005
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)


# Generated at 2022-06-24 22:52:22.731355
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    pass


# Generated at 2022-06-24 22:52:30.841941
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'K\xfd\xbb\x1b\x18'
    float_0 = 1.15
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    dict_0 = h_p_u_x_network_0.populate()
    assert 'interfaces' == dict_0.keys()[0]
    assert 'default_interface' == dict_0.keys()[1]
    assert 'default_gateway' == dict_0.keys()[2]
    assert 'lo0' == dict_0['interfaces'][0]
    dict_1 = dict_0['lo0']
    assert 'ipv4' == dict_1.keys()[0]
    dict_2 = dict_1['ipv4']

# Generated at 2022-06-24 22:52:35.003855
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'j\x12\x86\xf1'
    float_0 = 798.68
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    h_p_u_x_network_0.module = MagicMock()
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:52:41.111717
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var__0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:52:57.071113
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0, float_0)
    var_0 = h_p_u_x_network_collector_0.collect()

# Generated at 2022-06-24 22:53:04.024509
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:53:11.837739
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:53:17.305913
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    obj = HPUXNetwork(bytes_0, float_0)
    assert 'default_interface' in obj.populate()


# Generated at 2022-06-24 22:53:22.264394
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\xef\xff'
    float_0 = 514.1
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    print(h_p_u_x_network_0.interfaces)



# Generated at 2022-06-24 22:53:29.365786
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    dict_0 = {
        'default_interface': 'lan1',
        'default_gateway': '172.16.0.1'
    }
    dict_1 = h_p_u_x_network_0.get_default_interfaces()
    assert dict_0 == dict_1


# Generated at 2022-06-24 22:53:35.353128
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'l\xcb\x1b\xea\x8e\xc0\x9d'
    float_0 = 8.07
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0 is not None
    assert var_0 == {}


# Generated at 2022-06-24 22:53:39.501558
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:53:45.282641
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    default_interfaces_facts = h_p_u_x_network_0.get_default_interfaces()
    expected = {'default_gateway': '172.17.1.1', 'default_interface': 'lan2'}
    assert default_interfaces_facts == expected


# Generated at 2022-06-24 22:53:49.391248
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:54:18.977002
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\x9f\x07\x1c\xe6'
    float_0 = 640.78
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0, float_0)
    var_0 = h_p_u_x_network_collector_0._fact_class
    var_1 = h_p_u_x_network_collector_0._platform
    # TODO: Test if the values of var_0 and var_1 are equal to their expected values.
    # assert var_0 == expected_var_0 ...
    # assert var_1 == expected_var_1 ...


# Generated at 2022-06-24 22:54:23.739139
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:54:25.972380
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Test the number of attributes in the return dictionary.
    assert len(test_case_0()) == 3

# Generated at 2022-06-24 22:54:33.159124
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    h_p_u_x_network_0.fact_module.get_bin_path = lambda x:x
    h_p_u_x_network_0.module.run_command = lambda x: (0, "", "")
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:54:38.590665
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    # assert h_p_u_x_network_0.get_default_interfaces() == 'lan0'


# Generated at 2022-06-24 22:54:43.050797
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:54:45.611713
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0, float_0)

# Generated at 2022-06-24 22:54:52.058012
# Unit test for constructor of class HPUXNetworkCollector

# Generated at 2022-06-24 22:54:59.334069
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:55:01.348409
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:55:56.700367
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    try:
        var_0 = h_p_u_x_network_0.get_default_interfaces()
    except:
        var_0 = None
    assert var_0 == None


# Generated at 2022-06-24 22:56:01.190266
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:06.594485
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    c_h_p_u_x_network_0 = HPUXNetwork()
    var_0 = c_h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:56:07.146850
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass

# Generated at 2022-06-24 22:56:11.087714
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'#'
    float_0 = 3.41163325597579e-05
    class_0 = HPUXNetworkCollector(bytes_0, float_0)
    assert isinstance(class_0, NetworkCollector)
    assert hasattr(class_0, '_fact_class')
    assert hasattr(class_0, '_platform')


# Generated at 2022-06-24 22:56:12.866165
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_1 = b'\r`\x18\xb6,'
    float_1 = 550.3
    HPUXNetwork(bytes_1, float_1)


# Generated at 2022-06-24 22:56:16.350556
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\x10\x10\x16\x0e'
    float_0 = 12.7450421456
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    assert h_p_u_x_network_0.get_default_interfaces() == {}


# Generated at 2022-06-24 22:56:22.049814
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:56:27.530925
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
	bytes_0 = b'\r`\x18\xb6,'
	float_0 = 550.3
	h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0, float_0)

# Generated at 2022-06-24 22:56:34.929824
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b"\x18\xf0\x9f\x8d\xbb"
    float_0 = 562.8
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    # get_default_interfaces() implementation
    assert True # TODO: implement your test here
    # get_interfaces_info() implementation
    assert True # TODO: implement your test here
    # populate() implementation
    assert True # TODO: implement your test here


# Generated at 2022-06-24 22:58:38.963147
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0, float_0)
    assert isinstance(h_p_u_x_network_collector_0, HPUXNetworkCollector)

# Generated at 2022-06-24 22:58:47.425282
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\x00\x01a\x00\x80\x92`\x1a\x00\x00\x01\x00\x80\x92`\x1a\x00\x00'
    float_0 = 9.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0 == {}, "Returned value {} did not equal {}".format(var_0, {},)


# Generated at 2022-06-24 22:58:54.250016
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    assert h_p_u_x_network_0._module == bytes_0
    assert h_p_u_x_network_0.cache_ttl == float_0
    assert h_p_u_x_network_0.platform == 'HP-UX'


# Generated at 2022-06-24 22:58:58.052636
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:59:07.703675
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:59:12.094573
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_class = 'ansible.module_utils.facts.network.hpux.HPUXNetwork'
    platform = 'HP-UX'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(fact_class, platform)


# Generated at 2022-06-24 22:59:20.204994
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0, float_0)
    var_0 = h_p_u_x_network_collector_0.get_default_interfaces()

test_case_0()
test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:59:22.475175
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0, float_0)


# Generated at 2022-06-24 22:59:26.971349
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_0 = HPUXNetwork(bytes_0, float_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:59:33.067804
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\r`\x18\xb6,'
    float_0 = 550.3
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0, float_0)
    assert isinstance(h_p_u_x_network_collector_0, HPUXNetworkCollector)
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'
