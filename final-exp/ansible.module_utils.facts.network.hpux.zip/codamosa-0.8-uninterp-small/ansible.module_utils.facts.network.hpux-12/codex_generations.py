

# Generated at 2022-06-24 22:50:34.111422
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    # Tests instantiation of class HPUXNetworkCollector
    assert isinstance(h_p_u_x_network_collector_0, HPUXNetworkCollector)



# Generated at 2022-06-24 22:50:39.311767
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    assert isinstance(h_p_u_x_network_collector_1,
                      HPUXNetworkCollector)


if __name__ == '__main__':
    test_case_0()
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:50:40.984863
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_interfaces_info() is None


# Generated at 2022-06-24 22:50:49.711224
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    rc_0, out_0, err_0 = h_p_u_x_network_0.module.run_command("/usr/bin/netstat -niw")
    assert h_p_u_x_network_0.get_interfaces_info() == {
        'lan0': {
            'ipv4': {
                'address': '10.0.2.15',
                'network': '10.0.2.0',
                'interface': 'lan0'},
            'device': 'lan0'
        }
    }


# Generated at 2022-06-24 22:50:53.266907
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_default_interfaces() == {
        'default_interface': 'lan0',
        'default_gateway': '192.168.1.1'
    }


# Generated at 2022-06-24 22:50:55.115423
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_object = HPUXNetwork()
    print(h_p_u_x_network_object)


# Generated at 2022-06-24 22:51:00.540756
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:02.273045
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:07.416842
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_2 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_2._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_2._platform == 'HP-UX'


# Generated at 2022-06-24 22:51:15.563916
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = mock.MagicMock()
    h_p_u_x_network_0.module.run_command.return_value = (1, 'stdout', 'stderr')
    assert h_p_u_x_network_0.populate() == {}
    h_p_u_x_network_0.module.run_command.assert_called_once_with("/usr/bin/netstat -niw")


# Generated at 2022-06-24 22:51:22.297788
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork_instance = HPUXNetwork()
    assert isinstance(HPUXNetwork_instance, HPUXNetwork)


# Generated at 2022-06-24 22:51:27.463535
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()

    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:29.401921
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()


# Generated at 2022-06-24 22:51:29.964452
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass

# Generated at 2022-06-24 22:51:38.538127
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = HPUXNetwork()

    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0, '/usr/bin/netstat', ''))
    h_p_u_x_network_0.module.get_bin_path = MagicMock(return_value=None)

    h_p_u_x_network_0.populate()

    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0, '/usr/bin/netstat', ''))

# Generated at 2022-06-24 22:51:40.280585
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:43.780325
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Unit test for method HPUXNetwork.get_default_interfaces
    """
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:51:50.249229
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
# Test if the constructor raises a ValueError
# when the run_command method of the module class argument is not callable
    try:
        h_p_u_x_network_collector_0 = HPUXNetworkCollector(get_bin_path=None)
    except ValueError:
        pass

# Test if the constructor raises a ValueError
# when the module argument is missing the run_command method
    try:
        h_p_u_x_network_collector_0 = HPUXNetworkCollector(get_bin_path=None)
    except ValueError:
        pass

# Generated at 2022-06-24 22:51:57.993698
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netstat_path = "/usr/bin/netstat"
    h_p_u_x_network_0 = HPUXNetwork(None, netstat_path)
    default_interfaces_0 = h_p_u_x_network_0.get_default_interfaces()
    assert 'default_interface' in default_interfaces_0
    assert 'default_gateway' in default_interfaces_0


# Generated at 2022-06-24 22:52:02.813564
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = h_p_u_x_network_collector_0.collect()
    h_p_u_x_network_default_iface = h_p_u_x_network_0.get_default_interfaces()
    assert h_p_u_x_network_default_iface == {'default_interface': 'lan0',
                                             'default_gateway': '172.22.0.3'}


# Generated at 2022-06-24 22:52:11.353167
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()



# Generated at 2022-06-24 22:52:15.863328
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Initialize object of class HPUXNetwork
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)

    # Call method get_interfaces_info of class HPUXNetwork
    var_0 = h_p_u_x_network_0.get_interfaces_info()



# Generated at 2022-06-24 22:52:20.867603
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = '`@e{=n|$'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)


# Generated at 2022-06-24 22:52:28.178926
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '#<8www,W'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert isinstance(h_p_u_x_network_0, Network)
    str_1 = '\n\\B>cTbQU'
    h_p_u_x_network_1 = HPUXNetwork(str_1)
    assert isinstance(h_p_u_x_network_1, Network)
    assert isinstance(h_p_u_x_network_0, HPUXNetwork)
    assert isinstance(h_p_u_x_network_1, HPUXNetwork)


# Generated at 2022-06-24 22:52:35.873069
# Unit test for method populate of class HPUXNetwork

# Generated at 2022-06-24 22:52:41.341950
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    undef = None
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:52:45.110689
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = ''
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)
    str_0 = ''
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)


# Generated at 2022-06-24 22:52:49.543064
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._fact_class is HPUXNetwork
    assert HPUXNetworkCollector._platform is 'HP-UX'


# Generated at 2022-06-24 22:52:52.922441
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = '/A'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)
    h_p_u_x_network_collector_0.collect()

# Generated at 2022-06-24 22:53:01.352750
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    str_1 = 'default_interface'
    str_2 = 'default_gateway'
    str_3 = 'default'
    str_4 = '1.1.1.1'
    str_5 = '1.1.1.0'
    default_interfaces_0 = h_p_u_x_network_0.get_default_interfaces()
    interfaces_0 = h_p_u_x_network_0.get_interfaces_info()
    var_0 = h_p_u_x_network_0.populate()
    str_6 = 'default'
    str_7 = 'eth0'
    str_8

# Generated at 2022-06-24 22:53:13.269142
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    if HPUXNetworkCollector is not None:
        try:
            test_case_0()
        except:
            assert False
    else:
        assert False

# Generated at 2022-06-24 22:53:24.570596
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    str_1 = '5@lv^XF}'
    h_p_u_x_network_1 = HPUXNetwork(str_1)
    str_2 = 'l*J@jS(%'
    h_p_u_x_network_2 = HPUXNetwork(str_2)
    str_3 = '@R{O(O)>'
    h_p_u_x_network_3 = HPUXNetwork(str_3)
    str_4 = 'PGi,t#g.'
    h_p_u_x_network_4 = HPUXNetwork(str_4)

# Generated at 2022-06-24 22:53:28.093091
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0 == '{{ }}'

# Generated at 2022-06-24 22:53:34.702421
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 is not None


# Generated at 2022-06-24 22:53:38.863170
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector((str_0))
    var_0 = h_p_u_x_network_collector_0.platform
    print(var_0)


# Generated at 2022-06-24 22:53:47.166845
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_1 = '\n\\B>cTbQU'
    h_p_u_x_network_1 = HPUXNetwork(str_1)
    h_p_u_x_network_1.populate()
    var_1 = h_p_u_x_network_1.populate()

# Generated at 2022-06-24 22:53:51.969181
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    # Constructor of class HPUXNetwork
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)

    # Test for method get_default_interfaces
    test_case_0()



# Generated at 2022-06-24 22:53:56.983775
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    test_HPUXNetwork_get_default_interfaces method
    """
    str_0 = 'T$Ia'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()



# Generated at 2022-06-24 22:54:05.565419
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(
        str_0)  # Constructor test case
    var_0 = h_p_u_x_network_collector_0.get_interfaces_info()
    # Unit test for method get_default_interfaces of class HPUXNetworkCollector
    var_1 = h_p_u_x_network_collector_0.get_default_interfaces()
    # Unit test for method get_interfaces_info of class HPUXNetworkCollector
    var_2 = h_p_u_x_network_collector_0.get_interfaces_info()



# Generated at 2022-06-24 22:54:08.693590
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)
    var_0 = h_p_u_x_network_collector_0.platform == 'HP-UX'
    var_1 = h_p_u_x_network_collector_0.fact_class == HPUXNetwork


# Generated at 2022-06-24 22:54:31.628115
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_collector = HPUXNetworkCollector(str_0)
    print(h_p_u_x_network_collector)


# Generated at 2022-06-24 22:54:43.088757
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str1 = 'FC\x94\xeb'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str1)
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'
    assert h_p_u_x_network_collector_0._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_0._fact_class._platform == 'HP-UX'
    assert h_p_u_x_network_collector_0._fact_class._platform == h_p_u_x_network_collector_0._platform
    h_p_u_x_network_collector_1 = HPUXNetworkCollector(str1)
    assert h_p_u_x_network

# Generated at 2022-06-24 22:54:47.867466
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert h_p_u_x_network_0.module.run_command("/usr/bin/netstat -nr")
    assert h_p_u_x_network_0.module.run_command("/usr/bin/netstat -niw")


# Generated at 2022-06-24 22:54:52.975062
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = HPUXNetworkCollector(h_p_u_x_network_0)

# Generated at 2022-06-24 22:54:56.479635
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:59.120984
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    h_p_u_x_network_0 = HPUXNetwork()
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    var_1 = h_p_u_x_network_0.get_interfaces_info()
    var_2 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:55:03.324983
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork_populate()

# Generated at 2022-06-24 22:55:09.790192
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:55:15.179107
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert h_p_u_x_network_0._module == str_0
    assert h_p_u_x_network_0.platform == 'HP-UX'


# Generated at 2022-06-24 22:55:19.053030
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    h_p_u_x_network_0.get_interfaces_info()
    h_p_u_x_network_0.populate(collected_facts=None)

# Generated at 2022-06-24 22:56:07.655498
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)

# Generates a test case for class constructor

# Generated at 2022-06-24 22:56:10.960678
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_1 = ''
    h_p_u_x_network_1 = HPUXNetwork(str_1)
    assert h_p_u_x_network_1.platform == 'HP-UX'


# Generated at 2022-06-24 22:56:13.500932
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:16.241457
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()
    assert True


# Generated at 2022-06-24 22:56:21.391771
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:56:28.480262
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:37.296723
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Test cases
    testcase0 = (
        (['default 7.0.0.0 xyz0',
          'abc.xyz.com.in.  24.0.0.0  xyz1',
          'xyz2', ''],
        {'default_gateway': '7.0.0.0',
         'default_interface': 'xyz0'})
        )

    testcase1 = (
        (['default xyz2',
          'abc.xyz.com.in.  xyz1',
          'xyz0', ''],
        '''Unexpected output for netstat -nr''')
        )


# Generated at 2022-06-24 22:56:38.051725
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    assert True == True


# Generated at 2022-06-24 22:56:44.392197
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()
    print(var_0) # {'interfaces': ['lan9000e0', 'lan9000e1'], 'lan9000e1': {'ipv4': {'address': '10.2.1.20', 'network': '10.2.1.0', 'interface': 'lan9000e1'}}, 'lan9000e0': {'ipv4': {'address': '10.1.1.20', 'network': '10.1.1.0', 'interface': 'lan9000e0'}}, 'default_interface': 'lan9000e

# Generated at 2022-06-24 22:56:45.769185
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)


# Generated at 2022-06-24 22:58:42.159683
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()



# Generated at 2022-06-24 22:58:46.664622
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0



# Generated at 2022-06-24 22:58:49.945809
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_case_0()

    # Unit test for method get_interfaces_info of class HPUXNetwork
    
    # Unit test for method populate of class HPUXNetwork
    


# Generated at 2022-06-24 22:58:51.867473
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    try:
        h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    except:
        assert False


# Generated at 2022-06-24 22:58:59.499522
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    strData = '\x08^\x8a\xea\xd9\x9c'
    objHPUXNetwork = HPUXNetwork(strData)
    objDict = objHPUXNetwork.get_default_interfaces()
    assert type(objDict) == dict, 'Return type of get_default_interfaces is not dict'
    assert len(objDict) == 1, 'Invalid dict keys'
    assert "default_interface" in objDict, 'Invalid dict key'


# Generated at 2022-06-24 22:59:04.271882
# Unit test for constructor of class HPUXNetwork

# Generated at 2022-06-24 22:59:05.307027
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    assert False


# Generated at 2022-06-24 22:59:13.537861
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

    # Make sure the results look OK
    for i in var_0:
        assert ',' not in i



# Generated at 2022-06-24 22:59:17.592969
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    assert True == True



# Generated at 2022-06-24 22:59:21.380434
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = '\n\\B>cTbQU'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    h_p_u_x_network_0.populate(var_0)
