

# Generated at 2022-06-24 22:50:34.289551
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    result = h_p_u_x_network_0.get_default_interfaces()
    if result['default_interface'] == 'lan1':
        pass


# Generated at 2022-06-24 22:50:36.004196
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_case_0()

# Generated at 2022-06-24 22:50:38.564607
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:50:47.126810
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    default_interfaces = {u'default_interface': u'lan2', u'default_gateway': u'192.168.1.1'}
    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0, u'default 192.168.1.1 UG lan2 0 506\n', u''))
    assert h_p_u_x_network_0.get_default_interfaces() == default_interfaces


# Generated at 2022-06-24 22:50:52.035033
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    collected_facts = {}

# Call test method
    h_p_u_x_network_0.populate(collected_facts)


# Generated at 2022-06-24 22:50:53.586317
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    result1 = HPUXNetwork.get_default_interfaces(0)
    assert result1 is not None


# Generated at 2022-06-24 22:51:00.609199
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = ''
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    h_p_u_x_network_0.get_interfaces_info = MagicMock(return_value='value-out')
    h_p_u_x_network_0.get_default_interfaces = MagicMock(return_value='value-out')
    dict_0 = {}
    dict_0 = {'interfaces': 'value-out'}
    dict_0['default_interface'] = 'value-out'
    dict_0['default_gateway'] = 'value-out'
    dict_1 = {}
    dict_1 = dict_0
    return_value_0 = h_p_u_x_network_0.populate(dict_0)

# Generated at 2022-06-24 22:51:03.440062
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_case_0()


# Generated at 2022-06-24 22:51:06.032331
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert True


# Generated at 2022-06-24 22:51:09.486127
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)

    # There are no unit tests for this method, as it invokes code that is
    # not available in the testing environment.



# Generated at 2022-06-24 22:51:21.872331
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    if type(h_p_u_x_network_collector_0._fact_class) == type:
        #print("\n")
        assert True
    else:
        raise AssertionError("Failed: Constructor of class 'HPUXNetworkCollector' does not work as expected.")


# Generated at 2022-06-24 22:51:27.403495
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(
        module=None
    )


# Generated at 2022-06-24 22:51:29.105848
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:51:37.358019
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    print("Testing method get_default_interfaces")
    h_p_u_x_network_0 = HPUXNetwork(module=None)

    out = {}
    out['default_interface'] = 'lan0'
    out['default_gateway'] = '192.0.2.1'
    default_interfaces = h_p_u_x_network_0.get_default_interfaces()
    assert out['default_interface'] == default_interfaces['default_interface']
    assert out['default_gateway'] == default_interfaces['default_gateway']


# Generated at 2022-06-24 22:51:46.781979
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces_facts = h_p_u_x_network_0.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.168.56.1'
    mac_0 = h_p_u_x_network_0.get_default_interfaces()
    mac_1 = h_p_u_x_network_0.get_interfaces_info()
    mac_2 = h_p_u_x_network_0.populate()
    default_interfaces_facts = h_p_u_x_network_0.get_default_interfaces()

# Generated at 2022-06-24 22:51:48.980933
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    HPUXNetwork_0 = HPUXNetwork()
    # Test with valid parameters
    assert len(HPUXNetwork_0.get_interfaces_info()) > 0


# Generated at 2022-06-24 22:51:59.067763
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    network_facts = {}
    network_facts['default_interface'] = 'lan0'
    network_facts['default_gateway'] = '0.0.0.0'
    network_facts['interfaces'] = ['lan0', 'lan1']
    network_facts['lan0'] = {'device': 'lan0',
                             'ipv4': {'address': '198.51.100.7',
                                      'network': '198.51.100.0',
                                      'interface': 'lan0'}}

# Generated at 2022-06-24 22:52:01.874954
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:52:06.186075
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    print(h_p_u_x_network_0)

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork()

# Generated at 2022-06-24 22:52:08.643416
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()
    assert h_p_u_x_network.populate() is not False

# Generated at 2022-06-24 22:52:22.087378
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network = HPUXNetwork()
    interfaces = h_p_u_x_network.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0', 'ipv4': {'network': '172.16.0.0', 'interface': 'lan0', 'address': '172.16.0.1'}}

# Generated at 2022-06-24 22:52:22.643709
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert True == False

# Generated at 2022-06-24 22:52:24.812212
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:52:27.283511
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert isinstance(h_p_u_x_network_collector_0, NetworkCollector)


# Generated at 2022-06-24 22:52:30.299678
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    h_p_u_x_network_0 = HPUXNetwork(dict(), h_p_u_x_network_collector_1)


# Generated at 2022-06-24 22:52:33.318348
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:52:44.766657
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    available_data = {
        'default_interface': 'lan0',
        'default_gateway': '172.29.236.129',
        'interfaces': ['lan0'],
        'lan0': {
            'device': 'lan0',
            'ipv4': {
                'network': '172.29.236.128',
                'interface': 'lan0',
                'address': '172.29.236.130'
            }
        }
    }

    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = DummyModule(available_data)
    h_p_u_x_network_0.populate(collected_facts=available_data)


# Generated at 2022-06-24 22:52:49.413221
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:52:52.777393
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network_0 = HPUXNetwork('ansible_module')
    network_0.populate()

# Generated at 2022-06-24 22:52:56.386302
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_1 = HPUXNetwork()
    assert h_p_u_x_network_0 != h_p_u_x_network_1

# Generated at 2022-06-24 22:53:02.535379
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_case_0()



# Generated at 2022-06-24 22:53:12.869544
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert str_0 == h_p_u_x_network_0.module
    # test_case_0()
    # test_get_default_interfaces(h_p_u_x_network_0)
    # test_get_interfaces_info(h_p_u_x_network_0)
    # test_has_ipv4(h_p_u_x_network_0)
    # test_has_ipv6(h_p_u_x_network_0)
    # test_interface_name_cleanup(h_p_u_x_network_0)
    # test_interface_type(h_p_u_x_network_0)

# Generated at 2022-06-24 22:53:16.387768
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)


# Generated at 2022-06-24 22:53:20.259507
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    try:
        var_0 = h_p_u_x_network_0.get_default_interfaces()
    except:
        var_0 = None
    assert var_0 is None


# Generated at 2022-06-24 22:53:26.400513
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    # Test for interface
    str_1 = 'u'
    # Test for interface
    str_2 = 'u'
    # Test for interface
    str_3 = 'u'
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:53:34.280145
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = 'U'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'
    assert h_p_u_x_network_collector_0._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_0._fact_class._platform == 'HP-UX'


test_case_0()
test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:53:40.492081
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert h_p_u_x_network_0.get_default_interfaces() is None


# Generated at 2022-06-24 22:53:46.067430
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # TestCase setup
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    map_0 = dict()
    map_0['default_interface'] = 'lan1'
    map_0['default_gateway'] = '1.1.1.1'
    # TestCase
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == map_0


# Generated at 2022-06-24 22:53:48.904989
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork('lan1')
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:53:53.285127
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:54:07.978926
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    sys_platform = 'HP-UX'
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(h_p_u_x_network_0, sys_platform)


# Generated at 2022-06-24 22:54:11.478097
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:54:14.627027
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork('admin')
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:24.622755
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()

    var_0 = h_p_u_x_network_0.populate()

    var_0 = h_p_u_x_network_0.populate()

    var_0 = h_p_u_x_network_0.populate()

    var_0 = h_p_u_x_network_0.populate()

    var_0 = h_p_u_x_network_0.populate()

    var_0 = h_p_u_x_network_0.populate()

    var_0 = h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:54:28.226729
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:54:31.916514
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert str_0 == h_p_u_x_network_0.populate()
    

# Generated at 2022-06-24 22:54:36.406867
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()  # None


# Generated at 2022-06-24 22:54:40.310290
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:54:45.449522
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = '.'
    str_1 = '.'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0, str_1)

# Generated at 2022-06-24 22:54:46.972997
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)


# Generated at 2022-06-24 22:55:19.130368
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    netstat_path = '/usr/bin/netstat'
    rc = 1
    out = '''lan0          link#1             UP                                                192.168.0.0/23    lan0
lan1          link#2             UP                                                192.168.0.0/23    lan1
lan2                                                                                                  lan2
loopback      link#8             UP                                                127.0.0.1         lo0'''
    err = ''
    h_p_u_x_network_0 = HPUXNetwork(netstat_path)
    interfaces = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:55:20.323130
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'


# Generated at 2022-06-24 22:55:23.026973
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert h_p_u_x_network_0 is not None

# Generated at 2022-06-24 22:55:24.623375
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpu_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:55:27.284223
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'T'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:55:29.972416
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    print(__name__)
    print(test_case_0.__name__)
    test_case_0()

# Generated at 2022-06-24 22:55:34.755869
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    print('Testing method get_interfaces_info')
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    result = h_p_u_x_network_0.get_interfaces_info()
    print(result)
    print('Testing method get_interfaces_info done')

test_HPUXNetwork_get_interfaces_info()


# Generated at 2022-06-24 22:55:44.947070
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    # Test type of object h_p_u_x_network_0
    assert isinstance(h_p_u_x_network_0, object)
    # Test properties of object h_p_u_x_network_0
    assert h_p_u_x_network_0._platform == 'HP-UX'
    assert h_p_u_x_network_0._commands == {"/usr/bin/netstat -niw": {}}
    # Test methods of object h_p_u_x_network_0
    assert h_p_u_x_network_0.get_interfaces_info() == {}
    assert h_p_u_x_network_0.pop

# Generated at 2022-06-24 22:55:47.685007
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork('0')
    assert h_p_u_x_network_0 is not None


# Generated at 2022-06-24 22:55:48.703971
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_case_0()


# Generated at 2022-06-24 22:56:46.161596
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


if __name__ == '__main__':
    test_case_0()
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:56:49.618645
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # There is no test for constructor of class HPUXNetwork
    pass


# Generated at 2022-06-24 22:56:52.210657
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:56:54.197588
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:56:58.792739
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_case_0()

# Generated at 2022-06-24 22:57:01.123631
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 == {} or var_0 == None


# Generated at 2022-06-24 22:57:09.209820
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)

    assert h_p_u_x_network_0._module.get_bin_path('netstat') is None
    assert h_p_u_x_network_0._module.run_command is not None
    assert h_p_u_x_network_0._module._running_on_linux is False
    assert h_p_u_x_network_0.platform is 'HP-UX'
    assert h_p_u_x_network_0.installed_os_facts is str_0


# Generated at 2022-06-24 22:57:17.726900
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    result_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:57:20.977364
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == {}


# Generated at 2022-06-24 22:57:26.490686
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    test_case_0()

test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:59:35.323447
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    ansible_facts = {'ansible_os_family': 'Unix'}
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(ansible_facts)
    var_0 = h_p_u_x_network_collector_0.collect()
    assert var_0 is None

# Generated at 2022-06-24 22:59:38.337416
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    try:
        assert True
        print('Test for constructor of class HPUXNetwork passed')
    except AssertionError:
        print('Test for constructor of class HPUXNetwork failed')


# Generated at 2022-06-24 22:59:42.514786
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Arrange and act
    h_p_u_x_network_0 = HPUXNetwork('abc')
    var_0 = h_p_u_x_network_0.populate()

    # Assert
    assert var_0 is not None



# Generated at 2022-06-24 22:59:45.051418
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = 'U'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)


# Generated at 2022-06-24 22:59:50.466539
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork('U')
    assert callable(getattr(h_p_u_x_network_0, 'get_interfaces_info'))


# Generated at 2022-06-24 22:59:53.622878
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork('U')
    assert h_p_u_x_network_0.platform == 'HP-UX'


# Generated at 2022-06-24 22:59:58.171017
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    h_p_u_x_network_0.get_interfaces_info()
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:59:59.594057
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector(None)

# Generated at 2022-06-24 23:00:04.926171
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'U'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()

# Generated at 2022-06-24 23:00:08.043874
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    _fact_class = HPUXNetwork('U')
    _platform = 'HP-UX'
    _network_collector = HPUXNetworkCollector(_fact_class)
    assert _network_collector.fact_class.str_0 == 'U'
    assert _network_collector.platform == 'HP-UX'