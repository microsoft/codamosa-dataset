

# Generated at 2022-06-24 22:50:33.338614
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:50:39.114545
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = h_p_u_x_network_collector_0._fact_class(h_p_u_x_network_collector_0.module)
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:50:44.937574
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    # Testing __init__()
    assert isinstance(h_p_u_x_network_collector, HPUXNetworkCollector)


# Generated at 2022-06-24 22:50:49.456409
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces = h_p_u_x_network_0.get_default_interfaces()
    assert (default_interfaces['default_interface'] == 'lan0')
    assert (default_interfaces['default_gateway'] == '10.0.0.1')


# Generated at 2022-06-24 22:50:58.229249
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_net_0 = HPUXNetwork()

    interfaces_info_0 = h_p_u_x_net_0.get_interfaces_info()
    assert interfaces_info_0[u'lan0'] == {u'ipv4': {u'interface': u'lan0', u'network': u'10.0.0.0', u'address': u'10.0.0.2'}, u'device': u'lan0'}
    assert interfaces_info_0[u'lan1'] == {u'ipv4': {u'interface': u'lan1', u'network': u'192.168.34.0', u'address': u'192.168.34.17'}, u'device': u'lan1'}
    # Some HP-UX use different Ethernet

# Generated at 2022-06-24 22:51:00.867936
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces = h_p_u_x_network_0.get_default_interfaces()
    print("%s" % default_interfaces)


# Generated at 2022-06-24 22:51:09.525627
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    assert type(h_p_u_x_network_collector_1._fact_class) is type
    assert h_p_u_x_network_collector_1._fact_class is HPUXNetwork
    assert h_p_u_x_network_collector_1._platform is 'HP-UX'
    h_p_u_x_network_collector_1 = HPUXNetworkCollector(
        remote_host='user@example.org')

# Generated at 2022-06-24 22:51:14.586942
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_p_i_0 = HPUXNetwork()
    h_p_u_x_network_p_i_0.get_interfaces_info()

# Generated at 2022-06-24 22:51:18.828042
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)


# Generated at 2022-06-24 22:51:22.576223
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    h_p_u_x_network_0_0 = HPUXNetwork()
    h_p_u_x_network_1_0 = HPUXNetwork()
    # 1. Call to get_default_interfaces()
    h_p_u_x_network_1_0.get_default_interfaces()


# Generated at 2022-06-24 22:51:41.110735
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network = HPUXNetwork()
    interfaces = h_p_u_x_network.get_interfaces_info()
    assert ('lan0' in interfaces)
    assert (interfaces['lan0']['device'] == 'lan0')
    assert (interfaces['lan0']['ipv4']['address'] == '10.10.10.1')
    assert (interfaces['lan0']['ipv4']['network'] == '10.10.10.1')
    assert (interfaces['lan0']['ipv4']['interface'] == 'lan0')


# Generated at 2022-06-24 22:51:46.959458
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    HPUXNetwork_obj = HPUXNetwork(module=None)
    assert HPUXNetwork_obj.get_default_interfaces() == \
        {'default_interface': 'lan36', 'default_gateway': '172.30.203.254'}


# Generated at 2022-06-24 22:51:48.860681
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    name = HPUXNetwork()
    assert 'default_interface' in name.get_default_interfaces()


# Generated at 2022-06-24 22:51:58.158353
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network = HPUXNetwork()
    ansible_module_0 = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    h_p_u_x_network.module = ansible_module_0

    result_get_interfaces_info = h_p_u_x_network.get_interfaces_info()
    assert isinstance(result_get_interfaces_info, dict)
    assert len(result_get_interfaces_info) > 0


# Generated at 2022-06-24 22:52:09.560718
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Get the populated facts
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network.module.params = {'gather_subset': 'all'}
    h_p_u_x_network.module.exit_json = {'failed': False}
    h_p_u_x_network_facts = h_p_u_x_network.populate()

    # Test the default_interface
    assert 'default_interface' in h_p_u_x_network_facts
    assert h_p_u_x_network_facts['default_interface'] is not None

    # Test the default_gateway
    assert 'default_gateway' in h_p_u_x_network_facts

# Generated at 2022-06-24 22:52:16.468193
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork({})
    h_p_u_x_network_0.module = HPUXNetworkCollector()
    h_p_u_x_network_0.populate()
    output = h_p_u_x_network_0.get_default_interfaces()
    output_expected = {'default_gateway': '172.26.0.1',
                       'default_interface': 'lan1'}
    assert output == output_expected


# Generated at 2022-06-24 22:52:19.168725
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0 is not None


# Generated at 2022-06-24 22:52:27.825113
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    list_0 = ['default', '224.0.0.0', 'U', 'G', 'lan0']
    list_1 = ['default', '224.0.0.0', 'U', 'G', 'lan0']
    list_2 = ['default', '224.0.0.0', 'U', 'G', 'lan0']
    list_3 = ['default', '224.0.0.0', 'U', 'G', 'lan0']

# Generated at 2022-06-24 22:52:35.566245
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_obj_0 = HPUXNetwork()

# Generated at 2022-06-24 22:52:40.241928
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_interfaces_info() == {}



# Generated at 2022-06-24 22:53:00.367428
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()

    iface_output_0='''lan0	0	0	0	0	0	0	0	0	0	0	0'''
    iface_output_1='''lan0	0	1	0	0	0	0	0	0	0	0	0'''
    iface_output_2='''lan0	0	2	0	0	0	0	0	0	0	0	0'''
    iface_output_3='''lan0	0	3	0	0	0	0	0	0	0	0	0'''

# Generated at 2022-06-24 22:53:06.445428
# Unit test for constructor of class HPUXNetwork

# Generated at 2022-06-24 22:53:07.597042
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()


# Generated at 2022-06-24 22:53:11.038803
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert isinstance(h_p_u_x_network_collector, HPUXNetworkCollector)


# Generated at 2022-06-24 22:53:12.637702
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert h_p_u_x_network_collector.__class__.__name__ == 'HPUXNetworkCollector'


# Generated at 2022-06-24 22:53:19.826477
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    def_interfaces = h_p_u_x_network_0.get_default_interfaces()
    assert def_interfaces == {
        'default_gateway': '192.0.2.254',
        'default_interface': 'lan0'
    }, 'Expected value: {\'default_gateway\': \'192.0.2.254\', \'default_interface\': \'lan0\'}'


# Generated at 2022-06-24 22:53:23.220307
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    dict = h_p_u_x_network_0.get_interfaces_info()
    print(dict)


# Generated at 2022-06-24 22:53:25.692222
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert isinstance(HPUXNetworkCollector(), HPUXNetworkCollector)


# Generated at 2022-06-24 22:53:32.064547
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    rc, out, err = h_p_u_x_network_0.module.run_command("/usr/bin/netstat -niw")
    h_p_u_x_network_0.module.exit_json(changed=False, msg="Dummy exit_json")


# Generated at 2022-06-24 22:53:33.355858
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()


# Generated at 2022-06-24 22:53:55.410560
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network = HPUXNetwork()
    result = h_p_u_x_network.get_interfaces_info()


# Generated at 2022-06-24 22:53:59.418644
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    out = HPUXNetwork(module)


# Generated at 2022-06-24 22:54:01.557290
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    return h_p_u_x_network_collector


# Generated at 2022-06-24 22:54:06.936732
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass



# Generated at 2022-06-24 22:54:14.895301
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = MockModule()
    h_p_u_x_network_0.module.run_command.return_value = (0, test_out_0, '')
    h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:54:18.205619
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Test 0 - try creating a valid object for class HPUXNetworkCollector
    try:
        obj = HPUXNetworkCollector()
    except:
        assert False, "Construction of HPUXNetworkCollector object failed"
        # Test 1 - validating platform type
    assert obj._platform is not None, "Platform type check failed"
    # Test 2 - validating fact_class type
    assert obj._fact_class is not None, "Fact_class type check failed"

# Generated at 2022-06-24 22:54:20.668510
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network = HPUXNetwork()
    assert h_p_u_x_network.get_default_interfaces()


# Generated at 2022-06-24 22:54:25.343795
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces_facts = h_p_u_x_network_0.get_default_interfaces()
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts


# Generated at 2022-06-24 22:54:27.051738
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:54:34.813620
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-24 22:54:57.367966
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:54:58.973889
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

# Generated at 2022-06-24 22:55:01.905137
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:55:03.812672
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bool_0 = True
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bool_0)
    assert h_p_u_x_network_collector_0._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'


# Generated at 2022-06-24 22:55:08.820470
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:55:15.221925
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    assert h_p_u_x_network_0._want_defaults is True
    assert isinstance(h_p_u_x_network_0.facts, dict)
    assert h_p_u_x_network_0.platform == 'HP-UX'


# Generated at 2022-06-24 22:55:18.461968
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bool_0 = True
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bool_0)


if __name__ == "__main__":
    test_case_0()
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:55:20.282384
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0 is not None

# Generated at 2022-06-24 22:55:21.131079
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:55:29.118738
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)

# Generated at 2022-06-24 22:56:22.082479
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    map_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:32.271808
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hostname = ""
    h_p_u_x_network_0 = HPUXNetwork(hostname)
    hostname = h_p_u_x_network_0._hostname
    #  Get default_interface and default_gateway
    result_netstat_nr = h_p_u_x_network_0._get_default_interfaces()
    default_interface = result_netstat_nr['default_interface']
    default_gateway = result_netstat_nr['default_gateway']

    #  Get interface information
    result_netstat_niw = h_p_u_x_network_0._get_interfaces_info()
    for interface in result_netstat_niw:
        device = result_netstat_niw[interface]['device']
        ipv4 = result_netstat

# Generated at 2022-06-24 22:56:33.547999
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:56:38.918915
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_case_0()


# Generated at 2022-06-24 22:56:49.233320
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    h_p_u_x_network_1 = HPUXNetwork(bool_0)
    h_p_u_x_network_2 = h_p_u_x_network_0
    assert h_p_u_x_network_0 == h_p_u_x_network_2
    assert h_p_u_x_network_0 is not h_p_u_x_network_1
    assert h_p_u_x_network_0 is not h_p_u_x_network_2
    assert type(h_p_u_x_network_0) == HPUXNetwork
    assert type(h_p_u_x_network_1) == HPU

# Generated at 2022-06-24 22:56:51.623637
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert True


# Generated at 2022-06-24 22:56:53.671752
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    case_0 = test_case_0()

if __name__ == '__main__':
    test_HPUXNetwork_populate()

# Generated at 2022-06-24 22:57:00.116315
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:57:01.994248
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Case 1
    bool_1 = 'l0'
    h_p_u_x_network_0 = HPUXNetwork(bool_1)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:57:03.430882
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)


# Generated at 2022-06-24 22:59:05.313042
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    string_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:59:11.692586
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_1 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:59:18.818745
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    dictionary_0 = h_p_u_x_network_0.get_interfaces_info()

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:59:21.233040
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:59:23.573901
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:59:29.399068
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bool_1 = True
    h_p_u_x_network_collector_1 = HPUXNetworkCollector(bool_1)
    assert h_p_u_x_network_collector_1._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_1._platform == 'HP-UX'

# Generated at 2022-06-24 22:59:33.018537
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:59:33.664981
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert True

# Generated at 2022-06-24 22:59:39.864943
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    # HPUXNetwork instance created with default arguments
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)

    # Call the method
    result = h_p_u_x_network_0.get_default_interfaces()

    assert result == {u'default_interface': u'lan1', u'default_gateway': u'0.0.0.0'}


# Generated at 2022-06-24 22:59:47.974532
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0, 'default   192.168.1.1     UG   0   0   lan0', ''))
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    print("%s" % var_0)
    assert var_0 == {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}
