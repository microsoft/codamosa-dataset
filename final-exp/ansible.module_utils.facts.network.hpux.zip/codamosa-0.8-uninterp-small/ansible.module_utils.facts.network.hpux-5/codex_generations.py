

# Generated at 2022-06-24 22:50:26.955391
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:50:29.931921
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    float_0 = -1897.88
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    interfaces = h_p_u_x_network_0.get_interfaces_info()
    print(interfaces)


# Generated at 2022-06-24 22:50:40.615009
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    float_0 = -1622.58
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(float_0)
    h_p_u_x_network_collector_0.get_default_interfaces = lambda: \
        {'default_interface': 'lan8', 'default_gateway': '10.141.0.1'}


# Generated at 2022-06-24 22:50:43.049008
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    result = HPUXNetwork().get_default_interfaces()
    assert isinstance(result, dict)


# Generated at 2022-06-24 22:50:47.534531
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:50:56.936498
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(0)
    assert h_p_u_x_network_0.get_interfaces_info() == {'lan0': {'device': 'lan0',
                                                                 'ipv4': {'address': '10.20.30.40',
                                                                          'interface': 'lan0',
                                                                          'network': '10.20.30.0'}},
                                                        'lan1': {'device': 'lan1',
                                                                 'ipv4': {'address': '50.60.70.80',
                                                                          'interface': 'lan1',
                                                                          'network': '50.60.70.0'}}}


# Generated at 2022-06-24 22:51:02.664009
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    float_0 = -1622.58
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(float_0)
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0)


# Generated at 2022-06-24 22:51:08.624726
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    float_0 = -1622.58
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(float_0)
    device = h_p_u_x_network_collector_0.get_device()
    device = h_p_u_x_network_collector_0.get_device()
    device = h_p_u_x_network_collector_0.get_device()


# Generated at 2022-06-24 22:51:13.539882
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_case_0()
# End of unit tests for method populate of class HPUXNetwork


# Generated at 2022-06-24 22:51:16.316086
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    float_0 = -1622.58
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(float_0)
    h_p_u_x_network_0 = h_p_u_x_network_collector_0.populate()



# Generated at 2022-06-24 22:51:26.581266
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass


# Generated at 2022-06-24 22:51:31.959150
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0)
    default_interfaces = h_p_u_x_network_0.get_default_interfaces()



# Generated at 2022-06-24 22:51:33.874068
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()


# Generated at 2022-06-24 22:51:37.500882
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.populate() == {'interfaces': [],
        'default_interface': 'lan0'}


# Generated at 2022-06-24 22:51:40.322986
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:51:44.433932
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Make sure we never have a 'default_gateway' fact using the
    # HPUXNetworkCollector fact plugin.
    collector = HPUXNetworkCollector()
    facts = collector.collect()
    assert 'default_gateway' not in facts
    assert 'interfaces' in facts
    assert 'default_interface' in facts

# Generated at 2022-06-24 22:51:46.116389
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    try:
        assert h_p_u_x_network_collector_0.get_facts()
    except SystemExit:
        assert True

# Generated at 2022-06-24 22:51:48.165900
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    result = h_p_u_x_network_0.populate()
    assert result['interfaces'] == ['lan0']


# Generated at 2022-06-24 22:51:49.830256
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    # Tests if there are defined facts.
    assert h_p_u_x_network_0.populate() != 0


# Generated at 2022-06-24 22:51:54.213478
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_1.platform == 'HP-UX'
    assert h_p_u_x_network_collector_1.fact_class == HPUXNetwork


# Generated at 2022-06-24 22:52:05.094719
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    fact_collection = {}
    h_p_u_x_network_0.populate(fact_collection)
    var_0 = fact_collection.keys()


# Generated at 2022-06-24 22:52:14.243200
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_1 = ()
    h_p_u_x_network_1 = HPUXNetwork(tuple_1)
    # Check exception is caused by AnsibleModule argument to be of class AnsibleModule
    with pytest.raises(TypeError) as excinfo:
        tuple_2 = (3,)
        h_p_u_x_network_2 = HPUXNetwork(tuple_2)
    # Check exception is caused by setup argument to be of class bool
    with pytest.raises(TypeError) as excinfo:
        tuple_3 = (h_p_u_x_network_1.module, None)
        h_p_u_x_network_3 = HPUXNetwork(tuple_3)
    # Check exception is caused by sub fact argument to be of class bool

# Generated at 2022-06-24 22:52:19.863734
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:52:24.009430
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:52:30.090576
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == {u'default_interface': u'lan0', u'default_gateway': u'192.168.1.1'}



# Generated at 2022-06-24 22:52:36.225736
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    tuple_0 = ()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(tuple_0)
    assert h_p_u_x_network_collector_0 is not None


# Generated at 2022-06-24 22:52:43.255867
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    assert isinstance(h_p_u_x_network_collector_1, NetworkCollector)
    assert isinstance(h_p_u_x_network_collector_1, HPUXNetworkCollector)
    assert isinstance(h_p_u_x_network_collector_1._fact_class, HPUXNetwork)


# Generated at 2022-06-24 22:52:46.920685
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX', 'instance variable "HPUXNetworkCollector._platform" not set to "HP-UX"'
    assert HPUXNetworkCollector._fact_class.__name__ == 'HPUXNetwork', 'instance variable "HPUXNetworkCollector._fact_class" not set to "HPUXNetwork"'


# Generated at 2022-06-24 22:52:51.706259
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


if __name__ == '__main__':
    test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:52:55.594981
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 is None


# Generated at 2022-06-24 22:53:08.694330
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    var_1 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:53:13.189771
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Replace module.run_command() with the side_effect, which is an array of expected results defined above
    # tuple_0 = ()
    # h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    # var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert 1 == -1

# Generated at 2022-06-24 22:53:15.798026
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:53:19.611257
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    tuple_0 = ()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(tuple_0)

# Generated at 2022-06-24 22:53:24.352146
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    tuple_1 = ()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(tuple_1)
    tuple_0 = ()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(tuple_0)


# Generated at 2022-06-24 22:53:28.941075
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    var_1 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:53:32.108786
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(module)

# Generated at 2022-06-24 22:53:41.272222
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    import imp
    import sys
    module_name = 'ansible.module_utils.facts.network.hpux.hpux_network'
    my_module = imp.new_module(module_name)
    exec("""
import sys
from ansible.module_utils.facts.network.base import Network, NetworkCollector
from ansible.module_utils.facts.network.hpux.hpux_network import HPUXNetwork
from ansible.module_utils.facts.network.hpux.hpux_network import HPUXNetworkCollector
""", my_module.__dict__)
    sys.modules[my_module.__name__] = my_module
    h_p_u_x_network_1 = HPUXNetwork(None)

# Generated at 2022-06-24 22:53:45.572337
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    var_1 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == var_1


# Generated at 2022-06-24 22:53:49.060715
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    assert isinstance(h_p_u_x_network_0, HPUXNetwork)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:14.851150
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    tuple_0 = ()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(tuple_0)
    h_p_u_x_network_collector_0.get_all()
    h_p_u_x_network_collector_0.get_network_facts()


# Generated at 2022-06-24 22:54:16.950940
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:54:20.233064
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:54:26.668669
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_collector_1 = HPUXNetworkCollector(h_p_u_x_network_collector_0)
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:31.211873
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    expected_0 = {}
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == expected_0


# Generated at 2022-06-24 22:54:41.779424
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0['lan0'] == {'ipv4': {'interface': 'lan0',
                                      'address': '172.17.1.21',
                                      'network': '172.17.0.0'},
                             'device': 'lan0'}
    assert var_0['lan1'] == {'ipv4': {'interface': 'lan1',
                                      'address': '172.17.2.21',
                                      'network': '172.17.0.0'},
                             'device': 'lan1'}

# Generated at 2022-06-24 22:54:44.499577
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    assert isinstance(h_p_u_x_network_0,HPUXNetwork)


# Generated at 2022-06-24 22:54:51.545453
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    assert h_p_u_x_network_0._facts == {'default_interface': None, 'default_gateway': None, 'interfaces': None}
    assert h_p_u_x_network_0.platform == 'HP-UX'
    assert h_p_u_x_network_0.module is tuple_0[0]


# Generated at 2022-06-24 22:54:54.504373
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:55:01.782696
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    tuple_1 = ()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(tuple_1)
    var_1 = h_p_u_x_network_collector_0.__class__
    var_2 = h_p_u_x_network_collector_0.platform
    var_3 = h_p_u_x_network_collector_0.__dict__
    var_4 = h_p_u_x_network_collector_0._fact_class
    var_5 = h_p_u_x_network_collector_0._platform

# Generated at 2022-06-24 22:55:58.754266
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    assert h_p_u_x_network_0._platform == 'HP-UX'
    assert h_p_u_x_network_0._module.check_mode == False
    assert h_p_u_x_network_0._module._diff == False
    assert h_p_u_x_network_0._module.params == {}
    assert h_p_u_x_network_0._module.ansible_version == '2.7.15'
    assert h_p_u_x_network_0._module.ansible_version_full_info == ('2.7.15', 4)

# Generated at 2022-06-24 22:56:01.228660
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == {}


# Generated at 2022-06-24 22:56:05.952614
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)


# Generated at 2022-06-24 22:56:09.038829
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    tuple_1 = ()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(tuple_1)
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'


# Generated at 2022-06-24 22:56:11.797013
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    assert isinstance(h_p_u_x_network_0, object)


# Generated at 2022-06-24 22:56:18.090223
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    h_p_u_x_network_1 = HPUXNetwork(tuple_0)
    h_p_u_x_network_2 = HPUXNetwork(tuple_0)
    h_p_u_x_network_3 = HPUXNetwork(tuple_0)
    h_p_u_x_network_4 = HPUXNetwork(tuple_0)
    h_p_u_x_network_5 = HPUXNetwork(tuple_0)
    h_p_u_x_network_6 = HPUXNetwork(tuple_0)
    h_p_u_x_network_7 = HPUXNetwork(tuple_0)


# Generated at 2022-06-24 22:56:20.504936
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    o_a_1 = HPUXNetworkCollector(None)

test_case_0()

# Generated at 2022-06-24 22:56:22.296529
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:56:29.276510
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetworkCollector(tuple_0)

if __name__ == '__main__':
    for i in range(2):
        test_HPUXNetworkCollector()
    for i in range(2):
        test_case_0()

# Generated at 2022-06-24 22:56:33.603492
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:58:43.236115
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    assert h_p_u_x_network_0.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '192.168.122.1'} # value



# Generated at 2022-06-24 22:58:46.349870
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    #  Find out what is the output of this call.
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    #  What type of object is var_0?
    # var_0 is a dict, we need to iterate it
    dict = var_0
    for k, v in dict.items():
        print(k, '->', v)


# Generated at 2022-06-24 22:58:52.076529
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Setup test data
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)

    # Invoke method
    var_0 = h_p_u_x_network_0.get_interfaces_info()

    # Test Assertions
    assert not var_0

# Generated at 2022-06-24 22:59:02.083104
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Test case with default values
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_9 = h_p_u_x_network_0.get_interfaces_info()
    assert var_9 == {'lan0': {'ipv4': {'address': '10.76.142.33', 'interface': 'lan0', 'network': '10.76.142.32'}, 'device': 'lan0'}}
    # Test case with empty parameters
    tuple_1 = ()
    h_p_u_x_network_1 = HPUXNetwork(tuple_1)
    var_10 = h_p_u_x_network_1.get_interfaces_info()

# Generated at 2022-06-24 22:59:05.802483
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:59:11.753437
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:59:16.010984
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_1 = ()
    h_p_u_x_network_1 = HPUXNetwork(tuple_1)
# ---------------------------------------------------------------------

# Generated at 2022-06-24 22:59:19.350978
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:59:24.857577
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    tuple_0 = ()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(tuple_0)
    assert h_p_u_x_network_collector_0._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'


# Generated at 2022-06-24 22:59:34.415736
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Testing with a known correct interface
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(tuple_0)

    h_p_u_x_network_0._exec_command = (lambda param_0: (0, "lan0: flags=2080c<BROADCAST,MULTICAST,RUNNING,PERV> mtu 1500 inet 10.10.10.52 netmask 0xffffff00 broadcast 10.10.10.255 unspec 00-00-00-00-00-00-00-00-00-00-00-00-00-00-00-00  media: IEEE 802.3 autoselect status: active", ""))
    var_0 = h_p_u_x_network_0.get_interfaces_info()
