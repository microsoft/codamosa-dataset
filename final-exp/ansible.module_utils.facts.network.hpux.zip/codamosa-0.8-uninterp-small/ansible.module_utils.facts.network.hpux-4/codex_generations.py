

# Generated at 2022-06-24 22:50:27.148580
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:50:29.296513
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:50:32.205285
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector() != None


# Generated at 2022-06-24 22:50:35.833079
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    print(h_p_u_x_network_0.populate())


if __name__ == '__main__':
    test_HPUXNetwork()

# Generated at 2022-06-24 22:50:41.483165
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:50:45.971223
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.get_default_interfaces()



# Generated at 2022-06-24 22:50:50.721443
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:50:53.382245
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpu = HPUXNetwork()
    result = hpu.get_default_interfaces()
    assert result['default_gateway'] == '172.17.1.1'
    assert result['default_interface'] == 'lan1'


# Generated at 2022-06-24 22:50:55.335489
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:00.089642
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:07.567490
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    result = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:51:15.491433
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    output = h_p_u_x_network_0.populate()
    assert output['default_interface'] == 'lan0'
    assert output['interfaces'][0] == 'lan0'
    interfaces = output['interfaces']
    for intf in interfaces:
        if intf == 'lan0':
            assert output[intf]['ipv4']['address'] == '11.1.0.1'


# Generated at 2022-06-24 22:51:24.004627
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0.get_default_interfaces = MagicMock(return_value=dict())
    h_p_u_x_network_0.get_interfaces_info = MagicMock(return_value=dict())
    h_p_u_x_network_0.populate = MagicMock(return_value=dict())
    assert h_p_u_x_network_0.populate() == {}


# Generated at 2022-06-24 22:51:29.143318
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()

    assert h_p_u_x_network_collector_1._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_1._platform == 'HP-UX'


# Generated at 2022-06-24 22:51:33.379101
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    assert isinstance(h_p_u_x_network_0.get_interfaces_info(), dict)


# Generated at 2022-06-24 22:51:36.551452
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork(module=None)
    assert h_p_u_x_network is not None
    assert h_p_u_x_network


# Generated at 2022-06-24 22:51:40.194914
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork(None)
    result = h_p_u_x_network_0.get_default_interfaces()
    assert True == result

# Generated at 2022-06-24 22:51:41.417796
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'


# Generated at 2022-06-24 22:51:44.508854
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = MockModule()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:48.036603
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    actual = h_p_u_x_network_0.get_default_interfaces()
    assert actual == {'default_gateway': '192.168.2.1',
                      'default_interface': 'lan0'}


# Generated at 2022-06-24 22:51:54.665399
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

# Generated at 2022-06-24 22:52:00.045272
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    #assert str(h_p_u_x_network_0) == "Network Facts for github.com"
    assert h_p_u_x_network_0.platform == "HP-UX"
    assert h_p_u_x_network_0.module == "github.com"


# Generated at 2022-06-24 22:52:10.961732
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    str_1 = 'eth0'
    var_1 = var_0[str_1]
    var_2 = var_1['ipv4']
    str_2 = 'address'
    var_3 = var_2[str_2]
    str_3 = '192.168.0.10'
    var_4 = (var_3 == str_3)
    var_5 = var_1['device']
    str_4 = 'eth0'
    var_6 = (var_5 == str_4)
    assert (var_4 and var_6)


# Generated at 2022-06-24 22:52:17.768901
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    var_1 = HPUXNetwork('github.com')
    var_2 = var_1.populate()
    assert var_2['interfaces'].__class__ is list
    assert var_2['interfaces'][0] == 'lan0'
    assert var_2['interfaces'][1] == 'lan1'
    assert var_2['interfaces'][2] == 'lan2'
    assert var_2['interfaces'][3] == 'lo0'
    assert var_2['lan0']['ipv4']['address'] == '192.168.1.1'
    assert var_2['lan0']['ipv4']['network'] == '192.168.1'
    assert var_2['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-24 22:52:22.837043
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_1 = 'github.com'
    h_p_u_x_network_1 = HPUXNetwork(str_1)
    var_1 = h_p_u_x_network_1.populate()
    # In this case, variable default_interface is fixed.
    assert var_1['default_interface'] == 'lan0'
    # In this case, variable default_gateway is fixed.
    assert var_1['default_gateway'] == '172.30.0.1'
    # In this case, size of variable interfaces is fixed.
    assert len(var_1['interfaces']) == 1
    # In this case, the 1st element of variable interfaces is fixed.
    assert var_1['interfaces'][0] == 'lan0'


# Generated at 2022-06-24 22:52:26.919716
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()


if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:52:29.576161
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert h_p_u_x_network_0.get_default_interfaces() == {}


# Generated at 2022-06-24 22:52:32.207996
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'test'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:52:35.374687
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert h_p_u_x_network_0.platform == 'HP-UX', "Populate method not working for HPUXNetwork class"


# Generated at 2022-06-24 22:52:37.088745
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:52:50.587476
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()
    #print(var_0)


# Generated at 2022-06-24 22:52:56.669838
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'stackexchange.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:53:02.875257
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:53:07.635423
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:53:10.996799
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'ansible.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:53:15.253611
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:53:25.960120
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'github.com'
    str_1 = 'github.com'
    str_2 = 'github.com'
    str_3 = 'github.com'
    str_4 = 'github.com'
    str_5 = 'github.com'
    str_6 = 'github.com'
    str_7 = 'github.com'
    str_8 = 'github.com'
    str_9 = 'github.com'
    str_10 = 'github.com'
    str_11 = 'github.com'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9

# Generated at 2022-06-24 22:53:36.765502
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils.mock import Mock
    import os
    import tempfile

    # Save the current working directory
    cwd = os.getcwd()

    # Create a temporary directory
    tmp = tempfile.mkdtemp()
    # Create a text file in this directory
    fd, tmpfile = tempfile.mkstemp(dir=tmp)

    # Change to the temporary directory
    os.chdir(tmp)

    # Create some test input and output
    input = {"default_interface": "lan82", "default_gateway": "10.145.183.1"}
    output = {"default_interface": "lan82", "default_gateway": "10.145.183.1"}

    # Try to add the temporary directory to the system path

# Generated at 2022-06-24 22:53:40.890274
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    # Test with a sample string
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == {}



# Generated at 2022-06-24 22:53:45.696489
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetworkCollector.init(h_p_u_x_network_collector, str_0)

if __name__ == '__main__':
    test_case_0()
    #test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:54:10.512420
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    str_0 = 'LPAR2RRD-WEB'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:54:11.270276
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass


# Generated at 2022-06-24 22:54:14.999176
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:17.242104
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:19.154929
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)


# Generated at 2022-06-24 22:54:22.688250
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert h_p_u_x_network_0.populate() is None


# Generated at 2022-06-24 22:54:28.836850
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:54:32.529792
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_1 = 'github.com'
    h_p_u_x_network_1 = HPUXNetwork(str_1)
    var_1 = h_p_u_x_network_1.get_interfaces_info()
    return var_1


# Generated at 2022-06-24 22:54:35.425727
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    pass


# Generated at 2022-06-24 22:54:37.193932
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:55:19.238603
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'www.google.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:55:21.927969
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert isinstance(h_p_u_x_network_collector, HPUXNetworkCollector)


# Generated at 2022-06-24 22:55:22.465080
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 22:55:22.964875
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_case_0()


# Generated at 2022-06-24 22:55:24.126240
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Dummy test method
    pass



# Generated at 2022-06-24 22:55:30.124597
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    p0 = 'github.com'
    hpu_xn_0 = HPUXNetwork(p0)
    v0 = hpu_xn_0.get_default_interfaces()


# Generated at 2022-06-24 22:55:31.321024
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:55:33.961385
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert h_p_u_x_network_0


# Generated at 2022-06-24 22:55:38.312890
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:55:39.793352
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:57:28.251858
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()
    assert h_p_u_x_network_0._module.run_command.called == True


# Generated at 2022-06-24 22:57:32.669588
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    dict_0 = h_p_u_x_network_0.get_interfaces_info()



# Generated at 2022-06-24 22:57:36.839222
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    print('Testing populate of class HPUXNetwork')
    test_case_0()
    print('Tests Passed')

# Generated at 2022-06-24 22:57:42.457083
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Constructor of class HPUXNetworkCollector
    try:
        str_0 = 'github.com'
        h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)
        print("HPUXNetworkCollector() has been created.")
    except Exception as e:
        print("raise Exception('{0}') from None".format(str(e)))
        raise Exception(str(e))
    assert True


# Generated at 2022-06-24 22:57:46.098563
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    test_case_0()


# Generated at 2022-06-24 22:57:50.613898
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
  obj = HPUXNetworkCollector()
  assert obj

# Generated at 2022-06-24 22:57:56.415559
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 == {'default_interface': 'lan10000', 'interfaces': ['lan10000'], 'lan10000': {'ipv4': {'network': '10.33.0.0', 'interface': 'lan10000', 'address': '10.33.0.28'}, 'device': 'lan10000'}, 'default_gateway': '10.33.0.1'}


# Generated at 2022-06-24 22:58:06.015235
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'github.com'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    assert h_p_u_x_network_0._module == str_0
    assert h_p_u_x_network_0._platform == 'HP-UX'
    assert h_p_u_x_network_0._default_gateway == ''
    assert h_p_u_x_network_0._interfaces == {}
    assert h_p_u_x_network_0._default_interface == ''
    assert h_p_u_x_network_0._all_ipv4_addresses == {}


# Generated at 2022-06-24 22:58:12.270426
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = 'github.com'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)
    # TODO: Write test to check that an exception is thrown when a bad
    #       argument is passed.
    # TODO: Write test to check that the fact class instance variable
    #       is assigned properly.
    # TODO: Write test to check that the platform instance variable is
    #       is assigned properly.


# Generated at 2022-06-24 22:58:16.490702
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_1 = 'github.com'
    h_p_u_x_network_1 = HPUXNetwork(str_1)
    try:
        var_1 = h_p_u_x_network_1.get_interfaces_info()
    except NotImplementedError:
        var_1 = None
    assert var_1 is not None
