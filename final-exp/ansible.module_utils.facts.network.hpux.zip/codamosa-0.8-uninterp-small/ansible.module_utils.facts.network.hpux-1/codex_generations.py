

# Generated at 2022-06-24 22:50:33.300707
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.module is not None


# Generated at 2022-06-24 22:50:37.255351
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces_facts = {'default_interface': 'lan1', 'default_gateway': '10.0.0.1'}
    h_p_u_x_network_0 = HPUXNetwork()
    result = h_p_u_x_network_0.get_default_interfaces()
    assert result == default_interfaces_facts


# Generated at 2022-06-24 22:50:38.442561
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    H_P_U_X_Network = HPUXNetwork()


# Generated at 2022-06-24 22:50:39.365117
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    h_p_u_x_network_0 = HPUXNetwork()

# Generated at 2022-06-24 22:50:43.479304
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    h_p_u_x_network_collector.__init__()


# Generated at 2022-06-24 22:50:47.575556
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()

    # Call method populate
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:50:51.457585
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network.module = FakeModule()
    h_p_u_x_network.get_interfaces_info()


# Generated at 2022-06-24 22:50:53.500392
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    assert h_p_u_x_network_0 is not None


# Generated at 2022-06-24 22:50:55.446794
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    


# Generated at 2022-06-24 22:51:05.398742
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(module = None)
    # Tests with valid returned value
    result = h_p_u_x_network_0.get_interfaces_info()
    assert result == {'lan10': {'ipv4': {'network': '192.168.53.0', 'interface': 'lan10', 'address': '192.168.53.170'}, 'device': 'lan10'}}
    # Tests with None returned value
    result = h_p_u_x_network_0.get_interfaces_info()
    assert result == {'lan10': {'ipv4': {'network': '192.168.53.0', 'interface': 'lan10', 'address': '192.168.53.170'}, 'device': 'lan10'}}


# Generated at 2022-06-24 22:51:12.336891
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert isinstance(HPUXNetworkCollector(), NetworkCollector)


# Generated at 2022-06-24 22:51:20.432038
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    h_p_u_x_network0 = HPUXNetworkCollector.fact_class(None, None)

# Generated at 2022-06-24 22:51:22.016666
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Test instantiation of class HPUXNetwork with valid data
    inf1 = HPUXNetwork()


# Generated at 2022-06-24 22:51:23.342429
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:27.078074
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # HPUXNetwork.populate() raises NotImplementedError
    h_p_u_x_network_0 = HPUXNetwork()
    with pytest.raises(NotImplementedError):
        h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:51:30.043050
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    h_p_u_x_network_0 = HPUXNetwork()

    h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:51:37.051334
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = AnsibleModule(
        argument_spec={
            'filter': {'type': 'list', 'elements': 'str'},
            'gather_subset': {'type': 'list', 'elements': 'str'},
            'gather_network_resources': {'type': 'list', 'elements': 'str'}
        }
    )
    # pylint: disable=protected-access
    h_p_u_x_network_0._populate()


# Generated at 2022-06-24 22:51:39.559067
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:41.820977
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0


# Generated at 2022-06-24 22:51:47.483455
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces_facts = h_p_u_x_network_0.get_default_interfaces()
    assert 'default_interface' in default_interfaces_facts
    h_p_u_x_network_1 = HPUXNetwork()
    default_interfaces_facts = h_p_u_x_network_1.get_default_interfaces()
    assert 'default_gateway' in default_interfaces_facts


# Generated at 2022-06-24 22:51:59.251902
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)


# Generated at 2022-06-24 22:52:03.270517
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert h_p_u_x_network_collector._platform == 'HP-UX'



# Generated at 2022-06-24 22:52:12.428336
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
  h_p_u_x_network_collector = HPUXNetworkCollector()
  obj = h_p_u_x_network_collector.collect(None)
  if not isinstance(obj, dict):
    print('FAILURE: test_HPUXNetwork_populate() returned "%s" type, but expected "dict"' % type(obj))
    return
  if not obj:
    return
  obj_keys = obj.keys()

# Generated at 2022-06-24 22:52:13.065568
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass

# Generated at 2022-06-24 22:52:14.316293
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:52:21.132504
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hostname = 'hostname'
    domainname = 'domainname'
    fqdn = 'fqdn'
    h_p_u_x_network_0 = HPUXNetwork(hostname, domainname, fqdn)
    h_p_u_x_network_0.populate()



# Generated at 2022-06-24 22:52:22.390812
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()


# Generated at 2022-06-24 22:52:23.669649
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    testcase = HPUXNetworkCollector()
    assert testcase


# Generated at 2022-06-24 22:52:31.625648
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network = HPUXNetwork(None)
    h_p_u_x_network_populate = h_p_u_x_network.populate()
    assert h_p_u_x_network_populate is not None
    assert 'default_interface' in h_p_u_x_network_populate
    assert 'default_gateway' in h_p_u_x_network_populate
    assert 'interfaces' in h_p_u_x_network_populate
    assert 'lan0' in h_p_u_x_network_populate
    assert 'device' in h_p_u_x_network_populate
    assert 'ipv4' in h_p_u_x_network_populate
    assert 'network' in h_p_u

# Generated at 2022-06-24 22:52:32.709908
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert h_p_u_x_network_collector_0


# Generated at 2022-06-24 22:52:46.011532
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    var_0 = [h_p_u_x_network_collector_0, ]


# Generated at 2022-06-24 22:52:50.235857
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    int_0 = -76
    str_0 = 'C\x1e#\n\xf8\x1e:\xddk'
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    assert h_p_u_x_network_0.get_interfaces_info() != S

# Generated at 2022-06-24 22:52:55.101575
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    int_0 = -20
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:52:58.456406
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pop_test = HPUXNetwork()
    pop_test._module.get_bin_path = lambda arg: arg
    pop_test._module.run_command = lambda arg: (0, str(arg), '')
    pop_test.populate()


# Generated at 2022-06-24 22:53:05.075435
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'nn FYsJYI~\x0b9\re4'
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    str_1 = '/usr/bin/netstat'
    h_p_u_x_network_0.module.get_bin_path(str_1)
    h_p_u_x_network_0.populate(str_0)


# Generated at 2022-06-24 22:53:11.919392
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_1 = "default 10.0.0.1 UG lan0"
    int_0 = -781
    h_p_u_x_network_1 = HPUXNetwork(int_0)
    var_1 = h_p_u_x_network_1.get_default_interfaces()


# Generated at 2022-06-24 22:53:17.627803
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    int_arg_0 = -667
    h_p_u_x_network_0 = HPUXNetwork(int_arg_0)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 is not False


# Generated at 2022-06-24 22:53:21.619027
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(1)
    assert h_p_u_x_network_0.get_interfaces_info() == {}


# Generated at 2022-06-24 22:53:26.572616
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'V\xa6\x1e\x1f'
    int_0 = -884
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    result = h_p_u_x_network_0.get_interfaces_info(str_0)
    assert result == None


# Generated at 2022-06-24 22:53:31.109153
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:00.991968
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'nn FYsJYI~\x0b9\re4'
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    assert h_p_u_x_network_0.populate(str_0) == "hw_error"
    str_1 = '~\x0f1\x00s\x00\x0f\x0b\x07\x06\x07'
    int_1 = 1429
    h_p_u_x_network_1 = HPUXNetwork(int_1)
    assert h_p_u_x_network_1.populate(str_1) == "hw_error"


# Generated at 2022-06-24 22:54:05.144001
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    int_0 = -936
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    float_0 = 20.558911651753055
    var_0 = h_p_u_x_network_0.get_interfaces_info(float_0)


# Generated at 2022-06-24 22:54:08.754100
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork(1)
    str_0 = '\x00\x00\x00\x00\x00\x01'
    var_0 = h_p_u_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:54:14.554436
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'nn FYsJYI~\x0b9\re4'
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.populate(str_0)


# Generated at 2022-06-24 22:54:24.590247
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    int_0 = -13
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    int_1 = -13
    str_0 = '_\x0e'
    int_2 = -41
    str_1 = 'k\x12\r\r'
    str_2 = '\r\r\rk'
    dict_0 = {str_2: int_2, str_1: int_1, str_0: int_0}
    str_3 = '/usr/bin/netstat -nr'

# Generated at 2022-06-24 22:54:28.229066
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'nn FYsJYI~\x0b9\re4'
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)


# Generated at 2022-06-24 22:54:32.244575
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_2 = ''
    int_2 = 56
    h_p_u_x_network_2 = HPUXNetwork(int_2)
    var_2 = h_p_u_x_network_2.populate(str_2)


# Generated at 2022-06-24 22:54:38.507443
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    int_1 = 770
    h_p_u_x_network_1 = HPUXNetwork(int_1)
    str_1 = 'G'
    str_2 = 'cvbg^\x0f'
    int_2 = -6648
    var_1 = h_p_u_x_network_1.populate(str_1)


# Generated at 2022-06-24 22:54:41.411695
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    int_0 = 708
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:50.882975
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'c4P@\x7f\x0b/\r'
    int_0 = 671
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    assert h_p_u_x_network_0.platform == 'HP-UX'
    var_0 = h_p_u_x_network_0.populate(str_0)
    str_1 = 'c4P@\x7f\x0b/\r'
    int_1 = 671
    h_p_u_x_network_1 = HPUXNetwork(int_1)
    assert h_p_u_x_network_1.platform == 'HP-UX'

# Generated at 2022-06-24 22:55:35.994779
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()

# Generated at 2022-06-24 22:55:40.176594
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:55:46.193208
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    int_0 = -60
    h_p_u_x_network_0 = HPUXNetwork(int_0)

    str_0 = 'r\x0fI\x08\x04\x0e\x1eQ\x1f\x1e\x17\x07\x0f\x0e\x11\x12\x08\x1f'
    # The following call to get_default_interfaces is substituted with a call to
    # a function that returns a dictionary object:
    var_0 = {'default_interface': 'default_interface', 'default_gateway': 'default_gateway'}
    # get_default_interfaces(str_0)
    # assert(var_0 == var_1, '''get_default_interfaces returned an incorrect value, returned value: %s

# Generated at 2022-06-24 22:55:47.664562
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    test_case_0()

# Generated at 2022-06-24 22:55:54.575877
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    # AssertionError: popen: [Errno 2] No such file or directory.
    # assert exceptions.IOError.check(var_0)
    int_0 = -74
    h_p_u_x_network_1 = HPUXNetwork(int_0)
    int_1 = 2
    # ValueError: redundant literal in format string
    h_p_u_x_network_1.populate(int_1)
    # AssertionError: popen: [Errno 2] No such file or directory.
    # assert exceptions.IOError.check(var_1)
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}

# Generated at 2022-06-24 22:56:03.735921
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'nn FYsJYI~\x0b9\re4'
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    # Calling function 'get_default_interfaces' of class 'HPUXNetwork'
    ansible_1936284 = h_p_u_x_network_0.get_default_interfaces()
    # Calling function 'get_interfaces_info' of class 'HPUXNetwork'
    ansible_1936285 = h_p_u_x_network_0.get_interfaces_info()
    # Calling function 'populate' of class 'HPUXNetwork'
    ansible_1936286 = h_p_u_x_network_0.populate(str_0)

#

# Generated at 2022-06-24 22:56:11.041391
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    int_0 = -541
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    int_1 = -80
    h_p_u_x_network_0.module = int_1
    int_2 = -783
    h_p_u_x_network_0.module.run_command = int_2
    h_p_u_x_network_0.module.run_command = int_2
    var_0 = h_p_u_x_network_0.get_interfaces_info()



# Generated at 2022-06-24 22:56:13.319782
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    int_0 = -387
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    str_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:56:17.130121
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    str_0 = 'nn FYsJYI~\x0b9\re4'
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.populate(str_0)

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork_populate()

# Generated at 2022-06-24 22:56:22.359632
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = 'nn FYsJYI~\x0b9\re4'
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:58:20.506813
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    int_1 = 573
    h_p_u_x_network_1 = HPUXNetwork(int_1)
    # Test case for type error
    str_1 = 'n\tC\x0c!m\x1b\x1e'
    with pytest.raises(TypeError):
        h_p_u_x_network_1.get_default_interfaces(str_1)


# Generated at 2022-06-24 22:58:24.496326
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    str_0 = '\r#\x1d\x18\xc8\x02\x0c\xc7\\\x1f"'
    int_0 = -49
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:58:25.894875
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork(781)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:58:31.322873
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    int_0 = -1
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.populate()
    expected = dict({'interfaces': [], 'default_interface': None, 'default_gateway': None})
    assert var_0 == expected


# Generated at 2022-06-24 22:58:33.680457
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    str_0 = '\xba\xfc(E\t\xa1\x88\t'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(str_0)
    return h_p_u_x_network_collector_0


# Generated at 2022-06-24 22:58:35.237460
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    assert h_p_u_x_network_0._fact_class == 'HP-UX'

# Generated at 2022-06-24 22:58:39.449611
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    int_0 = -780
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:58:42.956171
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:58:44.098037
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    pass

# Generated at 2022-06-24 22:58:48.199818
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    str_0 = 'nn FYsJYI~\x0b9\re4'
    int_0 = -781
    h_p_u_x_network_0 = HPUXNetwork(int_0)
    var_0 = h_p_u_x_network_0.populate(str_0)
