

# Generated at 2022-06-24 22:50:40.591008
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork(dict())
    dict_0 = {}
    dict_0['changed'] = False
    dict_0['msg'] = 'All changes have been applied'
    dict_0['rc'] = 0
    dict_0['stderr'] = ''
    dict_0['stdout'] = """default <IPv4 gateway>  UG  lan0
default <IPv6 gateway>  UG  
""".strip()
    dict_0['stdout_lines'] = [
        'default <IPv4 gateway>  UG  lan0',
        'default <IPv6 gateway>  UG',
        '',
    ]
    dict_0['warnings'] = []

# Generated at 2022-06-24 22:50:50.294690
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    expected = {'eth0': {'device': 'eth0', 'ipv4': {'address': '192.168.1.1'}},
                'lo': {'device': 'lo', 'ipv4': {'address': '127.0.0.1'}},
                'eth1': {'device': 'eth1', 'ipv4': {'address': '192.168.2.1'}},
                'interfaces': ['eth0', 'lo', 'eth1'],
                'default_interface': 'eth0'}
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = HPUXNetwork(module=0)
    h_p_u_x_network_0.get_default_interfaces

# Generated at 2022-06-24 22:50:52.772716
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(dict())
    assert h_p_u_x_network_0.get_interfaces_info() == {}, 'Return value should be {}'


# Generated at 2022-06-24 22:50:55.507269
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    dict_0 = {}
    assert h_p_u_x_network_collector_0.platform == 'HP-UX'
    assert h_p_u_x_network_collector_0.default_network == None
    assert h_p_u_x_network_collector_0.network == None
    assert h_p_u_x_network_collector_0.facts == {}


# Generated at 2022-06-24 22:51:01.073168
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    dict_0 = {}
    h_p_u_x_network_0 = HPUXNetwork(dict_0)
    assert h_p_u_x_network_0.fact['interfaces'] == dict_0['interfaces']



# Generated at 2022-06-24 22:51:07.115611
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    dict_0 = {}
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(dict_0)
    h_p_u_x_network_0 = HPUXNetwork(dict_0)
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:16.684353
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Create instance of class (i.e.test fixture)
    h_p_u_x_network_0 = HPUXNetwork({"default_interface": "lan0"})

    # Create empty dictionary to hold return values
    return_values = {}
    # Add values to dictionary that would be returned by mocked functions
    return_values['get_bin_path'] = ('/usr/bin/netstat', '')
    return_values['run_command'] = (0,
                                    'default 10.3.4.5   UGH      0        0 lan0',
                                    '')

    with patch.multiple(HPUXNetwork,
                        **return_values) as patched_methods:
        # Call method under test
        h_p_u_x_network_0.get_default_interfaces()
        # Assert return values

# Generated at 2022-06-24 22:51:23.407594
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    dict_obj = {}
    h_p_u_x_network_collector_obj = HPUXNetworkCollector(dict_obj)
    # Verify if the fact class is set
    if h_p_u_x_network_collector_obj._fact_class != HPUXNetwork:
        return 1
    if not isinstance(HPUXNetworkCollector, NetworkCollector):
        return 1
    return 0


ansible_module_facts = dict(
    ansible_net_gather_network_resources=HPUXNetworkCollector
)



# Generated at 2022-06-24 22:51:28.939414
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    dict_0 = {}
    network_0 = HPUXNetwork(dict_0)
    network_facts_0 = network_0.get_default_interfaces()
    assert network_facts_0['default_interface'] == 'lan0'
    assert network_facts_0['default_gateway'] == '172.24.16.1'


# Generated at 2022-06-24 22:51:34.438873
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
  dict_0 = {}
  h_p_u_x_network_collector_0 = HPUXNetworkCollector(dict_0)
  print(h_p_u_x_network_collector_0.populate())


# Generated at 2022-06-24 22:51:41.782565
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    var_0 = HPUXNetwork()
    var_1 = var_0.populate()
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 22:51:43.316403
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    var_1 = HPUXNetwork(var_0)


# Generated at 2022-06-24 22:51:47.614543
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    var_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:51:48.859667
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Initialize class
    var_1 = HPUXNetwork()



# Generated at 2022-06-24 22:51:53.561860
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    var_0 = HPUXNetwork()
    var_1 = var_0.get_default_interfaces()
    assert var_1 == var_1


# Generated at 2022-06-24 22:52:01.720629
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    x = HPUXNetwork()
    x.module = mock()
    x.module.run_command = mock()
    x.module.run_command.return_value = (0, '', '')
    x.get_default_interfaces = mock()
    x.get_default_interfaces.return_value = var_0
    x.get_interfaces_info = mock()
    x.get_interfaces_info.return_value = var_0
    x.populate()
    x.get_interfaces_info.assert_called_with()
    x.module.run_command.assert_called_with("/usr/bin/netstat -niw")
    x.get_default_interfaces.assert_called_with()

# Generated at 2022-06-24 22:52:03.761135
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    var_3 = HPUXNetworkCollector()
    assert var_3.platform == 'HP-UX'



# Generated at 2022-06-24 22:52:14.168279
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netstat_path = '/usr/bin/netstat'
    obj = HPUXNetwork()
    obj.module = var_0
    obj.module.get_bin_path = var_0
    obj.module.get_bin_path.return_value = netstat_path
    rc = 0
    out = 'This is the output'
    err = 'This is the error'
    obj.module.run_command = var_0
    obj.module.run_command.return_value = (rc, out, err)

    # Test with no gateway present
    rc = 0

# Generated at 2022-06-24 22:52:15.801644
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test = HPUXNetworkCollector()


# Generated at 2022-06-24 22:52:20.027563
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_network = HPUXNetwork()
    var_1 = hpux_network.populate()
    assert var_1 == {}


# Generated at 2022-06-24 22:52:26.990121
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_0 = {}

    obj = HPUXNetwork(var_0)
    obj.get_interfaces_info()

# Generated at 2022-06-24 22:52:30.612440
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    var0 = {}
    obj0 = HPUXNetwork(var0)
    assert hasattr(obj0, 'facts') == True

    var1 = {"ansible_check_mode": False}
    obj1 = HPUXNetwork(var1)
    assert hasattr(obj1, 'facts') == True


# Generated at 2022-06-24 22:52:35.443938
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu = HPUXNetwork()


# Generated at 2022-06-24 22:52:46.564881
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_0 = {'__rc__': 0, '__stderr__': '', '__stdout__': '/usr/bin/netstat -niw\nDevice          Mtu    Network           Address              Ipkts Ierrs    Opkts Oerrs     Coll\nlan0           1310   192.168.0.0       192.168.0.12         843241  969     595177  0         0\nlan0           1310   195.64.0.0        195.64.14.87         5347    0       3594    0         0\nsys0           1500   default           195.64.14.87         0       0       0       0         0\n'}
    var_0 = HPUXNetwork.get_interfaces_info(var_0)

# Generated at 2022-06-24 22:52:48.031543
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    var_1 = HPUXNetwork()


# Generated at 2022-06-24 22:52:49.609049
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    var_1 = HPUXNetwork()
    print(var_1)


# Generated at 2022-06-24 22:52:55.027446
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    modObj = AnsibleModule(
        argument_spec = {
        },
        supports_check_mode = True
    )
    h = HPUXNetwork()
    modObj.params = var_0
    print(h.get_interfaces_info())


if __name__ == '__main__':
    if __builtin__.__dict__.has_key('__file__'):
        test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:52:56.091681
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    var_0 = {}


# Generated at 2022-06-24 22:52:57.364217
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    var_0 = HPUXNetwork()


# Generated at 2022-06-24 22:53:07.294082
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    var_0 = {}
    var_0['out'] = """Routing tables


Internet:
Destination        Gateway           Flags   Refs     Use    If
default            172.16.21.254     UGS        0        0    lan0
127.0.0.1          127.0.0.1         UH          0        0   lo0
172.16.21.0        172.16.21.254     UGS        0        0    lan0
172.16.21.254      172.16.21.254     UH         53     1515   lan0"""
    var_0['rc'] = 0
    var_0['err'] = []
    var_1 = HPUXNetwork()
    var_1.module = MagicMock()
    var_1.module.run_command.return_value = var_0

# Generated at 2022-06-24 22:53:27.722707
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Create an instance of class 'HPUXNetworkCollector'
    var_3 = HPUXNetworkCollector()
    # Check if instance 'var_3' of class 'HPUXNetworkCollector' implements interface '_NetworkCollector'.
    assert isinstance(var_3, HPUXNetworkCollector) == 1
    # Check if instance 'var_3' of class 'HPUXNetworkCollector' implements interface 'NetworkCollector'.
    assert isinstance(var_3, NetworkCollector) == 1
    # Check if instance 'var_3' of class 'HPUXNetworkCollector' implements interface 'BaseFactCollector'.
    assert isinstance(var_3, BaseFactCollector) == 1
    # Check if instance 'var_3' of class 'HPUXNetworkCollector' implements interface 'BaseFactCollector'.

# Generated at 2022-06-24 22:53:31.370871
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_0 = HPUXNetwork(var_0)
    result = var_0.get_interfaces_info()
# Check for exit status
    assert result is No


# Generated at 2022-06-24 22:53:38.794128
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    var_1 = HPUXNetworkCollector()
    assert var_1._platform == 'HP-UX', "constructor of class HPUXNetworkCollector, var _platform: %s" % var_1._platform
    assert var_1._fact_class == HPUXNetwork, "constructor of class HPUXNetworkCollector, var _fact_class: %s" % var_1._fact_class
    assert var_1._fact_class.platform == 'HP-UX', "constructor of class HPUXNetworkCollector, var _fact_class.platform: %s" % var_1._fact_class.platform


# Generated at 2022-06-24 22:53:41.102795
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Create an object of class HPUXNetworkCollector
    var_1 = HPUXNetworkCollector(module=None)
    assert var_1 is not None


# Generated at 2022-06-24 22:53:45.425432
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    var_0 = HPUXNetwork()


# Generated at 2022-06-24 22:53:51.106181
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    var_0 = {}
    var_1 = {}
    var_1['default_interface'] = 'lan0'
    var_1['default_gateway'] = '192.168.1.1'
    var_0['default_interface'] = 'lan0'
    var_0['default_gateway'] = '192.168.1.1'
    sub_0 = TestCase()
    if (sub_0.match(var_0, var_1)):
        test_case_0()


# Generated at 2022-06-24 22:53:52.452117
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    var_1 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:53:57.966908
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    var_0 = HPUXNetwork()
    var_1 = {}
    var_2 = {'default_interface': 'lan0', 'default_gateway': '172.17.0.1'}
    assert var_0.populate() == var_2, 'Method get_default_interfaces of class HPUXNetwork returned unexpected result.'


# Generated at 2022-06-24 22:53:59.545526
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    print("Running test_HPUXNetwork...")
    var_1 = HPUXNetwork()


# Generated at 2022-06-24 22:54:01.071014
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj_HPUXNetwork = HPUXNetwork()
    var_0 = obj_HPUXNetwork


# Generated at 2022-06-24 22:54:22.728719
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    testcase = HPUXNetwork()
    assert testcase is not None


# Generated at 2022-06-24 22:54:26.101752
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    import pytest
    global var_0
    pytest.main([__file__, '-v', '-s'])

if __name__ == '__main__':
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:54:29.304523
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_0 = HPUXNetwork()
    var_0.module.run_command = MagicMock(side_effect=test_case_0)
    var_0.get_interfaces_info()



# Generated at 2022-06-24 22:54:32.039588
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    var_1 = HPUXNetworkCollector()
    var_2 = HPUXNetworkCollector()
    var_3 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:54:35.371493
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    var_0 = HPUXNetwork()
    test_case_0()
    if var_0.platform is not None:
        var_0.populate()


# Generated at 2022-06-24 22:54:40.295065
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    import sys
    import copy
    import pytest
    from mock import Mock, patch

    # Constructing object instance of class HPUXNetwork
    module = Mock(has_task_run_once_cache_plugin=Mock(return_value=False),
        run_command=Mock(return_value=(0, '', '')), return_value=None,
        params={}, check_mode=False, no_log=False)
    module.get_bin_path = Mock(return_value=False)
    module.run_command = Mock(return_value=(0, '', ''))
    module.run_command.return_value = (0, '', '')

    var_0 = HPUXNetwork(module)

    # Printing object name, class name and required attributes

# Generated at 2022-06-24 22:54:44.912753
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    global var_0
    var_0 = HPUXNetwork()
    var_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:46.973287
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module_0 = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=[u'all'], type='list'),
        )
    )
    
    test_case_0()

# Generated at 2022-06-24 22:54:48.074144
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Create an instance of class HPUXNetwork
    iut = HPUXNetwork()



# Generated at 2022-06-24 22:54:53.477328
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    # normal case
    module = AnsibleModule(
        argument_spec = dict()
    )
    network = HPUXNetwork(module)

    # abnormal case
    var_0 = {}
    var_0['var_0'] = None
    if (var_0['var_0'] == None):
        pass

# Generated at 2022-06-24 22:55:42.158395
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    print ("##### In Method: get_default_interfaces #####")
    
    facts = HPUXNetwork()
    default_facts = facts.get_default_interfaces()
    print(default_facts)

    assert default_facts


# Generated at 2022-06-24 22:55:46.093032
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_0 = test_case_0()
    var_0 = {}
    var_1 = HPUXNetwork.get_interfaces_info(var_0)
    if var_1:
        print("get_interfaces_info of HP-UXNetwork succeeded")
    else:
        print("get_interfaces_info of HP-UXNetwork failed")


# Generated at 2022-06-24 22:55:47.075184
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    var_1 = HPUXNetwork(var_0)


# Generated at 2022-06-24 22:55:50.278218
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    var_1 = HPUXNetworkCollector()
    assert var_1._fact_class == HPUXNetwork


# Generated at 2022-06-24 22:55:53.720300
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    var_1 = HPUXNetwork()
    var_1.populate()



# Generated at 2022-06-24 22:55:55.412544
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    var_1 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:56:00.081060
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    var_0 = {}
    var_0 = HPUXNetwork().populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:56:10.920668
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_0 = {}

# Generated at 2022-06-24 22:56:12.680076
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network_facts = test_case_0()
    facter = HPUXNetworkCollector()
    facter.populate(network_facts)


# Generated at 2022-06-24 22:56:13.419971
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_0 = {}


# Generated at 2022-06-24 22:58:08.766246
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_0 = HPUXNetworkCollector()
    assert fact_0._platform == 'HP-UX'


# Generated at 2022-06-24 22:58:10.377257
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    var_0 = {}

    var_0 = HPUXNetwork.populate(self, var_0)

    return var_0


# Generated at 2022-06-24 22:58:12.112433
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Constructor test case 0
    var_0 = {}


# Generated at 2022-06-24 22:58:14.553775
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    assert HPUXNetwork().populate().get('interfaces') == ['lan0']


# Generated at 2022-06-24 22:58:19.211841
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    var_0 = {}

    network = HPUXNetwork(module=var_0)
    retval = network.populate()
    assert retval == {}

# Generated at 2022-06-24 22:58:26.740780
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_0_0 = var_0['ansible_facts']
    var_0_1 = var_0['ansible_network_resources']
    var_1_0 = None
    def test_method_0_of_class_0_HPUXNetwork():
        var_2_2 = None
        def test_method_4_of_class_3_HPUXFacts():
            var_5_5 = None
            var_5_6 = None
            var_5_7 = None
            var_5_8 = None
            var_5_9 = None
            var_5_10 = None
            var_5_11 = None
            var_5_12 = None
            var_5_13 = None
            var_5_14 = None
            var_5_15 = None
            var_5_

# Generated at 2022-06-24 22:58:30.468887
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    var_0 = {}
    ans = {}
    var_0 = HPUXNetwork.get_default_interfaces(var_0)
    assert var_0 == ans


# Generated at 2022-06-24 22:58:33.136321
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    network.get_interfaces_info()


# Generated at 2022-06-24 22:58:33.569937
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_0 = {}

# Generated at 2022-06-24 22:58:34.777527
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h = HPUXNetwork()
    h.populate()
    var_0 = h.facts
    assert var_0 == {}
