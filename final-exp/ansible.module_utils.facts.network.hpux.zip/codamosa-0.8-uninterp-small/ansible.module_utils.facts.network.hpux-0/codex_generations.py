

# Generated at 2022-06-24 22:50:28.949928
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:50:32.058279
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    result = HPUXNetwork()
    assert result == {}


# Generated at 2022-06-24 22:50:39.230590
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    if h_p_u_x_network_0.get_interfaces_info():
        print('Success is running method get_interfaces_info of class HPUXNetwork.')
    else:
        print('Failed is running method get_interfaces_info of class HPUXNetwork.')


if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:50:40.692409
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()
    assert "HP-UX" == h_p_u_x_network.platform


# Generated at 2022-06-24 22:50:50.295339
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module.run_command = lambda cmd: ('', '', 0)
    interfaces = h_p_u_x_network_0.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0', 'ipv4': {'interface': 'lan0', 'address': '10.17.2.73', 'network': '10.17.2.0'}}
    assert interfaces['lan1'] == {'device': 'lan1', 'ipv4': {'interface': 'lan1', 'address': '10.17.2.81', 'network': '10.17.2.0'}}

# Generated at 2022-06-24 22:50:51.659311
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_case_0()

if __name__ == '__main__':
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:50:57.041513
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_collector_0.module.run_command = get_run_command_mock
    assert h_p_u_x_network_collector_0.get_default_interfaces() == {
        'default_interface': 'lan0',
        'default_gateway': '192.168.142.2'
    }


# Generated at 2022-06-24 22:50:58.352193
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()


# Generated at 2022-06-24 22:50:58.789066
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass

# Generated at 2022-06-24 22:51:00.824502
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:51:12.459178
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    tuple_1 = ()
    h_p_u_x_network_1 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_1)
    var_1 = h_p_u_x_network_1.get_interfaces_info()

# Generated at 2022-06-24 22:51:18.550425
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    var_1 = h_p_u_x_network_0.get_default_interfaces()
    assert var_1 == var_0


# Generated at 2022-06-24 22:51:22.644391
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:28.644164
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Test case data
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == {}


# Generated at 2022-06-24 22:51:36.163329
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    assert h_p_u_x_network_0 is not None


# Generated at 2022-06-24 22:51:41.903679
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.populate({})


# Generated at 2022-06-24 22:51:43.744944
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:51:49.178726
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:51:57.486911
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    tuple_1 = ()
    h_p_u_x_network_1 = HPUXNetwork(h_p_u_x_network_collector_1, tuple_1)
    assert h_p_u_x_network_1._platform == 'HP-UX'
    assert h_p_u_x_network_1.module.run_command == h_p_u_x_network_collector_1.module.run_command


# Generated at 2022-06-24 22:52:06.048045
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    temp_net = HPUXNetworkCollector()
    temp_net._module = AnsibleModule({'ANSIBLE_MODULE_ARGS': {}, })
    temp_net._module.run_command = MagicMock(return_value=(0, 'a b c\n', ''))
    temp_net._platform = 'HP-UX'
    test_data = [("lan0 lo0 lan0", {'lo0': {'device': 'lo0'}, 'lan0': {'ipv4': {'address': 'lo0', 'network': 'lan0', 'interface': 'lan0'}, 'device': 'lan0'}})]
    for case, expected in test_data:
        temp_net._module.run_command.return_value = (0, case, '')

# Generated at 2022-06-24 22:52:21.995515
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:52:27.103300
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    get_default_interfaces = h_p_u_x_network_0.get_default_interfaces()
    assert get_default_interfaces is not None


# Generated at 2022-06-24 22:52:34.870858
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)

# Generated at 2022-06-24 22:52:42.825045
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    assert h_p_u_x_network_0._fact_class == 'HPUXNetwork'
    assert h_p_u_x_network_0._platform == 'HP-UX'



# Generated at 2022-06-24 22:52:46.731519
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    assert not h_p_u_x_network_0.platform


# Generated at 2022-06-24 22:52:52.166846
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()



# Generated at 2022-06-24 22:53:00.131939
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    #assert var_0 == "Assertion error - expected:<{'default_gateway': '192.168.1.1', 'default_interface': 'lan0'}> but was:<{'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}>"



# Generated at 2022-06-24 22:53:02.400391
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network = HPUXNetwork()
    result = h_p_u_x_network.get_default_interfaces()
    assert 'default_gateway' in result
    assert 'default_interface' in result


# Generated at 2022-06-24 22:53:12.425215
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)

    # Call method get_interfaces_info of class HPUXNetwork
    result = h_p_u_x_network_0.get_interfaces_info()

    # Check expected result
    assert result.keys() == ['lan0', 'lo0']
    assert result['lan0']['ipv4']['address'] == '10.168.1.114'
    assert result['lan0']['ipv4']['network'] == '10.168.1.0'

# Generated at 2022-06-24 22:53:21.351010
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)

    if h_p_u_x_network_0.get_default_interfaces() != {'default_interface': 'lan0', 'default_gateway': '20.0.0.2'}:
        raise AssertionError('default_interface should return dict with default_interface and default_gateway')


# Generated at 2022-06-24 22:53:47.262517
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    assert h_p_u_x_network_0._fact_class == h_p_u_x_network_collector_0._fact_class
    assert h_p_u_x_network_0._platform == h_p_u_x_network_collector_0._platform
    assert h_p_u_x_network_0._module == h_p_u_x_network_collector_0._module
    assert h_p_u_x_network_0._warnings == h_p_u_x_network_

# Generated at 2022-06-24 22:53:54.332507
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_1 = HPUXNetwork('HPUXNetworkCollector()', ())
    # Test for when no argument is passed
    var_1 = h_p_u_x_network_1.get_interfaces_info()

    h_p_u_x_network_2 = HPUXNetwork('HPUXNetworkCollector()', ())
    # Test for when 0 is passed
    var_2 = h_p_u_x_network_2.get_interfaces_info(0)

    pass

# Generated at 2022-06-24 22:54:00.949639
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    expected = {'default_interface': 'lan0', 'default_gateway': '172.16.0.1'}
    res = h_p_u_x_network_0.get_default_interfaces()
    assert expected == res


# Generated at 2022-06-24 22:54:06.095827
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.populate(None)
    assert var_0 == {}


# Generated at 2022-06-24 22:54:12.423781
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)


# Generated at 2022-06-24 22:54:16.714409
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:54:21.298644
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    # Zero argument specification
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:30.099841
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    if HPUXNetworkCollector._platform != 'HP-UX':
        return

    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0.platform == 'HP-UX'

    tuple_0 = ()
    h_p_u_x_network_1 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_1.get_default_interfaces()
    assert var_0 == {}


# Generated at 2022-06-24 22:54:35.956461
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    tuple_1 = ()
    h_p_u_x_network_1 = HPUXNetwork(h_p_u_x_network_collector_1, tuple_1)
    var_1 = h_p_u_x_network_1.get_default_interfaces()
    var_2 = h_p_u_x_network_1.get_interfaces_info()
    tuple_2 = (None,)
    h_p_u_x_network_2 = HPUXNetwork(h_p_u_x_network_collector_1, tuple_2)
    var_3 = h_p_u_x_network_2.get_default_interfaces()
    var_4 = h_p

# Generated at 2022-06-24 22:54:41.036271
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:55:17.560648
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:55:25.135088
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    tuple_1 = ()
    h_p_u_x_network_1 = HPUXNetwork(h_p_u_x_network_collector_1, tuple_1)
    assert h_p_u_x_network_1.platform == 'HP-UX'
    assert h_p_u_x_network_1.collector == h_p_u_x_network_collector_1
    assert h_p_u_x_network_1.module == tuple_1
    var_1 = h_p_u_x_network_1.get_default_interfaces()
    var_2 = h_p_u_x_network_1.get_interfaces_info()
    h_p_u

# Generated at 2022-06-24 22:55:34.051229
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    tuple_0 = ()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(tuple_0)
    tuple_1 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_1)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == {}


# Generated at 2022-06-24 22:55:36.071303
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:55:41.878062
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)


# Generated at 2022-06-24 22:55:50.336093
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    tuple_1 = ()
    h_p_u_x_network_1 = HPUXNetwork(h_p_u_x_network_collector_1, tuple_1)
    var_1 = h_p_u_x_network_1.get_interfaces_info()

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:55:56.626650
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:00.347682
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:56:07.774815
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:14.291216
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(None,None)
    h_p_u_x_network_0.module = MagicMock()
    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0,'lan1  10.241.66.41   10.240.0.0     UP  ETHER  1500  1500','stderr'))
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0 == {'lan1': {'ipv4': {'network': '10.240.0.0', 'address': '10.241.66.41', 'interface': 'lan1'}, 'device': 'lan1'}}


# Generated at 2022-06-24 22:57:55.275289
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.default_gateway
    var_1 = h_p_u_x_network_0.interfaces
    var_2 = h_p_u_x_network_0.default_interface


# Generated at 2022-06-24 22:57:58.088460
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network = HPUXNetwork()
    tuple_1 = ()
    h_p_u_x_network.populate(tuple_1)

# Generated at 2022-06-24 22:58:04.502074
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:58:11.644389
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_2 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_2, tuple_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:58:16.462743
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Unit test for constructor of class constructor of class HPUXNetwork
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:58:19.849204
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    assert h_p_u_x_network_0._platform == 'HP-UX'


# Generated at 2022-06-24 22:58:24.462871
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    assert h_p_u_x_network_0._fact_class == HPUXNetwork
    assert h_p_u_x_network_0._platform == 'HP-UX'

# Generated at 2022-06-24 22:58:28.050700
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    tuple_0 = ()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0, tuple_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:58:28.704668
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_case_0()

# Generated at 2022-06-24 22:58:29.668851
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_case_0()