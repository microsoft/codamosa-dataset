

# Generated at 2022-06-24 22:50:32.554924
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


test_case_0()

# Generated at 2022-06-24 22:50:38.379230
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    rc, out, err = h_p_u_x_network_0.module.run_command("/usr/bin/netstat -niw")
    print('rc is : %d' % rc)
    print(out)
    print(err)
    print(h_p_u_x_network_0.get_interfaces_info())


# Generated at 2022-06-24 22:50:48.541592
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-24 22:50:53.440770
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()


# Generated at 2022-06-24 22:51:00.563909
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_HPUXNetwork = HPUXNetwork()
    test_HPUXNetwork.module = AnsibleModule

    # Construct a mock for module.run_command('/usr/bin/netstat -niw')
    mocked_run_command = Mock()
    test_HPUXNetwork.module.run_command = mocked_run_command
    mock_call_0 = call('/usr/bin/netstat -niw')

# Generated at 2022-06-24 22:51:05.034023
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork(module=None)
    assert h_p_u_x_network.platform == 'HP-UX'


# Generated at 2022-06-24 22:51:07.444798
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:13.540197
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert h_p_u_x_network_collector._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector._platform == 'HP-UX'


# Generated at 2022-06-24 22:51:19.374249
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    h_p_u_x_network_collector.command_executor = CommandExecutor("/usr/bin/netstat -niw")
    interfaces_info = h_p_u_x_network_collector.get_interfaces_info()
    assert isinstance(interfaces_info, dict)
    assert interfaces_info=={'lan0': {'ipv4': {'network': '172.21.33.0', 'address': '172.21.33.1', 'interface': 'lan0'}, 'device': 'lan0'}}


# Generated at 2022-06-24 22:51:21.649783
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    assert h_p_u_x_network_0


# Generated at 2022-06-24 22:51:29.506179
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpuxnetwork_0 = HPUXNetwork()

    default_interfaces_0 = hpuxnetwork_0.get_default_interfaces()
    print(default_interfaces_0)

# Generated at 2022-06-24 22:51:34.129334
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()



# Generated at 2022-06-24 22:51:36.551443
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network.populate()


# Generated at 2022-06-24 22:51:39.070770
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:40.364607
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()

# Generated at 2022-06-24 22:51:49.760253
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    #
    # An error report from netstat has no correct interfaces info
    #
    fd = open('unit/modules/network/unit_tests/output/netstat_niw_err.txt')
    netstat_niw_out = fd.read()
    fd.close()
    h_p_u_x_network_0.module.run_command.return_value = 1, netstat_niw_out, ''
    assert h_p_u_x_network_0.get_interfaces_info() == {}
    #
    # Works well with netstat output:
    #
    fd = open('unit/modules/network/unit_tests/output/netstat_niw_ok.txt')
    netstat_ni

# Generated at 2022-06-24 22:51:55.885115
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    result_0 = h_p_u_x_network_0.populate()
    assert 'default_interface' in result_0
    assert 'interfaces' in result_0
    assert 'lan0' in result_0
    assert 'ipv4' in result_0['lan0']
    assert 'address' in result_0['lan0']['ipv4']


# Generated at 2022-06-24 22:51:57.620782
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert isinstance(network, HPUXNetwork)


# Generated at 2022-06-24 22:52:02.727698
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    mock_module = MagicMock()
    mock_module.run_command = MagicMock(return_value=(0,
                                      "default 00000000 192.168.1.1 UGS 700 0 lan0\n",
                                      ''))
    network_0 = HPUXNetwork(mock_module)

    default_interfaces_facts = {'default_gateway': '192.168.1.1',
                                'default_interface': 'lan0'}
    result_facts = network_0.get_default_interfaces()
    assert default_interfaces_facts == result_facts


# Generated at 2022-06-24 22:52:08.084553
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces_facts_0 = h_p_u_x_network_0.get_default_interfaces()
    assert ('default_interface' in default_interfaces_facts_0)
    assert ('default_gateway' in default_interfaces_facts_0)


# Generated at 2022-06-24 22:52:21.702786
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network_get_interfaces_info_0 = h_p_u_x_network.get_interfaces_info()


# Generated at 2022-06-24 22:52:26.864454
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0._module = mock.Mock()
    h_p_u_x_network_0.module.run_command = mock.Mock(return_value=('0',
        'default 192.168.1.1 UGH lan0', ''))
    h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:52:28.214260
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:52:35.872995
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces_facts_data = {'ipv4': {'address': '172.31.10.37', 'network': '172.31.10.0', 'interface': 'lan0'}, 'device': 'lan0'}
    default_interfaces_facts_data.update({'ipv4': {'address': '172.31.10.37', 'network': '172.31.10.0', 'interface': 'lan0'}, 'device': 'lan0'})
    default_interfaces_facts_data.update({'ipv4': {'address': '172.31.10.37', 'network': '172.31.10.0', 'interface': 'lan0'}, 'device': 'lan0'})

# Generated at 2022-06-24 22:52:40.975852
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    interfaces = h_p_u_x_network_0.get_interfaces_info()
    assert(interfaces['lan0']['ipv4']['address'] != '')


# Generated at 2022-06-24 22:52:42.708552
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()


# Generated at 2022-06-24 22:52:45.120666
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:52:48.344874
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.platform == 'HP-UX', "Default value for attribute 'platform' is not correct"


# Generated at 2022-06-24 22:52:56.716825
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    rc, out, err = h_p_u_x_network_0.module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]
    default_interfaces_facts = h_p_u_x_network_0.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == default_interface
    assert default_interfaces_facts['default_gateway'] == default_gateway


# Generated at 2022-06-24 22:53:00.346018
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    return_value_0 = h_p_u_x_network_0.get_default_interfaces()
    assert return_value_0 == {'default_gateway': '0.0.0.0', 'default_interface': 'lan0'}


# Generated at 2022-06-24 22:53:22.917471
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:53:25.961150
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:53:27.472272
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:53:31.109355
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert h_p_u_x_network_collector is not None


# Generated at 2022-06-24 22:53:38.209429
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network = HPUXNetwork()
    rc, out, err = h_p_u_x_network.module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]

    assert default_interface == "lan5"
    assert default_gateway == "0.0.0.0"


# Generated at 2022-06-24 22:53:39.545564
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()

# Generated at 2022-06-24 22:53:48.455553
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_get_interfaces_info_0 = HPUXNetwork()

    e_r_r_0 = ''
    o_u_t_0 = h_p_u_x_network_get_interfaces_info_0.get_interfaces_info()
    
    try:
        assert o_u_t_0.keys() == ['lan0', 'lan1', 'lan2']
    except AssertionError as e:
        e_r_r_0 = str(e)


# Generated at 2022-06-24 22:53:53.257058
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    if h_p_u_x_network_0.get_default_interfaces() != None:
        assert True
    else:
        assert False


# Generated at 2022-06-24 22:53:56.396675
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    assert (h_p_u_x_network_0.populate()) != None


# Generated at 2022-06-24 22:54:00.749634
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces = h_p_u_x_network_0.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.10.10.1'


# Generated at 2022-06-24 22:54:41.742069
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    print("HPUXNetworkCollector initialized successfully")

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:54:48.376606
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_1)
    facts = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:54:53.559597
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'

# Generated at 2022-06-24 22:54:56.775364
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    rc, out, err = h_p_u_x_network_0.module.run_command()
    assert rc == 0


# Generated at 2022-06-24 22:55:02.905633
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    result = HPUXNetwork()
    assert isinstance(result, HPUXNetwork)


# Generated at 2022-06-24 22:55:08.630094
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()


# Generated at 2022-06-24 22:55:11.491622
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork([])


# Generated at 2022-06-24 22:55:15.387189
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces = h_p_u_x_network_0.get_default_interfaces()
    assert ('default_interface' in default_interfaces) == True
    assert ('default_gateway' in default_interfaces) == True

# Generated at 2022-06-24 22:55:21.199371
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()

    # Check if the function populate exits
    assert hasattr(h_p_u_x_network_0, 'populate')

    # Check if the function populate is a callable
    assert callable(h_p_u_x_network_0.populate)

    # Call the function populate
    h_p_u_x_network_0.module = MockModule()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:55:22.283675
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network = HPUXNetwork()
    assert h_p_u_x_network.get_default_interfaces() == {}


# Generated at 2022-06-24 22:57:03.386016
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network_populate = h_p_u_x_network.populate()
    assert len(h_p_u_x_network_populate['ansible_default_ipv4']['interface']) > 1
    assert h_p_u_x_network_populate['ansible_default_ipv4']['interface'] == h_p_u_x_network_populate['ansible_lo']['interface']
    assert len(h_p_u_x_network_populate['ansible_eth0']['ipv4']['address']) > 1

# Generated at 2022-06-24 22:57:06.173254
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network_populate_0 = h_p_u_x_network.populate()


# Generated at 2022-06-24 22:57:17.215086
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = h_p_u_x_network_collector_0._fact_class(h_p_u_x_network_collector_0._module)

# Generated at 2022-06-24 22:57:22.889482
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(
        module=AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True
        )
    )
    h_p_u_x_network_0._get_interfaces_info()
    h_p_u_x_network_0.get_interfaces_info()
    h_p_u_x_network_0._get_default_interfaces()
    h_p_u_x_network_0.get_default_interfaces()

# Generated at 2022-06-24 22:57:26.958976
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # TODO: check if the below line returns expected result
    HPUXNetwork_get_default_interfaces_0 = test_case_0().get_default_interfaces()



# Generated at 2022-06-24 22:57:33.008964
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0.platform == 'HP-UX'
    assert h_p_u_x_network_collector_0.fact_class == HPUXNetwork


# Generated at 2022-06-24 22:57:36.122423
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert False, "Test not implemented"


# Generated at 2022-06-24 22:57:38.583829
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_instance = HPUXNetwork()


# Generated at 2022-06-24 22:57:40.784378
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_obj = HPUXNetworkCollector()

# Generated at 2022-06-24 22:57:44.950889
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    result = h_p_u_x_network_0.get_interfaces_info()
    assert isinstance(result, dict)


# Generated at 2022-06-24 22:59:37.730320
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'failed to read /etc/default/passwd: %s'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert (var_0 is None)



# Generated at 2022-06-24 22:59:47.842379
# Unit test for method populate of class HPUXNetwork

# Generated at 2022-06-24 22:59:51.098000
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_collector_0._fact_class == HPUXNetwork
    assert h_p_u_x_collector_0._platform == 'HP-UX'

# Generated at 2022-06-24 22:59:52.340430
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_case_0()

# Generated at 2022-06-24 22:59:57.219439
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert h_p_u_x_network_0.module == str_0


# Generated at 2022-06-24 22:59:59.596459
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    assert callable(getattr(HPUXNetwork, 'populate'))


# Generated at 2022-06-24 23:00:08.147897
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'failed to read /etc/default/passwd: %s'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    # Element var_0[0] of tuple var_0 is the interface name
    # Element var_0[1] of tuple var_0 is the interface address
    if (var_0[0][0] == 'lan0' and var_0[0][1] == 'lan0'):
        print('Unit test for method get_interfaces_info of class HPUXNetwork: PASS')
    else:
        print('Unit test for method get_interfaces_info of class HPUXNetwork: FAIL')


# Generated at 2022-06-24 23:00:12.428359
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'failed to read /etc/default/passwd: %s'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.populate()
    var_1 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 23:00:19.112689
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    str_0 = 'failed to read /etc/default/passwd: %s'
    h_p_u_x_network_0 = HPUXNetwork(str_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    var_1 = h_p_u_x_network_0.get_interfaces_info()
    var_2 = h_p_u_x_network_0.get_interfaces_info()
    var_3 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 23:00:22.836795
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    var_2 = HPUXNetwork('tcp://169.254.169.254')
    var_3 = var_2.get_interfaces_info()
