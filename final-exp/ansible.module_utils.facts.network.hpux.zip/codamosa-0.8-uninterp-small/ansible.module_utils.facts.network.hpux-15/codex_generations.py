

# Generated at 2022-06-24 22:50:33.635070
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(module=None)

    rc, out, err = h_p_u_x_network_0.module._run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        for i in range(len(words) - 1):
            if words[i][:3] == 'lan':
                device = words[i]
                interfaces_info = {'device': device}
                address = words[i + 3]
                interfaces_info['ipv4'] = {'address': address}
                network = words[i + 2]

# Generated at 2022-06-24 22:50:37.202331
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert h_p_u_x_network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-24 22:50:39.862183
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    # Assert that the constructor has created a data structure for collected
    # facts
    assert h_p_u_x_network_collector_0.collected_facts == {}


# Generated at 2022-06-24 22:50:41.313498
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()

    assert h_p_u_x_network_collector is not None


# Generated at 2022-06-24 22:50:47.736450
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0,
                                                 'default 172.16.1.1 UGS 0 100000 0 lan0',
                                                 ''))
    test_HPUXNetwork = HPUXNetwork(mock_module)
    test_HPUXNetwork.get_default_interfaces()


# Generated at 2022-06-24 22:50:54.800032
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert h_p_u_x_network_collector
    assert h_p_u_x_network_collector._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector._platform == 'HP-UX'

test_case_0()
test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:50:58.478202
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    print(h_p_u_x_network_collector)



# Generated at 2022-06-24 22:51:01.120106
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork(module=None)
    assert h_p_u_x_network.platform == 'HP-UX'
    assert h_p_u_x_network.module is None


# Generated at 2022-06-24 22:51:05.321943
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # test case 0
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:07.970393
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    out = h_p_u_x_network_0.populate()
    print(out)


# Generated at 2022-06-24 22:51:19.408973
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()



# Generated at 2022-06-24 22:51:20.975431
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:27.072648
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()

# Generated at 2022-06-24 22:51:31.469009
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '172.28.128.1'


# Generated at 2022-06-24 22:51:34.581004
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces_truth_0 = {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}
    assert h_p_u_x_network_0.get_default_interfaces() == default_interfaces_truth_0


# Generated at 2022-06-24 22:51:37.444626
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # create HPUXNetworkCollector() instance
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:51:42.950368
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    assert h_p_u_x_network_0 is not None
    h_p_u_x_network_0._collect()
    assert h_p_u_x_network_0.facts is None

if __name__ == '__main__':
    test_HPUXNetwork()

# Generated at 2022-06-24 22:51:52.032435
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()

# Generated at 2022-06-24 22:51:55.884470
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    os_platform = h_p_u_x_network_0.get_os_platform()
    if os_platform == 'HP-UX':
        h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:58.581502
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    interfaces = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:52:14.244411
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(module=None, facts=None)
    h_p_u_x_network_1 = HPUXNetwork(module=None, facts=None)
    h_p_u_x_network_2 = HPUXNetwork(module=None, facts=None)
    out = h_p_u_x_network_1.get_interfaces_info()
    assert out == h_p_u_x_network_1.get_interfaces_info()
    assert out == h_p_u_x_network_2.get_interfaces_info()



# Generated at 2022-06-24 22:52:20.665796
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    h_p_u_x_network_1 = HPUXNetwork(module=None)
    assert h_p_u_x_network_0 != h_p_u_x_network_1


# Generated at 2022-06-24 22:52:22.264136
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:52:30.417894
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Create the instance
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = AnsibleModule
    h_p_u_x_network_0.__init__()
    # Set the instance attributes
    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0,'default 192.168.0.1 US 0.0.0.0 UGS lan0','stderr'))
    # Get the result
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

# Generated at 2022-06-24 22:52:33.941869
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0.platform == 'HP-UX'


# Generated at 2022-06-24 22:52:42.870877
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(dict())

    rc, out, err = h_p_u_x_network_0.module.run_command("/usr/bin/netstat -niw")

    interfaces = h_p_u_x_network_0.get_interfaces_info()
    assert len(interfaces) > 0

    rc, out, err = h_p_u_x_network_0.module.run_command("/usr/bin/netstat -niw")
    assert rc == 0


# Generated at 2022-06-24 22:52:44.204955
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork(argument=None, platform='HP-UX')


# Generated at 2022-06-24 22:52:49.549058
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_default_interfaces() is None


# Generated at 2022-06-24 22:52:59.992050
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    rc, out, err = h_p_u_x_network_0.module.run_command(
        "/usr/bin/netstat -niw")
    assert rc == 0 and out != ""
    interfaces = {}
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        for i in range(len(words) - 1):
            if words[i][:3] == 'lan':
                device = words[i]
                interfaces[device] = {'device': device}
                address = words[i + 3]
                interfaces[device]['ipv4'] = {'address': address}
                network = words[i + 2]

# Generated at 2022-06-24 22:53:01.257618
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:53:23.697758
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    assert h_p_u_x_network_0.platform == 'HP-UX'
    assert h_p_u_x_network_0.default_interface is None
    assert h_p_u_x_network_0.interfaces is None


# Generated at 2022-06-24 22:53:27.050907
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h = HPUXNetwork()
    interfaces_info = h.get_interfaces_info()
    assert isinstance(interfaces_info, dict)
    assert 'lan0' in interfaces_info


# Generated at 2022-06-24 22:53:31.677531
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network = HPUXNetwork()
    default_interfaces = h_p_u_x_network.get_default_interfaces()
    assert type(default_interfaces) == dict



# Generated at 2022-06-24 22:53:35.221492
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
  try:
    h_p_u_x_network = HPUXNetwork(module)
  except NameError as err:
    assert type(err) == NameError
    assert str(err) == "global name 'module' is not defined"


# Generated at 2022-06-24 22:53:39.100961
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass # Nothing to do here

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:53:45.050980
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    # call to get_default_interfaces of class HPUXNetwork
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_collector_0.get_interfaces_info()
    default_interfaces_0 = h_p_u_x_network_0.get_default_interfaces()

# Generated at 2022-06-24 22:53:51.709899
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_ = HPUXNetworkCollector()
    assert isinstance(h_p_u_x_network_collector_, HPUXNetworkCollector)
    # Function 'get_collector' of class 'HPUXNetworkCollector' has no return statement defined.
    # assert h_p_u_x_network_collector_.get_collector() == HPUXNetworkCollector()

if __name__ == "__main__":
    h_p_u_x_network_collector_ = HPUXNetworkCollector()
    h_p_u_x_network_collector_.get_collector()
    print("All passed")

# Generated at 2022-06-24 22:54:00.452227
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    result = HPUXNetwork().populate()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.10.30.1'
    assert result['interfaces'][0] == 'lan0'
    assert result['lan0']['ipv4']['address'] == '10.10.30.231'
    assert result['lan0']['ipv4']['network'] == '10.10.30.0'
    assert result['lan0']['ipv4']['interface'] == 'lan0'
    assert result['lan0']['ipv4']['address'] == '10.10.30.231'

# Generated at 2022-06-24 22:54:01.341858
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()

# Generated at 2022-06-24 22:54:04.433729
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector_0 = HPUXNetworkCollector()
    assert len(collector_0._cache) == 0
    assert collector_0._platform == 'HP-UX'
    assert collector_0._fact_class == HPUXNetwork


# Generated at 2022-06-24 22:54:27.750377
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector.platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class.platform == 'HP-UX'

    h_p_u_x_network_collector = HPUXNetworkCollector()

    h_p_u_x_network_0 = h_p_u_x_network_collector.get_object()
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:32.950574
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()

# Generated at 2022-06-24 22:54:35.931333
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector_class = HPUXNetworkCollector()
    assert collector_class.platform == "HP-UX"
    assert collector_class.fact_class == HPUXNetwork


# Generated at 2022-06-24 22:54:44.921613
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-24 22:54:54.868318
# Unit test for method populate of class HPUXNetwork

# Generated at 2022-06-24 22:54:59.807114
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    var_h_p_u_x_network_collector = HPUXNetworkCollector(_fact_class=HPUXNetwork, _platform='HP-UX')
    assert var_h_p_u_x_network_collector.fact_class == HPUXNetwork
    assert var_h_p_u_x_network_collector.platform == 'HP-UX'


# Generated at 2022-06-24 22:55:06.568306
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)

    # Call method populate of HPUXNetwork
    var_0 = h_p_u_x_network_0.populate()
    print(var_0['default_interface'])

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork_populate()
    print('Done')

# Generated at 2022-06-24 22:55:12.103421
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()



# Generated at 2022-06-24 22:55:16.999667
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    byte_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(byte_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()

# Generated at 2022-06-24 22:55:24.781446
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    actual_value_0 = HPUXNetworkCollector(bytes_0)
    assert actual_value_0._fact_class == HPUXNetwork
    assert actual_value_0._platform == 'HP-UX'

# Generated at 2022-06-24 22:56:23.063160
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    assert h_p_u_x_network_0._fact_class is not None
    assert h_p_u_x_network_0._platform == 'HP-UX'


# Generated at 2022-06-24 22:56:32.327178
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import subprocess
    v_0 = subprocess.Popen('/usr/bin/netstat -nr', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    v_1 = v_0.communicate()
    var_0 = v_1[0]
    v_0.wait()

    var_1 = var_0.splitlines()

    var_3 = var_1[0]
    var_4 = var_3.split()
    if len(var_4) > 1:
        if var_4[0] == 'default':
            v_5 = var_4[4]
            v_6 = var_4[1]
    if len(var_4) > 1:
        if var_4[0] == 'default':
            v_

# Generated at 2022-06-24 22:56:36.631562
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:56:40.859821
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0)


if __name__ == '__main__':
    # test_HPUXNetworkCollector()
    # test_case_0()
    pass

# Generated at 2022-06-24 22:56:47.715228
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.populate()
    # var_0 should be type dict.



# Generated at 2022-06-24 22:56:55.693705
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    assert h_p_u_x_network_0.module is None


# Generated at 2022-06-24 22:57:03.440797
# Unit test for method populate of class HPUXNetwork

# Generated at 2022-06-24 22:57:13.278820
# Unit test for method get_default_interfaces of class HPUXNetwork

# Generated at 2022-06-24 22:57:20.003497
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:57:24.196845
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_2 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_2 = HPUXNetwork(bytes_2)
    h_p_u_x_network_2.module.run_command = MagicMock()
    collected_facts_3 = None
    var_0 = h_p_u_x_network_2.populate(collected_facts_3)
    assert var_0 == None

# Generated at 2022-06-24 22:59:23.047871
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 is not None


# Generated at 2022-06-24 22:59:33.119836
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    h_p_u_x_network_1 = HPUXNetwork(bytes_0)
    assert h_p_u_x_network_0 == h_p_u_x_network_1
    h_p_u_x_network_0.module.run_command = mock_module_run_command
    assert h_p_u_x_network_0.get_default_interfaces() == {}

# Generated at 2022-06-24 22:59:34.826494
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    assert 0 == len(__test_HPUXNetwork_get_default_interfaces())


# Generated at 2022-06-24 22:59:40.613690
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:59:43.989399
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\x9a\xc1\x1a\xab\xb0\xef\x80\xa7\x8a\x11\xb2`l\x02\xe6\x8c'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:59:48.189899
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bytes_0)


# Generated at 2022-06-24 22:59:54.279941
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\xa9\x13t\xef\xa4\xde\n\xeb\x15B\xec\x8b\x9b\xdb\xccV\x16`\x1b'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:00:01.612480
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:00:03.945083
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    with pytest.raises(TypeError):
        HPUXNetworkCollector(None)

# Method test_case_0 of class HPUXNetwork

# Generated at 2022-06-24 23:00:11.136972
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bytes_0 = b'\x9aq\xc4`(\x0c\x13j\x11>=bG\xf9\xea\x99\xb4\x1e\xb9\xee'
    h_p_u_x_network_0 = HPUXNetwork(bytes_0)
    var_0 = h_p_u_x_network_0.populate()