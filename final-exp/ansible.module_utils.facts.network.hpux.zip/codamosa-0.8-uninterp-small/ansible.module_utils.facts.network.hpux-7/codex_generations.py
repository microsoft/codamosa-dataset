

# Generated at 2022-06-24 22:50:26.757044
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:50:34.881632
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()


    try:
        assert isinstance(h_p_u_x_network, HPUXNetwork)
        assert isinstance(h_p_u_x_network, Network)
        assert h_p_u_x_network.platform == 'HP-UX'

    except Exception as inst:
        print(type(inst))    # the exception instance
        print(inst.args)     # arguments stored in .args
        print(inst)          # __str__ allows args to printed directly

# Generated at 2022-06-24 22:50:37.471317
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_interfaces_info() == {'lanc0': {
        'ipv4': {'network': '192.168.1.0', 'address': '192.168.1.2', 'interface': 'lanc0'}, 'device': 'lanc0'}}


# Generated at 2022-06-24 22:50:42.006404
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'
    assert h_p_u_x_network_collector_0._fact_class == 'HPUXNetwork'

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:50:47.855964
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0._fact_class == HPUXNetwork
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'

# Generated at 2022-06-24 22:50:52.421231
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces_facts = h_p_u_x_network_0.get_default_interfaces()
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts


# Generated at 2022-06-24 22:50:58.006329
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = MagicMock()
    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0, "default 192.168.1.1 UGSc 192.168.1.14 ixgbe0", ""))
    h_p_u_x_network_0.get_default_interfaces()



# Generated at 2022-06-24 22:50:59.639143
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network = HPUXNetwork()
    assert h_p_u_x_network is not None


# Generated at 2022-06-24 22:51:01.367449
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:04.736220
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:51:13.533922
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Test class constructor
    bool_0 = False
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bool_0)

# Generated at 2022-06-24 22:51:15.907883
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:51:20.196025
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0 is not None
    assert h_p_u_x_network_0.populate() is not None


# Generated at 2022-06-24 22:51:22.437085
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bool_0 = False
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:51:25.017666
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:51:29.359870
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:51:32.250001
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector('')
    assert isinstance(obj, HPUXNetworkCollector) is True
    assert obj._fact_class._platform is obj._platform


# Generated at 2022-06-24 22:51:34.439181
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:36.899252
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.__class__.__name__ == 'HPUXNetworkCollector'

# Generated at 2022-06-24 22:51:40.839891
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:51:53.348504
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)


# Generated at 2022-06-24 22:51:55.586741
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    # Do nothing


# Generated at 2022-06-24 22:51:59.252257
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    ansible_facts_0 = {}
    h_p_u_x_network_0.populate(ansible_facts_0)


# Generated at 2022-06-24 22:52:03.672252
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0

# Generated at 2022-06-24 22:52:08.595601
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module_0 = AnsibleModule(argument_spec={})
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(module_0)

# Generated at 2022-06-24 22:52:11.686030
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()



# Generated at 2022-06-24 22:52:14.756456
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    assert h_p_u_x_network_collector._platform == 'HP-UX'


# Generated at 2022-06-24 22:52:19.705959
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bool_0 = False
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:52:22.472754
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(False)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:52:23.413805
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_case_0()


# Generated at 2022-06-24 22:52:43.657799
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Test function of class HPUXNetworkCollector
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:52:48.454914
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)



# Generated at 2022-06-24 22:52:51.625189
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0._fact_class == HPUXNetwork


# Generated at 2022-06-24 22:52:56.691624
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0 != None


# Generated at 2022-06-24 22:53:02.446920
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_collector_0.collect()

# Generated at 2022-06-24 22:53:08.837903
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector

    # Test with empty values:
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

    assert h_p_u_x_network_collector_0.platform == "HP-UX"
    assert h_p_u_x_network_collector_0.fact_class == HPUXNetwork

# Generated at 2022-06-24 22:53:15.725636
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )
    out = HPUXNetwork(module).get_default_interfaces()
    print(out)
    assert True

if __name__ == '__main__':
    from ansible.module_utils.basic import *  # module_utils.basic overrides AnsibleModule
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    out = HPUXNetwork(AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )).populate()
    print(out)

# Generated at 2022-06-24 22:53:23.329218
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0 == {'lan0': {'ipv4': {'interface': 'lan0', 'address': '172.16.247.161', 'network': '172.16.247.128/25'}, 'device': 'lan0'}}


# Generated at 2022-06-24 22:53:29.785465
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    bool_1 = h_p_u_x_network_0._populate_from_ansible_module
    h_p_u_x_network_0.populate()
    h_p_u_x_network_0.get_default_interfaces()
    h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:53:39.330176
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    '''
    Test with a mocked netstat command
    '''
    netstat_out = ('lan0  42.5.49.138 255.255.255.0  42.5.49.254  U 1     0      0 lan0',
                   'lan1  192.168.1.1 255.255.255.0  192.168.1.255 U 2     0      0 lan1')
    test_subject = HPUXNetwork(False)
    test_subject.module.run_command = lambda x: (0, '\n'.join(netstat_out), '')


# Generated at 2022-06-24 22:54:19.265816
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    assert h_p_u_x_network_0 != None
    assert h_p_u_x_network_0._module != None
    assert h_p_u_x_network_0._get_interfaces_info != None

# Test suite for class HPUXNetwork

# Generated at 2022-06-24 22:54:21.774277
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bool_0 = False
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bool_0)

# Generated at 2022-06-24 22:54:26.245324
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bool_0 = True
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bool_0)
    var_0 = h_p_u_x_network_collector_0.facts()
    # Should not return anything
    assert var_0 == {}



# Generated at 2022-06-24 22:54:28.181811
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

# Generated at 2022-06-24 22:54:31.083829
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:54:32.664152
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)

# Generated at 2022-06-24 22:54:34.548732
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

# Generated at 2022-06-24 22:54:44.394260
# Unit test for constructor of class HPUXNetworkCollector

# Generated at 2022-06-24 22:54:47.993098
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    # Passed variables
    module_args=dict(
        gather_subset=['all']
    )

    # initialize the target object
    init_AnsibleModule(module_args=module_args)

    # This class is also instantiated by the facts collection process.
    # It is not instantiated by the constructor.
    h_p_u_x_network_0 = HPUXNetwork()




# Generated at 2022-06-24 22:54:58.757225
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    var_1 = h_p_u_x_network_0.get_interfaces_info()
    var_2 = h_p_u_x_network_0.populate()
    assert (var_1 == {'': {'ipv4': {'address': '0.0.0.0',
                                    'interface': '',
                                    'network': '0.0.0.0'}}})

# Generated at 2022-06-24 22:56:33.087865
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert len(var_0) == 2
    assert 'default_gateway' in var_0
    assert 'default_interface' in var_0


# Generated at 2022-06-24 22:56:35.694299
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetworkCollector(module).collect()
    assert len(network_facts['interfaces']) > 0
    assert network_facts['default_gateway']

# Generated at 2022-06-24 22:56:38.391144
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    var_0 = h_p_u_x_network_collector_0.fact()
    assert type(var_0).__name__ == "dict"


# Generated at 2022-06-24 22:56:41.756284
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 == {}, "Expected: {}, Given: {}".format({}, var_0)


# Generated at 2022-06-24 22:56:49.472353
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Create a new instance of HPUXNetworkCollector()
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    # Assert that class HPUXNetworkCollector() has attribute _platform
    assert hasattr(h_p_u_x_network_collector_0, '_platform')
    # Assert that class HPUXNetworkCollector() has attribute _fact_class
    assert hasattr(h_p_u_x_network_collector_0, '_fact_class')
    # Verify that class HPUXNetworkCollector()'s private attribute _platform is equal to 'HP-UX'
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'
    # Verify that class HPUXNetworkCollector()'s private attribute _fact

# Generated at 2022-06-24 22:56:52.721612
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)


# Generated at 2022-06-24 22:56:54.287549
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    '''
    Test case for constructor of class HPUXNetworkCollector
    '''
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

# Generated at 2022-06-24 22:57:00.141543
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()



# Generated at 2022-06-24 22:57:01.310810
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    HPUXNetwork_populate_obj = HPUXNetwork(False)
    HPUXNetwork_populate_obj.populate()

# Generated at 2022-06-24 22:57:04.163481
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = False
    # Test for equality with expected result
    assert (HPUXNetwork(bool_0).get_interfaces_info() == {
        'lan2': {
            'ipv4': {'address': '150.150.150.150', 'network': '150.150.150.0', 'interface': 'lan2'},
            'device': 'lan2'
        }})

