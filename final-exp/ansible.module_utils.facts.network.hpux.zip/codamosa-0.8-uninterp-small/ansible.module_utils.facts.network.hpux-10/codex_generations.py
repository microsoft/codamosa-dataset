

# Generated at 2022-06-24 22:50:29.641314
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    test = HPUXNetwork()

    results = test.get_interfaces_info()

    for iface in results:
        assert 'lan0' in results[iface]
        assert 'ipv4' in results[iface]


# Generated at 2022-06-24 22:50:34.482210
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    out = h_p_u_x_network_0.get_default_interfaces()
    assert {'default_gateway': '0.0.0.0', 'default_interface': 'lan0'} == out


# Generated at 2022-06-24 22:50:40.015563
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0._fact_class.get_default_interfaces() == \
        {'default_gateway': '10.0.0.1', 'default_interface': 'lan6'}


# Generated at 2022-06-24 22:50:43.859012
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    rc, out, err = h_p_u_x_network_0.module.run_command("/usr/bin/netstat -niw")
    h_p_u_x_network_0.module.exit_json(msg=h_p_u_x_network_0.get_interfaces_info())



# Generated at 2022-06-24 22:50:47.936564
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_default_interfaces() is not None


# Generated at 2022-06-24 22:50:55.774851
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    dict = {}
    dict['lan0'] = {'ipv4': {'interface': 'lan0', 'address': '172.20.1.18', 'network': '172.20.1.18'}, 'device': 'lan0'}
    dict['lan1'] = {'ipv4': {'interface': 'lan1', 'address': '172.20.2.18', 'network': '172.20.2.18'}, 'device': 'lan1'}

    HPUXNetwork_obj = HPUXNetwork()
    assert HPUXNetwork_obj.get_interfaces_info() == dict


# Generated at 2022-06-24 22:51:00.842491
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_interfaces_info() is not None


# Generated at 2022-06-24 22:51:04.333735
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert isinstance(HPUXNetworkCollector(), HPUXNetworkCollector)


# Generated at 2022-06-24 22:51:05.750565
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
  assert isinstance(HPUXNetworkCollector(),HPUXNetworkCollector)


# Generated at 2022-06-24 22:51:12.737332
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    interfaces_info = net.get_interfaces_info()

    assert interfaces_info['lan0'] == {'ipv4': {'address': '172.31.255.253',
                                                'interface': 'lan0',
                                                'network': '172.31.255.252'},
                                       'device': 'lan0'}

    assert interfaces_info['lan1'] == {'ipv4': {'address': '172.31.255.245',
                                                'interface': 'lan1',
                                                'network': '172.31.255.244'},
                                       'device': 'lan1'}



# Generated at 2022-06-24 22:51:21.346858
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # test initialization of class
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    # test __init__ (constructor)
    assert h_p_u_x_network_collector_0.__init__()


# Generated at 2022-06-24 22:51:24.930008
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_default_interfaces() == {'default_gateway': '', 'default_interface': '--'}



# Generated at 2022-06-24 22:51:30.960888
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    h_p_u_x_network_1 = HPUXNetwork(module=h_p_u_x_network_collector_1.module)
    h_p_u_x_network_1.get_default_interfaces()


# Generated at 2022-06-24 22:51:34.258038
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()

    # test method populate of Class HPUXNetwork with arguments self=h_p_u_x_network_0
    h_p_u_x_network_0.populate()



# Generated at 2022-06-24 22:51:38.948457
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork()

# Generated at 2022-06-24 22:51:41.622440
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_0 is not None


# Generated at 2022-06-24 22:51:49.822058
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_network = HPUXNetwork()
    network_facts = hpux_network.populate()
    assert network_facts
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '0.0.0.0'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '127.0.0.1'
    assert network_facts['lan0']['ipv4']['network'] == '127.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-24 22:51:52.964464
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    assert h_p_u_x_network_0 is not None


# Generated at 2022-06-24 22:51:56.284077
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    output_0 = h_p_u_x_network_0.get_interfaces_info()
    print(output_0)
    assert('lan0' in output_0.keys())


# Generated at 2022-06-24 22:52:05.830980
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    cli_resp_0 = "default 192.168.1.1 UG lan0 \n"
    cli_resp_1 = "127 0.0.0.1 UG localhost \n"
    cli_resp_2 = "127.0.0.0/8 192.168.1.1 UG lan0 \n"
    cli_resp_3 = "127.127.127.127 127.0.0.1 UH lo0\n"
    cli_resp_4 = "127.163.192.1 127.0.0.1 UH lo0\n"
    cli_resp_5 = "127.163.192.0/24 192.168.1.1 UG lan0\n"

# Generated at 2022-06-24 22:52:23.750971
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module.run_command = MagicMock(return_value=(0, "", ""))
    default_interfaces = {'default_interface': 'lan0',
                          'default_gateway': '10.1.1.1'}
    assert h_p_u_x_network_0.get_default_interfaces() == default_interfaces


# Generated at 2022-06-24 22:52:34.634389
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.h_p_u_x import HPUXNetwork
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network_collector_1 = HPUXNetworkCollector(network=h_p_u_x_network)

    h_p_u_x_network_collector_1.network.module.run_command = \
        lambda x: (0, 'default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default  default', '')

    h_p_u_x_network_collector_1.network

# Generated at 2022-06-24 22:52:38.009852
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu_xn_w0 = HPUXNetwork()
    hpu_xn_w0.populate()


# Generated at 2022-06-24 22:52:45.896710
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-24 22:52:47.669140
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:52:50.031687
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network = HPUXNetwork()
    print()
    print(h_p_u_x_network.get_interfaces_info())

# Generated at 2022-06-24 22:53:00.480638
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network.module.run_command = commands_run_command

# Generated at 2022-06-24 22:53:06.017894
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    assert HPUXNetwork({}).get_interfaces_info() == {'lan0': {'device': 'lan0', 'ipv4': {'address': '10.0.0.81', 'network': '10.0.0.0','interface': 'lan0'}}}


# Generated at 2022-06-24 22:53:11.685729
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = None
    h_p_u_x_network_0.module_run_command = None
    h_p_u_x_network_0.module_run_command = None
    h_p_u_x_network_0.module_run_command = None
    h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:53:14.677508
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    assert True


# Generated at 2022-06-24 22:53:36.242402
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_file_path() == ''


# Generated at 2022-06-24 22:53:40.373810
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network = HPUXNetwork()
    default_interfaces = h_p_u_x_network.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0', 'default_gateway': '172.17.2.1'}


# Generated at 2022-06-24 22:53:41.272213
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    pass


# Generated at 2022-06-24 22:53:46.212001
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert isinstance(HPUXNetworkCollector(), HPUXNetworkCollector)



# Generated at 2022-06-24 22:53:47.518596
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # print(test_case_0.__doc__)
    test_case_0()


# Generated at 2022-06-24 22:53:54.974735
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = HPUXNetwork(h_p_u_x_network_collector_0)
    # test case 0

# Generated at 2022-06-24 22:54:04.558061
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = h_p_u_x_network_collector_0.populate()
    assert len(h_p_u_x_network_0) == 3
    assert h_p_u_x_network_0['default_interface'] == 'lan3'
    assert h_p_u_x_network_0['default_gateway'] == '10.0.2.2'
    assert h_p_u_x_network_0['interfaces'] == ['lan3']
    assert h_p_u_x_network_0['lan3']['device'] == 'lan3'

# Generated at 2022-06-24 22:54:12.142459
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()

# Generated at 2022-06-24 22:54:13.519277
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()


# Generated at 2022-06-24 22:54:16.921901
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    my_hpuxnetwork = HPUXNetwork()

    interfaces = my_hpuxnetwork.get_interfaces_info()
    assert(interfaces.keys() == ['lan0', 'lan2', 'lan1'])
    assert(interfaces['lan2']['ipv4'] == {'address': '10.0.0.11',
                                          'network': '10.0.0.0',
                                          'interface': 'lan2',
                                          'address': '10.0.0.11'})


# Generated at 2022-06-24 22:54:40.918142
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    assert h_p_u_x_network_0.get_default_interfaces() is not None



# Generated at 2022-06-24 22:54:46.118645
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.populate()
    print(var_0)

# Generated at 2022-06-24 22:54:48.021089
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_collector_0.collect()


# Generated at 2022-06-24 22:54:52.765898
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:53.644265
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-24 22:54:58.547076
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    var_1 = h_p_u_x_network_0.get_interfaces_info()
    var_2 = h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:55:00.480348
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork(None)
    h_p_u_x_network_0.populate()

# Generated at 2022-06-24 22:55:03.284763
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:55:09.422451
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = {'en1': {'ipv4': {'address': '192.0.2.1',
                              'network': '192.0.2.0',
                              'interface': 'en1'}}}
    assert h_p_u_x_network_0.populate(var_0) == {'interfaces': ['en1'], 'en1': {'ipv4': {'address': '192.0.2.1',
                                                                                          'network': '192.0.2.0',
                                                                                          'interface': 'en1'}}}

# Generated at 2022-06-24 22:55:13.746260
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    print('Unit test for constructor of class HPUXNetwork')
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    test_case_0()


# Generated at 2022-06-24 22:56:08.331328
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    print('test_get_interfaces_info')
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:11.169803
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_1 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:56:12.929929
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork()
    print(h_p_u_x_network_0)

# Generated at 2022-06-24 22:56:15.752661
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bool_0 = True
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bool_0)
    assert isinstance(h_p_u_x_network_collector_0, HPUXNetworkCollector) == True


# Generated at 2022-06-24 22:56:21.306685
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = True
    bool_1 = bool_0 is True
    assert bool_1

    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    assert isinstance(h_p_u_x_network_0, HPUXNetwork)



# Generated at 2022-06-24 22:56:27.062774
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:31.584285
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:34.188720
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    bool_0 = None
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    assert isinstance(h_p_u_x_network_0, HPUXNetwork)


# Generated at 2022-06-24 22:56:36.989054
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
#     assert var_0 == {}


# Generated at 2022-06-24 22:56:39.648368
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_collector_0._fact_class()
    assert h_p_u_x_network_collector_0._platform == 'HP-UX'

# Generated at 2022-06-24 22:58:42.158745
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_case_0()

# Generated at 2022-06-24 22:58:44.753902
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)


# Generated at 2022-06-24 22:58:53.543580
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    bool_0 = False
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    h_p_u_x_network_0.get_default_interfaces = MagicMock(return_value = 'default_interfaces_facts')
    h_p_u_x_network_0.get_interfaces_info = MagicMock(return_value = 'interfaces')
    h_p_u_x_network_0.get_default_interfaces.assert_called_with()
    h_p_u_x_network_0.get_interfaces_info.assert_called_with()
    return 'Success'


# Generated at 2022-06-24 22:58:56.428588
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    bool_0 = True
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(bool_0)

# Generated at 2022-06-24 22:58:59.632084
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:59:02.425797
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:59:06.145273
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:59:13.589299
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    bool_0 = True
    h_p_u_x_network_0 = HPUXNetwork(bool_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == {'default_interface': 'lan0', 'default_gateway': '172.16.1.1'}, 'Return Value does not match'


# Generated at 2022-06-24 22:59:19.111572
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # We are assuming that we are on HP-UX.
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    print(type(h_p_u_x_network_collector_0))


# Generated at 2022-06-24 22:59:24.847602
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

# vim: set et ts=4 sw=4 :