

# Generated at 2022-06-24 22:50:40.445640
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    default_interfaces_facts = {'default_interface': 'lan0', 'default_gateway': '10.15.204.254'}
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_collector_0.module.run_command = Mock(side_effect=[(0, "", ""), (0, "", ""),
                                                                       (0, "", ""), (0, "", ""),
                                                                       (0, "", ""), (0, "", "")])
    h_p_u_x_network_collector_0.module.get_bin_path = Mock(return_value="/usr/bin/netstat")

# Generated at 2022-06-24 22:50:46.059798
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_default_interfaces() == ({'default_interface': 'lan0',
                                                          'default_gateway': '172.17.0.1'})



# Generated at 2022-06-24 22:50:49.826443
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:50:51.533778
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:50:56.606038
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector = HPUXNetworkCollector()
    print("test_HPUXNetworkCollector: " +
          str(h_p_u_x_network_collector._platform))
    assert h_p_u_x_network_collector._platform == 'HP-UX'
    assert h_p_u_x_network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-24 22:51:03.849205
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module = ''
    h_p_u_x_network_0.module.run_command = ''
    h_p_u_x_network_0.module.run_command.return_value = '1', '2', '3'
    assert h_p_u_x_network_0.get_interfaces_info() is not None


# Generated at 2022-06-24 22:51:12.565497
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    out = """Kernel Interface table
lan0      internet hxge0      1500   <Link>
lan1      internet hxge1      1500   <Link>
lan2      internet hxge2      1500   <Link>
lan3      internet hxge3      1500   <Link>"""

# Generated at 2022-06-24 22:51:16.874229
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork(dict())
    assert h_p_u_x_network_0.get_default_interfaces() == {'default_gateway': '0.0.0.0', 'default_interface': 'lan2'}


# Generated at 2022-06-24 22:51:19.972860
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    h_p_u_x_network_0 = HPUXNetwork()
    collected_facts = {}
    h_p_u_x_network_0.populate(collected_facts)


# Generated at 2022-06-24 22:51:22.196343
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()



# Generated at 2022-06-24 22:51:32.105276
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:51:39.468287
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()
    h_p_u_x_network_0 = HPUXNetwork()
    assert h_p_u_x_network_0.get_interfaces_info() == \
        h_p_u_x_network_collector_0._network_instances[h_p_u_x_network_0]

# Generated at 2022-06-24 22:51:44.008187
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork(module=None)
    interfaces = h_p_u_x_network_0.get_interfaces_info()
    assert('lan0' in interfaces)
    assert('lan0' in interfaces['lan0'])
    assert('address' in interfaces['lan0']['lan0'])


# Generated at 2022-06-24 22:51:45.377008
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:51:51.421544
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.module.run_command = mock_ansible_module_run_command(stdout_values=['netstat -niw'])

    # test
    interfaces = h_p_u_x_network_0.get_interfaces_info()
    assert interfaces == {'lan0': {'ipv4': {'network': '172.17.1.0',
                                            'interface': 'lan0',
                                            'address': '172.17.1.1'},
                                   'device': 'lan0'}}


# Generated at 2022-06-24 22:51:53.203720
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert h_p_u_x_network_collector_0.__init__() is not None


# Generated at 2022-06-24 22:51:57.697502
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network.module = set()

    h_p_u_x_network.module.run_command = lambda *args, **kwargs: (0, '', '')
    h_p_u_x_network.get_interfaces_info()


# Generated at 2022-06-24 22:52:00.009339
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:52:03.716558
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    h_p_u_x_network_0.get_default_interfaces()



# Generated at 2022-06-24 22:52:14.170836
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h_p_u_x_network_0 = HPUXNetwork()

    with open('/tmp/ansible_facts/netstat_cmd_file', 'rb') as f:
        buf = f.read()

    h_p_u_x_network_0.module.run_command = mock.Mock(return_value=(0, buf, ''))
    h_p_u_x_network_0.get_default_interfaces = mock.Mock(return_value={'default_interface': 'lan0', 'default_gateway': '192.168.1.0'})

# Generated at 2022-06-24 22:52:28.590631
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    h_p_u_x_network_0 = HPUXNetwork()

    collected_facts = HPUXNetwork.populate(h_p_u_x_network_0)
    h_p_u_x_network_0.get_default_interfaces()

# Generated at 2022-06-24 22:52:30.416761
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass
#     h_p_u_x_network_collector_1 = HPUXNetworkCollector()


# Generated at 2022-06-24 22:52:34.227499
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces = h_p_u_x_network_0.get_default_interfaces()
    print(default_interfaces)
    assert default_interfaces == {"default_interface": "lan0", "default_gateway": "10.1.1.1"}


# Generated at 2022-06-24 22:52:40.777388
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    result = h_p_u_x_network_0.get_interfaces_info()
    assert type(result) == dict
    assert 'default_interface' in result
    assert 'default_gateway' in result
    assert 'interfaces' in result
    assert 'lan0' in result

# Generated at 2022-06-24 22:52:43.317103
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_case = HPUXNetworkCollector()
    assert test_case._platform == 'HP-UX'
    assert test_case._fact_class == HPUXNetwork


# Generated at 2022-06-24 22:52:47.599199
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network_0 = HPUXNetwork()
    result = h_p_u_x_network_0.get_interfaces_info()
    assert result == {'lan0': {'ipv4': {'address': '10.194.205.222',
                                        'interface': 'lan0',
                                        'network': '10.194.192.0'},
                              'device': 'lan0'}}


# Generated at 2022-06-24 22:52:49.991136
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h_p_u_x_network = HPUXNetwork()
    h_p_u_x_network.get_interfaces_info()


# Generated at 2022-06-24 22:52:53.279516
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork()


# Generated at 2022-06-24 22:52:57.854476
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork()
    default_interfaces = h_p_u_x_network_0.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan2'
    assert default_interfaces['default_gateway'] == '172.16.132.1'


# Generated at 2022-06-24 22:53:02.390808
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    import pytest
    h_p_u_x_network_collector_1 = HPUXNetworkCollector()
    assert h_p_u_x_network_collector_1 is not None


# Generated at 2022-06-24 22:53:18.988006
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Initialize object
    float_0 = -1976.8073
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(h_p_u_x_network_0)


if __name__ == '__main__':
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:53:23.980702
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    float_0 = -1976.8073
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:53:27.056808
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h_p_u_x_network_collector_0 = HPUXNetworkCollector()

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetworkCollector()

# Generated at 2022-06-24 22:53:31.676433
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    float_0 = -1978.3528
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:53:36.947448
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
  float_0 = -818.0
  h_p_u_x_network_0 = HPUXNetwork(float_0)
  decimal_0 = decimal.Decimal('0.0')
  # parameters for HPUXNetwork.populate
  var_0 = None
  # parameter var_0
  var_0 = None
  h_p_u_x_network_0.populate(var_0)


# Generated at 2022-06-24 22:53:37.871108
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 22:53:43.604001
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    This test exercises the populate method
    """
    # Test setup
    float_0 = -763.475
    h_p_u_x_network_0 = HPUXNetwork(float_0)

    # Test the populate method
    result = h_p_u_x_network_0.populate()

    # Test that we have the expected results
    assert result['default_interface'] != None
    assert result['interfaces'] != None
    assert result['lan0'] != None



# Generated at 2022-06-24 22:53:46.572150
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    float_0 = -405.6
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 is not None


# Generated at 2022-06-24 22:53:49.456673
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    float_0 = -1976.3037
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_1 = h_p_u_x_network_0.populate(None)
    var_2 = h_p_u_x_network_0.populate()


# Generated at 2022-06-24 22:53:56.086212
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    float_0 = -539.1188
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    assert type(h_p_u_x_network_0).__name__ == 'HPUXNetwork'
    assert h_p_u_x_network_0.platform == 'HP-UX'
    assert h_p_u_x_network_0.module is float_0
    h_p_u_x_network_0 = HPUXNetwork(-3919.878)
    h_p_u_x_network_0.populate()
    h_p_u_x_network_0 = HPUXNetwork(-1674.63)
    var_0 = h_p_u_x_network_0.get_default_interfaces()

# Unit test

# Generated at 2022-06-24 22:54:20.557074
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    float_0 = 3936.3787
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:54:23.630504
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    float_1 = -1949.7946
    h_p_u_x_network_0 = HPUXNetwork(float_1)
    h_p_u_x_network_1 = HPUXNetwork(float_1)


# Generated at 2022-06-24 22:54:31.544179
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Default case with default argument
    h_p_u_x_network_0 = HPUXNetwork(-1.8692937e+24)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 == {'interfaces': [], 'default_interface': 'lan0', 'default_gateway': '172.28.23.254', 'lan0': {'ipv4': {'network': '172.28.23.0', 'interface': 'lan0', 'address': '172.28.23.254'}}}


# Generated at 2022-06-24 22:54:36.305577
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    float_0 = -1311.3113
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    h_p_u_x_network_0.get_interfaces_info()
######


#####

# Generated at 2022-06-24 22:54:40.864914
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    float_0 = -1976.8073
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    assert h_p_u_x_network_0.populate() is None


# Generated at 2022-06-24 22:54:47.344634
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    float_0 = -1428.1626
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 == {}

if __name__ == '__main__':
    test_case_0()
    test_HPUXNetwork_populate()

# Generated at 2022-06-24 22:54:52.092992
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    float_0 = -0.05
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:55:01.076025
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_p_u_x_network_0 = HPUXNetwork(float())
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert h_p_u_x_network_0.platform == 'HP-UX'
    assert h_p_u_x_network_0._platform == 'HP-UX'
    assert isinstance(h_p_u_x_network_0._fact_class, HPUXNetwork)
    assert isinstance(h_p_u_x_network_0._platform, str)
    assert isinstance(h_p_u_x_network_0.interfaces, list)
    assert isinstance(h_p_u_x_network_0.ipv4, dict)

# Generated at 2022-06-24 22:55:03.073196
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    float_0 = -1976.8073
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:55:10.047986
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    float_0 = -1166.47961665396
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:09.673423
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    float_0 = -543.02084
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(float_0)


if __name__ == '__main__':
    test_HPUXNetworkCollector()
    test_case_0()
    float_0 = -638.82923
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    print(var_0)

# Generated at 2022-06-24 22:56:11.460935
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    float_0 = 2975.6474
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(float_0)


# Generated at 2022-06-24 22:56:13.731893
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    float_0 = -1976.8073
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:56:16.666627
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    float_0 = -0.1504
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0 is None


# Generated at 2022-06-24 22:56:23.112041
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    float_0 = -1976.8073
    h_p_u_x_network_collector_0 = HPUXNetworkCollector(float_0)
    var_1 = h_p_u_x_network_collector_0.platform
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_2 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:56:25.047365
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    float_0 = -1965.23
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    assert h_p_u_x_network_0.platform == 'HP-UX'


# Generated at 2022-06-24 22:56:29.985936
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    float_0 = -1976.8073
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.populate()
    var_1 = h_p_u_x_network_0.get_default_interfaces()
    var_2 = h_p_u_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:56:37.560757
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # No network devices found
    float_0 = -1976.8073
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert var_0 == {}

    # A single network device found
    float_0 = -1976.8073
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:56:40.189835
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    float_0 = -812.805
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:56:44.564130
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    float_0 = -1277.4788
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_interfaces_info()
    assert isinstance(var_0, dict)



# Generated at 2022-06-24 22:58:58.347474
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    float_0 = -971.9501
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.populate()
    assert var_0 == {}

# Generated at 2022-06-24 22:59:03.525543
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    assert 0


# Generated at 2022-06-24 22:59:07.216774
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    float_0 = 9.41
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    assert h_p_u_x_network_0.module.get_bin_path('netstat') != None


# Generated at 2022-06-24 22:59:13.432254
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork(floati)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == {
        "default_interface": "lan1",
        "default_gateway": "192.168.0.1"
    }



# Generated at 2022-06-24 22:59:19.338729
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    float_0 = -1994.2898
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:59:25.266691
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h_p_u_x_network_0 = HPUXNetwork(True)
    assert h_p_u_x_network_0.get_default_interfaces() is None


# Generated at 2022-06-24 22:59:30.674258
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    float_0 = -9.807863268733
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert type(var_0) == dict



# Generated at 2022-06-24 22:59:36.672601
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    float_0 = -0.05
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    var_0 = h_p_u_x_network_0.get_default_interfaces()
    assert var_0 == {'default_gateway': '192.168.1.1', 'default_interface': 'lan0'}


# Generated at 2022-06-24 22:59:41.613374
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    float_0 = -832.717
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    assert h_p_u_x_network_0.get_interfaces_info() is not None
    test_HPUXNetwork_get_interfaces_info()


# Generated at 2022-06-24 22:59:48.946165
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    float_0 = -1976.8073
    h_p_u_x_network_0 = HPUXNetwork(float_0)
    h_p_u_x_network_0.get_interfaces_info()
    h_p_u_x_network_0.populate()
    h_p_u_x_network_0.get_default_interfaces()
