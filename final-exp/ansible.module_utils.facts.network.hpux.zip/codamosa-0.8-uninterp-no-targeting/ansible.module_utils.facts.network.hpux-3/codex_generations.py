

# Generated at 2022-06-20 18:09:45.215737
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class Module:
        def __init__(self):
            self.run_command_results = [
                (0, 'default 10.10.10.1 UG lan1', ''),
            ]

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    module = Module()
    default_interfaces_facts = HPUXNetwork(module).get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan1'
    assert default_interfaces_facts['default_gateway'] == '10.10.10.1'



# Generated at 2022-06-20 18:09:47.428270
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-20 18:09:51.379003
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network = HPUXNetwork(module)
    assert network.default_interface is not None
    assert network.default_gateway is not None
    assert network.interfaces is not None

# Generated at 2022-06-20 18:09:53.422065
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    nm = HPUXNetwork(None)
    assert nm.__class__.__name__ == 'HPUXNetwork'

# Generated at 2022-06-20 18:10:00.824428
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    m = HPUXNetwork()
    m.module = DummyModule({})
    ifaces = m.get_interfaces_info()
    assert ifaces['lan0'] == {'device': 'lan0',
                              'ipv4': {'address': '192.168.2.2',
                                       'network': '192.168.2.0',
                                       'address': '192.168.2.2',
                                       'interface': 'lan0'}}



# Generated at 2022-06-20 18:10:02.637186
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_collector = HPUXNetworkCollector()
    assert net_collector is not None

# Generated at 2022-06-20 18:10:14.695465
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    import platform
    if platform.system() != HPUXNetwork._platform:
        return
    facts = dict(default_gateway='192.168.1.1', default_interface='lo0')
    expected_facts = dict(default_gateway='192.168.1.1', default_interface='lo0',
                          interfaces=['lo0'])
    interface_facts = dict(device='lo0', ipv4=dict(address='127.0.0.1',
                                                   netmask='255.0.0.0'))
    expected_facts.update({'lo0': interface_facts})

    network = HPUXNetwork()
    network._populate_from_netstat = lambda: facts
    actual_facts = network.populate()

    assert actual_facts == expected_facts

# Generated at 2022-06-20 18:10:16.655454
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu = HPUXNetwork()
    assert hpu.platform == 'HP-UX'

# Generated at 2022-06-20 18:10:24.544537
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    out = '''
default         192.168.1.1          UG         0 0          lan0
'''
    net = HPUXNetwork()
    net.module = MockModule()
    net.module.run_command.return_value = (0, out, '')
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'

# Generated at 2022-06-20 18:10:29.561283
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    network.populate()
    assert network.facts['default_interface'] is not None
    assert network.facts['default_gateway'] is not None
    assert len(network.facts['interfaces']) > 0

# Generated at 2022-06-20 18:10:40.110040
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector.platform == 'HP-UX', 'Wrong platform'
    assert hpux_network_collector._fact_class == HPUXNetwork, 'Wrong _fact_class'

# Generated at 2022-06-20 18:10:45.069047
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    net = HPUXNetwork(module=module)
    default_interfaces_facts = net.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '10.11.12.1'



# Generated at 2022-06-20 18:10:47.031823
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork._get_interfaces_info()
    assert interfaces

# Generated at 2022-06-20 18:10:57.804904
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    output = """
    lan0: flags=4<UP,BROADCAST,RUNNING,MULTICAST>    inet 10.168.0.24 netmask ffffff00 broadcast 10.168.0.255
    lan1: flags=4<UP,BROADCAST,RUNNING,MULTICAST>    inet 0.0.0.0 netmask ff000000 broadcast 127.255.255.255
    """
    interfaces = {}
    lines = output.splitlines()
    for line in lines:
        words = line.split()
        for i in range(len(words) - 1):
            if words[i][:3] == 'lan':
                device = words[i]
                interfaces[device] = {'device': device}
                address = words[i + 3]
                network = words[i + 2]

# Generated at 2022-06-20 18:11:03.150490
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Unit test for constructor of class HPUXNetworkCollector
    """
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert isinstance(collector.facts, HPUXNetwork)


# Generated at 2022-06-20 18:11:10.259554
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Create an instance of a module
    module = AnsibleModule(argument_spec={})

    # Create an instance of a class for which we are going to run the populate
    # method
    network = HPUXNetwork(module)

    # Create the list of dictionaries returned by the method run_command
    # when calling the command /usr/bin/netstat -niw

# Generated at 2022-06-20 18:11:12.366007
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    '''
    Test the HPUXNetwork() constructor
    '''
    try:
        HPUXNetwork()
    except Exception as e:
        raise AssertionError("Could not initialize class Network"
                             ": %s" % e.message)

# Generated at 2022-06-20 18:11:16.223533
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    m = AnsibleModule()
    n = HPUXNetwork(m)

    interfaces = n.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-20 18:11:28.558370
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    network = HPUXNetwork(module=module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan1'
    assert network_facts['default_gateway'] == '10.20.210.254'
    assert network_facts['interfaces'] == ['lan0', 'lan1', 'lan2', 'lo0']
    assert network_facts['lan0']['ipv4']['address'] == '192.168.0.10'
    assert network_facts['lan1']['ipv4']['address'] == '10.20.210.10'
    assert network_facts['lan2']['ipv4']['address'] == '192.168.100.10'

# Generated at 2022-06-20 18:11:33.173024
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = NetworkCollector(module=module)
    network_object = network_collector.get_network_object()
    assert network_object is not None

# Generated at 2022-06-20 18:11:45.965178
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module.run_command = run_command
    network.module._socket_path = ''

    netstat_path = network.module.get_bin_path('netstat')

    if netstat_path is None:
        return

    expected = {'default_interface': 'lan0',
                'default_gateway': '10.0.2.2'}

    result = network.get_default_interfaces()
    assert result == expected



# Generated at 2022-06-20 18:11:56.195541
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    def mock_run_command(cmd):
        return (0, 'default  10.20.30.40   lan0               UG  3 17228 0 lan0', None)

    network = HPUXNetwork()
    network.module = Mock_Module()
    network.module.run_command = mock_run_command
    
    facts = network.populate()

    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.20.30.40'
    return True



# Generated at 2022-06-20 18:12:09.468326
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockModule()
    mod_path = '/usr/bin/netstat'

# Generated at 2022-06-20 18:12:19.585908
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    import sys
    import os
    # change directory to test dir
    script_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.dirname(os.path.dirname(script_dir))
    sys.path.append(test_dir)
    from test_data.module_utils.facts.network.fixtures.test_hpu_network_interfaces import test_data_netstat_files
    from ansible.module_utils.facts.network.hpu_network import HPUXNetwork
    from ansible.module_utils.facts.facts.network.facts.network import Network

    # create an object with 'out' of command netstat -niw,
    # and 'out2' of command netstat -nr
    test_obj = HPUXNetwork()


# Generated at 2022-06-20 18:12:23.417547
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpuxnetwork = HPUXNetwork(module)

    assert hpuxnetwork is not None

# Generated at 2022-06-20 18:12:30.014803
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpux_network = HPUXNetwork()
    interfaces = hpux_network.get_interfaces_info()
    assert 'lan0' in interfaces.keys()
    assert 'lan1000' not in interfaces.keys()
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['lan0']['address'] == '192.168.127.5'
    assert interfaces['lan0']['lan0']['network'] == '192.168.127'

# Generated at 2022-06-20 18:12:35.936982
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # --- Mock module
    class MockModule(object):
        def __init__(self):
            self.run_command_results = {}
        def run_command(self, cmd):
            rc, out, err = self.run_command_results[cmd]
            return rc, out, err
        def get_bin_path(self, binary):
            return ''
    # ---
    module = MockModule()
    module.run_command_results['/usr/bin/netstat -nr'] = (0, 'default 192.168.0.1 UG lo0\n', 'no error')
    network = HPUXNetwork()
    network.module = module
    #
    result = network.get_default_interfaces()
    assert result.get('default_interface') == 'lo0'

# Generated at 2022-06-20 18:12:39.216902
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork(dict())
    assert net.__class__.__name__ == 'HPUXNetwork'


# Generated at 2022-06-20 18:12:49.953629
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Test to ensure that the HPUXNetwork populate method works
    # properly on a HP-UX system with
    # eth0, eth1 devices and one default gateway
    # Logging does not appear to work on the Ubuntu Server
    # VM for pytest
    print("HP-UX: test_HPUXNetwork_populate")

    import os
    import tempfile
    test_filename = os.path.join(tempfile.mkdtemp(), "test_netstat.out")
    print("HP-UX: test_HPUXNetwork_populate: test_filename " + test_filename)

# Generated at 2022-06-20 18:12:53.884771
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    '''
    Unit test for constructor of class HPUXNetwork
    '''
    hpux_network = HPUXNetwork(None)
    assert hpux_network

# Generated at 2022-06-20 18:13:07.702702
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_facts = HPUXNetwork(module)
    network_facts.populate()
    assert network_facts.facts['default_interface'] == 'lan0'


# Generated at 2022-06-20 18:13:12.546157
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class is HPUXNetwork
    assert obj._platform == 'HP-UX'



# Generated at 2022-06-20 18:13:18.763467
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    This unit test checks the output of the method populate of class HPUXNetwork.
    """
    module = FakeOsModule()
    fact_class = HPUXNetwork(module)

    network_facts = fact_class.populate()
    assert network_facts == {'interface_en0': {'ipv4': {'address': '10.0.2.15',
                                                         'network': '10.0.2.0',
                                                         'interface': 'en0'}},
                             'interfaces': ['en0'],
                             'default_interface': 'lan0',
                             'default_gateway': '10.0.2.2'}


# Generated at 2022-06-20 18:13:29.532074
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Mock module
    class module_mock():
        def run_command(self, cmd):
            if cmd == "/usr/bin/netstat -nr":
                rc = 0
                out = "default 10.7.12.254 UGSc 0 0 lan1"
                err = None
            return rc, out, err

    test_module = module_mock()

    # Instantiate class
    test_facts = HPUXNetwork(test_module)
    test_facts.populate()

    default_facts = {'default_interface': 'lan1',
                     'default_gateway': '10.7.12.254'}

    assert test_facts._facts == default_facts
    assert test_facts.get_default_interfaces() == default_facts



# Generated at 2022-06-20 18:13:39.483329
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""

    HPUXNetwork_object = HPUXNetwork(None)
    """ A sample output of the command netstat -niw
    lan0  lan0  239.192.123.255  239.192.123.0  UP
    lan1  lan1  239.192.124.255  239.192.124.0  UP
    """
    interfaces = HPUXNetwork_object.get_interfaces_info()
    for device in interfaces:
        print('Device: ', device)
        for key in interfaces[device]:
            print('key: ', key)
            for key2 in interfaces[device][key]:
                print('key2: ', key2)
                print('Value: ', interfaces[device][key][key2])


# Generated at 2022-06-20 18:13:46.605016
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Create an instance of class HPUXNetwork
    hpuxnet = HPUXNetwork({})
    # Populate the facts
    hpuxnet.populate()
    # Assert that 'default_interface' fact is populated
    assert hpuxnet.facts['default_interface'] is not None
    # Assert that 'default_gateway' fact is populated
    assert hpuxnet.facts['default_gateway'] is not None
    # Assert that 'interfaces' fact is populated
    assert hpuxnet.facts['interfaces'] is not None



# Generated at 2022-06-20 18:13:50.982563
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule({})
    hpnnetwork = HPUXNetwork(module)
    hpnnetwork.module.run_command = run_command
    default_interfaces = hpnnetwork.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.75.64.1'



# Generated at 2022-06-20 18:13:53.849038
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    y = HPUXNetwork({'ansible_facts': {}})
    assert y is not None



# Generated at 2022-06-20 18:13:55.597251
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc.fact_class == HPUXNetwork
    assert nc.platform == 'HP-UX'

# Generated at 2022-06-20 18:13:58.538443
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(None)
    assert network.platform == 'HP-UX'


# Generated at 2022-06-20 18:14:10.389496
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:14:13.111316
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert isinstance(hn, HPUXNetworkCollector)


# Generated at 2022-06-20 18:14:15.489220
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector"""
    network_collector = HPUXNetworkCollector()
    assert network_collector.__class__.__name__ == 'HPUXNetworkCollector'


# Generated at 2022-06-20 18:14:19.052034
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-20 18:14:22.563438
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(dict())
    assert network
    assert network.platform == 'HP-UX'
    assert network.get_default_interfaces() == {}



# Generated at 2022-06-20 18:14:25.729344
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'
    assert network.default_interface == 'lan0'

# Unit tests for get_default_interface() of class HPUXNetwork

# Generated at 2022-06-20 18:14:26.500590
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-20 18:14:37.689695
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import ansible.module_utils.facts.network.hpux
    # make a fake module that'll be subsequently used by get_default_interfaces
    module = ansible.module_utils.facts.network.hpux.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        check_invalid_arguments=True,
        bypass_checks=True
    )

    # test against a real input
    real_out = """netstat: no IP address has been configured on this host.
Failed to obtain interface information
"""  # noqa
    real_out_lines = real_out.splitlines()
    setattr(module, 'run_command',
            lambda x: (0, real_out, ''))
    hpux_network = HPUXNetwork()

# Generated at 2022-06-20 18:14:48.459304
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:14:55.261551
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    default_interfaces_facts = network.get_default_interfaces()

    default_iface = default_interfaces_facts['default_interface']
    assert default_iface == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '150.216.99.1'



# Generated at 2022-06-20 18:15:07.492441
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-20 18:15:17.577209
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    hpuxnetwork = HPUXNetwork(module)
    hpuxnetwork.populate()

    assert hpuxnetwork.facts['default_interface'] == 'lan1'
    assert hpuxnetwork.facts['default_gateway'] == '172.24.1.1'
    expected_interfaces = ('lan1',)
    assert hpuxnetwork.facts['interfaces'] == expected_interfaces
    interfaces = hpuxnetwork.facts['lan1']
    assert interfaces['device'] == 'lan1'
    address = interfaces['ipv4']
    assert address['address'] == '172.25.1.1'
    assert address['network'] == '172.25'


# Generated at 2022-06-20 18:15:18.553601
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-20 18:15:25.619272
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.base import Network
    n = Network()
    n.module = MockModule()

# Generated at 2022-06-20 18:15:38.465967
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = DummyAnsibleModule()
    module.run_command = Mock(return_value=(0, "", ""))

    default_interfaces_facts = {'default_interface': 'lan0',
                                'default_gateway': '10.0.0.1'}
    interfaces = {'lan0': {'ipv4': {'address': '10.0.0.100',
                                    'network': '10.0.0.0',
                                    'interface': 'lan0'}}}

    instance = HPUXNetwork(module)
    instance.get_default_interfaces = Mock(return_value=default_interfaces_facts)
    instance.get_interfaces_info = Mock(return_value=interfaces)

    result = instance.populate()


# Generated at 2022-06-20 18:15:50.267419
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class TestModule(object):
        """Fake module to replace AnsibleModule"""
        def __init__(self):
            self.params = {}
        def run_command(self, cmd):
            test_cmd = 'netstat -niw'
            if cmd == test_cmd:
                rc = 0
                out = 'lan0 lan0     internet     0x2000052415a8b9e9    0x0 0x0 0x0 0x0 0x0 0x0 0x0 0x0\nlan0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND>'
                err = ''
                return rc, out, err


# Generated at 2022-06-20 18:15:53.070788
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector()
    assert hpux._platform == 'HP-UX'



# Generated at 2022-06-20 18:15:57.048875
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    class HPUXModuleTest:
        """Simulate AnsibleModule."""
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            return {'failed': True, 'msg': "test_fail_json was called"}

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/netstat'

        def run_command(self, *args, **kwargs):
            return 0, "netstat output", "stderr"

    params = {'gather_subset': ['network']}
    module = HPUXModuleTest(params)

    # create the object that will be used to generate facts
    netobj = HPUXNetwork(module)
    network_facts = netobj.populate()


# Generated at 2022-06-20 18:15:59.231333
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork.platform == 'HP-UX'


# Generated at 2022-06-20 18:16:07.656154
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={
        },
    )

    network_module = HPUXNetwork(module)
    assert network_module.get_default_interfaces() == {'default_gateway': '172.31.5.1', 'default_interface': 'lan2'}



# Generated at 2022-06-20 18:16:45.249772
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Test for constructor of class HPUXNetwork.
    """
    network_collector = HPUXNetworkCollector()
    assert isinstance(network_collector, HPUXNetworkCollector)
    assert network_collector.platform == 'HP-UX'
    assert network_collector._platform == 'HP-UX'
    assert isinstance(network_collector._fact_class, HPUXNetwork)

# Generated at 2022-06-20 18:16:48.157789
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-20 18:16:49.695637
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpx = HPUXNetwork()
    assert hpx.platform == 'HP-UX'
    assert isinstance(hpx, Network)

# Generated at 2022-06-20 18:16:58.599985
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpx_net = HPUXNetwork()
    netstat_path = hpx_net.module.get_bin_path('netstat')
    if netstat_path is None:
        hpx_net.module.fail_json(msg="'netstat' command not found")
    rc, out, err = hpx_net.module.run_command("/usr/bin/netstat -niw")
    interfaces = hpx_net.get_interfaces_info()
    for iface in interfaces:
        assert interfaces[iface]['device'] == iface



# Generated at 2022-06-20 18:17:07.645856
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    wifi_hpux = HPUXNetwork()
    interfaces = wifi_hpux.get_interfaces_info()
    assert interfaces['lan0'] == {'ipv4': {'interface': 'lan0',
                                           'network': '7.0.0.0',
                                           'address': '7.250.116.138'},
                                  'device': 'lan0'}



# Generated at 2022-06-20 18:17:14.726186
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=True)
    hn = HPUXNetwork(module)

    netstat_path = module.get_bin_path('netstat')
    module.get_bin_path = MagicMock(return_value=netstat_path)
    module.run_command = MagicMock(return_value=(0, "", ""))

    network_facts = hn.populate()

    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts
    assert 'ipv4' in network_facts['lan1']



# Generated at 2022-06-20 18:17:16.334910
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-20 18:17:21.793396
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    network_collector = HPUXNetworkCollector(module=module)
    network_collector._find_bin_path = AnsibleModuleMock().find_bin_path
    network_collector._gather_platform_facts = AnsibleModuleMock().facts
    network_collector._get_default_interfaces = AnsibleModuleMock().get_default_interfaces
    network_collector._get_interfaces_info = AnsibleModuleMock().get_interfaces_info

    facts = network_collector.collect()

    assert 'default_interface' in facts

# Generated at 2022-06-20 18:17:30.892194
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    result_expected = {'lan0': {'ipv4': {'address': '129.156.178.47',
                                         'network': '129.156.178.0',
                                         'interface': 'lan0',
                                         'broadcast': '129.156.178.47',
                                         'netmask': '255.255.255.255',
                                         'macaddress': '0:14:4f:18:43:87'},
                                 'device': 'lan0',
                                 'macaddress': '0:14:4f:18:43:87'}}
    test = HPUXNetwork()
    interfaces = test.get_interfaces_info()
    assert interfaces == result_expected


# Generated at 2022-06-20 18:17:41.045779
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    ansibleModule = AnsibleModule(supports_check_mode=True)
    ansibleModule.run_command = MagicMock(return_value=(0, '', ''))
    network_facts_instance = HPUXNetwork(ansibleModule=ansibleModule)
    network_facts_instance.get_default_interfaces = MagicMock(return_value='default_interface')
    network_facts_instance.get_interfaces_info = MagicMock(return_value='interface')

    network_facts = network_facts_instance.populate()
    assert network_facts['default_interface'] == 'default_interface'
    assert network_facts['default_gateway'] == 'default_interface'
    assert network_facts['interfaces'] == 'interface'

# Generated at 2022-06-20 18:18:31.182802
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    netobj = HPUXNetwork()
    facts = netobj.populate({})
    assert set(facts.keys()) == set(['default_interface', 'default_gateway', 'ansible_eth0', 'interfaces'])
    assert facts['interfaces'] == ['lan0']
    assert facts['ansible_eth0']['ipv4']['address'] == '10.0.0.1'
    assert facts['ansible_eth0']['ipv4']['network'] == '10.0.0.0'

# Generated at 2022-06-20 18:18:35.399950
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hn = HPUXNetwork()
    hn.module.run_command = MagicMock(return_value=(1, 'default 172.31.128.1 UG lan0', ''))
    assert hn.get_default_interfaces(hn) == {'default_interface': 'lan0', 'default_gateway': '172.31.128.1'}


# Generated at 2022-06-20 18:18:44.204466
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.run_command = Mock(return_value=(0, "", ""))

# Generated at 2022-06-20 18:18:48.016430
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:18:55.896336
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_merge
    module = MockModule()
    net = HPUXNetwork(module)
    interfaces = net.get_interfaces_info()
    default_interfaces_facts = net.get_default_interfaces()
    network_facts = net.populate()

# Generated at 2022-06-20 18:18:59.775862
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn_collector = HPUXNetworkCollector()
    assert hn_collector.platform == 'HP-UX'
    assert hn_collector._fact_class == HPUXNetwork
    assert hn_collector._fact_class.platform == 'HP-UX'


# Generated at 2022-06-20 18:19:01.077024
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj1 = HPUXNetworkCollector()

# Generated at 2022-06-20 18:19:10.714972
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    test_module.run_command = MagicMock(return_value=(0,
                                                      'default 0.0.0.0/0 10.1.2.3',
                                                      ''))

    network_facts = HPUXNetwork()
    default_interfaces = network_facts.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan1'
    assert default_interfaces['default_gateway'] == '10.1.2.3'



# Generated at 2022-06-20 18:19:12.996641
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()



# Generated at 2022-06-20 18:19:20.684991
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/usr/bin/netstat'
    iface_obj = HPUXNetwork(module)
    res = iface_obj.populate()
    assert 'default_interface' in res
    assert 'default_gateway' in res
    assert 'interfaces' in res