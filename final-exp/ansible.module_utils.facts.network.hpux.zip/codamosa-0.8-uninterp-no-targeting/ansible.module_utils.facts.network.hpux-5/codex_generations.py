

# Generated at 2022-06-20 18:09:43.331957
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = type('module', (object,), {})
    test_module.run_command = lambda arg: (0, '', '')
    test_module.get_bin_path = lambda arg: 'bin'
    test_net = HPUXNetwork(test_module)
    out = test_net.get_default_interfaces()
    assert out == {'default_interface': None, 'default_gateway': None}


# Generated at 2022-06-20 18:09:45.992072
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:09:52.225740
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network = HPUXNetwork(module)
    results = network.get_default_interfaces()
    assert isinstance(results, dict)
    assert len(results.keys()) == 2
    assert results['default_interface'] == 'lan0'
    assert results['default_gateway'] == '10.1.0.1'

# Generated at 2022-06-20 18:09:54.984770
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector.platform == 'HP-UX'
    assert network_collector.fact_class == HPUXNetwork

if __name__ == '__main__':
    test_HPUXNetworkCollector()

# Generated at 2022-06-20 18:09:56.485371
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-20 18:10:00.002169
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    expected_value = HPUXNetwork
    observed_value = HPUXNetworkCollector._fact_class
    assert expected_value == observed_value


# Generated at 2022-06-20 18:10:01.458724
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockAnsibleModule()
    network = HPUXNetwork(module)
    assert network.get_default_interfaces() == {'default_interface': 'lan9', 'default_gateway': '172.23.1.1'} 


# Generated at 2022-06-20 18:10:10.447791
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    net.module = MockModule()
    net.module.run_command = Mock()

# Generated at 2022-06-20 18:10:13.595390
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Initialize an object of class HPUXNetworkCollector
    hn = HPUXNetworkCollector()
    # Check if class attribute _fact_class points to the correct class
    assert (hn._fact_class == HPUXNetwork)

# Generated at 2022-06-20 18:10:25.849853
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import ModuleCollector
    from ansible.module_utils.facts.network.hpuix import HPUXNetwork
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts import get_collector_facts
    from ansible.module_utils.facts.network.base import Network

    class MyModule(object):
        def __init__(self):
            self.run_command_environ_update = None

        def get_bin_path(self, arg, required=False):
            return ""

        def get_module_hashes(self):
            return None

        def run_command(self, *args, **kwargs):
            if args[0] == '/usr/bin/netstat -niw':
                return 0, out

# Generated at 2022-06-20 18:10:36.236450
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module = MockModule()
    net.module.run_command = Mock(return_value=(0, netstat_nr_out, ""))
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces == {'default_gateway': '192.168.75.1',
                                  'default_interface': 'lan0'}



# Generated at 2022-06-20 18:10:43.359191
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """ Unit test for constructor of class HPUXNetworkCollector """
    # Unit test with correct arguments
    facts = dict()
    cond = HPUXNetworkCollector(None, facts)
    assert cond.platform == 'HP-UX'
    assert cond.fact_class == HPUXNetwork
    assert cond.facts == facts
    assert cond.module == None



# Generated at 2022-06-20 18:10:56.331914
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    # Get a valid set of arguments
    options = basic.AnsibleModule(argument_spec={}, supports_check_mode=False,
                                  _ansible_version='2.5.1')
    options.params = {}
    # Create a valid micro fact class
    fact_class = HPUXNetwork(options=options, bypass_cache=False)
    # Create a fact collector
    fact_collector = collector.BaseFactCollector(fact_classes=[fact_class])
    # Create an instance of the fact class within the fact collector
    fact_instance = fact_collector._create_fact_instance(fact_class)
    # Run the get

# Generated at 2022-06-20 18:11:04.235203
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpux_network = HPUXNetwork()
    interfaces = hpux_network.get_interfaces_info()
    if len(interfaces) > 0:
        device = interfaces.keys()[0]
        interface = interfaces[device]
        if 'ipv4' not in interface:
            return False
        if 'address' not in interface['ipv4']:
            return False
        return True
    else:
        return False

# Generated at 2022-06-20 18:11:10.324498
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()

    assert(obj.get_interfaces_info() == obj.interfaces_info)
    assert(obj.get_default_interfaces() == obj.default_interfaces)
    assert(obj.populate() == obj.facts)

# Generated at 2022-06-20 18:11:11.144702
# Unit test for method populate of class HPUXNetwork

# Generated at 2022-06-20 18:11:18.679013
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class_ = HPUXNetwork
    module = FakeModule()
    instance = class_(module)
    interfaces = instance.get_interfaces_info()
    assert interfaces['lan0'] == {
        'ipv4': {'interface': 'lan0', 'network': '10.0.0.0',
                 'address': '10.0.0.100'},
        'device': 'lan0'}
    assert interfaces['lan1'] == {
        'ipv4': {'interface': 'lan1', 'network': '192.168.10.0',
                 'address': '192.168.10.100'},
        'device': 'lan1'}



# Generated at 2022-06-20 18:11:22.943413
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpx = HPUXNetwork()

    network_facts = {}
    netstat_path = hpx.module.get_bin_path('netstat')
    if netstat_path is None:
        network_facts = {}
    else:
        network_facts = hpx.populate()
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert hpx.module.get_bin_path('netstat') is not None
    assert 'interfaces' in network_facts
    assert 'lan0' in network_facts['interfaces']



# Generated at 2022-06-20 18:11:32.020608
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()

    lines = ["default: net 224.0.0.0 netmask ffffff00", "default comlan0: flags=8e<UP,BROADCAST,NOTRAILERS,NOARP,SIMPLEX,LINK0,MULTICAST> <UP,BROADCAST,NOTRAILERS,NOARP,SIMPLEX,LINK0,MULTICAST>", "default 10.10.10.10: flags=8e<UP,BROADCAST,NOTRAILERS,NOARP,SIMPLEX,LINK0,MULTICAST> <UP,BROADCAST,NOTRAILERS,NOARP,SIMPLEX,LINK0,MULTICAST>"]

# Generated at 2022-06-20 18:11:40.746516
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:11:51.825168
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkCollector()
    network_facts = HPUXNetwork(module).populate()

    assert 'interfaces' in network_facts
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts

# Generated at 2022-06-20 18:11:58.206276
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    expected_result = {
        'lan0': {'ipv4': {'address': '192.168.0.1',
                         'network': '192.168.0.0',
                         'interface': 'lan0'},
                 'device': 'lan0'
                 },
        'lan1': {'ipv4': {'address': '192.168.0.2',
                         'network': '192.168.0.0',
                         'interface': 'lan1'},
                 'device': 'lan1'
                 },
    }

# Generated at 2022-06-20 18:12:09.830280
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import sys
    sys.path.append('/')

    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork()

    # Expected output from netstat -niw command
    expected_output = """flags           mtu     net/dest          address
lan0:            1500   10.10.10.10     0:f:fd:c0:a8:1:1
lan1:            1500   10.10.10.10     0:f:fd:c0:a8:1:2
lan2:            1500   10.10.10.10     0:f:fd:c0:a8:1:3"""

    # Expected interfaces info

# Generated at 2022-06-20 18:12:11.627486
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact = HPUXNetworkCollector()
    assert fact._platform == 'HP-UX'
    assert fact._fact_class == HPUXNetwork



# Generated at 2022-06-20 18:12:14.230376
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Unit test for method populate of class HPUXNetwork."""
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert isinstance(network_facts, dict), \
        'network.populate() did not return a dictionary'

# Generated at 2022-06-20 18:12:18.744641
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpux_network = HPUXNetwork({})
    interfaces = hpux_network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan4000' in interfaces
    assert 'lan4001' in interfaces
    assert len(interfaces['lan0']) == 2
    assert len(interfaces['lan4000']) == 2
    assert len(interfaces['lan4001']) == 2

# Generated at 2022-06-20 18:12:28.364857
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    net = HPUXNetwork(module)
    net.get_default_interfaces = MagicMock(return_value={"default_interface": "lan0", "default_gateway": "10.0.0.1"})
    assert net.get_default_interfaces() == {"default_interface": "lan0", "default_gateway": "10.0.0.1"}
    assert net.default_interface == "lan0"
    assert net.default_gateway == "10.0.0.1"



# Generated at 2022-06-20 18:12:36.535239
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network_facts = HPUXNetwork()
    network_facts.module = MagicMock()
    network_facts.module.run_command.return_value = (0, 'default 10.0.0.1 UGSc 10 0 lan0', '')
    default_interfaces = network_facts.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0', 'default_gateway': '10.0.0.1'}


# Generated at 2022-06-20 18:12:39.041348
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_mock = HPUXNetwork(dict())
    out = net_mock.populate()
    assert 'default_interface' in out
    assert 'default_gateway' in out
    assert 'interfaces' in out


# Generated at 2022-06-20 18:12:46.180863
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    interface_name = 'lan2'
    interface_ipv4_address = '202.108.22.5'
    network_facts = network.populate()
    assert network_facts[interface_name] is not None
    assert network_facts[interface_name]['ipv4']['address'] == interface_ipv4_address


# Generated at 2022-06-20 18:13:17.091052
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class FakeModule:
        def __init__(self, result):
            self.__result = result
            self.run_command_counter = 0

        def run_command(self, arg):
            self.run_command_counter += 1
            if arg == "/usr/bin/netstat -niw":
                return 0, self.__result, ""
            else:
                raise Exception("Invalid argument")


# Generated at 2022-06-20 18:13:29.163061
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'netstat_mock', '')
    objNetwork = HPUXNetwork(module)
    result = objNetwork.populate()

    assert 'lo0' in result['interfaces']
    assert result['lo0']['ipv4']['address'] == '127.0.0.1'
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.1.1.1'
    assert result['lo0']['ipv4']['network'] == '127.0.0.1'
    module.run_command.assert_any_call("/usr/bin/netstat -niw")

# Generated at 2022-06-20 18:13:31.645621
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_hpux_facts = HPUXNetwork()
    assert network_hpux_facts.platform == 'HP-UX'

# Generated at 2022-06-20 18:13:38.174968
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts import collect_facts
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    import tempfile
    module = collect_facts.AnsibleModuleMock(argument_spec=dict())
    module.run_command = lambda x: (1, "", "")
    facter_network_module = HPUXNetwork(module=module)
    assert facter_network_module

# Generated at 2022-06-20 18:13:44.669135
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={})
    HPUX_module = HPUXNetwork()

    # Setup test data
    interfaces = {'lan0': {'device': 'lan0',
                           'ipv4': {'address': '192.168.56.105',
                                    'network': '192.168.56.0',
                                    'interface': 'lan0'}}}
    default_interfaces = {'default_interface': 'lan0',
                          'default_gateway': '192.168.56.2'}

# Generated at 2022-06-20 18:13:56.975247
# Unit test for method get_default_interfaces of class HPUXNetwork

# Generated at 2022-06-20 18:14:09.097786
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import MagicMock

    module = MagicMock()
    module.run_command.return_value = (0, '/dev/ip ip0', '')
    result = {}
    result['lan0'] = {'device': 'lan0',
                      'ipv4': {'network': '172.20.36.0',
                               'interface': 'lan0',
                               'address': '172.20.36.200'}}
    result['lan1'] = {'device': 'lan1',
                      'ipv4': {'address': '172.20.45.1'}}

# Generated at 2022-06-20 18:14:10.731448
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-20 18:14:17.097945
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Test case for method get_default_interfaces of class HPUXNetwork
    """
    network = HPUXNetwork()
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '224.0.0.1'



# Generated at 2022-06-20 18:14:20.608130
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn._fact_class().platform == 'HP-UX'

# Generated at 2022-06-20 18:14:59.784347
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:15:05.387635
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module = MagicMock()
    net.module.run_command.return_value = (0,
                                           'default  192.168.0.1  UG  ixgbe0',
                                           '')
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'ixgbe0',
                                  'default_gateway': '192.168.0.1'}
    net.module.run_command.assert_called_once_with("/usr/bin/netstat -nr")



# Generated at 2022-06-20 18:15:07.702524
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_n = HPUXNetworkCollector()
    assert hpux_n.platform == 'HP-UX'

# Generated at 2022-06-20 18:15:13.493835
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    net_facts = HPUXNetwork(module)
    def_interfaces = net_facts.get_default_interfaces()
    assert def_interfaces


# Generated at 2022-06-20 18:15:22.072504
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = dict()
    module['bin_env'] = dict()
    module['run_command'] = run_command

    net = HPUXNetwork(module)
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.34.2.254'



# Generated at 2022-06-20 18:15:32.111501
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    netstat_path = "/usr/bin/netstat"
    modules = {'netstat': netstat_path}
    facts_module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    facts_module.params = {'gather_subset': ['all'],
                           'gather_timeout': 10,
                           'filter': '*'}
    facts_module.exit_json(ansible_facts={})
    obj = HPUXNetwork(facts_module)
    obj.module.get_bin_path = MagicMock(return_value=netstat_path)
    obj.module.run_command = MagicMock(return_value=(0, "", ""))
    result = obj.populate()
    assert result['default_interface'] == 'lan0'

# Generated at 2022-06-20 18:15:41.156302
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_example_1 = [
        'Name  Mtu   Net/Dest      Address        Ipkts Ierrs Opkts Oerrs',
        'lan0  1500  *UP*          123.456.789.1  0     0     0     0',
        '',
        'Name  Mtu   Net/Dest      Address        Ipkts Ierrs Opkts Oerrs',
        'lan1  1500  *UP*          123.456.789.2  0     0     0     0',
        '',
        'Name  Mtu   Net/Dest      Address        Ipkts Ierrs Opkts Oerrs',
        'lan2  1500  *UP*          123.456.789.3  0     0     0     0'
    ]
    my_HPUXNetwork_1 = H

# Generated at 2022-06-20 18:15:43.900287
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    assert h.platform == 'HP-UX'



# Generated at 2022-06-20 18:15:53.070728
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork()
    result = hpux_network.populate()
    # Parse the result to get the default_interface
    # Has to be present in the result
    assert "default_interface" in result
    default_interface = result["default_interface"]
    # default_interface has to be of the form lanX, where X is a digit
    assert default_interface[:3] == "lan"
    assert default_interface[3:].isdigit()
    # Parse the result to get the list of interfaces
    # Has to be present in the result
    assert "interfaces" in result
    assert isinstance(result["interfaces"], list)
    # Parse the result to get the

# Generated at 2022-06-20 18:16:01.748107
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hu = HPUXNetwork()
    hu.module = MockModule()

    hu.module.run_command.return_value = (0, '', '')

    hu.module.run_command.return_value = (
        0,
        "Kernel IP routing table\ndefault 192.168.2.254 UG 0 0",
        '')
    assert hu.get_default_interfaces() == {
        'default_interface': 'UG', 'default_gateway': '192.168.2.254'}

    hu.module.run_command.return_value = (0, '', '')


# Generated at 2022-06-20 18:17:49.982792
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    arguments = {'module_name': 'os', 'module_args': '', 'check_mode': False}

    module = AnsibleModule(**arguments)


# Generated at 2022-06-20 18:17:55.904809
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    """
    This method returns the default_interface value for a tested system.

    :rtype: dictionary of default_interface
    :return: {'default_interface':'lan1'}
    """
    network = HPUXNetwork()
    default_interfaces = network.get_default_interfaces()
    return default_interfaces


# Generated at 2022-06-20 18:18:06.098705
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module_mock = mock.Mock()
    module_mock.run_command.return_value = (0, 'default 172.16.1.1 USUAl 0 24 lan4000', None)
    network_collector = HPUXNetwork(module_mock)
    assert network_collector.get_default_interfaces() == {'default_interface': 'lan4000',
                                                          'default_gateway': '172.16.1.1'}

# Generated at 2022-06-20 18:18:11.094021
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class module_mock:
        def run_command(self, command):
            class FakeStream(object):
                def readlines(self):
                    return ['default 172.16.32.1 UG lan1']

            return (0, FakeStream(), '')

    hn = HPUXNetwork(module_mock())
    assert hn.get_default_interfaces() == {'default_gateway': '172.16.32.1',
                                           'default_interface': 'lan1'}


# Generated at 2022-06-20 18:18:19.646786
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interface_str = 'default 0.0.0.0 UG lan0'
    default_gateway_str = '0.0.0.0/0 lan0'
    test_network = HPUXNetwork()
    test_network.module.run_command = \
        lambda *args, **kwargs: (0, default_interface_str + '\n' +
                                 default_gateway_str, '')

    rc, default_interfaces = test_network.get_default_interfaces()
    assert rc == 0
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '0.0.0.0/0'


# Generated at 2022-06-20 18:18:31.094736
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    # Stub netstat command output
    netstat = """
default 192.168.1.2 UGSc 50 0 lan0
default 192.168.1.1 UGSc 50 0 lan1
"""
    # Stub netstat command
    def run_command(self, cmd):
        return 0, netstat, ''

    # Set stubbed netstat command in the HPUXNetwork class
    HPUXNetwork.module.run_command = run_command

    # Expected default interfaces
    default_interfaces = {
        'default_interface': 'lan1',
        'default_gateway': '192.168.1.1'
    }

    # Instantiate the HPUXNetwork class and call the
    # get_default_interfaces method
    my_hpuxnet = HPUXNetwork()

# Generated at 2022-06-20 18:18:33.695207
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_n = HPUXNetwork()
    assert isinstance(h_n, HPUXNetwork)

# Generated at 2022-06-20 18:18:39.053434
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert(isinstance(hn, NetworkCollector))
    assert(hn._fact_class == HPUXNetwork)
    assert(hn._platform == 'HP-UX')


# Generated at 2022-06-20 18:18:42.041715
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collect_net = HPUXNetworkCollector()
    print(collect_net)

# Generated at 2022-06-20 18:18:52.815613
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""
    test_class = HPUXNetwork
    test = test_class()
    test_out = ("lan0  HWaddr=AA:BB:CC:DD:EE:FF  Up <UP,BROADCAST,RUNNING,SMART> <0>  MTU=1500  Metric=1",
                "  lan0  Link encap:Ethernet  HWaddr AA:BB:CC:DD:EE:FF",
                "  lan0: flags=0x4086<UP,BROADCAST,RUNNING,SMART>  mtu 1500",
                "  inet 10.0.0.1  netmask ffffff00 broadcast 10.0.0.255")
    test.module = MagicMock()