

# Generated at 2022-06-20 18:09:39.244367
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'

# Generated at 2022-06-20 18:09:44.907439
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetwork()
    hpux_network.module = module
    fact_network = hpux_network.populate()
    print('\nFacts for HP-UX Network:')
    for interface in fact_network:
        print("{0} = {1}".format(interface, fact_network[interface]))


# Generated at 2022-06-20 18:09:56.386703
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpu_ux import HPUXNetwork
    net_facts = HPUXNetwork(None, "/bin", None)
    out = '''default,10.254.0.1,0.0.0.0,UG,0,0,0,lan40,10.254.0.79
                127.0.0.1,127.0.0.1,127.0.0.1,UH,0,0,0,lo0
                10.254.0.0,10.254.0.1,255.255.255.0,U,0,0,0,lan40
                <etc>'''
    result = net_facts.get_default_interfaces(out)
    assert 'default_interface' in result
    assert result['default_interface']

# Generated at 2022-06-20 18:10:07.032849
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Test for method populate of class HPUXNetwork
    """
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['all'], type='list')
        }
    )
    if not HAS_NETSTAT:
        module.fail_json(msg='The `netstat` binary is not in the path')
    network_collector = HPUXNetworkCollector(module)
    facts = network_collector.collect(module)
    assert facts['interfaces'] == ['lan1', 'lan0']
    assert facts['default_interface'] == 'lan1'
    assert facts['lan1']['ipv4']['address'] == '172.17.0.2'

# Generated at 2022-06-20 18:10:09.213250
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Create an instance of HPUXNetworkCollector
    tmp = HPUXNetworkCollector()
    assert tmp
# unit test for method populate() of class HPUXNetwork

# Generated at 2022-06-20 18:10:13.519716
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    test_network = HPUXNetwork()
    result_interfaces_info = test_network.get_interfaces_info()
    expected_interfaces_info = calculate_expected_interfaces_info()
    assert result_interfaces_info == expected_interfaces_info


# Calculate expected result for unit test of method get_interfaces_info
# of class HPUXNetwork

# Generated at 2022-06-20 18:10:25.815226
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    class ModuleMock:
        def run_command(self, command):
            return rc, out, err

    net = HPUXNetwork(ModuleMock())
    lines = ['lan0    UP    192.168.0.5  192.168.0.0  HWaddr 0:1:2:3:4:5  lan0',
             'lo        UP    127.0.0.1    127.0.0.0    HWaddr 0:1:2:3:4:5  lo',
             'lan2    UP    192.168.0.7  192.168.0.0  HWaddr 0:1:2:3:4:5  lan2']

    rc = 0
    out = '\n'.join(lines)
    err = ''
    interfaces = net.get_interfaces_info()

# Generated at 2022-06-20 18:10:36.907025
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    n = HPUXNetwork()
    out = """
                            Kernel Interface Table
Name                 MTU   State   Domain
lan0                1500  Up      IPv4
lan1                1500  Up      IPv4
lan2                1500  Up      IPv4
lo0                 8239  Up      IPv4
"""
    interfaces = n.get_interfaces_info()

# Generated at 2022-06-20 18:10:42.994839
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    expected_result = {'default_interface': 'lan0', 'default_gateway': '172.16.99.254'}
    assert network.get_default_interfaces() == expected_result


# Generated at 2022-06-20 18:10:46.527632
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    obj = HPUXNetwork(m)
    default_interface_facts = obj.get_default_interfaces()
    assert 'default_gateway' in default_interface_facts
    assert 'default_interface' in default_interface_facts


# Generated at 2022-06-20 18:10:56.797724
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule({})
    hpx = HPUXNetwork(module)
    interfaces = hpx.get_interfaces_info()
    assert 'lan0' in interfaces.keys()
    assert interfaces['lan0']['ipv4']['address'] == '10.84.5.123'
    assert interfaces['lan0']['ipv4']['network'] == '10.84.5.0'

# Generated at 2022-06-20 18:10:57.514951
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:11:07.787019
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork.
    """
    src = '''Interface              Address
lan9000                  192.168.1.1
lan8000                  192.168.2.1
lan4000                  192.168.3.1
default                  192.168.1.1
'''
    module = get_module(src)
    os = HPUXNetwork(module)
    result = {}
    interfaces = ['lan9000', 'lan8000', 'lan4000']
    result['interfaces'] = interfaces
    result['default_gateway'] = '192.168.1.1'
    result['default_interface'] = 'lan9000'

# Generated at 2022-06-20 18:11:11.680656
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Create an instance of HPUXNetwork class
    network = HPUXNetwork()

    # Check parameters set by constructor of HPUXNetwork
    assert network.platform == "HP-UX"

# Generated at 2022-06-20 18:11:16.043212
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = MockModule()
    hpux_network = HPUXNetwork(module)
    assert hpux_network._device_regex.pattern == '^[a-z]+\d$'
    assert hpux_network.platform == 'HP-UX'
    assert hpux_network.get_default_interfaces() == {'default_gateway': '192.168.1.1', 'default_interface': 'lan0'}
    assert hpux_network.get_interfaces_info() == {'lan0': {'device': 'lan0', 'ipv4': {'address': '192.168.1.100', 'network': '192.168.1.0', 'interface': 'lan0'}}}



# Generated at 2022-06-20 18:11:25.940491
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = HPUXNetwork()
    result = m.populate()
    assert result['interfaces'] == 'lan1 lan2'
    assert result['lan1'] == {'ipv4': {'network': '1.2.3.0', 'address': '1.2.3.4', 'interface': 'lan1'}}
    assert result['lan2'] == {'ipv4': {'network': '5.6.7.0', 'address': '5.6.7.8', 'interface': 'lan2'}}

# Generated at 2022-06-20 18:11:35.916333
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    expected_interfaces_info = \
        {'lan0': {'ipv4': {'network': '192.168.1.0',
                           'interface': 'lan0',
                           'address': '192.168.1.50'},
                  'device': 'lan0'}
         }
    mocked_module = MockModule()
    mocked_module.run_command.return_value = (0, NETSTAT_NIW_OUTPUT, '')
    network = HPUXNetwork(mocked_module)
    assert network.get_interfaces_info() == expected_interfaces_info



# Generated at 2022-06-20 18:11:47.574655
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import ansible.module_utils.facts.network.hpux as hpux
    output = ('lan0: flags=0x8002<BROADCAST,RUNNING> mtu 1500 index 1 '
              'inet 10.1.1.1 netmask ff000000 broadcast 10.255.255.255\n'
              'lan1: flags=0x8002<BROADCAST,RUNNING> mtu 1500 index 1 '
              'inet 10.1.1.1 netmask ff000000 broadcast 10.255.255.255')
    interfaces = hpux.HPUXNetwork().get_interfaces_info()
    assert interfaces['lan0']['ipv4']['address'] == '10.1.1.1'

# Generated at 2022-06-20 18:11:51.771827
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpuxNetwork = HPUXNetwork(module)
    assert isinstance(hpuxNetwork, Network)


# Generated at 2022-06-20 18:11:59.385882
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h_net = HPUXNetwork()
    assert h_net.default_gateway == ''
    assert h_net.default_interface == ''
    assert type(h_net.interfaces) == list
    for iface in h_net.interfaces:
        assert 'device' in h_net[iface]
        assert 'ipv4' in h_net[iface]
        assert 'network' in h_net[iface]['ipv4']
        assert 'interface' in h_net[iface]['ipv4']
        assert 'address' in h_net[iface]['ipv4']


# Generated at 2022-06-20 18:12:07.522015
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_mod = HPUXNetwork()
    test_mod._load_params()
    interfaces_list = test_mod.get_interfaces_info()
    assert 'lan0' in interfaces_list

# Generated at 2022-06-20 18:12:18.991121
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    network.get_default_interfaces = MagicMock(return_value={'default_interface': 'lan0',
                                                             'default_gateway': '10.10.10.1'})

# Generated at 2022-06-20 18:12:30.218049
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test = HPUXNetwork()
    result = test.get_interfaces_info()
    assert result['lan0'] == {'device': 'lan0',
                              'ipv4': {'address': '192.168.10.25',
                                       'network': '192.168.10.0',
                                       'interface': 'lan0',
                                       'address': '192.168.10.25'}}
    assert result['lan1'] == {'device': 'lan1',
                              'ipv4': {'address': '192.168.10.26',
                                       'network': '192.168.10.0',
                                       'interface': 'lan1',
                                       'address': '192.168.10.26'}}

# Generated at 2022-06-20 18:12:35.164084
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import Network, NetworkCollector

    from ansible.module_utils.facts import ansible_facts

    # initialization test
    iface = HPUXNetworkCollector.collect(ansible_facts)
    assert iface is not None

    # populate test
    iface = HPUXNetwork()
    assert isinstance(iface, Network)
    assert iface.populate() is not None

# Generated at 2022-06-20 18:12:38.733795
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc._fact_class is HPUXNetwork
    assert nc._platform == 'HP-UX'


# Generated at 2022-06-20 18:12:41.333261
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModule(argument_spec = dict())
    NetworkCollector(module)


# Generated at 2022-06-20 18:12:51.583321
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)


# Generated at 2022-06-20 18:13:01.707505
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:13:09.375781
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = DummyAnsibleModule()
    network = HPUXNetwork(module=module)
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'
    assert '192.168.188.20' in interfaces['lan0']['ipv4']['address']
    assert 'lan2' in interfaces
    assert interfaces['lan2']['device'] == 'lan2'
    assert interfaces['lan2']['ipv4']['interface'] == 'lan2'
    assert '192.168.188.30' in interfaces['lan2']['ipv4']['address']



# Generated at 2022-06-20 18:13:13.290938
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPUXNetworkTest():
        def run_command(self, cmd):
            rc, out, err = 0, (
                'Name          Mtu Network       Address            Ipkts Ierrs '
                'Opkts Oerrs Coll'), ''
            return rc, out, err
    network = HPUXNetworkTest()
    assert network.get_interfaces_info() == {
        'lan0': {
            'ipv4': {
                'interface': 'lan0',
                'network': 'Bcast',
                'address': '0.0.0.0'
            },
            'device': 'lan0'
        }
    }

# Generated at 2022-06-20 18:13:24.010759
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork
    assert issubclass(HPUXNetworkCollector._fact_class, Network)

# Generated at 2022-06-20 18:13:26.868998
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockNetworkModule()
    ifaces = HPUXNetwork(module).get_interfaces_info()
    assert ifaces['lan0']['ipv4']['address'] == '192.168.1.10'


# Generated at 2022-06-20 18:13:36.943710
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={}
    )
    network_collector = HPUXNetwork(module)
    facts = network_collector.populate()
    assert facts['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3', 'lan4',
                                   'lan5', 'lan6', 'lan7', 'lan8', 'lan9',
                                   'lan10', 'lan11', 'lan12', 'lan13', 'lan14',
                                   'lan15', 'lan16', 'lan17']
    assert facts['default_interface'] == 'lan0'


# Generated at 2022-06-20 18:13:41.847719
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MagicMock()
    network_fact_class = HPUXNetwork(module)
    from ansible.module_utils.facts import data

    network_fact_class.module.run_command.return_value = (0, data['hpux_netstat_command_output'], None)
    default_interfaces_facts = network_fact_class.get_default_interfaces()
    assert default_interfaces_facts == {'default_interface': 'lan3', 'default_gateway': '10.10.80.1'}


# Generated at 2022-06-20 18:13:50.337122
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_hpux_network = HPUXNetwork()
    test_hpux_network.module = FakeModule()
    test_get_interfaces_info = test_hpux_network.get_interfaces_info()
    assert test_get_interfaces_info == {'lan0': {'ipv4': {'network': '192.168.0.0',
                                                          'interface': 'lan0',
                                                          'address': '192.168.0.1'},
                                               'device': 'lan0'},
                                        'lan2': {'ipv4': {'network': '192.168.1.0',
                                                          'interface': 'lan2',
                                                          'address': '192.168.1.1'},
                                               'device': 'lan2'}}



# Generated at 2022-06-20 18:13:59.407701
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ModuleStub(object):
        def __init__(self, command_response):
            self.command_response = command_response
        def run_command(self, command):
            (rc, out, err) = self.command_response
            return (rc, out, err)
    test_data = [
        """
        Routing tables
        
        Destination        Gateway           Flags      Refs Use   Interface
        default            172.17.0.1        UG         1     0   lan0
                            127.0.0.1         UH         0     0     lo0
        """
    ]
    reference_values = [
        {
            'default_interface': 'lan0',
            'default_gateway': '172.17.0.1'
        }
    ]

# Generated at 2022-06-20 18:14:09.377330
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpn = HPUXNetwork()
    hpn.module = AnsibleModule(argument_spec={})
    hpn.module.run_command = Mock()

    hpn.module.run_command.return_value = (0, "default 192.168.34.254 UG 5 lan1948\ndefault 10.0.0.1 UG 5 lan1234", '')

    default_interfaces_facts = hpn.get_default_interfaces()
    assert len(default_interfaces_facts) == 2

    assert default_interfaces_facts['default_interface'] == 'lan1234'
    assert default_interfaces_facts['default_gateway'] == '10.0.0.1'



# Generated at 2022-06-20 18:14:13.807426
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.2.2'


# Generated at 2022-06-20 18:14:21.884210
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    HPUXNetwork.module = "AnsibleModule"
    HPUXNetwork.module.run_command = lambda x: (0, 'default 10.0.0.7 UG 0 0 en0', '')
    expected = {'default_interface': 'en0', 'default_gateway': '10.0.0.7'}
    assert HPUXNetwork.get_default_interfaces() == expected


# Generated at 2022-06-20 18:14:29.357471
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class HPUXNetworkMock:
        def run_command(self, cmd, check_rc=True, close_fds=True):
            return (0,
                    """Routing tables

Internet:
Destination           Gateway           Flags      Refs      Use  If
default              10.202.129.21     UG          4          0  lan0
10.202.129.0         10.202.129.21     U           11        0.0  lan0
127.0.0.1            127.0.0.1         UH           3       72.2  lo0
localnet             10.202.129.21     UG          1          0  lan0
localnet             127.0.0.1         UG          2          0  lo0

""", '')

    hpux_facts = HPUXNetwork()


# Generated at 2022-06-20 18:14:44.856491
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = Mock()
    netstat_out = """lan0            lan0            UP               
lan0:1          lan0            UP               
lan0:2          lan0            UP               
lan1            lan1            UP               
lan1:1          lan1            UP               
lan1:2          lan1            UP               
lan2            lan2            UP               
lan2:1          lan2            UP               
lan2:2          lan2            UP               
lan3            lan3            UP
"""
    expected_out = {
        'lan0': {'device': 'lan0'},
        'lan1': {'device': 'lan1'},
        'lan2': {'device': 'lan2'},
        'lan3': {'device': 'lan3'},
    }
    # project
    module.run_command.return_

# Generated at 2022-06-20 18:14:56.054835
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=False
    )

    if not HPUXNetwork:
        module.fail_json(msg='hpux_network is required for this test')

    network = HPUXNetwork(module)

    default_interfaces = network.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.98.0.1'

# Generated at 2022-06-20 18:14:58.594673
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector.platform == HPUXNetwork.platform

# Generated at 2022-06-20 18:14:59.737299
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network != None


# Generated at 2022-06-20 18:15:06.132113
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    netif = HPUXNetwork()
    interfaces = netif.get_interfaces_info()
    assert interfaces['lan1'] == {'ipv4': {'network': '0.0.0.0',
                                          'interface': 'lan1',
                                          'address': '10.56.94.192'},
                                  'device': 'lan1'}


# Generated at 2022-06-20 18:15:11.366732
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """ Constructor of class HPUXNetworkCollector should set _platform. """
    network_collector = HPUXNetworkCollector()
    platform = network_collector._platform
    assert platform == "HP-UX"


# Generated at 2022-06-20 18:15:16.424917
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule({})
    obj = HPUXNetwork(module)
    default_interfaces = {}
    default_interfaces['default_interface'] = 'lan2'
    default_interfaces['default_gateway'] = '10.0.0.1'
    assert obj.get_default_interfaces() == default_interfaces


# Generated at 2022-06-20 18:15:19.329785
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == "HP-UX"

# Generated at 2022-06-20 18:15:23.937140
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module = HPUXNetwork()
    network.module.run_command = Mock(return_value=(1, '', ''))
    assert {} == network.get_default_interfaces()

# Generated at 2022-06-20 18:15:33.196205
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    out = \
"""lan0: flags=8943<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST> mtu 1500
        index 3
        inet 129.156.156.156 netmask ffffff00 broadcast 129.156.156.255
lan4: flags=8943<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST> mtu 1500
        index 5
        inet 129.156.156.15 netmask ffffff00 broadcast 129.156.156.255"""
    interfaces = net.get_interfaces_info()
    assert "lan0" in interfaces.keys()
    assert "lan4" in interfaces.keys()

# Generated at 2022-06-20 18:15:49.220878
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netm = HPUXNetwork()
    netm.module = MockModule()
    netm.module.run_command = MockFunction()
    netm.module.run_command.return_value = (0, "default   0.0.0.0        0.0.0.0     192.168.0.1     UG      1  0  0  lan0", "")
    netm.populate()
    assert netm.default_interface == 'lan0'
    assert netm.default_gateway == '192.168.0.1'


# Generated at 2022-06-20 18:15:50.191101
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = {}
    netinfo = HPUXNetwork(facts, None)
    assert netinfo.platform == 'HP-UX'


# Generated at 2022-06-20 18:15:54.683382
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Instantiate class
    hpux_collector = HPUXNetworkCollector()

    # Test attributes
    assert (hpux_collector.fact_class == HPUXNetwork)



# Generated at 2022-06-20 18:15:58.990850
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # HPUXNetworkCollector writes a deprecation warning if it is instantiated.
    # Capture the warning and verify that the warning is written.

    import warnings
    from ansible.module_utils.facts.network.common import NetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector

    with warnings.catch_warnings(record=True) as warning_list:
        HPUXNetworkCollector()
        assert len(warning_list) == 1
        assert issubclass(warning_list[-1].category, DeprecationWarning)
        assert 'HPUXNetworkCollector is deprecated' in str(warning_list[-1].message)

# Generated at 2022-06-20 18:16:11.142139
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpuxtools import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import mock


# Generated at 2022-06-20 18:16:15.171394
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h = HPUXNetworkCollector()
    assert h.platform == 'HP-UX'
    assert h.fact_class == HPUXNetwork



# Generated at 2022-06-20 18:16:19.067000
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    facts = HPUXNetwork()
    rc, out, err = facts.module.run_command("/usr/bin/netstat -niw")
    facts.get_interfaces_info()
    assert out

# Generated at 2022-06-20 18:16:27.036653
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpx = HPUXNetwork()
    hpx_interface = hpx.get_interfaces_info()
    # Test expected keys
    assert('device' in hpx_interface['lan0'])
    assert('ipv4' in hpx_interface['lan0'])
    assert('network' in hpx_interface['lan0']['ipv4'])
    assert('interface' in hpx_interface['lan0']['ipv4'])
    assert('address' in hpx_interface['lan0']['ipv4'])

# Generated at 2022-06-20 18:16:38.210181
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_mod = Network()
    test_mod.module = Network()
    test_mod.module.run_command = lambda args: (0,
                                                """default - - - lan3198 192.168.1.1
192.168.1.0        192.168.1.255      UG    lan3198 0 0
192.168.1.0        192.168.1.255      U     lan3198 0 0
192.168.1.0        192.168.1.255      U     lan3198 0 0
192.168.1.0        192.168.1.255      U     lan3198 0 0
""", "")
    default_interfaces = test_mod.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan3198'
    assert default_interfaces

# Generated at 2022-06-20 18:16:40.250403
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.get_default_interfaces()

# Generated at 2022-06-20 18:17:20.150023
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.run_command_call_count = 0

        def run_command(self, cmd, check_rc=True):
            if self.run_command_call_count == 0:
                output = (
                    "lan0   Link encap:Ethernet  HWaddr 00:05:9a:3c:78:00  "
                    "          inet addr:10.235.197.162  Bcast:10.235.197.255  "
                    "          Mask:255.255.254.0"
                )
                self.run_command_call_count += 1
                return (0, output, '')

# Generated at 2022-06-20 18:17:31.215127
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.base import Network, NetworkCollector
    global network_facts
    network_facts = Network(module=dict())
    network_facts.get_default_interfaces = Mock(return_value={'default_interface': 'lan0',
                                                              'default_gateway': '10.0.1.1'})
    network_facts.get_interfaces_info = Mock(return_value={'lan0': {'device': 'lan0',
                                                                    'ipv4': {'address': '10.0.1.5',
                                                                             'network': '10.0.1.0',
                                                                             'interface': 'lan0'}}})
    result = network_facts.populate()

# Generated at 2022-06-20 18:17:40.935160
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    import sys
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    myNetwork = HPUXNetwork(None)
    network_facts = myNetwork.populate()
    print("network_facts  = ", network_facts)
    print("network_facts['interfaces']  = ", network_facts['interfaces'])
    print("network_facts.keys() = ", network_facts.keys())
    for key in network_facts.keys():
        if key in ['interfaces']:
            for value in network_facts[key]:
                print(value + " = ", network_facts[key][value])
        else:
            print(key + " = ", network_facts[key])

# Generated at 2022-06-20 18:17:50.576514
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpu_net = HPUXNetwork({'module_name': 'test', 'module_args': {},
                           'ansible_facts': {}})

    hpu_net.module.run_command = lambda x: (0,
                                            'default   192.168.2.2    UG        0   lan9',
                                            '')
    default_interfaces = hpu_net.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan9',
                                  'default_gateway': '192.168.2.2'}

    hpu_net.module.run_command = lambda x: (0,
                                            'lan0      1000        1000       0        0  '
                                            '      1000        1000       0        0',
                                            '')


# Generated at 2022-06-20 18:17:58.806273
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    module.run_command = mock.Mock(return_value=(0, "", ""))
    hp_ux_network = HPUXNetwork(module)

    # test get_default_interfaces():
    default_interfaces = hp_ux_network.get_default_interfaces()
    assert default_interfaces['default_interface'] == ''
    assert default_interfaces['default_gateway'] == ''

    # test get_interfaces_info():
    interfaces = hp_ux_network.get_interfaces_info()
    assert interfaces == {}

    # test populate():
    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    module.run_command.assert_called_

# Generated at 2022-06-20 18:18:10.408810
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule('/usr/bin/netstat')
    network = HPUXNetwork(module)
    network_facts = network.populate()
    expected_network_facts = {
        'default_gateway': '192.168.1.1',
        'default_interface': 'lan0',
        'interfaces': ['lan0'],
        'lan0': {
            'ipv4': {
                'address': '192.168.1.23',
                'network': '192.168.1.0',
                'interface': 'lan0'
            },
            'device': 'lan0'
        }
    }

    assert network_facts == expected_network_facts


# The following class, functions and global variables are used
# as a fake ansible module when running unit tests.

# Generated at 2022-06-20 18:18:13.493597
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeModule()
    interface = HPUXNetwork(module)
    assert interface.platform == 'HP-UX'



# Generated at 2022-06-20 18:18:17.987719
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hpuix import HPUXNetworkCollector
    network = Network(collector=collector)
    data = network.populate()
    assert(len(data) > 0)

# Generated at 2022-06-20 18:18:21.193408
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network is not None


# Generated at 2022-06-20 18:18:31.704875
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """HPUXNetwork: testing populate method
    """
    class MockModule:
        def __init__(self, bin_path=None):
            self.bin_path = bin_path

        def get_bin_path(self, name, True_false=False):
            if name in self.bin_path:
                return self.bin_path[name]
            else:
                return None

        def run_command(self, cmd):
            if cmd == "/usr/bin/netstat -nr":
                return 0, 'default 192.168.0.1 us-108.27.11.1 UGSc 9 0 0 lan0', ''

# Generated at 2022-06-20 18:19:30.253979
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils import basic

    class TestModule():
        pass

    m = TestModule()
    m.get_bin_path = basic.get_bin_path
    m.run_command = basic.run_command

    facts = HPUXNetwork(m)
    out = facts.populate()
    assert out != {}
    assert out['default_gateway'] != ''
    assert out['default_interface'] != ''



# Generated at 2022-06-20 18:19:41.061308
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_HPUXNetwork = HPUXNetwork()
    test_HPUXNetwork.module = AnsibleModuleMock()
    test_HPUXNetwork.module.run_command = mock.MagicMock()
    test_HPUXNetwork.module.run_command.return_value = (0, "default 192.168.1.1 UG ", "")
    default_interfaces = test_HPUXNetwork.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'UG'
    assert default_interfaces['default_gateway'] == '192.168.1.1'
