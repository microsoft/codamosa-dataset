

# Generated at 2022-06-20 18:09:43.545022
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    obj = HPUXNetwork()
    out = b'Routing tables\n' \
        b'Internet:\n' \
        b'Destination        Gateway        Flags     Refs Use Mtu Interface\n' \
        b'default            10.1.2.1       UG        0 29864 1500 lan0\n' \
        b'10.1.2.0            10.1.2.254     U         0 19983 1500 lan0\n' \
        b'127.0.0.1          127.0.0.1       UH        0 11976 32768 lo0\n' \
        b'127.255.255.255    127.0.0.1       UH        0  1421 32768 lo0'
    obj.module.run_command = lambda _cmd: (0, out, '')


# Generated at 2022-06-20 18:09:46.189204
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork

# Generated at 2022-06-20 18:09:48.424050
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_collector = HPUXNetworkCollector()
    assert hpux_collector is not None

# Generated at 2022-06-20 18:09:54.797266
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = FakeModule()
    network = HPUXNetwork(module=test_module)
    test_module.run_command.return_value = (0, 'default9           00000000    00000000    UG      0 0          0 lan0\n', '')
    res = network.get_default_interfaces()
    assert res['default_interface'] == 'lan0'
    assert res['default_gateway'] == '00000000'


# Generated at 2022-06-20 18:09:56.738000
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert isinstance(HPUXNetworkCollector(), HPUXNetworkCollector)


# Generated at 2022-06-20 18:09:59.436633
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = HPUXNetworkCollector()
    assert isinstance(facts, HPUXNetworkCollector)

# Generated at 2022-06-20 18:10:00.471424
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:10:09.625058
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class TestModule():
        def run_command(self, cmd):
            out = 'lan0: flags=2<br>mtu 1500 index 1<br> \
inets lan0 addr:192.168.1.11 mask:255.255.255.0<br> \
groupname web<br>status: active'
            return 0, out, 'Success'

    testmod = TestModule()
    test_network = HPUXNetwork(testmod)

    interfaces = test_network.get_interfaces_info()
    assert interfaces['lan0']['ipv4']['address'] == '192.168.1.11'
    assert interfaces['lan0']['ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-20 18:10:12.112755
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = HPUXNetwork()
    assert facts.default_interface == 'lan0'
    assert facts.interfaces == ['lan0', 'lo0', 'oem0']


# Generated at 2022-06-20 18:10:16.408825
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hp_ux import HPUXNetwork
    m = HPUXNetwork(None)
    result = m.get_default_interfaces()
    assert type(result) == dict
    assert 'default_gateway' in result.keys()
    assert 'default_interface' in result.keys()


# Generated at 2022-06-20 18:10:28.419426
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:10:33.901887
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()['ansible_network_resources']
    assert network_facts['default_interface'] == 'lan0'



# Generated at 2022-06-20 18:10:46.118854
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.run_command.side_effect = [
        (0, "default 172.17.51.2 UGS lan0", ""),
        (0, "default 172.17.51.2 UGS lan0", ""),
        (0, "lan0 172.17.51.1     172.17.51.0  UHLW   lan0", "")
    ]
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0', \
        "Default interface not properly determined."

# Generated at 2022-06-20 18:10:49.949538
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork().get_interfaces_info()
    print(interfaces)
    assert ('lan0' in interfaces)
    assert ('lan1' in interfaces)

# Generated at 2022-06-20 18:10:53.069340
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-20 18:10:57.814204
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    iface = HPUXNetwork(dict())
    rc, out, err = iface.module.run_command("/usr/bin/netstat -niw")
    return iface.get_default_interfaces()


# Generated at 2022-06-20 18:10:59.213212
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-20 18:11:05.912107
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network_module = HPUXNetwork(None)
    ifaces = {'lan0': {'ipv4': {'network': '192.168.1.0', 'address': '192.168.1.2', 'interface': 'lan0'},
                       'device': 'lan0'}}
    result = network_module.get_interfaces_info()
    assert result == ifaces

# Generated at 2022-06-20 18:11:10.324294
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    HPUXNetwork = HPUXNetwork()
    interfaces = HPUXNetwork.get_interfaces_info()
    for i in interfaces:
        print(i, ':', interfaces[i])


# Generated at 2022-06-20 18:11:11.752505
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:11:25.037700
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = type('', (), {})
    module.run_command = HPUXNetworkCollector.run_command
    module.get_bin_path = HPUXNetworkCollector.get_bin_path
    network = HPUXNetwork(module)

    assert network.platform == 'HP-UX'
    assert network.get_default_interfaces()
    assert network.get_interfaces_info()

# Generated at 2022-06-20 18:11:32.354391
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    assert network.get_interfaces_info() == {'lan0': {'device': 'lan0', 'ipv4': {'address': '172.16.13.26', 'network': '172.16.13.25', 'interface': 'lan0'}}}


# Generated at 2022-06-20 18:11:40.883713
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    def mock_get_bin_path(self, arg, required=False):
        return '/usr/bin/netstat'

    def mock_run_command1(self, arg):
        return 0, 'default 10.11.12.13 UGSc 0 16 lan0\n' \
                  '10.11.12.0/24    10.11.12.13 UGS 0 16 lan0', ''
    def mock_run_command2(self, arg):
        return 0, '', 'no such file or directory'
    def mock_run_command3(self, arg):
        return 1, '', 'no such file or directory'

    test_module = MockAnsibleModule('', '', '', '', '', '')
    test_module.get_bin_path = mock_get_bin_path
    test_module

# Generated at 2022-06-20 18:11:47.980182
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Verify that HPUXNetwork.get_default_interfaces returns two keys,
    'default_interface' and 'default_gateway'.
    """
    facts = {}
    mod = AnsibleModule()
    hpuxnetwork = HPUXNetwork(mod)
    default_interface_facts = hpuxnetwork.get_default_interfaces(
    )
    assert (set(default_interface_facts.keys()) ==
            set(['default_interface', 'default_gateway']))

# Generated at 2022-06-20 18:11:50.361185
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = HPUXNetworkCollector()
    assert facts.platform == 'HP-UX'

# Generated at 2022-06-20 18:11:52.856776
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    set_module_args(dict(gather_subset='min'))

    network_facts = HPUXNetwork(module)
    facts = network_facts.populate()

    assert facts['default_interface'] == 'lan0'

# Generated at 2022-06-20 18:11:58.939957
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpu import HPUXNetwork
    iface = HPUXNetwork()
    interfaces = iface.get_interfaces_info()
    ifaces = ['lan9000', 'lan0', 'lan1', 'lan2', 'lan3', 'lan4', 'lan5', 'lan6', 'lan7', 'lan8']
    #for i in ifaces:
    #    print(interfaces[i])
    assert 'lan9000' in interfaces.keys()
    assert 'lan0' in interfaces.keys()
    assert 'lan1' in interfaces.keys()
    assert 'lan2' in interfaces.keys()
    assert 'lan3' in interfaces.keys()
    assert 'lan4' in interfaces.keys()
    assert 'lan5' in interfaces.keys()

# Generated at 2022-06-20 18:12:02.609847
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Creating object of class HPUXNetwork
    hpu_network = HPUXNetwork({"module": "1"})
    assert hpu_network


# Generated at 2022-06-20 18:12:07.564176
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = HPUXNetwork({})
    rc, out, err = m.module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                gw = words[1]
                interface = words[4]
    default_interfaces = {'default_interface': interface,
                          'default_gateway': gw}
    assert m.get_default_interfaces() == default_interfaces


# Generated at 2022-06-20 18:12:19.014529
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""

    from ansible.module_utils.facts import FactCollector

    # create a module object
    fake_module = FactCollector.set_module_args({})
    fake_module.exit_json = FactCollector.exit_json
    fake_module.fail_json = FactCollector.fail_json

    # Test with 'netstat -niw' returns no interface
    fake_module.run_command = lambda x: (0, "", "")
    collector = HPUXNetworkCollector(fake_module)
    interfaces = collector._fact_class.get_interfaces_info()
    assert interfaces == {}

    # Test with 'netstat -niw' returns one interface

# Generated at 2022-06-20 18:12:33.082167
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class TestModule:
        def run_command(self, command):
            lines = [
                '    Name          Mtu   Network        Address       Ipkts Ierrs ',
                'lan0        1500  link#2            00:00:00:00:00:00   264    0 ',
                'lan0        1500  12.39.69.64       12.39.69.226     59813 1672'
            ]
            return None, '\n'.join(lines), None

    test_module = TestModule()
    test_network = HPUXNetwork(test_module)
    interfaces = test_network.get_interfaces_info()
    assert interfaces['lan0']['device'] == 'lan0'

# Generated at 2022-06-20 18:12:39.218046
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    iface = HPUXNetwork(module)
    facts = iface.populate()
    assert facts.has_key('default_interface')
    assert facts.has_key('default_gateway')
    assert facts.has_key('interfaces')


# Generated at 2022-06-20 18:12:41.600943
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Constructor of HPUXNetwork class can be called.
    """
    obj = HPUXNetwork({})
    assert bool(obj)

# Generated at 2022-06-20 18:12:51.717154
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    fake_module = {}
    fake_module.run_command = lambda cmd: (0, out_netstat_niw, err)
    hpuxnetwork = HPUXNetwork(fake_module)
    result = hpuxnetwork.populate()
    assert result['interfaces'] == ['lan1', 'lan2', 'lan3']
    assert result['lan1']['ipv4']['interface'] == 'lan1'
    assert result['lan1']['ipv4']['address'] == '15.11.0.50'
    assert result['lan1']['ipv4']['network'] == '15.11.0.0'
    assert result['lan1']['device'] == 'lan1'

# Generated at 2022-06-20 18:12:54.565825
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'

# Generated at 2022-06-20 18:13:02.892521
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork(dict(module=dict()))
    net.module.run_command = run_command_mock
    fact_subset = net.populate()
    fact_subset_keys = set(fact_subset.keys())
    assert fact_subset_keys == set(HPUX_NETSTAT_KEYS)
    for iface in fact_subset['interfaces']:
        assert iface == "lan0"
        assert fact_subset[iface]['device'] == 'lan0'
        assert fact_subset[iface]['ipv4']['address'] == '10.0.0.1'
        assert fact_subset[iface]['ipv4']['network'] == '10.0.0.0'

# Generated at 2022-06-20 18:13:06.600488
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork(dict())
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '172.16.120.129'



# Generated at 2022-06-20 18:13:17.210782
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda *args: (0,
                                        'lan9000 lan9005 link#4  192.168.0.100    255.255.255.0   lan9000',
                                        '')
    hpux_network = HPUXNetwork(module)
    assert hpux_network.get_interfaces_info() == {'lan9000': {'ipv4': {'address': '192.168.0.100',
                                                                        'network': '192.168.0.0',
                                                                        'interface': 'lan9000'},
                                                              'device': 'lan9000'}}


# Generated at 2022-06-20 18:13:23.416630
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network
    assert network.platform == 'HP-UX'
    assert len(network.get_default_interfaces()) == 2
    assert len(network.get_interfaces_info()) > 0



# Generated at 2022-06-20 18:13:26.577652
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces_facts = HPUXNetwork.get_default_interfaces()
    assert default_interfaces_facts == {'default_interface': 'lan1', 'default_gateway': '172.24.2.1'}


# Generated at 2022-06-20 18:13:39.864494
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpx_network = HPUXNetwork()
    assert isinstance(hpx_network.get_interfaces_info(), dict)



# Generated at 2022-06-20 18:13:49.089193
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Output of command /usr/sbin/netstat -niw
    netstat_nw_output = """Name  Mtu Network Address  Ipkts Ierrs Opkts Oerrs Coll
lan0   1500  192.168.0.0 192.168.0.1   0.0K     0     0.0    0.0    0
lan1   1500  192.168.1.0 192.168.1.1   0.0K     0     0.0    0.0    0
lan2   1500  192.168.2.0 192.168.2.1   0.0K     0     0.0    0.0    0
"""
    dummy_module = DummyModule()
    dummy_module.run_command = lambda command: [0, netstat_nw_output, '']

# Generated at 2022-06-20 18:13:50.375432
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    host = HPUXNetworkCollector()
    assert host.platform == 'HP-UX'

# Generated at 2022-06-20 18:13:59.432207
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:14:04.645950
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hn = HPUXNetwork()
    assert hn.get_default_interfaces() == {'default_gateway': '1.2.3.4',
                                           'default_interface': 'lan0'}


# Generated at 2022-06-20 18:14:15.954891
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    ''' test_HPUXNetwork_populate '''
    network = HPUXNetwork()
    network.module.run_command = lambda *_: (0, test_default_interfaces, '')
    network.get_default_interfaces()
    network.module.run_command = lambda *_: (0, test_interfaces_info, '')
    network.get_interfaces_info()


# Generated at 2022-06-20 18:14:25.494425
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from collections import namedtuple
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    FakeModule = namedtuple('FakeModule', ['run_command'])

    def fake_run_command(arg):
        FakeResponse = namedtuple('FakeResponse',
                                  ['returncode', 'stdout', 'stderr'])
        fake_netstat_output = ("Name  Mtu   Network     Address         Ipkts "
                               "Ierrs    Opkts  Oerrs    Coll\n"
                               "lan0 1500  10.15.160  192.168.160.179   79990  0 "
                               "    51880  0       0")

# Generated at 2022-06-20 18:14:37.288738
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""

    # Solicit input from user
    my_interfaces = input("\nEnter string of comma-separated interfaces: ")
    my_ips = input("Enter string of comma-separated IP addresses: ")
    my_networks = input("Enter string of comma-separated networks: ")

    # Put input into lists
    ifc_list = my_interfaces.split(",")
    ip_list = my_ips.split(",")
    nw_list = my_networks.split(",")

    # Generate output based on input
    output = "lan0      0        " + nw_list[0] + "    " + ip_list[0] + "     20     0     -"

# Generated at 2022-06-20 18:14:43.266821
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux = HPUXNetwork()

    assert hasattr(hpux, 'default_interface')
    assert hasattr(hpux, 'default_gateway')
    assert hasattr(hpux, 'interfaces')
    assert hasattr(hpux, 'interface_lo0')



# Generated at 2022-06-20 18:14:50.545632
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    obj = HPUXNetwork(None)
    interfaces = obj.get_interfaces_info()

    assert type(interfaces) is dict
    assert 'lan0' in interfaces

    lan0 = interfaces.get('lan0')
    lan1 = interfaces.get('lan1')

    assert lan0.get('device') == 'lan0'
    assert lan1.get('device') == 'lan1'
    assert lan0.get('ipv4').get('address') == '172.17.200.5'
    assert lan1.get('ipv4').get('address') == '192.168.100.5'
    assert lan0.get('ipv4').get('network') == '172.17.200.0'

# Generated at 2022-06-20 18:15:19.677876
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network import Network

    # Create a fake module
    from ansible.module_utils.facts import ModuleFacts

    module = ModuleFacts(
        dict(ANSIBLE_MODULE_ARGS=dict(gather_subset='default')))

    # Create a fake commans.get_bin_path function.
    import tempfile

    test_file = tempfile.NamedTemporaryFile()
    path = test_file.name
    test_file.write('')
    test_file.flush()

    def fake_get_bin_path(name, opts=None):
        path = test_file.name
        return path

    module.get_bin_path = fake_get_bin_path

    # Create a fake ansible.module_utils.basic.AnsibleModule function

# Generated at 2022-06-20 18:15:22.339242
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network._fact_class.platform == 'HP-UX'
    assert network._platform == 'HP-UX'



# Generated at 2022-06-20 18:15:32.324201
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = type('test_module', (object,), {'run_command': run_command})
    def run_command(self, args, check_rc=True):
        out = "lan0   14.14.100.223  netmask   255.255.255.0  broadcast   14.14.100.255  UHLcD 2   0  12  lan1   14.14.100.224  netmask   255.255.255.0  broadcast   14.14.100.255  UHLcI 2   0  12"
        return 0, out, ''
    network = HPUXNetwork(test_module)
    interfaces_info = network.get_interfaces_info()

    assert len(interfaces_info) == 2
    assert 'lan0' in interfaces_info
    assert 'lan1' in interfaces

# Generated at 2022-06-20 18:15:36.749399
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = {}
    hpu = HPUXNetworkCollector()
    assert hpu is not None
    assert hpu._fact_class is not None
    assert type(hpu._fact_class) == type
    assert hpu.platform == 'HP-UX'

# Generated at 2022-06-20 18:15:49.579985
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork({})
    test_interfaces = {'lan0': {'device': 'lan0', 'ipv4': {'network': '10.0.0.0', 'interface': 'lan0', 'address': '10.0.0.1'}}, 'lan1': {'device': 'lan1', 'ipv4': {'network': '10.0.1.0', 'interface': 'lan1', 'address': '10.0.1.1'}}}
    out = "lan0       0 0  0 10.0.0.1 10.0.0.0 up up\nlan1       0 0  0 10.0.1.1 10.0.1.0 up up"
    assert(test_interfaces == net.get_interfaces_info(out))


# Generated at 2022-06-20 18:15:53.631511
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import tempfile
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class FakeAnsibleModule():
        def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False):
            self.argument_spec = argument_spec
            self.check_mode = supports_check_mode
            self.bypass_checks = bypass_checks

    class FakeModule():
        def __init__(self, module_args):
            self.params = module_args

    def get_bin_path(path):
        if path == 'netstat':
            return '/usr/bin/netstat'
       

# Generated at 2022-06-20 18:15:58.587218
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    mod = AnsibleModule(argument_spec=dict())
    obj = HPUXNetwork(module=mod)
    rc, out, err = mod.run_command("/usr/bin/netstat -niw")
    assert out == obj.get_interfaces_info()

# Generated at 2022-06-20 18:16:02.563194
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    nm = HPUXNetwork(module)
    facts = nm.populate()
    print (facts)

# Unit test stub

# Generated at 2022-06-20 18:16:04.353201
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:16:09.285132
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Unit test for constructor of class HPUXNetworkCollector
    """
    networks = HPUXNetworkCollector()
    assert networks.platform == 'HP-UX'
    assert networks._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:16:50.551399
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Unit test for populate method of HP-UXNetwork"""

    class TestModule(object):
        def get_bin_path(self, *args, **kwargs):
            return None

    class TestModuleFail(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/netstat'

        def run_command(self, *args, **kwargs):
            return '-1', '', ''

    # Test without netstat binary
    net = HPUXNetwork(TestModule())
    assert net.populate() == {}

    # Test with netstat binary, but command failed
    net = HPUXNetwork(TestModuleFail())
    assert net.populate() == {}

    # Test with netstat binary, but command succeed

# Generated at 2022-06-20 18:16:56.030393
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module = FakeModule()
    assert net.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '10.76.0.1'}


# Generated at 2022-06-20 18:16:59.257771
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    net_obj = HPUXNetwork(module)
    default_interfaces = net_obj.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.2.2'


# Generated at 2022-06-20 18:16:59.980823
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork

# Generated at 2022-06-20 18:17:09.859787
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    interfaces = {}
    module = MockModule
    netstat_output = '/usr/bin/netstat -nr\ndefault 0.0.0.0 UG lo 10\n'
    module.run_command = Mock(return_value=(0, netstat_output, ''))
    hpn = HPUXNetwork(module)
    interfaces.update(hpn.get_default_interfaces())
    assert interfaces['default_gateway'] == '0.0.0.0'
    assert interfaces['default_interface'] == 'lo'



# Generated at 2022-06-20 18:17:12.264652
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_collector = HPUXNetworkCollector()
    assert hpux_collector._platform == 'HP-UX'
    assert hpux_collector._fact_class.__name__ == 'HPUXNetwork'

# Generated at 2022-06-20 18:17:16.991575
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    testobj = HPUXNetwork()
    interfaces = testobj.get_interfaces_info()
    assert interfaces.has_key('lan0')
    assert interfaces['lan0'] == {'device': 'lan0', 'ipv4': {'interface': 'lan0', 'network': '192.168.1.0', 'address': '192.168.1.2'}}

# Generated at 2022-06-20 18:17:18.693801
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-20 18:17:29.772962
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    class TestModule:
        def run_command(self, command):
            if command == "/usr/bin/netstat -niw":
                return (0, "lan0      en0      0.0.0.0         127.0.0.1", "")
            else:
                return (0, "", "")
    module = TestModule()
    hpux_network = HPUXNetwork(module)
    assert hpux_network.get_interfaces_info() == {'lan0': {'device': 'lan0', 'ipv4': {'interface': 'lan0', 'network': '0.0.0.0', 'address': '127.0.0.1'}}}



# Generated at 2022-06-20 18:17:34.471889
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Test without parameters
    x = HPUXNetworkCollector()

    # Test with parameters
    y = HPUXNetworkCollector(conditions=['test1', 'test2'])


# Generated at 2022-06-20 18:18:31.461958
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate for HPUXNetwork.
    Checks that the method populate generates the correct output.
    """
    my_hpuxnetwork = HPUXNetwork(dict())
    my_hpuxnetwork._module = MockModule()

    result = my_hpuxnetwork.populate()

    assert result['default_interface'] == "lan0"
    assert result['default_gateway'] == "10.0.2.2"
    assert "interfaces" in result.keys()
    assert result["lan0"]["ipv4"]["address"] == "10.0.2.15"
    assert result["lan0"]["ipv4"]["network"] == "10.0.2.0"
    assert result["lan0"]["ipv4"]["interface"] == "lan0"


#

# Generated at 2022-06-20 18:18:35.110374
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc.platform == 'HP-UX'
    assert nc._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:18:39.542163
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_object = HPUXNetwork()
    out = test_object.get_default_interfaces()
    assert out['default_interface'] == 'lan0'
    assert out['default_gateway'] == '10.82.31.21'



# Generated at 2022-06-20 18:18:51.242261
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # This init code is not correct for unittest, but it's the only way to
    # test get_interfaces_info method of HPUXNetwork class
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    net2 = HPUXNetwork(module)
    interfaces = net2.get_interfaces_info()
    assert interfaces['lan0']['ipv4']['network'] == '132.187.0'
    assert interfaces['lan0']['ipv4']['address'] == '132.187.0.134'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-20 18:19:01.199685
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Test with network interfaces
    test = HPUXNetwork()
    interfaces_info = test.get_interfaces_info()
    assert interface_info_expected == interfaces_info

# Expected test result

# Generated at 2022-06-20 18:19:12.771104
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    collected_facts = dict(default_gateway_interface='lan0',
                           ansible_en1=dict(address=['10.0.2.15', '10::a'],
                                            macaddress='08:00:27:9c:d1:d9'),
                           ansible_default_ipv4=dict(address='10.0.2.15',
                                                     network='10.0.2.0',
                                                     netmask='255.255.255.0',
                                                     gateway='10.0.2.2'),
                           ansible_default_ipv6=dict(address='10::a',
                                                     prefix='64',
                                                     gateway='fe80::1'))
    test_hp_ux = HPUXNetwork()

# Generated at 2022-06-20 18:19:23.509793
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    test_data = list()
    test_data.append(u'There are no LAN interfaces')
    test_data.append(u'As of 14:24:20 on Feb 08, 1995.')
    test_data.append(u'lan0: flags=11c43<UP,BROADCAST,RUNNING,NOARP,MULTICAST>')
    test_data.append(u'lan1: flags=c43<UP,BROADCAST,RUNNING,MULTICAST> ')

    test_obj = HPUXNetwork(module)
    lan = test_obj.get_interfaces_info()
    assert lan['lan0']['device'] == 'lan0'

# Generated at 2022-06-20 18:19:31.883508
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import os
    import pytest
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    module = pytest.Mock()
    module.run_command.return_value = (0, 'default 10.1.1.1 UG lan0', '')
    hpux_network = HPUXNetwork(module)
    default_interfaces_facts = hpux_network.get_default_interfaces()
    assert default_interfaces_facts == \
           {'default_interface': 'lan0', 'default_gateway': '10.1.1.1'}