

# Generated at 2022-06-20 18:09:45.705547
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import Network, NetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts import collector

    # Set print for testing
    class MockModule:
        def __init__(self):
            self.params = {}
            self._debug_enabled = False

        def _debug(self, msg):
            pass


# Generated at 2022-06-20 18:09:56.738381
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule(object):
        def get_bin_path(self, name, required=False):
            return "/usr/bin/netstat"
        def run_command(self, cmd, check_rc=True):
            return (0, DEFAULT_INTERFACE_RESULT, None)

    DEFAULT_INTERFACE_RESULT = "default 192.168.1.1 UG lan0\n"
    module = TestModule()
    network = HPUXNetwork(module)
    default_interfaces_facts = network.get_default_interfaces()
    assert type(default_interfaces_facts) == dict
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts
    assert default_interfaces_facts['default_interface'] == 'lan0'

# Generated at 2022-06-20 18:10:07.311441
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    dummy_module = HPUXNetworkCollector(None)

# Generated at 2022-06-20 18:10:12.361346
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    interfaces = HPUXNetwork().get_interfaces_info()

    # Test contents of a sample
    for iface in interfaces:
        if iface[:3] == 'lan':
            assert 'ipv4' in interfaces[iface]
            assert 'network' in interfaces[iface]['ipv4']
            assert 'interface' in interfaces[iface]['ipv4']
            assert 'address' in interfaces[iface]['ipv4']



# Generated at 2022-06-20 18:10:16.939881
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    "Test the constructor of HPUXNetwork"
    # Test creation
    HPUXNetworkFact = HPUXNetwork()

    # Test the variables
    assert HPUXNetworkFact is not None

# Generated at 2022-06-20 18:10:23.455055
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork({'ansible_python_interpreter': '/usr/bin/python'})
    result = net.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.50.1'


# Generated at 2022-06-20 18:10:29.027463
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    this_class = HPUXNetwork()
    assert(this_class.get_default_interfaces() == {'default_gateway': '10.0.2.2', 'default_interface': 'lan0'})


# Generated at 2022-06-20 18:10:30.680327
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mock_module = MockModule()
    h = HPUXNetwork(mock_module)
    assert h.module == mock_module
    assert h.platform == 'HP-UX'



# Generated at 2022-06-20 18:10:38.828493
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    output = 'lan0    link#1    UP    1000    0x2    A/S    ETHER    1000/Full/100BaseT    0.0.0.0    0.0.0.0\n' \
             'lan10000    link#2    UP    10000    0x2    A/S    ETHER    10000/Full/1000BaseT    0.0.0.0    0.0.0.0\n'
    test_obj = HPUXNetwork()
    test_obj.module = NetworkCollector()
    test_obj.module.run_command = lambda *_, **__: (0, output, None)
    interfaces = test_obj.get_interfaces_info()

# Generated at 2022-06-20 18:10:48.155164
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hn = HPUXNetwork()
    hn.module = MockModule()

    hn.module.run_command.return_value = (0, TEST_INTERFACES_INFO_1, "")

    interfaces = hn.get_interfaces_info()

    assert "lan0" in interfaces
    assert "lan1" in interfaces
    assert "lan2" in interfaces
    assert "lan3" in interfaces
    assert "lan4" in interfaces
    assert "lan5" in interfaces

    assert interfaces["lan0"]['device'] == "lan0"
    assert interfaces["lan1"]['device'] == "lan1"
    assert interfaces["lan2"]['device'] == "lan2"
    assert interfaces["lan3"]['device'] == "lan3"

# Generated at 2022-06-20 18:10:59.270810
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class FakeModule:
        def get_bin_path(self, path):
            return '/usr/bin/netstat'

        def run_command(self, path):
            return 0, 'default 10.1.1.1 UG lan1\ntest 10.1.2.2 UG lan2', ''

    fake_module = FakeModule()
    hpux_network = HPUXNetwork()
    hpux_network.module = fake_module
    default_interface_facts = hpux_network.get_default_interfaces()
    assert default_interface_facts['default_interface'] == 'lan1'
    assert default_interface_facts['default_gateway'] == '10.1.1.1'



# Generated at 2022-06-20 18:11:07.815989
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    def mock_run_command(self, args, check_rc=True, close_fds=True, executable=None,
                         data=None, binary_data=False):
        return 0, netstat, None
    HPUXNetwork.run_command = mock_run_command
    netstat = 'default 192.168.0.1 UGS 0 0 en0\ndefault 192.168.0.1 UGS 0 0 en1'
    test_interfaces = HPUXNetwork().get_default_interfaces()
    assert test_interfaces['default_interface'] == 'en0'
    assert test_interfaces['default_gateway'] == '192.168.0.1'



# Generated at 2022-06-20 18:11:14.565706
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    print("\n*** Output of method get_interfaces_info for class HPUXNetwork ***")
    for interface in interfaces:
        print("\nInterface %s: %s" % (interface, interfaces[interface]))



# Generated at 2022-06-20 18:11:28.000975
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    target = HPUXNetwork()
    target.module = AnsibleModule(
        argument_spec=dict()
    )
    target.module.run_command = MagicMock(return_value=(0,
"""Name  Mtu   Network   Address         Ipkts Ierrs    Opkts Oerrs  Coll
lan0   1500  -         192.168.1.10    42    0        27    0      0
lan0   1500  192.168.1.0 192.168.1.10  42    0        27    0      0
""", ''))
    network_facts = target.populate()
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['default_interface'] == 'lan0'

# Generated at 2022-06-20 18:11:38.683571
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork(module="Test")

    def mock_run_command(command):
        output = 'lan1   lan1  192.168.0.0  192.168.0.1   UP  UP  10  Ethernet  Jumbo'
        return (0, output, '')

    # Mocked method is expected to have been called once with command
    lan1_info = 'lan1   lan1  192.168.0.0  192.168.0.1   UP  UP  10  Ethernet  Jumbo'
    network.module.run_command = mock_run_command
    network.get_interfaces_info()
    network.module.run_command.assert_called_once_with('/usr/bin/netstat -niw')

    # Mocked method should have returned with 0, lan1 information and None

# Generated at 2022-06-20 18:11:46.759239
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class HPUXNetwork
    """
    module = Mock()
    module.run_command.return_value = 0, '/usr/bin/netstat -nr\n' + \
        'default  10.1.1.1 UG 0 0  lan0\n', ''
    n = HPUXNetwork(module)
    result = n.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.1.1.1'

# Generated at 2022-06-20 18:11:53.239488
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = Network
    network = HPUXNetwork()
    network.module = module
    facts = network.populate()
    assert len(facts['interfaces']) > 0
    assert 'default_interface' in facts
    assert 'default_gateway' in facts

# Generated at 2022-06-20 18:11:55.173546
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net.platform == "HP-UX"

# Generated at 2022-06-20 18:12:02.158584
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    net.module = None
    net.module.run_command = None
    net.module.run_command.return_value = (0,
                                           "lan0 lan0 0x80000000 0x00000000 "
                                           "0x0 0x0 0x0 0x0 0x0 0x0 0x0 "
                                           "lan0 0x0 0x0 0x0 0x0 0x0 0x0",
                                           "")
    expected_interfaces = {'lan0': {'ipv4': {'address': '0x0',
                                             'network': '0x0',
                                             'interface': 'lan0'},
                                    'device': 'lan0'}}

# Generated at 2022-06-20 18:12:11.689618
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    netstat_path = '/usr/bin/netstat'
    module = MockModule()
    module.run_command = MockFunction("run_command")

    network = HPUXNetwork(module)

# Generated at 2022-06-20 18:12:31.414755
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    output = """
lan0: flags=863<UP,BROADCAST,NOTRAILERS,RUNNING,MULTICAST> mtu 1500 index 1
        inet 10.30.0.2 netmask ffffff00 broadcast 10.30.0.255
lan1: flags=863<UP,BROADCAST,NOTRAILERS,RUNNING,MULTICAST> mtu 1500 index 2
        inet 10.30.1.2 netmask ffffff00 broadcast 10.30.1.255
"""


# Generated at 2022-06-20 18:12:32.447357
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    result = HPUXNetworkCollector()
    assert result._platform == 'HP-UX'

# Generated at 2022-06-20 18:12:37.668134
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    facts = network_facts.get_default_interfaces()
    assert facts == {'default_interface': 'lan1', 'default_gateway': '10.0.1.1'}


# Generated at 2022-06-20 18:12:47.809343
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule(object):
        def run_command(self, cmd):
            (rc, out, err) = (0, 'lan0  link#3         0            0        0  lan0                          lan0  link#3         0            0        0  lan0', '')
            return (rc, out, err)
    mock = MockModule()
    obj = HPUXNetwork()
    obj.module = mock
    interfaces = obj.get_interfaces_info()
    print(interfaces)
    actual = {'lan0': {'ipv4': {'address': '0', 'interface': 'lan0', 'network': '0'}, 'device': 'lan0'}}
    assert (interfaces == actual)

# Generated at 2022-06-20 18:13:00.194711
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    test_data = (
        "/usr/bin/netstat: no link-level statistics available\n",
        "Name  Mtu  Network       Address         Ipkts Ierrs     Opkts Oerrs"
        "  Coll  Queue\nlan0   1500  10.15.24.0    10.15.24.112    0     0"
        "          0     0      0      0\n")
    interfaces = net.get_interfaces_info()
    assert len(interfaces) is 1
    assert 'lan0' in interfaces.keys()
    assert interfaces['lan0']['ipv4']['address'] == '10.15.24.112'

# Generated at 2022-06-20 18:13:08.356775
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    f_cls = HPUXNetwork()
    f_cls.module = module

    facts = f_cls.populate()

    # Check the facts
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.2.2.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.2.2.11'
    assert facts['lan0']['ipv4']['network'] == '10.2.2.0'

# Generated at 2022-06-20 18:13:18.289998
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
            'gather_network_resources': dict(type='list')
        }
    )
    netstat = "/usr/bin/netstat"

    default_interfaces_data = """default 192.168.12.1 UG lan0 
default 192.168.18.1 UG lan1"""

    net_inst = HPUXNetwork(module)
    net_inst.module.run_command = MagicMock()
    net_inst.module.run_command.return_value = (0, default_interfaces_data, "")
    default_interfaces_facts = net_inst.get_default_interfaces()

# Generated at 2022-06-20 18:13:22.139268
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_hpux_network = HPUXNetwork()
    assert test_hpux_network._platform == 'HP-UX'

# Generated at 2022-06-20 18:13:24.088737
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:13:31.892316
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule:
        def __init__(self):
            self.run_command_called_count = 0

        @staticmethod
        def fail_json(*args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return args[0]

        def run_command(self, *args, **kwargs):
            assert args[0] == "/usr/bin/netstat -niw"
            assert kwargs == {}

            if self.run_command_called_count == 0:
                self.run_command_called_count += 1

# Generated at 2022-06-20 18:13:58.128090
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    collected_facts = {}
    network = HPUXNetwork()
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.10.10.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.10.10.142'
    assert network_facts['lan0']['ipv4']['network'] == '10.10.10.0'


# Generated at 2022-06-20 18:14:02.623393
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = Network()
    assert module._platform == 'HP-UX'
    assert module.platform == 'HP-UX'
    assert module.default_interfaces == {}
    assert module.interfaces == {}

# Generated at 2022-06-20 18:14:14.962384
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest

    class TestHPUXNetwork_get_default_interfaces(unittest.TestCase):
        def setUp(self):
            import ansible.module_utils.facts.network.hpux
            import ansible.module_utils.facts.network.base
            class FakeModule(object):
                def run_command(self, command):
                    self.run_command_args = command
                    self.run_command_called = True
                    return 0, '', ''
            self.fake_module = FakeModule()
            self.network_fact_class = hpux.HPUXNetwork(self.fake_module)

        def tearDown(self):
            self.fake_module = None
            self.network_fact_class = None



# Generated at 2022-06-20 18:14:24.902525
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import sys
    test = HPUXNetwork()

    # All of the interfaces are up, with only the specified IP address
    netstat_output = "Name Mtu Network Address Ipkts Ierrs Opkts Oerrs Coll" \
        "lan0 1500 172.16.145.0 172.16.145.2 487816 0 331242 0 0"
    rc, out, err = 0, netstat_output, None
    interfaces = test.get_interfaces_info(rc, out, err)

    assert 'lan0' in interfaces
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['network'] == '172.16.145.0'

# Generated at 2022-06-20 18:14:33.904722
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module.run_command = MagicMock(return_value=(0, 'default 10.1.1.2 UGS lan0', ''))
    rc = network.populate()
    assert rc.get('default_interface') == 'lan0'
    assert rc.get('default_gateway') == '10.1.1.2'


# Generated at 2022-06-20 18:14:39.888880
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mock_module = MockModule()
    mock_module.run_command = Mock(
        return_value=(0, '/usr/bin/netstat', ''))
    netstat_path = mock_module.get_bin_path('netstat')
    assert netstat_path != ''
    mock_network_facts = HPUXNetwork(mock_module)
    net_facts_dict = mock_network_facts.populate()
    assert net_facts_dict['default_interface'] == 'lan0'
    assert net_facts_dict['default_gateway'] == '172.19.110.254'
    assert net_facts_dict['interfaces'] == ['lan0']
    assert net_facts_dict['lan0']['device'] == 'lan0'

# Generated at 2022-06-20 18:14:44.273882
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()
    net.module.run_command = lambda x: (0, '/usr/bin/netstat -niw', None)
    net.default_interfaces = {'default_interface': 'lan0',
                              'default_gateway': '10.10.1.1'}
    net.interfaces = {'lan0': {'ipv4': {'address': '10.10.1.2',
                                        'network': '10.10.1.0',
                                        'interface': 'lan0'}}}
    result = net.populate()
    assert result.keys() == ['default_gateway', 'default_interface', 'interfaces', 'lan0']

# Generated at 2022-06-20 18:14:46.130553
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    HPUXNetworkObject = HPUXNetwork()
    assert HPUXNetworkObject.platform == "HP-UX"


# Generated at 2022-06-20 18:14:47.518914
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()



# Generated at 2022-06-20 18:14:58.643464
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.networks.hpux import HPUXNetwork
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule:
        options = None

        def run_command(self, command):
            if command == '/usr/bin/netstat -nr':
                return (0, to_native('default 192.168.20.1 UG lan0'), '')
            return (1, '', 'ERROR')

        def get_bin_path(self, w, req_true=False):
            if w == 'netstat':
                return '/usr/bin/netstat'
            return None

    class FakeAnsibleModule:
        params = {}
        module = None
        runner = None
        argument_spec = {}


# Generated at 2022-06-20 18:15:37.289214
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockModule()
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    device = 'lan0'
    assert interfaces[device]['device'] == device
    assert interfaces[device]['ipv4']['address'] == '192.168.1.24'
    assert interfaces[device]['ipv4']['network'] == '192.168.1.0'
    assert interfaces[device]['ipv4']['interface'] == device


# Generated at 2022-06-20 18:15:43.977268
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hostname = 'localhost'
    network_collector = HPUXNetworkCollector(hostname, hostname)
    assert isinstance(network_collector, NetworkCollector)
    assert (network_collector.hostname == hostname) and (network_collector.dev_name == hostname)



# Generated at 2022-06-20 18:15:52.060309
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:15:59.393453
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    netobj = HPUXNetwork(module=test_module)

    result = netobj.get_interfaces_info()

    test_module.exit_json(changed=False, ansible_facts=dict(
        ansible_net_interfaces=result
        )
    )



# Generated at 2022-06-20 18:16:10.343504
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_obj = HPUXNetwork(module)
    rc = network_obj.populate()
    assert 'default_interface' in rc
    assert 'default_gateway' in rc
    assert 'interfaces' in rc
    assert 'lo0' in rc
    assert 'lan0' in rc
    assert 'lan0' in rc['interfaces']
    assert 'ipv4' in rc['lan0']
    assert 'network' in rc['lan0']['ipv4']
    assert 'interface' in rc['lan0']['ipv4']
    assert 'address' in rc['lan0']['ipv4']

# Generated at 2022-06-20 18:16:14.973552
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_facts = HPUXNetworkCollector()
    assert network_facts._fact_class == HPUXNetwork
    assert network_facts._platform == 'HP-UX'

# Generated at 2022-06-20 18:16:16.360083
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()


# Generated at 2022-06-20 18:16:18.343851
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()


# Generated at 2022-06-20 18:16:25.276665
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    class MockModule(object):
        def get_bin_path(self, arg):
            if arg == 'netstat':
                return '/usr/bin/netstat'
            return None

        def run_command(self, arg):
            if arg == '/usr/bin/netstat -nr':
                return 0, """default 192.168.1.254 UGSc 0 0 lan0
192.168.1.0 192.168.1.254 UGS 0 0 lan0""", None
            if arg == '/usr/bin/netstat -niw':
                return 0, """lan0 192.168.1.101 UGS 0 0 0 0
lan1 192.168.1.102 UGS 0 0 0 0""", None
            return 0, '', ''

    mock_module = MockModule()

# Generated at 2022-06-20 18:16:28.920666
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    import os

    hn = HPUXNetwork()
    hn.module = os
    out = hn.get_default_interfaces()
    assert 'default_interface' in out
    assert 'default_gateway' in out
    assert out['default_interface'] == 'lan2'
    assert out['default_gateway'] == '192.168.100.1'



# Generated at 2022-06-20 18:18:04.777501
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hn = HPUXNetwork()
    result = hn.populate()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '136.199.11.1'
    assert result['interfaces'] == ['lan0']
    assert result['lan0']['device'] == 'lan0'
    assert result['lan0']['ipv4']['address'] == '136.199.11.68'
    assert result['lan0']['ipv4']['network'] == '136.199.11.0'

# Generated at 2022-06-20 18:18:07.602801
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector()
    assert hpux.platform == 'HP-UX'
    assert hpux._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:18:15.049920
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collected_facts = {}

    hn = HPUXNetworkCollector(None, collected_facts=collected_facts)
    # test if object created successfully
    assert hn._platform == 'HP-UX'
    # test if fact_class returns the class HPUXNetwork
    assert hn.fact_class is HPUXNetwork

# Generated at 2022-06-20 18:18:18.082336
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    assert isinstance(network, Network)
    assert network.platform == 'HP-UX'



# Generated at 2022-06-20 18:18:30.636063
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork()
    hpux_network.populate()
    facts = dict(
        default_interface='lan0',
        default_gateway='1.2.3.4',
        interfaces=['lan0'],
        lan0=dict(
            device='lan0',
            ipv4=dict(
                address='1.2.3.5',
                network='1.2.3.0',
                netmask='255.255.255.0',
                network_ipv6='1:2:3:4:5:6:7:8'
            )
        )
    )
    module.exit_json(ansible_facts=dict(network=facts))

# Generated at 2022-06-20 18:18:37.306166
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    network_collector = HPUXNetworkCollector(module=module)
    network_collector.populate()
    result = module.exit_json(ansible_facts=network_collector.get_facts())
    assert 'ansible_net_default_interface' in result['ansible_facts']
    assert 'ansible_net_ipv4' in result['ansible_facts']
    assert 'ansible_net_interface_ip' in result['ansible_facts']



# Generated at 2022-06-20 18:18:39.158440
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    m = HPUXNetwork()
    assert m.platform == 'HP-UX'



# Generated at 2022-06-20 18:18:51.967456
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:18:55.589468
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    pytest_connector = HPUXNetwork()
    assert pytest_connector._fact_class == HPUXNetwork
    assert pytest_connector._platform == 'HP-UX'

# Generated at 2022-06-20 18:18:58.034830
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hux = HPUXNetworkCollector()
    assert hux
    assert hux._platform == 'HP-UX'