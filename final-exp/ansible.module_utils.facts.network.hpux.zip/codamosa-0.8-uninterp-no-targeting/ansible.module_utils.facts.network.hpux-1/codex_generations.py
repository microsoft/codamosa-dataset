

# Generated at 2022-06-20 18:09:44.248288
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Note: The method populate generates a dictionary of network
    facts using the output of the netstat command.
    This test module provides unit test coverage for the data
    gathered by the populate method. If an element of
    collected_facts has the key 'network', then the method populate
    has already been run. The test module relies
    on the data to be present in the 'network' entry. The
    module test_net_module is responsible for generating the
    data used by this test module.
    """
    from ansible.module_utils.facts import cannot_fallback
    from ansible.module_utils.facts.network import Network
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    import ansible.module_utils.facts.network.hpux

    # hpux_network_populate_data is used

# Generated at 2022-06-20 18:09:46.067361
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-20 18:09:48.481082
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork({})
    print(hn)

if __name__ == '__main__':
    test_HPUXNetwork()

# Generated at 2022-06-20 18:09:56.187130
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netstat_output = """dummy output
    default -1 -1 unix 1d 0 unl unknown 0
    22.0.0.0 0.0.0.0 BNR1_0_LAN0_00
    """
    hpu = HPUXNetwork({}, netstat_output)
    result = hpu.get_default_interfaces()
    assert result == {'default_interface': 'BNR1_0_LAN0_00',
                      'default_gateway': '22.0.0.0'}


# Generated at 2022-06-20 18:10:06.878980
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = EmptyModule()
    hpn = HPUXNetwork(module)
    rc, out, err = module.run_command("netstat -nr")
    lines = out.splitlines()
    default_info = {}
    default_gateway = ''
    default_interface = ''
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]
    default_info['default_interface'] = default_interface
    default_info['default_gateway'] = default_gateway
    rc, out, err = module.run_command("netstat -niw")
    lines = out.splitlines()
    interfaces = {}
    for line in lines:
        words

# Generated at 2022-06-20 18:10:09.005488
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXNetwork


# Generated at 2022-06-20 18:10:10.258333
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert isinstance(obj, Network)

# Generated at 2022-06-20 18:10:14.762675
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = type('obj', (object,), {'run_command': lambda x: ('', 'default 192.168.1.1 UG 2 lan0', '')})()
    netobj = HPUXNetwork(test_module)
    assert netobj.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}

# Generated at 2022-06-20 18:10:20.379046
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_fact_class = HPUXNetwork
    default_interfaces = test_fact_class.get_default_interfaces()
    assert 'default_interface' in default_interfaces
    assert 'default_gateway' in default_interfaces


# Generated at 2022-06-20 18:10:24.924772
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Supply arguments as strings
    hw = HPUXNetwork('default_interface', 'interfaces', 'interface_em0')
    # Checks to see if values are correct
    assert hw.default_interface == 'default_interface'
    assert hw.interfaces == 'interfaces'
    assert hw.interface_em0 == 'interface_em0'

# Generated at 2022-06-20 18:10:31.759552
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h = HPUXNetworkCollector()

# Generated at 2022-06-20 18:10:39.125106
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    class options(object):
        def __init__(self, module):
            self.module = module

    class module(object):
        def __init__(self):
            self.params = options(self)
            self.run_command = lambda cmd: (None,
                                            'default 10.0.0.9 UGS 1 1526 lan0 \n'
                                            '10.0.0.0 10.0.0.9 UGS 1 1 lan0',
                                            None)
            self.get_bin_path = lambda cmd: cmd

    class module_util(object):
        def __init__(self):
            self.module = module()

    network_util = HPUXNetwork(module_util())
    network_facts = network_util.populate()

# Generated at 2022-06-20 18:10:43.694902
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpux = HPUXNetwork()
    test_interfaces = hpux.get_interfaces_info()
    assert test_interfaces['lan9']['ipv4']['address'] == '10.114.74.4'



# Generated at 2022-06-20 18:10:56.472295
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils._text import to_bytes
    import json

    module = HPUXNetwork._ansible_module
    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    out = to_bytes(out)
    lines = out.splitlines()
    default_interfaces = {}
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interfaces['default_interface'] = words[4]
                default_interfaces['default_gateway'] = words[1]
    module = HPUXNetwork._ansible_module

# Generated at 2022-06-20 18:11:03.273784
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpux_network = HPUXNetwork()
    interfaces = hpux_network.get_interfaces_info()
    assert 'f0' in interfaces
    assert 'f0' in interfaces['f0']
    assert 'ipv4' in interfaces['f0']
    assert 'address' in interfaces['f0']['ipv4']



# Generated at 2022-06-20 18:11:05.696381
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    This is a simple test of the constructor of the HPUXNetwork class
    """
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'



# Generated at 2022-06-20 18:11:07.725294
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    nm = HPUXNetwork({})
    assert isinstance(nm, HPUXNetwork)

# Generated at 2022-06-20 18:11:17.208485
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()
    network_facts = HPUXNetwork(module).populate()
    expected_network_facts = {'default_interface': 'lan0',
                              'default_gateway': '192.168.1.1',
                              'interfaces': ['lan0'],
                              'lan0': {'device': 'lan0',
                                       'ipv4': {'address': '192.168.1.30',
                                                'network': '192.168.1.0',
                                                'interface': 'lan0'}}}
    assert network_facts == expected_network_facts



# Generated at 2022-06-20 18:11:21.167887
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_facts = HPUXNetworkCollector()
    assert net_facts._fact_class == HPUXNetwork
    assert net_facts._platform == 'HP-UX'


# Generated at 2022-06-20 18:11:31.133488
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork().get_interfaces_info()
    assert isinstance(interfaces, dict, "interfaces is not a dictionary")
    for key in interfaces:
        assert isinstance(key, str, "interface is not a string")
        for key2 in interfaces[key]:
            assert isinstance(key2, str, "key in interface is not a string")
            assert isinstance(interfaces[key][key2], (str, dict), "value in interface is not a string or dict")
            if isinstance(interfaces[key][key2], dict):
                for key3 in interfaces[key][key2]:
                    assert isinstance(key3, str, "key in interface is not a string")
                    assert isinstance(interfaces[key][key2][key3], str, "value in interface is not a string")

# Generated at 2022-06-20 18:11:45.051004
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Create HPUXNetwork class object and examine its instance variables.
    """
    facts = HPUXNetwork()
    assert facts.platform == 'HP-UX'

# Generated at 2022-06-20 18:11:48.939376
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_obj = HPUXNetwork({}, module)
    assert network_obj is not None

# Generated at 2022-06-20 18:11:49.807352
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-20 18:11:52.433765
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Unit test for constructor of class HPUXNetwork"""
    # config = ConfigParser.RawConfigParser()
    pass

# Generated at 2022-06-20 18:12:01.373563
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork()
    network.module = module
    network.module.run_command = MagicMock(return_value=(0, '', ''))

    # test with netstat not found
    network.module.get_bin_path = MagicMock(return_value=None)
    network_facts = network.populate()
    assert network_facts == {}

    # test with netstat found
    network.module.get_bin_path = MagicMock(return_value=True)
    with open('/etc/hosts', 'r') as f:
        network.module.run_command = MagicMock(return_value=(0, f.read(), ''))
    network_facts = network.populate()

# Generated at 2022-06-20 18:12:02.239834
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-20 18:12:06.467843
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    result = test_module.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.10.10.1'



# Generated at 2022-06-20 18:12:16.298567
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    def mock_run_command(args):
        out = "default 192.0.2.1 UG lan0\n"
        return (0, out, '')

    module = MagicMock()
    module.run_command = mock_run_command
    iface = HPUXNetwork(module)
    result = iface.get_default_interfaces()
    assert (result['default_interface'] == 'lan0')
    assert (result['default_gateway'] == '192.0.2.1')


# Generated at 2022-06-20 18:12:29.303333
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = Network()
    test_module.run_command = lambda *args, **kwargs: (0, '', '')
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/bin/netstat'
    test_class = HPUXNetwork()
    test_class.module = test_module

    interfaces = test_class.get_interfaces_info()
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '192.168.56.100'
    assert interfaces['lan0']['ipv4']['network'] == '192.168.56.0'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'



# Generated at 2022-06-20 18:12:36.157396
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert isinstance(network_collector, NetworkCollector)
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork
    assert not hasattr(network_collector, '_netstat_path')

# This class is only for testing

# Generated at 2022-06-20 18:12:58.837817
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    class FakeModule:
        def __init__(self, run_command_rc, run_command_out, run_command_err):
            self.run_command_rc = run_command_rc
            self.run_command_out = run_command_out
            self.run_command_err = run_command_err

        def get_bin_path(self, command):
            path = '/bin/' + command
            return path

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class FakeCollector:
        def __init__(self, module):
            self.module = module
            self.network = HPUXNetwork(self.module)


# Generated at 2022-06-20 18:13:05.259078
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    hpux_network_instance = HPUXNetwork(module)
    hpux_network_instance.get_default_interfaces()
    assert (hpux_network_instance.outbuf == 'default_interface="lan1"'.encode()) or (hpux_network_instance.outbuf == 'default_interface="lan0"'.encode())


# Generated at 2022-06-20 18:13:17.298892
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Test get_interfaces_info method of HPUXNetwork class"""
    out_str = "lan0     Link encap:Ethernet  HWaddr d4:ae:52:4c:67:1d    " \
              " UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1    " \
              "RX packets:0 errors:0 dropped:0 overruns:0 frame:0    " \
              "TX packets:91 errors:0 dropped:0 overruns:0 carrier:0    " \
              "collisions:0 txqueuelen:0    " \
              "RX bytes:0 (0.0 b)  TX bytes:96821 (94.6 Kb)    "
    lines = out_str.splitlines()
    interfaces = {}

# Generated at 2022-06-20 18:13:29.275889
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Unit test for method HPUXNetwork.get_default_interfaces
    """
    # Default interface is not set
    network = HPUXNetwork()
    expected_result = {
        'default_gateway': '192.168.1.1',
        'default_interface': 'lan0',
    }
    out = 'default   192.168.1.0        UG   0 0         lan0'
    assert network.get_default_interfaces() == expected_result
    # Default interface is set
    network = HPUXNetwork()
    out = 'default   192.168.1.0        UG   0 0         lan0\n' \
          'default   192.168.1.0        UG   0 0         lan1\n'

# Generated at 2022-06-20 18:13:33.431776
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module)
    network = HPUXNetwork(network_collector)
    assert not network.populate()

# Generated at 2022-06-20 18:13:41.329897
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class Module:
        @staticmethod
        def run_command(command):
            results = "lan0 0.0.0.0 128.0.0.0 UP 00:14:4f:40:69:bf\nlan1 127.0.0.1 255.0.0.0 UP 00:0e:ec:a2:03:43\n"
            out = ''
            err = ''
            rc = 0
            return rc, results, err
        @staticmethod
        def get_bin_path(name):
            return "/usr/bin/%s" % (name)
    module = Module()
    testclass = HPUXNetwork(module)
    interfaces = testclass.get_interfaces_info()

# Generated at 2022-06-20 18:13:44.379229
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    expected_output = {
        "default_interface": None,
        "default_gateway": None,
        "interface_eth0": None,
        "interfaces": None
    }
    test_obj = HPUXNetwork()
    test_obj.populate()
    output = test_obj.get_facts()
    assert output == expected_output

# Generated at 2022-06-20 18:13:53.847899
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()

    netstat_path = module.get_bin_path('netstat')
    if netstat_path is None:
        return

    hpuXNetwork = HPUXNetwork(module)
    default_interfaces = hpuXNetwork.get_default_interfaces()

    assert(default_interfaces['default_interface'] == 'lan0')
    assert(default_interfaces['default_gateway'] == '192.168.0.1')



# Generated at 2022-06-20 18:14:00.429200
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:14:11.297315
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan4'
    assert network_facts['default_gateway'] == '10.100.100.1'
    assert network_facts['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3',
                                           'lan4', 'lan5', 'lan6', 'lan7',
                                           'lo0', 'lo1']
    assert network_facts['lan0'] == {'device': 'lan0'}
    assert network_facts['lan1'] == {'device': 'lan1'}
    assert network_facts['lan2'] == {'device': 'lan2'}

# Generated at 2022-06-20 18:14:23.345865
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-20 18:14:29.602212
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_facts = HPUXNetwork(test_module)
    interfaces = network_facts.get_interfaces_info()
    assert interfaces['lan0'] == 'lan0'

# Generated at 2022-06-20 18:14:36.119371
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    import mock
    import sys
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    m = mock.mock_module.MockModule('/dev/null')
    c = collector.ModuleCollector(m, network_fact_class=HPUXNetworkCollector)
    assert isinstance(c.network, HPUXNetworkCollector)

# Generated at 2022-06-20 18:14:47.903109
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    nm = HPUXNetwork(module)
    collected_facts = {}
    collected_facts['ansible_collect_network'] = 'True'
    facts = nm.populate(collected_facts)
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '192.168.1.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '192.168.1.4'
    assert facts['lan0']['ipv4']['network'] == '192.168.1.0'



# Generated at 2022-06-20 18:14:58.534693
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    '''Unit test for method get_default_interfaces of class HPUXNetwork'''

    module = AnsibleModule(argument_spec=dict())

    # Create an instance of HPUXNetwork
    network = HPUXNetwork(module)

    # Set the netstat output
    rc = 0
    out = '''default 192.168.1.1 UG lan0
192.168.1.0 192.168.1.1 U lan0
'''
    err = None

    # Execute the get_default_interfaces method
    default_interface = network.get_default_interfaces()

    # Assert the result
    assert default_interface == {'default_gateway': '192.168.1.1',
                                 'default_interface': 'lan0'}



# Generated at 2022-06-20 18:15:06.107868
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    result = network.populate()
    interfaces = result['interfaces']
    assert len(interfaces) >= 0
    for interface in interfaces:
        assert result[interface]['ipv4']['address'] != '0.0.0.0'
    assert result['default_interface'] != 'None'
    assert result['default_gateway'] != 'None'



# Generated at 2022-06-20 18:15:10.752795
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Create a HPUXNetwork object and verify that the platform attribute
    is set correctly.
    """
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'

# Generated at 2022-06-20 18:15:13.209411
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'



# Generated at 2022-06-20 18:15:17.954349
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()

    network.module.run_command = mock_run_command
    default_interfaces_facts = network.get_default_interfaces()
    default_interface = default_interfaces_facts['default_interface']
    default_gateway = default_interfaces_facts['default_gateway']

    assert default_interface == 'lan4'
    assert default_gateway == '20.1.0.1'



# Generated at 2022-06-20 18:15:27.226446
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class HPUXNetwork """
    import module_utils.facts.network.hpux as hpux_module

    # Make a mock ansible module object

# Generated at 2022-06-20 18:15:53.549591
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_collector = HPUXNetworkCollector()
    assert hpux_collector is not None
    assert hpux_collector.platform == 'HP-UX'
    assert hpux_collector.fact_class == HPUXNetwork

# Generated at 2022-06-20 18:15:56.951501
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetwork(module)
    assert not network_collector.collected_facts


# Generated at 2022-06-20 18:15:59.588616
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(dict(), dict())
    assert network.platform == 'HP-UX'


# Generated at 2022-06-20 18:16:11.417513
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = {'run_command.return_value': (0, "", "")}
    network = HPUXNetwork(m)

    # Test when netstat is missing
    result = network.populate()
    assert result == {}

    m = {'run_command.return_value': (0, "", "")}
    network = HPUXNetwork(m)
    m['get_bin_path.return_value'] = '/bin/netstat'

    # Test when the output of netstat is empty
    result = network.populate()
    assert result == {'interfaces': [], 'default_interface': '', 'default_gateway': ''}

    m = {'run_command.return_value': (0, "default 172.24.21.129  UG        0 0        0 lan1", "")}


# Generated at 2022-06-20 18:16:13.631354
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network1 = HPUXNetwork({})
    assert network1


# Generated at 2022-06-20 18:16:18.417333
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = None
    net_facts = HPUXNetwork(module)
    network_facts = net_facts.populate()
    assert network_facts['default_interface'] is not None
    assert network_facts['default_gateway'] is not None

# Generated at 2022-06-20 18:16:20.429503
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class == HPUXNetwork



# Generated at 2022-06-20 18:16:21.686318
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-20 18:16:25.598787
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_class = HPUXNetwork()
    out = """default 192.168.1.0 UG 0 0 lan1
192.168.1.0 127.0.0.1 UG 0 0 lo0
192.168.1.0 192.168.1.1 U 0 0 lan1"""
    default_interfaces_facts = test_class.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan1'
    assert default_interfaces_facts['default_gateway'] == '192.168.1.0'

# Generated at 2022-06-20 18:16:33.427963
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hostname = 'test_HPUXNetwork_hostname'
    custom_path = 'test_HPUXNetwork_custom_path'

    if_path = HPUXNetwork(module=None, custom_path=custom_path).get_device_path()
    assert if_path == custom_path
    hostname = HPUXNetwork(module=None).get_hostname()
    assert hostname == ""

# Generated at 2022-06-20 18:17:43.375818
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import sys
    import os
    import inspect

    # Avoid missing libs due to not having a real PYTHONPATH
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    sys.path.append(root)

    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector

    test_module = type('test_module', (object,), dict(params={}, check_mode=False))
    test_network = HPUX

# Generated at 2022-06-20 18:17:51.350837
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Unit test for method populate of class HPUXNetwork."""

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    class DummyModule:
        def run_command(self, command):
            return (0, "default 10.2.3.4 UGS 8 0 en0\n", "")

        def get_bin_path(self, command):
            return command

    dummy_module = DummyModule()
    hpux_network = HPUXNetwork(dummy_module)

    output = hpux_network.populate()


# Generated at 2022-06-20 18:17:59.313424
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = MockModule()
    test_module.run_command = lambda x: (0, test_netstat, "")
    network = HPUXNetwork()
    network.module = test_module
    test_facts = network.populate()
    assert test_facts['default_interface'] == "lan1"
    assert test_facts['default_gateway'] == "172.16.0.254"
    assert test_facts['interfaces'] == ['lan1', 'lan0']
    assert test_facts['lan1'] == {'ipv4': {'interface': 'lan1', 'address': '172.16.0.100', 'network': '172.16.0.0'}, 'device': 'lan1'}

# Generated at 2022-06-20 18:18:10.594228
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, command: (0,
            'Active Routes:\n\
            default\t10.1.1.1\t0\t0\tlans2\n\
            default\t10.2.2.2\t0\t0\tlans3\n', ''),
        'get_bin_path': lambda self, command: '/usr/bin/netstat'
        })()
    network_instance = HPUXNetwork(mock_module)
    default_interfaces = network_instance.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lans2',
                                  'default_gateway': '10.1.1.1'}



# Generated at 2022-06-20 18:18:19.860118
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))
    test_module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')

# Generated at 2022-06-20 18:18:22.673181
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Create the object and call it's populate method
    """
    hpux_network = HPUXNetwork()
    hpux_network.populate()


if __name__ == '__main__':
    test_HPUXNetwork()

# Generated at 2022-06-20 18:18:24.178240
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    assert HPUXNetwork.platform == "HP-UX"

# Generated at 2022-06-20 18:18:26.889259
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    platform_facts = HPUXNetwork()
    assert platform_facts.platform == 'HP-UX'

# Generated at 2022-06-20 18:18:30.569982
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hu = HPUXNetwork()
    hu.module = DummyModule()
    hu.module.run_command = lambda x: (0, 'lo0   lan0  lan1  lan2', '')
    result = hu.get_default_interfaces()
    assert result == {'default_interface': 'lan2', 'default_gateway': '0.0.0.0'}



# Generated at 2022-06-20 18:18:37.216518
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Test the constructor of class HPUXNetworkCollector
    """
    hpux_net_collector_obj = HPUXNetworkCollector()
    assert hpux_net_collector_obj._fact_class == HPUXNetwork
    assert hpux_net_collector_obj._platform == 'HP-UX'