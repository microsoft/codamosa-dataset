

# Generated at 2022-06-20 18:09:34.713743
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'



# Generated at 2022-06-20 18:09:36.991352
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    assert hpn.platform == 'HP-UX'


# Generated at 2022-06-20 18:09:46.905412
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={'gather_subset': dict(default=[], type='list')})
    # Using the class directly so I can swap out the module to make sure
    # run_command is called correctly
    hpux_net = HPUXNetwork(module=module)

    # Make sure the netstat call works
    hpux_net.module.run_command = Mock(return_value=(0, 'netstat test', ''))
    hpux_net.get_default_interfaces = Mock(
        return_value={'default_interface': 'lan0',
                      'default_gateway': '10.10.10.1'})

# Generated at 2022-06-20 18:09:56.788208
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    facts = HPUXNetwork()
    default_interface, default_gateway, interfaces, interface_info = facts.populate()
    assert default_interface == 'lan0'
    assert default_gateway == '10.6.0.1'
    assert interfaces == ['lan0']
    assert interface_info['lan0']['device'] == 'lan0'
    assert interface_info['lan0']['ipv4']['address'] == '10.6.0.5'
    assert interface_info['lan0']['ipv4']['network'] == '10.6.0.0'
    assert interface_info['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-20 18:10:04.078263
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list', elements='str'),
                           filter=dict(type='list', elements='str')),
        supports_check_mode=True)
    nm = HPUXNetwork(module=module)
    out = nm.populate()
    print(to_bytes(out))



# Generated at 2022-06-20 18:10:14.977319
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.utils.path import makedirs_safe
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2


# Generated at 2022-06-20 18:10:16.371246
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork.platform == 'HP-UX'

# Generated at 2022-06-20 18:10:20.810231
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpux_network = HPUXNetwork(dict())
    print(hpux_network)


# Generated at 2022-06-20 18:10:24.840744
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert (HPUXNetworkCollector._platform == 'HP-UX')
    assert (HPUXNetworkCollector._fact_class == HPUXNetwork)


# Generated at 2022-06-20 18:10:33.287465
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class ModuleStub():
        @staticmethod
        def run_command(cmd):
            return (0, 'lan1000 100 200', '')

    class HPUXNetworkStub(HPUXNetwork):
        def __init__(self):
            self.module = ModuleStub()

    hn = HPUXNetworkStub()
    interfaces = hn.get_interfaces_info()
    assert 'lan1000' in interfaces

# Generated at 2022-06-20 18:10:44.212832
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MagicMock()
    default_interfaces_facts = HPUXNetwork(module).get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.0.2.1'


# Generated at 2022-06-20 18:10:56.670691
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector"""


# Generated at 2022-06-20 18:11:01.740277
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hostname = 'hparamore.mydomain.com'
    domain = 'mydomain.com'
    host = HPUXNetwork(hostname, domain)
    assert host.domain == domain
    assert host.hostname == hostname


# Generated at 2022-06-20 18:11:09.744667
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = Network()
    module.run_command = lambda x, **kwargs: (0,
    '''
    Name  Mtu  Network    Address       Ipkts  Ierrs Idrop Opkts  Oerrs  Coll  Queue
lan0:  1500  -          00:00:7a:1c:0c:9f   5382     0     0    727     0     0     0
lan1:  1500  -          00:00:7a:1c:0c:9f   5382     0     0    727     0     0     0
lan2:  1500  -          00:00:7a:1c:0c:9f   5382     0     0    727     0     0     0''', '')

# Generated at 2022-06-20 18:11:16.996455
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
                                                  "default 192.168.1.1 UG lan1500",
                                                  ""))
    default_interfaces = HPUXNetwork(module).get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan1500'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-20 18:11:19.874952
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()

    assert network is not None
    assert network.platform == 'HP-UX'

# Generated at 2022-06-20 18:11:23.756959
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c._fact_class == HPUXNetwork
    assert c._platform == 'HP-UX'


# Generated at 2022-06-20 18:11:32.331211
# Unit test for method get_default_interfaces of class HPUXNetwork

# Generated at 2022-06-20 18:11:34.592884
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network
    assert network.platform == "HP-UX"


# Generated at 2022-06-20 18:11:43.939433
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ))
    obj = HPUXNetwork(module)
    default_interfaces = obj.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan900'
    assert default_interfaces['default_gateway'] == '0.0.0.0'


# Generated at 2022-06-20 18:12:01.551234
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class AnsibleModule(object):
        @staticmethod
        def run_command(*cmd):
            class Result(object):
                rc = 0
                stdout = (
                    "lan0: flags=5e080863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GRP,64>\n"
                    " inet 30.16.1.10 netmask ffffff00 broadcast 30.16.1.255\n"
                    " lan1: flags=5e080863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GRP,64>\n"
                    " inet 30.16.1.42 netmask ffffff00 broadcast 30.16.1.255\n"
                    )

# Generated at 2022-06-20 18:12:03.667634
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.populate()

# Generated at 2022-06-20 18:12:07.826087
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu_netw = HPUXNetwork(dict())
    # Test if the attribute _platform is set correctly
    assert hpu_netw._platform == 'HP-UX'
    # Test if the attribute _fact_class is set correctly
    assert hpu_netw._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:12:17.765376
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.populate() == {
        'default_interface': 'lan0',
        'default_gateway': '10.63.80.254',
        'interfaces': ['lan0'],
        'lan0': {'device': 'lan0',
                 'ipv4': {'address': '10.63.80.209',
                          'network': '10.63.80.0',
                          'interface': 'lan0',
                          'address': '10.63.80.209'}}}


# Generated at 2022-06-20 18:12:30.136510
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins

    test_obj = HPUXNetwork()

    # Create mocks for test.
    class MockRunCommand:
        def __init__(self):
            self.result = (0, "default 192.168.0.1 UGS 0 5 lan0\n", "")

        def __call__(self, module, cmd):
            return self.result

    builtins.run_command = MockRunCommand()

    test_obj.module = Mock()
    test_obj.module.run_command = MockRunCommand()


# Generated at 2022-06-20 18:12:37.672257
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '172.16.2.254'
    assert network_facts['lan0']['ipv4']['address'] == '172.16.2.166'
    assert network_facts['lan0']['ipv4']['network'] == '172.16.2.0'


# Generated at 2022-06-20 18:12:40.000667
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpuxnet_collector = HPUXNetworkCollector()
    assert hpuxnet_collector._fact_class == HPUXNetwork
    assert hpuxnet_collector._platform == 'HP-UX'



# Generated at 2022-06-20 18:12:42.523879
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    assert hpn.platform == 'HP-UX'


# Generated at 2022-06-20 18:12:52.165695
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import os

    hpn = HPUXNetwork()
    hpn.module = type("AnsibleModule", (object,),
                      {'run_command': fake_run_command})
    hpn.module.get_bin_path = lambda cmd: '/usr/bin/netstat'
    hpn.populate()

    if os.environ.get('TEST_NET_HPUX') == '1':
        def_if = hpn.facts['default_interface']
        def_gw = hpn.facts['default_gateway']
        assert def_gw == '192.168.0.1'
        assert def_if == 'lan0'
    else:
        print("HP-UX test skipped because TEST_NET_HPUX env variable is not set.")



# Generated at 2022-06-20 18:13:01.955412
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    def get_bin_path(cmd):
        return "/usr/bin/netstat"

    # create an instance of HPUXNetwork
    # and assign self.module to the mock object
    obj = HPUXNetwork()
    setattr(obj.module, 'get_bin_path', get_bin_path)

    # create the expected output
    expected = {'interfaces': ['lan0'],
                'lan0': {'ipv4': {'network': '192.168.0.0',
                                  'interface': 'lan0',
                                  'address': '192.168.0.93'}}}

    # collect and assign facts
    collected_facts = obj.populate()

    # check if all expected keys are in the collected_facts dictionary

# Generated at 2022-06-20 18:13:27.020818
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    '''
    Test method get_default_interfaces of class HPUXNetwork
    '''
    hpux_network_obj = HPUXNetwork()
    default_interfaces_facts = hpux_network_obj.get_default_interfaces()
    assert type(default_interfaces_facts) is dict
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts


# Generated at 2022-06-20 18:13:28.964792
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork


# Generated at 2022-06-20 18:13:29.783056
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    pass

# Generated at 2022-06-20 18:13:31.097352
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass


# Generated at 2022-06-20 18:13:35.622417
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_collector = HPUXNetworkCollector(module=module)
    network_collector.collect()
    network_collector.populate()



# Generated at 2022-06-20 18:13:37.249081
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:13:41.270492
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = MockModule()
    hpuxnet = HPUXNetwork(module)
    assert hpuxnet.module == module
    assert hpuxnet.platform == 'HP-UX'


# Generated at 2022-06-20 18:13:42.618975
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj
    assert obj.supported

# Generated at 2022-06-20 18:13:44.662130
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork is not None

if __name__ == '__main__':
    test_HPUXNetwork()

# Generated at 2022-06-20 18:13:47.535990
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork("test_module")
    assert network._platform == "HP-UX"


# Generated at 2022-06-20 18:14:29.821846
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpuxnc = HPUXNetworkCollector()
    assert isinstance(hpuxnc, NetworkCollector)
    assert hpuxnc._fact_class == HPUXNetwork
    assert hpuxnc._platform == 'HP-UX'


# Generated at 2022-06-20 18:14:31.274617
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    return HPUXNetworkCollector()

# Generated at 2022-06-20 18:14:34.778395
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    sut = HPUXNetworkCollector()
    assert (sut._fact_class == HPUXNetwork)
    assert (sut._platform == 'HP-UX')

# Generated at 2022-06-20 18:14:47.672718
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()

    h_HPUXNetwork = HPUXNetwork(module)
    h_HPUXNetwork.populate()

    assert module.params['gather_subset'] == ['!all', '!min']
    assert h_HPUXNetwork.default_interface == 'lan5'
    assert h_HPUXNetwork.default_gateway == '10.10.10.1'
    assert h_HPUXNetwork.netmask == '255.255.255.0'
    assert h_HPUXNetwork.interfaces == ['lan5']

# Generated at 2022-06-20 18:14:49.938385
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass



# Generated at 2022-06-20 18:14:53.932097
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork()
    network_facts.populate(module.params)



# Generated at 2022-06-20 18:14:55.994231
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork(module=None)
    assert isinstance(net, HPUXNetwork)
    assert net.platform == 'HP-UX'

# Generated at 2022-06-20 18:15:04.087056
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # create a module for testing
    module = AnsibleModule(argument_spec={})
    # set up Network
    network_facts = HPUXNetwork(module)

    # call the method populate
    network_facts.populate()
    # test the value of network_facts['default_gateway']
    assert network_facts['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-20 18:15:05.841219
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpxNetwork = HPUXNetwork({})
    assert hpxNetwork.get_interfaces_info()

# Generated at 2022-06-20 18:15:10.474628
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hp_collector = HPUXNetworkCollector()
    assert hp_collector.platform == 'HP-UX'
    assert hp_collector.fact_class == HPUXNetwork


# Generated at 2022-06-20 18:16:30.573551
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:16:34.994680
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import ModuleTestCase

    module = ModuleTestCase.get_module_mock()
    module.run_command.return_value = (0, "/usr/bin/netstat -niw\n"
                                           "Name    Mtu   Network  Address         Ipkts Ierrs ", "")
    network_obj = HPUXNetwork()
    interfaces = network_obj.get_interfaces_info()
    assert(interfaces == {})


# Generated at 2022-06-20 18:16:38.630253
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network_obj = HPUXNetwork(None)
    interfaces = network_obj.get_interfaces_info()
    print("Interfaces: %s" % interfaces)
    assert len(interfaces) > 0
    assert 'lan1' in interfaces.keys() or 'lan0' in interfaces.keys()
    assert 'lan0' in interfaces.keys() or 'lan1' in interfaces.keys()


# Generated at 2022-06-20 18:16:40.793759
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    isinstance(HPUXNetworkCollector(), NetworkCollector)

# Generated at 2022-06-20 18:16:51.072407
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPUXNetworkMock:

        def run_command(self, cmd):
            return (0,
                    'lan0      16       0           0     0     0     0     0         2 0   0   0   0   0   0   0   0   0 -\n'
                    'lan1000   16       0           0     0     0     0     0         2 0   0   0   0   0   0   0   0   0 -\n',
                    '')

    hpux_network = HPUXNetwork()
    hpux_network.module = HPUXNetworkMock()

    interfaces = hpux_network.get_interfaces_info()
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan1000']['device'] == 'lan1000'

# Generated at 2022-06-20 18:16:56.580028
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-20 18:17:00.484183
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class module:
        def run_command(self, command):
            return (0,
                    "default 127.0.0.0 UG 12 0 0 lan0",
                    "")
    class HPUXNetwork:
        module = module()
    h = HPUXNetwork()
    default_interfaces = h.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0',
                                  'default_gateway': '127.0.0.0'}


# Generated at 2022-06-20 18:17:08.700928
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    net_ = HPUXNetwork(module)
    default_interfaces = net_.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '0'


# Generated at 2022-06-20 18:17:12.248736
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector.platform == 'HP-UX'


# Generated at 2022-06-20 18:17:20.640444
# Unit test for method populate of class HPUXNetwork