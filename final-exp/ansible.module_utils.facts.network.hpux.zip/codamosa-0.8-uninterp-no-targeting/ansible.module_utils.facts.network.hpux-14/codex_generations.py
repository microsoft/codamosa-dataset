

# Generated at 2022-06-20 18:09:41.089691
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModuleMock()
    net_collector = HPUXNetworkCollector(module)
    assert net_collector._fact_class == HPUXNetwork
    assert net_collector._platform == 'HP-UX'


# Generated at 2022-06-20 18:09:44.382379
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of class HPUXNetworkCollector
    """
    hpu = HPUXNetworkCollector()
    assert hpu.platform == 'HP-UX'


# Generated at 2022-06-20 18:09:45.073960
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-20 18:09:47.856860
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpu = HPUXNetworkCollector()
    assert isinstance(hpu, HPUXNetworkCollector)



# Generated at 2022-06-20 18:09:50.049486
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork(dict())
    result = net.get_interfaces_info()
    assert result is not None

# Generated at 2022-06-20 18:09:53.129659
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'


# Generated at 2022-06-20 18:09:59.694626
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockAnsibleModule()
    module.run_command = Mock()
    module.run_command.return_value = (0, 'default 10.0.0.1 UG lan2', '')

    HPUXNetworkFactory(module).get_default_interfaces()

    module.run_command.assert_called_with("/usr/bin/netstat -nr")



# Generated at 2022-06-20 18:10:01.571732
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    a = HPUXNetworkCollector()
    assert isinstance(a, HPUXNetworkCollector)

# Generated at 2022-06-20 18:10:14.598216
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test = HPUXNetwork()

# Generated at 2022-06-20 18:10:20.738015
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import ansible.module_utils.facts.network.hpux.HPUXNetwork as HPUXNetwork
    my_network = HPUXNetwork()
    interfaces = my_network.get_interfaces_info()
    print("Interfaces: " + str(interfaces))
    assert interfaces is not None



# Generated at 2022-06-20 18:10:31.476491
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interfaces_info = network.get_interfaces_info()
    assert 'lan0' in interfaces_info
    assert 'lan2000' in interfaces_info


# Unit tests for method get_default_interfaces of class HPUXNetwork

# Generated at 2022-06-20 18:10:39.067342
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'default 10.0.0.1 UG lan0', ''))
    module.run_command = Mock(return_value=(0, 'lan0 192.168.0.5 255.255.255.0 UHF lan0', ''))
    module.run_command = Mock(return_value=(0, 'lan0 10.0.0.11 255.255.255.0 UHF lan0', ''))
    module.run_command = Mock(return_value=(0, 'lan0 192.168.0.3 255.255.255.0 UHF lan0', ''))
    network = HPUXNetwork(module=module, collected_facts=None)


# Generated at 2022-06-20 18:10:48.237006
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    demo_netstat_1 = "Routing tables\n\
\n\
Destination          Gateway            Flags   Refs    Use  If\n\
default              10.11.12.1         UG          0    6  lan0\n\
10.11.12            lan0               UG          0   76  lan0\n\
10.11.12            lan1               UG          0   10  lan1\n\
10.11.12            lan2               UG          0   14  lan2\n\
10.11.12.1          10.11.12.1         UH          0    0  lan0"


# Generated at 2022-06-20 18:10:50.962248
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_module = Network()
    assert test_module.platform == 'HP-UX'


# Generated at 2022-06-20 18:10:54.409440
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(None)
    assert network.platform == 'HP-UX'


# Generated at 2022-06-20 18:11:05.553572
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpuxnetwork = HPUXNetwork()

    rc = 0
    out = '''default 10.0.0.1 UGS 0 0 0 lan0
    10.0.0.0 lan0 U 0 0 0 lan0'''
    err = ''
    hpuxnetwork.module.run_command = lambda x: (rc, out, err)

    default_interfaces = hpuxnetwork.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'



# Generated at 2022-06-20 18:11:07.007409
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:11:18.114595
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hn = HPUXNetwork()
    test_out = '''netstat: /usr/lib/libsec.so.1: no version information available (required by netstat)
Name Link Mtu Network Address Ipkts Ierrs Idrop Opkts Oerrs Coll  
lan0   UP 1500 <Link#1> 1.2.3.4 0 0 0 0 0 0
lan2   UP 1500 <Link#3> 5.6.7.8 0 0 0 0 0 0
lan3   UP 1500 <Link#4> 9.10.11.12 0 0 0 0 0 0'''
    out = hn.get_interfaces_info()

# Generated at 2022-06-20 18:11:19.716573
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()



# Generated at 2022-06-20 18:11:30.286448
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpux_network = HPUXNetwork()

# Generated at 2022-06-20 18:11:48.639590
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:11:51.990769
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Unit test for constructor of class HPUXNetwork"""
    hpux_network = HPUXNetwork()
    assert hpux_network is not None

# Generated at 2022-06-20 18:11:56.433582
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.__class__.__name__ == 'HPUXNetworkCollector'
    assert collector._fact_class.__name__ == 'HPUXNetwork'
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-20 18:12:02.234416
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    assert network_collector.platform == "HP-UX"
    assert network_collector.fact_class == HPUXNetwork


# Generated at 2022-06-20 18:12:02.833527
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:12:06.082396
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'

# Generated at 2022-06-20 18:12:14.034036
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    facts = {'module_setup': True}
    module = FakeModule(facts)
    network = HPUXNetwork(module=module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-20 18:12:16.386809
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network._fact_class == HPUXNetwork
    assert network._platform == 'HP-UX'

# Generated at 2022-06-20 18:12:29.302773
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net_info = HPUXNetwork()

# Generated at 2022-06-20 18:12:33.817173
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_collector = HPUXNetworkCollector()
    assert hpux_collector.platform == 'HP-UX'
    assert hpux_collector._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:12:54.927866
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net_obj = HPUXNetwork()
    assert net_obj._platform == 'HP-UX'
    assert net_obj._fact_class == Network


# Generated at 2022-06-20 18:13:06.656792
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ Check that default default_interface and default_gateway are the same
    as on the host where the unit test is run.
    """
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.run_command.return_value = (0, "", "")

    network = HPUXNetwork()
    network.module = module
    network_facts = network.populate()

    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]

    assert network_facts

# Generated at 2022-06-20 18:13:10.912271
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    '''
    Unit test for constructor of class HPUXNetworkCollector
    '''
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:13:12.833917
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork(None)


# Generated at 2022-06-20 18:13:15.633873
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Test class constructor"""
    nc = HPUXNetworkCollector()
    assert nc.platform == 'HP-UX'
    assert nc._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:13:16.799297
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector(None)

# Generated at 2022-06-20 18:13:25.283161
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpux_network = HPUXNetwork({})
    default_interfaces_facts = hpux_network.get_default_interfaces()
    assert isinstance(default_interfaces_facts, dict)
    assert default_interfaces_facts == {
        'default_interface': 'lan0',
        'default_gateway': '10.10.10.9',
    }


# Generated at 2022-06-20 18:13:34.793493
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = Mock(name='module')
    module.run_command.return_value = (0, 'default 127.0.0.0 UGSc 2 0 lan9000 ', '')

    network_facts = HPUXNetwork(module)

    default_interfaces = network_facts.get_default_interfaces()

    assert default_interfaces == {'default_interface': 'lan9000',
                                  'default_gateway': '127.0.0.0'}



# Generated at 2022-06-20 18:13:46.518424
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    def run_command_mock(cmd):
        out = """
        Name  Mtu   Network       Address            Ipkts Ierrs     Opkts Oerrs  Queue

lan0   1500  192.168.122.0   192.168.122.234  144476     0   183348     0      0
lan1   1500  10.10.10.0      10.10.10.234     131936     0   139493     0      0
        """
        return (0, out, '')

    def get_bin_path_mock(cmd):
        return '/usr/bin/netstat'

    class MockModule(object):
        def __init__(self):
            self.run_

# Generated at 2022-06-20 18:13:52.518347
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    '''
    Test for HPUXNetwork class.
    :return:
    '''
    hpx_network_obj = HPUXNetwork()
    hpx_network_interfaces = hpx_network_obj.get_interfaces_info()
    print(hpx_network_interfaces)

# Generated at 2022-06-20 18:14:35.982360
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    test_module.run_command = MagicMock(return_value=(0, 'default  10.1.1.1        UG    0        0        lan0', ''))
    result = HPUXNetwork(test_module).get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.1.1.1'

# Generated at 2022-06-20 18:14:40.677131
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network = HPUXNetworkCollector()
    assert hpux_network._platform == 'HP-UX'
    assert hpux_network._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 18:14:45.962437
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    net_collector = NetworkCollector()
    network_collector = net_collector.collector
    for nc in network_collector:
        try:
            nc.populate()
            nc.get_default_interfaces()
            nc.get_interfaces_info()
        except:
            network_collector.remove(nc)

# Generated at 2022-06-20 18:14:57.313307
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpux_network = HPUXNetwork()
    rc, out, err = hpux_network.module.run_command("/usr/bin/netstat -niw")
    interfaces = hpux_network.get_interfaces_info()
    assert len(interfaces) == 2
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert interfaces['lan0']['ipv4']['address'] == '172.16.2.1'
    assert interfaces['lan1']['ipv4']['address'] == '172.16.2.2'



# Generated at 2022-06-20 18:15:04.655003
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )

    hpux_network = HPUXNetwork(module)
    network_facts = hpux_network.populate()
    for key in network_facts:
        assert network_facts[key] is not None

# Generated at 2022-06-20 18:15:05.577285
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-20 18:15:17.397871
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for HPUXNetwork get_interfaces_info."""
    class ModuleStub():
        def run_command(self, arg):
            self.run_command_args = arg
            if arg == "/usr/bin/netstat -niw":
                return (0, "lan0\t2\t16909056\t00:0c:29:3e:6f:7c\t16909056 lan0\n", "")
            else:
                return (0, "", "")

    class FactsHPUXNetworkCollectorStub(HPUXNetworkCollector):
        """Stub of HPUXNetworkCollector."""
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-20 18:15:18.087186
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.populate() is not None

# Generated at 2022-06-20 18:15:27.151273
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mock_module = MockModule()
    network = HPUXNetwork(mock_module)
    network.populate()

    facts = {'default_gateway': '10.1.1.1',
             'default_interface': 'lan0',
             'interfaces': ['lan0', 'lan1'],
             'lan0': {'device': 'lan0',
                      'ipv4': {'address': '10.1.1.3',
                               'network': '10.1.1.0'}},
             'lan1': {'device': 'lan1',
                      'ipv4': {'address': '10.2.2.3',
                               'network': '10.2.2.0'}}}

    assert facts == network.facts


# Generated at 2022-06-20 18:15:38.048336
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    cluster_module = AnsibleModule(argument_spec={})
    hpuxtest = HPUXNetwork(cluster_module)
    rc, out, err = hpuxtest.module.run_command("/usr/bin/netstat -nr")
    cluster_module.run_command = MagicMock(return_value=(rc, out, err))
    default_interface_facts = hpuxtest.get_default_interfaces()
    assert default_interface_facts == {'default_interface': 'lan0',
                                       'default_gateway': '10.21.33.254'}


# Generated at 2022-06-20 18:17:09.198774
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """ This test case tests the get_interfaces_info method
    """
    test_obj = HPUXNetwork()
    test_obj._get_interfaces_info()
    assert test_obj['eth0']['ipv4']['address'] == '10.0.0.1'

# Generated at 2022-06-20 18:17:20.001483
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import sys

    if sys.version_info.major >= 3:
        from unittest.mock import Mock
    else:
        from mock import Mock

    sample_data = '''
Routing Tables:
Destination        Gateway           Flags Refs Use  Intr  If
default            192.168.125.1     UG        1     0  lan9
192.168.125.0      lan9              UC        0     0  lan9
192.168.125.0      192.168.125.1     UHSb      0     0   lo0
loopback           127.0.0.0         US        0   187   lo0
'''

    def mock_run_command(self, command, check_rc=True):
        return (0, sample_data, None)

    module = Mock()
    module.run_command

# Generated at 2022-06-20 18:17:28.721326
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_mod = AnsibleModule(argument_spec=dict())
    test_mod.run_command = MagicMock(return_value=(0, 'default 192.168.33.1 UG lan1', ''))
    network = HPUXNetwork(test_mod)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan1'
    assert network_facts['default_gateway'] == '192.168.33.1'


# Generated at 2022-06-20 18:17:40.843759
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fact_subclass = HPUXNetwork()
    fact_subclass.module = AnsibleModuleMock()
    facts = fact_subclass.populate()
    assert facts['interfaces'] == ['lan0', 'lo0']
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.2.2'
    assert facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert facts['lo0']['ipv4']['network'] == '127.0.0.0'

# Generated at 2022-06-20 18:17:50.510540
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    HPUXModule = MockModule({})
    HPUXNetwork = HPUXNetwork(HPUXModule)
    return_value = HPUXNetwork.populate()
    assert return_value['interfaces'] == ['lan0', 'lan1']
    assert return_value['default_interface'] == 'lan0'
    assert return_value['lan0']['device'] == 'lan0'
    assert return_value['lan0']['ipv4']['address'] == '10.0.0.2'
    assert return_value['lan0']['ipv4']['network'] == '10.0.0.0'
    assert return_value['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-20 18:17:58.542676
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # create the test fixture
    network = HPUXNetwork()

    # execute the method being tested
    network.populate()

    # check the default_interface fact
    default_interface = network.get_option('default_interface')
    assert(default_interface)

    # check the interface fact
    interface = network.get_option('interface')
    assert(interface)

    # check the default_gateway fact
    default_gateway = network.get_option('default_gateway')
    assert(default_gateway)

    # test the interface fact
    interfaces = network.get_option('interfaces')
    assert(len(interfaces) > 0)

    # get the ipv4 address for the first interface
    first_interface = interfaces[0]

# Generated at 2022-06-20 18:18:10.282122
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    HPUXNetwork.populate method unit test
    """
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import Mock, patch

    # Mock modules builtin '__import__' function
    # because ansible.module_utils.facts.network.hpux.HPUXNetwork() is
    # instantiated
    with patch('ansible_collections.ansible.netcommon.plugins.module_utils.facts.network.hpux.HPUXNetwork.__init__') as mock_init:
        mock_init.return_value = None

        mock_module = Mock()
        mock_module.run_command.return_value = (0, '', '')
        mock

# Generated at 2022-06-20 18:18:19.748661
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    Network = HPUXNetwork(None)
    Network.module.run_command = lambda x: (0, 'default         10.34.43.1      UG       0        0        0 lan1', '')
    assert Network.get_default_interfaces() == {'default_interface': 'lan1', 'default_gateway': '10.34.43.1'}
    Network.module.run_command = lambda x: (0, 'default         0.0.0.0         UG       0        0        0 lan1', '')
    assert Network.get_default_interfaces() == {'default_interface': 'lan1', 'default_gateway': '0.0.0.0'}


# Generated at 2022-06-20 18:18:30.368127
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    # Create empty object of class HPUXNetwork
    obj = HPUXNetwork()
    # Call function populate and save result
    result = obj.populate()
    # Check that result has correct data
    assert 'default_interface' in result
    assert 'default_gateway' in result
    assert 'interfaces' in result

    for iface in result['interfaces']:
        assert 'device' in result[iface]
        assert 'ipv4' in result[iface]
        assert 'address' in result[iface]['ipv4']

    print("Unit test for method populate of HPUXNetwork class - OK")



# Generated at 2022-06-20 18:18:42.509127
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = '/bin/netstat'
    module.run_command.return_value = (0, 'default        192.0.2.1', None)
    network = HPUXNetwork(module)
    network_facts = network.populate()
    module.get_bin_path.assert_called_once_with('netstat')
    assert module.run_command.call_count == 3
    assert sorted(network_facts.keys()) == sorted(['interfaces',
                                                   'default_interface',
                                                   'default_gateway',
                                                   'lan0'])