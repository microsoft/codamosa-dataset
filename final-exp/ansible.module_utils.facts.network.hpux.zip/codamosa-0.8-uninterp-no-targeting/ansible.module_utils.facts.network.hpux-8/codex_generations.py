

# Generated at 2022-06-20 18:09:42.016728
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of class HPUXNetworkCollector.
    """

    # Create object of class HPUXNetworkCollector
    hpux_network_collector_obj = HPUXNetworkCollector()

    # Check instance attributes of class HPUXNetworkCollector
    assert hpux_network_collector_obj._fact_class == \
        HPUXNetwork
    assert hpux_network_collector_obj._platform == 'HP-UX'


# Generated at 2022-06-20 18:09:53.956323
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Create test data
    class MockedModule(object):
        def get_bin_path(self, name):
            return "/usr/bin/netstat"

        def run_command(self, cmd):
            out = '''default 127.0.0.1 UGRS 0 0 en0
169.254 link#4 UC 0 0 en0
'''
            return (0, out, '')

    class MockedNetworkCollector(object):
        def __init__(self):
            self.module = MockedModule()

    test_network = HPUXNetwork(MockedNetworkCollector())
    # Check if HPUXNetwork.get_default_interfaces works as expected
    res = test_network.get_default_interfaces()
    assert res['default_interface'] == 'en0'

# Generated at 2022-06-20 18:10:04.638380
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    This is a test for method populate of the class HPUXNetwork.
    The test makes sure that the dictionaries returned by
    default_interfaces and interfaces are not empty.
    """
    network = HPUXNetwork()
    result_actual = network.populate()
    result_expect = {'default_interface': 'lan0',
                     'interfaces': ['lan0'],
                     'lan0': {'device': 'lan0',
                              'ipv4': {'address': '172.16.38.135',
                                       'interface': 'lan0',
                                       'network': '172.16.38.0'}},
                     'default_gateway': '172.16.38.2'}

    assert result_actual == result_expect

# Generated at 2022-06-20 18:10:12.070214
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod_args = dict(
        gather_subset=[],
        gather_timeout=5,
        check_subset=[],
        check_timeout=5,
        check_network=False,
    )
    module = MockNetworkModule(argument_spec={}, **mod_args)
    ifaceobj = HPUXNetwork(module)
    assert module == ifaceobj.module


# Generated at 2022-06-20 18:10:15.606497
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    interfaces = net.get_interfaces_info()
    assert 'lan0' in interfaces.keys()
    assert interfaces['lan0']['ipv4']['address'] == '169.254.113.251'

# Generated at 2022-06-20 18:10:21.219770
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    m = HPUXNetwork()
    m.module = FakeModule()
    interfaces = m.get_interfaces_info()
    assert interfaces['lan0']['ipv4']['address'] == '10.1.0.1'


# Generated at 2022-06-20 18:10:27.165521
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    expected_interfaces_dict = {
        "lan0": {"ipv4": {"network": "10.14.20.0", "address": "10.14.20.80"}},
        "lan1": {"ipv4": {"network": "10.15.10.0", "address": "10.15.10.199"}},
        "lan2": {"ipv4": {"network": "10.16.0.0", "address": "10.16.0.0"}}
    }
    with open('/tmp/netstat_niw.out') as f:
        fact_out = f.read()
    interfaces_dict = HPUXNetwork().get_interfaces_info(fact_out)
    assert interfaces_dict == expected_interfaces_dict


# Generated at 2022-06-20 18:10:32.937063
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork
    """

# Generated at 2022-06-20 18:10:37.648666
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-20 18:10:42.573121
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector(None)
    assert isinstance(collector, NetworkCollector)
    assert collector._platform == 'HP-UX'
    assert isinstance(collector._fact_class(), HPUXNetwork)

# Generated at 2022-06-20 18:10:51.366235
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._platform is 'HP-UX'
    assert obj._fact_class is HPUXNetwork

# Generated at 2022-06-20 18:10:59.466711
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Class initialization
    module = AnsibleModule(argument_spec=dict())
    network_module = HPUXNetwork(module)
    # Populate
    network_facts = network_module.populate()
    # Assert the presence of default interface
    assert network_facts['default_interface']
    # Assert the presence of some interfaces
    assert network_facts['interfaces']
    # Assert the presence of ipv4 address in the first interface
    assert network_facts[network_facts['interfaces'][0]]['ipv4']['address']
    # Assert the presence of ipv4 network in the first interface
    assert network_facts[network_facts['interfaces'][0]]['ipv4']['network']
    # Assert the presence of ipv4 interface in the first interface

# Generated at 2022-06-20 18:11:08.197524
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = MockedModule()
    h = HPUXNetwork(m)
    h.populate()
    assert h.facts['interfaces'] == ['lan2', 'lan3', 'lan4']
    assert h.facts['default_interface'] == 'lan4'
    if_facts = h.facts['lan4']
    assert if_facts['ipv4']['address'] == '10.1.1.1'
    assert if_facts['ipv4']['network'] == '10.1.1.0'
    assert if_facts['ipv4']['address'] == '10.1.1.1'
    assert if_facts['ipv4']['interface'] == 'lan4'


# Generated at 2022-06-20 18:11:13.437325
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'
    assert hn.facts == {}
    assert hn.module == None
    assert hn.interfaces == []



# Generated at 2022-06-20 18:11:14.565601
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:11:18.419525
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():

    hpx_net = HPUXNetworkCollector()
    assert hpx_net is not None
    assert hpx_net._platform == 'HP-UX'

# Generated at 2022-06-20 18:11:27.188959
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    interfaces = net.get_interfaces_info()
    # Test lan0 on virtual machine
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '192.168.242.62'
    assert interfaces['lan0']['ipv4']['network'] == '192.168.242.0'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-20 18:11:31.231840
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    args = None
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    net = HPUXNetwork
    net.populate()

# Generated at 2022-06-20 18:11:34.192699
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    result = HPUXNetworkCollector()
    assert result._platform == 'HP-UX'
    assert result._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:11:35.382567
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fc = HPUXNetworkCollector()
    assert fc is not None

# Generated at 2022-06-20 18:11:45.151738
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_collector = HPUXNetworkCollector()
    assert test_collector.platform == 'HP-UX'
    assert test_collector._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:11:58.230377
# Unit test for constructor of class HPUXNetwork

# Generated at 2022-06-20 18:12:01.251475
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """ Unit test for method get_default_interfaces of class HPUXNetwork
    """
    from ansible.module_utils.facts import co

# Generated at 2022-06-20 18:12:03.969223
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork('dummy_module')
    assert hpux_network

# Generated at 2022-06-20 18:12:10.644323
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hn = HPUXNetwork()
    hn.module = MockModule()
    rc, out, err = hn.module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    default = False
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                if words[4] == 'lan0' and words[1] == '10.161.240.1':
                    default = True
    assert default


# Generated at 2022-06-20 18:12:20.069482
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(
        {'/usr/bin/netstat -nr':
         '''Kernel IP routing table
Destination        Gateway           Flags    Refs     Use   Netif Exp  Time
default            192.168.1.254     UGS         4     541   lan1
192.168.1.0        -                 U          6     989   lan1
192.168.1.0        -                 U          0     112   lan0
192.168.3.0        -                 U          2     189   lan3
224.0.0.0          -                 U         13      14   lan1
255.255.255.255/32 -                 UCS        0       0   lan1 '''})

    hpux_network = HPUXNetwork(module)


# Generated at 2022-06-20 18:12:31.247252
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    netstat_out = "Kernel Interface table\n" + \
                  "Destination        Gateway            Flags Refs Use Mtu Interface\n" + \
                  "default            10.1.40.1         UG        7 5255      lan2\n"
    module = MockModule(0, netstat_out, '')
    hpux = HPUXNetwork()
    hpux.module = module
    interfaces = hpux.get_default_interfaces()
    assert interfaces['default_interface'] == 'lan2'

# Generated at 2022-06-20 18:12:35.431126
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = Mock(run_command=Mock(return_value=(0, '', '')))
    collector = HPUXNetworkCollector(module)
    assert collector
    assert collector._fact_class is HPUXNetwork

# Generated at 2022-06-20 18:12:37.891894
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'



# Generated at 2022-06-20 18:12:41.615260
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h = HPUXNetworkCollector()
    assert h.platform == 'HP-UX'
    assert h.fact_class == HPUXNetwork


# Generated at 2022-06-20 18:12:57.589363
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    netstat = MockCommand("/usr/bin/netstat")
    netstat.add_cmd_output("-nr", "default   172.22.91.0      UG        0 0        0 lan2\n")

    network = HPUXNetwork(module)
    network.get_bin_path = Mock(return_value='/usr/bin/netstat')
    network.module.run_command = netstat

    assert (network.get_default_interfaces() ==
            {'default_interface': 'lan2', 'default_gateway': '172.22.91.0'})



# Generated at 2022-06-20 18:13:07.701698
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    headers = ["Destination", "Gateway", "Flags", "Refs", "Use",
               "Interface", "Mtu", "Net/Dest", "Routes", "0.0.0.0/0",
               "default", "172.16.200.1", "UG", "1", "0", "lan0", "1500",
               "172.16.200.0", "1"]

    test_cases = [
        "  " + "  ".join(headers) + "\n",
        "  " + "  ".join(headers[:-1]) + "\n",
        "  " + "  ".join(headers[:-6]) + "\n",
        ]

    for case in test_cases:
        default_gateway = HPUXNetwork().get_default_interfaces(case)
        assert default_gateway

# Generated at 2022-06-20 18:13:10.224511
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:13:17.058871
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork(module)
    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    default_interfaces = network.get_default_interfaces()
    assert len(default_interfaces) == 2
    assert 'default_interface' in default_interfaces
    assert 'default_gateway' in default_interfaces
    assert default_interfaces['default_interface'] == 'lan9'
    assert default_interfaces['default_gateway'] == '172.16.1.1'


# Generated at 2022-06-20 18:13:20.865065
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_fact = HPUXNetwork({})
    assert network_fact.platform == 'HP-UX'

# Generated at 2022-06-20 18:13:22.356825
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:13:31.125999
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    interface = 'lan0'
    gateway = '172.31.1.1'
    mock_run_command = {
        '/usr/bin/netstat -nr': ((0,
                                  "Other Net Flags   Refs Net Address      Iface\n"
                                  "default                          %s\n"
                                  "link#2             U     0 127.0.0.1      lo0\n"
                                  "localnet           U     1 %s %s" % (gateway, gateway, interface)),
                                 None),
    }
    import ansible.module_utils.facts.network.hpux.network as hpux_nw_mod
    hpux_nw_mod.Network.module.run_command = mock_run_command
    hpux_nw_fact = hpux_nw_mod.HPUXNetwork()


# Generated at 2022-06-20 18:13:33.680425
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork().populate()
    assert network_facts['default_interface'] is not None



# Generated at 2022-06-20 18:13:45.564247
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    for platform in ('HP-UX', 'Darwin'):
        sut = HPUXNetwork(dict(module=dict(run_command=lambda x: (0, '', '')),
                               ansible_facts=dict(
                                   ansible_net_version=2,
                                   ansible_system='HP-UX')))
        ipv4_interfaces_info = sut.get_interfaces_info()
        default_interfaces_info = sut.get_default_interfaces()
        network_facts = sut.populate()

        assert 'default_interface' in network_facts
        assert 'default_gateway' in network_facts
        assert 'interfaces' in network_facts

        if platform == 'HP-UX':
            assert len(default_interfaces_info) == 2

# Generated at 2022-06-20 18:13:54.049699
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['address'] == '192.168.0.100'
    assert interfaces['lan0']['ipv4']['network'] == '192.168.0.0'

# Generated at 2022-06-20 18:14:03.653961
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-20 18:14:05.718178
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(None)

    assert network
    assert network.platform == 'HP-UX'


# Generated at 2022-06-20 18:14:14.380868
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeModule()
    network = HPUXNetwork(module=module)
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '0.0.0.0'
    assert interfaces['lan0']['ipv4']['address'] == '0.0.0.0'



# Generated at 2022-06-20 18:14:18.171301
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-20 18:14:23.476304
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)

    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.10.63.254'


# Generated at 2022-06-20 18:14:28.596809
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network_facts = HPUXNetwork()
    assert hpux_network_facts.platform == 'HP-UX'
    assert hpux_network_facts._platform == 'HP-UX'


# Generated at 2022-06-20 18:14:38.155234
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    netstat_path = "/usr/bin/netstat"
    netstat_path2 = "/bin/netstat"

# Generated at 2022-06-20 18:14:48.636630
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = MockedModule()

    network_populate = HPUXNetwork()

    iface = {
        "default_gateway": "192.168.1.1",
        "default_interface": "lan9000"
    }

# Generated at 2022-06-20 18:14:58.590210
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class NetworkModule(object):

        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/bin'

        def run_command(self, command, check_rc=True):
            self.run_command_calls.append(command)
            return 0, 'default 192.168.1.1 UG lan0', ''

    module = NetworkModule()
    net = HPUXNetwork(module)
    expected_result = {'default_interface': 'lan0',
                       'default_gateway': '192.168.1.1'}
    assert net.get_default_interfaces() == expected_result

# Generated at 2022-06-20 18:15:08.527702
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    module.run_command.return_value = (2, "default 172.16.10.254 UGS \
        0 39400 lan0", '')
    module.get_bin_path.return_value = "/usr/bin/netstat"
    network = HPUXNetwork(module)
    net_facts = network.populate()
    assert 'default_interface' in net_facts
    assert net_facts['default_interface'] == 'lan0'
    assert net_facts['interfaces'] == ['lan0']
    assert net_facts['lan0']['device'] == 'lan0'
    assert net_facts['lan0']['ipv4']['address'] == '172.16.10.254'


# Generated at 2022-06-20 18:15:17.074447
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    '''
    Constructor of class HPUXNetworkCollector
    '''
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:15:19.877401
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c is not None

# Generated at 2022-06-20 18:15:22.301329
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork

# Generated at 2022-06-20 18:15:24.961446
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork.get_interfaces_info()
    assert 'lan0' in interfaces

# Generated at 2022-06-20 18:15:38.268266
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockAnsibleModule()
    module.set_command("/usr/bin/netstat",
                       "/usr/bin/netstat -niw")
    fake_network_out = "lan0      Link        encap:Ethernet  HWaddr 00:0c:29:79:2f:8b\
                        inet addr:10.1.1.1  Bcast:10.1.255.255  Mask:255.255.0.0\
                        lan1      Link        encap:Ethernet  HWaddr 00:0c:29:79:2f:8c\
                        inet addr:10.2.2.2  Bcast:10.2.255.255  Mask:255.255.0.0"
    module.set_command_output(fake_network_out)
    network = HPU

# Generated at 2022-06-20 18:15:49.509328
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    m_run_command = MagicMock(return_value=(0, "", ""))
    m_get_bin_path = MagicMock(return_value=True)
    module.run_command = m_run_command
    module.get_bin_path = m_get_bin_path
    network = HPUXNetwork(module)
    facts = network.populate()

    assert('default_interface' in facts)
    assert('default_gateway' in facts)
    assert('interfaces' in facts)
    assert('lan0' in facts)
    assert('lan1' in facts)
    assert('ipv4' in facts['lan0'])



# Generated at 2022-06-20 18:15:50.966725
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    output = """default - - - - - - - lan0
    default 192.168.1.1 UG 0 - - - lan1"""
    network.get_default_interfaces(output)


# Generated at 2022-06-20 18:15:54.887492
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    nm = HPUXNetwork(module)
    assert nm.module == module

# Unit test to check the populated facts

# Generated at 2022-06-20 18:15:57.070575
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc is not None


# Generated at 2022-06-20 18:16:00.221828
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hrn = HPUXNetwork({})
    assert hrn.platform == 'HP-UX'
    assert 'default_interface' in hrn.populate()

# Generated at 2022-06-20 18:16:17.070657
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert 'default_gateway' in default_interfaces
    assert 'default_interface' in default_interfaces
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.24.34.1'



# Generated at 2022-06-20 18:16:27.491290
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    fakeout = """lan0      Link encap:Ethernet  HWaddr 4a:78:4b:04:d0:54
      inet addr:10.100.100.100  Bcast:10.100.100.255  Mask:255.255.248.0
      UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
      RX packets:101934 errors:0 dropped:0 overruns:0 frame:0
      TX packets:81262 errors:0 dropped:0 overruns:0 carrier:0
      collisions:0 txqueuelen:1000
      RX bytes:8494576 (8.0 Mb)  TX bytes:9792998 (9.3 Mb)
      Memory:f6000000-f6012800"""

    hpu = HPUXNetwork()
    hpu.module

# Generated at 2022-06-20 18:16:31.840852
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class == HPUXNetwork
    assert c._platform == 'HP-UX'


# Generated at 2022-06-20 18:16:32.753298
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork({})
    assert hpn.platform == "HP-UX"


# Generated at 2022-06-20 18:16:40.207986
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = NetworkCollector()

    test_module.module.run_command.return_value = (
        0,
        "default/0x100000/0x2000         169.254.0.0         UG    0        0 0 lo0\n"
        "default/0x100000/0x20000       172.16.10.0        UG    0        0 0 lan0\n"
        "default/0x100000/0x200000      192.168.0.0        UG    0        0 0 lan1\n",
        "",
    )

    p = HPUXNetwork(test_module)
    res = p.get_default_interfaces()
    assert res['default_interface'] == 'lo0'

# Generated at 2022-06-20 18:16:45.249381
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpu import HPUXNetwork
    test_net = HPUXNetwork(None)

    result = test_net.get_interfaces_info()
    assert result

# Generated at 2022-06-20 18:16:46.917863
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    expected_platform = 'HP-UX'
    expected_fact_class = HPUXNetwork
    collector = HPUXNetworkCollector()
    assert collector._platform == expected_platform
    assert collector._fact_class == expected_fact_class



# Generated at 2022-06-20 18:16:54.510917
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpu_ux import HPUXNetwork
    hpux_network = HPUXNetwork()
    hpux_network.module.run_command = (
        lambda x: (0, 'default 192.168.1.1 UG lan0', ''))
    hpux_network.module.get_bin_path = lambda x: '/usr/bin/netstat'
    hpux_network.get_interfaces_info = (
        lambda x: ({'lan0': {'ipv4': {'address': '192.168.1.1',
                                      'network': '192.168.1.0',
                                      'interface': 'lan0'}}},
                   {'lan0': {'device': 'lan0'}}))
    interfaces = hpux_network.populate()


# Generated at 2022-06-20 18:16:59.864439
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpu = HPUXNetwork()
    assert hpu.get_interfaces_info() == {'lan0': {'device': 'lan0', 'ipv4': {'address': '10.15.1.71', 'network': '10.15.1.0', 'interface': 'lan0'}}, 'lan1': {'device': 'lan1', 'ipv4': {'address': '10.15.1.72', 'network': '10.15.1.0', 'interface': 'lan1'}}}


# Generated at 2022-06-20 18:17:12.231933
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Set up test environment
    class FakeModule:
        def __init__(self):
            self.run_command_invoked = False
            self.run_command_args = []

        def get_bin_path(self, value):
            return '/usr/bin/netstat'

        def run_command(self, args):
            self.run_command_invoked = True
            self.run_command_args.append(args)
            return (0, 'default: flags=5e5<UP,BROADCAST,GRP,MPROTO,SIMPLEX> mtu 1500\ndefault 192.168.0.10 UGS 0 0 en1\n', '')

    test_module = FakeModule()

    # Perform test on a sample output of /usr/bin/netstat -nr command
    test_object = HPUX

# Generated at 2022-06-20 18:17:53.828430
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    The test_HPUXNetwork_get_interfaces_info method tests the
    get_interfaces_info method of the HPUXNetwork class.
    """

    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    network = HPUXNetwork()

# Generated at 2022-06-20 18:17:56.576091
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector is not None
    assert network_collector._fact_class is HPUXNetwork
    assert network_collector._platform is 'HP-UX'


# Generated at 2022-06-20 18:18:07.713864
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    mock_module = MockAnsibleModule()
    mock_module.run_command.return_value = (0,
                                            'default 172.16.1.1 UGS 0 9 ge0',
                                            None)

    network_collector = HPUXNetwork(mock_module)
    default_interfaces_facts = network_collector.get_default_interfaces()

    assert default_interfaces_facts == {'default_interface': 'ge0',
                                        'default_gateway': '172.16.1.1'}



# Generated at 2022-06-20 18:18:17.666810
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = Network()
    m.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    m.module.run_command = Mock(return_value=(1, 'test out', 'test err'))
    m.populate()
    assert m.default_interface == 'lan0'
    assert m.default_gateway == '10.10.10.1'
    assert m.interfaces[0] == 'lan0'
    assert m.lan0['ipv4']['address'] == '10.10.10.112'

# Generated at 2022-06-20 18:18:23.062102
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork



# Generated at 2022-06-20 18:18:28.238095
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces = {'default_interface': 'lan0',
                          'default_gateway': '172.27.70.254'}
    network = HPUXNetwork({})
    assert network.get_default_interfaces() == default_interfaces



# Generated at 2022-06-20 18:18:39.053621
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_hpuxnetwork = HPUXNetwork({})
    interfaces = test_hpuxnetwork.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'address': '9.152.68.130',
                                           'network': '9.152.64.0',
                                           'interface': 'lan0',
                                           'address': '9.152.68.130'}}


# Generated at 2022-06-20 18:18:49.678454
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    hpux_network = HPUXNetwork(None)

    out = 'default 192.168.0.1 UG 2 0 0 lan0\n'
    expected = {'default_interface': 'lan0', 'default_gateway': '192.168.0.1'}
    unittest.TestCase.assertEqual(unittest.TestCase(),
                                  expected, hpux_network.get_default_interfaces(out))



# Generated at 2022-06-20 18:18:52.034357
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.__class__


# Generated at 2022-06-20 18:19:01.463800
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Create a dummy module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Read output of command 'netstat -r'
    with open('unit/ansible/module_utils/facts/network/hpux/netstat_r.txt') as f:
        netstat_r = f.read()
    # Read output of command 'netstat -in'
    with open('unit/ansible/module_utils/facts/network/hpux/netstat_in.txt') as f:
        netstat_in = f.read()

    # This is the output of the mocked commands
    rc = 0
    cmd1_out = netstat_r
    cmd1_err = ''
    cmd2_out = netstat_in
    cmd2_err = ''

   