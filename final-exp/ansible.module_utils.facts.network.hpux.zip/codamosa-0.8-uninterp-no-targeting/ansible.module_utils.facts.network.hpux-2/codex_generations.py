

# Generated at 2022-06-20 18:09:38.706316
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:09:48.027235
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.hpux.collector import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts import ansible_fact_suite
    import ansible.module_utils.facts.network.base as tm

    tm.get_module_path = lambda *args, **kwargs: None
    ansible_fact_suite.patch(tm.Network, 'get_module_path', lambda *args, **kwargs: None)
    network_fact = HPUXNetwork()
    lines = []
    lines.append("  lan0            lan0    0    0  172.16.13.14   172.16.13.9")

# Generated at 2022-06-20 18:09:54.797410
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert isinstance(interfaces, dict)
    assert 'lan0' in interfaces
    assert 'ipv4' in interfaces['lan0']
    assert 'address' in interfaces['lan0']['ipv4']
    assert 'network' in interfaces['lan0']['ipv4']
    assert 'interface' in interfaces['lan0']['ipv4']


# Generated at 2022-06-20 18:09:58.806417
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    networkcollector_obj=HPUXNetworkCollector()
    assert networkcollector_obj.platform == 'HP-UX'
    assert networkcollector_obj._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:10:02.321708
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork({'module': None, 'params': {'collect_default_gateway': True}})
    result = net.get_interfaces_info()
    assert result is not None
    assert 'lan0' in result


# Generated at 2022-06-20 18:10:12.610661
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    module.run_command = Fake_run_command
    hpn = HPUXNetwork(module)
    output = {'lan0': {'ipv4': {'address': '1.1.1.1',
                                'network': '127.0.0.0',
                                'interface': 'lan0'},
                       'device': 'lan0'}}
    result = hpn.get_interfaces_info()
    assert output == result


# Utility classes and functions


# Generated at 2022-06-20 18:10:24.038107
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_output = b"""
          Destination        Gateway           Flags Refs Use   Mtu  Interface
    ----------------------------------------------------------------------------
    default                10.0.2.2         UG       -      -   -   lan0
                               -                -       -      -   -   lan1
    """
    test_module = AnsibleModule(argument_spec=dict())
    obj = HPUXNetwork(test_module)
    default_interfaces = obj.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.2.2'



# Generated at 2022-06-20 18:10:35.760024
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule({})
    hpuxNetwork = HPUXNetwork(module)
    network_facts = hpuxNetwork.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'][0] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-20 18:10:37.740201
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    networkCollector = HPUXNetworkCollector()
    assert networkCollector is not None

# Generated at 2022-06-20 18:10:46.792835
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    network_facts = network.populate()
    print(network_facts)
    # assert some facts
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.11.12.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4'] == {'network': '10.11.12.0',
                                             'interface': 'lan0',
                                             'address': '10.11.12.54'}



# Generated at 2022-06-20 18:10:59.470692
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of HPUXNetworkCollector.
    """
    network_collector = HPUXNetworkCollector()
    assert network_collector

# Generated at 2022-06-20 18:11:05.482275
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    hpuxnetwork_constructor_test.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      This test is used to unit test the constructor of class
      HPUXNetwork for various inputs
    """
    hpuxnetwork = HPUXNetwork()
    assert hpuxnetwork.platform == 'HP-UX'
    assert hpuxnetwork.default_interface is None
    assert hpuxnetwork.default_gateway is None



# Generated at 2022-06-20 18:11:17.567181
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO
    module = type('', (), {})()
    network = HPUXNetwork(module)
    network.module.run_command = lambda cmd: (None, 'default 10.88.128.1 UG lan0', None)
    facts = network.get_default_interfaces()
    assert facts == {'default_gateway': '10.88.128.1',
                     'default_interface': 'lan0'}, facts

    network.module.run_command = lambda cmd: (None, 'default 10.192.47.1 UG lan0', None)
    facts = network.get_default_interfaces()

# Generated at 2022-06-20 18:11:25.771460
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h = HPUXNetwork()
    interfaces = h.get_interfaces_info()

    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['network'] == '10.2.30.0'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '10.2.30.78'

# Generated at 2022-06-20 18:11:27.662212
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    assert hpn.platform == 'HP-UX'

# Generated at 2022-06-20 18:11:38.242713
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hpux = HPUXNetworkCollector(module=module)
    network_facts = hpux.get_network_facts()
    assert network_facts['default_interface'] == "lan0"
    assert network_facts['default_gateway'] == "192.168.254.254"
    assert network_facts['interfaces'] == ["lan0"]
    assert network_facts['lan0'] == {'ipv4': {'network': "192.168.254.0",
                                              'interface': "lan0",
                                              'address': "192.168.254.12"}}
    assert network_facts['lan0']['device'] == "lan0"

# Generated at 2022-06-20 18:11:48.062197
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os
    import sys
    import subprocess
    import unittest
    from ansible.module_utils.facts.network.hpux import HPUXNetwork as ifconfig

    class MockModule(object):

        def run_command(self, command):
            if command == '/usr/bin/netstat -niw':
                if os.path.isfile("./test_data/netstat-niw"):
                    f = open("./test_data/netstat-niw")
                    output = f.read()
                    f.close()
                    return 0, output, ''
                else:
                    # The test is executed from subdirectory.
                    # Try again in parent directory.
                    f = open("../test_data/netstat-niw")
                    output = f.read()
                    f.close()
                    return 0

# Generated at 2022-06-20 18:11:52.212784
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector
    assert HPUXNetworkCollector._fact_class == HPUXNetwork
    assert HPUXNetworkCollector._platform == 'HP-UX'

# Generated at 2022-06-20 18:11:54.045046
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector is not None
    assert isinstance(collector, NetworkCollector)


# Generated at 2022-06-20 18:12:01.869068
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork()

    module.run_command = MagicMock(return_value=(0, 'lan0  link#5    00:60:08:5d:59:0c    UP          UP    lan0    xxx.xxx.xxx.xxx  xxx.xxx.xxx.xxx', None))
    network.module = module
    collected_facts = network.populate()

    assert collected_facts['default_interface'] == 'lan0'
    assert collected_facts['default_gateway'] == 'xxx.xxx.xxx.xxx'
    assert collected_facts['interfaces'] == ['lan0']

# Generated at 2022-06-20 18:12:13.102416
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_collector = HPUXNetworkCollector()
    assert net_collector._fact_class == HPUXNetwork
    assert net_collector._platform == 'HP-UX'

# Generated at 2022-06-20 18:12:17.620542
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_object = HPUXNetwork()
    interfaces_info = test_object.get_interfaces_info()
    assert 'lan0' in interfaces_info
    assert 'lan1' in interfaces_info
    assert 'lan2' in interfaces_info
    assert 'lan3' in interfaces_info
    assert 'lan4' in interfaces_info

# Generated at 2022-06-20 18:12:30.056571
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_module = NetworkCollector()
    net_module.module.run_command = lambda *args, **kwargs: (0,
                                                             'default 10.1.1.1 UG S1 lan1\ndefault 10.1.2.2 UG S2 lan2',
                                                             '')
    net_module.module.run_command = lambda *args, **kwargs: (0,
                                                             'lan0/0 10.1.1.1/24 10.1.1.1 U S lan0\nlan0/1 10.1.2.2/24 10.1.2.2 U S lan1',
                                                             '')
    facts = net_module.populate()
    assert facts['default_interface'] == 'lan1'
    assert facts['default_gateway']

# Generated at 2022-06-20 18:12:35.959391
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts import NetworkInfo
    module = FakeModule()
    network_info = NetworkInfo()
    hpux_network = HPUXNetwork(module)
    result = hpux_network.populate(network_info)

# Generated at 2022-06-20 18:12:43.225384
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method HPUXNetwork.populate.
    """
    net = HPUXNetwork()
    facts = net.populate()
    assert facts['default_interface'] == 'lan10000'
    assert facts['default_gateway'] == '10.0.1.1'
    assert facts['interfaces'] == ['lan10000']



# Generated at 2022-06-20 18:12:44.717520
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor test of class HPUXNetworkCollector
    """

    obj = HPUXNetworkCollector()
    assert obj._platform == "HP-UX"
    assert obj._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:12:45.280200
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-20 18:12:57.897621
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Test with simple output of netstat command
    lines = [
        'default 192.168.2.2 UG lan0',
        'lan0 192.168.2.1 U lan0 0 9',
        'lan1 192.168.1.1 U lan1 1 2',
        'lan2 192.168.0.1 U lan2 2 1',
    ]
    netstat_path = '/usr/bin/netstat'
    mock_run_command = lambda self, cmd: (0, '\n'.join(lines), '')
    HPUXNetwork.get_default_interfaces = lambda self: {}
    HPUXNetwork.get_interfaces_info = lambda self: {}
    HPUXNetwork.module.run_command = mock_run_command

# Generated at 2022-06-20 18:13:07.702219
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network_collector = HPUXNetworkCollector({})
    HPUX_Network = HPUXNetwork(network_collector.module)
    default_interfaces_facts = {}
    default_interfaces_facts = HPUX_Network.get_default_interfaces()
    with open('test_HPUXNetwork_get_default_interfaces.txt', 'r') as f:
        lines = f.readlines()

    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]

    assert default_interface == default_interfaces_facts['default_interface']
    assert default_gateway == default_interfaces_facts['default_gateway']



# Generated at 2022-06-20 18:13:13.111129
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    output = hpux_network.get_interfaces_info()

    assert output



# Generated at 2022-06-20 18:13:33.681282
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpuxtcp import HPUXNetwork
    network = HPUXNetwork(None)
    network.get_interfaces_info()

# Generated at 2022-06-20 18:13:45.562475
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class ModuleStub:
        changed = True

        def __init__(self):
            self._name = "localhost"

        def get_bin_path(self, executable, required=False):
            executable_paths = {
                'netstat': '/usr/bin/netstat'
            }
            if executable in executable_paths:
                return executable_paths[executable]
            else:
                return None


# Generated at 2022-06-20 18:13:57.439611
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m_module = MockModule()
    m_run_command = MockRunCommand(m_module)
    m_get_bin_path = MockGetBinPath(m_module)

    network = HPUXNetwork(m_module)

    m_get_bin_path.return_value = '/usr/bin/netstat'
    m_run_command.set_out('/usr/bin/netstat -niw', ['lan0      2    0    0    0    0    0    0  <Link>   10.0.0.1      10.0.0.1',
                                                    'lan1      2    0    0    0    0    0    0  <Link>   10.0.1.1      10.0.1.1'])

# Generated at 2022-06-20 18:14:01.553938
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    fact_network = HPUXNetwork(None)
    fact_network.populate()
    assert fact_network.facts['interfaces'][0] == 'lan0'



# Generated at 2022-06-20 18:14:11.235723
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import pytest
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts import ansible_facts

    # stdout expected to be returned by network_facts.get_default_interfaces
    # method when called with input stdin
    stdout = '''
    default 192.168.100.1 UGSc 2 12 lan0
    192.168.100.0/24 192.168.100.0 U 1 12 lan2
    '''

    # Mock the execute_module method of AnsibleModule class to return
    # the above-mentioned stdout
    def execute_module(self):
        return (0, stdout, '')

    # Save the original execute_module of AnsibleModule class

# Generated at 2022-06-20 18:14:16.488826
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Test case to test the method populate of class HPUXNetwork
    """
    hpu_net = HPUXNetwork()
    hpu_net_facts = hpu_net.populate()
    assert 'interfaces' in hpu_net_facts

# Generated at 2022-06-20 18:14:18.372459
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    h = HPUXNetwork()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 18:14:26.641344
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    assert isinstance(net.get_interfaces_info(), dict)
    assert isinstance(net.get_interfaces_info().values(), list)
    assert isinstance(net.get_interfaces_info()['lan0'], dict)
    assert isinstance(net.get_interfaces_info()['lan0']['ipv4'], dict)
    assert net.get_interfaces_info()['lan0']['ipv4']['address'] == '127.0.0.1'
    assert net.get_interfaces_info()['lan0']['ipv4']['network'] == '127.0.0.0'
    assert net.get_interfaces_info()['lan0']['ipv4']['interface'] == 'lan0'



# Generated at 2022-06-20 18:14:32.809673
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    net = HPUXNetwork(module)
    facts = net.populate()
    assert 'default_interface' in facts
    assert 'default_gateway' in facts
    assert 'interfaces' in facts

# Generated at 2022-06-20 18:14:34.917954
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network.__dict__["_fact_class"] == HPUXNetwork

# Generated at 2022-06-20 18:15:14.812401
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector(None)
    assert collector
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:15:18.279558
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network.platform == 'HP-UX'


# Generated at 2022-06-20 18:15:28.652604
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import unittest
    import module_utils.facts.network.hpux


# Generated at 2022-06-20 18:15:39.739859
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Test case for method get_interfaces_info of class HPUXNetwork.
    It will generate a test output from netstat command, which is
    used by the method and make sure the output will be parsed correctly.
    """

# Generated at 2022-06-20 18:15:46.216897
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = HPUXNetwork(dict())
    test_module.module = MockModule()
    result = test_module.get_default_interfaces()
    assert result['default_gateway'] == '192.168.0.1'
    assert result['default_interface'] == 'lan0'


# Generated at 2022-06-20 18:15:52.402783
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    results = HPUXNetwork()
    keys = sorted(results.keys())
    assert 'interfaces' in keys
    assert 'interface_lan0' in keys
    assert 'default_interface' in keys
    assert 'default_gateway' in keys
    assert 'interface_lo0' in keys

# Generated at 2022-06-20 18:15:54.683567
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert isinstance(obj, HPUXNetwork)

# Generated at 2022-06-20 18:15:59.430199
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpu_net = HPUXNetwork()
    interfaces = hpu_net.get_interfaces_info()
    assert interfaces['lan0'] == {'ipv4': {'address': '9.10.11.12',
                                           'network': '9.10.11.0',
                                           'interface': 'lan0'},
                                  'device': 'lan0'}

# Generated at 2022-06-20 18:16:00.699602
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:16:05.028618
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
  collector = HPUXNetworkCollector()
  assert collector._fact_class is not None
  assert collector._platform == 'HP-UX'

# Generated at 2022-06-20 18:17:42.129966
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    test_HPUXNetwork = HPUXNetwork()
    interfaces = test_HPUXNetwork.get_interfaces_info()
    interface_list = interfaces.keys()
    assert 'lan0' in interface_list

# Generated at 2022-06-20 18:17:46.737472
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    facts = HPUXNetwork()
    assert facts.populate() == {
        'default_interface': 'lan0',
        'default_gateway': '10.10.10.1',
        'interfaces': ['lan0']
    }

# Generated at 2022-06-20 18:17:49.332938
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module)
    network.get_default_interfaces = Mock(return_value=test_default_interfaces)
    result = network.get_default_interfaces()
    assert result == test_default_interfaces



# Generated at 2022-06-20 18:17:57.892905
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector

    def run_command_mock(module, command):

        if command == '/usr/bin/netstat -nr':
            rc = 0
            out = 'default                  192.168.1.1    US\n' \
                  '192.168.1.0              192.168.1.1    US\n'
            err = ''
        else:
            rc = 0
            out = ''
            err = ''

        return (rc, out, err)

    temp_module = HPUXNetworkCollector.load_module()
    temp_module.HPUXNetwork = HPUXNetwork
    temp_module_command = temp_module.run

# Generated at 2022-06-20 18:18:01.554804
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = False
    network_facts = HPUXNetwork(module)
    assert isinstance(network_facts.populate(), dict)

# Generated at 2022-06-20 18:18:04.347532
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpxnet = HPUXNetwork()
    assert hpxnet.platform == 'HP-UX'



# Generated at 2022-06-20 18:18:06.312287
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork({})
    assert net is not None

# Generated at 2022-06-20 18:18:14.914227
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()

    network_facts = {}
    network_facts['default_interface'] = 'lan0'
    network_facts['default_gateway'] = '192.168.1.1'
    network_facts['interfaces'] = ['lan0']
    network_facts['lan0'] = {}
    network_facts['lan0']['ipv4'] = {}
    network_facts['lan0']['ipv4']['address'] = '192.168.1.100'
    network_facts['lan0']['ipv4']['network'] = '192.168.1.0'
    network_facts['lan0']['ipv4']['interface'] = 'lan0'

    network = HPUXNetwork(module)
    facts = network.populate()


# Generated at 2022-06-20 18:18:18.084547
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXNetwork


# Generated at 2022-06-20 18:18:24.686443
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():

    hpux_platform_network_collector = HPUXNetworkCollector()

    assert hpux_platform_network_collector._fact_class == HPUXNetwork
    assert hpux_platform_network_collector._platform == 'HP-UX'