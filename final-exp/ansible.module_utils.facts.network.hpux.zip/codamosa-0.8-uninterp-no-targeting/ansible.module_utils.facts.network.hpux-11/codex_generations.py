

# Generated at 2022-06-20 18:09:41.042000
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    obj = HPUXNetwork(module)
    # For now, we just test whether this runs without errors,
    # and display the output.
    facts = obj.populate()
    pprint(facts)



# Generated at 2022-06-20 18:09:52.330604
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}
    sample_netstat = '/usr/bin/netstat: illegal option -- i\n' +\
                     'usage:  netstat [-Aan] [-f address_family] [-M core] [-N system] [-P protocol]\n' +\
                     '\t\t[-r] [-s] [-T] [-w wait]\n' +\
                     '       netstat -i [-f address_family] [-M core] [-N system] [-P protocol]\n' +\
                     '\t\t[-w wait] [interface]\n' +\
                     '       netstat -m [-f address_family]\n' +\
                     '       netstat -v\n'

# Generated at 2022-06-20 18:09:55.787191
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    platform = 'HP-UX'
    net_collector = HPUXNetworkCollector(platform)
    net_object = net_collector.collect()
    assert net_object.platform == 'HP-UX'

# Generated at 2022-06-20 18:09:57.191346
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    col = HPUXNetworkCollector()
    assert col.platform == 'HP-UX'

# Generated at 2022-06-20 18:09:59.898986
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network
    assert network.platform == 'HP-UX'


# Generated at 2022-06-20 18:10:02.905374
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    assert h.platform == 'HP-UX'
    assert h.default_interface is None
    assert h.default_gateway is None
    assert h.interfaces is None

# Generated at 2022-06-20 18:10:12.905455
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    result_expected = {'default_interface': 'lan0',
                       'default_gateway': '10.64.20.254',
                       'interfaces': ['lan0'],
                       'lan0': {'ipv4': {'address': '10.64.20.210',
                                         'network': '10.64.20.0',
                                         'interface': 'lan0'}}}

    network = HPUXNetwork()
    network.module.run_command = _run_command_mock
    result = network.populate()
    assert result == result_expected



# Generated at 2022-06-20 18:10:19.856108
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """ Constructor of  class HPUXNetworkCollector """
    module = AnsibleModule(argument_spec=dict())
    collector = HPUXNetworkCollector(module)
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'
    assert collector._module == module

# Generated at 2022-06-20 18:10:28.034825
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = DummyAnsibleModule()
    test_module.params = {}
    test_module.run_command = mock_run_command
    test_module.get_bin_path = mock_get_bin_path

    network_facts = HPUXNetwork().populate()

    assert network_facts['all_ipv4_addresses'] == ['172.16.1.1', '192.168.1.1']
    assert network_facts['default_gateway'] == '172.16.1.254'
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['interfaces'] == ['lan0', 'lan1']
    assert network_facts['lan0']['device'] == 'lan0'

# Generated at 2022-06-20 18:10:37.953844
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    import sys
    import os

    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(root_dir)

    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.base import Network, NetworkCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}


# Generated at 2022-06-20 18:10:48.114701
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    hpu = HPUXNetwork(module=module)
    interfaces = hpu.get_interfaces_info()

# Generated at 2022-06-20 18:10:58.232849
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    INTERFACES = {'lan0': {'device': 'lan0',
                           'ipv4': {'address': '192.168.1.2',
                                    'network': '192.168.1.0',
                                    'interface': 'lan0',
                                    'address': '192.168.1.2'},
                           }}
    out = """\
Name Mtu   Network       Address      Ipkts Ierrs    Opkts Oerrs  Coll
lan0 1500  192.168.1.0   192.168.1.2   1     0         1     0     0
"""
    module = MockModule(out=out)
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert interfaces == INTERFACES



# Generated at 2022-06-20 18:11:02.543475
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Check initialization of class object
    hpuxnetwork = HPUXNetworkCollector(None)
    assert hpuxnetwork._fact_class == HPUXNetwork
    assert hpuxnetwork._platform == 'HP-UX'

# Generated at 2022-06-20 18:11:06.636564
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = DummyAnsibleModule()
    module.run_command = DummyRunCommand(0,
                                         "lan0: flags=8c02<BROADCAST,OACTIVE,SIMPLEX,MULTICAST> mtu 1500\n"
                                         "    addr: 0:0:b0:33:23:80\n"
                                         "    lan0:1: flags=4843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500\n"
                                         "    addr: 192.0.2.7 netmask: ffffff00 broadcast: 192.0.2.255\n")
    network = HPUXNetwork(module)
    interfaces_info = network.get_interfaces_info()

# Generated at 2022-06-20 18:11:17.505196
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.netstat_path = "/usr/bin/netstat"
    interfaces = module.get_interfaces_info()
    assert interfaces is not None
    assert len(interfaces) > 0
    assert 'lan0' in interfaces
    for iface in interfaces:
        assert interfaces[iface] is not None
        assert interfaces[iface]['device'] is not None
        assert interfaces[iface]['ipv4'] is not None
        assert interfaces[iface]['ipv4']['address'] is not None
        assert interfaces[iface]['ipv4']['network'] is not None
        assert interfaces[iface]['ipv4']['interface'] is not None



# Generated at 2022-06-20 18:11:19.716493
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Test HP-UX Network Collector"""
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:11:21.189450
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})

    assert network.platform == 'HP-UX'


# Generated at 2022-06-20 18:11:21.890937
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(None)
    assert network.platform == 'HP-UX'

# Generated at 2022-06-20 18:11:32.151802
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = AnsibleModule()
    m.get_bin_path = MagicMock(return_value='/usr/bin/netstat')

# Generated at 2022-06-20 18:11:39.705729
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )
    network = HPUXNetwork(module)
    version = '11.23'
    system = 'ia64'
    hostname = 'ansiblehp'
    fact_subset = module.params['gather_subset']
    network_facts = network.populate()

    # Assert for default interface
    assert 'default_interface' in network_facts

    # Assert for default gateway
    assert 'default_gateway' in network_facts

    # Assert for interfaces
    assert 'interfaces' in network_facts

# Generated at 2022-06-20 18:11:58.194827
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import sys
    import stat
    import tempfile
    import os


# Generated at 2022-06-20 18:12:09.830306
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_case = {
        'lan0': {
            'device': 'lan0',
            'ipv4': {
                'address': '192.168.1.1',
                'network': '192.168.1.0',
                'interface': 'lan0',
            }
        },
        'lan1': {
            'device': 'lan1',
            'ipv4': {
                'address': '172.16.1.1',
                'network': '172.16.1.0',
                'interface': 'lan1',
            }
        }
    }
    output = """
    lan0        <Link> lan0        192.168.1.0       -
    lan1        <Link> lan1        172.16.1.0       -
    """

# Generated at 2022-06-20 18:12:12.262735
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == HPUXNetwork.platform


# Generated at 2022-06-20 18:12:20.279883
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = Mock(run_command=Mock(return_value=(0,
                                                      'lan1000Mb 1000MB/s  up  up   inet'
                                                      ' 10.0.0.1       255.255.255.0',
                                                      '')))
    test_network = HPUXNetwork(test_module)
    expected_result = {'lan1000Mb': {'device': 'lan1000Mb',
                                     'ipv4': {'network': '10.0.0.0',
                                              'interface': 'lan1000Mb',
                                              'address': '10.0.0.1'}}}
    result = test_network.get_interfaces_info()
    assert result == expected_result

# Generated at 2022-06-20 18:12:31.234165
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:12:36.603940
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpu = HPUXNetwork(dict(module=dict()))
    assert hpu.get_default_interfaces() == {'default_gateway': '172.18.75.1',
                                            'default_interface': 'lan0'}


# Generated at 2022-06-20 18:12:48.080635
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import Network
    from ansible.module_utils.facts.network.hpux import NetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector


# Generated at 2022-06-20 18:12:59.539837
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mock_module = MockModule()
    net = HPUXNetwork(mock_module)

    netstat_path = mock_module.get_bin_path('netstat')
    if netstat_path is None:
        # netstat not present, so we can't do the test
        return

    assert net.populate() == \
            {'default_interface': 'lan0', 'default_gateway': '192.168.0.1',
             'interfaces': ['lan0'],
             'lan0': {'ipv4': {'address': '192.168.0.10',
                               'interface': 'lan0',
                               'network': '192.168.0.0/24'},
                      'device': 'lan0'}}



# Generated at 2022-06-20 18:13:01.538827
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces.keys()

# Generated at 2022-06-20 18:13:09.232991
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    data = ['lan0', "lan0 Link encap:Ethernet  HWaddr 00:1F:C6:23:6E:7E",
            "lo0 Link encap:Local Loopback",
            "lan0      192.168.10.0   0xffffff00        0x0          0      0"]
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    interfaces = hpux_network.get_interfaces_info()

# Generated at 2022-06-20 18:13:27.852352
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    hn = HPUXNetwork(module)
    facts = hn.populate()

    interfaces = facts["interfaces"]

    assert_equals(interfaces, ['lan0', 'lan1', 'lan2'])
    assert_equals(facts["lan0"]["ipv4"]["address"], '10.10.10.10')
    assert_equals(facts["lan0"]["ipv4"]["network"], '10.10.10.0')
    assert_equals(facts["lan1"]["ipv4"]["address"], '127.0.0.1')
    assert_equals(facts["lan1"]["ipv4"]["network"], '127.0.0.0')

# Generated at 2022-06-20 18:13:30.115387
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    ht = HPUXNetworkCollector()
    assert ht._fact_class == HPUXNetwork
    assert ht._platform == 'HP-UX'



# Generated at 2022-06-20 18:13:38.250936
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    lan1 = {'ipv4': {'network': '+',
                     'interface': 'lan1',
                     'address': '+'}}
    lan0 = {'ipv4': {'network': '+',
                     'interface': 'lan0',
                     'address': '+'}}
    interfaces = {'lan0': lan0, 'lan1': lan1}
    assert (network.get_interfaces_info() == interfaces)

# Generated at 2022-06-20 18:13:38.995795
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork(None)

# Generated at 2022-06-20 18:13:44.001328
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module = MagicMock()
    network.module.run_command.return_value = (0, 'default  172.20.46.1      UG        0    0        0 lan0\n172.20.46.0       172.20.46.1      U         0  176        0 lan0', None)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '172.20.46.1'



# Generated at 2022-06-20 18:13:49.280032
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    lines = "lan0          0 0x800000000 0x800001234  fe800000              0 0 0 0 0 0 0 0 0 0 0 0\n" \
            "lan1          0 0x800000000 0x800001234  fe800000              0 0 0 0 0 0 0 0 0 0 0 0\n"

    rc, out, err = AnsibleModule.run_command(module, "echo '" + lines + "'")
    network.netstat = {'rc': rc, 'stdout': out, 'stderr': err}
    interfaces = network.get_interfaces_info()
    assert interfaces['lan0']['ipv4']['address'] == 'fe800000'

# Generated at 2022-06-20 18:13:57.556218
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork()
    network.module = module

    interfaces = network.get_interfaces_info()
    assert interfaces  # Verify that dictionary is not empty
    assert ('tcp' not in interfaces)  # Verify that tcp is not in the dictionary
    assert ('lo0' not in interfaces)  # Verify that lo0 is not in the dictionary
    assert ('ip' not in interfaces)  # Verify that ip is not in the dictionary
    assert ('unix' not in interfaces)  # Verify that unix is not in the dictionary
    assert ('icmp' not in interfaces)  # Verify that icmp is not in the dictionary
    assert ('udp' not in interfaces)  # Verify that udp is not in the dictionary



# Generated at 2022-06-20 18:14:09.412716
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module_mock = Mock(return_value=None)
    module_mock.get_bin_path.return_value = "/usr/bin/netstat"
    module_mock.run_command.return_value = (0,
                                            "default 192.168.1.1 UGSc 7 0 lan0\n"
                                            "192.168.1.0/24 192.168.1.1 U 1 0 lan0",
                                            None)

    hpuxnetwork = HPUXNetwork(module=module_mock)
    hpuxnetwork_facts = hpuxnetwork.populate()

    assert hpuxnetwork_facts['default_interface'] == 'lan0'
    assert hpuxnetwork_facts['default_gateway'] == '192.168.1.1'

# Generated at 2022-06-20 18:14:11.271815
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    expected_result = HPUXNetworkCollector()
    assert expected_result._platform == 'HP-UX'
    assert expected_result._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:14:16.558018
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'
    assert network.get_default_interfaces is not None
    assert network.get_interfaces_info is not None


# Generated at 2022-06-20 18:14:37.990222
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Test method populate of class HPUXNetwork.
    We are creating here a mock-module object, to run the netstat -rn command
    with. This is a list of the result of the command.
    """
    result = [
        "default 10.10.10.254 UGSc  1 0 lan1",
        "10.10.10.0 10.10.10.255 UHLc 2 0 lan1"
    ]
    module_params = []
    module_args = dict(
        _ansible_version='2.9.9',
        ansible_facts={},
    )
    module_mock = AnsibleModuleMock(module_params, module_args)
    module_mock.run_command = MagicMock(return_value=result)

    # We are using here a mock-facts object

# Generated at 2022-06-20 18:14:48.580213
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import get_default_interfaces
    from ansible.module_utils.facts.network.hpux import get_interfaces_info

    class MockModule:

        def get_bin_path(self, foo):
            return "/usr/bin/netstat"

        def run_command(self, cmd):
            return 0, "", ""

    nm = HPUXNetwork(MockModule())
    facts = nm.populate()
    assert facts['interfaces'] == ['lan0']

# Generated at 2022-06-20 18:14:51.667514
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces

# Generated at 2022-06-20 18:14:58.883051
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_collector = NetworkCollector(module=module,
                                         subparser_loader=None)
    network = network_collector.collect()
    assert network.default_interface == 'lan0'
    assert network.default_gateway == '10.10.234.1'
    assert len(network.interfaces) == 3
    for device in network.interfaces:
        assert 'lan' == device[:3]
    assert network.lan0.ipv4.address == '10.10.234.209'
    assert network.lan0.ipv4.network == '10.10.234.0'

# Generated at 2022-06-20 18:15:09.010800
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    m_get_bin_path = MagicMock(side_effect=['/usr/bin/netstat', '/usr/bin/netstat'])
    m_run_command = MagicMock(side_effect=[(0, '', ''),
                                           (0,
                                            'default 127.0.0.1 UGDF 0 1 lan0',
                                            ''),
                                           (0,
                                            'lan0    IP  127.0.0.1       127.0.0.1       U -    -    -    -',
                                            '')])

# Generated at 2022-06-20 18:15:11.504535
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpx = HPUXNetwork()
    assert hpx.platform == 'HP-UX'


# Generated at 2022-06-20 18:15:19.786279
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    out_stat = """
    Routing tables

    Internet:
    Destination        Gateway           Flags Refs Use If  Mtu  Interface
    127.0.0.1          127.0.0.1          UH       47 778 lo0
    default            10.0.0.1           UG        5   0 lan0
    10.0.0.0           10.0.0.11          U         -   - lan0
    127.0.0.1          127.0.0.1          UH       51  13 lo0
    """
    network = HPUXNetwork()
    network.module = MockModule()
    network.module.run_command = Mock(return_value=(0, out_stat, ''))

    default_interfaces_facts = network.get_default_interfaces()
    assert default_interfaces_

# Generated at 2022-06-20 18:15:25.318532
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    rc, out, err = net.module.run_command("/usr/bin/netstat -nr")
    assert HPUXNetwork.get_default_interfaces(net) == {'default_interface': 'lan0', 'default_gateway': '9.65.0.1'}


# Generated at 2022-06-20 18:15:29.303657
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    n = HPUXNetwork()
    assert n.platform == 'HP-UX'
    assert n.interfaces == None


# Generated at 2022-06-20 18:15:40.037144
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, *args):
            return self.rc, self.out, self.err

    netstat_path = '/usr/bin/netstat'
    rc = 0
    out = """default 192.168.1.1 UG 1 24 lan0
default 0.0.0.0 UH 2 4 vlan2
default 10.10.10.10 UG 1 24 lan0
default 0.0.0.0 UH 2 4 vlan1"""
    err = ''
    module = TestModule(rc, out, err)
    HPUXNetworkCollector._fact_class.module = module
    net = HPUXNetworkCollect

# Generated at 2022-06-20 18:16:08.926386
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {'lan0': {'device': 'lan0', 'ipv4': {'address': '172.22.0.24',
                                                      'network': '172.22.0.24',
                                                      'interface': 'lan0'}}}
    network = HPUXNetwork()
    assert network.get_interfaces_info() == interfaces

# Generated at 2022-06-20 18:16:20.813614
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netstat_out = 'default 192.168.0.1 UG 1 en0\ndefault 192.168.0.1 UG 2 lo0'
    obj = HPUXNetwork()
    obj.module = MockModule()
    obj.module.run_command = Mock(return_value = (0, netstat_out, ''))
    default_interfaces = obj.get_default_interfaces()
    assert 'default_interface' in default_interfaces
    assert default_interfaces['default_interface'] == 'en0'
    assert 'default_gateway' in default_interfaces
    assert default_interfaces['default_gateway'] == '192.168.0.1'



# Generated at 2022-06-20 18:16:27.080704
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Init mock module
    module = MockNetworkModule()
    # Set return value for run_command for netstat
    # Note, we have to use 'bare' dictionaries, because this is what ansible
    # would pass to the run_command function of module_utils.command
    # (see https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/command.py#L17)
    # We use a list of dictionaries, where each dictionary describes one call
    # of run_command.

# Generated at 2022-06-20 18:16:30.387370
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    networkCollector = HPUXNetworkCollector()
    result = networkCollector._get_fact_class()
    assert(HPUXNetwork == result)

# Generated at 2022-06-20 18:16:38.734612
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_mock = MockedModule()
    test_mod = HPUXNetwork(test_mock)
    test_mod.get_interfaces_info()
    assert test_mock.run_command.called
    assert (0, 'lan0  lan  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0') in test_mock.run_command.call_args_list
    assert ('lan0',
            {'device': 'lan0',
             'ipv4': {'address': '0',
                      'network': '0',
                      'interface': 'lan0'}}) in test_mod.interfaces.items()

# Generated at 2022-06-20 18:16:42.116073
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork(dict(module=None, params=None)).get_interfaces_info()
    assert 'lan1' in interfaces

# Generated at 2022-06-20 18:16:44.623805
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net = HPUXNetworkCollector()
    assert net is not None


# Generated at 2022-06-20 18:16:50.827569
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network import Network
    import os
    hosts_path = os.path.join(os.path.dirname(__file__), '../../', 'tests/units/module_utils/network/hpux/ansible_net_tools/')
    hpux_network = HPUXNetwork(None, hosts_path)
    network_facts = hpux_network.populate()
    assert 'default_interface' in network_facts
    assert 'interfaces' in network_facts
    assert len(network_facts['interfaces']) > 0

# Generated at 2022-06-20 18:17:00.484372
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    test_interfaces = ["lan0", "lan1", "lan2"]

# Generated at 2022-06-20 18:17:04.372022
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(None)
    assert network.platform == 'HP-UX'



# Generated at 2022-06-20 18:18:10.022692
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:18:19.673371
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    class AnsibleModuleMock(object):
        def __init__(self):
            self.run_command_rc = 0

# Generated at 2022-06-20 18:18:31.134657
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()
    net.module = MockModule()
    rc, out, err = net.module.run_command("/usr/bin/netstat -niw")
    net.out = out


# Generated at 2022-06-20 18:18:35.335262
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeModule()
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'
    assert hpux_network._default_interface == {}
    assert hpux_network._fact_class == HPUXNetwork
    assert hpux_network._interfaces == {}
    assert hpux_network.module == module


# Generated at 2022-06-20 18:18:44.170379
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

# Generated at 2022-06-20 18:18:52.364621
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Get the Network class object
    network_collector = HPUXNetworkCollector(module=module)
    network_object = network_collector.collect()[0]

    # Call the populate method
    network_object.populate()
    # Test the default_interface fact
    assert 'default_interface' in network_object.network_facts
    assert 'default_gateway' in network_object.network_facts
    # Test the interface fact
    assert 'interfaces' in network_object.network_facts



# Generated at 2022-06-20 18:18:55.423955
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj1 = HPUXNetworkCollector()
    assert obj1._fact_class == HPUXNetwork
    assert obj1._platform == 'HP-UX'

# Generated at 2022-06-20 18:19:02.461818
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    '''
    This unit test checks that method get_default_interfaces of class HPUXNetwork
    returns a dictionary of network interfaces that contains the expected keys
    and values.
    '''
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    test_arguments = {
        'module': None,
        'run_command': HPUXNetwork.run_command,
        'get_file_content': HPUXNetwork.get_file_content,
        'get_bin_path': HPUXNetwork.get_bin_path,
    }

    network = HPUXNetwork()
    network.__dict__.update(test_arguments)

    interfaces = network.get_interfaces_info()
    assert isinstance(interfaces, dict)


# Generated at 2022-06-20 18:19:07.989605
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    m = HPUXNetwork()
    lines = ['lan0: flags=8d43<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 1',
             '        inet 192.168.0.123 netmask ffffff00 broadcast 192.168.0.255',
             '        ether 00:14:4f:e3:74:4a',
             'lan1: flags=8d43<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 1',
             '        inet 192.168.0.123 netmask ffffff00 broadcast 192.168.0.255',
             '        ether 00:14:4f:e3:74:4b']
    outputs = m.get_interfaces_info()

# Generated at 2022-06-20 18:19:14.808537
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)

    module.run_command = MagicMock(return_value=(0, 'default 123.123.123.123'
                                                    'lan123 123.123.123.0', None))
    module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    network.populate()
    assert network.default_interface == 'lan123'
    assert network.default_gateway == '123.123.123.123'
    assert network.interfaces == ['lan123']
    assert network.lan123 == {'ipv4': {'address': '123.123.123.0',
                                'network': '123.123.123.0', 'interface':
                                'lan123'}}

