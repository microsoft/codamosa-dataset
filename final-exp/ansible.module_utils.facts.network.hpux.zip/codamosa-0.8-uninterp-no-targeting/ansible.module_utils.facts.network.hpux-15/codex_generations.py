

# Generated at 2022-06-20 18:09:40.678171
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = HPUXNetworkCollector._create_module()
    net_fact = HPUXNetworkCollector._create_fact(module)

    assert "default_interface" == net_fact.populate()['default_interface'], \
           "Failed to collect default interface"

# Generated at 2022-06-20 18:09:46.975740
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    my_HP_UX = HPUXNetwork()
    my_HP_UX.module = Facts().module
    # my_HP_UX.get_default_interfaces = MagicMock()
    # my_HP_UX.get_interfaces_info = MagicMock()
    res = my_HP_UX.populate()
    # print (my_HP_UX.get_default_interfaces())
    print(res)



# Generated at 2022-06-20 18:09:48.907059
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    n = HPUXNetwork()
    assert n.platform == 'HP-UX'


# Unit tests for functions defined for class HPUXNetwork

# Generated at 2022-06-20 18:10:00.773913
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import NetstatCollector
    from ansible.module_utils.facts.network.hpux import Response
    hpux_network_instance = HPUXNetwork()
    netstat_collector_instance = NetstatCollector()
    response_obj = Response()
    response_obj.rc = 0
    response_obj.stdout = 'lan0      <Link#1>   fdd0       0        0    0    0    0    0        -        -        -        -        0.0.0.0         0.0.0.0        127.0.0.1   127.0.0.1        -        -        -        -        -'
    netstat_collector_instance

# Generated at 2022-06-20 18:10:09.864326
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    hpn = HPUXNetwork(module)

    hpn.module.run_command = Mock(return_value=(0, 'default 127.0.0.1 UGSc lan0', ''))
    assert hpn.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '127.0.0.1'}

    hpn.module.run_command = Mock(return_value=(0, 'default 127.0.0.1 UGSc', ''))
    assert hpn.get_default_interfaces() == {'default_interface': '', 'default_gateway': '127.0.0.1'}

    hpn.module.run_command = Mock(return_value=(1, '', 'error'))
    assert hpn.get_

# Generated at 2022-06-20 18:10:12.506527
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector.platform is HPUXNetwork._platform
    assert HPUXNetworkCollector._fact_class is HPUXNetwork

# Generated at 2022-06-20 18:10:25.262028
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()
    hpux_network = HPUXNetwork(module)
    facts = hpux_network.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '192.168.128.1'
    assert 'interfaces' in facts
    assert 'lan0' in facts
    assert 'lan0' in facts['interfaces']
    assert 'ipv4' in facts['lan0']
    assert 'address' in facts['lan0']['ipv4']
    assert 'network' in facts['lan0']['ipv4']
    assert '0x10001b8a' in facts['lan0']['ipv4']['network']



# Generated at 2022-06-20 18:10:36.620901
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    module.run_command = run_command
    n = HPUXNetwork(module)
    facts = n.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '192.168.1.1'
    assert sorted(facts['interfaces']) == ['lan0', 'lan18']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '192.168.1.200'
    assert facts['lan0']['ipv4']['network'] == '192.168.1.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-20 18:10:37.468210
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass

# Generated at 2022-06-20 18:10:40.180386
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._platform == 'HP-UX'

# Generated at 2022-06-20 18:10:51.513547
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    module = AnsibleModule(argument_spec=dict())
    networking = HPUXNetwork()
    interfaces = networking.get_interfaces_info()
    module.exit_json(interfaces=interfaces)



# Generated at 2022-06-20 18:10:55.668185
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts import collector
    import os

    os_name = os.name
    os.name = 'posix'

    l = collector.get_network_collector()
    assert isinstance(l, HPUXNetworkCollector)

    os.name = os_name

# Generated at 2022-06-20 18:11:07.119975
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from tempfile import mkdtemp
    import shutil
    import os
    import sys
    import tempfile
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 18:11:16.923439
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mock_module = MockModule({})
    hpux_net = HPUXNetwork(mock_module)
    default_interfaces = hpux_net.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '172.16.1.254'
    interfaces = hpux_net.get_interfaces_info()['lan0']
    assert interfaces['ipv4']['address'] == '172.16.1.179'
    assert interfaces['device'] == 'lan0'


# Unit Test for method populate of class HPUXNetworkCollector

# Generated at 2022-06-20 18:11:25.433838
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module)
    output = """
default 192.168.0.1
"""
    module.run_command.return_value = (0, output, '')
    network.get_default_interfaces()
    assert_equal(network.default_interface, 'lan0')
    assert_equal(network.default_gateway, '192.168.0.1')



# Generated at 2022-06-20 18:11:31.087823
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Test case to demonstrate simple unit testing of methods of class HPUXNetwork
    using pytest.
    """
    unittest_module = HPUXNetwork()
    interfaces = unittest_module.get_interfaces_info()
    assert 'lan0' in interfaces.keys()

# Generated at 2022-06-20 18:11:32.413685
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpuNetwork = HPUXNetwork()
    assert hpuNetwork.platform == 'HP-UX'



# Generated at 2022-06-20 18:11:38.172564
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = AnsibleModule()
    m.run_command = lambda x: (0, "default 10.1.1.1 UGSc I 224 lan0", None)
    hpu = HPUXNetwork()
    result = hpu.get_default_interfaces()
    assert 'default_interface' in result
    assert 'default_gateway' in result
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.1.1.1'

# Generated at 2022-06-20 18:11:47.786227
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_ins = HPUXNetwork()
    network_facts = net_ins.populate()
    assert network_facts['default_interface'] == 'lan900'
    assert network_facts['default_gateway'] == '192.168.1.1'
    assert network_facts['interfaces'] == ['lan900']
    assert network_facts['lan900']['device'] == 'lan900'
    assert network_facts['lan900']['ipv4']['address'] == '192.168.1.14'
    assert network_facts['lan900']['ipv4']['network'] == '192.168.1'
    assert network_facts['lan900']['ipv4']['interface'] == 'lan900'



# Generated at 2022-06-20 18:11:56.322124
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork(dict(module=None))
    netstat_output = "default 10.9.8.7 UG 1 1 kai0\n"
    network.module.run_command = lambda x, *_, **__: (0, netstat_output, '')
    assert network.get_default_interfaces() == {'default_interface': 'kai0',
                                                'default_gateway': '10.9.8.7'}


# Generated at 2022-06-20 18:12:18.541412
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import sys
    import tempfile
    from ansible.module_utils.facts.network.hpubase import HPUXNetwork
    import pytest

    myhostname = 'myhostname'

    # Create a file with the contents of the second netstat -niw command
    # to be returned by ansible.module_utils.basic.AnsibleModule.run_command
    netstat_out = """
Name  Mtu   Network       Address              Ipkts Ierrs    Opkts Oerrs  Coll
lan0  1500  172.18.93.0   172.18.93.145    41693739     0 28443842     0  0
lan1  1500  172.18.94.0   172.18.94.145     4684536     0  2788888     0  0
    """
   

# Generated at 2022-06-20 18:12:28.234878
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    network = HPUXNetwork(module)
    facts = network.populate()
    assert 'default_interface' in facts
    assert 'default_gateway' in facts
    assert 'interfaces' in facts
    assert 'en0' in facts['interfaces']
    assert 'ipv4' in facts['en0']
    assert 'address' in facts['en0']['ipv4']
    assert 'network' in facts['en0']['ipv4']
    assert 'interface' in facts['en0']['ipv4']



# Generated at 2022-06-20 18:12:35.616652
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = mock.Mock(return_value=(0, '', ''))

    test_populate_network = HPUXNetwork().populate()
    assert 'default_interface' in test_populate_network
    assert 'interfaces' in test_populate_network



# Generated at 2022-06-20 18:12:37.668228
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    This is a placeholder for automated tests using pytest.
    """
    pass

# Generated at 2022-06-20 18:12:41.991631
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # This test case can be run only after installation of HP-UX
    collected_fact = {
        'default_interface': 'lan0',
        'default_gateway': '172.31.56.254'
    }
    hpux_network = HPUXNetwork()
    fact = hpux_network.get_default_interfaces()
    assert fact == collected_fact



# Generated at 2022-06-20 18:12:51.910179
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Test for method populate of class HPUXNetwork.
    """
    # Test 1: no argument
    # Test 2: argument is not dict
    # Test 3: argument is dict but no key "device"

    # Test 1: no argument
    hpuxtest = HPUXNetwork()
    hpuxtest.module = FakeAnsibleModule()
    result = hpuxtest.populate()
    assert result == {'interfaces': ['lan0'], 'default_interface': 'lan0',
                      'default_gateway': '10.0.1.1', 'lan0': {'ipv4': {
                          'network': '10.0.1.0', 'interface': 'lan0',
                          'address': '10.0.1.2'}, 'device': 'lan0'}}

    #

# Generated at 2022-06-20 18:12:53.938712
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    networks = HPUXNetwork(None)
    assert networks is not None


# Generated at 2022-06-20 18:12:55.138431
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:13:05.491685
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    network = HPUXNetwork(module=module)
    facts = network.populate()

    default_interface = facts['default_interface']
    interfaces = facts['interfaces']
    for iface in interfaces:
        if iface == default_interface:
            pass
        else:
            assert 'ipv4' in facts[iface]
            assert 'address' in facts[iface]['ipv4']
            assert 'network' in facts[iface]['ipv4']

# Unit test class HPUXNetworkCollector

# Generated at 2022-06-20 18:13:17.383026
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    collected_facts = {}
    interfaces = network.populate(collected_facts)
    assert interfaces['default_interface'] == 'lan4'
    assert interfaces['default_gateway'] == '10.2.2.2'
    assert interfaces['interfaces'] == ['lan4']
    assert interfaces['lan4']['ipv4']['address'] == '10.2.2.171'
    assert interfaces['lan4']['ipv4']['network'] == '10.2.2.0'
    assert interfaces['lan4']['ipv4']['interface'] == 'lan4'
    assert interfaces['lan4']['ipv4']['address'] == '10.2.2.171'



# Generated at 2022-06-20 18:13:39.061698
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network._fact_class == HPUXNetwork
    assert network._platform == 'HP-UX'

# Generated at 2022-06-20 18:13:47.589601
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Tests the get_default_interfaces and get_interfaces_info methods of
    the HPUXNetwork class.
    """
    hn = HPUXNetwork()
    network_facts = hn.populate()

    expected_interfaces = {
        'default_interface': 'lan0',
        'default_gateway': '10.0.16.1',
        'interfaces': ['lan0'],
        'lan0': {
            'ipv4': {'address': '10.0.16.206',
                     'interface': 'lan0',
                     'network': '10.0.16.0'
                     }
            }
        }

    assert network_facts == expected_interfaces

# Generated at 2022-06-20 18:13:50.647353
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert (obj._fact_class == HPUXNetwork)
    assert (obj._platform == 'HP-UX')

# Generated at 2022-06-20 18:13:54.880721
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Create an instance of HPUXNetworkCollector
    """
    hnCollector = HPUXNetworkCollector()
    assert hnCollector._platform == 'HP-UX'

# Generated at 2022-06-20 18:14:01.687153
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(module)
    result = network.populate()
    result.pop('interfaces')
    assert result == dict(default_interface='lan0', default_gateway='192.168.1.1')
#

# Generated at 2022-06-20 18:14:03.361676
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:14:12.312380
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """ Ansible facts Network_get_default_interfaces """
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    network_collector = HPUXNetworkCollector(module)
    network = network_collector.get_network_inst()

    default_interface = network.get_default_interfaces()
    assert isinstance(default_interface, object)
    assert 'default_interface' in default_interface
    assert 'default_gateway' in default_interface



# Generated at 2022-06-20 18:14:24.035909
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    import sys
    import os

    test_file_path = os.path.dirname(sys.modules[__name__].__file__)
    test_base_path = os.path.dirname(test_file_path)
    sys.path.insert(0, test_base_path)
    from module_utils.facts.network.hpux import HPUXNetwork

    network_facts = HPUXNetwork().populate()
    assert type(network_facts) is dict
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.10.43.1'

# Generated at 2022-06-20 18:14:36.835676
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    hpuxnetwork = HPUXNetwork(module)

    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]

    hpuxnetwork.populate()
    assert hpuxnetwork['default_interface'] == default_interface
    assert hpuxnetwork['default_gateway'] == default_gateway

    assert hpuxnetwork['interfaces']
    interfaces = hpuxnetwork['interfaces']
    assert 'lan0' in hpuxnetwork['interfaces']

    rc, out, err = module.run_command

# Generated at 2022-06-20 18:14:46.686509
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class HPUXNetworkStub(HPUXNetwork):
        def __init__(self):
            pass

        def run_command(self, command):
            test_data = "default 172.31.254.1 UGSc       10 10.10.10.1\n"
            return 0, test_data, ''

    fact_class = HPUXNetworkStub()
    default_interfaces = fact_class.get_default_interfaces()
    assert default_interfaces['default_gateway'] == "172.31.254.1"
    assert default_interfaces['default_interface'] == "10.10.10.1"


# Generated at 2022-06-20 18:15:30.569985
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    facts = network_facts.populate()
    assert(facts)


# Generated at 2022-06-20 18:15:32.507476
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj is not None

# Generated at 2022-06-20 18:15:39.454771
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    fake_module = type('', (), dict(run_command=lambda *args, **kwargs: (0, 'lo0\tlan0\tlan1\tlan2\tlan3\tlan4', '')))()

    net = HPUXNetwork(fake_module)
    interfaces = net.get_interfaces_info()
    assert len(interfaces) == 5
    assert set(interfaces.keys()) == set(['lan0', 'lan1', 'lan2', 'lan3', 'lan4'])

# Generated at 2022-06-20 18:15:50.593906
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    HPUXNetwork = HPUXNetwork()

    interfaces = [
        {
            'device': 'lan0',
            'ipv4': {
                'network': '192.0.2.0',
                'interface': 'lan0',
                'address': '192.0.2.1'
            }
        },
        {
            'device': 'lan1',
            'ipv4': {
                'network': '192.0.3.0',
                'interface': 'lan1',
                'address': '192.0.3.1'
            }
        }
    ]


# Generated at 2022-06-20 18:16:00.453383
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Return a dictionary of facts from the script file.
    """
    default_interfaces = module.get_default_interfaces()
    default_iface = default_interfaces['default_interface']
    default_gateway = default_interfaces['default_gateway']
    interfaces = module.get_interfaces_info()
    assert default_iface == 'lan0'
    assert default_gateway == '10.105.13.1'
    assert interfaces == {'lan0': {'device': 'lan0',
                                   'ipv4': {'address': '10.105.13.200',
                                            'interface': 'lan0',
                                            'network': '10.105.13.0'}}}


# Generated at 2022-06-20 18:16:07.190952
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    interfaces = HPUXNetwork()
    default_interfaces = interfaces.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan5'
    assert default_interfaces['default_gateway'] == '10.0.0.1'



# Generated at 2022-06-20 18:16:13.133864
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netstat = '''
      Routing tables

      Internet:
      Destination        Gateway           Flags   Refs     Use  If
      default            10.192.64.194     UG         1   54084  lan1
      '''
    network = HPUXNetwork()
    network.module.run_command = lambda *args, **kwargs: (0, netstat, '')

    network.populate()

    assert len(network.facts) == 2
    assert network.facts['default_interface'] == 'lan1'
    assert network.facts['default_gateway'] == '10.192.64.194'

    del network


# Generated at 2022-06-20 18:16:21.680008
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class mock_module:
        def run_command(self):
            return (0, 'lan0           link#6           proto        IP    \
            lan0           link#6                           UP           \
            lan0           link#6                           UP              \
            lan0           34.56.78.90/23', '')

        def get_bin_path(self):
            return '/usr/bin/netstat'

    mock_module = mock_module()
    hpn = HPUXNetwork(mock_module)
    interfaces = hpn.get_interfaces_info()

# Generated at 2022-06-20 18:16:25.392626
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert str(type(net)) == "<class 'ansible.module_utils.facts.network.hpu_ux.HPUXNetwork'>"


# Generated at 2022-06-20 18:16:34.490047
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Module is not available in Windows
    module = AnsibleModule(argument_spec={})
    hpux_network_facts = HPUXNetwork()
    network_facts = hpux_network_facts.populate()
    interfaces = network_facts['interfaces']
    assert 'lan5' in interfaces
    assert network_facts['default_interface'] == 'lan5'

    assert network_facts['lan5']['ipv4']['address'] == '10.0.0.15'


# Generated at 2022-06-20 18:18:17.107749
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork(dict())
    test_out = net.get_default_interfaces()
    assert test_out == {'default_interface': 'lan2',
                        'default_gateway': '10.0.0.1'}


# Generated at 2022-06-20 18:18:23.007976
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c._platform == "HP-UX"
    assert c.platform == "HP-UX"
    assert c._fact_class == HPUXNetwork
    assert c.fact_class == HPUXNetwork

# Generated at 2022-06-20 18:18:26.959711
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.__class__.__name__ == 'HPUXNetworkCollector'

# Generated at 2022-06-20 18:18:33.456313
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}

# Generated at 2022-06-20 18:18:34.139222
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-20 18:18:37.968584
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpux_network_obj = HPUXNetwork()
    interfaces = hpux_network_obj.get_interfaces_info()
    assert interfaces
    for i in (('lan0', '192.168.10.1'), ('lan1', '192.168.10.2'), ('lan2', '192.168.10.3')):
        assert i in interfaces.items()

# Generated at 2022-06-20 18:18:41.087052
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork(dict(), dict())
    assert hpux_network.platform == 'HP-UX'
    assert hpux_network.collector == 'HPUXNetworkCollector'

# Generated at 2022-06-20 18:18:45.116165
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = mock.MagicMock()
    module.run_command.return_value = (0, "/usr/bin/netstat -nr output", None)
    hpn = HPUXNetwork(module)
    default_interfaces = hpn.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan1'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-20 18:18:49.184552
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    # Test empty constructor
    network_collector = HPUXNetwork()

    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:18:59.611840
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule:
        def run_command(self, *args, **kwargs):
            out = "default 192.168.1.1 UG 8 0 lan0"
            return 0, out, ""
        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/netstat"
    mock_module = MockModule()
    HPUXNet = HPUXNetwork(mock_module)
    result = HPUXNet.get_default_interfaces()
    expected_result = {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}
    assert result == expected_result
