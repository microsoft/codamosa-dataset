

# Generated at 2022-06-20 18:09:47.769194
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    network = HPUXNetwork(None)

    # Expected output
    interfaces = {}
    interfaces['lan0'] = {'device': 'lan0',
                          'ipv4': {'network': '10.33.77.0',
                                   'interface': 'lan0',
                                   'address': '10.33.77.111'}}

    # Test input

# Generated at 2022-06-20 18:09:54.807965
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    network = HPUXNetwork()
    network.module = module
    network.module.run_command = FakeCommand
    default_interfaces_facts = network.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '172.17.15.254'


# Generated at 2022-06-20 18:10:05.457409
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Arrange
    module = MockModule()
    network_collector = HPUXNetworkCollector(module)
    network_collector._module = module
    network = HPUXNetwork(module)

    module.run_command.return_value = (0, 'default 192.168.1.1 us.rd.yahoo.com UGSc 1 1 lan3', '')
    # Act
    network._populate()

    # Assert
    expected = {'default_interface': 'lan3', 'default_gateway': '192.168.1.1'}
    assert network._facts['default_interface'] == expected['default_interface']
    assert network._facts['default_gateway'] == expected['default_gateway']
    assert network._facts['interfaces'] == ['lan3']

# Generated at 2022-06-20 18:10:10.242535
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu = HPUXNetwork()
    if hpu.platform == 'HP-UX':
        print("test_HPUXNetwork Passed")
    else:
        print("test_HPUXNetwork Failed")


# Generated at 2022-06-20 18:10:12.710073
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    my_network = HPUXNetwork()
    interfaces = my_network.get_default_interfaces()
    print(interfaces)



# Generated at 2022-06-20 18:10:25.595489
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    class Module(object):

        def __init__(self):
            self.run_command_calls = 0

        def run_command(self, cmd):
            self.run_command_calls += 1

# Generated at 2022-06-20 18:10:29.416934
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class is HPUXNetwork


# Generated at 2022-06-20 18:10:33.482587
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collect_net_obj = HPUXNetworkCollector()
    assert collect_net_obj._platform == 'HP-UX'
    assert collect_net_obj._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:10:43.653371
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    net = HPUXNetwork(module)
    interfaces = {'lan0': {'device': u'lan0', 'ipv4': {'address': u'172.16.1.2', 'network': u'172.16.1.0', 'interface': 'lan0'}}}
    result = net.get_interfaces_info()
    assert result == interfaces, 'result: %s' % result


# Generated at 2022-06-20 18:10:52.718322
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network_info = HPUXNetwork()
    interfaces = network_info.get_interfaces_info()
    print(interfaces)
    assert interfaces == {'lan0': {'ipv4': {'address': '127.0.0.1',
                                            'interface': 'lan0',
                                            'network': '127.0.0.0'},
                                  'device': 'lan0'}}



# Generated at 2022-06-20 18:11:03.083353
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-20 18:11:06.985418
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """ Unit test for method get_default_interfaces of class HPUXNetwork """
    network_facts = HPUXNetwork()
    default_interfaces = network_facts.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.0.2.1'


# Generated at 2022-06-20 18:11:14.734483
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModuleMock()
    module.run_command = lambda *args, **kwargs: (0, "", "")
    module.get_bin_path = lambda *args, **kwargs: "/usr/bin/netstat"
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'
    assert network.interfaces == []
    assert network.default_interface is None

# Generated at 2022-06-20 18:11:17.837838
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Constructor without arguments
    c = HPUXNetworkCollector()
    assert c



# Generated at 2022-06-20 18:11:29.397519
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class ModuleFake(object):
        def __init__(self):
            self.run_command_result = (0, 'lan0: flags=0a<BROADCAST,SMART,MULTICAST,IPv4> mtu 1500 index 1 inet 192.168.2.7 netmask 8 prefixlen 255\nlan1: flags=0a<BROADCAST,SMART,MULTICAST,IPv4> mtu 1500 index 2 inet 192.168.2.8 netmask ffffff00 prefixlen 24\nlan1: flags=0a<BROADCAST,SMART,MULTICAST,IPv4> mtu 1500 index 2 inet 192.168.2.9 netmask 8 prefixlen 255', '')

        def get_bin_path(self, path):
            return "/usr/bin/netstat"


# Generated at 2022-06-20 18:11:31.160874
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork

# Generated at 2022-06-20 18:11:35.190868
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    obj = HPUXNetwork()
    mock_run_command = obj.module.run_command
    mock_run_command.return_value = 0, '', ''
    obj.populate()
    assert mock_run_command.call_count == 2

# Generated at 2022-06-20 18:11:47.290816
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleStub()
    fill_module_args(module)
    net_coll = HPUXNetworkCollector(module)
    fact = net_coll.populate()
    assert fact == {'default_interface': 'lan2',
                    'default_gateway': '10.0.0.1',
                    'interfaces': ['lan1', 'lan2'],
                    'lan1': {'ipv4': {'address': '192.168.2.100',
                                   'network': '192.168.2.0',
                                   'interface': 'lan1'}},
                    'lan2': {'ipv4': {'address': '10.0.0.100',
                                   'network': '10.0.0.0',
                                   'interface': 'lan2'}}}

# Unit

# Generated at 2022-06-20 18:11:57.062780
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    def mock_run_command(self):
        return 0, '192.168.4.254 localhost.localdomain', ''
    HPUXNetwork._run_command = mock_run_command

    default_interfaces_facts = {}
    default_interfaces_facts['default_interface'] = 'localhost.localdomain'
    default_interfaces_facts['default_gateway'] = '192.168.4.254'

    net = HPUXNetwork()
    assert net.get_default_interfaces() == default_interfaces_facts


# Generated at 2022-06-20 18:12:06.338873
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    net = HPUXNetwork(module=None)
    net.module = MockNetworkModule()
    net.module.run_command = MockRunCommand()

    default_interfaces_facts = net.get_default_interfaces()
    assert default_interfaces_facts == {'default_interface': 'lan0',
                                        'default_gateway': '1.2.3.4'}



# Generated at 2022-06-20 18:12:17.746621
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network.platform == 'HP-UX'
    assert network._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:12:19.123560
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork(dict())
    assert net

# Generated at 2022-06-20 18:12:25.803915
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork.get_interfaces_info([])
    assert interfaces['lan0'] == {'ipv4': {'address': '173.194.32.128', 'network': '173.194.32.0', 'interface': 'lan0'}, 'device': 'lan0'}

# Generated at 2022-06-20 18:12:30.303899
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpuxnc = HPUXNetworkCollector()
    assert hpuxnc._fact_class == HPUXNetwork
    assert hpuxnc._platform == 'HP-UX'

# Generated at 2022-06-20 18:12:40.005173
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    iface = HPUXNetwork(module)
    default_interfaces = iface.get_default_interfaces()
    assert len(default_interfaces) == 2
    assert default_interfaces['default_interface'] == 'lan9'
    assert default_interfaces['default_gateway'] == '172.17.157.254'


# Generated at 2022-06-20 18:12:43.265618
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    network = HPUXNetwork(module)
    network.get_default_interfaces = MagicMock()
    network.get_default_interfaces.return_value = "default"
    result = network.get_default_interfaces()
    assert result == "default"
    assert type(result) is str


# Generated at 2022-06-20 18:12:44.215529
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    hpx = HPUXNetwork()
    assert hpx is not None

    return hpx



# Generated at 2022-06-20 18:12:47.912207
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hpu import HPUXNetworkCollector

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    collector_obj = HPUXNetworkCollector(module=module)
    assert (type(collector_obj)) is HPUXNetworkCollector
    assert type(collector_obj.collect()) is dict
    assert collector.NetworkCollector not in collector_obj.__class__.__bases__



# Generated at 2022-06-20 18:12:55.110468
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, "", ""))
    h = HPUXNetwork(mock_module)
    facts = h.populate()
    assert sorted(facts.keys()) == ['default_interface', 'default_gateway',
                                    'interfaces']

# Generated at 2022-06-20 18:12:57.422954
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    assert hpn.platform == 'HP-UX'

# Generated at 2022-06-20 18:13:20.268540
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    fact_module = HPUXNetwork(module)
    interfaces = fact_module.get_interfaces_info()
    assert interfaces

# Generated at 2022-06-20 18:13:26.372465
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hn = HPUXNetwork()
    hn.module = MockModule()
    hn.module.run_command = MockRunCommand()


# Generated at 2022-06-20 18:13:32.719279
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hn = HPUXNetwork()
    interfaces = hn.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['address'] == '172.22.0.11'


# Generated at 2022-06-20 18:13:39.114547
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpu_net_obj = HPUXNetwork()
    interfaces = hpu_net_obj.get_interfaces_info()
    assert isinstance(interfaces, dict)
    assert 'lan0' in interfaces
    assert 'ipv4' in interfaces['lan0']
    assert 'address' in interfaces['lan0']['ipv4']
    assert 'network' in interfaces['lan0']['ipv4']
    assert 'interface' in interfaces['lan0']['ipv4']
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-20 18:13:45.362886
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    my_HPUXNetwork = HPUXNetwork()
    rc, out, err = my_HPUXNetwork.module.run_command("/usr/bin/netstat -niw")
    my_HPUXNetwork.module.run_command = Mock(return_value=(rc, out, err))
    my_HPUXNetwork.module.get_bin_path = Mock(return_value="/usr/bin/netstat")
    my_HPUXNetwork.get_default_interfaces = Mock(return_value={"default_interface":"lan0", "default_gateway":"192.168.1.1"})

# Generated at 2022-06-20 18:13:47.747660
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector is not None


# Generated at 2022-06-20 18:13:50.224714
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()  # constructor call
    assert hpux_network is not None


# Generated at 2022-06-20 18:13:59.168008
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    expected_interfaces = {'lan0': {'device': 'lan0', 'ipv4':
                                    {'address': '10.10.10.10', 'network': '10.10.10.0',
                                     'interface': 'lan0', 'address': '10.10.10.10'}},
                           'lan1': {'device': 'lan1', 'ipv4':
                                    {'address': '10.10.10.20', 'network': '10.10.10.0',
                                     'interface': 'lan1', 'address': '10.10.10.20'}}}
    interfaces = net.get_interfaces_info()
    assert interfaces == expected_interfaces


# Generated at 2022-06-20 18:14:08.644829
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module_mock = Mock()
    module_mock.get_bin_path.return_value = "netstat_path"
    module_mock.run_command.return_value = ('return_code', 'out', 'err')

    expected = {'default_interface': 'default_interface',
                'default_gateway': 'default_gateway',
                'interfaces': ['lan3'],
                'lan3': {'device': 'lan3',
                         'ipv4': {'address': 'address',
                                  'network': 'network'}}}

    assert test_collector.populate(HPUXNetwork(module_mock)) == expected

# Generated at 2022-06-20 18:14:17.181686
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.run_command = None
            self.get_bin_path = None

    facts_obj = HPUXNetwork(MockModule())

    rc, out, err = [0,
                    'default 192.168.99.1 UG 1000 0 en0\n'
                    '127 127.0.0.1 UCS 0 0 lo0\n'
                    '127.0.0.1 127.0.0.1 UH 2 0 lo0\n',
                    '']
    facts_obj.module.run_command = lambda x: (rc, out, err)

    facts_obj._default_interfaces = None
    facts_obj.default_interfaces = None


# Generated at 2022-06-20 18:15:00.866785
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec=dict())
    test_HPUXNetwork = HPUXNetwork(test_module)
    out = "lan0      Link encap:Ethernet  HWaddr 00:04:96:6A:7C:2A  " \
          "          inet addr:10.140.213.129  Bcast:10.140.213.255  " \
          "          Mask:255.255.255.0"
    rc, err = 0, ''
    interfaces = test_HPUXNetwork.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '10.140.213.129'

# Generated at 2022-06-20 18:15:04.351798
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.__repr__() == '<network.HP-UX.HPUXNetworkFactCollector>'


# Generated at 2022-06-20 18:15:06.274780
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_object = HPUXNetwork()
    result = test_object.get_interfaces_info()
    assert result is not None

# Generated at 2022-06-20 18:15:17.786800
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = FakeAnsibleModule()
    test_network = HPUXNetwork(test_module)
    test_network.module.run_command = FakeAnsibleModule.run_command

    test_network.module.run_command = FakeAnsibleModule.run_command
    test_network.module.run_command.side_effect = ['0\n', '0\n', '1\n']

    (rc, out, err) = test_network.module.run_command("/usr/bin/netstat -nr", check_rc=False)
    assert rc == 0

    default_interfaces_facts = test_network.get_default_interfaces()

# Generated at 2022-06-20 18:15:18.875566
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    print(network_collector.as_dict())

# Generated at 2022-06-20 18:15:25.137913
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = type('', (), {})()
    module.run_command = lambda x: (0, x, '')

    iface = HPUXNetwork(module)
    interfaces = iface.get_interfaces_info()
    assert 'lan0' in interfaces, "lan0 not in interfaces dictionary"
    assert 'lan1' in interfaces, "lan1 not in interfaces dictionary"



# Generated at 2022-06-20 18:15:37.715091
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_netstat_out = '''default 192.168.1.10 UG lan0
default 192.168.1.10 UG lan0
'''
    test_module = Network(dict(module_name=__name__,
                               module_args=dict()),
                          NetworkCollector)
    test_module.run_command = lambda path: (0, test_netstat_out, '')
    default_interfaces_facts = HPUXNetwork(dict(), test_module).\
                                                get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.168.1.10'


# Generated at 2022-06-20 18:15:41.762721
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    # Constructor of class HPUXNetwork
    hpuxnetwork = HPUXNetwork()
    # Populate method of class HPUXNetwork
    hpuxnetwork.populate()

# Generated at 2022-06-20 18:15:47.876048
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ Unit test for method populate of class HPUXNetwork. """
    # Initialization
    facts = HPUXNetwork()
    # Test
    # Case 1 - if path of netstat is None
    # Expected result: facts.collect() is empty dictionary
    facts.module.get_bin_path = lambda x: None
    facts.populate()
    assert facts.collect() == {}

# Generated at 2022-06-20 18:15:59.889749
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    class Module(object):

        def __init__(self):
            self.run_command_calls = 0

        def run_command(self, cmd, check_rc=True, close_fds=True):
            if cmd == "/usr/bin/netstat -niw":
                out = 'lo0,9,,,0,0,0,0,,,0,0,,lan0,0,,,0,0,1,0,,,0,0,,'
            else:
                out = 'default 192.168.1.1 UGS lan0'
            self.run_command_calls += 1
            return 0, out, ''

    module = Module()
    net = HPUXNetwork(module)
    default_interfaces_facts = net.get_default_interfaces()


# Generated at 2022-06-20 18:17:38.763949
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    facts = network.populate()
    assert facts['interfaces'] == ['lan0', 'lan1']

# Generated at 2022-06-20 18:17:49.752288
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_facts = HPUXNetwork(module=module)
    network_facts.populate()
    facts = module.params['ansible_facts']
    interfaces = facts['ansible_interfaces']
    ansible_lan11 = facts['ansible_lan11']
    ansible_lan2 = facts['ansible_lan2']
    ansible_lan2_0 = facts['ansible_lan2_0']
    ansible_lan3 = facts['ansible_lan3']
    ansible_lan3_0 = facts['ansible_lan3_0']
    ansible_lan4 = facts['ansible_lan4']
    ansible_lan5 = facts['ansible_lan5']
    ans

# Generated at 2022-06-20 18:17:53.080182
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpn = HPUXNetwork()
    interfaces = hpn.get_interfaces_info()
    assert isinstance(interfaces, dict)
    assert len(interfaces) > 0


# Generated at 2022-06-20 18:17:54.907134
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-20 18:18:00.697932
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = type('module', (object,), {})
    module.get_bin_path = lambda x: "/bin/netstat"
    net = HPUXNetwork(module)

    module.run_command = lambda x: (0, "default  10.10.10.1 netmgmt UG 1 0 0 lan0", None)
    facts = net.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.10.10.1'

    module.run_command = lambda x: (0, "lo0   10.10.10.1\nlan0", None)
    facts = net.populate()
    assert facts['interfaces'] == ['lan0']

# Generated at 2022-06-20 18:18:11.147634
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = HPUXNetwork({})
    facts_dict = m.populate()

    print(facts_dict)
    print(facts_dict.keys())
    assert facts_dict['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3',
                                        'lan4', 'lan5', 'lan6', 'lan7']
    assert facts_dict['lan0']['ipv4'] == {'address': '192.168.1.20',
                                          'network': '192.168.1.0',
                                          'interface': 'lan0'}

# Generated at 2022-06-20 18:18:12.500625
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-20 18:18:15.456731
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:18:21.485868
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    lines = "default 192.168.10.1 UGS 0 1500 0 0 lan9000\n"
    module.run_command = lambda x: (0, lines, '')
    network_facts = HPUXNetwork()
    facts = network_facts.populate()
    assert facts['default_interface'] == 'lan9000'
    assert facts['default_gateway'] == '192.168.10.1'



# Generated at 2022-06-20 18:18:27.249677
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network = HPUXNetwork(network_collector=network_collector)
    assert network.platform == 'HP-UX'

