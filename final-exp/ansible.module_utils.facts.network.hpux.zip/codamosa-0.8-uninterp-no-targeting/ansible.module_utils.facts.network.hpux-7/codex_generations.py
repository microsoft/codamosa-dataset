

# Generated at 2022-06-20 18:09:45.741416
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Initialize module and class under test
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)

    # Prepare test data
    def fake_get_default_interfaces(self):
        return {'default_interface': 'lan0', 'default_gateway': '10.0.0.1'}

    def fake_get_interfaces_info(self):
        return {'lan0': {'device': 'lan0',
                         'ipv4': {'address': '10.0.0.2',
                                  'network': '10.0.0.2/40',
                                  'interface': 'lan0'}}}

    network_facts.get_default_interfaces = fake_get_default_interfaces
    network_facts.get_interfaces_info = fake_get

# Generated at 2022-06-20 18:09:56.837001
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    This is a unit test method for testing populate method of class
    HPUXNetwork.
    """
    # Test with argument collected_facts as None
    test_object = HPUXNetwork(None)
    output = test_object.populate()
    assert (output['default_interface'] == 'lan0')
    assert (output['default_gateway'] == '10.10.10.1')
    assert (output['interfaces'] == ['lan0', 'lan1'])
    assert (output['lan0'] == {'ipv4': {'network': '10.10.10.0',
                                        'interface': 'lan0',
                                        'address': '10.10.10.10'}, 'device': 'lan0'})

# Generated at 2022-06-20 18:10:00.774533
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 18:10:02.219995
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network
    assert network.populate()

# Generated at 2022-06-20 18:10:05.207400
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert issubclass(HPUXNetwork, Network)



# Generated at 2022-06-20 18:10:14.788637
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    network.module.run_command = run_command
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['address'] == '192.168.1.10'
    assert interfaces['lan0']['ipv4']['network'] == '192.168.1.0'
    assert 'lan1' in interfaces
    assert interfaces['lan1']['ipv4']['address'] == '192.168.2.11'
    assert interfaces['lan1']['ipv4']['network'] == '192.168.2.0'



# Generated at 2022-06-20 18:10:25.959768
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = None
    networking = HPUXNetwork(module=module)
    networking.module.run_command = run_command_mock
    net_facts = networking.populate()
    assert net_facts['default_interface'] == 'lan0'
    assert net_facts['default_gateway'] == '10.88.88.1'
    assert 'lan0' in net_facts['interfaces']
    assert 'lan1' in net_facts['interfaces']
    assert net_facts['lan0']['ipv4']['address'] == '10.88.88.50'
    assert net_facts['lan1']['ipv4']['address'] == '10.88.90.50'


# Mock for module.run_command, used in unittest

# Generated at 2022-06-20 18:10:31.257575
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network = HPUXNetworkCollector()
    HPUXNetworkCollector._platform = 'HPUX'
    assert hpux_network._platform == 'HPUX'
    assert hpux_network._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:10:32.765596
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network

# Unit tests for populate() method of class HPUXNetworkCollector

# Generated at 2022-06-20 18:10:39.106015
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    network = HPUXNetwork(module)

    network.get_interfaces_info = mock.Mock(return_value={'lan0': {'device': 'lan0'}})
    network.get_default_interfaces = mock.Mock(return_value={'default_interface': 'lan0'})

    collected_facts = {}
    expected = {'default_interface': 'lan0',
                'interfaces': ['lan0'],
                'lan0': {'device': 'lan0'}}
    network_facts = network.populate(collected_facts)

    assert expected == network_facts

# Unit tests for method get_default_interfaces of class HPUXNetwork

# Generated at 2022-06-20 18:10:50.809857
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Unit test for constructor of class HPUXNetwork"""
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'
    assert net.get_default_interfaces() == {}
    assert net.get_interfaces_info() == {}
    assert net.populate() == {}

# Generated at 2022-06-20 18:10:54.409082
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = get_module_mock()
    module.run_command = MagicMock(return_value=(0, "", ""))
    handler = HPUXNetwork()
    handler.module = module
    handler.populate()
    assert len(handler._not_implemented_methods) > 0


# Generated at 2022-06-20 18:11:06.680721
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    #  Testing a simple case where ipv4 address exists for all the interfaces
    info = '''
lan0      lan         Link#5          007a.1027.4080    10.15.4.1         255.255.255.0     U   4     5     0
lan1      lan         Link#6          007a.1027.4081    10.16.0.1         255.255.255.0     U   4     2     0
lan100000 lan         Link#10         007a.1027.40a0    10.34.0.1         255.255.255.0     U   4     1     0
lo0       loopback    Link#1          0xfffffe80007a.1  127.0.0.1         255.0.0.0         U   4     11    0
'''
   

# Generated at 2022-06-20 18:11:18.003433
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    HPUXNetwork.run_command = lambda self, command: (0, 'lan0: flags=10b843<BROADCAST,SIMPLEX,MULTICAST,DEPRECATED> mtu 1500\nlan1000: flags=10b843<BROADCAST,SIMPLEX,MULTICAST,DEPRECATED> mtu 1500\nlan0: ip:192.168.1.129/255.255.255.0\nlan1000: ip:192.168.1.130/255.255.255.0\n', '')
    interfaces = HPUXNetwork().get_interfaces_info()
    assert(interfaces['lan0']['device'] == 'lan0')
    assert(interfaces['lan0']['ipv4']['address'] == '192.168.1.129' )

# Generated at 2022-06-20 18:11:22.101073
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    fact_network = HPUXNetwork(module)
    assert fact_network._platform == 'HP-UX'


# Generated at 2022-06-20 18:11:22.998652
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork({}, {}, {})
    assert net.platform == 'HP-UX'

# Generated at 2022-06-20 18:11:34.997095
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_obj = HPUXNetwork()
    rc = 0

# Generated at 2022-06-20 18:11:38.938219
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Constructor test for class HPUXNetwork
    """
    HPUXNetwork()

# Generated at 2022-06-20 18:11:42.997109
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.network_class_name == 'HPUXNetwork'
    assert network_collector.platform == 'HP-UX'

# Generated at 2022-06-20 18:11:46.085930
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network


# Generated at 2022-06-20 18:11:53.527816
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    x = HPUXNetworkCollector()
    assert x is not None

# Generated at 2022-06-20 18:12:00.976453
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    hn = HPUXNetwork()
    assert(hn.platform == 'HP-UX')
    if1 = {'default_gateway': '192.168.0.2',
           'default_interface': 'lan1',
           'ipv4': {'address': '192.168.0.129',
                    'interface': 'lan1',
                    'network': '192.168.0.128'},
           'lan2': {'ipv4': {'address': '192.168.0.130',
                             'interface': 'lan2',
                             'network': '192.168.0.128'}}}
    assert(hn.get_interfaces_info() == if1)

# Generated at 2022-06-20 18:12:11.226655
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    mod = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
            'filter': dict(default=None, type='str'),
        },
    )
    mod.run_command = MagicMock()

# Generated at 2022-06-20 18:12:20.279897
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_command = ''

        def get_bin_path(self, arg):
            return '/usr/bin/netstat'

        def run_command(self, command):
            self.run_command_count += 1
            self.run_command_command = command
            return 3, 'default:\n   gateway 10.10.10.1', ''

    hpx_network = HPUXNetwork(MockModule())
    assert hpx_network.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '10.10.10.1'}
    assert hpx_network.module.run_command_count == 1
    assert hpx_network.module

# Generated at 2022-06-20 18:12:21.720886
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class == HPUXNetwork
    assert c._platform == 'HP-UX'

# Generated at 2022-06-20 18:12:23.197801
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:12:32.578313
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """Test get_default_interfaces method of class HPUXNetwork"""

    class MockModule(object):
        def __init__(self, command_output):
            self.command_output = command_output

        def get_bin_path(self, pathname):
            """Returns pathname as given."""
            return pathname

        def run_command(self, cmd):
            """Returns cmd and netstat -nr command output."""
            return 0, self.command_output, ''

    command_output = "default 192.168.122.1 UG 1 16 lan0"
    test_module = MockModule(command_output)

    test_facts_class = HPUXNetwork(module=test_module)
    default_interfaces_facts = \
        test_facts_class.get_default_interfaces()
    assert default_

# Generated at 2022-06-20 18:12:45.599550
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class mock_module:
        def run_command(self, command):
            return ('', '/usr/bin/netstat -niw\n')
    class mock_network:
        def __init__(self):
            self.module = mock_module()
    network = mock_network()
    interfaces = network.get_interfaces_info()
    assert len(interfaces) == 3
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces
    assert 'ipv4' in interfaces['lan0']
    assert 'ipv4' in interfaces['lan1']
    assert 'ipv4' in interfaces['lan2']
    assert 'address' in interfaces['lan0']['ipv4']
    assert 'address' in interfaces['lan1']['ipv4']
   

# Generated at 2022-06-20 18:12:47.341855
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn1 = HPUXNetwork()


# Generated at 2022-06-20 18:12:54.147039
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    modules = dict(HP_UX=dict(run_command=lambda *args: (0, '', '')))
    mock_module = FakeAnsibleModule(**modules)
    hpuxtnetwork = HPUXNetwork(mock_module)
    assert hpuxtnetwork.platform == 'HP-UX'


# Generated at 2022-06-20 18:13:09.849709
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    hpux_network = HPUXNetwork(module=module)


# Generated at 2022-06-20 18:13:16.373636
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    hpux_network = HPUXNetwork(test_module)
    default_interfaces_facts = hpux_network.get_default_interfaces()
    assert(default_interfaces_facts['default_interface'] == 'lan0')
    assert(default_interfaces_facts['default_gateway'] == '10.0.0.11')



# Generated at 2022-06-20 18:13:28.782711
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os
    import subprocess
    import sys
    import unittest

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))
    from ansible.module_utils.facts import Network
    from ansible.module_utils.facts import FactCollector

    class FakeModule:
        command_results = (
            (0, '''
Name  Mtu   Net/Dest      Address        Ipkts  Ierrs Opkts  Oerrs  Coll
lan0 1500  default        172.31.1.1        87      0   127      0     0
lan0 1500  7.7.3.0        7.7.3.1        2069     0  3634      0     0
''', 'Error'),
        )


# Generated at 2022-06-20 18:13:34.944514
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
            'gather_timeout': dict(default=10, type='int')
        },
    )

    hpux_network = HPUXNetwork(module)
    assert hpux_network


# Generated at 2022-06-20 18:13:46.607487
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Test HPUXNetwork by creating a HPUXNetwork object with
    sample facts collected by HP-UX and compare the output
    """

# Generated at 2022-06-20 18:13:54.084451
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork().populate()
    facts = dict(ansible_facts=dict(network=network_facts))
    module_result = dict(success=True, ansible_facts=network_facts)
    module.exit_json(**facts)

from ansible.module_utils.basic import *

main()

# Generated at 2022-06-20 18:13:58.926437
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Unit testing for the constructor of class HPUXNetwork
    """
    hpux_network = HPUXNetwork(module=None)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-20 18:14:02.261694
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_collector = HPUXNetworkCollector()
    obj = net_collector.collect()

    assert obj is not None

# Generated at 2022-06-20 18:14:10.699405
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = ['lan0', 'lan1', 'lan2', 'lan3', 'lan4']
    def _get_command_output(module, command):
        return '', '\n'.join(interfaces), ''
    Network._get_command_output = _get_command_output
    h = HPUXNetwork()
    assert h.get_interfaces_info() == {'lan4': {'device': 'lan4'},
                                       'lan2': {'device': 'lan2'},
                                       'lan3': {'device': 'lan3'},
                                       'lan0': {'device': 'lan0'},
                                       'lan1': {'device': 'lan1'},}

# Generated at 2022-06-20 18:14:14.043694
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._collector_platform == 'HP-UX'
    assert hn._fact_class.platform == 'HP-UX'


# Generated at 2022-06-20 18:14:30.480188
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c is not None
    assert c._fact_class == HPUXNetwork
    assert c._platform == 'HP-UX'


# Generated at 2022-06-20 18:14:34.954195
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of class HPUXNetworkCollector should assign
    correct value to instance variables
    """
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:14:47.707609
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import paginate
    from ansible.module_utils.facts import timeout
    module = Network()
    module.get_bin_path = lambda _: "/usr/bin/netstat"
    module.run_command = lambda _: (0, "default 192.168.1.1 UGS 0 0 lan0", "")
    paginator = paginate.Paginate()
    cache_manager = cache.CacheManager(paginator)
    timeout_manager = timeout.Timeout()
    module.cache_manager = cache_manager
    module.timeout_manager = timeout_manager


# Generated at 2022-06-20 18:14:58.691219
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux.legacy import HPUXNetwork

    module = MagicMock()
    module.run_command.return_value = (0, '', '')

    hpux_network = HPUXNetwork(module)


# Generated at 2022-06-20 18:15:08.926219
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    class MockModule(object):

        def run_command(self, cmd):
            return (0, "", "")

        def get_bin_path(self, cmd):
            return cmd

    class MockFactCollector(object):

        def __init__(self, module):
            self.module = module

    class MockAnsibleModule(object):

        def __init__(self, module):
            self.params = {}
            self.module = module

    hpux_network = HPUXNetwork(MockAnsibleModule(MockModule(
        MockFactCollector(MockModule(None)))))
    default_interface = {'default_gateway': '10.0.0.1',
                         'default_interface': 'lan0'}

# Generated at 2022-06-20 18:15:18.767695
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_facts_c = HPUXNetwork(dict())
    net_facts_c.module = FakeAnsibleModule()
    facts = net_facts_c.populate()
    assert facts['default_interface'] == 'lan2'
    assert facts['default_gateway'] == '10.12.14.1'
    assert facts['interfaces'] == ['lan6', 'lan5', 'lan4', 'lan3', 'lan2', 'lan1']
    assert facts['lan1']['device'] == 'lan1'
    assert facts['lan1']['ipv4']['address'] == '10.10.12.24'
    assert facts['lan1']['ipv4']['network'] == '10.10.12.0'

# Generated at 2022-06-20 18:15:23.335478
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj
    assert isinstance(obj, HPUXNetwork)
    assert obj.platform == 'HP-UX'

# Unit test to test the 'get_default_interfaces' function of class HPUXNetwork

# Generated at 2022-06-20 18:15:32.818542
# Unit test for constructor of class HPUXNetwork

# Generated at 2022-06-20 18:15:40.999282
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module = AnsibleModuleMock()
    net.module.run_command.return_value = (0,
            "         Destination        Gateway           Flags Refs Interface  MSS Window  irtt Ifname",
            "default  172.1.1.1        UG        0        0        0 0        en0",
            "")
    default_interfaces = net.get_default_interfaces()
    assert 'default_interface' in default_interfaces
    assert default_interfaces['default_interface'] == 'en0'
    assert 'default_gateway' in default_interfaces
    assert default_interfaces['default_gateway'] == '172.1.1.1'



# Generated at 2022-06-20 18:15:51.160572
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Network module
    module = MockNetworkModule()
    facts_module = module.AnsibleModule
    facts_module.run_command.return_value = (0, '', '')

    network = HPUXNetwork(facts_module)
    facts_module.params = {}
    actual_network_facts = network.populate()

    # Result
    interfaces = {'lan0': {'device': 'lan0', 'ipv4': {'network': '192.168.0.0',
                                                      'interface': 'lan0', 'address': '192.168.0.1'}}},

# Generated at 2022-06-20 18:16:05.406448
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork({}, None)
    assert hpux_network.platform == 'HP-UX'

# Generated at 2022-06-20 18:16:13.804745
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    sn_module = HPUXNetwork(dict())
    rc = 0
    output = "Routing tables\n"
    output = output + "\n"
    output = output + "default lan0 10.139.22.1 UG 0 0 en0\n"
    output = output + "\n"
    output = output + "Destination        Gateway           Flags Refs Use Mtu Interface\n"  # noqa
    output = output + "127.0.0.1          127.0.0.1         UH    2   0   9999 lo0\n"  # noqa
    output = output + "10.139.22.0        10.139.22.87      U     2   1   1500 lan0\n"  # noqa

# Generated at 2022-06-20 18:16:23.338072
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    class TestModule(object):
        def __init__(self):
            self.facts = Facts()
            self.facts['os'] = {'family': 'HP-UX'}
            self.module = self


# Generated at 2022-06-20 18:16:26.513913
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=["!all"], type='list')
        ),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    hpux_network.get_default_interfaces()
    # Probably need to pass in test data.
    assert True


# Generated at 2022-06-20 18:16:30.575045
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    instance = HPUXNetworkCollector()
    assert instance._platform == 'HP-UX'
    assert instance._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:16:33.037913
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    mc = HPUXNetworkCollector()
    assert isinstance(mc, HPUXNetworkCollector)


# Generated at 2022-06-20 18:16:40.318433
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    iface_info = {'lan0': {'device': 'lan0',
                           'ipv4': {'address': '10.2.127.222',
                                    'network': '10.2.127.0',
                                    'interface': 'lan0'}},
                  'lan1': {'device': 'lan1',
                           'ipv4': {'address': '10.5.20.222',
                                    'network': '10.5.20.0',
                                    'interface': 'lan1'}}}


# Generated at 2022-06-20 18:16:43.034302
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_obj = HPUXNetwork()
    assert network_obj.platform == 'HP-UX'

# Generated at 2022-06-20 18:16:47.713046
# Unit test for method populate of class HPUXNetwork

# Generated at 2022-06-20 18:16:48.520110
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:17:15.224933
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()

# Generated at 2022-06-20 18:17:17.541163
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_facts = facts_module.HPUXNetwork()
    assert network_facts.platform == 'HP-UX'



# Generated at 2022-06-20 18:17:19.050623
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hux_network = HPUXNetwork({})
    hux_network.populate()
    assert hux_network.populate()


# Generated at 2022-06-20 18:17:21.607699
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.get_default_interfaces()

# Generated at 2022-06-20 18:17:25.432192
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    new_network = HPUXNetwork()
    interfaces = new_network.get_interfaces_info()
    assert 'lan0' in interfaces

# Generated at 2022-06-20 18:17:29.061060
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Unit test for HPUXNetwork Constructor.
    """
    hpux_network = HPUXNetwork(None, dict(), dict(), dict())
    assert hpux_network.platform == 'HP-UX'
    assert hpux_network.module == None

# Generated at 2022-06-20 18:17:33.902527
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)

    # constructor of class HPUXNetwork
    assert hpux_network


# Generated at 2022-06-20 18:17:37.013033
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    g = HPUXNetwork()
    interfaces = g.get_interfaces_info()
    assert 'lan0' in interfaces and 'lan1' in interfaces

# Generated at 2022-06-20 18:17:44.804058
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    netstat_path = "/usr/bin/netstat"
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    test_module.get_bin_path = MagicMock(return_value=netstat_path)
    test_module.run_command = MagicMock(
        side_effect=[(0, netstat_nr_out, ""), (0, netstat_niw_out, "")])

    net = HPUXNetwork(test_module)
    result = net.populate()
    assert result["default_interface"] == "lan9000"
    assert result["default_gateway"] == "10.10.10.254"
    assert result["interfaces"][0] == "lan9000"

# Generated at 2022-06-20 18:17:56.691614
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""
    # get_interfaces_info returns a dictionary.
    # The dictionary has a key as a device
    # The dictionary has a value as a dictionary
    # The dictionary has an entry 'device' with the device as the value
    # The dictionary has an entry 'ipv4' with a dictionary as the value
    # The dictionary has an entry 'address' with the ipv4 address as the value

    hpux = HPUXNetwork()


# Generated at 2022-06-20 18:18:25.717752
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info(module)
    assert interfaces != {}


# Generated at 2022-06-20 18:18:32.340833
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Test the retrun value of method get_default_interfaces of class HPUXNetwork.
    """
    # Create new instance of HPUXNetwork.
    hn = HPUXNetwork(None)

    # Need to mock the module.run_command method.
    hn.module = MockModule()

    # Create expected return value for method get_default_interfaces.
    expected_result = {}
    expected_result['default_interface'] = 'lan0'
    expected_result['default_gateway'] = '10.186.0.1'

    facts = hn.get_default_interfaces()
    assert facts == expected_result



# Generated at 2022-06-20 18:18:34.452689
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleMock()
    network = HPUXNetwork(module)
    network.populate()
    # TODO: add some asserts

# Generated at 2022-06-20 18:18:43.852762
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()

# Generated at 2022-06-20 18:18:47.131783
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Create an object of HPUXNetworkCollector.
    """
    HPUXNetworkCollector()

# Generated at 2022-06-20 18:18:55.559742
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hpux_network_col = HPUXNetworkCollector(module=module)
    hpux_network = hpux_network_col.facts()

    assert hpux_network['default_interface'] == 'lan0'
    assert hpux_network['default_gateway'] == '172.20.6.1'
    assert hpux_network['interfaces'][0] == 'lan0'
    assert hpux_network['lan0']['device'] == 'lan0'
    assert hpux_network['lan0']['ipv4']['address'] == '172.20.6.201'

# Generated at 2022-06-20 18:19:01.510050
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    hn = HPUXNetwork(module)
    network_facts = hn.populate()
    assert network_facts == {'default_interface': 'lan1000',
                             'default_gateway': '10.0.0.1',
                             'interfaces': ['lan1000'],
                             'lan1000': {'device': 'lan1000',
                                         'ipv4': {'address': '10.0.0.10',
                                                  'interface': 'lan1000',
                                                  'network': '10.0.0.0'}}}

# Generated at 2022-06-20 18:19:12.827279
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Prepare class HPUXNetwork for testing
    test_module = AnsibleModule(argument_spec=dict())
    test_network_class = HPUXNetwork(test_module)

    # Prepare mocked value of /usr/bin/netstat -nr
    output = '/usr/bin/netstat -nr output in HP-UX'
    test_module.run_command = mock.Mock(return_value=(0, output, ""))

    # Define expected value of method get_default_interfaces
    expected_default_interfaces = {'default_gateway': 'gateway_address',
                                   'default_interface': 'iface_name'}

    # Run method get_default_interfaces
    result = test_network_class.get_default_interfaces()

    # Verify method get_default_interfaces

# Generated at 2022-06-20 18:19:18.636218
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # create an instance
    test_class_inst = HPUXNetworkCollector()

    # test for attribute access
    assert test_class_inst.platform is not None
    assert test_class_inst.fact_class is not None

# Generated at 2022-06-20 18:19:24.229539
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, command, check_rc=True, close_fds=True,
                        executable=None, data=None):
            self.run_command_calls.append(command)