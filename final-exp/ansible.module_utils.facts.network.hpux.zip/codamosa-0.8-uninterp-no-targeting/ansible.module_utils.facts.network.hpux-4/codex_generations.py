

# Generated at 2022-06-20 18:09:39.918645
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hn = HPUXNetwork()
    default_interfaces = {}
    default_interfaces = hn.get_default_interfaces()
    if len(default_interfaces) > 0:
        return True
    else:
        return False



# Generated at 2022-06-20 18:09:46.975512
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    facts = HPUXNetwork(module).populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.12.4.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.12.4.156'
    assert facts['lan0']['ipv4']['network'] == '10.12.4.0'

# Test class for mocking AnsibleModule

# Generated at 2022-06-20 18:09:56.788228
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    def my_run_command(module, cmd):
        rc = 0
        out = 'default 10.1.1.1 UG  lan0'
        err = ''
        return rc, out, err
    module = type('', (), {})()
    setattr(module, 'get_bin_path', lambda module, cmd: None)
    setattr(module, 'run_command', my_run_command)
    hpuxnetwork = HPUXNetwork(module)
    default_interfaces = hpuxnetwork.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.1.1.1'



# Generated at 2022-06-20 18:10:07.350725
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpu import HPUXNetwork
    network_obj = HPUXNetwork()


# Generated at 2022-06-20 18:10:14.316820
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    mod = FakeModule()
    net_obj = HPUXNetwork(module=mod)

    result = net_obj.populate()


# Generated at 2022-06-20 18:10:25.996883
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    def mock_run_command(*args, **kwargs):
        return 0, '/usr/sbin/netstat -niw', ''

    # Mocking module object
    class MockModule(object):
        def __init__(self):
            self.run_command = mock_run_command
            self.params = {}

    # Mocking network object
    class MockNetwork(object):
        def __init__(self, module):
            self.module = module

    module = MockModule()
    network = MockNetwork(module)

    # Expected result for get_interfaces_info method

# Generated at 2022-06-20 18:10:30.629579
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class is not None


# Generated at 2022-06-20 18:10:31.204990
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork(module)

# Generated at 2022-06-20 18:10:38.983691
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpubase import HPUXNetwork

    hpn = HPUXNetwork(None)
    testdata = """default         10.0.0.1        UG     0       0        0 lan0
default         10.0.0.1        UG     0       0        0 lan0
              0 link#2              UC            0      0          0 lan0
              1 link#1              UC            0      0          0 lan1
              2 link#3              UC            0      0          0 lan2"""
    hpn.module.run_command = lambda x: (None, testdata, None)
    print(hpn.get_default_interfaces())

# Generated at 2022-06-20 18:10:46.012486
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_network = HPUXNetwork(dict())
    test_network.module = MockModule()
    test_network.module.run_command.return_value = (0, 'default 127.0.0.1 UG 0 45 lan0', '')
    default_interfaces_facts = test_network.get_default_interfaces()
    assert(default_interfaces_facts == {'default_interface': 'lan0', 'default_gateway': '127.0.0.1'})


# Generated at 2022-06-20 18:10:57.883464
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class DeviceHelper:
        @staticmethod
        def run_command(*args, **kwargs):
            return 0, 'default 192.168.1.1 UGS 0 0 lan0', 'out,err'

    module = DeviceHelper()
    facts = HPUXNetwork()
    default_interfaces_facts = facts.get_default_interfaces()

    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.168.1.1'



# Generated at 2022-06-20 18:10:59.492542
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # test constructor without parameters
    hpu = HPUXNetwork()
    assert (hpu.platform == 'HP-UX') and (hpu.interfaces is None)


# Generated at 2022-06-20 18:11:00.381064
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'

# Generated at 2022-06-20 18:11:02.907367
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network = HPUXNetworkCollector()
    assert hpux_network._fact_class == HPUXNetwork

# Generated at 2022-06-20 18:11:08.076827
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net_info = HPUXNetwork()
    interfaces = net_info.get_interfaces_info()
    assert len(interfaces) >= 1
    assert interfaces['lan0']['ipv4']['address'] == '192.168.1.132'

# Generated at 2022-06-20 18:11:11.977196
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'



# Generated at 2022-06-20 18:11:14.335612
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpu_net = HPUXNetwork()
    default_interface_facts = hpu_net.get_default_interfaces()
    assert default_interface_facts['default_interface'] == 'lan9000'
    assert default_interface_facts['default_gateway'] == '10.10.10.1'


# Generated at 2022-06-20 18:11:21.020351
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork.
    :return: nothing.
    """
    my_class = HPUXNetwork()
    result = my_class.get_interfaces_info()
    print(result)



# Generated at 2022-06-20 18:11:21.753650
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_facts = HPUXNetwork()
    assert network_facts


# Generated at 2022-06-20 18:11:25.304701
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpu = HPUXNetworkCollector()
    assert hpu._fact_class == HPUXNetwork
    assert hpu._platform == 'HP-UX'



# Generated at 2022-06-20 18:11:34.447631
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'default  192.168.0.1 UG  0 '
                                               '0  lan1', ''))
    hn = HPUXNetwork(module)
    default_interfaces = hn.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan1'
    assert default_interfaces['default_gateway'] == '192.168.0.1'



# Generated at 2022-06-20 18:11:35.571432
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert issubclass(HPUXNetworkCollector, NetworkCollector)


# Generated at 2022-06-20 18:11:46.310455
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )

    # Initialize the collector
    collector = HPUXNetworkCollector(module=module)

    # Call method populate of class HPUXNetwork
    network_facts = collector.populate()

    # Assert that correct keys are present in the result
    keys = [
        'interfaces',
        'default_interface',
        'default_gateway',
        'lo0',
        'lan0'
    ]
    for key in keys:
        assert key in network_facts


# Generated at 2022-06-20 18:11:49.084102
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork({})
    print(obj)


# Generated at 2022-06-20 18:11:54.184143
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_facts_network = HPUXNetworkCollector()
    assert hpux_facts_network._platform == 'HP-UX'
    assert hpux_facts_network._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:12:01.888290
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = Mock()
    net = HPUXNetwork(module)

# Generated at 2022-06-20 18:12:09.683525
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    hpux_network = HPUXNetwork(None)
    try:
        out = hpux_network.get_default_interfaces()
        print(out)
    except Exception as e:
        print(e)



# Generated at 2022-06-20 18:12:12.592433
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.__class__.__name__ == 'HPUXNetworkCollector'
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class.__name__ == 'HPUXNetwork'


# Generated at 2022-06-20 18:12:20.214506
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mock_module = Mock(params=dict(), run_command=Mock())
    mock_module.get_bin_path = Mock(return_value='/usr/bin/netstat')


# Generated at 2022-06-20 18:12:31.232448
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class Netstat:
        def __init__(self, out):
            self.out = out

        def run_command(self, command):
            return 0, self.out, ''


# Generated at 2022-06-20 18:12:51.850383
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os

    module = os.environ.get('ANSIBLE_MODULE_ARGS', '')
    if (module.find('get_interfaces_info') != -1):
        file = open("/tmp/ansible_test_netstat")
        out = file.read()
        module_return = dict(rc=0, out=out, err='')
        hp = HPUXNetwork(ansible_module=module_return)
        interfaces = hp.get_interfaces_info()

# Generated at 2022-06-20 18:12:56.188058
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert ('ansible.module_utils.facts.network.'
            'hpux.HPUXNetworkCollector') == collector.__module__ + '.' + \
            collector.__class__.__name__


# Generated at 2022-06-20 18:13:06.609236
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock()
    module.run_command.side_effect = [
        (0, 'default  10.0.0.1      UG      0 0        0 lan0', ''),
    ]
    net = HPUXNetwork()
    net.module = module

    assert('default_interface' in net.get_default_interfaces())
    assert(net.get_default_interfaces()['default_interface'] == 'lan0')
    assert('default_gateway' in net.get_default_interfaces())
    assert(net.get_default_interfaces()['default_gateway'] == '10.0.0.1')



# Generated at 2022-06-20 18:13:17.848393
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Create an instance of class HPUXNetwork
    network = HPUXNetwork()


    # Test the populate method
    __result = network.populate(collected_facts=None)

    if isinstance(__result, dict) and __result.has_key('default_interface'):
        assert(__result['default_interface'] == 'lan0')
        assert(__result['default_gateway'] == '192.168.1.1')
    else:
        assert(False) # The populate method has returned a bad result.

    if isinstance(__result, dict) and __result.has_key('interfaces'):
        assert(len(__result['interfaces']) > 0)
    else:
        assert(False) # The populate method has returned a bad result.


# Generated at 2022-06-20 18:13:26.756975
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    n = HPUXNetwork()
    out="""default 192.168.1.1 UGS 0 0 en0
default 192.168.2.1 UGS 0 0 en1"""
    n.module.run_command = lambda x: (0, out, None)
    default_interfaces = {'default_interface': 'en0',
                          'default_gateway': '192.168.1.1'}
    assert n.get_default_interfaces() == default_interfaces


# Generated at 2022-06-20 18:13:28.833053
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-20 18:13:38.720484
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpux_network_object = HPUXNetwork(dict())
    hpux_network_object.module = FakeAnsibleModule(dict())
    expected_output = {'lan0': {'device': 'lan0',
                                'ipv4': {'address': '192.168.122.1',
                                         'network': '192.168.122.0',
                                         'interface': 'lan0',
                                         'broadcast': None}},
                       'lan1': {'device': 'lan1',
                                'ipv4': {'address': '192.168.123.1',
                                         'network': '192.168.123.0',
                                         'interface': 'lan1',
                                         'broadcast': None}}}

# Generated at 2022-06-20 18:13:44.662912
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    This function is used to test the constructor of class HPUXNetworkCollector
    """
    network_fact = HPUXNetworkCollector()
    assert network_fact.platform == "HP-UX"
    assert network_fact.fact_class == HPUXNetwork
    assert network_fact.service_name == "network"

# Generated at 2022-06-20 18:13:46.940911
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-20 18:13:57.832485
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Test:  HPUXNetwork.get_default_interfaces
    Expected Result:  Return dictionary with keys 'default_interface' and
    'default_gateway'
    """
    # netstat command return
    netstat = ("default  10.255.96.1 UG   0  0  lan2    \n"
               "other default  10.255.96.1 UG   0  0  lan2    \n")
    # module_utils.basic.AnsibleModule object
    module = AnsibleModule()
    module.run_command = Mock(return_value=(0, netstat, ''))
    # HPUXNetwork object
    network = HPUXNetwork(module)
    # Expected dictionary for default interface information

# Generated at 2022-06-20 18:14:20.324349
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._fact_class == HPUXNetwork
    assert HPUXNetworkCollector._platform == 'HP-UX'

# Generated at 2022-06-20 18:14:28.271347
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    ansible_facts = {
        'default_interface': 'lan0',
        'default_gateway': '192.168.1.254',
        'interfaces': ['lan0'],
        'lan0': {'device': 'lan0', 'ipv4': {'address': '192.168.1.1', 'network': '192.168.1.0', 'interface': 'lan0'}}
    }

    collected_facts = {'ansible_facts': {'ansible_net_interfaces': 'lan0'}}
    collected_facts['ansible_facts']['ansible_net_default_interface'] = 'lan0'
    collected_facts['ansible_facts']['ansible_net_default_gateway'] = '192.168.1.254'

# Generated at 2022-06-20 18:14:33.177882
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network = HPUXNetworkCollector()
    print(hpux_network._fact_class)
    assert hpux_network._fact_class == HPUXNetwork


# Generated at 2022-06-20 18:14:39.142154
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    network = HPUXNetwork(module)
    result = network.populate()

    assert result['ipv4']['address'] == '172.16.0.1'
    assert result['ipv4']['network'] == '172.16.0.0'
    assert result['ipv4']['netmask'] == '255.255.255.0'
    assert result['ipv4']['interface'] == 'lan0'
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '172.16.0.254'
    assert result['interfaces'] == ['lan0']

# Generated at 2022-06-20 18:14:47.274172
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = Mock()
    module.run_command = Mock(return_value=(0, DEFAULT_INTERFACES_OUTPUT, None))
    hp_network = HPUXNetwork(module)
    default_interfaces = hp_network.get_default_interfaces()
    assert (default_interfaces['default_interface']
            == DEFAULT_INTERFACES_RESULT['default_interface'])
    assert (default_interfaces['default_gateway']
            == DEFAULT_INTERFACES_RESULT['default_gateway'])



# Generated at 2022-06-20 18:14:50.089924
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert issubclass(HPUXNetwork, Network)


# Generated at 2022-06-20 18:14:55.051590
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    class_name = "HPUXNetwork"
    assert collector._fact_class.__name__ == class_name

# Generated at 2022-06-20 18:15:06.238706
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    iface = HPUXNetwork()
    interfaces = iface.get_interfaces_info()
    assert isinstance(interfaces, dict)

    assert 'lan0' in interfaces

    lan0 = interfaces['lan0']
    assert isinstance(lan0, dict)

    assert 'ipv4' in lan0
    assert 'device' in lan0

    ipv4 = lan0['ipv4']
    assert isinstance(ipv4, dict)

    assert 'address' in ipv4
    assert 'network' in ipv4
    assert 'interface' in ipv4
    assert 'address_type' not in ipv4

# Generated at 2022-06-20 18:15:11.435097
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.__class__.__name__ == 'HPUXNetworkCollector'
    assert collector._fact_class.__name__ == 'HPUXNetwork'
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-20 18:15:19.757077
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class TestModule(object):
        def run_command(self, command):
            _out = """
                lan0  lan0  192.168.1.0  192.168.1.102   UHLWIir  1516543 0  11548 lan0
            """
            return 0, _out, ""
        def get_bin_path(self, command):
            return '/usr/bin/netstat'

    class Network(object):
        interfaces = None
        module = TestModule()

    test_obj = HPUXNetwork(Network())

# Generated at 2022-06-20 18:16:05.332419
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-20 18:16:07.380461
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Test HP-UX Network.
    """
    HPUXNetwork(dict())

# Generated at 2022-06-20 18:16:12.758094
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "lan0       0      0     0     0     0   0        0\n"
                                          "lan1       0      0     0     0     0   0        0\n",
                                       '')
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert interfaces == {'lan0': {'device': 'lan0'},
                          'lan1': {'device': 'lan1'}}


# Generated at 2022-06-20 18:16:22.348489
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    tst_HPUXNetwork = HPUXNetwork()
    result = tst_HPUXNetwork.populate()
    assert result == { 'default_interface': 'lan1000',
                       'interfaces': [ 'lan1000', 'lan2000' ],
                       'lan100': { 'ipv4': { 'address': '192.168.1.1' },
                                   'device': 'lan100' },
                       'lan1000': { 'ipv4': { 'address': '192.168.1.1' },
                                    'device': 'lan1000' },
                       'lan2000': { 'ipv4': { 'address': '192.168.2.1' },
                                    'device': 'lan2000' }
                     }



# Generated at 2022-06-20 18:16:24.464523
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    test_net = HPUXNetwork(module=module)
    test_net.get_default_interfaces()
    assert test_net.default_interfaces == {'default_interface': 'lan0',
                                           'default_gateway': '172.17.0.1'}



# Generated at 2022-06-20 18:16:32.362237
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Make a HPUXNetwork object with a fake module object with contents
    # of a HP-UX netstat output.
    fake_module = FakeAnsibleModule()
    facts = HPUXNetwork(fake_module)

    # Check that the default gateway was parsed correctly from the output.
    assert facts.get_facts()['default_gateway'] == '127.0.0.1'

    # Check that the default interface was parsed correctly from the output.
    assert facts.get_facts()['default_interface'] == 'lo0'



# Generated at 2022-06-20 18:16:35.856670
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Create an instance of HPUXNetworkCollector
    """
    network_collector = HPUXNetworkCollector()
    assert network_collector is not None

# Generated at 2022-06-20 18:16:49.539912
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces = {'default_interface': 'lan0',
                          'default_gateway': '10.0.0.1'}
    return_code = 0
    stdout = """Kernel IP routing table
Destination           Gateway           Flags Refs Use If  MTU State Interface
default              10.0.0.1          UG        0   106 lan0 1500
10.0.0.0              10.0.0.2          U         0    12 lan0 1500
127.0.0.1             127.0.0.1         UH        0    21 lo0 16896"""
    stderr = ''
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    iface = HPUXNetwork()
    result = iface.get_default_interfaces()
    assert default_

# Generated at 2022-06-20 18:17:00.063176
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    fake_netstat_out = '''Routing tables

default              0.0.0.0          192.168.0.1 UG        0        0 lan0
default              0.0.0.0          192.168.1.1 UG        0        0 lan1
default           192.168.0.0        255.255.255.0 U        0        0 lan0
default           192.168.1.0        255.255.255.0 U        0        0 lan1
default            127.0.0.0         255.255.255.0 U        0        0 lo0
'''
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector()
    network_collector.module = module

# Generated at 2022-06-20 18:17:12.325203
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()

    net.module.run_command = lambda x: (0, "default  10.0.2.2  UG   en0", "")
    default_interfaces_facts = net.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'en0'
    assert default_interfaces_facts['default_gateway'] == '10.0.2.2'

    net.module.run_command = lambda x: (0, "lan0      10.10.10.25   0   lan0", "")
    interfaces = net.get_interfaces_info()
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '10.10.10.25'


# Generated at 2022-06-20 18:18:51.656661
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = type(str('_AnsibleFakeModule'), (object,),
                  {'get_bin_path': lambda x: "/usr/bin/netstat"})
    network_collector = HPUXNetworkCollector(module)
    network_collector.module = module
    network_collector.module.run_command = lambda x: (0, "", "")
    network_facts = network_collector.populate()
    assert len(network_facts) > 0
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts



# Generated at 2022-06-20 18:18:59.181692
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert interfaces['lan5001'] == {'device': 'lan5001',
                                     'ipv4': {'address': '172.21.201.24',
                                              'interface': 'lan5001',
                                              'network': '172.21.201.0'}}



# Generated at 2022-06-20 18:19:01.073833
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpuxnet = HPUXNetwork()
    assert hpuxnet.populate()

# Generated at 2022-06-20 18:19:05.460291
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    t_module = AnsibleModule(argument_spec={})
    t_network = HPUXNetwork(t_module)
    t_network.get_interfaces_info()



# Generated at 2022-06-20 18:19:08.143393
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-20 18:19:10.688943
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-20 18:19:15.976052
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod = Network(NetworkCollector)
    hpux_network_fact = HPUXNetwork(mod)
    assert hpux_network_fact.platform == 'HP-UX'


# Generated at 2022-06-20 18:19:23.944784
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    x = HPUXNetwork(module=None)

# Generated at 2022-06-20 18:19:24.678983
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert isinstance(HPUXNetworkCollector(), NetworkCollector)


# Generated at 2022-06-20 18:19:27.461685
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    kwargs = {'run_command': lambda *args, **kwargs: (0, 'lan0:f:1:d:3', '')}
    network = HPUXNetwork(**kwargs)
    interfaces = network.get_interfaces_info()
    assert interfaces['lan0']['ipv4']['address'] == 'f'
    assert interfaces['lan0']['ipv4']['network'] == '1'
