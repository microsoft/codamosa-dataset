

# Generated at 2022-06-17 00:53:36.419175
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_out = """
lan0: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500
        inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255
lan1: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500
        inet 10.0.1.1 netmask ffffff00 broadcast 10.0.1.255
"""

        def get_bin_path(self, arg):
            return '/usr/bin/netstat'

        def run_command(self, arg):
            self.run_command_called

# Generated at 2022-06-17 00:53:39.326475
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:53:49.165913
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_collector = HPUXNetworkCollector(module=module)
    network_collector.collect()
    facts = network_collector.get_facts()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.2.2'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:54:00.331154
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.10.10.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.10.10.10'
    assert network_facts['lan0']['ipv4']['network'] == '10.10.10.0'
    assert network_facts['lan0']['ipv4']['interface']

# Generated at 2022-06-17 00:54:05.226935
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:54:07.448110
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 00:54:14.341409
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:54:17.832054
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:54:20.790191
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:54:33.132858
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_collector = HPUXNetworkCollector(module=module)
    network_collector.collect()
    network_facts = network_collector.get_facts()
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts
    assert 'lo0' in network_facts['interfaces']
    assert 'lan0' in network_facts['interfaces']
    assert 'lan0' in network_facts
    assert 'ipv4' in network_facts['lan0']
    assert 'address' in network_facts['lan0']['ipv4']

# Generated at 2022-06-17 00:54:47.286471
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan0' in interfaces['lan0']
    assert 'lan1' in interfaces['lan1']
    assert 'ipv4' in interfaces['lan0']
    assert 'ipv4' in interfaces['lan1']
    assert 'address' in interfaces['lan0']['ipv4']
    assert 'address' in interfaces['lan1']['ipv4']
    assert 'network' in interfaces['lan0']['ipv4']
    assert 'network' in interfaces['lan1']['ipv4']

# Generated at 2022-06-17 00:54:49.503793
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:55:00.413044
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:55:02.809827
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:55:13.251117
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces
    assert 'lan3' in interfaces
    assert 'lan4' in interfaces
    assert 'lan5' in interfaces
    assert 'lan6' in interfaces
    assert 'lan7' in interfaces
    assert 'lan8' in interfaces
    assert 'lan9' in interfaces
    assert 'lan10' in interfaces
    assert 'lan11' in interfaces
    assert 'lan12' in interfaces
    assert 'lan13' in interfaces
    assert 'lan14' in interfaces
    assert 'lan15' in interfaces
    assert 'lan16' in interfaces
    assert 'lan17' in interfaces


# Generated at 2022-06-17 00:55:19.183064
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:55:27.964567
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface']

# Generated at 2022-06-17 00:55:32.916593
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'



# Generated at 2022-06-17 00:55:42.798660
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork()
    network_facts.module = module
    network_facts.populate()
    assert network_facts.facts['default_interface'] == 'lan0'
    assert network_facts.facts['default_gateway'] == '10.0.0.1'
    assert network_facts.facts['interfaces'] == ['lan0']
    assert network_facts.facts['lan0']['ipv4']['address'] == '10.0.0.10'
    assert network_facts.facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts.facts['lan0']['ipv4']['interface'] == 'lan0'
    assert network_facts.facts

# Generated at 2022-06-17 00:55:48.431437
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:55:59.122907
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'

# Generated at 2022-06-17 00:56:01.689249
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:56:07.689722
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:56:10.043232
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'

# Generated at 2022-06-17 00:56:12.600919
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:56:20.584777
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 10.0.0.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:56:23.504960
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:56:31.719999
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:56:35.262758
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:56:41.532050
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:57:07.715769
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork().populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:57:13.135365
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:57:15.607255
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:57:20.561569
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:57:27.871909
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-17 00:57:31.212971
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:57:41.816661
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'

# Generated at 2022-06-17 00:57:44.856693
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:57:47.075852
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'

# Generated at 2022-06-17 00:57:57.667863
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:58:47.285895
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class Module(object):
        def __init__(self):
            self.run_command = self.run_command_impl

        def run_command_impl(self, command):
            if command == "/usr/bin/netstat -niw":
                return 0, "lan0      0.0.0.0      0.0.0.0      0.0.0.0      UP", ""
            else:
                return 0, "", ""

    module = Module()
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert interfaces['lan0']['ipv4']['address'] == '0.0.0.0'
    assert interfaces['lan0']['ipv4']['network'] == '0.0.0.0'

# Generated at 2022-06-17 00:58:53.569375
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.10.10.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.10.10.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.10.10.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:58:56.861797
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:59:05.490325
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork(None)
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces
    assert 'lan3' in interfaces
    assert 'lan4' in interfaces
    assert 'lan5' in interfaces
    assert 'lan6' in interfaces
    assert 'lan7' in interfaces
    assert 'lan8' in interfaces
    assert 'lan9' in interfaces
    assert 'lan10' in interfaces
    assert 'lan11' in interfaces
    assert 'lan12' in interfaces
    assert 'lan13' in interfaces
    assert 'lan14' in interfaces
    assert 'lan15' in interfaces
    assert 'lan16' in interfaces
   

# Generated at 2022-06-17 00:59:13.959935
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    class MockModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_out = """lan0: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500
        inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255
        lan1: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500
        inet 10.0.1.1 netmask ffffff00 broadcast 10.0.1.255"""
            self.run_command_err = ''


# Generated at 2022-06-17 00:59:15.912785
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'


# Generated at 2022-06-17 00:59:26.833458
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_out = """
lan0: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 1
        inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255
lan1: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 2
        inet 10.0.1.1 netmask ffffff00 broadcast 10.0.1.255
"""

        def get_bin_path(self, arg):
            return '/usr/bin/netstat'

        def run_command(self, arg):
            self.run

# Generated at 2022-06-17 00:59:31.078375
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:59:36.157350
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetwork(module)
    assert hpux_network.module == module
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:59:39.033806
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 01:01:15.693897
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'

# Generated at 2022-06-17 01:01:20.406186
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 01:01:24.370829
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 01:01:34.034758
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 01:01:36.029062
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-17 01:01:48.274437
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 01:01:55.326418
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.10'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 01:01:57.110414
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 01:02:10.657842
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_get_interfaces_info
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_get_default_interfaces
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_populate
    from ansible.module_utils.facts.network.hpux import test_HPUXNetworkCollector_collect
    from ansible.module_utils.facts.network.hpux import test_HPUXNetworkCollector_populate

# Generated at 2022-06-17 01:02:22.268910
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface']