

# Generated at 2022-06-17 00:53:29.800219
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:53:33.091223
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Unit test for constructor of class HPUXNetworkCollector
    """
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork

# Generated at 2022-06-17 00:53:43.457150
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:53:44.547948
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'

# Generated at 2022-06-17 00:53:52.208831
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:53:59.555415
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    facts = network.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.0.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['ipv4']['address'] == '10.0.0.10'
    assert facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:54:02.251969
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-17 00:54:07.555209
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:54:12.446212
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:54:14.961271
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-17 00:54:32.697198
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:54:44.819873
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkPlatform
    from ansible.module_utils.facts.network.hpux import HPUXNetworkInterface
    from ansible.module_utils.facts.network.hpux import HPUXNetworkInterfaceFact
    from ansible.module_utils.facts.network.hpux import HPUXNetworkInterfaceIPv4
    from ansible.module_utils.facts.network.hpux import HPUXNetworkInterfaceIPv6
    from ansible.module_utils.facts.network.hpux import HPUXNetworkInterfaceIPv4Fact

# Generated at 2022-06-17 00:54:49.686675
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:54:59.648173
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Create a HPUXNetwork object
    hpux_network = HPUXNetwork(module)

    # Create a dictionary of expected network facts
    expected_network_facts = {
        'default_interface': 'lan0',
        'default_gateway': '10.0.0.1',
        'interfaces': ['lan0'],
        'lan0': {
            'device': 'lan0',
            'ipv4': {
                'address': '10.0.0.2',
                'network': '10.0.0.0',
                'interface': 'lan0',
                'address': '10.0.0.2'
            }
        }
    }

    # Call method populate of class

# Generated at 2022-06-17 00:55:00.370735
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 00:55:02.809085
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 00:55:12.978089
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:55:17.473050
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'


# Generated at 2022-06-17 00:55:23.129415
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 00:55:31.480298
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_out = 'default 192.168.1.1 UG lan0'
            self.run_command_err = ''

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/bin/netstat'

        def run_command(self, arg):
            self.run_command_called = True
            return self.run_command_rc, self.run_command_out, self.run_command_err

    test_module = TestModule()
    test_network = HPUXNetwork(test_module)
    default_interfaces = test_network.get_default_interfaces()
    assert default_

# Generated at 2022-06-17 00:55:37.557927
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 00:55:49.463107
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-17 00:55:52.975247
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-17 00:55:54.878993
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:55:59.587764
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.0.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.0.1'


# Generated at 2022-06-17 00:56:02.434454
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:56:08.065645
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:56:10.387032
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-17 00:56:16.607095
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:56:17.696059
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 00:56:32.864283
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'



# Generated at 2022-06-17 00:56:37.602498
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert 'default_interface' in default_interfaces
    assert 'default_gateway' in default_interfaces


# Generated at 2022-06-17 00:56:48.753939
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.2.0'

# Generated at 2022-06-17 00:56:55.260105
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    net.module = MockModule()
    net.module.run_command = Mock(return_value=(0, 'lan0: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 1\n'
                                                    '        inet 192.168.1.1 netmask ffffff00 broadcast 192.168.1.255\n'
                                                    'lan1: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 2\n'
                                                    '        inet 192.168.2.1 netmask ffffff00 broadcast 192.168.2.255\n', ''))
    interfaces = net.get_interfaces_info()

# Generated at 2022-06-17 00:57:05.531180
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:57:15.569666
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    hpux_network.populate()
    assert hpux_network.facts['default_interface'] == 'lan0'
    assert hpux_network.facts['default_gateway'] == '10.0.0.1'
    assert hpux_network.facts['interfaces'] == ['lan0']
    assert hpux_network.facts['lan0']['device'] == 'lan0'
    assert hpux_network.facts['lan0']['ipv4']['address'] == '10.0.0.2'

# Generated at 2022-06-17 00:57:23.545740
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module = FakeModule()
    net.module.run_command = FakeRunCommand()
    net.module.run_command.set_output('/usr/bin/netstat -nr',
                                      'default 192.168.1.1 UG lan0')
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'



# Generated at 2022-06-17 00:57:34.919428
# Unit test for method get_default_interfaces of class HPUXNetwork

# Generated at 2022-06-17 00:57:46.106134
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    class MockModule:
        def __init__(self):
            self.run_command_result = (0,
                                       "lan0: flags=8c03<UP,BROADCAST,SIMPLEX,MULTICAST> mtu 1500\n"
                                       "        inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255\n"
                                       "lan1: flags=8c03<UP,BROADCAST,SIMPLEX,MULTICAST> mtu 1500\n"
                                       "        inet 10.0.1.1 netmask ffffff00 broadcast 10.0.1.255\n",
                                       "")


# Generated at 2022-06-17 00:57:53.725704
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:58:25.054564
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces
    assert 'lan3' in interfaces
    assert 'lan4' in interfaces
    assert 'lan5' in interfaces
    assert 'lan6' in interfaces
    assert 'lan7' in interfaces
    assert 'lan8' in interfaces
    assert 'lan9' in interfaces
    assert 'lan10' in interfaces
    assert 'lan11' in interfaces
    assert 'lan12' in interfaces
    assert 'lan13' in interfaces
    assert 'lan14' in interfaces
    assert 'lan15' in interfaces
    assert 'lan16' in interfaces

# Generated at 2022-06-17 00:58:29.529708
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:58:34.351159
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:58:41.860829
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:58:48.461280
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "default 192.168.1.1 UG lan0", ""))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:58:50.340792
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork

# Generated at 2022-06-17 00:58:54.765460
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:58:58.073835
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 00:59:09.502471
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:59:11.856619
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-17 00:59:57.169703
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkModule
    from ansible.module_utils.facts.network.hpux import HPUXNetworkFacts
    from ansible.module_utils.facts.network.hpux import HPUXNetworkFile
    from ansible.module_utils.facts.network.hpux import HPUXNetworkParse
    from ansible.module_utils.facts.network.hpux import HPUXNetworkSetup
    from ansible.module_utils.facts.network.hpux import HPUXNetworkFallback
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

# Generated at 2022-06-17 01:00:01.720285
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'
    assert network.get_default_interfaces() == {}
    assert network.get_interfaces_info() == {}
    assert network.populate() == {}

# Generated at 2022-06-17 01:00:12.928809
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan0' in interfaces['lan0']
    assert 'lan1' in interfaces['lan1']
    assert 'ipv4' in interfaces['lan0']
    assert 'ipv4' in interfaces['lan1']
    assert 'address' in interfaces['lan0']['ipv4']
    assert 'address' in interfaces['lan1']['ipv4']
    assert 'network' in interfaces['lan0']['ipv4']

# Generated at 2022-06-17 01:00:19.396278
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 01:00:27.050135
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
                                                 'default 192.168.1.1 UG lan0',
                                                 ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'



# Generated at 2022-06-17 01:00:28.676389
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 01:00:35.285495
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 01:00:39.144710
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-17 01:00:47.959370
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-17 01:00:52.067528
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'


# Generated at 2022-06-17 01:02:47.132385
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 01:02:53.221722
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    facts = network.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.2.2'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.0.2.15'


# Generated at 2022-06-17 01:02:54.452423
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 01:03:04.793491
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_get_interfaces_info
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_get_default_interfaces
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_populate

    # Test data

# Generated at 2022-06-17 01:03:09.311861
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork


# Generated at 2022-06-17 01:03:12.391953
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 01:03:13.998455
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'


# Generated at 2022-06-17 01:03:17.292214
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-17 01:03:23.578005
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    hn = HPUXNetwork(module)
    interfaces = hn.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'network': '192.168.1.0',
                                           'interface': 'lan0',
                                           'address': '192.168.1.1'}}
