

# Generated at 2022-06-17 00:53:36.259246
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    facts = network.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.0.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['ipv4']['address'] == '10.0.0.10'
    assert facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:53:38.985883
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:53:43.400387
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:53:45.331724
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'


# Generated at 2022-06-17 00:53:55.146882
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork

# Generated at 2022-06-17 00:54:06.581188
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'lan0: flags=8c43<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 1\n'
                                                     '        inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255\n'
                                                     'lan1: flags=8c43<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 2\n'
                                                     '        inet 10.0.1.1 netmask ffffff00 broadcast 10.0.1.255\n', ''))
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()

# Generated at 2022-06-17 00:54:09.119233
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:54:18.214056
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:54:21.260235
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:54:24.506911
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn._fact_class == HPUXNetwork


# Generated at 2022-06-17 00:54:38.449570
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetwork(module)
    network_facts = hpux_network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.10.10.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.10.10.10'
    assert network_facts['lan0']['ipv4']['network'] == '10.10.10.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:54:49.186644
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_collector = HPUXNetworkCollector(module=module)
    network_collector.populate()

    assert network_collector.facts['default_interface'] == 'lan0'
    assert network_collector.facts['default_gateway'] == '10.0.2.2'
    assert network_collector.facts['interfaces'] == ['lan0']
    assert network_collector.facts['lan0']['device'] == 'lan0'
    assert network_collector.facts['lan0']['ipv4']['address'] == '10.0.2.15'

# Generated at 2022-06-17 00:54:51.640121
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:54:52.571721
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 00:55:03.395321
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    test_module.run_command = MagicMock(return_value=(0, 'lan0: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 1\n'
                                                      '        inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255\n'
                                                      'lan1: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 2\n'
                                                      '        inet 10.0.1.1 netmask ffffff00 broadcast 10.0.1.255\n', ''))
    test_network = HPUXNetwork(test_module)


# Generated at 2022-06-17 00:55:09.168384
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:55:16.459841
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:55:19.985640
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Unit test for constructor of class HPUXNetworkCollector
    """
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'

# Generated at 2022-06-17 00:55:24.444787
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:55:36.687255
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-17 00:55:51.755181
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpux_network = HPUXNetwork()
    interfaces = hpux_network.get_interfaces_info()
    assert len(interfaces) > 0
    for interface in interfaces:
        assert interfaces[interface]['device'] == interface
        assert interfaces[interface]['ipv4']['address'] != ''
        assert interfaces[interface]['ipv4']['network'] != ''

# Generated at 2022-06-17 00:55:54.254162
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:55:57.939034
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:56:09.620811
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    import pytest

    class MockModule(object):
        def __init__(self):
            self.run_command = MockModule.run_command

        def run_command(self, command):
            return MockModule.run_command(self, command)


# Generated at 2022-06-17 00:56:14.082268
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '172.16.1.1'



# Generated at 2022-06-17 00:56:24.531218
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.10'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:56:27.878334
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Unit test for constructor of class HPUXNetworkCollector
    """
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'

# Generated at 2022-06-17 00:56:36.291298
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:56:39.040262
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:56:43.901089
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    default_interfaces = hpux_network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:57:07.621772
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:57:13.429620
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'
    assert hn.default_interface is None
    assert hn.default_gateway is None
    assert hn.interfaces == []
    assert hn.all_ipv4_addresses == []
    assert hn.all_ipv6_addresses == []


# Generated at 2022-06-17 00:57:15.926025
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of class HPUXNetworkCollector
    """
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:57:23.216758
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:57:30.523626
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'network': '172.16.0.0',
                                           'interface': 'lan0',
                                           'address': '172.16.0.1'}}


# Generated at 2022-06-17 00:57:39.575018
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:57:40.642076
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:57:44.082276
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 00:57:54.081455
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    class MockModule(object):
        """
        Mock class for AnsibleModule
        """
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            """
            Mock method for run_command
            """

# Generated at 2022-06-17 00:57:56.545455
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:58:39.699149
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'

# Generated at 2022-06-17 00:58:48.366124
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkModule
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollectorModule
    from ansible.module_utils.facts.network.hpux import HPUXNetworkFileModule
    from ansible.module_utils.facts.network.hpux import HPUXNetworkFileCollectorModule
    from ansible.module_utils.facts.network.hpux import HPUXNetworkFile
    from ansible.module_utils.facts.network.hpux import HPUXNetworkFileCollector

# Generated at 2022-06-17 00:58:50.598093
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:58:53.303681
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 00:59:02.359521
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:59:08.367206
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 00:59:16.134208
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:59:27.010574
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpux_network = HPUXNetwork()
    interfaces = hpux_network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces
    assert 'lan3' in interfaces
    assert 'lan4' in interfaces
    assert 'lan5' in interfaces
    assert 'lan6' in interfaces
    assert 'lan7' in interfaces
    assert 'lan8' in interfaces
    assert 'lan9' in interfaces
    assert 'lan10' in interfaces
    assert 'lan11' in interfaces
    assert 'lan12' in interfaces
    assert 'lan13' in interfaces
    assert 'lan14' in interfaces
    assert 'lan15' in interfaces
    assert 'lan16'

# Generated at 2022-06-17 00:59:35.027703
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)

    interfaces = network.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'network': '192.168.1.0',
                                           'interface': 'lan0',
                                           'address': '192.168.1.1'}}


# Generated at 2022-06-17 00:59:38.043755
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork


# Generated at 2022-06-17 01:01:24.146205
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network_collector = HPUXNetworkCollector(module=module)
    network_collector.populate()
    network_facts = network_collector.get_facts()

    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts
    assert 'lo0' in network_facts['interfaces']
    assert 'lan0' in network_facts['interfaces']
    assert 'lan0' in network_facts
    assert 'ipv4' in network_facts['lan0']
    assert 'address' in network_facts['lan0']['ipv4']

# Generated at 2022-06-17 01:01:33.823801
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class MockNetwork(HPUXNetwork):
        def __init__(self):
            self.module = MockModule()

    network = MockNetwork()

    # Test 1:
    # Check that the method returns the expected dictionary
    # when the command returns the expected output

# Generated at 2022-06-17 01:01:39.510530
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'
    assert network_facts['lan0']['device']

# Generated at 2022-06-17 01:01:45.697802
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'



# Generated at 2022-06-17 01:01:53.980412
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 01:01:59.200196
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 01:02:03.586450
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-17 01:02:12.368381
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.10'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 01:02:23.242830
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Create a HPUXNetwork object
    hpux_network = HPUXNetwork(module)

    # Get the network facts
    network_facts = hpux_network.populate()

    # Assert that the network facts are as expected
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'

# Generated at 2022-06-17 01:02:26.103242
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork