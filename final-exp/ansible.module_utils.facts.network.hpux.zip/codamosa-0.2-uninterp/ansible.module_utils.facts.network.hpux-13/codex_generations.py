

# Generated at 2022-06-17 00:53:37.505422
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-17 00:53:47.647007
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:53:54.839521
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:54:03.200330
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_get_interfaces_info
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_get_default_interfaces
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_populate
    from ansible.module_utils.facts.network.hpux import test_HPUXNetworkCollector_collect
    from ansible.module_utils.facts.network.hpux import test_HPUXNetworkCollector_populate

# Generated at 2022-06-17 00:54:05.843096
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-17 00:54:12.289309
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 00:54:18.501529
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os
    import sys
    import unittest
    import tempfile

    class TestHPUXNetwork(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'netstat')

# Generated at 2022-06-17 00:54:24.286564
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:54:27.236672
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:54:32.190145
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:54:49.050628
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_get_interfaces_info
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_get_default_interfaces
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_populate
    from ansible.module_utils.facts.network.hpux import test_HPUXNetworkCollector_collect
    from ansible.module_utils.facts.network.hpux import test_HPUXNetworkCollector_populate

# Generated at 2022-06-17 00:54:51.505413
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:54:55.989907
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:55:08.391298
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface']

# Generated at 2022-06-17 00:55:10.042022
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:55:16.722706
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:55:19.521825
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:55:21.399410
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of class HPUXNetworkCollector can be called without
    any error.
    """
    HPUXNetworkCollector()

# Generated at 2022-06-17 00:55:25.422439
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:55:28.820434
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:55:49.767756
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface']

# Generated at 2022-06-17 00:55:54.045165
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork


# Generated at 2022-06-17 00:55:56.826131
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:56:03.341491
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:56:04.940881
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:56:15.014357
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:56:24.037480
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces_facts = network.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:56:31.966401
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    # Create an instance of HPUXNetwork
    hn = HPUXNetwork()

    # Create a mock module
    mock_module = MockModule()

    # Attach the mock module to the instance of HPUXNetwork
    hn.module = mock_module

    # Create a mock command
    mock_command = MockCommand()

    # Attach the mock command to the mock module
    mock_module.run_command = mock_command

    # Set the output of the mock command

# Generated at 2022-06-17 00:56:38.993136
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "default 10.0.0.1 UG lan0", ""))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:56:46.563818
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert interfaces == {'lan0': {'device': 'lan0', 'ipv4': {'network': '172.16.0.0', 'interface': 'lan0', 'address': '172.16.0.1'}}}


# Generated at 2022-06-17 00:57:11.318360
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Unit test for constructor of class HPUXNetworkCollector
    """
    obj = HPUXNetworkCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:57:13.900531
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork

# Generated at 2022-06-17 00:57:23.745642
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_facts = HPUXNetwork(module)
    network_facts.populate()
    facts = network_facts.get_facts()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.2.2'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:57:27.548881
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:57:38.458931
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    net_facts = HPUXNetwork()
    net_facts.module = module
    net_facts.populate()
    facts = net_facts.get_facts()

    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.0.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert facts['lan0']['ipv4']['network'] == '10.0.0.0'

# Generated at 2022-06-17 00:57:49.613136
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:57:54.247035
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:58:06.427080
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:58:08.304580
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpn = HPUXNetworkCollector()
    assert hpn._platform == 'HP-UX'
    assert hpn._fact_class == HPUXNetwork

# Generated at 2022-06-17 00:58:13.524746
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:59:03.623499
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of class HPUXNetworkCollector
    """
    obj = HPUXNetworkCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXNetwork


# Generated at 2022-06-17 00:59:13.819751
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces
    assert 'lan3' in interfaces
    assert 'lan4' in interfaces
    assert 'lan5' in interfaces
    assert 'lan6' in interfaces
    assert 'lan7' in interfaces
    assert 'lan8' in interfaces
    assert 'lan9' in interfaces
    assert 'lan10' in interfaces
    assert 'lan11' in interfaces
    assert 'lan12' in interfaces
    assert 'lan13' in interfaces
    assert 'lan14' in interfaces
    assert 'lan15' in interfaces
    assert 'lan16' in interfaces

# Generated at 2022-06-17 00:59:15.952154
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:59:26.870844
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:59:35.156455
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}



# Generated at 2022-06-17 00:59:45.874171
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network_collector = HPUXNetworkCollector(module=module)
    network_collector.populate()
    network_facts = network_collector.get_facts()

    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts
    assert 'lo0' in network_facts['interfaces']
    assert 'lan0' in network_facts['interfaces']
    assert 'lan0' in network_facts
    assert 'ipv4' in network_facts['lan0']
    assert 'address' in network_facts['lan0']['ipv4']

# Generated at 2022-06-17 00:59:47.564411
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:59:48.841325
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:59:54.992818
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of class HPUXNetworkCollector
    """
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 01:00:00.369360
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "default 192.168.1.1 UGSc 0 0 lan0", ""))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 01:01:55.006414
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 01:01:57.906289
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 01:02:11.082384
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

# Generated at 2022-06-17 01:02:15.349204
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 01:02:24.759599
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkModule
    from ansible.module_utils.facts.network.hpux import HPUXNetworkFile
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCommand
    from ansible.module_utils.facts.network.hpux import HPUXNetworkFallback
    from ansible.module_utils.facts.network.hpux import HPUXNetworkParse
    from ansible.module_utils.facts.network.hpux import HPUXNetworkConditional
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

# Generated at 2022-06-17 01:02:26.436898
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 01:02:27.439144
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 01:02:29.230291
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    assert hpn.platform == 'HP-UX'


# Generated at 2022-06-17 01:02:31.760875
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 01:02:39.202521
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'