

# Generated at 2022-06-17 00:53:32.779736
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:53:34.615587
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-17 00:53:39.479699
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:53:48.252633
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces
    assert 'lan3' in interfaces
    assert 'lan4' in interfaces
    assert 'lan5' in interfaces
    assert 'lan6' in interfaces
    assert 'lan7' in interfaces
    assert 'lan8' in interfaces
    assert 'lan9' in interfaces
    assert 'lan10' in interfaces
    assert 'lan11' in interfaces
    assert 'lan12' in interfaces
    assert 'lan13' in interfaces
    assert 'lan14' in interfaces
    assert 'lan15' in interfaces
    assert 'lan16' in interfaces

# Generated at 2022-06-17 00:53:59.170564
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:54:03.981727
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.2.2'



# Generated at 2022-06-17 00:54:15.836953
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:54:28.473045
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '172.16.1.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '172.16.1.100'
    assert network_facts['lan0']['ipv4']['network'] == '172.16.1.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:54:32.593292
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetwork(module)
    assert hpux_network.module == module
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:54:42.448086
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    hpux_network.populate()
    assert hpux_network.facts['default_interface'] == 'lan0'
    assert hpux_network.facts['default_gateway'] == '192.168.1.1'
    assert hpux_network.facts['interfaces'] == ['lan0']
    assert hpux_network.facts['lan0']['ipv4']['address'] == '192.168.1.100'
    assert hpux_network.facts['lan0']['ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-17 00:54:54.195540
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-17 00:54:55.860287
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'


# Generated at 2022-06-17 00:54:59.180013
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Unit test for constructor of class HPUXNetworkCollector
    """
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'


# Generated at 2022-06-17 00:55:11.208919
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = Mock(return_value=(0, 'lan0: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 1\n'
                                                  '        inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255\n'
                                                  'lan1: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 index 1\n'
                                                  '        inet 10.0.0.2 netmask ffffff00 broadcast 10.0.0.255\n', ''))

    module = MockModule()
    hpux_network = HPUXNetwork(module)
    interfaces = hp

# Generated at 2022-06-17 00:55:23.176883
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """

# Generated at 2022-06-17 00:55:27.356559
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}


# Generated at 2022-06-17 00:55:30.857950
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-17 00:55:33.386148
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:55:38.442850
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:55:50.108016
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:55:59.965210
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network = HPUXNetwork(module=module, network_collector=network_collector)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:56:11.640531
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:56:18.308889
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:56:28.505634
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_collector = HPUXNetworkCollector(module=module)
    network_collector.populate()
    facts = network_collector.get_facts()

    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.10.10.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.10.10.10'
    assert facts['lan0']['ipv4']['network'] == '10.10.10.0'

# Generated at 2022-06-17 00:56:34.901919
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "default 10.10.10.1 UG lan0", ""))
    network_facts = HPUXNetwork(module)
    default_interfaces = network_facts.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.10.10.1'


# Generated at 2022-06-17 00:56:41.223731
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG lan0', ''))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:56:48.911367
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.10.10.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.10.10.10'
    assert network_facts['lan0']['ipv4']['network'] == '10.10.10.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:56:50.514133
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'

# Generated at 2022-06-17 00:56:54.047051
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:56:58.068914
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:57:12.349662
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
                                                 "default 192.168.1.1 UGS 0 0 0 lan0",
                                                 ""))
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 00:57:19.483356
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:57:23.710322
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 00:57:34.952778
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:57:35.912394
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-17 00:57:45.494751
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:57:56.773948
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:57:58.953363
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-17 00:58:03.497344
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-17 00:58:12.526180
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network_collector.populate()
    facts = network_collector.get_facts()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.0.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:58:34.737043
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Create a HPUXNetwork object
    hpux_network = HPUXNetwork()

    # Create a test string

# Generated at 2022-06-17 00:58:39.321469
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:58:48.047695
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network = network_collector.collect()[0]
    assert network.platform == 'HP-UX'
    assert network.default_interface == 'lan0'
    assert network.default_gateway == '10.0.2.2'
    assert network.interfaces == ['lan0']
    assert network.lan0['device'] == 'lan0'
    assert network.lan0['ipv4']['address'] == '10.0.2.15'
    assert network.lan0['ipv4']['network'] == '10.0.2.0'
    assert network.lan0['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:58:49.225604
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'

# Generated at 2022-06-17 00:58:55.546184
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface']

# Generated at 2022-06-17 00:59:04.932511
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 00:59:08.285624
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-17 00:59:10.450284
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-17 00:59:12.470403
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXNetwork


# Generated at 2022-06-17 00:59:20.784881
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.10'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['interface']

# Generated at 2022-06-17 00:59:45.419557
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-17 00:59:53.771785
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '172.16.1.1'
    assert network_facts['interfaces'] == ['lan0', 'lan1']
    assert network_facts['lan0']['ipv4']['address'] == '172.16.1.2'
    assert network_facts['lan0']['ipv4']['network'] == '172.16.1.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 00:59:56.138172
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'


# Generated at 2022-06-17 01:00:01.164641
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 01:00:03.380214
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'


# Generated at 2022-06-17 01:00:06.054999
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-17 01:00:11.142124
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 01:00:18.304562
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UGSc 0 0 lan0', ''))
    test_network = HPUXNetwork(test_module)
    default_interfaces = test_network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-17 01:00:20.528815
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'

# Generated at 2022-06-17 01:00:31.272777
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network_facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-17 01:01:46.287532
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-17 01:01:54.609829
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class ModuleStub(object):
        def __init__(self):
            self.params = {}


# Generated at 2022-06-17 01:02:04.563637
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    facts = network_facts.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.0.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.0.0.2'
    assert facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-17 01:02:10.631522
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.10.10.1'


# Generated at 2022-06-17 01:02:17.719772
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'
    assert network_facts.get_default_interfaces() == {}
    assert network_facts.get_interfaces_info() == {}
    assert network_facts.populate() == {}


# Generated at 2022-06-17 01:02:21.135981
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork
    assert hn.fact_subclasses == {}
    assert hn.collector == {}


# Generated at 2022-06-17 01:02:25.058426
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-17 01:02:28.215331
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork


# Generated at 2022-06-17 01:02:37.497605
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces
    assert 'lan3' in interfaces
    assert 'lan4' in interfaces
    assert 'lan5' in interfaces
    assert 'lan6' in interfaces
    assert 'lan7' in interfaces
    assert 'lan8' in interfaces
    assert 'lan9' in interfaces
    assert 'lan10' in interfaces
    assert 'lan11' in interfaces
    assert 'lan12' in interfaces
    assert 'lan13' in interfaces
    assert 'lan14' in interfaces
    assert 'lan15' in interfaces
    assert 'lan16' in interfaces

# Generated at 2022-06-17 01:02:42.463721
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.10.10.1'
