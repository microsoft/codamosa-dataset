

# Generated at 2022-06-22 23:56:03.215288
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc.platform == 'HP-UX'

# Generated at 2022-06-22 23:56:11.775337
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Create a mock AnsibleModule
    module = AnsibleModuleMock()
    iface = HPUXNetwork(module)
    facts = iface.populate()
    assert facts['default_interface'] == 'hpie0'
    assert facts['default_gateway'] == '10.10.10.1'
    assert facts['interfaces'] == ['hp0']
    assert facts['hp0'] == {'device': 'hp0', 'ipv4': {'address': '10.10.10.3', 'network': '10.10.10.0', 'interface': 'hp0'}}

# Generated at 2022-06-22 23:56:14.467372
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Object creation
    hpux_network_facts = HPUXNetworkCollector()
    assert hpux_network_facts._platform == 'HP-UX'

# Generated at 2022-06-22 23:56:18.751388
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    network_instance = HPUXNetwork(module)
    interfaces = network_instance.get_interfaces_info()
    assert interfaces["lan0"] == {'ipv4': {'address': '192.168.1.1',
                                          'network': '192.168.1.0',
                                          'interface': 'lan0'},
                                  'device': 'lan0'}


# Generated at 2022-06-22 23:56:20.845491
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Initialize the object
    obj = HPUXNetwork(None)
    assert obj

# Generated at 2022-06-22 23:56:32.347101
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ Unit test for `HPUXNetwork.populate` method
    """
    net = HPUXNetwork({}, None)
    net.get_default_interfaces = lambda: {'default_interface': 'lan1',
                                          'default_gateway': '192.168.2.1'}
    net.get_interfaces_info = lambda: {'lan1': {'device': 'lan1',
                                                'ipv4': {'address': '192.168.2.100',
                                                         'network': '192.168.2.0'}}}
    network_facts = net.populate()
    assert network_facts['default_interface'] == 'lan1'
    assert network_facts['default_gateway'] == '192.168.2.1'

# Generated at 2022-06-22 23:56:34.356250
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-22 23:56:38.693330
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector.platform == 'HP-UX'
    assert hpux_network_collector.fact_class == HPUXNetwork

# Generated at 2022-06-22 23:56:46.381720
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = mock.Mock()
    module.run_command.return_value = (0,
                                       "Kernel IP routing table\n"
                                       "default 192.168.1.2 UG lan0\n", '')
    network = HPUXNetwork()
    network.module = module

    default_interfaces = network.get_default_interfaces()

    expected_default_interfaces = {'default_interface': 'lan0',
                                   'default_gateway': '192.168.1.2'}
    assert expected_default_interfaces == default_interfaces


# Generated at 2022-06-22 23:56:47.661969
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    m = HPUXNetwork({})
    assert m.module is not None

# Generated at 2022-06-22 23:56:58.957066
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module_mock = AnsibleModuleMock()
    network_mock = HPUXNetwork(module_mock)
    network_facts = network_mock.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.10.10.1'
    assert network_facts['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.10.10.2'
    assert network_facts['lan0']['ipv4']['network'] == '10.10.10.0'

# Generated at 2022-06-22 23:57:01.429225
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    fact_network = HPUXNetwork(module)
    network_facts = fact_network.populate()
    assert network_facts


# Generated at 2022-06-22 23:57:04.868302
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces = HPUXNetwork.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.10.10.1'



# Generated at 2022-06-22 23:57:16.442626
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_module = AnsibleModule(argument_spec={})

    m_run_command = mock.Mock()
    m_run_command.return_value = (0, 'fake command output', 'fake command errors')
    net_module.run_command = m_run_command

    m_get_bin_path = mock.Mock()
    m_get_bin_path.return_value = '/path/to/netstat'
    net_module.get_bin_path = m_get_bin_path

    n = HPUXNetwork()
    n.module = net_module

    n.populate()
    assert n.default_interface == 'lan0'
    assert n.default_gateway == '1.2.3.4'

    interfaces = n.interfaces.keys()
    interfaces.sort()
   

# Generated at 2022-06-22 23:57:25.196167
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_facts = HPUXNetwork(module)
    network_facts.populate()

    interfaces = network_facts.interfaces
    for i in interfaces:
        assert type(i) == str
    for i in interfaces:
        assert type(interfaces[i]) == dict
        assert type(interfaces[i]['ipv4']) == dict
        assert type(interfaces[i]['ipv4']['address']) == str
        assert type(interfaces[i]['ipv4']['network']) == str

    default_interfaces = network_facts.default_interfaces
    for i in default_interfaces:
        assert type(default_interfaces[i]) == str

# Generated at 2022-06-22 23:57:35.817014
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    """ unit test for the method get_interfaces_info of class HPUXNetwork """
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    HPUNETWORK = HPUXNetwork()
    rc, out, err = HPUNETWORK.module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    interfaces_dict = {}
    for line in lines:
        words = line.split()

# Generated at 2022-06-22 23:57:41.434812
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = MockModule()
    network_obj = HPUXNetwork(module=test_module)
    default_interfaces = network_obj.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.87.3.1'



# Generated at 2022-06-22 23:57:51.441928
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork()
    network_facts.module = module
    rc, out, err = module.run_command("/usr/bin/netstat -niw")
    network_facts.out = out

    expected_result = dict(interfaces=['lan0'],
                           lan0=dict(device='lan0',
                                     ipv4=dict(network='192.168.1.0',
                                               interface='lan0',
                                               address='192.168.1.117')))
    assert expected_result == network_facts.populate()


# Generated at 2022-06-22 23:57:59.914737
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = NetworkCollector()
    test_class = HPUXNetwork()
    interfaces = test_class.get_interfaces_info()
    #print("Interfaces=", interfaces)
    interface_type = dict
    assert isinstance(interfaces, interface_type)
    assert interfaces != {}
    assert interfaces['lan1'] == {'device': 'lan1', 'ipv4': {'network': '172.17.19.0',
                                                             'interface': 'lan1',
                                                             'address': '172.17.19.160'}}


# Generated at 2022-06-22 23:58:11.262882
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hn = HPUXNetwork()

    hn.module = MagicMock()
    hn.module.run_command.return_value = (0, """default 192.168.1.1 UGS  0 0    - lan0
192.168.1.0 192.168.1.1 UGS  0 0    - lan0
192.168.2.0 192.168.2.1 UGS  0 0    - lan1""", "")
    hn.module.get_bin_path.return_value = "/usr/bin/netstat"

    default_interfaces_facts = hn.get_default_interfaces()
    assert default_interfaces_facts == {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}


# Generated at 2022-06-22 23:58:12.464624
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()



# Generated at 2022-06-22 23:58:18.580738
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hn = HPUXNetwork()
    hn.module = MockModule()
    hn.module.run_command = Mock(return_value=(0, sample_output_netstat_iw, ''))
    interfaces = hn.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'address': '172.16.1.90',
                                           'network': '172.16.1.0',
                                           'interface': 'lan0'}}
    assert interfaces['lan1'] == {'device': 'lan1',
                                  'ipv4': {'address': '192.168.1.90',
                                           'network': '192.168.1.0',
                                           'interface': 'lan1'}}

sample_

# Generated at 2022-06-22 23:58:25.462304
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})

    hpux_network = HPUXNetwork(module)
    netstat_path = hpux_network.module.get_bin_path('netstat')
    assert netstat_path is not None

    rc = hpux_network.module.run_command(netstat_path + " -niw")
    assert rc[0] == 0

    rc = hpux_network.module.run_command(netstat_path + " -nr")
    assert rc[0] == 0

    net_facts = hpux_network.populate(None)
    assert net_facts is not None


# Generated at 2022-06-22 23:58:30.502835
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    default_interfaces_facts = HPUXNetwork.get_default_interfaces(module)
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts


# Generated at 2022-06-22 23:58:34.036200
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    my_hpux_network = HPUXNetwork()
    my_hpux_network.module = AnsibleModuleStub()
    assert my_hpux_network.populate().keys() == ['ansible_facts']



# Generated at 2022-06-22 23:58:36.955677
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-22 23:58:48.567777
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interface_info = {}
    interface_info['lan0'] = {'device': 'lan0',
                              'ipv4': {'address': '10.0.2.15',
                                       'network': '10.0.2',
                                       'address': '10.0.2.15'}}
    interface_info['lan1'] = {'device': 'lan1',
                              'ipv4': {'address': '10.0.1.15',
                                       'network': '10.0.1',
                                       'address': '10.0.1.15'}}

# Generated at 2022-06-22 23:58:51.735524
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(module)
    facts = network.populate()
    assert 'default_interface' in facts
    assert 'interfaces' in facts



# Generated at 2022-06-22 23:58:59.219896
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
                                                 'lan0      lan0      unspec   0      -       65    -      \
                                                 -      0    -      -        0      -           0  56794  0  \
                                                 0     -     -     -     0.0.0.0   0.0.0.0        - \
                                                 0.0.0.0   0.0.0.0     -',
                                                 ''))
    network = HPUXNetwork(module)
    ifaces = network.get_interfaces_info()
    assert ifaces.keys() == ['lan0']
    assert ifaces['lan0']['device'] == 'lan0'

# Generated at 2022-06-22 23:59:07.794691
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    input1 = {'_ansible_version': '2.8.1'}
    input2 = HPUXNetworkCollector.get_device_data()
    obj = HPUXNetwork(input1, 'tmp', 'root', input2)
    assert obj.module == input1
    assert obj.module_name == 'tmp'
    assert obj.module_args == 'root'
    assert obj.device_data == input2
    assert obj.fact_class == HPUXNetwork
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-22 23:59:08.604722
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-22 23:59:14.271391
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """Test the get_default_interfaces method of HPUXNetwork class. """
    mock_module = MockedModule()
    network_obj = HPUXNetwork(mock_module)
    default_interfaces = network_obj.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.34.158.1'


# Generated at 2022-06-22 23:59:21.226557
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = type('', (), {})()
    module.fail_json = fail_json
    module.get_bin_path = get_bin_path
    module.run_command = run_command

    module.params = {'gather_subset': ['!all', 'network']}

    net = HPUXNetwork(module)
    facts = net.populate()

    assert 'default_interface' in facts.keys()
    assert 'default_gateway' in facts.keys()
    assert 'interfaces' in facts.keys()

    interfaces = facts['interfaces']
    for iface in interfaces:
        assert iface in facts.keys()
        assert 'ipv4' in facts[iface].keys()
        assert 'network' in facts[iface]['ipv4'].keys()
        assert 'interface' in facts

# Generated at 2022-06-22 23:59:31.862078
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule:
        def __init__(self):
            self.run_command_lines = [
                (1, 'default 10.11.1.1 UG lan0', ''),  # Default interface
                (1, '1    10.11.1.1  UG  lan0', ''),  # Scenario with "1"
            ]
            self.run_command_count = 0

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/bin/netstat'

        def run_command(self, cmd, check_rc=False):
            (rc, out, err) = self.run_command_lines[self.run_command_count]
            self.run_command_count += 1
            return (rc, out, err)

    network_facts = HPU

# Generated at 2022-06-22 23:59:34.931560
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts ={'ansible_os_family': 'HP-UX'}
    network = HPUXNetworkCollector(None, facts, None)
    assert network._platform == 'HP-UX'
    assert network._fact_class == HPUXNetwork

# Generated at 2022-06-22 23:59:37.058194
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = Network(dict())
    assert net.platform == 'Generic'
    net = HPUXNetwork(dict())
    assert net.platform == 'HP-UX'


# Generated at 2022-06-22 23:59:39.803517
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork()
    network.module = module
    print(network.populate())


# Generated at 2022-06-22 23:59:50.568484
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    import subprocess
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hn = HPUXNetwork()
    hn._module = subprocess
    hn._module.run_command = lambda x: (0,
                                        "      lan0       192.168.1.1   255.255.255.0   U   8   0      0 lan0",
                                        None)
    hn.populate()
    assert hn.facts['interfaces'] == ['lan0']
    assert hn.facts['lan0'] == {'device': 'lan0',
                                'ipv4': {'address': '192.168.1.1',
                                         'network': '192.168.1.0',
                                         'interface': 'lan0'}}



# Generated at 2022-06-22 23:59:51.742422
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = None

    hux_net = HPUXNetwork(module)

    return hux_net

# Generated at 2022-06-23 00:00:02.888274
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux.hpux import (
        HPUXNetworkCollector
    )
    from ansible.module_utils.facts.network.hpux.hpux import Task
    from ansible.module_utils.facts.network.hpux.hpux import AnsibleModule

    # Create a fake AnsibleModule object
    fake_module = AnsibleModule()
    # Create a fake Task object
    task = Task(fake_module)
    # Create a HPUXNetworkCollector object
    facts_collector = HPUXNetworkCollector(task)
    # Create a HPUXNetwork object
    network_facts = HPUXNetwork(facts_collector)

    # Create the result of calling

# Generated at 2022-06-23 00:00:13.079948
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class module:
        def get_bin_path(self):
            return "/usr/bin/netstat"
        def run_command(self):
            return 0, '''default 1.2.3.4 UG lan1
default 5.6.7.8 UG lan2
''', ''
    class ansible_module:
        def __init__(self):
            self.module = module()
    network = HPUXNetwork(ansible_module())
    ret = network.get_default_interfaces()
    assert ret['default_interface'] == 'lan2'
    assert ret['default_gateway'] == '5.6.7.8'


# Generated at 2022-06-23 00:00:21.589970
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    ifacenetwork = HPUXNetwork({})
    default_interfaces_facts = {'default_interface': 'lan0',
                                'default_gateway': '10.0.0.1'}

# Generated at 2022-06-23 00:00:29.680824
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    '''
    Unit test for method get_default_interfaces of class HPUXNetwork
    '''
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork()
    network.module = module

    if network.get_default_interfaces()['default_interface'] == 'lan0':
        exit_json({'changed': False})
    else:
        exit_json({'msg': 'Unit test for get_default_interfaces failed'})

# Generated at 2022-06-23 00:00:31.709814
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_facts = HPUXNetwork(module)
    assert hpux_facts
    assert hpux_facts.platform == 'HP-UX'



# Generated at 2022-06-23 00:00:32.472183
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork().platform == 'HP-UX'

# Generated at 2022-06-23 00:00:34.001119
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:00:38.561347
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    This test tries to instantiate class HPUXNetworkCollector and checks
    that created object is an instance of NetworkCollector.
    """
    network_collector = HPUXNetworkCollector()
    assert isinstance(network_collector, NetworkCollector)


# Generated at 2022-06-23 00:00:47.355333
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Test of get_default_interfaces method of class HPUXNetwork
    """
    #pylint: disable=too-many-locals
    #pylint: disable=too-many-branches
    #pylint: disable=too-many-statements
    #pylint: disable=protected-access
    #pylint: disable=unused-argument
    class FakeModule:
        @staticmethod
        def run_command(params):
            return 0, netstat_out, ''

        @staticmethod
        def get_bin_path(params):
            return '/usr/bin/netstat'
    result = {}
    netstat_out = "HP-UX network statistics\n"
    netstat_out += "Routing tables\n"
    netstat_out += "\n"
    netstat

# Generated at 2022-06-23 00:00:53.097103
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    hn.module = AnsibleModuleStub()
    hn.module.run_command.return_value = (0, '', '')
    hn.get_interfaces_info = lambda: ''
    hn.get_default_interfaces = lambda: ''
    hn.populate()

# Generated at 2022-06-23 00:01:01.175617
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    ''' Unit test for method populate of class HPUXNetwork
    '''
    m_module = MagicMock()

# Generated at 2022-06-23 00:01:11.235125
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:01:13.376726
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork()
    network.get_interfaces_info()

# Generated at 2022-06-23 00:01:16.267895
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network_module = HPUXNetwork()
    network_fact = network_module.get_default_interfaces()
    assert network_fact['default_interface'] == 'lan0'
    assert network_fact['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-23 00:01:20.700653
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = NetworkFactModule()
    hpuxNetwork = HPUXNetwork(module=m)
    default_interfaces = hpuxNetwork.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.5.5.5'


# Generated at 2022-06-23 00:01:28.727589
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork

    hpux_ifaces_info = {'lan0': {'ipv4': {'interface': 'lan0',
                                          'address': '10.10.10.11',
                                          'network': '10.10.10'},
                                 'device': 'lan0'}
                        }
    hpux_network = HPUXNetwork({'module': None})
    assert hpux_network.get_interfaces_info() == hpux_ifaces_info



# Generated at 2022-06-23 00:01:32.194029
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    x = HPUXNetworkCollector()
    assert x.platform == 'HP-UX'

# Generated at 2022-06-23 00:01:35.814712
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network._fact_class == HPUXNetwork
    assert network._platform == 'HP-UX'


# Generated at 2022-06-23 00:01:45.631249
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule
    module.run_command = MagicMock(return_value=(0, '/usr/bin/netstat -niw', ''))
    hpux_network = HPUXNetwork(module)
    result = hpux_network.get_interfaces_info()
    assert result == {'lan0': {'ipv4': {'address': '192.168.0.2',
                                        'interface': 'lan0',
                                        'network': '192.168.0.0'}},
                      'lan1': {'ipv4': {'address': '192.168.1.2',
                                        'interface': 'lan1',
                                        'network': '192.168.1.0'}}}

# Generated at 2022-06-23 00:01:48.040587
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class is HPUXNetwork
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-23 00:01:58.445882
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock({})
    module.run_command = AnsibleRunCommandMock(
        rc=0, out='default 10.146.0.1 UG lan0\n'
                 '10.146.0.0 10.146.0.255 U lan0', err='')
    hpux_network = HPUXNetwork()
    hpux_network.module = module
    hpux_network_facts = hpux_network.populate()

# Generated at 2022-06-23 00:02:00.392592
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net_facts = HPUXNetwork()

    assert net_facts.platform == 'HP-UX'

# Generated at 2022-06-23 00:02:03.436098
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-23 00:02:14.205051
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpu import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.base import Network

    class FakeModule(object):
        def get_bin_path(self, arg):
            return "/usr/bin"

        def run_command(self, arg):
            if arg == '/usr/bin/netstat -nr':
                return (0, 'default 192.168.42.129 UGSc 42 27 lan0', '')

# Generated at 2022-06-23 00:02:14.961345
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:02:17.724137
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork(dict())
    assert net.default_gateway == ''
    assert net.default_interface == ''
    assert net.interfaces == list()
    assert net.ipv4 == dict()
    assert net.ipv6 == dict()

# Generated at 2022-06-23 00:02:21.293112
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpu = HPUXNetwork({})
    ifaces = hpu.get_interfaces_info()
    keys = ['lan0']
    assert ifaces.keys() == keys

# Generated at 2022-06-23 00:02:31.519881
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hn = HPUXNetwork()
    hn.module.run_command = lambda args: (0, '', '')
    hn.module._executable_exists = lambda path: True
    default_interfaces_facts = hn.get_default_interfaces()
    assert default_interfaces_facts == {}
    # to test run_command results
    hn.module.run_command = lambda args: (0, 'default 10.1.1.1 UG   lan0', '')
    default_interfaces_facts = hn.get_default_interfaces()
    assert default_interfaces_facts == {'default_interface': 'lan0', 'default_gateway': '10.1.1.1'}


# Generated at 2022-06-23 00:02:35.358977
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert hasattr(collector, '_fact_class') is True
    assert hasattr(collector, '_platform') is True


# Generated at 2022-06-23 00:02:38.529446
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Test with no arguments
    network = HPUXNetworkCollector()
    assert network.get_fact_class() == HPUXNetwork
    assert network.get_platform() == 'HP-UX'


# Generated at 2022-06-23 00:02:40.222467
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net_obj = HPUXNetwork()
    assert net_obj.platform == 'HP-UX'

# Generated at 2022-06-23 00:02:46.407614
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = HPUXNetwork()
    mock_module = MagicMock()
    mock_module.run_command.return_value = [0, '', '']
    m.module = mock_module
    m.populate()
    assert mock_module.run_command.call_args_list == [call('/usr/bin/netstat -nr'),
                                                      call('/usr/bin/netstat -niw')]

# Generated at 2022-06-23 00:02:48.988408
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork(None)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-23 00:02:50.803318
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.fact_class
    assert obj.platform

# Generated at 2022-06-23 00:02:56.858221
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    result = HPUXNetwork.get_interfaces_info()
    assert result == {
        'lan0': {
            'device': 'lan0',
            'ipv4': {
                'address': '172.16.121.8',
                'interface': 'lan0',
                'network': '172.16.121.0'
            }
        }
    }

# Generated at 2022-06-23 00:02:58.592953
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'



# Generated at 2022-06-23 00:03:00.796273
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'



# Generated at 2022-06-23 00:03:03.399523
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'

# Generated at 2022-06-23 00:03:05.510112
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:03:13.073935
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = DummyModule()
    module.run_command = get_interfaces_info_dummy
    network = HPUXNetwork(module=module)
    interfaces = network.get_interfaces_info()
    test = interfaces['lan0']['ipv4']['address']
    if test != '172.17.0.3':
        raise Exception("Unit test for method get_interfaces_info of "
                        "class HPUXNetwork was failed")


# Generated at 2022-06-23 00:03:25.017268
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={'module_name': {'required': False, 'type': 'str'},
                       'module_args': {'required': False, 'type': 'str'}})
    set_module_args(dict(module_name='test_HPUXNetwork',
                         module_args=dict()))
    obj = HPUXNetwork(module)
    rc, out, err = module.run_command('/usr/bin/netstat -nr')
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]

# Generated at 2022-06-23 00:03:27.558068
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    the_HPUXNetwork = HPUXNetwork()
    the_HPUXNetwork.populate()
    # print(the_HPUXNetwork)
    # print(the_HPUXNetwork.facts)

# Generated at 2022-06-23 00:03:38.082837
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd, check_rc=True):
            return (self.rc, self.out, self.err)

    module = MockModule(0, 'default 192.168.10.254 UGS 0 1500 lan0', '')
    network_facts = HPUXNetwork()
    network_facts.module = module
    result = network_facts.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.10.254'


# Generated at 2022-06-23 00:03:40.460983
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:03:42.509945
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork

# Generated at 2022-06-23 00:03:53.364725
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_obj = HPUXNetwork(module)
    network_facts = network_obj.populate()
    assert network_facts['default_interface'] == 'lan11'
    assert network_facts['default_gateway'] == '172.20.100.1'
    assert network_facts['interfaces'][0] == 'lan11'
    assert network_facts['lan11']['ipv4']['address'] == '172.20.100.156'
    assert network_facts['lan11']['ipv4']['network'] == '172.20.100.0'
    assert network_facts['lan11']['ipv4']['interface'] == 'lan11'

# Generated at 2022-06-23 00:04:03.313073
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    raw_network_facts = {
        'default_interfaces': {'default_interface': 'lan0', 'default_gateway': '10.10.0.1'},
        'interfaces': ['lan0', 'lan1'],
        'lan0': {'device': 'lan0', 'ipv4': {'address': '10.10.0.2', 'network': '10.10.0.0',
                                            'interface': 'lan0', 'address': '10.10.0.2'}},
        'lan1': {'device': 'lan1', 'ipv4': {'address': '10.10.1.2', 'network': '10.10.1.0',
                                            'interface': 'lan1', 'address': '10.10.1.2'}}
    }

   

# Generated at 2022-06-23 00:04:14.049201
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    # input data is similar output from /usr/bin/netstat -nr
    netstat_output = """default 172.17.0.1 UG 0 0 0 lan9
172.17.0.0/24 172.17.0.1 U 0 0 0 lan9
172.17.0.0/24 127.0.0.1 U 0 0 0 lo0"""
    test_netstat = Network()
    test_netstat.module = Network()
    return_value = test_netstat.get_default_interfaces(netstat_output)
    assert return_value['default_interface'] == 'lan9'
    assert return_value['default_gateway'] == '172.17.0.1'


# Generated at 2022-06-23 00:04:20.209259
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork(None)

    expected_out_1 = {'default_interface': 'lan0',
                      'default_gateway': '10.10.0.1'}
    out_1 = net.get_default_interfaces()
    assert (out_1 == expected_out_1)


# Generated at 2022-06-23 00:04:23.060216
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    hpn.get_default_interfaces()
    hpn.get_interfaces_info()
    hpn.populate()

# Generated at 2022-06-23 00:04:32.316427
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # create a dummy module containing a valid path to netstat
    path = "/usr/bin/netstat"
    module = type('', (), {'run_command': lambda self, cmd: (0, '', ''),
                           'get_bin_path': lambda self, binary: path})()
    # create a new instance of HPUXNetwork
    network = HPUXNetwork(module)
    # try to get the collected facts
    facts = network.populate()
    # check the default_interface facts
    assert(facts['default_interface'] != '')
    # check the default_gateway facts
    assert(facts['default_gateway'] != '')
    # check the interfaces facts
    assert(facts['interfaces'] != '')
    # check the ipv4 interface address facts

# Generated at 2022-06-23 00:04:36.048844
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    collected_facts = dict()
    network = HPUXNetwork(module)
    network_facts = network.populate(collected_facts)
    assert network_facts['default_interface'] == 'lan8'



# Generated at 2022-06-23 00:04:40.291468
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkCollector()
    network = HPUXNetwork(module)
    facts = network.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.208.98.1'
    assert facts['interfaces'][0] == 'lan0'

# Generated at 2022-06-23 00:04:47.019388
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    rc, out, err = network.module.run_command("/usr/bin/netstat -nr")
    result = network.get_default_interfaces()
    assert 'default_interface' in result
    assert 'default_gateway' in result
    if err != '':
        module.fail_json(msg=err)


# Generated at 2022-06-23 00:04:58.241166
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Test hpux netstat output
    NETSTAT_OUTPUT = """Routing tables

Internet:
Destination        Gateway           Flags   Refs     Use  If  Pmtu  State
default            172.16.2.254      UG        1        0  lan1     -  Enabld
127.0.0.1          127.0.0.1         UH        1        0  lo0       -  Enabld
"""

    # Setup
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork()

    # Pre-condition
    module.run_command = MagicMock(return_value=(0, NETSTAT_OUTPUT, ''))

    # Call method to test
    result = network.get_default_interfaces(module)

    # Make test assertions
    assert result is not None

# Generated at 2022-06-23 00:05:00.727392
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:05:03.071166
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:05:08.314898
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command):
            return '/usr/bin/netstat'

        def run_command(self, command):
            return 0, 'default  0000000B 00000000D2B46600', None

    my_object = MockModule()
    network = HPUXNetwork(module=my_object)
    network.populate()
    assert network.default_interface == 'D2B46600'
    assert network.default_gateway == '0000000B'



# Generated at 2022-06-23 00:05:09.298463
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()


# Generated at 2022-06-23 00:05:21.240744
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Create a mock module
    module = MockModule()

    # Create a mock command for netstat command which is executed
    # by the populate method of class HPUXNetwork
    mock_command1 = MockCommand("/usr/bin/netstat -nr")
    mock_command2 = MockCommand("/usr/bin/netstat -niw")
    commands = [mock_command1, mock_command2]

    # Populate the mock module with mock commands
    module.run_command.side_effect = commands

    # Create an instance of the HPUXNetwork
    network = HPUXNetwork()

    # Call the populate method of the HPUXNetwork
    network.populate()

    # Assert that run_command of the mock module has been called twice

# Generated at 2022-06-23 00:05:33.143518
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPXtestModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, cmd):
            return "/usr/bin/netstat"

# Generated at 2022-06-23 00:05:45.081133
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # Call method populate of class HPUXNetwork with a mock of module
    result = HPUXNetwork.populate(module)

# Generated at 2022-06-23 00:05:46.650824
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_fact = HPUXNetwork()
    assert network_fact.platform == 'HP-UX'


# Generated at 2022-06-23 00:05:56.217882
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network.populate()
    assert network.facts['default_interface'] == 'lan0'
    assert network.facts['default_gateway'] == '10.0.2.2'
    assert 'lan0' in network.facts['interfaces']
    assert 'lan1' in network.facts['interfaces']
    assert 'lan2' in network.facts['interfaces']
    assert 'lan0' in network.facts
    assert 'lan1' in network.facts
    assert 'lan2' in network.facts
    assert network.facts['lan0']['device'] == 'lan0'
    assert network.facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert network

# Generated at 2022-06-23 00:06:06.745850
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()