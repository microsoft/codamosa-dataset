

# Generated at 2022-06-22 23:56:04.626143
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}
    fact_module_mock = FakeFactModule(['netstat -niw'],
                                      netstat_niw_out)
    hpu_network = HPUXNetwork(fact_module_mock)
    interfaces = hpu_network.get_interfaces_info()
    for device in interfaces:
        for key in interfaces[device]:
            if key != 'device':
                assert 'tcp' not in interfaces[device][key]['address']


# Generated at 2022-06-22 23:56:08.427636
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hpuxnetwork_instance = HPUXNetwork(module)
    assert hpuxnetwork_instance.platform == 'HP-UX'

# Generated at 2022-06-22 23:56:19.327392
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)

    # Normally, we would use mock of the ansible module to provide
    # module.get_bin_path() and module.run_command(). Instead, we will
    # use real commands and data, since it is easy to get on HP-UX.
    #
    # Create empty dictionary for collected_facts.
    collected_facts = {}
    network_facts = network.populate()

    # Test for the presence of network_facts['interfaces']
    assert network_facts['interfaces']

    # Test for the presence of network_facts['default_interface']
    assert network_facts['default_interface']

    # Test for the presence of network_facts['default_gateway']
    assert network_facts['default_gateway']

    # Test for

# Generated at 2022-06-22 23:56:28.190683
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import platform

    module = MockModule()
    module.run_command = mock_run_command

    network = HPUXNetwork(module)

    # Set OS to HP-UX
    platform.system = mock__hpux_system

    # Run method
    default_interfaces_facts = network.get_default_interfaces()

    # Check facts produced
    assert default_interfaces_facts['default_interface'] == 'lan1'
    assert default_interfaces_facts['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-22 23:56:31.021707
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # run test
    net_collector = HPUXNetworkCollector()

    # test parameters
    assert net_collector._fact_class == HPUXNetwork
    assert net_collector._platform == 'HP-UX'

# Generated at 2022-06-22 23:56:32.558749
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform =="HP-UX"


# Generated at 2022-06-22 23:56:36.586669
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    rc, out, err = net.module.run_command("/usr/bin/netstat -nr")
    assert out.splitlines()[1].split()[4] == 'lan0'



# Generated at 2022-06-22 23:56:44.370967
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    facts = HPUXNetwork(module)

    rc, out, err = module.run_command("/usr/bin/netstat -niw")
    iface = out.splitlines()[1].split()[0]
    assert facts.default_gateway is not None
    assert facts.default_interface is not None
    assert out.splitlines()[1].split()[3] == facts.interface[iface]['ipv4']['address']

# Generated at 2022-06-22 23:56:50.924811
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_class = HPUXNetwork()
    interfaces = test_class.get_interfaces_info()
    device = interfaces.keys()[0]
    assert 'lan0' == device
    assert 'lan0' == interfaces[device]['device']
    assert '192.168.0.1' == interfaces[device]['ipv4']['address']
    assert '192.168.0.0' == interfaces[device]['ipv4']['network']

# Generated at 2022-06-22 23:56:53.539247
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'


# Generated at 2022-06-22 23:56:54.823142
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector()



# Generated at 2022-06-22 23:57:02.713385
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.base import Network, NetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    # Test with good data
    hpux_network = HPUXNetwork({'ansible_facts': {'distribution': 'HP-UX', 'module_setup': True}})

    facts = {'ansible_eth0': {'ipv4': {'address': '10.0.2.15'}},
             'ansible_eth1': {'ipv4': {'address': '192.168.1.42'}}}

    hpux_network.populate(facts)

# Generated at 2022-06-22 23:57:08.073655
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_class = HPUXNetwork()
    test_class.module = DummyAnsibleModule('fake_module')
    netstat_bin = test_class.module.get_bin_path('netstat')
    if netstat_bin is not None:
        result = test_class.populate()
        assert result is not None



# Generated at 2022-06-22 23:57:18.432409
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    network = HPUXNetworkCollector.collect(None, None)

    assert network['default_interface'] == 'lan0'
    assert network['default_gateway'] == '10.241.0.1'
    assert 'lan0' in network['interfaces']
    assert network['lan0']['ipv4']['address'] == '10.241.0.3'
    assert network['lan0']['ipv4']['network'] == '10.241.0.0'
    assert network['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-22 23:57:23.492056
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Create an instance of the HPUXNetwork class
    on = HPUXNetwork(module=None)

    # Populate instance with network facts
    facts = on.populate()

    # Assert facts are as expected
    assert 'default_interface' in facts
    assert 'default_gateway' in facts
    assert 'interfaces' in facts
    assert 'lo0' in facts



# Generated at 2022-06-22 23:57:27.825351
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h = HPUXNetworkCollector()
    assert h._platform == 'HP-UX'
    assert h._fact_class.__name__ == 'HPUXNetwork'
    assert h._fact_class().platform == 'HP-UX'


# Generated at 2022-06-22 23:57:35.805430
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    emulated_module = AnsibleMockModule({'warnings': list()})
    emulated_module.run_command = mock_run_command
    emulated_module.get_bin_path = mock_get_bin_path
    hpux_network = HPUXNetwork(emulated_module)

    interfaces = hpux_network.get_interfaces_info()
    assert('lan1' in interfaces)

    lan1 = interfaces['lan1']
    assert('ipv4' in lan1)
    assert('network' in lan1['ipv4'])
    assert(lan1['ipv4']['network'] == '10.10.0.0')



# Generated at 2022-06-22 23:57:39.143682
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    obj = HPUXNetwork()
    obj.module = NetworkCollectorTestMock()

    facts = dict()
    facts['network'] = obj.populate()
    assert 'lan0' in facts['network']['interfaces']
    assert 'ipv4' in facts['network']['lan0']
    assert 'address' in facts['network']['lan0']['ipv4']
    assert 'network' in facts['network']['lan0']['ipv4']
    assert 'default_interface' in facts['network']
    assert 'default_gateway' in facts['network']


# Generated at 2022-06-22 23:57:43.109669
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux = HPUXNetwork(dict())
    assert hpux.platform == 'HP-UX'
    assert hpux.module


# unit test for get_default_interfaces of class HPUXNetwork

# Generated at 2022-06-22 23:57:50.906102
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts import FactCollector
    facts_collector = FactCollector()
    network_collector = HPUXNetworkCollector(facts_collector)
    collected_facts = NetworkCollector.populate(network_collector)
    fact_network = HPUXNetwork(collected_facts)
    fact_network.populate()


if __name__ == '__main__':
    test_HPUXNetwork_populate()

# Generated at 2022-06-22 23:57:54.864316
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = {}
    netstat = HPUXNetwork(module)
    interfaces = netstat.get_interfaces_info()

    assert type(interfaces) is dict
    assert 'lan0' in interfaces

# Generated at 2022-06-22 23:57:56.637129
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-22 23:58:00.327777
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class is HPUXNetwork
    assert HPUXNetworkCollector.platforms == ['HP-UX']

# HP-UX tests

# Generated at 2022-06-22 23:58:06.130051
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    set_module_args({})
    hn = HPUXNetwork({})
    name = hn.get_default_interfaces()['default_interface']
    print("Default interface is %s" % name)
    assert name is not None
    assert name in ('lan0', 'lan1', 'lan2', 'lan3', 'lan4')



# Generated at 2022-06-22 23:58:10.023742
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = HPUXNetwork()
    module.module.run_command = lambda x: (0, "default            192.168.1.1       UG          0 3        lan23", "")
    expected_default_interfaces = {'default_gateway': '192.168.1.1', 'default_interface': 'lan23'}
    assert module.get_default_interfaces() == expected_default_interfaces

# Generated at 2022-06-22 23:58:21.204194
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_obj = HPUXNetwork(module)
    rc, out, err = module.run_command("/usr/bin/netstat -niw")
    interfaces = network_obj.get_interfaces_info()

    assert(len(interfaces) > 0)
    for iface in interfaces:
        assert(interfaces[iface]['device'] == iface)
        assert(interfaces[iface]['ipv4']['address'] == '0.0.0.0')
        assert(interfaces[iface]['ipv4']['network'] == '0.0.0.0')
        assert(interfaces[iface]['ipv4']['interface'] == iface)

    return True


# Generated at 2022-06-22 23:58:32.310861
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset':'!all,min'}
        def get_bin_path(self,cmd):
            return "/usr/bin/netstat"
        def run_command(self, cmd):
            out = "lanE0  default  192.168.1.0 UG   2      0        lanE0  "
            return (0, out, '')

    oci = HPUXNetwork(MockModule())
    default_interfaces = oci.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lanE0',
                                  'default_gateway': '192.168.1.0'}


# Generated at 2022-06-22 23:58:36.248862
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._platform == 'HP-UX'
    assert hn._fact_class == HPUXNetwork


# Generated at 2022-06-22 23:58:48.176565
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method ``HPUXNetwork.populate``.
    """
    import subprocess
    from ansible.module_utils.facts.network.hpu_ux.hpu_ux import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    # Mock class Network methods
    Network.run_command = lambda self: (0, 'Fake run_command output', '')
    network_collector = HPUXNetworkCollector()
    hpu_ux_network = HPUXNetwork(network_collector)
    network_facts = hpu_ux_network.populate()

# Generated at 2022-06-22 23:58:50.363845
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net_mod = HPUXNetwork({})
    assert 'default_interface' in net_mod.get_default_interfaces()

# Generated at 2022-06-22 23:58:53.928662
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Test case to construct an object of class HPUXNetworkCollector
    """
    net_collector_obj = HPUXNetworkCollector()
    assert net_collector_obj._platform == 'HP-UX'
    assert net_collector_obj._fact_class == HPUXNetwork


# Generated at 2022-06-22 23:59:05.551876
# Unit test for constructor of class HPUXNetwork

# Generated at 2022-06-22 23:59:07.570508
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod = AnsibleModuleMock({})
    net = HPUXNetwork(mod)
    assert mod == net.module

# Generated at 2022-06-22 23:59:16.770447
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class mock_module(object):
        def __init__(self):
            self.params = {'path': ''}

        def get_bin_path(self, *args):
            return args[0]

        def run_command(self, *args):
            return 0, "lan0      14776565      0   0  4  1 4 0    0        0 lo0\n", None
    network = HPUXNetwork(mock_module())
    ifaces = network.get_interfaces_info()
    assert ifaces == {'lan0': {'ipv4': {'network': 'lo0',
                                        'interface': 'lan0',
                                        'address': 'lan0'},
                               'device': 'lan0'}}


# Generated at 2022-06-22 23:59:28.277790
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class_name = 'network_module.HPUXNetwork'
    module = AnsibleModule({}, {}, False, False)
    setattr(module, 'get_bin_path', lambda x, **kwargs: None)
    setattr(module, 'run_command', lambda x, **kwargs: (0, "", ""))

    def run_command(self, cmd):
        return (0, "default 192.0.2.5 UGS 0 80 lo0", "")

    run_command_method_mock = Mock(side_effect=run_command)
    setattr(module, 'run_command', run_command_method_mock)

    ansible_facts = {}
    network = __import__(class_name).HPUXNetwork({}, ansible_facts, module)
    default_interfaces = network.get

# Generated at 2022-06-22 23:59:29.606592
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network is not None

# Generated at 2022-06-22 23:59:39.149647
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-22 23:59:45.801247
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    module.run_command.return_value = (0, "default 192.168.0.1 UGS 0 0 0 lan8\n", "")
    hn = HPUXNetwork()
    hn.module = module
    network_facts = hn.populate()
    assert network_facts['default_interface'] == 'lan8'
    assert network_facts['default_gateway'] == '192.168.0.1'



# Generated at 2022-06-22 23:59:47.878523
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-22 23:59:52.378773
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    hpuxnetwork = HPUXNetwork(module)
    network_facts = hpuxnetwork.populate()
    assert network_facts['default_interface'].startswith('lan'), \
        "Default interface should start with lan"
    assert network_facts['default_gateway'].startswith('10.'), \
        "Default gateway should start with 10."

# Generated at 2022-06-23 00:00:01.284322
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class HPUXNetwork """

    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    test_object = HPUXNetwork()
    network_facts = {}
    network_facts = test_object.get_interfaces_info()
    test_network_facts = {'lan2': {'ipv4': {'network': '0.0.0.0', 'address': '192.168.60.222'},
                                   'device': 'lan2'}}
    assert(network_facts == test_network_facts)

# Generated at 2022-06-23 00:00:03.684796
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork(None)
    assert hpux_network.platform == 'HP-UX'

# Generated at 2022-06-23 00:00:15.183695
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    result = HPUXNetwork(module).populate()
    assert 'default_interface' in result.keys()
    assert 'default_gateway' in result.keys()
    assert 'interfaces' in result.keys()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.122.1'
    assert 'lan0' in result['interfaces']
    assert {'ipv4': {'address': '192.168.122.101', 'network': '192.168.122.0', 'interface': 'lan0'}, 'device': 'lan0'} == result['lan0']


# Generated at 2022-06-23 00:00:16.154020
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:00:17.061124
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpn = HPUXNetworkCollector()
    assert hpn


# Generated at 2022-06-23 00:00:28.708998
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # generate test data
    interfaces = {
        'lan0': {
            'device': 'lan0',
            'ipv4': {
                'address': '9.86.169.49',
                'network': '9.86.169.0',
                'netmask': '255.255.255.0',
                'broadcast': '9.86.169.255'}}}

    # root netstat
    netstat_path = '/usr/bin/netstat'

# Generated at 2022-06-23 00:00:31.846954
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    data = '''
            default       10.192.0.1       UG        0        0        lan0
    '''.splitlines()
    # Create a instance of HPUXNetworkCollector
    fact_network = HPUXNetworkCollector(data)
    if fact_network.platform == 'HP-UX' and fact_network._fact_class == HPUXNetwork:
        assert True
    else:
        assert False

# Generated at 2022-06-23 00:00:36.427242
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    HP-UX: Test cases for constructor of class HPUXNetworkCollector.
    """
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-23 00:00:46.590367
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import ModuleDataCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.base import Network
    import sys

    # Initialize mocks for test.
    class TestModule:
        @staticmethod
        def _handle_exception(exc):
            pass
        @staticmethod
        def run_command(cmd):
            return (0, "lan0: flags=8d43<UP,BROADCAST,RUNNING,MULTICAST,NOARP>\n", "")
    TestModule.params = dict()
    TestModule.tmpdir = ""
    TestModule.ansible_facts = dict()
    TestModule.fail_json = lambda **kwargs: exit(1)


# Generated at 2022-06-23 00:00:48.416676
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'


# Generated at 2022-06-23 00:00:55.880409
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    assert h.populate() == {'default_interface': 'lan1000',
                            'default_gateway': '192.168.2.254',
                            'interfaces': ['lan1000'],
                            'lan1000': {'device': 'lan1000',
                                        'ipv4': {'address': '192.168.2.200',
                                                 'network': '192.168.2.0',
                                                 'interface': 'lan1000'}}}

# Generated at 2022-06-23 00:01:01.314333
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'
    assert len(hpux_network.interfaces) > 0
    assert hpux_network.default_interface is not None
    assert hpux_network.default_gateway is not None
    for interface in hpux_network.interfaces:
        assert hpux_network[interface]['device'] == interface
        assert hpux_network[interface]['ipv4']['address'] is not None
        assert hpux_network[interface]['ipv4']['network'] is not None

# Generated at 2022-06-23 00:01:07.219258
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = type('', (object,), {'run_command': fake_run_command})
    hpux_net = HPUXNetwork(module=module)
    default_interfaces = hpux_net.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0', 'default_gateway': '10.17.1.1'}


# Generated at 2022-06-23 00:01:15.033162
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    HPUXNetwork.module = MockModule()
    hn = HPUXNetwork()
    hn.get_interfaces_info()
    assert HPUXNetwork.module.run_command.call_count == 2
    assert HPUXNetwork.module.run_command.call_args_list[0][0][0] == '/usr/bin/netstat -niw'
    assert HPUXNetwork.module.run_command.call_args_list[1][0][0] == '/usr/bin/netstat -nr'
    assert HPUXNetwork.module.run_command.call_args_list[1][0][0] == '/usr/bin/netstat -nr'


from ansible.module_utils.basic import *



# Generated at 2022-06-23 00:01:24.915433
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ModuleStub():
        @staticmethod
        def get_bin_path(arg, opt_dirs=[]):
            return "/usr/bin/netstat"

        @staticmethod
        def run_command(cmd, check_rc=True, close_fds=False, executable=None, data=None, binary_data=False):
            return 0, "default  10.180.4.60 UGSc        1      127 lan0", ""

    module = ModuleStub()
    ha = HPUXNetwork(module)
    default_interfaces_facts = ha.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '10.180.4.60'


# Generated at 2022-06-23 00:01:26.870906
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = NetworkCollector(dict())
    assert isinstance(module, HPUXNetworkCollector)

# Generated at 2022-06-23 00:01:35.329935
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = Network()
    test_module.run_command = test_module.run_command_mock

# Generated at 2022-06-23 00:01:37.603222
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    huxnet = HPUXNetwork(None)
    interfaces = huxnet.get_interfaces_info()
    assert 'lan0' in interfaces

# Generated at 2022-06-23 00:01:48.038273
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = Ansible()

    def run_command(cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return (0, 'default 10.0.2.2 UGS 0 22 en0\n', None)

    netstat_path = module.get_bin_path('netstat')

    setattr(module, 'run_command', run_command)

    network = HPUXNetwork()

    network_facts = network.populate()
    assert network_facts['interfaces'] == ['en0']

# Generated at 2022-06-23 00:01:55.007306
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=('', 'default 172.16.1.1 UGS lan0', ''))
    network = HPUXNetwork(module)

    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_gateway'] == "172.16.1.1"
    assert default_interfaces['default_interface'] == "lan0"


# Generated at 2022-06-23 00:01:55.945092
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert (HPUXNetwork().populate())

# Generated at 2022-06-23 00:02:00.330131
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Test class constructor for HPUXNetwork
    """
    hpux_network = HPUXNetwork(module=None)
    assert hpux_network.interfaces.keys() is not None
    assert hpux_network.default_interface is not None
    assert hpux_network.default_gateway is not None

# Generated at 2022-06-23 00:02:11.880284
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    mod = AnsibleModule(argument_spec=dict())
    ran_command = False

    def run_command(module, command):
        nonlocal ran_command
        ran_command = True
        return 0, "default default_network default_gateway default_interface\n", ""

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = run_command
    default_interfaces = HPUXNetwork().get_default_interfaces()
    assert ran_command is True
    assert "default_interface" in default_interfaces
    assert "default_gateway" in default_interfaces
    assert default_interfaces["default_interface"] == "default_interface"
    assert default_interfaces["default_gateway"] == "default_gateway"

# Unit

# Generated at 2022-06-23 00:02:16.326105
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    out = "lan0      0        0        30   4096   30  4096  0 0  0 0  0 0" \
          + " 2.2.2.1"
    assert network.get_interfaces_info() == {'lan0': {'device': 'lan0',
                                                      'ipv4': {'address': '2.2.2.1'}}}

# Generated at 2022-06-23 00:02:18.725944
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    result = HPUXNetwork().get_interfaces_info()
    assert result == {'lan0': {'device': 'lan0', 'ipv4': {'network': 'lan0', 'interface': 'lan0', 'address': '192.168.1.1'}}}

# Generated at 2022-06-23 00:02:21.604314
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert isinstance(obj, HPUXNetworkCollector)
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-23 00:02:25.811571
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:02:28.107022
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    assert hpn.platform == 'HP-UX'
    assert hpn.get_interfaces_info()

# Generated at 2022-06-23 00:02:34.910018
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = mock.Mock(return_value=(0, '', ''))
    hpuxNetwork = HPUXNetwork(module)
    hpuxNetwork.get_default_interfaces = mock.Mock(return_value=dict())
    hpuxNetwork.get_interfaces_info = mock.Mock(return_value=dict())
    assert hpuxNetwork.populate() == dict()



# Generated at 2022-06-23 00:02:42.463988
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule(object):
        def get_bin_path(self, path):
            return 'netstat'

        def run_command(self, path):
            return 0, "default 129.144.33.61 UGS 0 112000 lan0\n", ''

    test_module = TestModule()

    net_obj = HPUXNetwork(test_module)
    assert net_obj.get_default_interfaces() == {'default_gateway':
                                                '129.144.33.61',
                                                'default_interface': 'lan0'}



# Generated at 2022-06-23 00:02:45.148020
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._fact_class == HPUXNetwork
    assert HPUXNetworkCollector._platform == 'HP-UX'

# Generated at 2022-06-23 00:02:52.072972
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_fact_collector = NetworkCollector()
    network = net_fact_collector.get_network_facts()
    assert len(network.default_interface) > 0
    assert len(network.interfaces) > 0
    assert network.interface_lo0  # Test that a dictionary is returned
    assert len(network.interface_lo0) > 0
    assert 'default_interface' in network.default_interface
    assert 'default_gateway' in network.default_interface

# Generated at 2022-06-23 00:02:57.689209
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    nm = HPUXNetwork(module)
    # There is no good way to unit test the populate method.  It would be
    # good to find or create a test system with a reliable known state.
    # For now, just verify that it runs without throwing an exception.
    nm.populate()

# Generated at 2022-06-23 00:03:00.614242
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork
    assert hn.default_facts is None


# Generated at 2022-06-23 00:03:03.226762
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXNetwork

# Testing the get_default_interfaces method of class HPUXNetwork

# Generated at 2022-06-23 00:03:04.111532
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:03:06.428291
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._fact_class == HPUXNetwork
    assert hpux_network_collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:03:13.613153
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    rc = 0
    out = 'default 192.168.0.1 UG  700    0  0  lan2'
    err = ''
    module = mock_module(rc, out, err)
    fact_module = HPUXNetwork(module)
    result = fact_module.get_default_interfaces()
    assert result == {'default_interface': 'lan2', 'default_gateway': '192.168.0.1'}



# Generated at 2022-06-23 00:03:18.273622
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network_fact = HPUXNetwork()

    default_interfaces_facts = network_fact.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan1'
    assert default_interfaces_facts['default_gateway'] == '172.31.223.1'

    interfaces = network_fact.get_interfaces_info()
    assert interfaces['lan1']['ipv4']['address'] == '172.31.223.64'
    assert interfaces['lan1']['ipv4']['network'] == '172.31.223.0'
    assert interfaces['lan1']['ipv4']['address'] == '172.31.223.64'

# Generated at 2022-06-23 00:03:19.697129
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()



# Generated at 2022-06-23 00:03:27.402573
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = Mock()
    module.run_command.return_value = (0,
                                       'default 192.168.201.254 UGSc    0 0 '
                                       'en0',
                                       '')
    net = HPUXNetwork(module)
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'en0',
                                  'default_gateway': '192.168.201.254'},\
           'Invalid default interfaces information'



# Generated at 2022-06-23 00:03:27.956457
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    pass

# Generated at 2022-06-23 00:03:38.214935
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    network_collector = HPUXNetworkCollector(m)
    network_collector.collect()
    facts = network_collector.get_facts()
    assert "default_interface" in facts
    assert "default_gateway" in facts
    assert "interfaces" in facts
    for iface in facts['interfaces']:
        assert iface in facts
        assert 'ipv4' in facts[iface]
        assert 'address' in facts[iface]['ipv4']



# Generated at 2022-06-23 00:03:43.393193
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = FakeModule()
    test_module.run_command = fake_run_command
    test_args = {'module': test_module}
    test_obj = HPUXNetwork(**test_args)
    test_result = test_obj.get_default_interfaces()
    assert test_result == {'default_interface': 'lan0',
                           'default_gateway': '10.40.0.1'}


# Generated at 2022-06-23 00:03:54.476839
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network import Network
    import ansible.module_utils.facts.network.hpux as hpux

    mock = hpux.HPUXNetwork()

    class Module:
        def __init__(self, value):
            self.value = value

        @staticmethod
        def run_command(command):
            if command == "/usr/bin/netstat -nr":
                return 0, "  default  19.XX.XX.XX UG       0 0        0 lan0", ""
            return 0, " ", ""

    mock.module = Module('value')

    # Case: Default interface lan0
    result = mock.get_default_interfaces()
    assert result == {'default_interface': 'lan0',
                      'default_gateway': '19.XX.XX.XX'}




# Generated at 2022-06-23 00:04:04.114995
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Standalone test that runs on a system.
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import NetworkCollector
    import ansible.module_utils.facts.network.hpux as hpux_facts

    fact = HPUXNetwork()
    fact.module = hpux_facts
    interfaces = fact.get_interfaces_info()
    interfaces['lan0'] = {'device': 'lan0',
                          'ipv4': {'address': '10.0.2.15',
                                   'network': '10.0.2.0',
                                   'interface': 'lan0'}}
    # Unit test for a specific method

# Generated at 2022-06-23 00:04:07.565461
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork(None)
    network.module = get_mock_module()
    network.get_default_interfaces()



# Generated at 2022-06-23 00:04:19.427301
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Unit test for method populate of class HPUXNetwork."""
    # create an instance of HPUXNetwork
    hpux_network = HPUXNetwork()

    # Mock function run_command
    def run_command_mock(self, command):
        return(0, "default 172.16.0.0 US          lan0", "")

    hpux_network.module.run_command = run_command_mock

    # Populate the instance.
    hpux_network.populate()

    # Check the result.
    assert hpux_network.default_interface == "lan0"
    assert hpux_network.default_gateway == "172.16.0.0"
    assert hpux_network['lan0']['ipv4']['address'] == "0.0.0.0"
    assert hp

# Generated at 2022-06-23 00:04:28.091026
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    m = dict(ansible_facts={})
    interfaces = HPUXNetwork(m).get_interfaces_info()
    assert 'lan0' in interfaces.keys()
    assert interfaces['lan0']['ipv4']['address'] == '10.0.0.1'
    assert interfaces['lan0']['ipv4']['network'] == '10.0.0.0'
    assert 'lan1' in interfaces.keys()
    assert interfaces['lan1']['ipv4']['address'] == '10.0.1.1'
    assert interfaces['lan1']['ipv4']['network'] == '10.0.1.0'

# Generated at 2022-06-23 00:04:28.973031
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:04:31.491514
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Test constructor of class HPUXNetworkCollector
    """
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector.platform == "HP-UX"

# Generated at 2022-06-23 00:04:37.628974
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = get_module()
    my_hpux_network = HPUXNetwork(module)
    my_hpux_network.get_default_interfaces = MagicMock(return_value={'default_interface': 'lan0', 'default_gateway': '172.30.2.1'})
    assert my_hpux_network.default_interface == 'lan0'
    assert my_hpux_network.default_gateway == '172.30.2.1'


# Generated at 2022-06-23 00:04:44.704305
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_object = HPUXNetwork(dict())

    expected_result = {'lan0': {'device': 'lan0',
                                'ipv4': {'address': '10.17.66.193',
                                         'interface': 'lan0',
                                         'network': '10.17.66.192'}}}
    current_result = test_object.get_interfaces_info()
    assert expected_result == current_result

# Generated at 2022-06-23 00:04:50.385601
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
    )

    obj = HPUXNetwork()
    obj.module = module
    obj.get_default_interfaces()

    out = obj.get_default_interfaces()

    assert out
    assert out['default_interface']
    assert out['default_gateway']


# Generated at 2022-06-23 00:05:01.419622
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(sys.modules[__name__].__file__)))
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork(dict(module=None, params={}))
    interfaces = network.get_interfaces_info()

# Generated at 2022-06-23 00:05:02.099228
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network_obj = HPUXNetwork()



# Generated at 2022-06-23 00:05:05.198881
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()
    network_facts_from_populate = net.populate()
    network_facts_from_constructor = net.get_facts()

    assert network_facts_from_populate == network_facts_from_constructor



# Generated at 2022-06-23 00:05:06.336875
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    m = HPUXNetwork()
    assert m.platform == 'HP-UX'

# Generated at 2022-06-23 00:05:08.128176
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_class = HPUXNetworkCollector._fact_class
    assert fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 00:05:19.387425
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = Network(_ansible_module=module)
    collected_facts = {
        'default_interface': 'lan0'
    }

    collected_facts = network_facts.populate(collected_facts=collected_facts)

    assert 'ansible_eth0' not in collected_facts
    assert 'ansible_eth1' not in collected_facts
    assert 'ansible_eth2' not in collected_facts
    assert 'ansible_eth3' not in collected_facts
    assert 'ansible_eth4' not in collected_facts
    assert 'ansible_eth5' not in collected_facts
    assert 'ansible_eth6' not in collected_facts
    assert 'ansible_eth7' not in collected_facts

# Generated at 2022-06-23 00:05:31.310047
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts["default_interface"] == "lan1"
    assert network_facts["default_gateway"] == "172.31.4.1"
    interfaces = network_facts['interfaces']
    assert len(interfaces) == 1
    assert interfaces[0] == "lan0"
    iface = network_facts['lan0']
    assert iface["device"] == "lan0"
    ipv4 = iface["ipv4"]
    assert ipv4["address"] == "172.31.2.67"
    assert ipv4["network"] == "172.31.2.0"
    assert ipv4["interface"] == "lan0"


#
# Unit test helper classes and

# Generated at 2022-06-23 00:05:38.393027
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_HPUXNetwork = HPUXNetwork()
    test_HPUXNetwork.module.run_command = my_run_command
    default_interfaces_facts = test_HPUXNetwork.get_default_interfaces()
    assert len(default_interfaces_facts) == 2
    assert default_interfaces_facts['default_interface'] == 'lan11'
    assert default_interfaces_facts['default_gateway'] == '12.0.0.1'


# Generated at 2022-06-23 00:05:40.842700
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hl = HPUXNetwork()
    interfaces = hl.get_interfaces_info()
    print(interfaces)
    

# Generated at 2022-06-23 00:05:47.595763
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network_info_mock = {
        'default_interface': 'lan1',
        'default_gateway': '192.0.2.254'
    }
    module = AnsibleModuleMock('get_default_interfaces')
    obj = HPUXNetwork(module)
    network_iface_info = obj.get_default_interfaces()
    assert network_iface_info == network_info_mock


# Generated at 2022-06-23 00:05:53.772043
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    unit test for constructor of class HPUXNetworkCollector
    """
    # call HPUXNetworkCollector
    hpx_nc = HPUXNetworkCollector()
    # check type
    assert isinstance(hpx_nc, object)
    assert isinstance(hpx_nc, NetworkCollector)
    # check attributes
    assert hpx_nc._fact_class is HPUXNetwork
    assert hpx_nc._platform == 'HP-UX'

# Generated at 2022-06-23 00:06:00.969406
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fact_class = HPUXNetwork()

# Generated at 2022-06-23 00:06:05.399952
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """This function is to test the constructor of class HPUXNetworkCollector."""
    hpx_net = HPUXNetworkCollector()
    assert hpx_net._platform == 'HP-UX'
    assert hpx_net._fact_class == HPUXNetwork
