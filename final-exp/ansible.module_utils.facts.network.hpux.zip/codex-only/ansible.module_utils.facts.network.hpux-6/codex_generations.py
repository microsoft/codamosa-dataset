

# Generated at 2022-06-22 23:56:15.465988
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpuxnetwork = HPUXNetwork()
    rc, out, err = hpuxnetwork.module.run_command("/usr/bin/netstat -niw")
    interfaces = hpuxnetwork.get_interfaces_info(out)
    assert int(interfaces['lan0']['ipv4']['network'])
    assert int(interfaces['lan0']['ipv4']['address'])
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'
    assert int(interfaces['lan1']['ipv4']['network'])
    assert int(interfaces['lan1']['ipv4']['address'])
    assert interfaces['lan1']['ipv4']['interface'] == 'lan1'


# Generated at 2022-06-22 23:56:27.205334
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={}
    )
    net = HPUXNetwork(module=module)

    module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    module.run_command = MagicMock(return_value=(0, ', '.join(['default: flags=128<NOARP>']), ''))
    assert net.get_default_interfaces() == {'default_gateway': 'default', 'default_interface': '<NOARP>'}


# Generated at 2022-06-22 23:56:36.343397
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    netstat_output = '''
default 149.43.99.9 UG 0 0 0 lan23
149.43.0.0        link#1 U          0 876 lan23
149.43.0.0        link#1 UHS        0   0 lo0
127.0.0.1         link#2 UH          0   0 lo0
'''
    net.module = MagicMock()
    net.module.run_command = MagicMock(return_value=(0, netstat_output, ''))
    assert net.get_default_interfaces() == \
        {'default_interface': 'lan23', 'default_gateway': '149.43.99.9'}

# Generated at 2022-06-22 23:56:39.290497
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts.network.hpx import HPUXNetwork
    facts = HPUXNetwork()
    assert isinstance(facts, HPUXNetwork)

# Generated at 2022-06-22 23:56:43.320557
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_collector = HPUXNetworkCollector()
    assert isinstance(fact_collector, HPUXNetworkCollector)
    assert fact_collector._platform == 'HP-UX'
    assert fact_collector._fact_class == HPUXNetwork


# Generated at 2022-06-22 23:56:53.791098
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()
    network_facts = HPUXNetwork(module)

    # Unit test for method get_default_interfaces of class HPUXNetwork
    def test_get_default_interfaces():
        module = FakeAnsibleModule()
        network_facts = HPUXNetwork(module)
        expected_interface = {'default_interface': 'lan0',
                              'default_gateway': '192.0.2.1'}
        assert network_facts.get_default_interfaces() == expected_interface

    # Unit test for method get_interfaces_info of class HPUXNetwork
    def test_get_interfaces_info():
        module = FakeAnsibleModule()
        network_facts = HPUXNetwork(module)

# Generated at 2022-06-22 23:56:55.869388
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    n = HPUXNetwork()
    assert n.platform == 'HP-UX'


# Generated at 2022-06-22 23:57:05.829639
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    collector = module.get_bin_path('netstat')
    network_facts = HPUXNetwork(module).populate()

    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts

    # Testing interface_<name> facts
    if collector is None:
        assert network_facts['interfaces'] == []
    else:
        for iface in network_facts['interfaces']:
            assert iface in network_facts
            assert 'device' in network_facts[iface]
            assert 'ipv4' in network_facts[iface]
            assert 'network' in network_facts[iface]['ipv4']

# Generated at 2022-06-22 23:57:08.869687
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    NetworkCollector._init_test_class_HPUXNetworkCollector()



# Generated at 2022-06-22 23:57:10.341793
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj is not None


# Generated at 2022-06-22 23:57:13.562179
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """HPUXNetwork - constructor unit test stubs"""
    # Implement me
    #raise NotImplementedError()

if __name__ == '__main__':
    test_HPUXNetwork()

# Generated at 2022-06-22 23:57:23.182158
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork.get_interfaces_info()

# Generated at 2022-06-22 23:57:24.616888
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert(HPUXNetworkCollector._platform == 'HP-UX')

# Generated at 2022-06-22 23:57:29.823157
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hostname = 'localhost'
    interfaces = HPUXNetwork(module=None, params=None).get_interfaces_info().keys()
    network = HPUXNetwork(module=None, params=None)
    assert network.platform == 'HP-UX'
    assert network.hostname == hostname
    assert network.interfaces == interfaces

# Generated at 2022-06-22 23:57:31.739057
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts.network.hp_ux import HPUXNetwork
    interface = HPUXNetwork(None)
    assert hasattr(interface, 'platform'), \
        "Missing member: platform"
    assert interface.platform == 'HP-UX', \
        "Member: platform has unexpected value"

# Generated at 2022-06-22 23:57:42.967126
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = AnsibleModule(argument_spec={})
    os_obj = HPUXNetwork()
    interfaces = ['ip.tun0', 'lan0', 'lo0.32763', 'lo0', 'ip.tun70']
    default_interfaces = {'default_interface': 'lan0',
                          'default_gateway': '10.10.21.1'}

# Generated at 2022-06-22 23:57:55.710799
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test of method populate of class HPUXNetwork
    """
    HPUXNetwork_object = HPUXNetwork()
    result = HPUXNetwork_object.populate()
    assert isinstance(result, dict), "Facts not returned as dictionary"

# Generated at 2022-06-22 23:57:58.145527
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector.network_class == HPUXNetwork
    assert HPUXNetworkCollector.platform == 'HP-UX'


# Generated at 2022-06-22 23:58:03.781994
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'
    assert net.get_default_interfaces() != {}
    assert 'default_interface' in net.get_default_interfaces()
    assert 'default_gateway' in net.get_default_interfaces()
    assert net.get_interfaces_info() != {}


# Generated at 2022-06-22 23:58:09.377459
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpux = HPUXNetwork()

    interfaces = hpux.get_interfaces_info()

    assert(type(interfaces) is dict)
    assert('lan0' in interfaces.keys())
    assert('device' in interfaces['lan0'].keys())

# Generated at 2022-06-22 23:58:11.482719
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_networkcollector = HPUXNetworkCollector()
    assert len(hpux_networkcollector.collect()) > 0

# Generated at 2022-06-22 23:58:19.239393
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, 'default 10.2.2.2 UG lan0', '')
    network = HPUXNetwork(module)
    result = network.get_default_interfaces()
    assert 'default_interface' in result
    assert result['default_interface'] == 'lan0'
    assert 'default_gateway' in result
    assert result['default_gateway'] == '10.2.2.2'



# Generated at 2022-06-22 23:58:20.319605
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'

# Generated at 2022-06-22 23:58:31.150727
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork.
    """
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-22 23:58:37.934215
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    mk_arg = Mock()
    mk_arg.run_command.return_value = (0,
                                       'default  10.10.10.1        UG     0      0 lan0\n'
                                       '10.10.10.0        10.10.0.0        U       0 0 lan0\n',
                                       '')

    net_obj = HPUXNetwork(module)
    net_obj.populate()
    ret = net_obj.gather_facts()
    assert ret['default_interface'] == 'lan0'
    assert ret['default_gateway'] == '10.10.10.1'



# Generated at 2022-06-22 23:58:39.988646
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.__class__ == HPUXNetworkCollector
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-22 23:58:50.516571
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    import sys

    # This block is to patch print function and redirect to a StringIO object
    # to be able to use this string in a unit test.
    # Without it, the result of print will be showed in stdout and the test
    # will fail.
    stdout = sys.stdout
    sys.stdout = stringio = StringIO()
    print = stringio.write
    builtins.print = print

    # Here the text to test

# Generated at 2022-06-22 23:58:58.440259
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    sample_output = """ lan0: flags=863<UP,BROADCAST,NOTRAILERS,RUNNING,MULTICAST> mtu 1500 address: 00.16.cb.f8.bf.d1
                inet bcast:131.180.223.255 netmask:ff.ff.ff.0
                inet6 fe80::216:cbff:fef8:bfd1%lan0 prefixlen 64 scopeid 0x2
                inet6 2001:4898:1e:1010:216:cbff:fef8:bfd1 prefixlen 64
                zone global
        """
    class TestHPUXNetwork:

        def run_command(self, cmd):
            return (0, sample_output, '')

    test_net = TestHPUXNetwork()

# Generated at 2022-06-22 23:59:02.618099
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    generated_facts = HPUXNetwork().get_default_interfaces()
    generated_facts = generated_facts['default_interface']
    expected_facts = 'lan4'
    assert generated_facts == expected_facts

# Generated at 2022-06-22 23:59:13.281393
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MagicMock()
    module.get_bin_path.return_value = '/usr/bin/netstat'
    module.run_command.return_value = (0, '', '')
    module.exit_json.return_value = {"changed": False, "ansible_facts": {}}
    module.run_command.side_effect = [
        (0, "netstat: cannot get kstat chain", ""),
        (0, "netstat: cannot get kstat chain", ""),
        (0, "netstat: cannot get kstat chain", ""),
        (0, "netstat: cannot get kstat chain", "")]

    network = HPUXNetwork(module)

    result = network.get_default_interfaces()
    assert result == {}

    result = network.get_interfaces_info()


# Generated at 2022-06-22 23:59:18.183709
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h = HPUXNetwork(dict())
    interfaces_info = h.get_interfaces_info()
    assert interfaces_info['lan0'] == {'device': 'lan0',
                                       'ipv4': {'address': '172.16.0.134',
                                                'network': '172.16.0.0',
                                                'interface': 'lan0'}}
    assert 'lo0' in interfaces_info


# Generated at 2022-06-22 23:59:24.701427
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    mock_module = MockModule({})
    mock_module = MockModule({'netstat': 'netstat'})
    mock_module.run_command = Mock(return_value=(0, 'lan0 lo0', ''))
    net = HPUXNetwork(mock_module)
    assert net.get_interfaces_info() == {'lan0': {'device': 'lan0'}}



# Generated at 2022-06-22 23:59:29.096733
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Unit Test for constructor of class HPUXNetwork
    """
    import collections
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    network_facts = HPUXNetwork()
    assert isinstance(network_facts.get_interfaces_info(), collections.OrderedDict)

# Generated at 2022-06-22 23:59:38.719087
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class ModuleStub(object):
        def __init__(self):
            self.run_command_called = False
            self.rc = 0

# Generated at 2022-06-22 23:59:49.388442
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule(object):
        def __init__(self):
            self.run_command_called = False

        def get_bin_path(self, _):
            return None

        def run_command(self, _):
            self.run_command_called = True
            return 0, '''
netstat -rn
Routing tables
Destination          Gateway            Flags Refs Use Interface
default              10.0.0.1           UG        7 31  lan0
10.0.0.0             10.0.0.207         U         7 30  lan0
127.0.0.0            localhost          UH        0 24  lo0
localhost            localhost          UH        0 24  lo0
''', ''

    sys = TestModule()
    hpuxNetwork = HPUXNetwork()
    hpuxNetwork.module

# Generated at 2022-06-22 23:59:52.402629
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h = HPUXNetwork()
    expected_default_interface = {'default_interface': 'lan0',
                                  'default_gateway': '10.0.0.1'}
    assert expected_default_interface == h.get_default_interfaces()


# Generated at 2022-06-23 00:00:03.823428
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Test when netstat binary is not present
    result = HPUXNetwork(dict(module=dict(run_command=lambda *_, **__: (
        1, '', 'FAILED')))).populate()
    assert result == {}, 'Expected empty result'

    # Test when default gateway and default interface cannot be determined.
    # Expectations:
    # - interfaces is a list of interface names.
    # - interface_<name> dictionary of ipv4 address information.
    module = dict(run_command=lambda *_, **__: (0,
                                                'lan0 link#1 UP 437033640 bytes\n'
                                                'lan0 192.168.1.1', ''))
    net = HPUXNetwork(dict(module=module))
    result = net.populate()
    assert result

# Generated at 2022-06-23 00:00:15.671959
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux.collector import HPUXNetwork
    class HPUXNetworkTest:
        def __init__(self):
            self.check_mode = True
            self.path = {'generic': ['', '/bin', '/usr/bin']}
            self.module_deprecated_warnings = []

        def get_bin_path(self, executable, _prefer_uncast=False):
            return executable

        def run_command(self, cmd):
            return 0, 'default 192.168.1.1 UGS 0     0         lan0\n', ''

    network = HPUXNetwork()
    network.module = HPUXNetworkTest()
    facts = network.populate()
    assert facts['default_interface'] == 'lan0'

# Generated at 2022-06-23 00:00:22.909320
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    fake_module = FakeModule(
        default_output=dict(
            rc=0,
            out='lan11: flags=1e080863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT>\n'
                '\tinet 192.168.126.57 netmask ffffff00 broadcast 192.168.126.255\n'
                'lan12: flags=1e080863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT>\n'
                '\tinet 192.168.127.57 netmask ffffff00 broadcast 192.168.127.255\n'
        )
    )
    hpn = H

# Generated at 2022-06-23 00:00:32.969602
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Unit test for HPUXNetwork class constructor."""
    module = AnsibleModule(argument_spec={})
    hux_network = HPUXNetwork(module)
    default_interfaces = hux_network.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0',
                                  'default_gateway': '10.10.10.254'}
    interfaces = hux_network.get_interfaces_info()
    assert interfaces == {'lan0': {'device': 'lan0',
                                   'ipv4': {'address': '10.10.10.105',
                                            'network': '10.10.10.0',
                                            'interface': 'lan0',
                                            }
                                   }
                         }

# Generated at 2022-06-23 00:00:44.113034
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    import os
    import json

    test_netstat = open(os.path.join(os.getcwd(), 'tests', 'test_netstat_niw'), 'r')
    test_lines = test_netstat.read().splitlines()
    test_netstat.close()
    h = HPUXNetwork({})
    h.module = {}
    h.module.run_command = lambda x: (0, test_lines, "")
    expected_result = {'lan1': {'device': 'lan1', 'ipv4': {'interface': 'lan1', 'network': '10.1.0.0', 'address': '10.1.2.2'}}}
    result = h.get_interfaces_info()


# Generated at 2022-06-23 00:00:53.544509
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.base import Network
    from importlib import import_module
    _collector = import_module('ansible.module_utils.facts.network.hpux.HPUXNetworkCollector')
    collector = _collector.HPUXNetworkCollector()
    assert collector.__class__.__name__ == 'HPUXNetworkCollector'
    assert collector.platform == 'HP-UX'
    assert collector._fact_class is HPUXNetwork


# Generated at 2022-06-23 00:00:55.239736
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network.platform == 'HP-UX'


# Generated at 2022-06-23 00:01:02.377189
# Unit test for constructor of class HPUXNetwork

# Generated at 2022-06-23 00:01:12.298814
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    data = {
        "default_interface": 'lo0',
        "default_gateway": '172.28.128.1',
        "interfaces": ['lo0', 'lan0'],
        "lan0": {
            "device": 'lan0',
            "ipv4": {
                "address": '172.28.129.58',
                "network": '172.28.128.0',
                "netmask": '255.255.254.0'
            }
        },
        "lo0": {
            "device": 'lo0',
            "ipv4": {
                "address": '127.0.0.1',
                "network": '127.0.0.0',
                "netmask": '255.0.0.0'
            }
        }
    }
    fact

# Generated at 2022-06-23 00:01:20.794779
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    class ModuleStub():
        def __init__(self):
            self.params = {}
            self.params['command'] = 'netstat'
            self.params['default_interface'] = ['lan0']
            self.params['device'] = ['lan0', 'lan1', 'lan2']
            self.params['network'] = ['10.0.0.0', '10.1.0.0', '10.2.0.0']
            self.params['address'] = ['10.0.0.1', '10.1.0.1', '10.2.0.1']

        def get_bin_path(self, arg):
            return self.params[arg]

        def run_command(self, arg):
            return (0, '', '')

    hpuxtestobj = moduleStub()


# Generated at 2022-06-23 00:01:21.424621
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    pass

# Generated at 2022-06-23 00:01:31.560006
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """Unit test for method get_default_interfaces of class HPUXNetwork"""

# Generated at 2022-06-23 00:01:41.412593
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod = AnsibleModule(argument_spec={})
    net = HPUXNetwork(mod)
    out = net.populate()
    assert out['default_interface'] == 'lan3'
    assert out['default_gateway'] == '10.10.10.1'
    assert out['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3']
    assert out['lan0'] == {'device': 'lan0',
                           'ipv4': {'network': '10.10.10.0',
                                    'interface': 'lan0',
                                    'address': '10.10.10.3'}}

# Generated at 2022-06-23 00:01:50.415501
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    expected_interfaces_info = {'lan0': {'device': 'lan0', 'ipv4': {'address': '192.0.2.3',
                                                                    'network': '192.0.2.0',
                                                                    'interface': 'lan0'}}}
    net_info = HPUXNetwork()

# Generated at 2022-06-23 00:02:01.667109
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:02:03.669559
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hnet = HPUXNetwork()
    assert hnet.platform == 'HP-UX'


# Generated at 2022-06-23 00:02:10.252290
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    result = network.populate()
    assert result.get('default_interface') == 'lan9000'
    assert result.get('default_gateway') == '10.254.254.254'
    assert result['interfaces'] == ['lan9000']
    assert result.get('lan9000')['ipv4']['address'] == '10.254.254.50'

# Generated at 2022-06-23 00:02:16.422330
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule({})
    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()['ansible_network_resources']
    assert ('default_interface' in network_facts)
    assert ('default_gateway' in network_facts)


from ansible.module_utils.facts import *


if __name__ == '__main__':
    # Unit test for method populate of class HPUXNetwork
    test_HPUXNetwork_populate()

# Generated at 2022-06-23 00:02:28.242629
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = object()
    setattr(module, 'get_bin_path', get_bin_path)
    setattr(module, 'run_command', run_command)
    network_facts = HPUXNetwork(module).populate()
    expected_interfaces = ['lan0', 'lan1', 'lan2', 'lan3', 'lan4', 'lan5', 'lan6', 'lan7', 'lan8', 'lan9', 'lan10', 'lan11', 'lan12', 'lan13', 'lan14', 'lan15']
    assert sorted(network_facts['interfaces']) == sorted(expected_interfaces)
    assert network_facts['lan0']['ipv4']['address'] == '10.5.5.5'
    assert network_facts['default_interface'] == 'lan9'
    assert network

# Generated at 2022-06-23 00:02:29.845840
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.populate() is not None

# Generated at 2022-06-23 00:02:35.439250
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hpux_network = HPUXNetwork(module)

    interfaces = hpux_network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan0' in interfaces['lan0']['device']



# Generated at 2022-06-23 00:02:38.172590
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(mod)
    assert network.platform == 'HP-UX'


# Generated at 2022-06-23 00:02:39.154524
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()

# Generated at 2022-06-23 00:02:48.403341
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkCollector(dict(gather_subset=['all']), None)
    network_collector = HPUXNetwork(module)
    network_facts = network_collector.populate()
    expected_results = {'default_gateway': '192.168.1.1',
                        'default_interface': 'lan0',
                        'interfaces': ['lan0'],
                        'lan0': {'device': 'lan0',
                                 'ipv4': {'address': '192.168.1.215',
                                          'interface': 'lan0',
                                          'network': '192.168.1.0'}}}
    assert network_facts == expected_results

# Generated at 2022-06-23 00:02:59.391818
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict()
    )

    h_net = HPUXNetwork()
    h_net.module = module
    h_net._interfaces = {
        'lan0': 'lan0',
        'lan1': 'lan1',
        'lan2': 'lan2'
    }
    h_net._interfaces_ipv4 = {
        'lan0': '192.168.10.2',
        'lan1': '192.168.10.3',
        'lan2': '192.168.10.4'
    }
    interfaces = h_net.get_interfaces_info()

# Generated at 2022-06-23 00:03:01.226169
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    nm = HPUXNetwork(module)

    assert nm is not None



# Generated at 2022-06-23 00:03:04.791462
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()
    data = net.populate()
    if data.has_key('default_gateway') and \
       data.has_key('default_interface') and \
       data['interfaces'][0] == 'lan0':
        assert True
    else:
        assert False

# Generated at 2022-06-23 00:03:08.568406
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list')
        },
        supports_check_mode=True)

    network = HPUXNetwork(module=module)
    network_facts = network.populate()

    # check if the fact is present in the result
    assert 'default_interface' in network_facts



# Generated at 2022-06-23 00:03:11.777807
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Constructor for HPUXNetwork
    """
    module = AnsibleModule()
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'

# Generated at 2022-06-23 00:03:23.777953
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    class HPModuleTest(object):

        def __init__(self):
            self.params = {'script_directories': ["/usr/bin"]}
            self.run_command_calls = 0
            self.run_command_success = True

        def run_command(self, args):
            cmd_out = ['lan0: flags=4d008<UP,BROADCAST,RUNNING,NOARP,MULTICAST>\n',
                       '        lan0:\n',
                       '        lo0: flags=8d008<UP,BROADCAST,RUNNING,NOARP,MULTICAST>\n',
                       '        lo0:\n',
                       '        default 192.168.0.1 UGS \n',
                       'default 192.168.0.1 UGS']

# Generated at 2022-06-23 00:03:31.373007
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module = MagicMock()
    net.module.run_command.return_value = (0, out, "")

    out = ("""Kernel IP routing table
Destination        Gateway      Flags Refs      Use If  Exp  Group
default            10.147.0.1   UG          0 104927 lan0
10.147.0.0         10.147.0.245 U          0       0 lan0
10.147.0.245       10.147.0.245 UHS         0       0 lan0
""", "", "")
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces['default_interface'] == "lan0"
    assert default_interfaces['default_gateway'] == "10.147.0.1"


#

# Generated at 2022-06-23 00:03:41.543730
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    collector.add_callback(HPUXNetworkCollector)
    ansible_facts = collector.collect(module=module)
    network_facts = ansible_facts['ansible_network_resources']
    default_interface_name = network_facts['default_interface']
    default_interface_ipv4_address = network_facts[default_interface_name]['ipv4']['address']
    assert (default_interface_name in network_facts['interfaces'])

# Generated at 2022-06-23 00:03:43.006463
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert isinstance(HPUXNetworkCollector(), HPUXNetworkCollector)


# Generated at 2022-06-23 00:03:53.992968
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test
    """
    class MockModule:
        """
        Mock class for AnsibleModule
        """
        def __init__(self):
            self.params = {}
        def fail_json(self, *args, **kwargs):
            """
            Fail json method
            """
            raise Exception('AnsibleModule.fail_json: %s %s' % (args, kwargs))
        def get_bin_path(self, *args, **kwargs):
            """
            get_bin_path method
            """
            return '/bin/netstat'
        def run_command(self, *args, **kwargs):
            """
            run_command method
            """
            out = "Routing tables"
            out += "\n"

# Generated at 2022-06-23 00:04:03.200921
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    network = HPUXNetwork(module=module)
    network_facts = network.populate()

    assert network_facts['default_gateway'] == '10.1.1.1'
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['interfaces'][0] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.1.14.7'
    assert network_facts['lan0']['ipv4']['network'] == '10.1.14.0'
    assert network_facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-23 00:04:15.199212
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class module:
        def run_command(self, command):
            out = """Kernel IP routing table
Destination     Gateway         Flags Refs Use If
default         net-0-0-3.net.c  UG    0    0 lan0
172.31.0.0      net-0-0-3.net.c  U     0    0 lan1
172.31.0.0      net-0-0-3.net.c  U     0    0 lan0
172.31.0.0      net-0-0-3.net.c  U     0    0 lan1"""
            return 123, out, ""
    m = module()
    net = HPUXNetwork(m)

# Generated at 2022-06-23 00:04:26.913115
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    network = HPUXNetwork()

    interfaces_info = network.get_interfaces_info()

    assert isinstance(interfaces_info, dict)
    # Assuming that there is at least one interface on the test host
    assert len(interfaces_info) > 0

    # Check the structure of a valid interface entry
    interface_entry = interfaces_info.get(interface_entry.keys()[0])

    assert isinstance(interface_entry, dict)
    assert 'device' in interface_entry
    assert 'ipv4' in interface_entry

    interface_entry_ipv4 = interface_entry['ipv4']

    assert isinstance(interface_entry_ipv4, dict)
    assert 'address' in interface_entry_ipv4


# Generated at 2022-06-23 00:04:32.430216
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    network = HPUXNetwork(dict(module=dict()), dict())

    interfaces_info = network.get_interfaces_info()

    assert interfaces_info["lan0"] == {'device': 'lan0', 'ipv4': {'address': '9.112.173.122', 'interface': 'lan0', 'network': '9.112.173.0'}}



# Generated at 2022-06-23 00:04:36.164118
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = MockModule()
    ip = HPUXNetwork(module)
    assert ip.get_default_interfaces() == {
        'default_interface': 'lan0',
        'default_gateway': '172.22.17.254'
    }



# Generated at 2022-06-23 00:04:36.988227
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork(None)
    return net

# Generated at 2022-06-23 00:04:47.964967
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockAnsibleModule()
    module.run_command.side_effect = fake_run_command
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert interfaces == {'lan0': {'ipv4': {'network': '255.255.255.224',
                                            'interface': 'lan0',
                                            'address': '127.0.0.1'},
                                  'device': 'lan0'},
                          'lan1': {'ipv4': {'network': '255.255.255.255',
                                            'interface': 'lan1',
                                            'address': '0.0.0.0'},
                                  'device': 'lan1'}}


# Generated at 2022-06-23 00:04:51.217531
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = DummyAnsibleModule()
    netobj = HPUXNetwork(module)
    netobj.populate()
    assert isinstance(netobj.interfaces, dict)
    assert "lo" in netobj.interfaces


# Generated at 2022-06-23 00:04:55.763148
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    module = basic.AnsibleModule(
        argument_spec={
        }
    )

    network_collector = collector.get_network_collector(module)
    network_facts = network_collector.get_network_facts()
    hpux_network = HPUXNetwork()
    hpux_network.populate(network_facts)

    default_interfaces = hpux_network.get_default_interfaces()

    assert 'default_interface' in default_interfaces.keys()
    assert 'default_gateway' in default_interfaces.keys()



# Generated at 2022-06-23 00:05:05.273608
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu_network_collector = HPUXNetworkCollector()
    hpu_network_facts = hpu_network_collector.collect()
    assert(type(hpu_network_facts) is dict)
    assert('interfaces' in hpu_network_facts)
    assert(type(hpu_network_facts['interfaces']) is list)
    assert('lan0' in hpu_network_facts)
    assert(type(hpu_network_facts['lan0']) is dict)
    assert('ipv4' in hpu_network_facts['lan0'])
    assert(type(hpu_network_facts['lan0']['ipv4']) is dict)
    assert('address' in hpu_network_facts['lan0']['ipv4'])

# Generated at 2022-06-23 00:05:10.108698
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hn = HPUXNetwork()
    hn.get_default_interfaces = lambda: {'default_interface': 'lan0',
                                         'default_gateway': '1.2.3.4'}
    assert hn.get_default_interfaces() == {'default_interface': 'lan0',
                                           'default_gateway': '1.2.3.4'}

# Generated at 2022-06-23 00:05:22.075008
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpux_network = HPUXNetwork()

    class AnsibleModule():
        def __init__(self):
            self.run_command = lambda x: (0, "lan0\tlan1\tlan1\tlan2", None)
        def get_bin_path(self, x):
            return ""

    class AnsibleModule2():
        def __init__(self):
            self.run_command = lambda x: (0, "lan0\tlan1\tlan1\tlan2", None)
        def get_bin_path(self, x):
            return ""
    hpux_network.module = AnsibleModule2()

    result = hpux_network.get_interfaces_info()

# Generated at 2022-06-23 00:05:24.440490
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == "HP-UX"
    assert not hn.populate()

# Generated at 2022-06-23 00:05:27.888321
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h = HPUXNetworkCollector()
    assert h.platform == 'HP-UX'
    assert h._fact_class == HPUXNetwork
    assert h._platform == 'HP-UX'
    assert h.name == 'network'

# Generated at 2022-06-23 00:05:40.138410
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())

    class FakeModuleUtils(object):
        def __init__(self):
            class FakeAnsibleModule(object):
                def __init__(self):
                    self.params = dict()

# Generated at 2022-06-23 00:05:43.401756
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._platform == 'HP-UX'
    assert hn._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:05:45.131998
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector(None)

# Generated at 2022-06-23 00:05:50.353588
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interface_info = network.get_interfaces_info()
    assert 'lan0' in interface_info
    assert interface_info['lan0']['device'] == 'lan0'
    assert interface_info['lan0']['ipv4']['address'][:7] == 'fe80::'
    assert interface_info['lan0']['ipv4']['network'] == 'link#2'

# Generated at 2022-06-23 00:05:53.316132
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._platform == 'HP-UX'
    assert hpux_network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:05:57.240139
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    This method tests the get_interfaces_info method of class HPUXNetwork
    for output consistency.
    """
    hpx = HPUXNetwork(None, dict(), False)
    (rc, out, err) = hpx.get_interfaces_info()
    assert rc == 1, 'Failed to run netstat command'

# Generated at 2022-06-23 00:06:01.433851
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockModule()
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()

    assert 'lan0' in interfaces
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '192.168.122.1'
    assert interfaces['lan0']['ipv4']['network'] == '192.168.122.0'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-23 00:06:07.535421
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hu = HPUXNetwork()
    hu.module = MockModule()
    hu.module.run_command = Mock(return_value=(0, "default              192.168.122.0      UGS         0        0        enp0s3", ""))
    assert hu.get_default_interfaces() == {'default_interface': 'enp0s3', 'default_gateway': '192.168.122.0'}
