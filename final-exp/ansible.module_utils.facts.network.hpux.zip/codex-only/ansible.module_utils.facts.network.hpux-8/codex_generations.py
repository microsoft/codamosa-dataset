

# Generated at 2022-06-22 23:56:03.162168
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    custom_class = HPUXNetworkCollector()
    assert custom_class.platform == 'HP-UX'


# Generated at 2022-06-22 23:56:14.694650
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    class TestModule:
        def __init__(self):
            self.params = {}


# Generated at 2022-06-22 23:56:18.249605
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux = HPUXNetwork()
    default_interfaces = hpux.get_default_interfaces()
    assert 'default_interface' in default_interfaces
    interfaces_info = hpux.get_interfaces_info()
    assert 'lan0' in interfaces_info

# Generated at 2022-06-22 23:56:30.307180
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    interfaces = {}
    interfaces['lan0'] = {'ipv4': {'address': '192.168.1.1',
                                   'interface': 'lan0',
                                   'network': '192.168.1.0'},
                          'device': 'lan0'}
    interfaces['lan1'] = {'ipv4': {'address': '192.168.2.1',
                                   'interface': 'lan1',
                                   'network': '192.168.2.0'},
                          'device': 'lan1'}
    HPUXNetwork_object = HPUXNetwork(interfaces)
    assert HPUXNetwork_object.interfaces == interfaces.keys()
    assert HPUXNetwork_object.default_gateway == '192.168.1.0'
    assert HPUXNetwork_object

# Generated at 2022-06-22 23:56:40.996896
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    result = HPUXNetworkCollector.collect()
    assert result['ansible_facts']['default_interface'] == 'lan0'
    assert result['ansible_facts']['default_gateway'] == '172.16.0.1'
    assert result['ansible_facts']['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3']
    assert result['ansible_facts']['lan0']['ipv4']['network'] == '172.16.0.0'
    assert result['ansible_facts']['lan0']['ipv4']['address'] == '172.16.0.11'
    assert result['ansible_facts']['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-22 23:56:43.406597
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = HPUXNetworkCollector()
    assert facts._fact_class == HPUXNetwork
    assert facts._platform == 'HP-UX'

# Generated at 2022-06-22 23:56:45.823304
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn._fact_class.platform == 'HP-UX'

# Generated at 2022-06-22 23:56:52.673440
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    example_facts = {'HP-UX': {
                     'default_interface': 'lan0',
                     'default_gateway': '192.168.1.1'
                    }
                   }
    network_instance = HPUXNetwork({}, {})
    network_instance.module = NetworkCollector(dict(), {})
    network_instance.module.run_command = lambda cmd: (0, 'NETSTAT_OUTPUT')
    assert example_facts == network_instance.populate()


# Generated at 2022-06-22 23:56:59.848908
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    test = HPUXNetwork()
    interfaces = test.get_interfaces_info()
    print(interfaces)
    assert 'lan1' in interfaces
    assert interfaces['lan1']['ipv4']['address'] == '192.168.0.1'
    assert interfaces['lan2']['ipv4']['address'] == '192.168.0.1'


# Generated at 2022-06-22 23:57:04.781252
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():

    # Constructor for class HPUXNetworkCollector
    network_collector = HPUXNetworkCollector()

    # Asserts for class HPUXNetworkCollector
    assert network_collector
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-22 23:57:15.305492
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', 'network']
    module.params['gather_timeout'] = 10
    network_info = HPUXNetwork(module)
    interfaces = network_info.get_interfaces_info()
    assert isinstance(interfaces, dict)
    assert 'lan0' in interfaces
    lan0 = interfaces['lan0']
    assert isinstance(lan0, dict)
    assert 'device' in lan0
    assert lan0['device'] == 'lan0'
    address = lan0['ipv4']['address']
    assert address and address != '127.0.0.1'

# Generated at 2022-06-22 23:57:16.457155
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    result = HPUXNetworkCollector()
    assert result._fact_class == HPUXNetwork
    assert result._platform == 'HP-UX'

# Generated at 2022-06-22 23:57:17.863207
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert (HPUXNetworkCollector._fact_class == HPUXNetwork)
    assert (HPUXNetworkCollector._platform == 'HP-UX')

# Generated at 2022-06-22 23:57:26.036909
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    class TestHPUXNetwork():
        def __init__(self):
            self.run_command_out = []
            self.run_command_out.append("""lan0      link#       1                          hardware address: b0:99:ba:8b:5e:e5
lan0      lan link#       1                          hardware address: b0:99:ba:8b:5e:e5
lan0      ok              0           0  127.0.0.1/8          127.0.0.1\0""")

        def run_command(self, command):
            return (0, self.run_command_out[0], '')

    hpux = TestHPUXNetwork()

# Generated at 2022-06-22 23:57:29.536163
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork({})
    assert hn.platform == 'HP-UX'
    assert HPUXNetwork.platform == 'HP-UX'


# Generated at 2022-06-22 23:57:33.853127
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    ch_obj = HPUXNetwork(None)
    device = "lan0"
    value = {'device': device, 'ipv4': {'address': '10.126.6.69', 'network': '10.126.0.0', 'interface': device}}
    assert value == ch_obj.interfaces[device]

# Generated at 2022-06-22 23:57:44.767852
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    hpux_network = HPUXNetwork(module)
    network_facts = hpux_network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '192.0.2.1'
    assert network_facts['interfaces'][0] == 'lan0'
    assert network_facts['interfaces'][1] == 'lan1'
    assert network_facts['interfaces'][2] == 'lan2'
    assert network_facts['interfaces'][3] == 'lan3'
    assert network_facts['lan0']['ipv4']['network'] == '192.0.2.0'

# Generated at 2022-06-22 23:57:50.320155
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    assert HPUXNetwork.get_interfaces_info() == {'lan0': {'device': 'lan0', 'ipv4': {'address': '192.168.0.3', 'network': '192.168.0.0', 'interface': 'lan0'}}}

# Generated at 2022-06-22 23:57:52.505812
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = MockModule()
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'



# Generated at 2022-06-22 23:57:56.422637
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Unit test for constructor of class HPUXNetwork
    """
    hpux_network_obj = HPUXNetwork()
    assert hpux_network_obj.platform == 'HP-UX'

# Generated at 2022-06-22 23:58:00.511100
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    HPUXNet = HPUXNetwork(module)
    default_interfaces = HPUXNet.get_default_interfaces()
    assert default_interfaces['default_interface'] != ''


# Generated at 2022-06-22 23:58:01.449657
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-22 23:58:07.672641
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    network.module.run_command = FakeRunCommand(module, 'netstat -nr')
    facts = network.get_default_interfaces()
    assert facts == {'default_interface': 'lan0',
                     'default_gateway': '10.20.30.1'}



# Generated at 2022-06-22 23:58:15.921417
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule(object):
        def run_command(self, command):
            output = 'lan0 lan0     0.0.0.0        192.168.0.1'
            return (0, output, '')

    network = HPUXNetwork(MockModule)
    interfaces = network.get_interfaces_info()

    assert interfaces == {'lan0': {'device': 'lan0',
                                   'ipv4': {'network': '0.0.0.0',
                                            'interface': 'lan0',
                                            'address': '192.168.0.1'}}}



# Generated at 2022-06-22 23:58:25.571922
# Unit test for method populate of class HPUXNetwork

# Generated at 2022-06-22 23:58:28.711258
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_facts = HPUXNetwork()
    assert network_facts.populate() is not None

# Generated at 2022-06-22 23:58:32.100980
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hppuxN1 = HPUXNetwork(None)
    assert hppuxN1.platform == 'HP-UX'

    hppuxN2 = HPUXNetwork(dict())
    assert hppuxN2.platform == 'HP-UX'



# Generated at 2022-06-22 23:58:34.218753
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-22 23:58:40.240994
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Creates a platform instance and checks if the constructor
    of HPUXNetworkCollector creates a HPUXNetwork instance as a fact_class
    object.
    """
    platform_instance = HPUXNetworkCollector()
    assert isinstance(platform_instance.fact_class, HPUXNetwork)


# Generated at 2022-06-22 23:58:41.604108
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.get_default_interfaces()

# Generated at 2022-06-22 23:58:50.213620
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    c = HPUXNetwork()

# Generated at 2022-06-22 23:58:58.242193
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # sample netstat output for reference
    '''
    % netstat -nr

    Routing tables

    Internet:
    Destination        Gateway           Flags   Refs     Use   Interface
    -------------------- -------------------- ----- ------ ---------- ---------
    default            192.168.1.1       UG        1        0 lan0
    '''

    # mock module class
    class MockModule:
        def get_bin_path(self, executable):
            return '/usr/bin/netstat'

        def run_command(self, cmd):
            return 0, '''default            192.168.1.1       UG        1        0 lan0
            ''', ''

    # mock module object
    mock_module = MockModule()

    # set up target object
    hpux_network = HPUXNetwork(mock_module)

    # call method
    out

# Generated at 2022-06-22 23:59:02.081677
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()

    if collector._fact_class != HPUXNetwork:
        raise "Collector class mismatch"

    if collector._platform != 'HP-UX':
        raise "Platform mismatch"

# Generated at 2022-06-22 23:59:07.662567
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces = {'default_interface': 'lan1',
                          'default_gateway': '172.17.50.2'}

    test = HPUXNetwork()
    test.module = get_module_mock()
    default_interfaces_facts = test.get_default_interfaces()
    assert default_interfaces == default_interfaces_facts



# Generated at 2022-06-22 23:59:15.190068
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    fake_module = FakeAnsibleModule()
    fake_module.add_cmd_outputs(
        '/usr/bin/netstat -nr',
        stdout='''default 192.168.1.1 UG
            ''',
        stderr='',
        rc=0
    )
    network = HPUXNetwork(fake_module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'UG'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-22 23:59:24.606971
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Test populate method of class HPUXNetwork"""
    from ansible.module_utils.facts.network.base import Network, NetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork, HPUXNetworkCollector

    mm = MockModule()
    nc = NetworkCollector()
    nc.module = mm
    nc._get_interfaces_info = Mock(return_value=[])
    nc._get_default_interfaces = Mock(return_value=[])
    nm = HPUXNetwork()
    nm.module = mm
    nm.populate('')
    nc._get_interfaces_info.assert_called()
    nc._get_default_interfaces.assert_called()


# Mock class to replace the class used by the unit test

# Generated at 2022-06-22 23:59:34.557729
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netstat_output = """Routing tables

Internet:
Destination        Gateway            Flags Refs Use  If
default            192.168.0.1        UG        1 345  lan0
192.168.0.0        192.168.0.2        U         4  42  lan0
"""
    # Create an empty module object
    module = type('obj', (object,), {'run_command': lambda *_: (0, netstat_output, '')})
    # Create an instance of HPUXNetwork class
    fact_class = HPUXNetwork(module)
    # Get default network interfaces
    default_interfaces = fact_class.get_default_interfaces()
    # Check default network interfaces
    assert default_interfaces['default_interface'] == 'lan0'

# Generated at 2022-06-22 23:59:37.818827
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector(None, None)

    assert isinstance(network_collector, NetworkCollector)
    assert network_collector._platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-22 23:59:43.776154
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = Network()
    hpux = HPUXNetwork(module)

    netstat_path = module.get_bin_path('netstat')
    if netstat_path is None:
        pass

    network = hpux.populate()
    assert network.get('default_interface') is not None
    assert network.get('interfaces') is not None
    assert network.get('interface') is not None

# Generated at 2022-06-22 23:59:45.558224
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork

# Generated at 2022-06-22 23:59:50.204407
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    hp_ux_nw = HPUXNetwork()
    hp_ux_nw.module = module

    # populate must return a dictionary
    network_facts = hp_ux_nw.populate()
    assert isinstance(network_facts, dict)
    assert network_facts

# Generated at 2022-06-22 23:59:56.406669
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Set up a mock module
    module = NetworkCollector()
    module.get_bin_path = lambda _: '/usr/bin/netstat'

    # Set up a mock module.run_command
    def run_command(command, check_rc=True):
        class MockRunCommandReturn:
            def __init__(self, out, err, rc):
                self.out = out
                self.err = err
                self.rc = rc
        if command == '/usr/bin/netstat -nr':
            out = 'default 10.0.0.1 UG 1 lan0'
        elif command == '/usr/bin/netstat -niw':
            out = 'lan0          link#2     10.0.0.10   24'
        else:
            out = ''

# Generated at 2022-06-23 00:00:07.978851
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    collected_facts = {'ansible_os_family': 'HP-UX'}
    hpux_network = HPUXNetwork()
    hpux_network.module = FakeAnsibleModule()
    hpux_network.link_property = "hardware"
    setattr(hpux_network.module, 'run_command', fakerun_command)
    network_facts = hpux_network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '188.1.1.2'
    assert network_facts['interfaces'] == ['lan0', 'lan6']
    assert network_facts['lan0']['ipv4']['network'] == '188.1.0.0'

# Generated at 2022-06-23 00:00:12.313121
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class AnsibleModuleMock(object):
        def __init__(self):
            self.run_command_result = 3, """
              Name  Mtu  Network  Address            Ipkts  Ierrs  Opkts  Oerrs  Coll
              lan1  1500  172.29.16.0  172.29.16.213     112     0     31     0     0
              lan0  1500  172.16.29.0  172.16.29.213     108     0     37     0     0
            """, ""
            self.run_command_called = False

        def run_command(self, args):
            self.run_command_called = True
            return self.run_command_result

    class AnsibleNetworkModuleMock(object):
        def __init__(self):
            self.params

# Generated at 2022-06-23 00:00:19.870999
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Constructor of HPUXNetwork class should return an object of
    Network class with the following mandatory attributes:
    1. default_interface
    2. default_gateway
    3. interface_<name>
    4. default_interface_ipv4
    """
    network_facts = HPUXNetwork()
    network_facts.populate()
    assert(network_facts.default_interface is not None)
    assert(network_facts.default_gateway is not None)
    assert(network_facts.interfaces[0] is not None)
    assert(network_facts.interface_ipv4(network_facts.default_interface) is not None)

# Generated at 2022-06-23 00:00:32.127083
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Test for HPUXNetwork for method populate"""
    m = AnsibleModuleMock('/usr/bin/netstat')

    m.run_command.return_value = 0, \
        """default  192.168.122.1 UGS  0  6808  lan1000
192.168.122.0  192.168.122.2   U   6  1084  lan1000
192.168.122      127.0.0.1   UH  19  7101  lo0
""", \
        ''
    h = HPUXNetwork()
    h.module = m
    facts = h.populate()
    assert facts['default_gateway'] == '192.168.122.1'
    assert facts['default_interface'] == 'lan1000'

# Generated at 2022-06-23 00:00:43.784189
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    # Test case 1: For network
    module = Network()
    module.run_command = Mock(return_value=(0, 'default 192.168.100.1 UG lan0', ''))
    network_facts = HPUXNetwork()
    default_interfaces_facts = network_facts.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.168.100.1'

    # Test case 2: For network
    module.run_command = Mock(return_value=(0, 'default ', ''))
    default_interfaces_facts = network_facts.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == ''

# Generated at 2022-06-23 00:00:52.014236
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    fact_class = HPUXNetwork()

    out_good = "default 192.168.122.1 UG 2 0 0 lan1000"
    interfaces = fact_class.get_default_interfaces()
    assert interfaces["default_interface"] == "lan1000"
    assert interfaces["default_gateway"] == "192.168.122.1"


# Generated at 2022-06-23 00:00:54.459200
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpx_net = HPUXNetwork(module)
    assert hpx_net.platform == 'HP-UX'


# Generated at 2022-06-23 00:00:58.520512
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Unit test for constructor of class HPUXNetwork.
    """
    module = AnsibleModule(argument_spec=dict())
    hpux_network_object = HPUXNetwork(module)
    assert hpux_network_object.module == module
    assert hpux_network_object.platform == 'HP-UX'



# Generated at 2022-06-23 00:01:09.356623
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(module=module)
    network.get_default_interfaces = MagicMock(return_value={'default_interface': 'lan0',
                                                             'default_gateway': '172.17.1.1'})

# Generated at 2022-06-23 00:01:13.495740
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network_facts = HPUXNetwork()
    default_interfaces = network_facts.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan3'
    assert default_interfaces['default_gateway'] == '172.27.0.1'



# Generated at 2022-06-23 00:01:22.509873
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_HPUXNetwork = HPUXNetwork()
    test_HPUXNetwork.module = DummyAnsibleModule()
    test_HPUXNetwork.module.run_command = DummyRunCommand()

# Generated at 2022-06-23 00:01:32.351962
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    source = '''default 127.0.0.1 UGSc        0     0 lo0
      10.10.10.0      10.10.10.56      UGSc        2   755 lan0
      10.10.10.0      10.10.10.56      UGc         2  2987 lan0
      10.10.10.0      10.10.10.56      Uc          2    84 lo0
       127.0.0.1       127.0.0.1       UH          0     0 lo0'''
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, source, 'stdout'))
    network = HPUXNetwork({'module': module})
    result = network.get_default_interfaces()
   

# Generated at 2022-06-23 00:01:35.454548
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-23 00:01:43.121449
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for the method HPUXNetwork.populate.
    """
    def mock_module():
        return AnsibleModuleMock()

    def mock_run_command(cmd):
        """
        Mocks the call to run_command that is used to get the output of
        the commands.
        """
        if cmd == "/usr/bin/netstat -nr":
            return (0, "default: flags=842<UP,HOST,RUNNING,MULTICAST> mtu 1500\n\
        inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255\n\
        inet4 192.168.0.1 netmask 0xffffff00 broadcast 192.168.0.255\n\
        inet6 ::1%1/128\n", '')


# Generated at 2022-06-23 00:01:46.435125
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces.keys()
    assert 'lan1' in interfaces.keys()
    assert 'lan100' not in interfaces.keys()


# Generated at 2022-06-23 00:01:50.378930
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    network_collector = HPUXNetworkCollector(module)
    assert network_collector._fact_class == HPUXNetwork and \
        network_collector._platform == 'HP-UX'


# Generated at 2022-06-23 00:01:57.862935
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    unix_default_interfaces_output = 'default 169.254.125.1 UGSc 12 12 lan1\ndefault 192.168.6.1 UGSc 0 0 lan2'
    facts = HPUXNetwork()
    interfaces = facts._get_default_interfaces(unix_default_interfaces_output)
    assert interfaces == {
        'default_interface': 'lan1',
        'default_gateway': '169.254.125.1'
    }


# Generated at 2022-06-23 00:02:08.637695
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_network = HPUXNetwork()
    # Fill in mock data for network interfaces
    interfaces = {}
    interfaces['lan0'] = {'ipv4': {'address': '10.20.30.40'}}
    interfaces['lan1'] = {'ipv4': {'address': '172.30.40.50'}}

    # Fill in mock data for m_run_command
    test_network.module.run_command = lambda args, **kwargs: (0,
                                                              'lo0              flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1',
                                                              '')
    result = test_network.get_interfaces_info()
    assert result == interfaces



# Generated at 2022-06-23 00:02:15.910618
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hp_ux import HPUXNetwork
    hpux_network_obj = HPUXNetwork(None)
    interface_info = hpux_network_obj.get_interfaces_info()

    for device in ['lan1', 'lan3', 'lan4']:
        assert device in interface_info.keys()
        assert interface_info[device]['ipv4']
        assert interface_info[device]['ipv4']['address']


if __name__ == '__main__':
    test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-23 00:02:18.095390
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    default_interfaces_facts = HPUXNetwork().get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'

# Generated at 2022-06-23 00:02:30.335310
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    interfaces_info = {
        'lan0': {
            'device': 'lan0',
            'ipv4': {
                'network': '192.168.0.0',
                'address': '192.168.0.1'
            }
        }
    }

    default_interfaces_facts = {
        'default_interface': 'lan0',
        'default_gateway': '192.168.0.254'
    }


# Generated at 2022-06-23 00:02:32.681180
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-23 00:02:35.439297
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'

# Generated at 2022-06-23 00:02:46.004630
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:02:52.123007
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux = HPUXNetwork(module)
    module.exit_json(ansible_facts={'ansible_network_resources': hpux.populate()})


# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:02:53.183597
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpxnetwork_collector = HPUXNetworkCollector()
    assert str(hpxnetwork_collector) == "<HPUXNetworkCollector " \
                                        "HP-UX>"

# Generated at 2022-06-23 00:02:59.675384
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts import FactCollector
    hpux_net = HPUXNetwork()
    facts = FactCollector().get_facts(hpux_net)
    print("facts = ", facts)
    assert facts['interfaces'] == ['lan1']
    assert facts['default_interface'] == 'lan1'
    assert facts['lan1'] == {'device': 'lan1', 'ipv4': {'address': '10.0.3.2'}}

# Generated at 2022-06-23 00:03:07.055931
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    facts = {}
    module = MockModule()
    module.get_bin_path.return_value = "/usr/bin/netstat"
    network = HPUXNetwork(module)
    network.module.run_command.return_value = (0, netstat_output, "")
    network_facts = network.populate(facts)
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['interfaces'][0] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.3'


# Generated at 2022-06-23 00:03:12.829775
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hnet = HPUXNetwork()
    interfaces = hnet.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4'] == {'network': '192.168.0.0',
                                          'interface': 'lan0',
                                          'address': '192.168.0.2'}


# Generated at 2022-06-23 00:03:16.278607
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network_facts = HPUXNetwork()
    result = network_facts.get_interfaces_info()
    print(result)

if __name__ == "__main__":
    test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-23 00:03:27.715710
# Unit test for method get_default_interfaces of class HPUXNetwork

# Generated at 2022-06-23 00:03:33.682609
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method HPUXNetwork.populate
    """
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    net_ins = HPUXNetwork()
    hpux_network_facts = net_ins.populate()

    assert hpux_network_facts['default_interface']
    assert hpux_network_facts['default_gateway']

# Generated at 2022-06-23 00:03:37.080148
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
   """ Unit test for constructor of class HPUXNetwork"""

   test_obj = HPUXNetwork(None)
   assert test_obj.platform == 'HP-UX'

# Generated at 2022-06-23 00:03:43.967460
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = None
    test_module = HPUXNetwork(test_module)
    interfaces_info = test_module.get_interfaces_info()
    assert interfaces_info['lan0']['ipv4']['address'] == '192.168.1.1'
    assert interfaces_info['lan1000']['ipv4']['address'] == '192.168.1.2'
    assert interfaces_info['lan2000']['ipv4']['address'] == '192.168.1.3'
    assert interfaces_info['lan3000']['ipv4']['address'] == '192.168.1.4'



# Generated at 2022-06-23 00:03:54.041201
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    my_HPUXNetwork = HPUXNetwork()
    expected_data = {
        'lan9':
            {'ipv4':
             {'interface': 'lan9',
              'network': '192.168.56.0',
              'address': '192.168.56.1'}
             },
        'lan0':
            {'ipv4':
             {'interface': 'lan0',
              'network': '192.168.122.0',
              'address': '192.168.122.1'}
             }
        }
    data = my_HPUXNetwork.get_interfaces_info()
    assert(len(data) == 2)
    assert(data == expected_data)

# Generated at 2022-06-23 00:04:03.527137
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    net = HPUXNetwork(None)
    interfaces = {u'lan0': {'device': u'lan0', u'ipv4': {'network': u'172.30.1.0',
                                                        'interface': u'lan0',
                                                        'address': u'172.30.1.251'}},
                  u'lan1': {'device': u'lan1', u'ipv4': {'network': u'10.17.1.0',
                                                        'interface': u'lan1',
                                                        'address': u'10.17.1.251'}}}
    assert net.get_interfaces_info() == interfaces


# Generated at 2022-06-23 00:04:15.243464
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    def MockModule_run_command(self, *args, **kwargs):
        out = "default 192.168.0.1 UG 0 0 lan1"
        return 0, out, ""
    def MockModule_get_bin_path(self, *args, **kwargs):
        return "/usr/bin/netstat"

    from ansible.module_utils.facts import collector
    import sys
    import os
    sys.modules['ansible.module_utils.facts'] = collector

    setattr(collector.HPUXNetwork, "run_command", MockModule_run_command)
    setattr(collector.HPUXNetwork, "get_bin_path", MockModule_get_bin_path)

    network_collector = HPUXNetworkCollector()
    network_collector.collect()

# Generated at 2022-06-23 00:04:26.979520
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Returns a dictionary of dictionaries of dictionaries.
    """
    # input_data is a list of strings obtained from the output of
    # netstat command.

# Generated at 2022-06-23 00:04:35.333842
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    test_network = HPUXNetwork(test_module)

# Generated at 2022-06-23 00:04:39.909261
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # GIVEN
    module = MockModule()

    # WHEN
    x = HPUXNetworkCollector(module, [])

    # THEN
    assert x._fact_class == HPUXNetwork
    assert x._platform == 'HP-UX'
    assert x.module is module


# Generated at 2022-06-23 00:04:45.653099
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_HPUXNetwork = HPUXNetwork()
    test_HPUXNetwork.module = FakeAnsibleModule()
    test_out = test_HPUXNetwork.get_default_interfaces()
    assert "default_interface" in test_out and \
        "default_gateway" in test_out



# Generated at 2022-06-23 00:04:55.937655
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
    )

    network = HPUXNetwork(module=module)

    module.run_command = MagicMock(return_value=(0, 'default 1.2.3.4 1.2.3.4', ''))

    facts = network.populate()

    assert facts['interfaces'] == ['lan0']
    assert facts['lan0'] == {'device': 'lan0',
                             'ipv4': {'address': '1.2.3.4',
                                      'network': '1.2.3.4',
                                      'interface': 'lan0'}}
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '1.2.3.4'

# Generated at 2022-06-23 00:05:05.410949
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:05:16.225961
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils import basic
    import json
    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    # Fixtures
    netstat_path = '/usr/bin/netstat'

# Generated at 2022-06-23 00:05:22.778698
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class module:
        def run_command(self, cmd):
            return 0, '/usr/bin/netstat -nr output', None
    hx_network = HPUXNetwork(module)
    default_interfaces = hx_network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.11.12.13'


# Generated at 2022-06-23 00:05:29.800550
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    device_list = ['lan0', 'lan1']
    assert len(interfaces) == len(device_list)
    for device in interfaces:
        assert device in device_list
        assert interfaces[device]['ipv4'] == {'address': '192.168.1.1'}


# Generated at 2022-06-23 00:05:31.817223
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpn = HPUXNetworkCollector()
    print(hpn.__dict__)

# Generated at 2022-06-23 00:05:43.222040
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    import platform
    print("Testing", platform.node())
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    obj = HPUXNetwork(module)
    result = obj.populate()

    # Check the results
    assert result['interfaces'] == ['lan0', 'lan1']
    assert result['lan0']['device'] == 'lan0'
    assert result['lan0']['ipv4']['address'] == '192.168.56.100'
    assert result['lan0']['ipv4']['network'] == '192.168.56.0'
    assert result['lan1']['device'] == 'lan1'

# Generated at 2022-06-23 00:05:48.564304
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {'lan0': {'ipv4': {'address': '10.07.64.60',
                                    'network': '10.07.64.0',
                                    'interface': 'lan0'}, 'device': 'lan0'}}
    if HPUXNetwork().get_interfaces_info() != interfaces:
        raise AssertionError("Wrong interfaces_info returned")



# Generated at 2022-06-23 00:05:54.395480
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Check if method populate of class HPUXNetwork
    returns a dict with default_interface and interfaces keys."""
    import ansible.module_utils.facts.network.hpux as hpux
    hpux_network = hpux.HPUXNetwork()
    assert isinstance(hpux_network.populate(), dict)
    assert 'default_interface' in hpux_network.populate().keys()
    assert 'interfaces' in hpux_network.populate().keys()



# Generated at 2022-06-23 00:05:58.485276
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interface_info = {'lan0': {'ipv4': {'address': '192.168.1.12',
                                        'interface': 'lan0',
                                        'network': '192.168.1.0'},
                               'device': 'lan0'}}
    test = HPUXNetwork()
    assert test.get_interfaces_info() == interface_info

# Generated at 2022-06-23 00:06:05.650181
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    mod = get_module()
    mod.run_command = get_run_command()
    net = HPUXNetwork(mod)

    rc, out, err = mod.run_command("/usr/bin/netstat -nr")
    ifaces = net.get_default_interfaces()
    assert ifaces['default_interface'] == 'lan0'
    assert ifaces['default_gateway'] == '172.16.1.1'

