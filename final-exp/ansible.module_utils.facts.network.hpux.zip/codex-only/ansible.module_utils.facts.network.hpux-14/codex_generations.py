

# Generated at 2022-06-22 23:56:09.436612
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network_ins = HPUXNetwork()
    hpux_network_ins.module = module
    hpux_network_ins.populate()


if __name__ == '__main__':

    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-22 23:56:14.882974
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    facts = HPUXNetwork()
    fact_ansible_facts = facts.populate()
    assert 'default_gateway' in fact_ansible_facts
    assert 'default_interface' in fact_ansible_facts
    assert 'interfaces' in fact_ansible_facts


# Generated at 2022-06-22 23:56:18.039307
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    obj = HPUXNetwork()
    default_interfaces = obj.get_default_interfaces()
    assert 'default_interface' in default_interfaces
    assert 'default_gateway' in default_interfaces


# Generated at 2022-06-22 23:56:23.454361
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkCollector()
    hpse = HPUXNetwork()
    hpse.module = module
    hpse.populate()
    interfaces = hpse.get_interfaces_info()
    assert(interfaces)
    default_interfaces = hpse.get_default_interfaces()
    assert(default_interfaces)

# Generated at 2022-06-22 23:56:31.315495
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Test get_interfaces_info method of HPUXNetwork class.
    """

    expected_interfaces = {'lan0': {'ipv4': {'network': '172.16.0.0',
                                             'interface': 'lan0',
                                             'address': '172.16.2.167'},
                                   'device': 'lan0'}}
    test_hpux_network = HPUXNetwork()
    interfaces = test_hpux_network.get_interfaces_info()
    assert interfaces == expected_interfaces

# Generated at 2022-06-22 23:56:42.433665
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    # Create a fake module
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class FakeModule(basic.AnsibleModule):

        def __init__(self, *args, **kwargs):
            super(FakeModule, self).__init__(*args, **kwargs)

        def get_bin_path(self, arg, required=False):
            executable = "/usr/bin/" + arg
            return executable if os.path.exists(executable) else None

        def run_command(self, cmd, check_rc=True):
            """Run a command - dummy function as we just want to test"""


# Generated at 2022-06-22 23:56:44.034138
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hu_net_col = HPUXNetworkCollector(None)
    assert hu_net_col._platform == 'HP-UX'
    assert hu_net_col._fact_class == HPUXNetwork

# Generated at 2022-06-22 23:56:50.925717
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {'lan0': {'device': 'lan0', 'ipv4': {'address': '192.168.1.196', 'network': '192.168.1.0', 'interface': 'lan0'}}, 'lan1': {'device': 'lan1', 'ipv4': {'address': '192.168.2.200', 'network': '192.168.2.0', 'interface': 'lan1'}}}
    assert HPUXNetwork().get_interfaces_info() == interfaces

# Generated at 2022-06-22 23:56:54.670380
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'

# Generated at 2022-06-22 23:56:56.063350
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModuleMock()
    HPUXNetworkCollector(module)

# Generated at 2022-06-22 23:57:04.302043
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Given:
    netstat_results = "default 192.168.122.1 UGS 0 0 en0\n"

    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    input = HPUXNetwork(None)
    input.module = MockModule()
    input.module.run_command = Mock(return_value=(0, netstat_results, ""))

    # When:
    output = input.get_default_interfaces()

    # Then:
    assert output == {'default_interface': 'en0', 'default_gateway': '192.168.122.1'}



# Generated at 2022-06-22 23:57:15.874634
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network = HPUXNetwork(module)
    netstat_path = module.get_bin_path('netstat')

    if netstat_path is None:
        return

    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    default_interfaces = {}
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interfaces['default_interface'] = words[4]
                default_interfaces['default_gateway'] = words[1]
    assert network.get_default_interfaces() == default_interfaces


# Unit test

# Generated at 2022-06-22 23:57:24.806656
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(dict())
    test_network = HPUXNetwork(test_module)

    test_default_interfaces = {'default_interface': 'lan0', 'default_gateway': '172.17.0.1'}

    test_out1 = "default 172.17.0.1 UG 32 0 lan0"
    test_out2 = "net 172.17.0.0 10 U 0 0 lan0"
    test_out3 = "default 172.17.0.1 UG 32 0 lan1"
    test_out4 = "net 172.17.0.0 10 U 0 0 lan1"

    test_out = test_out1 + "\n" + test_out2 + "\n" + test_out3 + "\n" + test_out4
    test_module.run_command

# Generated at 2022-06-22 23:57:35.346325
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Init
    h = HPUXNetwork({})

    # Mock
    class MockModule(object):
        def __init__(self):
            self.params = {}
        def run_command(self, cmd):
            if cmd == '/usr/bin/netstat -niw':
                return 0, OUTPUT, ''
            raise Exception
    h.module = MockModule()

    # Run
    result = h.get_interfaces_info()

# Generated at 2022-06-22 23:57:42.163711
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list')
        ),
        supports_check_mode=True
    )
    hpux_nw = HPUXNetwork(module)
    assert hpux_nw.module == module
    assert hpux_nw.module.check_mode == True
    assert hpux_nw.module.params['gather_subset'] == ['all']

# Generated at 2022-06-22 23:57:55.116092
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    cmd = ['/usr/bin/netstat', '-nr']
    out = '''Routing tables


Internet:
Destination        Gateway            Flags    Refs  Use If
default            1024:3:3:3:0:0:0   UG        1    0   lan0
default            1024:1:2:3:0:0:0   UG        1    0   lan1
default            1024:2:1:1:0:0:0   UG        1    0   lan2

'''

# Generated at 2022-06-22 23:58:01.763203
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeModule()
    network = HPUXNetwork(module)
    interfaces_info = {}
    interfaces_info = network.get_interfaces_info()
    assert interfaces_info['lan0'] == {'device': 'lan0', 'ipv4': {'address': '10.1.2.11', 'network': '10.1.2',
                                                                  'interface': 'lan0', 'address': '10.1.2.11'}}



# Generated at 2022-06-22 23:58:12.464977
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os
    import json
    import pytest
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    module = os.path.realpath(__file__).split('/')
    module = module[:len(module) - 2]
    module.append('fixtures')
    module.append('netstat-niw.out')
    module.append('get_interfaces_info.json')
    module = '/'.join(module)

    net = HPUXNetwork()
    net.module.run_command = lambda args: (0, get_netstat_niw_output(), '')
    interfaces = net.get_interfaces_info()
    assert interfaces == get_interfaces_info_dict()



# Generated at 2022-06-22 23:58:15.667201
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector"""
    assert HPUXNetworkCollector._fact_class == HPUXNetwork
    assert HPUXNetworkCollector._platform == 'HP-UX'

# Generated at 2022-06-22 23:58:19.554685
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor test of HPUXNetworkCollector class
    """
    collector_obj = HPUXNetworkCollector()
    assert collector_obj._fact_class == HPUXNetwork



# Generated at 2022-06-22 23:58:25.535325
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()
    net.module = MockModule()
    assert net.populate() == {'default_interface': 'lan0',
                              'default_gateway': '192.168.1.1',
                              'interfaces': ['lan0'],
                              'lan0': {'device': 'lan0',
                                       'ipv4': {'address': '192.168.1.100',
                                                'interface': 'lan0',
                                                'network': '192.168.1.0'}}}


# Generated at 2022-06-22 23:58:30.159787
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    module_mock = MockModule()
    network_mock = HPUXNetwork()
    if network_mock:
        network_mock.populate()



# Generated at 2022-06-22 23:58:37.114383
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True
    )
    if not HAS_NETIFACES:
        module.fail_json(msg=missing_required_lib('netifaces'),
                         exception=NETIFACES_IMP_ERR)
    network_facts = HPUXNetwork(module)
    default_interfaces_facts = network_facts.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '1.1.1.1'


# Generated at 2022-06-22 23:58:43.471076
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    class MockModule(object):

        def __init__(self, params):
            self.params = params

    nc = HPUXNetworkCollector(MockModule({}))
    assert nc._platform == 'HP-UX'
    assert nc._fact_class == HPUXNetwork
    assert nc._options == {'gather_subset': '!all', 'gather_network_resources': ['default_gateway', 'interfaces']}

# Generated at 2022-06-22 23:58:47.390301
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    given_dict = {'default_interface': 'lan0',
                  'default_gateway': '192.168.1.1'}
    hpn = HPUXNetwork({})
    returned_dict = hpn.get_default_interfaces()
    assert returned_dict == given_dict



# Generated at 2022-06-22 23:58:56.264812
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # This is the output of `netstat -nr` command
    netstat_nr_output = (
        'Routing tables\n'
        '\n'
        'Internet:\n'
        'Destination          Gateway            Flags Refs Use  Interface\n'
        'default              192.168.17.2       UG        0   0  lan0\n'
        '127.0.0.1            127.0.0.1          UH        1   0  lo0\n'
        '127.0.0.1            127.0.0.1          UH        0   0  lo0\n'
        '192.168.17           192.168.17.2       U         0   0  lan0\n'
    )

    # This is the output of `netstat -niw` command
   

# Generated at 2022-06-22 23:58:57.816150
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXNetwork

# Generated at 2022-06-22 23:59:07.705619
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module.run_command = \
        lambda cmd, check_rc=True, close_fds=True, executable=None: \
        ([0, '', ''], ['default 10.66.11.1 UG lan0',
                       'default 10.66.11.2 UG lan1',
                       '10.66.11.0/24 link#1 U lan0',
                       '10.66.11.0/24 link#1 U lan1'])

    assert {'default_interface': 'lan0',
            'default_gateway': '10.66.11.1'} == network.get_default_interfaces()


# Generated at 2022-06-22 23:59:13.405119
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    set_module_args(dict(
        ansible_facts=dict(default_interface='lan0', default_gateway='10.0.0.1')
    ))
    net = HPUXNetwork(module)
    assert net.get_default_interfaces() == dict(default_interface='lan0', default_gateway='10.0.0.1')


# Generated at 2022-06-22 23:59:15.784284
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-22 23:59:18.460746
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork()

    interfaces = network_facts.populate()
    assert 'interfaces' in interfaces
    for interface in interfaces['interfaces']:
        assert interface in interfaces

# Generated at 2022-06-22 23:59:29.701594
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network = HPUXNetwork()
    network.module = AnsibleModule(argument_spec={})
    network.module.run_command = Mock(return_value=(0, '', ''))

    # Default interfaces
    netstat_content = '''default        192.168.1.1     UG      0        0   lan0
10.0.0.0  255.255.0.0  192.168.1.10    U   0        0   lan0
'''
    network.module.run_command = Mock(return_value=(0, netstat_content, ''))
    assert network.populate() == {'default_interface': 'lan0',
                                  'default_gateway': '192.168.1.1'}

    # Interfaces information

# Generated at 2022-06-22 23:59:39.225946
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list')))
    network = HPUXNetwork(module=module)

    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                expected_default_interface = words[4]
                expected_default_gateway = words[1]

    interfaces = {}
    rc, out, err = module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    for line in lines:
        words = line.split()

# Generated at 2022-06-22 23:59:42.264610
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Create object of Network class and check if the object is not None.
    """
    obj = network.HPUXNetwork()
    assert obj is not None


# Generated at 2022-06-22 23:59:51.984833
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})

    class HPUXFactCollector(object):
        def __init__(self, module):
            self.module = module

        def get_default_interfaces(self):
            return {
                'default_interface': 'x'
            }

        def get_interfaces_info(self):
            return {
                'y': {
                    'ipv4': {
                        'address': '192.168.1.1'
                    }
                }
            }

    network_collector = HPUXNetworkCollector(module)
    network_collector._fact_class = HPUXFactCollector
    result = network_collector.collect()


# Generated at 2022-06-22 23:59:57.525309
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    net_info = HPUXNetwork()
    default_interfaces = net_info.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.0.1'



# Generated at 2022-06-23 00:00:03.913063
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_network = HPUXNetwork()
    test_network.module = MockModule()
    test_network.module.run_command.return_value = (0,
        default_interfaces_output, "")
    out = test_network.get_default_interfaces()
    assert out == \
        {'default_gateway': '10.0.0.1', 'default_interface': 'lan1'}



# Generated at 2022-06-23 00:00:15.754437
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    output = b"Name    MTU    State    Intf Address"
    output += b"lan0    1500    UP    lan0    172.31.254.225"
    output += b"lan1    1500    UP    lan1    172.31.254.226"
    output += b"lan2    1500    UP    lan2    172.31.254.227"
    output += b"lan3    1500    UP    lan3    172.31.254.228"
    output += b"lan4    1500    UP    lan4    172.31.254.229"
    output += b"lan5    1500    UP    lan5    172.31.254.230"
    output += b"loop0    1492    DOWN    loop0    127.0.0.1"

# Generated at 2022-06-23 00:00:16.745289
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'

# Generated at 2022-06-23 00:00:27.858679
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    h = HPUXNetwork()
    h.module = mock.MagicMock()
    h.module.run_command.return_value = (0, "","")

    with open(os.path.join(os.path.dirname(__file__),
                          'fixtures/netstat_niw_hpux.txt')) as f:
        h.module.run_command.return_value = (0, f.read(),"")

    interfaces = h.get_interfaces_info()
    assert len(interfaces) == 2
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces

# Generated at 2022-06-23 00:00:29.891120
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    net = HPUXNetwork(module)
    net.populate()
    assert module.run_command.call_count == 3
    args = module.run_command.call_args_list
    command = args[0][0][0]
    assert command == '/usr/bin/netstat -nr'


# Generated at 2022-06-23 00:00:33.523700
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    import platform
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector, HPUXNetwork

    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:00:44.438819
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Initializing required variables
    facts = {}
    module = MockModule()
    net_stat = MockNetwork()

    # Testing populate method
    net_stat.populate(module, net_stat, facts)

    assert 'default_interface' in facts
    assert facts['default_interface'] == 'lan0'

    assert 'default_gateway' in facts
    assert facts['default_gateway'] == '192.168.100.1'

    assert 'interfaces' in facts
    assert 'lan0' in facts['interfaces']

    assert 'lan0' in facts
    assert 'ipv4' in facts['lan0']
    assert 'network' in facts['lan0']['ipv4']
    assert facts['lan0']['ipv4']['network'] == '192.168.100.1'

# Generated at 2022-06-23 00:00:51.518934
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = MyModule(
        dict(
            gather_subset=['!all', '!min'],
        ),
        False,
        False
    )
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'



# Generated at 2022-06-23 00:00:55.426297
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts import ansible_facts
    facts_dict = ansible_facts.HPUXFacts()
    module = facts_dict.get('module')
    network = HPUXNetwork()
    network.module = module
    network.populate()



# Generated at 2022-06-23 00:01:00.551236
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces = {}
    rc, out, err = Network.module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interfaces['default_interface'] = words[4]
                default_interfaces['default_gateway'] = words[1]

    return default_interfaces



# Generated at 2022-06-23 00:01:02.458331
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork({})
    assert h is not None



# Generated at 2022-06-23 00:01:12.287848
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_obj = HPUXNetwork()
    test_out = """lan0  192.168.50.252  255.255.255.0    U    0  0  0 lan0
                 lo0   127.0.0.1       255.0.0.0        U    0  0  0 lo0
                 ppp0  10.152.142.23   255.255.255.255  U    0  0  0 ppp0"""
    test_out = test_out.splitlines()
    test_out = [line.strip() for line in test_out]
    test_obj.module.run_command = lambda x: (0, test_out, '')
    result = test_obj.get_interfaces_info()

# Generated at 2022-06-23 00:01:13.605493
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'


# Generated at 2022-06-23 00:01:14.794800
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.get_default_interfaces() is not None



# Generated at 2022-06-23 00:01:21.816608
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Unit test for constructor of class HPUXNetwork
    """
    module = AnsibleModule(argument_spec=dict())
    hpn = HPUXNetwork(module)
    assert hpn.module == module
    assert hpn.platform == 'HP-UX'
    assert hpn.default_interfaces == {}
    assert hpn.interfaces == {}
    assert hpn._platform == 'HP-UX'
    assert hpn.facts == {}
    assert hpn.default_interface == ''
    assert hpn.default_gateway == ''



# Generated at 2022-06-23 00:01:26.641293
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Test for the get_default_interfaces method of HPUXNetwork class
    """
    h = HPUXNetwork()
    assert h.get_default_interfaces() == {'default_interface': 'lan0',
                                          'default_gateway': '10.0.0.1'}



# Generated at 2022-06-23 00:01:35.221345
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork()
    collected_facts = {'default_gateway': '192.168.1.1',
                       'default_interface': 'lan0',
                       'interfaces': ['lan0', 'lan1'],
                       'lan0': {'device': 'lan0', 'ipv4': {'address': '192.168.1.100', 'network': '192.168.1.0', 'interface': 'lan0'}},
                       'lan1': {'device': 'lan1', 'ipv4': {'address': '192.168.2.100', 'network': '192.168.2.0', 'interface': 'lan1'}}
                       }
    network_facts.populate()


# Generated at 2022-06-23 00:01:40.252235
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h = HPUXNetwork()
    h.module = Mock(return_value=None)
    h.module.run_command = Mock(return_value=(0, 'default 192.168.1.1 UGS lan0  \n', ''))

    assert h.get_default_interfaces() == {'default_interface': 'lan0',
                                          'default_gateway': '192.168.1.1'}


# Generated at 2022-06-23 00:01:49.297003
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""

    class FakeModule():

        def __init__(self, name):
            self.name = name
            self.run_command_was_called = False

        def run_command(self, command):
            self.run_command_was_called = True
            return 0, "lan0  1.2.3.4  255.255.0.0\nlan1  1.2.3.5  255.255.0.0", ""

    # test code begins

    module = FakeModule("netstat")
    HPUX_network = HPUXNetwork(module)

    # the method is the one being tested
    result = HPUX_network.get_interfaces_info()

    # assertions

    assert module.run_command_was_

# Generated at 2022-06-23 00:01:55.597759
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    '''
        Not a unit test, just a convenient-to-run test for
        the method HPUXNetwork.get_interfaces_info
    '''
    import sys
    sys.path.append('/path/to/module')
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    fact = HPUXNetwork()
    print(fact.get_interfaces_info())

# Generated at 2022-06-23 00:02:06.155492
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os

    m = HPUXNetwork()

    # The script that populates the tmp file is in ../../files/network/hpux/netstat.txt
    tmp_filename = '/tmp/ansible_test_facts_netstat_hpux'
    if os.path.isfile(tmp_filename):
        f = open(tmp_filename)
        netstat = f.read()
        f.close()
        os.remove(tmp_filename)
    else:
        netstat = "lan0   lan    10.75.160.0  8  UP  1/1/0/0/0/1  VLAN00  \n"
        netstat += "lan1   lan    10.75.160.0  8  UP  0/1/1/0/0/0  VLAN00  \n"


# Generated at 2022-06-23 00:02:13.836808
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Create the class
    network_collector = HPUXNetworkCollector()
    # Create the class
    network = network_collector._fact_class()
    network.module = MockModule()
    expected_value = {'lan1': {'device': 'lan1',
                               'ipv4': {'network': '192.168.121.0',
                                        'interface': 'lan1',
                                        'address': '192.168.121.129'}}}
    value = network.get_interfaces_info()
    assert expected_value == value


# Generated at 2022-06-23 00:02:22.237387
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network = HPUXNetwork(module)
    facts = network.populate()
    assert 'default_interface' in facts
    assert 'default_gateway' in facts
    assert 'interfaces' in facts
    assert facts['default_interface'] in facts['interfaces']
    assert 'ipv4' in facts[facts['default_interface']]
    assert 'address' in facts[facts['default_interface']]['ipv4']
    assert 'network' in facts[facts['default_interface']]['ipv4']

# Generated at 2022-06-23 00:02:24.027861
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux = HPUXNetwork()
    assert hpux.platform == 'HP-UX'


# Generated at 2022-06-23 00:02:26.399864
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mt = HPUXNetwork()
    assert mt.platform == 'HP-UX'


# Generated at 2022-06-23 00:02:29.268829
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    obj = HPUXNetwork()
    assert obj.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '10.0.0.1'}

# Generated at 2022-06-23 00:02:31.438729
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """unit test for HPUXNetwork class"""
    module = MockModule()
    net_obj = HPUXNetwork()
    net_obj.populate()

# Generated at 2022-06-23 00:02:32.721262
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModuleMock()
    obj = HPUXNetwork(module)
    assert obj._platform == "HP-UX"


# Generated at 2022-06-23 00:02:34.553744
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-23 00:02:36.846740
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj_HPUXNetwork = HPUXNetwork()
    assert obj_HPUXNetwork.platform == 'HP-UX'


# Generated at 2022-06-23 00:02:37.802348
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:02:40.046419
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = os.path.join(os.path.dirname(__file__),
                          'hpux_netstat_niw.py')
    rc, out, err = module_utils.run_command(module)
    interfaces = json.loads(out)

    interfaces_info = HPUXNetwork._get_interfaces_info()

    assert interfaces_info == interfaces

# Generated at 2022-06-23 00:02:49.764236
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    net = HPUXNetwork(module)
    output = net.populate()
    assert output['default_interface'] == 'lan0'
    assert output['default_gateway'] == '10.0.2.2'
    assert output['interfaces'] == ['lan0']
    assert output['lan0']['device'] == 'lan0'
    assert output['lan0']['ipv4']['address'] == '10.0.2.15'
    assert output['lan0']['ipv4']['network'] == '10.0.2.0'
    assert output['lan0']['ipv4']['interface'] == 'lan0'



# Generated at 2022-06-23 00:02:54.505712
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.hpux.hpux_network import HPUXNetworkCollector
    network = HPUXNetworkCollector()
    assert network._platform == 'HP-UX'
    assert network._fact_class.__name__ == 'HPUXNetwork'

# Generated at 2022-06-23 00:02:55.958550
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'

# Generated at 2022-06-23 00:03:05.097107
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.common import FactsBaseNetwork
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.base import Network, NetworkCollector


# Generated at 2022-06-23 00:03:13.717835
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule
    from ..hpux_network import HPUXNetwork

    module = AnsibleModule(
        argument_spec={},
    )

    hpux_network = HPUXNetwork(module)
    default_interfaces_facts = hpux_network.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.0.2.1'


# Generated at 2022-06-23 00:03:16.982339
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    myinterface = HPUXNetwork()
    myinterface.module = FakeAnsibleModule()
    assert myinterface.populate() == {'default_interface': 'lan0',
                                      'default_gateway': '10.10.10.1',
                                      'interfaces': ['lan0'],
                                      'lan0': {'device': 'lan0',
                                               'ipv4': {'address': '10.10.10.10',
                                                        'interface': 'lan0',
                                                        'network': '10.10.10.0'}}}



# Generated at 2022-06-23 00:03:25.686115
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork(None).get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['address'] == '10.23.22.7'
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['network'] == '10.23.22.0'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-23 00:03:26.924928
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-23 00:03:33.778365
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeModule()
    net = HPUXNetwork(module)
    interfaces = net.get_interfaces_info()

    assert interfaces is not None
    assert 'lan0' in interfaces
    assert 'lan0' in interfaces['lan0']['device']
    assert '192.168.2.24' in interfaces['lan0']['ipv4']['address']
    assert '192.168.2.0' in interfaces['lan0']['ipv4']['network']


# Generated at 2022-06-23 00:03:35.601465
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:03:36.610218
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork.platform == 'HP-UX'

# Generated at 2022-06-23 00:03:37.897909
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    result = HPUXNetwork.get_interfaces_info()
    assert result is not None

# Generated at 2022-06-23 00:03:46.854752
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpx = HPUXNetwork()
    # input data

# Generated at 2022-06-23 00:03:58.597275
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    class ModuleStub(object):

        def run_command(self):
            return (0, 'lan0 Link encap:Ethernet  HWaddr 00:02:55:3c:e8:50\n'
                       '      inet addr:10.203.222.23  Bcast:10.203.223.255'
                       '  Mask:255.255.254.0\n'
                       '      inet6 addr: fe80::202:55ff:fe3c:e850/64 Scope:Link\n',
                       '')

    class AnsibleModuleStub(object):

        def __init__(self):
            self.params = {}
            self.run_command = ModuleStub.run_command

    module = Ansible

# Generated at 2022-06-23 00:03:59.837329
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-23 00:04:01.401237
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-23 00:04:03.200471
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Constructor of Network should set the:
    - platform attribute
    """
    assert HPUXNetwork.platform == 'HP-UX'

# Generated at 2022-06-23 00:04:11.394963
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hp_ux import HPUXNetwork
    interface_info = HPUXNetwork()
    interface_info.module = MockModule()
    interfaces = interface_info.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0', 'ipv4': {'network': '10.10.10.0', 'interface': 'lan0', 'address': '10.10.10.10'}}



# Generated at 2022-06-23 00:04:23.155424
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:04:27.434874
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Checks if _platform is assign to HPUXNetworkCollector.
    collector1 = HPUXNetworkCollector()
    assert collector1._platform == 'HP-UX'
    # Checks if _fact_class is assign to HPUXNetworkCollector.
    collector2 = HPUXNetworkCollector()
    assert collector2._fact_class == HPUXNetwork

# Generated at 2022-06-23 00:04:30.017496
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    assert HPUXNetwork().get_default_interfaces() == {'default_interface': 'lan1000', 'default_gateway': '10.0.0.2'}


# Generated at 2022-06-23 00:04:34.476066
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    f = HPUXNetwork()
    f._module = FakeModule()
    f._module.run_command = run_command

    if f.get_default_interfaces():
        assert f.get_default_interfaces()['default_interface'] == 'en1'
        assert f.get_default_interfaces()['default_gateway'] == '10.10.0.1'
    else:
        assert False



# Generated at 2022-06-23 00:04:45.759157
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:04:56.900496
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import FallbackModuleUtils
    import ansible.module_utils.facts.network.hpux.netstat as netstat
    from ansible.module_utils.facts.network.hpux.netstat import HPUXNetwork
    from ansible.module_utils._text import to_text

    class NetworkModule(object):
        def __init__(self):
            self.run_command_environ_update = dict()
            self.run_command_stdout = b""
            self.run_command_rc = 0
            self.run_command_stderr = b""
            self.params = dict()

        def get_bin_path(self, arg):
            return "netstat"

        def run_command(self, cmd):
            return self.run_command_rc, to_

# Generated at 2022-06-23 00:05:00.118018
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    my_net = HPUXNetworkCollector()
    assert isinstance(my_net, NetworkCollector)
    assert isinstance(my_net._fact_class, HPUXNetwork)
    assert isinstance(my_net._platform, str)

# Generated at 2022-06-23 00:05:05.091543
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h = HPUXNetwork()
    rc, out, err = h.module.run_command("echo 'default 172.19.49.1 UGSc   0 0   lan0'")
    output = out.splitlines()
    ret = h.get_default_interfaces()
    assert ret.get('default_interface') == 'lan0'
    assert ret.get('default_gateway') == '172.19.49.1'



# Generated at 2022-06-23 00:05:13.015982
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Constructor test
    """
    hu = HPUXNetwork()
    assert hu.platform == 'HP-UX'
    assert hu.default_interface is None
    assert hu.interfaces is None
    assert hu.default_gateway is None
    assert hu.macaddress is None
    assert hu.ipv4['address'] is None
    assert hu.name is None
    assert hu.type is None
    assert hu.mtu is None
    assert hu.netmask is None
    assert hu.broadcast is None



# Generated at 2022-06-23 00:05:24.393318
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})

    # The 'out' variable is defined in order to create output for get_default_interfaces method
    # The output should be in the format:
    # default	<default_gateway>	UG	lan0	<default_interface>
    # The variable 'out' contains the string that the output of the method should contain
    out = "default	10.0.0.1	UG	lan0	lan0"
    module.run_command = lambda *args, **kwargs: (0, out, '')

    network = HPUXNetwork(module)

    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'

# Generated at 2022-06-23 00:05:28.516459
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """HPUXNetwork - constructor test"""
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_facts = HPUXNetwork(module)
    result = network_facts.populate()



# Generated at 2022-06-23 00:05:34.193178
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Create an object of the class
    hpux_net = HPUXNetwork()
    # Test the get_default_interfaces method of the class
    assert hpux_net.get_default_interfaces()
    # Test the get_interfaces_info method of the class
    assert hpux_net.get_interfaces_info()

# Generated at 2022-06-23 00:05:37.709950
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    platform = 'HP-UX'

    obj = HPUXNetwork(platform)

    assert obj.platform == platform
    assert obj.get_default_interfaces() is not None
    assert obj.get_interfaces_info() is not None

# Generated at 2022-06-23 00:05:40.627137
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c._fact_class is HPUXNetwork
    assert c._platform is 'HP-UX'


# Generated at 2022-06-23 00:05:45.041663
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork

# Class HPUXNetwork

# Generated at 2022-06-23 00:05:46.970499
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector(None)
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork

# Generated at 2022-06-23 00:05:47.787256
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector(None)

# Generated at 2022-06-23 00:05:57.390603
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:05:58.528427
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    netobj = HPUXNetwork({})

    assert netobj.populate() is not None

# Generated at 2022-06-23 00:06:07.948017
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Create a test module object
    module_mock = MockAnsibleModule()
    module_mock.params = {}
    module_mock.run_command = MagicMock(return_value=(0, NETSTAT_OUTPUT, ""))

    # Create an object of class HPUXNetwork
    hpux_network = HPUXNetwork(module_mock)

    # Call method get_default_interfaces of class HPUXNetwork
    default_interfaces = hpux_network.get_default_interfaces()

    assert default_interfaces['default_interface'] == "lan0"
    assert default_interfaces['default_gateway'] == "172.16.1.1"

