

# Generated at 2022-06-22 23:56:05.993057
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network = HPUXNetwork(module)

    interfaces = network.populate()
    assert interfaces['interfaces'] == ['lan0', 'lan1']
    assert interfaces['lan0'] == {'ipv4': {'address': '10.22.33.44',
                                           'interface': 'lan0',
                                           'network': '10.22.33.0'}}
    assert interfaces['lan1'] == {'ipv4': {'address': '10.22.33.45',
                                           'interface': 'lan1',
                                           'network': '10.22.33.0'}}
    assert interfaces['default_interface'] == 'lan0'

# Generated at 2022-06-22 23:56:08.615571
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_obj = HPUXNetworkCollector()
    assert net_obj is not None


# Generated at 2022-06-22 23:56:15.563258
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    assert type(network) is HPUXNetwork
    module2 = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    network2 = HPUXNetwork(module2)
    assert type(network2) is HPUXNetwork
    interfaces = network2.get_default_interfaces()
    assert type(interfaces) is dict



# Generated at 2022-06-22 23:56:18.317134
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()
    net.module.run_command = lambda x: (0, "", "")
    net.populate()

# Generated at 2022-06-22 23:56:23.028917
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    networkCollector = HPUXNetworkCollector()
    assert networkCollector.__class__.__name__ == 'HPUXNetworkCollector'
    assert networkCollector._fact_class == HPUXNetwork
    assert networkCollector._platform == 'HP-UX'



# Generated at 2022-06-22 23:56:33.509811
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

# Generated at 2022-06-22 23:56:36.586659
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hostname = 'foo'
    network = HPUXNetwork(module, hostname)
    assert network.platform == 'HP-UX'

# Generated at 2022-06-22 23:56:41.096798
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    module.run_command = mock_run_command

    network = HPUXNetwork(module)
    network.populate()
    assert network.default_interface == 'lan0'
    assert network.default_gateway == '10.10.0.1'

# Generated at 2022-06-22 23:56:51.719538
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # create mock module
    class MockModule(object):
        def run_command(self, cmd):
            class MockRetVal(object):
                rc = None

# Generated at 2022-06-22 23:56:52.976463
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'


# Generated at 2022-06-22 23:57:03.733229
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.namespace import HPUXFactsNamespace

    module_kwargs = dict(
        command_defaults=dict(
            binary_from_command='which',
        ),
    )
    test_files = [
        '/usr/bin/netstat',
    ]
    required_files = ['/usr/bin/netstat']
    for test_file in test_files:
        HPUXFactsNamespace.create_test_file(test_file, required_files)
    test_module = HPUXFactsNamespace.create_test_module(**module_kwargs)

    hpuxtest = HPUXNetwork()
    hpuxtest.module = test_module
    interfaces = hpuxtest.get_interfaces_info()

    assert interfaces['lan0']

# Generated at 2022-06-22 23:57:15.306756
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Test the get_interfaces_info method of class HPUXNetwork
    """

    class DummyModule():
        class RunCommandResult():
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err
        def __init__(self):
            self.params = {'gather_subset': ['network']}
        def run_command(self, command):
            rc = 0

# Generated at 2022-06-22 23:57:21.043078
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
    net = HPUXNetwork(mod)
    interfaces = net.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0', 'ipv4': {'address': '172.16.9.25', 'network': '172.16.9.0', 'interface': 'lan0'}}

# Generated at 2022-06-22 23:57:27.317879
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    expected = {'default_gateway': '192.168.122.1',
                'default_interface': 'enp3s0'}
    class Module:
        def __init__(self):
            pass
        def get_bin_path(self, name):
            if name == 'netstat':
                return '/usr/bin/netstat'
            else:
                return None
        def run_command(self, cmd):
            if cmd == '/usr/bin/netstat -nr':
                return 0, 'default 192.168.122.1 UG 1 enp3s0', ''
            else:
                return None
    HPUX_network = HPUXNetwork(Module())
    assert HPUX_network.get_default_interfaces() == expected


# Generated at 2022-06-22 23:57:31.120545
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_fact_collector = HPUXNetworkCollector()
    assert isinstance(hpux_fact_collector, NetworkCollector)
    assert hpux_fact_collector._platform == 'HP-UX'
    assert hpux_fact_collector._fact_class == HPUXNetwork

# Generated at 2022-06-22 23:57:34.113000
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    my_hpux = HPUXNetworkCollector()
    assert 'HP-UX' == my_hpux._platform
    assert 'HPUXNetwork' == my_hpux._fact_class.__name__

# Generated at 2022-06-22 23:57:44.678632
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule(platform='HP-UX')
    module.run_command = run_command_mock
    fact = HPUXNetwork(module)
    result = fact.populate()
    assert isinstance(result, dict)
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.0.1'
    assert 'interfaces' in result
    assert 'lan0' in result
    assert 'lan1' in result
    assert 'lan2' in result
    assert 'lan3' in result
    assert 'lan4' in result
    assert 'lan5' in result
    assert 'lan6' in result
    assert 'lan7' in result
    assert 'lan8' in result



# Generated at 2022-06-22 23:57:56.334555
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    uname_result = {'kernel_name': 'HP-UX', 'hostname': 'localhost',
                    'kernel_release': 'B.11.31', 'kernel_version': '',
                    'os_version': 'B.11.31', 'platform': 'HP-UX',
                    'platform_version': '11.31'}
    hostname = 'test_host'
    netstat = '/usr/bin/netstat'

    module = MockModule(uname_result, hostname, netstat)
    hpux_network = HPUXNetwork(module)
    assert hpux_network.kernel_name == 'HP-UX'
    assert hpux_network.platform == 'HP-UX'



# Generated at 2022-06-22 23:58:01.817673
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork({'module': None})
    interfaces = net.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'network': '0.0.0.0',
                                           'interface': 'lan0',
                                           'address': '0.0.0.0'}}

# Generated at 2022-06-22 23:58:13.433952
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    This is a unit test of the method get_interfaces_info of the class
    HPUXNetwork. It creates a class object, invokes the method, and checks the
    returned result.
    """
    class MyModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = [0, "lan0\t16384\t0\t1\t12\t68\t0\t0\t0\t0\t0\t0\t0\t0\t0\nlan1\t16384\t0\t1\t12\t68\t0\t0\t0\t0\t0\t0\t0\t0\t0\n", None]
            self.run_command_calls = []
       

# Generated at 2022-06-22 23:58:14.723606
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h = HPUXNetwork()
    h.populate()
    return

# Generated at 2022-06-22 23:58:20.041051
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net_obj = HPUXNetwork()
    interfaces = net_obj.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0', 'ipv4': {'address': '10.0.0.1', 'interface': 'lan0', 'network': '10.0.0.0'}}


# Generated at 2022-06-22 23:58:21.061340
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == "HP-UX"


# Generated at 2022-06-22 23:58:29.632841
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """test of HPUXNetwork method get_default_interfaces"""
    default_interfaces = {}
    default_interfaces['default_interface'] = 'lan0'
    default_interfaces['default_gateway'] = '192.168.2.2'
    hpux_network = HPUXNetwork()
    hpux_network.module.run_command = run_command
    result = hpux_network.get_default_interfaces()
    collect_default_interfaces.append(result)
    assert result == default_interfaces



# Generated at 2022-06-22 23:58:37.222441
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule():
        def __init__(self):
            self.run_command_lines = []
            self.run_command_rcs = []
            self.run_command_calls = 0

        def run_command(self, args, check_rc=True):
            self.run_command_calls += 1
            self.run_command_lines.append(args)
            return (self.command_rc, self.command_out, self.command_err)

    class TestHPUXNetwork(HPUXNetwork):
        def __init__(self):
            self.module = TestModule()

    test_default_interfaces = TestHPUXNetwork()


# Generated at 2022-06-22 23:58:37.630008
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-22 23:58:38.670674
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Create an instance of HPUXNetworkCollector
    """
    HPUXNetworkCollector()

# Generated at 2022-06-22 23:58:40.314602
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nm = HPUXNetworkCollector()
    assert nm._fact_class == HPUXNetwork
    assert nm._platform == 'HP-UX'


# Generated at 2022-06-22 23:58:50.862111
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    class MockModule(object):
        def __init__(self, params=None):
            if params is None:
                params = {}
            self.params = params

        def get_bin_path(self, arg, required=False):
            return '/usr/bin/netstat'


# Generated at 2022-06-22 23:58:54.095809
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = dict()
    network = HPUXNetwork()
    network.module = module
    network.populate()
    assert 'default_interface' in network.facts
    assert 'interfaces' in network.facts

# Generated at 2022-06-22 23:58:57.076904
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector"""

    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._fact_class == HPUXNetwork
    assert hpux_network_collector._platform == 'HP-UX'

# Generated at 2022-06-22 23:59:05.639761
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    module.run_command = Mock(return_value=(0, "default 10.10.10.1 UG 0 0 lan0",
                                            ""))
    default_interfaces_facts = HPUXNetwork(module).\
        get_default_interfaces()
    assert len(default_interfaces_facts.items()) == 2
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '10.10.10.1'



# Generated at 2022-06-22 23:59:08.014312
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h = HPUXNetworkCollector()
    assert h._fact_class == HPUXNetwork
    assert h._platform == 'HP-UX'

# Generated at 2022-06-22 23:59:09.351008
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork(dict())
    assert hn

# Generated at 2022-06-22 23:59:10.682074
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector()

# Generated at 2022-06-22 23:59:17.557632
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    mock_module = MockModule()
    mock_module.run_command = Mock(side_effect=[(0, '/usr/bin/netstat -niw', '')])
    hpu_network = HPUXNetwork(mock_module)
    interfaces = hpu_network.get_interfaces_info()
    assert (interfaces['lan0'] ==
            {'device': 'lan0', 'ipv4': {'network': '192.168.0.0',
                                        'interface': 'lan0',
                                        'address': '192.168.0.2'}})



# Generated at 2022-06-22 23:59:27.262192
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux.network_utils import HPUXNetwork
    hpuxtest = HPUXNetwork()
    hpuxtest.netstat_path = 'netstat'
    hpuxtest.module = None
    interface = hpuxtest.get_interfaces_info()
    example = {'lan0': {'device': 'lan0',
                        'ipv4': {'network': '130.158.148.0',
                                 'interface': 'lan0',
                                 'address': '130.158.148.197'}}}
    assert interface == example

# Generated at 2022-06-22 23:59:34.515619
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # initialize object
    module = Mock(run_command=Mock(return_value=(0, "default 192.168.0.1 UGSc 0 2 lan5", "")))
    hpux = HPUXNetwork(module)

    default_interfaces = hpux.get_default_interfaces()

    assert 'default_interface' in default_interfaces
    assert default_interfaces['default_interface'] == "lan5"
    assert 'default_gateway' in default_interfaces
    assert default_interfaces['default_gateway'] == "192.168.0.1"


# Generated at 2022-06-22 23:59:40.973147
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = Mock()
    module.run_command = Mock()

# Generated at 2022-06-22 23:59:51.618432
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network_resource = HPUXNetwork()

# Generated at 2022-06-22 23:59:53.128205
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpu = HPUXNetworkCollector()
    assert hpu._fact_class == HPUXNetwork
    assert hpu._platform == 'HP-UX'

# Generated at 2022-06-23 00:00:04.718792
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkCollector()
    network = HPUXNetwork(module)

    network.module.run_command = mock_run_command
    network.module.get_bin_path = mock_get_bin_path

    network.populate()


# Generated at 2022-06-23 00:00:08.632654
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork().get_interfaces_info()
    assert interfaces is not None
    assert len(interfaces) > 0
    for interface in interfaces:
        assert interfaces[interface] is not None

# Generated at 2022-06-23 00:00:13.292330
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    platform = 'HP-UX'
    fact_class = HPUXNetwork
    fact_collector = HPUXNetworkCollector(platform, fact_class)
    assert fact_collector._platform == platform
    assert fact_collector._fact_class == fact_class

# Generated at 2022-06-23 00:00:22.022143
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info for class HPUXNetwork
    """
    class ModuleMock(object):
        class params(object):
            ansible_facts = {}
            ansible_facts['ansible_net_interfaces'] = ['lan1', 'lan2', 'lan3', 'lan5']

        def get_bin_path(self, executable):
            return '/usr/bin/netstat'

        def run_command(self, cmd):
            return None

    class HPUXMock(HPUXNetwork):
        def __init__(self, module):
            self.module = module

        def populate(self, collected_facts=None):
            return None

        def get_default_interfaces(self):
            return None


# Generated at 2022-06-23 00:00:33.078150
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:00:35.957353
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeModule()
    hpux_network = HPUXNetwork(module)

    assert hpux_network.module == module
    assert hpux_network.platform == 'HP-UX'



# Generated at 2022-06-23 00:00:46.324401
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collected_facts = {'default_gateway': '172.21.176.1',
                       'default_interface': 'lan1',
                       'interfaces': ['lan1', 'lan7'],
                       'lan1': {'device': 'lan1',
                                'ipv4': {'address': '172.21.176.114',
                                         'interface': 'lan1',
                                         'network': '172.21.176.0/24'},
                                'ipv6': {}},
                       'lan7': {'device': 'lan7',
                                'ipv4': {'address': '172.21.179.88',
                                         'interface': 'lan7',
                                         'network': '172.21.179.0/24'},
                                'ipv6': {}}}
    fact_subset

# Generated at 2022-06-23 00:00:49.089543
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts_collector = HPUXNetworkCollector()
    assert facts_collector.platform == 'HP-UX'
    assert issubclass(facts_collector.fact_class, Network)

# Generated at 2022-06-23 00:00:57.214097
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
                                                 'default            192.168.0.1         UG      0         0 lan1',
                                                 ''))
    net_collector = HPUXNetwork(module)
    default_interfaces = net_collector.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan1'
    assert default_interfaces['default_gateway'] == '192.168.0.1'


# Generated at 2022-06-23 00:00:59.303038
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._fact_class == HPUXNetwork
    assert hpux_network_collector._platform == 'HP-UX'


# Generated at 2022-06-23 00:01:10.361555
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network = HPUXNetwork(module)
    # Assert that the default_interface is defined and correct
    assert 'default_interface' in network.populate()
    assert 'lo0' in network.populate()['default_interface']
    # Assert that the default_gateway is defined and correct
    assert 'default_gateway' in network.populate()
    assert '127.0.0.1' in network.populate()['default_gateway']
    # Assert that the interfaces list is correct
    assert 'lan0' in network.populate()['interfaces']
    assert 'lan1' in network.populate()['interfaces']
    assert 'lan2' in network.populate()['interfaces']


# Generated at 2022-06-23 00:01:17.585133
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Create a test case to test the method get_default_interfaces of class
    HPUXNetwork.
    """
    # Test max_loops
    h = HPUXNetwork()
    out = "default 192.168.3.1 UG lan0"
    h._module.run_command.return_value = 0, out, None
    rc, out, err = h._module.run_command(
        "/usr/bin/netstat -nr")
    assert rc == 0
    assert err == None
    h.get_default_interfaces()
    assert h._facts['default_interface'] == 'lan0'
    assert h._facts['default_gateway'] == '192.168.3.1'



# Generated at 2022-06-23 00:01:19.135345
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    hn = HPUXNetwork()
    assert hn
    assert hn.platform == 'HP-UX'

# Generated at 2022-06-23 00:01:30.060703
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:01:41.045658
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:01:45.630284
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Create an instance of HPUXNetworkCollector
    """
    hpux_network_collector = HPUXNetworkCollector()
    if hpux_network_collector.platform != 'HP-UX':
        print('Expected HP-UX and got %s' % hpux_network_collector.platform)

# Collect the facts

# Generated at 2022-06-23 00:01:51.265598
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class HPUXNetwork
    """
    import re

    mock_module = Mock(run_command=Mock(return_value=(0, "default 192.168.1.1 UGSc 33 0 lan0", "")))
    # Instantiate class
    fact = HPUXNetwork(mock_module)

    result = fact.get_default_interfaces()
    assert result == {"default_interface": "lan0", "default_gateway": "192.168.1.1"}



# Generated at 2022-06-23 00:02:02.138415
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = Mock(return_value=(0, '', ''))
    network = HPUXNetwork()
    facts = network.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.2.2'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['ipv4']['address'] == '10.0.2.15'
    assert facts['lan0']['ipv4']['network'] == '10.0.2.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'



# Generated at 2022-06-23 00:02:08.216274
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    # Create object of class HPUXNetwork
    network = HPUXNetwork(module)
    # Call method populate of class HPUXNetwork
    network_facts = network.populate()
    assert 'default_interface' in network_facts
    assert 'interfaces' in network_facts
    assert 'default_gateway' in network_facts
    # Create default_interface
    default_interface = network_facts['default_interface']
    # Check that interface is in network_facts
    assert default_interface in network_facts
    # Check structure of network_facts for default_interface
    assert 'ipv4' in network_facts[default_interface]
    assert 'address' in network_facts[default_interface]['ipv4']


# Generated at 2022-06-23 00:02:17.269814
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import tempfile
    import os

    (fd, path) = tempfile.mkstemp()

# Generated at 2022-06-23 00:02:27.055437
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hn = HPUXNetwork()
    interfaces = hn.get_interfaces_info()
    assert(interfaces.keys()[0] == 'lan0')
    assert(interfaces['lan0']['device'] == 'lan0')
    assert(interfaces['lan0']['ipv4']['address'] == '147.82.245.199')
    assert(interfaces['lan0']['ipv4']['network'] == '147.82.245.0')
    assert(interfaces['lan0']['ipv4']['interface'] == 'lan0')


# Generated at 2022-06-23 00:02:37.759192
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_obj = HPUXNetwork()
    test_obj.module = AnsibleModule(argument_spec={})
    test_obj.module.run_command = run_command_mockup
    interfaces = test_obj.get_interfaces_info()
    assert interfaces['lan0'] == {'ipv4': {'network': '192.168.1.0',
                                          'address': '192.168.1.37',
                                          'interface': 'lan0'},
                                  'device': 'lan0'}
    assert interfaces['lan1'] == {'device': 'lan1'}

# Generated at 2022-06-23 00:02:42.031783
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    n = HPUXNetwork(module=module)
    ifaces = n.get_interfaces_info()
    assert ifaces is not None
    assert len(ifaces) >= 1

# Generated at 2022-06-23 00:02:50.594572
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "default  173.37.148.1   UG        0        0 lan0", ""))
    netstat = HPUXNetwork(module)
    ifnet = netstat.get_default_interfaces()
    print(ifnet)
    assert 'default_interface' in ifnet
    assert ifnet['default_interface'] == 'lan0'
    assert 'default_gateway' in ifnet
    assert ifnet['default_gateway'] == '173.37.148.1'


# Generated at 2022-06-23 00:02:52.983901
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector"""
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:03:01.403506
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, """
default 192.168.56.1 UGS 0 0 0 lan0
default 192.168.56.2 UGS 0 0 0 lan1
""", '')
    network = HPUXNetwork(module)
    default_interfaces_facts = network.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == "lan0"
    assert default_interfaces_facts['default_gateway'] == "192.168.56.1"
    assert len(default_interfaces_facts.keys()) == 2


# Generated at 2022-06-23 00:03:04.317194
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    def_interfaces = net.get_default_interfaces()
    assert def_interfaces['default_interface'] != ''
    assert def_interfaces['default_gateway'] != ''


# Generated at 2022-06-23 00:03:08.454758
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for get_interfaces_info method of class HPUXNetwork
    """
    # pylint: disable=protected-access, unused-argument
    test_result = HPUXNetwork.get_interfaces_info(None)
    assert 'lan0' in test_result
    assert test_result['lan0']['ipv4']['address'] == '192.168.1.2'


# Generated at 2022-06-23 00:03:13.277883
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()['ansible_network_resources']

    assert ('ansible_default_ipv4' in network_facts) is True
    assert ('ansible_default_ipv6' in network_facts) is False
    assert ('ansible_interfaces' in network_facts) is True
    assert ('ansible_all_ipv4_addresses' in network_facts) is True
    assert ('ansible_all_ipv6_addresses' in network_facts) is False
    assert ('ansible_all_ipv4_addresses' in network_facts) is True

# Generated at 2022-06-23 00:03:15.242871
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_network = HPUXNetwork({}, {}, {})
    assert test_network.populate() is not None

# Generated at 2022-06-23 00:03:24.331023
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    hpux_network_collector = HPUXNetworkCollector(module=module)
    hpux_network = hpux_network_collector._fact_class(module=module)
    fact_subset = hpux_network.populate()

    assert fact_subset['default_interface'] == 'lan0'
    assert fact_subset['default_gateway'] == '10.26.32.1'
    assert fact_subset['interfaces'] == ['lan0']

# create a class for handling mock objects

# Generated at 2022-06-23 00:03:28.227689
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockAnsibleModule(default_interface_out)
    h = HPUXNetwork()
    h.module = module
    assert h.get_default_interfaces() == {'default_interface' : 'lan0',
                                          'default_gateway': '10.76.0.1'}


# Generated at 2022-06-23 00:03:33.165540
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net_class = HPUXNetwork()
    default_interfaces_facts = net_class.get_default_interfaces()
    assert default_interfaces_facts is not None
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts



# Generated at 2022-06-23 00:03:42.920419
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPUXNetwork_for_test(HPUXNetwork):
        def __init__(self, module):
            self.module = module

    class FakeModule:
        def get_bin_path(self, tool):
            return '/usr/bin/netstat'

        def run_command(self, cmd):
            return 0, out, ''
    out = ("lan0      lan0   M   -  E   -              4      2 89800    -\n"
           "lan1      lan1   M   -  E   -         -          -\n"
           "lo0               M   -  -   -              1      0 89800    -")
    network = HPUXNetwork_for_test(FakeModule())
    interfaces = network.get_interfaces_info()

# Generated at 2022-06-23 00:03:44.340188
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc is not None


# Generated at 2022-06-23 00:03:53.709684
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    output = """Kernel IP routing table
Destination          Gateway            Flags Metric Ref     Use   Interface
default              10.0.0.1           UG        2      0        0 lan0"""

    module = MagicMock()
    network = HPUXNetwork(module)
    network.module.run_command.return_value = (0, output, "")

    facts = network.get_default_interfaces()

    assert 'default_interface' in facts
    assert facts['default_interface'] == 'lan0'
    assert 'default_gateway' in facts
    assert facts['default_gateway'] == '10.0.0.1'



# Generated at 2022-06-23 00:04:02.708194
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    net = HPUXNetwork()
    net.run_command = lambda x: (0, 'lan0: flags=' +
                                 ' flag1 flag2 flag3' +
                                 ' MTU: 65520' +
                                 ' IP address: 192.168.1.1', '')
    ifaces = net.get_interfaces_info()
    assert ifaces['lan0'] == {'device': 'lan0',
                              'ipv4': {'address': '192.168.1.1',
                                       'network': '192.168.1.1/32',
                                       'interface': 'lan0'}}

# Generated at 2022-06-23 00:04:13.280667
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    sample_data = (
        'Routing tables\n'
        '\n'
        'default/24         192.168.1.1                    UG        lan76\n'
        '192.168.1/24       192.168.1.151                 U         lan78\n'
    )

    module = Mock()
    module.run_command.return_value = (0, sample_data, None)
    facts = HPUXNetwork(module)

    assert facts.populate()['default_interface'] == 'lan76'
    assert facts.populate()['default_gateway'] == '192.168.1.1'



# Generated at 2022-06-23 00:04:23.522251
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'
    assert network.get_interfaces_info() == {
        'lan0': {
            'device': 'lan0',
            'ipv4': {'address': '192.168.74.84',
                     'network': '192.168.74.0',
                     'interface': 'lan0'}},
        'lan1': {
            'device': 'lan1',
            'ipv4': {'address': '10.0.0.14',
                     'network': '10.0.0.0',
                     'interface': 'lan1'}}}

# Generated at 2022-06-23 00:04:25.723942
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network.platform == 'HP-UX'
    assert network.module is not None


# Generated at 2022-06-23 00:04:34.308682
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:04:38.873951
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpuxnet = HPUXNetwork()
    interfaces = hpuxnet.get_default_interfaces()
    assert interfaces['default_interface'] == 'lan0'
    assert interfaces['default_gateway'] == '10.50.10.254'


# Generated at 2022-06-23 00:04:43.245784
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hpux_network = HPUXNetwork()
    hpux_network.module = module
    hpux_network.populate()

    assert 'default_interface' in hpux_network.facts
    assert 'default_gateway' in hpux_network.facts
    assert 'interfaces' in hpux_network.facts
    ifaces = hpux_network.facts['interfaces']

# Generated at 2022-06-23 00:04:44.800444
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork({})
    assert net is not None


# Generated at 2022-06-23 00:04:50.285667
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock(
        dict(ansible_facts={}),
        dict(
            gather_subset=[],
            filter=None
        )
    )

    hpux_network_collector = HPUXNetworkCollector(module)

    # mock the subprocess functions
    hpux_network_collector.module.get_bin_path = Mock(return_value='/bin/')

# Generated at 2022-06-23 00:04:57.950450
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    interfaces = net.get_interfaces_info()
    assert type(interfaces) is dict
    assert 'lan0' in interfaces
    assert 'lan0' in interfaces['lan0']
    assert 'ipv4' in interfaces['lan0']
    assert 'address' in interfaces['lan0']['ipv4']
    assert 'network' in interfaces['lan0']['ipv4']
    assert 'interface' in interfaces['lan0']['ipv4']


# Generated at 2022-06-23 00:04:58.950036
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network

# Generated at 2022-06-23 00:05:03.558296
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    network_collector = HPUXNetwork(module)
    interfaces = network_collector.populate()
    assert 'default_interface' in interfaces
    assert 'default_gateway' in interfaces



# Generated at 2022-06-23 00:05:05.819451
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_obj = HPUXNetworkCollector()
    assert test_obj
    assert isinstance(test_obj, NetworkCollector)
    assert test_obj.platform == 'HP-UX'


# Generated at 2022-06-23 00:05:07.342665
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector()
    assert hpux._fact_class == HPUXNetwork
    assert hpux._platform == 'HP-UX'

# Generated at 2022-06-23 00:05:09.393519
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == "HP-UX"

# Generated at 2022-06-23 00:05:13.063500
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert isinstance(collector, HPUXNetworkCollector)
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:05:16.177002
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork
    assert collector.fact_subclasses == {}

# Generated at 2022-06-23 00:05:21.381951
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Test if method populate() can create the basic network facts structure.
    """
    net = HPUXNetwork()
    facts = net.populate()

    assert facts['default_interface'] is not None
    assert facts['default_gateway'] is not None
    assert len(facts['interfaces']) > 0



# Generated at 2022-06-23 00:05:33.269998
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_unreachable = HPUXNetwork()
    net_unreachable.module = MagicMock()
    net_unreachable.module.run_command.return_value = (1, '', '')
    result = net_unreachable.populate()
    assert result == {}

    net_reachable = HPUXNetwork()
    net_reachable.module = MagicMock()

# Generated at 2022-06-23 00:05:40.668240
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fact_network = HPUXNetwork()
    hpx = {'interfaces': ['lan0'], 'lan0': {'ipv4': {'network': '172.20.183.0',
                                                   'interface': 'lan0',
                                                   'address': '172.20.183.55'},
                                           'device': 'lan0'},
           'default_interface': 'lan0', 'default_gateway': '172.20.183.1'}
    assert fact_network.populate() == hpx

# Generated at 2022-06-23 00:05:51.206136
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network = HPUXNetwork()
    network.module = FakeAnsibleModule()
    network.module.run_command.return_value = (0, "default 172.16.1.1 UGS 0 0 en0", "")
    network.module.run_command.return_value = (0, "lan1 172.16.1.1 UGS 0 0 en0", "")
    network.module.run_command.return_value = (0, "lan1 172.16.1.1 UGS 0 0 en0", "")
    network.populate()

# Generated at 2022-06-23 00:05:52.410662
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj is not None

# Generated at 2022-06-23 00:06:00.266451
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork({})
    out = \
"""lan0: flags=963<UP,BROADCAST,NOTRAILERS,RUNNING,MULTICAST,NONUD> mtu 1500 index 2
        inet 192.168.1.2 netmask ff000000
lan1: flags=963<UP,BROADCAST,NOTRAILERS,RUNNING,MULTICAST,NONUD> mtu 1500 index 6
        inet 192.168.2.2 netmask ff000000
"""

# Generated at 2022-06-23 00:06:03.118601
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpu = HPUXNetworkCollector()
    assert hpu._platform == 'HP-UX'
