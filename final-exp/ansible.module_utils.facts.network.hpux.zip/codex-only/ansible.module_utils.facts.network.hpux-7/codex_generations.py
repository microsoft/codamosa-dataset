

# Generated at 2022-06-22 23:56:12.170066
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils._text import to_text
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils.facts.collector import BaseFactCollector
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = "netstat"

# Generated at 2022-06-22 23:56:12.691625
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()


# Generated at 2022-06-22 23:56:14.269636
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hn = HPUXNetwork()
    hn.get_interfaces_info()

# Generated at 2022-06-22 23:56:17.954298
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network = HPUXNetwork(module=module)
    interfaces = network.get_interfaces_info()
    assert len(interfaces) > 0



# Generated at 2022-06-22 23:56:24.105466
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module_mock = Mock()
    setattr(module_mock, 'run_command', run_command_mock)
    network = HPUXNetwork(module_mock)
    network_facts = network.get_default_interfaces()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.1.1.1'


# Generated at 2022-06-22 23:56:30.780924
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    module.run_command().return_value = 0, "default         192.0.2.8      UGS         0          0        lan0", "test"
    hpux_network = HPUXNetwork(module)
    assert hpux_network.get_default_interfaces() == {'default_gateway': '192.0.2.8', 'default_interface': 'lan0'}


# Generated at 2022-06-22 23:56:33.584135
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    This is a unit test for constructor of class HPUXNetworkCollector
    """
    collector = HPUXNetworkCollector()
    assert collector._platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork

# Generated at 2022-06-22 23:56:39.820480
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = FakeModule()
    hpxnet = HPUXNetworkCollector(module)

    assert(hpxnet._platform == 'HP-UX')
    assert(type(hpxnet)== HPUXNetworkCollector)
    assert(hpxnet._fact_class == HPUXNetwork)
    assert(type(hpxnet._fact_class) == type)


# Generated at 2022-06-22 23:56:50.441290
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule({'file': '/etc/resolv.conf'})
    module.run_command = run_command_mock(0, '/usr/bin/netstat -nr',
                                          'default 127.0.0.1 UG 0 0 \
                                          lan11 192.168.1.1 U 0 32000 \
                                          lan10 192.168.1.1 U 0 32000')
    module.run_command = run_command_mock(0, '/usr/bin/netstat -niw',
                                          'lan11 192.168.1.0 192.168.1.1 \
                                          192.168.1.1 U 0 0 0')
    net = HPUXNetwork(module)
    facts = net.populate()

# Generated at 2022-06-22 23:57:00.960659
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpu_ux import (
        HPUXNetwork,
    )
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.base import Network

    netstat_default_gateway = """
default 192.168.0.1 UG 1 0 lan0
default 192.168.0.2 UG 1 0 lan1
default 192.168.0.3 UG 2 0 lan2
default 192.168.0.4 UG 2 0 lan3
"""

    default_gateway = {
        'default_interface': 'lan0',
        'default_gateway': '192.168.0.1'
    }

# Generated at 2022-06-22 23:57:06.833543
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    module.run_command.return_value = (0, 'default    192.168.88.1      UG        17   0          lan0', '')
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.88.1'



# Generated at 2022-06-22 23:57:15.613350
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockNetworkModule()
    obj = HPUXNetwork(module)

    expected = {'interfaces': ['lan1'], 'default_interface': 'lan1',
                'default_gateway': '10.0.0.1',
                'lan1': {'ipv4': {'network': '10.0.0.0',
                                  'interface': 'lan1',
                                  'address': '10.0.0.2'},
                         'device': 'lan1'}}
    assert obj.populate() == expected



# Generated at 2022-06-22 23:57:22.073181
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = AnsibleModule()
    m.run_command = Mock(return_value=(0, "default 192.168.122.0 UG 2 0 0 lan0", ''))
    n = HPUXNetwork()
    n.populate = Mock(return_value=True)
    n.module = m
    default_interfaces = n.get_default_interfaces()
    assert default_interfaces == {'default_gateway': '192.168.122.0', 'default_interface': 'lan0'}



# Generated at 2022-06-22 23:57:23.975307
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-22 23:57:25.614770
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    obj = HPUXNetwork()
    assert obj.get_interfaces_info()


# Generated at 2022-06-22 23:57:28.810375
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = HPUXNetworkCollector()
    assert module.__class__.__name__ == "HPUXNetworkCollector"


# Generated at 2022-06-22 23:57:30.666632
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork

# Generated at 2022-06-22 23:57:33.975446
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._fact_class == HPUXNetwork
    assert hpux_network_collector._platform == 'HP-UX'


# Generated at 2022-06-22 23:57:44.537981
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hn = HPUXNetwork()

    rc, out, err = hn.module.run_command(
        "/usr/bin/netstat -nr"
    )
    lines = out.splitlines()

    default_interfaces_facts = hn.get_default_interfaces()

    assert rc == 0, "rc is not 0"

    assert len(lines) > 0, "out is not null"
    assert len(default_interfaces_facts) > 0, "out is not null"
    assert len(default_interfaces_facts['default_gateway']) > 0, \
        "default_gateway is not null"
    assert len(default_interfaces_facts['default_interface']) > 0, \
        "default_interface is not null"



# Generated at 2022-06-22 23:57:47.815564
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collectornetwork = HPUXNetworkCollector()
    assert collectornetwork._fact_class == HPUXNetwork
    assert collectornetwork._platform == 'HP-UX'

# Generated at 2022-06-22 23:57:51.821556
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c._platform == 'HP-UX'
    assert c._fact_class == HPUXNetwork
    assert isinstance(c._fact_class, object)

# Generated at 2022-06-22 23:57:57.401393
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    net_facts = network.populate()
    assert net_facts['default_interface']
    assert 'default_gateway' in net_facts
    assert 'interfaces' in net_facts
    for iface in net_facts['interfaces']:
        assert 'ipv4' in net_facts[iface]

# Generated at 2022-06-22 23:58:08.010294
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mod_args = dict(gather_subset='!all', gather_network_resources='no')
    mock_module = create_ansible_module(argument_spec=mod_args)
    mock_module.run_command = MagicMock(return_value=(0, '', ''))
    mock_module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    HPUXNetwork = HPUXNetwork()
    network_facts = HPUXNetwork.populate(None, mock_module)
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts


# Generated at 2022-06-22 23:58:09.292402
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_obj = HPUXNetwork()
    assert network_obj


# Generated at 2022-06-22 23:58:09.857960
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-22 23:58:21.046076
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = 'ansible.module_utils.facts.network.hp_ux'
    module = mock.MagicMock()
    module.run_command.return_value = 0, "lan0      link#1     UP   192.168.1.1       255.255.255.0      \
    lan1      link#2     UP   192.168.2.1       255.255.255.0      ", ""

    hpux_network = HPUXNetwork(module)

# Generated at 2022-06-22 23:58:23.126701
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    m = HPUXNetworkCollector()
    assert isinstance(m, NetworkCollector)

# Generated at 2022-06-22 23:58:29.548272
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # hpux_facts is not instantiated by default
    hpux_facts = HPUXNetwork(module)
    assert hpux_facts._platform == 'HP-UX'

# Generated at 2022-06-22 23:58:33.185040
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = get_test_module()
    result = HPUXNetwork(module).populate()
    assert len(result['interfaces']) > 0
    assert result['default_gateway'] == '192.168.1.1'
    assert result['default_interface'] == 'lan0'


# Generated at 2022-06-22 23:58:45.088568
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    '''
    Unit test for method populate of class HPUXNetwork
    '''
    import os
    from ansible.module_utils.facts.network.hpux import HPUXNetwork, HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_populate
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_populate_outputs
    from ansible.module_utils.facts.network.hpux import test_HPUXNetwork_populate_inputs

    # Variables for test:
    # file output of command used for test
    fake_filename = os.path.join(os.path.dirname(__file__), 'test_HPUXNetwork_populate.out')
    # file input of command used for

# Generated at 2022-06-22 23:58:54.865581
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    interfaces = {'default_interface': 'lan0', 'default_gateway': '10.0.0.1'}
    out = '''default 10.0.0.1 UG lan0
10.0.0.0        127.0.0.1      U     lo0
10.0.0.0        10.0.0.1       U     lan0
10.0.0.1        127.0.0.1      U     lo0
10.0.0.1        10.0.0.1       U     lan0
127.0.0.1       127.0.0.1      U     lo0
127.0.0.1       10.0.0.1       U     lo0
255.0.0.0       10.0.0.1      UG lan0
'''
   

# Generated at 2022-06-22 23:59:00.918727
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    import os
    import textwrap
    from ansible.module_utils.basic import AnsibleModule

    def test_get_netstat_net_result():
        network = HPUXNetwork(module=AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=False
        ))

        # Suppress actual command execution

# Generated at 2022-06-22 23:59:09.303318
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Tests that the method get_default_interfaces returns expected values
    """
    test_net_inst = HPUXNetwork()
    test_out = """
default 192.168.1.1 UGS lan0
default 192.168.10.1 UGS lan1
default 192.168.20.1 UGS lan2
"""
    default_interfaces = test_net_inst.get_default_interfaces(test_out)
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'

# Generated at 2022-06-22 23:59:12.845068
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    hpux_network = HPUXNetwork(module)
    hpux_network.populate()
    assert module.exit_json.called

# Generated at 2022-06-22 23:59:20.056854
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
                                                 "lan0      UP            0 "
                                                 "127.0.0.1", ""))
    network_collector = HPUXNetworkCollector(module=module)
    interfaces_info = network_collector._fact_class.get_interfaces_info()
    assert interfaces_info == {'lan0': {'device': 'lan0',
                                        'ipv4': {'address': '127.0.0.1',
                                                 'network': '0',
                                                 'interface': 'lan0'}}}

# Generated at 2022-06-22 23:59:24.032181
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_facts = HPUXNetworkCollector().collect()
    assert network_facts['default_gateway']
    assert network_facts['default_interface']
    assert network_facts['interfaces']
    assert network_facts['lan0']

# Generated at 2022-06-22 23:59:26.363760
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    assert h
    h1 = HPUXNetwork()
    assert h1


# Generated at 2022-06-22 23:59:35.884437
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    module = unittest.mock.MagicMock()
    module.run_command.return_value = (0, "testdata", None)

    with patch('ansible.module_utils.facts.network.hpu_x.get_interfaces_info') as mock_getiface:
        mock_getiface.return_value = {'lan0': {'device': 'lan0', 'ipv4': {'address': '10.0.0.0', 'network': '10.0.0.0'}}}
        network = HPUXNetwork(module)
        network.populate()
    return network

# Generated at 2022-06-22 23:59:38.641338
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    ''' test_HPUXNetworkCollector instantiates a HPUXNetworkCollector object'''
    hux_network_collector = HPUXNetworkCollector()
    assert hux_network_collector is not None

# Generated at 2022-06-22 23:59:42.756619
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    hpn = HPUXNetwork(module)
    out = hpn.get_default_interfaces()
    assert out == {'default_interface': 'lan0',
                   'default_gateway': '192.168.0.1'}


# Generated at 2022-06-22 23:59:51.730664
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkCollector._create_mock_module()
    network_facts = HPUXNetwork(module).populate()
    assert network_facts is not None
    assert network_facts['interfaces'] == ['lan0']
    iface = 'lan0'
    assert iface in network_facts
    assert len(network_facts[iface]['ipv4']['address']) > 0
    assert len(network_facts[iface]['ipv4']['network']) > 0
    assert len(network_facts[iface]['ipv4']['interface']) > 0
    assert len(network_facts['default_interface']) > 0
    assert len(network_facts['default_gateway']) > 0



# Generated at 2022-06-22 23:59:59.569480
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpu_ux import HPUXNetwork
    """Testing HPUXNetwork.get_interfaces_info()"""
    network = HPUXNetwork()
    network.module = TestModule()

    interfaces_info = network.get_interfaces_info()
    device_list = ['lan0', 'lan1', 'lan2', 'lan3']
    interfaces_list = interfaces_info.keys()

    assert set(device_list) == set(interfaces_list)



# Generated at 2022-06-23 00:00:11.171027
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Test method get_interfaces_info of class HPUXNetwork"""
    hpx_net = HPUXNetwork()
    hpx_net.module.run_command = run_command
    hpx_net.run()
    assert hpx_net.facts['interfaces'] == ['lan0', 'lan1']
    assert hpx_net.facts['lan0']['ipv4']['address'] == '192.168.0.1'
    assert hpx_net.facts['lan0']['ipv4']['network'] == '192.168.0.0'
    assert hpx_net.facts['lan1']['ipv4']['address'] == '10.0.0.1'

# Generated at 2022-06-23 00:00:13.572829
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts_obj = HPUXNetwork(module)
    network_facts = network_facts_obj.populate()
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts

# Generated at 2022-06-23 00:00:17.731663
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    hpux_network = HPUXNetwork(module)
    default_interfaces = hpux_network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'

# Generated at 2022-06-23 00:00:19.795477
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_obj = HPUXNetworkCollector
    assert test_obj._fact_class == HPUXNetwork
    assert test_obj._platform == 'HP-UX'

# Generated at 2022-06-23 00:00:28.377603
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list')
        }
    )

    hpux_network = HPUXNetwork()
    hpux_network.module = module

    hpux_network.populate()
    default_interfaces_facts = hpux_network.get_default_interfaces()
    assert default_interfaces_facts is not None



# Generated at 2022-06-23 00:00:33.421219
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_net = HPUXNetwork()
    test_interfaces = test_net.get_default_interfaces()
    assert isinstance(test_interfaces, dict)
    assert 'default_interface' in test_interfaces.keys()
    assert 'default_gateway' in test_interfaces.keys()
    assert test_interfaces['default_interface'] == 'lan0'
    assert test_interfaces['default_gateway'] == '192.168.50.1'

# Generated at 2022-06-23 00:00:34.384521
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:00:38.207061
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeAnsibleModule()
    hpux_network = HPUXNetwork(module)
    assert hpux_network.platform == 'HP-UX'
    assert hpux_network.module == module


# Generated at 2022-06-23 00:00:40.809345
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = HPUXNetworkCollector().collect()
    # Expect at least default interface and default gateway
    assert facts['default_interface']
    assert facts['default_gateway']

# Generated at 2022-06-23 00:00:44.278458
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_object = HPUXNetwork()
    assert network_object.platform == 'HP-UX'
    assert network_object.get_default_interfaces() == {}
    assert network_object.get_interfaces_info() == {}

# Generated at 2022-06-23 00:00:46.490100
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    hp_network = HPUXNetwork(module)
    result = hp_network.get_default_interfaces()
    assert result == {}


# Generated at 2022-06-23 00:00:48.415011
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'

# Generated at 2022-06-23 00:00:51.471768
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork(dict())
    assert net.platform == 'HP-UX'


# Generated at 2022-06-23 00:00:52.443851
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector

# Generated at 2022-06-23 00:00:55.562780
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of class HPUXNetworkCollector
    """
    collector = HPUXNetworkCollector()
    assert collector
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:01:02.514453
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_facts = {
        "device_ipv4": [
            {
                "broadcast": "255.255.255.255",
                "address": "10.10.20.51",
                "netmask": "255.255.255.0",
                "network": "10.10.20.0"
            }
        ]
    }

    hpu_network = HPUXNetwork()
    hpu_network.module.exit_json = lambda x: None
    hpu_network.module.params = {}
    hpu_network.module.run_command = lambda a, b, c: (0, "command ran", "")
    hpu_network.populate()
    interface_info = hpu_network.get_interfaces_info()
    assert interface_info['lan0'] == test_facts



# Generated at 2022-06-23 00:01:12.050003
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpx_net = HPUXNetwork()
    fake_module = FakeHPModule()
    hpx_net.module = fake_module
    int_dict = hpx_net.get_interfaces_info()
    assert int_dict['lan0'] == {'ipv4': {'network': '10.10.10.0',
                                         'address': '10.10.10.10',
                                         'interface': 'lan0'},
                                'device': 'lan0'}
    assert int_dict['lan1'] == {'ipv4': {'network': '20.20.20.0',
                                         'address': '20.20.20.20',
                                         'interface': 'lan1'},
                                'device': 'lan1'}


# Generated at 2022-06-23 00:01:14.166635
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'
    assert network.interfaces == None
    assert network.default_interface == None



# Generated at 2022-06-23 00:01:20.689113
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class FakeModule:
        @staticmethod
        def run_command(cmd):
            return 0, "lan0         link#4    lan0         ETHER       LAN0        937.5.5.5   0   0   -", None
        @staticmethod
        def get_bin_path(cmd):
            return None

    class FakeCollector:
        def __init__(self):
            self.network_module = FakeModule()

    fake_collector = FakeCollector()
    hpux_network = HPUXNetwork(fake_collector)
    results = hpux_network.get_interfaces_info()
    assert 'lan0' in results
    assert results['lan0']['ipv4']['address'] == '937.5.5.5'

# Generated at 2022-06-23 00:01:23.297128
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_module = HPUXNetworkCollector()
    assert fact_module.fact_class is HPUXNetwork
    assert fact_module.platform is 'HP-UX'

# Generated at 2022-06-23 00:01:32.910550
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}
    network = HPUXNetwork()
    rc, out, err = network.module.run_command("/usr/bin/netstat -niw")

# Generated at 2022-06-23 00:01:41.670245
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    class MockModule(object):

        def __init__(self):
            pass

        def run_command(self, cmd):
            cmds = {
                '/usr/bin/netstat -niw': (0,
                                          'lan0      0              0     5         0           0 '
                                          '   0          0          up',
                                          ''),
            }
            return cmds[cmd]
    hpx_network = HPUXNetwork()
    hpx_network.module = MockModule()
    test_result = {'lan0': {'device': 'lan0',
                            'ipv4': {'interface': 'lan0',
                                     'address': '0',
                                     'network': '5'}
            }
        }
    method_result = hpx_network.get_interfaces_

# Generated at 2022-06-23 00:01:46.222026
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    obj = HPUXNetwork()
    interfaces = obj.get_interfaces_info()
    assert interfaces
    for key in interfaces:
        assert interfaces[key]
        assert interfaces[key]['ipv4']
        assert interfaces[key]['ipv4']['address']
        assert interfaces[key]['ipv4']['network']

# Generated at 2022-06-23 00:01:47.762261
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network_facts = HPUXNetwork()
    assert hpux_network_facts.platform == 'HP-UX'

# Generated at 2022-06-23 00:01:48.581677
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector.collect()

# Generated at 2022-06-23 00:01:49.071415
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-23 00:01:51.009573
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == 'HP-UX'



# Generated at 2022-06-23 00:01:53.398371
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec=dict())
    hpx_net = HPUXNetwork(module)
    result = hpx_net.populate()
    assert ('default_interface' in result and 'default_gateway' in result)



# Generated at 2022-06-23 00:02:03.436505
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Fake module object for unit test
    class DummyModule(object):
        def get_bin_path(*args, **kwargs):
            return "/usr/bin/netstat"

        def run_command(*args, **kwargs):
            data = ('destination        gateway           mask        interface "flags"   refs   use     if     exp')
            data += ('default            172.16.0.1       U           lan0           UG        0       0      -    600')
            data += ('127.0.0.1          127.0.0.1        UH          loopback       16        0       0      -    -')
            data += ('172.16.0.0         172.16.0.136     U           lan0           U         0       0      -    -')
            return 0, data, ""

    m = D

# Generated at 2022-06-23 00:02:11.827013
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    hpux_network_facts = HPUXNetwork(module)
    hpux_network_facts.populate()
    assert('default_interface' in hpux_network_facts.network.keys())
    assert('default_gateway' in hpux_network_facts.network.keys())
    assert('interfaces' in hpux_network_facts.network.keys())
    assert('lan11' in hpux_network_facts.network['interfaces'])

# Generated at 2022-06-23 00:02:19.120988
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()

# Generated at 2022-06-23 00:02:30.758953
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:02:35.656835
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = module_mock()
    n = HPUXNetwork(m)
    interfaces = n.get_default_interfaces()
    assert interfaces['default_gateway'] == '192.0.2.235'
    assert interfaces['default_interface'] == 'lan0'



# Generated at 2022-06-23 00:02:39.633460
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector(None)
    print(collector.platform)
    assert collector.platform == 'HP-UX', \
        "Constructor of class HPUXNetworkCollector failed"
    print("Constructor of class HPUXNetworkCollector successful")


# Generated at 2022-06-23 00:02:42.805486
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """This will test the instantiation of HPUXNetworkCollector"""
    testobj = HPUXNetworkCollector()
    assert testobj._fact_class == HPUXNetwork
    assert testobj._platform == 'HP-UX'

# Generated at 2022-06-23 00:02:54.951442
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Test the method populate of class HPUXNetwork.
    """
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    argument_spec = dict(
        gather_subset=dict(default=['!all', '!min'], type='list')
    )

    module = basic.AnsibleModule(argument_spec=argument_spec)
    facts_collector = collector.BaseFactsCollector(module)
    network_collector = HPUXNetworkCollector(module=module,
                                             facts=facts_collector)
    network_obj = HPUXNetwork(module)
    result = network_obj.populate()
    assert result != {}

# Generated at 2022-06-23 00:02:58.229182
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Create an instance of HPUXNetworkCollector.
    """
    collector = HPUXNetworkCollector()

    assert collector._platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork



# Generated at 2022-06-23 00:03:01.861381
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module)

    assert network is not None
    assert network.module is not None
    assert isinstance(network, HPUXNetwork)


# Generated at 2022-06-23 00:03:02.742123
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:03:06.952098
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
    argument_spec = dict(
        gather_subset=dict(default=['!all'], type='list')
    ),
    supports_check_mode=True)
    nm = HPUXNetwork(module)
    out = nm.get_interfaces_info()
    assert out is not None



# Generated at 2022-06-23 00:03:08.907921
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():

    class args:
        module = ModuleStub()

    collector = HPUXNetworkCollector(args)
    assert collector is not None
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-23 00:03:12.283118
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class AnsibleModule_get_interfaces_info:
        def __init__(self, argument):
            self.argument = argument

        def run_command(self, argument):
            return
    a = AnsibleModule_get_interfaces_info('argument')

    # If the command run successfully,
    # the method get_interfaces_info returns a dictionary

# Generated at 2022-06-23 00:03:15.064834
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork(None)
    interfaces = network.get_interfaces_info()
    assert isinstance(interfaces, dict)



# Generated at 2022-06-23 00:03:26.660587
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class Module:
        def get_bin_path(self, cmd, opts=None, required=False):
            return None

        def run_command(self, cmd):
            out = "default 0.0.0.0 1.1.1.1 UGH 1 lan0\n"
            out += "192.168.0.0 0.0.0.0 255.255.255.0 U 0 lan0\n"
            out += "192.168.1.0 1.1.1.1 255.255.255.0 U 0 lan0\n"
            out += "192.168.2.0 1.1.1.1 255.255.255.0 U 0 lan1\n"
            return 0, out, ''

    mod = Module()
    hpux_net = HPUXNetwork(mod)
    default

# Generated at 2022-06-23 00:03:37.678546
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.network.linux.test_HPUXNetwork import (
        MockModule, MockResponse)
    module = MockModule(
        dict(),  # module.params
        dict()  # module.extra_argv
    )
    netston_path = '/usr/bin/netstat'
    module.get_bin_path = Mock(return_value=netston_path)

# Generated at 2022-06-23 00:03:40.423971
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod_args = dict()
    mod_args['run_command'] = dict()
    hpux_network_obj = HPUXNetwork(mod_args)
    assert hpux_network_obj.platform == 'HP-UX'

# Generated at 2022-06-23 00:03:43.393447
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.__class__ == HPUXNetworkCollector
    assert network_collector._fact_class.__class__ == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:03:46.190041
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = None
    network = HPUXNetworkCollector(module).collect()
    print("Network for host: {0}".format(
        module.get_bin_path("netstat", True)))
    for key, val in network.items():
        print("Key: {0}   Value: {1}".format(key, val))


if __name__ == '__main__':
    test_HPUXNetworkCollector()

# Generated at 2022-06-23 00:03:57.452888
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """``get_interfaces_info`` returns a dictionary of interfaces in the
    following format:

    {"lan0": {"device": "lan0",
              "ipv4": {"network": '172.17.1.0',
                       "address": "172.17.1.8"}},
     "lan1": {"device": "lan1",
              "ipv4": {"network": "172.17.2.0",
                       "address": "172.17.2.8"}}}
    """

# Generated at 2022-06-23 00:04:05.094178
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    module_result = {
        'ansible_facts': {
            'interfaces': ['lan1'],
            'default_interface': 'lan1',
            'lan1': {
                'ipv4': {
                    'network': '10.0.0.0',
                    'interface': 'lan1',
                    'address': '10.0.0.1'
                }
            }
        }
    }
    module.run_command = run_command_mock
    hpu = HPUXNetwork()
    hpu.module = module
    result = hpu.populate()
    assert result == module_result['ansible_facts']


# Generated at 2022-06-23 00:04:16.653271
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import Network
    import ansible.module_utils.facts.network.hpux

    # Create an instance of Network
    network = Network()

    # Create an instance of HPUXNetwork
    iface = ansible.module_utils.facts.network.hpux.HPUXNetwork()

    # Test method get_interfaces_info of class HPUXNetwork
    result = iface.get_interfaces_info()
    interfaces = ['lan0', 'lan1', 'lan2', 'lan3', 'lan4', 'lan5', 'lan6']
    for iface in interfaces:
        assert iface in result
        assert 'device' in result[iface]
        assert result[iface]['device'] == iface
        assert 'ipv4' in result[iface]

# Generated at 2022-06-23 00:04:25.988619
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    out = '''default gateway    192.168.1.1     UGS   lan0
'''

    test_module = NetworkCollector()
    test_module.module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(return_value=(0, out, ''))
    network = HPUXNetwork(test_module)

    default_interfaces_facts = network.get_default_interfaces()

    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-23 00:04:30.265964
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector.__class__.__name__ == 'HPUXNetworkCollector'
    assert hpux_network_collector._platform == 'HP-UX'
    assert hpux_network_collector._fact_class == HPUXNetwork

# Generated at 2022-06-23 00:04:32.082829
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hux_network = HPUXNetwork()

    assert hux_network.platform == "HP-UX"


# Generated at 2022-06-23 00:04:35.383330
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModuleMock({})
    hpux_network = HPUXNetwork(module)

    default_interfaces = hpux_network.get_default_interfaces()

    assert default_interfaces == \
           {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}


# Generated at 2022-06-23 00:04:46.147270
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import ansible.module_utils.facts.network.hpux as hpux_network
    test_module = get_test_module()
    hpux_network.get_networkmodule(test_module)
    hpux_network.HPUXNetwork.module = test_module
    test_object = hpux_network.HPUXNetwork()
    network_info = test_object.get_interfaces_info()
    assert network_info['lan0'] == \
        {'device': 'lan0',
         'ipv4':
            {'network': '192.168.1.0',
             'interface': 'lan0',
             'address': '192.168.1.1'
             }
         }



# Generated at 2022-06-23 00:04:50.988102
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Test with no arguments
    h = HPUXNetwork()
    assert h.platform == 'HP-UX'
    assert h._platform == 'HP-UX'

    # Test with arguments
    h = HPUXNetwork(module=dict(params='lan0'))
    assert h.platform == 'HP-UX'
    assert h._platform == 'HP-UX'

# Generated at 2022-06-23 00:04:52.899486
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h = HPUXNetworkCollector()
    assert h._fact_class == HPUXNetwork

# Generated at 2022-06-23 00:04:54.580282
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net1 = HPUXNetwork(None)



# Generated at 2022-06-23 00:04:56.750541
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    assert len(HPUXNetwork().get_interfaces_info()) == 1

# Generated at 2022-06-23 00:04:59.255354
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    result = HPUXNetworkCollector()
    assert result._fact_class == HPUXNetwork
    assert result._platform == 'HP-UX'


# Generated at 2022-06-23 00:05:04.727564
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    def run_command(self, *args, **kwargs):
        return (0, '', '')
    HPUXNetwork.module.run_command = run_command
    result = HPUXNetwork.get_default_interfaces()
    expected_result = {"default_gateway": "192.0.2.0", "default_interface": "lan0"}
    assert result == expected_result


# Generated at 2022-06-23 00:05:10.774438
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    module.run_command.return_value = 0, "/usr/bin/netstat -nr: check permissions on this command", ""
    network = HPUXNetwork(module)
    out = network.get_default_interfaces()
    assert out == {}
    module.run_command.return_value = 0, 'default 192.0.2.254 UGSc 1 0 lan0', ''
    out = network.get_default_interfaces()
    assert out == {'default_gateway': '192.0.2.254', 'default_interface': 'lan0'}
    module.run_command.return_value = 0, """default 192.0.2.254 UGSc 1 0 lan0
192.0.2.0/24 link#3 UC 1 0 lan0""", ''
    out = network

# Generated at 2022-06-23 00:05:14.926805
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hux_network_col = HPUXNetworkCollector()
    assert hux_network_col.platform == 'HP-UX'
    assert hux_network_col._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:05:24.981820
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.hpux.netstat import HPUXNetwork

    module = MockModule()
    module.run_command = Mock(return_value=(0,
                                            to_bytes('lan0 link#2       UP         1500  internet  10.0.1.1'),
                                            to_bytes('')))

    network = HPUXNetwork()
    network.module = module
    interfaces = network.get_interfaces_info()

    assert len(interfaces) == 1
    assert interfaces['lan0']['ipv4']['address'] == "10.0.1.1"


# Mock of module

# Generated at 2022-06-23 00:05:36.957017
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    # Test will fail if there is any key in the dictionary 'expected_facts'
    # that is not present in the actual 'facts' dictionary.

    # Test will fail if there is any value of a key in the dictionary
    # 'expected_facts' that is not equal to the corresponding key in the actual
    # 'facts' dictionary.

    # Test will fail if there is any key in the dictionary 'facts' that is not
    # present in the dictionary 'expected_facts'

    # Default_interfaces keys and values
    default_interface = 'lan0'
    default_gateway = '10.10.10.1'

    # Interfaces keys and values
    lan0 = 'lan0'
    lan1 = 'lan1'
    lan2 = 'lan2'
    lan3 = 'lan3'
    lan4 = 'lan4'


# Generated at 2022-06-23 00:05:46.202607
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for class HPUXNetwork method populate.
    """
    # Create a HPUXNetwork object
    network = HPUXNetwork({})
    facts = network.populate()
    assert 'default_interface' in facts
    assert 'interfaces' in facts
    assert 'lan0' in facts['interfaces']
    assert 'device' in facts['lan0']
    assert 'ipv4' in facts['lan0']
    assert 'address' in facts['lan0']['ipv4']
    assert 'network' in facts['lan0']['ipv4']


# Generated at 2022-06-23 00:05:47.602457
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._fact_class
    assert HPUXNetworkCollector._platform

# Generated at 2022-06-23 00:05:50.732684
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = dict()
    module['run_command'] = run_command
    network = HPUXNetwork(module)
    assert network.module == module


# Generated at 2022-06-23 00:05:53.315890
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net
    assert net.platform == 'HP-UX'
    assert net.interfaces == 'Interfaces'
    assert net.default_interface == 'Default interface'



# Generated at 2022-06-23 00:05:54.566736
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector is not None

# Generated at 2022-06-23 00:05:59.170407
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpux_network_collector = HPUXNetworkCollector()
    hpux_network_facts = hpux_network_collector.collect()
    hpux_network_instance = HPUXNetwork(hpux_network_facts)
    network_facts = hpux_network_instance.get_default_interfaces()
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts



# Generated at 2022-06-23 00:06:10.288193
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method "populate" of class "HPUXNetwork"
    """

    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.collector import FactsCollector

    # Assign module, which is normally passed to the class constructor
    HPUXNetworkCollector._module = HPUXNetworkCollector._module_class()
    HPUXNetwork._module = HPUXNetwork._module_class()

    # Create the HPUXNetworkCollector object
    hpux_network_collector = HPUXNetworkCollector()

    # Create the FactsCollector object, which will invoke the populate methods
    # for all facts subclasses, with the exception of sub