

# Generated at 2022-06-22 23:56:13.837421
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import Network
    import os
    import sys
    import tempfile
    import shutil

    dirpath = tempfile.mkdtemp()
    output = [
        'lan0: flags=842<BROADCAST,RUNNING,MULTICAST>',
        '        inet 10.2.3.4 netmask ffffff00 broadcast 10.2.3.255',
        'lan2: flags=842<BROADCAST,RUNNING,MULTICAST>',
        '        inet 10.2.5.6 netmask ffffff00 broadcast 10.2.5.255',
        ''
    ]
    netstat_path = os.path.join(dirpath, '/usr/bin/netstat')

# Generated at 2022-06-22 23:56:25.025773
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module = mock.Mock()
    net.module.run_command.return_value = (0, '', '')

# Generated at 2022-06-22 23:56:27.912866
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collected_facts = {}
    cn = HPUXNetworkCollector(None, collected_facts)
    assert cn is not None


# Generated at 2022-06-22 23:56:29.014842
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-22 23:56:33.322114
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collected_facts = {'kernel': 'HP-UX'}
    fact_class = HPUXNetwork
    network_collector = HPUXNetworkCollector(fact_class,
                                             collected_facts=collected_facts)
    assert network_collector.platform == 'HP-UX'
    assert network_collector.collected_facts == collected_facts

# Generated at 2022-06-22 23:56:34.102757
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()

# Generated at 2022-06-22 23:56:36.836941
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector(None, None)
    assert isinstance(obj, HPUXNetworkCollector)

# Generated at 2022-06-22 23:56:38.142358
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork(dict())
    assert hpux_network.platform == "HP-UX"


# Generated at 2022-06-22 23:56:44.721758
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = MockNetworkModule()
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'
    assert network.module == module
    assert network.get_interfaces_info()['lan0'] == {'device': 'lan0',
                                                     'ipv4': {'network': '192.168.1.0',
                                                              'interface': 'lan0',
                                                              'address': '192.168.1.121'}}



# Generated at 2022-06-22 23:56:46.829630
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork

# Generated at 2022-06-22 23:56:54.720672
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    my_net = HPUXNetwork()
    my_net.module.run_command = lambda cmd: (0, '', '')
    my_net.module.run_command = lambda cmd: (0,
                                             'lan0      0   0   0   0   ETHER     0    0    0    0',
                                             '')

    interfaces = my_net.get_interfaces_info()
    assert interfaces.keys() == ['lan0']
    assert interfaces['lan0']['ipv4'] == {'address': '0'}

# Generated at 2022-06-22 23:56:56.868752
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector is not None


# Generated at 2022-06-22 23:57:06.438779
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    my_obj = HPUXNetwork()
    dummy, test_file_name = basic._make_tmp_file_or_dir()
    my_obj.module = basic.AnsibleModule(argument_spec={})
    my_obj.module.run_command = lambda cmd: \
        0, to_bytes('default 192.168.1.1 UG lan7'), to_bytes('')
    default_interfaces = my_obj.get_default_interfaces()
    assert(default_interfaces['default_interface'] == 'lan7')
    assert(default_interfaces['default_gateway'] == '192.168.1.1')



# Generated at 2022-06-22 23:57:10.388686
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    my_HPUXNetwork = HPUXNetwork()
    interfaces = my_HPUXNetwork.get_interfaces_info()
    print(interfaces)


# Generated at 2022-06-22 23:57:14.135086
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Create a stub module
    module = type(str("AnsibleModuleStub"))()
    module.run_command = lambda cmd: (0, test_HPUXNetwork_out, '')

    network_col = HPUXNetwork(module=module)
    ifaces = network_col.get_interfaces_info()

    assert len(ifaces) == 3
    assert 'lan0' in ifaces
    assert ifaces['lan0'] == {'device': 'lan0',
                              'ipv4': {'address': '192.168.1.10',
                                       'interface': 'lan0',
                                       'network': '192.168.1.0'}}



# Generated at 2022-06-22 23:57:15.785476
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.populate()


# Generated at 2022-06-22 23:57:24.743162
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}
    module = HPUXNetwork()
    rc, out, err = module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    output_info = module.get_interfaces_info()
    for line in lines:
        words = line.split()
        for i in range(len(words) - 1):
            if words[i][:3] == 'lan':
                device = words[i]
                interfaces[device] = {'device': device}
                address = words[i + 3]
                interfaces[device]['ipv4'] = {'address': address}
                network = words[i + 2]

# Generated at 2022-06-22 23:57:28.287813
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    net = HPUXNetwork(module)
    facts = {}
    net.populate()
    assert net.default_interface

# Generated at 2022-06-22 23:57:32.159838
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    net = HPUXNetwork(dict())
    out = net.get_default_interfaces()
    assert out['default_gateway'] == '10.224.108.1'
    assert out['default_interface'] == 'lan0'


# Generated at 2022-06-22 23:57:37.956441
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """Unit test for method get_default_interfaces of class HPUXNetwork"""
    dummy_module = AnsibleModule(argument_spec=dict())
    obj = HPUXNetwork(dummy_module)
    default_interfaces_result = obj.get_default_interfaces()
    assert "default_gateway" in default_interfaces_result
    assert "default_interface" in default_interfaces_result


# Generated at 2022-06-22 23:57:44.896997
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module=module)
    default_interfaces_facts = network.get_default_interfaces()
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '10.0.2.2'



# Generated at 2022-06-22 23:57:57.689032
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hostname = 'ansi01'
    domain = 'ansi.com'


# Generated at 2022-06-22 23:57:58.616178
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-22 23:57:59.958092
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-22 23:58:04.817268
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan3'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-22 23:58:08.191031
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork


# Generated at 2022-06-22 23:58:19.239521
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """Create the class instance with a test module and test
    parsing of the output from the command:
    netstat -nr.
    """
    from ansible.module_utils.facts import Collector
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = mock.Mock(return_value=(0, to_bytes(
'''default 192.168.56.1 UGS 0 788 lan1
default 192.168.56.1 UGS 0 788 lan2
'''), None))

    facts_collector = Collector(module=module)

    default_interfaces = HPUXNetwork(facts_collector=facts_collector).get_default_interfaces()

# Generated at 2022-06-22 23:58:27.012896
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Stub values for testing
    default_interface = 'lan0'
    default_gateway = '10.11.13.1'
    device = 'lan0'
    address = '10.11.13.14'
    network = '10.11.13.0'
    interfaces = {'lan0': {'ipv4': {'address': address, 'network': network, 'interface': device, 'address': address},
                           'device': 'lan0'}}
    default_interfaces = {'default_interface': default_interface, 'default_gateway': default_gateway}

    # This test uses the HPUXNetwork class defined in this module
    class TestHPUXNetwork(HPUXNetwork):
        def get_default_interfaces(self):
            # Stub for testing
            return default_interface


# Generated at 2022-06-22 23:58:30.051960
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = AnsibleModuleMock()
    test_module.run_command.return_value = (0, 'default  10.12.10.68 UG       3 0 ixgbe0', None)
    network = HPUXNetwork(module=test_module)
    result = network.populate()
    assert result == {'default_interface': 'ixgbe0',
                      'default_gateway': '10.12.10.68'}



# Generated at 2022-06-22 23:58:31.968933
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_facts = HPUXNetwork(None)
    assert network_facts.platform == 'HP-UX'



# Generated at 2022-06-22 23:58:35.262940
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    net_obj = HPUXNetwork(module)
    default_interfaces = {'default_interface': 'lan0', 'default_gateway': '10.18.68.1'}
    assert net_obj.get_default_interfaces() == default_interfaces


# Generated at 2022-06-22 23:58:47.357167
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule:
        def __init__(self):
            self.params = {}
            self.run_command_called = False
            self.run_command_args = None
            self.run_command_kwargs = None

        def get_bin_path(self, name, required=False):
            return '/usr/bin/' + name

        def run_command(self, cmd, check_rc=True):
            self.run_command_called = True
            self.run_command_args = cmd


# Generated at 2022-06-22 23:58:52.623904
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module.run_command = mock_run_command
    network.module.run_command.return_value = 0, netstat_nr_out, ''

    default_interfaces_facts = network.get_default_interfaces()
    assert default_interfaces_facts == {'default_interface': 'lan0',
                                        'default_gateway': '192.168.0.1'}



# Generated at 2022-06-22 23:58:55.508234
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_module = AnsibleModule(argument_spec={})
    network_module.params = PARAMS_FOR_TESTS
    network = HPUXNetwork(network_module)
    assert network.module == network_module


# Generated at 2022-06-22 23:58:58.840905
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-22 23:59:04.731566
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    obj = HPUXNetwork()
    default_interfaces = obj.get_default_interfaces()
    assert default_interfaces['default_gateway'] == "default"
    assert default_interfaces['default_interface'] == "lan6"


# Generated at 2022-06-22 23:59:07.569261
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    obj = HPUXNetwork(module)
    obj.populate()


# Generated at 2022-06-22 23:59:15.447205
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    TestModule = type('TestModule', (object,), {})
    TestModule.run_command = (lambda x: (0, 'default 192.168.0.1 UGS lan0', None))
    TestModule.get_bin_path = (lambda x: '/usr/bin/netstat')
    network = HPUXNetwork(TestModule)
    expected_default_interfaces = {'default_interface': 'lan0',
                                   'default_gateway': '192.168.0.1'}
    actual_default_interfaces = network.get_default_interfaces()
    assert actual_default_interfaces == expected_default_interfaces

# Generated at 2022-06-22 23:59:21.424471
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_HPUXNetwork = HPUXNetwork(None)
    netstat_path = test_HPUXNetwork.module.get_bin_path('netstat')
    if netstat_path is None:
        return {}
    rc, out, err = test_HPUXNetwork.module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                assert test_HPUXNetwork.get_default_interfaces(None) == {'default_interface': words[4], 'default_gateway': words[1]}



# Generated at 2022-06-22 23:59:30.903351
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpuxtest import \
        AnsibleModuleTest
    mod = AnsibleModuleTest()
    netstat_cmd = mod.netstat_path
    mod.run_command = mock_run_command
    c = HPUXNetwork()
    c.module = mod
    c.run_command = mock_run_command
    interfaces = c.get_interfaces_info()
    assert interfaces == {'lan0': {'device': 'lan0',
                                   'ipv4': {'address': '35.0.0.3',
                                            'interface': 'lan0',
                                            'network': '35.0.0.0'}}}



# Generated at 2022-06-22 23:59:36.003709
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module.run_command = mock_run_command
    result = network.get_default_interfaces()
    assert len(result) == 2
    assert set(result.keys()) == set(['default_interface', 'default_gateway'])
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '172.16.25.1'



# Generated at 2022-06-22 23:59:38.220467
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    my_obj = HPUXNetworkCollector()
    assert my_obj._platform == 'HP-UX'


# Generated at 2022-06-22 23:59:48.113785
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_content = '/usr/bin/netstat -nr'
    test_default_interface = {'default_interface': 'lan0',
                              'default_gateway': '10.10.10.1'}
    # Instantiate the module
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, test_content, None))
    # Instantiate the class to be tested
    obj = HPUXNetwork()
    # Set AnsibleModule instance as our module instance
    obj.module = module
    # Run method get_default_interfaces()
    result = obj.get_default_interfaces()
    # Assertion
    assert result == test_default_interface


# Generated at 2022-06-22 23:59:55.166328
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    network_module = MockNetworkModule()
    hpux_network = HPUXNetwork(network_module)
    hpux_network.get_interfaces_info()

    for iface in network_module.interfaces:
        assert iface in hpux_network.facts['interfaces']
        assert hpux_network.facts[iface]['ipv4']['address'] == \
               network_module.interfaces[iface]['ipv4']['address']
        assert hpux_network.facts[iface]['ipv4']['network'] == \
               network_module.interfaces[iface]['ipv4']['network']


# Mocked network module

# Generated at 2022-06-23 00:00:05.615539
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ModuleMock(object):
        def __init__(self):
            self.run_command = run_command
        def get_bin_path(self):
            return '/usr/bin/netstat'

    class RunCommandMock(object):
        def __init__(self, stdout, stderr, rc):
            self.stdout = stdout
            self.stderr = stderr
            self.rc = rc
        def __call__(self, _, check_rc=True):
            return self.rc, self.stdout, self.stderr


# Generated at 2022-06-23 00:00:10.257950
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = MockAnsibleModule()
    net = HPUXNetwork(m)
    facts = net.get_default_interfaces()

    assert 'default_interface' in facts.keys()
    assert 'default_gateway' in facts.keys()



# Generated at 2022-06-23 00:00:14.129293
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    res = module.run_command("/usr/bin/netstat -niw")
    hpux_network = HPUXNetwork(module)
    interfaces = hpux_network.get_interfaces_info()
    assert interfaces['lan2'] == {'device': 'lan2',
                                  'ipv4': {'address': '10.10.10.1',
                                           'network': '10.10.10.0',
                                           'interface': 'lan2',
                                           'address': '10.10.10.1'}}


# Generated at 2022-06-23 00:00:15.445998
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    result = HPUXNetworkCollector()
    assert result



# Generated at 2022-06-23 00:00:22.806797
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()

    m1 = module.get_bin_path.return_value = None
    netstat_path = module.get_bin_path.return_value = "/usr/bin/netstat"

    m2 = module.run_command.return_value = (0, DEFAULT_INTERFACE_OUTPUT, None)
    m3 = module.run_command.return_value = (0, INTERFACES_OUTPUT, None)

    hpuxnetwork = HPUXNetwork(module)
    hpuxnetwork_facts = hpuxnetwork.populate()

    assert len(hpuxnetwork_facts) == 5

    assert hpuxnetwork_facts['default_interface'] == 'lan0'
    assert hpuxnetwork_facts['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-23 00:00:33.218328
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )
    if not HAS_NETSTAT:
        module.fail_json(msg="'netstat' not found in PATH. Install net-tools")

    hpux_network = HPUXNetwork(module)
    out = hpux_network.populate()
    # Test to check 'default_interface' key exists in the result
    assert 'default_interface' in out, \
           "Key 'default_interface' not in the result"
    # Test to check 'default_gateway' key exists in the result

# Generated at 2022-06-23 00:00:44.113157
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = dict()
    facts['ansible_eth1'] = {'ipv4': {'address': '10.10.10.21', 'netmask': '255.255.255.0', 'network': '10.10.10.0'}}
    facts['ansible_eth2'] = {'ipv4': {'address': '10.10.11.21', 'netmask': '255.255.255.0', 'network': '10.10.11.0'}}
    facts['ansible_default_ipv4'] = {'address': '10.10.10.21', 'interface': 'eth1'}
    facts['ansible_eth1']['active'] = True
    facts['ansible_eth2']['active'] = True
    hn = HPUXNetwork(facts)

# Generated at 2022-06-23 00:00:56.822452
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netstat = """
    Routing tables

    Internet:
    Destination        Gateway           Flags Refs Use If
    default            10.172.0.1        UG        0   3 lan2
    10.172.0.0         10.172.0.244      U         7   0 lan2
    10.172.20.0        10.172.20.199     U         1   0 lan0"""
    module = DummyModule(netstat)

    network = HPUXNetwork(module)
    default_interfaces_info = network.get_default_interfaces()
    assert default_interfaces_info['default_interface'] == 'lan2'
    assert default_interfaces_info['default_gateway'] == '10.172.0.1'


# Generated at 2022-06-23 00:00:58.214813
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fact_class = HPUXNetwork()
    result = fact_class.populate()
    assert result['default_interface'] == 'lan0'


# Generated at 2022-06-23 00:01:00.343767
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:01:11.112439
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module = FakeModule()
    # On a HP-UX server the output of command /usr/bin/netstat -nr is:
    # Destination	Gateway		Flags	Refs	Use	If
    # default		172.22.15.241	UG	0	0	lan1
    # 172.22.0.0	172.22.15.241	U	0	0	lan1
    # 172.22.0.0	172.22.15.241	U	0	0	lan1
    # 172.22.15.240	172.22.15.241	UHSb	0	0	lan1
    default_interfaces = network.get_default_interfaces()

    assert(len(default_interfaces) == 2)

# Generated at 2022-06-23 00:01:17.385064
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule:
        def run_command(self, cmd):
            res = {'stdout': 'default 172.24.73.1 UGSc195 lan0\n',
                   'rc': 0}
            return res['rc'], res['stdout'], res['stderr']

    test_module = TestModule()
    network = HPUXNetwork(test_module)
    expected_interfaces = {'default_interface': 'lan0', 'default_gateway': '172.24.73.1'}
    interfaces = network.get_default_interfaces()
    assert interfaces == expected_interfaces


# Generated at 2022-06-23 00:01:27.810139
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import ansible.module_utils.facts.network.hpux

    module = ansible.module_utils.facts.network.hpux.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )


# Generated at 2022-06-23 00:01:29.895291
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_net = HPUXNetwork()
    test_net.get_default_interfaces()


# Generated at 2022-06-23 00:01:37.138859
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpx_network_collector = HPUXNetworkCollector()
    assert HPUXNetworkCollector == type(hpx_network_collector)
    assert str == type(hpx_network_collector.platform)
    assert hpx_network_collector.platform == "HP-UX"
    assert HPUXNetwork == type(hpx_network_collector.fact_class)

# Generated at 2022-06-23 00:01:40.059788
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = HPUXNetwork()
    ifaces = module.get_interfaces_info()
    assert 'lan0' in ifaces

# Generated at 2022-06-23 00:01:41.619395
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert isinstance(obj, HPUXNetworkCollector)


# Generated at 2022-06-23 00:01:43.809420
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network.platform == 'HP-UX'


# Generated at 2022-06-23 00:01:48.387308
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))
    network_module = HPUXNetwork(module)
    network_facts = network_module.populate()
    assert network_facts['interfaces'] == ['lan0', 'lan4', 'lan5', 'lan6', 'lan7', 'lan8', 'lan9']

# Generated at 2022-06-23 00:01:58.616172
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    obj = HPUXNetwork()
    obj.module = MagicMock()
    obj.module.run_command = MagicMock()

    # No default interface
    out = '''
Kernel IP routing table
Destination        Gateway          Flag    Ref      Use    Interface
default            abcdef           UG      13        2      lan0
abcdef             *                U       0        0      lo0
'''
    rc = 0
    err = ''
    obj.module.run_command.return_value = [rc, out, err]
    result = obj.get_default_interfaces()
    assert result == {}

    # With default interface

# Generated at 2022-06-23 00:02:02.161076
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_nc = HPUXNetworkCollector()
    assert hpux_nc.platform == 'HP-UX'
    assert hpux_nc._fact_class == HPUXNetwork

# Generated at 2022-06-23 00:02:03.920857
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpuxnet = HPUXNetwork()
    assert hpuxnet.platform == 'HP-UX'


# Generated at 2022-06-23 00:02:12.642642
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    class MockModule:
        def get_bin_path(self, command):
            return None

    class MockFacts:
        def populate(self):
            return {}

    network = HPUXNetwork(module=MockModule(), facts=MockFacts())
    network.module.run_command = lambda cmd: [0, netstat, '']
    network_facts = network.populate()
    assert network_facts['interfaces'][0] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '192.168.1.1'



# Generated at 2022-06-23 00:02:17.199006
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux.netstat import HPUXNetwork
    network = HPUXNetwork(None)
    network.module.run_command = fake_run_command
    expected = {'default_gateway': '192.168.1.1',
                'default_interface': 'lan2'}
    result = network.get_default_interfaces()
    assert result == expected


# Generated at 2022-06-23 00:02:21.788780
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    mock_HPUXNetwork = Mock(spec=HPUXNetwork)
    interface = 'lan0'
    network_facts = {'default_interface': 'lan0',
                     'default_gateway': '192.168.2.2',
                     'interfaces': [interface],
                     interface:
                     {'device': interface,
                      'ipv4': {'address': '192.168.2.10',
                               'network': '192.168.2.0/24',
                               'interface': interface,
                               'address': '192.168.2.10'}}}

    mock_HPUXNetwork.populate.return_value = network_facts

    facts = mock_HPUXNetwork.pop

# Generated at 2022-06-23 00:02:23.305627
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces_facts = HPUXNetwork.get_default_interfaces(None)
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts


# Generated at 2022-06-23 00:02:30.632430
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fake_module = FakeModule()
    instance = HPUXNetwork(fake_module)
    instance.populate()
    assert instance.facts == {'default_interface': 'lan0', 'interfaces': ['lan0'], 'lan0': {'ipv4': {'address': '10.66.33.217', 'network': '10.66.33.0', 'interface': 'lan0'}, 'device': 'lan0'}, 'default_gateway': '10.66.33.1'}



# Generated at 2022-06-23 00:02:34.244824
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector."""
    collector = HPUXNetworkCollector()
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:02:36.899225
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector.platform == 'HP-UX'


# Generated at 2022-06-23 00:02:41.436286
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)

    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-23 00:02:42.937092
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    n = HPUXNetwork()
    assert n is not None

# Generated at 2022-06-23 00:02:46.053121
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hp_facts = HPUXNetwork(module)
    assert hp_facts.module == module

# Generated at 2022-06-23 00:02:57.545656
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    module.run_command = fake_run_command
    module.get_bin_path = fake_get_bin_path
    netinfo = HPUXNetwork(module).populate()

# Generated at 2022-06-23 00:03:06.356663
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux.HPUXNetwork import HPUXNetwork
    net = HPUXNetwork()
    interfaces = net.get_interfaces_info()

# Generated at 2022-06-23 00:03:12.015022
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class ModuleStub(object):
        def __init__(self, out):
            self.out = out

        def run_command(self, cmd, check_rc=True):
            return 0, self.out, None

    output1 = '/usr/bin/netstat -niw\n' \
        'Name       Mtu   Network       Address         Ipkts Ierrs     Ibytes    Opkts Oerrs     Obytes  Coll\n' \
        'lan0       1500  10.128.9.0    10.128.9.161   269468     0   41471130   453767     0  538605437     0\n' \
        'lan1       4500  default       default                0     0          0        0     0          0     0\n'


# Generated at 2022-06-23 00:03:14.830642
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    network.get_default_interfaces()



# Generated at 2022-06-23 00:03:16.435944
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_NetworkCollector = HPUXNetworkCollector()
    assert hpux_NetworkCollector._fact_class == HPUXNetwork
    assert hpux_NetworkCollector._platform == 'HP-UX'

# Generated at 2022-06-23 00:03:18.035058
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network is not None


# Generated at 2022-06-23 00:03:28.873086
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
                                                 "default 172.26.110.254 UGS 0 0 lan18\n"
                                                 "172.26.64.0 172.26.64.1 U 0 0 lan19\n"
                                                 "172.26.64.64 172.26.64.65 U 0 0 lan19\n"
                                                 "172.26.64.128 172.26.64.129 U 0 0 lan19\n"
                                                 "172.26.64.192 172.26.64.193 U 0 0 lan19\n",
                                                 ""))
    mock_ifconfig = MagicMock()

# Generated at 2022-06-23 00:03:33.116789
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""
    network_facts = HPUXNetwork()
    interfaces = network_facts.get_interfaces_info()
    assert type(interfaces) == dict

# Generated at 2022-06-23 00:03:42.849933
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    def get_bin_path(name, **kwargs):
        return '/usr/bin/netstat'

    module.get_bin_path = get_bin_path


# Generated at 2022-06-23 00:03:49.628588
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, 'default 192.168.56.1 UG lan0', '')
    network = HPUXNetwork(mock_module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces == {
        'default_interface': 'lan0',
        'default_gateway': '192.168.56.1',
    }



# Generated at 2022-06-23 00:03:59.461598
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    HPUXNetwork_test = HPUXNetwork({'module': None})
    interfaces = HPUXNetwork_test.get_interfaces_info()
    assert interfaces == {'lan11': {'ipv4': {'interface': 'lan11',
                                             'address': '10.255.255.5',
                                             'network': '10.255.255.0'},
                                   'device': 'lan11'},
                          'lan0': {'ipv4': {'interface': 'lan0',
                                            'address': '10.255.255.1',
                                            'network': '10.255.255.0'},
                                   'device': 'lan0'}}

# Generated at 2022-06-23 00:04:01.358439
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpx = HPUXNetworkCollector()
    assert isinstance(hpx, HPUXNetworkCollector)


# Generated at 2022-06-23 00:04:04.565203
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Validate the constructor of class HPUXNetworkCollector
    """
    collector = HPUXNetworkCollector()
    assert collector is not None
    assert collector.__class__.__name__ == 'HPUXNetworkCollector'
    assert isinstance(collector, NetworkCollector)


# Generated at 2022-06-23 00:04:09.629044
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    NetCollect = HPUXNetworkCollector()
    assert isinstance(NetCollect._fact_class, type(HPUXNetwork))
    assert NetCollect._fact_class.platform == 'HP-UX'
    assert NetCollect._platform == 'HP-UX'



# Generated at 2022-06-23 00:04:21.338463
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:04:31.089187
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Create an instance of HPUXNetwork class
    network = HPUXNetwork({})

# Generated at 2022-06-23 00:04:33.151506
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net_mod = HPUXNetwork({})
    assert net_mod.platform == 'HP-UX'
    assert net_mod.get_interfaces_info() != {}

# Generated at 2022-06-23 00:04:37.605351
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class Module(object):
        # unit test fail without this line, dont know why.
        def get_bin_path(self, item):
            pass
        def run_command(self):
            return (0, 'default 192.168.1.1 UG lan0', '')
    module = Module()
    iface = HPUXNetwork(module)
    result = iface.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-23 00:04:46.988634
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    net_collector = HPUXNetwork(module)
    net_facts = net_collector.populate()

    assert 'lo0' in net_facts['interfaces']
    assert 'lan1' in net_facts['interfaces']

    assert 'default_interface' in net_facts
    assert 'default_gateway' in net_facts

    assert 'ipv4' in net_facts['lo0']
    assert 'ipv4' in net_facts['lan1']

    assert len(net_facts['interface_ip']) > 0

# Generated at 2022-06-23 00:04:58.194153
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    network = HPUXNetwork()
    network.module.run_command = lambda *args, **kwargs: (0,
                                                          'lan0: flags=8c43<UP,BROADCAST,RUNNING,ALLMULTI,SIMPLEX,MULTICAST> mtu 1500\n'
                                                          '        inet 10.1.1.1 netmask ff000000 broadcast 10.255.255.255\n'
                                                          'lan1: flags=843<UP,BROADCAST,RUNNING,ALLMULTI,SIMPLEX,MULTICAST> mtu 1500\n'
                                                          '        inet 10.2.2.2 netmask ff000000 broadcast 10.255.255.255\n',
                                                          '')
    interfaces = network.get_interfaces_info

# Generated at 2022-06-23 00:05:01.418776
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MagicMock()
    module.run_command.return_value = (0, "", "")
    hpu = HPUXNetwork(module)
    assert isinstance(hpu.populate(), dict)


# Generated at 2022-06-23 00:05:04.355264
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hwn = HPUXNetwork()
    assert hwn.platform == 'HP-UX'
    assert hwn.get_default_interfaces() is not None
    assert hwn.get_interfaces_info() is not None


# Generated at 2022-06-23 00:05:07.277650
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    default_interface = net.get_default_interfaces()
    assert 'default_interface' in default_interface
    assert 'default_gateway' in default_interface


# Generated at 2022-06-23 00:05:12.245174
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default_interfaces = {'default_interface': 'lan0', 'default_gateway': '10.176.68.1'}

    class TestModule(object):
        def __init__(self):
            self.run_command_str = "/usr/bin/netstat -nr"
            self.run_command_rc = 0

# Generated at 2022-06-23 00:05:14.539913
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn
    assert isinstance(hn, NetworkCollector)


# Generated at 2022-06-23 00:05:25.770047
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    inputfile = open('/tmp/inputfile', 'w')
    inputfile.write(
        'link   rbytes      rpackets      rerrors      rdrops' + '\n' +
        'lan0    0           0              0            0' + '\n' +
        'lan0    0           0              0            0' + '\n' +
        'lan1    0           0              0            0' + '\n' +
        'lan1    0           0              0            0' + '\n')
    inputfile.close()
    os.environ['ANSIBLE_NET_HPUX'] = '/tmp/inputfile'
    os.environ['ANSIBLE_NET_SSH_CONFIG'] = None
    os.environ['ANSIBLE_NET_SSH_KEY'] = None

# Generated at 2022-06-23 00:05:31.257536
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.network.hpux import HPUXNetworkCollector
    obj = HPUXNetworkCollector()
    assert obj._fact_class is HPUXNetwork
    assert obj._platform == 'HP-UX'



# Generated at 2022-06-23 00:05:33.785877
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'
    assert HPUXNetwork.platform == 'HP-UX'


# Generated at 2022-06-23 00:05:35.595471
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpn_c = HPUXNetworkCollector()
    assert hpn_c


# Generated at 2022-06-23 00:05:38.216622
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'



# Generated at 2022-06-23 00:05:41.012511
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Test the constructor of class HPUXNetworkCollector.
    """
    collector = HPUXNetworkCollector()
    assert collector



# Generated at 2022-06-23 00:05:42.609894
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork({})
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-23 00:05:48.340992
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # First, create a mock module object, and mock module input parameters.
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all', '!min']),
        ),
        supports_check_mode=True,
    )
    # Next, create a mock AnsibleModule object.
    NetworkCollector(module=module, platform='HP-UX')



# Generated at 2022-06-23 00:05:53.737635
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all',
                                                        '!min'],
                                              type='list')),
        supports_check_mode=True)
    ansible_network_facts = HPUXNetworkCollector(module)
    result = ansible_network_facts.populate()
    assert ('default_interface' in result)
    assert ('default_gateway' in result)
    assert ('interfaces' in result)



# Generated at 2022-06-23 00:05:59.034863
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """ Test creation of the HPUXNetworkCollector. """
    result = HPUXNetworkCollector()
    # assert that the object created is of the right class
    assert result.__class__.__name__ == 'HPUXNetworkCollector'
    # assert that _fact_class is set to HPUXNetwork
    assert result._fact_class.__name__ == 'HPUXNetwork'
    # assert that _platform is set to 'HP-UX'
    assert result._platform == 'HP-UX'

# Generated at 2022-06-23 00:06:10.146004
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())