

# Generated at 2022-06-22 23:56:10.511983
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Constructor of class HPUXNetwork should create an instance of HPUXNetwork,
    and its platform should be HP-UX.
    """
    network_obj = HPUXNetwork()
    assert isinstance(network_obj, HPUXNetwork)
    assert network_obj.platform == HPUXNetwork.platform


# Generated at 2022-06-22 23:56:14.275402
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._platform is not None
    assert hpux_network_collector._fact_class is not None


# Generated at 2022-06-22 23:56:15.867629
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    HPUXNetwork.get_default_interfaces()



# Generated at 2022-06-22 23:56:27.565273
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    HPUXNetwork.populate() Test for correct data
    """
    module = type('module', (object,), {'run_command':fake_run_command})
    hpux_network = HPUXNetwork(module)
    network_facts = hpux_network.populate()
    assert('interfaces' in network_facts)
    assert('lo0' in network_facts['interfaces'])
    assert('lan0' in network_facts['interfaces'])
    assert(len(network_facts['interfaces']) == 2)
    assert('default_interface' in network_facts)
    assert('default_gateway' in network_facts)
    assert(network_facts['default_interface'] == 'lan0')
    assert(network_facts['default_gateway'] == '172.29.246.1')

# Generated at 2022-06-22 23:56:33.471814
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ModuleMock(object):
        def __init__(self):
            self.run_command = lambda x: \
            (0, 'default 172.17.0.1 UGSc 0 0 lan0', '')

    module = ModuleMock()
    network = HPUXNetwork(module)
    result = {'default_interface': 'lan0', 'default_gateway': '172.17.0.1'}
    assert result == network.get_default_interfaces()


# Generated at 2022-06-22 23:56:39.339070
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'default 192.168.122.0 UGSc 0 0 lan0 ', '')
    mynetwork = HPUXNetwork(module)
    network_facts = mynetwork.populate()
    assert network_facts['default_interface'] == 'lan0'

# Generated at 2022-06-22 23:56:45.423152
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    test_module.module.run_command = lambda args, check_rc=True: (0, 'default           192.168.1.1        UG        0        0        lan0', '')
    network = HPUXNetwork(test_module)
    result = network.get_default_interfaces()
    assert result == {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}



# Generated at 2022-06-22 23:56:47.792491
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector."""

    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector

# Generated at 2022-06-22 23:56:56.590446
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    out = '\ndefault 10.0.2.2 UG 0 0 wlan0 \n'
    expected_default_interfaces = {'default_interface': 'wlan0', 'default_gateway': '10.0.2.2'}
    network_obj = HPUXNetwork()
    network_obj.module = Mock(return_value=None)
    network_obj.module.run_command = Mock(return_value=(0, out, None))
    default_interfaces = network_obj.get_default_interfaces()
    assert default_interfaces == expected_default_interfaces


# Generated at 2022-06-22 23:56:59.712538
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector.platform == 'HP-UX'
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-22 23:57:10.950200
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Test get_default_interfaces
    """
    class ModuleMock(object):
        def __init__(self, cmd, out=""):
            self.cmd = cmd
            self.out = out

        def run_command(self, cmd):
            if isinstance(self.cmd, list):
                self.cmd = [x.strip() for x in self.cmd]
            return (0, self.out, '')

    hpn = HPUXNetwork(None)

    # Case 1, default gateway and interface are present in netstat -r output
    module_mock = ModuleMock(["netstat -nr"], "default 192.168.1.1 UGSc 120 1 lan0\n")
    hpn.module = module_mock
    default_interfaces = hpn.get_default_interfaces()


# Generated at 2022-06-22 23:57:16.573082
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeModule()
    hpux_network = HPUXNetwork(module)
    interfaces = hpux_network.get_interfaces_info()
    assert interfaces['lan1'] == {'ipv4': {'network': '0.0.0.0', 'interface': 'lan1',
                                        'address': '0.0.0.0'}, 'device': 'lan1'}



# Generated at 2022-06-22 23:57:18.536414
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc._fact_class == HPUXNetwork
    assert nc._platform == 'HP-UX'

# Generated at 2022-06-22 23:57:26.402157
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    def _run_command(*args, **kwargs):
        return 0, """default 192.168.0.1 UGS 0 0 lan0
        default 192.168.0.1 UGS 0 0 lan0
        127.0.0.1 127.0.0.1 UH 0 0 lo0
        192.168.0.0 192.168.0.1 U 0 0 lan0
        default 192.168.0.1 UGS 0 0 lan0
        127.0.0.1 127.0.0.1 UH 0 0 lo0
        192.168.0.0 192.168.0.1 U 0 0 lan0""", ''
    module = {}
    module['run_command'] = _run_command
    net = HPUXNetwork(module)

# Generated at 2022-06-22 23:57:30.025823
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule({})
    hp_network = HPUXNetwork(module)
    assert hp_network is not None
    assert hp_network.platform == 'HP-UX'


# Generated at 2022-06-22 23:57:40.483138
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
        network_module = HPUXNetwork({'module': "Network"})
        result = network_module.populate()
        assert result['default_interface'] == "lan0"
        assert result['default_gateway'] == "10.1.1.1"
        assert result['interfaces'] == ['lan0', 'lan1']
        assert 'device' in result['lan0']
        assert 'ipv4' in result['lan0']
        assert 'ipv4' in result['lan1']
        assert 'address' in result['lan0']['ipv4']
        assert 'network' in result['lan0']['ipv4']
        assert 'interface' in result['lan0']['ipv4']
        assert 'address' in result['lan1']['ipv4']
        assert 'network' in result

# Generated at 2022-06-22 23:57:43.059960
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._platform == 'HP-UX'
    assert hn._fact_class == HPUXNetwork

# Generated at 2022-06-22 23:57:48.999194
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hostvars = {'ansible_facts': {}}
    collected_facts = HPUXNetwork(
        None, '.', {}, hostvars).populate()['ansible_facts']['ansible_network_resources']
    assert 'default_interface' in collected_facts
    assert 'interfaces' in collected_facts
    assert collected_facts['default_interface'] in collected_facts['interfaces']

# Generated at 2022-06-22 23:58:01.402666
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    collector = HPUXNetworkCollector(module=module)
    fact_class = collector._fact_class(module=module)
    fact_class.populate()
    assert module.run_command.call_count == 2
    assert fact_class.get_default_interfaces() == {'default_interface': 'lan5', 'default_gateway': '192.168.1.1'}

# Generated at 2022-06-22 23:58:08.059508
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.facts import Facts

    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=[], type='list'))
    )

    ansible_facts = Facts(module)
    facts = ansible_facts.get_facts()
    network_facts = facts['ansible_network_resources']
    assert 'default_interface' in network_facts

# Generated at 2022-06-22 23:58:09.682974
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.populate()


# Generated at 2022-06-22 23:58:20.865366
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module_mock = Mock(return_value=None)
    module_mock.run_command = Mock(return_value=(0, '', ''))
    module_mock.get_bin_path = Mock(return_value=True)
    hpn = HPUXNetwork(module_mock)
    hpn.get_default_interfaces = Mock(return_value=
                                      {'default_interface': 'lan0',
                                       'default_gateway': '10.10.10.1'})

# Generated at 2022-06-22 23:58:23.674231
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mock_module = MockModule()
    hn = HPUXNetwork(mock_module)
    hn.populate()
    assert mock_module.run_command.call_count == 3

# Unit test class for HPUXNetworkCollector

# Generated at 2022-06-22 23:58:29.583723
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mock_module = MockModule()

    # Construct the object that will be tested
    net = HPUXNetwork(mock_module)

    # Mock netstat output.  The values of 'default_interface' and
    # 'default_gateway' defined here correspond to the output of this
    # command on a HP-UX system.
    rc_netstat_nr = 0
    out_netstat_nr = ("default         172.16.0.1        UG        0        0        0 lan0\n")
    err_netstat_nr = ("")

    # Mock netstat output.  The values of 'device', 'address' and
    # 'network' defined here correspond to the output of this command
    # on a HP-UX system.
    rc_netstat_niw = 0

# Generated at 2022-06-22 23:58:31.250853
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    networking = HPUXNetwork()
    test_interfaces = networking.get_interfaces_info()
    assert('lan0' in test_interfaces)
    assert('lan1' in test_interfaces)



# Generated at 2022-06-22 23:58:36.463218
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec=dict())
    n = HPUXNetwork()
    n.populate_from_module(module)
    assert 'default_interface' in n.facts
    assert 'interfaces' in n.facts
    assert n.facts['default_interface'] == 'lan2'

# Generated at 2022-06-22 23:58:46.266181
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX', \
        "HPUXNetwork.platform: expected 'HP-UX', got %s" \
        % hn.platform
    assert hn.get_interfaces_info() is not None, \
        "HPUXNetwork.get_interfaces_info(): unexpected return value %s" \
        % hn.get_interfaces_info()
    assert hn.get_default_interfaces() is not None, \
        "HPUXNetwork.get_default_interfaces(): unexpected return value %s" \
        % hn.get_default_interfaces()

# Generated at 2022-06-22 23:58:47.644702
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-22 23:58:51.186509
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork({})
    hpux_network.populate()
    assert hpux_network.facts['default_interface'].startswith('lan')
    assert hpux_network.facts['default_gateway'].startswith('192.168.')

# Generated at 2022-06-22 23:58:52.415914
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    nm = HPUXNetwork()
    assert nm.platform == 'HP-UX'

# Generated at 2022-06-22 23:58:54.660720
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'
    assert hn.get_default_interfaces() == {}



# Generated at 2022-06-22 23:58:57.246605
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector_test = HPUXNetworkCollector()
    assert isinstance(collector_test, NetworkCollector)
    assert collector_test._fact_class == HPUXNetwork
    assert collector_test._platform == 'HP-UX'


# Generated at 2022-06-22 23:59:08.602333
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector
    from ansible.module_utils.facts.network.hpuux import HPUXNetwork

    module = AnsibleModule(argument_spec=dict())
    collector = get_collector(module.params['gather_subset'], module.params['gather_network_resources'], module)

    HPUX_Network = collector.get_network_collector()._fact_class
    hpux_network = HPUX_Network(module)

    hpux_network_facts = hpux_network.populate()

    for k in ['default_interface', 'default_gateway', 'interfaces']:
        assert k in hpux_network_facts

# Generated at 2022-06-22 23:59:17.973336
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    n = HPUXNetwork()

    expected_value = {'lan0': {'ipv4': {'network': '172.22.5.0/24',
                                        'interface': 'lan0',
                                        'address': '172.22.5.50'},
                               'device': 'lan0'},
                      'lan1': {'ipv4': {'network': '172.22.22.0/24',
                                        'interface': 'lan1',
                                        'address': '172.22.22.22'},
                               'device': 'lan1'}}
    obtained_value = n.get_interfaces_info()

    assert obtained_value == expected_value



# Generated at 2022-06-22 23:59:21.815331
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    iface = HPUXNetwork()
    assert iface.get_default_interfaces() == {'default_gateway': '172.18.10.1', 'default_interface': 'lan0'}


# Generated at 2022-06-22 23:59:22.429977
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork

# Generated at 2022-06-22 23:59:33.097302
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network_object = HPUXNetwork(module=AnsibleModule(argument_spec=dict()))

    network_object.module.run_command = MagicMock(
        side_effect=[(0, 'default 127.0.0.1 UG 1 0 en0', ''),
                     (0, 'default 192.168.42.42 UG 1 0 en1', '')]
    )
    default_interface = network_object.get_default_interfaces()

    assert default_interface['default_interface'] == 'en0'
    assert default_interface['default_gateway'] == '127.0.0.1'

    # Tests the case where there is no default gateway.

# Generated at 2022-06-22 23:59:34.314452
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    hpux_network = HPUXNetwork(module)
    hpux_network.populate()

# Generated at 2022-06-22 23:59:35.356755
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_network = HPUXNetworkCollector()
    assert fact_network._platform == 'HP-UX'

# Generated at 2022-06-22 23:59:41.649641
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Test if method get_interfaces_info works as expected."""
    class NetstatStdout:
        def __init__(self, data):
            self.data = data
            self.index = 0

        def readline(self):
            if self.index == len(self.data):
                return ''
            else:
                line = self.data[self.index]
                self.index += 1
                return line

    network = HPUXNetwork()

    # Test if method works as expected when input is a list of string.

# Generated at 2022-06-22 23:59:51.427145
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork(None)
    interfaces_info = {
        'lan0': {
            'ipv4': {
                'address': '192.168.0.1',
                'network': '192.168.0.0/16',
                'interface': 'lan0',
            },
            'device': 'lan0',
        },
        'lan1': {
            'ipv4': {
                'address': '192.168.1.1',
                'network': '192.168.1.0/16',
                'interface': 'lan1',
            },
            'device': 'lan1',
        },
    }

    test_interfaces_info = network.get_interfaces_info()
    assert test_interfaces_info == interfaces_info

# Generated at 2022-06-22 23:59:53.912410
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    collected_facts = {'default_interface': 'lan0'}
    net = HPUXNetwork(dict(), collected_facts)
    assert net.populate()['default_interface'] == 'lan0'

# Generated at 2022-06-22 23:59:55.952991
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeModule()
    HPUXNetwork(module)



# Generated at 2022-06-22 23:59:58.546169
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:00:00.719220
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork({})
    assert net.platform == 'HP-UX'


# Generated at 2022-06-23 00:00:02.398279
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-23 00:00:10.948794
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Test the method get_interfaces_info of class HPUXNetwork.
    """
    myhost = HPUXNetwork()
    interfaces = myhost.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['address'] == '10.46.73.10'
    assert interfaces['lan0']['ipv4']['network'] == '10.46.73.0'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-23 00:00:12.731662
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network is not None


# Generated at 2022-06-23 00:00:15.003353
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    test_HPUXNetwork = HPUXNetwork(module=test_module)
    default_interfaces = test_HPUXNetwork.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] >= '160.38.99.1'


# Generated at 2022-06-23 00:00:22.582370
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux.collector import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux.collector import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    # Mock module and say that netstat is available
    mock_module = Mock(spec=AnsibleModule)
    mock_module.get_bin_path.return_value = 'netstat_path_dummy'
    # Create the collector and the network facts object
    c = HPUXNetworkCollector(mock_module)
    f = HPUXNetwork(mock_module)
    # Mock of the run_command method that returns different output
    # depending on the command

# Generated at 2022-06-23 00:00:25.828346
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hHPUX = HPUXNetworkCollector()
    assert hHPUX.platform == 'HP-UX'
    assert hHPUX.fact_class == 'HPUXNetwork'

# Generated at 2022-06-23 00:00:29.241451
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = type('module', (object,), {})
    network_obj = HPUXNetwork(module)
    assert isinstance(network_obj, HPUXNetwork)


# Generated at 2022-06-23 00:00:35.895950
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    interfaces_output = """lan0      Link encap:Ethernet  HWaddr 00:95:69:E7:04:F9
      inet addr:10.0.0.2  Bcast:10.0.0.255  Mask:255.255.255.0
      UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
      RX packets:30718079 errors:0 dropped:0 overruns:0 frame:0
      TX packets:30140904 errors:0 dropped:0 overruns:0 carrier:0
      collisions:0 txqueuelen:1000
      RX bytes:31621443716 (29.5 GiB)  TX bytes:172722336773 (161.4 GiB)"""

# Generated at 2022-06-23 00:00:45.732354
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hp = HPUXNetwork()
    interfaces = hp.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'network': '172.16.122.0',
                                           'interface': 'lan0',
                                           'address': '172.16.122.182'}}
    assert interfaces['lan1'] == {'device': 'lan1',
                                  'ipv4': {'network': '172.16.123.0',
                                           'interface': 'lan1',
                                           'address': '172.16.123.182'}}



# Generated at 2022-06-23 00:00:57.255519
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(argument_spec={})
    m.get_bin_path = lambda x: '/usr/bin/netstat'
    m.run_command = lambda x: (0, '', '')
    m.load_file_common_arguments = lambda x: dict()
    collector = HPUXNetwork(module=m, collected_facts={})
    facts = collector.populate()
    assert facts['interfaces'] == ['lan0']
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '172.17.0.1'
    assert facts['lan0']['device'] == 'lan0'

# Generated at 2022-06-23 00:01:01.727891
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils import facts
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    network_collector = HPUXNetworkCollector()
    assert(isinstance(network_collector, facts.collector.BaseFactCollector))
    assert(isinstance(network_collector, facts.collector.NetworkCollector))

# Generated at 2022-06-23 00:01:11.721669
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    HPUXNetwork - populate
    """

    class TestFactsModule(object):
        def __init__(self):
            self.exit_json = mock.Mock(return_value=0)
            self.fail_json = mock.Mock(return_value=1)
            self.get_bin_path = mock.Mock(return_value="netstat")

    class TestNetwork(HPUXNetwork):
        '''
        Class to create HPUXNetwork object with mocked module parameter
        '''
        def __init__(self):
            self.module = TestFactsModule()

    test_network = TestNetwork()

# Generated at 2022-06-23 00:01:19.141759
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Create a HPUXNetwork instance ans test the populate method.
    """
    import os
    import imp
    module = imp.new_module('test_ansible_network_hpux')
    module.run_command = os.system
    module.get_bin_path = lambda x: '/usr/bin/netstat' if x == 'netstat' else None
    test_platform = 'HP-UX'
    test_instance = HPUXNetworkCollector(module, test_platform).collect()
    assert test_instance is not None
    assert test_instance['default_interface'] == 'lan2'
    assert test_instance['default_gateway'] == '10.24.3.1'
    assert test_instance['interfaces'] == ['lan3', 'lan2', 'lan1']

# Generated at 2022-06-23 00:01:30.062051
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}

# Generated at 2022-06-23 00:01:41.045715
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.network.hps_ux import HPUXNetwork
    from ansible.module_utils.facts.network.hp_ux import HPUXNetworkCollector

    iface = HPUXNetwork()
    values = {'out': ("default 192.168.1.1 UG 1 0 0 lan0",),
              'rc': 0,
              'err': ''}
    iface.module.run_command = lambda *args: values
    collected_facts = Collector().collect(HPUXNetworkCollector, [iface])

    iface_facts = collected_facts['ansible_facts']['ansible_network_resources']
    assert iface_facts['default_interface'] == 'lan0'

# Generated at 2022-06-23 00:01:45.968540
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hn = HPUXNetwork(dict(module=None))
    default_interfaces = hn.get_default_interfaces()
    assert default_interfaces
    assert default_interfaces['default_interface']
    assert default_interfaces['default_gateway']



# Generated at 2022-06-23 00:01:48.156043
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    testobj = HPUXNetwork()
    output = testobj.get_default_interfaces()
    assert 'default_interface' in output
    assert 'default_gateway' in output

# Generated at 2022-06-23 00:01:54.741150
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()

# Generated at 2022-06-23 00:02:03.631842
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    check_output = ['default 239.255.255.254 UG 2 0 0 lan1234',
                    '192.168.1.0 192.168.1.1 U 2 0 0 lan5678',
                    '240.0.0.0 240.255.255.255 U 0 0 - 0']

    m = HPUXNetwork()
    m.module.run_command = lambda args, **kw: (0, '\n'.join(check_output), '')
    default_interfaces = m.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan1234'
    assert default_interfaces['default_gateway'] == '239.255.255.254'



# Generated at 2022-06-23 00:02:05.866559
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net_obj = HPUXNetwork()
    assert net_obj.platform == 'HP-UX'


# Generated at 2022-06-23 00:02:10.054253
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module)

    network_facts = network_collector.collect()
    if network_facts['ansible_facts']:
        assert 'interfaces' in network_facts['ansible_facts']

# Generated at 2022-06-23 00:02:12.083499
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    h = HPUXNetwork()
    h.get_default_interfaces()

# Generated at 2022-06-23 00:02:19.259727
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    tests method get_default_interfaces of class HPUXNetwork
    """
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    out = """Routing Tables

Destination           Gateway           Flags Refs Use  If  Mtu  State Interface
default               192.168.1.1       UG        0 90976 1 lan0    1500  
192.168.1             127.0.0.1         UH       50 125   1 lo0      889     
"""
    stdout_mock = Mock(return_value=(0, out, ""))
    module.run_command = stdout_mock
    default_interfaces = network.get_default_interfaces()
    # I don't like that we have to use repr(), but that's necessary
    # to compare the

# Generated at 2022-06-23 00:02:22.585546
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert isinstance(collector._fact_class, HPUXNetwork)
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:02:34.070315
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    mod = AnsibleModule(argument_spec={})
    obj = HPUXNetwork(module=mod)
    interfaces = obj.get_default_interfaces()
    default_interfaces = {'default_interface': 'lan4',
                          'default_gateway': '10.68.64.1'}
    if interfaces != default_interfaces:
        raise Exception("Default interface and gateway do not match")
    interfaces = obj.get_interfaces_info()
    interface_info = {'lan4': {'device': u'lan4', 'ipv4': {'interface': u'lan4',
                                                           'network': u'10.68.64.0',
                                                           'address': u'10.68.64.101'}}}

# Generated at 2022-06-23 00:02:39.301654
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network = HPUXNetwork()
    network.module = FakeAnsibleModule()
    facts = network.populate()
    assert facts['default_interface'] == 'lan2'
    assert 'interfaces' in facts
    assert 'lan2' in facts['interfaces']
    assert 'lan0' in facts['interfaces']

# Helper class for unit test

# Generated at 2022-06-23 00:02:41.597323
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._platform == "HP-UX"
    assert hn._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:02:49.961037
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {'lan0':
                  {'device': 'lan0',
                   'ipv4':
                   {'address': '10.10.10.1',
                    'network': '10.10.10.0',
                    'interface': 'lan0'},
                   'ipv6': ['2001:db8::1']}}

    network = HPUXNetwork()
    network.module.run_command = lambda x, y=None: (0, interfaces, '')
    network_facts = network.get_interfaces_info()
    assert network_facts == interfaces



# Generated at 2022-06-23 00:03:00.976733
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts import ModuleDataLoader
    from ansible.module_utils.facts.utils import get_file_content
    import sys

    running_test_on_hpux = True
    if sys.platform != 'hp-ux11':
        running_test_on_hpux = False

    dummy_module_data_loader = ModuleDataLoader()
    data = {'ansible_module_name': 'dummy_module'}
    module = dummy_module_data_loader.load_module(data)

    network_facts = HPUXNetwork(module)
    facts = network_facts.populate()
    if running_test_on_hpux:
        assert 'interfaces' in facts
        assert 'lan0'

# Generated at 2022-06-23 00:03:08.709543
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import mock
    import os

    # Sample data of lan0 interface on HP-UX
    sample_out = """Name         Mtu    Net/Dest      Address        Ipkts/s        Ierrs/s Idrops/s  Ibytes/s   Opkts/s   Oerrs/s   Odrops/s  Obytes/s Collis/s
lan0          1500   default        1.2.3.4           0.0            0          0          0          0          0          0          0          0          0
lan2          1500   default        9.8.7.6           0.0            0          0          0          0          0          0          0          0          0"""

    # Collect data on mocked module
    module = mock.MagicMock(params={})

# Generated at 2022-06-23 00:03:19.999486
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Output of command /usr/bin/netstat -nr
    netstat_nr_out = """
    Routing tables
    Destination          Gateway             Flags Ref     Use If
    default              192.168.1.1         UG        0        0 lan1
    127.0.0.1            127.0.0.1           UH        0        0 lo0
    192.168.1.0          192.168.1.254       U         0        0 lan1
    192.168.1.254        192.168.1.254       UH        0        0 lan1
    """
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    test = HPUXNetwork()
    test.module.run_command = MagicMock(return_value=(0, netstat_nr_out))
   

# Generated at 2022-06-23 00:03:24.229639
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_module = HPUXNetwork(module)
    assert network_module.module is module
    assert network_module.platform == 'HP-UX'

# Generated at 2022-06-23 00:03:29.497606
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    n = HPUXNetwork(module=module)
    module.run_command = MagicMock(
        return_value=(0, 'default 192.168.0.1 UGS lan0\n', '')
    )
    facts = n.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '192.168.0.1'

# Generated at 2022-06-23 00:03:35.956952
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    interface_names = ['default_interface', 'default_gateway']
    test_get_default_interfaces = {'default_interface': "lan0",
                                   'default_gateway': "10.85.192.1"}
    assert test_get_default_interfaces == HPUXNetwork.get_default_interfaces(interface_names)


# Generated at 2022-06-23 00:03:40.858013
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hn = HPUXNetwork()
    hn.module.run_command = MagicMock(return_value=(0,
                                                    'default   172.17.0.1       UGS   lan1',
                                                    ''))
    default_interfaces_facts = hn.get_default_interfaces()
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts
    assert default_interfaces_facts['default_interface'] == 'lan1'
    assert default_interfaces_facts['default_gateway'] == '172.17.0.1'


# Generated at 2022-06-23 00:03:42.319804
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == "HP-UX"


# Generated at 2022-06-23 00:03:44.790890
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """ Returns platform name for HPUXNetworkCollector
    """
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 00:03:56.440291
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ Unit test for method populate of class HPUXNetwork """

    class HPUXNetwork_module_mock:

        def __init__(self, *args, **kwargs):
            self.run_command_args = []
            self.run_command_rc = [0, 0, 0]

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/netstat'

        def run_command(self, *args, **kwargs):
            self.run_command_args.append(args[0])
            return (self.run_command_rc.pop(0), '/usr/bin/netstat -niw', '')


# Generated at 2022-06-23 00:03:57.825497
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert isinstance(HPUXNetworkCollector(), NetworkCollector)

# Generated at 2022-06-23 00:04:00.890039
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = "AnsibleModule"
    module.run_command = lambda cmd: (0, '/usr/bin/netstat -nr', '')

    hpux_network = HPUXNetwork(module)
    default_interfaces_facts = hpux_network.get_default_interfaces()

    # Test that the method actually return something
    assert default_interfaces_facts
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts


# Generated at 2022-06-23 00:04:06.560288
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    fake_module = get_fake_module()
    network = HPUXNetwork(fake_module)
    interfaces = network.get_interfaces_info()
    assert interfaces['lan0'] == {'device': u'lan0', 'ipv4': {'network': u'10.0.2.0', 'interface': u'lan0', 'address': u'10.0.2.15'}}
    assert interfaces['lan1000'] == {'device': u'lan1000', 'ipv4': {'network': u'192.168.122.0', 'interface': u'lan1000', 'address': u'192.168.122.179'}}


# Generated at 2022-06-23 00:04:17.940898
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    hpux_network = HPUXNetwork(module)
    hpux_network.get_default_interfaces = MagicMock(return_value={
                                            'default_interface': 'lan0',
                                            'default_gateway': '10.100.100.1'
                                          })

# Generated at 2022-06-23 00:04:20.872681
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_obj = HPUXNetwork({})

    # Mock netstat command stdout
    netstat_str = '''
default 192.168.80.254 UG LAN0
'''
    test_obj.module.run_command = lambda x: (0, netstat_str, '')

    default_interface_facts = test_obj.get_default_interfaces()

    assert default_interface_facts['default_interface'] == 'LAN0'
    assert default_interface_facts['default_gateway'] == '192.168.80.254'



# Generated at 2022-06-23 00:04:27.280072
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())

    network_facts = HPUXNetwork(module)
    default_interfaces = network_facts.get_default_interfaces()

    facts_to_check = {'default_interface': 'lan1',
                      'default_gateway': '172.17.2.254'}

    for fact in facts_to_check:
        assert fact in default_interfaces
        assert default_interfaces[fact] == facts_to_check[fact]

# Generated at 2022-06-23 00:04:29.182789
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_facts = HPUXNetwork()

    assert network_facts.platform == 'HP-UX'


# Generated at 2022-06-23 00:04:34.343327
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interface_info = {'lan0': {'device': 'lan0',
                               'ipv4': {'address': '172.31.128.10',
                                        'interface': 'lan0',
                                        'network': '172.31.128.0'}}}
    rc, out, err = HPUXNetwork().module.run_command('/usr/bin/netstat -niw')
    assert HPUXNetwork().get_interfaces_info() == interface_info


# Generated at 2022-06-23 00:04:40.124371
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    # Constructor of class Network is tested in test_Network
    # Here we only test the constructor of the subclass
    # Constructor of class HPUXNetwork
    network = Network()
    hpux_network = HPUXNetwork(network)
    assert hpux_network.module == network.module

# Generated at 2022-06-23 00:04:47.756918
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork({})
    net.module = AnsibleModuleMock()
    result = net.get_interfaces_info()
    for key in result:
        assert result[key]['ipv4']['address']
        assert result[key]['ipv4']['network']
        assert result[key]['ipv4']['interface']
        result[key]['device'] == key
        assert result[key]['ipv4']['address']


# Generated at 2022-06-23 00:04:51.041103
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec=dict())
    hpux_network = HPUXNetwork(module=module)
    assert isinstance(hpux_network, Network)
    assert hpux_network.platform == 'HP-UX'



# Generated at 2022-06-23 00:04:51.833617
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-23 00:04:59.690322
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mock_module = MockNetworkModule()
    mock_module.params = {'gather_subset': '!all'}
    mock_module.run_command.side_effect = [
        (1, 'Not found', ''),
        (0, 'kernel_server:x:5:5:Kernel Build:/:/usr/bin/ksh', '')
        ]
    network_fact_instance = HPUXNetwork(mock_module)
    result = network_fact_instance.populate()
    assert result == {}


# Generated at 2022-06-23 00:05:04.766085
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpn = HPUXNetwork()
    hpn.module = FakeAnsibleModule()
    default_interfaces = hpn.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan1'
    assert default_interfaces['default_gateway'] == '192.168.1.254'


# Generated at 2022-06-23 00:05:15.785785
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for network.py.
    Testing the populate method of the HPUXNetwork class.
    """
    net_input = """default     172.16.0.0  172.16.255.255 UG   0   0        0 en1
172.16.0.0      172.16.255.255   U         1      0        0 en1
127.0.0.0        127.255.255.255 UH        5      0        0 lo0
172.16.18.0  172.16.18.255   U         1      0        0 en1
172.16.18.1  172.16.18.2     U         2      0        0 en1
172.16.18.2  172.16.18.1     U         1      0        0 en1
"""
    net_facts

# Generated at 2022-06-23 00:05:26.724684
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        check_invalid_arguments=False
    )
    network_facts = HPUXNetwork(module)
    network_facts.populate()

    assert network_facts.facts['default_interface'] == "lan1"
    assert network_facts.facts['default_gateway'] == "172.21.33.254"
    assert 'interfaces' in network_facts.facts.keys()
    assert 'lan0' in network_facts.facts['interfaces']

# Generated at 2022-06-23 00:05:38.582022
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    class MockNetwork(object):
        def __init__(self):
            pass

    class MockAnsibleModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False
            self._debug = False

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/netstat'


# Generated at 2022-06-23 00:05:49.748498
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class Module():
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = None
            self.run_command_out = None
            self.run_command_err = None

        def run_command(self, args):
            self.run_command_called = True
            self.run_command_args = args
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class Collected_facts_stub():
        def __init__(self):
            self.collected_facts = None

        def populate(self):
            self.collected_facts = {'os_family': 'unix'}
            return self.collected_facts

    # Expected out (netstat -niw out)
    out

# Generated at 2022-06-23 00:05:52.721776
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    mod = AnsibleModule(argument_spec=dict())
    net = HPUXNetwork(module=mod)
    result = net.get_default_interfaces()
    assert result['default_interface'] == 'lan0'


# Generated at 2022-06-23 00:05:56.698701
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.six.moves import StringIO

    module = FakeModule()
    network = HPUXNetwork(module)
    assert network.default_interfaces_facts == {'default_gateway': '10.10.10.1',
                                                'default_interface': 'lan2'}



# Generated at 2022-06-23 00:06:04.471136
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector.__module__ == 'ansible.module_utils.facts.network.hpux'
    assert HPUXNetworkCollector.__name__ == 'HPUXNetworkCollector'
    assert HPUXNetworkCollector._fact_class.__module__ == 'ansible.module_utils.facts.network.hpux'
    assert HPUXNetworkCollector._fact_class.__name__ == 'HPUXNetwork'
    assert HPUXNetworkCollector._platform == 'HP-UX'


# Generated at 2022-06-23 00:06:12.353596
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import json
    import sys
    import os
    import subprocess

    syspath = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../lib/ansible/module_utils/facts/network'))
    if syspath not in sys.path:
        sys.path.append(syspath)
    from hpux_network import HPUXNetwork

    network = HPUXNetwork(None)

    # We mock the os.path.exists function with our own function
    def mock_exists(path):
        return True
    network.module.os.path.exists = mock_exists

    # We mock the subprocess.Popen function with our own function