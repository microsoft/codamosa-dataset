

# Generated at 2022-06-22 23:56:07.967774
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod = AnsibleModule(
        argument_spec=dict()
    )
    net_collector = HPUXNetwork(module=mod)
    assert isinstance(net_collector, HPUXNetwork)

# Generated at 2022-06-22 23:56:17.661909
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    mod = lambda *args, **kwargs: None
    mod.run_command = lambda *args, **kwargs: (0, "lan0: flags=104843<UP,BROADCAST,RUNNING,ALLMULTI,IPv4> mtu 1500 index 1\n         inet 10.10.10.1 netmask ff000000 broadcast 0.0.0.0\n", '')
    hp = HPUXNetwork(module=mod)
    assert hp.get_interfaces_info() == {'lan0': {'ipv4': {'network': '10.10.10.1', 'address': '10.10.10.1', 'interface': 'lan0'}, 'device': 'lan0'}}

# Generated at 2022-06-22 23:56:22.235282
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Checking if all variables are set/initialized properly"""
    collector = HPUXNetworkCollector()

    assert collector.identifier == 'HPUX'
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-22 23:56:32.225400
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = Mock()
    module.run_command = Mock()
    module.run_command.return_value = (0, 'lan100        32        0         828        816        742   1500   0   0  lan100', '')

    network_facts = HPUXNetwork(module)
    expected_interfaces = {'lan100': {'ipv4': {'network': '742',
                                               'interface': 'lan100',
                                               'address': '816'},
                                     'device': 'lan100'}}
    interfaces = network_facts.get_interfaces_info()
    assert interfaces == expected_interfaces

    module.run_command.assert_called_with('/usr/bin/netstat -niw')

# Generated at 2022-06-22 23:56:43.494879
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ModuleMock(object):
        def get_bin_path(self, cmd):
            return 'cmd'


# Generated at 2022-06-22 23:56:46.698799
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    fact_network = HPUXNetwork(module)
    assert fact_network.__doc__ is not None
    assert fact_network.platform == 'HP-UX'


# Generated at 2022-06-22 23:56:48.662064
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Create an instance of HPUXNetwork
    h = HPUXNetwork()
    # Check if instance was created successfully
    assert h


# Generated at 2022-06-22 23:56:52.374036
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._fact_class == HPUXNetwork
    assert hpux_network_collector._platform == 'HP-UX'

# Generated at 2022-06-22 23:56:55.076469
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    hpux_network = HPUXNetwork(module)
    hpux_network.populate()


# Generated at 2022-06-22 23:56:57.160737
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    obj = network_collector._fact_class()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-22 23:56:59.573293
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu_net = HPUXNetwork(None)
    assert hpu_net.platform == 'HP-UX'


# Generated at 2022-06-22 23:57:02.328338
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork({'PATH': '', 'ANSIBLE_MODULE_ARGS': {}, 'ANSIBLE_MODULE_UTILS': ''})
    assert h.platform == 'HP-UX'


# Generated at 2022-06-22 23:57:04.390892
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    x = HPUXNetworkCollector()
    assert type(x) == HPUXNetworkCollector

# Generated at 2022-06-22 23:57:14.165627
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import module_executor
    test_module = NetworkCollector()
    module = test_module.init_module()
    test_class = HPUXNetwork(module)
    test_result = test_class.get_interfaces_info()
    expected_result = {'lan1': {'ipv4': {'network': '172.18.97.0',
                                           'address': '172.18.97.1',
                                           'interface': 'lan1'},
                                   'device': 'lan1'}}
    assert test_result == expected_result


# Generated at 2022-06-22 23:57:16.455931
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    module = AnsibleModule(
        argument_spec=dict()
    )

    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '172.16.232.1'



# Generated at 2022-06-22 23:57:25.225272
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockAnsibleModule()
    network = HPUXNetwork(module=module)
    module.run_command.return_value = 0, '', ''
    collected_facts = {}

# Generated at 2022-06-22 23:57:35.806635
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Simple test for method get_interfaces_info
    """
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'network']
            self.exit_json = MagicMock(return_value={})
            self.run_command = MagicMock(return_value=(0, '', ''))

    m = FakeModule()

    iface = HPUXNetwork(m)
    interfaces = iface.get_interfaces_info()

    assert len(interfaces) > 0
    assert 'lan0' in interfaces
    assert interfaces['lan0'].get('device') == 'lan0'

    print('HPUXNetwork.get_interfaces_info passed')


# unit test for HPUXNetwork.get

# Generated at 2022-06-22 23:57:47.018489
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network_facts = {}
    network_facts['default_interface'] = 'lan0'
    network_facts['default_gateway'] = '9.160.254.1'
    network_facts['interfaces'] = ['lan0', 'lan1', 'lan2']
    network_facts['lan0'] = {'ipv4': {'network': '9.160.254.0',
                                      'interface': 'lan0',
                                      'address': '9.160.254.109'}}
    network_facts['lan1'] = {'ipv4': {'network': '10.160.254.0',
                                      'interface': 'lan1',
                                      'address': '10.160.254.100'}}

# Generated at 2022-06-22 23:57:48.902481
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-22 23:58:00.511616
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})

    network = HPUXNetwork()
    network.module = module
    network.module.run_command = mock.MagicMock()
    network.module.run_command.return_value = (0, "default 192.168.0.1 UGS HP-UX-10.0.0.0-1-default-client  WAN 192.168.0.1", None)

    expected_facts = {'default_interface': 'HP-UX-10.0.0.0-1-default-client', 'default_gateway': '192.168.0.1'}
    facts = network.get_default_interfaces()
    assert facts == expected_facts



# Generated at 2022-06-22 23:58:02.056573
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.populate() is not None

# Generated at 2022-06-22 23:58:13.654833
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class ModuleMock(object):
        def __init__(self):
            self.run_command_args = None
            self.run_command_rc = None
            self.run_command_out = None
            self.run_command_err = None

        def run_command(self, args, check_rc=True):
            self.run_command_args = args
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    module = ModuleMock()
    module.run_command_rc = 0

# Generated at 2022-06-22 23:58:18.733441
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    interface_collector = HPUXNetwork(module=module)
    interface_collector.populate()

    assert interface_collector.interfaces is not None

# Generated at 2022-06-22 23:58:23.474265
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net.populate()["interfaces"][0] == "lan0"
    assert net.populate()["default_interface"] == "lan0"
    assert net.populate()["default_gateway"] == "172.31.0.1"
    assert net.populate()["lan0"]["ipv4"]["address"] == "172.31.0.3"

# Generated at 2022-06-22 23:58:27.242994
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpu = HPUXNetwork()
    netstat = hpu.module.run_command.call_args[0][0]
    assert netstat.startswith('/usr/bin/netstat')

# Generated at 2022-06-22 23:58:31.805258
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}
    device = "lan3"
    address = "192.168.1.1"
    network = "192.168.1.0"
    intf = {'device': device, 'ipv4': {'network': network,
                                       'interface': device,
                                       'address': address}}
    interfaces = {device: intf}


# Generated at 2022-06-22 23:58:40.752113
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock({})
    obj = HPUXNetwork(module)
    result = obj.populate()

    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.64.32.225'
    assert result['interfaces'] == ['lan0']
    assert result['device'] == 'lan0'
    assert result['network'] == '10.64.32.'
    assert result['address'] == '10.64.32.174'

# Generated at 2022-06-22 23:58:48.993441
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {'lan0': {'ipv4': {'address': '10.0.0.10',
                                    'network': '10.0.0.0',
                                    'interface': 'lan0'}},
                  'lan1': {'ipv4': {'address': '10.0.1.10',
                                    'network': '10.0.1.0',
                                    'interface': 'lan1'}}
                  }
    hpn = HPUXNetwork()
    hpn.module = MockModule()
    assert hpn.get_interfaces_info() == interfaces



# Generated at 2022-06-22 23:58:56.350751
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpux_network = HPUXNetwork({'module':None})
    interfaces = hpux_network.get_interfaces_info()
    assert 'lan0' in interfaces
    lan0 = interfaces['lan0']
    assert lan0['device'] == 'lan0'
    assert lan0['ipv4']['address'] == '10.0.0.1'
    assert lan0['ipv4']['network'] == '10.0.0.0'
    assert lan0['ipv4']['interface'] == 'lan0'
    assert lan0['ipv4']['address'] == '10.0.0.1'


# Generated at 2022-06-22 23:59:07.795115
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_string = ' Routing Table: IPv4\n'
    test_string += '                Destination           Gateway           Flags  Refs Use If\n'
    test_string += '                                    Interface\n'
    test_string += 'default         192.0.2.1             172.16.1.1                 1     0 16 lan1\n'
    test_string += '127.0.0.0       127.0.0.1             127.0.0.1                 1     0 16 lo0\n'
    test_string += '172.16.1.0      172.16.1.1             172.16.1.1                 1     0 16 lan1\n'

# Generated at 2022-06-22 23:59:17.284627
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network = HPUXNetwork()
    network.module = AnsibleModule(argument_spec=dict())

    network.module.run_command = Mock(return_value=(0, "hello", ""))
    network.get_default_interfaces = Mock(return_value=dict(default_interface='lan0', default_gateway='1.1.1.1'))
    network.get_interfaces_info = Mock(return_value=dict(lan0=dict(ipv4=dict(address='1.1.1.1', network='1.1.0.0'))))
    network.populate()
    network.module.run_command.assert_called_with('/usr/bin/netstat -niw')
    network.module.run_command.assert_called_with('/usr/bin/netstat -nr')


# Generated at 2022-06-22 23:59:25.023209
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class FakeModule(object):
        def run_command(self, cmd):
            if cmd == '/usr/bin/netstat -niw':
                return 0, netstat_out, ''
            else:
                raise ValueError('unexpected command: %s' % cmd)
    class FakeNetwork(HPUXNetwork):
        def __init__(self):
            self.module = FakeModule()

    net = FakeNetwork()
    net.get_interfaces_info()

# Generated at 2022-06-22 23:59:26.024564
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-22 23:59:33.416617
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.network.\
        hpux.network import HPUXNetwork
    module = AnsibleModule(argument_spec={})
    network_obj = HPUXNetwork(module=module)
    facts = network_obj.populate()
    assert facts.get('default_interface') is not None
    assert facts.get('default_gateway') is not None
    assert facts.get('interfaces') is not None
    assert facts.get('lan0') is not None



# Generated at 2022-06-22 23:59:40.273924
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    network_facts = {'interfaces': ['lan0', 'lan1'],
                     'lan0': {'ipv4': {'address': '10.10.10.10',
                                       'network': '10.10.10.0',
                                       'interface': 'lan0'},
                              'device': 'lan0'},
                     'lan1': {'ipv4': {'address': '10.10.10.11',
                                       'network': '10.10.10.0',
                                       'interface': 'lan1'},
                              'device': 'lan1'}}
    module = AnsibleModule('')
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert interfaces == network_

# Generated at 2022-06-22 23:59:51.004846
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeModule()
    # Fake command output
    module.run_command.return_value = (0, """
Name  Mtu  Net/Dest      Address    Ipkts  Ierrs Opkts  Oerrs Coll  Queue
lan0  1500  default  172.16.101.34   372755     0  67591     0    0    8
lan1  1500  default  172.16.101.37   106772     0  52112     0    0    8
lan2  1500  default  172.16.101.10   162755     0  62691     0    0    8
""", "")

    hpuxtest = HPUXNetwork(module)
    interfaces_info = hpuxtest.get_interfaces_info()

# Generated at 2022-06-22 23:59:57.858154
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    # Stub module execute call.
    module.run_command = run_command
    # Construct HPUXNetwork
    network = HPUXNetwork(module)
    # Check the facts returned by the method
    assert network.get_interfaces_info() == {'lan0': {'ipv4': {'interface': 'lan0', 'network': '192.168.1.0', 'address': '192.168.1.100'}, 'device': 'lan0'}}



# Generated at 2022-06-23 00:00:02.352402
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    default_interfaces_facts = network.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan1'
    assert default_interfaces_facts['default_gateway'] == '172.16.0.1'

# Generated at 2022-06-23 00:00:04.399690
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    assert h._fact_class == HPUXNetwork._fact_class
    assert h._platform == HPUXNetwork._platform

# Generated at 2022-06-23 00:00:12.422071
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all', '!min'], type='list'))
    )

    network_collector = HPUXNetworkCollector(module=module)
    network_collector.collect()
    network_facts_instance = network_collector.get_facts()['ansible_network']
    assert isinstance(network_facts_instance, Network)


# Generated at 2022-06-23 00:00:19.988941
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils._text import to_bytes

    network = HPUXNetwork()
    network.module.run_command = lambda arg: (0, to_bytes("""
default 192.168.100.1 UG    1 37 lan3
10.0.0.0             192.168.100.0     U       1      0 lan3
"""), '')
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan3', 'default_gateway': '192.168.100.1'}


# Generated at 2022-06-23 00:00:26.503105
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    net = HPUXNetwork({})
    output = {'default_interface': 'lan0',
              'default_gateway': '127.0.0.1'}
    assert net.get_default_interfaces() == output


# Generated at 2022-06-23 00:00:32.313493
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    facts = {'module': {'run_command': MagicMock(return_value=(0, netstat_out1, ''))
                        }
             }
    net = HPUXNetwork(facts=facts)
    result = net.get_default_interfaces()
    expected = {'default_interface': 'lan0',
                'default_gateway': '192.168.1.1'
                }
    assert result == expected



# Generated at 2022-06-23 00:00:34.681514
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'
    assert network.populate() == {}

# Generated at 2022-06-23 00:00:38.926762
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all', 'min'], type='list'))
    )
    network = HPUXNetwork(module)
    assert network



# Generated at 2022-06-23 00:00:42.534805
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()
    network_facts = net.populate()

    assert network_facts['default_gateway'] == '127.0.0.1'
    assert network_facts['default_interface'] == 'lo0'



# Generated at 2022-06-23 00:00:45.152408
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork({'module': {'get_bin_path': lambda x: '/usr/bin/netstat'}})
    net.get_default_interfaces()
    net.get_interfaces_info()

# Generated at 2022-06-23 00:00:57.213530
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import set_module_args, AnsibleFailJson
    module = AnsibleFailJson()

# Generated at 2022-06-23 00:01:01.033365
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module)
    network.get_default_interfaces = Mock(return_value={'default_interface': 'test_interface', 'default_gateway': 'test_gateway'})

    assert(network.get_default_interfaces() == {'default_interface': 'test_interface', 'default_gateway': 'test_gateway'})



# Generated at 2022-06-23 00:01:04.472435
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = FakeModule()
    test_module.run_command = FakeCommand
    test_hpux = HPUXNetwork(test_module)

    test_hpux.get_interfaces_info()


# Generated at 2022-06-23 00:01:08.394398
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_object = HPUXNetwork()
    result = test_object.get_default_interfaces()
    assert result['default_interface'] == 'lan1234'
    assert result['default_gateway'] == '10.10.10.1'



# Generated at 2022-06-23 00:01:09.974481
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert 'default_interface' in network
    assert 'interfaces' in network

# Generated at 2022-06-23 00:01:11.843791
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModuleStub()
    hpux_net = HPUXNetwork(module)
    assert hpux_net._module == module


# Generated at 2022-06-23 00:01:13.013406
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    instance = HPUXNetwork()

    assert instance is not None

# Generated at 2022-06-23 00:01:17.887294
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    net = HPUXNetwork(module=module)
    net.get_default_interfaces()
    assert module.run_command.call_count == 1
    for call in module.run_command.call_args_list:
        cmd = call[0][0]
        assert cmd == '/usr/bin/netstat -nr'
        stdout_value = call[0][1]
        assert stdout_value == 'default ??????????????? ?????????????? lan1'


# Generated at 2022-06-23 00:01:20.264604
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork(None)
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-23 00:01:23.249802
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._fact_class == HPUXNetwork
    assert hpux_network_collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:01:27.669737
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = HPUXNetwork(mock_module)
    default_interfaces = {'default_interface': 'lan0',
                          'default_gateway': '10.0.2.2'}
    assert m.get_default_interfaces() == default_interfaces



# Generated at 2022-06-23 00:01:35.660628
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    class TestModule(object):
        def get_bin_path(self, path, opt_dirs=[]):
            return '/usr/bin/netstat'

        def run_command(self, cmd):
            return (0,
"""Routing tables
Destination        Gateway        Flags      Refs     Use     Interface
default            192.168.0.1    UGS         0        24     lan0
localnet           link#1         U           0        23     lan0
192.168.0.0        link#1         U           0        65     lan0
#lo0         localhost
""", '')

    module = TestModule()

    network = HPUXNetwork()
    network.populate(module)

    assert network.default_gateway == '192.168.0.1'

# Generated at 2022-06-23 00:01:37.519351
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector(None)

    assert hpux.platform == 'HP-UX'

# Generated at 2022-06-23 00:01:42.898584
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test = HPUXNetwork()
    assert test.get_interfaces_info() == {'lan3': {'ipv4': {'address': '10.0.1.4', 'network': '10.0.1.0', 'interface': 'lan3'}, 'device': 'lan3'}}

# Generated at 2022-06-23 00:01:44.378380
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network.platform == 'HP-UX'
    assert network.fact_class == HPUXNetwork


# Generated at 2022-06-23 00:01:50.384916
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = AnsibleModule(argument_spec={})
    instances = [HPUXNetwork()]
    ansible_facts = {'ansible_net_version': "hpux11i-v2"}
    results = dict(changed=False, ansible_facts=ansible_facts)
    module = NetworkCollector(m, results, Network=instances[0])
    module.populate_fact_cache()

    assert "default_interface" in results['ansible_facts']
    assert "default_gateway" in results['ansible_facts']



# Generated at 2022-06-23 00:01:55.818481
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    net = HPUXNetwork(module)
    defaults = net.get_default_interfaces()
    assert defaults['default_interface'] == 'lan1'
    assert defaults['default_gateway'] == '129.158.10.1'



# Generated at 2022-06-23 00:01:59.787460
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor for HP-UX Network Collector.
    """
    obj = HPUXNetworkCollector()
    assert obj.platform == 'HP-UX'
    assert issubclass(obj.fact_class, HPUXNetwork)
    assert obj.fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 00:02:06.251204
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict(name=dict(required=True, type='str'),
                                              state=dict(required=True, type='str')))
    net = HPUXNetwork()
    default_interfaces = net.get_default_interfaces()
    module.exit_json(changed=False,
                     ansible_facts=dict(default_interfaces=default_interfaces))


# Generated at 2022-06-23 00:02:11.912657
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = Mock()
    module.run_command = mock_run_command
    hpux_network = HPUXNetwork(module)
    interfaces = hpux_network.get_default_interfaces()
    assert interfaces == {'default_interface': 'lan7',
                          'default_gateway': '10.13.99.1'}


# Generated at 2022-06-23 00:02:22.337889
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Testing the creation of a HPUXNetwork object and testing
    the correctness of its attributes by comparing the keys
    and values of the facts populated by the populate method with
    those expected.
    """

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_collector = HPUXNetworkCollector(module=module)
    network_facts_list = network_collector.collect()
    network_facts = network_facts_list[0]

    assert set(network_facts.keys()) == set(['default_interface',
                                             'default_gateway',
                                             'interfaces',
                                             'lan0',
                                             'lan1000'])

    assert network_facts['default_interface'] == 'lan1000'
    assert network_facts

# Generated at 2022-06-23 00:02:26.916238
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    if HPUXNetworkCollector._platform != 'HP-UX':
        raise AssertionError("_platform must be 'HP-UX'")
    if HPUXNetworkCollector._fact_class is None:
        raise AssertionError("_fact_class must be a class")

# Generated at 2022-06-23 00:02:27.520694
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    pass

# Generated at 2022-06-23 00:02:38.529725
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    EXPECTED_DEFAULT_INTERFACES_FACTS = {u'default_interface': u'lan0',
                                         u'default_gateway': u'10.17.98.1'}

    def get_bin_path(name):
        return '/usr/bin/netstat'

    class Module():
        def __init__(self):
            pass

        def run_command(self, cmd, check_rc=True):
            return 0, FACT_NETSTAT_OUTPUT, ''

        def get_bin_path(self, name):
            return get_bin_path(name)

    module = Module()
    obj = HPUXNetwork()
    obj.module = module

    default_interfaces_facts = obj.get_default_interfaces()
    assert default_interfaces_facts == EXP

# Generated at 2022-06-23 00:02:49.388960
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os
    import sys
    import unittest
    sys.path.insert(0, os.path.abspath('../../../lib'))
    from ansible.module_utils.facts.network import HPUXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    class TestHPUXNetworkCollector(unittest.TestCase):
        def setUp(self):
            self.collector = HPUXNetworkCollector()

        def test_get_interfaces_info_success(self):
            # Input data
            test_data = "lan0      lan0        192.168.100.0    255.255.255.0   UP       1500"

            # Expected result

# Generated at 2022-06-23 00:03:00.420573
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/netstat'

        def run_command(self, *args, **kwargs):
            return self.rc, self.out, self.err


# Generated at 2022-06-23 00:03:02.704474
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    my_test = HPUXNetworkCollector()
    my_test._platform = "HP-UX"
    assert my_test._platform == "HP-UX"



# Generated at 2022-06-23 00:03:03.837491
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpuxNetworkCollector = HPUXNetworkCollector()
    assert hpuxNetworkCollector is not None


# Generated at 2022-06-23 00:03:15.298373
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestClassHPUXNetwork():
        def run_command(self, command):
            return (0, 'default 192.168.1.1 u23 0 104478     lan24', '')
        def get_bin_path(self, command):
            return "/usr/bin/netstat"

    test_class_HPUXNetwork = TestClassHPUXNetwork()

    hpuxNetwork = HPUXNetwork()
    hpuxNetwork.module = test_class_HPUXNetwork
    default_interfaces = hpuxNetwork.get_default_interfaces()
    assert default_interfaces == {u'default_interface': 'lan24',
                                  u'default_gateway': '192.168.1.1'}


# Generated at 2022-06-23 00:03:26.858877
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Test with no arguments - will use system facts
    c = HPUXNetworkCollector()
    assert c.facts['default_interface'] == 'lan0'
    assert c.facts['default_gateway'] == '10.1.1.1'
    assert c.facts['interfaces'] == ['lan0', 'lan1', 'lan2']
    assert c.facts['lan0']['device'] == 'lan0'
    assert c.facts['lan1']['device'] == 'lan1'
    assert c.facts['lan2']['device'] == 'lan2'
    assert ('ipv4' in c.facts['lan0'])
    assert ('ipv4' in c.facts['lan1'])
    assert ('ipv4' in c.facts['lan2'])

# Generated at 2022-06-23 00:03:29.240479
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    testobj = HPUXNetwork(module)
    out = testobj.populate()
    assert out['default_interface'] == 'lan0'

# Generated at 2022-06-23 00:03:30.512546
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    pass

# Generated at 2022-06-23 00:03:31.855234
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:03:41.882219
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    tmpdir = tempfile.mkdtemp()
    path = os.path.join(tmpdir, 'netstat')

# Generated at 2022-06-23 00:03:43.999105
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpu import HPUXNetwork
    obj = HPUXNetwork()
    return obj.get_default_interfaces()


# Generated at 2022-06-23 00:03:52.194173
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module = AnsibleModule(argument_spec={})
    net.module.run_command = run_command
    net.module.get_bin_path = get_bin_path
    net.module.params = {'gather_subset': ['']}
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan1'
    assert default_interfaces['default_gateway'] == '10.1.1.1'



# Generated at 2022-06-23 00:04:02.431182
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mod = AnsibleModuleMock()
    mod.run_command = run_command_mock
    mod.get_bin_path = get_bin_path_mock
    mod.params = {}
    mod.params['gather_subset'] = ['default']
    mod.params['gather_network_resources'] = ['all']
    mod.params['filter'] = ''

    net_obj = HPUXNetwork(module=mod)
    network_facts = net_obj.populate()
    assert network_facts['default_interface'] == 'lan3'
    assert network_facts['default_gateway'] == '10.76.50.1'
    assert network_facts['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3']

# Generated at 2022-06-23 00:04:06.384102
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'

# Generated at 2022-06-23 00:04:13.733043
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    '''
    Returns a NetworkCollector with the initialized fact for HP-UX OS.
    '''
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    module = FakeAnsibleModule()
    network_collector = HPUXNetworkCollector(module)
    network_fact = network_collector.collect()
    network = HPUXNetwork()

    assert network_fact == network.populate()



# Generated at 2022-06-23 00:04:19.903042
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.__class__.__name__ == 'HPUXNetworkCollector'
    assert network_collector._fact_class.__name__ == 'HPUXNetwork'
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-23 00:04:20.958268
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:04:24.977851
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {'lan0': {'device': 'lan0',
                           'ipv4': {'network': '172.16.1.0',
                                    'address': '172.16.1.1'}}}
    assert HPUXNetwork().get_interfaces_info() == interfaces

# Generated at 2022-06-23 00:04:33.724108
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network_facts_object = HPUXNetwork()
    network_facts_object.module = AnsibleModule(
        argument_spec={})
    network_facts_object.get_default_interfaces = MagicMock(
        return_value={'default_interface': 'ip.0',
                      'default_gateway': '10.88.88.1'})
    network_facts_object.get_interfaces_info = MagicMock(
        return_value={'lan0': {'device': 'lan0',
                    'ipv4': {'address': '10.88.88.11',
                             'network': '10.88.88.0',
                             'interface': 'lan0'}}})


# Generated at 2022-06-23 00:04:36.364974
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:04:47.715938
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts import FactModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.pycompat24 import get_exception
    import json

    class MockModule:
        def __init__(self):
            self.fail_json = lambda **kwargs: None
            self.run_command = MockModule.run_command
            self.params = {'gather_network_resources': 'no'}


# Generated at 2022-06-23 00:04:58.861683
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    out1 = 'default 10.0.2.2 UG 1 0 lan2' + '\n'
    out2 = 'lan0 192.168.122.0 U 1 0 lan0' + '\n'
    out3 = 'lan1 192.168.123.0 U 1 0 lan1' + '\n'
    out4 = 'lan2 192.168.2.0 U 1 0 lan2' + '\n'
    out5 = 'lan3 192.168.5.0 U 1 0 lan3' + '\n'
    netstat_path = '/usr/bin/netstat'

    def netstat(self, *command):
        module = self
        command = list(command)
        command.insert(0, netstat_path)
        rc, out, err = module.run_command(command)
       

# Generated at 2022-06-23 00:05:07.143415
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )
    obj = HPUXNetwork()
    obj.module = m

    rc, out, err = m.run_command("/usr/bin/netstat -niw")
    network_facts = obj.populate(True)
    assert network_facts['default_gateway'] == '192.168.1.1'
    assert network_facts['default_interface'] == 'lan0'
    assert len(network_facts['interfaces']) == 2
    assert network_facts['interfaces'][0] == 'lan0'
    assert network_facts['interfaces'][1] == 'lan1'
    assert network_facts['lan0']['device'] == 'lan0'

# Generated at 2022-06-23 00:05:18.571576
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    '''Unit test for method get_interfaces_info of class HPUXNetwork'''
    hn = HPUXNetwork()

    interfaces = {}
    rc, out, err = hn.module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        for i in range(len(words) - 1):
            if words[i][:3] == 'lan':
                device = words[i]
                interfaces[device] = {'device': device}
                address = words[i + 3]
                interfaces[device]['ipv4'] = {'address': address}
                network = words[i + 2]

# Generated at 2022-06-23 00:05:25.813659
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:05:37.806918
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    network = HPUXNetwork(module)

    rc, out, err = module.run_command.return_value
    netstat_path = module.get_bin_path.return_value
    if netstat_path is not None:
        default_interfaces = network.get_default_interfaces()
        interfaces = network.get_interfaces_info()
        network_facts = network.populate()

    module.run_command.assert_called_with("/usr/bin/netstat -niw")
    assert network_facts['default_interface'] == "lan0"
    assert network_facts['default_gateway'] == "192.168.0.1"
    assert network_facts['default_interface'] == "lan0"

# Generated at 2022-06-23 00:05:45.318086
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module)
    network.get_default_interfaces = Mock(return_value={'default_gateway': '192.168.5.5', 'default_interface': 'lan0'})

    assert network.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '192.168.5.5'}



# Generated at 2022-06-23 00:05:47.824728
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hpux_net = HPUXNetwork()
    hpux_net.module = module

# Generated at 2022-06-23 00:05:49.940288
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    n = HPUXNetwork()
    assert n.platform == 'HP-UX'

# Generated at 2022-06-23 00:05:58.413240
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=None, type='list')
        }
    )

    p = HPUXNetwork(module)
    facts = p.populate()
    assert 'interfaces' in facts
    assert 'default_interface' in facts
    assert facts['default_interface'] == 'lan1'
    assert facts['default_gateway'] == '192.168.0.6'
    assert 'lo0' in facts['interfaces']
    assert 'lan0' in facts['interfaces']
    assert 'lan1' in facts['interfaces']
    assert 'lan2' in facts['interfaces']
    assert 'lan3' in facts['interfaces']
    assert 'lan4' in facts['interfaces']

# Generated at 2022-06-23 00:06:02.864379
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Test without netstat
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[]),
        'filter': dict(default=None)})
    module.params['filter'] = list()
    module.params['gather_subset'] = None

    tmp = HPUXNetwork(module)
    result = tmp.populate()
    assert result == {}, \
        'Empty result when netstat is not found'

    # Test with netstat
    module.get_bin_path = lambda x: '/usr/bin/netstat'

# Generated at 2022-06-23 00:06:06.841420
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_network = HPUXNetwork()
    test_network.module = AnsibleModuleStub()
    assert test_network.get_default_interfaces() == \
           {'default_gateway': '172.31.254.1', 'default_interface': 'lan2'}
