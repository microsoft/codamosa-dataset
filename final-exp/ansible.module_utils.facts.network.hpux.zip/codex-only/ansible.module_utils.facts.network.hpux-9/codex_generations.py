

# Generated at 2022-06-22 23:56:07.159342
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork(None, None)
    assert hpux_network.platform == "HP-UX"

# Generated at 2022-06-22 23:56:18.042310
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class HPUXNetwork
    """
    # initialize test instance of HPUXNetwork
    net = HPUXNetwork()

    # mock input string returned by HP-UX netstat -nr
    netstat_nr_out = """\
default 192.168.1.1 UGS lan0
default 192.168.2.1 UGS lan1
default 192.168.3.1 UGS lan2
default 192.168.4.1 UGS lan3
"""
    net.netstat_nr_out = netstat_nr_out
    # test call of method get_default_interfaces
    default_interfaces = net.get_default_interfaces()
    assert len(default_interfaces) == 2
    assert default_interfaces.has_key("default_interface")
   

# Generated at 2022-06-22 23:56:24.441343
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'src': {'required': False, 'default': ''}})
    hpux_network = HPUXNetwork(module)
    expected_default_interfaces = {'default_interface': u'lan5', 'default_gateway': u'10.0.0.1'}
    assert hpux_network.get_default_interfaces() == expected_default_interfaces



# Generated at 2022-06-22 23:56:28.189836
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    interfaces = net.get_interfaces_info()
    assert type(interfaces) is dict
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces


# Generated at 2022-06-22 23:56:38.446695
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockModule()
    interface_info = HPUXNetwork(module)
    netstat_out = {'msg': '', 'rc': 0, 'stderr': '',
                   'stdout': 'lan0    link#28    0    lan0    150.10.1.254    '
                   '150.10.1.0          U    1500    0            0 lan0'}
    module.run_command.return_value = netstat_out

    result = interface_info.get_interfaces_info()
    assert result == {'lan0': {'device': 'lan0',
                               'ipv4': {'address': '150.10.1.254',
                                        'interface': 'lan0',
                                        'network': '150.10.1.0'}}}

# Generated at 2022-06-22 23:56:39.055691
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork

# Generated at 2022-06-22 23:56:44.502721
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_collector = HPUXNetworkCollector(module)
    network_collector.collect()
    network = network_collector.get_device()
    assert network.platform == 'HP-UX'
    assert network_collector.get_device().platform == 'HP-UX'



# Generated at 2022-06-22 23:56:48.706076
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    fact_value = net.get_interfaces_info()
    assert fact_value['lan0']['ipv4']['address'] == '16.151.236.4'
    assert fact_value['lan0']['ipv4']['network'] == '16.151.236.0'



# Generated at 2022-06-22 23:57:00.122177
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network_module = AnsibleModule({})
    network_module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    network = HPUXNetwork(network_module)
    network.get_default_interfaces = MagicMock(return_value={'default_interface': 'lan0', 'default_gateway': '0.0.0.0'})

# Generated at 2022-06-22 23:57:02.755866
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_collector = HPUXNetworkCollector()
    assert isinstance(test_collector._fact_class, HPUXNetwork)
    assert test_collector._platform == 'HP-UX'

# Generated at 2022-06-22 23:57:05.128546
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c._platform == 'HP-UX'
    assert c._fact_class == HPUXNetwork

# Generated at 2022-06-22 23:57:14.213468
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    moduledir = os.path.dirname(__file__)
    filename = os.path.join(moduledir, 'resources/sample_netstat')
    module.run_command = MagicMock(return_value=(0, open(filename).read(), None))

    network = HPUXNetwork(module)
    net_facts = network.get_default_interfaces()
    assert net_facts == {'default_interface': 'lan0', 'default_gateway': '193.0.14.129'}


# Generated at 2022-06-22 23:57:23.493251
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network_facts = HPUXNetwork()

    interfaces = {
        'lan0': {'device': 'lan0', 'ipv4': {'address': '192.168.124.25', 'network': '192.168.124.0', 'interface': 'lan0'}},
        'lan1': {'device': 'lan1', 'ipv4': {'address': '192.168.124.26', 'network': '192.168.124.0', 'interface': 'lan1'}},
        'lan2': {'device': 'lan2', 'ipv4': {'address': '127.0.0.1', 'network': '127.0.0.0', 'interface': 'lan2'}},
    }


# Generated at 2022-06-22 23:57:27.825341
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network_facts = HPUXNetwork()
    interfaces = network_facts.get_interfaces_info()
    assert 'lan1' in interfaces
    assert 'lan0' in interfaces
    assert 'ipv4' in interfaces['lan1']

# Generated at 2022-06-22 23:57:33.148361
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Unit test for method populate of class HPUXNetwork"""

    class HPUXNetworkMock(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, path):
            return '/usr/bin/netstat'

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return '/usr/bin/netstat'

        def run_command(self, cmd):
            pass

    mod = AnsibleModuleMock()
    net = HPUXNetworkMock(mod)
    net_facts = net.populate()
    assert net_facts['default_interface'] == 'lan0'

# Generated at 2022-06-22 23:57:44.156292
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Arrange
    test_net = HPUXNetwork
    test_net.module = MagicMock()
    command = "/usr/bin/netstat -niw"
    test_net.module.run_command.return_value = (0, netstat_return_value, '')

# Generated at 2022-06-22 23:57:55.014892
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    net = HPUXNetwork()
    net.module = MockModule()

    default_interfaces = net.get_default_interfaces()
    assert default_interfaces['default_gateway'] == "10.0.2.2"

    interfaces = net.get_interfaces_info()
    assert "lan9" in interfaces
    assert interfaces['lan9']['ipv4']['network'] == "10.0.2"


# Generated at 2022-06-22 23:58:03.280243
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    fact_network = HPUXNetwork()
    fact_network.module = module
    fact_network.populate()
    assert module.run_command_called
    assert fact_network.facts == {'default_interface': 'lan0', 'default_gateway': '10.0.0.1', 'interfaces': ['lan0'], 'lan0': {'ipv4': {'address': '10.0.0.2', 'network': '10.0.0.0', 'interface': 'lan0'}, 'device': 'lan0'}}


# Generated at 2022-06-22 23:58:14.807488
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    nm = HPUXNetwork(module)
    network_facts = nm.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '172.22.33.1'

# Generated at 2022-06-22 23:58:16.380456
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    assert isinstance(hpn, HPUXNetwork)

# Generated at 2022-06-22 23:58:23.275395
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
            argument_spec=dict(
                gather_subset=dict(default=['!all'], type='list')
            ))
    network_facts = HPUXNetwork()
    network_facts.populate()
    interfaces = network_facts.interfaces

    for interface in interfaces:
        for key in ['ipv4', 'ipv6']:
            module.fail_json(msg='%s not present in network facts of %s' % (key, interface))



# Generated at 2022-06-22 23:58:29.352531
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpux_network = HPUXNetwork({})

    def mock_run_command(cmd):
        return 0, """lan0    stream    sock    dgram    raw      
lan1    stream    sock    dgram    raw      
lan2    stream    sock    dgram    raw""", ''


# Generated at 2022-06-22 23:58:31.623676
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    interfaces = HPUXNetwork().get_default_interfaces()
    assert 'default_interface' in interfaces
    assert 'default_gateway' in interfaces


# Generated at 2022-06-22 23:58:38.449469
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetworkCollector(ansible_module)
    network_facts = hpux_network.collect()
    # Verify there is no error on initialization
    assert hpux_network.ansible_module is not None
    # Verify that the expected variables are set
    assert hpux_network.platform == 'HP-UX'
    assert hpux_network._fact_class == HPUXNetwork
    # Verify that the gathered facts are what we expect
    assert type(network_facts['ansible_all_ipv4_addresses']) == list
    assert type(network_facts['ansible_all_ipv6_addresses']) == list

# Generated at 2022-06-22 23:58:40.478167
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network_collector = HPUXNetworkCollector(module=module)
    assert isinstance(network_collector.facts, HPUXNetwork)



# Generated at 2022-06-22 23:58:45.500910
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """ Check if the constructor works as expected """
    ansible_module = mock.MagicMock()
    ansible_module.get_bin_path.return_value = "/usr/bin/netstat"

    network = HPUXNetwork(ansible_module)
    assert network.platform == 'HP-UX'

# Generated at 2022-06-22 23:58:49.175734
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Test loading the HPUXNetworkCollector class."""
    hn = HPUXNetworkCollector()
    assert hn._fact_class == HPUXNetwork
    assert hn._platform == "HP-UX"


# Generated at 2022-06-22 23:58:55.587831
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ForTest:
        def __init__(self):
            pass

        def run_command(self, command):
            out = "default 192.168.0.254 UGSc lan3\ndefault 192.168.0.254 UGSc lan4\n"
            return 0, out, ''

    module = ForTest()

    network = HPUXNetwork(module)
    result = network.get_default_interfaces()
    assert result['default_interface'] == 'lan3'
    assert result['default_gateway'] == '192.168.0.254'


# Generated at 2022-06-22 23:59:07.016269
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    import os
    from ansible.module_utils.facts import collector

    # Create Network Collector
    collector._instance = HPUXNetworkCollector()

    # Run populate method
    ins = HPUXNetwork()

    # To see the difference
    ins.module.run_command = lambda self, x: [0, 'lan0      0  190  0  0  0    0    0    0    0    0   0    0    0    0', '']
    default_interfaces = ins.get_default_interfaces()

    # To see the difference
    ins.module.run_command = lambda self, x: [0, 'lan0      190  86  0  0  0    0    0    0    0    0   0    0    0    0', '']
    interfaces = ins.get_interfaces_info()

   

# Generated at 2022-06-22 23:59:13.199005
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    out = """Routing Tables:
Destination           Gateway           Flags Refs Use  Interface\n"""

    modules = {}
    module_name = os.path.splitext(os.path.basename(__file__))[0]
    module_args = {}
    modules[module_name] = module_args
    set_module_args(modules)

    default_interfaces = HPUXNetwork().get_default_interfaces()
    assert default_interfaces == {}


# Generated at 2022-06-22 23:59:15.909478
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fake_module = FakeModule()
    m = HPUXNetwork(module=fake_module)
    m.populate()

    assert fake_module.run_command.call_count == 2



# Generated at 2022-06-22 23:59:17.256087
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'


# Generated at 2022-06-22 23:59:29.146139
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    network = HPUXNetwork()
    network.module = module
    facts = network.populate()
    assert isinstance(facts, dict)
    assert 'interfaces' in facts
    assert facts['interfaces'] == ['lo0', 'lan0']
    assert facts['lo0'] == {'ipv4': {'address': '127.0.0.1',
                                     'interface': 'lo0',
                                     'network': '127.0.0.0'},
                           'device': 'lo0'}

# Generated at 2022-06-22 23:59:38.759076
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    testobj = HPUXNetwork(None, None, None)
    testobj._module.run_command = run_command_sim
    int_info = testobj.get_interfaces_info()
    assert 'en6' in int_info
    assert int_info['en6']['ipv4']['address'] == '10.145.50.57'
    assert int_info['en6']['ipv4']['network'] == '10.145.50.0'
    assert int_info['en6']['ipv4']['interface'] == 'lan6'
    assert 'lo0' in int_info
    assert int_info['lo0']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-22 23:59:39.600507
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()



# Generated at 2022-06-22 23:59:44.411260
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {'lan0': {'device': 'lan0', 'ipv4': {'network': '192.168.0.0', 'interface': 'lan0', 'address': '192.168.0.1'}}}
    assert HPUXNetwork().get_interfaces_info() == interfaces

# Generated at 2022-06-22 23:59:53.447324
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    result = {}
    result['interfaces'] = ['lan0', 'lan3']
    lan0_facts = {'ipv4': {'address': '10.0.0.1', 'network': '10.0.0.0',
                           'interface': 'lan0'}}

    lan3_facts = {'ipv4': {'address': '10.0.0.1', 'network': '10.0.0.0',
                           'interface': 'lan3'}}

    default_interface_facts = {'default_interface': 'lan0',
                               'default_gateway': '192.168.0.1'}

    result['lan0'] = lan0_facts
    result['lan3'] = lan3_facts
    result['default_interface'] = default_interface_facts

    hpux_network

# Generated at 2022-06-23 00:00:01.989216
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector

    networks = HPUXNetworkCollector.collect(None, None)
    interfaces = HPUXNetwork.get_default_interfaces(networks)
    assert 'default_interface' in interfaces
    assert 'default_gateway' in interfaces
    assert interfaces['default_interface'] != ''
    assert interfaces['default_gateway'] != ''



# Generated at 2022-06-23 00:00:09.325732
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    net.module = NetworkCollector()
    net.module.run_command = NetworkCollector.run_command

    ifaces = net.get_interfaces_info()
    for iface in ifaces:
        assert iface.startswith('lan')
        assert 'ipv4' in ifaces[iface]
        assert 'address' in ifaces[iface]['ipv4']
        assert 'network' in ifaces[iface]['ipv4']

# Generated at 2022-06-23 00:00:19.586685
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Tests the method populate of class HPUXNetwork.
    """
    args = {
        'ansible_facts': {
            'ansible_env': {
                'PATH': '/usr/bin:/usr/sbin'
            }
        }
    }
    rc, out, err = module.run_command("netstat -nr")
    def_dev = []
    def_gw = []
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                def_dev.append(words[4])
                def_gw.append(words[1])
    rc, out, err = module.run_command("netstat -niw")

    ips = []

# Generated at 2022-06-23 00:00:26.650250
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network_facts = HPUXNetwork()
    result = network_facts.populate()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.11.1.1'
    assert result['interfaces'] == ['lan0']

# Generated at 2022-06-23 00:00:35.048234
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

# Generated at 2022-06-23 00:00:38.159516
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    networkCollector = HPUXNetworkCollector()
    assert networkCollector._fact_class.platform == 'HP-UX'


# Generated at 2022-06-23 00:00:38.744028
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-23 00:00:47.460670
# Unit test for method get_default_interfaces of class HPUXNetwork

# Generated at 2022-06-23 00:00:58.208967
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux.system import HPUXNetwork

# Generated at 2022-06-23 00:01:08.897518
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpu_ux import HPUXNetwork
    from ansible.module_utils.facts.network.hpu_ux import HPUXNetworkCollector

    test_module = type('TestModule', (object,), dict(run_command=run_command))

    net = HPUXNetwork(test_module)

    def run_command(self):
        return 1, '', ''

    def get_bin_path(module, bin_name, required=False):
        return '/usr/bin/netstat'

    test_module.get_bin_path = get_bin_path

    collector = HPUXNetworkCollector(net, test_module)
    ans = collector.populate()
    assert ans['default_interface'] == 'lan0'
    assert ans['default_gateway']

# Generated at 2022-06-23 00:01:10.453731
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork(dict())
    assert hn.platform == 'HP-UX'



# Generated at 2022-06-23 00:01:12.932224
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module_args = {}
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    hpux = HPUXNetwork(module)
    assert hpux is not None

# Generated at 2022-06-23 00:01:19.999077
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.hp_ux import HPUXNetwork
    # sample output of command: /usr/bin/netstat -niw

# Generated at 2022-06-23 00:01:29.133984
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule({})
    network_collector = HPUXNetworkCollector(module)
    network_collector._detect_default_network()
    facts = network_collector.collect()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.1.1.53'
    assert 'lan0' in facts['interfaces']
    assert 'ipv4' in facts['lan0']
    assert facts['lan0']['ipv4']['address'] == '10.1.1.70'
    assert facts['lan0']['ipv4']['network'] == '10.1.1.0'

# Generated at 2022-06-23 00:01:40.141980
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    network_facts = HPUXNetwork(module).populate()
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts
    assert network_facts['default_interface'] in network_facts['interfaces']
    assert 'ipv4' in network_facts[network_facts['default_interface']]
    assert 'address' in network_facts[network_facts['default_interface']]['ipv4']
    assert 'network' in network_facts[network_facts['default_interface']]['ipv4']



# Generated at 2022-06-23 00:01:42.899201
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_collector = HPUXNetworkCollector()
    assert net_collector.platform == 'HP-UX'
    assert isinstance(net_collector.facts, HPUXNetwork)

# Generated at 2022-06-23 00:01:43.767889
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.populate() is not None

# Generated at 2022-06-23 00:01:48.039459
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    default_interfaces_facts = network.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-23 00:01:56.795223
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockAnsibleModule():
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            if cmd == '/usr/bin/netstat -nr':
                return(0, default_interfaces, '')

    default_interfaces = """Destination Gateway Flags Refs Interface
default 192.168.1.1 UGS 0 lan0
"""
    hpux_network = HPUXNetwork(MockAnsibleModule())
    default_interfaces = hpux_network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'


# Generated at 2022-06-23 00:02:00.089308
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.__class__.__name__ == 'HPUXNetworkCollector'
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork

# Generated at 2022-06-23 00:02:03.476261
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = {}
    collector = HPUXNetworkCollector(None, facts)
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-23 00:02:14.243706
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {
        'lan0': {
            'ipv4': {
                'address': '192.168.1.1',
                'network': '192.168.1.0',
                'interface': 'lan0'
            },
            'device': 'lan0',
        },
        'lan1': {
            'ipv4': {
                'address': '200.100.0.1',
                'network': '200.100.0.0',
                'interface': 'lan1'
            },
            'device': 'lan1',
        },
    }
    netstat_path = "/usr/bin/netstat"
    cmd = [netstat_path, "-niw"]

# Generated at 2022-06-23 00:02:21.083329
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_mock = HPUXNetwork(None)
    test_mock.module = MockModule()
    network_facts = test_mock.get_interfaces_info()
    assert network_facts == {'lan0': {'device': 'lan0',
                                      'ipv4': {'address': '192.168.1.1',
                                               'network': '192.168.1.0',
                                               'interface': 'lan0'}}}



# Generated at 2022-06-23 00:02:32.032659
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network_facts = HPUXNetwork()
    network_facts.module = module
    network_facts.populate()
    result = network_facts.get_all_facts()

    assert type(result) == dict
    assert len(result) == 4
    assert result['default_interface'] == 'lan1'
    assert result['default_gateway'] == '10.2.2.1'
    assert len(result['interfaces']) == 3
    assert 'lan1' in result['interfaces']
    assert 'lan2' in result['interfaces']
    assert 'lan3' in result['interfaces']
    assert 'ipv4' in result['lan1']

# Generated at 2022-06-23 00:02:36.336933
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ Return a set of test data to test the method populate of class HPUXNetwork.
    """

# Generated at 2022-06-23 00:02:44.187742
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    import pprint
    pp = pprint.PrettyPrinter(indent=2)
    facts = {}
    network = HPUXNetwork()
    network_facts = network.populate()
    pp.pprint(network_facts)

    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.173.238.1'
    assert 'interfaces' in network_facts
    assert 'lan0' in network_facts
    assert network_facts['lan0']['device'] == 'lan0'


test_HPUXNetwork_populate()

# Generated at 2022-06-23 00:02:52.561114
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert(hn.platform == 'HP-UX')
    assert(hn.default_interface == 'lan0')
    assert(hn.default_gateway == '10.10.10.1')
    assert(hn.interfaces == ['lan0'])
    assert(hn.lan0 == {'ipv4': {'network': '10.10.10.0', 'interface': 'lan0', 'address': '10.10.10.51'}, 'device': 'lan0'})



# Generated at 2022-06-23 00:03:02.702146
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpu import HPUXNetwork,\
                                            HPUXNetworkCollector

    module = MagicMock()
    m_fact_class = Mock(return_value=None)
    m_platform = Mock(return_value=None)

    module.get_bin_path.return_value = '/usr/bin/netstat'
    module.run_command.return_value = \
        (0, "default xxx.xxx.xxx.xxx UG    0 0        0 lan0\n"
              "xxxx.xxxx.xxxx.xxxx/xx  xxx.xxx.xxx.xxx U         0 0        0 lan0",
             '')

    hpuxnetwork = HPUXNetwork(module)

# Generated at 2022-06-23 00:03:04.243254
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    my_network = HPUXNetwork()
    assert my_network.platform == 'HP-UX'


# Generated at 2022-06-23 00:03:05.058785
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork


# Generated at 2022-06-23 00:03:08.307386
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '172.16.10.254'


# Generated at 2022-06-23 00:03:08.876689
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    assert HPUXNetwork.populate.__doc__
    # TODO: Implement test

# Generated at 2022-06-23 00:03:17.023732
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=[], type='list')
        ),
        supports_check_mode=True
    )
    collector = HPUXNetworkCollector(module=module, type_gather_subset=module.params.get('gather_subset'))
    ansible_facts = collector.collect()
    module.exit_json(ansible_facts=ansible_facts)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:03:21.114400
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():

    network_collector = HPUXNetworkCollector()

    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:03:23.978906
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_network_collector = HPUXNetworkCollector()
    assert fact_network_collector is not None



# Generated at 2022-06-23 00:03:31.448434
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    m_netstat = module.get_bin_path = Mock(return_value='/usr/bin/netstat')
    m_run_command = module.run_command = Mock(return_value=(0, 'default 10.0.2.2 UGSc 64 0 lan1\nlan1 10.0.2.15 netmask 0xffffff00 UGNI 64 6\n', ''))
    network = HPUXNetwork()
    network.module = module
    network_facts = network.populate()
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['default_interface'] == 'lan1'
    assert network_facts['interfaces'] == ['lan1']

# Generated at 2022-06-23 00:03:37.126183
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    _platform = network_collector._platform
    assert(_platform == 'HP-UX')
    _fact_class = network_collector._fact_class
    assert(_fact_class.__name__ == 'HPUXNetwork')
    assert(_fact_class.platform == 'HP-UX')



# Generated at 2022-06-23 00:03:40.822220
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork({}, None)
    assert net.platform == 'HP-UX'
    # test that we have an instance of Network
    assert isinstance(net, Network)
    # test that this instance knows how to find network facts
    assert hasattr(net, 'populate')


# Generated at 2022-06-23 00:03:43.118280
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    platform = 'HP-UX'
    hpn = HPUXNetworkCollector(platform)
    assert hpn._platform == platform
    assert hpn._fact_class == HPUXNetwork


# Generated at 2022-06-23 00:03:48.517138
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = DummyAnsibleModule()
    eth0_info = 'lan0   link#1         UP  1500 0x8100 10.1.1.10   255.255.255.0      00:08:5d:71:21:b6'
    eth1_info = 'lan1   link#2         UP  1500 0x8100 10.1.1.20   255.255.255.0      00:08:5d:71:21:b6'

# Generated at 2022-06-23 00:03:59.795817
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:04:01.015618
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = HPUXNetwork()
    assert facts.populate() == {}

# Generated at 2022-06-23 00:04:05.721249
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    fake_module, module_io = get_fake_module_and_io()

    fact_class_instance = HPUXNetwork(fake_module)
    interfaces = fact_class_instance.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0', 'ipv4': {
        'address': '10.0.0.10',
        'network': '10.0.0.0',
        'interface': 'lan0',
    }}



# Generated at 2022-06-23 00:04:17.166264
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert(network_facts.populate()['default_interface'] == "lan0")
    assert(len(network_facts.populate()['interfaces']) > 2)
    assert(network_facts.populate()['lan0']['device'] == "lan0")
    assert(network_facts.populate()['lan0']['ipv4']['network'] == "10.50.56.0")
    assert(network_facts.populate()['lan0']['ipv4']['address'] == "10.50.56.67")
    assert(network_facts.populate()['lo0']['device'] == "lo0")

# Generated at 2022-06-23 00:04:28.304855
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork(None)

    interfaces = network.get_interfaces_info()
    assert isinstance(interfaces['lan1000'], dict)
    assert isinstance(interfaces['lan1000']['ipv4'], dict)
    assert len(interfaces['lan1000']['ipv4']) == 3
    assert isinstance(interfaces['lan2000'], dict)
    assert isinstance(interfaces['lan2000']['ipv4'], dict)
    assert len(interfaces['lan2000']['ipv4']) == 3
    assert isinstance(interfaces['lan3000'], dict)

# Generated at 2022-06-23 00:04:29.569682
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    input = HPUXNetwork()
    assert input.platform == 'HP-UX'

# Generated at 2022-06-23 00:04:36.824380
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    '''
    Unit test for method HPUXNetwork.populate.
    '''
    test_class = HPUXNetwork()
    # Setup test data
    test_class.module = Mock()
    test_class.module.run_command = Mock(return_value=(0,
                                                       netstat_output,
                                                       ''))

    # Execute method populate with predefined test data
    test_val = test_class.populate()

    # Verify output of method populate

# Generated at 2022-06-23 00:04:48.271307
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """HPUXNetwork - Test populate method"""
    # Test data from HP-UX manpage

# Generated at 2022-06-23 00:04:53.928044
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    HPUXNetwork_instance = HPUXNetwork()
    result = HPUXNetwork_instance.get_interfaces_info()
    assert result['lan0'] == {'ipv4': {'address': '10.44.44.1',
                                       'network': '10.44.44.0',
                                       'interface': 'lan0'},
                              'device': 'lan0'}


# Generated at 2022-06-23 00:05:03.796944
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    iface = HPUXNetwork()

    rc, out, err = iface.module.run_command("/usr/bin/netstat -nr")

    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]

    default_interfaces_facts = iface.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == default_interface
    assert default_interfaces_facts['default_gateway'] == default_gateway


# Generated at 2022-06-23 00:05:08.295152
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os
    import sys
    import tempfile
    import unittest
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    class FakeModule(object):
        def __init__(self):
            self.exit_json = sys.exit


# Generated at 2022-06-23 00:05:19.983335
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Test default interfaces
    default_interfaces = {}
    default_interfaces['default_interface'] = 'lan1'
    default_interfaces['default_gateway'] = '172.16.0.1'
    # Test input interfaces
    interfaces = {}
    interfaces['lan1'] = {'device': 'lan1'}
    interfaces['lan1']['ipv4'] = {'address': '172.16.0.30'}
    interfaces['lan1']['ipv4'] = {'network': '172.16.0.0',
                                  'interface': 'lan1',
                                  'address': '172.16.0.30'}
    interfaces['lan2'] = {'device': 'lan2'}

# Generated at 2022-06-23 00:05:28.082347
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = HPUXNetwork()
    module.module = MagicMock()
    module.get_default_interfaces = MagicMock()
    module.get_interfaces_info = MagicMock()
    collected_facts = {}
    network_facts = module.populate(collected_facts)
    assert network_facts == {'default_interface': 'lan0', 'default_gateway': '10.1.1.1', 'interfaces': [], 'lan0': {'ipv4': {'network': 'UNKNOWN', 'address': '10.1.1.1', 'interface': 'lan0'}}}

# Generated at 2022-06-23 00:05:30.234985
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector = HPUXNetworkCollector()

# Generated at 2022-06-23 00:05:40.797664
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.h_p_u_x.test_HPUXFacts import mock_module

    # Test getting network facts
    network = HPUXNetwork(mock_module)
    interfaces = network.get_interfaces_info()
    assert interfaces['lan15'] == {'device': 'lan15', 'ipv4': {'address': '10.170.48.47', 'network': '10.170.48.0', 'interface': 'lan15'}}
    assert interfaces['lan0'] == {'device': 'lan0', 'ipv4': {'address': '10.100.2.44', 'network': '10.100.2.0', 'interface': 'lan0'}}

# Generated at 2022-06-23 00:05:51.326428
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    netstat_path = "/usr/bin/netstat"
    class HPUXNetwork():
        module = HPUXNetwork
        platform = 'HP-UX'

        def get_bin_path(self, bin_path):
            if bin_path == 'netstat':
                return netstat_path

    class HPUXNetworkCollector():
        _fact_class = HPUXNetwork
        _platform = 'HP-UX'

    class AnsibleModule():
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

        def get_bin_path(self, bin_path):
            if bin_path == 'netstat':
                return netstat_path


# Generated at 2022-06-23 00:05:59.570748
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class Module:
        def __init__(self):
            self.run_command_result = [0, 'lan0      link#3         UP  UP   1500        10.39.7.1',
                                    'lan10000  link#65535     UP  UP   1500        10.39.9.1']
        def run_command(self, cmd):
            return self.run_command_result
    module = Module()
    hp = HPUXNetwork(module)
    interfaces = hp.get_interfaces_info()

# Generated at 2022-06-23 00:06:01.798550
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork(dict()).platform == 'HP-UX'

# Generated at 2022-06-23 00:06:07.156562
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    module.run_command = FakeCmd
    hp = HPUXNetwork(module)

    default_interfaces = hp.get_default_interfaces()
    assert len(default_interfaces) == 2
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.10.10.1'

