

# Generated at 2022-06-22 23:56:05.780456
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'

# Generated at 2022-06-22 23:56:13.219033
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = get_module_mock()
    module.run_command.return_value = (0, 'default 192.168.101.1 UG lan0', '')
    network = HPUXNetwork(module=module)
    expected_result = {
        'default_gateway': '192.168.101.1',
        'default_interface': 'lan0'
    }
    result = network.get_default_interfaces()
    assert result == expected_result


# Generated at 2022-06-22 23:56:15.868147
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork(dict(module=dict()))
    assert HPUXNetwork != None


# Generated at 2022-06-22 23:56:23.360956
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_network = HPUXNetwork()
    facts = hpux_network.populate()
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0'] == {'ipv4': {'address': '10.0.0.1', 'network': '10.0.0.0', 'interface': 'lan0'}, 'device': 'lan0'}
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.0.254'



# Generated at 2022-06-22 23:56:33.893202
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})

    test_network = HPUXNetwork(module)

    # Mocked up netstat command output for default_interfaces_facts
    default_interfaces_output = """default 00000000 00000000 00000000 00000000 00000000 00000000 00000
default 00000000 00000000 00000000 00000000 00000000 00000000 00000
host1 00000000 00000000 00000000 00000000 00000000 00000000 00000
host2 00000000 00000000 00000000 00000000 00000000 00000000 00000
host3 00000000 00000000 00000000 00000000 00000000 00000000 00000"""

    # Mocked up netstat command output for interfaces

# Generated at 2022-06-22 23:56:41.990827
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import HPUXNetwork
    network = HPUXNetwork(None)
    network._exec_command = _exec_command
    interfaces = network.get_interfaces_info()

    assert interfaces['lan1'] == {'ipv4': {'address': '10.10.10.10',
                                           'network': '10.10.10.0',
                                           'interface': 'lan1'}, 'device': 'lan1'}



# Generated at 2022-06-22 23:56:44.063267
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork

# Generated at 2022-06-22 23:56:46.520497
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Create an instance of HPUXNetworkCollector without exceptions
    """
    nc = HPUXNetworkCollector()
    assert isinstance(nc, HPUXNetworkCollector)

# Generated at 2022-06-22 23:56:51.632066
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    network_collector = HPUXNetworkCollector(module=module)

    network_facts = network_collector.collect()
    assert 'default_interface' in network_facts, \
            'Default interface not found in facts'

# Generated at 2022-06-22 23:57:02.026967
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()

    def get_interfaces_info(interfaces):
        return getattr(network, 'get_interfaces_info')(interfaces)


# Generated at 2022-06-22 23:57:02.587043
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-22 23:57:05.689355
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hx_network = HPUXNetwork()
    assert hx_network.get_default_interfaces() == {'default_interface': None,
                                                   'default_gateway': None}

# Generated at 2022-06-22 23:57:17.307624
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    # Create temp file
    fd, netstat_path = tempfile.mkstemp()
    f = os.fdopen(fd, "w")
    f.write("""
    default  172.28.0.0        UG     0         0        lan1
    default  172.30.0.0        UG     0         0        lan1
    default  172.31.0.0        UG     0         0        lan1
    default  172.32.0.0        UG     0         0        lan1
    default  172.34.0.0        UG     0         0        lan1
    default  172.35.0.0        UG     0         0        lan1
    default  172.36.0.0        UG     0         0        lan1
    """)
    f.close

# Generated at 2022-06-22 23:57:19.198014
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Test that an object of the class exists.
    network_collector = HPUXNetworkCollector()
    assert network_collector

# Generated at 2022-06-22 23:57:21.834594
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector()
    assert hpux._fact_class.platform == 'HP-UX'
    assert hpux._platform == 'HP-UX'



# Generated at 2022-06-22 23:57:30.314892
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    test_network = HPUXNetwork({}, {}, {}, {}, {})
    default_interfaces = test_network.get_default_interfaces()
    assert len(default_interfaces) == 2
    assert 'default_interface' in default_interfaces
    assert 'default_gateway' in default_interfaces
    assert default_interfaces['default_interface'] == 'lan9'
    assert default_interfaces['default_gateway'] == '10.0.2.2'

# Generated at 2022-06-22 23:57:32.519625
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpuinx_network = HPUXNetwork(None)
    assert hpuinx_network.platform == 'HP-UX'

# Generated at 2022-06-22 23:57:43.432095
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}
    command = '/usr/bin/netstat'
    args = ' -niw'
    lines = []

# Generated at 2022-06-22 23:57:45.111662
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpxnet = HPUXNetwork()
    assert hpxnet.platform == 'HP-UX'


# Generated at 2022-06-22 23:57:57.900279
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    nm = HPUXNetwork(module)


# Generated at 2022-06-22 23:58:02.344570
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_return = {'default_gateway': '10.111.11.1',
                   'default_interface': 'lan9'}
    network = HPUXNetwork()
    assert network.get_default_interfaces() == test_return


# Generated at 2022-06-22 23:58:13.919299
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    # Unit test for the method populate
    from ansible.module_utils.facts import Collector

    test_HPUXNetwork = HPUXNetwork()
    test_HPUXNetwork.module = object()
    test_HPUXNetwork.module.run_command = Mock(return_value=(0, "", ""))
    test_HPUXNetwork.module.get_bin_path = Mock(return_value="/bin/netstat")

    actual_result = test_HPUXNetwork.populate()


# Generated at 2022-06-22 23:58:21.290498
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    mock = HPUXNetwork()
    mock.module = MockModule()
    # set module.run_command() to run a given command successfully
    mock.module.run_command = Mock(return_value=(0, MOCK_NETSTAT_NR_RESULT, ''))
    # call the method get_default_interfaces() to assert return values
    interfaces = mock.get_default_interfaces()
    assert interfaces == {'default_interface': 'lan1',
                          'default_gateway': '172.17.29.1'}


# Generated at 2022-06-22 23:58:32.732138
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.hpux.facts import HPUXNetwork
    # Create a HPUXNetwork object with a mocked module
    hpux_network = HPUXNetwork(mocked_module())

    # Read test data
    from os import path
    module_dir = path.dirname(path.dirname(path.dirname(path.dirname(path.dirname(path.abspath(__file__))))))
    data_dir = path.join(module_dir, 'test/unit/module_utils/facts/network/hpux')
    with open(path.join(data_dir, 'sample_netstat_niw_output.txt')) as file:
        sample_netstat_niw_output = file.read()


# Generated at 2022-06-22 23:58:45.014727
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    test method get_interfaces_info of class HPUXNetwork
    """

# Generated at 2022-06-22 23:58:46.641982
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu = HPUXNetwork()
    assert hpu

# Generated at 2022-06-22 23:58:50.315334
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = AnsibleModule(argument_spec={'key': {'type': 'str'}})
    hpux_network = HPUXNetwork(m)
    assert hpux_network.get_default_interfaces().get('default_gateway') is None


# Generated at 2022-06-22 23:58:58.299468
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = get_test_module('hpux')
    module.get_bin_path = get_bin_path
    module.run_command = get_command
    module.fail_json = get_fail_json

    # Calling populate
    NetworkCollector.populate(module)

    facts = module.ansible_facts
    assert 'default_interface' in facts
    assert facts['default_interface'] == 'lo0'
    assert 'default_gateway' in facts
    assert facts['default_gateway'] == '127.0.0.1'
    assert 'interfaces' in facts
    assert 'lan0' in facts['interfaces']
    assert 'lan1' in facts['interfaces']
    assert 'lan2' in facts['interfaces']
    assert 'lan3' in facts['interfaces']

# Generated at 2022-06-22 23:58:59.861197
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-22 23:59:03.240506
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # create network object and populate fact dictionary
    fact_network = HPUXNetwork()
    fact_network.populate()
    fact_dict = fact_network.populate_dict()

    # check the default interface
    default_interface = fact_dict.get('default_interface', 'none')
    assert default_interface == 'lan0', 'default_interface is wrong'

    # check actual interface properties
    interfaces = fact_dict.get('interfaces', 'none')
    assert interfaces == ['lan0'], 'interfaces are wrong'
    assert 'lan0' in fact_dict, 'lan0 is not in the fact dictionary'
    assert 'device' in fact_dict['lan0'], 'device not in lan0'
    assert fact_dict['lan0']['device'] == 'lan0', 'device is wrong'

# Generated at 2022-06-22 23:59:12.479532
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    facts = network.populate()

    interfaces = facts.get('interfaces')
    assert len(interfaces) > 0
    for iface in interfaces:
        assert facts[iface]['device'] == iface
        assert facts[iface]['ipv4']['network'] != ''
        assert facts[iface]['ipv4']['interface'] != ''
        assert facts[iface]['ipv4']['address'] != ''


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-22 23:59:18.662174
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = Mock(params={})
    hpux_network = HPUXNetwork(module)
    interfaces = hpux_network.get_interfaces_info()
    ifaces = list(interfaces.keys())
    assert len(ifaces) > 1
    for iface in ifaces:
        assert interfaces[iface]['device'] == iface
        assert interfaces[iface]['ipv4']['network']
        assert interfaces[iface]['ipv4']['address']
        assert interfaces[iface]['ipv4']['interface'] == iface

# Generated at 2022-06-22 23:59:24.176409
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpuxnetwork_obj = HPUXNetwork()
    default_interfaces_facts = hpuxnetwork_obj.get_default_interfaces()
    test_result = {'default_interface': 'lan0',
                   'default_gateway': '10.10.10.1'}
    assert test_result == default_interfaces_facts


# Generated at 2022-06-22 23:59:30.469182
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    hpuxnetwork = HPUXNetwork(module=module)

    assert hpuxnetwork.get_default_interfaces()['default_interface'] == 'lan0'
    default_gateway = hpuxnetwork.get_default_interfaces()['default_gateway']
    assert default_gateway == '172.31.41.254' or \
           default_gateway == '192.168.0.1'


# Generated at 2022-06-22 23:59:39.804024
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class Module(object):
        def __init__(self):
            self.bin_path = '/usr/bin'
        def run_command(self, args, check_rc=True):
            return 0, test_HPUX_netstat_interfaces, ''
    net = HPUXNetwork(Module())
    interfaces = net.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'address': '10.0.0.1'}}
    assert interfaces['lan1'] == {'device': 'lan1',
                                  'ipv4': {'address': '10.0.1.1'}}

# Generated at 2022-06-22 23:59:50.568380
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    module = AnsibleModule(argument_spec=dict())
    hpx_network = HPUXNetwork(module)
    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    assert rc == 0
    assert len(out.splitlines()) >= 2
    default_interfaces_facts = hpx_network.get_default_interfaces()
    assert 'default_gateway' in default_interfaces_facts
    assert 'default_interface' in default_interfaces_facts
    interfaces = hpx_network.get_interfaces_info()
    assert len(interfaces) == 1
    for iface in interfaces:
        assert 'ipv4' in interfaces[iface]
        assert 'address' in interfaces[iface]['ipv4']

# Generated at 2022-06-22 23:59:51.258516
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector()

# Generated at 2022-06-22 23:59:52.184019
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert issubclass(HPUXNetworkCollector, NetworkCollector)


# Generated at 2022-06-22 23:59:52.927995
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-22 23:59:55.734331
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.__dict__['_platform'] == 'HP-UX'

# Generated at 2022-06-23 00:00:05.483175
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    '''
    Unit test for method HPUXNetwork.get_default_interfaces
    '''
    # pylint: disable=R0904,C0103
    HPUXNetwork._module = None

    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    net = HPUXNetwork()

    net.module.run_command = lambda b, c: (0, 'default  192.168.0.254 UGSc 10 0  lan0 ', '')
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.0.254'



# Generated at 2022-06-23 00:00:06.661670
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:00:18.014542
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Creating a class instance to run its method
    hpuxNetwork = HPUXNetwork
    test_cmd = "echo 'lan3: flags=10 <UP,BROADCAST,SIMPLEX,MULTICAST> metric 1 mtu 1500\n  lan4: flags=10 <UP,BROADCAST,SIMPLEX,MULTICAST> metric 1 mtu 1500'| netstat -ni"

# Generated at 2022-06-23 00:00:20.878090
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector._platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork
    assert collector._fact_class({}) is not None

# Generated at 2022-06-23 00:00:27.100867
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = NetworkCollector()
    net = HPUXNetwork(module)
    interfaces = net.get_interfaces_info()
    assert interfaces['lan1'] == {'device': 'lan1', 'ipv4': {'network': '172.16.0.0', 'interface': 'lan1', 'address': '172.16.0.11'}}

# Generated at 2022-06-23 00:00:29.144714
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.populate() is not None

# Generated at 2022-06-23 00:00:35.837911
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    testedclass = HPUXNetwork()
    rc, out, err = testedclass.module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    default_interfaces = {}
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interfaces['default_interface'] = words[4]
                default_interfaces['default_gateway'] = words[1]

    rc, out, err = testedclass.module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    interfaces = {}
    for line in lines:
        words = line.split()

# Generated at 2022-06-23 00:00:38.554352
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'



# Generated at 2022-06-23 00:00:46.675970
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule:
        def run_command(command):
            lines = "default 172.17.16.1 1 UL ipv4 0 0\n" \
                    "172.18.153.0 172.18.153.1 2 UGS lan0 ipv4 0 0".splitlines()
            return 0, lines, None

        def get_bin_path(name, opt_dirs=[]):
            return '/usr/bin/netstat'

    obj = HPUXNetwork(module=MockModule())
    assert obj.get_default_interfaces() == {'default_interface': 'lan0',
                                            'default_gateway': '172.17.16.1'}


# Generated at 2022-06-23 00:00:52.060866
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_obj = HPUXNetwork()
    test_obj.module = MagicMock()
    assert test_obj.get_default_interfaces() == {'default_gateway': '10.1.1.1',
                                                 'default_interface': 'lan7'}


# Generated at 2022-06-23 00:00:54.859289
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class == HPUXNetwork
    assert c._fact_class.platform == 'HP-UX'

# Generated at 2022-06-23 00:01:02.174879
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXFacts
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    fake_module = HPUXFacts()
    fake_module.get_bin_path = lambda x: ('', '', 0)
    fake_module.run_command = lambda x: ('', 'default 10.0.0.1 UGS 0 787 lan0\n'
                                             'lan0 10.0.0.0 U 3 17 lan0\n'
                                             'lan0 10.0.0.2 UH 2 3 lo0\n', '')

    obj = HPUXNetwork(fake_module)
    facts = obj.populate()

    assert facts['default_interface'] == 'lan0'

# Generated at 2022-06-23 00:01:05.824981
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network.platform == 'HP-UX'
    assert network.fact_class == HPUXNetwork
    assert network.fact_subclass == 'network'


# Generated at 2022-06-23 00:01:14.475078
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.run_command = run_command

    net_obj = HPUXNetwork(module)

    def run_command(cmd, check_rc=True):
        if cmd == '/usr/bin/netstat -nr':
            return 0, 'default 10.0.2.2 UG 0 0 0 lan0', ''
        elif cmd == '/usr/bin/netstat -niw':
            return 0, 'lan0 0.0.0.0 10.0.2.0 UP 0 0 0 0 lan0', ''
        else:
            return 0, '', ''

    network_facts_res = net_obj.populate()

    assert network_facts_res['default_interface'] == 'lan0'
    assert network_facts

# Generated at 2022-06-23 00:01:24.007503
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    # Setup
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
                                                 """default 192.168.86.3 UGSc 0 0 lan0
192.168.86.0       192.168.86.3       UG        0        0 lan0""",
                                                 'stderr'))
    network = HPUXNetwork(module)

    # Exercise
    default_interfaces_facts = network.get_default_interfaces()

    # Verify
    expected_default_interfaces_facts = {'default_interface': 'lan0',
                                         'default_gateway': '192.168.86.3'}
    assert expected_default_interfaces_facts == default_interfaces_facts



# Generated at 2022-06-23 00:01:33.392357
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    assert 'default_interface' in network_facts.keys()
    assert 'default_gateway' in network_facts.keys()
    assert 'interfaces' in network_facts.keys()
    assert 'lo0' in network_facts.keys()
    assert 'lan0' in network_facts.keys()
    assert network_facts['lan0']['ipv4']['address'] == '127.0.0.1'
    assert network_facts['lan0']['ipv4']['network'] == '127.0.0.0'
    assert network_facts['lan0']['ipv4']['interface'] == '127.0.0.1'

# Generated at 2022-06-23 00:01:35.814785
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    f = HPUXNetworkCollector()
    assert f._fact_class == HPUXNetwork
    assert f._platform == 'HP-UX'

# Generated at 2022-06-23 00:01:45.628858
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    result = {'interface1': {'ipv4': {'address': '192.168.x.x',
                                      'network': '192.168.x.x',
                                      'interface': 'interface1', },
                             'device': 'interface1'},
              'interface2': {'ipv4': {'address': '192.168.y.y',
                                      'network': '192.168.y.y',
                                      'interface': 'interface2', },
                             'device': 'interface2'}
              }

# Generated at 2022-06-23 00:01:53.634137
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class Module(object):
        def __init__(self):
            self.run_command = lambda x: (0, "default 172.20.0.1 UGS 0 0 en0", "")

    class Network(object):
        def __init__(self):
            self.module = Module()

    net_inst = Network()
    hpu_net = HPUXNetwork()
    ret = hpu_net.get_default_interfaces(net_inst)
    assert ret == {'default_interface': 'en0', 'default_gateway': '172.20.0.1'}



# Generated at 2022-06-23 00:02:03.670144
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import sys
    import tempfile

    test_data = """
lo0        lan0        udp        0       0       0
lo0        lan0        ip         0       0       0
lo0        lan0        rawip      0       0       0
lo0        lan0        tcp        0       0       0
lan0       lan0        udp        0       0       0
lan0       lan0        ip         0       0       0
lan0       lan0        rawip      0       0       0
lan0       lan0        tcp        0       0       0
lan1       lan1        udp        0       0       0
lan1       lan1        ip         0       0       0
lan1       lan1        rawip      0       0       0
lan1       lan1        tcp        0       0       0
"""


# Generated at 2022-06-23 00:02:14.401239
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network = HPUXNetwork()
    network.module = MockModule()
    network.module.run_command.return_value = (0, '', '')
    facts = {'network': 'information'}

    # call method populate
    network.populate(facts)


# Generated at 2022-06-23 00:02:26.173784
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork.get_interfaces_info()
    assert isinstance(interfaces, dict)
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lan2' in interfaces
    assert 'lan3' in interfaces
    assert 'lo0' in interfaces
    lan0 = interfaces['lan0']
    assert isinstance(lan0, dict)
    assert lan0['device'] == 'lan0'
    ipv4 = lan0['ipv4']
    assert isinstance(ipv4, dict)
    assert 'address' in ipv4
    assert 'network' in ipv4
    assert 'interface' in ipv4
    assert ipv4['address'] == '192.168.2.2'
    assert ipv4['network'] == '192.168.2.0'


# Generated at 2022-06-23 00:02:28.817481
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    assert hpux_network is not None


# Generated at 2022-06-23 00:02:39.915182
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class AnsibleModule:
        FAKE_STDOUT='lan0      0   5    0 79675  0  0    0    0    0 0 1 0\n' \
            'lan1      0   5  639 79675  0  0  79731  6096    0 0 1 0\n' \
            'lan2      0   5  788 79675  0  0  79731  6096    0 0 1 0\n' \
            'lan3      0   5    0 79675  0  0    0    0    0 0 1 0\n' \
            'lan4      0   5  639 79675  0  0  79731  6096    0 0 1 0\n'

# Generated at 2022-06-23 00:02:50.792165
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    fake = {
            'default_interfaces_facts': {
                'default_interface': 'lan19',
                'default_gateway': '172.16.10.1',
                },
            'interfaces_facts': {
                'lan19': {
                    'device': 'lan19',
                    'ipv4': {
                        'address': '172.16.10.55',
                        'network': '172.16.10.0',
                        'interface': 'lan19',
                        },
                    },
                }
            }
    
    test = HPUXNetwork()

# Generated at 2022-06-23 00:02:55.669558
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpn = HPUXNetwork()
    default_ifaces = hpn.get_default_interfaces()
    ifaces = default_ifaces['default_interface']
    if ifaces != 'lan0':
        print("Error, interface should be lan0")



# Generated at 2022-06-23 00:03:04.871567
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    network_collector = HPUXNetworkCollector(module=module)
    network_collector._platform = 'HP-UX'
    fact_class = network_collector._fact_class
    netstat_path = module.get_bin_path('netstat')
    module.run_command.return_value = (0, '', '')

# Generated at 2022-06-23 00:03:07.618005
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network
    assert network.platform == 'HP-UX'


# Generated at 2022-06-23 00:03:18.877508
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""

    class TestHPUXModule(object):
        def __init__(self):
            self.params = {'path': ''}
            self.run_command_results = None

        def get_bin_path(self, name, opts=None):
            """Return the path of the script"""
            return "/usr/bin/netstat"

        def run_command(self, cmd):
            """Return the output of the command"""
            return (0, self.run_command_results, None)

    test_module = TestHPUXModule()
    hpux_network = HPUXNetwork(test_module)

# Generated at 2022-06-23 00:03:20.245155
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()

# Generated at 2022-06-23 00:03:29.991910
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    network = HPUXNetwork(module=module, collected_facts=None)

    rc, out, err = module.run_command.return_value
    out = '/usr/bin/netstat: not found\n'
    rc = 127

    network.populate(collected_facts=None)
    assert module.run_command.called is True

    rc, out, err = module.run_command.return_value

# Generated at 2022-06-23 00:03:40.701307
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network_collector = HPUXNetworkCollector(module=module)
    hpux_network = hpux_network_collector.collect()[0]

# Generated at 2022-06-23 00:03:46.827271
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpu.hpu_network import HPUXNetwork
    hpu = HPUXNetwork(None)
    assert hpu.get_interfaces_info() == {'lan0': {'device': 'lan0',
                                                  'ipv4': {'address': '192.168.22.32',
                                                           'interface': 'lan0',
                                                           'network': '192.168.22.0'}},
                                         'lan1': {'device': 'lan1',
                                                  'ipv4': {'address': '172.31.255.254',
                                                           'interface': 'lan1',
                                                           'network': '172.31.255.0'}}}

# Generated at 2022-06-23 00:03:47.845693
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    return HPUXNetworkCollector

# Generated at 2022-06-23 00:03:59.382395
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    HPUX_network_mock = HPUXNetwork()
    # Fake the output of command netstat
    HPUX_network_mock.module.run_command.return_value = (0,
                                    'default 192.168.0.1 UGS lan0\n' +
                                    '127.0.0.1 127.0.0.1 UH lo0\n' +
                                    'lan0 192.168.0.0 0xffffff00 U lan0\n' +
                                    'lo0 127.0.0.0 0xff000000 U lo0\n',
                                    None)
    # Fake the output of command netstat -niw

# Generated at 2022-06-23 00:03:59.921151
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-23 00:04:04.220708
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """Unit test for method ge_default_interfaces of class HPUXNetwork."""
    test_network = HPUXNetwork(dict())
    test_network.module = FakeAnsibleModule()
    result = test_network.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-23 00:04:12.610728
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net_obj = HPUXNetwork({'module_utils': 'noop',
                           'path': 'noop'})
    interfaces = {'default_interface': 'lan0',
                  'default_gateway': '10.10.10.10'}
    out = ['default 10.10.10.10 UG 0 0 lan0',
           '10.10.10.0 10.10.10.255 U 1 0 lan0']
    assert net_obj.get_default_interfaces(out) == interfaces



# Generated at 2022-06-23 00:04:19.203366
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    This function unit tests method populate of HPUXNetwork class.
    """
    '''
    This function unit tests method populate of HPUXNetwork class.
    '''
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    iface = HPUXNetwork()
    iface.populate()



# Generated at 2022-06-23 00:04:21.337842
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hux_network = HPUXNetwork()
    assert isinstance(hux_network, HPUXNetwork)


# Generated at 2022-06-23 00:04:22.281817
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-23 00:04:31.928729
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts import Facts
    def execute_module():
        module_args = dict()
        module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
        return module.run_command('netstat -nr')

    def get_interfaces_info():
        return "default 192.168.1.1 UG lan0"

    mocker.patch.object(HPUXNetwork, 'get_interfaces_info', side_effect=get_interfaces_info)
    mocker.patch.object(HPUXNetwork, 'module')
    hpux_network_collector = HPUXNetwork(Facts({}))

# Generated at 2022-06-23 00:04:42.326376
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-23 00:04:52.945882
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()

# Generated at 2022-06-23 00:05:03.505664
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import Network
    network_fact = Network()
    result = network_fact.get_interfaces_info()
    assert len(result) > 0
    assert 'lan0' in result
    assert 'lan1' in result
    assert 'lan2' in result
    assert 'lan3' in result
    assert 'lan4' in result
    assert result['lan0']['ipv4']['network'] == '192.168.0.0'
    assert result['lan0']['ipv4']['address'] == '192.168.0.44'
    assert result['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-23 00:05:07.403345
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    out = "default 172.16.1.1 UGSc 1 10 lan0\nlan0 172.16.1.245 UH 2 0 lan0\nlan1 172.16.2.245 UH 2 0 lan1"
    err = ""
    rc = 0
    module = MockModule(out=out, err=err, rc=rc)
    interfaces_info = HPUXNetwork.get_interfaces_info(module)

    assert len(interfaces_info) == 2
    for item in interfaces_info:
        assert interfaces_info[item]['device'] == item
        assert isinstance(interfaces_info[item]['ipv4'], dict)



# Generated at 2022-06-23 00:05:12.917502
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    fake_module = FakeAnsibleModule()
    module = HPUXNetwork(fake_module)
    default_interfaces = module.get_default_interfaces()
    assert default_interfaces == { "default_interface": "lan0",
                                   "default_gateway": "10.0.0.1" }


# Generated at 2022-06-23 00:05:16.854243
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    hpn = hpn.populate()
    assert hpn["default_interface"]
    assert hpn["default_gateway"]
    assert hpn["interfaces"]


# Generated at 2022-06-23 00:05:18.961558
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    assert network is not None



# Generated at 2022-06-23 00:05:27.500338
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = Mock(exit_json=dict(), fail_json=dict(), params={})
    setattr(module, 'run_command', Mock(return_value=(0, "", "")))
    network_collector = HPUXNetworkCollector()
    network_collector.set_module(module)
    assert network_collector.get_interfaces_info() == {'lan0': {'device': 'lan0', 'ipv4': {'network': '192.168.122.0', 'interface': 'lan0', 'address': '192.168.122.1'}}}



# Generated at 2022-06-23 00:05:30.864472
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork

# Generated at 2022-06-23 00:05:33.009846
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    g = HPUXNetworkCollector()
    assert isinstance(g, NetworkCollector)

# Generated at 2022-06-23 00:05:44.934167
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class HPUXNetwork_get_default_interfaces_TestModule(object):
        def run_command(self, cmd):
            # test data taken from a HP-UX system
            output = 'default 192.168.1.1 UG lan6 10.0.0.1 U'
            return (0, output, '')

        def get_bin_path(self, name):
            return name

    class NetworkModule_TestFacts(dict):
        def __init__(self):
            self._netstat_path = 'netstat'

    test_module = HPUXNetwork_get_default_interfaces_TestModule()
    network_module = NetworkModule_TestFacts()
    test_HPUXNetwork = HPUXNetwork(test_module, network_module)
    default_interfaces_facts = test_HPUX

# Generated at 2022-06-23 00:05:45.849011
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.modu

# Generated at 2022-06-23 00:05:50.390337
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    nm = HPUXNetwork({})
    nm.module = DummyModule()
    nm.module.run_command = DummyRunCommand()
    nm.get_default_interfaces = DummyGetDefaultInterfaces()
    nm.get_interfaces_info = DummyGetInterfacesInfo()
    nm.populate()



# Generated at 2022-06-23 00:05:58.800237
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    obj_HPUXNetwork = HPUXNetwork()
    default_interfaces_facts = obj_HPUXNetwork.get_default_interfaces()
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts
    assert 'lan0' in default_interfaces_facts['default_interface']
    assert 'lan1' in default_interfaces_facts['default_interface']
    assert 'lan2' in default_interfaces_facts['default_interface']
    assert 'lan3' in default_interfaces_facts['default_interface']
    assert 'lan4' in default_interfaces_facts['default_interface']
    assert 'lan5' in default_interfaces_facts['default_interface']

# Generated at 2022-06-23 00:06:02.434663
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-23 00:06:04.421966
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    mycoll = HPUXNetworkCollector()
    assert mycoll._fact_class == HPUXNetwork