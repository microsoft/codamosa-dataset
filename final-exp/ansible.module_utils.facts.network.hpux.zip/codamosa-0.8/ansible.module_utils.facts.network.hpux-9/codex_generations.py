

# Generated at 2022-06-11 03:25:27.871568
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    default_interfaces = {'default_interface': 'lan5',
                          'default_gateway': '192.168.4.254'}

# Generated at 2022-06-11 03:25:39.854842
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpn = HPUXNetwork(None)

    # Return value test 1
    out = "lan0: flags=843<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500 inet 10.15.34.12 netmask ffffff00 broadcast 10.15.34.255\nlo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232"
    interfaces = hpn.get_interfaces_info()

# Generated at 2022-06-11 03:25:41.368639
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-11 03:25:46.702622
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    test = HPUXNetworkCollector()
    assert test._platform == 'HP-UX'
    assert test._fact_class == 'HPUXNetwork'
    assert test.platform == 'HP-UX'
    assert test.fact_class == HPUXNetwork

# Generated at 2022-06-11 03:25:48.778365
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeAnsibleModule()
    hpu_network = HPUXNetwork(module)
    assert hpu_network is not None
    assert hpu_network.module is module
    assert hpu_network.platform == 'HP-UX'


# Generated at 2022-06-11 03:25:49.892662
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    w = HPUXNetworkCollector()
    assert w is not None

# Generated at 2022-06-11 03:25:58.368097
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class HPUXNetwork
    """
    module = FakeModule(run_command_results=[(0, OUT_GET_DEFAULT_INTERFACES, "")])
    default_interfaces_facts = {'default_gateway': '192.0.2.1',
                                'default_interface': 'lan0'}
    hpuxnetwork = HPUXNetwork()
    hpuxnetwork.module = module
    assert hpuxnetwork.get_default_interfaces() == default_interfaces_facts



# Generated at 2022-06-11 03:26:06.251180
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    out = "default 192.168.1.1 UG 10 0 lan0"
    t_words = out.split()
    interfaces_facts = {'default_interface': 'lan0',
                        'default_gateway': '192.168.1.1'}
    m_run_command = MagicMock(return_value=(0, out, None))
    m_module = MagicMock(run_command=m_run_command)
    HPUX_network = HPUXNetwork(m_module)
    assert(interfaces_facts == HPUX_network.get_default_interfaces())


# Generated at 2022-06-11 03:26:09.749984
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = NetworkCollector(None, None)
    o = HPUXNetwork(module)
    testinteface = o.get_default_interfaces()
    assert 'default_interface' in testinteface
    assert 'default_gateway' in testinteface

# Generated at 2022-06-11 03:26:13.419361
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    m = AnsibleModule(argument_spec={})
    hpuxnetwork = HPUXNetwork(m)
    interfaces = hpuxnetwork.get_interfaces_info()

    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['network'] == '172.31.100.0'
    assert interfaces['lan0']['ipv4']['address'] == '172.31.100.125'

    assert 'lan1' in interfaces
    assert interfaces['lan1']['ipv4']['network'] == '172.31.101.0'
    assert interfaces['lan1']['ipv4']['address'] == '172.31.101.125'


# Generated at 2022-06-11 03:26:29.582784
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    nm = HPUXNetwork(module)
    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]
    rc, out, err = module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    interfaces = {}
    for line in lines:
        words = line.split()

# Generated at 2022-06-11 03:26:35.146557
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, 'default  10.32.50.1/24  route-134  lan138', 'stderr'))
    network = HPUXNetwork(module=module)
    default_interfaces = network.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan138'
    assert default_interfaces['default_gateway'] == '10.32.50.1'

# Generated at 2022-06-11 03:26:36.920532
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Create an instance of HPUXNetworkCollector
    """
    hpuxnetworkcollector = HPUXNetworkCollector()
    assert hpuxnetworkcollector._platform == 'HP-UX'

# Generated at 2022-06-11 03:26:38.011415
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network._platform == 'HP-UX'

# Generated at 2022-06-11 03:26:38.895429
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()



# Generated at 2022-06-11 03:26:41.151367
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpx = HPUXNetworkCollector()
    assert (hpx._fact_class is HPUXNetwork)
    assert (hpx._platform is 'HP-UX')

# Generated at 2022-06-11 03:26:47.598143
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    hn = HPUXNetwork()
    hn.module = BaseFactCollector()

    # Return value of method get_interfaces_info of class HPUXNetwork
    # will be a dictionary as follows:
    expected_result = {'lan0': {'device': 'lan0', 'ipv4': {'address': '0.0.0.0', 'network': '127', 'interface': 'lan0'}}}

    # Make sure the test works no matter what the current directory is.
    # The test fixture is in ../../../../test/units/module_utils/facts/network/hpux/netstat.
    # The current directory is changed so that module

# Generated at 2022-06-11 03:26:53.030619
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetwork(module)
    out = hpux_network.populate()

    assert out['default_gateway'] is not None
    assert out['default_interface'] is not None
    assert len(out['interfaces']) > 1

# Generated at 2022-06-11 03:27:03.452268
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    m_run_command = Mock(return_value=(0, '/usr/bin/netstat', 'fake stderr'))
    module.run_command = m_run_command
    m_get_bin_path = MagicMock(return_value="/usr/bin/netstat")
    module.get_bin_path = m_get_bin_path

# Generated at 2022-06-11 03:27:04.358051
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork



# Generated at 2022-06-11 03:27:21.311150
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    "Unit test for method populate of class HPUXNetwork."
    class Config:
        def __init__(self):
            self.module = "TestModule"

    config = Config()
    network_module = HPUXNetwork(config)
    rc, out, err = config.module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    device = lines[1].split()[0]

    # Test that the IP address is ok.
    ip_address = network_module.get_interfaces_info()[device]['ipv4']
    assert_equal(ip_address['address'], lines[1].split()[3])

    # Test that the network is ok.
    network = network_module.get_interfaces_info()[device]['ipv4']
   

# Generated at 2022-06-11 03:27:23.267262
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockModule()
    hpx_network = HPUXNetwork(module)
    hpx_network.get_interfaces_info()

# Generated at 2022-06-11 03:27:25.234568
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    obj = HPUXNetwork()
    result = obj.get_interfaces_info()
    assert 'lan0' in result

# Generated at 2022-06-11 03:27:32.001417
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_mod = AnsibleModule(argument_spec={})
    test_mod.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UGSc 3 0 en0', ''))
    test_mod.params = {}
    hpux_net = HPUXNetwork(module=test_mod)
    default_interfaces = hpux_net.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'en0', 'default_gateway': '192.168.1.1'}


# Generated at 2022-06-11 03:27:41.726682
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    n = HPUXNetwork(module)
    n.populate()
    assert n.facts['default_interface'] == 'lan0'
    assert n.facts['default_gateway'] == '192.168.0.1'
    assert n.facts['interfaces'] == ['lan0']
    assert n.facts['lan0']['ipv4']['address'] == '192.168.0.2'
    assert n.facts['lan0']['ipv4']['network'] == '192.168.0.0'



# Generated at 2022-06-11 03:27:44.448937
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_info = HPUXNetworkCollector()
    assert fact_info._fact_class == HPUXNetwork
    assert fact_info._platform == 'HP-UX'

# Generated at 2022-06-11 03:27:47.801450
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_get_default_interfaces = HPUXNetwork()
    test_get_default_interfaces.module.run_command = lambda x: ('0', 'default 130.45.113.254 UGS 0 0 24 - lan0', '')
    assert test_get_default_interfaces.get_default_interfaces() == \
            {'default_gateway': '130.45.113.254', 'default_interface': 'lan0'}
    test_get_default_interfaces.module.run_command = lambda x: ('0', '', '')
    assert test_get_default_interfaces.get_default_interfaces() == \
            {'default_gateway': 'none', 'default_interface': 'none'}


# Generated at 2022-06-11 03:27:57.417082
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.tests.unit.modules.utils \
        import set_module_args
    from ansible_collections.ansible.community.tests.unit.compat \
        import unittest

    class TestHPUXNetwork(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec={},
                supports_check_mode=True
            )
            self.module._socket_path = '/dev/null'
            set_module_args(dict(gather_subset='network'))
            self.hpuxnetwork_obj = self.module.get_network_info()[0]

        def test_HPUXNetwork_get_interfaces_info(self):
            interfaces = self.hpuxnetwork_obj.get_

# Generated at 2022-06-11 03:28:04.832321
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpu_ux.get_interfaces_info import HPUXNetwork
    hpxn = HPUXNetwork(None)
    interfaces = hpxn.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4'] == {'address': '0.0.0.0', 'network': '0.0.0.0', 'interface': 'lan0', 'broadcast': '255.255.255.255'}

# Generated at 2022-06-11 03:28:07.002232
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Create object of HPUXNetwork class
    """
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-11 03:28:22.574641
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj_HPUXNetworkCollector = HPUXNetworkCollector()
    assert obj_HPUXNetworkCollector._fact_class == HPUXNetwork
    assert obj_HPUXNetworkCollector._platform == 'HP-UX'
    assert obj_HPUXNetworkCollector._vendor == 'Hewlett-Packard'

# Generated at 2022-06-11 03:28:29.962882
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    h = HPUXNetwork(None)
    default_interfaces = h.get_default_interfaces()
    for i in default_interfaces.keys():
        if i == 'default_interface' or i == 'default_gateway':
            assert isinstance(default_interfaces[i], str)
        elif i == 'default_gateway_interface':
            assert isinstance(default_interfaces[i], str)



# Generated at 2022-06-11 03:28:32.143174
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.__class__.__name__ == 'HPUXNetworkCollector'


# Generated at 2022-06-11 03:28:34.659934
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    hpux_network = HPUXNetwork({}, None)
    assert hpux_network
    assert hpux_network.get_interfaces_info()
    assert hpux_network.get_default_interfaces()

# Generated at 2022-06-11 03:28:36.351098
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-11 03:28:38.301221
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fail = False
    try:
        HPUXNetworkCollector()
    except:
        fail = True
    assert fail == False
    return

# Generated at 2022-06-11 03:28:44.372554
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
    )

    network = HPUXNetwork()
    network.module = module

    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] != ''
    assert default_interfaces['default_gateway'] != ''



# Generated at 2022-06-11 03:28:45.608797
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-11 03:28:47.601940
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._platform == HPUXNetworkCollector._platform

# Generated at 2022-06-11 03:28:50.484662
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of HPUXNetworkCollector
    """
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'

# Generated at 2022-06-11 03:29:16.610944
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork().get_interfaces_info()
    for device in interfaces:
        print("Device: %s" % device)
        for key in interfaces[device]:
            print("  %s: %s" % (key, interfaces[device][key]))

if __name__ == '__main__':
    test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-11 03:29:24.754126
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    facts = dict()
    facts['module'] = dict()
    class fake_module(object):
        def __init__(self):
            self.params = dict()
        def get_bin_path(self, executable, required=False):
            return '/usr/bin/netstat'

# Generated at 2022-06-11 03:29:36.072614
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    HP-UXNetwork.get_default_interfaces returns default network interface
    and gateway address
    """
    class FakeModule:
        """
        Fake module for use with testing the get_default_interfaces method
        """
        def run_command(self):
            """
            Fake run_command method for use with testing the
            get_default_interfaces method
            """

# Generated at 2022-06-11 03:29:45.017464
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class HPUXNetwork """
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    network = HPUXNetwork()
    network.module.run_command = mock_run_command
    network.module.run_command.return_value = 0, NETSTAT_OUTPUT, ''
    expected = {'lan0': {'device': 'lan0', 'ipv4': {'address': '123.123.123.123', 'interface': 'lan0', 'network': '123.123.123.123'}}}
    ret = network.get_interfaces_info()
    assert ret == expected



# Generated at 2022-06-11 03:29:46.737446
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-11 03:29:49.624671
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    m = HPUXNetworkCollector()
    assert isinstance(m, HPUXNetworkCollector)
    assert isinstance(m.get_facts(), dict)
    assert m._platform == 'HP-UX'



# Generated at 2022-06-11 03:30:00.864510
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert (network_facts['default_interface'] == 'lan0')
    assert (network_facts['default_gateway'] == '192.168.0.1')
    assert (len(network_facts['interfaces']) > 0)
    for iface in network_facts['interfaces']:
        assert (network_facts[iface]['device'] == iface)
        assert (network_facts[iface]['ipv4']['address'] == '192.168.0.130')
        assert (network_facts[iface]['ipv4']['network'] == '192.168.0.0')

# Generated at 2022-06-11 03:30:06.155689
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = fake_ansible_module()
    module.run_command = fake_run_command
    module.run_command.side_effect = fake_run_command_effect
    net = HPUXNetwork(module)
    assert net.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}


# Generated at 2022-06-11 03:30:08.892114
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    opt_value = "/usr/bin/netstat"
    netstat_path = HPUXNetworkCollector.get_netstat_path(opt_value)
    assert netstat_path == opt_value



# Generated at 2022-06-11 03:30:16.313128
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    m = AnsibleModule(argument_spec={})
    m.run_command = mock_run_command
    n = HPUXNetwork()
    n.module = m
    interfaces = n.get_interfaces_info()
    assert 'lan0' in interfaces.keys()
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '192.168.1.3'
    assert interfaces['lan0']['ipv4']['network'] == '192.168.1.0'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '192.168.1.3'


# Generated at 2022-06-11 03:31:02.006434
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Test constructor of class HPUXNetworkCollector
    """
    network_collector_object = HPUXNetworkCollector()
    assert network_collector_object._fact_class is HPUXNetwork

# Generated at 2022-06-11 03:31:05.828974
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """
    net = HPUXNetwork(None)
    ifaces = net.get_interfaces_info()
    assert isinstance(ifaces, dict)



# Generated at 2022-06-11 03:31:08.268866
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    result = HPUXNetworkCollector(None)
    assert result._fact_class == HPUXNetwork
    assert result._platform == 'HP-UX'



# Generated at 2022-06-11 03:31:15.375396
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    module.get_bin_path = AnsibleModuleGetBinPathMock()
    module.run_command = AnsibleModuleRunCommandMock()
    hpux_network = HPUXNetwork(module)
    facts = hpux_network.populate()
    assert facts['default_gateway'] == '192.168.10.1'
    assert facts['default_interface'] == 'lan0'
    assert 'en0' in facts['interfaces']
    assert facts['en0']['ipv4']['address'] == '192.168.10.10'
    assert facts['en0']['ipv4']['network'] == '192.168.10.0'

# Generated at 2022-06-11 03:31:16.662055
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    my_net = HPUXNetworkCollector()
    assert my_net._platform == "HP-UX"

# Generated at 2022-06-11 03:31:21.365337
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({}, {})
    assert network.__module__ == 'ansible.module_utils.facts.network.hpu_ux.HPUXNetwork'
    assert network.platform == 'HP-UX'
    assert network.default_interface == 'lan2'
    assert network.interfaces == ['lan0', 'lan1', 'lan2', 'lan3', 'lan4', 'lan5', 'lan6', 'lan7']
    assert network.lan0['device'] == 'lan0'
    assert network.lan0['ipv4']['address'] == '15.12.128.132'
    assert network.lan1['device'] == 'lan1'
    assert network.lan1['ipv4']['address'] == '10.8.0.132'
    assert network.lan2['device']

# Generated at 2022-06-11 03:31:23.839991
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Return the correct subclass
    """
    obj = HPUXNetworkCollector()
    assert obj.__class__.__name__ == 'HPUXNetworkCollector'


# Generated at 2022-06-11 03:31:33.496560
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test to verify that HPUXNetwork class correctly parses interfaces
    information.
    """
    from ansible.module_utils.facts import ModuleStub

    module = ModuleStub()

    network = HPUXNetwork(module)
    out = '''
lan0            lan   1.1.1.1    lan0_subnet_mask 1.255.255.0
lan1            lan   2.2.2.2    lan1_subnet_mask 2.255.255.0
'''

# Generated at 2022-06-11 03:31:40.387613
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork.
    """
    network = HPUXNetwork()

    # Test if netstat exists
    network.module.run_command = lambda x: (1, '', 'ERROR')
    network.populate()


# Generated at 2022-06-11 03:31:46.591149
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Test the HP-UXNetwork.get_interfaces_info method
    """
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import Mock, patch
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.hpux.facts.network.\
        hpux import HPUXNetwork

    sample_output = {'eth0': {'ipv4': {'address': '172.18.34.11',
                                       'network': '172.18.34.0',
                                       'interface': 'eth0'}},
                     'eth1': {'ipv4': {'address': '172.18.35.11',
                                       'network': '172.18.35.0',
                                       'interface': 'eth1'}}}

   

# Generated at 2022-06-11 03:34:02.004681
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network_cli_mock = {
        '/usr/bin/netstat -niw': '''
Name    Mtu    Network       Address         Ipkts Ierrs Opkts Oerrs Collis Queue
lan0    1500   10.0.0.0      50.63.185.168   54    0     54    0     0      0
lan1    1500   172.16.0.0    172.16.0.212    50    0     50    0     0      0

'''
    }
    interface_names = [
        'lan0',
        'lan1'
    ]
    interface_addresses = [
        '50.63.185.168',
        '172.16.0.212'
    ]

# Generated at 2022-06-11 03:34:10.401579
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import platform
    import unittest
    module = FakeModule()
    module.run_command = FakeRunCommand
    net = HPUXNetwork(module)

# Generated at 2022-06-11 03:34:18.599376
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    unix_facts = HPUXNetwork()
    returned_facts = unix_facts.populate()

    assert returned_facts['default_interface'] == 'lan0'
    assert returned_facts['default_gateway'] == '172.31.64.1'
    assert returned_facts['interfaces'] == ['lan0', 'lan1']
    assert returned_facts['lan0']['ipv4']['address'] == '172.31.64.207'
    assert returned_facts['lan1']['ipv4']['address'] == '172.31.65.207'
    assert returned_facts['lan0']['ipv4']['network'] == '172.31.64.0'

# Generated at 2022-06-11 03:34:24.458804
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    class MyModule(object):
        def __init__(self):
            self.run_command_response = (0, "", "")
            self.run_command_responses = {}
            self.run_command_responses["/usr/bin/netstat -niw"] = (0, "lan9000 Flags: UP<BROADCAST,NOTRAILERS,RUNNING>\nlan3000 Flags: UP<BROADCAST,NOTRAILERS,RUNNING>", "")
            self.run_command_responses["/usr/bin/netstat -nr"] = (0, "default 172.16.0.1 UGS 0 0 lan9000 0", "")
            self.run_response = True
        def run_command(self, command):
            retval = self.run_command_responses.get(command)

# Generated at 2022-06-11 03:34:26.404261
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()

    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-11 03:34:27.482537
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_HPUXNetwork = HPUXNetwork()
    assert test_HPUXNetwork

# Generated at 2022-06-11 03:34:32.413634
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.network.hpuux import HPUXNetworkFactCollector
    from ansible.module_utils.facts.network.base import Network, NetworkCollector
    facts = FactCollector()
    network = Network(module=None)
    network.populate()
    hpux_collector = HPUXNetworkFactCollector(module=None)
    hpux_collector.collect()
    assert(hpux_collector)


# Generated at 2022-06-11 03:34:33.579501
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    rc, out, err = HPUXNetwork.get_interfaces_info()

# Generated at 2022-06-11 03:34:37.758261
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()
    module.params = {'gather_network_resources': 'no'}
    facts = HPUXNetwork(module).populate()
    default_interface = facts.get('default_interface')
    default_gateway = facts.get('default_gateway')
    interfaces = facts.get('interfaces')

    assert default_interface
    assert default_gateway
    assert interfaces


# Generated at 2022-06-11 03:34:43.062230
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpux_network = HPUXNetwork()
    hpux_network.module.run_command = lambda cmd: (0,
                                                   'default 192.168.1.11 UGS 8 2 0 lan0',
                                                   None)
    interfaces = hpux_network.get_default_interfaces()
    default_interf = {
        'default_interface': 'lan0',
        'default_gateway': '192.168.1.11',
    }
    assert default_interf == interfaces

