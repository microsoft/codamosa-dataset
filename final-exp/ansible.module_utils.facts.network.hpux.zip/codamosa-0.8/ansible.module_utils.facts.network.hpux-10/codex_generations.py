

# Generated at 2022-06-11 03:25:26.005924
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MyModule(object):
        def get_bin_path(self, name, required=True):
            return '/usr/bin/netstat'

        def run_command(self, cmd, check_rc=True):
            out = """\
Routing tables

default         lan22           00000000
default         0.0.0.0         00000000       UG
"""
            return 0, out, None

    module = MyModule()
    network = HPUXNetwork(module)

    # actual results
    netstat_path = network.module.get_bin_path('netstat')
    rc, out, err = network.module.run_command(netstat_path)
    default_interfaces = network.get_default_interfaces()

    # expected results
    netstat_rc = 0
    netstat_out = out
    net

# Generated at 2022-06-11 03:25:37.371968
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpxnet = HPUXNetwork()
    facts = {'module_hw': True}
    hpxnet.populate(facts)
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.1.1.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.1.1.2'
    assert facts['lan0']['ipv4']['network'] == '10.1.1.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-11 03:25:41.637221
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = {}
    hpux = HPUXNetworkCollector(facts=facts, module=None)
    assert hpux._platform == 'HP-UX'
    assert hpux._fact_class == HPUXNetwork
    assert hpux.facts == facts
    assert hpux.module is None

# Generated at 2022-06-11 03:25:44.587600
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc._fact_class == HPUXNetwork
    assert nc._platform == 'HP-UX'


# Generated at 2022-06-11 03:25:52.899040
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class test_HPUXNetwork(object):
        def run_command(self, cmd):
            class test_cmd(object):
                def __init__(self):
                    self.rc = 0
                    self.err = None

# Generated at 2022-06-11 03:26:04.072133
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockedModule:
        def run_command(self, cmd):
            class MockedFacts:
                def __init__(self):
                    self.default_interfaces_facts = \
                        {'default_interface': 'lan0',
                         'default_gateway': '10.1.1.1'}
                    self.interfaces = 'lan0'
                    self.netstat_interfaces_info = \
                        {'lan0': {'device': 'lan0',
                                  'ipv4': {'address': '10.1.1.2',
                                           'network': '10.1.1.0',
                                           'interface': 'lan0'}}}

# Generated at 2022-06-11 03:26:13.570673
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Arrange
    # Mock modules
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.network.hpux
    mocked_hpuxnetwork = ansible.module_utils.facts.network.hpux.HPUXNetwork
    mocked_hpuxnetwork_instance = mocked_hpuxnetwork.return_value
    mocked_hpuxnetwork_instance.get_default_interfaces.return_value = {'default_interface' : 'lan0',
                                                                       'default_gateway' : '10.1.1.1'}
    interfaces = {'lan0': {'ipv4': {'address': '10.1.1.11',
                                    'network': '10.1.1.0',
                                    'interface': 'lan0'}}}
    mocked_hpuxnetwork_

# Generated at 2022-06-11 03:26:17.722979
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    module.run_command = run_command
    obj = HPUXNetwork(module)
    default_interface_facts = obj.get_default_interfaces()
    assert default_interface_facts == {'default_interface': 'lan0',
                                       'default_gateway': '10.76.37.81'}



# Generated at 2022-06-11 03:26:19.776476
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'
    assert not hn.interfaces

# Generated at 2022-06-11 03:26:30.443670
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class ModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.return_value = (0,
                                 'lan0      lan0        lan0        192.168.0.1',
                                 '')
            self.run_command = self.run_command_mk

        def run_command_mk(self, args, check_rc=True, environ_update=None,
                           data=None, binary_data=False, path_prefix=None,
                           cwd=None, use_unsafe_shell=False, prompt_regex=None,
                           environ_fallback=(), encoding=None):
            return self.return_value

    module = ModuleMock(argument_spec={})

# Generated at 2022-06-11 03:26:37.155487
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-11 03:26:42.453703
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpux_network = HPUXNetwork(None)
    # Set a fake netstat command output
    hpux_network.module.run_command = \
        mock_run_command(get_output_default_interface())
    # Get the default interfaces
    default_interfaces = hpux_network.get_default_interfaces()
    # Validate the results
    results = get_expected_default_interfaces()
    assertEqual(default_interfaces, results)


# Generated at 2022-06-11 03:26:44.938015
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # create the object
    obj = HPUXNetwork(None)
    # test to see if the result is what you want
    result = obj.populate()
    assert result is not None


# Generated at 2022-06-11 03:26:48.578545
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_collector = HPUXNetworkCollector()
    assert net_collector._platform == 'HP-UX'
    assert net_collector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:26:51.641391
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict()
    )
    network = HPUXNetwork(module)
    assert network._platform == 'HP-UX'

# Generated at 2022-06-11 03:26:57.506977
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # create an instance
    hpux_network = HPUXNetwork()
    # invoke populate method
    network_facts = hpux_network.populate()

    # for each key of network_facts, verify that
    # the values are present in the returned facts
    for key in network_facts:
        assert key in network_facts

if __name__ == '__main__':
    test_HPUXNetwork_populate()

# Generated at 2022-06-11 03:26:58.902448
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector"""
    pass

# Generated at 2022-06-11 03:27:08.032594
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork.
    """
    from ansible.module_utils.facts.network.hpux.network import HPUXNetwork
    fact_class_instance = HPUXNetwork()
    # Output from mock:
    # /usr/bin/netstat -nr
    # default 172.16.122.2 UG 0 0  lan1
    # 127.0.0.0 127.0.0.1 UH 0 0  lo0
    # 172.16.122.0 172.16.122.2 U 0 0  lan1
    # /usr/bin/netstat -niw
    # Name  Mtu  Network  Address  Ipkts  Ierrs  Opkts  Oerrs  Coll  Queue
    # lan1  1500  172.16  172.

# Generated at 2022-06-11 03:27:11.081867
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    c = HPUXNetworkCollector()
    assert c.platform == 'HP-UX', 'platform should be HP-UX'

# Generated at 2022-06-11 03:27:13.231825
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    if hn is None:
        assert False

# Generated at 2022-06-11 03:27:32.243605
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_network = HPUXNetwork()
    hpux_network.module.run_command = run_command_unix_test
    facts = hpux_network.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '192.168.1.1'
    assert 'interfaces' in facts
    assert 'lan0' in facts['interfaces']
    assert facts['lan0']['device'] == 'lan0'
    assert 'ipv4' in facts['lan0']
    assert 'address' in facts['lan0']['ipv4']
    assert facts['lan0']['ipv4']['address'] == '192.168.1.43'
    assert 'network' in facts['lan0']['ipv4']
    assert facts

# Generated at 2022-06-11 03:27:43.489622
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(module)
    assert network.get_default_interfaces() == {'default_interface': 'lan9',
                                                'default_gateway': '192.168.1.1'}

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.hpuxtemplate import HPUXNetwork
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(module)
    facts = network.populate()
    module.exit_json(ansible_facts=facts)

# Generated at 2022-06-11 03:27:48.327702
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModuleMock()
    h = HPUXNetwork(module)
    interfaces = h.get_interfaces_info()
    assert interfaces
    assert len(interfaces) > 0
    for i in interfaces.keys():
        assert 'ipv4' in interfaces[i]


# Generated at 2022-06-11 03:27:51.529469
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Unit test for constructor of class HPUXNetwork
    """
    hpux_network = HPUXNetwork(None, None)
    assert hpux_network is not None



# Generated at 2022-06-11 03:27:52.516415
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    tc = HPUXNetworkCollector()



# Generated at 2022-06-11 03:27:59.385156
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Creating an instance of class HPUXNetwork
    net = HPUXNetwork()
    # Creating a class to prevent running the code and
    # to provide a return value for method get_interfaces_info
    class Test(object):

        @staticmethod
        def run_command(command):
            # return value of method get_interfaces_info
            return (0, "lan0      lan0   192.168.12.2/24", "")

    # Assign the method get_interfaces_info to return value of method run_command
    net.module.run_command = Test.run_command
    # Expected values for interfaces_info

# Generated at 2022-06-11 03:28:02.950241
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec=dict())
    nm = HPUXNetwork(module)
    assert nm.module == module
    assert nm.platform == 'HP-UX'



# Generated at 2022-06-11 03:28:06.743485
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    interface = net.get_default_interfaces()
    assert interface['default_interface'] == 'lan0'
    assert interface['default_gateway'] == '192.168.1.1'



# Generated at 2022-06-11 03:28:13.133224
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fact_module = Network()
    fact_module.module = MockModule()
    network_facts = HPUXNetwork().populate()
    assert type(network_facts['default_interface']) is str
    assert type(network_facts['default_gateway']) is str
    assert network_facts['interfaces'][0] == 'lan0'
    assert type(network_facts['lan0']) is dict
    assert network_facts['lan0']['ipv4']['address'] == '192.168.1.1'



# Generated at 2022-06-11 03:28:15.967565
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:28:44.044679
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Create a HPUXNetwork object
    hpux_network = HPUXNetwork(None)
    # Call get_interfaces_info method of HPUXNetwork
    interfaces = hpux_network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan0_v1' in interfaces
    assert interfaces['lan0']['ipv4']['network'] == '192.168.0.0'
    assert interfaces['lan0']['ipv4']['address'] == '192.168.0.223'
    assert interfaces['lan0_v1']['ipv4']['network'] == '192.168.3.0'
    assert interfaces['lan0_v1']['ipv4']['address'] == '192.168.3.223'

# Unit test

# Generated at 2022-06-11 03:28:53.613997
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    from ansible.module_utils.facts.facts.network.hppux import HPUXNetwork

    class AnsibleModuleFake:
        def __init__(self):
            pass

        def get_bin_path(self, command):
            if command == 'netstat':
                return 'netstat'

        def run_command(self, command):
            return 0, 'default 192.168.1.1 UGSR 0 0 lan0', None

    module = AnsibleModuleFake()

    net_obj = HPUXNetwork(module)
    assert net_obj.get_default_interfaces() == {'default_gateway': '192.168.1.1',
                                                'default_interface': 'lan0'}

# Generated at 2022-06-11 03:28:54.542391
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork


# Generated at 2022-06-11 03:28:56.909138
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    network.populate()
    print(network.interfaces)
    for item in network.interfaces:
        print(network[item])

# Generated at 2022-06-11 03:29:03.477835
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    fact_class = HPUXNetwork
    netstat_out = "Name  Mtu   Network     Address         Ipkts Ierrs    Opkts Oerrs  Coll lan0   1500 10.10.9.0       10.10.9.192     7679787    0    293888    0     0 lan1   1500 192.168.170.0  192.168.170.2  3397197    0      2456    0     0"
    netstat_rc = 0
    netstat_err = ''
    netstat_fun = lambda: (netstat_rc, netstat_out, netstat_err)
    fact_class.module = Mock(run_command=netstat_fun)
    interfaces = fact_class().get_interfaces_info()
    assert 'lan0' in interfaces.keys()

# Generated at 2022-06-11 03:29:05.242428
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():

    instance = HPUXNetworkCollector()
    assert(instance._platform == 'HP-UX')


# Generated at 2022-06-11 03:29:12.248132
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )
    n = HPUXNetwork(module)
    assert n.platform == 'HP-UX'
    assert n.module == module
    assert n._default_interface is None
    assert n._default_gateway is None
    assert n._interfaces == []
    assert n._interfaces_ipv4 == {}



# Generated at 2022-06-11 03:29:16.964184
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod_args = dict(
        config_options=dict(
            gather_subset=['!all', 'network']
        ),
        ansible_facts=dict()
    )

    net = HPUXNetwork(created_at_the_end_of_constructor=True, **mod_args)
    assert net.platform == 'HP-UX'

# Generated at 2022-06-11 03:29:24.943959
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Create a HPUXNetwork object
    hn = HPUXNetwork()

    # Inspect the fields of this object
    # print(hn.__dict__)

    # Simulate a netstat command
    out = '''
    lan0      link#1      UP block       RUNNING        5000/10000    lan0:192.168.0.10
    '''

    # Simulate a run_command for the netstat command
    hn.module.run_command = lambda x: (0, out, '')

    # Call the get_interfaces_info method
    interfaces = hn.get_interfaces_info()

    # Check the result
    assert interfaces['lan0']['ipv4']['address'] == '192.168.0.10'
    assert len(interfaces) == 1

# Generated at 2022-06-11 03:29:32.048936
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hl = HPUXNetwork()
    hl.module = FakeModule()
    hl.module.run_command = lambda x: (0, "default   10.10.10.1      UG       hme0", '')
    default_interfaces_facts = hl.get_default_interfaces()
    assert default_interfaces_facts == {'default_interface': 'hme0', 'default_gateway': '10.10.10.1'}



# Generated at 2022-06-11 03:30:14.186075
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    instance = HPUXNetworkCollector()
    assert isinstance(instance, NetworkCollector)
    assert isinstance(instance, object)
    assert instance._fact_class == HPUXNetwork
    assert instance._platform == 'HP-UX'


# Generated at 2022-06-11 03:30:16.477873
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetwork(module=module)
    assert isinstance(network_collector, HPUXNetwork)



# Generated at 2022-06-11 03:30:19.414163
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector()
    assert isinstance(hpux, HPUXNetworkCollector)
    assert hpux._fact_class is HPUXNetwork
    assert hpux._platform == 'HP-UX'

# Generated at 2022-06-11 03:30:21.878320
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Unit test for constructor of class HPUXNetwork
    """
    network = HPUXNetwork()
    assert network.fact_subclass == 'network'
    assert network.platform == 'HP-UX'



# Generated at 2022-06-11 03:30:26.583859
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_net = HPUXNetwork({})
    facts = hpux_net.populate()
    print(repr(facts))
    if '127.0.0.1' in facts['default_interface']:
        print("OK")
        exit(0)
    else:
        print("Failed")
        exit(1)



# Generated at 2022-06-11 03:30:28.101895
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-11 03:30:31.806540
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False)
    net = HPUXNetwork(module=test_module)
    interfaces = net.get_interfaces_info()
    assert isinstance(interfaces, dict)



# Generated at 2022-06-11 03:30:40.447600
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    This method is being called by the constructor of the HPUXNetwork class. The
    method is called during the initialization of the HPUXNetwork class.
    The method get_interfaces_info gets the content of the output of the command
    /usr/bin/netstat -niw and stores the output into a list. It then iterates
    over the list and splits the lines. If a word begins with lan, it is
    interpreted as a network device and the name of the network device is stored
    in the first index of the list. The name of the network device is then used
    as key for the dictionary. A dictionary key is created and set to the
    dictionary interfaces. The dictionary key is set to the dictionary
    interfaces and contains the name of the network device and the ipv4 address
    of the network device.
    """

# Generated at 2022-06-11 03:30:45.006490
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = HPUXNetwork()
    test_module.module.run_command = lambda *args, **kwargs: (0, 'default 127.0.0.0 UGS lan0', '')
    default_interfaces = test_module.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0', 'default_gateway': '127.0.0.0'}


# Generated at 2022-06-11 03:30:47.317613
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    netcoll = HPUXNetworkCollector()
    assert netcoll._fact_class is HPUXNetwork
    assert netcoll._platform == 'HP-UX'


# Generated at 2022-06-11 03:32:36.925167
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork(dict())
    assert isinstance(hpn, HPUXNetwork)
    assert hpn.platform == 'HP-UX'

# Unit testing for default_interface

# Generated at 2022-06-11 03:32:38.234995
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-11 03:32:44.243399
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    d = dict(interfaces=['lan0', 'lan1'], default_interface='lan0',
             lan0=dict(device='lan0', ipv4=dict(network='192.168.1.0',
                                                address='192.168.1.58')),
             lan1=dict(device='lan1', ipv4=dict(network='10.10.10.0',
                                                address='10.10.10.30')))
    net = HPUXNetwork(module)
    result = net.get_interfaces_info()
    assert result == d
    module.exit_json(changed=False, ansible_facts=dict(test='test'))

# Generated at 2022-06-11 03:32:48.259794
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    network_collector = HPUXNetworkCollector(module)
    network = HPUXNetwork(network_collector)
    default_interfaces = network.get_default_interfaces()
    assert(len(default_interfaces) == 2)
    assert(default_interfaces['default_interface'] == 'lan0')
    assert(default_interfaces['default_gateway'] == '10.0.0.1')



# Generated at 2022-06-11 03:32:50.187628
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpu = HPUXNetworkCollector()
    assert hpu._platform == 'HP-UX'
    assert hpu._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:32:51.441369
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'



# Generated at 2022-06-11 03:32:59.150868
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # HPUXNetworkCollector is a subclass of NetworkCollector
    assert issubclass(HPUXNetworkCollector, NetworkCollector)

    # Create an object for testing
    network_collector_obj = HPUXNetworkCollector()

    # _fact_class is a class attribute
    assert isinstance(network_collector_obj._fact_class, type)

    # _fact_class is HPUXNetwork
    assert network_collector_obj._fact_class == HPUXNetwork

    # _platform is a class attribute
    assert isinstance(network_collector_obj._platform, str)

    # _platform is 'HP-UX'
    assert network_collector_obj._platform == 'HP-UX'



# Generated at 2022-06-11 03:33:07.250107
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class FakeModule(object):
        def run_command(self, cmd):
            out = """
Name    Mtu    Network Address             Ipkts Ierrs Opkts Oerrs Coll
lan0    1500   123.123.123.0  123.123.123.1     0     0     0     0    0
lan2    1500   234.234.234.0  234.234.234.1     0     0     0     0    0
            """
            return (0, out, '')

    network = HPUXNetwork(FakeModule())
    result = network.get_interfaces_info()
    assert result['lan0']['device'] == 'lan0'
    assert result['lan0']['ipv4']['address'] == '123.123.123.1'

# Generated at 2022-06-11 03:33:11.084974
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module_mock = Mock()
    module_mock.run_command.return_value = (0, 'lan0: 64 packets,  10,536 bytes', '')
    network_facts = HPUXNetwork(module=module_mock)
    assert network_facts.get_interfaces_info() == {'lan0': {'device': 'lan0'}}


# Generated at 2022-06-11 03:33:14.447535
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    out = '''Interface: lan6005b8 Index: 6 Type: Ethernet\
Speed: 100 MBit MTU: 1500 Address: 0x6005b8'''
    interfaces = network.get_interfaces_info()
    assert interfaces['lan6005b8']['ipv4']['network'] == ''