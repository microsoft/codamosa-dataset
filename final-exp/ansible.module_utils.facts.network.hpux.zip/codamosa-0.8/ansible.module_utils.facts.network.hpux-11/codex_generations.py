

# Generated at 2022-06-11 03:25:19.628195
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(dict())
    assert network.platform == "HP-UX"
    assert network.interfaces == []
    assert len(network.interfaces) == 0



# Generated at 2022-06-11 03:25:22.110180
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    nc = HPUXNetworkCollector()
    assert nc._platform == 'HP-UX'
    assert nc._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:25:23.888489
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    collector = HPUXNetworkCollector()

    # Returns Network class object
    assert isinstance(collector.collect()[0], HPUXNetwork)

# Generated at 2022-06-11 03:25:29.387842
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    phn = hn.get_network_facts()
    assert phn.platform == 'HP-UX'
    hn_facts = hn.collect()
    assert 'default_interface' in hn_facts
    assert 'interfaces' in hn_facts
    assert hn_facts['interfaces']
    interface_names = hn_facts.get('interfaces', [])
    for interface in interface_names:
        assert interface in hn_facts
        assert 'ipv4' in hn_facts[interface]


# Generated at 2022-06-11 03:25:37.040107
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netstat_path = '/usr/bin/netstat'
    default_interfaces = {}
    rc, out, err = run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interfaces['default_interface'] = words[4]
                default_interfaces['default_gateway'] = words[1]
    return default_interfaces


# Generated at 2022-06-11 03:25:42.896897
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_HPUXNetwork = HPUXNetwork()
    out = "lo0        lan0                  lan0"
    interfaces_info = test_HPUXNetwork.get_interfaces_info(out)
    assert interfaces_info['lan0']['device'] == 'lan0'
    assert interfaces_info['lan0']['ipv4']['address'] == 'lan0'

# Generated at 2022-06-11 03:25:48.232587
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_network = HPUXNetwork(module)
    default_interfaces = hpux_network.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0',
                                  'default_gateway': '10.168.0.1'}

# Generated at 2022-06-11 03:25:58.661871
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # This test is not generic. It is based on the output of netstat -nr command
    # (see below)
    out = """Routing tables

Internet:
Destination        Gateway           Flags   Refs     Use   Interface
default            10.62.51.254      UG         3        0 lan1000
10.62.51/24        10.62.51.254      U         18    64538 lan1000
127.0.0.1          127.0.0.1         UH         5        0 lo0
224.0.0/4          127.0.0.1         U         12        0 lo0
224.0/4            127.0.0.1         U         12        0 lo0

"""

# Generated at 2022-06-11 03:26:02.052114
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """ Unit test for constructor of class HPUXNetworkCollector
    """
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-11 03:26:03.817532
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpuxnet = HPUXNetwork()
    assert hpuxnet != None


# Generated at 2022-06-11 03:26:16.963460
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class Module:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    out = """
Kernel Interface table
lan0      link   LLA  Group  Flags   MTU  State  Over
lan0      lo0    X    -      UP      1500 UP      IP
lan0      lan0   X    -      UP      1500 UP      IP
lan0      lan1   X    -      UP      1500 UP      IP
    """
    result = {"interfaces": ['lo0', 'lan0', 'lan1']}

# Generated at 2022-06-11 03:26:27.562797
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_ins = HPUXNetwork()
    net_ins.module = MockModule()
    facts = net_ins.populate()
    assert facts['default_interface'] == 'lan1'
    assert facts['default_gateway'] == '10.17.92.2'
    assert facts['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3', 'lan4', 'lan5', 'lan6', 'lan7', 'lan8', 'lan9', 'lan10', 'lan11', 'lan12', 'lan13', 'lan14', 'lan15', 'lan16', 'lan17', 'lan18', 'lan19', 'lan20', 'lan21', 'lan22', 'lan23']


# Generated at 2022-06-11 03:26:31.079365
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Create a HPUXNetwork instance and check if it has the correct data.
    """
    network = HPUXNetwork({})
    assert network.interfaces == []
    assert network.default_interface is None
    assert network.default_gateway is None

# Generated at 2022-06-11 03:26:32.143433
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net_test_obj = HPUXNetwork()
    assert net_test_obj.platform == "HP-UX"

# Generated at 2022-06-11 03:26:40.230100
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ Unit test class HPUXNetwork.
        All interactions with underlying system are mocked. Tests
        that:
          - HPUXNetwork returns a dictionary named HPUXNetwork_facts
    """
    # Set up the mock AnsibleModule class
    from ansible.module_utils.facts import Network
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    import ansible.module_utils.facts.network.hpux

    class TestAnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=False, check_invalid_arguments=True, mutually_exclusive=None, required_together=None, required_one_of=None, add_file_common_args=False):
            self.params = {}
            self.exit_json = lambda a,**kwargs: True

# Generated at 2022-06-11 03:26:46.839680
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    netstat_path = '/usr/bin/netstat'
    module = MockModule(netstat_path)
    network = HPUXNetwork(module)
    rc, out, err = module.run_command(netstat_path + " -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                default_interface = words[4]
                default_gateway = words[1]
    network_facts = network.get_default_interfaces()
    network_facts['default_interface'] == default_interface
    network_facts['default_gateway'] == default_gateway


# Generated at 2022-06-11 03:26:47.917404
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    NetworkCollector('HP-UX')

# Generated at 2022-06-11 03:26:50.381419
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class is HPUXNetwork
    assert c.collect() == {}

# Generated at 2022-06-11 03:26:55.535813
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    network = HPUXNetwork(module)
    network.get_default_interfaces()
    assert module.run_command.call_count == 1
    cmd = module.run_command.call_args[0][0]
    assert cmd == '/usr/bin/netstat -nr'


# Generated at 2022-06-11 03:26:57.411393
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork(dict()) is not None

# Generated at 2022-06-11 03:27:03.970110
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'

# Generated at 2022-06-11 03:27:06.232388
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    interfaces = HPUXNetwork(module).get_interfaces_info()
    print(interfaces)

# Generated at 2022-06-11 03:27:10.595670
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_HPUXNetwork = HPUXNetwork(None, None)
    interfaces = test_HPUXNetwork.get_interfaces_info()
    assert interfaces['lan0'] == {'ipv4': {'interface': 'lan0', 'address': '172.16.1.20',
                                           'network': '172.16.1.0'}, 'device': 'lan0'}

# Generated at 2022-06-11 03:27:17.961917
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.collect()

    assert network_facts['default_interface'] is not None
    assert network_facts['default_gateway'] is not None

    for iface in network_facts['interfaces']:
        assert network_facts[iface] is not None
    assert 'lo0' not in network_facts['interfaces']

# Generated at 2022-06-11 03:27:27.456151
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fact_module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['all'], type='list'))
    )
    network_collector = HPUXNetworkCollector(fact_module)
    network_facts = network_collector.collect(None, None)
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts
    assert 'interfaces' in network_facts
    assert 'lo0' in network_facts
    assert 'ipv4' in network_facts['lo0']
    assert 'address' in network_facts['lo0']['ipv4']
    assert 'network' in network_facts['lo0']['ipv4']


# Generated at 2022-06-11 03:27:34.848085
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # example output from /usr/bin/netstat -niw
    test1 = '''lan0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2 inet 172.20.11.23 netmask ffffff00 broadcast 172.20.11.255
lan0:1: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2 inet 172.20.11.30 netmask ffffff00 broadcast 172.20.11.255
lan1: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 3 inet 172.20.10.23 netmask ffffff00 broadcast 172.20.10.255'''
    hp

# Generated at 2022-06-11 03:27:46.650598
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    import platform

    # Mock the module and class
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = '/usr/bin/netstat'
    class_mock = MagicMock()
    class_mock.module = module_mock
    class_mock.run_command.return_value = (0, '', '')

    # Mock the values returned by the methods

# Generated at 2022-06-11 03:27:47.423635
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    assert True

# Generated at 2022-06-11 03:27:56.263834
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    hpx = HPUXNetwork(module)
    hpx.module.run_command = Mock(return_value=(None, "", ""))
    hpx.module.run_command = Mock(return_value=(0,
                                                "default default NETWORK/IP "
                                                "192.168.0.0 192.168.0.1 UGS",
                                                ""))
    expected_default_interfaces = {'default_interface': '192.168.0.1',
                                   'default_gateway': 'default'}
    result = hpx.get_default_interfaces()
    assert result == expected_default_interfaces


# Generated at 2022-06-11 03:28:06.694565
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Runs unit tests for method populate
    """
    # Initialize the class
    h = HPUXNetwork()

    # Check if it is HPUX
    assert h.platform == 'HP-UX'

    # Define facts dictionary
    h.module = MagicMock(run_command=MagicMock(return_value=(0, 'stdout',
                                                             'stderr')))
    h.module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')

    # Test get_interfaces_info

# Generated at 2022-06-11 03:28:22.796137
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network = HPUXNetwork()
    network.module = MockModule(params=None)

    network.get_default_interfaces = Mock(return_value=
                                          {'default_interface': 'lan0',
                                           'default_gateway': '10.0.0.1'})
    network.get_interfaces_info = Mock(return_value=
                                       {'lan0': {'device': 'lan0',
                                                 'ipv4': {'address': '10.0.0.3',
                                                          'network': '10.0.0.0',
                                                          'interface': 'lan0'}}})
    network.populate()
    assert network.facts['default_interface'] == 'lan0'

# Generated at 2022-06-11 03:28:32.774963
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={
    })

    network_module = HPUXNetwork(module)
    network_facts = network_module.populate()

    assert(network_module.platform == 'HP-UX')
    assert(network_facts['default_interface'] == 'lan0')
    assert(network_facts['default_gateway'] == '10.1.1.1')
    assert(network_facts['interfaces'] == ['lan0'])
    assert(network_facts['lan0']['ipv4']['address'] == '10.1.1.101')
    assert(network_facts['lan0']['ipv4']['network'] == '10.1.1.0')

# Generated at 2022-06-11 03:28:34.387387
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork(dict())
    assert hn is not None


# Generated at 2022-06-11 03:28:36.350626
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_coll = HPUXNetworkCollector()
    assert net_coll._fact_class == HPUXNetwork
    assert net_coll._platform == 'HP-UX'


# Generated at 2022-06-11 03:28:38.209090
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn is not None
    assert hn._platform == 'HP-UX'
    assert hn._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:28:49.235862
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    interfaces = {'lan0': {'device': 'lan0',
                           'ipv4': {'address': '10.220.88.1',
                                    'network': '10.220.88.0',
                                    'interface': 'lan0',
                                    'address': '10.220.88.1'}}}

    # Define the output of command netstat -niw
    out = ('Name  Mtu   Network       Address            Ipkts      Ierrs  Opkts      Oerrs  Coll')
    out = out + ('lan0  1500  10.220.88.0  10.220.88.1                 125082          248262          0')

# Generated at 2022-06-11 03:28:54.175388
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Test case to check if object of HPUXNetwork class is created
    successfully.
    """
    hpu = HPUXNetwork({})
    assert hpu is not None
    # Assert type of object from the class HPUXNetwork
    assert isinstance(hpu, HPUXNetwork)
    # Assert platform used
    assert hpu.platform == 'HP-UX'

# Generated at 2022-06-11 03:28:56.909100
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector is not None
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-11 03:29:00.024757
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = HPUXNetwork({})
    test_module.module.run_command = run_command_mock
    network_facts = test_module.populate()
    assert network_facts['default_interface'] == "lan0"
    assert network_facts['default_gateway'] == "10.1.1.1"


# Generated at 2022-06-11 03:29:06.604707
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule(
        params={'gather_subset': '!all', 'gather_network_resources': 'network'})

    hpux_network = HPUXNetwork(module)
    network_facts = hpux_network.populate()

    assert 'lo0' in network_facts['interfaces']
    assert 'lan2' in network_facts['interfaces']
    assert 'default_interface' in network_facts
    assert 'default_gateway' in network_facts



# Generated at 2022-06-11 03:29:24.467230
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Runs 'ifconfig -a' command and checks that the number of interfaces
    is the one returned by OutputParser.ParseOutput method.
    """
    hpux = HPUXNetwork()
    hpux.module = get_mock_module()
    hpux.module.run_command = get_mock_run_command()
    # Return the same output as ifconfig -a command
    hpux.module.run_command.return_value = (0, HPUX_NETSTAT_OUTPUT, '')
    ansible_facts = hpux.populate()
    assert len(ansible_facts['interfaces']) == 7



# Generated at 2022-06-11 03:29:26.663518
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector(None)
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-11 03:29:38.235210
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    HPUXNetwork.populate Unit Test
    """
    test_HPUXNetwork = HPUXNetwork({})
    test_HPUXNetwork.module = DummyAnsibleModule(params={})
    test_HPUXNetwork.get_interfaces_info = mock_get_interfaces_info
    test_network_facts = test_HPUXNetwork.populate()
    assert 'default_interface' in test_network_facts
    assert test_network_facts['default_interface'] == 'lan1000'
    assert 'interfaces' in test_network_facts
    assert test_network_facts['interfaces'] == ['lan1000', 'lan1001']
    assert 'lan1000' in test_network_facts
    assert 'ipv4' in test_network_facts['lan1000']
    assert 'address' in test

# Generated at 2022-06-11 03:29:40.519034
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict()
    )
    network_facts = HPUXNetwork(module)
    assert network_facts.populate() is not None

# Generated at 2022-06-11 03:29:46.030768
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = 'hpux'
    if module not in sys.modules:
        sys.modules[module] = MockModule()
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network = HPUXNetwork(module)
    network.get_default_interfaces()
    assert network.get_default_interfaces()[
        'default_interface'] == 'lan0'
    assert network.get_default_interfaces()['default_gateway'] == '10.104.255.254'


# Generated at 2022-06-11 03:29:47.114441
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:29:49.003742
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
  assert HPUXNetworkCollector._platform == 'HP-UX'
  assert HPUXNetworkCollector._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:29:54.559431
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    hpux_network = HPUXNetwork(module)

    expected_default_interfaces = {'default_interface': 'lan5',
                                   'default_gateway': '10.0.9.129'}

    assert hpux_network.get_default_interfaces() == expected_default_interfaces



# Generated at 2022-06-11 03:29:57.229144
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    nm = HPUXNetwork()
    rc, out, err = nm.module.run_command("/usr/bin/netstat -niw")
    interfaces = nm.get_interfaces_info()
    assert interfaces != {}

# Generated at 2022-06-11 03:30:07.540311
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    nm = HPUXNetwork(module)
    nm.get_default_interfaces = MagicMock(return_value={'default_interface': 'lan0', 'default_gateway': '192.168.1.1'})
    nm.get_interfaces_info = MagicMock(return_value={'lan0': {'device': 'lan0', 'ipv4': {'address': '192.168.1.2'}}})
    nm.populate()
    assert nm.get_default_interfaces.called
    assert nm.get_interfaces_info.called
    assert 'default_interface' in nm.fact
    assert 'default_gateway' in nm.fact
    assert 'interfaces' in nm.fact

# Generated at 2022-06-11 03:30:38.753110
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    m_get_bin_path = MagicMock(return_value="/usr/bin/netstat")
    module.get_bin_path = m_get_bin_path


# Generated at 2022-06-11 03:30:47.052490
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}
    test_object = {}
    words = []

    interfaces["lan0"] = {'device': "lan0"}
    interfaces["lan0"]['ipv4'] = {'address': "0.0.0.0"}
    interfaces["lan0"]['ipv4'] = {'network': "0.0.0.0",
                                  'interface': "lan0",
                                  'address': "0.0.0.0"}

    test_object["lan0"] = {'device': "lan0"}
    test_object["lan0"]['ipv4'] = {'address': "0.0.0.0"}

# Generated at 2022-06-11 03:30:50.939871
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)

    interfaces = network.get_interfaces_info()
    if len(interfaces) > 0:
        module.exit_json(ansible_facts={'ansible_network_resources': interfaces})
    else:
        module.fail_json(msg="No interfaces found!")



# Generated at 2022-06-11 03:30:53.661517
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    fn = HPUXNetwork()
    assert fn.platform == 'HP-UX'
    assert fn.default_interface == ''
    assert not fn.interfaces
    assert not fn._interfaces
    assert not fn.default_gateway

# Generated at 2022-06-11 03:30:54.220584
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()


# Generated at 2022-06-11 03:31:00.492081
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Test if the method get_interfaces_info of class HPUXNetwork returns
    the expected dictionary.
    """
    network = HPUXNetwork({})
    network.run_command = test_run_command
    interfaces_info = network.get_interfaces_info()
    expected_interfaces_info = {'lan0': {'device': 'lan0',
                                         'ipv4': {'network': '192.168.1.0',
                                                  'interface': 'lan0',
                                                  'address': '192.168.1.240'}}}
    assert(interfaces_info == expected_interfaces_info)

# Define a run_command method to be used by the test method above

# Generated at 2022-06-11 03:31:09.787947
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    module.run_command = Mock(return_value=(0, netstat_output, 'err'))
    network = HPUXNetwork(module)
    network_facts = network.populate()
    default_interface_expected = 'lan8000'
    default_gateway_expected = '10.0.2.2'
    assert network_facts['default_interface'] == default_interface_expected
    assert network_facts['default_gateway'] == default_gateway_expected
    interfaces_expected = ['lan8000']
    assert network_facts['interfaces'] == interfaces_expected
    assert network_facts['lan8000']['device'] == 'lan8000'
    assert network_facts['lan8000']['ipv4']['network'] == '10.0.2.0'

# Generated at 2022-06-11 03:31:10.921978
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'

# Generated at 2022-06-11 03:31:12.388365
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert(collector.platform == 'HP-UX')

# Generated at 2022-06-11 03:31:19.225525
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(test_module)

# Generated at 2022-06-11 03:32:34.212714
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    out = 'default       192.168.100.1 UG  0    0    lan0'
    network.run_command = lambda x: (0, out, '')
    result = {'default_interface': 'lan0', 'default_gateway': '192.168.100.1'}
    assert network.get_default_interfaces() == result


# Generated at 2022-06-11 03:32:36.661329
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module = FakeAnsibleModule()
    assert net.get_default_interfaces() == {'default_gateway': '172.22.16.254', 'default_interface': 'lan0'}



# Generated at 2022-06-11 03:32:38.020849
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_instance = HPUXNetwork()
    output = test_instance.get_interfaces_info()
    assert 'lan0' in output

# Generated at 2022-06-11 03:32:43.288311
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_class = HPUXNetwork()
    test_class.module = FakeModule()
    test_interfaces = test_class.get_interfaces_info()
    assert len(test_interfaces) == 2
    assert test_interfaces['lan0'] == {'device': 'lan0', 'ipv4': {'address': '10.0.0.17', 'network': '10.0.0.0', 'interface': 'lan0'}}
    assert test_interfaces['lan1'] == {'device': 'lan1', 'ipv4': {'address': '10.0.0.32', 'network': '10.0.0.0', 'interface': 'lan1'}}


# Generated at 2022-06-11 03:32:44.155113
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    assert hpn.platform == 'HP-UX'

# Generated at 2022-06-11 03:32:50.891452
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    # Create a module object for testing -
    # This creates a module and fills in the argument dictionary
    # which is used as keyword arguments for the HPUXNetwork class
    # constructor. The bin_path array is also created for storing
    # the pathname to the netstat command.
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    module.bin_path = dict()
    module.bin_path['netstat'] = '/usr/bin/netstat'
    module.run_command = run_command_mock
    run_command_mock.rc = 0
    run_command_mock.out = "default   192.168.0.1        UG        0   en0         default"
    run_command_mock.err = ""

    # Initialise the

# Generated at 2022-06-11 03:32:53.214658
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # check that fact class is HPUXNetwork
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-11 03:32:55.226043
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_facts_obj = HPUXNetwork()
    assert network_facts_obj.platform == 'HP-UX'


# Generated at 2022-06-11 03:32:56.926304
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork(dict())
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-11 03:32:58.293430
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn._platform == 'HP-UX'

# Generated at 2022-06-11 03:35:06.665215
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork(dict())

    assert hpux_network.get_default_interfaces() is not None
    assert hpux_network.get_interfaces_info() is not None

# Generated at 2022-06-11 03:35:08.161366
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork.get_interfaces_info()

    assert len(interfaces) > 0

# Generated at 2022-06-11 03:35:09.774498
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeAnsibleModule()
    hpuxNetwork = HPUXNetwork(module)
    assert hpuxNetwork is not None


# Generated at 2022-06-11 03:35:14.116984
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.facts.network.hpux.HPUXNetwork import HPUXNetwork
    net = HPUXNetwork(None)
    assert net.get_interfaces_info()['lan0'] == {'ipv4': {'interface': 'lan0',
                                                         'network': '10.128.0.0',
                                                         'address': '10.128.1.50'},
                                                 'device': 'lan0'}
