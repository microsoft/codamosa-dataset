

# Generated at 2022-06-11 03:25:27.720594
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpuxtools import HPUXNetwork

    # Define the names of each interface and its IPV4 address
    interface_dict = {'lan0': '10.31.209.130',
                      'lan1': '10.31.208.130',
                      'lan2': '10.31.207.130',
                      'lan3': '10.31.206.130',
                      'lan4': '10.31.205.130',
                      'lan5': '10.31.204.130',
                      'lan6': '10.31.203.130',
                      'lan7': '10.31.202.130'}

    # Define the command that will be executed to test the method
    command = ('/usr/bin/netstat -niw')

    # Create

# Generated at 2022-06-11 03:25:37.891310
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpux_network = HPUXNetwork()
    out = "default 192.168.0.0 UG   0 0    lan0\n"
    hpux_network.module.run_command = lambda *args, **kargs: (0, out, '')
    default_interfaces_facts = hpux_network.get_default_interfaces()
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.168.0.0'


# Generated at 2022-06-11 03:25:38.793333
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-11 03:25:41.088256
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Test HPUXNetwork class"""
    module = MockModule()
    hp_net = HPUXNetwork(module)


# Generated at 2022-06-11 03:25:43.740459
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork(module=None)
    assert hpn.platform == 'HP-UX'


# Generated at 2022-06-11 03:25:45.544934
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    instance = HPUXNetworkCollector()
    assert instance.platform == 'HP-UX'


# Generated at 2022-06-11 03:25:47.391852
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetword1 = HPUXNetwork()
    assert HPUXNetword1 is not None


# Generated at 2022-06-11 03:25:53.999394
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    fact_network = HPUXNetwork()

    # Run the method get_default_interfaces of class HPUXNetwork as a unit test
    default_interfaces_facts = fact_network.get_default_interfaces()

    # Check if the returned object has the attributes we expect
    assert len(default_interfaces_facts) == 2
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts

    # Check if the returned object has the expected values for the attributes
    assert default_interfaces_facts['default_interface'] == "lan1"
    assert default_interfaces_facts['default_gateway'] == "192.168.1.1"


# Generated at 2022-06-11 03:26:05.004662
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
        'lan0\t163617\t0\t0\t131.15.5.5\t0\t0\t0\tlan0\n'
        'lan0\t163617\t0\t0\t128.15.5.5\t0\t0\t0\tlan0\n'
        'lan1\t163617\t0\t0\t131.15.5.6\t0\t0\t0\tlan1\n'
        'lan2\t163617\t0\t0\t131.15.5.6\t0\t0\t0\tlan2\n', ''))
    network

# Generated at 2022-06-11 03:26:11.323773
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    netstat_path = module.get_bin_path('netstat')
    f = HPUXNetwork(module)
    default_interfaces = f.get_default_interfaces()
    if not netstat_path:
        assert default_interfaces == {}
    else:
        assert default_interfaces['default_gateway'] == '172.17.1.254'
        assert default_interfaces['default_interface'] == 'lan1'



# Generated at 2022-06-11 03:26:16.780781
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpuxnetwork = HPUXNetworkCollector()

# Generated at 2022-06-11 03:26:19.928503
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    result = {'default_gateway': '10.1.1.1', 'default_interface': 'lan0'}
    assert result == HPUXNetwork(module).get_default_interfaces()


# Generated at 2022-06-11 03:26:30.605648
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class module:
        def run_command(self, command):
            out = '''
                lan0           Link encap:Ethernet  HWaddr 00:02:55:24:7e:d8  
                              inet addr:192.168.234.150  Bcast:192.168.234.255  Mask:255.255.255.0
                lan1           Link encap:Ethernet  HWaddr 00:02:55:24:7e:d9  
                              inet addr:192.168.235.150  Bcast:192.168.235.255  Mask:255.255.255.0
            '''
            interfaces = {}
            rc = 0
            err = ''
            lines = out.splitlines()
            for line in lines:
                words = line.split()

# Generated at 2022-06-11 03:26:38.867613
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ Unit test to check the correct behavior of method populate.
    """
    from ansible.module_utils.facts.network.hpuux import HPUXNetwork
    facts = HPUXNetwork()
    network_facts = facts.populate()

    # check interfaces are well detected (at least sc0, lan0 and lan1 on my VM)
    assert 'sc0' in network_facts['interfaces']
    assert 'lan0' in network_facts['interfaces']
    assert 'lan1' in network_facts['interfaces']

    # check default gateway has been correctly parsed
    assert 'default_gateway' in network_facts
    assert network_facts['default_gateway'] == '192.168.10.1'

    # check default interface has been correctly parsed
    assert 'default_interface' in network_facts
    assert network_facts

# Generated at 2022-06-11 03:26:42.415242
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """test_HPUXNetwork_get_interfaces_info tests get_interfaces_info method of
    class HPUXNetwork for expected output"""

    test_HPUXNetwork = HPUXNetwork()

    interfaces = test_HPUXNetwork.get_interfaces_info()

    assert len(interfaces) is not 0

# Generated at 2022-06-11 03:26:45.521502
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    assert network_facts['default_gateway'] == '10.0.0.1'



# Generated at 2022-06-11 03:26:57.072212
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    :return:
    """
    from ansible.module_utils.facts.network.hpu_lldp import HPUXNetwork

    myNet = HPUXNetwork()
    myNet.module = AnsibleModuleMock()
    myNet.module.get_bin_path.return_value = None
    myNet_facts = myNet.populate()
    assert len(myNet_facts.keys()) == 0

    myNet = HPUXNetwork()
    myNet.module = AnsibleModuleMock()
    myNet.module.run_command.return_value = (0, '', '')
    myNet.module.get_bin_path.return_value = '/usr/bin/netstat'
    myNet_facts = myNet.populate()


# Generated at 2022-06-11 03:26:58.057667
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass


# Generated at 2022-06-11 03:27:07.382653
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork"""
    class MockModule(object):
        def __init__(self):
            self.params = {}

# Generated at 2022-06-11 03:27:12.164866
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}
    interfaces = HPUXNetwork.get_interfaces_info(None)
    assert 'lan9250' in interfaces.keys()
    assert interfaces['lan9250']['device'] == 'lan9250'
    assert interfaces['lan9250']['ipv4']['address'] == '172.31.128.243'


# Generated at 2022-06-11 03:27:23.140738
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    HPUXNetwork.populate() Test Plan:
    """
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    test = HPUXNetwork({})
    test.populate()
    assert test.populate()['default_gateway'] == '172.17.2.129'
    assert test.populate()['default_interface'] == 'lan0'
    assert test.populate()['interfaces'] == ['lan0']

# Generated at 2022-06-11 03:27:25.447838
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    test_platform = HPUXNetworkCollector(None)
    assert test_platform.platform == 'HP-UX'



# Generated at 2022-06-11 03:27:27.284038
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import os.path
    import tempfile

# Generated at 2022-06-11 03:27:29.814006
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector._fact_class is HPUXNetwork
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-11 03:27:32.506238
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Constructor for class HPUXNetwork
    hp_net = HPUXNetwork()
    assert hp_net._platform == 'HP-UX'
    assert hp_net.platform == 'HP-UX'
    # Make sure Platform is not hardcoded
    hp_net.platform = 'AIX'
    assert hp_net._platform == 'AIX'
    assert hp_net.platform == 'AIX'


# Generated at 2022-06-11 03:27:39.719088
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Unit test for constructor of class HPUXNetwork"""
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network_facts_handler = HPUXNetwork(module)
    result = network_facts_handler.populate()
    interfaces = result['interfaces']
    assert len(interfaces) >= 1


# Generated at 2022-06-11 03:27:44.080333
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetwork(module)
    assert network_collector.platform == 'HP-UX'
    assert network_collector.default_interface is None
    assert network_collector.interfaces == []


# Generated at 2022-06-11 03:27:45.176777
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-11 03:27:55.624331
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    #Testing for invalid platform_distro
    lnobject = HPUXNetwork({}, {}, {}, {}, None)
    assert lnobject._platform_distro == None

    #Testing for valid platform_distro with empty module
    module = {"run_command": None}
    lnobject = HPUXNetwork({}, {}, {}, {}, module)
    assert lnobject._platform_distro == None

    #Testing for valid platform_distro with valid module
    def fake_run_command(self, cmd, check_rc=False):
        return (0, "HP-UX", "")
    module = {"run_command": fake_run_command}
    lnobject = HPUXNetwork({}, {}, {}, {}, module)
    assert lnobject._platform_distro == "HP-UX"


#

# Generated at 2022-06-11 03:28:06.376661
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    mydict = {'word_one': 'network',
              'word_two': 'address',
              'word_three': 'device',
              'word_four': 'bcast',
              'word_five': 'Ipkts',
              'word_six': 'Ierrs',
              'word_seven': 'Opkts',
              'word_eight': 'Oerrs',
              'word_nine': 'Colls'}

# Generated at 2022-06-11 03:28:19.468673
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    collected_facts = {}
    network = HPUXNetwork(module=None, collected_facts=collected_facts)
    assert network.platform == 'HP-UX'
    assert network.populate() == {}

# Generated at 2022-06-11 03:28:25.310747
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_obj = HPUXNetwork()
    assert test_obj.populate() == {u'default_interface': u'lan0', u'interfaces': [u'lan0'], u'lan0': {u'ipv4': {u'address': u'172.16.2.205', u'network': u'172.16.2.0', u'interface': u'lan0'}}}

# Generated at 2022-06-11 03:28:34.539569
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.utils.fake import FakeModule


# Generated at 2022-06-11 03:28:35.556920
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    n = HPUXNetwork()
    assert n.platform == 'HP-UX'


# Generated at 2022-06-11 03:28:41.212407
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test = HPUXNetwork()
    results = test.get_interfaces_info()

    if not isinstance(results, dict):
        print('ERROR: Unexpected type: %s' % type(results))
    else:
        for item in results:
            print('Device %s:' % item)
            for field in results[item]:
                print('  %s: %s' % (field, results[item][field]))
            print()



# Generated at 2022-06-11 03:28:51.986689
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    hpux_network_ins = HPUXNetwork(module)
    hpux_network_ins.module.run_command = lambda *args, **kwargs: (0, 'default 192.168.60.1 UG 1    lan0\n192.168.60.0/24 link#1 UC 2 lan0\n', '')
    hpux_network_ins.module.get_bin_path = lambda *args, **kwargs: '/usr/bin/netstat'
    rc = hpux_network_ins.populate()
    assert rc.get('default_interface') == 'lan0'
    assert rc.get('default_gateway') == '192.168.60.1'
    assert rc.get('interfaces') == ['lan0']

# Generated at 2022-06-11 03:28:54.470647
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:28:57.156510
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_values = {}
    test_values['HPUXNetwork'] = HPUXNetwork(None)

    for key in test_values:
        assert test_values[key] is not None


# Generated at 2022-06-11 03:29:03.060996
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    :return: None
    """

    # Test case 1
    module = MockAnsibleModule(mock_ansible_module_results)
    got_results = HPUXNetwork(module).get_interfaces_info()
    expected_results = {
        'lan0': {
            'ipv4': {
                'interface': 'lan0',
                'address': '172.31.255.2',
                'network': '172.31.255.0'
            },
            'device': 'lan0'
        }
    }

    assert got_results == expected_results


# Generated at 2022-06-11 03:29:04.874372
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector.
    """
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:29:33.862983
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network_facts = {'default_interface': 'lan0',
                     'default_gateway': '10.10.10.1',
                     'interfaces': ['lan0'],
                     'lan0': {'device': 'lan0',
                              'ipv4': {'address': '10.10.10.2',
                                       'network': '10.10.10.0',
                                       'interface': 'lan0'}
                     }}

    module = MockModule()
    network_collector = HPUXNetworkCollector(module)
    fact_class = network_collector._fact_class(module)
    network_facts2 = fact_class.populate()

    assert network_facts == network_facts2



# Generated at 2022-06-11 03:29:43.786926
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ HPUXNetwork - populate
    """
    hn = HPUXNetwork()
    netstat_path = hn.module.get_bin_path('netstat')

    if netstat_path is None:
        return

    rc, out, err = hn.module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    result = hn.get_interfaces_info()

# Generated at 2022-06-11 03:29:52.988193
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hw_network_facts = HPUXNetwork()
    hw_network_facts.module.run_command = lambda x: (0, 'default 10.144.2.1        UG    0 0 lan0', '')  # noqa
    hw_network_facts.module.get_bin_path = lambda x: '/usr/bin/netstat'
    default_interfaces = hw_network_facts.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.144.2.1'
    

# Generated at 2022-06-11 03:29:57.073710
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module)
    if_info = network.get_default_interfaces()
    assert if_info['default_interface'] == 'lan2'
    assert if_info['default_gateway'] == '172.29.211.254'



# Generated at 2022-06-11 03:30:03.161573
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network_collector = HPUXNetworkCollector(module=module)
    network_collector.collect()
    facts = network_collector.get_facts()
    assert 'ansible_net_default_interface' in facts
    assert 'ansible_net_default_gateway' in facts
    assert 'ansible_net_interfaces' in facts

# Generated at 2022-06-11 03:30:07.292514
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Check for class HPUXNetwork
    module = AnsibleModule(argument_spec=dict())
    hpux_network = HPUXNetwork(module)
    # Check success for constructor of class HPUXNetwork
    assert hpux_network.__class__.__name__ == 'HPUXNetwork'


# Generated at 2022-06-11 03:30:15.333135
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    import os
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    network_collector = HPUXNetworkCollector(module)
    network_collector.collect()
    facts = network_collector.get_facts()
    fact_version = facts['ansible_net_version']
    fact_interfaces = facts['ansible_interfaces']
    fact_module = facts['ansible_net_module']
    fact_default_interface = facts['ansible_default_ipv4']['interface']
    fact_default_gateway = facts['ansible_default_ipv4']['gateway']
    assert fact_version == os.uname()[2]
    assert fact_module == 'lan'
    assert fact_default_interface in fact_

# Generated at 2022-06-11 03:30:24.317552
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    class Module(object):
        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            results = ('/usr/bin/netstat -nr\n' +
                       'default 192.168.56.1 UGSc 229 0 0 lan0\n' +
                       '/usr/bin/netstat -niw\n' +
                       'lan0      950   0  0.0.0.0      0.0.0.0 ' +
                       'U      -      -      0        0    lan0\n')
            return (0, results, '')

    module = Module()
    facts = HPUXNetwork()
    facts.module = module
    result = facts.populate()

# Generated at 2022-06-11 03:30:34.002553
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    # Mock class for module
    class module:
        def __init__(self):
            self.run_command = run_command

    # Mock function for run_command
    def run_command(*args, **kwargs):
        # Return output of the netstat command
        return 0, out, err

    # Mocked output of netstat command

# Generated at 2022-06-11 03:30:34.879196
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    n = HPUXNetwork()


# Generated at 2022-06-11 03:31:20.097743
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class is HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-11 03:31:23.664405
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    sut = HPUXNetwork()
    def_interfaces_fact = sut.get_default_interfaces()
    assert def_interfaces_fact['default_interface'] is not None
    assert def_interfaces_fact['default_gateway'] is not None


# Generated at 2022-06-11 03:31:33.321671
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, out='', err='')
    network = HPUXNetwork(module)

    network.module.run_command = FakeRunCommand(rc=-1, out='', err='command not found')
    assert network.get_default_interfaces() == {}

    network.module.run_command.set_out_data("""
    default       10.0.0.1        UG    1      0        lan0       10.0.0.10
    default       10.0.0.1        UG    1      0        lan0       10.0.0.10
    """)
    expected_default_interfaces = {'default_interface': 'lan0', 'default_gateway': '10.0.0.1'}


# Generated at 2022-06-11 03:31:35.709316
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeModule()
    network_facts = HPUXNetwork(module)
    assert network_facts is not None
    assert network_facts.default_gateway() is not None


# Generated at 2022-06-11 03:31:36.769826
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-11 03:31:37.998315
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = HPUXNetworkCollector()
    assert facts.platform == 'HP-UX'


# Generated at 2022-06-11 03:31:43.111805
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    nc = HPUXNetwork(module)
    network_facts = nc.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.123.22.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['ipv4']['address'] == '10.123.22.199'
    assert network_facts['lan0']['ipv4']['network'] == '10.123.22.0'

# Generated at 2022-06-11 03:31:45.629352
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector()
    assert hpux.platform == 'HP-UX'
    assert hpux._fact_class._platform == 'HP-UX'
    assert hpux._fact_class.platform == 'HP-UX'

# Generated at 2022-06-11 03:31:48.662308
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert (HPUXNetworkCollector().platform == HPUXNetworkCollector._platform)
    assert (HPUXNetworkCollector()._fact_class ==
            HPUXNetworkCollector._fact_class)
    assert (HPUXNetworkCollector()._fact_class().platform ==
            HPUXNetworkCollector._platform)


# Generated at 2022-06-11 03:31:51.863272
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net_info = HPUXNetwork()
    interfaces = net_info.get_interfaces_info()

    for iface in interfaces:
        assert isinstance(interfaces[iface]['device'], str)
        assert isinstance(interfaces[iface]['ipv4']['network'], str)
        assert isinstance(interfaces[iface]['ipv4']['address'], str)

# Generated at 2022-06-11 03:33:48.935812
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-11 03:33:51.838362
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os
    import ansible.module_utils.facts.network.hpux as hpux
    interfaces = hpux.HPUXNetwork().get_interfaces_info()
    assert 'lan0' in interfaces



# Generated at 2022-06-11 03:33:55.034656
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = HPUXNetworkCollector(None, None)
    interfaces_info = test_module.get_interfaces_info()
    assert interface_info is not None
    assert 'lo0' in interface_info


# Generated at 2022-06-11 03:33:57.580147
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = HPUXNetwork()
    assert facts.get_interfaces_info()
    assert facts.get_default_interfaces()
    assert facts.populate()

# Generated at 2022-06-11 03:34:01.185566
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_collector = NetworkCollector(module=module,
                                         subclasses=[HPUXNetwork])
    networks = network_collector.collect()
    assert 'default_interface' in networks
    # assert 'default_gateway' in networks
    assert 'interfaces' in networks


# Generated at 2022-06-11 03:34:09.287208
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule(object):
        def run_command(self, command):
            class TestOut(object):
                def splitlines(self):
                    return ['default  192.168.1.1  UG   lan0',
                            '192.168.1.0      192.168.1.1  U    lan0',
                            "127.0.0.1        127.0.0.1      UH",
                            "192.168.1.1      192.168.1.1      UH    lan0"]
            class TestErr(object):
                pass
            out = TestOut()
            err = TestErr()
            return (0, out, err)

        def get_bin_path(self, command):
            return '/usr/bin/netstat'

    test_module = TestModule()


# Generated at 2022-06-11 03:34:14.305020
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpn = HPUXNetwork()
    interfaces = hpn.get_interfaces_info()
    assert 'lan0' in interfaces.keys()
    assert 'address' in interfaces['lan0']['ipv4'].keys()
    assert 'network' in interfaces['lan0']['ipv4'].keys()
    assert 'interface' in interfaces['lan0']['ipv4'].keys()



# Generated at 2022-06-11 03:34:21.044209
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(required=True, type='list'))
    )
    hp_ux_network = HPUXNetwork(module)
    interfaces = hp_ux_network.get_interfaces_info()
    assert('lan0' in interfaces)
    assert(interfaces['lan0']['ipv4']['network'] == '172.27.24.228')
    default_interfaces = hp_ux_network.get_default_interfaces()
    assert(default_interfaces['default_interface'] == 'lan0')
    assert(default_interfaces['default_gateway'] == '172.27.24.1')

# Generated at 2022-06-11 03:34:23.470310
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    collector = HPUXNetworkCollector(module)
    network_facts = collector.collect()

    assert 'default_interface' in network_facts
    assert 'interfaces' in network_facts

# Generated at 2022-06-11 03:34:28.919278
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class HPUXNetwork.

    :return:
        TRUE for success, otherwise FALSE
    :rtype: bool
    """
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    network_facts = HPUXNetwork()
    network_facts._module.run_command = magic_run_command

    interfaces = network_facts.get_interfaces_info()
    assert interfaces == EXPECTED_INTERFACES_INFO

    return True

