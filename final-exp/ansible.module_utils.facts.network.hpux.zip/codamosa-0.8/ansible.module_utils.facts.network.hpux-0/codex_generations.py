

# Generated at 2022-06-11 03:25:26.840426
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Method get_interfaces_info returns a dictionary of dictionaries containing
    the interface device name and its address info.
    """
    import types
    import os
    import sys
    import unittest
    import ansible.module_utils.facts.network.hpux as hpux
    import ansible.module_utils.facts.network.base as base

    RESULT_FILE = 'hpux_netstat_ni_output.txt'
    class TestModule(object):
        def get_bin_path(self, arg):
            return '/usr/bin/netstat'
        def run_command(self, arg):
            rc = 0
            with open(os.path.join(sys.path[0], RESULT_FILE), 'r') as f:
                results = f.read()

            results = results.splitlines()

# Generated at 2022-06-11 03:25:30.990812
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hux_collector = HPUXNetworkCollector()

    assert hux_collector.platform == 'HP-UX'
    assert hux_collector._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:25:33.860153
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:25:36.895961
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock({})
    try:
        pop = HPUXNetwork(module).populate()
    except:
        pop = None
    assert pop is not None

# Generated at 2022-06-11 03:25:47.533788
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = HPUXNetworkCollector().collect()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.0.1'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.0.0.162'
    assert facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.0.0.162'

# Generated at 2022-06-11 03:25:50.915043
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Use Python mock to simulate a AnsibleModule
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    my_obj = HPUXNetwork({'module': mock.Mock()})
    default_interface = my_obj.get_default_interfaces()
    default_interface == 'lan0'
    default_gateway == '192.168.0.1'


# Generated at 2022-06-11 03:26:02.569817
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpn = HPUXNetwork()

# Generated at 2022-06-11 03:26:12.223727
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_values = {
                ('/usr/bin/netstat -niw',): ('', '', 0)
            }

        def get_bin_path(self, name):
            return '/usr/bin/' + name

        def run_command(self, command):
            return self.run_command_values[(command,)]

    mockmodule = MockModule()
    network = HPUXNetwork(mockmodule)


# Generated at 2022-06-11 03:26:13.409256
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network.facts == {}



# Generated at 2022-06-11 03:26:15.559852
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'


# Generated at 2022-06-11 03:26:29.786800
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpu_x import HPUXNetwork
    from ansible.module_utils.facts.network.hp_ux import HPUXNetworkCollector
    my_obj = HPUXNetworkCollector()
    my_obj.get_interfaces_info()
    assert my_obj.facts['interfaces'] == ['lan0', 'lan1', 'lan2']
    for interface in my_obj.facts['interfaces']:
        my_obj.facts[interface]['ipv4']['address'] == u'10.10.10.10'
        my_obj.facts[interface]['ipv4']['network'] == u'10.10.10.0'

# Generated at 2022-06-11 03:26:35.386893
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    m = HPUXNetwork(module)
    network_facts = m.populate()
    assert network_facts['interfaces'][0] == 'lan0'
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.159.40.1'



# Generated at 2022-06-11 03:26:36.720481
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-11 03:26:41.076092
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Test case 1:  All interfaces are up and have an ipv4 address
    module = MockModule()
    network = HPUXNetwork(module)
    network.populate()
    assert network.default_interface is not None
    assert 'lan0' in network.interfaces

    # Test case 2:  One interface is down
    module = MockModule()
    module.rc = 1
    network = HPUXNetwork(module)
    network.populate()
    assert network.default_interface is None



# Generated at 2022-06-11 03:26:42.529724
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork
    assert HPUXNetwork.platform == 'HP-UX'


# Generated at 2022-06-11 03:26:53.317187
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Unit test for constructor of class HPUXNetwork"""
    data = [
        'e1000',
        'e1000',
        'lan0             lan0            UP',
        'lan0: 10000010    lan0:           UP',
        '      flags=0x41<UP,RUNNING>',
        '      inet 192.168.119.10 netmask ffffff00 broadcast 192.168.119.255'
    ]
    module_mock = NetworkModuleMock()
    module_mock.run_command = MagicMock(return_value=(0, '\n'.join(data), ''))
    network = HPUXNetwork(module_mock)
    network.populate()

# Generated at 2022-06-11 03:27:02.961159
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_nw = HPUXNetwork()
    hpux_nw.module = module
    hpux_facts = hpux_nw.populate()
    assert hpux_facts['default_interface'] == 'lan0'
    assert hpux_facts['interfaces'] == ['lan0']
    assert hpux_facts['lan0'] == {'device': 'lan0',
                                  'ipv4': {'address': '10.0.0.5',
                                           'network': '10.0.0.0',
                                           'interface': 'lan0'}
                                  }



# Generated at 2022-06-11 03:27:09.770194
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = fake_module()
    module.params = {'gather_subset': 'all'}
    mocker = fake_mocker(module)
    mocker.patch = Mocker()
    HPUXNetwork = fake_HPUXNetwork(module)
    HPUXNetwork.populate_default = Mocker()
    HPUXNetwork.populate_interfaces = Mocker()
    HPUXNetwork.populate_all()

    assert HPUXNetwork.populate_default.call_count == 1, \
        "populate_default called"
    assert HPUXNetwork.populate_interfaces.call_count == 1, \
        "populate_interfaces called"


# Generated at 2022-06-11 03:27:11.975996
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Test HP-UXNetwork class
    """
    module = None
    HPUXNetwork(module)



# Generated at 2022-06-11 03:27:15.261119
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:27:27.666311
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    l = HPUXNetworkCollector()
    assert l.platform == 'HP-UX'
    assert l.fact_class == HPUXNetwork


# Generated at 2022-06-11 03:27:30.138801
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpx_net = HPUXNetworkCollector()
    assert hpx_net.__class__.__name__ == "HPUXNetworkCollector"


# Generated at 2022-06-11 03:27:32.412269
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Test constructor of the HP-UXNetworkCollector class"""
    hpux_network = HPUXNetworkCollector()
    assert hpux_network
    assert hpux_network.platform == 'HP-UX'

# Generated at 2022-06-11 03:27:39.180238
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fact_module = AnsibleModule
    fact_module.run_command = run_module_command
    fact_module.get_bin_path = get_module_bin_path
    collected_facts = HPUXNetwork(fact_module).populate()
    assert collected_facts['default_interface'] == 'lan0'


# Unit test helper method

# Generated at 2022-06-11 03:27:50.230538
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector

    hpux_network_facts_obj = HPUXNetwork()

    hpux_network_facts_obj.get_default_interfaces = mock_get_default_interfaces
    hpux_network_facts_obj.get_interfaces_info = mock_get_interfaces_info

    hpux_network_facts = hpux_network_facts_obj.populate()

    assert hpux_network_facts['default_interface'] == 'hme0'
    assert hpux_network_facts['default_gateway'] == '1.1.1.1'

# Generated at 2022-06-11 03:27:52.894613
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'
    assert network_collector._fact_class is HPUXNetwork

# Generated at 2022-06-11 03:28:00.148781
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    net_fact_class = HPUXNetwork(module)
    net_fact_class.get_default_interfaces = Mock(return_value='default_interface',
                                                 default_gateway='default_gateway')
    net_fact_class.get_interfaces_info = Mock(
        return_value={'lan0': {'device': 'lan0',
                               'ipv4': {'address': '192.168.0.4'}},
                     'lan1': {'device': 'lan1',
                              'ipv4': {'address': '192.168.0.5'}}})
    network_facts = net_fact_class.populate()
    assert network_facts.get('default_interface') == 'default_interface'

# Generated at 2022-06-11 03:28:11.060725
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    hpu_net = HPUXNetwork(module)
    default_interfaces = {'default_interface': 'lan0',
                          'default_gateway': '10.5.6.1'}
    interfaces = {'lan0': {'device': 'lan0',
                           'ipv4': {'address': '10.5.6.8',
                                    'network': '10.5.6.0',
                                    'interface': 'lan0',
                                    'address': '10.5.6.8'}}}
    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    module.run_command.return_value = 0, out, err

# Generated at 2022-06-11 03:28:15.328496
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test = HPUXNetwork()
    interfaces = test.get_interfaces_info()
    assert interfaces == {'lan0': {'device': 'lan0',
                                   'ipv4': {'interface': 'lan0',
                                            'network': '10.10.10.0',
                                            'address': '10.10.10.10'}}}



# Generated at 2022-06-11 03:28:20.629537
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import AnsibleModule
    import sys

    reload(sys)
    sys.setdefaultencoding('utf8')

    test = HPUXNetwork()
    test.module = AnsibleModule()

    interfaces = test.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'localhost' not in interfaces



# Generated at 2022-06-11 03:28:47.391435
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Constructor test of HPUXNetwork class.
    """
    d = HPUXNetwork()
    assert d.populate() == {'default_interface': 'lan0', 'default_gateway': '17.112.152.1', 'interfaces': ['lan0'], 'lan0': {'ipv4': {'address': '17.112.152.195', 'network': '17.112.152.0', 'interface': 'lan0'}, 'device': 'lan0'}}


# Generated at 2022-06-11 03:28:57.197377
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.varsparse import VarParser
    import os
    import tempfile

    # Create tempfiles
    temp_file_read, temp_file_write = tempfile.mkstemp()
    os.write(temp_file_write, '/usr/bin/netstat')
    os.close(temp_file_write)

    class ModuleFake:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = []
            self.params['gather_timeout'] = 5
            self.params['filter'] = '*'
        def get_bin_path(self, arg, required=False):
            return temp_file_read

        def fail_json(self, *args, **kwargs):
            raise Exception(args)


# Generated at 2022-06-11 03:29:03.981391
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = type('module', (), {'run_command': staticmethod(lambda x: (0, "default          0.0.0.0          255.255.255.255    UG   0 0          0 lan2", ""))})
    test_network = HPUXNetwork()
    test_network.module = test_module
    test_default_interfaces_facts = test_network.get_default_interfaces()
    assert test_default_interfaces_facts['default_interface'] == "lan2"
    assert test_default_interfaces_facts['default_gateway'] == "0.0.0.0"

# Generated at 2022-06-11 03:29:07.684809
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_facts_instance = HPUXNetworkCollector()
    assert network_facts_instance.platform == 'HP-UX'
    assert network_facts_instance.fact_class == HPUXNetwork


# Generated at 2022-06-11 03:29:16.564558
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    network = HPUXNetwork(module)
    network_info = network.populate()

    assert network_info['default_interface'] is not None
    assert network_info['default_gateway'] is not None
    assert network_info['interfaces'] is not None
    for interface in network_info['interfaces']:
        assert network_info[interface]['ipv4'] is not None
        assert network_info[interface]['ipv4']['address'] is not None
        assert network_info[interface]['ipv4']['network'] is not None
        assert network_info[interface]['ipv4']['interface'] is not None

# Generated at 2022-06-11 03:29:18.236110
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'


# Generated at 2022-06-11 03:29:19.256001
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network


# Generated at 2022-06-11 03:29:26.044376
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))
    network_facts = {}
    if_path = '/opt/ignored/netstat'
    if_rc = 0

# Generated at 2022-06-11 03:29:30.219133
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_net_facts = HPUXNetworkCollector()
    assert hpux_net_facts._fact_class == HPUXNetwork
    assert hpux_net_facts._platform == 'HP-UX'


# Generated at 2022-06-11 03:29:41.209137
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPUXNetwork_test(HPUXNetwork):
        def __init__(self):
            self.module = None
        def run_command(self, command):
            rc = 0
            out = "  lan21    Link encap:Ethernet  HWaddr 00:0E:F7:3C:87:C7\n"
            out = out + "      inet addr:172.31.2.231  Bcast:172.31.2.255  Mask:255.255.255.0\n"
            out = out + "      inet6 addr: fe80::20e:f7ff:fe3c:87c7/64 Scope:Link\n"
            out = out + "      UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1\n"

# Generated at 2022-06-11 03:30:30.475615
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    class MockModule():
        def __init__(self):
            self.run_command = MagicMock(return_value=(0, '', ''))
            self.get_bin_path = MagicMock(return_value='/usr/bin/netstat')

    class MockNetwork():
        def __init__(self):
            self.module = MockModule()

    network = MockNetwork()
    network_facts = network.populate()

    assert network_facts['default_interface'] == 'lan1'
    assert network_facts['default_gateway'] == '192.168.0.1'
    assert network_facts['interfaces'] == ['lan1']
    assert network_facts['lan1']['device'] == 'lan1'

# Generated at 2022-06-11 03:30:39.359302
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network = HPUXNetwork()
    network.module = MagicMock()
    network.module.run_command.return_value = (0, '''default 10.0.2.2 UGS 0 8192 lo0
10.0.2.0/24 link#1 U 0 lo0
10.0.2.2 link#1 UHS 0 lo0''', '')
    facts = network.populate()
    assert 'interfaces' in facts
    assert 'default_interface' in facts
    assert 'default_gateway' in facts
    assert 'default_gateway' in facts
    assert 'lo0' in facts['interfaces']
    for iface in facts['interfaces']:
        assert 'device' in facts[iface]
        assert 'ipv4' in facts[iface]

# Generated at 2022-06-11 03:30:40.533109
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-11 03:30:44.457115
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule({})
    ntwk = HPUXNetwork(module)
    default_interfaces_facts = ntwk.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '10.10.42.1'


# Generated at 2022-06-11 03:30:50.670340
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec={})
    test_args = {
        "run_command.return_value": (0, "default          127.0.0.1         UG    0        0        127", ""),
    }
    test_module.params = test_args
    test_obj = HPUXNetwork(test_module)
    actual = test_obj.get_default_interfaces()
    expected = {
        'default_interface': '127',
        'default_gateway': '127.0.0.1'
    }
    assert actual == expected


# Generated at 2022-06-11 03:30:52.844042
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hns = HPUXNetwork()
    assert isinstance(hns, HPUXNetwork)
    assert hns.platform == 'HP-UX'


# Generated at 2022-06-11 03:30:56.133571
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    datastructure = net.get_interfaces_info()
    print(datastructure)
    assert(datastructure['lan0']['ipv4']['address'] == '172.16.1.2')
    assert(datastructure['lan1']['ipv4']['address'] == '192.168.1.2')

# Generated at 2022-06-11 03:30:58.594285
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts.network.hpx.hpux import HPUXNetwork
    hpxnw = HPUXNetwork(None)
    assert hpxnw.platform == 'HP-UX'



# Generated at 2022-06-11 03:30:59.063878
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-11 03:31:08.382571
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    default_interfaces = {'default_interface': 'lan1',
                          'default_gateway': '10.0.0.1'}
    module.run_command = Mock(return_value=(0, "", ""))
    module.run_command.assert_called_with('/usr/bin/netstat -niw')
    interfaces = {'lan1': {'device': 'lan1',
                           'ipv4': {'address': '10.0.0.22',
                                    'network': '10.0.0.0',
                                    'interface': 'lan1',
                                    'address': '10.0.0.22'}}}
    test_networks = HPUXNetwork(module)

# Generated at 2022-06-11 03:33:04.781211
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network = HPUXNetwork(module=module)
    facts = network.populate()

    assert len(facts['interfaces']) == 2
    assert 'lan0' in facts['interfaces']
    assert 'lan0' in facts
    assert 'default_interface' in facts
    assert 'default_gateway' in facts


# Generated at 2022-06-11 03:33:06.890114
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    module = AnsibleModule(argument_spec={})
    hp_network = HPUXNetwork(module)

    assert hp_network._platform == 'HP-UX'



# Generated at 2022-06-11 03:33:10.441855
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_gateway'] == '192.168.1.1'
    assert default_interfaces['default_interface'] == 'lan0'

# Generated at 2022-06-11 03:33:11.728605
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    c = HPUXNetwork()
    # Check instance creation
    assert c != None


# Generated at 2022-06-11 03:33:13.154057
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    result = HPUXNetworkCollector()
    assert isinstance(result, HPUXNetworkCollector)

# Generated at 2022-06-11 03:33:22.371844
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network_obj = HPUXNetwork()

# Generated at 2022-06-11 03:33:26.903243
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_dict = {'lan0': {'ipv4': {'network': '192.168.1.0',
                                   'address': '192.168.1.22',
                                   'interface': 'lan0'}}}
    hpx_test_net = HPUXNetwork()
    interfaces = hpx_test_net.get_interfaces_info()
    assert interfaces == test_dict


# Generated at 2022-06-11 03:33:30.075394
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork({})
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] != ''


# Generated at 2022-06-11 03:33:31.654024
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network.platform == 'HP-UX'


# Generated at 2022-06-11 03:33:33.038585
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(dict())

    assert network is not None