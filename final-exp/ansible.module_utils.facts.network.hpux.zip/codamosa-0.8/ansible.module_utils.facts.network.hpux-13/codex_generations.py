

# Generated at 2022-06-11 03:25:22.467604
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_collector = HPUXNetworkCollector()
    assert net_collector.platform == 'HP-UX'
    assert net_collector._fact_class == HPUXNetwork



# Generated at 2022-06-11 03:25:23.405264
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    unittest.main()

# Generated at 2022-06-11 03:25:24.673082
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert isinstance(HPUXNetwork(), Network)



# Generated at 2022-06-11 03:25:25.843111
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 03:25:27.590625
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Unit test for constructor of class HPUXNetwork.
    """
    hn = HPUXNetwork()
    print(hn)

# Generated at 2022-06-11 03:25:31.901021
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module_mock = type('module_mock', (object,), {})()
    h = HPUXNetwork(module_mock)
    assert h is not None

# Generated at 2022-06-11 03:25:42.832177
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class TestModule(object):
        def run_command(self, *args, **kwargs):
            class AttrDict(dict):
                def __getattr__(self, name):
                    try:
                        return self[name]
                    except KeyError:
                        return None

                def __setattr__(self, name, value):
                    self[name] = value

                def __delattr__(self, name):
                    try:
                        del self[name]
                    except KeyError:
                        raise AttributeError(name)


# Generated at 2022-06-11 03:25:50.142900
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    fake_module = FakeModule()
    fake_module.run_command = fake_run_command
    network = HPUXNetwork(fake_module)
    interfaces = network.get_interfaces_info()
    assert interfaces == {
        'lan0': {
            'device': 'lan0',
            'ipv4': {
                'address': '10.1.1.1',
                'network': '255.255.255.0',
                'interface': 'lan0',
                'address': '10.1.1.1'
                }
            }
        }


# Generated at 2022-06-11 03:26:01.500162
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MyModule:
        def run_command(self, cmd):
            cmd = '/usr/bin/netstat -niw'
            rc = 0
            err = ''

            # expected
            out_no_lan_entry = '''
Name  Mtu  Network       Address              Ipkts  Ierrs Idrop    O
em0   1500  10.10.10.0    10.10.10.10         5603    0     0    5603
                                  '''

# Generated at 2022-06-11 03:26:11.323114
# Unit test for constructor of class HPUXNetworkCollector

# Generated at 2022-06-11 03:26:18.243728
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._platform == 'HP-UX'

# Generated at 2022-06-11 03:26:29.212474
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_network = HPUXNetwork()
    test_facts = test_network.populate()

    assert test_facts['default_interface'] == 'lan5'
    assert test_facts['default_gateway'] == '10.15.193.1'

    assert test_facts['interfaces'] == ['lan8', 'lan6', 'lan5']

    assert test_facts['lan8']['ipv4']['address'] == '127.0.0.1'
    assert test_facts['lan8']['ipv4']['network'] == '127.0.0.0'
    assert test_facts['lan8']['ipv4']['interface'] == 'lan8'

    assert test_facts['lan6']['ipv4']['address'] == '10.15.193.227'

# Generated at 2022-06-11 03:26:31.943763
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts import Facts
    facts = Facts(dict(ansible_facts=dict()))
    network = HPUXNetwork(facts)
    assert 'netstat' in network.executable



# Generated at 2022-06-11 03:26:38.068564
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    system_ipv4_default_gateway = '192.168.1.1'
    system_ipv4_default_interface = 'lan0'
    return_code = 0
    module_mock = Mock()
    module_mock.run_command.return_value = (return_code,
        'default ' + system_ipv4_default_gateway + ' UGSc 0 0 lan0', '')
    hpux_network = HPUXNetwork(module_mock)
    default_interfaces = hpux_network.get_default_interfaces()
    assert(system_ipv4_default_gateway in default_interfaces.values())
    assert(system_ipv4_default_interface in default_interfaces.values())


# Generated at 2022-06-11 03:26:41.639446
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Creates a HPUXNetworkCollector object and checks that the
    object is a HPUXNetworkCollector object.
    """
    network_collector = HPUXNetworkCollector()
    assert isinstance(network_collector, HPUXNetworkCollector)



# Generated at 2022-06-11 03:26:49.215784
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    hpuxnetwork = HPUXNetwork(module)
    hpuxnetwork.get_default_interfaces = Mock(return_value={})
    hpuxnetwork.get_interfaces_info = Mock(
        return_value={'lan0': {'device': 'lan0', 'ipv4': {'address': '1.0.0.0', 'network': '1.0.0.0'}}})
    hpuxnetwork.populate()
    assert module.facts['default_gateway'] == '1.0.0.0'



# Generated at 2022-06-11 03:26:54.397647
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    if module.check_mode:
        module.exit_json(changed=False)

    net = HPUXNetwork(module)
    facts = net.populate()

    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-11 03:27:04.633494
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork().populate(module)

    assert network_facts['default_interface'] == 'lan98'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert network_facts['ipv4']['address'] == '10.0.0.3'

    assert network_facts['interfaces'] == ['lan98']
    assert network_facts['lan98']['ipv4']['address'] == '10.0.0.3'
    assert network_facts['lan98']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan98']['ipv4']['interface'] == 'lan98'

# Generated at 2022-06-11 03:27:11.362274
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Stub the module parameters, module instance and the run_command method
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.run_command.return_value = (0, "default 192.168.1.1 UG lan0", "")
    # Instantiate the fact class.
    fact_obj = HPUXNetwork(module)
    # Call the method being tested
    result = fact_obj.get_default_interfaces()
    # Test the results
    assert result == {"default_interface": "lan0",
                      "default_gateway": "192.168.1.1"}
    # Verify that run_command was called with something similar to the
    # following

# Generated at 2022-06-11 03:27:22.381927
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    class ModuleMock:
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            pass

        def get_bin_path(self, name):
            if name == 'netstat':
                return '/usr/bin/netstat'
            else:
                return None


# Generated at 2022-06-11 03:27:44.534128
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:27:51.670277
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hn = HPUXNetwork()
    interfaces = hn.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'address': '10.0.0.11',
                                           'network': '10.0.0.0',
                                           'interface': 'lan0'}}



# Generated at 2022-06-11 03:27:59.556785
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import sys
    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    class TestHPUXNetwork(unittest.TestCase):
        def setUp(self):
            class TestModule(object):
                def __init__(self):
                    self.run_command = self.mock_run_command


# Generated at 2022-06-11 03:28:08.512234
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network

    fact_subclass = HPUXNetwork()

    fact_subclass.populate()
    expected_keys = ['default_gateway', 'default_interface', 'interfaces']
    assert sorted(expected_keys) == sorted(fact_subclass.facts.keys())
    assert fact_subclass.facts['default_gateway'] is not None
    assert fact_subclass.facts['default_interface'] is not None
    assert fact_subclass.facts['interfaces'] is not None



# Generated at 2022-06-11 03:28:16.555904
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_facts = HPUXNetwork()
    hpux_facts.module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    hpux_facts.module.run_command = MagicMock(return_value=(0, _OUT_NETSTAT, ""))
    facts = hpux_facts.populate()
    assert facts["interfaces"] == ['lan0', 'lan1', 'lan2', 'lan3', 'lan4', 'lan5', 'lan7', 'lan9']
    assert facts["lan0"]["ipv4"]["address"] == "0.0.0.0"
    assert facts["lan9"]["ipv4"]["address"] == "0.0.0.0"
    assert facts["default_interface"] == "lan9"

# Generated at 2022-06-11 03:28:27.058479
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    test_HPUXNetwork = HPUXNetwork(test_module)
    rc, out, err = test_module.run_command("/usr/bin/netstat -niw")
    test_interfaces_info = test_HPUXNetwork.get_interfaces_info()
    test_default_interfaces_facts = test_HPUXNetwork.get_default_interfaces()
    out = test_module.from_json(out)
    first_interface = out[1][0]
    assert test_default_interfaces_facts['default_interface'] == first_interface

# Generated at 2022-06-11 03:28:36.030774
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """

    class TestModule(object):
        """
        Dummy class for testing
        """
        def run_command(self, cmd):
            """
            Dummy method for testing get_interfaces_info
            """
            return 0, "lan0/0/0/0     lan0/0/0/0      192.168.1.0   30", None

        def get_bin_path(self, path):
            return None

    class TestNetwork(HPUXNetwork):
        """
        Dummy class for testing
        """
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-11 03:28:43.573497
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPUXNetworkTest:
        module = HPUXNetworkTest

    hn = HPUXNetworkTest()
    interfaces = hn.get_interfaces_info()
    assert isinstance(interfaces, dict)
    assert 'lan0' in interfaces
    assert 'device' in interfaces['lan0']
    assert 'lan0' == interfaces['lan0']['device']
    assert 'ipv4' in interfaces['lan0']
    assert 'address' in interfaces['lan0']['ipv4']
    assert interfaces['lan0']['ipv4']['address']


# Generated at 2022-06-11 03:28:53.521193
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test1 = HPUXNetwork({'module': None})
    test1.default_interface = 'lan0'
    test1.default_gateway = '10.0.0.1'
    test1.interfaces = ['lan0']
    test1.lan0 = {'device': 'lan0',
                  'ipv4': {'address': '10.0.0.2',
                           'network': '10.0.0.0',
                           'netmask': '255.255.255.0'}}
    test_value1 = test1.populate()
    assert test_value1['default_interface'] == 'lan0'
    assert test_value1['default_gateway'] == '10.0.0.1'



# Generated at 2022-06-11 03:29:01.497839
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net_fact = HPUXNetwork()

    # Verify get_default_interfaces returns the expected dictionary
    net_fact.module.run_command = Mock(return_value=(0, '', ''))
    net_fact.module.run_command.return_value = (0, "default 10.0.0.1 UGS 0 0 lan0", "")
    assert net_fact.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '10.0.0.1'}

    # Verify no default interface and default gateway are returned when /usr/bin/netstat -nr returns an empty string
    net_fact.module.run_command.return_value = (0, '', '')
    assert net_fact.get_default_interfaces() == {}

    # Verify no default interface and

# Generated at 2022-06-11 03:29:21.641071
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:29:23.131867
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:29:33.872928
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    hpux_network = HPUXNetwork(module)

    interfaces = hpux_network.get_interfaces_info()

    assert len(interfaces) > 0
    assert 'lo0' in interfaces
    assert 'lan0' in interfaces
    assert 'lan2' in interfaces
    assert 'lan9' in interfaces
    assert 'lan38' in interfaces
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4']['interface'] == 'lo0'
    assert interfaces['lo0']['ipv4']['network'] == '127'


# Generated at 2022-06-11 03:29:43.784702
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    default_interfaces = {'default_gateway': '172.17.0.1', 'default_interface': 'net0'}
    interfaces = {'lan0': {'ipv4': {'interface': 'lan0', 'network': '172.19',
                                    'address': '172.19.10.31'}, 'device': 'lan0'},
                  'net0': {'ipv4': {'interface': 'net0', 'network': '172.17',
                                    'address': '172.17.10.31'}, 'device': 'net0'}}

# Generated at 2022-06-11 03:29:46.156968
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    ans = HPUXNetwork()
    assert ans.platform == 'HP-UX'


# Generated at 2022-06-11 03:29:56.606289
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.hp_ux import HPUXNetwork
    from ansible.module_utils import basic
    import json
    import shutil
    import tempfile

    test_data = {'default_interface': 'lan0', 'default_gateway': '192.168.1.254'}

    my_tmp_dir = tempfile.mkdtemp()
    module_file = my_tmp_dir + '/ansible_module.py'
    with open(module_file, 'w') as fp:
        fp.write("#!/usr/bin/python")
    my_module = basic.AnsibleModule(argument_spec={})

# Generated at 2022-06-11 03:30:07.038097
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    network_facts = HPUXNetwork(module=module)
    defaults = {'default_interface': 'lan0',
                'default_gateway': '192.168.1.1'}
    ifaces = {
        'lan0': {
            'ipv4': {
                'address': '192.168.1.98',
                'network': '192.168.1.0',
                'netmask': '255.255.255.0',
                'gateway': '192.168.1.1'
            },
            'macaddress': '00:16:3e:cf:ff:54'
        }
    }
    network_facts.populate()
    assert network_facts.default_interfaces == defaults
    assert network_facts.interfaces == ifaces

# Generated at 2022-06-11 03:30:15.176686
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        class FakeRunCommand:
            returncode = 0
            stdout = to_bytes(
"""lan0            Link encap:Ethernet  HWaddr 00:00:97:9B:05:F0
      inet addr:10.0.0.1  Bcast:10.0.0.255  Mask:255.255.255.0
      UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
      RX packets:35276 errors:0 dropped:0 overruns:0 frame:0
      TX packets:38261 errors:0 dropped:0 overruns:0 carrier:0
      collisions:0 txqueuelen:100
      Interrupt:33 Base address:0x1000""")

# Generated at 2022-06-11 03:30:16.975069
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HP_UXNetworkCollector()
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-11 03:30:26.321429
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

# Generated at 2022-06-11 03:31:10.439295
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Test the constructor of class HPUXNetwork
    """
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'
    assert net.get_interfaces_info() is None


# Generated at 2022-06-11 03:31:17.881911
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = []
    out = (
        b"Name   Mtu   Network     Address             Ipkts Ierrs     Opkts Oerrs  Coll\n"
        b"lan0   1500  123.124.125.116     123.124.125.117  3505     0      94064     0     0\n"
        b"lan1   1500  123.124.125.118     123.124.125.119  3505     0      94064     0     0\n"
    )
    network = HPUXNetwork(None)
    interfaces = network.get_interfaces_info(out)

# Generated at 2022-06-11 03:31:21.348171
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module = get_platform_module('HP-UX')
    default = network.get_default_interfaces()
    assert default['default_interface'] == 'lan3'
    assert default['default_gateway'] == '10.0.0.2'


# Generated at 2022-06-11 03:31:27.779002
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    class TestModule(object):
        def get_bin_path(self, arg, *args, **kwargs):
            return arg

        def run_command(self, arg, *args, **kwargs):
            out = """default 172.16.0.1 UG lan0
default 172.16.0.1 UG lan1
"""
            return 0, out, None

    net = HPUXNetwork(TestModule())
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan1', 'default_gateway': '172.16.0.1'}


# Generated at 2022-06-11 03:31:30.828815
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-11 03:31:38.677348
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hostname = 'HP-UX'
    domain = 'example.com'

# Generated at 2022-06-11 03:31:41.475880
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    assert hpux_network.module == module
    assert hpux_network._platform == "HP-UX"


# Generated at 2022-06-11 03:31:44.834769
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = MockModule()
    network = HPUXNetwork(module)
    network.populate()
    assert network.default_interface == 'lan1'
    assert network.default_gateway == '192.168.0.1'
    assert network.interfaces == ['lan1']


# Mock class for unit testing

# Generated at 2022-06-11 03:31:49.102938
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(
        return_value=(0, 'default 10.0.0.1 UG 0 8 lan1 lan1', ''))

    hp_network_facts = HPUXNetwork(module)
    network_facts_result = hp_network_facts.populate()
    assert network_facts_result['default_interface'] == 'lan1'
    assert network_facts_result['default_gateway'] == '10.0.0.1'

# Generated at 2022-06-11 03:31:52.417545
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Test function for constructor of class HPUXNetwork.
    Since the class itself is tested by unit tests in the module test_plugins.test_network,
    this test only tests that object of class HPUXNetwork can be created.
    """
    host_name = "testhost"
    network = HPUXNetwork(host_name)
    assert network is not None

# Unit class for constructor of class HPUXNetworkCollector

# Generated at 2022-06-11 03:33:58.284023
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPUXNetwork():
        interfaces = {}

        def run_command(self, command):
            out = "LAN0\tlan0\t0.0.0.0\t0\tHWaddr\t00:00:00:00:00:00\n"
            out = out + "LAN1\tlan1\t0.0.0.0\t0\tHWaddr\t00:00:00:00:00:00\n"
            out = out + "LAN2\tlan2\t0.0.0.0\t0\tHWaddr\t00:00:00:00:00:00\n"

# Generated at 2022-06-11 03:34:06.215149
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 03:34:14.769222
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h = HPUXNetwork()
    h.module = MockModule()
    h.module.run_command = Mock(return_value=(0, "default 127.0.0.1 UG lo0\
            lan0 0.0.0.0 UG lan1\
            127 127.0.0.1 UH lo0", ''))
    network_facts = h.populate()
    assert network_facts['default_interface'] == 'lo0'
    assert network_facts['default_gateway'] == '127.0.0.1'
    assert network_facts['interfaces'] == ['lan0', 'lan1', 'lo0']
    assert network_facts['lan0']['ipv4']['address'] == '0.0.0.0'

# Generated at 2022-06-11 03:34:19.783334
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    def run_command(self, cmd, check_rc=None):
        return 0, NETSTAT_RESULT, ''
    network = HPUXNetwork()
    # Patch module.run_command.
    HPUXNetwork.run_command = run_command
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0',
                                  'default_gateway': '10.10.10.1'}


# Generated at 2022-06-11 03:34:21.784457
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    nc = NetworkCollector()
    hnc = HPUXNetworkCollector()
    assert isinstance(hnc, NetworkCollector)

# Generated at 2022-06-11 03:34:23.082527
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-11 03:34:24.513320
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    Network.platform = 'HP-UX'
    fact_network = Network()
    fact_HPUXNetwork = HPUXNetwork()
    assert fact_HPUXNetwork.platform == fact_network.platform


# Generated at 2022-06-11 03:34:31.936804
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """test_get_interfaces_info: Test HPUXNetwork.get_interfaces_info()
    """


# Generated at 2022-06-11 03:34:39.547864
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    try:
        from unittest.mock import patch
        from unittest import mock
    except ImportError:
        from mock import patch, mock

    net = HPUXNetwork()

    module = mock.MagicMock()
    module.run_command.return_value = 0, '', ''
    module.get_bin_path.return_value = None
    net.module = module
    assert net.populate() == {}


# Generated at 2022-06-11 03:34:41.736023
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class_HPUXNetwork = HPUXNetwork()
    interfaces_info = class_HPUXNetwork.get_interfaces_info()
    assert isinstance(interfaces_info, dict)
