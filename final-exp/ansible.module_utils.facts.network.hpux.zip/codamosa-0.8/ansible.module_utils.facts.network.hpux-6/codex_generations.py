

# Generated at 2022-06-11 03:25:24.714139
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Test the method get_default_interfaces of the class HPUXNetwork.
    """
    # Test with a non existing command
    netstat_path = '/usr/bin/netstat'
    rc, out, err = module.run_command(netstat_path)
    assert rc == 0
    if "HP-UX" in out:
        n = HPUXNetwork()
        default_interfaces_facts = n.get_default_interfaces()
        assert default_interfaces_facts['default_gateway'] != ''


# Generated at 2022-06-11 03:25:30.818430
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(
                                    os.path.abspath(__file__)))))
    from ansible.module_utils.facts.network import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    hpux_net = HPUXNetwork()
    net = Network()


# Generated at 2022-06-11 03:25:33.326286
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict()
    )

    result = HPUXNetwork(module)
    assert result is not None

# Generated at 2022-06-11 03:25:44.257589
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    net = HPUXNetwork(module)
    out = net.populate()
    assert out['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3', 'lan4', 'lan5']
    assert out['default_interface'] == 'lan6'
    assert out['default_gateway'] == '10.1.1.254'
    assert out['lan0']['ipv4']['address'] == '10.1.1.244'
    assert out['lan0']['ipv4']['network'] == '10.1.1.240'
    assert out['lan5']['ipv4']['address'] == '10.1.1.249'

# Generated at 2022-06-11 03:25:48.770871
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network_collector = HPUXNetworkCollector()
    hpn = HPUXNetwork(network_collector)
    default_interfaces = hpn.get_default_interfaces()
    assert default_interfaces
    assert 'default_interface' in default_interfaces
    assert 'default_gateway' in default_interfaces



# Generated at 2022-06-11 03:25:52.326752
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hpux_network = HPUXNetwork()
    hpux_network.module = module
    hpux_network.get_interfaces_info()


# Generated at 2022-06-11 03:26:03.450778
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpu import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic import GenericNetwork
    from ansible.module_utils.facts.network.ios import IosNetwork
    from ansible.module_utils.facts.network.iosxr import IosxrNetwork
    from ansible.module_utils.facts.network.junos import JunosNetwork
    from ansible.module_utils.facts.network.nxos import NxosNetwork
    from ansible.module_utils.facts.network.solaris import SolarisNetwork
    from ansible.module_utils.facts.network.vyos import VyosNetwork


# Generated at 2022-06-11 03:26:05.824352
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = None
    net = HPUXNetwork(facts)
    assert net._facts == facts
    assert net.platform == 'HP-UX'

# Generated at 2022-06-11 03:26:07.441892
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c._platform == 'HP-UX'


# Generated at 2022-06-11 03:26:15.995586
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = {}
    ansible_facts = {}
    ansible_facts['ansible_net_interfaces'] = ['lan0', 'lan1', 'lan2', 'lan3',
                                               'lan4', 'lan5', 'lan6', 'lan7']
    ansible_facts['ansible_net_default_interface'] = "lan0"

    ansible_facts['ansible_net_ipv4_address'] = "10.1.1.1"
    net = HPUXNetwork(ansible_facts, facts)
    net.populate()
    assert net.facts['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3',
                                       'lan4', 'lan5', 'lan6', 'lan7']
    assert net.facts['default_interface'] == "lan0"


# Generated at 2022-06-11 03:26:31.079396
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class module:
        def run_command(self, cmd):
            return 0, '', ''
    m = module()
    n = HPUXNetwork(m)

    # Emulate netstat -nr output in case of default route is configured
    def run_command_default_route(cmd):
        out = ("default  172.16.0.1      UG        0        0        lan1")
        return 0, out, ''
    m.run_command = run_command_default_route
    default_interfaces = n.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan1',
                                  'default_gateway': '172.16.0.1'}

    # Emulate netstat -nr output in case of default route is not configured

# Generated at 2022-06-11 03:26:36.950843
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Testing with HP-UX sample data
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)

    # Unit test using HP-UX sample data
    # Return value of netstat -niw command

# Generated at 2022-06-11 03:26:42.567505
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network_collector = HPUXNetworkCollector()
    network_collector.module = MockModule()
    network_collector._setup()
    network_collector.data = {}
    network = HPUXNetwork(network_collector)
    network.populate()
    for device in network.interfaces:
        assert isinstance(network.interfaces[device], dict)
        for item in network.interfaces[device]:
            assert isinstance(network.interfaces[device][item], dict)



# Generated at 2022-06-11 03:26:53.318626
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    import json

    # Define fake arguments
    module = type('module', (), {})()
    module.get_bin_path = lambda x: '/sbin'
    module.run_command = lambda x: [0, "test", ""]

    # Create HPUXNetwork instance
    fact_class = HPUXNetwork(module)

    # Call populate method
    result = fact_class.populate()

    # Check result
    assert json.dumps(result) == '{"default_interface": "lan0", "default_gateway": "192.168.1.1", "interfaces": ["lan0"], "lan0": {"ipv4": {"network": "192.168.1.0", "interface": "lan0", "address": "192.168.1.42"}}}'


# Generated at 2022-06-11 03:26:55.116372
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'

# Generated at 2022-06-11 03:27:04.935288
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fake_module = FakeAnsibleModule()
    fake_module.run_command = FakeRunCommand(rc=0, lines='10.0.0.1', err='',
                                             path='/usr/bin/netstat')
    fake_module.get_bin_path = FakeGetBinPath()
    fake_network = HPUXNetwork()
    fake_network.module = fake_module
    assert fake_network.populate() == {
        'default_gateway': '10.0.0.1',
        'default_interface': 'lan0',
        'interfaces': ['lan0'],
        'lan0': {'device': 'lan0', 'ipv4': {'address': '10.0.0.1'}},
    }



# Generated at 2022-06-11 03:27:14.501497
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule:
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_call_list = []

# Generated at 2022-06-11 03:27:17.238838
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:27:18.197536
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:27:25.282695
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUX = HPUXNetwork()
    assert HPUX.platform == 'HP-UX'
    assert HPUX.get_interfaces_info()['lan0'] == {'device': 'lan0', 'ipv4': {'network': '10.0.0.0', 'interface': 'lan0', 'address': '10.0.0.157'}}
    assert HPUX.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '10.0.0.5'}

# Generated at 2022-06-11 03:27:40.407511
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector(None)
    assert network_collector.__class__.__name__ == 'HPUXNetworkCollector'
    assert network_collector._platform == 'HP-UX'
    assert network_collector.get_facts(None) is not None

# Generated at 2022-06-11 03:27:44.863452
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    my_module = FakeModule()
    h = HPUXNetwork(my_module)
    h.get_interfaces_info()
    return_from_run = my_module.run_command_args
    assert return_from_run[0] == '/usr/bin/netstat -niw'


# Generated at 2022-06-11 03:27:47.555805
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    result = HPUXNetworkCollector()
    assert result.__class__.__name__ == 'HPUXNetworkCollector'


# Generated at 2022-06-11 03:27:49.427479
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = HPUXNetwork()
    assert module.platform == 'HP-UX'



# Generated at 2022-06-11 03:27:58.332417
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:28:03.636969
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network_facts = HPUXNetwork()
    default_interfaces = network_facts.get_default_interfaces()
    default_interface = default_interfaces.get('default_interface')
    default_gateway = default_interfaces.get('default_gateway')
    assert default_interface is not None
    assert default_gateway is not None


# Generated at 2022-06-11 03:28:13.460476
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    '''Test the populate method of class HPUXNetwork.'''
    # Setup test variables
    module = AnsibleModule(argument_spec={})
    fake_network_class = HPUXNetwork(module)
    fake_network_class.module.run_command = fake_run_command
    fake_network_class.get_interfaces_info = fake_get_interfaces_info

    # run get_default_interfaces()
    default_interface = fake_network_class.get_default_interfaces()

    # run populate()
    facts = fake_network_class.populate()

    # To-do complete unit test
    assert facts['interfaces'] == ['lan0', 'lan1']
    assert facts['lan0']['ipv4'] == {'address': '10.137.14.93'}
    assert facts

# Generated at 2022-06-11 03:28:16.242329
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_object = HPUXNetwork({})
    list_of_interfaces = test_object.get_interfaces_info().keys()
    assert 'lan0' in list_of_interfaces


# Generated at 2022-06-11 03:28:19.819605
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hux_fact_collector = HPUXNetworkCollector()
    assert hux_fact_collector.platform == 'HP-UX'
    assert hux_fact_collector.fact_class == HPUXNetwork


# Generated at 2022-06-11 03:28:22.795292
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork().get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['address'] == '10.0.2.15'

# Generated at 2022-06-11 03:28:44.607936
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_collector = HPUXNetworkCollector()
    assert net_collector.platform == 'HP-UX'


# Generated at 2022-06-11 03:28:55.003507
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    nm = HPUXNetwork(module)
    nm.populate()
    interfaces = nm.interfaces()
    assert interfaces is not None
    assert 'lo0' in interfaces
    assert nm.has_interface('lo0') is True
    assert nm.has_interface('eth0') is False
    assert nm.default_interface() is not None
    assert nm.ipv4_address('lan0') is not None
    assert nm.ipv4_address('lo0') is None
    assert nm.ipv4_network('lan0') is not None
    assert nm.ipv4_network('lo0') is None
    assert nm.ipv4_netmask('lan0') is None
    assert nm.ipv6_address('lo0') is None

# Generated at 2022-06-11 03:28:55.912384
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:28:57.889387
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    hpn = HPUXNetwork(module)
    hpn.populate()



# Generated at 2022-06-11 03:28:59.632021
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc._fact_class == HPUXNetwork
    assert nc._platform == 'HP-UX'

# Generated at 2022-06-11 03:29:02.650943
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._platform == "HP-UX"
    assert hpux_network_collector._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:29:13.537558
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    n = HPUXNetwork({})
    facts = n.populate()
    assert facts['default_interface'] == 'lan5'
    assert facts['default_gateway'] == '10.3.3.2'
    assert facts['interfaces'] == ['lan5', 'lan4']
    assert facts['lan4']['ipv4']['address'] == '10.3.3.197'
    assert facts['lan4']['ipv4']['network'] == '10.3.3.0'
    assert facts['lan4']['ipv4']['interface'] == 'lan4'
    assert facts['lan5']['ipv4']['address'] == '10.3.3.196'

# Generated at 2022-06-11 03:29:22.786540
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'default'}
            self.run_command = Mock(return_value=(0, SAMPLE_NETSTAT_OUTPUT, ''))

        def get_bin_path(self, arg1):
            return arg1

    class MockNetwork(HPUXNetwork):
        def __init__(self):
            self.module = MockModule()

        def get_default_interfaces(self):
            return super(MockNetwork, self).get_default_interfaces()

    n = MockNetwork()
    default_interfaces_facts = n.get_default_interfaces()

    assert default_interfaces_facts['default_interface'] == 'lan1'
    assert default_interfaces_facts['default_gateway']

# Generated at 2022-06-11 03:29:28.052894
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    facts = {'default_interface': default_interfaces['default_interface'],
             'default_gateway': default_interfaces['default_gateway']}
    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-11 03:29:33.628322
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module.run_command = run_command_sample

    default_interfaces_facts = net.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '10.10.10.1'



# Generated at 2022-06-11 03:30:20.588621
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    net = HPUXNetwork(module)
    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    default_interfaces_facts = net.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-11 03:30:29.372800
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpx = HPUXNetwork()
    assert hpx.get_default_interfaces()['default_interface'] == 'lan4'
    assert hpx.get_default_interfaces()['default_gateway'] == '10.11.13.2'
    assert hpx.get_interfaces_info()['lan0']['ipv4'] == {'address': '10.11.13.1', 'network': '10.11.8.0', 'interface': 'lan0'}
    assert hpx.get_interfaces_info()['lan4']['ipv4'] == {'address': '10.11.13.4', 'network': '10.11.8.0', 'interface': 'lan4'}

# Generated at 2022-06-11 03:30:33.612188
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    facts = {
        'kernel': 'HP-UX',
    }
    m = HPUXNetwork(module=None, facts=facts)
    result = m.get_interfaces_info()
    assert result is not None
    assert len(result) > 1
    assert 'lan0' in result
    assert 'lan1' in result


# Generated at 2022-06-11 03:30:42.275012
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_network = HPUXNetwork()

    def run_command_func(command, module, check_rc=True):
        if command == '/usr/bin/netstat -niw':
            return 0, "\
Interface    Mtu    Net/Dest      Address        Ipkts Ierrs     Opkts Oerrs Collis Queue\n\
lan0        1500  default         192.168.0.100  24844     0     18363     0    0    0\n\
lan1        1500  default         192.168.1.100  24844     0     18363     0    0    0\n\
lan2        1500  default         192.168.2.100  24844     0     18363     0    0    0\n", ''
        else:
            # Other commands are not tested
            return None

   

# Generated at 2022-06-11 03:30:47.265907
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    i = HPUXNetwork()
    interfaces = i.get_interfaces_info()
    assert interfaces == {u'lan0': {'device': u'lan0',
                                    'ipv4': {'address': u'9.115.181.254',
                                             'interface': u'lan0',
                                             'network': u'9.115.181.0'}},
                         u'lan1': {'device': u'lan1',
                                   'ipv4': {'address': u'9.115.181.255',
                                            'interface': u'lan1',
                                            'network': u'9.115.181.0'}}}


# Generated at 2022-06-11 03:30:54.815171
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network = HPUXNetwork(module)
    network_facts = network.populate()

    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['default_interface'] == "lan0"
    assert network_facts['lan0']['device'] == "lan0"
    assert network_facts['lan0']['ipv4']['address'] == "10.20.4.20"
    assert network_facts['lan0']['ipv4']['network'] == "10.20.4.0"
    assert network_facts['default_gateway'] == "10.20.4.1"


# Generated at 2022-06-11 03:30:59.396725
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec={},
    )
    m_run_command = Mock(return_value=(0, 'default 127.0.0.1 UGSc 4 lo0', ''))
    module.run_command = m_run_command
    m_exists = Mock(return_value=True)
    module.params = {}
    hpux_network = HPUXNetwork(module)
    facts = hpux_network.populate()
    assert facts is not None
    assert facts['default_interface'] == 'lo0'

# Generated at 2022-06-11 03:31:04.130153
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Create a HPUXNetwork object
    net = HPUXNetwork(None)

    # Create an attribute 'interfaces' for the object
    net.interfaces = []

    # Populate the object with facts
    net.populate()

    # Check if the number of interfaces found is valid (greater than one)
    assert len(net.interfaces) > 1

# Generated at 2022-06-11 03:31:12.805033
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:31:14.810141
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    obj = HPUXNetworkCollector()
    assert isinstance(obj, NetworkCollector)


# Generated at 2022-06-11 03:33:20.066902
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = mock.MagicMock()
    command = '/usr/bin/netstat -niw'
    module.run_command.return_value = 0, HP_UX_NETSTAT_NIW, ''
    hpux_obj = HPUXNetwork(module)
    assert hpux_obj.get_interfaces_info() == INTERFACES_INFO
    assert hpux_obj.get_default_interfaces() == DEFAULT_INTERFACES_INFO
    assert hpux_obj.populate() == NETWORK_INFO


# Generated at 2022-06-11 03:33:25.943038
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module).populate()
    # Test to see if default_interface is set
    assert network_facts['default_interface'] != None
    # Test to see if default_gateway is set
    assert network_facts['default_gateway'] != None
    # Test to see if an interface has an ipv4 address
    for iface in network_facts['interfaces']:
        assert network_facts[iface]['ipv4']['address'] != None

# Generated at 2022-06-11 03:33:33.763228
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule:
        def __init__(self):
            self.run_command_results = [(0, 'default   10.1.1.1 UG      0 lan0', ''),
                                        (0, 'default   10.1.1.1 UG      0 lan1', '')]

        def run_command(self, cmd):
            return self.run_command_results.pop()

    class MockHPUXNetwork:
        module = MockModule()

    hpuxnetwork = MockHPUXNetwork()
    default_interfaces = hpuxnetwork.get_default_interfaces()
    assert default_interfaces.get('default_interface') == 'lan0'
    assert default_interfaces.get('default_gateway') == '10.1.1.1'



# Generated at 2022-06-11 03:33:34.645039
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:33:36.617478
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:33:42.801771
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec={})
    test_network = HPUXNetwork(module=test_module)
    out = test_network.get_interfaces_info()
    assert(len(out) == 1)
    assert('lan0' in out)
    assert(out['lan0']['device'] == 'lan0')
    assert(out['lan0']['ipv4'] == {'network': '10.99.56.0',
                                   'interface': 'lan0',
                                   'address': '10.99.56.251'})


# Generated at 2022-06-11 03:33:51.327858
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = mock.Mock()
    module.run_command.return_value = 0, "lan0      0.0.0.0         0.0.0.0         0.0.0.0   UP\nlan1\
      192.168.81.204 192.168.81.0   255.255.255.0 UP\nlan2      0.0.0.0         0.0.0.0         0.0.0.0   UP\n\
      lan3      192.168.251.34    192.168.251.0  255.255.255.0 UP\n", None
    hpux = HPUXNetwork(module)
    interfaces = hpux.get_interfaces_info()

# Generated at 2022-06-11 03:33:55.563895
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec={
            "gather_subset": dict(default=[], type='list')
        }
    )
    h = HPUXNetwork(module)
    assert h.get_default_interfaces()
    assert h.get_interfaces_info()
    assert h.populate()

# Generated at 2022-06-11 03:34:03.868808
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Unit test for constructor of class HPUXNetwork
    """
    interfaces_info = {'lan0': {'device': 'lan0',
                                'ipv4': {'address': '10.112.19.20',
                                         'network': '10.112.0.0/16',
                                         'interface': 'lan0', }}}
    default_interfaces_info = {'default_interface': 'lan0',
                               'default_gateway': '10.112.0.1'}

    expected_result = interfaces_info
    expected_result.update(default_interfaces_info)

    m_module = MockModule()
    my_HPUXNetwork = HPUXNetwork(m_module)
    my_HPUXNetwork.interfaces = interfaces_info

# Generated at 2022-06-11 03:34:10.166088
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    out = """
default  0.0.0.0         UG   721    0      0 lan0
default  10.0.2.1        UG   0      0      0 lan3
                """
    expected = {'default_interface': 'lan0', 'default_gateway': '0.0.0.0'}
    network._module.run_command = Mock(return_value=(0, out, ''))
    assert network.get_default_interfaces() == expected

