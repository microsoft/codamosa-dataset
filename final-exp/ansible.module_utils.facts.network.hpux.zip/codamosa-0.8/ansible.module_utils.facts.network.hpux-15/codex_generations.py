

# Generated at 2022-06-11 03:25:27.811126
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork.
    """
    network_obj = HPUXNetwork()

    def mock_run_command(module, cmd):
        """
        Utility function to mock run_command.
        """
        rc = 0
        out = ("lan0      lan01    10.66.80.0      10.66.80.42 "
               "UP        1000 Full")
        err = ""
        return rc, out, err

    # Mock module
    network_obj.module.run_command = mock_run_command

    result = network_obj.get_interfaces_info()

# Generated at 2022-06-11 03:25:32.791528
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.platform == 'HP-UX'
    assert hn.fact_class == HPUXNetwork

# Unit test to test the constuctor of class HPUXNetwork

# Generated at 2022-06-11 03:25:36.548509
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    hpn = HPUXNetwork(module=module)
    assert hpn.get_default_interfaces() == {'default_gateway': '1.1.1.1', 'default_interface': 'lan0'}


# Generated at 2022-06-11 03:25:37.896995
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector.__name__ == 'HPUXNetworkCollector'

# Generated at 2022-06-11 03:25:38.752691
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    assert h.platform == 'HP-UX'



# Generated at 2022-06-11 03:25:49.200138
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeModule()
    network = HPUXNetwork(module)

    netstat_path = module.get_bin_path('netstat')
    module.run_command.return_value = (0, '/usr/sbin/netstat', '')
    assert network.get_bin_path('netstat') == netstat_path

    module.run_command.return_value = (
        0,
        "Kernel IP routing table\n"
        "Destination     Gateway         Flags Refs Use If   Expire\n"
        "default         192.0.2.1       UG         1    0 lan0\n"
        "192.0.2.0       255.255.255.0   U         1  176 lan0\n",
        '')
    default_interfaces = network.get_default_interfaces

# Generated at 2022-06-11 03:25:51.749467
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    my_obj = HPUXNetworkCollector()
    assert my_obj._fact_class == HPUXNetwork
    


# Generated at 2022-06-11 03:25:58.802040
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    test_network = HPUXNetwork(module=test_module)
    default_interfaces_facts = test_network.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '172.16.64.1'


# Generated at 2022-06-11 03:26:00.272164
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net.platform == 'HP-UX'

# Generated at 2022-06-11 03:26:02.004617
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'



# Generated at 2022-06-11 03:26:15.886815
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_input = """
lan0      1.1.1.1          1.1.1.0          U         -   -   -   -        lan0
lan1      2.2.2.2          2.2.2.0          U         -   -   -   -        lan0"""
    test_output = {'lan0': {'device': 'lan0', 'ipv4': {'network': '1.1.1.0',
                                                      'address': '1.1.1.1', 'interface': 'lan0'}},
                   'lan1': {'device': 'lan1', 'ipv4': {'network': '2.2.2.0',
                                                      'address': '2.2.2.2', 'interface': 'lan0'}}}
    network = HPUXNetwork()


# Generated at 2022-06-11 03:26:21.298874
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    x = HPUXNetwork()
    x.module = MockModule()
    x._get_interfaces = Mock(return_value=['lan0'])
    x.get_interfaces_info()
    assert x.get_interfaces_info() == {'lan0': {'device': 'lan0',
                                                'ipv4': {'address': '10.10.10.10'}}}



# Generated at 2022-06-11 03:26:23.294230
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({})
    assert network.platform == 'HP-UX'


# Generated at 2022-06-11 03:26:26.749405
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ Test that the populate method of HP-UXNetwork class works as expected"""
    # Test data
    module = MagicMock()
    network_instance = HPUXNetwork(module)
    # Run the test
    network_instance.populate()

# Generated at 2022-06-11 03:26:28.477795
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork({})
    assert hpux_network is not None


# Generated at 2022-06-11 03:26:34.281142
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.run_command.return_value = (0, "", "")
    test_module.get_bin_path.return_value = '/usr/bin/netstat'

    test_HPUXNetwork = HPUXNetwork(test_module)
    facts = test_HPUXNetwork.populate()

    assert 'default_interface' in facts
    assert 'interfaces' in facts



# Generated at 2022-06-11 03:26:41.594322
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network_collector = HPUXNetworkCollector()
    network = HPUXNetwork(network_collector)

    # Without default_interface and default_gateway in the output of netstat
    output = ' default          IP      192.168.1.1      link#1          UHS     0     0  lo0 '
    interfaces = network.get_default_interfaces(output)
    assert interfaces['default_interface'] == 'lo0'
    assert interfaces['default_gateway'] == '192.168.1.1'

    # With default_interface and default_gateway in the output of netstat
    output = ' default          IP      192.168.1.1      link#1          UHS     0     0  '
    interfaces = network.get_default_interfaces(output)

# Generated at 2022-06-11 03:26:43.390449
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net = HPUXNetworkCollector()
    assert net._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:26:54.304676
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    m = HPUXNetwork('ansible.module_utils.facts.network.hpux')
    assert m.default_gateway == m.default_gateway
    assert m.default_interface == m.default_interface
    assert m.interfaces == m.interfaces
    assert m.module.ansible_facts['ansible_net_default_gateway'] == m.default_gateway
    assert m.module.ansible_facts['ansible_net_default_interface'] == m.default_interface
    assert m.module.ansible_facts['ansible_net_interfaces'] == m.interfaces
    for iface in m.interfaces:
        assert m.module.ansible_facts['ansible_net_' + iface] == m.module.ansible_facts['ansible_net_' + iface]

# Generated at 2022-06-11 03:26:57.316421
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    network_collector = HPUXNetworkCollector(module=module)
    network_collector.collect()

# Generated at 2022-06-11 03:27:11.464785
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    result = HPUXNetwork().populate()
    assert result['ipv4']['address'] == '10.62.25.135'
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.62.25.1'

# Generated at 2022-06-11 03:27:14.353617
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-11 03:27:16.746594
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of HPUXNetworkCollector class is called without arguments
    """
    obj = HPUXNetworkCollector()



# Generated at 2022-06-11 03:27:26.507729
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = HPUXNetwork()
    m.module = FakeModule()
    facts = m.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.0.1'
    assert facts['default_interface'] == 'lan0'
    assert facts['interfaces'] == ['lan0']
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.0.0.118'
    assert facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-11 03:27:29.210239
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_class = HPUXNetworkCollector()
    assert net_class._platform == 'HP-UX'
    assert net_class._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:27:32.729389
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    m = AnsibleModule(argument_spec={})
    h = HPUXNetwork(m)
    interfaces = h.get_interfaces_info()
    assert interfaces is not None
    assert 'lan0' in interfaces
    assert 'lan0' in interfaces['lan0']
    assert 'ipv4' in interfaces['lan0']

# Generated at 2022-06-11 03:27:33.881094
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-11 03:27:39.179814
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    facts = HPUXNetwork({'module': FakeModule()})
    assert facts.get_default_interfaces() == {'default_interface': 'lan1',
                                              'default_gateway': '172.22.7.254'}


# Generated at 2022-06-11 03:27:48.640968
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    lines = '''
    default         128.123.122.0 UG   0      0        0 lan0
    128.123.122.0   255.255.255.0 U     2    118    42394 lan0
    128.123.122.0   255.255.255.0 U     1    349      959 lan1
    '''
    net.module.run_command = Mock(return_value=(0, lines, ''))
    assert net.get_default_interfaces() == {'default_gateway': '128.123.122.0',
                                            'default_interface': 'lan0'}



# Generated at 2022-06-11 03:27:57.862640
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.base import Network

    # sample input as subprocess.check_output would return

# Generated at 2022-06-11 03:28:18.798508
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork()



# Generated at 2022-06-11 03:28:24.581601
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, SAMPLE_NETSTAT_OUTPUT, None)
    hpx_network = HPUXNetwork(module)
    output = hpx_network.get_default_interfaces()
    assert output == {'default_interface': 'lan4', 'default_gateway': '192.0.2.2'}


# Generated at 2022-06-11 03:28:26.232016
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    return

if __name__ == '__main__':
    test_HPUXNetworkCollector()

# Generated at 2022-06-11 03:28:28.683687
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    fake_module = None
    obj = HPUXNetwork(fake_module)
    assert obj.platform == 'HP-UX'



# Generated at 2022-06-11 03:28:30.281870
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_object = HPUXNetwork()
    assert test_object.platform == 'HP-UX'


# Generated at 2022-06-11 03:28:32.440442
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_facts = HPUXNetwork(dict(module=dict()))
    assert(network_facts.populate())
    assert(network_facts.populate())


# Generated at 2022-06-11 03:28:33.667126
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    ml = HPUXNetworkCollector()
    assert ml.platform == 'HP-UX'

# Generated at 2022-06-11 03:28:39.755734
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    data = {
        'default_interface': '/usr/bin/netstat -nr',
        'interface_info': '/usr/bin/netstat -niw'
    }
    collection = HPUXNetworkCollector(None, data)
    collection.populate_facts()
    network_facts = collection.get_facts()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '192.168.4.1'
    assert network_facts['interfaces'] == ['lan0']
    assert network_facts['lan0']['device'] == 'lan0'
    assert network_facts['lan0']['ipv4']['address'] == '192.168.4.115'

# Generated at 2022-06-11 03:28:51.038682
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Test for netstat -niw output with data and without data
    class DummyModule:
        @staticmethod
        def run_command(cmd):
            if cmd == "/usr/bin/netstat -niw":
                out = """lan0   27136  0  0  -  0  0  0  0  -  4   0   0 unspec  0 0        - - -     - -"""
                return [0, out, '']
            else:
                return [0, "", ""]

        @staticmethod
        def get_bin_path(cmd):
            return cmd

    def check_result(interfaces):
        assert(len(interfaces) == 1)
        iface = interfaces['lan0']
        assert(iface['ipv4']['network'] == '0')

# Generated at 2022-06-11 03:28:54.216098
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Constructor of HPUXNetworkCollector object
    """
    obj = HPUXNetworkCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:29:37.823170
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._fact_class is not None
    assert hpux_network_collector._platform == 'HP-UX'


# Generated at 2022-06-11 03:29:46.212059
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class DummyModule(object):
        def __init__(self):
            self.run_command_values = dict()

# Generated at 2022-06-11 03:29:56.641950
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:29:59.082057
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._platform == 'HP-UX'


# Generated at 2022-06-11 03:30:08.720217
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    lan_lines = ["lan0       2        0    0    0    0    0    0    0"
                  "127.0.0.1        127.0.0.1         UGHD      0        0   29",
                 "lan1       1        0    0    0    0    0    0    0"
                  "10.94.24.41    10.94.22.0     UGHI       0     3000   60",
                 "lan1       2        0    0    0    0    0    0    0"
                  "10.94.24.41    10.94.24.41    UGHD       0        0   29"
                ]
    interfaces = {}
    for lan_line in lan_lines:
        words = lan_line.split()

# Generated at 2022-06-11 03:30:14.201342
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    getinterfacesinfo = HPUXNetwork(dict(), dict())
    ifaces_info = getinterfacesinfo.get_interfaces_info()
    assert 'lan0' in ifaces_info
    assert ifaces_info['lan0']['device'] == 'lan0'
    assert 'ipv4' in ifaces_info['lan0']
    assert 'interface' in ifaces_info['lan0']['ipv4']
    assert ifaces_info['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-11 03:30:23.107245
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})

    network_collector = HPUXNetworkCollector(module=module)
    network_collector.collect()
    facts = network_collector.get_facts()

    assert 'interfaces' in facts
    assert isinstance(facts['interfaces'], list)
    assert 'default_interface' in facts
    assert isinstance(facts['default_interface'], str)
    assert 'default_gateway' in facts
    assert isinstance(facts['default_gateway'], str)
    for interface in facts['interfaces']:
        assert interface in facts
        assert isinstance(facts[interface], dict)
        assert 'device' in facts[interface]
        assert isinstance(facts[interface]['device'], str)
        assert 'ipv4' in facts[interface]

# Generated at 2022-06-11 03:30:24.934268
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork({'ANSIBLE_MODULE_ARGS': {}})
    assert hn
    assert hn.module

# Generated at 2022-06-11 03:30:26.367857
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h = HPUXNetworkCollector()
    if h is None:
        return 1

# Generated at 2022-06-11 03:30:35.391071
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = Network()
    network_facts = module.get_network_facts()

    assert network_facts['default_interface'] == 'lan0', \
           "Incorrect default interface"
    assert network_facts['default_gateway'] == '10.43.31.5', \
           "Incorrect default gateway"
    assert 'lan0' in network_facts['interfaces'], \
           "Network device lan0 not found"
    assert network_facts['lan0']['ipv4']['address'] == '10.43.31.6', \
           "Incorrect IP address for lan0"

# Generated at 2022-06-11 03:32:24.920873
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector(None)
    assert network

# Generated at 2022-06-11 03:32:26.918181
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform=='HP-UX'
    collector = HPUXNetworkCollector()
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:32:34.888563
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    module = NetworkModuleTestCase(HPUXNetwork)
    set_module_args(dict())
    fake_rc = 0
    fake_out = 'default 192.168.1.1 UGS 0 lan0\n'
    module.run_command = MagicMock(return_value=(fake_rc, fake_out, ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    module.get_default_interfaces = HPUXNetwork.get_default_interfaces
    module.exit_json = AnsibleExitJson
    module.fail_json = AnsibleFailJson

    expected

# Generated at 2022-06-11 03:32:36.330889
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_facts = HPUXNetwork(dict(module=None))

    assert network_facts.platform == 'HP-UX'



# Generated at 2022-06-11 03:32:41.930430
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.0.1'
    assert 'lan0' in network_facts['interfaces']
    assert 'lan1' in network_facts['interfaces']
    assert 'lan2' in network_facts['interfaces']
    assert network_facts['lan0']['ipv4']['network'] == '10.0.0.0'
    assert network_facts['lan0']['ipv4']['address'] == '10.0.0.202'

# Generated at 2022-06-11 03:32:48.354204
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h = HPUXNetwork()

# Generated at 2022-06-11 03:32:49.051083
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()


# Generated at 2022-06-11 03:32:51.407726
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hostname = "test.example.com"
    HPUXNetworkCollector(module=None)
    HPUXNetwork(module=None, collected_facts={'ansible_facts': {'ansible_hostname': hostname}})

# Generated at 2022-06-11 03:32:54.303850
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc.platform == 'HP-UX'
    assert nc.fact_class == HPUXNetwork
    assert nc.fact_subclass == 'default'


# Generated at 2022-06-11 03:32:58.993702
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    obj = HPUXNetwork(module)
    interfaces = obj.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0', 'ipv4': {'network': '192.168.1.0', 'interface': 'lan0', 'address': '192.168.1.112'}}

