

# Generated at 2022-06-11 03:25:17.413456
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork('module')

# Generated at 2022-06-11 03:25:19.951249
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'


# Generated at 2022-06-11 03:25:20.940872
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-11 03:25:30.873515
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    my_mod = HPUXNetwork()
    actual = my_mod.get_interfaces_info()

# Generated at 2022-06-11 03:25:33.763136
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:25:44.684465
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule():
        def __init__(self, out, out1):
            self.run_command_out = out
            self.run_command_out1 = out1

        def run_command(self, cmd):
            if cmd == "/usr/bin/netstat -nr":
                return (0, self.run_command_out, None)
            if cmd == "/usr/bin/netstat -niw":
                return (0, self.run_command_out1, None)

    module = TestModule(out='default 10.0.2.2 UG lan0',
                        out1='lan0 lan0 UDP 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0')

    hpux = HPUXNetwork(module)
    ifaces = hpux.get_default_interfaces()
    assert ifaces

# Generated at 2022-06-11 03:25:46.893742
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network.__class__.__name__ == "HPUXNetworkCollector"

# Generated at 2022-06-11 03:25:49.684359
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork()
    fact = 'default_interface'
    default_interfaces = hpux_network.get_default_interfaces()
    assert fact in default_interfaces
    fact = 'default_gateway'
    assert fact in default_interfaces



# Generated at 2022-06-11 03:25:52.630044
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector.network_facts is None


# Generated at 2022-06-11 03:25:56.715425
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_obj = HPUXNetwork(module)
    assert network_obj._platform == 'HP-UX'
    assert network_obj._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:26:08.089273
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec={})
    net = HPUXNetwork(test_module)
    interfaces = net.get_interfaces_info()
    assert interfaces == {'lan0': {'ipv4': {'interface': 'lan0',
                                           'network': '192.168.1.0',
                                           'address': '192.168.1.147'},
                                  'device': 'lan0'}}



# Generated at 2022-06-11 03:26:11.616420
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    class MockModule(object):
        def get_bin_path(self, command):
            return command
        def run_command(self, command):
            return (0, '', '')
    hpu = HPUXNetwork(MockModule())
    hpu.populate()

# Generated at 2022-06-11 03:26:16.534455
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = type('module', (object,), dict(run_command=lambda *_: (0, 'default 123.123.123.123 0.0.0.0 UG 0 0 0 lan0', None)))
    hpux_network = HPUXNetwork(test_module)
    result = hpux_network.get_default_interfaces()
    assert result['default_gateway'] == '123.123.123.123'
    assert result['default_interface'] == 'lan0'


# Generated at 2022-06-11 03:26:22.374500
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    testobj = HPUXNetwork()
    testobj.module.run_command = mock_run_command
    testobj.module.get_bin_path = mock_get_bin_path

    devices = testobj.get_interfaces_info()
    assert len(devices) == 4
    assert 'lan9000' in devices
    assert 'lan0' in devices
    assert 'lan1000' in devices
    assert 'lan2000' in devices



# Generated at 2022-06-11 03:26:27.563425
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    '''
    Unit test for constructor of class HPUXNetwork
    '''
    myNetwork = HPUXNetwork()
    assert myNetwork.platform == 'HP-UX'
    assert myNetwork.default_interface == 'lan0'
    assert myNetwork.default_gateway == '172.16.10.254'
    assert myNetwork.interfaces == ['lan0']

# Generated at 2022-06-11 03:26:30.483732
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'



# Generated at 2022-06-11 03:26:32.204901
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._fact_class is not None

# Generated at 2022-06-11 03:26:35.378642
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # verify that a ModuleStub exist
    assert "Command" in str(type(Network.module))

    assert str(type(Network.get_default_interfaces())) == "<type 'dict'>"
    assert str(type(Network.get_interfaces_info())) == "<type 'dict'>"
    assert str(type(Network.populate(NetworkCollector))) == "<type 'dict'>"

# Generated at 2022-06-11 03:26:37.799883
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    This is a unit test for the constructor of class HPUXNetwork
    """
    results = HPUXNetworkCollector._fact_class()
    assert results._platform == 'HP-UX'

# Generated at 2022-06-11 03:26:39.875616
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network._fact_class == 'HP-UX'
    assert network._platform == 'HP-UX'


# Generated at 2022-06-11 03:27:00.002230
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    facts = network.populate()
    assert facts
    assert 'default_interface' in facts.keys()
    assert 'default_gateway' in facts.keys()
    assert 'interfaces' in facts.keys()
    assert 'lan0' in facts.keys()
    assert 'ipv4' in facts['lan0'].keys()
    assert 'address' in facts['lan0']['ipv4'].keys()
    assert 'network' in facts['lan0']['ipv4'].keys()
    assert 'interface' in facts['lan0']['ipv4'].keys()


# Generated at 2022-06-11 03:27:08.756094
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    default_interfaces = {'default_interface': 'lan0', 'default_gateway': '1.2.3.4'}
    default_interfaces_ipv4 = {'address': '1.2.3.4',
                               'network': '1.2.3.0',
                               'interface': 'lan0',
                               'address': '1.2.3.4'}

# Generated at 2022-06-11 03:27:20.297738
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for get_interfaces_info method.
    """
    os.environ['NETSTAT'] = '/usr/bin/netstat'
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    if os.path.exists('results'):
        out_file = open('results/get_interfaces_info_output', 'w')
        out_file.write(str(interfaces))
        out_file.close()
    if os.path.exists('tests/get_interfaces_info_output'):
        test_file = open('tests/get_interfaces_info_output', 'r')
        output = eval(test_file.read())
        test_file.close()

# Generated at 2022-06-11 03:27:22.976437
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    assert network_facts.platform == 'HP-UX'
    assert network_facts.module == module


# Generated at 2022-06-11 03:27:25.704501
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    NetworkCollector._platform = 'HP-UX'
    assert HPUXNetworkCollector._platform == 'HP-UX', 'Error in network_collector'


# Generated at 2022-06-11 03:27:33.912756
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Method get_interfaces_info of class HPUXNetwork return information
    about network interfaces on HP-UX system.
    Return value of this method should be a dictionary of
    dictionaries of interfaces' information.
    """
    rc, out, err = NetworkCollector().module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        for i in range(len(words) - 1):
            if words[i][:3] == 'lan':
                device = words[i]
                network = words[i + 2]
                address = words[i + 3]
                interfaces = {'ipv4': {'interface': device,
                                       'address': address,
                                       'network': network}}

# Generated at 2022-06-11 03:27:41.558526
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = FakeAnsibleModule()
    test_module.mock_run_command(1, "netstat -niw output\n")
    test_network = HPUXNetwork(test_module)
    interfaces = test_network.get_interfaces_info()

# Generated at 2022-06-11 03:27:45.226420
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = HPUXNetworkCollector(module)
    assert(collector._fact_class == HPUXNetwork)
    assert(collector._platform == 'HP-UX')


# Generated at 2022-06-11 03:27:50.474563
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux.hpux import get_interfaces_info
    module = None
    network_info = HPUXNetwork(module)
    res = network_info.populate()
    print(res)

# Generated at 2022-06-11 03:27:52.755774
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:28:15.289944
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:28:20.582734
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    fixture = 'default     default     UGS   0 0  lan0   10.0.2.2        UGScI  0 0   0\n'
    network = HPUXNetwork()
    result = network.get_default_interfaces()
    expected = {'default_interface': 'lan0', 'default_gateway': '10.0.2.2'}
    assert result == expected



# Generated at 2022-06-11 03:28:21.979837
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hnx = HPUXNetworkCollector()
    assert hnx is not None

# Generated at 2022-06-11 03:28:25.764154
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    assert hpux_network._module == module
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-11 03:28:31.009856
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
            argument_spec=dict(
                gather_subset=dict(default=['!all'], type='list')
                )
            )
    hpux_network = HPUXNetwork(module)
    result = hpux_network.get_default_interfaces()
    assert 'default_interface' in result
    assert 'default_gateway' in result



# Generated at 2022-06-11 03:28:36.597751
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    setup_detect_sudo(module)
    hpux_network = HPUXNetwork()
    hpux_network.module = module
    expected_keys = ['default_interface', 'default_gateway']
    result = hpux_network.get_default_interfaces()
    assert ('default_interface' in result.keys())
    assert ('default_gateway' in result.keys())
    assert (set(expected_keys) == set(result.keys()))


# Generated at 2022-06-11 03:28:40.008418
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    hpux_network = HPUXNetwork(module)
    hpux_network.populate()

# Unit test class HPUXNetworkCollector

# Generated at 2022-06-11 03:28:51.317710
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Create HPUXNetwork instance
    net_test = HPUXNetwork(None)

    # Create mock netstat output
    default_out = "default 192.168.122.1 UGS 0 117906267 en0\n" + \
                  "default 192.168.122.1 UGS 0 117906267 em0"

    # Set module return values
    net_test.module.run_command.return_value = (0, default_out, None)

    # Run method under test
    default_interfaces_facts = net_test.get_default_interfaces()

    # Test interface name
    assert default_interfaces_facts["default_interface"] == 'en0'

    # Test gateway address
    assert default_interfaces_facts["default_gateway"] == '192.168.122.1'

# Unit test

# Generated at 2022-06-11 03:28:53.791867
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpnx_network_collector = HPUXNetworkCollector()
    assert hpnx_network_collector.fact_class is HPUXNetwork


# Generated at 2022-06-11 03:28:56.512639
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_network = HPUXNetwork()
    network_facts = hpux_network.populate()

if __name__ == '__main__':
    test_HPUXNetwork_populate()

# Generated at 2022-06-11 03:29:44.982298
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    network.module = MagicMock()
    network.module.run_command = MagicMock(return_value=(0, '''lan0: flags=201 mtu 1500
        inet 127.0.0.1 netmask ffffff00 broadcast 127.255.255.255
        up
        lan1: flags=201 mtu 1500
        inet 192.168.1.3 netmask ffffff00 broadcast 192.168.1.255
        up
    ''',''))
    result = network.get_interfaces_info()


# Generated at 2022-06-11 03:29:46.738192
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-11 03:29:49.612368
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test of method __init__ of class Network"""
    collector = HPUXNetworkCollector()
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == "HP-UX"
    assert collector._network_class == HPUXNetwork

# Generated at 2022-06-11 03:30:00.862519
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, HPUX_NETSTAT_OUTPUT, "")
    module.get_bin_path.return_value = True

    network = HPUXNetwork(module=module)
    network.populate()

    # Check content of network.facts
    assert network.facts['default_interface'] == 'lan0'
    assert network.facts['default_gateway'] == '10.209.16.1'
    assert 'interfaces' in network.facts
    assert len(network.facts['interfaces']) == 4
    assert 'lan0' in network.facts['interfaces']
    assert network.facts['lan0']['device'] == 'lan0'
    assert network.facts['lan0']['ipv4']['address']

# Generated at 2022-06-11 03:30:02.346210
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    a = HPUXNetwork()
    assert a.platform == "HP-UX"

# Generated at 2022-06-11 03:30:11.539674
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    This test unit checks the correctness of method get_interfaces_info
    of class HPUXNetwork. It generates a list of interfaces with its
    attributes and compares the result with the result of the method
    get_interfaces_info.
    """
    import platform
    import re
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork

    hpux_network = HPUXNetwork({})
    interfaces = hpux_network.get_interfaces_info()
    out = hpux_network.module.run_command("/usr/bin/netstat -niw")
    lines = out[1].splitlines()
    for line in lines:
        words = line.split()

# Generated at 2022-06-11 03:30:15.210246
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_obj = HPUXNetwork()
    assert network_obj.default_interface is None
    assert network_obj.default_gateway is None
    assert network_obj.interfaces is None
    assert network_obj.ipv4 is None
    assert network_obj.ipv6 is None


if __name__ == '__main__':
    test_HPUXNetwork()

# Generated at 2022-06-11 03:30:16.366749
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    print(hn)

# Generated at 2022-06-11 03:30:25.643228
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module_mock = mock.Mock()
    module_mock.run_command.return_value = 0, \
        '          Destination        Gateway           Flags Refs Use Interf\n' \
        'default         172.18.10.1    172.18.10.2           UG        7 lo0\n' \
        '224.0.0/4        127.0.0.1      127.0.0.1           U         4 lo0\n' \
        '127.0.0.0        127.0.0.1      127.0.0.1           U         4 lo0\n', ''

    test_obj = HPUXNetwork(module_mock)
    test_facts = test_obj.get_default_interfaces()
    assert 'default_interface' in test_facts
    assert test

# Generated at 2022-06-11 03:30:35.079797
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    network = HPUXNetwork(module)
    network_facts = network.populate()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.17.0.1'
    assert network_facts['interfaces'] == ['lan0', 'lan1']
    assert network_facts['lan0'] == {'device': 'lan0', 'ipv4': {'network': '10.17.0/24', 'address': '10.17.0.136', 'interface': 'lan0'}}
    assert network_facts['lan1'] == {'device': 'lan1', 'ipv4': {'network': '10.20.0/24', 'address': '10.20.0.134', 'interface': 'lan1'}}

# Generated at 2022-06-11 03:32:24.814668
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork({"module": ""}) is not None

# Generated at 2022-06-11 03:32:32.982640
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux.hpux_ifconfig import HPUXNetwork as HPUXNetwork_test

    obj_network = HPUXNetwork_test()

    interfaces = obj_network.get_interfaces_info()

    for iface in interfaces:
        assert iface in ('lan0', 'lan1', 'lan100', 'lan1000')
        assert 'device' in interfaces[iface]
        assert 'ipv4' in interfaces[iface]
        assert 'address' in interfaces[iface]['ipv4']
        assert 'network' in interfaces[iface]['ipv4']
        assert interfaces[iface]['ipv4']['address'] == '192.168.104.135'

# Generated at 2022-06-11 03:32:35.866172
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    HPUX_network = HPUNXNetwork(module)
    module.run_command = MagicMock(return_value=(0, 'a\nb\nc', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    network_facts = HPUX_network.populate()
    assert network_facts == {'default_interface': 'lan1',
                             'default_gateway': 'b',
                             'interfaces': ['lan1']}



# Generated at 2022-06-11 03:32:40.160047
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod_args = dict(
    )
    module = FakeModule(**mod_args)
    hpux_network = HPUXNetwork(module=module)
    assert hpux_network.module == module
    assert hpux_network.module.params['gather_subset'] == ['all']
    assert hpux_network.module.params['gather_timeout'] == 10
    assert hpux_network.module.params['filter'] == '*'
    assert hpux_network.module.params['gather_network_resources'] == ['all']


# Generated at 2022-06-11 03:32:46.437539
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hp_ux import HPUXNetwork
    hux = HPUXNetwork()

# Generated at 2022-06-11 03:32:53.806707
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    This unittest verifies the output of HPUXNetworkCollector().
    """
    class FakeModule(object):
        def get_bin_path(path, required=False):
            return '/usr/bin/netstat'

        def run_command(cmd, check_rc=True, close_fds=True,
                        executable=None, data=None, binary_data=False):
            out = '''/usr/bin/netstat -niw
lan0       0      0        0        0        0         0
lan1       111    222      333      444      555       666
'''
            return 0, out, ''

    class FakeFactManager(object):
        def __init__(self):
            self.ansible_facts = {'ansible_net_interfaces': 'lan0 lan1'}

    module

# Generated at 2022-06-11 03:32:59.549882
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net_obj = HPUXNetwork()

    def exec_command(cmd, *args, **kwargs):
        rc = 0
        out = "default 192.168.56.1 UG lan1"
        err = None
        return rc, out, err

    net_obj.module.run_command = exec_command

    assert net_obj.get_default_interfaces() == {'default_interface': 'lan1',
                                                'default_gateway': '192.168.56.1'}



# Generated at 2022-06-11 03:33:01.661297
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network._fact_class == HPUXNetwork
    assert network._platform == 'HP-UX'


# Generated at 2022-06-11 03:33:02.767275
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mod = HPUXNetwork()
    assert mod is not None


# Generated at 2022-06-11 03:33:05.812827
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    _module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    hpux_network = HPUXNetwork(_module)
    interfaces = hpux_network.get_interfaces_info()
    assert interfaces != {}