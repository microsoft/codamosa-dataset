

# Generated at 2022-06-11 03:25:26.983579
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpu_ux.network import HPUXNetwork
    from ansible.module_utils.facts.collector import TestAnsibleModule
    from ansible.module_utils.facts import timeout
    import os
    import os.path
    import sys
    import io

    module = TestAnsibleModule()
    network = HPUXNetwork(module)

    # We need to mock the command to return a specific output (the content of
    # /usr/bin/netstat -nr on a system that we know)
    network.module.run_command = mock_run_command
    network.module.run_command.__name__ = mock_run_command.__name__

    default_interfaces_facts = network.get_default_interfaces()


# Generated at 2022-06-11 03:25:39.006581
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class RunCommandMock(object):
        def __init__(self):
            self.last_command = None
            self.last_rc = None
            self.last_out = None
            self.last_err = None

        def run_command(self, command, check_rc=False, close_fds=True):
            self.last_command = command
            self.last_rc = 0
            self.last_out = """lan0
lan0      192.168.1.0      0.0.0.0        U         0       0     lan0
lan1
lan1      192.168.2.0      0.0.0.0        U         0       0     lan1
lan2
lan2      192.168.3.0      0.0.0.0        U         0       0     lan2
"""

# Generated at 2022-06-11 03:25:40.853731
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    obj = HPUXNetwork()
    assert obj.platform == 'HP-UX'



# Generated at 2022-06-11 03:25:50.777897
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux.netstat import HPUXNetworkCollector
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    new_network_facts = network_collector.populate()

    assert type(new_network_facts) == dict
    assert new_network_facts['interfaces'] == ['lan0', 'lan1', 'lan2', 'lan3']
    assert new_network_facts['default_interface'] == 'lan0'
    assert new_network_facts['default_gateway'] == '172.17.84.1'
    assert new_network_facts['lan0']['ipv4']['address'] == '172.17.84.132'

# Generated at 2022-06-11 03:26:02.395698
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    n = HPUXNetwork(module)
    facts = n.populate()
    assert facts['default_interface'] == 'lan0'
    assert 'ipv4' in facts['lan0']
    assert 'ipv4' in facts['lan1']
    assert facts['ipv4']['address'] == '172.22.30.2'
    assert facts['lan0']['ipv4']['address'] == '172.22.30.2'
    assert facts['lan0']['ipv4']['network'] == '172.22.30.0'
    assert facts['lan0']['ipv4']['interface'] == 'lan0'

# Generated at 2022-06-11 03:26:12.101422
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:26:14.239149
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'
    assert hpux_network.default_interfaces == {}



# Generated at 2022-06-11 03:26:23.643789
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            pass

        def run_command(self, cmd):
            return (0, 'lan0      FASt32      ETHER', '')

    module = MockModule()
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == 'FASt32'
    assert interfaces['lan0']['ipv4']['network'] == 'ETHER'
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'



# Generated at 2022-06-11 03:26:26.706485
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    network_collector = NetworkCollector()
    assert isinstance(network_collector, NetworkCollector)

# Generated at 2022-06-11 03:26:28.086250
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-11 03:26:40.582593
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:26:45.753505
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux = HPUXNetwork({}, {})

    assert hpux.module.get_bin_path('netstat') is not None
    assert hpux.module.run_command("/usr/bin/netstat -nr")[0] == 0
    assert hpux.module.run_command("/usr/bin/netstat -niw")[0] == 0
    assert hpux.get_default_interfaces()['default_interface'] is not None
    assert hpux.get_default_interfaces()['default_gateway'] is not None

# Generated at 2022-06-11 03:26:48.808148
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:26:50.574427
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    my_hpux_net = HPUXNetwork()

    assert my_hpux_net.platform == 'HP-UX'

# Generated at 2022-06-11 03:26:55.392830
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    HPUXNetwork_obj = HPUXNetwork()
    default_interfaces = HPUXNetwork_obj.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0',
                                  'default_gateway': '192.168.1.1'}


# Generated at 2022-06-11 03:26:58.056602
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-11 03:27:00.699010
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj
    assert obj._fact_class == HPUXNetwork
    assert obj._platform == 'HP-UX'



# Generated at 2022-06-11 03:27:03.885729
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_ins = HPUXNetworkCollector()
    print("Class HPUXNetworkCollector: " + str(hpux_network_ins))

if __name__ == '__main__':
    test_HPUXNetworkCollector()

# Generated at 2022-06-11 03:27:05.799958
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    a = HPUXNetworkCollector()
    assert a._fact_class == HPUXNetwork
    assert a._platform == 'HP-UX'

# Generated at 2022-06-11 03:27:07.019824
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 03:27:19.768941
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector.platform == 'HP-UX'

# Generated at 2022-06-11 03:27:29.615123
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:27:33.585764
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork()
    network.module = module
    network.module.run_command = mock.Mock(
        return_value=(0, """
default        192.168.1.1 UG       1        0 lan0
""",
                      None))
    assert network.get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}
    return True



# Generated at 2022-06-11 03:27:41.732751
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Constructor for HPUXNetwork should set default value for empty
    variables.
    """
    module = {'run_command': run_command_stub}
    network = HPUXNetwork(module)
    assert network._facts['default_interface'] == "lan0"
    assert network._facts['default_gateway'] == "10.1.1.1"

    assert "lan0" in network._facts['interfaces']
    assert "lo0" in network._facts['interfaces']

# Generated at 2022-06-11 03:27:44.918311
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    This function tests the constructor of the class HPUXNetworkCollector.
    """
    hpuxNetworkCollector = HPUXNetworkCollector()
    assert hpuxNetworkCollector is not None


# Generated at 2022-06-11 03:27:55.430834
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.network.hpux
    import os
    import sys

    if sys.version_info[0] >= 3:
        unicode = str

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    collector.collectors.append(HPUXNetworkCollector(module=module))

    # Check that facts has been registered
    assert(collector._fact_collectors[HPUXNetworkCollector._platform] is not None)
    # Check that fact class is HPUXNetwork

# Generated at 2022-06-11 03:27:58.142957
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:28:03.828877
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    net_facts = net.get_interfaces_info()
    assert 'lo0' in net_facts
    assert 'ipv4' in net_facts['lo0']
    assert 'address' in net_facts['lo0']['ipv4']
    assert '127.0.0.1' in net_facts['lo0']['ipv4']['address']

# Generated at 2022-06-11 03:28:13.638813
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:28:16.125620
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """
    Test for HPUXNetwork class constructor.
    """
    hpx_n = HPUXNetwork(None)
    assert hpx_n is not None


# Generated at 2022-06-11 03:28:36.314800
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts_collector = HPUXNetworkCollector()
    assert facts_collector._fact_class is HPUXNetwork
    assert facts_collector._platform == 'HP-UX'

# Generated at 2022-06-11 03:28:38.183440
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    assert HPUXNetwork().get_default_interfaces() == \
           {'default_interface': 'lan0',
            'default_gateway': '10.0.2.2'}


# Generated at 2022-06-11 03:28:49.173581
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    h = HPUXNetwork()
    d = {}
    sample_out = '''lanXX_YY\tlanXX_YY\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\tlanXX_YY\t0\t0\t0
lanZZ_AA\tlanZZ_AA\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\tlanZZ_AA\t0\t0\t0
'''

# Generated at 2022-06-11 03:28:51.484800
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module = AnsibleModule(argument_spec={})
    network.get_default_interfaces()
    assert True

# Generated at 2022-06-11 03:29:00.180420
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network_object = HPUXNetwork(None)

    output = '''default  192.168.1.1          UG       0   1     lan3
default  192.168.1.1          UG       5   0     lan3
lan0     127.0.0.0           UHl      0   5      127.0.0.1
lan1     192.168.1.0        U         0   5     lan3
127.0.0.1         127.0.0.1          UH       1   3      lo0
192.168.1.50      192.168.1.50       UH       4   4    lan3'''


# Generated at 2022-06-11 03:29:04.810523
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network_facts = HPUXNetwork()
    default_interfaces_facts = network_facts.get_default_interfaces()
    assert isinstance(default_interfaces_facts, dict)
    assert 'default_interface' in default_interfaces_facts
    assert 'default_gateway' in default_interfaces_facts


# Generated at 2022-06-11 03:29:15.949617
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Unit test for method populate of class HPUXNetwork"""
    from ansible.module_utils.facts.network import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts import base
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network import Network
    from ansible.module_utils.facts.utils import get_file_lines
    import os
    import os.path
    import sys
    import unittest

    class MockModule(object):
        def __init__(self, params):
            self.params

# Generated at 2022-06-11 03:29:24.352689
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock({'get_bin_path': lambda x: '/usr/bin/netstat'})
    network = HPUXNetwork(module)


# Generated at 2022-06-11 03:29:32.867797
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # input data
    network = HPUXNetwork({})
    network.module = AnsibleModule(argument_spec=dict())
    network.module.run_command = MagicMock(return_value=(0,
                                                         'default 10.20.30.40 10.20.30.5 UGS 0 0 en1',
                                                         ''))
    # the actual test
    r = network.get_default_interfaces()
    # ensure we got the correct output
    assert r == {'default_interface': 'en1', 'default_gateway': '10.20.30.5'}



# Generated at 2022-06-11 03:29:37.394731
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.interfaces == [u'lan0', u'lan1', u'lan2', u'lan3']
    assert network.default_interface_name == 'lan0'
    assert network.default_gateway == '10.20.68.1'

# Generated at 2022-06-11 03:30:19.963512
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    input = "default 10.10.10.1 UG 1 0 lan1000\n"
    result = HPUXNetwork().get_default_interfaces()
    expected = {'default_gateway': '10.10.10.1', 'default_interface': 'lan1000'}
    assert result == expected

# Generated at 2022-06-11 03:30:29.333847
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(module)

    rc, out, err = module.run_command("/usr/bin/netstat -nr")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if len(words) > 1:
            if words[0] == 'default':
                gateway = words[1]
                default_interface = words[4]

    rc, out, err = module.run_command("/usr/bin/netstat -niw")
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        for i in range(len(words) - 1):
            if words[i][:3] == 'lan':
                device = words[i]
                address

# Generated at 2022-06-11 03:30:33.244288
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    fact_class = HPUXNetwork(module)
    default_interfaces = fact_class.get_default_interfaces()
    assert 'default_interface' in default_interfaces
    assert 'default_gateway' in default_interfaces


# Generated at 2022-06-11 03:30:35.439218
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net_collector = NetworkCollector()
    network = HPUXNetwork()

    interfaces = network.get_interfaces_info()
    assert "lan0" in interfaces

# Generated at 2022-06-11 03:30:36.884324
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert isinstance(nc, HPUXNetworkCollector)

# Generated at 2022-06-11 03:30:39.394650
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    networkCollector = HPUXNetworkCollector()
    assert networkCollector._fact_class == HPUXNetwork
    assert networkCollector._platform == 'HP-UX'

# Generated at 2022-06-11 03:30:45.236467
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )

    nm = NetworkCollector(module=module, platform='HP-UX')
    nm.collect()
    facts = nm.get_facts()
    interfaces = facts['interfaces']
    default_interface = facts['default_interface']
    default_gateway = facts['default_gateway']

    assert default_interface == 'lan2'
    assert default_gateway == '192.168.1.1'
    assert 'lan0' in interfaces
    assert 'lan5' in interfaces

# Generated at 2022-06-11 03:30:49.624344
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    interfaces = net.get_interfaces_info()

    assert interfaces is not None

    if 'lo0' in interfaces:
        assert interfaces['lo0']['ipv4']['address'] == '127.0.0.1'
        assert interfaces['lo0']['ipv4']['network'] == '127.0.0.0'
    else:
        assert False

# Generated at 2022-06-11 03:30:51.484822
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu = HPUXNetwork()
    assert hpu is not None
    assert hpu.platform == 'HP-UX'



# Generated at 2022-06-11 03:30:55.836915
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    net = HPUXNetwork(module)
    output = 'default 192.168.1.5 UG lan0\n'
    expected_output = {'default_gateway': '192.168.1.5',
                       'default_interface': 'lan0'}
    net.module.run_command = Mock(return_value=(0, output, ""))
    assert net.get_default_interfaces() == expected_output


# Generated at 2022-06-11 03:32:49.385494
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, 'output', 'err'))
    network = HPUXNetwork(mock_module)
    mock_module.run_command.assert_called_with('/usr/bin/netstat -nr')
    mock_module.run_command.assert_called_with('/usr/bin/netstat -niw')
    assert network.default_interfaces['default_interface'] == 'lan0'
    assert network.interfaces[0] == 'lan0'



# Generated at 2022-06-11 03:32:57.251019
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    network.module.run_command = Mock(return_value=(0, NETSTAT_NIW, ''))


# Generated at 2022-06-11 03:32:59.150619
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpx = HPUXNetworkCollector()
    assert hpx._fact_class == HPUXNetwork
    assert hpx._platform == 'HP-UX'

# Generated at 2022-06-11 03:33:03.829627
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.Mock(return_value=(0, "", ""))
    hpuxNetwork = HPUXNetwork(module)
    hpuxNetwork.get_default_interfaces()
    return_value = module.run_command.call_args_list[0][0][0]
    assert return_value == '/usr/bin/netstat -nr'



# Generated at 2022-06-11 03:33:11.518761
# Unit test for constructor of class HPUXNetworkCollector

# Generated at 2022-06-11 03:33:13.302474
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    instance_HPUXNetwork = HPUXNetwork()
    assert instance_HPUXNetwork.platform == 'HP-UX'


# Generated at 2022-06-11 03:33:16.812354
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0',
                                  'default_gateway': '192.168.0.1'}

# Generated at 2022-06-11 03:33:25.865940
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    facts = HPUXNetwork()
    fact_dict = {'default_interface': 'lan0', 'default_gateway': '192.168.0.1',
                 'interfaces': ['lan0', 'lan1', 'lo0'],
                 'lan0': {'device': 'lan0', 'ipv4': {'address': '192.168.0.101'}},
                 'lan1': {'device': 'lan1', 'ipv4': {'address': '192.168.0.102'}},
                 'lo0': {'device': 'lo0', 'ipv4': {'address': '127.0.0.1'}}}
    test_dict = facts.populate()
    assert test_dict == fact

# Generated at 2022-06-11 03:33:29.400830
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test class HPUXNetworkCollector constructor.
    """
    fact_network = HPUXNetworkCollector()
    assert fact_network._platform == 'HP-UX'
    assert fact_network._fact_class.platform == 'HP-UX'

if __name__ == '__main__':
    test_HPUXNetworkCollector()

# Generated at 2022-06-11 03:33:30.741484
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    HPUXNetwork = HPUXNetwork()
    assert HPUXNetwork.populate() is None