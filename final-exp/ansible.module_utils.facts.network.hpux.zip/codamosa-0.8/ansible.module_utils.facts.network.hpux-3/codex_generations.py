

# Generated at 2022-06-11 03:25:21.837424
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()
    assert hn.__class__.__name__ == 'HPUXNetworkCollector'
    assert hn.__class__.__bases__[0].__name__ == 'NetworkCollector'



# Generated at 2022-06-11 03:25:23.362127
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork({'module_name': 'test_module'})
    assert hpn._platform == 'HP-UX'

# Generated at 2022-06-11 03:25:30.253293
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpuxnet = HPUXNetwork()

    class FakeModule(object):
        def run_command(self, command, check_rc=True):
            return 0, test_string, ''


# Generated at 2022-06-11 03:25:34.722977
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    hpux_network = HPUXNetwork()
    default_interfaces = hpux_network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.4.1'


# Generated at 2022-06-11 03:25:45.686450
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.network.hpux import Network
    from ansible.module_utils.facts.network.hpux import NetworkCollector

    network = HPUXNetwork()
    interfaces = network.get_interfaces_info()
    print(interfaces)
    assert len(interfaces) == 2
    assert interfaces['lan1'] == {'ipv4': {'network': '172.16.1.0', 'interface': 'lan1', 'address': '172.16.1.100'}, 'device': 'lan1'}

# Generated at 2022-06-11 03:25:50.554544
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockAnsibleModule()
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    if 'default_interface' in default_interfaces:
        assert default_interfaces['default_interface'] is not None
    if 'default_gateway' in default_interfaces:
        assert default_interfaces['default_gateway'] is not None



# Generated at 2022-06-11 03:25:52.417090
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert issubclass(HPUXNetworkCollector, NetworkCollector)

# Generated at 2022-06-11 03:26:03.597672
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    dut = HPUXNetwork(None)
    dut.module.run_command = MockRunCommand
    dut.module.run_command.side_effect = [
        (0, "Kernel  Interface table\nlana0  lan0          2a01:c0:1:1234::1/64\n", ''),
        (0, "Kernel  Interface table\nlana1  lan1          2a01:c0:1:1234::2/64\n", ''),
        (0, "Kernel  Interface table\n", ''),
    ]
    interfaces = dut.get_interfaces_info()

# Generated at 2022-06-11 03:26:12.845208
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    class Mod:
        def run_command(self, command):
            return 1, '/usr/bin/netstat -niw\nlan0       link#2        UP        10Mb    HD    1000baseT       Full    06:6b:f5:bd:6d:24\nlan4       link#4        UP        10Mb    HD    1000baseT       Full    06:6b:f5:bd:6d:23', 'stderr'

    module = Mod()
    net = HPUXNetwork()
    n = net.get_interfaces_info()

    assert n['lan0']['ipv4']['address'] == '10Mb'
    assert n['lan4']['ipv4']['address'] == 'UP'

# Generated at 2022-06-11 03:26:21.685277
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    m = MagicMock()
    m.module.run_command.return_value = (0, '/usr/sbin/netstat: Some result\n', '')

    net = HPUXNetwork()
    net.module = m
    net.get_default_interfaces = MagicMock(return_value={'default_interface': 'lan1',
                                                         'default_gateway': '1.1.1.1'})

# Generated at 2022-06-11 03:26:28.604603
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    collector = HPUXNetworkCollector()
    network_instance = collector.get_network_instance()
    assert network_instance._platform == 'HP-UX'

# Generated at 2022-06-11 03:26:36.832760
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    net = HPUXNetwork(None, None)

    netstat_result = (0, '''default 192.168.200.1 UGMS 0 0 lan0
127.0.0.0 127.0.0.1 UH 2 0 lo0
192.168.200.0 192.168.200.1 U 20 36 lan0
''', '')

    net._module.run_command = lambda *args, **kwargs: netstat_result

    facts = net.get_default_interfaces()

    assert facts == {'default_interface': 'lan0', 'default_gateway': '192.168.200.1'}



# Generated at 2022-06-11 03:26:37.836643
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:26:45.554142
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module1 = AnsibleModule(argument_spec={})
    test_module1.run_command = MagicMock(return_value=(0, 'lan0    vlan       192.168.0.2        192.168.0.0       UHLc   0   42   -  1', ''))
    test_network1 = HPUXNetwork(test_module1)
    result1 = test_network1.get_interfaces_info()
    assert result1['lan0']['device'] == 'lan0'
    assert result1['lan0']['ipv4']['network'] == '192.168.0.0'
    assert result1['lan0']['ipv4']['address'] == '192.168.0.2'

# Generated at 2022-06-11 03:26:47.513423
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork.platform == 'HP-UX'



# Generated at 2022-06-11 03:26:58.526976
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module_args = dict()
    module_args['gather_network_resources'] = 'yes'
    test_module = NetworkCollector.create_ansible_module(module_args)
    network_info = HPUXNetwork(test_module)

    network_default_interfaces = network_info.get_default_interfaces()
    assert 'default_interface' in network_default_interfaces
    assert 'default_gateway' in network_default_interfaces

    network_interfaces = network_info.get_interfaces_info()
    assert 'device' in network_interfaces['lan0']
    assert 'ipv4' in network_interfaces['lan0']

    network_facts = network_info.populate()
    assert 'default_interface' in network_facts
    assert 'interfaces' in network_facts
   

# Generated at 2022-06-11 03:27:00.785884
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'


# Generated at 2022-06-11 03:27:09.180790
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Checks that the get_interfaces_info method correctly constructs
    a list of interface dictionaries.
    """
    class HP_Module:
        def __init__(self):
            self.run_command = HP_Module.run_command


# Generated at 2022-06-11 03:27:20.788675
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPUX_Network():
        def __init__(self):
            self.mod = Mock()

    class Mock():
        def get_bin_path(self, cmd, required=False):
            return '/usr/bin/' + cmd

        def run_command(self, cmd, check_rc=True):
            if 'netstat -nr' in cmd:
                return 1, "default xxx.xxx.xxx.xxx\n", ""
            if 'netstat -niw' in cmd:
                return 1, "lanx xxx.xxx.xxx.xxx lanx xxx.xxx.xxx.xxx\n", ""

    HPUX_Network.module = Mock()

    hpu = HPUX_Network()
    fact_dic = hpu.get_interfaces_info()
    assert 'lanx' in fact_

# Generated at 2022-06-11 03:27:30.570501
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """unit test for method HPUXNetwork.get_interfaces_info()
    """

# Generated at 2022-06-11 03:27:43.007293
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork(module=None)
    fake_output = """
default		192.168.2.1	U	G	lan0
"""
    setattr(network.module, 'run_command', lambda *args: (0, fake_output, ''))
    assert network.get_default_interfaces() == {'default_interface': 'lan0',
                                                'default_gateway': '192.168.2.1'}


# Generated at 2022-06-11 03:27:43.986656
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:27:45.827020
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Unit test for constructor of class HPUXNetwork"""
    HPUXNetwork()



# Generated at 2022-06-11 03:27:48.122358
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = dict()
    network = HPUXNetwork(facts=facts)
    assert network.facts == dict()

# Generated at 2022-06-11 03:27:57.552739
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mod = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    mod.run_command = MagicMock(return_value=(0, "", ""))
    # Return values of methods get_default_interfaces and get_interfaces_info
    # are mocked to return predefined dictionaries
    net = HPUXNetwork(mod)
    net.get_default_interfaces = MagicMock(
        return_value={'default_interface': 'lan0',
                      'default_gateway': '172.16.1.1'})

# Generated at 2022-06-11 03:27:59.017789
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_network = HPUXNetwork(None)
    hpux_network.populate()

# Generated at 2022-06-11 03:28:02.137861
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXNetwork


# Generated at 2022-06-11 03:28:05.076346
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert isinstance(collector, NetworkCollector), \
        "HPUXNetworkCollector() should return instance of NetworkCollector"

# Generated at 2022-06-11 03:28:07.217864
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # Test for empty constructor
    hnet = HPUXNetwork()
    assert hnet.platform == 'HP-UX'


# Generated at 2022-06-11 03:28:11.019175
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module,
                                             collected_facts={})
    network = network_collector.collect()[0]
    assert network.populate()['interfaces'] == ['lan0']

# Generated at 2022-06-11 03:28:22.708461
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_network = HPUXNetwork(None)
    assert test_network.platform == 'HP-UX'


# Generated at 2022-06-11 03:28:25.352575
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork(dict())
    assert hpn.default_interface
    assert hpn.default_gateway
    assert hpn.interfaces

# Generated at 2022-06-11 03:28:27.300967
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()

    assert hpux_network.platform == 'HP-UX'



# Generated at 2022-06-11 03:28:31.062569
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """This function is to unit test the function
    get_default_interfaces of class HPUXNetwork"""
    HPUXNetwork_test = HPUXNetwork()
    default_interfaces = HPUXNetwork_test.get_default_interfaces()
    assert default_interfaces

# Generated at 2022-06-11 03:28:38.445205
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:28:47.432371
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    net = HPUXNetwork({}, module)

    # mock values of netstat output
    netstat_out = "<snip>\ndefault  192.168.1.1      UG        0 0        0 lan0"
    expected_interfaces = {'default_interface': 'lan0',
                           'default_gateway': '192.168.1.1'}

    module.run_command.return_value = (0, netstat_out, '')
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces == expected_interfaces



# Generated at 2022-06-11 03:28:57.236924
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """Test the method populate of class HPUXNetwork"""
    module = AnsibleModule(argument_spec=dict())

    # Create a instance of HPUXNetwork. We don't need to pass the class
    # as argument since it's already passed in the constructor
    net_collector = HPUXNetwork(module)
    net_collector.populate()

# Generated at 2022-06-11 03:29:03.651186
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():

    class Module:
        def __init__(self):
            self.run_command_args_list = []
            self.run_command_calls = 0

# Generated at 2022-06-11 03:29:14.602091
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class Module(object):
        """
        Fake module class for
        HPUXNetworkCollector.get_interfaces_info test.
        Mandatory to return a result in a Module class
        """
        def __init__(self, run_command_result):
            self.run_command_result = run_command_result

        def run_command(self, command):
            return self.run_command_result

    class Facts(object):
        """
        Fake Facts class for
        HPUXNetworkCollector.get_interfaces_info test.
        Mandatory to return a result in a Facts class
        """
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-11 03:29:23.592582
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Ensures that network facts are populated correctly on HP-UX
    """
    ansible_module = MagicMock()
    ansible_module.run_command = MagicMock()
    ansible_module.get_bin_path = MagicMock(return_value=True)

    netstat_out = (
        'Routing tables\n'
        '\n'
        'Internet:\n'
        'Destination        Gateway           Flags Refs Use Interface\n'
        'default            172.16.0.1        160    0    0 lan10\n'
        '172.16.0.0         127.0.0.1         UGH   0   11 lo0\n'
    )


# Generated at 2022-06-11 03:29:48.759632
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    run_module = {
        'path': '/',
        'commands': {
            'netstat': '/usr/bin/netstat'
        },
        'changed': False,
        '_ansible_no_log': False,
        '_ansible_module_name': 'setup'
    }
    from ansible.modules.system import setup
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    m = setup.SetupModule(run_module)
    results = m.run()
    facts = results['ansible_facts']
    iface = facts['ansible_default_ipv4']['interface']
    assert iface == 'lan0'

# Generated at 2022-06-11 03:29:56.063269
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_mod = HPUXNetwork()
    test_mod.module = type('', (object,), dict(run_command=lambda x: (0,
                             'lan0      link#1             UC             2      0  lan0', None)))()
    result = test_mod.get_interfaces_info()
    assert result['lan0']['ipv4']['address'] == '2'
    assert result['lan0']['ipv4']['network'] == '0'

# Generated at 2022-06-11 03:30:00.218838
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    from ansible.module_utils.facts.network.hpux import HPUXNetworkCollector
    collector = HPUXNetworkCollector()
    assert collector._fact_class is HPUXNetwork
    assert collector._platform is 'HP-UX'


# Generated at 2022-06-11 03:30:09.798949
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net = HPUXNetwork()
    assert net._platform == 'HP-UX'
    assert net._fact_class == HPUXNetwork

    dif = net.get_default_interfaces()
    assert dif['default_interface'] == 'lan0'
    assert dif['default_gateway'] == '144.69.60.1'

    ifs = net.get_interfaces_info()

    assert ifs['lan0']['device'] == 'lan0'
    assert ifs['lan0']['ipv4']['address'] == '144.69.60.242'
    assert ifs['lan0']['ipv4']['network'] == '144.69.60.0'
    assert ifs['lan0']['ipv4']['interface'] == 'lan0'
   

# Generated at 2022-06-11 03:30:16.868558
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    iface = "lan1000"
    netstat_output = []
    netstat_output.append(
        "Name  Mtu  Network  Address          Ipkts Ierrs    Opkts Oerrs"
    )
    netstat_output.append(
        "lan1000   1500  0x7ffa0a19  0x7ffa0a18      683     0       67     0"
    )
    netstat_output.append(
        "lan1000   1500  0x7f9515ff  0x7f9515fe      683     0       67     0"
    )


# Generated at 2022-06-11 03:30:19.453957
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class Module:
        def __init__(self):
            pass


# Generated at 2022-06-11 03:30:28.796671
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ModuleStub(object):
        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '/usr/bin/' + name

    module = ModuleStub()
    network = HPUXNetwork(module)


# Generated at 2022-06-11 03:30:37.541713
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeModule()
    hux_net = HPUXNetwork(module)
    hux_net.get_default_interfaces = MagicMock(return_value='lan0')

# Generated at 2022-06-11 03:30:44.818739
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModuleMock(
        argument_spec=dict(),
        supports_check_mode=True)

    # Mock the module
    network = HPUXNetwork(module)

    # Mock the netstat command output
    netstat_out = "default 192.168.1.1 UG 0 0 en0"

    # Mock the run_command method of the module to return our data
    module.run_command.return_value = 0, netstat_out, None

    assert network.get_default_interfaces() == {'default_interface': 'en0',
                                                'default_gateway':
                                                '192.168.1.1'}



# Generated at 2022-06-11 03:30:53.040943
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_info = HPUXNetwork()

# Generated at 2022-06-11 03:31:45.015483
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpx_facts = HPUXNetwork()
    hpx_facts()

# Generated at 2022-06-11 03:31:48.540327
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:31:49.718682
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """Construct one instance of class HPUXNetwork"""

    module = HPUXNetwork()
    assert module


# Generated at 2022-06-11 03:31:56.978791
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Load bare minimum module_utils
    module = AnsibleModule(argument_spec={})

    # Create an instance of HPUXNetwork
    h = HPUXNetwork(module)

    # Fake run_command.
    # Content of dummy_netstat_output is an excerpt of output
    # of the command "netstat -nr" on a HP-UX system.
    dummy_netstat_output = """
netstat: error opening /dev/eci/ip6.nd_cache: No such file or directory
Routing tables

Internet:
Destination        Gateway           Flags Refs Use  Interface
default            192.168.254.254   UG        1     0  lan1000
""".strip()

    h.module.run_command = lambda x: (0, dummy_netstat_output, None)

    # Call the tested method.


# Generated at 2022-06-11 03:32:01.240175
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = ''
        def get_bin_path(self, arg1, opt1=None):
            return '/usr/bin/netstat'
        def run_command(self, arg1):
            return (0, 'default ::ffff:192.168.1.254 UGHD0   1    5    0 lo0', '')

    class FakeHPUXNetwork(HPUXNetwork):
        def __init__(self):
            self.module = FakeAnsibleModule()

    hpux_network = FakeHPUXNetwork()
    default_interfaces_facts = hpux_network.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lo0'

# Generated at 2022-06-11 03:32:06.652998
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork({})
    network.module.run_command = lambda x: (0,
                                            'default/--/0.0.0.0/127.0.0.1/lan0/UH\ndefault/--/0.0.0.0/127.0.0.2/lan1/UH',
                                            '')
    out = network.get_default_interfaces()
    assert out == {'default_interface': 'lan0', 'default_gateway': '0.0.0.0'}



# Generated at 2022-06-11 03:32:13.274090
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HPUXNetwork(module=module)
    interfaces = network.get_interfaces_info()

    assert len(interfaces) == 1
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'
    assert 'lan0' in interfaces
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'
    assert 'address' in interfaces['lan0']['ipv4']
    assert 'device' in interfaces['lan0']


# Generated at 2022-06-11 03:32:14.279160
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpx = HPUXNetwork()
    assert hpx.platform == 'HP-UX'

# Generated at 2022-06-11 03:32:17.806596
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    network = HPUXNetwork(module)
    assert network.i.get_default_interfaces() == {u'default_interface': u'lan1',
                                                  u'default_gateway': u'192.0.2.1'}


# Generated at 2022-06-11 03:32:20.966515
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    network_facts = HPUXNetwork()
    default_interfaces = network_facts.get_default_interfaces()
    nb_of_keys = len(default_interfaces)
    assert (nb_of_keys == 2)
    assert (default_interfaces['default_interface'] == 'lan1')


# Generated at 2022-06-11 03:34:16.326612
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    print('Unit test for class HPUXNetwork')
    hpux_network = HPUXNetwork({})
    assert hpux_network.get_default_interfaces() == {'default_interface': None,
                                                     'default_gateway': None}
    assert hpux_network.get_interfaces_info() == {}
    assert hpux_network.platform == 'HP-UX'

# Generated at 2022-06-11 03:34:19.782493
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    network_facts = HPUXNetwork()
    rc, out, err = network_facts.module.run_command("/usr/bin/netstat -niw")
    interfaces_info = network_facts.get_interfaces_info()
    print(interfaces_info)

# Generated at 2022-06-11 03:34:21.017211
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpuxtest = HPUXNetwork(None)
    assert hpuxtest.platform == 'HP-UX'

# Generated at 2022-06-11 03:34:28.646959
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """Unit test for testing method get_interfaces_info of class HPUXNetwork
    """
    # This is the output of "/usr/bin/netstat -niw".

# Generated at 2022-06-11 03:34:30.313233
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    np = HPUXNetworkCollector()

    assert(np.platform == 'HP-UX')
    assert(np.fact_class == HPUXNetwork)

# Generated at 2022-06-11 03:34:34.509469
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """Unit test method HPUXNetwork.get_default_interfaces"""
    network = HPUXNetwork()
    defaults = network.get_default_interfaces()
    if defaults['default_interface'] is not None:
        print("\nDefault interface Name = %r" % defaults['default_interface'])
        print("Default interface Address = %r" % defaults['default_gateway'])
    else:
        print("\nNo default interface")



# Generated at 2022-06-11 03:34:35.638155
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    print(h.populate())

# Generated at 2022-06-11 03:34:43.590397
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule
    hpux_network = HPUXNetwork(module)
    network = hpux_network.populate()
    assert network['default_interface'] == 'lan0'
    assert network['default_gateway'] == '172.17.98.1'
    assert network['lan0']['device'] == 'lan0'
    assert network['lan0']['ipv4']['address'] == '172.17.98.254'
    assert network['lan0']['ipv4']['network'] == '172.17.98.0'
    assert network['lan0']['ipv4']['interface'] == 'lan0'
    assert network['lan0']['ipv4']['address'] == '172.17.98.254'

# Generated at 2022-06-11 03:34:46.488954
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    HPUXNetworks = HPUXNetwork()
    interfaces = HPUXNetworks.get_interfaces_info()
    assert interfaces
    assert interfaces['lan0']
    assert interfaces['lan0']['ipv4']
    assert interfaces['lan0']['ipv4']['address'] == 'xx.xx.xx.xx'



# Generated at 2022-06-11 03:34:47.364881
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hn = HPUXNetwork()
    assert hn.platform == 'HP-UX'