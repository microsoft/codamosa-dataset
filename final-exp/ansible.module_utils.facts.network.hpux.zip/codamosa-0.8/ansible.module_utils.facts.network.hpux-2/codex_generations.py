

# Generated at 2022-06-11 03:25:27.203170
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkModule()
    # Create an instance of HPUXNetwork
    hpux_net = HPUXNetwork(module)
    # Mock the module's run_command function to return out and err as
    # per our test case
    hpux_net.module.run_command = Mock(return_value=(0,
                                                     NETSTAT_OUTPUT_1,
                                                     ""))
    # Invoke the method 'populate' of class HPUXNetwork
    hpux_net.populate()
    # Assert that the value of default_interface and default_gateway are
    # as expected.
    assert hpux_net.default_interface == "lan0"
    assert hpux_net.default_gateway == "172.16.208.1"
    # Invoke the method 'populate' of class HPU

# Generated at 2022-06-11 03:25:39.247504
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network import network_collector
    from ansible.module_utils import basic

    mock_module = basic.AnsibleModule(argument_spec=dict())
    mock_module.run_command = lambda *_, **__: (0, 'default 10.0.2.2 UG 1 lan0', '')
    mock_network = HPUXNetwork(mock_module)

    expected_facts = {'default_interface': 'lan0',
                      'default_gateway': '10.0.2.2'}
    assert mock_network.get_default_interfaces() == expected_facts

    network_collector.NetworkCollector._module = mock_module

# Generated at 2022-06-11 03:25:43.138064
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    class_name = HPUXNetworkCollector._platform.lower() + NetworkCollector._class_separator + \
                 HPUXNetworkCollector._fact_class.__name__
    assert class_name == "hp-ux_hpuxnetwork"

# Generated at 2022-06-11 03:25:50.665962
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    network_facts.populate()
    facts = network_facts.get_facts()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.0.0.1'
    assert facts['interfaces'] == ['lan0', 'lan1']
    assert facts['lan0'] == {'device': 'lan0', 'ipv4': {'address': '10.0.0.2', 'network': '10.0.0.0', 'interface': 'lan0'}}

# Generated at 2022-06-11 03:26:02.194139
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # mocks
    class MockModule:
        def run_command(self, cmd):
            return 0, lines, None
    # init mocks
    netstat_path = "/usr/bin/netstat -niw"

# Generated at 2022-06-11 03:26:11.946172
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = ansible.module_utils.basic.AnsibleModule()
    mock_Utils = MagicMock()
    mocked_class = mock_Utils.run_command

# Generated at 2022-06-11 03:26:18.334192
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPUXNetwork_Mockup:
        def __init__(self):
            self.lan0_exists = True

        def run_command(self, cmd, check_rc=True):
            if self.lan0_exists:
                out = 'lan0   link#1    UP   1000baseSX <Full-duplex> \
      lan0      0x00000080        1500        00:0a:f5:9c:a1:18  \
      lan0      127.0.0.1   127.0.0.1         UH'
            else:
                out = ''

            return (0, out, "")

    class AnsibleModule_Mockup:
        def __init__(self):
            self.params = {}


# Generated at 2022-06-11 03:26:21.819001
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    result = hpux_network.populate()
    assert(result is not None)

# Generated at 2022-06-11 03:26:23.428562
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector(dict())



# Generated at 2022-06-11 03:26:32.843899
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    class MockModule(object):
        class HPModule(object):
            def get_bin_path(self, arg):
                return "/usr/bin/netstat"

            def run_command(self, arg):
                rc = 0

# Generated at 2022-06-11 03:26:41.948734
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpx_net_col = HPUXNetworkCollector()
    assert hpx_net_col._platform == 'HP-UX'
    assert hpx_net_col._fact_class.platform == 'HP-UX'
    assert hpx_net_col.collect() == {}
    assert hpx_net_col.delete_cache_file() == None

# Generated at 2022-06-11 03:26:42.786387
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:26:53.589315
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """This method unit tests the get_interfaces_info method of the
    HPUXNetwork class.
    """
    module = MockHP_UXModule()
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert 'lo0' in interfaces
    assert 'lan0' in interfaces['lan0']
    assert 'lo0' in interfaces['lo0']
    assert 'ipv4' in interfaces['lan0']
    assert 'ipv4' in interfaces['lo0']
    assert 'network' in interfaces['lan0']['ipv4']
    assert 'network' in interfaces['lo0']['ipv4']
    assert 'device' in interfaces['lan0']['ipv4']

# Generated at 2022-06-11 03:26:56.144143
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = HPUXNetworkCollector()
    assert facts.fact_class == HPUXNetwork
    assert facts.platform == 'HP-UX'


# Generated at 2022-06-11 03:27:01.073758
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    fact = HPUXNetwork(module)
    list_fact_class = [fact]
    for fact_class in list_fact_class:
        assert fact_class._platform == 'HP-UX'



# Generated at 2022-06-11 03:27:07.890349
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    host_name = "my_host"
    host_ip = "192.168.1.1"
    domain_name = "hp.com"
    interfaces = {"lan0": {"device": "lan0", "ipv4": {"address": "10.1.1.1",
                                                      "network": "10.1.1.1", "interface": "lan0"}}}
    default_gateway = "10.1.1.1"

    hpu = HPUXNetwork(host_name, domain_name, interfaces, host_ip, default_gateway)
    assert hpu.platform == "HP-UX"

# Generated at 2022-06-11 03:27:12.103295
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """Unit test for constructor of class HPUXNetworkCollector"""
    # Unit test for constructor of HPUXNetworkCollector class
    collector = HPUXNetworkCollector()
    assert collector._fact_class == HPUXNetwork
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-11 03:27:21.872228
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = NetworkCollector().get_network_facts()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.1.2.254'
    assert facts['interfaces'][0] == 'lan1'
    assert facts['interfaces'][1] == 'lan0'
    assert facts['lan1']['device'] == 'lan1'
    assert facts['lan0']['device'] == 'lan0'
    assert facts['lan0']['ipv4']['address'] == '10.1.2.18'
    assert facts['lan0']['ipv4']['network'] == '10.1.2.0'


# Generated at 2022-06-11 03:27:23.509363
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    test_net = HPUXNetwork(None)
    assert test_net.platform == 'HP-UX'

# Generated at 2022-06-11 03:27:32.818676
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mod = HPUXNetwork({})
    rc = mod.populate()

# Generated at 2022-06-11 03:27:48.690384
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector(None)
    # Assert that class of returned object is HPUXNetworkCollector
    assert isinstance(network_collector, HPUXNetworkCollector)
    # Assert that platform is HP-UX
    assert network_collector._platform == 'HP-UX'
    # Assert that fact class is HPUXNetwork
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:27:54.738028
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = (0, 'default         172.22.0.1      UG        0 0          0 lan1', '')
    network = HPUXNetwork(module_mock)
    expected_result = {'default_interface': 'lan1', 'default_gateway': '172.22.0.1'}
    assert network.get_default_interfaces() == expected_result

# Generated at 2022-06-11 03:28:05.601697
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # Create an instance of HPUXNetwork class
    network = HPUXNetwork()

    # Create a class for module and set value of module.run_command
    class Module:
        def __init__(self, run_command):
            self.run_command = run_command

    # Create an instance of module by calling constructor and passing
    # value for module.run_command. This will be used to create a value
    # for run_command argument in get_default_interfaces method.
    module = Module(run_command='/usr/bin/netstat -nr')

    # Set module as attribute of class HPUXNetwork
    network.module = module

    # Set value for default_interface and default_gateway in output of
    # module.run_command and call get_default_interfaces method. This will
    # return default_interface

# Generated at 2022-06-11 03:28:07.413640
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:28:09.343785
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_facts = HPUXNetworkCollector()
    assert network_facts
    assert network_facts._fact_class.platform == 'HP-UX'

# Generated at 2022-06-11 03:28:11.990131
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = {}
    network_facts = HPUXNetwork(facts, {}, {}, {}, {})
    assert network_facts.platform == 'HP-UX'

# Generated at 2022-06-11 03:28:22.708988
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_obj = HPUXNetworkCollector()
    test_obj.module.run_command = mock_run_command
    interfaces = test_obj.get_interfaces_info()
    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'address': '10.34.88.111',
                                           'network': '10.34.80.0',
                                           'interface': 'lan0',
                                           'address': '10.34.88.111'}}

# Generated at 2022-06-11 03:28:28.687216
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module = DummyAnsibleModule()
    network.module.run_command = DummyRunCommand()
    interfaces = network.get_default_interfaces()
    assert interfaces == {'default_interface': 'lan0',
                          'default_gateway': '0.0.0.0'}, \
        "Fail to get default interface for HP-UX"


# Generated at 2022-06-11 03:28:30.284529
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HP_network = HPUXNetworkCollector
    n = HP_network == NetworkCollector
    assert n is True

# Generated at 2022-06-11 03:28:37.064205
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False)

    m.run_command = lambda *args, **kwargs: (0, to_bytes('default 192.168.0.1 UG 1 100 lan0\n'), None)

    network = HPUXNetwork()
    network.module = m
    result = network.populate()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.0.1'



# Generated at 2022-06-11 03:28:56.600881
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:29:03.318378
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = Network()
    module.get_bin_path = lambda *_: '/usr/bin/netstat'

    module.run_command = lambda *args: (
        0, 'default 10.1.1.1 U 1 1234 lan0\n'
           'lan0 10.1.1.1 U 1 0 0 lan0', ''
    )
    module.__init__()

    hn = HPUXNetwork()
    hn.populate()
    assert hn.default_interface == 'lan0'
    assert hn.default_gateway == '10.1.1.1'
    assert hn.interfaces == ['lan0']

# Generated at 2022-06-11 03:29:07.812176
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_class = HPUXNetworkCollector()
    result = test_class.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.1.1.1'



# Generated at 2022-06-11 03:29:16.705463
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    iface_info = __import__('iface_info')
    iface_info.run_command = iface_info.mocked_run_command
    hp_ux_network = HPUXNetwork(iface_info)
    interfaces = hp_ux_network.get_interfaces_info()
    assert 'lo0' in interfaces
    assert 'lan0' in interfaces
    assert 'lan1' in interfaces
    assert interfaces['lan0']['ipv4']['address'] == '10.22.33.44'
    assert interfaces['lan1']['ipv4']['address'] == '10.251.4.4'


# Generated at 2022-06-11 03:29:24.809276
# Unit test for method get_interfaces_info of class HPUXNetwork

# Generated at 2022-06-11 03:29:28.616349
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    class_HPUXNetwork = HPUXNetwork
    class_HPUXNetwork.module = AnsibleModule({'ansible_facts': {'kernel': 'HP-UX'}})
    HPUXNetwork._interfaces = {}

# Generated at 2022-06-11 03:29:33.627518
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpu_ux import HPUXNetwork
    test_network = HPUXNetwork()
    interfaces = test_network.get_interfaces_info()
    for iface in interfaces:
        print ('%s: %s' % (iface, interfaces[iface]))


# Generated at 2022-06-11 03:29:38.235418
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    default_interfaces = net.get_default_interfaces()
    expected_interfaces = {'default_gateway': '192.168.1.1',
                           'default_interface': 'lan0'}
    assert  default_interfaces == expected_interfaces


# Generated at 2022-06-11 03:29:39.165780
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()


# Generated at 2022-06-11 03:29:47.019070
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Unit test method get_default_interfaces
    :return:
    """
    from ansible.module_utils.facts.network.hpu_x import HPUXNetwork
    hpux_network_instance = HPUXNetwork()
    assert isinstance(hpux_network_instance, HPUXNetwork)

    netstat_path = '/usr/bin/netstat'
    command = netstat_path + ' -nr'
    # input_output = {'rc': 0, 'stdout': 'default\t150.205.81.129\t150.205.81.1\tlan0\tUG\n', 'stderr': ''}

# Generated at 2022-06-11 03:30:34.084981
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = mock.Mock()
    netstat_path = '/usr/bin/netstat'
    module.get_bin_path.return_value = netstat_path
    module.run_command.return_value = 0, """
default   192.168.1.1 UGd   0        0  lan0
default   192.168.2.2 UGd   0        0  lan1
""", ''
    network = HPUXNetwork(module=module)
    default_interfaces = network.get_default_interfaces()
    assert 'default_interface' in default_interfaces.keys()
    assert 'default_gateway' in default_interfaces.keys()
    assert default_interfaces['default_interface'] == 'lan0'

# Generated at 2022-06-11 03:30:42.768256
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class HPUXNetworkMock(HPUXNetwork):
        def __init__(self):
            self.module = AnsibleModuleMock()

    class AnsibleModuleMock():
        def get_bin_path(self, bin_path):
            return '/usr/bin/netstat'

    class RunCommandMock():
        def __init__(self, out=None):
            self.out = out

        def run_command(self, cmd):
            if cmd == '/usr/bin/netstat -nr':
                return [0, self.out, '']
            else:
                return [1, '', 'Test Error']

    facts_obj = HPUXNetworkMock()
    facts_obj.module = RunCommandMock()

# Generated at 2022-06-11 03:30:47.729987
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    iface = HPUXNetwork()
    expected_default_interfaces = {
        'default_interface': 'lan0',
        'default_gateway': '192.168.1.1'
    }
    out = (0, 'default 192.168.1.1 UG lan0', '')
    actual_default_interfaces = iface.get_default_interfaces(out)
    assert actual_default_interfaces == expected_default_interfaces


# Generated at 2022-06-11 03:30:55.383275
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    set up hpuxnetwork object and test populate method
    """
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    module = HPUXNetwork()
    # Set up expected output
    expected_interfaces = ['lan0', 'lan1']
    expected_default_interface = 'lan0'

# Generated at 2022-06-11 03:30:56.850324
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():

    collector = HPUXNetworkCollector()
    assert collector._fact_class is HPUXNetwork
    assert collector._platform is 'HP-UX'

# Generated at 2022-06-11 03:31:00.993860
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = object()
    module.run_command = test_HPUXNetwork_mock_run_command

    net = HPUXNetwork(module)
    expected_results = {'default_interface': 'lan20',
                        'default_gateway': '142.99.1.1'}

    results = net.get_default_interfaces()
    assert results == expected_results



# Generated at 2022-06-11 03:31:05.033718
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = dict()

    # Test when netstat is missing
    module = MockModule(facts)
    module.get_bin_path.return_value = None
    hpuxn = HPUXNetwork(module)
    hpuxn.populate(facts)
    assert facts == {}



# Generated at 2022-06-11 03:31:13.568805
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = type('MockModule', (object,), {
        'run_command': lambda self, cmd: ([0, "lan0      2        4        0        0        lan0      ETHER_AUTO ",
                                                  "lan1      2        4        0        0        lan1      ETHER_AUTO ",
                                                  "lan2      2        4        0        0        lan2      ETHER_AUTO ",
                                                  "lan3      2        4        0        0        lan3      ETHER_AUTO "], "", "")
    })
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()

# Generated at 2022-06-11 03:31:19.870931
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_module.run_command = MagicMock(return_value=(0, "lan0      UP                 3000000  0   -   -   -   80000   80000  80000  lan0     127.0.0.1/32        UP                 -   0   -   -   -   -   -   -   lan0      127.0.0.1/32        UP                 -   0   -   -   -   -   -", ""))
    hpu = HPUXNetwork(test_module)
    interfaces = hpu.get_interfaces_info()

# Generated at 2022-06-11 03:31:22.019021
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    h = HPUXNetwork()
    k = {}
    k = h.populate()
    print(k)


# Generated at 2022-06-11 03:33:20.827758
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.__class__.__name__=='HPUXNetworkCollector'
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:33:29.159851
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    collected_facts = {}

    module = AnsibleModule({})

    # Mock defaults for module_utils functions
    module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    module.run_command = MagicMock(return_value=(0, 'default 127.0.0.0 UGSc 0 0 en0\nlan0 192.168.122.1 192.168.122.0 UGS 0 0 lan0\n', ''))

    network = HPUXNetwork()
    network.module = module

    network_facts = network.populate()

    assert(network_facts['default_gateway'] == '127.0.0.0')
    assert(network_facts['default_interface'] == 'en0')
    assert('interfaces' in network_facts)

# Generated at 2022-06-11 03:33:33.337882
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hpux_network = HPUXNetwork()
    interfaces = hpux_network.get_interfaces_info()
    assert 'lan0' in interfaces
    lan0 = interfaces['lan0']
    assert lan0['ipv4']['interface'] == 'lan0'
    assert lan0['ipv4']['address'] == '10.32.0.2'

# Generated at 2022-06-11 03:33:39.772202
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_network = HPUXNetwork(None)
    test_output = 'lan0: flags=842<BROADCAST,RUNNING,MULTICAST> mtu 1500 index 9'
    test_output = test_output + '\ninet 192.168.1.200 netmask ffffff00 broadcast 192.168.1.255'
    interfaces = test_network.get_interfaces_info(test_output)
    assert interfaces == {'lan0': {'ipv4': {'address': '192.168.1.200', 'network': '192.168.1.0',
                                            'interface': 'lan0'}, 'device': 'lan0'}}

# Generated at 2022-06-11 03:33:44.884553
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = NetworkModule(argument_spec=dict())
    module.run_command = Mock(return_value=(0, 'default 10.0.0.80 UG lan0 ', ''))
    hpux_network = HPUXNetwork(module=module)
    result = hpux_network.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.0.0.80'


# Generated at 2022-06-11 03:33:53.753517
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    # Create an instance of HPUXNetwork
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    # Check for the first interface
    assert_equal(interfaces.keys()[0], 'lan0')
    assert_equal(interfaces['lan0']['device'], 'lan0')
    assert_equal(interfaces['lan0']['ipv4']['address'], '192.168.1.10')
    assert_equal(interfaces['lan0']['ipv4']['network'], '192.168.1.0')
    assert_equal(interfaces['lan0']['ipv4']['interface'], 'lan0')

# Generated at 2022-06-11 03:34:02.192941
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    output = """
default  192.168.56.0        UG        1        0        lan0
192.168.56.0       192.168.56.255       U         1        0        lan0
127.0.0.0          127.255.255.255      U         0        0        lo0
    """
    net_module.run_command = MagicMock(return_value=(0, output, ''))
    network = HPUXNetwork(module=net_module)
    result = network.populate()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.56.0'



# Generated at 2022-06-11 03:34:10.587770
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkCollector
    module.run_command = lambda *args, **kwargs: (0, "default 127.0.0.1 UGSc 1 0 lan0\n"
                                                  "lan0 127.0.0.1 UHrI 5 0 lan0\n"
                                                  "lan0 127.0.0.1 UHrI 5 0 lan0", '')
    n = HPUXNetwork(module)
    result = n.populate()
    assert result['default_interface'] == "lan0"
    assert result['default_gateway'] == "127.0.0.1"
    assert result['interfaces'] == ['lan0']
    assert result['lan0']['ipv4']['address'] == "127.0.0.1"

# Generated at 2022-06-11 03:34:18.815824
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    default = {'default_interface': None, 'default_gateway': None}

    network = HPUXNetwork()

    network.module.run_command = lambda x, check_rc=True: (0, 'default      192.168.10.1      UG       0        0 lan0', '')
    result = network.get_default_interfaces()
    assert result == {'default_interface': 'lan0', 'default_gateway': '192.168.10.1'}

    network.module.run_command = lambda x, check_rc=True: (0, '', '')
    result = network.get_default_interfaces()
    assert result == default

    network.module.run_command = lambda x, check_rc=True: (1, '', '')
    result = network.get_default_interfaces

# Generated at 2022-06-11 03:34:26.025869
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    m = HPUXNetwork(module)
    facts = m.get_interfaces_info()

    print('Interface: %s' % m.default_interface)
    print('Address: %s' % facts[m.default_interface]['ipv4']['address'])
    print('Network: %s' % facts[m.default_interface]['ipv4']['network'])
    for fact in facts:
        print('Interface: %s' % fact)
        print('Address: %s' % facts[fact]['ipv4']['address'])
        print('Network: %s' % facts[fact]['ipv4']['network'])

