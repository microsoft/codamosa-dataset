

# Generated at 2022-06-11 03:25:27.556719
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeModule()
    hn = HPUXNetwork(module)
    hn._executable_exists = hn._executable_exists_mock
    hn._run_command = hn._run_command_mock

    interfaces = hn.get_interfaces_info()

# Generated at 2022-06-11 03:25:33.423743
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    facts = {}
    ansible_facts = {}
    module = AnsibleModule(argument_spec=dict())
    net = HPUXNetwork(module)
    ipv4s = net.populate(ansible_facts)
    assert ipv4s['default_interface'] == 'lan0'

# Generated at 2022-06-11 03:25:34.773982
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    network_collector.collect()

# Generated at 2022-06-11 03:25:36.594615
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'

# Generated at 2022-06-11 03:25:41.553349
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule('hpux')
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.0.0.1'


# Generated at 2022-06-11 03:25:51.278926
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Method populate of class HPUXNetwork return the following:
    - default_interface
    - interfaces (list of interface names)
    For each interface name, a dictionary containing the following:
    - device
    - ipv4 dictionary:
      - address
      - network
      - interface
      - address
    """
    # create a mock module
    module = MockAnsibleModule('HP-UX')

    # create an instance of HPUXNetwork
    network = HPUXNetwork(module)

    # apply populate method of HPUXNetwork class
    network_facts = network.populate()

    # check that the return value is correct
    assert 'default_interface' in network_facts.keys()
    assert 'default_gateway' in network_facts.keys()
    assert 'interfaces' in network_facts.keys()
   

# Generated at 2022-06-11 03:25:53.555159
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    n = HPUXNetwork()
    assert n is not None
    assert n.platform == 'HP-UX'


# Generated at 2022-06-11 03:26:00.032006
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    network_collector = HPUXNetworkCollector(module)
    network = HPUXNetwork(network_collector)
    default_interfaces = network.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '172.31.254.10'



# Generated at 2022-06-11 03:26:07.751124
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin'

    class TestNetwork(object):
        def __init__(self):
            self.module = TestModule()

    test_network = TestNetwork()
    facts = HPUXNetwork()
    facts.populate(test_network)

    assert(facts['default_interface'] == 'lan0')
    assert(facts['default_gateway'] == '172.27.1.1')


# Generated at 2022-06-11 03:26:10.212655
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc
    assert nc._platform == 'HP-UX'
    assert nc._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:26:25.986760
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():

    class MockModule:
        def __init__(self):
            self.run_command = MockModule.run_command

        def run_command(self, command):
            if command[-2:] == "ni":
                return 0, globals()['ni_out'], None
            else:
                return 0, globals()['netstat_out'], None


# Generated at 2022-06-11 03:26:27.689954
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork(dict())
    assert hpn.platform == 'HP-UX'



# Generated at 2022-06-11 03:26:36.642019
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {}
    out = """
    Name    Mtu   Network           Address        Ipkts Ierrs Idrop Opkts Oerrs Coll Drop
    lan0    1500  10.17.91.0        10.17.91.155   1570   0     0      1428   0     0    0
    lan0    1500  10.17.91.1        10.17.91.155   1570   0     0      1428   0     0    0
    lan1    1500  10.17.87.0        10.17.87.155   1188   0     0      2271   0     0    0
    """
    lines = out.splitlines()
    for line in lines:
        words = line.split()

# Generated at 2022-06-11 03:26:41.435371
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class module:
        def run_command(self, cmd):
            return (0, 'default 192.168.1.200 UGS lan0\n', '')

    class HPUXNetwork(object):
        def __init__(self):
            self.module = module()
            self.plugin_root = '/etc/ansible/facts.d'

    hpuxnetwork = HPUXNetwork()
    assert hpuxnetwork.get_default_interfaces() == {'default_gateway': '192.168.1.200', 'default_interface': 'lan0'}



# Generated at 2022-06-11 03:26:51.695142
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mod_args = {'ANSIBLE_MODULE_ARGS': {'gather_subset': '!all,!min'}}
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, **mod_args)
    network = HPUXNetwork(module=module)
    facts = network.populate()
    assert facts['default_interface'] == 'lan17'
    assert facts['default_gateway'] == '9.252.254.254'
    assert facts['lan17']['device'] == 'lan17'
    assert facts['lan17']['ipv4']['address'] == '9.252.215.233'
    assert facts['lan17']['ipv4']['network'] == '9.252.254.0'

# Generated at 2022-06-11 03:26:53.588719
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    data = HPUXNetwork.get_interfaces_info(None)
    assert len(data) > 0

# Generated at 2022-06-11 03:26:58.902819
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    obj = HPUXNetwork()
    assert obj.get_interfaces_info() == {'lan0': {'ipv4': {'network': '172.22.176.0',
                                                          'interface': 'lan0',
                                                          'address': '172.22.176.10'},
                                                'device': 'lan0'}}


# Generated at 2022-06-11 03:27:08.033874
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule:
        class MockFailJson():
            def __init__(self, out, rc=0, err=""):
                self.out = out
                self.rc = rc
                self.err = err

            def fail_json(self, **kwargs):
                raise Exception(self.out)

        def __init__(self):
            self.fail_json = self.MockFailJson

        def get_bin_path(self, app, required=False):
            return "/usr/bin/netstat"


# Generated at 2022-06-11 03:27:11.082659
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Test constructor of the class HPUXNetworkCollector
    """

    # Call constructor of the class
    HPUXNetworkCollector()

    # This is a class, so it will not return anything to test

# Generated at 2022-06-11 03:27:14.356606
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    assert hpux_network != None


# Generated at 2022-06-11 03:27:20.618183
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()

# Generated at 2022-06-11 03:27:30.409963
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """

    from ansible_collections.ansible.community.plugins.module_utils.facts.network.hpux import HPUXNetwork

    module = ansible_module_mock()
    objNetwork = HPUXNetwork(module)

    rc, out, err = module.run_command("/usr/bin/netstat -niw")
    rc2, out2, err2 = module.run_command("/usr/bin/netstat -nr")

    interfaces = objNetwork.get_interfaces_info()
    default_interfaces = objNetwork.get_default_interfaces()

    rc3, out3, err3 = module.run_command("/usr/bin/netstat -niw")
    rc4, out4, err4

# Generated at 2022-06-11 03:27:32.652846
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    network_collector_class = NetworkCollector
    network_class = Network
    assert isinstance(collector, network_collector_class)
    assert isinstance(collector, network_class)
    assert isinstance(collector, HPUXNetworkCollector)

# Generated at 2022-06-11 03:27:41.742001
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    expected_result = {
        'default_interface': 'lan1',
        'default_gateway': '192.168.13.1'
    }
    actual_result = network.get_default_interfaces()
    assert actual_result == expected_result, \
        "get_default_interfaces of class HPUXNetwork should return %s" \
        " but returned %s" % (expected_result, actual_result)



# Generated at 2022-06-11 03:27:52.475929
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    fact_class = HPUXNetwork()
    netstat_data = """
Name  Mtu   Network       Address         Ipkts Ierrs Opkts Oerrs  Coll
lan0     1500 1.2.3.4     1.2.3.4         432029     0  188527     0     0
lan1     1500 1.2.3.5     1.2.3.5           547     0      43     0     0
"""
    interfaces = fact_class.get_interfaces_info(netstat_data)
    assert 'lan0' in interfaces
    assert interfaces['lan0']['device'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '1.2.3.4'

# Generated at 2022-06-11 03:27:59.345093
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class test_module(object):

        def __init__(self):
            self.bin_path = '/usr/bin'

        def get_bin_path(self, name):
            if name == 'netstat':
                return self.bin_path + '/netstat'


# Generated at 2022-06-11 03:28:07.217480
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mod = HPUXNetwork()
    facts = {
        'default_gateway': '10.6.5.2',
        'default_interface': 'lan0',
        'interfaces': ['lan0'],
        'lan0': {
            'device': 'lan0',
            'ipv4': {
                'address': '10.6.5.1',
                'network': '10.6.5.0',
                'interface': 'lan0',
            },
        },
    }
    assert mod.populate() == facts

# Generated at 2022-06-11 03:28:14.873064
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    iface = interfaces['lan0']
    assert iface['device'] == 'lan0'
    assert iface['ipv4']['address'] == '172.24.66.140'
    assert iface['ipv4']['network'] == '172.24.66.128'
    assert iface['ipv4']['interface'] == 'lan0'
    assert iface['ipv4']['address'] == '172.24.66.140'

# Generated at 2022-06-11 03:28:25.271173
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hn = HPUXNetwork()
    # Create list of sample output from netstat -niw command

# Generated at 2022-06-11 03:28:28.117294
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    mycollector = HPUXNetworkCollector()
    assert mycollector._fact_class is HPUXNetwork
    assert mycollector._platform == 'HP-UX'


# Generated at 2022-06-11 03:28:50.278474
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    HPUXNetwork - Unit test of method populate
    """
    hpux_net = HPUXNetwork()
    default_interfaces = {'default_interface': 'lan8',
                          'default_gateway': '172.16.20.1'}
    hpux_net.netstat_path = '/bin/netstat'
    hpux_net.get_default_interfaces = lambda: default_interfaces
    interfaces = {'lan8': {'device': 'lan8',
                           'ipv4': {'address': '172.16.20.20'}}}
    hpux_net.get_interfaces_info = lambda: interfaces
    network_facts = hpux_net.populate()
    assert network_facts['default_interface'] == 'lan8'

# Generated at 2022-06-11 03:28:52.383895
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class.platform == 'HP-UX'

# Generated at 2022-06-11 03:28:59.457022
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork(dict(ANSIBLE_MODULE_ARGS={}), {})
    net.populate()
    assert net.default_interface == 'lan0' or net.default_interface == 'lan1'
    assert net.default_gateway == '10.65.1.1'
    assert net.interfaces[0] == 'lan0' or net.interfaces[0] == 'lan1'
    assert net.lan0.ipv4.network == '10.65.1.0'
    assert net.lan0.ipv4.address == '10.65.1.200'


# Generated at 2022-06-11 03:29:01.043058
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hinetwork = HPUXNetworkCollector()
    assert hinetwork is not None

# Generated at 2022-06-11 03:29:04.105582
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    """unit test for class HPUXNetwork"""
    network_facts = HPUXNetwork()
    assert network_facts.get_default_interfaces()
    assert network_facts.get_interfaces_info()

# Generated at 2022-06-11 03:29:12.689244
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    facts = {'default_gateway_ipv6': '', 'default_gateway': u'10.0.0.1', 'interfaces': ['lan0']}
    lan0 = {'ipv4': {'network': u'10.0.0.0', 'address': u'10.0.0.10', 'interface': 'lan0'}}
    facts['lan0'] = lan0
    facts['default_interface'] = u'lan0'
    module = object
    network = HPUXNetwork({}, module)
    network.populate(facts)
    assert facts == network.facts

# Generated at 2022-06-11 03:29:19.087721
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hpuxn = HPUXNetwork(module)
    hpuxn.populate()
    module.exit_json(changed=False, facts=module.params['_ansible_facts'])


# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 03:29:21.488609
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict()
    )
    network_facts = HPUXNetworkCollector(module).collect()
    assert network_facts['default_interface'] == \
        'lan7'

# Generated at 2022-06-11 03:29:21.995535
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-11 03:29:32.523542
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Test if interface lan0 has a correct IP address
    """
    class TestModule(object):
        def __init__(self):
            self.paths = {
                'netstat': '/usr/bin/netstat',
            }

        def get_bin_path(self, binary, opt_dirs=None):
            return self.paths[binary]

        def run_command(self, cmd, check_rc=True):
            command = '/usr/bin/netstat -niw 2>/dev/null'
            if cmd == command:
                return 0, TEST_OUTPUT, None
            else:
                assert False, "unexpected command: %s" % cmd



# Generated at 2022-06-11 03:29:59.226349
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork(module)
    network_facts.populate()
    assert module.exit_json.called
    result_args, _ = module.exit_json.call_args
    assert 'ansible_network_resources' in result_args['ansible_facts']


# Generated at 2022-06-11 03:30:04.882169
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    hpux_network = HPUXNetwork(module)
    hpux_network_facts = hpux_network.populate()
    assert hpux_network_facts['default_interface']
    assert hpux_network_facts['default_gateway']
    assert hpux_network_facts['interfaces']
    for interface in hpux_network_facts['interfaces']:
        assert hpux_network_facts[interface]

# Generated at 2022-06-11 03:30:07.903905
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector._fact_class == HPUXNetwork
    assert hpux_network_collector._platform == 'HP-UX'

# Generated at 2022-06-11 03:30:12.734259
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork()
    network_facts.populate()
    result = network_facts.get_all()
    print("facts: " + str(result))
    assert 'default_interface' in result
    assert 'default_gateway' in result
    assert 'interfaces' in result
    assert len(result['interfaces']) >= 1


# Generated at 2022-06-11 03:30:21.261819
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    net = HPUXNetwork()
    net.module = {'get_bin_path': lambda x: "/usr/bin/netstat"}
    net.get_default_interfaces = lambda: {'default_interface': 'lan0', 'default_gateway': '10.0.2.2'}
    net.get_interfaces_info = lambda: {'lan0': {'device': 'lan0', 'ipv4': {'address': '10.0.2.15'}}}

# Generated at 2022-06-11 03:30:31.159494
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    # The output for the command /usr/bin/netstat -niw is hardcoded as it is
    # not easy to mock the output of a command.


# Generated at 2022-06-11 03:30:32.376076
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork.platform == "HP-UX"


# Generated at 2022-06-11 03:30:41.153360
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    import os
    import unittest

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            class MockCMD(object):
                def __init__(self, out):
                    self.stdout = out

            wordlist = []

# Generated at 2022-06-11 03:30:45.581089
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    Network = HPUXNetwork()
    Network.module = FakeModule()
    interfaces_info = Network.get_interfaces_info()
    assert interfaces_info == {'lan0': {'device': 'lan0',
                                        'ipv4': {'address': '10.0.2.15',
                                                 'network': '10.0.2.0',
                                                 'interface': 'lan0'}}}



# Generated at 2022-06-11 03:30:52.587317
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, "default 00000000 00000000 00000000 000lan0", "")
    HPUXNetwork = HPUXNetworkCollector._fact_class(MockModule())

    default_interfaces_facts = HPUXNetwork.get_default_interfaces()
    default_interface = default_interfaces_facts['default_interface']
    default_gateway = default_interfaces_facts['default_gateway']
    assert default_interface == "lan0"
    assert default_gateway == "00000000"
    # assert False, "get_default_interfaces() should be tested"


# Generated at 2022-06-11 03:31:53.571343
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hpn = HPUXNetwork(module)
    result = hpn.get_default_interfaces()
    assert len(result) == 2
    assert result['default_gateway'] == '10.0.2.2'
    assert result['default_interface'] == 'lan0'



# Generated at 2022-06-11 03:31:55.203296
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'


# Generated at 2022-06-11 03:31:59.677184
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    Unit test for method populate of class HPUXNetwork
    """
    # Create a HPUXNetwork object
    hpux_network = HPUXNetwork()

    # Mock module and pass it as parameter to HPUXNetwork object
    hpux_network.module = MagicMock()

    # Mock netstat_path
    hpux_network.module.get_bin_path.return_value = (
        "/usr/bin/netstat")

    # Mock return values of method run_command
    out1 = "default 192.168.122.1"
    rc1, out1, err1 = (0, out1, "")
    out2 = "lan0 192.168.122.166"
    rc2, out2, err2 = (0, out2, "")
    hpux_network.module.run_command

# Generated at 2022-06-11 03:32:02.100794
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = HPUXNetworkCollector()
    assert network is not None

if __name__ == '__main__':
    test_HPUXNetworkCollector()

# Generated at 2022-06-11 03:32:03.409756
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net_collector = HPUXNetworkCollector()
    assert net_collector is not None

# Generated at 2022-06-11 03:32:07.645779
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    net = HPUXNetwork()
    net.module.run_command = MagicMock(return_value=(0, "default  224.0.0.0 UG      0       0        lan0", ""))
    result = net.get_default_interfaces()
    expected = {'default_interface': 'lan0', 'default_gateway': '224.0.0.0'}
    assert result == expected



# Generated at 2022-06-11 03:32:10.220348
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hn = HPUXNetworkCollector()

    assert(isinstance(hn, NetworkCollector))
    assert(isinstance(hn, HPUXNetworkCollector))


# Generated at 2022-06-11 03:32:17.205519
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Check if the method get_default_interfaces returns the right
    dictionary with values of default interface and gateway.
    """
    # run_command returns a tuple with 3 elements.
    # the first element is the return code, the second one is
    # stdout, and the last one is stderr.
    # if all is ok, the return code is 0.

# Generated at 2022-06-11 03:32:24.744924
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ModuleMock:
        @staticmethod
        def get_bin_path(bin_name, required=True):
            return bin_name

        @staticmethod
        def run_command(args, check_rc=True, close_fds=True, executable=None,
                        data=None, binary_data=False):
            return 0, "default 192.0.2.30 UGSc 4 0 0 lan0\ndefault 192.0.2.30 UGSc 4 0 0 lan1\n", ''

    class FactsNetworkMock:
        def __init__(self):
            self.module = ModuleMock()
            self.platform = 'HP-UX'

    network_facts = HPUXNetwork(FactsNetworkMock())
    default_interfaces = network_facts.get_default_interfaces()
    assert default

# Generated at 2022-06-11 03:32:31.145654
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule:
        def __init__(self, out):
            self.out = [out]
        def run_command(self, cmd):
            return 0, self.out[0], None
    net = HPUXNetwork(MockModule("""default 192.168.1.1 UG lan0"""))
    default_interfaces_facts = net.get_default_interfaces()
    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-11 03:34:30.291890
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpn = HPUXNetworkCollector()
    assert hpn._fact_class == HPUXNetwork
    assert hpn._platform == 'HP-UX'

# Generated at 2022-06-11 03:34:31.795767
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})

    netobj = HPUXNetwork(module)
    assert netobj


# Generated at 2022-06-11 03:34:33.020999
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:34:35.005298
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    assert HPUXNetwork().get_default_interfaces() == {'default_interface': 'lan0', 'default_gateway': '10.0.0.1'}


# Generated at 2022-06-11 03:34:42.013858
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_obj = HPUXNetwork()
    net_obj.module.get_bin_path = lambda x: '/usr/bin/netstat'
    net_obj.module.run_command = lambda x: (0, 'default 127.0.0.1 UGSc 127 0 0 lo0', '')
    collected_facts = {'default_network_facts': {}, 'interfaces_facts': {}}
    net_facts = net_obj.populate(collected_facts=collected_facts)
    assert net_facts['default_interface'] == 'lo0'
    assert net_facts['default_gateway'] == '127.0.0.1'
    assert net_facts['interfaces'] == ['lo0']



# Generated at 2022-06-11 03:34:46.871531
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = type('module', (object,), dict(run_command=lambda x, check_rc=True:
                                            (0,
                                             'default 192.168.12.254 UGSc  2 10 lan0',
                                             None)))

    HPUXNetwork.module = module
    network = HPUXNetwork()

    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.12.254'


# Generated at 2022-06-11 03:34:48.568561
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUX_col = HPUXNetworkCollector()
    assert HPUX_col._fact_class is HPUXNetwork
    assert HPUX_col._platform is 'HP-UX'

# Generated at 2022-06-11 03:34:55.228689
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule({})

    net_mock = MagicMock(return_value={'default_interface': 'lan0',
                                       'default_gateway': '172.16.1.1',
                                       'interfaces': ['lan0'],
                                       'lan0':
                                       {'ipv4':
                                        {'address': '172.16.1.198',
                                         'network': '172.16.1.0',
                                         'interface': 'lan0'}}})

    net_obj = HPUXNetwork(module)
    net_obj.get_default_interfaces = net_mock
    net_obj.get_interfaces_info = net_mock

    network_facts = net_obj.populate({'interesting_fact': 'interesting_fact'})

# Generated at 2022-06-11 03:34:56.541184
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Test a call to the get_device_name() method

# Generated at 2022-06-11 03:35:03.925763
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockNetworkModule:
        def __init__(self):
            self.params = {}
            self.run_command_calls = 0
            self.run_command_result = ['1', '2', '3']