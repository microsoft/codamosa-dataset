

# Generated at 2022-06-11 03:25:26.866944
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    expected = {'lan0': {'device': 'lan0',
                         'ipv4': {'address': '10.20.30.40',
                                  'interface': 'lan0',
                                  'network': '10.20.30.0'}},
                'lan1': {'device': 'lan1',
                         'ipv4': {'address': 'invalid',
                                  'interface': 'lan1',
                                  'network': 'invalid',
                                  }}}

# Generated at 2022-06-11 03:25:31.038566
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class is HPUXNetwork
    assert collector._platform == 'HP-UX'


# Generated at 2022-06-11 03:25:34.672102
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()

    assert network
    assert network.platform == 'HP-UX'
    assert network.get_default_interfaces() == {}
    assert network.get_interfaces_info() == {}
    assert network.populate() == {}

# Generated at 2022-06-11 03:25:42.071616
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    This method tests the correctness of the method
    get_interfaces_info of class HPUXNetwork
    """
    hpux_network = HPUXNetwork()
    network_info_dict = {'lan0': {'ipv4': {'address': '10.253.42.76',
                                           'network': '10.253.42.0',
                                           'interface': 'lan0'},
                                 'device': 'lan0'}}
    assert hpux_network.get_interfaces_info() == network_info_dict

# Generated at 2022-06-11 03:25:44.257711
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    n = HPUXNetwork(None)
    print(n.get_default_interfaces())



# Generated at 2022-06-11 03:25:48.399368
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    hpux_nw = HPUXNetwork(module)
    result = hpux_nw.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.1.1.1'



# Generated at 2022-06-11 03:25:54.541849
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    net = HPUXNetwork()
    interfaces = net.get_interfaces_info()
    assert interfaces['lan0']['ipv4']['interface'] == 'lan0'
    assert interfaces['lan0']['ipv4']['address'] == '192.168.0.2'
    assert interfaces['lan0']['ipv4']['network'] == '192.168.0.0'
    assert interfaces['lan1']['ipv4']['interface'] == 'lan1'
    assert interfaces['lan1']['ipv4']['address'] == '10.0.0.1'
    assert interfaces['lan1']['ipv4']['network'] == '10.0.0.0'

# Generated at 2022-06-11 03:26:01.309880
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    net_facts = HPUXNetwork()
    net_facts.module = MockModule()
    net_facts.module.run_command = Mock(return_value=(0, '', ''))
    facts = net_facts.populate()
    assert 'default_interface' in facts
    assert 'interfaces' in facts
    assert isinstance(facts['interfaces'], list)
    assert 'default_gateway' in facts



# Generated at 2022-06-11 03:26:11.198361
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    _module = "ansible.module_utils.facts.network.hpux.HPUXNetwork"
    _module_to_test = "ansible.module_utils.facts.network.hpux.HPUXNetwork"
    _msg = "Module imported: {0}, expected {1}".format(_module, _module_to_test)
    assert _module == _module_to_test, _msg

    # Arrange
    net = HPUXNetwork()
    net.netstat_path = '/usr/bin/netstat'
    net.module = FakeModule()

    # Act
    network_facts = net.populate()

    # Assert
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '172.16.255.2'
    assert network_

# Generated at 2022-06-11 03:26:17.996063
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    facts_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    facts = HPUXNetwork(facts_module)
    facts_module.run_command = MagicMock(return_value=[0, "/usr/bin/netstat:\n", ""])
    def_iface = facts.get_default_interfaces()
    assert def_iface == {}

# Generated at 2022-06-11 03:26:28.311071
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-11 03:26:37.176632
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self, rc, out):
            self.rc = rc
            self.out = out
            self.err = ''
        def run_command(self, cmd):
            return self.rc, self.out, self.err

    test_data = [
        ("/usr/bin/netstat -niw", dict(lan0='lan0', lan1='lan1')),
        ("/usr/bin/netstat -niw", dict()),
        ("/usr/bin/netstat -niw", {'ipv4': {'address': '192.0.2.1'}}),
    ]

    for out, interf_dict in test_data:
        my_obj = HPUXNetwork(MockModule(0, out))
        assert my_obj.get_inter

# Generated at 2022-06-11 03:26:39.174210
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector.platform == "HP-UX"
    assert collector._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:26:40.523308
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network_facts = HPUXNetwork()

    assert network_facts.platform == 'HP-UX'



# Generated at 2022-06-11 03:26:43.943609
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    hpn = HPUXNetwork(module)
    default_interfaces = hpn.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0',
                                  'default_gateway': '127.0.0.1'}



# Generated at 2022-06-11 03:26:47.465793
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector()
    assert hpux.platform == 'HP-UX'
    assert hpux._fact_class == HPUXNetwork
    assert hpux._platform == 'HP-UX'

# Generated at 2022-06-11 03:26:58.477039
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    ansible_module = basic.AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    collector_obj = collector.get_network_collector(ansible_module)
    network_obj = HPUXNetwork(ansible_module)

    collected_facts = {'kernel': 'HP-UX'}

# Generated at 2022-06-11 03:27:03.713605
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    network = HPUXNetwork()
    fake_interfaces = network.get_interfaces_info()

    assert fake_interfaces['lan0'] == {'ipv4':
                                       {'interface': 'lan0',
                                        'network': '192.168.0.0',
                                        'address': '192.168.0.1'},
                                        'device': 'lan0'}

# Generated at 2022-06-11 03:27:04.978227
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net = HPUXNetwork()
    assert net


# Generated at 2022-06-11 03:27:08.627518
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-11 03:27:20.120720
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu_net = HPUXNetwork(None)
    assert hpu_net is not None

# Generated at 2022-06-11 03:27:24.088119
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkCollector()
    network_data = HPUXNetwork(module)
    net_facts = network_data.populate()
    assert 'default_interface' in net_facts
    assert 'default_gateway' in net_facts
    assert 'interfaces' in net_facts


# Generated at 2022-06-11 03:27:32.989550
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class Module:
        def __init__(self):
            self.run_command_results = [(0, 'default: flags=89c<UP,BROADCAST,RUNNING,NOARP,PROMISC,SIOCP> mtu 1500\ndefault: flags=89c<UP,BROADCAST,RUNNING,NOARP,PROMISC,SIMPLEX,MULTICAST> mtu 1500\n', '')]

        def get_bin_path(self, arg, *args, **kwargs):
            return "/usr/bin"

        def run_command(self, command, *args, **kwargs):
            return self.run_command_results.pop(0)

    module = Module()

    hpux_network = HPUXNetwork()
    hpux_network.module = module

# Generated at 2022-06-11 03:27:45.227760
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    class AnsibleModule:
        def __init__(self):
            self.params = None

        def run_command(self, cmd):
            self.command = cmd
            out = ''
            out += 'default 192.168.1.1 USAGI UGHS 0 0 lan0\n'
            out += 'default 192.168.1.1 USAGI UGHS 0 0 lan1\n'
            return 0, out, ''

        def get_bin_path(self, cmd):
            return '/usr/bin/%s' % cmd

    a = AnsibleModule()
    b = HPUXNetwork(a)
    expected = {'default_interface': 'lan0', 'default_gateway': '192.168.1.1'}
    assert b.get_default_interfaces() == expected



# Generated at 2022-06-11 03:27:54.655224
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockedNetworkModule()
    hpuxnet = HPUXNetwork(module)
    hpuxnet.get_default_interfaces = MockedGetDefaultInterfaces()
    hpuxnet.get_interfaces_info = MockedGetInterfacesInfo()
    facts = hpuxnet.populate()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '192.168.1.1'
    assert facts['interface_lan0']['ipv4']['address'] == '192.168.1.15'
    assert facts['interface_lan1']['ipv4']['address'] == '192.168.1.16'



# Generated at 2022-06-11 03:28:02.332754
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import os
    import json
    import sys
    import ansible.module_utils.facts.network.hpux as hpux

    mynetwork = hpux.HPUXNetwork({})
    f = open(os.getcwd() + '/test/test_network.json')
    facts = json.loads(f.read())
    interfaces = {}
    for k, v in facts.items():
        if k.startswith('interface_'):
            interfaces[k] = v
    assert mynetwork.get_interfaces_info() == interfaces



# Generated at 2022-06-11 03:28:11.835663
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.basics import FactsNetworkBasics
    network_module = FactsNetworkBasics(module=None)
    network = HPUXNetwork(module=network_module)

    network_facts = {
        'default_interface': 'lan0',
        'default_gateway': '10.1.1.1',
        'interfaces': ['lan0'],
        'lan0': {
            'device': 'lan0',
            'ipv4': {
                'address': '10.1.1.2',
                'network': '10.1.1.0',
                'interface': 'lan0'
            }
        }
    }

    assert network_facts == network.populate()

# Generated at 2022-06-11 03:28:16.241311
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector.platform == 'HP-UX', "Test for platform attribute of class HPUXNetworkCollector has failed"
    assert HPUXNetworkCollector._fact_class == HPUXNetwork, "Test for fact_class attribute of class HPUXNetworkCollector has failed"
    assert HPUXNetworkCollector._platform == 'HP-UX', "Test for platform attribute of class HPUXNetworkCollector has failed"

test_HPUXNetworkCollector()


# Generated at 2022-06-11 03:28:19.077801
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    h = HPUXNetworkCollector()
    assert h._fact_class == HPUXNetwork
    assert h._platform == 'HP-UX'


# Generated at 2022-06-11 03:28:21.260622
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collect = HPUXNetworkCollector()
    assert collect._fact_class == HPUXNetwork
    assert collect._platform == 'HP-UX'

# Generated at 2022-06-11 03:28:44.900841
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == 'HP-UX'
    assert HPUXNetworkCollector._fact_class == HPUXNetwork
    assert HPUXNetworkCollector.__name__ == 'HPUXNetworkCollector'
    assert HPUXNetworkCollector.platform == 'HP-UX'


# Generated at 2022-06-11 03:28:49.127119
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()
    assert h.platform == 'HP-UX'
    assert h._platform == 'HP-UX'
    assert h.get_interfaces_info() != {}
    assert h.get_default_interfaces() != {}
    assert h.populate() != {}

# Generated at 2022-06-11 03:28:58.524881
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hn = HPUXNetwork()
    hn.module = MockModule()
    hn.module.run_command = mock_run_command
    interfaces = hn.get_interfaces_info()

# Generated at 2022-06-11 03:29:08.733019
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = {'lan0': {'ipv4': {'network': '127.0.0.0',
                                    'interface': 'lan0',
                                    'address': '127.0.0.1'},
                           'device': 'lan0'},
                  'lan1': {'ipv4': {'network': '127.0.0.0',
                                    'interface': 'lan1',
                                    'address': '127.0.0.1'},
                           'device': 'lan1'},
                  'lo0': {'ipv4': {'network': '127.0.0.0',
                                   'interface': 'lo0',
                                   'address': '127.0.0.1'},
                          'device': 'lo0'}
                  }
    net = HPUXNetwork

# Generated at 2022-06-11 03:29:09.674923
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork()


# Generated at 2022-06-11 03:29:11.825879
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    n = HPUXNetwork()
    assert n
    assert n.interfaces == []


# Generated at 2022-06-11 03:29:12.460322
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()

# Generated at 2022-06-11 03:29:14.977441
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert HPUXNetwork


if __name__ == '__main__':
    # Unit test for constructor of class HPUXNetwork
    test_HPUXNetwork()

# Generated at 2022-06-11 03:29:17.792851
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._fact_class == HPUXNetwork
    assert network_collector._platform == 'HP-UX'

# Generated at 2022-06-11 03:29:25.403401
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Test get_interfaces_info of HPUXNetwork
    """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.run_command = lambda *args, **kwargs: (0, to_bytes(
        '-------------------------------\n'
        'lan0     lan0           10.3.3.3\n'
        'lan1     lan1           10.3.3.4\n'
        'lan2     lan2           10.20.15.20\n'
        '-------------------------------\n'), b'')
    net = HPUXNetwork(module)
    interfaces_info = net.get_interfaces

# Generated at 2022-06-11 03:30:07.623552
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HPUXNetworkCollector(module=module)
    network_facts = network_collector.get_facts()
    assert 'default_interface' in network_facts

# Generated at 2022-06-11 03:30:15.566141
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = None
    fact_class = HPUXNetwork
    fact_class.module = module
    fact_class.get_interfaces_info = lambda x: {'lan0': {'device': 'lan0', 'ipv4': {'address': '10.104.182.30'}}}
    fact_class.get_default_interfaces = lambda x: {'default_interface': 'lan0'}
    expected_facts = {'default_interface': 'lan0',
                      'default_gateway': '',
                      'interfaces': ['lan0'],
                      'lan0': {'ipv4': {'address': '10.104.182.30'},
                               'device': 'lan0'}
                      }
    actual_facts = fact_class.populate()
    assert actual_facts == expected_facts

# Generated at 2022-06-11 03:30:17.349249
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network = NetworkCollector().get_network_collector()

    if network._platform != "HP-UX":
        raise AssertionError()

# Generated at 2022-06-11 03:30:20.296825
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:30:23.746590
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    interfaces = {'default_interface': 'lan0', 'default_gateway': '10.0.0.1'}
    network = HPUXNetwork()
    network_info = network.get_default_interfaces()
    assert network_info == interfaces


# Generated at 2022-06-11 03:30:28.961453
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    module = FakeModule()
    network = HPUXNetwork(module)
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces["default_interface"] == 'lan2'
    assert default_interfaces["default_gateway"] == '10.0.0.1'



# Generated at 2022-06-11 03:30:33.232311
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    hn = HPUXNetwork()
    ifaces = hn.get_interfaces_info()
    for iface in ifaces.keys():
        if ifaces[iface]['ipv4']['address'] != '127.0.0.1':
            return ifaces[iface]['ipv4']['address']
    return None

# Generated at 2022-06-11 03:30:40.571316
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    net = HPUXNetwork(module)
    out = '''default 10.137.1.1 UG 0 0
default 10.137.1.1 UG 0 0
'''
    rc = 0
    err = ''
    module.run_command = Mock(return_value=(rc, out, err))

    default_interfaces_facts = net.get_default_interfaces()

    assert default_interfaces_facts['default_interface'] == 'lan0'
    assert default_interfaces_facts['default_gateway'] == '10.137.1.1'


# Generated at 2022-06-11 03:30:41.567533
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module_mock = MockModule()
    network_instance = HPUXNetwork(module=module_mock)
    assert network_instance.platform == 'HP-UX'

# Generated at 2022-06-11 03:30:46.069852
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    network = HPUXNetwork(module)

    network_facts = network.populate()

    assert "default_interface" in network_facts
    assert "interfaces" in network_facts
    assert "default_gateway" in network_facts
    for interface in network_facts['interfaces']:
        assert "ipv4" in network_facts[interface]
        assert "device" in network_facts[interface]



# Generated at 2022-06-11 03:32:32.397422
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:32:33.805695
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert HPUXNetworkCollector._platform == collector.platform


# Generated at 2022-06-11 03:32:38.992911
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = MagicMock(return_value=(1, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    network_facts = HPUXNetwork.populate(module)
    assert network_facts['default_gateway'] == '10.10.10.1'
    assert network_facts['default_interface'] == 'lan1'
    assert network_facts['interfaces'] == ['lan1']
    assert network_facts['lan1']['ipv4']['address'] == '10.10.10.7'

# Generated at 2022-06-11 03:32:42.699128
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    '''
    get_interfaces_info() should return a dictionary of key-value pairs
    where key is the linux interface name, and the value is an ipv4 network
    dictionary.
    '''
    hn = HPUXNetwork()
    ifaces_info = hn.get_interfaces_info()
    assert (hn._platform == ifaces_info['lan0']['ipv4']['network'])
    assert (hn._platform == ifaces_info['lan1']['ipv4']['network'])



# Generated at 2022-06-11 03:32:48.641208
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ModuleStub:
        def run_command(self, cmd):
            output = ('default 192.168.0.1   UG   0 8       - lan0\n'
                      'default 0.0.0.0  UG   0   8    - lan0\n'
                      '192.168.0.0      0.0.0.0  U         0 8        - lan0\n')
            return (0, output, None)

    module = ModuleStub()
    hpux = HPUXNetwork(module)
    result = hpux.get_default_interfaces()

    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.0.1'



# Generated at 2022-06-11 03:32:56.574095
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """ Unit test for method populate of class HPUXNetwork. """
    ifaces = [{}, {}, {'default_interface': 'lan10', 'default_gateway': '192.168.1.1'}]
    netstat_path = ['/usr/bin/netstat']
    netstat_run_rc = [0, 1, 0]
    netstat_run_stdout = ['''default 10.10.10.10      UG        0 0          -
   default                   UG        0 0          -
   default 192.168.1.1       UG        0 0          lan10''', '', '''lan0   192.168.1.1        U  4          2       0         lan0
      lan10  192.168.1.2        U  4          2       0         lan10''']
    netstat

# Generated at 2022-06-11 03:32:59.702870
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector(None)
    assert hpux_network_collector.platform == HPUXNetworkCollector._platform
    assert hpux_network_collector.fact_class == HPUXNetworkCollector._fact_class

# Generated at 2022-06-11 03:33:02.160852
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux = HPUXNetwork(module)
    hpux.populate()



# Generated at 2022-06-11 03:33:04.315544
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    facts = HPUXNetworkCollector()
    assert facts._platform == 'HP-UX'
    assert facts._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:33:06.353354
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj._platform == 'HP-UX'
    assert obj._fact_class == HPUXNetwork
