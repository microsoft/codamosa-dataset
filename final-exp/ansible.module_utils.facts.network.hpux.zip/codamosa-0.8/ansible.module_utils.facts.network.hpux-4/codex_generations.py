

# Generated at 2022-06-11 03:25:24.758329
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    netstat_path = module.get_bin_path('netstat')
    if netstat_path is None:
        pytest.skip("netstat binary not found")

    net = HPUXNetwork(module)
    default_interfaces = net.get_default_interfaces()

    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '10.1.1.1'



# Generated at 2022-06-11 03:25:27.473970
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Test case for creating an object of HPUXNetworkCollector
    """
    hpnwc = HPUXNetworkCollector()
    assert hpnwc is not None


# Generated at 2022-06-11 03:25:30.158414
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpn = HPUXNetwork()
    assert hpn.platform == 'HP-UX'

# Generated at 2022-06-11 03:25:32.693448
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec={})
    hpuxnetwork = HPUXNetwork(module)
    assert hpuxnetwork

# Generated at 2022-06-11 03:25:40.854193
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    This is meant to be used to test the get_default_interfaces method of
    HPUXNetwork class.
    """
    mock_module = type('module', (object, ), {'run_command': lambda *args: (0, TEST_NETSTAT_OUTPUT_DEFAULT_INTERFACE, None)})
    hpuxNetwork = HPUXNetwork()
    hpuxNetwork.module = mock_module
    assert hpuxNetwork.get_default_interfaces() == {'default_interface': 'lan1', 'default_gateway': '10.10.10.1'}



# Generated at 2022-06-11 03:25:41.879484
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    h = HPUXNetwork()



# Generated at 2022-06-11 03:25:51.488083
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class HPUXNetwork
    """

# Generated at 2022-06-11 03:25:52.886351
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpu = HPUXNetwork()
    assert hpu.populate() is not None

# Generated at 2022-06-11 03:26:01.355393
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = Network()
    test_module.module = AnsibleModule(argument_spec={})
    test_module.module.run_command = MagicMock(return_value=(0,
                                                             'default 192.168.0.1 UG lan0',
                                                             ''))
    default_interfaces = test_module.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.0.1'



# Generated at 2022-06-11 03:26:03.550333
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    obj = HPUXNetworkCollector()
    assert obj.platform == "HP-UX"
    assert obj._fact_class == HPUXNetwork

# Generated at 2022-06-11 03:26:16.962092
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    HPUXNetwork.populate() Test
    """
    import sys
    import os
    import inspect
    import platform
    import argparse
    from ansible.module_utils.facts import ansible_facts

    mock_module = argparse.Namespace()

    mock_module.run_command = lambda _: (0, "lo0: ... lan2: ... lan1: ...", "")
    mock_module.get_bin_path = lambda _: "/usr/bin/netstat"

    mock_module.params = {}

    hpux_network = HPUXNetwork(mock_module)
    hpux_network.populate()

# Generated at 2022-06-11 03:26:20.075307
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpx_net = HPUXNetwork(dict())
    assert hpx_net.platform == 'HP-UX'
    assert hpx_net.get_default_interfaces() == {}
    assert hpx_net.get_interfaces_info() == {}

# Generated at 2022-06-11 03:26:28.729882
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():

    class AnsibleModuleMock:

        def run_command(self, path):
            rc = 0
            out = 'default 192.168.122.0 UGS lan0\n'
            err = ''
            return rc, out, err

        def get_bin_path(self, executable):
            return "/usr/bin/netstat"

    module = AnsibleModuleMock()
    network = HPUXNetwork(module)
    result = network.get_default_interfaces()
    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '192.168.122.0'



# Generated at 2022-06-11 03:26:34.086917
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class MockModule:
        def __init__(self):
            self.run_command = self.mock_run_command

        def mock_run_command(self, command):
            self.run_command_called_with = command
            return 0, "lan0      flags=1c43<UP,BROADCAST,RUNNING,MULTICAST>    mtu 1500", ''

    class MockNetwork:
        def __init__(self):
            self.module = MockModule()

    network = MockNetwork()
    interfaces = network.get_interfaces_info()
    assert interfaces == {'lan0': {'ipv4': {'network': '224.0.0.0', 'address': '192.168.1.1',
                                           'interface': 'lan0'}, 'device': 'lan0'}}




# Generated at 2022-06-11 03:26:41.362673
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, hpux_netstat_niw_output, ''))
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert interfaces['lan0'] == {
        'device': 'lan0',
        'ipv4': {
            'address': '192.168.0.10',
            'network': '192.168.0.0',
            'interface': 'lan0',
            'address': '192.168.0.10'
       }
    }

# Generated at 2022-06-11 03:26:46.603808
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "lan0  lan     0  0   0   10      0      0      0  ENABLED UP  10.0.2.15", "")
    fact = HPUXNetwork(module)
    interfaces = fact.get_interfaces_info()
    assert interfaces.get('lan0')['ipv4']['network'] == '10.0.2.0'
    assert interfaces.get('lan0')['ipv4']['address'] == '10.0.2.15'


# Generated at 2022-06-11 03:26:53.084466
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork()
    network.module.run_command = mock_run_command
    network.get_default_interfaces()
    # Note: netstat output for HP-UX will be in the following format:
    # default default_gateway UGSc 0 0 lan9 lan9 UH
    assert network.default_gateway == 'default_gateway'
    assert network.default_interface == 'lan9'


# Generated at 2022-06-11 03:26:57.694240
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = NetworkCollector().get_module(None, None)
    iface = HPUXNetwork(module=module)
    default_interfaces = iface.get_default_interfaces()

    # Test if at least the default interface is there
    assert ('default_interface' in default_interfaces)



# Generated at 2022-06-11 03:27:07.060896
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    collector._set_module(module)

    interfaces = HPUXNetwork.get_interfaces_info(
        {'run_command': basic.AnsibleModule.run_command}, module)

# Generated at 2022-06-11 03:27:17.578813
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test to check the result of get_interfaces_info
    """
    interfaces = {}
    interfaces = HPUXNetwork.get_interfaces_info()

# Generated at 2022-06-11 03:27:32.578018
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, "default 127.0.0.1 UGSc 1 0 lan0", ""))
    network = HPUXNetwork(module)
    result = network.get_default_interfaces()
    assert result == {'default_interface': 'lan0', 'default_gateway': '127.0.0.1'}


# Generated at 2022-06-11 03:27:35.030078
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork({'module_setup': True})
    assert network

# Generated at 2022-06-11 03:27:47.074015
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class HPUXModule:
        def __init__(self):
            class HPUXCommandResult:
                def __init__(self):
                    self.rc = 0
                    self.stdout = """
                Name  Mtu  Network       Address         Ipkts Ierrs Opkts Oerrs Coll
                lan1  1500  9.0.0.0       9.0.5.5       14430     0  13688     0    0
                """
                    self.stderr = ""

            self.run_command = lambda cmd: HPUXCommandResult()

        def get_bin_path(self, arg):
            return None

    class HPUXNetworkClass:
        def __init__(self):
            self.module = HPUXModule()

    instance = HPUXNetworkClass()

# Generated at 2022-06-11 03:27:48.593818
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    instance = HPUXNetworkCollector()
    assert isinstance(instance, NetworkCollector)

# Generated at 2022-06-11 03:27:57.840742
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    ansible_module = MockAnsibleModule()

    expected_interfaces = {}
    expected_interfaces['lan0'] = {'ipv4': {'address': '10.0.0.1/24',
                                            'network': '10.0.0.0',
                                            'interface': 'lan0'},
                                   'device': 'lan0'}
    expected_interfaces['lan1'] = {'ipv4': {'address': '10.0.0.2/24',
                                            'network': '10.0.0.0',
                                            'interface': 'lan1'},
                                   'device': 'lan1'}

# Generated at 2022-06-11 03:28:01.677229
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    import ansible.module_utils.facts.network
    m = ansible.module_utils.facts.network.NetworkModule()
    net = HPUXNetwork(m)
    output_netstat = net.get_default_interfaces()
    return output_netstat


# Generated at 2022-06-11 03:28:06.838232
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network_facts = HPUXNetwork()
    interfaces = network_facts.get_interfaces_info()
    for iface in interfaces:
        assert isinstance(iface, str)

    default_interfaces = network_facts.get_default_interfaces()
    for k in default_interfaces.keys():
        assert isinstance(k, str)

# Generated at 2022-06-11 03:28:11.020542
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list'),
            'gather_network_resources': dict(default=[], type='list')
        }
    )
    result = HPUXNetwork(module)
    assert result is not None

# Generated at 2022-06-11 03:28:17.718182
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # I set up the fixtures for the test:
    class Module(object):
        def get_bin_path(self, arg):
            return "/usr/bin"
        run_command = get_default_interfaces(self)
        run_command = get_interfaces_info(self)
        self.module = Module()

    network_collector = HPUXNetworkCollector(self.module)
    network_facts_gathered = network_collector.collect()
    assert network_facts_gathered['default_gateway'] == '1.1.1.1'
    assert network_facts_gathered['ipv4']['network'] == '1.1.1.0'
    assert network_facts_gathered['ipv4']['interface'] == 'lan1'

# Generated at 2022-06-11 03:28:23.864361
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """Unit test for method get_default_interfaces of class HPUXNetwork."""
    hpux_network = HPUXNetwork()
    default_interfaces = hpux_network.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '192.168.1.1'


# Generated at 2022-06-11 03:28:50.862801
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    ansible_module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))
    ansible_module.params['gather_subset'] = ['network']

    net = HPUXNetwork(ansible_module)
    result = net.populate()

    result_interface=result['default_interface']
    print(result_interface)


# Generated at 2022-06-11 03:28:53.342412
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector._platform == "HP-UX"
    assert HPUXNetworkCollector._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:28:56.427037
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # This should raise an exception:
    try:
        HPUXNetworkCollector()
    except Exception as e:
        assert(e.args[0] == 'NetworkCollector must be instantiated via NetworkCollector.factory()')

# Generated at 2022-06-11 03:29:01.063438
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    result = {}
    network = HPUXNetwork()
    default_interfaces = network.get_default_interfaces()
    if default_interfaces.get('default_interface') is None:
        result['failed'] = True
        result['msg'] = "Reason: netstat -nr does not return a default route"
    else:
        result['failed'] = False
        result['msg'] = "Success, default interface and gateway collected"
    return result



# Generated at 2022-06-11 03:29:03.058710
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():

    hpn = HPUXNetwork()
    assert hpn.get_default_interfaces() == {}



# Generated at 2022-06-11 03:29:08.645927
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    a = HPUXNetwork(None)
    result = a.populate()
    for k in result:
        print(k, ":", result[k])

if __name__ == '__main__':
    test_HPUXNetwork_populate()

# Generated at 2022-06-11 03:29:10.944760
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_net = HPUXNetwork()
    assert hpux_net.populate()['interfaces'] == ['lan0']



# Generated at 2022-06-11 03:29:11.535239
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    NetworkCollector()

# Generated at 2022-06-11 03:29:18.793338
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    expected_results = {'default_gateway': '10.0.0.1',
                        'default_interface': 'lan0'}
    mock_module = Mock(name='mock_module')
    mock_module.run_command.return_value = 0, \
        "default 10.0.0.1 UG 0 0 lan0", ""
    network_facts = HPUXNetwork(mock_module)
    results = network_facts.get_default_interfaces()
    assert expected_results == results


# Generated at 2022-06-11 03:29:21.526712
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hn = HPUXNetwork({})
    interfaces = hn.get_interfaces_info()
    assert 'lan0' in interfaces.keys()

# Generated at 2022-06-11 03:29:43.108553
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    pass

# Generated at 2022-06-11 03:29:47.113957
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = FakeModule()
    net_info = HPUXNetwork(module)
    assert net_info.platform == 'HP-UX'

    assert net_info.get_default_interfaces() is None

    assert net_info.get_interfaces_info() is None



# Generated at 2022-06-11 03:29:56.373581
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class ModuleStub(object):
        def __init__(self, result):
            self.result = result

        def run_command(self, cmd):
            return self.result
    result = (0, out, '')
    out = '''Kernel IP routing table
default 172.17.10.1 UG 1 0 en0
'''
    module_stub = ModuleStub(result)
    hpux_network = HPUXNetwork(module_stub)
    interfaces = hpux_network.get_default_interfaces()

    assert interfaces['default_interface'] == 'en0'
    assert interfaces['default_gateway'] == '172.17.10.1'


# Generated at 2022-06-11 03:30:06.393096
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    m = HPUXNetwork({})

    # Create the mock module output for netstat -rn
    netstat_rn = ("KRF default 192.168.1.1 UGS 0 0 0 lan1\n")

    # Mock the module.run_command function
    m.module.run_command = Mock(return_value=(0, netstat_rn, ""))

    # Now that we have mocked the module.run_command, calling
    # get_default_interfaces will call the mocked function.
    default_interfaces = m.get_default_interfaces()

    # Assert that the results are as expected
    assert default_interfaces['default_interface'] == 'lan1'
    assert default_interfaces['default_gateway'] == '192.168.1.1'

# Generated at 2022-06-11 03:30:10.457581
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = DummyModule()
    network = HPUXNetwork(module)

    network.get_interfaces_info()

    assert module.run_command.call_count == 1
    args, kwargs = module.run_command.call_args
    assert args[0] == "/usr/bin/netstat -niw"


# Generated at 2022-06-11 03:30:17.286122
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mod = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )
    nin = HPUXNetwork(mod)
    nin.populate()

# Generated at 2022-06-11 03:30:23.782579
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    test_class = HPUXNetwork({})
    interfaces = test_class.get_interfaces_info()
    # A device name starts with lan
    assert(interfaces.keys()[0][:3] == 'lan')
    # There is an address
    assert(interfaces[interfaces.keys()[0]]['ipv4']['address'] != "")
    # There is a network
    assert(interfaces[interfaces.keys()[0]]['ipv4']['network'] != "")



# Generated at 2022-06-11 03:30:27.184106
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    n = HPUXNetwork()
    assert n.platform == 'HP-UX'

#Unit test for constructor of class HPUXNetworkCollector

# Generated at 2022-06-11 03:30:30.258727
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_class = HPUXNetworkCollector._fact_class
    assert fact_class.platform == "HP-UX"
    assert issubclass(fact_class, Network)
    assert issubclass(HPUXNetworkCollector, NetworkCollector)

# Generated at 2022-06-11 03:30:39.201028
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = MockModule()
    netstat_path = '/usr/bin/netstat'
    net_path = '/usr/bin/net'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifup_path = '/sbin/ifup'
    # return_value stores the return value of the mocked function

# Generated at 2022-06-11 03:31:35.278459
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    # input - no input required
    # expected output
    expected = {'default_gateway': '10.2.x.x', 'default_interface': 'lan8'}

    # initialize object to test
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)

    # test method
    result = network.get_default_interfaces()

    # check result
    assert result == expected


# Generated at 2022-06-11 03:31:41.595368
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class TestModule(object):
        def __init__(self):
            self._command_result = None

        def run_command(self, command):
            self._command = command
            self._command_result = [0, 'lan0: flags=8c43<UP,BROADCAST,RUNNING,MULTICAST,DHCP> mtu 1500 index 1 inet 192.168.1.10 netmask fffffc00 broadcast 192.168.3.255lan1: flags=8c02<BROADCAST,MULTICAST,UP> mtu 1500 index 2 inet 0.0.0.0 netmask 0 broadcast 0', '']
            return self._command_result

        def get_bin_path(self, _):
            return '/usr/bin/netstat'

    test_module = TestModule()
    n = HPU

# Generated at 2022-06-11 03:31:43.832916
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    instance = HPUXNetworkCollector()
    assert instance is not None
    assert instance._fact_class is not None
    assert instance._platform == 'HP-UX'

# Generated at 2022-06-11 03:31:46.648101
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModuleMock(
        params={
            'gather_subset': [
                'all',
            ],
            'gather_network_resources': [
                'all',
            ],
        },
        check_mode=False,
    )
    network_collector = HPUXNetworkCollector(module)
    network = HPUXNetwork(network_collector)
    network.populate()



# Generated at 2022-06-11 03:31:52.547823
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    '''Unit test for method get_interfaces_info of class HPUXNetwork.
    '''
    import os.path
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../../'))
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork

    network_obj = HPUXNetwork(None)

    # Returns dictionary of expected interfaces

# Generated at 2022-06-11 03:31:59.291409
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hn = HPUXNetwork()
    hn.module = DummyAnsibleModule()
    facts = hn.populate()
    assert 'default_interface' in facts
    assert 'interfaces' in facts
    assert 'lan8' in facts
    assert 'lan9' in facts
    assert 'lan' in facts['lan8']['device']
    assert 'lan' in facts['lan9']['device']
    assert facts['default_interface'] == 'lan8'
    assert facts['lan8']['ipv4']['address'] == '10.0.2.15'
    assert facts['lan8']['ipv4']['network'] == '10.0.2.0'

# Generated at 2022-06-11 03:32:05.736670
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = MockModule({'run_command': run_command})
    hpn = HPUXNetwork(module)
    res = hpn.get_interfaces_info()
    assert 'lan0' in res
    assert res['lan0']['device'] == 'lan0'
    assert res['lan0']['ipv4']['address'] == '192.168.0.10'
    assert res['lan0']['ipv4']['network'] == '192.168.0.0'
    assert res['lan0']['ipv4']['interface'] == 'lan0'


# Generated at 2022-06-11 03:32:07.800517
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_class = HPUXNetworkCollector._fact_class
    assert fact_class.platform == 'HP-UX'
    assert fact_class(dict(), dict())._platform == 'HP-UX'

# Generated at 2022-06-11 03:32:09.786447
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    collector = HPUXNetworkCollector()
    assert collector
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-11 03:32:12.653881
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    """
    This test will only work on HP-UX machine.
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    if not module.check_mode:
        network_facts = HPUXNetwork().populate()

# Generated at 2022-06-11 03:34:24.018009
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = FakeModule()
    network = HPUXNetwork(module)

    # Sample output of command /usr/bin/netstat -niw

# Generated at 2022-06-11 03:34:25.477945
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux = HPUXNetwork()
    assert hpux.platform == 'HP-UX'
    hpux.populate()

# Generated at 2022-06-11 03:34:26.826589
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HPUXNetwork().populate()
    module.exit_json(ansible_facts={'ansible_network_resources': network_facts})



# Generated at 2022-06-11 03:34:29.158879
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec=dict())
    hpux_network = HPUXNetwork(module)
    network_facts = hpux_network.populate()
    assert network_facts is not None

# Generated at 2022-06-11 03:34:31.795885
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hpux_network_ins = HPUXNetwork(module)

    assert hpux_network_ins.platform == 'HP-UX'



# Generated at 2022-06-11 03:34:39.375398
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, "", "")
    netstat_output = '''
lan8: flags=f10008d4e5,c0<UP,BROADCAST,NOTRAILERS,RUNNING,MULTICAST,NOARP,SIMPLEX,SLAVE,LINK0,CRCSTRIP>
        inet 10.10.10.1 mask ffffff00 broadcast 10.10.10.255
        ether 0:18:c0:d7:2e:f3
'''
    mock_module.run_command.return_value = (0, netstat_output, "")
    HPNetwork = HPUXNetwork(mock_module)
    interfaces = HPNetwork.get_interfaces_info()

# Generated at 2022-06-11 03:34:46.373896
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    class TestModule:
        @staticmethod
        def run_command(arg):
            if arg == "/usr/bin/netstat -niw":
                return (0,
                        'Name      Mtu   Network     Address     Ipkts       '
                        'Ierrs  Opkts       Oerrs  Coll   Queue\n'
                        'lan0   1500    10.100.1.0   10.100.1.51  10456541    '
                        '0     7268915        0       0       0\n'
                        'lan1   1500    10.100.2.0   10.100.2.51  10456541    '
                        '0     7268915        0       0       0\n',
                        '')
            else:
                return (1, '', '')


# Generated at 2022-06-11 03:34:48.406788
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector()
    assert hpux._platform == 'HP-UX'
    assert hpux._fact_class == HPUXNetwork
    assert hpux._options_name == 'ansible_network'


# Generated at 2022-06-11 03:34:51.403593
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = FakeModule()
    net_provider = HPUXNetwork(module)
    default_interfaces = net_provider.get_default_interfaces()
    assert default_interfaces['default_gateway'] == '172.16.78.1'
    assert default_interfaces['default_interface'] == 'lan1'



# Generated at 2022-06-11 03:34:52.056220
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()