

# Generated at 2022-06-11 03:25:26.982325
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    fake_module = FakeAnsibleModule()
    fake_network = HPUXNetwork(module=fake_module)
    collected_facts = {}
    collected_facts['default_interface'] = 'lan0'
    collected_facts['default_gateway'] = '10.1.1.1'
    collected_facts['interfaces'] = ['lan0']
    collected_facts['lan0'] = {'ipv4': {'network': '10.1.1.0', 'address': '10.1.1.2', 'interface': 'lan0'}}
    network_facts = fake_network.populate(collected_facts=collected_facts)
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.1.1.1'
    assert network

# Generated at 2022-06-11 03:25:30.357918
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux_network_collector = HPUXNetworkCollector()
    assert hpux_network_collector.platform == 'HP-UX'

# Generated at 2022-06-11 03:25:36.410013
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert 'lan1500' in interfaces
    assert interfaces['lan1500']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lan1500']['ipv4']['network'] == '127.0.0.0'


# Generated at 2022-06-11 03:25:47.502731
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule(object):
        """
        Mock module used for unit testing
        """
        def __init__(self):
            self.run_command = self.mock_run_command

        def mock_run_command(self, cmd):
            """
            Mock run_command method to return test output
            """
            if cmd == "/usr/bin/netstat -nr":
                file_path = "unit/module_utils/facts/network/HP-UX/files/netstat"
                data = open(file_path).read()
                return (0, data, "")
            return (0, "", "")

    module = MockModule()
    network = HPUXNetwork(module)
    interfaces = network.get_default_interfaces()
    assert interfaces['default_interface'] == "lan0"

# Generated at 2022-06-11 03:25:48.855626
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """
    Test the constructor of HPUXNetworkCollector
    """
    hpux_nwc = HPUXNetworkCollector()
    assert hpux_nwc

# Generated at 2022-06-11 03:25:52.742360
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = MockModule()
    net = HPUXNetwork(module)
    default_interfaces = net.get_default_interfaces()
    assert default_interfaces == {'default_interface': 'lan0',
                                  'default_gateway': '10.14.64.1'}


# Generated at 2022-06-11 03:25:55.924865
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(argument_spec=dict())
    network = HPUXNetwork(module)
    assert network.platform == 'HP-UX'



# Generated at 2022-06-11 03:26:02.569707
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    network = HPUXNetwork()
    facts = network.populate()
    assert 'default_interface' in facts
    assert len(facts['default_interface']) > 0
    assert 'default_gateway' in facts
    assert len(facts['default_gateway']) > 0
    assert 'interfaces' in facts
    assert 'ipv4' in facts['lan1000']
    assert facts['lan1000']['ipv4']['interface'] == 'lan1000'

# Generated at 2022-06-11 03:26:03.900289
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork()
    assert network.platform == 'HP-UX'

# Generated at 2022-06-11 03:26:13.411368
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_module.run_command.return_value = (0, MOCK_ROUTING_TABLE, '')
    test_network = HPUXNetwork(test_module)
    network_facts = test_network.populate()
    assert network_facts['default_gateway'] == '192.168.1.1'
    assert network_facts['default_interface'] == 'lan4'
    assert network_facts['interfaces'] == ['lan4']
    assert network_facts['lan4']['ipv4']['address'] == '192.168.1.2'

# Generated at 2022-06-11 03:26:29.338535
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = Network()
    module.run_command = run_command_mock
    # check if the facts cannot be collected
    netstat_path = module.get_bin_path('netstat')
    if netstat_path is None:
        pass
    else:
        network_facts = module.populate()
        interfaces = network_facts['interfaces']
        assert 'lan0' in interfaces
        assert network_facts['lan0'] is not None
        ipv4 = network_facts['lan0']['ipv4']
        assert ipv4['address'] == '192.168.1.9'
        assert ipv4['network'] == '192.168.1.0'
        assert ipv4['interface'] == 'lan0'
        assert network_facts['default_interface'] == 'lan0'
        assert network

# Generated at 2022-06-11 03:26:37.802182
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = MockModule()
    network = HPUXNetwork(module=module)
    network.get_default_interfaces = Mock(return_value={'default_interface': 'lan11',
                                                        'default_gateway': '10.0.0.1'})
    network.get_interfaces_info = Mock(return_value={'lan11': {'ipv4': {'address': '10.0.0.12',
                                                                         'network': '10.0.0.0',
                                                                         'interface': 'lan11'}},
                                                     'lan0': {'ipv4': {'address': '10.0.0.1',
                                                                        'network': '10.0.0.0',
                                                                        'interface': 'lan0'}}})
    network.pop

# Generated at 2022-06-11 03:26:39.579549
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    net = HPUXNetworkCollector()
    assert net.__class__.__name__ == 'HPUXNetworkCollector'


# Generated at 2022-06-11 03:26:46.787866
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    # Define test data
    input = """
    lan0 link#5                0    0.0.0.0                    /0
    lan0  8        8        0x00         0x20000008   lan0
    lan0  9        9        0x00         0x80         lan0
    lan1  4        4        0x00         0x20000004   lan1
    lan1  6        6        0x00         0x80         lan1
    lan1  7        7        0x00         0x80000000   lan1
    """

# Generated at 2022-06-11 03:26:49.724661
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    '''
    Unit test for constructor of class HPUXNetwork
    '''
    instance = HPUXNetwork()
    assert(isinstance(instance, HPUXNetwork))


# Generated at 2022-06-11 03:27:00.127372
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class TestModule(object):
        def run_command(self, *args, **kwargs):
            out = ("""
Kernel Interface table
Destination        Gateway           Flags   Refs     Use     Interface
------------------------------------------------------------------------
default            10.200.0.1        UG         0   47003     lan0
------------------------------------------------------------------------
""")
            return (0, out, '')

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/netstat'

    facts = HPUXNetwork(TestModule())
    facts.populate()

    assert facts.get('default_interface') == 'lan0'
    assert facts.get('default_gateway') == '10.200.0.1'



# Generated at 2022-06-11 03:27:08.066419
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import sys
    import types
    import os
    import collections
    from distutils.version import LooseVersion

    from ansible.module_utils.facts.network.hpx import HPUXNetwork
    from ansible.module_utils.facts.network.base import Network

    # Create instance of the HPUXNetwork class.
    hpx_network = HPUXNetwork({})

    #
    # Setup a mock module object since the module_utils.facts.network.hpx
    # module is not importable.
    #

    if sys.version_info[0] == 3:
        module_type = types.ModuleType('ansible.module_utils.facts.network')

# Generated at 2022-06-11 03:27:10.150643
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'


# Generated at 2022-06-11 03:27:21.337674
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    facts = {'kernel': 'HP-UX'}
    mod = AnsibleModuleMock(facts=facts,
                            params={},
                            check_mode=False)
    net = HPUXNetwork(mod, mod.params)
    rc, stdout, stderr = mod.run_command.mock.mock_calls[0][1][0]
    assert rc == 0
    out = '''Kernel Interface Table
lan0      lan0        1000        0 00000000     0099E8000000     -

Routing Information

Destination            Gateway           Flags   Refs     Use      Interface
default          10.0.0.1       UG        1        133    lan0
10.0.0.0         10.0.0.152     U         1        0        lan0
'''

# Generated at 2022-06-11 03:27:31.062217
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = NetworkCollectorTestUtil.get_ansible_module_mock()
    net = HPUXNetwork(module)

    module.run_command.return_value = (0, '', '')
    net.get_default_interfaces()
    net.get_interfaces_info()
    result = net.populate()

    assert result['default_interface'] == 'lan0'
    assert result['default_gateway'] == '10.10.10.1'
    assert result['interfaces'] == ['lan0', 'lan1']
    assert result['lan0']['ipv4']['address'] == '10.10.10.10'
    assert result['lan1']['ipv4']['address'] == '10.10.10.20'



# Generated at 2022-06-11 03:27:41.684074
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    default_interfaces = test_module.get_default_interfaces()
    assert default_interfaces['default_interface'] == 'lan0'
    assert default_interfaces['default_gateway'] == '159.142.54.1'



# Generated at 2022-06-11 03:27:42.911296
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector()

# Generated at 2022-06-11 03:27:49.817774
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    test_instance = HPUXNetwork()
    test_instance.module = AnsibleModule(argument_spec={})
    test_instance.module.run_command = Mock(return_value=(0, 'some_string', ''))
    result = test_instance.get_default_interfaces()
    expected_result = {'default_interface': 'lan0',
                       'default_gateway': '10.3.144.1'}
    assert result == expected_result

# Generated at 2022-06-11 03:27:58.572460
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    """
    Unit test method get_interfaces_info of class HPUXNetwork.
    """
    module = AnsibleModule(argument_spec={})
    out = "lan0   link#1          UP    " \
          "UP   0   3008       0" \
          "    14.1.11.0/24   14.1.11.1"
    module.run_command = Mock(return_value=(
        0, out, ''
    ))
    network = HPUXNetwork(module)
    interfaces = network.get_interfaces_info()
    assert interfaces.get('lan0') is not None, \
        'interfaces dictionary should contain lan0 entry'

# Generated at 2022-06-11 03:28:01.035126
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == 'HP-UX'



# Generated at 2022-06-11 03:28:11.565457
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Mocking objects
    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_provider = {}
            self.run_command_provider['boottime'] = self.run_command_boottime
            self.run_command_provider['fib'] = self.run_command_fib
            self.run_command_provider['netstat'] = self.run_command_netstat
            self.run_command_provider['facts'] = self.run_command_facts
            self.run_command_provider['files'] = self.run_command_files

        def get_bin_path(self, arg, opt_dirs=None):
            return '/usr/bin/' + arg

        def run_command(self, cmd):
            return self

# Generated at 2022-06-11 03:28:16.718278
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    """
    Function that tests return of method get_default_interfaces
    """
    class Mod:
        def run_command(self, arg):
            return 0, "default 172.16.0.1 UGSc 108 11185 en0", None

    mod = Mod()
    hp_ux_net = HPUXNetwork(mod)
    result = hp_ux_net.get_default_interfaces()
    assert result['default_interface'] == 'en0'
    assert result['default_gateway'] == '172.16.0.1'


# Generated at 2022-06-11 03:28:19.508695
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hux = HPUXNetwork()
    assert hux.platform == 'HP-UX'
    assert hux.default_interface is None
    assert hux.interfaces is None

# Generated at 2022-06-11 03:28:20.905004
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    net_config = HPUXNetwork()



# Generated at 2022-06-11 03:28:30.585995
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    result = dict(
        ansible_facts=dict(
            ansible_net_interfaces=['lan0', 'lan1']
        )
    )

    hupuxNetwork = HPUXNetwork(module)
    interfaces = hupuxNetwork.get_interfaces_info()
    result['ansible_facts']['ansible_net_interfaces'] = interfaces.keys()
    for iface in interfaces:
        result['ansible_facts'][iface] = interfaces[iface]

    module.exit_json(**result)

# Generated at 2022-06-11 03:28:43.624792
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    fake_module = FakeModule()
    hpux_network = HPUXNetwork(fake_module)
    interfaces = hpux_network.get_interfaces_info()

    assert interfaces['lan0'] == {'device': 'lan0',
                                  'ipv4': {'address': '172.17.0.1',
                                           'network': '172.17.0.0',
                                           'interface': 'lan0',
                                           'address': '172.17.0.1'}}



# Generated at 2022-06-11 03:28:46.627808
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_facts = HPUXNetworkCollector()
    assert network_facts._fact_class == HPUXNetwork
    assert network_facts._platform == 'HP-UX'

# Generated at 2022-06-11 03:28:49.382445
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    assert issubclass(HPUXNetwork, Network)
    hpuxnetwork = HPUXNetwork()
    assert isinstance(hpuxnetwork, Network)


# Generated at 2022-06-11 03:28:53.617781
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    # Create object for class HPUXNetworkCollector
    net_obj = HPUXNetworkCollector()

    # Check value of private instance variable _fact_class
    assert net_obj._fact_class == HPUXNetwork

    # Check value of private instance variable _platform
    assert net_obj._platform == 'HP-UX'

# Generated at 2022-06-11 03:28:56.331264
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpxNetwork = HPUXNetwork()
    assert hpxNetwork.platform == 'HP-UX'
    assert hpxNetwork.populate() is not None
    assert hpxNetwork.get_default_interfaces() is not None

# Generated at 2022-06-11 03:28:59.161277
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts.network.hpux.collector import HPUXNetwork
    network_facts = HPUXNetwork()
    assert network_facts.platform == 'HP-UX'
    return



# Generated at 2022-06-11 03:29:09.582413
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule()
    network = HPUXNetwork(module)
    network.populate()
    network_facts = network.get_facts()
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['default_gateway'] == '10.0.2.2'
    assert network_facts['interfaces'] == ['lan0', 'ent0']
    assert network_facts['lan0'] == {'device': 'lan0',
                                     'ipv4': {'address': '10.0.2.15',
                                              'interface': 'lan0',
                                              'network': '10.0.2.0'}}

# Generated at 2022-06-11 03:29:19.047393
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    with open('/etc/passwd', 'r') as infile:
        content = infile.read()
    module = FakeAnsibleModule(content)
    network = HPUXNetwork(module)
    facts = network.populate()
    assert facts['default_interface'] == 'lan4'
    assert facts['default_gateway'] == '10.10.10.1'
    assert facts['interfaces'] == ['lan4']
    assert facts['lan4'] == {'device': 'lan4',
                             'ipv4': {'network': '10.10.10.0',
                                      'interface': 'lan4',
                                      'address': '10.10.10.53'}}


# Generated at 2022-06-11 03:29:25.944074
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self):
            self.facts = dict()
            self.params = {'gather_subset': ['!all', 'network']}

        def get_bin_path(self, arg, req_true=False, opt_true=False):
            return "netstat"

        def run_command(self, cmd):
            return 0, 'default 10.1.1.1 UGS 0 424 lan0', ''
    module = MockModule()
    net = HPUXNetwork(module)
    a = net.populate()
    assert 'default_interface' in a
    assert a['default_interface'] == 'lan0'
    assert 'default_gateway' in a
    assert a['default_gateway'] == '10.1.1.1'

# Generated at 2022-06-11 03:29:32.146504
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    """This function tests the constructor for class HPUXNetworkCollector
    """
    hpux_network_collector = HPUXNetworkCollector()
    assert len(hpux_network_collector.platforms) == 1
    assert hpux_network_collector.platforms[0] == 'HP-UX'
    assert hpux_network_collector.fact_class == HPUXNetwork

# Generated at 2022-06-11 03:29:43.648639
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    pass

# Generated at 2022-06-11 03:29:49.876018
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = FakeAnsibleModule({})
    network = HPUXNetwork(module)
    collected_facts = {'ansible_net_interfaces': ['lo', 'lan0']}
    network_facts = network.populate(collected_facts)
    assert network_facts is not None
    assert network_facts['default_interface'] == 'lan0'
    assert network_facts['interfaces'] == collected_facts['ansible_net_interfaces']



# Generated at 2022-06-11 03:29:53.371897
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact = HPUXNetworkCollector()
    assert fact.get_fact_class() == HPUXNetwork
    assert fact.get_platform() == 'HP-UX'

# Generated at 2022-06-11 03:29:57.671404
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )
    network_collector = HPUXNetworkCollector(module=module)
    network_collector.populate()
    assert len(network_collector.gather_facts().keys()) == 2

# Generated at 2022-06-11 03:29:59.272810
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    HPUXNetworkCollector(None, None)

# Generated at 2022-06-11 03:30:08.936589
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    mock_module = Mock(params={})
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = ('/usr/bin/netstat')
    network = HPUXNetwork(mock_module)

    rc, out, err = mock_module.run_command.return_value
    mock_module.run_command.assert_called_once_with('/usr/bin/netstat -nr')
    assert rc == 0
    assert out == ''
    assert err == ''


# Generated at 2022-06-11 03:30:15.207862
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hpux_network = HPUXNetwork(module)

    mock_command = Mock(return_value=0)
    with patch.dict(hpux_network.module.params, {'gather_subset': 'all'}):
        with patch.object(hpux_network, 'run_command', mock_command):
            hpux_network.populate()
            mock_command.assert_any_call('/usr/bin/netstat -nr')
            mock_command.assert_any_call('/usr/bin/netstat -niw')

# Generated at 2022-06-11 03:30:17.574896
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    hpux_network = HPUXNetwork()
    assert hpux_network.platform == "HP-UX"


# Generated at 2022-06-11 03:30:19.532370
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    hpux = HPUXNetworkCollector()
    assert hpux._platform == 'HP-UX'

# Generated at 2022-06-11 03:30:22.268106
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    res = HPUXNetwork().get_default_interfaces()
    assert res == {'default_interface': 'lan0', 'default_gateway': '10.10.10.3'}, 'get_default_interfaces failed!'


# Generated at 2022-06-11 03:30:51.996642
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    network = HPUXNetwork(dict(), dict())

    expected = {'default_interface': 'lan0',
                'default_gateway': '10.0.0.1'}
    netstat_out = """
Kernel IP routing table
Destination        Gateway           Flags  Refs If  Expire
=================== ================== ====== ==== === =====
default            10.0.0.1          UGS    0    1    0
10.0.0.0           =                UGC    0    0    0
"""
    network.module.run_command = lambda x: (0, netstat_out, '')
    default_interfaces = network.get_default_interfaces()
    assert default_interfaces == expected


# Generated at 2022-06-11 03:30:55.754097
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    hpux_network = HPUXNetwork()
    hpux_network.module.run_command = lambda x: (0, "lan0    8000.060f2a6eea57", "")
    hpux_network.get_interfaces_info = lambda: {}
    collected_facts = hpux_network.populate()
    assert collected_facts['default_interface'] == 'lan0'


# Generated at 2022-06-11 03:30:57.272950
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hpux_network = HPUXNetwork({})
    assert hpux_network.populate()['interfaces'] == ['lan0']

# Generated at 2022-06-11 03:31:00.135997
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector.platform == 'HP-UX'
    assert network_collector.fact_class == HPUXNetwork
    assert network_collector.fact_subclasses == {}


# Generated at 2022-06-11 03:31:01.969333
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    c = HPUXNetworkCollector()
    assert c.platform == 'HP-UX'
    assert c._fact_class.platform == 'HP-UX'

# Generated at 2022-06-11 03:31:04.366403
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    # class HPUXNetwork is tested as part of the facts collection routine
    # in the 'hpux_network' tested module
    pass



# Generated at 2022-06-11 03:31:05.320385
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    assert HPUXNetworkCollector()

# Generated at 2022-06-11 03:31:08.155168
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    network_collector = HPUXNetworkCollector()
    assert network_collector._platform == 'HP-UX'
    assert network_collector._fact_class.platform == 'HP-UX'

# Generated at 2022-06-11 03:31:12.875046
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'default 10.10.10.1 UG lan0', '')
    network = HPUXNetwork(module)
    interfaces = network.get_default_interfaces()
    assert interfaces['default_interface'] == 'lan0'
    assert interfaces['default_gateway'] == '10.10.10.1'



# Generated at 2022-06-11 03:31:14.916554
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    result = HPUXNetwork().get_default_interfaces()
    assert result == {'default_interface': 'lan0', 'default_gateway': '172.16.0.10'}

# Generated at 2022-06-11 03:32:25.408283
# Unit test for method get_default_interfaces of class HPUXNetwork
def test_HPUXNetwork_get_default_interfaces():
    facts = HPUXNetwork().get_default_interfaces()
    assert facts['default_interface'] == 'lan0'
    assert facts['default_gateway'] == '10.1.1.1'


# Generated at 2022-06-11 03:32:27.951850
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    interfaces = HPUXNetwork().get_interfaces_info()
    assert 'lan0' in interfaces
    net = interfaces['lan0']
    assert 'network' in net
    assert 'interface' in net
    assert 'address' in net

# Generated at 2022-06-11 03:32:35.815503
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    # Test the HPUXNetwork.populate method with a mocked module object
    # Create a mock module object to pass to the HPUXNetwork
    # initialize function
    from ansible.module_utils.facts.network.collectors import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hpuix_network import HPUXNetwork
    from ansible.module_utils.facts.network.ios import IOSNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBSDNetwork
    class MockModule(object):
        def __init__(self, params):
            self.params = params
        def fail_json(self, **kwargs):
            return


# Generated at 2022-06-11 03:32:38.406442
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    from ansible.module_utils.facts.network.hpux.hpux import HPUXNetwork
    hpux_network = HPUXNetwork(dict())
    print("hpux_network: ", hpux_network)

if __name__ == '__main__':
    test_HPUXNetwork()

# Generated at 2022-06-11 03:32:39.883880
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    nc = HPUXNetworkCollector()
    assert nc._platform == 'HP-UX'
    assert nc._fact_class == HPUXNetwork


# Generated at 2022-06-11 03:32:46.109951
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    import sys
    print(sys.path)

    mock_module = Mock(return_value=1)

# Generated at 2022-06-11 03:32:47.880332
# Unit test for constructor of class HPUXNetworkCollector
def test_HPUXNetworkCollector():
    fact_network = HPUXNetworkCollector()
    assert fact_network._fact_class is HPUXNetwork
    assert fact_network._platform == 'HP-UX'


# Generated at 2022-06-11 03:32:51.706669
# Unit test for method get_interfaces_info of class HPUXNetwork
def test_HPUXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    net_mod = HPUXNetwork(None)
    rc, out, err = net_mod.module.run_command("/usr/bin/netstat -niw")
    net_mod.get_interfaces_info()
if __name__ == '__main__':
    test_HPUXNetwork_get_interfaces_info()

# Generated at 2022-06-11 03:32:56.751871
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    network = HPUXNetwork(None)
    # Checking that private attributes are not created
    try:
        network.interfaces
    except AttributeError:
        pass
    else:
        assert('Private attribute interfaces is created')
    # Checking that protected attributes are not created
    try:
        network.ipv4_interfaces
    except AttributeError:
        pass
    else:
        assert('Protected attribute ipv4_interfaces is created')



# Generated at 2022-06-11 03:32:58.153920
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    hnet = HPUXNetwork()
    assert hnet.platform == 'HP-UX'



# Generated at 2022-06-11 03:35:04.623970
# Unit test for method populate of class HPUXNetwork
def test_HPUXNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    HPUXNetworkCollector.populate(module)
    d = module.params['ansible_facts']
    assert d['ansible_default_ipv4']['gateway'] == '10.2.2.1'
    assert len(d['ansible_interfaces']) == 1
    assert d['ansible_interfaces'][0] == 'lan8'

# Generated at 2022-06-11 03:35:07.336154
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    try:
        hpux_network = HPUXNetwork()
        assert hpux_network is not None
    except:
        assert False


# Generated at 2022-06-11 03:35:08.117079
# Unit test for constructor of class HPUXNetwork
def test_HPUXNetwork():
    HPUXNetwork()
