

# Generated at 2022-06-25 19:43:28.684163
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    result = ask_whether_to_apply_changes_to_file(file_path = "file_path")

# Generated at 2022-06-25 19:43:33.360258
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    from unittest import mock
    from unittest.mock import Mock
    m = Mock()
    m.return_value = 'N'
    with mock.patch('builtins.input', m):
        assert not ask_whether_to_apply_changes_to_file('/test/file')


# Generated at 2022-06-25 19:43:38.947003
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = create_terminal_printer(True, sys.stdout)
    assert isinstance(colorama_printer_0, ColoramaPrinter)

    basic_printer_0 = create_terminal_printer(False, sys.stdout)
    assert isinstance(basic_printer_0, BasicPrinter)


# Generated at 2022-06-25 19:43:44.051768
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    dict_0 = {
        "path": "test_path",
        "color": True,
        "output": sys.stdout,
    }
    with unittest.mock.patch("sys.stdout", new=io.StringIO()) as mock_stdout:
        with unittest.mock.patch("builtins.input", new=lambda x: "y") as mock_input:
            assert ask_whether_to_apply_changes_to_file(**dict_0) == True
        assert mock_stdout.getvalue() == "Apply suggested changes to 'test_path' [y/n/q]? \n"

# Generated at 2022-06-25 19:43:45.552554
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("ABS/RELATIVE/PATH") == True

# Generated at 2022-06-25 19:43:52.536869
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    # Test 1
    colorama_printer_0 = create_terminal_printer(False, sys.stdout)
    assert isinstance(colorama_printer_0, BasicPrinter), "Fault in create_terminal_printer"
    # Test 2
    colorama_printer_0 = create_terminal_printer(True, sys.stdout)
    assert isinstance(colorama_printer_0, ColoramaPrinter), "Fault in create_terminal_printer"



# Generated at 2022-06-25 19:43:58.733478
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    color = True
    output = None
    result_0 = create_terminal_printer(color, output)
    assert isinstance(result_0, ColoramaPrinter)
    print(result_0)

    color = False
    output = None
    result_1 = create_terminal_printer(color, output)
    assert isinstance(result_1, BasicPrinter)
    print(result_1)

if __name__ == "__main__":
    print("Running", __file__)

    test_case_0()

    test_create_terminal_printer()

# Generated at 2022-06-25 19:44:01.265558
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    response = ask_whether_to_apply_changes_to_file("test.py")
    assert isinstance(response, bool)


# Generated at 2022-06-25 19:44:04.790959
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    # arrange
    color = False
    output = None
    expected = "testfile.py: before"
    no_color = create_terminal_printer(color, output)
    # act
    actual = no_color.style_text("testfile.py: before")

    # assert
    assert expected == actual



# Generated at 2022-06-25 19:44:06.187513
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test_file_path")


# Generated at 2022-06-25 19:44:18.906086
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_1 = create_terminal_printer(True)
    assert type(colorama_printer_1) == ColoramaPrinter

    colorama_printer_2 = create_terminal_printer(False)
    assert type(colorama_printer_2) == BasicPrinter

    colorama_printer_3 = create_terminal_printer(False, sys.stdout)
    assert type(colorama_printer_3) == BasicPrinter

    colorama_printer_4 = create_terminal_printer(True, sys.stdout)
    assert type(colorama_printer_4) == ColoramaPrinter
# Execute the test case
test_case_0()
test_create_terminal_printer()

# Generated at 2022-06-25 19:44:19.757689
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    pass


# Generated at 2022-06-25 19:44:26.295432
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    mock_stdin = [
        "y",
        "n",
        "q",
    ]

    with mock.patch("builtins.input", side_effect=mock_stdin):
        assert ask_whether_to_apply_changes_to_file("some_file") == True
        assert ask_whether_to_apply_changes_to_file("some_file") == False
        sys.exit(0)

if __name__ == "__main__":
    test_case_0()
    test_ask_whether_to_apply_changes_to_file()

# Generated at 2022-06-25 19:44:32.660262
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = create_terminal_printer(True)
    assert colorama_printer_0.ADDED_LINE == colorama.Fore.GREEN
    assert colorama_printer_0.REMOVED_LINE == colorama.Fore.RED
    assert colorama_printer_0.SUCCESS == '\x1b[32mSUCCESS\x1b[0m'
    assert colorama_printer_0.ERROR == '\x1b[31mERROR\x1b[0m'
    assert colorama_printer_0.diff_line('Lorem ipsum') == None
    assert colorama_printer_0.diff_line('+Lorem ipsum') == None
    assert colorama_printer_0.diff_line('-Lorem ipsum') == None

# Generated at 2022-06-25 19:44:34.937322
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert create_terminal_printer(color=False)



# Generated at 2022-06-25 19:44:38.573796
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    # Case 0
    test_answer_0 = 'y'
    test_file_path_0 = './test.py'
    ret_val_0 = ask_whether_to_apply_changes_to_file(test_file_path_0)

    assert ret_val_0 == True


# Generated at 2022-06-25 19:44:43.305214
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    # print("Test case 1: no")
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    # print("Test case 2: yes")
    assert ask_whether_to_apply_changes_to_file("file_path") == True

test_ask_whether_to_apply_changes_to_file()

# Generated at 2022-06-25 19:44:46.045684
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "test.py"
    result = ask_whether_to_apply_changes_to_file(file_path)
    assert result == True



# Generated at 2022-06-25 19:44:48.024952
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert str(ask_whether_to_apply_changes_to_file('example.py')) == str('True')


# Generated at 2022-06-25 19:44:58.933078
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    class FakePrinter:
        def __init__(self, output: Optional[TextIO] = None):
            pass

    # Case 1: Empty args
    assert create_terminal_printer(False) == BasicPrinter()

    # Case 2: With args
    class ColoramaPrinterStub(ColoramaPrinter):
        def __init__(self, output: Optional[TextIO] = None):
            assert output == sys.stdout
            pass

    assert create_terminal_printer(True, sys.stdout) == ColoramaPrinterStub(sys.stdout)

    # Case 3: With args, Colorama unavailable
    sys.modules['colorama'] = None
    assert create_terminal_printer(True, sys.stdout) == BasicPrinter(sys.stdout)

# Generated at 2022-06-25 19:45:09.380020
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    # Test case where the user enters "y" or "yes"
    user_interaction = io.StringIO()
    sys.stdin = io.StringIO("yes\n")
    assert(ask_whether_to_apply_changes_to_file("mypath.py") == True)
    # Test case where the user enters "n" or "no"
    user_interaction = io.StringIO()
    sys.stdin = io.StringIO("no\n")
    assert(ask_whether_to_apply_changes_to_file("mypath.py") == False)
    # Test case where the user enters "q" or "quit"
    user_interaction = io.StringIO()
    sys.stdin = io.StringIO("quit\n")

# Generated at 2022-06-25 19:45:13.156385
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = ColoramaPrinter()
    assert create_terminal_printer(color=True, output=None) == colorama_printer_0

if __name__ == "__main__":
    print("\nTesting Function: test_case_0\n")
    test_case_0()
    print("\nTesting Function: test_create_terminal_printer\n")
    test_create_terminal_printer()

# Generated at 2022-06-25 19:45:15.070973
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("/home/user/Desktop/test") == True


# Generated at 2022-06-25 19:45:18.058478
# Unit test for function ask_whether_to_apply_changes_to_file

# Generated at 2022-06-25 19:45:29.396880
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    color_0 = True
    output_0 = sys.stdout
    expected_printer_0 = ColoramaPrinter()
    result_printer_0 = create_terminal_printer(color_0, output_0)
    if type(result_printer_0) != type(expected_printer_0):
        raise Exception("Returned printer is of the wrong type")
    output_1 = sys.stdout
    color_1 = False
    expected_printer_1 = BasicPrinter()
    result_printer_1 = create_terminal_printer(color_1, output_1)
    if type(result_printer_1) != type(expected_printer_1):
        raise Exception("Returned printer is of the wrong type")
    color_2 = True
    output_2 = None
    expected

# Generated at 2022-06-25 19:45:31.071498
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("path") == True

# Generated at 2022-06-25 19:45:33.809247
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    # Check if the response is yes, y, no, n, quit, q
    assert ask_whether_to_apply_changes_to_file("file_path") == True



# Generated at 2022-06-25 19:45:39.778050
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():

    correct = ("y","Y","Yes","yes")
    incorrect = ("N","n","No","no","anything")

    for c in correct:
        result = ask_whether_to_apply_changes_to_file("/etc/hosts")
        assert result == True
    for i in incorrect:
        result = ask_whether_to_apply_changes_to_file("/etc/hosts")
        assert result == False

# Generated at 2022-06-25 19:45:41.382252
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test_file") == True


# Generated at 2022-06-25 19:45:42.727847
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert isinstance(create_terminal_printer(False), BasicPrinter)

# Generated at 2022-06-25 19:45:51.659163
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = create_terminal_printer(True)
    assert isinstance(colorama_printer_0, ColoramaPrinter)

    basic_printer_0 = create_terminal_printer(False)
    assert isinstance(basic_printer_0, BasicPrinter)

# Generated at 2022-06-25 19:46:00.532631
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    with patch('builtins.input') as mock1_input:
        mock1_input.side_effect = ["y"]
        assert ask_whether_to_apply_changes_to_file('foo') == True
    with patch('builtins.input') as mock2_input:
        mock2_input.side_effect = ["n"]
        assert ask_whether_to_apply_changes_to_file('foo') == False
    with patch('builtins.input') as mock3_input:
        mock3_input.side_effect = ["q"]
        with pytest.raises(SystemExit):
            ask_whether_to_apply_changes_to_file('foo')
    with patch('builtins.input') as mock4_input:
        mock4_input.side_effect = ["y", "n", "q"]
       

# Generated at 2022-06-25 19:46:02.992393
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("somefile.txt") == True


# Generated at 2022-06-25 19:46:06.545229
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("file.txt")
    assert ask_whether_to_apply_changes_to_file("file.txt") == False

# Generated at 2022-06-25 19:46:08.497926
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("example") is True


# Generated at 2022-06-25 19:46:16.356328
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    # Gets the real status of colorama_unavailable
    global colorama_unavailable
    colorama_unavailable = True
    color_0 = True
    output = sys.stdout
    try:
        create_terminal_printer(color_0, output)
    except SystemExit as e:
        assert e.code == 1
    else:
        assert False, "SystemExit expected"
    
    # Checks if it calls ColoramaPrinter, when color equals True and colorama is available
    colorama_unavailable = False
    color_1 = True
    output = None
    try:
        create_terminal_printer(color_1, output)
    except SystemExit:
        assert False, "SystemExit not expected"
    else:
        assert True
        
    # Checks if it calls BasicPrinter, when color equals

# Generated at 2022-06-25 19:46:19.018658
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    answer = None
    while answer not in ("yes", "y"):
        answer = input(f"Apply suggested changes to '{file_path}' [y/n]? ")  # nosec
        return True

# Generated at 2022-06-25 19:46:20.713833
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "filename"
    assert ask_whether_to_apply_changes_to_file(file_path) is True

# Generated at 2022-06-25 19:46:23.541459
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    color_output = True
    output = sys.stdout
    # print(create_terminal_printer(color_output, output))


# Generated at 2022-06-25 19:46:27.318194
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = ColoramaPrinter()
    assert isinstance(colorama_printer_0, ColoramaPrinter)

    basic_printer_0 = BasicPrinter()
    assert isinstance(basic_printer_0, BasicPrinter)


# Generated at 2022-06-25 19:46:38.769655
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    # Test colorama_unavailable
    create_terminal_printer(True, sys.stdout)

    # Test color
    colorama_printer_1 = ColoramaPrinter(sys.stdout)
    printer_1 = create_terminal_printer(True, sys.stdout)
    assert printer_1.ERROR == colorama_printer_1.ERROR
    assert printer_1.SUCCESS == colorama_printer_1.SUCCESS
    assert printer_1.ADDED_LINE == colorama_printer_1.ADDED_LINE
    assert printer_1.REMOVED_LINE == colorama_printer_1.REMOVED_LINE

    # Test no color
    basic_printer_1 = BasicPrinter(sys.stdout)

# Generated at 2022-06-25 19:46:50.121431
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    # Test colorama_unavailable=True
    setattr(sys.modules[__name__], "colorama_unavailable", True)
    colorama_printer_0 = create_terminal_printer(color=True)
    assert isinstance(colorama_printer_0, BasicPrinter), (
        "Expected: BasicPrinter\n"
        "Got: {}".format(colorama_printer_0)
    )
    colorama_printer_1 = create_terminal_printer(color=False)
    assert isinstance(colorama_printer_1, BasicPrinter), (
        "Expected: BasicPrinter\n"
        "Got: {}".format(colorama_printer_1)
    )
    # Test colorama_unavailable=False

# Generated at 2022-06-25 19:46:52.088190
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test_file.json") == False

# Test case for function create_terminal_printer

# Generated at 2022-06-25 19:46:54.624930
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file() == True


# Generated at 2022-06-25 19:47:00.984779
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    # Expected basic printer
    result = create_terminal_printer(False)
    assert type(result) == BasicPrinter

    # Expected basic printer when colorama is not installed
    global colorama_unavailable
    colorama_unavailable = True
    result = create_terminal_printer(True)
    assert type(result) == BasicPrinter

    # Expected colorama printer
    global colorama_unavailable
    colorama_unavailable = False
    result = create_terminal_printer(True)
    assert type(result) == ColoramaPrinter

# Generated at 2022-06-25 19:47:04.565544
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    # Case 0
    pName = 'C:\\Users\\Makayla\\Desktop\\isort\\isort-4.3.21.dist-info'

    assert ask_whether_to_apply_changes_to_file(pName) == True


# Generated at 2022-06-25 19:47:05.929905
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    create_terminal_printer(True)


# Generated at 2022-06-25 19:47:10.849425
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("/test/file/path.py") == False
    assert ask_whether_to_apply_changes_to_file("/test/file/path.py") == True
    assert ask_whether_to_apply_changes_to_file("/test/file/path.py") == False
    assert ask_whether_to_apply_changes_to_file("/test/file/path.py") == True

test_case_0()
test_ask_whether_to_apply_changes_to_file()

# Generated at 2022-06-25 19:47:12.398022
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test") is True

# Generated at 2022-06-25 19:47:16.996908
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    original_stdout = sys.stdout

    try:
        out = Path(__file__).parent / "test_output.txt"
        out.touch()
        file = open(out, "w")
        sys.stdout = file
        answer = ask_whether_to_apply_changes_to_file("test file")
    finally:
        sys.stdout = original_stdout
        file.close()
        out.unlink()

    assert answer is False

# Generated at 2022-06-25 19:47:24.110093
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("file_path") is False


# Generated at 2022-06-25 19:47:26.917060
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file('test') == False
    assert ask_whether_to_apply_changes_to_file('test') == True


# Generated at 2022-06-25 19:47:32.760729
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    with mock.patch('builtins.input', return_value='y'):
        assert ask_whether_to_apply_changes_to_file('file_path') is True
    with mock.patch('builtins.input', return_value='n'):
        assert ask_whether_to_apply_changes_to_file('file_path') is False
    with mock.patch('builtins.input', return_value='q'):
        assert ask_whether_to_apply_changes_to_file('file_path') is False



# Generated at 2022-06-25 19:47:35.277815
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("/tmp/foo.txt") == False
    assert ask_whether_to_apply_changes_to_file("/tmp/bar.txt") == True


# Generated at 2022-06-25 19:47:36.967295
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test_file") == True
    assert ask_whether_to_apply_changes_to_file("test_file2") == False


# Generated at 2022-06-25 19:47:38.239782
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "test_case_0.txt"
    assert ask_whether_to_apply_changes_to_file(file_path) == False


# Generated at 2022-06-25 19:47:45.742200
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file

# Generated at 2022-06-25 19:47:48.181355
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    print("Testing function test_ask_whether_to_apply_changes_to_file")
    filepath = "isort.py"
    assert ask_whether_to_apply_changes_to_file(filepath) == True



# Generated at 2022-06-25 19:47:51.933591
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "the/file.py"
    read_input = lambda: "yes"
    with patch("builtins.input", read_input):
        assert ask_whether_to_apply_changes_to_file(file_path)

    read_input = lambda: "no"
    with patch("builtins.input", read_input):
        assert not ask_whether_to_apply_changes_to_file(file_path)

    read_input = lambda: "quit"
    with patch("builtins.input", read_input):
        with pytest.raises(SystemExit):
            ask_whether_to_apply_changes_to_file(file_path)



# Generated at 2022-06-25 19:47:53.496197
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test") == True


# Generated at 2022-06-25 19:48:04.423273
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    # Test 1: Test if function returns true for yes,y
    assert True == ask_whether_to_apply_changes_to_file("test")

    # Test 2: Test if function returns false for no,n
    assert False == ask_whether_to_apply_changes_to_file("test")

    # Test 3: Test if function returns true for quit,q
    assert True == ask_whether_to_apply_changes_to_file("test")



# Generated at 2022-06-25 19:48:07.929023
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file('setup.py') == False
    assert ask_whether_to_apply_changes_to_file('README.md') == False
    assert ask_whether_to_apply_changes_to_file('LICENSE') == False



# Generated at 2022-06-25 19:48:09.084526
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 19:48:10.791907
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert(ask_whether_to_apply_changes_to_file("file_path")==True)


# Generated at 2022-06-25 19:48:17.001522
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    # Test case 0
    # Test with typescript file
    file_path = "test.ts"
    assert ask_whether_to_apply_changes_to_file(file_path) == False, "Expected True but got False"
    # Test case 1
    # Test with python file
    file_path = "test.py"
    assert ask_whether_to_apply_changes_to_file(file_path) == False, "Expected True but got False"



# Generated at 2022-06-25 19:48:18.338593
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert not ask_whether_to_apply_changes_to_file("")


# Generated at 2022-06-25 19:48:19.910061
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "file_path"
    assert ask_whether_to_apply_changes_to_file(file_path)


# Generated at 2022-06-25 19:48:26.078085
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_true = create_terminal_printer(color=True)
    assert isinstance(colorama_printer_true, ColoramaPrinter)

    colorama_printer_false = create_terminal_printer(color=False)
    assert isinstance(colorama_printer_false, BasicPrinter)

# Generated at 2022-06-25 19:48:28.972973
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("file_path") == True


# Generated at 2022-06-25 19:48:34.718111
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test_file.py") == True
    assert ask_whether_to_apply_changes_to_file("test_file.py") == True
    assert ask_whether_to_apply_changes_to_file("test_file.py") == True


# Generated at 2022-06-25 19:48:47.023909
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_1 = create_terminal_printer(True)
    assert isinstance(colorama_printer_1, ColoramaPrinter)
    assert colorama_printer_1.output is sys.stdout
    assert colorama_printer_1.ADDED_LINE is not None

    colorama_printer_2 = create_terminal_printer(False)
    assert isinstance(colorama_printer_2, BasicPrinter)
    assert colorama_printer_2.output is sys.stdout
    assert colorama_printer_2.ADDED_LINE == colorama.Fore.GREEN

    printer_3 = create_terminal_printer(True, sys.stderr)
    assert isinstance(printer_3, ColoramaPrinter)

# Generated at 2022-06-25 19:48:52.020430
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = create_terminal_printer(False)
    assert type(colorama_printer_0).__name__ == "BasicPrinter"

    colorama_printer_0 = create_terminal_printer(True)
    assert type(colorama_printer_0).__name__ == "ColoramaPrinter"

# Generated at 2022-06-25 19:49:00.517076
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    output = None
    color = False
    colorama_printer = None
    if colorama_unavailable:
        colorama_printer = colorama_printer_0 = None
    else:
        colorama_printer = ColoramaPrinter()
        colorama_printer_0 = ColoramaPrinter()
    basic_printer = BasicPrinter()
    test_0 = create_terminal_printer(color, output)
    assert isinstance(test_0, ColoramaPrinter) or isinstance(test_0, BasicPrinter)
    test_1 = create_terminal_printer(color, None)
    assert isinstance(test_1, ColoramaPrinter) or isinstance(test_1, BasicPrinter)
    test_2 = create_terminal_printer(False, sys.stdout)


# Generated at 2022-06-25 19:49:01.744652
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file(file_path="test") == True

# Generated at 2022-06-25 19:49:08.427034
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = create_terminal_printer(color=True)
    assert isinstance(colorama_printer_0, ColoramaPrinter)
    colorama_printer_1 = create_terminal_printer(color=True, output=sys.stdout)
    assert isinstance(colorama_printer_1, ColoramaPrinter)
    basic_printer_0 = create_terminal_printer(color=False)
    assert isinstance(basic_printer_0, BasicPrinter)
    basic_printer_1 = create_terminal_printer(color=False, output=sys.stdout)
    assert isinstance(basic_printer_1, BasicPrinter)

# Generated at 2022-06-25 19:49:16.812107
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_1 = ColoramaPrinter()
    colorama_printer_2 = ColoramaPrinter(output=sys.stdout)
    colorama_printer_3 = ColoramaPrinter(output=sys.stdout)
    basic_printer_1 = BasicPrinter()
    basic_printer_2 = BasicPrinter(output=sys.stdout)
    basic_printer_3 = BasicPrinter(output=sys.stdout)

    assert(create_terminal_printer(True,output=sys.stdout) == colorama_printer_2)
    assert(create_terminal_printer(False,output=sys.stdout) == basic_printer_2)

# Generated at 2022-06-25 19:49:19.425067
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    color_true = create_terminal_printer(color=True)
    assert type(color_true) == ColoramaPrinter

    color_false = create_terminal_printer(color=False)
    assert type(color_false) == BasicPrinter

# Generated at 2022-06-25 19:49:20.799100
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test.py") == True


# Generated at 2022-06-25 19:49:22.299518
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test_file_path") == False

# Generated at 2022-06-25 19:49:24.428769
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert create_terminal_printer(color=False) is not None
    assert create_terminal_printer(color=True) is not None


# Generated at 2022-06-25 19:49:30.652454
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert create_terminal_printer(False, None) is not None
    assert create_terminal_printer(True, None) is not None



# Generated at 2022-06-25 19:49:34.273551
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "test.py"
    res = ask_whether_to_apply_changes_to_file("test.py")
    if(res == True):
        print("test passed")
    else:
        print("test failed")


# Generated at 2022-06-25 19:49:35.169080
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("file_path") == True

# Generated at 2022-06-25 19:49:38.204817
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    # Constructor checks if the given file_path is a valid file name.
    assert isinstance(ask_whether_to_apply_changes_to_file("requirements.txt"),bool)


# Generated at 2022-06-25 19:49:39.324473
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("file_path") == True


# Generated at 2022-06-25 19:49:49.433239
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert str(create_terminal_printer(True, None)) in [
        '<__main__.BasicPrinter object at 0x7f0cdd2d9a90>', 
        '<__main__.ColoramaPrinter object at 0x7f0cdd2d9a90>']
    assert str(create_terminal_printer(False, None)) in [
        '<__main__.BasicPrinter object at 0x7f0cdd2d9a90>', 
        '<__main__.ColoramaPrinter object at 0x7f0cdd2d9a90>']


# Generated at 2022-06-25 19:49:59.758825
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = create_terminal_printer(True)
    assert isinstance(colorama_printer_0, ColoramaPrinter)
    colorama_printer_1 = create_terminal_printer(False)
    assert isinstance(colorama_printer_1, BasicPrinter)
    try:
        colorama_printer_2 = create_terminal_printer(True, output=sys.stdout)
    except Exception as exception_0:
        assert isinstance(exception_0, ImportError)
    else:
        raise AssertionError("ImportError expected")


# Generated at 2022-06-25 19:50:03.206892
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("file_path") is True


# Generated at 2022-06-25 19:50:05.861297
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert create_terminal_printer(color=False).__class__ == BasicPrinter
    assert create_terminal_printer(color=True).__class__ == ColoramaPrinter


# Generated at 2022-06-25 19:50:12.292389
# Unit test for function create_terminal_printer
def test_create_terminal_printer():

    # create_terminal_printer(color=False, output=None)
    test_case_0()

if __name__ == "__main__":
    print("================== START OF UNIT TESTS ==================")
    print("Unit test for function create_terminal_printer")
    test_create_terminal_printer()
    print("==================== FUNCTIONS DONE =====================")
    print("======================= DONE ============================")

# Generated at 2022-06-25 19:50:18.796391
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file('test_case_1.py') == True


# Generated at 2022-06-25 19:50:23.333825
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = create_terminal_printer(True, sys.stdout)
    assert(type(colorama_printer_0) == ColoramaPrinter)

    basic_printer_0 = create_terminal_printer(False, sys.stdout)
    assert(type(basic_printer_0) == BasicPrinter)

    try:
        colorama_printer_1 = create_terminal_printer(True)
        assert(False)
    except SystemExit as e:
        assert(e.code == 1)

# Generated at 2022-06-25 19:50:29.530869
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "./isort/tests/test_data/test.py"
    assert ask_whether_to_apply_changes_to_file(file_path) == True
    file_path = "./isort/tests/test_data/"
    assert ask_whether_to_apply_changes_to_file(file_path) == True
    file_path = "./isort/tests/test_data/test_data.py"
    assert ask_whether_to_apply_changes_to_file(file_path) == False
    file_path = "none"
    assert ask_whether_to_apply_changes_to_file(file_path) == False


# Generated at 2022-06-25 19:50:34.990965
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = create_terminal_printer(True, sys.stdout)
    assert isinstance(colorama_printer_0, ColoramaPrinter)
    colorama_printer_1 = create_terminal_printer(False, sys.stdout)
    assert isinstance(colorama_printer_1, BasicPrinter)


# Generated at 2022-06-25 19:50:36.338566
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test_file_0") == True


# Generated at 2022-06-25 19:50:45.256126
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    color = False
    output = sys.stdout
    with patch('builtins.input', create=True) as mock_input:
        mock_input.return_value = 'yes'
        answer = ask_whether_to_apply_changes_to_file('test1')
        mock_input.assert_called_once_with(f"Apply suggested changes to 'test1' [y/n/q]? ")
        assert answer == True
    with patch('builtins.input', create=True) as mock_input:
        mock_input.return_value = 'y'
        answer = ask_whether_to_apply_changes_to_file('test2')
        mock_input.assert_called_once_with(f"Apply suggested changes to 'test2' [y/n/q]? ")
        assert answer == True


# Generated at 2022-06-25 19:50:48.045412
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    printer = create_terminal_printer(color=True)

    assert type(printer) is ColoramaPrinter


# Generated at 2022-06-25 19:50:52.475094
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path_0= "./test_case.py"
    try:
        ask_whether_to_apply_changes_to_file(file_path_0)
        assert True
    except AssertionError as e:
        print(e)
        print('test case ask_whether_to_apply_changes_to_file_0 failed')



# Generated at 2022-06-25 19:50:56.735314
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    # Test with ColoramaPrinter
    colorama_printer_0 = create_terminal_printer(True)
    assert isinstance(colorama_printer_0, ColoramaPrinter)

    # Test with BasicPrinter
    basic_printer_0 = create_terminal_printer(False)
    assert isinstance(basic_printer_0, BasicPrinter)

# Generated at 2022-06-25 19:50:59.342878
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    colorama_printer_0 = ColoramaPrinter()
    assert ask_whether_to_apply_changes_to_file("file_path") == bool()


# Generated at 2022-06-25 19:51:12.977267
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert str(type(create_terminal_printer(color=False))) == "<class 'isort.printer.BasicPrinter'>"
    assert str(type(create_terminal_printer(color=True))) == "<class 'isort.printer.ColoramaPrinter'>"
    assert str(type(create_terminal_printer(color=True, output=sys.stdout))) == "<class 'isort.printer.ColoramaPrinter'>"
    assert str(type(create_terminal_printer(color=False, output=sys.stdout))) == "<class 'isort.printer.BasicPrinter'>"
    assert str(type(create_terminal_printer(color=True, output=sys.stderr))) == "<class 'isort.printer.ColoramaPrinter'>"

# Generated at 2022-06-25 19:51:21.235058
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "somefile"
    with mock.patch("builtins.input", side_effect=["n", "y", "NO", "YES", "q", "y", "yes"]):
        assert not ask_whether_to_apply_changes_to_file(file_path)
        assert ask_whether_to_apply_changes_to_file(file_path)
        assert not ask_whether_to_apply_changes_to_file(file_path)
        assert ask_whether_to_apply_changes_to_file(file_path)
        with pytest.raises(SystemExit):
            ask_whether_to_apply_changes_to_file(file_path)
        assert ask_whether_to_apply_changes_to_file(file_path)
        assert ask_whether_to_apply_changes_

# Generated at 2022-06-25 19:51:23.400231
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    from unittest.mock import patch
    with patch("builtins.input", return_value="n"):
        ask_whether_to_apply_changes_to_file(file_path="foo.py")
    assert True

# Generated at 2022-06-25 19:51:25.506672
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    with patch('builtins.input', return_value='yes'):
        assert ask_whether_to_apply_changes_to_file('test_file')


# Generated at 2022-06-25 19:51:31.195073
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("file1") == True
    assert ask_whether_to_apply_changes_to_file("file2") == True
    assert ask_whether_to_apply_changes_to_file("file3") == False
    assert ask_whether_to_apply_changes_to_file("file4") == False


# Generated at 2022-06-25 19:51:37.800385
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    with patch('builtins.input', return_value="y"):
        assert ask_whether_to_apply_changes_to_file("/blah") == True
    with patch('builtins.input', return_value="Y"):
        assert ask_whether_to_apply_changes_to_file("/blah") == True
    with patch('builtins.input', return_value="n"):
        assert ask_whether_to_apply_changes_to_file("/blah") == False
    with patch('builtins.input', return_value="N"):
        assert ask_whether_to_apply_changes_to_file("/blah") == False
    with patch('builtins.input', return_value="q"):
        assert ask_whether_to_apply_changes_to_file("/blah") == False

# Generated at 2022-06-25 19:51:41.818867
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    old_stdin = sys.stdin
    try:
        sys.stdin = "true\n"
        file_path = ""
        # save_ask_whether_to_apply_changes_to_file
        result = ask_whether_to_apply_changes_to_file(file_path)
        # assert_ask_whether_to_apply_changes_to_file
        if(result != True):
            raise AssertionError()
    finally:
        # restore_ask_whether_to_apply_changes_to_file
        sys.stdin = old_stdin


# Generated at 2022-06-25 19:51:45.173873
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("foo.xml") == True


# Generated at 2022-06-25 19:51:48.865570
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    # Test case #0
    was_no_exception_t0 = True
    try:
        test_case_0()
    except:
        was_no_exception_t0 = False
    assert was_no_exception_t0

test_create_terminal_printer()

# Generated at 2022-06-25 19:51:54.118978
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer_0 = create_terminal_printer(True)
    print(isinstance(colorama_printer_0, ColoramaPrinter))
    basic_printer_0 = create_terminal_printer(False)
    print(isinstance(basic_printer_0, BasicPrinter))

# Generated at 2022-06-25 19:51:59.937929
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert create_terminal_printer(color = None) is not None


# Generated at 2022-06-25 19:52:07.243588
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    printer_0 = create_terminal_printer(True)
    assert type(printer_0) == ColoramaPrinter
    printer_1 = create_terminal_printer(False)
    assert type(printer_1) == BasicPrinter
    try:
        # noinspection PyUnresolvedReferences
        from colorama import Fore, Style
    except ImportError:
        printer_2 = create_terminal_printer(True)
        assert type(printer_2) == BasicPrinter


# Generated at 2022-06-25 19:52:13.876380
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    printer_0 = create_terminal_printer(True)
    assert type(printer_0) == ColoramaPrinter
    printer_1 = create_terminal_printer(False)
    assert type(printer_1) == BasicPrinter
    return True


if __name__ == "__main__":
    test_case_0()
    test_create_terminal_printer()
    print("Test complete")

# Generated at 2022-06-25 19:52:15.625947
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test.py")


# Generated at 2022-06-25 19:52:17.464589
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file('/path/to/file.py') == False


# Generated at 2022-06-25 19:52:21.585003
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    import sys
    import io

    old_stdin = sys.stdin
    input_value = "yes"
    sys.stdin = io.StringIO(input_value)
    assert ask_whether_to_apply_changes_to_file("file_name.py") == True
    sys.stdin = old_stdin


# Generated at 2022-06-25 19:52:30.679158
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test.txt") == False
    assert ask_whether_to_apply_changes_to_file("test.txt") == False
    assert ask_whether_to_apply_changes_to_file("test.txt") == True
    assert ask_whether_to_apply_changes_to_file("test.txt") == False
    assert ask_whether_to_apply_changes_to_file("test.txt") == True
    assert ask_whether_to_apply_changes_to_file("test.txt") == False


# Generated at 2022-06-25 19:52:31.646162
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file('isort_test.py') == True


# Generated at 2022-06-25 19:52:34.946399
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    old_stdin = sys.stdin
    sys.stdin = StringIO("y\n")
    assert ask_whether_to_apply_changes_to_file("")
    sys.stdin = StringIO("n\n")
    assert not ask_whether_to_apply_changes_to_file("")
    sys.stdin = old_stdin

# Generated at 2022-06-25 19:52:36.508753
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    create_terminal_printer(False)
    create_terminal_printer(True)

# Generated at 2022-06-25 19:52:44.592457
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert type(create_terminal_printer(color=False)) is BasicPrinter
    assert type(create_terminal_printer(color=True)) is ColoramaPrinter

# Generated at 2022-06-25 19:52:52.233343
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    try:
        colorama.init()
    except:
        print('No colorama module')
        return
    # Test 0
    colorama_printer_0 = create_terminal_printer(True, sys.stdout)
    assert isinstance(colorama_printer_0, ColoramaPrinter)
    # Test 1
    basic_printer_1 = create_terminal_printer(False, sys.stdout)
    assert isinstance(basic_printer_1, BasicPrinter)
    # Test 2
    basic_printer_2 = create_terminal_printer(False, None)
    assert isinstance(basic_printer_2, BasicPrinter)
    # Test 3
    colorama_printer_3 = create_terminal_printer(False, None)

# Generated at 2022-06-25 19:53:02.022302
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    colorama_printer = create_terminal_printer(True)
    basic_printer = create_terminal_printer(False)

    assert isinstance(colorama_printer, ColoramaPrinter)
    assert isinstance(basic_printer, BasicPrinter)
    assert isinstance(colorama_printer.output, TextIO)
    assert isinstance(basic_printer.output, TextIO)
    assert isinstance(colorama_printer.SUCCESS, str)
    assert isinstance(basic_printer.SUCCESS, str)
    assert isinstance(colorama_printer.ERROR, str)
    assert isinstance(basic_printer.ERROR, str)


# Generated at 2022-06-25 19:53:04.614215
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    t0 = ColoramaPrinter()
    t1 = ColoramaPrinter()
    t0.output = sys.stdout
    t1.output = sys.stdout

    assert t0.output == t1.output

# Generated at 2022-06-25 19:53:06.946765
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    try:
        ask_whether_to_apply_changes_to_file("test_file")
        assert(True)
    except:
        assert(False)

# Generated at 2022-06-25 19:53:07.722985
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    test_case_0()


# Generated at 2022-06-25 19:53:09.474210
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("foo")==True or ask_whether_to_apply_changes_to_file("foo")==False


# Generated at 2022-06-25 19:53:10.440091
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file('test_file') == True

# Generated at 2022-06-25 19:53:12.801031
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert create_terminal_printer(1) == create_terminal_printer(True)
    assert create_terminal_printer(0) == create_terminal_printer(False)
    assert create_terminal_printer(0) == create_terminal_printer(None)
