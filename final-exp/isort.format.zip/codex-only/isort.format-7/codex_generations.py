

# Generated at 2022-06-23 20:25:29.203420
# Unit test for function format_natural
def test_format_natural():
    print("Test format_natural")
    assert format_natural("import foo") == "import foo"
    assert format_natural("import foo, bar") == "import foo, bar"
    assert format_natural("foo") == "import foo"
    assert format_natural("foo.bar") == "from foo import bar"
    assert format_natural("foo.bar.baz") == "from foo.bar import baz"
    assert format_natural("from foo import bar") == "from foo import bar"
    assert format_natural("from foo.bar import baz") == "from foo.bar import baz"
    assert format_natural("from foo import bar as baz") == "from foo import bar as baz"
    assert format_natural("from foo import (bar, baz)") == "from foo import (bar, baz)"
    assert format

# Generated at 2022-06-23 20:25:36.127880
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    printer = ColoramaPrinter()
    lines = [
        "--- a/tests/tests_difftools.py\n",
        "+++ b/tests/tests_difftools.py\n",
        "@@ -49,7 +49,7 @@\n",
        "     print(line, end='')\n",
        " \n",
        "-    printer.diff_line(line)\n",
        "+    printer.diff_line(line)\n",
    ]
    for line in lines:
        assert printer.diff_line(line) == None

# Generated at 2022-06-23 20:25:37.348713
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    output = "Test"
    assert BasicPrinter().success(output) is None
    assert output == "SUCCESS: Test"


# Generated at 2022-06-23 20:25:40.557484
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    bp = BasicPrinter()
    assert bp.diff_line('+Added_line') == '+Added_line'
    assert bp.diff_line('-Removed_line') == '-Removed_line'
    assert bp.diff_line('Not_added_nor_removed_line') == 'Not_added_nor_removed_line'

# Generated at 2022-06-23 20:25:47.159675
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    import io
    import isort.main
    old_stdout = isort.main._out
    try:
        isort.main._out = io.StringIO()
        BasicPrinter().success("test_success")
        assert "SUCCESS: test_success" == str(isort.main._out.getvalue()).strip()
    finally:
        isort.main._out = old_stdout


# Generated at 2022-06-23 20:25:49.940965
# Unit test for function remove_whitespace
def test_remove_whitespace():
    test_content = """\
    def foo():
        pass


    def bar():
        pass
    """
    assert remove_whitespace(test_content) == "deffoo():passdefbar():pass"

# Generated at 2022-06-23 20:25:59.311350
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    bad_answers = ["fuddylol", ""]
    for bad_answer in bad_answers:
        with mock.patch("isort.main.input", return_value=bad_answer):
            assert not ask_whether_to_apply_changes_to_file("")

    good_answers = ["y", "yes"]
    for good_answer in good_answers:
        with mock.patch("isort.main.input", return_value=good_answer):
            assert ask_whether_to_apply_changes_to_file("")

    quit_answers = ["q", "quit"]

# Generated at 2022-06-23 20:26:04.939317
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == True
    assert ask_whether_to_apply_changes_to_file("file_path") == True
    assert ask_whether_to_apply_changes_to_file("file_path") == False
    assert ask_whether_to_apply_changes_to_file("file_path") == True


# Generated at 2022-06-23 20:26:07.563755
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    sys.stdin = ["x", "yes", "n", "y", "no", "quit"]
    assert ask_whether_to_apply_changes_to_file("/test") is True

# Generated at 2022-06-23 20:26:12.119805
# Unit test for function remove_whitespace
def test_remove_whitespace():
    assert remove_whitespace("") == ""
    assert remove_whitespace("test") == "test"
    assert remove_whitespace("test\ntest") == "testtest"
    assert remove_whitespace("test\rtest") == "testtest"
    assert remove_whitespace("test\r\ntest") == "testtest"
    assert remove_whitespace("test\ttest") == "testtest"
    assert remove_whitespace("test\ntest\rtest\r\ntest\ttest") == "testtesttesttesttest"

# Generated at 2022-06-23 20:26:16.170040
# Unit test for constructor of class ColoramaPrinter
def test_ColoramaPrinter():
    c = ColoramaPrinter()
    assert c is not None
    assert not c.ERROR == ""
    assert not c.SUCCESS == ""
    assert not c.ADDED_LINE == ""
    assert not c.REMOVED_LINE == ""

# Generated at 2022-06-23 20:26:20.537488
# Unit test for function format_natural
def test_format_natural():
    assert format_natural("import tensorflow") == "import tensorflow"
    assert format_natural("import tensorflow.python") == "import tensorflow.python"
    assert format_natural("import tensorflow.python.tools") == "import tensorflow.python.tools"
    assert format_natural("tensorflow") == "import tensorflow"
    assert format_natural("tensorflow.python") == "from tensorflow import python"
    assert format_natural("tensorflow.python.tools") == "from tensorflow.python import tools"


# Generated at 2022-06-23 20:26:29.099550
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    class FakeStdout:
        fake_line = ""

        def write(self, line):
            self.fake_line = line

    output = FakeStdout()
    printer = ColoramaPrinter(output)
    colorama.init()
    # Test diff_line for added line
    printer.diff_line("+AddedLine")
    assert output.fake_line == colorama.Fore.GREEN + "+AddedLine" + colorama.Style.RESET_ALL

    # Test diff_line for removed line
    printer.diff_line("-RemovedLine")
    assert output.fake_line == colorama.Fore.RED + "-RemovedLine" + colorama.Style.RESET_ALL

    # Test diff_line for unchanged line
    printer.diff_line("UnchangedLine")
    assert output.fake_line == "UnchangedLine"

# Generated at 2022-06-23 20:26:31.386951
# Unit test for constructor of class ColoramaPrinter
def test_ColoramaPrinter():
    print('test_ColoramaPrinter')
    assert isinstance(ColoramaPrinter(), ColoramaPrinter)


# Generated at 2022-06-23 20:26:33.982338
# Unit test for function remove_whitespace
def test_remove_whitespace():
    test_string = """
    Something
    some_other_thing
    """
    empty_string = ""
    assert remove_whitespace(test_string) == "Somethingsome_other_thing"
    assert remove_whitespace(test_string, "\r\n") == "Somethingsome_other_thing"
    assert remove_whitespace(empty_string) == ""



# Generated at 2022-06-23 20:26:42.938106
# Unit test for method error of class BasicPrinter
def test_BasicPrinter_error():
    from io import StringIO
    # Default output
    printer = BasicPrinter()
    with StringIO() as buf:
        old_stderr = sys.stderr
        sys.stderr = buf
        printer.error("Hello World")
        sys.stderr = old_stderr
        assert buf.getvalue() == "ERROR: Hello World\n"

    # Custom output
    printer = BasicPrinter(output=buf)
    printer.error("Hello World")
    assert buf.getvalue() == "ERROR: Hello World\n"



# Generated at 2022-06-23 20:26:48.131938
# Unit test for method style_text of class ColoramaPrinter
def test_ColoramaPrinter_style_text():
    assert ColoramaPrinter.style_text("ERROR", None) == "ERROR"
    assert ColoramaPrinter.style_text("ERROR", "") == "ERROR"
    assert ColoramaPrinter.style_text("ERROR", colorama.Fore.RED) == (
        colorama.Fore.RED + "ERROR" + colorama.Style.RESET_ALL
    )

# Generated at 2022-06-23 20:26:54.001346
# Unit test for function format_natural
def test_format_natural():
    # Test 1
    import_line = "from a import b"
    assert format_natural(import_line) == import_line

    # Test 2
    import_line = "import re"
    assert format_natural(import_line) == import_line

    # Test 3
    import_line = "a"
    assert format_natural(import_line) == "import a"

    # Test 4
    import_line = "a.b"
    assert format_natural(import_line) == "from a import b"

    # Test 5
    import_line = "a.b.c"
    assert format_natural(import_line) == "from a.b import c"

# Generated at 2022-06-23 20:26:59.818514
# Unit test for function show_unified_diff
def test_show_unified_diff():
    from io import StringIO
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        inp = "one\ntwo"
        outp = "three\nfour"
        config = {
            "file_input": inp,
            "file_output": outp,
            "file_path": tmpdir / "tmpfile"
        }
        tmpfile = config["file_path"]
        tmpfile.write_text(inp)
        output_stream = StringIO()
        config["output"] = output_stream
        show_unified_diff(**config)

# Generated at 2022-06-23 20:27:04.641933
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    basic_printer = create_terminal_printer(False)
    colorama_printer = create_terminal_printer(True)

    assert isinstance(basic_printer, BasicPrinter)
    assert isinstance(colorama_printer, ColoramaPrinter)


# Generated at 2022-06-23 20:27:05.446038
# Unit test for constructor of class ColoramaPrinter
def test_ColoramaPrinter():
	color_output = True
	output = sys.stdout
	x = ColoramaPrinter(color_output, output)

# Generated at 2022-06-23 20:27:10.347579
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    import re

    # Test if class ColoramaPrinter has changed
    def test_subclass_of_BasicPrinter():
        if not isinstance(ColoramaPrinter, BasicPrinter):
            print("ColoramaPrinter is not a subclass of BasicPrinter, but it should be.")

    # Test if the method diff_line of class ColoramaPrinter has changed

# Generated at 2022-06-23 20:27:12.154727
# Unit test for constructor of class ColoramaPrinter
def test_ColoramaPrinter():
    colorama_printer = ColoramaPrinter()
    assert colorama_printer.output is not None

# Generated at 2022-06-23 20:27:14.968753
# Unit test for constructor of class BasicPrinter
def test_BasicPrinter():
    printer = BasicPrinter()
    assert printer.output == sys.stdout
    assert printer.ERROR == "ERROR"
    assert printer.SUCCESS == "SUCCESS"


# Generated at 2022-06-23 20:27:18.669880
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    printer = create_terminal_printer(True, output=StringIO())
    assert isinstance(printer, ColoramaPrinter)
    assert printer.output, StringIO()

    printer = create_terminal_printer(False, output=StringIO())
    assert isinstance(printer, BasicPrinter)
    assert printer.output, StringIO()

# Generated at 2022-06-23 20:27:24.177377
# Unit test for function remove_whitespace
def test_remove_whitespace():
    assert "" == remove_whitespace("")
    assert "" == remove_whitespace(" ")
    assert "" == remove_whitespace("  ")
    assert "" == remove_whitespace(" \n\t ")
    assert "" == remove_whitespace("\x0c")
    assert " " == remove_whitespace(" \n\t ", line_separator=" ")
    assert "string" == remove_whitespace("s   t   r   i   n   g")
    assert "string" == remove_whitespace("   s   t   r   i   n   g   ")
    assert "string" == remove_whitespace(" s t r i n g ")

# Generated at 2022-06-23 20:27:27.428565
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "arbitrary_file"
    assert ask_whether_to_apply_changes_to_file(file_path) is True


# Generated at 2022-06-23 20:27:29.472474
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file('file_path') == True


# Generated at 2022-06-23 20:27:34.043411
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    # test correct answers
    assert ask_whether_to_apply_changes_to_file("test1") == True
    assert ask_whether_to_apply_changes_to_file("test2") == False
    # test wrong answers
    with mock.patch('builtins.input', return_value='invalid answer'):
        assert ask_whether_to_apply_changes_to_file("test") == True

# Generated at 2022-06-23 20:27:41.976122
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    class FakeInput:
        def __init__(self):
            self.answer = None
            self.user_input = None
            self.call_count = 0

        def __call__(self):
            self.call_count += 1
            if self.answer is not None:
                return self.answer
            if self.user_input is not None:
                return self.user_input[self.call_count - 1]
            return ""

    class FakeStdout:
        def __init__(self):
            self.content = ""

        def write(self, content):
            self.content += content

    fake_input = FakeInput()
    fake_stdout = FakeStdout()


# Generated at 2022-06-23 20:27:49.852487
# Unit test for function format_simplified

# Generated at 2022-06-23 20:27:53.342611
# Unit test for function format_simplified
def test_format_simplified():
    import_line = "from package import function" 
    assert format_simplified(import_line) == "package.function"
    import_line = "import package" 
    assert format_simplified(import_line) == "package"

# Generated at 2022-06-23 20:27:56.473089
# Unit test for function format_natural
def test_format_natural():
    assert format_natural("django.contrib.auth") == "import django.contrib.auth"
    assert format_natural("from django.contrib import auth") == "from django.contrib import auth"


# Generated at 2022-06-23 20:28:04.857982
# Unit test for function format_simplified
def test_format_simplified():
    """Test if format_simplified function is working properly."""
    assert format_simplified("import os") == "os", "Test failed for format_simplified (os)"
    assert format_simplified("from os import fdopen") == "os.fdopen", "Test failed for format_simplified (os.fdopen)"
    assert format_simplified("from os.path import basename") == "os.path.basename", "Test failed for format_simplified (os.path.basename)"
    assert format_simplified("import pymongo.collection") == "pymongo.collection", "Test failed for format_simplified (pymongo.collection)"

# Generated at 2022-06-23 20:28:12.067603
# Unit test for function format_simplified
def test_format_simplified():
    import_line = "from math import sqrt, acos"
    assert format_simplified(import_line) == "math.sqrt,acos"
    import_line = "import   math as   foo   "
    assert format_simplified(import_line) == "math as foo"
    import_line = "import foo"
    assert format_simplified(import_line) == import_line
    import_line = "from foo import bar as foobar"
    assert format_simplified(import_line) == "foo.bar as foobar"
    import_line = 'from foo import \\\n\\\nbar'
    assert format_simplified(import_line) == "foo.bar"

# Generated at 2022-06-23 20:28:17.302063
# Unit test for method style_text of class ColoramaPrinter
def test_ColoramaPrinter_style_text():
    # This is a weird test, but should be enough to give you confidence on
    # being able to modify it, if you need to
    c = ColoramaPrinter()
    assert c.style_text("text1") == "text1"
    assert c.style_text("text1", colorama.Fore.GREEN) == "\x1b[32mtext1\x1b[0m"

# Generated at 2022-06-23 20:28:20.567919
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    success="success"
    printer = BasicPrinter()
    out=printer.success(success)
    assert out == print(f"{printer.SUCCESS}: {success}", file=sys.stdout)


# Generated at 2022-06-23 20:28:25.226422
# Unit test for function format_simplified
def test_format_simplified():
    import_line = "from module import a, b, c"
    assert "module.a, module.b, module.c" == format_simplified(import_line)
    import_line = "from . import submodule"
    assert ".submodule" == format_simplified(import_line)
    import_line = "import a, b, c"
    assert "a, b, c" == format_simplified(import_line)

# Generated at 2022-06-23 20:28:27.829892
# Unit test for constructor of class BasicPrinter
def test_BasicPrinter():
    printer = BasicPrinter
    assert printer is not None


# Generated at 2022-06-23 20:28:32.838867
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    fd = StringIO()

    # Setup printer with different from, to and line_separator
    printer = BasicPrinter(fd)
    printer.diff_line("from")
    printer.diff_line("to")

    assert fd.getvalue() == "from\nto", "Unexpected result"

    return 0


# Generated at 2022-06-23 20:28:37.483113
# Unit test for function show_unified_diff

# Generated at 2022-06-23 20:28:41.659013
# Unit test for constructor of class ColoramaPrinter
def test_ColoramaPrinter():
    Color = ColoramaPrinter(output=BasicPrinter())
    print(Color.ERROR)
    print(Color.SUCCESS)
    print(Color.ADDED_LINE)
    print(Color.REMOVED_LINE)

if __name__ == "__main__":
    test_ColoramaPrinter()

# Generated at 2022-06-23 20:28:49.334103
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    class MyTty(object):
        def __init__(self):
            self.contents = ""
        def write(self, contents):
            self.contents += contents
        def readlines(self):
            return self.contents.splitlines(keepends=True)
    tty = MyTty()
    printer = BasicPrinter(tty)
    printer.diff_line("1\n")
    assert tty.readlines() == ["1\n"]
    printer.diff_line("2\n")
    assert tty.readlines() == ["1\n", "2\n"]


# Generated at 2022-06-23 20:28:50.793689
# Unit test for function format_natural
def test_format_natural():
    result = format_natural("import os")
    assert result == "import os"


# Generated at 2022-06-23 20:28:54.025927
# Unit test for method error of class BasicPrinter
def test_BasicPrinter_error():
    printer = BasicPrinter()
    assert printer.ERROR == "ERROR"
    assert printer.SUCCESS == "SUCCESS"

# Generated at 2022-06-23 20:29:00.101009
# Unit test for constructor of class ColoramaPrinter
def test_ColoramaPrinter():
    printer = ColoramaPrinter()
    # Note: these tests will fail if Colorama is not installed
    assert printer.ERROR == colorama.Fore.RED + "ERROR" + colorama.Style.RESET_ALL
    assert printer.SUCCESS == colorama.Fore.GREEN + "SUCCESS" + colorama.Style.RESET_ALL
    assert printer.ADDED_LINE == colorama.Fore.GREEN
    assert printer.REMOVED_LINE == colorama.Fore.RED

# Generated at 2022-06-23 20:29:11.486265
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    try:
        import colorama
    except ImportError:
        return
    # Check the style of added lines
    printer = ColoramaPrinter(output=StringIO())
    printer.diff_line("+import os")
    result = printer.output.getvalue()
    assert result.startswith(colorama.Fore.GREEN)
    # Check the style of removed lines
    printer = ColoramaPrinter(output=StringIO())
    printer.diff_line("-import os")
    result = printer.output.getvalue()
    assert result.startswith(colorama.Fore.RED)
    # Check the style of normal lines
    printer = ColoramaPrinter(output=StringIO())
    printer.diff_line(" import os")
    result = printer.output.getvalue()

# Generated at 2022-06-23 20:29:23.135541
# Unit test for function remove_whitespace
def test_remove_whitespace():
    assert remove_whitespace("") == ""
    assert remove_whitespace("\n") == ""
    assert remove_whitespace(" \n") == ""
    assert remove_whitespace(" \n ") == ""
    assert remove_whitespace(" \n\r", line_separator="\r") == ""
    assert remove_whitespace("\n\n\n") == ""
    assert remove_whitespace(" \n\n\n") == ""
    assert remove_whitespace(" \n\n\n\n") == ""
    assert remove_whitespace(" \n\n\n\n ") == ""
    assert remove_whitespace(" \n\n\n\n ", line_separator="\t") == "\t"

# Generated at 2022-06-23 20:29:24.562512
# Unit test for function format_simplified
def test_format_simplified():
    assert format_simplified('from os import path') == 'os.path'


# Generated at 2022-06-23 20:29:31.104693
# Unit test for function show_unified_diff
def test_show_unified_diff():
    import io

    # Colorama is not installed in the test environment and trying to use
    # it will trigger an exception, so this unit test only validates if
    # the output without color is correct
    color_output = False
    output = io.StringIO()
    show_unified_diff(
        file_input="1\n2\n3\n4\n5",
        file_output="4\n5\n6\n7\n8\n9\n10",
        file_path=None,
        output=output,
        color_output=color_output,
    )

# Generated at 2022-06-23 20:29:37.156340
# Unit test for method style_text of class ColoramaPrinter
def test_ColoramaPrinter_style_text():
    printer = ColoramaPrinter()
    assert printer.style_text("test-text") == "test-text"

    assert printer.style_text("test-text", colorama.Fore.GREEN) == "\x1b[32mtest-text\x1b[0m"
    assert printer.style_text("test-text", colorama.Fore.RED) == "\x1b[31mtest-text\x1b[0m"

# Generated at 2022-06-23 20:29:42.799086
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    import_file = "tests/test_data/.import.py"
    file_path = Path(import_file)
    with file_path.open() as file_pointer:
        file_input = file_pointer.read()
    file_output = file_input.replace("isort", "\tfile_output")
    printer = ColoramaPrinter()
    unified_diff_lines = unified_diff(
        file_input.splitlines(keepends=False),
        file_output.splitlines(keepends=False),
    )
    for line in unified_diff_lines:
        printer.diff_line(line)

# Generated at 2022-06-23 20:29:48.359729
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    from io import StringIO
    output = StringIO()
    bp = BasicPrinter(output)
    bp.diff_line("this is a line")
    assert output.getvalue() == "this is a line"
    bp.diff_line("this is another line")
    assert output.getvalue() == "this is a linethis is another line"


# Generated at 2022-06-23 20:29:56.148159
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    # Initialize a ColoramaPrinter
    colorama_printer = ColoramaPrinter()
    # Calling method diff_line, argument line = '+'
    result_1 = colorama_printer.diff_line('+')
    # Calling method diff_line, argument line = '+'
    result_2 = colorama_printer.diff_line('+')
    # Assert the result
    assert result_1 == result_2, 'ColoramaPrinter.diff_line() method FAILED'
    assert result_1 == '\x1b[32m+\x1b[0m', 'ColoramaPrinter.diff_line() method FAILED'
    # Print test result
    print('ColoramaPrinter.diff_line() method PASSED')

# Generated at 2022-06-23 20:30:06.492558
# Unit test for function show_unified_diff
def test_show_unified_diff():
    from textwrap import dedent
    file_input = dedent("""
    from A import X
    import B
    """)
    file_output = dedent("""
    from A import X, Y
    from C.D import Z
    from E import J
    """)
    file_path = Path("file-name")
    output = StringIO()
    expected_output = dedent("""
    --- file-name:before
    +++ file-name:after
    +from A import X, Y
    +
    +from C.D import Z
    +
    +from E import J
    """)
    show_unified_diff(file_input=file_input,
                      file_output=file_output,
                      file_path=file_path,
                      output=output)

# Generated at 2022-06-23 20:30:11.359312
# Unit test for function format_natural
def test_format_natural():
    natural_format = format_natural("from django.contrib.auth import get_user_model")
    assert natural_format == "from django.contrib.auth import get_user_model"
    natural_format = format_natural("import django.contrib.auth.get_user_model")
    assert natural_format == "from django.contrib.auth import get_user_model"

# Generated at 2022-06-23 20:30:15.064214
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    output = StringIO()
    printer = BasicPrinter(output)
    printer.success("abc")
    assert "SUCCESS: abc" in output.getvalue()


# Generated at 2022-06-23 20:30:19.581541
# Unit test for function format_natural
def test_format_natural():
    assert format_natural("import a") == "import a"
    assert format_natural("import b") == "import b"
    assert format_natural("a") == "import a"
    assert format_natural("a.b") == "from a import b"
    assert format_natural("a.b.c") == "from a.b import c"


# Generated at 2022-06-23 20:30:25.648807
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    out = sys.stdout
    try:
        sys.stdout = io.StringIO()
        printer = BasicPrinter(None)
        printer.success('test')
        sys.stdout.seek(0)
        assert sys.stdout.read() == 'SUCCESS: test\n'
    finally:
        sys.stdout = out


# Generated at 2022-06-23 20:30:33.697853
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    from io import StringIO
    from isort.settings import Config
    from tests.test_utils import get_test_resources_path


    config = Config(
        line_length=79,
        known_first_party=["isort"],
        known_third_party=["colorama", "mock"],
        multi_line_output=Config.MULTI_LINE_FINAL,
    )
    file_path = get_test_resources_path("text_files/text_with_class.py")
    with open(file_path) as f:
        file_content = f.read()
    new_file_content = file_content + "\n"

# Generated at 2022-06-23 20:30:34.993036
# Unit test for constructor of class BasicPrinter
def test_BasicPrinter():
    output = sys.stdout
    BasicPrinter(output)


# Generated at 2022-06-23 20:30:37.204084
# Unit test for constructor of class ColoramaPrinter
def test_ColoramaPrinter():
    printer = ColoramaPrinter()
    assert printer.ERROR.startswith(colorama.Fore.RED)
    assert printer.SUCCESS.startswith(colorama.Fore.GREEN)

# Generated at 2022-06-23 20:30:44.345246
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    file_path = "path/to/file.py"
    input_yes = ["yes", "y", "y\n"]
    input_no = ["no", "n", "n\n"]
    for ans in input_yes:
        with patch("builtins.input", return_value=ans):
            assert ask_whether_to_apply_changes_to_file(file_path)
    for ans in input_no:
        with patch("builtins.input", return_value=ans):
            assert not ask_whether_to_apply_changes_to_file(file_path)

# Generated at 2022-06-23 20:30:50.860663
# Unit test for function format_simplified
def test_format_simplified():
    assert format_simplified("from foo import bar") == "foo.bar"
    assert format_simplified("import foo") == "foo"
    assert format_simplified("    from foo import bar as baz") == "foo.bar as baz"
    assert format_simplified("import asyncio as async_") == "asyncio as async_"
    assert format_simplified("from . import foo") == ".foo"
    assert format_simplified(".foo") == ".foo"
    assert format_simplified("from . import foo, bar, baz") == ".foo, .bar, .baz"
    assert format_simplified("from . import foo as bar") == ".foo as bar"

# Generated at 2022-06-23 20:30:53.659547
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    printer = BasicPrinter()
    message = "Test success"
    printer.success(message)
    assert True


# Generated at 2022-06-23 20:31:02.835287
# Unit test for function show_unified_diff
def test_show_unified_diff():
    from io import StringIO

    file_input = """import sys
from datetime import datetime
from typing import Optional, TextIO

import colorama

ADDED_LINE_PATTERN = re.compile(r"\+[^+]")
REMOVED_LINE_PATTERN = re.compile(r"-[^-]")
"""
    file_output = """import sys
from datetime import datetime

import colorama
from typing import Optional, TextIO

ADDED_LINE_PATTERN = re.compile(r"\+[^+]")
REMOVED_LINE_PATTERN = re.compile(r"-[^-]")
"""
    output = StringIO()

# Generated at 2022-06-23 20:31:08.666000
# Unit test for method style_text of class ColoramaPrinter
def test_ColoramaPrinter_style_text():
    colorama_printer = ColoramaPrinter()
    assert colorama_printer.style_text("mytext") == 'mytext'
    assert colorama_printer.style_text("mytext", colorama.Fore.GREEN) == '\x1b[32mmytext\x1b[0m'
    assert colorama_printer.style_text("mytext", colorama.Fore.RED) == '\x1b[31mmytext\x1b[0m'
    assert colorama_printer.style_text("mytext", colorama.Fore.YELLOW) == '\x1b[33mmytext\x1b[0m'


# Generated at 2022-06-23 20:31:12.741299
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    buffer = io.StringIO()
    printer = BasicPrinter(output=buffer)
    printer.success("test_message")
    assert buffer.getvalue() == "SUCCESS: test_message\n"

# Generated at 2022-06-23 20:31:15.577673
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    if not colorama_unavailable:
        assert isinstance(create_terminal_printer(True), ColoramaPrinter)
    assert isinstance(create_terminal_printer(False), BasicPrinter)

# Generated at 2022-06-23 20:31:20.075428
# Unit test for method style_text of class ColoramaPrinter
def test_ColoramaPrinter_style_text():
    assert ColoramaPrinter.style_text("TEXT", colorama.Fore.GREEN) == "\x1b[92mTEXT\x1b[0m"

# Generated at 2022-06-23 20:31:22.839249
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    with io.StringIO() as f:
        output = f
        BasicPrinter(output).success("")
        assert f.getvalue()=="SUCCESS: {}\n"


# Generated at 2022-06-23 20:31:26.224863
# Unit test for method style_text of class ColoramaPrinter
def test_ColoramaPrinter_style_text():
    printer = ColoramaPrinter()
    assert printer.style_text('hi') == 'hi'
    assert printer.style_text('hi', None) == 'hi'
    assert printer.style_text('hi', '\x1b[32m') == '\x1b[32mhi\x1b[0m'

# Generated at 2022-06-23 20:31:28.016327
# Unit test for method error of class BasicPrinter
def test_BasicPrinter_error():
    b = BasicPrinter()
    assert b.error("error") is None
    assert b.error("error") != print("error")

# Generated at 2022-06-23 20:31:33.110143
# Unit test for method error of class BasicPrinter
def test_BasicPrinter_error():
    print("Test BasicPrinter.error")
    output = io.StringIO()
    expected_output = "ERROR: test error message\n"
    printer = BasicPrinter(output=output)
    printer.error("test error message")
    assert expected_output == output.getvalue()


# Generated at 2022-06-23 20:31:35.070142
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert(ask_whether_to_apply_changes_to_file('test') == True)

# Generated at 2022-06-23 20:31:39.923351
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    _out, sys.stdout = sys.stdout, StringIO()
    try:
        printer = BasicPrinter()
        printer.success("everything ok")
        assert sys.stdout.getvalue().strip() == "SUCCESS: everything ok"
    finally:
        sys.stdout.close()
        sys.stdout = _out


# Generated at 2022-06-23 20:31:41.482815
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    assert BasicPrinter(output=sys.stdout).success("Success") is None


# Generated at 2022-06-23 20:31:44.107887
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    printer = BasicPrinter()
    output = StringIO()
    printer.output = output
    printer.diff_line('-import b\n')
    assert output.getvalue() == '-import b\n'


# Generated at 2022-06-23 20:31:44.786499
# Unit test for method error of class BasicPrinter
def test_BasicPrinter_error():
    printer = BasicPrinter()
    printer.error("Test")
    assert True

# Generated at 2022-06-23 20:31:56.214017
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    # Example of a diff output.
    diff_output_lines = [
        "--- /home/user/file.py:before        2019-09-13 21:35:48.606918337 +0300\n",
        "+++ /home/user/file.py:after         2019-09-13 21:35:48.606918337 +0300\n",
        "@@ -1,3 +1,3 @@\n",
        "-import os\n",
        "+import sys\n",
        " import random\n",
        " import other_module\n",
        "-import sys\n",
    ]
    # Expected output for diff_line method.
    expected_output = diff_output_lines[0] + diff_output_lines[1] + diff_output_lines[2]
    expected_output

# Generated at 2022-06-23 20:31:57.666580
# Unit test for function format_natural
def test_format_natural():
    assert format_natural('import a') == 'import a'
    assert format_natural('import a.b') == 'from a import b'

# Generated at 2022-06-23 20:32:03.802813
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    import io

    class Dummy:
        pass

    output = Dummy()
    output.write = lambda line: None

    colorama_printer = ColoramaPrinter(output)

    assert colorama_printer.diff_line('+1') == colorama.Fore.GREEN + '1' + colorama.Style.RESET_ALL
    assert colorama_printer.diff_line('-1') == colorama.Fore.RED + '1' + colorama.Style.RESET_ALL
    assert colorama_printer.diff_line('anything') == 'anything'

# Generated at 2022-06-23 20:32:14.852551
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    import io
    import sys
    old_out = sys.stdout
    sys.stdout = stream = io.StringIO()

    class BasicPrinter_test():
        def __init__(self):
            self.output = stream
        def success(self, message):
            print(f"{self.SUCCESS}: {message}", file=self.output)
        def error(self, message):
            print(f"{self.ERROR}: {message}", file=sys.stderr)
        def diff_line(self, line):
            self.output.write(line)

    b = BasicPrinter_test()
    b.success("success")
    assert stream.getvalue() == "SUCCESS: success\n"

    stream.close()
    sys.stdout = old_out


# Generated at 2022-06-23 20:32:19.200413
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    # Code coverage does not include the execution of the method diff_line
    # because it requires to override the colorama object
    printer = ColoramaPrinter()
    printer.diff_line("     ^^")
    printer.diff_line('+   "A": 1')
    printer.diff_line('-  "B": 2')

# Generated at 2022-06-23 20:32:28.453482
# Unit test for function show_unified_diff
def test_show_unified_diff():
    import io
    import_lines = ["from  my_package import ModuleA", "import  my_package.ModuleB"]
    file_input: str = "\n".join(import_lines) + "\n"
    file_output: str = "\n".join(import_lines[::-1]) + "\n"
    output = io.StringIO()
    show_unified_diff(
        file_input=file_input,
        file_output=file_output,
        file_path=None,
        output=output,
        color_output=True
    )

# Generated at 2022-06-23 20:32:33.864288
# Unit test for function format_natural
def test_format_natural():
    assert format_natural("import foo") == "import foo"
    assert format_natural("from foo import bar") == "from foo import bar"
    assert format_natural("from foo.bar import biz") == "from foo.bar import biz"
    assert format_natural("foo") == "import foo"
    assert format_natural("foo.bar") == "from foo import bar"


# Generated at 2022-06-23 20:32:37.498191
# Unit test for method error of class BasicPrinter
def test_BasicPrinter_error():
    printer = BasicPrinter()
    sys.stderr.write("BasicPrinter error: ")
    printer.error("basic")
    assert True


# Generated at 2022-06-23 20:32:43.182119
# Unit test for function show_unified_diff
def test_show_unified_diff():
    from io import StringIO
    from unittest import mock
    from isort.util import show_unified_diff

    expected = r'''
-import unittest
+import unittest
+import os


-def test_add_argument_file_input(self):
+def test_add_argument_file_input(self):
+    return os.path.
+
+
-def test_simple_arguments(self):
+def test_simple_arguments(self):
+    """
'''


# Generated at 2022-06-23 20:32:44.526616
# Unit test for function format_natural
def test_format_natural():
    assert "from a import b" == format_natural("a.b")


# Generated at 2022-06-23 20:32:48.573101
# Unit test for method error of class BasicPrinter
def test_BasicPrinter_error():
    error_message = "This is a test-error message"
    error_message_with_prefix = "ERROR: This is a test-error message"

    bp = BasicPrinter()
    bp.error(error_message)
    assert sys.stderr.getvalue().rstrip() == error_message_with_prefix



# Generated at 2022-06-23 20:32:55.513078
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    import unittest.mock

    def run_test(test_input, expected_result):
        printer = ColoramaPrinter()
        with unittest.mock.patch("sys.stdout", new=unittest.mock.MagicMock()) as mock_stdout:
            printer.diff_line(test_input)
            assert mock_stdout.write.called
            mock_stdout.write.assert_called_with(expected_result)

    run_test("+TEST", "TEST")
    run_test("+TEST+", "TEST+")
    run_test("+TEST+\n", "TEST+\n")
    run_test("-TEST", "TEST")
    run_test("-TEST-", "TEST-")

# Generated at 2022-06-23 20:32:59.849602
# Unit test for function format_natural
def test_format_natural():
    assert format_natural("import os") == "import os"
    assert format_natural("from pathlib import Path") == "from pathlib import Path"
    assert format_natural("os") == "import os"
    assert format_natural("pathlib.Path") == "from pathlib import Path"


# Generated at 2022-06-23 20:33:04.961220
# Unit test for function remove_whitespace
def test_remove_whitespace():
    assert remove_whitespace("a\nb") == "ab"
    assert remove_whitespace("a\nb", ".") == "a.b"
    assert remove_whitespace("a \tb") == "ab"
    assert remove_whitespace("a  b") == "ab"
    assert remove_whitespace("a \x0c b") == "ab"

# Generated at 2022-06-23 20:33:08.695934
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    # Create BasicPrinter object
    bp = BasicPrinter()
    # Set variables used to check the function
    message = "Success"
    print_value = "SUCCESS: Success"
    # Execute function to test
    bp.success(message)
    # Check if the function returned the correct value
    assert sys.stdout.getvalue().strip() == print_value


# Generated at 2022-06-23 20:33:13.436337
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    output = sys.stdout
    bp = BasicPrinter(output=output)
    test_lines = [
        "   hello world\n",
        "+ hello\n",
        "- world\n",
    ]
    for line in test_lines:
        bp.diff_line(line)



# Generated at 2022-06-23 20:33:16.222614
# Unit test for method style_text of class ColoramaPrinter
def test_ColoramaPrinter_style_text():
    color = True
    output = None
    printer = create_terminal_printer(color, output)
    text = "Test"
    style = colorama.Fore.GREEN
    result = printer.style_text(text, style)
    expected = '\x1b[32mTest\x1b[0m'
    assert result == expected

# Generated at 2022-06-23 20:33:19.427384
# Unit test for function show_unified_diff
def test_show_unified_diff():
    import io

    stream = io.StringIO()
    show_unified_diff(
        file_input="""test1
test2
test3""",
        file_output="""test4
test5
test6""",
        file_path=None,
        output=stream,
    )
    diff = stream.getvalue()
    assert diff.count("\n") == 6



# Generated at 2022-06-23 20:33:23.505383
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    from io import StringIO
    from contextlib import contextmanager
    with mock_stream() as string_io:
        p = BasicPrinter(string_io)
        p.success("Hello World!")
        assert string_io.getvalue().rstrip() == "SUCCESS: Hello World!"


# Generated at 2022-06-23 20:33:34.256828
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    # test color and colorama available
    printer = create_terminal_printer(True)
    assert isinstance(printer, ColoramaPrinter)
    # test color not available but colorama available
    printer = create_terminal_printer(False)
    assert isinstance(printer, BasicPrinter)
    # test color is unset and colorama available
    printer = create_terminal_printer()
    assert isinstance(printer, BasicPrinter)
    # test color is unset and colorama not available
    from isort.settings import DEFAULT_USE_COLOR
    with mock.patch("isort.utils.colorama.init") as mock_colorama:
        mock_colorama.side_effect = ImportError
        printer = create_terminal_printer()
        assert isinstance(printer, BasicPrinter)

# Generated at 2022-06-23 20:33:40.974401
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    if colorama_unavailable:
        try:
            create_terminal_printer(True)
            assert False, 'create_terminal_printer did not throw an exception'
        except SystemExit:
            # raises an exception when colorama is not installed
            pass
    else:
        coloramaPrinter = create_terminal_printer(True)
        basicPrinter = create_terminal_printer(False)
        assert isinstance(coloramaPrinter, ColoramaPrinter)
        assert isinstance(basicPrinter, BasicPrinter)

# Generated at 2022-06-23 20:33:46.925945
# Unit test for function format_natural
def test_format_natural():
    assert "import abc" == format_natural("import abc")
    assert "import abcdef" == format_natural("import abcdef")
    assert "import abcdef" == format_natural("import abcdef ")
    assert "import abcdef" == format_natural(" import abcdef ")
    assert "from abc import defg" == format_natural("abc.defg")

# Generated at 2022-06-23 20:33:47.860537
# Unit test for constructor of class ColoramaPrinter
def test_ColoramaPrinter():
    printer = ColoramaPrinter()
    assert printer != None

# Generated at 2022-06-23 20:33:55.510952
# Unit test for function show_unified_diff
def test_show_unified_diff():
    import io
    from pathlib import Path
    from subprocess import run
    from tempfile import NamedTemporaryFile

    def check_output(input_content, output_content, file_path, color_output):
        with NamedTemporaryFile() as tmp_file:
            tmp_file.write(input_content.encode("utf8"))
            tmp_file.flush()
            tmp_file.file.seek(0)
            with io.StringIO() as tmp_output:
                show_unified_diff(
                    file_input=input_content,
                    file_output=output_content,
                    output=tmp_output,
                    file_path=Path(tmp_file.name),
                    color_output=color_output,
                )

# Generated at 2022-06-23 20:34:05.009434
# Unit test for function format_natural
def test_format_natural():
    assert format_natural("from x import y") == "from x import y"
    assert format_natural("from x import y, z") == "from x import y, z"
    assert format_natural("from x import (y, z)") == "from x import (y, z)"
    assert format_natural("from x import (y, z,)") == "from x import (y, z,)"
    assert format_natural("from x import (y, z\n)") == "from x import (y, z\n)"
    assert format_natural("from x import (\ny, z\n)") == "from x import (\ny, z\n)"
    assert format_natural("import a, b") == "import a, b"
    assert format_natural("import a, b, c") == "import a, b, c"


# Generated at 2022-06-23 20:34:08.916512
# Unit test for method diff_line of class ColoramaPrinter
def test_ColoramaPrinter_diff_line():
    printer = ColoramaPrinter()
    # diff_line method should highlight inserted line in green.
    assert printer.diff_line('+from package import module') == colorama.Fore.GREEN + '+from package import module' + colorama.Style.RESET_ALL
    # diff_line method should highlight removed line in red.
    assert printer.diff_line('-from package import module') == colorama.Fore.RED + '-from package import module' + colorama.Style.RESET_ALL

# Generated at 2022-06-23 20:34:13.234776
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert isinstance(create_terminal_printer(color=False), BasicPrinter)
    assert isinstance(create_terminal_printer(color=True), ColoramaPrinter)



# Generated at 2022-06-23 20:34:15.160378
# Unit test for constructor of class BasicPrinter
def test_BasicPrinter():
    bp = BasicPrinter()
    assert bp.output == sys.stdout
    bp = BasicPrinter(output=sys.stderr)
    assert bp.output == sys.stderr


# Generated at 2022-06-23 20:34:18.476388
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert isinstance(create_terminal_printer(color=False), BasicPrinter)
    assert isinstance(create_terminal_printer(color=True), ColoramaPrinter)

# Generated at 2022-06-23 20:34:24.453819
# Unit test for function format_simplified
def test_format_simplified():
    # Simple imports
    assert format_simplified("import os") == "os"
    assert format_simplified("import random as random") == "random"

    # Import with star
    assert format_simplified("from random import *") == "random.*"
    assert format_simplified("from random import *, random as new_random") == "random.*, new_random"

    # Import with multiline
    lines = format_simplified("""from random import (chance,
                                        random as new_random)""")[:-1]
    assert lines == "random.chance,\n           random.new_random"

# Generated at 2022-06-23 20:34:33.881545
# Unit test for function format_natural
def test_format_natural():
    """Testing the funciton format_natural"""
    assert format_natural('import abc') == 'import abc'
    assert format_natural('import abc, def') == 'import abc, def'
    assert format_natural('import abc.def') == 'from abc import def'
    assert format_natural('from abc import def') == 'from abc import def'
    assert format_natural('from abc.def import ghi') == 'from abc.def import ghi'
    assert format_natural('from abc.def import ghi, jkl') == 'from abc.def import ghi, jkl'
    assert format_natural('abc.def') == 'from abc import def'
    assert format_natural('abc') == 'import abc'

# Generated at 2022-06-23 20:34:36.496818
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    assert(create_terminal_printer(False, None).__class__.__name__ == "BasicPrinter")
    assert(create_terminal_printer(True, None).__class__.__name__ == "ColoramaPrinter")


# Generated at 2022-06-23 20:34:42.385960
# Unit test for function format_simplified
def test_format_simplified():
    assert format_simplified(' import os') == 'os'
    assert format_simplified('import os') == 'os'
    assert format_simplified(' from os import path') == 'os.path'
    assert format_simplified('from os import path') == 'os.path'
    assert format_simplified(' from os.path import join') == 'os.path.join'
    assert format_simplified('from os.path import join') == 'os.path.join'


# Generated at 2022-06-23 20:34:46.517652
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    stream = io.StringIO()
    basic_printer = BasicPrinter(stream)
    line = "- This is a test"
    basic_printer.diff_line(line)
    stream.seek(0)
    assert stream.read() == "- This is a test"


# Generated at 2022-06-23 20:34:54.580985
# Unit test for method diff_line of class BasicPrinter
def test_BasicPrinter_diff_line():
    old = "from flask import Flask"
    new = "from flask import Flask, render_template"

    printer = create_terminal_printer(None)
    output = io.StringIO()
    printer.output = output
    unified_diff_lines = unified_diff(
        old.splitlines(keepends=True),
        new.splitlines(keepends=True),
        fromfile="fromfile",
        tofile="tofile",
        fromfiledate="fromfiledate",
        tofiledate="tofiledate",
    )
    for line in unified_diff_lines:
        printer.diff_line(line)
    assert "--- fromfile\tfromfiledate" in output.getvalue()

# Generated at 2022-06-23 20:35:03.653447
# Unit test for function format_simplified
def test_format_simplified():
    import pytest
    assert format_simplified("    from .foo import Bar") == ".foo.Bar"
    assert format_simplified("from .foo import Bar") == ".foo.Bar"
    assert format_simplified("from .foo import Bar, Foo, bar") == ".foo.Bar, .foo.Foo, .foo.bar"
    assert format_simplified("from .foo import bar as bar") == ".foo.bar"
    assert format_simplified("from .foo import bar as baz") == ".foo.bar"
    assert format_simplified("from .foo import *") == ".foo.*"
    assert format_simplified("import foo") == "foo"
    assert format_simplified("import foo, bar.baz") == "foo, bar.baz"
    assert format_simpl

# Generated at 2022-06-23 20:35:08.507668
# Unit test for function remove_whitespace
def test_remove_whitespace():
    input_string = "a\tb\n\n\r\r\r\r \r\r\r\r\r  c\r\r \r\r\r\r\r\r\f  \f\f\f\f"
    expected_output = "abcc"
    output = remove_whitespace(input_string)
    assert output == expected_output

# Generated at 2022-06-23 20:35:11.486408
# Unit test for method success of class BasicPrinter
def test_BasicPrinter_success():
    from io import StringIO
    output = StringIO()
    printer = BasicPrinter(output)

    printer.success("Hello World")

    assert output.getvalue() == "SUCCESS: Hello World\n"


# Generated at 2022-06-23 20:35:14.572425
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    color = True
    output = sys.stdout
    assert create_terminal_printer(color, output) is ColoramaPrinter(output)

    color = False
    output = sys.stdout
    assert create_terminal_printer(color, output) is BasicPrinter(output)

# Generated at 2022-06-23 20:35:17.568482
# Unit test for function create_terminal_printer
def test_create_terminal_printer():
    if not colorama_unavailable:
        assert isinstance(create_terminal_printer(True), ColoramaPrinter)
    assert isinstance(create_terminal_printer(False), BasicPrinter)



# Generated at 2022-06-23 20:35:19.174624
# Unit test for function ask_whether_to_apply_changes_to_file
def test_ask_whether_to_apply_changes_to_file():
    assert ask_whether_to_apply_changes_to_file("test_path")