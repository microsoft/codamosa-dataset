

# Generated at 2022-06-22 07:37:11.006142
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case = GlideIE(GlideIE._TEST)
    assert test_case._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test_case.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:37:20.595734
# Unit test for constructor of class GlideIE
def test_GlideIE():
    new_GlideIE = GlideIE()
    assert new_GlideIE.IE_NAME == 'glide'
    assert new_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:32.106149
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:37:32.782082
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:35.492599
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:37:38.175587
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-22 07:37:40.271118
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_instance = GlideIE()
    assert test_instance

# Generated at 2022-06-22 07:37:44.780968
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_cases = [
        {
            'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
        }
    ]
    for test_case in test_cases:
        GlideIE().extract(test_case)
    pass

# Generated at 2022-06-22 07:37:47.798528
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test the constructor of class GlideIE"""
    glide_ie = GlideIE()


# Generated at 2022-06-22 07:37:48.337850
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-22 07:38:01.385160
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Define GlideIE class instance "ie"
	ie = GlideIE()
	# Define valid url
	test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	# Execute _real_extract method
	ie._real_extract(test_url)

# Generated at 2022-06-22 07:38:07.139030
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    print("Successfully created GlideIE instance with URL: {}".format(obj.url))

if __name__ == "__main__":
    test_GlideIE()

# Generated at 2022-06-22 07:38:08.597936
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE.__name__ == 'GlideIE'


# Generated at 2022-06-22 07:38:13.613648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Unit test for Glide IE constructor """
    info_extractor = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    info_extractor.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:38:15.881196
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert('common/GlideIE' == ie.IE_NAME)

# Generated at 2022-06-22 07:38:18.880235
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME

# Generated at 2022-06-22 07:38:24.765141
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    ie = GlideIE();
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:27.567537
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:38:28.574114
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-22 07:38:29.132826
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test GlideIE constructor 
    GlideIE('GlideIE', '0')

# Generated at 2022-06-22 07:38:35.998244
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:38:39.102278
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    return

# Generated at 2022-06-22 07:38:41.438164
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:38:45.901637
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_NAME == 'Glide mobile video messages'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:38:46.965581
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_instance = GlideIE()



# Generated at 2022-06-22 07:38:56.481583
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie.is_suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True)
    assert(ie.is_suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=') == False)
    assert(ie.is_suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0') == False)

# Generated at 2022-06-22 07:38:59.670752
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    assert GlideIE().IE_DESC == GlideIE._TEST['info_dict']

# Generated at 2022-06-22 07:39:00.709311
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-22 07:39:11.505585
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\\-=_+]+)'

# Generated at 2022-06-22 07:39:13.362237
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_instance_for_class_GlideIE = GlideIE()
    assert(test_instance_for_class_GlideIE)


# Generated at 2022-06-22 07:39:27.401015
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Unit test for constructor of class GlideIE
    '''
    GlideIE()

# Generated at 2022-06-22 07:39:31.054413
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(InfoExtractor)._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert False

# Generated at 2022-06-22 07:39:38.933524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    

# Generated at 2022-06-22 07:39:49.504636
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:01.370871
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('GlideIE', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:06.830587
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:09.438568
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:12.691360
# Unit test for constructor of class GlideIE
def test_GlideIE():
  url = "http://share.glide.me/ZGX0k0qxRyW2b8hd4Jy1tA=="
  expected = GlideIE(url)
  assert expected

# Generated at 2022-06-22 07:40:23.771533
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert ie._TEST["url"] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST["md5"] == "4466372687352851af2d131cfaa8a4c7"
    assert ie._TEST["info_dict"]["id"] == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST["info_dict"]["ext"] == "mp4"

# Generated at 2022-06-22 07:40:33.402717
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:40:59.548323
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('foo', 'bar')

# Generated at 2022-06-22 07:41:05.883470
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    url = ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert url['thumbnail'] == 'https://d2y5tu0bxtmmyb.cloudfront.net/share/UZF8zlmuQbe4mr+7dCiQ0w==.jpg'

# Generated at 2022-06-22 07:41:14.966896
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_id = 'glide'
    ie_dsc = 'Glide mobile video messages (glide.me)'
    ie_valid_url = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:18.781111
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-22 07:41:26.356239
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	assert obj.IE_NAME == 'Glide'
	assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert obj.BRAND == 'Glide'



# Generated at 2022-06-22 07:41:28.798150
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:41:35.144464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert hasattr(ie, "IE_DESC"), "GlideIE: The description of the IE must be set"
    assert hasattr(ie, "_VALID_URL"), "GlideIE: The _VALID_URL class attribute must be set"
    assert hasattr(ie, "_TEST"), "GlideIE: The _TEST dict must be set"

# Generated at 2022-06-22 07:41:39.872528
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:41:50.291175
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:41:55.812686
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Initializes class to be tested
	test_obj = GlideIE()
	# Assigns values to the instance variables
	test_obj._downloader = "Downloader"
	test_obj._match_id = "id"
	test_obj._html_search_regex = "search_regex"
	test_obj._proto_relative_url = "relative_url"
	test_obj._search_regex = "regex"
	# Validates instance variables
	assert test_obj._downloader == "Downloader"
	assert test_obj._match_id == "id"
	assert test_obj._html_search_regex == "search_regex"
	assert test_obj._proto_relative_url == "relative_url"
	assert test_obj._search_regex == "regex"
#

# Generated at 2022-06-22 07:42:57.445631
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE("GlideIE")

# Generated at 2022-06-22 07:43:08.510607
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:43:09.539010
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:43:12.496449
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-22 07:43:16.156246
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:43:17.359183
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj


# Generated at 2022-06-22 07:43:17.935809
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:43:22.547283
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE().extract(
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(info)

# Generated at 2022-06-22 07:43:31.665589
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from inspect import isclass
    import warnings
    from youtube_dl.extractor.glide import GlideIE
    assert isclass(GlideIE)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        obj = GlideIE(u'http://www.youtube.com/watch?v=BaW_jenozKc')
        assert obj.ie_key() == u'Glide'

    # test responsiveness of GlideIE to incorrect urls
    assert obj.suitable(u'https://www.hbo.com/game-of-thrones') == False
    assert obj.suitable(u'https://www.hbo.com/documentaries/kurt-cobain-montage-of-heck') == False

# Generated at 2022-06-22 07:43:34.672835
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide = GlideIE()
    assert 'glide' == glide._match_id(url)


# Generated at 2022-06-22 07:45:59.036697
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE._TEST['url'] == GlideIE()._TEST['url'])
    assert (GlideIE._TEST['md5'] == GlideIE()._TEST['md5'])

# Generated at 2022-06-22 07:46:00.788436
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor)._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-22 07:46:03.763195
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url)
    assert True

# Generated at 2022-06-22 07:46:13.853398
# Unit test for constructor of class GlideIE
def test_GlideIE():
    id  = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    input_url = 'http://share.glide.me/'+id

    constructor = GlideIE()
    instance = constructor._real_extract(input_url)
    # instance = constructor.test_GlideIE()

    assert(instance['id'] == id)
    assert(instance['title'] == "Damon's Glide message")

# Generated at 2022-06-22 07:46:23.494090
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE_DESC = 'Glide mobile video messages (glide.me)'
    VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:46:33.526106
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:46:44.848044
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert(glide.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    # test _TEST
    assert(glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(glide._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')

# Generated at 2022-06-22 07:46:45.682739
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, InfoExtractor)

# Generated at 2022-06-22 07:46:49.650192
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for constructor of class GlideIE
    #
    # Create a new instance of GlideIE
    #
    # Returns a new instance of GlideIE
    instance = GlideIE()

# Generated at 2022-06-22 07:46:50.443524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None, None).assertTrue(True)