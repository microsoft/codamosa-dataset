

# Generated at 2022-06-22 07:37:06.820278
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE()._VALID_URL ==
           'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-22 07:37:09.289088
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from . import GlideIE
    assert "object" == type(GlideIE).__name__

# Generated at 2022-06-22 07:37:10.949732
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:37:13.148903
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == GlideIE.IE_DESC

# Generated at 2022-06-22 07:37:15.340813
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:37:16.625411
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:19.292987
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:27.302132
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert (GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert (GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
    assert (GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert (GlideIE._TEST['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-22 07:37:32.987987
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:37:44.629062
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import unittest

    # Creating a subclass of unittest.TestCase
    class TestGlideIE(unittest.TestCase):
        def setUp(self):
            self.ie = GlideIE()
            self.test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
            self.test_video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:37:49.834123
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:37:54.376289
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide_test = GlideIE()

    info_dict = glide_test._real_extract(url)
    assert info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info_dict['url'] == 'https://vc.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==.mov'

# Generated at 2022-06-22 07:38:02.846121
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None).check_IE_name()
    # test for content-type = application/json
    GlideIE(None)._download_webpage(
        url='https://share.glide.me/M5aE+1HWQ2CxKxq3JqkU6A==',
        video_id='None')
    # test for content-type = text/html
    GlideIE(None)._download_webpage(
        url='https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        video_id='None')

# Generated at 2022-06-22 07:38:14.303951
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:38:20.000762
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print("Testing GlideIE")
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:38:21.212277
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert type(GlideIE()) == GlideIE

# Generated at 2022-06-22 07:38:26.234478
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # valid url
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # invalid URL
    assert not ie.suitable('http://share.glide.me/')

test_GlideIE()

# Generated at 2022-06-22 07:38:32.657984
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from os.path import dirname, join
    from py import test
    from .common import TEST_DATA_DIR

    test = GlideIE()

    file_test = join(dirname(dirname(dirname(__file__))), 'test')
    test.to_screen(file_test)

    file_input = join(TEST_DATA_DIR, 'glide_share.me.html')
    test.to_screen(file_input)

# Generated at 2022-06-22 07:38:36.323961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ele = GlideIE()
    assert ele._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:39.804458
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Test for attributes of class GlideIE
    assert(ie.IE_DESC)
    assert(ie._VALID_URL)
    assert(ie._TEST)


# Generated at 2022-06-22 07:38:56.023751
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Testing constructor of class GlideIE:
    ie = GlideIE()
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.extract_info("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }

# Generated at 2022-06-22 07:38:59.221835
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE(None)
    assert glide.IE_DESC is not None
    assert glide._VALID_URL is not None
    assert glide._TEST is not None

# Generated at 2022-06-22 07:39:10.464798
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from compat import compat_str
    from compat import compat_urllib_request
    from compat import compat_urllib_parse
    from compat import compat_urlparse
    from compat import compat_urllib_parse_urlparse
    from compat import compat_urllib_parse_urlunparse
    from compat import compat_urllib_parse_urlencode


    import video_url_resolver
    video_url_resolver.register_resolver('glide', 'glide')

    tester = video_url_resolver.UrlResolver()

# Generated at 2022-06-22 07:39:15.469069
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test GlideIE's constructor
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Should be able to return an instance of GlideIE
    assert isinstance(GlideIE(url), InfoExtractor)


# Generated at 2022-06-22 07:39:21.175868
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_instance = GlideIE()
    assert test_instance.IE_NAME == 'Glide'
    assert test_instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:39:23.245895
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') is True

# Generated at 2022-06-22 07:39:23.946336
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(GlideIE._VALID_URL)

# Generated at 2022-06-22 07:39:25.480400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie is not None


# Generated at 2022-06-22 07:39:29.528467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE(url)
    assert ie.get_url() == url

# Generated at 2022-06-22 07:39:33.110222
# Unit test for constructor of class GlideIE
def test_GlideIE():
    Glide = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    Glide.extract(url)

# Generated at 2022-06-22 07:39:57.425292
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    The purpose of this function is to check if the constructor of the class GlideIE
    works properly.
    """
    # Arrange
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    # Act
    glide_ie = GlideIE()

    # Assert
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:39:59.602007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == "GlideIE"


# Generated at 2022-06-22 07:40:10.667536
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:22.303538
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'Glide mobile video messages'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:32.389994
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide'
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:40:38.327683
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    glide_ie = GlideIE()
    glide_ie.download(test.get('url'))

# Generated at 2022-06-22 07:40:48.147228
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:40:51.667972
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert(instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-22 07:40:55.047175
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE == GlideIE.ie_key())
    assert(GlideIE.ie_key() == GlideIE().ie_key())
    assert(GlideIE.ie_key() == GlideIE.ie_key())

# Generated at 2022-06-22 07:40:55.904007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:41:35.649436
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE
    assert hasattr(class_, '_VALID_URL')
    assert hasattr(class_, 'IE_NAME')
    assert hasattr(class_, 'IE_DESC')
    assert hasattr(class_, '_TEST')

# Generated at 2022-06-22 07:41:39.271691
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:51.212353
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_desc = ie.IE_DESC
    valid_url = ie._VALID_URL
    test = ie._TEST

    assert ie_desc == 'Glide mobile video messages (glide.me)'
    assert valid_url == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:52.314198
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:41:54.553867
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE();
    assert(test_GlideIE.IE_NAME == 'Glide')

# Generated at 2022-06-22 07:41:55.218816
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:42:03.804843
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert(glideIE.IE_DESC)
    assert(glideIE._VALID_URL)
    assert(glideIE._TEST)
    assert(glideIE._TEST['url'])
    assert(glideIE._TEST['md5'])
    assert(glideIE._TEST['info_dict'])
    assert(glideIE._TEST['info_dict']['id'])
    assert(glideIE._TEST['info_dict']['ext'])
    assert(glideIE._TEST['info_dict']['title'])
    assert(glideIE._TEST['info_dict']['thumbnail'])


# Generated at 2022-06-22 07:42:05.897624
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test for valid constructor
    construct_test = GlideIE(GlideIE.IE_NAME)

# Generated at 2022-06-22 07:42:13.418711
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # Instance of GlideIE
    glide_ie = GlideIE()
    assert glide_ie._match_id(video_url) == video_id
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:42:16.770419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE()
    assert video.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:43:31.949008
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()

# Generated at 2022-06-22 07:43:34.778559
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:43:42.324305
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Given
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # When
    glide_ie = GlideIE()
    # Then
    assert glide_ie is not None
    assert glide_ie.IE_DESC is not None
    assert glide_ie._VALID_URL is not None
    assert glide_ie._TEST is not None
    assert glide_ie._real_extract is not None
    assert glide_ie._match_id is not None

# Generated at 2022-06-22 07:43:53.062409
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:43:57.520524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor.IE_NAME == 'Glide'
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:44:08.964687
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:44:16.693055
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test GlideIE constructor
    
    It should raise an error if any argument is missing
    """

    # Test with url
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    GlideIE(url)

    # Test with url and ie_key
    ie_key = 'Glide'
    GlideIE(ie_key, url)

    # Invalid arguments
    invalid_args = [[], {}, '', 0, None]
    for arg in invalid_args:
        try:
            GlideIE(arg, arg)
            assert False, "GlideIE constructor should fail if any argument is missing"
        except:
            pass



# Generated at 2022-06-22 07:44:18.256023
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-22 07:44:20.141517
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:44:22.620428
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'