

# Generated at 2022-06-22 07:37:05.103787
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:07.409384
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE().get_info(GlideIE._TEST['url'])

# Generated at 2022-06-22 07:37:08.852128
# Unit test for constructor of class GlideIE
def test_GlideIE():
# These arguments are intentionally unused.
    assert GlideIE('Glide')

# Generated at 2022-06-22 07:37:18.961265
# Unit test for constructor of class GlideIE
def test_GlideIE():
    my_info_extractor = GlideIE()
    my_webpage = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    my_video_id = my_info_extractor._match_id(my_webpage)
    my_webpage_content = my_info_extractor._download_webpage(my_webpage, my_video_id)
    my_title = my_info_extractor._html_search_regex(
        r'<title>(.+?)</title>', my_webpage_content,
        'title', default=None) or my_info_extractor._og_search_title(my_webpage_content)

# Generated at 2022-06-22 07:37:20.602095
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-22 07:37:23.016453
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test input is a string that contains http
    test = GlideIE('http')
    assert 'GlideIE' in str(test)

# Generated at 2022-06-22 07:37:28.630861
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:37:31.395132
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-22 07:37:33.751097
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download(url='http://www.glide.me/share/')

# Generated at 2022-06-22 07:37:39.462576
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Constructor test for class GlideIE"""
    expected_result = GlideIE(_downloader=None)
    result = GlideIE(_downloader=None)

    assert result.IE_DESC == expected_result.IE_DESC
    assert result._VALID_URL == expected_result._VALID_URL
    assert result._TEST == expected_result._TEST

# Generated at 2022-06-22 07:37:47.957873
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:37:59.222553
# Unit test for constructor of class GlideIE
def test_GlideIE():
    for constructor in (GlideIE, GlideIE.ie_key(), GlideIE()):
        result = constructor(dict(url='http://share.glide.me/37aDyw6UcT6UZT6EssmT6A=='))
        assert result.count('/') == result.count('\\') == 2
        assert result.endswith('.mp4"')
        assert '"url": "http://f.vimeocdn.com/p/4/000/049/1a5/49a5d1e.mp4"' in result
        assert '"title": "My Glide message"' in result
        assert '"id": "37aDyw6UcT6UZT6EssmT6A=="' in result
        assert '"thumbnail": ' in result

# Generated at 2022-06-22 07:38:08.317769
# Unit test for constructor of class GlideIE
def test_GlideIE():
    def mock_download_webpage(self, *args):
        self.assertTrue(args[0].startswith('http://share.glide.me'))
        self.assertIsInstance(args[1], basestring)

# Generated at 2022-06-22 07:38:10.605618
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_GlideIE = GlideIE
    assert class_GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:38:12.449536
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
# Test for member function _real_extract of class GlideIE

# Generated at 2022-06-22 07:38:19.379043
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$'}}

# Generated at 2022-06-22 07:38:31.079639
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This method tests the constructor of class GlideIE.
    """
    glide_ie = GlideIE(None)

    assert glide_ie.ie_key() == 'Glide'
    assert glide_ie.ie_desc() == "Glide mobile video messages (glide.me)"
    assert glide_ie.valid_url("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert not glide_ie.valid_url("https://facebook.com/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:38:32.552188
# Unit test for constructor of class GlideIE
def test_GlideIE():
  """Simple unit test for GlideIE constructor"""
  GlideIE()

# Generated at 2022-06-22 07:38:35.780329
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == ie._VALID_URL


# Generated at 2022-06-22 07:38:46.023587
# Unit test for constructor of class GlideIE
def test_GlideIE():
 
    # Success case
    
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:58.259497
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Unit tests for constructor of class GlideIE

# Generated at 2022-06-22 07:39:06.004935
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    # mpeg4 (mp4) is the only file format that I have seen supported by this site
    assert ie._WORKING == True
    
    

# Generated at 2022-06-22 07:39:07.810756
# Unit test for constructor of class GlideIE
def test_GlideIE():
	from glide import GlideIE
	assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-22 07:39:15.706962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Basic test for constructor of class GlideIE
    """
    testcases = [
        # Glide url
        ("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", "")
        ]
    for test in testcases:
        # Create object of GlideIE
        glide = GlideIE()
        # Compare the given url with get_video_info method
        assert test[0] == glide._real_extract(test[0])

# Generated at 2022-06-22 07:39:24.964926
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # object created with url 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide = GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')
    test_dict = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$'
    }
    assert glide._TEST == test_dict

# Generated at 2022-06-22 07:39:26.094295
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert type(obj) is GlideIE

# Generated at 2022-06-22 07:39:27.866967
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE()


# Generated at 2022-06-22 07:39:29.055909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test(GlideIE)

# Generated at 2022-06-22 07:39:40.288583
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    info = info_extractor._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    video_url = info.get("url")
    video_id = info.get("id")

    assert video_url == "http://cn.glide.me/video/UZF8zlmuQbe4mr+7dCiQ0w==.mp4?size=540p"
    assert video_id == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-22 07:39:41.480955
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-22 07:39:57.092223
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None, None)

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-22 07:39:59.359628
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert type(glide) == GlideIE


# Generated at 2022-06-22 07:40:01.181729
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w'

# Generated at 2022-06-22 07:40:02.340386
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:05.623843
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_extract('https://share.glide.me/O56Nw8fBQrOb6Y+Y6RVKew==')

# Generated at 2022-06-22 07:40:08.262450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:40:09.227301
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:40:12.134996
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Simple test for GlideIE
    """
    glide_test_object = GlideIE()
    assert glide_test_object.IE_NAME == 'glide'

# Generated at 2022-06-22 07:40:14.359204
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-22 07:40:15.007206
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:48.743048
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')
	assert(GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
	assert(GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	assert(GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
	assert(GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:40:53.876801
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'glide'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:40:57.699424
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    GlideIE()._real_extract(url)

    assert GlideIE.IE_DESC

# Generated at 2022-06-22 07:41:01.157151
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unittest is written with Python 3 in mind. The purpose is to test if
    # the constructor of class GlideIE is instantiable.
    one_instance = GlideIE(None)
    assert isinstance(one_instance, GlideIE)

# Generated at 2022-06-22 07:41:02.117380
# Unit test for constructor of class GlideIE
def test_GlideIE():
    construct_instance_for_testing(GlideIE)

# Generated at 2022-06-22 07:41:03.054461
# Unit test for constructor of class GlideIE
def test_GlideIE():
    help(GlideIE)

# Generated at 2022-06-22 07:41:03.959033
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC is not None

# Generated at 2022-06-22 07:41:13.911236
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['title'] == 'Damon\'s Glide message'
    assert info['url'] == '//d1v6bk1pg2wnew.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/UZF8zlmuQbe4mr+7dCiQ0w==.ke.mp4'

# Generated at 2022-06-22 07:41:23.750642
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'test')
    assert obj.IE_NAME == 'Glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:34.375789
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Initialize object GlideIE
    object_GlideIE = GlideIE()

    # Unit test for _real_extract
    # _match_id unit test
    assert object_GlideIE._match_id( "https://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D" ) == "UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D"

    # _valid_url unit test

# Generated at 2022-06-22 07:42:32.792457
# Unit test for constructor of class GlideIE
def test_GlideIE():
    item = GlideIE()
    assert item.IE_NAME == 'glide'
    assert item.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert item._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:42:34.261725
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == ie.IE_DESC

# Generated at 2022-06-22 07:42:36.779103
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_extract('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:42:41.062626
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # the next line will raise an exception if the _real_extract() method does not exist
    ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-22 07:42:41.865285
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-22 07:42:48.262300
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie=GlideIE()
    # Return value of _valid_url
    url='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # _VALID_URL='https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    match=ie._VALID_URL.search(url)
    # Print result of video_id
    print(match.group('id'))
# Test for extracting title, url and thumbnail from website

# Generated at 2022-06-22 07:42:52.649577
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print(ie.IE_DESC)
    print(ie.IE_DESC)
    print(ie._VALID_URL)
    print(ie._TEST)

# Generated at 2022-06-22 07:42:55.977260
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert glide_ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"


# Generated at 2022-06-22 07:42:57.848057
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST


# Generated at 2022-06-22 07:43:02.631865
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL.startswith('https?')
    try:
        GlideIE._VALID_URL.format(id='foo')
    except ValueError:
        assert False, 'Wrong regexp'

# Generated at 2022-06-22 07:45:28.272813
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:45:29.885888
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:45:31.590249
# Unit test for constructor of class GlideIE
def test_GlideIE():
	TE_instance = GlideIE()
	assert not TE_instance is None

# Generated at 2022-06-22 07:45:35.022786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide'



# Generated at 2022-06-22 07:45:36.069419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie is not None


# Generated at 2022-06-22 07:45:37.438615
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert "GlideIE" in str(GlideIE.__bases__).split(", ")


# Generated at 2022-06-22 07:45:42.629234
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiate the GlideIE class
    # Arguments:
    #     ie or info_extractors
    #         A list of InfoExtractor objects that will be used to obtain
    #         the information
    #     downloader or downloader_factory
    #         Downloader object that will be used to download the video
    #     params:
    #         Extra parameters that will be passed to the InfoExtractor
    #         object.
    #
    ie = GlideIE('test')
    # Assert that the class object is of type InfoExtractor
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 07:45:53.191271
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE(InfoExtractor())
    assert x._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:45:55.902757
# Unit test for constructor of class GlideIE
def test_GlideIE():
    p = GlideIE()
    assert isinstance(p, InfoExtractor)
    assert isinstance(p.IE_DESC, str)
    assert isinstance(p._VALID_URL, str)
    assert isinstance(p._TEST, dict)
    assert isinstance(p._download_webpage, object)

# Generated at 2022-06-22 07:46:00.283046
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test whether constructor of class GlideIE works correctly
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    # Test whether setting of class attributes works correctly
    ie = GlideIE(ie_key='test_ie_key')
    assert ie.ie_key == 'test_ie_key'
