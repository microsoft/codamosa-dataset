

# Generated at 2022-06-22 07:37:08.144588
# Unit test for constructor of class GlideIE
def test_GlideIE():
    expected_fields = "id,title,thumbnail"
    glide_ie = GlideIE()
    assert glide_ie.fields == expected_fields

# Generated at 2022-06-22 07:37:11.852407
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_glideie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    print(ie_glideie._real_extract(url))

# Generated at 2022-06-22 07:37:13.255308
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:23.017170
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This tests whether the constructor of the class GlideIE is properly
    written.
    """
    glide_ie = GlideIE()
    assert glide_ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_ie.md5 == '4466372687352851af2d131cfaa8a4c7'
    assert glide_ie.info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_ie.info_dict['ext'] == 'mp4'
    assert glide_ie.info_dict['title'] == "Damon's Glide message"

# Generated at 2022-06-22 07:37:29.059494
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/L-jY_hFV8zvx90xZ9lzZgw==') == True
    assert GlideIE.suitable('blabla') == False
    assert GlideIE.suitable('https://www.youtube.com/watch?v=ENp6IYdgUz8') == False

# Generated at 2022-06-22 07:37:31.533394
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g_ie = GlideIE()
    assert g_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:37:33.887738
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:35.336977
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	assert obj.ie_key() == 'Glide'

# Generated at 2022-06-22 07:37:46.671628
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_NAME = 'glide'
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:37:51.312398
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = GlideIE()
    assert infoExtractor.IE_DESC == "Glide mobile video messages (glide.me)"
    assert infoExtractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:38:07.528570
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:11.477632
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test of constructor, to has a correct class
    try:
        GlideIE()
    except:
        # If there is a problem in instantiation, it is a problem in the code
        assert False
    # If the object is created, it is correct.
    assert True

# Generated at 2022-06-22 07:38:15.004289
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:15.836476
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:38:16.854719
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:38:24.018590
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert x._VALID_URL == x._TEST['url']
    assert x._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert x._TEST['info_dict'] == x._real_extract(x._TEST['url'])


# Generated at 2022-06-22 07:38:24.664181
# Unit test for constructor of class GlideIE
def test_GlideIE():
	pass

# Generated at 2022-06-22 07:38:25.794103
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(GlideIE(InfoExtractor()))

# Generated at 2022-06-22 07:38:28.994496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    ie.IE_NAME = 'test'
    assert ie.IE_NAME == 'test'
    ie2 = GlideIE();
    assert ie2.IE_NAME == 'Glide'

# Generated at 2022-06-22 07:38:30.398597
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-22 07:38:37.506111
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert isinstance(instance, GlideIE)

# Generated at 2022-06-22 07:38:40.585962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

test_GlideIE()

# Generated at 2022-06-22 07:38:49.589926
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # test GlideIE._VALID_URL
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    match = ie._VALID_URL.match(url)
    video_id = match.group('id')
    assert video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:38:50.726159
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #simple test
    GlideIE()

# Generated at 2022-06-22 07:38:52.438738
# Unit test for constructor of class GlideIE
def test_GlideIE():	
    assert 1==1
    print('Test passed')

# Generated at 2022-06-22 07:38:54.806256
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()

    # Test for GlideIE._real_extract()
    IE._real_extract(url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:39:07.000581
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:39:17.408899
# Unit test for constructor of class GlideIE
def test_GlideIE():
    G = GlideIE('url', 'args', 'http')
    assert isinstance(G, InfoExtractor)
    assert G.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert G.VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:29.057343
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:40.287057
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert 'tags' in instance._TEST
    assert instance._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert instance._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert 'id' in instance._TEST['info_dict']

# Generated at 2022-06-22 07:40:02.106613
# Unit test for constructor of class GlideIE
def test_GlideIE():
    expected_result = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }

    glide_ie = GlideIE(None)
    result = glide_ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert result == expected_result

# Generated at 2022-06-22 07:40:12.117128
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test(str_or_bytes_or_none, str_or_bytes, unicode_or_bytes)
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # test(str_or_bytes_or_none, str_or_bytes, unicode_or_bytes)
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:40:15.928395
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Unit tests for constructor of GlideIE class.
    '''
    test_object = GlideIE()
    assert test_object.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:40:21.541656
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gie = GlideIE()
    urls = [
        "http://share.glide.me/GemwSVpf-jYCVoeXJejxbA==",
        "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==",
    ]
    for url in urls:
        info = gie._e

# Generated at 2022-06-22 07:40:31.308560
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_names = dir(InfoExtractor)
    ConstructorNames = [x for x in class_names if x.endswith("IE")]

    for class_name in ConstructorNames:
        try:
            ie_class = getattr(globals()[class_name], class_name)
            # instance = ie_class(downloader=None)
            instance = ie_class(downloader=None, params={'force_generic_extractor': True})
            assert isinstance(instance, InfoExtractor)
        except:
            error_msg = "Failed to initialize instance of class %s" % class_name
            raise AssertionError(error_msg)


# Generated at 2022-06-22 07:40:32.691205
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE.GlideIE()
    assert ie.get_info

# Generated at 2022-06-22 07:40:38.702314
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Creating a new instance of a subclass should invoke its __init__() method
	# and return instance of that subclass
	assert isinstance(GlideIE, InfoExtractor)

	# Testing invalid URL
	invalid_url = 'http://www.youtube.com/watch?v=-cEzsCAzTak'
	ie = GlideIE(invalid_url)
	assert ie._match_id(invalid_url) is None

	# Testing valid URL
	valid_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	ie = GlideIE(valid_url)
	assert ie._match_id(valid_url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:40:40.197708
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    print(test_GlideIE)

# Generated at 2022-06-22 07:40:46.757817
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test that GlideIE can be constructed with a given video id
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(video_id)

    # Test that GlideIE can be constructed with a given video url
    glide_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(glide_url)


# Generated at 2022-06-22 07:40:48.584490
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:41:28.902672
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-22 07:41:33.303155
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert hasattr(GlideIE, '_VALID_URL')
    assert hasattr(GlideIE, 'IE_DESC')
    #assert GlideIE.IE_NAME is None
    #assert GlideIE.IE_NAME != GlideIE.IE_DESC
    assert hasattr(GlideIE, '_TEST')


# Generated at 2022-06-22 07:41:39.004596
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Use http://share.glide.me/6mroU6YJUZfzUronV3q6Nw== as test dataset,
    # which is extracted from the webpage http://share.glide.me/6mroU6YJUZfzUronV3q6Nw==
    GlideIE('http://share.glide.me/6mroU6YJUZfzUronV3q6Nw==')

# Generated at 2022-06-22 07:41:40.711701
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    obj = GlideIE()
    assert obj.IE_NAME == 'Glide'

# Generated at 2022-06-22 07:41:43.429283
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:41:53.400372
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST == {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

# Generated at 2022-06-22 07:41:54.275788
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:42:03.783425
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_ie = GlideIE()
    assert test_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:42:05.170343
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test for constructor"""
    GlideIE()

# Generated at 2022-06-22 07:42:14.467495
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == ie.ie_key()
    expected_urls = []
    valid_urls = ['http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==']
    for valid_url in valid_urls:
        m = ie._VALID_URL_RE.match(valid_url)
        expected_url = m.group('id')
        expected_urls.append(expected_url)
    assert ie._extract_urls(valid_urls) == expected_urls
    invalid_urls = []

# Generated at 2022-06-22 07:43:27.244724
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Init class GlideIE
    GlideIE()

# Generated at 2022-06-22 07:43:34.070395
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    except Exception as exception:
        assert False
        print ('Error: ' + str(type(exception)) + ': ' + exception.message)
        print ('Something went wrong with the GlideIE class')
    assert True
    print ('The class GlideIE has been formed correctly')


# Generated at 2022-06-22 07:43:35.778101
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_glide = GlideIE()

# Generated at 2022-06-22 07:43:46.845419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    expected_result = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'title': "Damon's Glide message",
        'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        'url': 'http://glidemedia.glide.me/videos/cfa1cad7-3e61-4fb7-b6a0-bd715f9c4e8d/cfa1cad7-3e61-4fb7-b6a0-bd715f9c4e8d.mp4'
    }

    ie = GlideIE()
    result = ie._real_extract(ie._TEST['url'])
    assert expected_result == result

# Generated at 2022-06-22 07:43:55.350357
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:43:56.012596
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-22 07:44:03.146548
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/o0i_OzHZWtP8gDTeZC_1Pg==')
    assert ie.url == 'http://share.glide.me/o0i_OzHZWtP8gDTeZC_1Pg=='
    assert ie.video_id == 'o0i_OzHZWtP8gDTeZC_1Pg=='


# Generated at 2022-06-22 07:44:14.776859
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    glide_ie = GlideIE()
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:44:24.650847
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test in constructor of class GlideIE
    instance = GlideIE()
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert instance._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert instance._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert instance._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert instance._TEST['info_dict']['ext'] == 'mp4'
    assert instance._

# Generated at 2022-06-22 07:44:27.468465
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        InfoExtractor()
        assert False
    except TypeError as e:
        assert str(e) == 'Can\'t instantiate abstract class InfoExtractor with abstract methods _real_extract'