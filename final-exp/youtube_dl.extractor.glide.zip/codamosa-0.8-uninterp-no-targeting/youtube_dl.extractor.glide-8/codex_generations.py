

# Generated at 2022-06-22 07:37:07.054294
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert type(GlideIE)

# Generated at 2022-06-22 07:37:17.350859
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Note: parameter of constructor is the class name
    unitTest = InfoExtractor("GlideIE")
    assert unitTest != None
    # Assert the attribute
    assert unitTest.IE_DESC == "Glide mobile video messages (glide.me)"
    assert unitTest._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert len(unitTest._TEST) == 3
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert unitTest._TEST['url'] == url
    md5 = '4466372687352851af2d131cfaa8a4c7'
    assert unitTest._TEST

# Generated at 2022-06-22 07:37:23.835331
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.description == 'Glide mobile video messages (glide.me)'
    assert i.valid_url_re == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:37:35.492605
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert i._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert i._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert i._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:37:42.317635
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    glide = GlideIE()
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:37:52.225847
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._TEST[0]['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST[0]['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:37:53.353434
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE({})

# Generated at 2022-06-22 07:37:53.942043
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:55.403590
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()

# Generated at 2022-06-22 07:38:07.094784
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.suitable('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.suitable('https://share.glide.me/ZWxoOjMwOTMwMDg1')
    ie.suitable('https://share.glide.me/ZWxoOjMwOTMwMDg1')
    ie.suitable('https://share.glide.me/ZWxoOjMwOTMwMDg1')

# Generated at 2022-06-22 07:38:16.217400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:18.128226
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This is just a test to ensure the constructor of GlideIE is working.
    obj = GlideIE()

# Generated at 2022-06-22 07:38:29.889542
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE("test", 2)
    assert i.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert i._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert i._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    d = i._TEST['info_dict']
    assert d['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert d['ext']

# Generated at 2022-06-22 07:38:30.926725
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('youtube', 'youtube')

# Generated at 2022-06-22 07:38:42.017248
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert info.url == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert info.IE_DESC == "Glide mobile video messages (glide.me)"
    assert info._VALID_URL == "^https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)$"

# Generated at 2022-06-22 07:38:46.862456
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glide = GlideIE('http://www.glide.me')
    assert glide.IE_NAME == 'Glide'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:38:47.458534
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:38:49.224878
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_instance = GlideIE()
    assert isinstance(ie_instance, GlideIE)

# Generated at 2022-06-22 07:38:56.183107
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractorTest = InfoExtractor()
    infoExtractor = GlideIE()
    assert(infoExtractor.IE_DESC == infoExtractorTest.IE_DESC)
    assert(infoExtractor.IE_NAME == infoExtractorTest.IE_NAME)
    assert(infoExtractor.IE_VERSION == infoExtractorTest.IE_VERSION)
    assert(infoExtractor.PROVIDER_NAME == infoExtractorTest.PROVIDER_NAME)


# Generated at 2022-06-22 07:39:08.259505
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title']

# Generated at 2022-06-22 07:39:24.515868
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE()
    video_url = video.search_video_url(url='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',video_id='')
    print (video_url)

# Generated at 2022-06-22 07:39:26.870016
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('www.youtube.com')
    assert obj.ie_key() == 'Glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:39:30.675709
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:33.398702
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:39:37.318927
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC)
    assert(ie._VALID_URL)
    assert(ie._TEST)
    assert(ie._real_extract)

# Generated at 2022-06-22 07:39:39.665498
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # check that there are no problems with GlideIE
    try:
        GlideIE()
    except Exception as e:
        print(e)
        assert False, 'An exception is raised from GlideIE'

# Generated at 2022-06-22 07:39:45.596297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This test method creates an instance of GlideIE by calling constructor.
    Then it calls extract_info method with a sample url.
    """
    ie = GlideIE()
    ie.extract_info("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:39:46.768362
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:39:53.057626
# Unit test for constructor of class GlideIE
def test_GlideIE():
    "GlideIE Unit Testing for constructor"
    test_object = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(test_object, GlideIE) is True
    assert hasattr(test_object, '_VALID_URL') is True
    assert hasattr(test_object, '_TEST') is True



# Generated at 2022-06-22 07:40:05.138853
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_NAME = 'GlideIE'

    # Check for videourl
    video_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    url = 'http://share.glide.me/' + video_id
    webpage = ie._download_webpage(url, video_id)
    video_url = ie._proto_relative_url(ie._search_regex(
        r'<source[^>]+src=(["\'])(?P<url>.+?)\1',
        webpage, 'video URL', default=None,
        group='url'))

# Generated at 2022-06-22 07:40:30.816538
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:40:32.230462
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (isinstance(GlideIE(), InfoExtractor))



# Generated at 2022-06-22 07:40:34.371901
# Unit test for constructor of class GlideIE
def test_GlideIE():
    InfoExtractor.test(GlideIE)
    
if __name__ == "__main__":
    test_GlideIE()

# Generated at 2022-06-22 07:40:40.672592
# Unit test for constructor of class GlideIE
def test_GlideIE():
	with open ('tests/test_data/Glide.webpage') as f:
		webpage = f.read()
		GlideIE (webpage)._search_regex(r'<title>(.+?)</title>', webpage,
            'title', default=None) == 'Damon&#039;s Glide message'


# Generated at 2022-06-22 07:40:41.583221
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-22 07:40:43.844499
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-22 07:40:45.892910
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    assert IE is not None
    assert IE.IE_NAME == 'glide'

# Generated at 2022-06-22 07:40:56.324365
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor_class = GlideIE
    test_GlideIE = True
    expected_GlideIE = 'Glide mobile video messages (glide.me)'
    test_GlideIE_2 = '<source id="video-player-source" src="http://s3.amazonaws.com/glide-share/p3qgdjw6Uzyah6Cg489+4A==.mp4" type="video/mp4" />'
    test_GlideIE_3 = 'https://s3.amazonaws.com/glide-share/p3qgdjw6Uzyah6Cg489+4A==.jpg'

# Generated at 2022-06-22 07:41:00.031768
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-22 07:41:05.318707
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url_set = [
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'http://share.glide.me/5gRBe5z4QCKG4o4RcaO4jg==',
        ]
    for test_url in test_url_set:
        ie = GlideIE(test_url)
        ie.test()

# Generated at 2022-06-22 07:42:01.439361
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:42:02.367442
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    return ie

# Generated at 2022-06-22 07:42:04.959499
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor('glide')).is_origin(
        GlideIE._VALID_URL) == True

# Generated at 2022-06-22 07:42:14.319756
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://url.ie')._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE('http://url.ie').IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:42:22.756386
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    if not isinstance(ie, GlideIE):
        raise AssertionError("Expected object to be instance of class GlideIE, instead got %s" % type(ie))

    # Test for working function _real_extract(self, url)
    print('Testing function _real_extract')
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    expected_video_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    expected_title = "Damon's Glide message"

# Generated at 2022-06-22 07:42:35.214833
# Unit test for constructor of class GlideIE
def test_GlideIE():
    I = GlideIE()
    assert(I.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(I._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-22 07:42:38.663293
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    if not ie:
        assert False, "Invalid __init__, please test again"


# Generated at 2022-06-22 07:42:40.117113
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie

# Unit test of function _real_extract of class GlideIE

# Generated at 2022-06-22 07:42:45.541242
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test code for class GlideIE

    video_id = 'MNS-Hbzaa5k-a5I5C5n5Fxg=='
    url = 'http://share.glide.me/%s' % video_id
    glide = GlideIE()
    res = glide.extract(url)
    assert res

# Generated at 2022-06-22 07:42:56.076990
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-22 07:45:17.652478
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:45:27.729451
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:45:36.479062
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test instantiation of subclass
    glide_ie = GlideIE()

    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

    # Test result of _real_extract
    result = glide_ie._real_extract(glide_ie._TEST['url'])
    assert result['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert result['ext'] == 'mp4'
    assert result['title'] == "Damon's Glide message"
    assert result['thumbnail'] == 'https://d2y91gy9evn72m.cloudfront.net/d2c2cd43-b0fc-4f51-9e4d-9ba34993baf0.jpg'

# Generated at 2022-06-22 07:45:40.999610
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # ie.download --> ie._real_initialize() --> ie._download_webpage()
    assert ie._download_webpage('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-22 07:45:49.775957
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:45:52.952924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # make sure GlideIE can be created (see
    # https://github.com/ytdl-org/youtube-dl/issues/10884)
    ie = GlideIE()

# Generated at 2022-06-22 07:46:02.137129
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj.IE_NAME == 'Glide.me'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:46:05.536366
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()

    def assert_expected_result(test):
        # return the class of the extractor;
        # if the instance isn't equal to GlideIE it fails
        assert extractor.__class__ == GlideIE

    assert_expected_result(GlideIE)

# Generated at 2022-06-22 07:46:10.533890
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:46:19.787209
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'