

# Generated at 2022-06-22 07:37:07.882658
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', '720x400')

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-22 07:37:10.613429
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor._downloader)._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-22 07:37:15.765534
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:37:19.529303
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:23.871693
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie is not None


# Generated at 2022-06-22 07:37:35.497120
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert Gl

# Generated at 2022-06-22 07:37:44.269552
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""

    # Create instance of class GlideIE
    GlideIEInstance = GlideIE()

    # Test for variables initialised
    assert GlideIEInstance.IE_NAME == 'glide'
    assert GlideIEInstance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIEInstance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Unit tests for _real_extract method of class GlideIE

# Generated at 2022-06-22 07:37:53.661496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    dl = GlideIE()
    assert dl.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert dl._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert dl._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert dl._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert dl._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:37:54.763799
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(1)


# Generated at 2022-06-22 07:37:56.215509
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == GlideIE.IE_NAME

# Generated at 2022-06-22 07:38:08.338864
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    expected_video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='

    # Constructor of class GlideIE
    GlideIE(GlideIE.IE_NAME, GlideIE.IE_DESC, expected_video_id)

    # Function 'suitable'
    assert GlideIE.suitable(test_url)

    # Function '_real_extract'
    GlideIE._match_id(test_url)
    GlideIE._html_search_regex()
    GlideIE._og_search_title()
    GlideIE._og_search_thumbnail()
    GlideIE._search_regex()

# Generated at 2022-06-22 07:38:11.874698
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    ie = GlideIE()
    ie._match_id(test_url)

# Generated at 2022-06-22 07:38:23.850955
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title']

# Generated at 2022-06-22 07:38:24.505098
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:38:30.670901
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
	assert GlideIE.__name__ == 'GlideIE'
	assert GlideIE.__doc__ == 'Glide mobile video messages (glide.me)'

# Unit test function test_GlideIE()
test_GlideIE()

# Generated at 2022-06-22 07:38:37.577270
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide.me'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert isinstance(ie._TEST, dict)


# Generated at 2022-06-22 07:38:39.249608
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance != None


# Generated at 2022-06-22 07:38:42.752593
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:38:46.031739
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext']

# Generated at 2022-06-22 07:38:49.625693
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test_object = GlideIE()
	assert test_object._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:38:53.444126
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-22 07:38:54.661185
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(object())

# Generated at 2022-06-22 07:39:00.152165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # The information of the constructor should be stored
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    asser

# Generated at 2022-06-22 07:39:03.404912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:39:06.850471
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor(GlideIE)
    ie.IE_DESC
    ie.IE_NAME
    ie.URL_TEMPLATES
    ie.VALID_URL
    ie.TEST



# Generated at 2022-06-22 07:39:08.764757
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert True
    GlideIE()

# Generated at 2022-06-22 07:39:10.093139
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie=GlideIE()
    ie._match_id.func_doc

# Generated at 2022-06-22 07:39:13.615282
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "https://share.glide.me/4Bq3sDkvqqyWdN8KjCiQ0w=="
    ie = GlideIE()
    ie.extract(url)

# Generated at 2022-06-22 07:39:15.790556
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE().IE_NAME == 'glide')

# Generated at 2022-06-22 07:39:19.969634
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).IE_NAME == 'Glide'

# Generated at 2022-06-22 07:39:33.275555
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==")
    ie._download_webpage("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", ie._match_id("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="))

# Generated at 2022-06-22 07:39:34.801241
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:39:37.132487
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:39:37.753078
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:39:48.429014
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:51.256565
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:39:52.949311
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert(test != None)


# Generated at 2022-06-22 07:39:58.673479
# Unit test for constructor of class GlideIE
def test_GlideIE():
  ie = GlideIE()
  assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
  assert(ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:40:05.191717
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.get_md5() == '4466372687352851af2d131cfaa8a4c7'
    assert ie.get_title() == "Damon's Glide message"
    assert ie.get_id() == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.get_ext() == 'mp4'

# Generated at 2022-06-22 07:40:05.850130
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:19.545777
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    GlideIE()

# Generated at 2022-06-22 07:40:20.545750
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    assert True

# Generated at 2022-06-22 07:40:31.829509
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gIE = GlideIE()
    assert gIE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert gIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:34.019326
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE."""
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:40:34.611693
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:36.624187
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE({})
    assert(instance)


# Generated at 2022-06-22 07:40:39.851510
# Unit test for constructor of class GlideIE
def test_GlideIE():
	print("test_GlideIE()")
	assert(isinstance(GlideIE(), InfoExtractor))
	return


# Generated at 2022-06-22 07:40:40.451397
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert False

# Generated at 2022-06-22 07:40:49.351710
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    ie_assert_valid_url(ie, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie_assert_valid_url(ie, 'http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==')
    ie_assert_valid_url(ie, 'http://share.glide.me/UZF8zlmuQbe4mr_7dCiQ0w==')
    ie_assert_valid_url(ie, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w')

# Generated at 2022-06-22 07:40:55.667027
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideie = GlideIE()
    assert glideie.IE_NAME == 'Glide'
    assert glideie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:30.307217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = GlideIE()
    assert result != None

# Generated at 2022-06-22 07:41:32.795990
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:41:35.261683
# Unit test for constructor of class GlideIE
def test_GlideIE():
    m = GlideIE()
    assert "IE_DESC" in m.__dict__.keys()
    assert "VALID_URL" in m.__dict__.keys()

# Generated at 2022-06-22 07:41:38.012809
# Unit test for constructor of class GlideIE
def test_GlideIE():
    object = GlideIE()
    assert(object.IE_DESC)
    assert(object._VALID_URL)
    assert(object._TEST)

# Generated at 2022-06-22 07:41:39.872050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test that IE exists
    ie = InfoExtractor.get_info_extractor("glide")

# Generated at 2022-06-22 07:41:51.909388
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE('a', 'b', 'c')
    assert e.IE_NAME == 'glide'
    assert e.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert e._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:42:02.905538
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("Glide mobile video messages (glide.me)",
        "Glide mobile video messages (glide.me)",
        r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)',
        "UZF8zlmuQbe4mr+7dCiQ0w==",
        "4466372687352851af2d131cfaa8a4c7",
        {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$'})


# Generated at 2022-06-22 07:42:06.056838
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:42:09.269611
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE_DESC = 'Glide mobile video messages (glide.me)'
    assert IE_DESC == GlideIE.IE_DESC


# Generated at 2022-06-22 07:42:13.657026
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_target = GlideIE()
    assert test_target.ie_key() == "Glide"
    assert test_target.ie_desc == "Glide mobile video messages (glide.me)"
    assert test_target._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:43:33.301074
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    title = "Damon's Glide message"
    thumbnail = r're:^https?://.*?\.cloudfront\.net/.*\.jpg$'
    video_url = r're:^https?://.*cloudfront\.net/video/.*'
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='

    glide = GlideIE()
    info_dict = glide._real_extract(url)
    assert info_dict['title'] == title
    assert info_dict['thumbnail'] == thumbnail
    assert info_dict['url'] == video_url
    assert info_dict['id'] == video_id


# Generated at 2022-06-22 07:43:44.951962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
   

# Generated at 2022-06-22 07:43:48.486740
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._real_extract(url)

# Generated at 2022-06-22 07:43:50.020076
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    assert GlideIE



# Generated at 2022-06-22 07:43:50.654644
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE(InfoExtractor())

# Generated at 2022-06-22 07:43:56.123417
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not GlideIE.suitable('http://google.com/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:43:57.150894
# Unit test for constructor of class GlideIE
def test_GlideIE():
  assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-22 07:43:59.175818
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'glide'


# Generated at 2022-06-22 07:44:00.913833
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    test.scrape_info()

# Generated at 2022-06-22 07:44:03.145979
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:46:37.278775
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'glide'

# Generated at 2022-06-22 07:46:47.224067
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'
    assert ie._VALID_URL == 'http://share.glide.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:46:49.722372
# Unit test for constructor of class GlideIE
def test_GlideIE():
     if GlideIE() is not None:
         return True
     else:
         return False


# Generated at 2022-06-22 07:46:52.876847
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gie = GlideIE()
    assert gie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-22 07:46:55.830216
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:47:02.471320
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    b = GlideIE("http://www.share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    c = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==")
    d = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr_7dCiQ0w==")
    e = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr=7dCiQ0w==")