

# Generated at 2022-06-22 07:37:07.017150
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert type(i) == GlideIE


# Generated at 2022-06-22 07:37:11.538852
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ydl = None
    ie = GlideIE(ydl)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST
    assert ie

# Generated at 2022-06-22 07:37:16.088783
# Unit test for constructor of class GlideIE
def test_GlideIE():
    objGlideIE = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert objGlideIE.__class__.__name__ == "GlideIE"
    assert objGlideIE.extract(objGlideIE._VALID_URL) == True

# Generated at 2022-06-22 07:37:19.761545
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Method to test GlideIE class.
    """
    glide_video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()
    ie.extract(glide_video_url)

# Generated at 2022-06-22 07:37:23.283749
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-22 07:37:24.604650
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:27.719443
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')



# Generated at 2022-06-22 07:37:39.406093
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for info dictionary of glide API
    glide_api_testfile = 'test_data/test_glide_mobile_video_api.json'
    with open(glide_api_testfile, 'r') as fin:
        glide_api_test_json = fin.read()
    glide_dict = {
        'glide_video_info': glide_api_test_json,
    }

    glide_ie = GlideIE()
    res = glide_ie._real_extract(glide_ie._VALID_URL % 'unittest', glide_dict)

    assert res['id'] == 'UnittestId'
    assert res['title'] == 'Unit Test Video'

# Generated at 2022-06-22 07:37:42.419487
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:37:43.509365
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:38:00.737682
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert(info_extractor.IE_NAME == 'glide')
    assert(info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-22 07:38:01.381799
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-22 07:38:03.604694
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:38:09.752157
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/A')
    ie.extract('http://share.glide.me/A?B=C')
    ie.extract('http://share.glide.me/A#B=C')
    ie.extract('http://share.glide.me/A#B')

# Generated at 2022-06-22 07:38:11.978646
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:38:14.244681
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test GlideIE constructor"""
    GlideIE('glide', 'glide.me')


# Generated at 2022-06-22 07:38:15.881106
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE(None)
    assert a is not None

# Generated at 2022-06-22 07:38:17.766496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
        assert(True)
    except:
        assert(False)

# Generated at 2022-06-22 07:38:26.698122
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test with a valid URL
    glide_ie = GlideIE()
    result = glide_ie.extract('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert result['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert result['title'] == "Damon's Glide message"

    # Test with an invalid URL
    with pytest.raises(ExtractorError) as excinfo:
        glide_ie.extract('https://share.glide.me/')
    assert 'Invalid URL' in str(excinfo)

# Generated at 2022-06-22 07:38:29.510448
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-22 07:38:45.006974
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:38:49.491525
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:38:52.894387
# Unit test for constructor of class GlideIE
def test_GlideIE():
    construct_object = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert construct_object.ie_key() == 'Glide'

# Generated at 2022-06-22 07:38:53.372757
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:38:54.044629
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:38:56.132171
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.parameter = '123'
    assert ie.parameter == '123'

# Generated at 2022-06-22 07:38:58.687217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, GlideIE)
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 07:39:00.517651
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("tested test_GlideIE")
    GlideIE()

# Generated at 2022-06-22 07:39:03.351467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-22 07:39:03.967413
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:39:31.101755
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:39:34.301003
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:39:44.506594
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:39:51.821341
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", test=True)
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", download=False)
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", download=False, test=True)



# Generated at 2022-06-22 07:39:54.726793
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:39:58.793503
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE

if __name__ == '__main__':
    # Just in case some people want to run this without nose
    from nose.tools import run_test
    run_test(test_GlideIE)

# Generated at 2022-06-22 07:40:10.061628
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test basic instances
    valid_glide_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert(GlideIE()._match_id(valid_glide_url) == 'UZF8zlmuQbe4mr+7dCiQ0w==')

    invalid_glide_url = 'http://share.glide.me/'
    assert(GlideIE()._match_id(invalid_glide_url) is None)

    not_glide_url_at_all = 'https://www.youtube.com/watch?v=TznT0NyO6Uw'
    assert(GlideIE()._match_id(not_glide_url_at_all) is None)

test_Gl

# Generated at 2022-06-22 07:40:11.062966
# Unit test for constructor of class GlideIE
def test_GlideIE():
        GlideIE()

# Generated at 2022-06-22 07:40:22.503321
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# This URL points to a .mp4 video
	url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
	# This URL points to a .jpg thumbnail
	url2 = "https://d2rjzayws5w6ep.cloudfront.net/6f3c6a3d-2dce-44b0-bae5-149e0a5a5c43.jpg"
	# Create an instance of the GlideIE extractor with the URL
	ie = GlideIE(url)
	# Test the is_suitable() function of class GlideIE
	assert(ie.is_suitable(url))
	# Test the is_suitable() function of class GlideIE

# Generated at 2022-06-22 07:40:32.430021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(ie.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(ie._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7")

# Generated at 2022-06-22 07:41:11.197394
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:41:22.362475
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Checking for GlideIE class object
    assert isinstance(glideIE, GlideIE)

    # Checking for correct class variable
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

    # Checking for correct _VALID_URL variable
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

    # Checking for correct _TEST dictionary

# Generated at 2022-06-22 07:41:25.955948
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Class constructor test"""
    glide = GlideIE()
    assert glide.IE_NAME == "Glide"
    assert glide.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-22 07:41:30.455796
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._match_id(test_url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:41:35.573062
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-22 07:41:46.901731
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import re
    user_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    test = GlideIE()
    test_extractor = test.ie_key()
    # Check if class GlideIE is correctly initialized.
    assert test_extractor == 'Glide'
    # Check if video id is correctly extracted from the url
    assert test._match_id(user_url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # Check if class GlideIE has the right _VALID_URL regex
    assert re.match(GlideIE._VALID_URL, user_url)
# Stop unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:41:48.853870
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie


# Generated at 2022-06-22 07:41:50.669319
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This is the GlideIE class that is used in the register function
    from .youtube import YoutubeIE
    assert YoutubeIE.ie_key() in GlideIE.ie_key_map

# Generated at 2022-06-22 07:42:02.004948
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:42:12.427862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Check for valid and invalid URLs
    assert GlideIE._is_valid_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert GlideIE._is_valid_url("http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D")
    assert not GlideIE._is_valid_url("http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w=%3D")
    assert not GlideIE._is_valid_url("http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w=%%3D")

# Generated at 2022-06-22 07:43:39.566989
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Simple test for constructor using the class GlideIE.
    """
    glideie = GlideIE()
    assert glideie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    info_dict = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }

# Generated at 2022-06-22 07:43:44.193597
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("\nUnit test for constructor of class GlideIE")
    try:
        webpage = GlideIE()
    # Catch all exceptions of GlideIE class
    except Exception as exp:
        print("Caught exception of GlideIE constructor")
        print(str(exp))


# Generated at 2022-06-22 07:43:47.444382
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", "test.mp4")

# Generated at 2022-06-22 07:43:51.867021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    objGlideIE = GlideIE()
    objGlideIE._download_webpage("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", "UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:43:56.466517
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie.extract('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:43:59.090362
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE('/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:44:05.544809
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:44:17.374952
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:44:18.451143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-22 07:44:28.080222
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # assert the constructor,
    ie = GlideIE(GlideIE._VALID_URL)
    # assert the created instance
    assert ie.ie_key() == 'Glide'
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'