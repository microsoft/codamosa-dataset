

# Generated at 2022-06-22 07:37:05.768748
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:37:16.443632
# Unit test for constructor of class GlideIE
def test_GlideIE():

	class TestGlideIE():

		def __init__(self):
			self.IE_DESC = 'Glide mobile video messages (glide.me)'
			self.__valid_url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
			self.__video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='

#		 @staticmethod
#		def match_id(cls, url):

#		 @staticmethod
#		def _real_extract(cls, url):

		def _download_webpage(self, url, display_id = None):
			return "Unittest webpage"


# Generated at 2022-06-22 07:37:18.102644
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE.

    """
    GlideIE("")

# Generated at 2022-06-22 07:37:25.748084
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_video_urls = [
        # (URL, Expected Return)
        ("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", True),
        ("http://share.glide.me/", False),
    ]
    for video_url, expected_return in glide_video_urls:
        video_url_obj = GlideIE(GlideIE.IE_NAME, video_url)
        assert((video_url_obj is not None) == expected_return)


# Generated at 2022-06-22 07:37:32.388656
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # URL of test video
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    # Create instance of class GlideIE
    glide_ie = GlideIE()

    # Check if expected keys are in extracted information
    expected_keys = ['id', 'ext', 'title', 'thumbnail']
    for key in expected_keys:
        assert key in glide_ie.extract(url)

# Generated at 2022-06-22 07:37:34.768233
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide:glide'


# Generated at 2022-06-22 07:37:37.878061
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE(None)
    assert inst._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:38.680496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:49.205464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:55.401597
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE(url)
    assert ie.url == url

# To run unit tests of this class, run this module like this:
# python -m unittest glide
if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-22 07:38:10.506628
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-22 07:38:12.945635
# Unit test for constructor of class GlideIE
def test_GlideIE():
    "Class GlideIE should have been created"
    assert(isinstance(GlideIE(), InfoExtractor))

# Generated at 2022-06-22 07:38:17.553450
# Unit test for constructor of class GlideIE
def test_GlideIE():
  ie = GlideIE();
  ie.IE_DESC = "test";
  ie._TEST = { 'url': 'test' };
  assert ie.IE_DESC == "test";
  assert ie._TEST['url'] == 'test';

# Generated at 2022-06-22 07:38:20.136220
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.ie_key() == "Glide")
    assert(ie.ie_desc() == ie.IE_DESC)

# Generated at 2022-06-22 07:38:23.536457
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .. import GlideIE
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:38:24.610912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-22 07:38:27.005400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_obj = GlideIE()
    # This is a class instance, not a static method
    assert ie_obj is not None


# Generated at 2022-06-22 07:38:33.197279
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test case for valid URL
    valid_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE.suitable(valid_url)

    # Test case for invalid URL
    invalid_url = 'http://www.google.com/'
    assert not GlideIE.suitable(invalid_url)

# Generated at 2022-06-22 07:38:34.525678
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(nullcontext())

# Generated at 2022-06-22 07:38:42.023218
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Shortened URL with video ID
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==").download("UZF8zlmuQbe4mr+7dCiQ0w==")
    # Long URL with video ID
    GlideIE("http://www.glide.me/share/UZF8zlmuQbe4mr+7dCiQ0w==").download("UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:38:49.057209
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE({}) != None

# Generated at 2022-06-22 07:38:58.807363
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test(GlideIE, [{
        'url': 'https://share.glide.me/7kfBZtGvaXtXHZt1gtf+pw==',
        'info_dict': {
            'id': '7kfBZtGvaXtXHZt1gtf+pw==',
            'ext': 'mp4',
            'title': "Glide - Video Messaging",
            'description': 'md5:d4f4b4a4b4de9d99f92428f323e1a20b',
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }], ie=GlideIE.ie_key())

# Generated at 2022-06-22 07:39:10.259809
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:13.241204
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:39:25.210691
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import datetime
    now_time = datetime.datetime.now()
    # Unit test 1, a constructor without parameters
    ie1 = GlideIE()
    assert(ie1 != None)
    # Unit test 2, a constructor with all parameters

# Generated at 2022-06-22 07:39:32.537117
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_cases = [
        (1, 1),
        (2, 1),
        (0, 1),
        (2, 2),
        (1, 2),
        (0, 2)
    ]
    for test_case in test_cases:
        (a, b) = test_case
        result = construct_solution(a, b)
        assert result == (a*b) / gcd(a,b)

# Generated at 2022-06-22 07:39:34.194474
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.ie_key()


# Generated at 2022-06-22 07:39:35.717459
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test GlideIE constructor"""
    ie = GlideIE()

# Generated at 2022-06-22 07:39:38.008925
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        assert False, 'An unexpected exception has occurred in constructor of GlideIE'

# Generated at 2022-06-22 07:39:48.641620
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test with a page that has no <title> tag
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    global glide_ie
    glide_ie = GlideIE()

    # We expect a <title> tag
    assert "" != glide_ie._real_extract(test_url)['title']

    # Now, test with a page that has no title tag
    test_url = "http://share.glide.me/yVmg-LKjFZz7nRn0hZwn7A=="

    # We expect the <meta> tag to have a title, and that
    # it should be returned by the function
    assert "Rachel's Glide message" == glide_ie._real_extract(test_url)

# Generated at 2022-06-22 07:40:02.436217
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE

# Generated at 2022-06-22 07:40:03.779785
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(isinstance(GlideIE(), GlideIE))

# Generated at 2022-06-22 07:40:06.936850
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:12.573477
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .test_construtor import DatabaseTest
    test = DatabaseTest.create_test_for(GlideIE)
    assert test.test_constructor('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', test.database) == True,"Unable to extract information for http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-22 07:40:17.807476
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:40:28.956577
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.name == 'Glide'
    assert ie.ie_key() == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:36.816240
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

    #TODO: implement isinstance() method
    #assert( isinstance(ie, GlideIE))
    #assert( isinstance(ie, InfoExtractor))
    #assert( isinstance(ie._match_id(url), 'unicode'))
    #assert( isinstance(ie._proto_relative_url(url), 'unicode'))
    #assert( isinstance(ie._html_search_regex(webpage, pattern, name, default, flags), 'unicode'))
   

# Generated at 2022-06-22 07:40:44.131720
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test sample: http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w== 
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    GlideIE(test_GlideIE.test_instance, url)
    test_instance = GlideIE(test_GlideIE.test_instance, url)
    assert test_instance is not None
    
test_GlideIE.test_instance = InfoExtractor()

# Generated at 2022-06-22 07:40:54.520005
# Unit test for constructor of class GlideIE
def test_GlideIE():
    sg = GlideIE(QUnit.create_mock_extractor())
    sg.test_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    sg.test_url('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    sg.test_url('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w')
    sg.test_url('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w/')

# Generated at 2022-06-22 07:40:55.096464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:41:35.519471
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE('http://www.share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==?foo=bar')
    GlideIE('http://www.share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==?foo=bar')

# Generated at 2022-06-22 07:41:39.522842
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # pylint: disable=redefined-outer-name
    assert(GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-22 07:41:44.563352
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-22 07:41:56.641336
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:57.723831
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None, None)

# Generated at 2022-06-22 07:42:02.808511
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert x.IE_DESC == 'Glide mobile video messages (glide.me)'
    

# Generated at 2022-06-22 07:42:06.217591
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print(ie.IE_NAME)
    print(ie.IE_DESC)
    print(ie.VALID_URL)
    print(ie.TEST)

# Generated at 2022-06-22 07:42:07.398242
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:42:08.396850
# Unit test for constructor of class GlideIE
def test_GlideIE():
    initGlideIE = GlideIE()

# Generated at 2022-06-22 07:42:11.436885
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    assert isinstance(inst, GlideIE)
    assert inst.ie_key() == 'Glide'
    assert inst.ie_desc() == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:43:26.071449
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    assert test_GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:43:29.050271
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE(None)
    except TypeError as e:
        assert True
        return
    assert False

# Generated at 2022-06-22 07:43:29.875040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('test')

# Generated at 2022-06-22 07:43:35.280765
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:43:37.927039
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract_thumbnail("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:43:39.477474
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor = GlideIE()
    assert constructor != None


# Generated at 2022-06-22 07:43:42.841929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST
    ie._DOWNLOAD_WEBPAGE_ERRORS
    ie._REAL_EXTRA

# Generated at 2022-06-22 07:43:53.551233
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('url')
    assert ie.ie_key() == 'glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:44:04.668270
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    # Test for the method _real_extract

# Generated at 2022-06-22 07:44:05.655001
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-22 07:46:38.451375
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide = GlideIE()
	assert isinstance(glide, GlideIE)

# Generated at 2022-06-22 07:46:39.121322
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE()

# Generated at 2022-06-22 07:46:40.618973
# Unit test for constructor of class GlideIE
def test_GlideIE():
    check_ie_constructor('glide:', 'glide.com')

# Generated at 2022-06-22 07:46:44.583277
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).get_info('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==').get('id') == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:46:46.455311
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-22 07:46:54.374396
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:47:02.340657
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class TestingGlideIE(GlideIE):
        def __init__(self, *args, **kwargs):
            assert kwargs['IE_DESC'] == GlideIE.IE_DESC
            assert kwargs['_VALID_URL'] == GlideIE._VALID_URL
            assert kwargs['_TEST'] == GlideIE._TEST
            super(TestingGlideIE, self).__init__(*args, **kwargs)
    testing_glide_ie = TestingGlideIE()
    out = testing_glide_ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert out['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
   