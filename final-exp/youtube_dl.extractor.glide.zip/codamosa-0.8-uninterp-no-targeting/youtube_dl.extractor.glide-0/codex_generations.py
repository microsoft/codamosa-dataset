

# Generated at 2022-06-22 07:37:05.116012
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("www.glide.me")
    assert ie.IE_NAME == "glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-22 07:37:09.604966
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.params['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:37:10.424185
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE() != None

# Generated at 2022-06-22 07:37:11.362782
# Unit test for constructor of class GlideIE
def test_GlideIE():
    c = GlideIE()
    c

# Generated at 2022-06-22 07:37:15.157801
# Unit test for constructor of class GlideIE
def test_GlideIE():
    Test = GlideIE
    Test._VALID_URL = Test._TEST['url']
    Test._TEST = None
    Test()._real_extract(Test._VALID_URL)

# Generated at 2022-06-22 07:37:23.714708
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    assert ie.highest_rated_video_url == False
    assert ie.best_rated_video_url == False
    assert ie.multiple_videos_found == False
    assert ie.url_search_title == False
    assert ie.url_search_video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.url_search_urls == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.url_search_videos_url == False
    assert ie.url_search_highest_rated == False
    assert ie.url_search_best_rated == False



# Generated at 2022-06-22 07:37:26.375326
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:37:29.670733
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._downloader



# Generated at 2022-06-22 07:37:39.518656
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # test_url = 'https://share.glide.me/DZ2tAOjtQ8m4H4RSi0m0RQ=='
    # test_url = 'https://share.glide.me/l8IyKbX9Sha3LSdOl3Dq3Q=='
    # test_url = 'https://share.glide.me/K9IoQObKRcW1TgZsdbwZlw=='
    # test_url = 'https://share.glide.me/1v3qHTmwQfK6r1Z6InRU6Q=='
    # test_url = 'https

# Generated at 2022-06-22 07:37:40.726755
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-22 07:37:48.621021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glide_ie = GlideIE()
    # Tests if returns a GlideInfoExtractor object
    assert isinstance(glide_ie, GlideIE)

# Generated at 2022-06-22 07:37:49.728241
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide_ie = GlideIE()

# Generated at 2022-06-22 07:37:50.650460
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE

# Generated at 2022-06-22 07:38:00.324813
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

    GlideIE()._real_extract(test['url'])
    assert True

# Generated at 2022-06-22 07:38:08.433331
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:21.461323
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_desc()
    assert ie.VALID_URL == ie.valid_url()
    assert ie.TEST == ie.test()
    assert GlideIE.IE_NAME == ie.ie_key()
    assert GlideIE.IE_DESC == ie.ie_desc()
    assert GlideIE.VALID_URL == ie.valid_url()
    assert GlideIE.TEST == ie.test()
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:38:26.044095
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert 'us' in ie.IE_DESC
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:26.886684
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()


# Generated at 2022-06-22 07:38:32.775798
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance._VALID_URL == 'https?://share.glide.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert instance.IE_NAME == 'glide'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:38:35.009700
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'gli.de'


# Generated at 2022-06-22 07:38:48.706625
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\\-=_+]+)'
    assert not ie.hoster_domains
    assert not ie.br
    assert not ie.a_test


# Generated at 2022-06-22 07:38:51.347238
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).ie_key() == 'Glide'
    assert GlideIE(None).IE_NAME == 'Glide'

# Generated at 2022-06-22 07:38:54.426519
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D'
    ie.download(url)

# Generated at 2022-06-22 07:38:57.427575
# Unit test for constructor of class GlideIE
def test_GlideIE():
    
    glide_ie = GlideIE()
    assert(glide_ie.IE_DESC == "Glide mobile video messages (glide.me)")



# Generated at 2022-06-22 07:39:01.643798
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()

    assert(info_extractor != None, "Failed to create instance of class InfoExtractor")
    assert(info_extractor._VALID_URL == GlideIE._VALID_URL, "InfoExtractor.VALID_URL is not the same as GlideIE.VALID_URL")
    assert(info_extractor._TEST == GlideIE._TEST, "InfoExtractor._TEST is not the same as GlideIE._TEST")

# Generated at 2022-06-22 07:39:02.772285
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-22 07:39:14.200016
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:18.662259
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global _TEST
    ie = GlideIE(_TEST)
    assert ie.info(dict)['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-22 07:39:19.634065
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extractor()

# Generated at 2022-06-22 07:39:25.064588
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'Glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:39:39.232706
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #TODO: search for better test url (the one for now is invalid)
    global GlideIE
    # global test_GlideIE
    # test_GlideIE.__class__.__name__ = 'GlideIE'
    GlideIE = GlideIE(
        {},
        {},
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(GlideIE.extract())

# test_GlideIE()

# Generated at 2022-06-22 07:39:40.721759
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-22 07:39:47.384145
# Unit test for constructor of class GlideIE
def test_GlideIE():
    data = GlideIE()._extract_urls('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert data == ['http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==']
    data = GlideIE()._extract_urls('http://share.glide.me/')
    assert data == []

# Generated at 2022-06-22 07:39:49.227075
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        obj = GlideIE(None)
    except Exception as e:
        pass

# Generated at 2022-06-22 07:40:01.097089
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glide_ie = GlideIE()
    assert glide_ie.IE_NAME == "glide"
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert glide_ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert glide_ie._TEST['info_dict']['id']

# Generated at 2022-06-22 07:40:02.226565
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME

# Generated at 2022-06-22 07:40:04.005387
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    GlideIE(InfoExtractor)

# Generated at 2022-06-22 07:40:14.682385
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import InfoExtractor
    classDict = vars(InfoExtractor)
    classDict["IE_DESC"] = 'Glide mobile video messages (glide.me)'
    classDict["_VALID_URL"] = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:40:18.754572
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    if obj:
        print("Constructor of class GlideIE succeed!")
    else:
        print("Constructor of class GlideIE failed!")


# Generated at 2022-06-22 07:40:20.111276
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._match_id(None) == None

# Generated at 2022-06-22 07:40:31.413648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    website = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    actual = ie.match(website)
    expected = True
    assert expected == actual


# Generated at 2022-06-22 07:40:36.515331
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ae = GlideIE("www.glide.me", {})
    # Test that GlideIE can work with an empty config
    info = ae._real_extract(GlideIE._TEST['url'])
    assert info['id'] == GlideIE._TEST['info_dict']['id']
    assert info['title'] == GlideIE._TEST['info_dict']['title']
    assert info['thumbnail'] == GlideIE._TEST['info_dict']['thumbnail']

# Generated at 2022-06-22 07:40:40.100429
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:40:49.144666
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:55.182088
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    obj = ie("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    obj.download("C:\\Temp\\", "video")

# Generated at 2022-06-22 07:40:56.770838
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie is not None)

# Generated at 2022-06-22 07:41:06.625127
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:10.021158
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:10.687169
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'glide'

# Generated at 2022-06-22 07:41:21.876994
# Unit test for constructor of class GlideIE
def test_GlideIE():

    import re

    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    # Check valid URL (1)
    glide_ex = GlideIE(
        downloader=None,
        extractor_key=None,
        ie_key=None,
        ie=None,
        destdir=None,
        progress_hooks=None,
        params=None,
        formats=None,
    )

    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-22 07:41:48.490131
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:42:00.347587
# Unit test for constructor of class GlideIE
def test_GlideIE():
	extractor = GlideIE()
	# This has been chosen because it has a full video, including 
	# webm, opus and mp4 format, and that it does not change 
	# from time to time.
	url = "http://share.glide.me/CnJL-jfLVpYbNjDjyWtGxg=="
	# This will be made uppon object initialization 
	filename = extractor.download_filename
	# This is the actual download method
	extractor.download(url)
	# And this is how we check if the file exists
	import os.path
	exists = os.path.isfile(filename)
	assert exists == True

# Generated at 2022-06-22 07:42:02.970510
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import re
    from .common import InfoExtractor
    regex_test = re.compile(GlideIE._VALID_URL)
    assert InfoExtractor.suitable(regex_test)

# Generated at 2022-06-22 07:42:13.023788
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    video = IE._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert video['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert video['url'] == 'https://d1yhp92t0kq3q3.cloudfront.net/480p/UZF8zlmuQbe4mr+7dCiQ0w==_1.mp4'
    assert video['thumbnail'] == 'https://d1yhp92t0kq3q3.cloudfront.net/snapshots/UZF8zlmuQbe4mr+7dCiQ0w==_7.jpg'

# Generated at 2022-06-22 07:42:15.733186
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:42:26.676709
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:42:29.648399
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Should not raise exception
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:42:34.469477
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glideIE = GlideIE()
    assert glideIE.suitable(test_url)

# Generated at 2022-06-22 07:42:45.612483
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Unit test for valid_url
	GlideIE().valid_url("http://share.glide.me/Ju0pGzfT0hHpgFy9N0g+ng==")
	GlideIE().valid_url("http://share.glide.me/OvhYBcX7Vx1b5Cxa-VvZGQ==")
	GlideIE().valid_url("http://share.glide.me/xDjGaPf-ZLHPDi_M2IOKfg==")

	# Unit test for invalid_url
	GlideIE().invalid_url("http://share.glide.me/Ju0pGzfT0hHpgFy9N0g+ng==/")

# Generated at 2022-06-22 07:42:47.435924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE(None)
    assert isinstance(info_extractor.IE_DESC, str)

# Generated at 2022-06-22 07:43:33.083360
# Unit test for constructor of class GlideIE
def test_GlideIE():
	info_extractor = GlideIE()
	assert info_extractor.ie_key() == 'Glide'
	assert info_extractor.ie_desc() == 'Glide mobile video messages (glide.me)'
	assert info_extractor.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:43:34.182799
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE(None, None)
    except TypeError:
        pass

# Generated at 2022-06-22 07:43:35.482361
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC

# Generated at 2022-06-22 07:43:37.846430
# Unit test for constructor of class GlideIE
def test_GlideIE():
  q = GlideIE()
  """Tests GlideIE constructor"""
  assert(q.__class__.__name__ == 'GlideIE')

# Generated at 2022-06-22 07:43:39.822204
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"



# Generated at 2022-06-22 07:43:40.472365
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:43:42.224841
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_obj = GlideIE()
    print("Done Testing GlideIE class constructor")

# Generated at 2022-06-22 07:43:50.547489
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.name == 'Glide'
    assert ie.ie_key() == 'Glide'
    assert ie.ie_url() == 'ThisClip.com'
    assert ie.url_re.match('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==').groups() == ('UZF8zlmuQbe4mr+7dCiQ0w==',)

# Generated at 2022-06-22 07:43:52.762692
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testobj = GlideIE()
    assert(testobj.IE_DESC == "Glide mobile video messages (glide.me)")


# Generated at 2022-06-22 07:43:55.006786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-22 07:45:10.082107
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:45:13.110016
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testObj = GlideIE()
    assert(testObj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(testObj.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-22 07:45:20.169782
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("")
    assert(ie.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(hasattr(ie, '_TEST'))
    return ie;


# Generated at 2022-06-22 07:45:20.726711
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:45:21.876448
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE(None).IE_NAME == "Glide")


# Generated at 2022-06-22 07:45:22.737577
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()


# Generated at 2022-06-22 07:45:23.997881
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test instance creation
    ie = GlideIE()
    assert ie.IE_DESC

# Generated at 2022-06-22 07:45:27.775602
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE()
    video.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:45:29.469034
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:45:35.023325
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Try to download a Glide video.
    """
    extractor = GlideIE()
    extractor.download("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")