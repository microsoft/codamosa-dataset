

# Generated at 2022-06-22 07:37:05.101514
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testProto.test_GlideIE()

# Generated at 2022-06-22 07:37:09.914439
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide = GlideIE()
    assert glide.extract(url)['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:37:13.254450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:37:16.087161
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor)._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:17.493712
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()

# Generated at 2022-06-22 07:37:19.647497
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:37:26.324023
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE.suitable('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not GlideIE.suitable('http://https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not GlideIE.suitable('http://share.glide.me/')

# Generated at 2022-06-22 07:37:37.591123
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE
    assert class_.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert class_.IE_NAME == 'glide'
    assert class_._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:42.034537
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.get_url_re().pattern == '^https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)$'

# Generated at 2022-06-22 07:37:46.032098
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("GlideIE")
    assert ie.IE_NAME == "GlideIE"


# Generated at 2022-06-22 07:37:54.815304
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST
    ie._real_extract()

# Generated at 2022-06-22 07:37:55.592283
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:59.857166
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:38:08.393460
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:38:11.924306
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide_ie = GlideIE()
    glide_ie._real_extract(url)

# Generated at 2022-06-22 07:38:23.891854
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test GlideIE constructor
    instance = GlideIE(GlideIE.ie_key())
    # Assert GlideIE.IE_NAME is 'Glide'
    assert(instance.IE_NAME == 'Glide')
    # Assert GlideIE.IE_DESC is 'Glide mobile video messages (glide.me)'
    assert(instance.IE_DESC == 'Glide mobile video messages (glide.me)')
    # Assert GlideIE._VALID_URL is 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert(instance._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-22 07:38:31.757595
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert e.url == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert e.video_id == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-22 07:38:42.958129
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:53.396385
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiate GlideIE subclass and test it against some expected values
    class_ = GlideIE
    inst = class_()
    assert inst._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:56.339186
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test(GlideIE, {"url": "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="})

# Generated at 2022-06-22 07:39:10.318726
# Unit test for constructor of class GlideIE
def test_GlideIE():
  s = GlideIE()
  assert (s is not None)


# Generated at 2022-06-22 07:39:15.226896
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL[0] == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:39:16.052536
# Unit test for constructor of class GlideIE
def test_GlideIE():
	q = GlideIE()

# Generated at 2022-06-22 07:39:22.239415
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This is just a dummy test to check that the constructor of the class
    # builds a GlideIE object without errors.
    ie = GlideIE(InfoExtractor())
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-22 07:39:25.665323
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:39:29.317379
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:39:34.301283
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:44.467507
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:46.597860
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        return False
    else:
        return True

# Generated at 2022-06-22 07:39:48.817641
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:40:15.614994
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    return True


# Generated at 2022-06-22 07:40:16.157691
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:21.775745
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This function performs unit test of GlideIE()
    """

    # create object of class GlideIE
    glide = GlideIE()

    # check if the object was created successfully
    if isinstance(glide, GlideIE):
        print("Unit test for GlideIE() was successful")
    else:
        print("Unit test for GlideIE() was unsuccessful")



# Generated at 2022-06-22 07:40:32.353321
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gl = GlideIE()
    assert gl.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert gl._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert gl._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert gl._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert gl._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:40:38.577056
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert i.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:40:41.188466
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL == GlideIE._VALID_URL
    assert glide._TEST == GlideIE._TEST

# Generated at 2022-06-22 07:40:42.501349
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_extract

# Generated at 2022-06-22 07:40:44.636155
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()



# Generated at 2022-06-22 07:40:55.000873
# Unit test for constructor of class GlideIE
def test_GlideIE():
    w = GlideIE()
    w.query_api(keyword="happy birthday", count=9)
    assert w.query_api(keyword="happy birthday", count=9)
    assert w.query_api(keyword="happy birthday", count=9)
    assert w.query_api(keyword="happy birthday", count=9)
    assert w.query_api(keyword="happy birthday", count=9)
    assert w.query_api(keyword="happy birthday", count=9)
    assert w.query_api(keyword="happy birthday", count=9)
    assert w.query_api(keyword="happy birthday", count=9)
    assert w.query_api(keyword="happy birthday", count=9)
    assert w.query_api(keyword="happy birthday", count=9)

# Generated at 2022-06-22 07:40:59.692294
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Create test object
	info_path = os.path.dirname(os.path.realpath(__file__))
	ie = GlideIE(info_path)
	
	# Test if constructor returns an object
	if ie is None:
		raise Exception("Object GlideIE is not constructed")

# Generated at 2022-06-22 07:42:00.058402
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:42:10.693662
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:42:12.604772
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception as e:
        raise AssertionError(e)

# Generated at 2022-06-22 07:42:15.220310
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-22 07:42:16.150207
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert type(instance) == GlideIE

# Generated at 2022-06-22 07:42:18.487139
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie.IE_DESC
    ie = GlideIE(ie.IE_DESC)
    assert ie._VALID_URL == ie.IE_DESC

# Generated at 2022-06-22 07:42:20.160143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:42:28.991321
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE.__name__ = 'test_GlideIE'
    ie = InfoExtractor('glide', {'glide': True, 'youtube_dl': True})
    (info, ie) = ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'glide'
    assert ie.info()['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    return True

# Generated at 2022-06-22 07:42:35.137954
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:42:46.466853
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:44:02.692903
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # testing for invalid url
    _TEST = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    x = GlideIE()
    y = x._real_extract(_TEST['url'])
    assert len(y) == 4
   

# Generated at 2022-06-22 07:44:05.222111
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    instance._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:44:07.425865
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
        assert True
    except:
        assert False

# Generated at 2022-06-22 07:44:11.469919
# Unit test for constructor of class GlideIE
def test_GlideIE():
	url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

	passed = False
	try:
		g = GlideIE(url)
		passed = True
	except:
		passed = False

	assert passed == True

# Generated at 2022-06-22 07:44:13.435553
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(1)._VALID_URL == GlideIE.IE_DESC

# Generated at 2022-06-22 07:44:19.336895
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME == 'glide'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:44:24.690811
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert result.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert result.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-22 07:44:30.265107
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
# test .run method

# Generated at 2022-06-22 07:44:40.363004
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert len(ie._TEST) == 4
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert len(ie._TEST['info_dict']) == 4

# Generated at 2022-06-22 07:44:43.008709
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie is not None)