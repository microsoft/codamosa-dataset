

# Generated at 2022-06-22 07:37:07.927018
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj.IE_DESC == GlideIE.IE_DESC
    assert test_obj._VALID_URL == GlideIE._VALID_URL
    assert test_obj._TEST == GlideIE._TEST

# Generated at 2022-06-22 07:37:13.530078
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_NAME == 'Glide'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.m e)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:20.357197
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_desc = ie.IE_DESC
    ie_valid_url = ie._VALID_URL
    test = ie._TEST
    print("ie_desc type: " + str(type(ie_desc)))
    print("ie_desc: " + str(ie_desc))
    print("ie_valid_url type: " + str(type(ie_valid_url)))
    print("ie_valid_url: " + str(ie_valid_url))
    print("test type: " + str(type(test)))
    print("test: " + str(test))

# Generated at 2022-06-22 07:37:31.801314
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # Constructor of class InfoExtractor
    ie._html_search_regex("<title>(" + "Damon's Glide message" + ")</title>", ie._download_webpage("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==",
                                                                                                   "UZF8zlmuQbe4mr+7dCiQ0w=="),
                         "title"
                         )

# Generated at 2022-06-22 07:37:35.508563
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:37:37.486003
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:37:43.066621
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create an object of class GlideIE
    glide_ie = GlideIE()
    # Test get_videos()
    glide_ie.get_videos('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:37:49.385118
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test 1:
    # we need to construct an object of class GlideIE() to embeded tests.
    actual = GlideIE(None)
    expected = 'GlideIE'
    actual_string = str(actual.__repr__)
    assert_equals(actual_string, expected)


# Generated at 2022-06-22 07:37:59.263786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests that GlideIE throws an error when an empty URL is given
    from .common import ExtractorError
    from .common import expected_warnings
    
    with expected_warnings(['Invalid URL']):
        try:
            GlideIE(None)._real_initialize()
        except ExtractorError as e:
            if "URL could not be parsed" in str(e):
                print("Passed Test 1: GlideIE throws an error on an invalid URL")
            else:
                print("Failed Test 1: GlideIE throws an illegal error on an invalid URL")
        else:
            print("Failed Test 1: GlideIE doesn't throw an error on an invalid URL")


# Generated at 2022-06-22 07:38:07.964735
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    print("\nUnit test for constructor of class GlideIE")
    print("\nURL:\n{url}".format(url=url))
    print("\nVideo ID:\n{video_id}".format(video_id=GlideIE._VALID_URL))
    print("\nVideo title:\n{title}".format(title='title'))
    print("\nVideo URL:\n{video_url}".format(video_url='video_url'))
    print("\nVideo thumbnail:\n{thumbnail}".format(thumbnail='thumbnail'))
test_GlideIE()

# Generated at 2022-06-22 07:38:18.286372
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Unit test to check if the url returns 404

# Generated at 2022-06-22 07:38:20.405442
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:38:24.240076
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://www.glide.me/test/test14')
    assert ie.url == 'http://share.glide.me/test/test14'
    assert ie.video_id == 'test/test14'

# Generated at 2022-06-22 07:38:25.292927
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:38:36.541552
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testcases = [
        {
            'input': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        },
        {
            'input': 'http://share.glide.me/jb-JhVaD9kjB+q3rq1cj_Q==',
            'id': 'jb-JhVaD9kjB+q3rq1cj_Q==',
        },
    ]

    for testcase in testcases:
        ie_ = GlideIE(testcase['input'])
        assert ie_.videoID.value == testcase['id']


# Generated at 2022-06-22 07:38:46.563723
# Unit test for constructor of class GlideIE
def test_GlideIE():
  assert GlideIE._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
  assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-22 07:38:58.098802
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:39:02.549196
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:05.655328
# Unit test for constructor of class GlideIE
def test_GlideIE():

    info_extractor = GlideIE()
    info_extractor.suitable('http://share.glide.me/WwEV8D0+U6pEgFkX9WJH8Q==')

# Generated at 2022-06-22 07:39:07.047306
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-22 07:39:14.139909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-22 07:39:19.004301
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie.IE_NAME == "GlideIE"
    assert ie._VALID_URL is not None
    assert ie._TEST is not None


# Generated at 2022-06-22 07:39:27.302381
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert len(obj._TEST) == 3
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert len(obj._TEST['info_dict']) == 4

# Generated at 2022-06-22 07:39:33.389349
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:39:37.493648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 'glide.me' in GlideIE.suitable
    assert 'glide.me' in GlideIE.ie_keywords
    assert GlideIE.ie_keywords['glide.me'] == (GlideIE.IE_DESC)


# Generated at 2022-06-22 07:39:48.330121
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # To check the constructor of class GlideIE
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id']

# Generated at 2022-06-22 07:40:00.041768
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_class = GlideIE('GlideIE')
    inst_GlideIE = test_class
    assert inst_GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert inst_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:01.151679
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-22 07:40:02.266933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert type(GlideIE()) == GlideIE

# Generated at 2022-06-22 07:40:03.611459
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-22 07:40:26.429053
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:32.981291
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==/UZF8zlmuQbe4mr+7dCiQ0w==.mp4")
    e.extract()
    assert e.info()
    assert e.url()
    assert e.title()
    assert e.thumbnail()

# Generated at 2022-06-22 07:40:37.741763
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

    ie = InfoExtractor()
    assert ie._VALID_URL == r'(?:https?://)?(?:\w+\.)?(?:(?:youtube\.com/watch\?(?:.*&)?v=|youtu\.be/)|(?:vimeo\.com/|hd\.mail\.ru/.+/)(?P<id>[0-9]+))'

# Generated at 2022-06-22 07:40:39.850987
# Unit test for constructor of class GlideIE
def test_GlideIE():
  ex = GlideIE('test_GlideIE', 'http://glide.me/')
  assert ex is not None

# Generated at 2022-06-22 07:40:42.457715
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:40:45.132634
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test if GlideIE was initialized properly.
    """
    GlideIE()

# Generated at 2022-06-22 07:40:50.909732
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()
    assert ie._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-22 07:41:01.544465
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)', 'expected GlideIE.IE_DESC to be set to the correct value'
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', 'expected GlideIE._VALID_URL to be set to the correct value'

# Generated at 2022-06-22 07:41:10.847963
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:21.967180
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from . import GlideIE, _stderr_write, _stderr_reset, _unite_test
    from .common import InfoExtractor
    from .common import webpage
    from .common import SearchInfoExtractor

    _stderr_write('[Constructor of class GlideIE] [start]')

    glide_ie = GlideIE('GlideIE', 'glide', 'glide.me')
    # locate: glide_ie.suitable(self, url)
    assert glide_ie.suitable(GlideIE('GlideIE', 'glide', 'glide.me')._VALID_URL)
    assert not glide_ie.suitable('https://www.youtube.com/watch?v=BaW_jenozKc')

    # locate: glide_ie.extract(self, url)
    #

# Generated at 2022-06-22 07:41:56.091572
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import unittest
    class TestGlideIE(unittest.TestCase):
        def setUp(self):
            self.glide_test = GlideIE(
                                GlideIE._TEST)
        def test_id(self):
            self.assertEqual(
                self.glide_test._match_id(
                    GlideIE._TEST['url']),
                GlideIE._TEST['info_dict']['id'])
    unittest.main()


# Generated at 2022-06-22 07:42:01.832239
# Unit test for constructor of class GlideIE
def test_GlideIE():
	url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	class_ = GlideIE(url)

	assert_equal(class_.url, url)
	assert_equal(class_.parameters, {'id': 'UZF8zlmuQbe4mr+7dCiQ0w=='})	
	

# Generated at 2022-06-22 07:42:02.769863
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()

# Generated at 2022-06-22 07:42:03.886706
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:42:11.072040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    instance = GlideIE()
    expected = GlideIE._TEST
    actual = instance._real_extract(url)
    assert 'id' in actual
    assert expected['md5'] == actual['md5']
    assert expected['url'] == actual['url']
    assert expected['title'] == actual['title']
    assert expected['thumbnail'] == actual['thumbnail']

# Generated at 2022-06-22 07:42:14.980364
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test case for constructor
    from .test import make_test_case
    from .common import make_extractor

    # test case for constructor of GlideIE
    extracts = make_extractor(GlideIE, 'GlideIE')
    # test case for _real_extract method of GlideIE
    extracts += make_test_case(GlideIE, 'GlideIE')

    return extracts

# Generated at 2022-06-22 07:42:18.070474
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide.me'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:42:24.636111
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', 'Invalid GlideIE._VALID_URL'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)', 'Invalid GlideIE.IE_DESC'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'Invalid GlideIE._TEST[\'url\']'
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7', 'Invalid GlideIE._TEST[\'md5\']'


# Generated at 2022-06-22 07:42:29.042543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    assert GlideIE().IE_DESC == GlideIE._IE_DESC
    assert GlideIE()._TEST == GlideIE._TEST



# Generated at 2022-06-22 07:42:32.608594
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.ie_key() != "", "IE_KEY is not initialized in the GlideIE?!"


# Generated at 2022-06-22 07:43:43.014878
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    

# Generated at 2022-06-22 07:43:53.698192
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import copy
    import sys

    # check invalid urls are not allowed
    invalidUrl = "https://test.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glideObj = GlideIE()

    assert glideObj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

    # tests for _match_id
    # correct video id
    videoId = glideObj._match_id("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert videoId == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    videoId = glideObj._match_id

# Generated at 2022-06-22 07:44:04.802289
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r"https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-22 07:44:16.585380
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    info = glide._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['title'] == "Damon's Glide message"
    assert info['url'] == u'//d2m9uxzm54jtb.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==_hd.mp4'
    assert info['thumbnail'] == u'//d2m9uxzm54jtb.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==_small.jpg'

# Generated at 2022-06-22 07:44:17.718266
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)


# Generated at 2022-06-22 07:44:27.242394
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:44:38.564351
# Unit test for constructor of class GlideIE
def test_GlideIE():

    import unittest
    from . import GlideIE

    class GlideTestCase(unittest.TestCase):
        def setUp(self):
            self.glide = GlideIE()

        def test_constructor(self):
            self.assertEqual(self.glide.ie_key(), 'Glide')
            self.assertEqual(
                self.glide.IE_DESC,
                'Glide mobile video messages (glide.me)'
            )
            self.assertEqual(
                self.glide._VALID_URL,
                r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
            )

# Generated at 2022-06-22 07:44:47.474819
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    General test for GlideIE
    """
    glide_ie = GlideIE()
    assert glide_ie.IE_NAME == 'glide:share:glide.me'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:44:50.084225
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:44:53.096611
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()