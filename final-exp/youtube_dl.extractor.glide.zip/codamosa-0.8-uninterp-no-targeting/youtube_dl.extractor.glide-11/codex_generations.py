

# Generated at 2022-06-22 07:37:08.973916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(dict())
    assert isinstance(ie, InfoExtractor)
    assert ie._WORKING == True


# Generated at 2022-06-22 07:37:13.682461
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:15.373284
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:37:16.353715
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:37:23.785081
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.description == 'Glide mobile video messages (glide.me)'
    assert ie.id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.extractor == 'GlideIE'
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.title == "Damon's Glide message"


# Generated at 2022-06-22 07:37:25.611615
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    print(i.IE_DESC)

# Generated at 2022-06-22 07:37:31.799723
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.search_regex()
    assert len(ie.format_ids) == 1
    assert ie.url_result == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.num_entries == 1
    assert ie.file_downloader.ytdl_options == {'continuedl': False}

# Generated at 2022-06-22 07:37:32.318204
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:35.545377
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    GlideIE(url)

# Generated at 2022-06-22 07:37:36.953820
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor_constructor_test(GlideIE)

# Generated at 2022-06-22 07:37:53.661308
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:56.449512
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception as e:
        assert False, e.message



# Generated at 2022-06-22 07:38:02.449873
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    pattern = ie._VALID_URL
    match = ie._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert match == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:38:06.013152
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        # Testing of class GlideIE constructor
        assert GlideIE
    except AssertionError:
        raise AssertionError
test_GlideIE()

# Generated at 2022-06-22 07:38:06.864863
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-22 07:38:07.496915
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:38:10.209851
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:11.637669
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE()

# Generated at 2022-06-22 07:38:15.157040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert isinstance(glide, InfoExtractor)

# Generated at 2022-06-22 07:38:26.082006
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glide_ie = GlideIE(url)
    assert glide_ie.url == url, \
        "The object GlideIE doesn't get the right url"
    assert glide_ie.ie_key == 'Glide', \
        "The object GlideIE doesn't get the right ie_key"
    assert glide_ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w==', \
        "The object GlideIE doesn't get the right video_id"
    assert glide_ie.video_url == None, \
        "The object GlideIE doesn't get the right video_url"

# Generated at 2022-06-22 07:38:43.770307
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit test for constructor of class GlideIE
    obj = GlideIE('IE_DESC', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    # match_id will return the video ID of the URL
    assert obj._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w=='

    # _real_extract will return the video URL

# Generated at 2022-06-22 07:38:54.132734
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie

# Generated at 2022-06-22 07:39:03.247903
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("GlideIE")
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:39:04.344613
# Unit test for constructor of class GlideIE
def test_GlideIE():
    globals()['GlideIE']

# Generated at 2022-06-22 07:39:06.998433
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # The IE_DESC class variable is set in class InfoExtractor
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:39:07.621694
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:39:12.531865
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    print(ie)
    # testing if the variable info_dict is a dictionary or not
    assert(type(ie.info_dict) == type({}))

# Generated at 2022-06-22 07:39:16.944331
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test case for constructor with one argument
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:19.583680
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

test_GlideIE()

# Generated at 2022-06-22 07:39:21.345528
# Unit test for constructor of class GlideIE
def test_GlideIE():
	g = GlideIE()
	g._download_webpage
	return g._download_webpage


# Generated at 2022-06-22 07:39:38.214031
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, type), "GlideIE is not a class"
    assert issubclass(GlideIE, InfoExtractor), "GlideIE is not a subclass of InfoExtractor"



# Generated at 2022-06-22 07:39:49.126292
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:00.935013
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for class GlideIE
    
    Several unit tests are combined into one function since they are tested together.
    """

# Generated at 2022-06-22 07:40:07.995581
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for constructor of class GlideIE
    def test_constructor_1():
        # Test for correct output
        assert isinstance(GlideIE('glide'), GlideIE)

    def test_constructor_2():
        # Test for correct output
        assert isinstance(GlideIE(False), GlideIE)

    # Test for constructor of class GlideIE
    test_constructor_1()
    test_constructor_2()



# Generated at 2022-06-22 07:40:11.452397
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert isinstance(extractor, InfoExtractor)
    assert extractor._VALID_URL == GlideIE._VALID_URL
    assert extractor._TEST == GlideIE._TEST


# Generated at 2022-06-22 07:40:23.088925
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(InfoExtractor())

    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:24.790316
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie != None


# Generated at 2022-06-22 07:40:25.885900
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE()

# Generated at 2022-06-22 07:40:27.162044
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:37.082635
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert isinstance(ie._TEST, dict)
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert isinstance(ie._TEST['info_dict'], dict)

# Generated at 2022-06-22 07:41:12.434996
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:41:13.538268
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:41:18.338964
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()._get_info('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info.get('id')
    assert info.get('title')
    assert info.get('url')
    assert info.get('thumbnail')

# Generated at 2022-06-22 07:41:22.442169
# Unit test for constructor of class GlideIE
def test_GlideIE():
    r = GlideIE()
    assert r.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:41:24.633823
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:41:34.923789
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Test for constructor
	glide_ie = GlideIE()
	assert glide_ie.IE_NAME == 'Glide'
	assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:45.251536
# Unit test for constructor of class GlideIE
def test_GlideIE():
	print 

# Generated at 2022-06-22 07:41:47.215782
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:41:50.535973
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Initialize an object of class GlideIE with test for URL
    assert GlideIE(GlideIE._TEST)._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-22 07:41:52.094752
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.IE_NAME == 'Glide'

# Generated at 2022-06-22 07:42:59.635136
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'glide:share'

# Generated at 2022-06-22 07:43:04.726602
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test_cases = [
        (GlideIE, GlideIE._VALID_URL),
    ]
    for constructor_test_case in constructor_test_cases:
        constructor, (test_case, _expected_status) = constructor_test_case
        ie = constructor()
        assert ie._VALID_URL == GlideIE._VALID_URL


# Generated at 2022-06-22 07:43:05.841667
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download()

# Generated at 2022-06-22 07:43:11.390206
# Unit test for constructor of class GlideIE
def test_GlideIE():
	if 'glide' not in InfoExtractor._available_constructors:
		print("Error: InfoExtractor._available_constructors is missing 'glide'")
		return False

	print("Success: InfoExtractor._available_constructors.keys() has 'glide'")
	return True

# Generated at 2022-06-22 07:43:12.363579
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-22 07:43:13.298090
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:43:15.902042
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    assert t._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:43:16.780208
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-22 07:43:23.181587
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie.url_re() == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-22 07:43:23.769443
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:46:11.671265
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:46:18.168434
# Unit test for constructor of class GlideIE
def test_GlideIE():
    o = GlideIE()
    assert o.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert o._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:46:25.288159
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global IE
    IE = GlideIE()
    assert IE.IE_NAME == 'glide'
    assert IE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert IE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:46:29.659359
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:46:33.182889
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()

	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


#TODO: Add unit test for _real_extract

# Generated at 2022-06-22 07:46:34.720212
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert isinstance(extractor, GlideIE)

# Generated at 2022-06-22 07:46:45.391866
# Unit test for constructor of class GlideIE
def test_GlideIE(): 

    # Test correct URL
    correct_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    # Test incorrect URL
    incorrect_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==/"

    # Test GlideIE constructor with correct URL
    try:
        correct_ie = GlideIE(correct_url)
    except:
        assert False, "GlideIE constructor does not handle correct URL"

    # Test GlideIE constructor with incorrect URL
    try:
        incorrect_ie = GlideIE(incorrect_url)
        assert False, "GlideIE constructor does not handle incorrect URL"
    except:
        assert True

# Generated at 2022-06-22 07:46:54.669384
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE
    d = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    t(d)

# Generated at 2022-06-22 07:46:57.000758
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract(url=ie._VALID_URL, download=False)

# Generated at 2022-06-22 07:46:57.539154
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE({})