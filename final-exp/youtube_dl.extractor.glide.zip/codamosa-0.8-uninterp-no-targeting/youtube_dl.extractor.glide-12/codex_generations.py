

# Generated at 2022-06-22 07:37:07.966996
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide = GlideIE()

# Generated at 2022-06-22 07:37:18.321233
# Unit test for constructor of class GlideIE
def test_GlideIE():
    new = GlideIE(InfoExtractor())
    assert new.ie_key() == 'Glide'
    assert new.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert new._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:18.876823
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:27.126109
# Unit test for constructor of class GlideIE
def test_GlideIE():
    args = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    test_class = GlideIE()
    test_class.test_IE(args)

# Unit tests for methods of class GlideIE

# Generated at 2022-06-22 07:37:29.059114
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE(InfoExtractor())
    assert isinstance(glide, InfoExtractor)

# Generated at 2022-06-22 07:37:30.121084
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-22 07:37:32.844906
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
        print('test for constructor of class GlideIE passed!')
    except:
        print('test for constructor of class GlideIE failed!')

# Generated at 2022-06-22 07:37:37.104593
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = GlideIE(None)._VALID_URL
    match = GlideIE(None)._VALID_URL_RE.match(url)
    assert match.group('id') == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:37:38.925662
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'

# Generated at 2022-06-22 07:37:49.260245
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:00.736115
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE('http://share.glide.me/id')
    assert extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert extractor.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:38:12.588706
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IES = []
    video_urls = []
    video_ids = []
    titles = []
    thumbnails = []

    glideIE = GlideIE()
    for url in glideIE._TEST['url']:
        IES.append(glideIE._real_extract(url))

    for counter, ie in enumerate(IES):
        video_urls.append(ie['url'])
        video_ids.append(ie['id'])
        titles.append(ie['title'])
        thumbnails.append(ie['thumbnail'])

    assert glideIE._TEST['url'] == video_urls[0]
    assert glideIE._TEST['md5'] == video_ids[0]
    assert glideIE._TEST['info_dict']['title'] == titles[0]
    assert glide

# Generated at 2022-06-22 07:38:17.135963
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    result = IE._real_extract(url)
    assert(len(result) == 4)

# Generated at 2022-06-22 07:38:27.411179
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # test for _VALID_URL
    assert ie._VALID_URL =="https?://share\.glide\.me/([A-Za-z0-9\-=_+]+)"
    # test for _TEST

# Generated at 2022-06-22 07:38:30.257909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).IE_NAME == 'Glide'

# Generated at 2022-06-22 07:38:38.465019
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiate GlideIE class
    glide_ie = GlideIE()
    # Call _real_extract function with a GlideIE link
    glide_ie._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # _real_extract() should return a dictionary
    assert type(glide_ie._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")) == dict

# Generated at 2022-06-22 07:38:38.942077
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert True == False

# Generated at 2022-06-22 07:38:40.338709
# Unit test for constructor of class GlideIE
def test_GlideIE():
   assert 'GlideIE' == GlideIE().ie_key()


# Generated at 2022-06-22 07:38:45.246750
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == "Glide"
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-22 07:38:48.519379
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'http://localhost/watching')
    ie.extract()


# Generated at 2022-06-22 07:38:58.579430
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(InfoExtractor()).extract(url)

# Generated at 2022-06-22 07:38:59.993292
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-22 07:39:10.951447
# Unit test for constructor of class GlideIE
def test_GlideIE():
  assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
  assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
  

# Generated at 2022-06-22 07:39:12.276640
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:39:15.628118
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:39:26.552173
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:39:38.628570
# Unit test for constructor of class GlideIE
def test_GlideIE():
    items = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    obj = GlideIE(items)

# Generated at 2022-06-22 07:39:49.461711
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gIE = GlideIE()

# Generated at 2022-06-22 07:39:50.729655
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-22 07:39:55.294763
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glide = GlideIE()
    assert glide.IE_NAME == 'Glide'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide.ie_key() == 'Glide'


# Generated at 2022-06-22 07:40:11.593646
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE)._VALID_URL == GlideIE._VALID_URL
    assert GlideIE(GlideIE).IE_DESC == GlideIE.IE_DESC


# Generated at 2022-06-22 07:40:16.556530
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gIE = GlideIE()
    assert gIE.IE_DESC
    assert gIE._VALID_URL
    assert gIE._TEST
    assert gIE._real_extract
    assert gIE._real_extract(gIE._TEST['url'])

# Generated at 2022-06-22 07:40:18.773759
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_instance = GlideIE()
    assert class_instance._TEST['md5'] == class_instance._md5

# Generated at 2022-06-22 07:40:19.664839
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE(None)


# Generated at 2022-06-22 07:40:29.876995
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:40:30.643081
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:40:31.260374
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-22 07:40:41.003265
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test downloader.py
    glideIE = GlideIE()
    # Test constructie of the class
    assert glideIE.IE_NAME == "Glide"
    assert glideIE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert glideIE._VALID_URL == r"https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert glideIE._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert glideIE._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-22 07:40:41.924557
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:53.411030
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE()._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE()._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE()._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE()._TEST['info_dict']['ext'] == 'mp4'
    assert GlideIE()._T

# Generated at 2022-06-22 07:41:33.216714
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:36.437007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from . import r
    ie = r.get_info_extractor(GlideIE.ie_key())
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-22 07:41:48.325051
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert gie.IE_NAME == 'Glide'
    assert gie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert gie.IE_VERSION == None
    assert gie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert gie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert gie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert gie._

# Generated at 2022-06-22 07:41:50.327257
# Unit test for constructor of class GlideIE
def test_GlideIE():
	y = GlideIE()
	print(y.IE_DESC)

# Generated at 2022-06-22 07:41:56.641654
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    from .Extractor import Extractor

    e = Extractor(GlideIE(GlideIE._TEST))
    assert e.extract() == GlideIE._TEST['info_dict']

if __name__ == '__main__':
    import sys
    import unittest
    if sys.version_info.major == 2:
        unittest.main()

# Generated at 2022-06-22 07:42:03.266109
# Unit test for constructor of class GlideIE
def test_GlideIE():
    _f = GlideIE()
    assert _f.IE_NAME ==  'Glide'
    assert _f.IE_DESC ==  'Glide mobile video messages (glide.me)'
    assert _f._VALID_URL ==  r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:42:10.089734
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(glide._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-22 07:42:20.418066
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:42:25.159463
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    if not assertEqual(ie._VALID_URL,
                       "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="):
        raise RuntimeError("The default URL for GlideIE constructor is wrong!")



# Generated at 2022-06-22 07:42:36.765741
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""

    from .common import InfoExtractor
    from .glide import GlideIE
    from .pladform import PladformIE

    assert isinstance(GlideIE, type(InfoExtractor))
    assert not hasattr(GlideIE, "suitable")
    assert not hasattr(GlideIE, "url_result")
    assert hasattr(GlideIE, "_VALID_URL")
    assert GlideIE._VALID_URL == r"https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert not hasattr(GlideIE, "_TESTS")

    assert hasattr(GlideIE, "IE_DESC")

# Generated at 2022-06-22 07:43:52.863336
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, InfoExtractor)

# Generated at 2022-06-22 07:43:55.429896
# Unit test for constructor of class GlideIE
def test_GlideIE():
    unit_test_GlideIE = GlideIE()
    unit_test_GlideIE
    print(unit_test_GlideIE.IE_DESC)


# Generated at 2022-06-22 07:44:00.330809
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._download_webpage = lambda _, __: ''
    ie._og_search_title = lambda _: ''
    ie._proto_relative_url = lambda _: ''
    ie._search_regex = lambda *args: ''
    ie._html_search_regex = lambda *args: ''
    ie._og_search_thumbnail = lambda _: ''
    ie._og_search_video_url = lambda _: ''
    GlideIE._real_extract(ie, ie._VALID_URL)

# Generated at 2022-06-22 07:44:01.407817
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()

# Generated at 2022-06-22 07:44:05.787842
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert test._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:44:09.201498
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-22 07:44:13.434738
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    assert_equal(test_GlideIE.IE_NAME, 'GlideIE')
    assert_equal(test_GlideIE.IE_DESC, 'Glide mobile video messages (glide.me)')


# Generated at 2022-06-22 07:44:21.146682
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'glide:share'

# Generated at 2022-06-22 07:44:28.270648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test for class GlideIE constructor
    """
    # assert that an exception is not raised for a known video glide
    GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

    # assert that an exception is raised for a bad glide
    with pytest.raises(ValueError):
        GlideIE("https://share.glide.me")

# Generated at 2022-06-22 07:44:34.399412
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.ie_key() == 'Glide'
    assert instance.IE_NAME == 'Glide'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'