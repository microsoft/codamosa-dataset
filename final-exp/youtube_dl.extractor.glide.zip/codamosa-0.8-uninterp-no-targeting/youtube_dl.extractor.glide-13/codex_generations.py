

# Generated at 2022-06-22 07:37:06.525655
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()

# Generated at 2022-06-22 07:37:16.853638
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert instance._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert instance._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:37:18.093297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.ie_key() == 'Glide')

# Generated at 2022-06-22 07:37:26.895376
# Unit test for constructor of class GlideIE
def test_GlideIE():
	myGlideIE = GlideIE()

	# Test for fetching video title with given video id

# Generated at 2022-06-22 07:37:28.414281
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test class GlideIE constructor"""
    glide = GlideIE()

# Generated at 2022-06-22 07:37:31.567105
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:37:34.819761
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global glide;
    glide = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")


# Generated at 2022-06-22 07:37:46.198633
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import sys
    if sys.version_info.major == 2:
        import __builtin__ as builtins
    else:
        import builtins
    builtins.globals()['__builtins__'] = {}
    builtins.globals()['__builtins__']['globals'] = {}
    builtins.globals()['__builtins__']['globals']['__builtins__'] = {}
    builtins.globals()['__builtins__']['globals']['__builtins__']['__import__'] = None
    builtins.globals()['__builtins__']['globals']['__builtins__']['abs'] = None

# Generated at 2022-06-22 07:37:48.526869
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('glideie', '0.0.1', {}, False)
    assert ie._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-22 07:37:49.015257
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:37:57.818908
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-22 07:38:09.494539
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print(ie)
    print(ie.IE_DESC)
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    print(ie.IE_NAME)
    assert ie.IE_NAME == "Glide"
    print(ie.VALID_URL)
    assert ie.VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    print(ie._TEST)
    test_url = ie._TEST['url']
    print("test_url:", test_url)
    print("ie.suitable(test_url)?")
    assert ie.suitable(test_url) is True
    print("ie.working()?")
   

# Generated at 2022-06-22 07:38:21.628625
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-22 07:38:33.001086
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie.event_type == 'video')
    assert(ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie.VALID_URL == GlideIE._VALID_URL)
    assert(ie._TEST == GlideIE._TEST)
    assert(ie._real_extract == GlideIE._real_extract)
    assert(ie.IE_DESC == GlideIE.IE_DESC)

# Generated at 2022-06-22 07:38:37.288121
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:38:37.809512
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(True)

# Generated at 2022-06-22 07:38:49.031596
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:00.940065
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:39:06.605647
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:10.217716
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:19.483735
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:31.333959
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://www.youtube.com/watch?v=BaW_jenozKc')
    GlideIE('http://www.youtube.com/embed/BaW_jenozKc')
    GlideIE('http://www.youtube.com/v/BaW_jenozKc')
    GlideIE('http://www.youtube.com/e/BaW_jenozKc')
    GlideIE('http://www.youtube.com/?v=BaW_jenozKc')
    GlideIE('http://www.youtube.com/watch?feature=player_embedded&v=BaW_jenozKc')
    GlideIE('http://youtu.be/BaW_jenozKc')

# Generated at 2022-06-22 07:39:42.276692
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:51.227153
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:39:55.887346
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	test_object = GlideIE()
	test_object.suitable(test_url)
	test_object.extract(test_url)

# Generated at 2022-06-22 07:39:59.716431
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Testing constructor
    ie = GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:40:10.753715
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.IE_NAME == 'Glide'
    # Test _VALID_URL
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Test _TEST
    assert i._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert i._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:40:11.452227
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:17.713706
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:40:19.967956
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/JgKjWkF8dv2OaOzjX9qJIQ==')

# Generated at 2022-06-22 07:40:34.090581
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("Run into GlideIE constructor")
    glide_ie = GlideIE()
    print("glide_ie:",glide_ie)

# Generated at 2022-06-22 07:40:35.722982
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_Glide = GlideIE()

# Generated at 2022-06-22 07:40:37.279843
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:41.816451
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-22 07:40:42.434277
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:40:53.914405
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:55.347057
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = GlideIE()
    assert infoExtractor is not None

# Generated at 2022-06-22 07:40:57.977305
# Unit test for constructor of class GlideIE
def test_GlideIE():
    temp_GlideIE = GlideIE(InfoExtractor())
    assert isinstance(temp_GlideIE, GlideIE)

# Generated at 2022-06-22 07:41:05.965961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.name() == "GlideIE"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-22 07:41:07.499735
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE({},'')

# Generated at 2022-06-22 07:41:38.161341
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(isinstance(GlideIE(), GlideIE))

# Generated at 2022-06-22 07:41:39.223261
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-22 07:41:40.205445
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass


# Generated at 2022-06-22 07:41:41.656229
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('Glide')
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-22 07:41:44.508523
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:41:48.221390
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    assert GlideIE()._TEST['url'] == GlideIE._TEST['url']
# vim: set ts=4 sw=4 sts=4 et:

# Generated at 2022-06-22 07:42:00.157484
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create an object of the GlideIE class
    glideIE = GlideIE()

    # Check if GlideIE object is not None
    assert glideIE is not None

    # Check if GlideIE object is an instance of the InfoExtractor class
    assert isinstance(glideIE, InfoExtractor)

    # Check if the the class attributes are not None
    assert glideIE._downloader is not None
    assert glideIE._download_webpage is not None
    assert glideIE._download_xml is not None
    assert glideIE._downloader_cache is not None
    assert glideIE._html_search_regex is not None
    assert glideIE._html_search_meta is not None
    assert glideIE._json_search is not None
    assert glideIE._LOGGER is not None
    assert glideIE._match_id is not None
   

# Generated at 2022-06-22 07:42:10.735968
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE().extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert info is not None
    assert info["title"] == "Damon's Glide message"
    assert info["id"] == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert info["url"] == "https://d2xht16hs8tbvf.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==-2016-10-12-11-08-23/video-2016-10-12-11-08-23.mp4"

# Generated at 2022-06-22 07:42:11.240062
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:42:17.151346
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test GlideIE by giving a url which link to a Glide video
    """
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    GlideIE = GlideIE()
    GlideIE.extract(url)

# Generated at 2022-06-22 07:43:38.918457
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:43:41.865981
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor(None)
    assert ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:43:52.616527
# Unit test for constructor of class GlideIE
def test_GlideIE():
  # Initialise the IE
  ie = GlideIE()
  # Test input
  test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
  # Expected output
  test_url_expected_result = {
    'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
    'ext': 'mp4',
    'title': 'Damon\'s Glide message',
    'thumbnail': 'https://d1m59l5oyvgm9h.cloudfront.net/UZF8zlmuQbe4mr-7dCiQ0w_thumb.jpg'
  }
  # Test
  test_url_result = ie._real_extract(test_url)
 

# Generated at 2022-06-22 07:43:56.792690
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:44:02.334476
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:44:02.961438
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-22 07:44:03.585332
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:44:15.265396
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert (ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert (ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-22 07:44:16.340467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide'

# Generated at 2022-06-22 07:44:17.374111
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-22 07:46:53.545311
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    # The __init__ function of the class will call assert True, if it is called without parameters
    assert True

# Generated at 2022-06-22 07:46:55.121059
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extraction_class = GlideIE()
    extraction_class._match_id("dsadsadsa")
    
test_GlideIE()

# Generated at 2022-06-22 07:47:02.362978
# Unit test for constructor of class GlideIE
def test_GlideIE():
	#Set up the test suite
	import unittest
	#Set up the test cases