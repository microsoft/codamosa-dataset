

# Generated at 2022-06-22 07:37:08.893308
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE."""
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    GlideIE(url, "test")


# Generated at 2022-06-22 07:37:09.721564
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None, None)


# Generated at 2022-06-22 07:37:19.877963
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Input data for testing

# Generated at 2022-06-22 07:37:23.263982
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create a GlideIE instance for unit test
    glide_ie = GlideIE()
    # Test method _real_extract
    glide_ie._real_extract(glide_ie._TEST.get('url'))

# Generated at 2022-06-22 07:37:25.338623
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(0)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:37:28.145889
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE().extract(url)

# Generated at 2022-06-22 07:37:30.483542
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert(obj._VALID_URL is not None)
    assert(obj._TEST is not None)


# Generated at 2022-06-22 07:37:31.567901
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST

# Generated at 2022-06-22 07:37:32.354290
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj

# Generated at 2022-06-22 07:37:44.228154
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    sample_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert test_GlideIE._match_id(sample_url) == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-22 07:37:48.199941
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE('www.glide.me')

# Generated at 2022-06-22 07:37:50.748094
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructorGlideIE = GlideIE('extractor')
    assert constructorGlideIE


# Generated at 2022-06-22 07:37:53.205064
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:37:54.590861
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    GlideIE()

# Generated at 2022-06-22 07:38:05.963896
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:08.058292
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-22 07:38:09.127677
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE([])

# Generated at 2022-06-22 07:38:11.775063
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception as e:
        assert False

# Generated at 2022-06-22 07:38:17.240592
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj1 = GlideIE()
    assert obj1.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj1._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:38:19.542232
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:38:30.501001
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj.id == 'UZF8zlm..CiQ0w=='
    assert obj.ie_key() == 'Glide'

# Generated at 2022-06-22 07:38:35.781623
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
        ie = GlideIE(url)
    except Exception as e:
        raise Exception("Unable to create object of class GlideIE\n{}".format(e))


# Generated at 2022-06-22 07:38:44.774967
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Set up constant values to be used for testing
    TEST_CONSTANT_URL1 = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    TEST_CONSTANT_URL2 = "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    TEST_CONSTANT_URL3= "http://share.glide.me/g0"
    TEST_CONSTANT_URL4 = "https://share.glide.me/fakeUrl"

    # Test that the two URLs work
    instance = GlideIE(TEST_CONSTANT_URL1)

# Generated at 2022-06-22 07:38:49.625907
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('https://www.glide.me/video/fb2f5a5f5c7042a18f7f8fd3cd6a04d3/send')
    assert obj.constructor_args == ['https://www.glide.me/video/fb2f5a5f5c7042a18f7f8fd3cd6a04d3/send',]

# Generated at 2022-06-22 07:38:51.347862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test if the object is instantiated correctly
    GlideIE

# Generated at 2022-06-22 07:38:56.132321
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == "Glide mobile video messages (glide.me)"
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:02.499428
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_class = GlideIE(None)
    assert test_class.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_class._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:39:08.402206
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
        assert True
    except:
        assert False

# Generated at 2022-06-22 07:39:09.559665
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE(InfoExtractor()))

# Generated at 2022-06-22 07:39:10.490859
# Unit test for constructor of class GlideIE
def test_GlideIE():
    m = GlideIE()
    assert m != None

# Generated at 2022-06-22 07:39:23.789317
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_Glide = GlideIE()
    test_Glide.constructor()

# Generated at 2022-06-22 07:39:25.356879
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g != None


# Generated at 2022-06-22 07:39:37.545930
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['title'] == "Damon's Glide message"
    assert info['url'] == 'https://d1e4pidl3fu268.cloudfront.net/snapchat/UZF8zlmuQbe4mr+7dCiQ0w==/mp4.mp4'
    assert info['thumbnail'] == 'https://d1e4pidl3fu268.cloudfront.net/snapchat/UZF8zlmuQbe4mr+7dCiQ0w==/thumbnail.jpg'

# Generated at 2022-06-22 07:39:39.288742
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("https://share.glide.me/AZU_1VdYTg-kA80oWQVRvQ==")

# Generated at 2022-06-22 07:39:49.933986
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:01.591094
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Input
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Expected output
    # ie.TEST
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:40:09.739453
# Unit test for constructor of class GlideIE
def test_GlideIE():
   # Set up test environment
   i=GlideIE(InfoExtractor)
   i.add_default_info_extractors()
   i.report_warning = lambda *args, **kwargs: None
   i.report_error = lambda *args, **kwargs: None
   assert i.IE_DESC=='Glide mobile video messages (glide.me)'
   assert i._VALID_URL==r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
   


# Generated at 2022-06-22 07:40:16.773105
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    testurl = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    testid = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert testid == ie._match_id(testurl)
    assert ie.IE_DESC == ie.ie_key()

# Generated at 2022-06-22 07:40:28.179755
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert('glide.me' in ie.IE_DESC)
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-22 07:40:30.564453
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:41:00.528634
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.ie_key() == 'Glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._WORKING == True

# Generated at 2022-06-22 07:41:04.483788
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-22 07:41:10.443138
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE.
    """
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:21.640915
# Unit test for constructor of class GlideIE
def test_GlideIE():
    req = GlideIE()

    assert req.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert req._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:24.624384
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE._VALID_URL)
    assert ie._VALID_URL == GlideIE._VALID_URL



# Generated at 2022-06-22 07:41:27.034094
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:41:31.439466
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_name = 'GlideIE'
    ie = GlideIE()
    assert ie.__class__.__name__ == class_name, 'test_GlideIE: AssertionError'
    assert ie.ie_key() == class_name, 'test_GlideIE: AssertionError'


# Generated at 2022-06-22 07:41:33.171911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:41:40.148560
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE(GlideIE.ie_key())
    assert a.ie_key() in ('Glide', 'glide')
    assert a.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert a.suitable('http://share.glide.me/wq3k-NyMi0+yKjxieBJD9g==')
    assert not a.suitable('http://share.glide.me/')
    assert not a.suitable('http://share.glide.me')


# Generated at 2022-06-22 07:41:43.802895
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:42:38.665677
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:42:47.692090
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This function tests the constructor of class GlideIE
    # The following are the basic steps:
    # 1) Instantiate an instance of GlideIE
    # 2) Call the method real_extract() of GlideIE instance
    # 3) Check if meta data such as the video title and download link is captured
    # The extracted parameters are checked against the TEST case at the top of the file.
    glide_ie = GlideIE()
    glide_info = glide_ie._real_extract(glide_ie._TEST['url'])

    assert glide_info['id'] == glide_ie._TEST['info_dict']['id']
    assert glide_info['title'] == glide_ie._TEST['info_dict']['title']

# Generated at 2022-06-22 07:42:57.746867
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    print("Testing GlideIE")
    # Test constructor of GlideIE
    # ValueError should be raised
    try:
        GlideIE('glide.me')
        print("FAIL: ValueError exception should have been raised")
    except ValueError:
        print("PASS: ValueError exception has been raised")

    # Test constructor of GlideIE
    # ValueError should be raised
    try:
        GlideIE('https://www.glide.me/')
        print("FAIL: ValueError exception should have been raised")
    except ValueError:
        print("PASS: ValueError exception has been raised")

    # Test constructor of GlideIE
    # ValueError should be raised

# Generated at 2022-06-22 07:43:01.063304
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:43:02.710023
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:43:10.682010
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE.suitable('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE.suitable('https://static.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    assert not GlideIE.suitable('http://www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not GlideIE.suitable('http://www.example.com/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:43:11.792070
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(GlideIE())

# Generated at 2022-06-22 07:43:14.463377
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        raise Exception("Unit test for GlideIE: can not create instance.")

# Generated at 2022-06-22 07:43:15.691053
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).ie_key() == 'Glide'

# Generated at 2022-06-22 07:43:16.402511
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:45:38.254124
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:45:44.607055
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:45:45.564664
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie)

# Generated at 2022-06-22 07:45:46.236150
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:45:49.585199
# Unit test for constructor of class GlideIE
def test_GlideIE():
    exampleGlideLink = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    ie = GlideIE(exampleGlideLink)

    assert ie is not None

# Generated at 2022-06-22 07:45:50.381172
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert True


# Generated at 2022-06-22 07:45:52.389138
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie


# Generated at 2022-06-22 07:46:01.665380
# Unit test for constructor of class GlideIE

# Generated at 2022-06-22 07:46:06.718640
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import sys
    from ytdl.extractor.common import InfoExtractor
    from ytdl.extractor.glide import GlideIE
    assert issubclass(GlideIE, InfoExtractor)
    if sys.version_info.major == 2:
        return
    assert dir(GlideIE) == dir(InfoExtractor)


# Generated at 2022-06-22 07:46:09.530101
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie=GlideIE()
    index=0
    ie.extract('http://share.glide.me/'+test.test_glide_id[index])
    print('unit test passed: ' + test.test_glide_id[index])