

# Generated at 2022-06-22 07:37:06.917599
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-22 07:37:07.514391
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE

# Generated at 2022-06-22 07:37:09.565235
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:37:14.372647
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ GlideIE class allows to create instance of class GlideIE using GlideIE class name and parameter.
    """
    obj = GlideIE('GlideIE', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj



# Generated at 2022-06-22 07:37:16.807263
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    if ie.IE_DESC != 'Glide mobile video messages (glide.me)':
        raise Exception('Wrong IE_DESC')

# Generated at 2022-06-22 07:37:19.451627
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "GlideIE"
    assert ie.IE_DESC is not None
    assert ie._VALID_URL is not None


# Generated at 2022-06-22 07:37:20.680003
# Unit test for constructor of class GlideIE
def test_GlideIE():
    objGlideIE = GlideIE()

# Generated at 2022-06-22 07:37:24.265635
# Unit test for constructor of class GlideIE
def test_GlideIE():
	url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	x = GlideIE()
	x._real_extract(url)

# Generated at 2022-06-22 07:37:35.905656
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("GlideIE")
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-22 07:37:36.503835
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-22 07:37:42.055053
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE("www.youtube.com")
        assert False
    except NotImplementedError:
        assert True



# Generated at 2022-06-22 07:37:53.305929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_NAME = 'Glide'
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:37:55.158446
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == ie.ie_key()

# Generated at 2022-06-22 07:37:59.073291
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:38:10.805999
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:16.098262
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor.IE_NAME == 'Glide mobile video messages (glide.me)'
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'

# Unit tests for _real_extract() of class GlideIE

# Generated at 2022-06-22 07:38:26.697659
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert test.IE_NAME == 'Glide Video Share'
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test.VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:37.933912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance
    # test for attributes of class InfoExtractor
    assert instance.ie_key() == 'Glide'
    assert instance.ie_desc() == 'Glide mobile video messages (glide.me)'
    # test for attribute of class GlideIE
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert instance._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert instance._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    

# Generated at 2022-06-22 07:38:49.031382
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:38:51.160507
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test_GlideIE = GlideIE("test constructor")
	assert test_GlideIE.test_GlideIE == True

# Generated at 2022-06-22 07:38:58.313984
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE."""
    GlideIE()

# Generated at 2022-06-22 07:39:02.764600
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:05.039812
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-22 07:39:16.607198
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:28.083603
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:39:29.215182
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(GlideIE())

# Generated at 2022-06-22 07:39:35.928092
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test a valid url
    url = 'http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D'
    assert GlideIE().suitable(url)

    # Test an invalid url
    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    assert not GlideIE().suitable(url)


# Generated at 2022-06-22 07:39:39.442321
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.extract("http://share.glide.me/u/7QgQONzOTA1NWVl")

# Generated at 2022-06-22 07:39:43.817735
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE('Glide', 'http://www.glide.me')
    assert g.name == 'Glide'
    assert g.IE_NAME == 'Glide'
    assert g.ie_key() == 'Glide'

# Generated at 2022-06-22 07:39:44.367952
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:39:56.638822
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-22 07:39:58.977123
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Basic test to ensure constructor is working as expected
    """
    assert GlideIE(None)

# Generated at 2022-06-22 07:40:04.015066
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:40:14.681929
# Unit test for constructor of class GlideIE
def test_GlideIE():
	class_name = 'GlideIE'
	url = 'http://share.glide.me/qN_ClAe-OZ2QJZzG3fWgKQ=='
	# Constructor tests
	GlideIE('extract', url, 9999)
	GlideIE('extract', url, False)
	GlideIE('extract', url, True)
	GlideIE(lambda x,y,z: None, url, True)
	GlideIE(lambda x: None, url, True)
	GlideIE(None, url, True)

	# Method tests
	#TODO test_real_download('real_download', url, class_name)
	#TODO test_real_extract('real_extract', url, class_name, None)
	#TODO test

# Generated at 2022-06-22 07:40:16.556864
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-22 07:40:18.228298
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('GlideIE')
    ie.extract('dummy')

# Generated at 2022-06-22 07:40:20.904771
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:40:32.230701
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Testing parsing of GlideIE
    assert GlideIE(GlideIE._downloader)._match_id(_TEST_URL) == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # Testing url fetching
    assert GlideIE(GlideIE._downloader)._real_extract(_TEST_URL)['url'] == 'https://storage.googleapis.com/glide-prod/video_streams/videos/fdbba594d2c60ecaa2b95ffcdaadf00547e67f61/video-fdbba594d2c60ecaa2b95ffcdaadf00547e67f61-720.mp4'

########### Unittest code #############################
# Global variables for unittest

# Generated at 2022-06-22 07:40:35.993687
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test create new GlideIE instance
    ie = GlideIE()
    expected_ie_desc = 'Glide mobile video messages (glide.me)'
    assert ie.IE_DESC == expected_ie_desc

test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-22 07:40:40.012944
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"


# Generated at 2022-06-22 07:41:14.065710
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """GlideIE instantiation test

    This test will check for exceptions raised by GlideIE constructor.
    """
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.name == 'Glide'
    assert ie.ie_key == 'Glide'
    assert ie.host == 'share.glide.me'
    assert ie.url_re.match("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-22 07:41:17.705974
# Unit test for constructor of class GlideIE
def test_GlideIE():
    globals()["GlideIE"]("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
### END OF HIDDEN TESTS

# Generated at 2022-06-22 07:41:20.289238
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:41:24.958435
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # GlideIE wasn't inheriting from InfoExtractor in a previous version, so
    # check that it is inheriting now.
    assert issubclass(GlideIE, InfoExtractor)
    # Also check that the constructor is not a bound method.
    assert GlideIE.__init__.__self__ is None

# Generated at 2022-06-22 07:41:26.062813
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-22 07:41:30.938819
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)', "Description should match"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', "URL should match"

# Generated at 2022-06-22 07:41:34.001676
# Unit test for constructor of class GlideIE
def test_GlideIE():
	instance = GlideIE()
	instance.extract(instance._TEST['url'])

# Generated at 2022-06-22 07:41:35.878628
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-22 07:41:47.682655
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-22 07:41:53.354636
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:42:56.621770
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    assert inst._TEST == {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

# Generated at 2022-06-22 07:43:02.789413
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from collections import namedtuple
    from .common import InfoExtractor
    from .common import InfoExtractorTest
    from .common import json

    testcase = namedtuple('TestCase', ['glide_link', 'glide_id'])


# Generated at 2022-06-22 07:43:10.701228
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Class GlideIE should have the following attributes:
    """
    # Testing the GlideIE class
    ie = GlideIE()  ## Initializing a GlideIE object
    # Testing the id of the class
    assert ie.IE_NAME == 'Glide'
    # Testing the class name
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    # Testing the url regex
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Testing the _TEST dictionary of the class

# Generated at 2022-06-22 07:43:11.815714
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE(None)

# Generated at 2022-06-22 07:43:18.128109
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_obj = GlideIE()
    assert ie_obj.IE_NAME == "glide"
    assert ie_obj.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie_obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:43:20.562800
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-22 07:43:29.778367
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test the constructor of GlideIE
    ie = GlideIE()
    # Test whether the IE name was correctly set
    assert ie.ie_key() == 'Glide'
    # Test whether the IE description was correctly set
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    # Test whether the IE should be considered reliable
    assert ie.ie_is_reliable() == False
    # Test whether the IE is suitable for the given URL
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True
    assert ie.suitable('http://www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == False
    # Test whether the video ID

# Generated at 2022-06-22 07:43:31.478651
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test(GlideIE)

# Generated at 2022-06-22 07:43:36.955491
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ieTest = GlideIE()
    assert ieTest.IE_NAME == 'Glide'
    assert ieTest.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ieTest._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-22 07:43:48.133568
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class Args(object):
        def __init__(self, url, ie, video_id, query, download, Note='', expected_success=True):
            self.url = url
            self.ie = ie
            self.video_id = video_id
            self.query = query
            self.download = download
            self.Note = Note
            self.expected_success = expected_success

    def test(args):
        # Runs the unit test for class GlideIE
        # Args:
        #    args:       arguments as given by the user.
        #
        # Returns:
        #    True or False depending on the outcome of the unit test.

        url = args.url
        ie = args.ie
        video_id = args.video_id
        query = args.query
        download = args.download
        note

# Generated at 2022-06-22 07:46:04.418909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor()).suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-22 07:46:07.940139
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr'
    GlideIE(url)



# Generated at 2022-06-22 07:46:10.977411
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert GlideIE.IE_DESC == obj.IE_DESC
    assert GlideIE._VALID_URL == obj._VALID_URL


# Generated at 2022-06-22 07:46:17.655116
# Unit test for constructor of class GlideIE
def test_GlideIE():
    URL = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ID = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    TEST = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': ID,
            'title': 'Damon\'s Glide message',
            'ext': 'mp4',
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    glideIE

# Generated at 2022-06-22 07:46:20.769819
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='),
                      GlideIE)

# Generated at 2022-06-22 07:46:21.386003
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-22 07:46:23.518641
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-22 07:46:31.031561
# Unit test for constructor of class GlideIE
def test_GlideIE():
	print('Testing GlideIE class')
	attach_credentials()	
	print('Testing GlideIE constructor')
	glide_ie = GlideIE()
	print('Testing GlideIE constructor successful')	
	print('Testing GlideIE _real_extract method')	
	glide_ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	print('Testing GlideIE _real_extract method successful')	
	print('Testing GlideIE class successfully finished')

# Generated at 2022-06-22 07:46:31.780903
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-22 07:46:37.349916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    title = "Damon's Glide message"
    video_url = "https://s3.amazonaws.com/glide-production/video-messages/UZF8zlmuQbe4mr+7dCiQ0w==/original.mp4"
    thumbnail = "https://d2m2gkuc36tfn8.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==-1427886945.jpg"
    description="Cool Glide message by Damon"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'