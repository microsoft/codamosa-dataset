

# Generated at 2022-06-26 12:00:18.393554
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:00:21.140685
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:22.624377
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()

# Generated at 2022-06-26 12:00:27.051272
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("test_GlideIE")

    try:
        glide_i_e_0 = GlideIE()
    except TypeError as err:
        print("test_GlideIE: TypeError: " + str(err))


# Generated at 2022-06-26 12:00:29.997871
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_1 = GlideIE()


# Generated at 2022-06-26 12:00:31.983748
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()



# Generated at 2022-06-26 12:00:33.563933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert glide_i_e_0 != None


# Generated at 2022-06-26 12:00:35.569897
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE == GlideIE)


# Generated at 2022-06-26 12:00:43.652832
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiation using default constructor
    glide_i_e_0 = GlideIE()
    assert glide_i_e_0._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_i_e_0.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_i_e_0.IE_NAME == 'glide'

# Generated at 2022-06-26 12:00:48.446674
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()
    assert isinstance(glide_i_e_0, GlideIE), "test_GlideIE class GlideIE creation failed"


# Generated at 2022-06-26 12:00:56.782925
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:00:59.917334
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r"https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.extractor == GlideIE

# Generated at 2022-06-26 12:01:03.851443
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception:
        print("Unit test for constructor of class GlideIE FAILED")
        raise



# Generated at 2022-06-26 12:01:04.723029
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:05.534355
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:09.255360
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:19.136658
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE({
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
            'url': 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
        })

# Generated at 2022-06-26 12:01:32.045865
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()

    assert(glide.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:01:33.406531
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for constructor
    ie = GlideIE()

# Generated at 2022-06-26 12:01:38.364269
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie = GlideIE('GlideIE')
    ie = GlideIE(ie)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:01:45.417953
# Unit test for constructor of class GlideIE
def test_GlideIE():
	"""Unit test function for class GlideIE."""
	GlideIE(InfoExtractor(), {}, {}, {})

# Generated at 2022-06-26 12:01:54.801494
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:00.999947
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:02:04.598703
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    assert GlideIE(GlideIE.get_url_regex(GlideIE._VALID_URL))


# Generated at 2022-06-26 12:02:07.551968
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:08.378467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:02:20.950787
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()._real_extract(url)
    assert ie['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie['title'] == "Damon's Glide message"
    assert ie['thumbnail'] == 'https://8d90618d45113b00bd1d-c6f8d0311c049bf42b1e84b5515d5f5d.ssl.cf5.rackcdn.com/UZF8zlmuQbe4mr+7dCiQ0w==.jpg'

# Generated at 2022-06-26 12:02:29.329786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video_id = glide_ie._match_id(url)
    webpage = glide_ie._download_webpage(url, video_id)
    title = glide_ie._html_search_regex(r'<title>(.+?)</title>', webpage, 'title', default=None)

# Generated at 2022-06-26 12:02:31.368214
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-26 12:02:37.975694
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gl = GlideIE()
    assert gl.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert gl._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-26 12:02:55.709262
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print ("\n" + GlideIE._TEST)
    print ("\n" + GlideIE._VALID_URL)
    print ("\n" + GlideIE._IE_DESC)

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-26 12:03:03.758545
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    #TODO Note: how to write regex in python?

# Generated at 2022-06-26 12:03:05.589553
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test noop
    pass

# Generated at 2022-06-26 12:03:06.690648
# Unit test for constructor of class GlideIE
def test_GlideIE():
	print("Running unit test for GlideIE() class constructor...")	
	assert 1==1	

# Generated at 2022-06-26 12:03:14.843021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert_equal(ie.IE_DESC, 'Glide mobile video messages (glide.me)')
    assert_equal(ie._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:03:16.232409
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-26 12:03:23.736021
# Unit test for constructor of class GlideIE
def test_GlideIE():

	# Check that variables were wired up correctly
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:34.223661
# Unit test for constructor of class GlideIE
def test_GlideIE():
    YoutubeIE_test_cases = [
        {
            'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
            'expected': {
                'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
                'title': "Damon's Glide message",
                'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
            }
        },
    ]
    for test_case in YoutubeIE_test_cases:
        url = test_case['url']
        expected = test_case['expected']
        ie = GlideIE(downloader=None) # no need to pass in downloader
        result = ie.extract(url)

# Generated at 2022-06-26 12:03:35.091004
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE.IE_DESC

# Generated at 2022-06-26 12:03:40.591175
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:09.204426
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = GlideIE()
    assert isinstance(result, GlideIE)

# Generated at 2022-06-26 12:04:12.113429
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except TypeError:
        print('Unable to create instance, constructor requires one argument')



# Generated at 2022-06-26 12:04:19.873602
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Test the method of class GlideIE

# Generated at 2022-06-26 12:04:25.011573
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test GlideIE"""
    glide_ie = GlideIE()
    assert glide_ie.extractor_key == GlideIE.IE_KEY
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.test()

# Generated at 2022-06-26 12:04:26.251525
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-26 12:04:32.747111
# Unit test for constructor of class GlideIE
def test_GlideIE():
    'Test the constructor of class GlideIE.'
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:04:45.397439
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:47.170830
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:48.514661
# Unit test for constructor of class GlideIE
def test_GlideIE():
  """ No unit test for GlideIE """
  return

# Generated at 2022-06-26 12:04:58.322613
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE.
    """

    # Possible inputs for GlideIE.__init__ are:
    #   __init__(self, ie_name=None, ie_id=None,
    #            downloader=None, params={})
    #   __init__(self, downloader=None)

    # Test the first constructor of GlideIE class
    # Expected: an object of GlideIE class
    assert isinstance(GlideIE(ie_name='glide', ie_id='glide',
                              downloader=None, params={}),
                      GlideIE)
    assert isinstance(GlideIE(ie_name='glide', ie_id='glide'), GlideIE)
    assert isinstance(GlideIE(ie_name='glide'), GlideIE)

# Generated at 2022-06-26 12:06:12.360536
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._build_url(None) is None


# Generated at 2022-06-26 12:06:13.772436
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(GlideIE(None))


# Generated at 2022-06-26 12:06:16.573020
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == GlideIE.IE_DESC

# Generated at 2022-06-26 12:06:17.661522
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE == InfoExtractor


# Generated at 2022-06-26 12:06:18.505101
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:06:30.232772
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests for constructor without any argument
    try:
        ie = GlideIE()
    except Exception:
        # "if any exception is raised in the constructor, it fails"
        assert False

    # Tests for constructor with empty argument
    try:
        ie1 = GlideIE('')
    except Exception:
        # "if any exception is raised in the constructor, it fails"
        assert False

    # Tests for constructor with valid argument
    try:
        ie2 = GlideIE('arXiv')
    except Exception:
        # "if any exception is raised in the constructor, it fails"
        assert False
    assert ie2.ie_key() == 'arXiv'
    assert ie2.ie_key() != 'Glide'

# Generated at 2022-06-26 12:06:31.517292
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()


# Generated at 2022-06-26 12:06:41.444157
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title']

# Generated at 2022-06-26 12:06:45.849467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:53.432570
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()._real_extract(r'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info[u'id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['title'] == "Damon's Glide message"

# Generated at 2022-06-26 12:09:36.975021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test object creation
    obj = GlideIE("http://share.glide.me/h0JgSiTlTlKAs0Kl+JWBbw==")
    assert isinstance(obj, GlideIE)

# Generated at 2022-06-26 12:09:39.973377
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-26 12:09:48.949443
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test that the GlideIE constructor works correctly."""
    if not hasattr(GlideIE, "IE_DESC"):
        raise AssertionError("GlideIE.IE_DESC not defined.")
    if not hasattr(GlideIE, "_VALID_URL"):
        raise AssertionError("GlideIE._VALID_URL not defined.")
    if not hasattr(GlideIE, "_TEST"):
        raise AssertionError("GlideIE._TEST not defined.")
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._T

# Generated at 2022-06-26 12:09:50.264337
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:09:53.170191
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:09:56.889552
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:09:59.174195
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    ie.initialize()
    assert ie.ie_key() == 'glide'
# Testcase for constructor of class GlideIE where
# IE extractor is initialized

# Generated at 2022-06-26 12:10:06.985408
# Unit test for constructor of class GlideIE
def test_GlideIE():

    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'