

# Generated at 2022-06-26 12:00:10.462905
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass # TODO

# Generated at 2022-06-26 12:00:14.550495
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    if glide_i_e is not None:
        print("GlideIE class instance is created successfully")
    else:
        print("Failed to create GlideIE class instance")

# Generated at 2022-06-26 12:00:16.283060
# Unit test for constructor of class GlideIE
def test_GlideIE():
    
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-26 12:00:23.960709
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()
    assert (glide_i_e_0._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)',
        'Test failed because assert condition was not met')


# Generated at 2022-06-26 12:00:28.170121
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()
    # Test case: constructor
    assert(glide_i_e_0.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='))


# Generated at 2022-06-26 12:00:40.524479
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:00:42.551950
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_1 = GlideIE()


# Generated at 2022-06-26 12:00:49.688980
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    assert glide_i_e.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_i_e._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:00:51.796740
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:57.390912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__doc__ is not None
    assert GlideIE.IE_DESC is not None
    assert GlideIE._VALID_URL is not None
    assert GlideIE._TEST is not None
    assert GlideIE().__doc__ is not None
    assert GlideIE() != None


# Generated at 2022-06-26 12:01:06.453426
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE(url)
    info = ie.extract()
    assert ie._match_id(url) == info['id']

# Generated at 2022-06-26 12:01:14.313332
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("test_GlideIE()")
    obj = GlideIE()
    print("obj.ie_key = %s" % (obj.ie_key))
    print("obj.IE_NAME = %s" % (obj.IE_NAME))
    print("obj.IE_DESC = %s" % (obj.IE_DESC))
    print("obj.IE_VERSION = %s" % (obj.IE_VERSION))
    print("obj.VALID_URL = %s" % (obj.VALID_URL))
    print("obj.TEST = %s" % (obj.TEST))
    print("obj.BROWSER = %s" % (obj.BROWSER))
    print("obj.DOMAIN_ID = %s" % (obj.DOMAIN_ID))

# Generated at 2022-06-26 12:01:20.123830
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This code tests the constructor of GlideIE class.
    """
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    test_ie = GlideIE()
    assert(test_ie.suitable(url))


# Generated at 2022-06-26 12:01:29.795614
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:01:32.791912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:01:41.559609
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from . import GlideIE
    
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    test_result = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'title': "Damon's Glide message",
        'thumbnail': 'http://d2y1cc8a7585jf.cloudfront.net/preview/UZF8zlmuQbe4mr+7dCiQ0w==.mp4.jpg'
    }
    assert GlideIE()._real_extract(url) == test_result

# Generated at 2022-06-26 12:01:48.704645
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    instance = ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    #assert instance
    assert instance['title'] is not None
    assert instance['url'] is not None
    assert instance['thumbnail'] is not None

# Generated at 2022-06-26 12:01:49.400619
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:53.818909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    temp = GlideIE()
    # these are the values expected by the constructor of the class InfoExtractor
    assert isinstance(temp, InfoExtractor)


# Generated at 2022-06-26 12:01:55.617603
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.ie_key() == 'Glide'

# Generated at 2022-06-26 12:02:03.842189
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception as e:
        print(e)
    else:
        print('constructor test passed')


# Generated at 2022-06-26 12:02:09.020646
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for GlideIE class
    """
    # Test __init__ with glide.me URL
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    # Test __init__ with invalid URL
    try:
        GlideIE('http://invalid.url')
    except ValueError:
        pass

# Generated at 2022-06-26 12:02:11.238007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(True)
    assert isinstance(ie, GlideIE)

# Generated at 2022-06-26 12:02:13.922693
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__doc__ is not None



# Generated at 2022-06-26 12:02:20.431716
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).IE_NAME == "Glide"
    assert GlideIE(None).IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE(None)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    extractor = GlideIE(None)._real_extract
    assert extractor is not None

# Generated at 2022-06-26 12:02:26.970325
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:02:28.344659
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-26 12:02:37.901008
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # build an instance of class GlideIE
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # test build
    print('[Testing GlideIE]: Instance created')
    # test compilation
    print('[Testing GlideIE]: Compilation completed')
    # test extraction
    print('[Testing GlideIE]: Extraction completed')

# Generated at 2022-06-26 12:02:39.053203
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create an instance of class
    GlideIE()


# Generated at 2022-06-26 12:02:41.569954
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:02:55.649917
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-26 12:02:58.152648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE();
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:03:00.406368
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("GlideIE", "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    return 0

# Generated at 2022-06-26 12:03:10.295309
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for instantiating a class whose parent is InfoExtractor
    assert issubclass(GlideIE, InfoExtractor)
    assert GlideIE('').IE_NAME == "glide"
    assert GlideIE('').IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE('')._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:03:14.690727
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE().IE_DESC
    instance = GlideIE()
    assert (video is not None), "Get some video"
    assert instance.IE_NAME == 'Glide', "Glide is not Glide"

# Generated at 2022-06-26 12:03:16.034279
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-26 12:03:19.470198
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:25.040767
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:28.706839
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()

    except:
        print("FAIL: Not able to initialize GlideIE")

        return False
    print("Unit Test Passed")

    return True

# Generated at 2022-06-26 12:03:32.561734
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-26 12:04:11.278112
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # In this also we need to pass the url as an argument
    globals()["ie"] = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    globals()["ie"]._downloader.params["forcetitle"] = False
    globals()["ie"]._downloader.params["quiet"] = True
    globals()["ie"]._downloader.params["skip_download"] = True
    globals()["ie"].download("1")

# Generated at 2022-06-26 12:04:13.099986
# Unit test for constructor of class GlideIE
def test_GlideIE():
    s = GlideIE(dict())
    print(s._VALID_URL)

# Generated at 2022-06-26 12:04:25.097235
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from urllib import quote
    from urlparse import urlparse
    global GlideIE
    _VALID_URL = GlideIE._VALID_URL

    # construction
    ie = GlideIE('http://share.glide.me/'+quote("Ram's Glide message",''));
    assert ie.name() == 'Glide', ie.name()
    assert ie.__class__ == GlideIE, ie.__class__
    assert isinstance(ie, InfoExtractor), isinstance(ie, InfoExtractor)

    # sort order
    assert ie.suitable( 'http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D' ) > 100

# Generated at 2022-06-26 12:04:27.850140
# Unit test for constructor of class GlideIE
def test_GlideIE():
    q = GlideIE()
    assert(q.IE_NAME == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-26 12:04:36.028556
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:39.934114
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Simple creation test.
	ie = GlideIE()
	assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:04:48.439192
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:04:50.385618
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE.__name__ == 'Glide'


# Generated at 2022-06-26 12:04:58.879756
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:05:03.147214
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:23.787363
# Unit test for constructor of class GlideIE
def test_GlideIE():
	x = GlideIE()
	assert x.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert x._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert x._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert x._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
	assert x._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:06:33.465133
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Arrange
    import re
    import extractors.glide as glide

    # Act
    glideIE = glide.GlideIE()

    # Assert
    assert glideIE.IE_DESC is not None
    assert re.compile(glide.GlideIE._VALID_URL).match('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') is not None
    assert glideIE._TEST is not None
    assert glideIE._TEST['url'] is not None
    assert glideIE._TEST['md5'] is not None
    assert glideIE._TEST['info_dict'] is not None
    assert glideIE._TEST['info_dict']['id'] is not None

# Generated at 2022-06-26 12:06:35.350031
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:06:42.849410
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None, "UZF8zlmuQbe4mr+7dCiQ0w==");
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:46.020305
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:06:48.643178
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj_GlideIE=GlideIE("test")
    print("test_GlideIE: ", obj_GlideIE)


# Generated at 2022-06-26 12:06:49.761269
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:06:50.583388
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:06:52.545238
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('glide.me')



# Generated at 2022-06-26 12:06:58.559742
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(str(GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')) == 'GlideIE [http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==]')

# Generated at 2022-06-26 12:09:43.525922
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE._downloader).IE_NAME == 'glide'

# Generated at 2022-06-26 12:09:46.419400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:09:47.526181
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:09:59.984883
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # constructor without argument
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.ie_key() == 'Glide'
    # test for non-group items
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.ie_key() == 'Glide'
    # test for ie

# Generated at 2022-06-26 12:10:10.162989
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''Unit test for constructor of class GlideIE'''
    a = GlideIE()
    assert a.IE_NAME == 'glide'
    assert a.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert a._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert a._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert a._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'