

# Generated at 2022-06-26 12:00:10.981780
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return None


# Generated at 2022-06-26 12:00:12.426388
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_object = GlideIE()


# Generated at 2022-06-26 12:00:19.338819
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global glide_i_e_0
    try:
        global glide_i_e_0
        glide_i_e_0
    except NameError:
        test_case_0()
    # assert_equal(glide_i_e_0.IE_DESC, 'Glide mobile video messages (glide.me)')
    assert(glide_i_e_0.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(glide_i_e_0._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    test_GlideIE.glide_i_e_0 = glide_i_e_0


# Generated at 2022-06-26 12:00:20.077814
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert glide_i_e_0


# Generated at 2022-06-26 12:00:20.968771
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()


# Generated at 2022-06-26 12:00:22.490713
# Unit test for constructor of class GlideIE
def test_GlideIE():
  pass


# Generated at 2022-06-26 12:00:25.713980
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Default constructor of class.
    assert GlideIE()



# Generated at 2022-06-26 12:00:27.317002
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(glide_i_e_0, GlideIE)



# Generated at 2022-06-26 12:00:40.423061
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC== "Glide mobile video messages (glide.me)"
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:00:47.077129
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    GlideIE
    """
    glide_i_e_0 = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide_i_e_0.extract(url)


# Generated at 2022-06-26 12:00:58.435430
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")._match_id("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert GlideIE("http://share.glide.me/abcd")._match_id("http://share.glide.me/abcd") == "abcd"


# Generated at 2022-06-26 12:01:11.276755
# Unit test for constructor of class GlideIE
def test_GlideIE():

    #valid url
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    #create a instance of GlideIE
    video_glide = GlideIE(url)
    #unit test for id
    assert video_glide._match_id('https://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D');

    #unit test for webpage

# Generated at 2022-06-26 12:01:16.450238
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #print (GlideIE._TEST)
    #print (GlideIE._TEST['url'])
    glideie = GlideIE()
    print (type(glideie))

# Generated at 2022-06-26 12:01:24.908992
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import json
    import re
    import requests
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    #constructor, extract_id and _real_extract of class InfoExtractor
    #is not tested here.
    glide_video = GlideIE()
    #test with the test case given in the test dict.
    print ("Test case: extract glide video")
    test_dict = glide_video._TEST
    #Input: url of test case.
    glide_video.url_result = url
    glide_video.ie_key = "Glide"
    #test class method _match_id
    id = glide_video._match_id(url)
    if id != test_dict.get("id"):
        raise Assertion

# Generated at 2022-06-26 12:01:35.425219
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    test_glide_ie = GlideIE(url)
    assert test_glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test_glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_glide_ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-26 12:01:36.779889
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-26 12:01:40.484019
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.ie_key() == 'Glide'
    assert ie.video_id() == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:01:42.542573
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #
    # Test GlideIE
    #
    # Access to a web page of GlideIE and extract info
    #
    # @param none
    # @return nothing
    #
    pass

# Generated at 2022-06-26 12:01:45.196776
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # test url can be retrieve by regex

# Generated at 2022-06-26 12:01:54.744236
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'glide'
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:02:02.364764
# Unit test for constructor of class GlideIE
def test_GlideIE():
	o = GlideIE()

# Generated at 2022-06-26 12:02:11.142048
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide.me'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:21.954584
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE(url)
    info = ie._real_extract(url)
    assert 'Damon' in info['title']
    assert 'UZF8zlmuQbe4mr+7dCiQ0w==' == info['id']
    assert 'e=1491517711&amp;s=3c3a4a4a9e9f9daf8c8da29290ef1d2bc1bc94d2cfb5f5b5d2c9d2d2cf8f8f8&amp' in info['url']

# Generated at 2022-06-26 12:02:27.661716
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test GlideIE constructor."""
    # Arrange
    _GlideIE = GlideIE(youtube_ie=None, downloader=None)

    # Assert
    assert _GlideIE.ie_key() == 'Glide'

# Generated at 2022-06-26 12:02:30.029130
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:39.225013
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:02:47.029199
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        print("Unable to create an instance of the class GlideIE")
        assert False


if __name__ == '__main__':
    test = GlideIE()
    test.download("http://share.glide.me/Y/Z2WqaZv/")

# Generated at 2022-06-26 12:02:47.510662
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(0) == GlideIE

# Generated at 2022-06-26 12:02:48.345341
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:02:54.905621
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import get_testdata_file

    expected_GlideIE = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }

    GlideIE_test_file = get_testdata_file('GlideIE.txt')
    glideIE = GlideIE(GlideIE_test_file)
    glideIE_dict = glideIE.test()

    assert glideIE_dict == expected_GlideIE

# Generated at 2022-06-26 12:03:10.368725
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = GlideIE()
    assert isinstance(result, InfoExtractor)
    assert repr(result).startswith("<GlideIE")


# Generated at 2022-06-26 12:03:16.411401
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:18.181885
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 'glide.me' in GlideIE.IE_DESC

# Generated at 2022-06-26 12:03:22.033878
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.url == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-26 12:03:29.407349
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create an instance of GlideIE
    glide_ie = GlideIE()

    # Test the function _match_id from class GlideIE
    assert glide_ie._match_id(GlideIE._TEST['url']) == GlideIE._TEST['info_dict']['id']

# Generated at 2022-06-26 12:03:36.870991
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE.suitable('http://share.glide.me/9N6I4A4AQgy1apZuB7o4xA==')
    assert GlideIE.suitable('http://share.glide.me/CCAeJwPnAi_nF-8E-aPtDQ==')
    assert GlideIE.suitable('http://share.glide.me/YvYJ1lCzTu9pKa-FIo+OEw==')


# Generated at 2022-06-26 12:03:37.989380
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:03:44.708455
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert video['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert video['title'] == "Damon's Glide message"
    assert video['thumbnail'] == 'http://d2snldi1e1jolw.cloudfront.net/i/00/b_ZF8zlmuQbe4mr+7dCiQ0w==.jpg?w=564'

# Generated at 2022-06-26 12:03:45.756365
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()
    assert(True)


# Generated at 2022-06-26 12:03:50.974557
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:04:26.530247
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    e = ie.IE_DESC
    r = ie._VALID_URL
    t = ie._TEST
    assert e == 'Glide mobile video messages (glide.me)'
    assert r == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:33.453352
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # First we create an instance of our CustomTestCase
    test = GlideIE()

    # check valid url
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # check invalid url
    # url = 'http://www.youtube.com/watch?v=BaW_jenozKc'

    if url:
        # we call our function to be tested
        test._real_extract(url)

# Generated at 2022-06-26 12:04:38.663372
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC is not None
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-26 12:04:40.466505
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test = GlideIE(downloader=None)
	assert test._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert test.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:04:48.586723
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:04:56.499031
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.is_ready()
    ie.get_info(GlideIE._TEST['url'])
    assert ie.get_title(GlideIE._TEST['url']) == GlideIE._TEST['info_dict']['title']
    assert ie.get_download_url(GlideIE._TEST['url']) == GlideIE._TEST['info_dict']['url']
    assert ie.get_thumbnail(GlideIE._TEST['url']) == GlideIE._TEST['info_dict']['thumbnail']

# Generated at 2022-06-26 12:05:07.644488
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_dict = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'file': 'UZF8zlmuQbe4mr+7dCiQ0w==.mp4',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        },
        'expected_warnings': [],
    }
    assert_test_dict(GlideIE()._real_extract(test_dict['url']), test_dict)

# Generated at 2022-06-26 12:05:16.365253
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    IE_DESC = 'Glide mobile video messages (glide.me)'
    valid_url = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    ie = GlideIE({})
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc == IE_DESC
    assert ie._VALID_URL == valid_url

# Generated at 2022-06-26 12:05:26.791755
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_cases_IE_DESC = {
        "Glide mobile video messages (glide.me)": True,
        "Glide mobile video messages": True,
        "Glide mobile video": False,
        "Glide messages (glide.me)": False,
        "Glide mobile": False,
    }

    for test_item in test_cases_IE_DESC:
        test_case_IE_DESC = GlideIE(test_item)
        assert (test_case_IE_DESC.IE_DESC == test_item) == test_cases_IE_DESC.get(test_item)

# Generated at 2022-06-26 12:05:36.187316
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Fake video for testing
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    # Checks if the class has been successfully constructed
    ie = GlideIE(test_url)
    assert(ie.suitable(test_url))
    # Checks if the class successfully extracts the ID of the video
    assert(ie._match_id(test_url) == "UZF8zlmuQbe4mr+7dCiQ0w==")



# Generated at 2022-06-26 12:06:50.956649
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    IE_DESC = 'Glide mobile video messages (glide.me)'

    # call constructor of GlideIE
    glide_ie = GlideIE()

    # check that it is instance of InfoExtractor class
    assert isinstance(glide_ie, InfoExtractor)

    # check that it has attribute IE_DESC as description
    assert hasattr(glide_ie, 'IE_DESC')
    assert getattr(glide_ie, 'IE_DESC') == IE_DESC

    # check that it has attribute _VALID_URL to check the URL
    assert hasattr(glide_ie, '_VALID_URL')

    # check that it has attribute _TEST to test the extraction

# Generated at 2022-06-26 12:07:01.617165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==') == True
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr_7dCiQ0w==') == True
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w+') == False

# Generated at 2022-06-26 12:07:10.400091
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    glideIE.IE_DESC
    glideIE._VALID_URL
    # glideIE._TEST
    # glideIE._download_webpage
    # glideIE._proto_relative_url
    # glideIE._og_search_thumbnail
    # glideIE._og_search_video_url
    # glideIE._og_search_title
    # glideIE._html_search_regex
    # glideIE._search_regex
    # glideIE._match_id
    # glideIE._real_extract

# Generated at 2022-06-26 12:07:14.734415
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Check constructor
    glide = GlideIE(None)
    assert glide.params['clip_name_prefix'] == 'Glide_'

# Generated at 2022-06-26 12:07:16.731458
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiate class GlideIE to query video information  
    GlideIE()

# Generated at 2022-06-26 12:07:18.095954
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE.IE_DESC is not None

# Generated at 2022-06-26 12:07:19.097366
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:07:19.864748
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)

# Generated at 2022-06-26 12:07:24.159464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:07:30.194435
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE("id", "url")
    assert i.IE_DESC == "Glide mobile video messages (glide.me)"
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
