

# Generated at 2022-06-26 12:00:11.156027
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:12.461630
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case_0()


# Generated at 2022-06-26 12:00:14.394829
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), GlideIE)


# Generated at 2022-06-26 12:00:16.513645
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()
    assert isinstance(glide_i_e_0, GlideIE)



# Generated at 2022-06-26 12:00:29.145932
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    assert glide_i_e._dbus_init.im_class == GlideIE
    assert glide_i_e._dbus_init.__doc__ is None
    assert glide_i_e._dbus_init.__dict__ == {}
    assert glide_i_e._dbus_init.__module__ == "__main__"
    assert glide_i_e._dbus_init.func_code.co_argcount == 3
    assert glide_i_e._dbus_init.func_code.co_consts == (None,)
    assert glide_i_e._dbus_init.func_code.co_flags == 67
    assert glide_i_e._dbus_init.func_code.co_firstlineno == 5
    assert glide_i_e

# Generated at 2022-06-26 12:00:31.099917
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie_0 = GlideIE()


# Generated at 2022-06-26 12:00:41.710536
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:00:53.818916
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:00:54.340860
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-26 12:01:01.273932
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert test_case_0() == None

if __name__ == '__main__':
    test_GlideIE()
    
    
    
    
    
#     """Find Glide IE."""
#     _VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
#     _TEST = {
#         'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
#         'md5': '4466372687352851af2d131cfaa8a4c7',
#         'info_dict': {
#             'id': 'UZF8zlmuQbe4mr+7dCiQ0w==

# Generated at 2022-06-26 12:01:08.243076
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-26 12:01:12.467589
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert(glideIE._VALID_URL)
    assert(glideIE._TEST)
    assert(glideIE._TEST['url'])


# Generated at 2022-06-26 12:01:17.986018
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:01:20.421542
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Create a GlideIE instance
    instance = GlideIE()

    # Check correct creation of GlideIE instance
    assert isinstance(instance, GlideIE)

# Generated at 2022-06-26 12:01:32.827438
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:01:36.357130
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:01:39.440381
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(object)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:52.052479
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.__name__ == 'GlideIE'
    assert ie.ie_key() == 'Glide'
    assert ie.server_url('www.youtube.com','http://gdata.youtube.com/feeds/api/videos/%s?v=2') == 'http://gdata.youtube.com/feeds/api/videos/www.youtube.com?v=2'

# Generated at 2022-06-26 12:01:53.351142
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print (ie)

# Generated at 2022-06-26 12:02:03.531038
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == "Glide"
    assert obj.IE_DESC == "Glide mobile video messages (glide.me)"
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:14.158669
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE.__new__(GlideIE)
    assert(x.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-26 12:02:19.139077
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit test function: test constructor of class GlideIE

    # ***** Start test *****
    # Try to create class GlideIE instance
    global extractor
    extractor = GlideIE()

    # Some tests...
    assert 'glide' in extractor._WORKING


# Generated at 2022-06-26 12:02:31.100664
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._downloader == None
    assert ie.workingDir == None
    assert ie.params == None
    assert ie._downloader_kwargs == None
    assert ie.urls_location == None
    assert ie._ies_instances == None
    assert ie._ies == None
    assert ie._ies_instances == None
    assert ie._geo_bypass == False
    assert ie._geo_bypass_ip == '173.194.55.83'


# Generated at 2022-06-26 12:02:41.714124
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:43.453782
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:02:49.316340
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test the constructor
    """
    g = GlideIE()
    assert isinstance(g.IE_DESC, str)
    assert isinstance(g._VALID_URL, str)
    assert isinstance(g._TEST, dict)
    assert len(g._TEST) > 0


# Generated at 2022-06-26 12:02:52.721353
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:03:02.649958
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    ie_info_dict = ie._TEST
    ie_id = ie_info_dict['url']
    ie_url = ie_info_dict['url']
    ie_webpage = ie._download_webpage(ie_url, ie_id)
    assert ie_webpage.startswith(b'<!DOCTYPE html>')
    assert ie_webpage.find(b'<title>') >= 0
    assert ie_webpage.find(b'<!--\n') >= 0
    assert ie_webpage.find(b'-->\n') >= 0
    assert ie_webpage.find(b'<div id="video-message-container"') >= 0
    assert ie_

# Generated at 2022-06-26 12:03:13.446850
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:15.398478
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i != None

# Generated at 2022-06-26 12:03:29.293898
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide'


# Generated at 2022-06-26 12:03:41.950066
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
   

# Generated at 2022-06-26 12:03:52.899450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._TEST == {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

# Generated at 2022-06-26 12:04:05.161407
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.__name__ == 'Glide'
    assert ie.__class__.__name__ == 'GlideIE'

# Generated at 2022-06-26 12:04:11.843250
# Unit test for constructor of class GlideIE
def test_GlideIE():
	"""
	Unit test for constructor of class GlideIE
	"""

# Generated at 2022-06-26 12:04:15.976407
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:04:24.651276
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:04:25.718306
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-26 12:04:28.846458
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:04:31.711491
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:05:02.661560
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:05:09.440391
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:05:14.060111
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-26 12:05:20.418283
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:05:21.696673
# Unit test for constructor of class GlideIE
def test_GlideIE():
    lGlideIE = GlideIE()

# Generated at 2022-06-26 12:05:29.798969
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:05:34.412807
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor of class GlideIE should not raise any exception
    obj = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:05:35.505772
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE is not None


# Generated at 2022-06-26 12:05:36.410161
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:05:41.234477
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:06:39.581366
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(None)
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:40.861840
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE() != None)

# Generated at 2022-06-26 12:06:45.297319
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie.IE_DESC == 'Glide mobile video messages (glide.me)', "Test constructor of class GlideIE"


# Generated at 2022-06-26 12:06:50.245496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE(None).IE_NAME == 'glide:glide'
    assert GlideIE(None).IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:06:51.597354
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print (GlideIE)

# Generated at 2022-06-26 12:06:54.779136
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:06:57.859175
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("")
    expected = ["GlideIE"]
    assert ie.extractor._ies == expected

# Generated at 2022-06-26 12:07:03.766088
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:07:13.164808
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ''' 
    Make sure the video url, thumbnail, and video id are fetched for a share.glide.me
    '''
    glide_ie = GlideIE('www', {})
    glide_ie._download_webpage = lambda x, y: '<source src="http://s3.amazon.com/video.mp4"><img id="video-thumbnail" src="http://s3.amazon.com/thumbnail.jpg"/>'

    video = glide_ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert video['url'] == 'http://s3.amazon.com/video.mp4'
    assert video['thumbnail'] == 'http://s3.amazon.com/thumbnail.jpg'
    assert video

# Generated at 2022-06-26 12:07:22.452373
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test example 1
    glide_extractor = GlideIE()
    assert(glide_extractor.IE_NAME == 'Glide')
    assert(glide_extractor.IE_DESC == 'Glide mobile video messages (glide.me)')

    # Test example 2
    glide_extractor = GlideIE()
    glide_extractor._match_id(glide_extractor._VALID_URL)
    assert(glide_extractor._match_id(glide_extractor._VALID_URL) != None)

    #Test example 3
    glide_extractor = GlideIE()
    assert(glide_extractor._real_extract(glide_extractor._TEST))
    print('test_GlideIE() passed!')

# Generated at 2022-06-26 12:09:55.500986
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print(ie)
    
 # Unit test for match_id of class GlideIE

# Generated at 2022-06-26 12:10:01.902871
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:10:05.151166
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:10:11.534448
# Unit test for constructor of class GlideIE
def test_GlideIE():
    expected_results = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        'webpage_url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
    }
    glide_test = GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glide_test == expected_results