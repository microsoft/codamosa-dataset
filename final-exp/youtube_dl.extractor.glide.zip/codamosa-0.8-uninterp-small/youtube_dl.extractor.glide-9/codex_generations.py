

# Generated at 2022-06-26 12:00:11.182517
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()
    assert glide_i_e_0.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:00:19.003400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    assert glide_i_e.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_i_e._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:00:21.956919
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)')



# Generated at 2022-06-26 12:00:25.081282
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()

if __name__ == '__main__':
    # Unit test for constructor of class GlideIE
    test_GlideIE()

# Generated at 2022-06-26 12:00:25.722866
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-26 12:00:27.890066
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    assert glide_i_e.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:00:30.816431
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.IE_DESC == "Glide mobile video messages (glide.me)")


# Generated at 2022-06-26 12:00:32.254103
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case_0()

# Generated at 2022-06-26 12:00:34.492261
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()


# Generated at 2022-06-26 12:00:36.508294
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()



# Generated at 2022-06-26 12:00:42.706746
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test whether an instance of class GlideIE is created"""
    extractor = GlideIE()
    assert(isinstance(extractor, GlideIE))

# Generated at 2022-06-26 12:00:46.052969
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    glide_bool = isinstance(glide, InfoExtractor)
    assert (glide_bool is True)

# Generated at 2022-06-26 12:00:47.111096
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:00:57.594916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:01:02.142921
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_extractor = GlideIE()
    assert (video_extractor.IE_DESC == 'Glide mobile video messages (glide.me)')


# Generated at 2022-06-26 12:01:05.019763
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(str(GlideIE()) == 'Glide mobile video messages (glide.me)')



# Generated at 2022-06-26 12:01:09.014936
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)

    assert ie.IE_NAME == ie.__class__.__name__
    assert ie.IE_DESC == ie.__class__.IE_DESC

# Generated at 2022-06-26 12:01:10.345726
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://www.google.com')

# Generated at 2022-06-26 12:01:15.921055
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-26 12:01:19.678050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(object())._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:35.623670
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE({}, u'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-26 12:01:39.900300
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor with valid url
    GlideIE(url='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Test constructor with invalid url
    GlideIE(url='http://example.com/invalid-url')

# Generated at 2022-06-26 12:01:41.281464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    current_obj = GlideIE()

# Generated at 2022-06-26 12:01:45.494302
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:01:48.661479
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Tests the constructor of class GlideIE."""
    assert GlideIE == type(GlideIE())
    

# Generated at 2022-06-26 12:01:51.957186
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert isinstance (obj, InfoExtractor)


# Generated at 2022-06-26 12:02:03.041544
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for video URL
    video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    # Test for video object
    video = GlideIE().extract(video_url)

# Generated at 2022-06-26 12:02:10.762075
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    assert test_GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test_GlideIE._TEST.get('url') == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert test_GlideIE._TEST.get('md5') == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:02:15.386909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests to see if constructor creates an object of type GlideIE
    glide_ie = GlideIE()
    assert type(glide_ie) == GlideIE


# Generated at 2022-06-26 12:02:18.559618
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    if obj.IE_NAME == 'glide':
        print("success")
    else:
        print("fail")

# Generated at 2022-06-26 12:02:39.083017
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import InfoExtractor
    from .glide import GlideIE
    from .glide import MobileAppIE
    from .theplatform import ThePlatformIE
    from .glide import GlideIE
    from .glide import MobileAppIE
    from .theplatform import ThePlatformIE
    assert issubclass(GlideIE,InfoExtractor)
    assert issubclass(MobileAppIE,InfoExtractor)
    assert issubclass(ThePlatformIE,InfoExtractor)

# Generated at 2022-06-26 12:02:42.730042
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of GlideIE
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-26 12:02:49.274882
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    GlideIE = GlideIE()
    GlideIE._real_extract('http://www.glide.me')
    GlideIE._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:03:01.359039
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-26 12:03:03.335953
# Unit test for constructor of class GlideIE
def test_GlideIE():
	print(GlideIE())

# Generated at 2022-06-26 12:03:13.725454
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    assert IE.IE_NAME == "Glide"
    assert IE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert IE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:17.276515
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:19.288430
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-26 12:03:32.453345
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None, None)
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:03:33.503363
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Simple test to see if the code works
    GlideIE()

# Generated at 2022-06-26 12:04:02.121709
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(ie.extract())

# Generated at 2022-06-26 12:04:08.268099
# Unit test for constructor of class GlideIE
def test_GlideIE():
    expected_email = 'test@test.com'
    expected_pass = '12345'
    glide_ie = GlideIE(expected_email, expected_pass)
    assert glide_ie.email == expected_email
    assert glide_ie.passwd == expected_pass

# Generated at 2022-06-26 12:04:11.603132
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages'
    ie.test_glide()

# Generated at 2022-06-26 12:04:24.433371
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:35.111302
# Unit test for constructor of class GlideIE
def test_GlideIE():
    valid_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    test = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': 're:https?://.*?\.cloudfront\..*\.jpg',
        }
    }

# Generated at 2022-06-26 12:04:38.425592
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    test_obj.suite()

# Generated at 2022-06-26 12:04:40.364165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, type)


# Generated at 2022-06-26 12:04:45.632435
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glide.me/U0FNtqHkxJSx_WhQ_efPuz==')
    ie.extract('http://share.glide.me/XhD5V7o5f5BIuV7iN2eo5w==')

# Generated at 2022-06-26 12:04:47.374108
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:53.589918
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    gie = GlideIE()
    assert (gie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:06:07.775960
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test instantiation of the class
    glide_ie = GlideIE()
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:06:12.858894
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_GlideIE = GlideIE(InfoExtractor)
    assert class_GlideIE is not None # must return something other than None, this is just a placeholder to pass Travis CI
    

# Generated at 2022-06-26 12:06:18.669765
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print('\nRunning unit test')
    ie = GlideIE()
    ie._download('http://www.youtube.com/watch?v=BaW_jenozKc')
    print('\nFinished!')

# Run unit test if run as main
if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-26 12:06:31.185601
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:31.955596
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()

# Generated at 2022-06-26 12:06:32.991765
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie != None


# Generated at 2022-06-26 12:06:37.767708
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE._download_json(
        'http://api.glide.me/api/video/info/UZF8zlmuQbe4mr+7dCiQ0w==/',
        'UZF8zlmuQbe4mr+7dCiQ0w==', 'Downloading video JSON')
    assert video['video_token'] == 'b21a0f709c7e9486dc2c47f1fc32e1cf'

# Generated at 2022-06-26 12:06:38.542381
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test class GlideIE"""
    GlideIE()

# Generated at 2022-06-26 12:06:45.156290
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-26 12:06:48.767596
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._real_extract(url)

# Generated at 2022-06-26 12:09:12.820940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE()
    return a

# Generated at 2022-06-26 12:09:19.910382
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Creating object of class GlideIE
	glideIE_object = GlideIE()
	# Checking if object is of class GlideIE
	if isinstance(glideIE_object, GlideIE):
		print("object glideIE_object is of class GlideIE")
	else:
		print("object glideIE_object is not of class GlideIE")

# test_GlideIE()

# Generated at 2022-06-26 12:09:21.521127
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-26 12:09:32.228869
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from re import match
    ie = GlideIE()
    ie_class = ie.__class__.__name__
    assert ie_class == 'GlideIE', 'ie.__class__.__name__ = ' + ie_class
    assert ie_class == ie.IE_NAME, 'ie.__class__.__name__ != ' + ie.IE_NAME
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert isinstance(ie._VALID_URL, str)
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert match(ie._VALID_URL, test_url), 'ie._VALID_URL != test_url'

# Generated at 2022-06-26 12:09:35.825428
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 12:09:37.720702
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test = GlideIE()

	assert(test._VALID_URL is not None)

# Generated at 2022-06-26 12:09:41.985374
# Unit test for constructor of class GlideIE
def test_GlideIE():
	url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
	assert(GlideIE(url)._VALID_URL == GlideIE._VALID_URL)

# Test methods extract() and _real_extract() of class GlideIE
# Test for _real_extract() is already performed by YoutubeDL test

# Generated at 2022-06-26 12:09:43.886342
# Unit test for constructor of class GlideIE
def test_GlideIE():
    s = GlideIE()
    u = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:09:44.556824
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE._VALID_URL

# Generated at 2022-06-26 12:09:46.479873
# Unit test for constructor of class GlideIE