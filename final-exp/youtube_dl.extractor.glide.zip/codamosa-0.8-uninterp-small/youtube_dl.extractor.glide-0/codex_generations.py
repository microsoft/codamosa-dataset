

# Generated at 2022-06-26 12:00:12.799581
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global glide_i_e_0
    assert (glide_i_e_0.IE_DESC == 'Glide mobile video messages (glide.me)')


# Generated at 2022-06-26 12:00:14.236961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case_0()

# Generated at 2022-06-26 12:00:15.511403
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()


# Generated at 2022-06-26 12:00:16.612175
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()


# Generated at 2022-06-26 12:00:19.329200
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()


# Generated at 2022-06-26 12:00:20.265689
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()


# Generated at 2022-06-26 12:00:22.919243
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(glide_i_e_0, GlideIE) == True


# Generated at 2022-06-26 12:00:30.988720
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)', 'Test 1 for class GlideIE is failed!'
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', 'Test 3 for class GlideIE is failed!'

# Generated at 2022-06-26 12:00:41.662284
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert glide_i_e_0._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_i_e_0._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_i_e_0._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert glide_i_e_0._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_i_e_0._TEST['info_dict']['ext']

# Generated at 2022-06-26 12:00:53.785402
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()
    assert (glide_i_e_0.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert (glide_i_e_0._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:01:01.924636
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:05.313914
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:01:08.465037
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", 'NA')

# Generated at 2022-06-26 12:01:09.831857
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == "Glide"

# Generated at 2022-06-26 12:01:22.580341
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Test constructor
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.SUFFIX == '.glide.me'

# Generated at 2022-06-26 12:01:27.018887
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE.IE_DESC)

    assert(ie.IE_DESC is GlideIE.IE_DESC)


# Generated at 2022-06-26 12:01:36.152892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("Testing Constructor for class GlideIE")
    ie = GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST.get("url") == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST.get("md5") == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-26 12:01:36.991119
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-26 12:01:43.501770
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Given I have a Glide video URL
    glideUrl = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    # And the GlideIE
    glideIE = GlideIE()
    # I expect the GlideIE to parse and extract the right video information
    result = glideIE.extract(glideUrl)
    assert result['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert result['url'].startswith("//")
    assert result['thumbnail'].startswith("//")
    assert result['title'] == "Damon's Glide message"

# Generated at 2022-06-26 12:01:44.326933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:53.799444
# Unit test for constructor of class GlideIE
def test_GlideIE():
    newGlideIE = GlideIE()
    assert newGlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert newGlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:02:00.484339
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# test for extracting glide
	url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	extractor = GlideIE()
	info = extractor.extract(url)

# Generated at 2022-06-26 12:02:08.245890
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.name == 'Glide'
    assert ie.ie_key() == 'Glide'
    assert ie.ie_key() == 'Glide'
    assert ie.valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not ie.valid_url('http://www.youtube.com/watch?v=BaW_jenozKc')


# Generated at 2022-06-26 12:02:11.586862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:16.035364
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #  Make sure nothing wrong happens if the get_info function is called
    GlideIE().get_info(['http://share.glide.me/'])



# Generated at 2022-06-26 12:02:16.575859
# Unit test for constructor of class GlideIE
def test_GlideIE():
    globals()['GlideIE']()

# Generated at 2022-06-26 12:02:17.336961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj is not None

# Generated at 2022-06-26 12:02:22.121261
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/1')
    ie.extract('https://share.glide.me/1')
    ie.IE_DESC
    ie._VALID_URL

test_GlideIE()

# Generated at 2022-06-26 12:02:26.358562
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", {}, {}, {})

# Generated at 2022-06-26 12:02:28.907830
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert TestGlideIE._TEST['url'] == ie._VALID_URL



# Generated at 2022-06-26 12:02:43.525942
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:02:46.158021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:02:49.515700
# Unit test for constructor of class GlideIE
def test_GlideIE():
    globals()['GlideIE'] = type('GlideIE',
                               (type(globals()['GlideIE']), object),
                               {})

# Generated at 2022-06-26 12:03:00.718352
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__name__ == "GlideIE"
    assert GlideIE.__doc__ == "Glide mobile video messages (glide.me)"
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] ==  'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:03:03.692023
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # TEST CASE - GlideIE.__init__.
    GlideIE()

# Generated at 2022-06-26 12:03:09.693753
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)

    assert "Glide mobile video messages (glide.me)" == ie.IE_DESC
    assert "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)" == ie._VALID_URL

# Generated at 2022-06-26 12:03:21.552821
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()

    assert IE.IE_NAME == 'Glide'
    assert IE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert IE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:33.632505
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()._extract_info("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert info.get('id', -1) == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert info.get('title', -1) == "Damon's Glide message"
    assert (info.get('thumbnail', -1) ==
            "https://d2mkgmv7d8m1e3.cloudfront.net/image/UZF8zlmuQbe4mr+7dCiQ0w%3D%3D/thumb?height=300&width=300")

# Generated at 2022-06-26 12:03:36.670265
# Unit test for constructor of class GlideIE
def test_GlideIE():
    Class = GlideIE
    Instance = GlideIE()

    assert Class.ie_key() == 'Glide'
    assert Class.ie_slug() == 'glide'
    assert Class.domain() == 'share.glide.me'

    assert repr(Instance) == 'GlideIE()'

# Generated at 2022-06-26 12:03:38.330707
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie)

# Generated at 2022-06-26 12:04:07.055759
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit tests for constructor of class GlideIE"""
    # object of GlideIE
    inst = GlideIE()
    inst._real_extract(['url'])

# Generated at 2022-06-26 12:04:08.124440
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(
        GlideIE(InfoExtractor()),
        InfoExtractor
    )

# Generated at 2022-06-26 12:04:11.146969
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE("Test")
    except ImportError:
        return True
    return False

# Generated at 2022-06-26 12:04:17.878649
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = GlideIE._TEST.get('url')
    ie_obj = GlideIE(test_url)
    assert ie_obj.ie_key() == 'Glide'
    assert ie_obj.ie_url() == test_url
# test for method _real_extract of class GlideIE

# Generated at 2022-06-26 12:04:22.487123
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        InfoExtractor
    except NameError:
        raise Exception("InfoExtractor class not found")
    try:
        GlideIE
    except NameError:
        raise Exception("GlideIE class not found")

test_GlideIE()


# Generated at 2022-06-26 12:04:34.621423
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:36.014502
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE("glide")

# Generated at 2022-06-26 12:04:40.498321
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_instance = GlideIE()
    assert test_instance.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:04:48.604504
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:58.345455
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()

    url1 = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    result1 = glide._real_extract(url1)
    assert result1['id'] == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert result1['title'] == "Damon's Glide message"
    assert result1['url'] == "https://s3-eu-west-1.amazonaws.com/s3.glideo.com/UZF8zlmuQbe4mr+7dCiQ0w==.mp4"

# Generated at 2022-06-26 12:06:20.852625
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_test_case = (ie, GlideIE._TEST)
    assert(ie_test_case[0].IE_DESC == GlideIE.IE_DESC)
    video_url = ie_test_case[1]['url']
    info = ie_test_case[0]._real_extract(video_url)

# Generated at 2022-06-26 12:06:23.393090
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie == GlideIE()

# Generated at 2022-06-26 12:06:24.873323
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-26 12:06:34.093155
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for constructor of class GlideIE
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:45.229250
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Object GlideIE
    glideIE = GlideIE()
    # Url of current test
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    # Get the video result
    video_result = glideIE.extract(test_url)

    # Testing class attibutes
    assert (glideIE.IE_DESC == "Glide mobile video messages (glide.me)")
    assert (glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:06:49.146066
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        from pytube import YouTube
        YouTube('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    except:
        print("No video found")
        pass

# Generated at 2022-06-26 12:06:55.946566
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.getURL() == 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='




# Generated at 2022-06-26 12:06:58.103979
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE().IE_NAME == 'glide')


# Generated at 2022-06-26 12:06:59.488266
# Unit test for constructor of class GlideIE
def test_GlideIE():
    p = GlideIE()

# Generated at 2022-06-26 12:07:11.626354
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for GlideIE"""
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:09:54.886956
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:09:57.949428
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:10:06.495940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_ = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    info_dict = ie_.extract()
    assert info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info_dict['title'] == "Damon's Glide message"