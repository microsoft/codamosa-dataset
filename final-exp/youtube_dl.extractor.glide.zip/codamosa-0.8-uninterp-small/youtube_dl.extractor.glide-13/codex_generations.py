

# Generated at 2022-06-26 12:00:12.465076
# Unit test for constructor of class GlideIE
def test_GlideIE():
    with pytest.raises(RegexNotFoundError):
        glide_i_e = GlideIE(GlideIE._VALID_URL)



# Generated at 2022-06-26 12:00:14.399091
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE() != None)


# Generated at 2022-06-26 12:00:16.043435
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:23.729752
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()
    # assert_raises
    # ~~~~~~~~~~~~

    # assert_raises(Exception, glide_i_e_0._real_extract, [])
    # assert_raises(Exception, glide_i_e_0._real_extract, [])



# Generated at 2022-06-26 12:00:25.216727
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case_0()

# Generated at 2022-06-26 12:00:26.284193
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # TODO: implement this.
    assert True

# Generated at 2022-06-26 12:00:34.464573
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj_GlideIE = GlideIE()

    assert_equal(obj_GlideIE._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-26 12:00:43.337406
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()
    assert isinstance(glide_i_e_0, InfoExtractor)
    assert isinstance(glide_i_e_0._VALID_URL, unicode)
    assert isinstance(glide_i_e_0._downloader, youtube_dl.YoutubeDL)
    assert isinstance(glide_i_e_0._match_id, functools.partial)
    assert isinstance(glide_i_e_0._WORKING, bool)
    assert isinstance(glide_i_e_0._TEST, dict)
    assert isinstance(glide_i_e_0.IE_NAME, unicode)
    assert isinstance(glide_i_e_0.IE_DESC, unicode)

# Generated at 2022-06-26 12:00:46.053554
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case_0()


if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-26 12:00:57.421818
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    assert glide_i_e.ie_key() == 'Glide'
    assert glide_i_e.ie_desc == 'Glide mobile video messages (glide.me)'
    assert glide_i_e.severity == 2
    assert glide_i_e.webpage_url_re == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_i_e.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_i_e._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:01:07.442306
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test if the constructor of class GlideIE works correctly.
    """
    glide_inst = GlideIE()
    assert glide_inst.IE_NAME == 'glide'
    assert glide_inst.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:01:08.592439
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(GlideIE.ie_key())

# Generated at 2022-06-26 12:01:10.476858
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.ie_key() == 'glide'


# Generated at 2022-06-26 12:01:11.824689
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()



# Generated at 2022-06-26 12:01:19.429022
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Unit tests for class GlideIE

# Generated at 2022-06-26 12:01:20.191193
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:32.677449
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test to check if it works with valid URL
    x = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert x

    # Test to check if it is returning correct URL
    y = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert y.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")['url'] == 'https://s3.amazonaws.com/glide-users/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D/1516949434.mp4'

    # Test to check

# Generated at 2022-06-26 12:01:34.028308
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert not GlideIE._TEST['url'] is None

# Generated at 2022-06-26 12:01:35.332533
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()

# Generated at 2022-06-26 12:01:43.502573
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert info_extractor._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info_extractor._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert info_extractor._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:01:51.729892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    usa = GlideIE()
    assert usa is not None


# Generated at 2022-06-26 12:01:54.618270
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()._real_extract(GlideIE._TEST['url'])
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['title'] == "Damon's Glide message"

# Generated at 2022-06-26 12:01:56.659162
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME == 'Glide'

# Generated at 2022-06-26 12:02:00.438948
# Unit test for constructor of class GlideIE
def test_GlideIE():
    tester = GlideIE()
    assert tester._VALID_URL == GlideIE._VALID_URL
    assert tester.IE_DESC == GlideIE.IE_DESC
    assert tester._TEST == GlideIE._TEST
    assert tester._real_extract(GlideIE._TEST['url']) == GlideIE._TEST

# Generated at 2022-06-26 12:02:04.165060
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("")
    assert(ie.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:02:06.273262
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    try:
        ie.IE_DESC
        ie._VALID_URL
        ie._TEST
        ie._real_extract
    except:
        assert False, 'Failed to initialize DotsubIE'
    assert True

# Generated at 2022-06-26 12:02:07.447366
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:08.778544
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert glideIE

# Generated at 2022-06-26 12:02:21.132599
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:02:25.267954
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import re
    assert re.match(r'https?://.*?\.cloudfront\.net/.*\.jpg$', GlideIE._TEST['info_dict']['thumbnail'])

# Generated at 2022-06-26 12:02:52.106033
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This is the constructor for the class
    glide_ie = GlideIE()
    # These are the variables that we want to test:
    # _VALID_URL
    # _TEST
    # IE_DESC

    # First we will test the _VALID_URL variable
    valid_url_pattern = glide_ie._VALID_URL
    # Now we will see if the _VALID_URL variable is a string
    assert(type(valid_url_pattern) == str)

    # Now we will test the _TEST variable
    test_dict = glide_ie._TEST
    assert(type(test_dict) == dict)
    # Now we will test if each element of the dictionary is the right type

# Generated at 2022-06-26 12:02:55.780382
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # TODO: make a unittest.TestCase for GlideIE
    ie = GlideIE()
    ie.extract(ie._TEST['url'])

# Generated at 2022-06-26 12:03:00.718289
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:03:13.018859
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:03:17.145664
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide.main()
    assert glide.GlideIE is not None
    assert glide.GlideIE.IE_DESC is not None
    assert glide.GlideIE.__doc__ is not None

# Generated at 2022-06-26 12:03:24.063396
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:03:32.414780
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	assert obj._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
	assert obj._TEST.get('url') == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
	assert obj._TEST.get('md5') == "4466372687352851af2d131cfaa8a4c7"
# End of unit test


# Generated at 2022-06-26 12:03:34.179150
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for constructor with no params
    GlideIE.__init__()

# Generated at 2022-06-26 12:03:36.445753
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie is not None


# Generated at 2022-06-26 12:03:38.853666
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-26 12:04:11.602837
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:14.070702
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = ie._VALID_URL
    ie._match_id(url)

# Generated at 2022-06-26 12:04:16.995580
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 1 == GlideIE().IE_NAME == 'glide.me'

# Generated at 2022-06-26 12:04:26.178402
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:04:26.993731
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:29.564724
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    assert test_GlideIE == GlideIE()


# Generated at 2022-06-26 12:04:34.729126
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:40.840375
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.IE_NAME == 'glide:glide')
    assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')

# Unit tests for methods of class GlideIE

# Generated at 2022-06-26 12:04:45.124659
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:04:57.125801
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testargs = {'id': 'UZF8zlmuQbe4mr+7dCiQ0w=='}
    testargs.update(GlideIE._TEST)
    assert GlideIE._match_id(GlideIE, testargs['url']), "Test to match an id from a glide url"
    try:
        assert GlideIE._match_id(GlideIE, "http://url.not.glide/UZF8zlmuQbe4mr+7dCiQ0w==")
    except:
        print("Test to match an id from a non-glide url: PASS")
    GlideIE._search_regex(testargs['webpage'], r'<title>(.+?)</title>', None, None, None)

# Generated at 2022-06-26 12:06:19.462327
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-26 12:06:22.937912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    # Test without video URL
    GlideIE(None)

# Generated at 2022-06-26 12:06:29.033714
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for GlideIE to test the constructor of class GlideIE
    glide_instance = GlideIE()
    assert glide_instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:06:39.713195
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("")
    print(ie.IE_DESC)
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    id = ie._match_id(url)
    assert(id == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie._VALID_URL == 'http://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-26 12:06:50.349304
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Testing extraction from URL
    # http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==
    url1 = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    info1 = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }

    yield extractor_test(GlideIE, url1, info1)

# Generated at 2022-06-26 12:06:58.561486
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Testcase for constructor of class GlideIE
    """
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url, video_id)
    print("Unit test for class GlideIE passed successfully")


# Generated at 2022-06-26 12:07:11.178636
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:07:16.800938
# Unit test for constructor of class GlideIE
def test_GlideIE(): 
    """
    This tests the GlideIE class.
    """

    glide_test = GlideIE()
    assert glide_test.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:07:19.389642
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST['url'] == GlideIE._VALID_URL


# Generated at 2022-06-26 12:07:22.107274
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
