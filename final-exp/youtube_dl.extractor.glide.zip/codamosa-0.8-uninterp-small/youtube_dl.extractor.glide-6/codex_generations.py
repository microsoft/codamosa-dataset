

# Generated at 2022-06-26 12:00:11.320308
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()

# Generated at 2022-06-26 12:00:12.124537
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-26 12:00:13.420673
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()


# Generated at 2022-06-26 12:00:15.051992
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        glide_i_e_1 = GlideIE()
    except Exception:
        assert False

# Generated at 2022-06-26 12:00:16.168402
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()



# Generated at 2022-06-26 12:00:17.551880
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-26 12:00:29.594387
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    assert GlideIE().IE_DESC == GlideIE._TEST['url']
    assert GlideIE().IE_DESC == GlideIE._TEST['md5']
    assert GlideIE().IE_DESC == GlideIE._TEST['info_dict']
    assert GlideIE().IE_DESC == GlideIE._TEST['info_dict']['id']
    assert GlideIE().IE_DESC == GlideIE._TEST['info_dict']['ext']
    assert GlideIE().IE_DESC == GlideIE._TEST['info_dict']['title']
    assert GlideIE().IE_DESC == GlideIE._TEST['info_dict']['thumbnail']

# Unit

# Generated at 2022-06-26 12:00:30.949177
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case_0()

# Generated at 2022-06-26 12:00:32.323598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()

# Generated at 2022-06-26 12:00:33.914936
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()

# Generated at 2022-06-26 12:00:39.276321
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """  Unit test for constructor of class GlideIE """
    GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:00:41.404805
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(dict())
    GlideIE.suite()

# Generated at 2022-06-26 12:00:44.142942
# Unit test for constructor of class GlideIE
def test_GlideIE():
  instance = GlideIE()

# unit test for '_real_extract' of class GlideIE

# Generated at 2022-06-26 12:00:44.976598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("")

# Generated at 2022-06-26 12:00:47.296143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE() # should not raise exception, InfoExtractor type

# Generated at 2022-06-26 12:00:57.664781
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert not hasattr(GlideIE, '_download_json')
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:00:59.915313
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from . import comment
    GlideIE(comment)

# Generated at 2022-06-26 12:01:00.832545
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:07.211628
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:01:14.362427
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    glide = GlideIE()
    assert glide._TEST == test

# Test for constructor of class GlideIE

# Generated at 2022-06-26 12:01:25.696320
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:26.284367
# Unit test for constructor of class GlideIE
def test_GlideIE():
    object = GlideIE()
    object.suite()

# Generated at 2022-06-26 12:01:35.926707
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test case for constructor of GlideIE class
    tester = GlideIE("url", "title")
    assert tester.url == "url"
    assert tester.title == "title"
    assert tester.ie_key == "Glide"

    # test case for constructor with _VALID_URL set to http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==
    tester = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", "")
    assert tester._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:39.964077
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glideIE = GlideIE(url)
    assert glideIE.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glideIE.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # Test if the execute_function does work
    webpage = glideIE._download_webpage(url, glideIE.video_id)
    assert webpage != ""
    # Test if _real_extract does work
    vidInfo = glideIE._real_extract(url)
    assert vidInfo != None

# Generated at 2022-06-26 12:01:41.047265
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = GlideIE()
    assert infoExtractor


# Generated at 2022-06-26 12:01:44.540649
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-26 12:01:44.901874
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:48.283522
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:01:57.428647
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE(InfoExtractor())
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:02.261643
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Instatiate test object
	GlideIE_obj = GlideIE()
	
	# Test for the extraction of the video name
	assert GlideIE_obj._real_extract(GlideIE_obj._TEST[u'url'])[u'title'] == GlideIE_obj._TEST[u'info_dict'][u'title']


# Generated at 2022-06-26 12:02:22.833661
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Class GlideIE's constructor test.
    """
    # Create a GlideIE instance to test
    glide_ie = GlideIE()

    # Check instance attributes
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    #assert glide_ie._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe

# Generated at 2022-06-26 12:02:33.083670
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    video_title = "Damon's Glide message"
    video_thumbnail = ('http://d6h4tc4ogq3n0.cloudfront.net/'
                       '2015/07/01/99/99/528dc6c12898b0d85e5d0e9e_1435755079.jpg')

    ie = GlideIE(False)
    info_dict = ie._real_extract(video_url)

    assert info_dict['id'] == video_id
    assert info_dict['title'] == video_title

# Generated at 2022-06-26 12:02:35.531984
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert(glide.IE_NAME == 'glide')

# Generated at 2022-06-26 12:02:38.828051
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    ie = GlideIE()
    ie.extract(GlideIE._TEST['url'])
    return True

# Generated at 2022-06-26 12:02:48.929340
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert isinstance(info_extractor, InfoExtractor), "info_extractor variable must be an instance of InfoExtractor class"
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:02:55.831353
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # These tests only check if the constructor can handle its input
    assert GlideIE('test:test:test:test:test')
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE('http://share.glide.me/4mo4ytuw4IeV7bQBLCeM9A==')
    assert GlideIE('https://share.glide.me/4mo4ytuw4IeV7bQBLCeM9A==')

# Generated at 2022-06-26 12:02:56.589333
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-26 12:02:59.272717
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    print(glideIE)

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-26 12:03:12.232696
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:22.283225
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ''' Create the basic GlideIE class
    '''
    glide_ie = GlideIE()
    assert glide_ie
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:53.244453
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE(GlideIE.IE_NAME)
    assert e.IE_NAME == GlideIE.IE_NAME
    assert e.cookiejar is None
    assert e.url_result is None
    assert e.success is None
    assert e.countries == []
    assert e.age_limit == 0
    assert e.params == {}
    assert e._downloader is None
    assert e._match_id == GlideIE._match_id

# Generated at 2022-06-26 12:04:02.841805
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_instance = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    data = ie_instance._real_extract(url)
    assert data['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert 'http://' in data['url']
    assert 'http://' in data['thumbnail']
    assert data['title'] == "Damon's Glide message"

# Generated at 2022-06-26 12:04:06.818992
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert 'GlideIE' == ie.__class__.__name__
	

# Generated at 2022-06-26 12:04:14.486086
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()

    assert info_extractor._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-26 12:04:23.072806
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Construct the class
    glide_ie = GlideIE()
    # Check that the class is constructed correctly
    assert(glide_ie.name == 'glide')  # name of class
    assert(glide_ie.ie_key() == 'glide')  # key of class
    assert(glide_ie.ie_desc() == 'Glide mobile video messages (glide.me)')  # description of class

# Unit tests for extraction of video information

# Generated at 2022-06-26 12:04:24.123431
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:27.144385
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Class constructor should take two arguments
    assert GlideIE.__init__.__code__.co_argcount == 2

# Generated at 2022-06-26 12:04:30.375259
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:04:31.547869
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(str(GlideIE) != "")

# Generated at 2022-06-26 12:04:33.241400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC
    assert ie.IE_NAME
    assert ie.WORKING

# Generated at 2022-06-26 12:05:47.832285
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj.extractor_key == 'glide'
    assert test_obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_obj.IE_NAME == 'Glide'
    assert test_obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:05:59.415170
# Unit test for constructor of class GlideIE
def test_GlideIE():

    obj = GlideIE()


# Generated at 2022-06-26 12:06:02.575097
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of class GlideIE
    # Note: this is a dummy test.
    assert True == True

# Generated at 2022-06-26 12:06:11.917419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:06:21.328040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.name == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.url == 'http://share.glide.me/UZF8zlmuQb'
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-26 12:06:32.507017
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert(instance.IE_NAME == 'glide')
    assert(instance.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:06:42.246741
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test correct constructor
    # Case 1
    # Test with correct URL
    # Test that the created object is of type class GlideIE
    glide_ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert type(glide_ie) == GlideIE

    # Case 2
    # Test with correct URL
    # Test that the created object is of type class GlideIE
    glide_ie = GlideIE(
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==?param=value')
    assert type(glide_ie) == GlideIE

    # Case 3
    # Test with correct URL
    # Test that the created object is of type class GlideIE

# Generated at 2022-06-26 12:06:45.442174
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:06:47.902123
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:07:00.450118
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Constructor with url
	try:
		GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	except ValueError as e:
		assert (e.message == 'Invalid GlideIE url: ' + 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	else:
		raise ValueError('Constructor should fail with ' + 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

	# The full url of the video message
	url_full = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

	#

# Generated at 2022-06-26 12:09:44.343157
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Fake function to create GlideIE object
    def Constructor(test):
        pass

    #Constructor of GlideIE class
    GlideIE_constructor = GlideIE.__init__.__func__
    #Create object
    GlideIE_object = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    Constructor(GlideIE_constructor)
    # Assert function return None
    assert GlideIE_constructor(GlideIE_object, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') is None

# Generated at 2022-06-26 12:09:47.968544
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie.IE_NAME == GlideIE.IE_NAME
    assert ie.IE_DESC == GlideIE.IE_DESC
    assert ie._TEST == GlideIE._TEST


# Generated at 2022-06-26 12:09:56.656851
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #GlideIE is a subclass of InfoExtractor, it is a abstract class that can not be instantiated
    try :
        GlideIE(r'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
        assert True
    except TypeError :
        assert False
    except AssertionError :
        assert False
    except :
        assert False

# Generated at 2022-06-26 12:09:59.175159
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Unit test to check if content is downloaded

# Generated at 2022-06-26 12:10:00.752925
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from . import GlideIE
    GlideIE()

# Generated at 2022-06-26 12:10:10.485287
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE(InfoExtractor)
    test_GlideIE._downloader
    test_GlideIE._download_webpage
    test_GlideIE._html_search_regex
    test_GlideIE._og_search_title
    test_GlideIE._proto_relative_url
    test_GlideIE._search_regex
    test_GlideIE._og_search_video_url
    test_GlideIE._og_search_thumbnail

    test_GlideIE.test_GlideIE
    test_GlideIE.test_url
    test_GlideIE.test_returns_sizes
    test_GlideIE.test_subtitles
    test_GlideIE.test_nosubtitles
    test_GlideIE.test_live
    test