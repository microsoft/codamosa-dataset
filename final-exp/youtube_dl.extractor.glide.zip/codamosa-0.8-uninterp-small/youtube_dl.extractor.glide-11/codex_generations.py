

# Generated at 2022-06-26 12:00:09.245334
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'thumbnail': 're:^https?://.*?\\.cloudfront\\.net/.*\\.jpg$', 'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message"}}


# Generated at 2022-06-26 12:00:17.326542
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test function GlideIE.suitable
    assert GlideIE.suitable(GlideIE._TEST['url']) is True
    assert GlideIE.suitable('https://www.youtube.com') is False
    # Test function GlideIE._real_extract
    assert GlideIE._real_extract(GlideIE, GlideIE._TEST['url']) == GlideIE._TEST['info_dict']
    assert GlideIE._real_extract(GlideIE, 'https://www.youtube.com') is None


# Generated at 2022-06-26 12:00:29.490909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    assert(glide_i_e.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(glide_i_e._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(glide_i_e._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(glide_i_e._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')

# Generated at 2022-06-26 12:00:32.053216
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-26 12:00:39.833334
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide_i_e_1 = GlideIE()
    glide_i_e_1.suitable(url)
    glide_i_e_1.extract(url)
    glide_i_e_1.suitable(video_id)

# Generated at 2022-06-26 12:00:52.868855
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Asserts that GlideIE constructor sets IE_DESC
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    # Asserts that GlideIE constructor sets _VALID_URL
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Asserts that GlideIE constructor sets _TEST

# Generated at 2022-06-26 12:00:54.592684
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_1 = GlideIE()


# Generated at 2022-06-26 12:00:55.487355
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()

# Generated at 2022-06-26 12:00:58.186078
# Unit test for constructor of class GlideIE
def test_GlideIE():

    assert(glide_i_e_0.test())
################################################################################
# End of testing class GlideIE
################################################################################

# Generated at 2022-06-26 12:01:09.527909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url0 = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide_i_e_0 = GlideIE(url0, {'fatal': True}, None, None, None)

    url1 = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:01:14.645522
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-26 12:01:15.558103
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:23.650676
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Constructor test for class GlideIE
    """
    # Valid Glide URL with actual video
    assert GlideIE.suitable("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

    # Valid Glide URL with video, but receiving 404
    assert GlideIE.suitable("http://share.glide.me/xDsBQwgBd6y87fOA67qsXA==")

    # URL of invalid video on glide
    assert not GlideIE.suitable("http://share.glide.me/video/UZF8zlmuQbe4mr7dCiQ0w==")

# Generated at 2022-06-26 12:01:30.264327
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # check that nothing is returned for an invalid url
    url1 = "http://example.com/nothing"
    ie = GlideIE(url1)
    assert ie is None, "Invalid url should return None"
    # check that info is returned for a valid url
    url2 = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    ie = GlideIE(url2)
    info = ie._real_extract(url2)
    assert info['url'] == "//content.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==.mp4"

# Generated at 2022-06-26 12:01:36.024364
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # TODO: find a good way to unit test extractors in general.
    # This is not what we want.
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:37.940671
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert type(ie) == GlideIE

# Generated at 2022-06-26 12:01:51.189440
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:51.988317
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download()

# Generated at 2022-06-26 12:01:53.563933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-26 12:01:54.560774
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()

# Generated at 2022-06-26 12:02:04.318661
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Test that constructor creates object correctly """
    ie = GlideIE()
    ie._downloader.cache.remove()


# Unit test to check video extraction

# Generated at 2022-06-26 12:02:11.864531
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == "GlideIE"
    assert instance.IE_DESC == "Glide mobile video messages (glide.me)"
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:14.938884
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ge = GlideIE()
    assert ge.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:02:17.586938
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert isinstance(instance, GlideIE)


# Generated at 2022-06-26 12:02:24.342914
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:02:30.757186
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_object = ie._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    print("id  = " + ie_object['id'])
    print("title = " + ie_object['title'])
    print("url = " + ie_object['url'])
    print("thumbnail = " + ie_object['thumbnail'])

# Generated at 2022-06-26 12:02:36.214434
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiation of class GlideIE (using the constructor of the info extractor class)
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:41.724207
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE('http://glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(glide_ie.IE_NAME == 'glide')
    assert(glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:02:43.162379
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-26 12:02:45.216911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._real_extract(dummy_url)

# Generated at 2022-06-26 12:02:58.815788
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    GlideIE()

# Generated at 2022-06-26 12:03:00.067350
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE()

# Generated at 2022-06-26 12:03:08.017664
# Unit test for constructor of class GlideIE
def test_GlideIE():
    newGlideIE = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert newGlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:09.969106
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:03:11.323969
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-26 12:03:14.899183
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:03:15.613898
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)
    assert GlideIE == GlideIE

# Generated at 2022-06-26 12:03:16.433966
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:03:18.366419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:24.324521
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:03:55.585297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:04:05.996534
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:08.934828
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test1 = GlideIE()
    print(test1._VALID_URL)
    result = test1._VALID_URL
    assert result == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', 'Test failed'
    print('Test passed!')


# Generated at 2022-06-26 12:04:11.865407
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w')

# Generated at 2022-06-26 12:04:12.773506
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:24.953787
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie=GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:04:35.235106
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_name = GlideIE.__name__
    # Check if all class attributes exists
    assert hasattr(GlideIE, '_VALID_URL')
    assert hasattr(GlideIE, 'IE_NAME')
    assert hasattr(GlideIE, 'IE_DESC')
    assert hasattr(GlideIE, '_TESTS')
    assert hasattr(GlideIE, '_download_webpage_handle')
    assert hasattr(GlideIE, '_html_search_meta')
    assert hasattr(GlideIE, '_html_search_regex')
    assert hasattr(GlideIE, '_html_search_regex')
    assert hasattr(GlideIE, '_match_id')
    assert hasattr(GlideIE, '_og_search_title')
    assert hasattr

# Generated at 2022-06-26 12:04:40.839112
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._PARAMS_RE == r'(?:&|&amp;)?(?:(?!amp;)(\w+)=)?(?:(?!amp;)(\w+))'

# Generated at 2022-06-26 12:04:47.501052
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'http://www.youtube.com/watch?v=x_bBFhW8XNU')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.title == "Damon's Glide message"

# Generated at 2022-06-26 12:04:49.335819
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor test when we have an empty argument
    assert GlideIE({}) is not None

# Generated at 2022-06-26 12:06:02.150966
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:06:05.494374
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:06:08.562637
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Testing for valid input
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-26 12:06:11.722661
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==') != None

# Generated at 2022-06-26 12:06:19.610162
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.__name__ == 'GlideIE'
    assert ie.extractor_key() == 'Glide'



# Generated at 2022-06-26 12:06:20.318491
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:06:32.100460
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests if inputs are correct type
    try:
        # Testing with a Glide url
        GlideIE.suitable("https://share.glide.me/uZF8zLmuqbe4mr+7dCiQ0w==")
        GlideIE.suitable("http://share.glide.me/uZF8zLmuqbe4mr+7dCiQ0w==")
    except:
        assert False
    else:
        assert True
    try:
        # Testing with a Glide url
        GlideIE.suitable("https://share.glide.me/")
        GlideIE.suitable("http://share.glide.me/")
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-26 12:06:33.172982
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Calling constructor of class without arguments (url).
    assert GlideIE()

# Generated at 2022-06-26 12:06:37.431924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert_equal(ie.IE_NAME, 'glide')
    assert_equal(ie.IE_DESC, 'Glide mobile video messages (glide.me)')
    assert_equal(ie._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:06:38.084323
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:09:01.164471
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:09:02.899874
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-26 12:09:11.288733
# Unit test for constructor of class GlideIE
def test_GlideIE():
    sut = GlideIE()
    assert_equal(sut._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert_equal(sut.IE_DESC, 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-26 12:09:15.440762
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")



# Generated at 2022-06-26 12:09:17.210812
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-26 12:09:19.055682
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)._real_extract(None)

# Generated at 2022-06-26 12:09:21.215776
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(_DummyProvider())
    assert ie



# Generated at 2022-06-26 12:09:25.552554
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(None)
    assert obj._VALID_URL == GlideIE._VALID_URL
    assert obj._TEST == GlideIE._TEST

# Generated at 2022-06-26 12:09:28.281882
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())._real_extract(test_GlideIE.TEST)

# Generated at 2022-06-26 12:09:30.320244
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST['md5'] == GlideIE(None)._real_extract(GlideIE._TEST['url'])['id']