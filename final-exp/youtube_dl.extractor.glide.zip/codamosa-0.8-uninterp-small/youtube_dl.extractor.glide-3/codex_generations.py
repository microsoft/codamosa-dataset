

# Generated at 2022-06-26 12:00:11.036538
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if __name__=='__main__':
        test_case_0()

# Generated at 2022-06-26 12:00:11.493572
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-26 12:00:13.300571
# Unit test for constructor of class GlideIE
def test_GlideIE():

    glide_i_e_1 = GlideIE()


# Generated at 2022-06-26 12:00:15.250976
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:18.408468
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == 'glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj.can_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")


# Generated at 2022-06-26 12:00:23.506681
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()
    pass

if __name__ == "__main__":
    # Unit test for constructor of class GlideIE
    test_GlideIE()
    pass

# Generated at 2022-06-26 12:00:25.576505
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:33.915877
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__dict__['IE_NAME'] == 'Glide'
    assert GlideIE.__dict__['IE_DESC'] == 'Glide mobile video messages (glide.me)'
    assert GlideIE.__dict__['_VALID_URL'] == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:00:36.010784
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:37.356910
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance0 = GlideIE()


# Generated at 2022-06-26 12:00:41.227926
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:00:53.569408
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:01.007768
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        # TODO(daniel1011): In this test, "input_url" is of unicode type, but "_VALID_URL"
        # is of string type. As a result, the "self._match_id(input_url)" function called
        # in the constructor fails. To avoid this failure, both "input_url" and "_VALID_URL"
        # should be of unicode type.
        GlideIE(object(), 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    except:
        pass
    # On the other hand, if both "input_url" and "_VALID_URL" are of unicode type, test will pass

# Generated at 2022-06-26 12:01:10.648437
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'ext': 'mp4', 'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'thumbnail': 're:^https?://.*?\\.cloudfront\\.net/.*\\.jpg$', 'title': "Damon's Glide message"}}


# Generated at 2022-06-26 12:01:11.963135
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE is not None

# Generated at 2022-06-26 12:01:23.651416
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    test_data = dict(
        id='kYBDm7JUGO5nm5bqcNqN_A==',
        ext='mp4',
        title="Glide - #1 Video Messenger",
        url="http://d11z3qefdk5p5b.cloudfront.net/kYBDm7JUGO5nm5bqcNqN_A==.mp4",
        thumbnail="http://img.glide.me/kYBDm7JUGO5nm5bqcNqN_A==.jpg",
    )
    print(test_data['title'])
    assert ie.ie_key() == 'glide'  # ie_key() returns the name of the IE

# Generated at 2022-06-26 12:01:26.083094
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:01:35.852424
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    test_object = ie. _TEST
    test_object.get('url') == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    test_object.get('md5') == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:01:36.601434
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:01:37.940790
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-26 12:01:45.157607
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Create a GlideIE object

    This shouldn't fail
    """

    o = GlideIE()

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-26 12:01:47.983401
# Unit test for constructor of class GlideIE
def test_GlideIE():
    aGlideIE = GlideIE()
    aGlideIE.initialize()
    assert aGlideIE is not None

# Generated at 2022-06-26 12:01:51.543491
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:58.938459
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# First test case:
	# The url is valid and a correct video id is returned
	assert_equal(InfoExtractor._match_id(GlideIE._VALID_URL), "UZF8zlmuQbe4mr+7dCiQ0w==")
	# Second test case:
	# The url is not valid and an exception is raised
	try:
		InfoExtractor._match_id('https://www.youtube.com/watch?v=BaW_jenozKc')
	except Exception as e:
		pass
	else:
		assert False, "Should not have passed."

# Generated at 2022-06-26 12:02:02.511389
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:03.260364
# Unit test for constructor of class GlideIE
def test_GlideIE():
    toTest = GlideIE()
    return toTest

# Generated at 2022-06-26 12:02:04.039749
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:02:11.768154
# Unit test for constructor of class GlideIE
def test_GlideIE():
  ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

  assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
  assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:22.146787
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:02:26.970920
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    obj1 = ie.ie_key()
    obj2 = ie.ie_key()
    assert(obj1 == obj2)
    #assert(obj1 is obj2)

# Generated at 2022-06-26 12:02:47.982047
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert test is not None
    assert test.is_valid(test._VALID_URL)
    assert test.is_valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert test._TEST

# Generated at 2022-06-26 12:02:50.403171
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:03:01.869163
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create an instance of GlideIE
    glide_ie = GlideIE()

    # Check that the test cases are valid.
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:06.721506
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:03:18.248759
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_tests = [
        {
            'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
            'md5': '4466372687352851af2d131cfaa8a4c7',
            'info_dict': {
                'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
                'ext': 'mp4',
                'title': "Damon's Glide message",
                'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
            }
        }
    ]

    for video in video_tests:
        video_md5 = video['md5']
        video_info_dict = video['info_dict']
       

# Generated at 2022-06-26 12:03:22.059764
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:03:26.563248
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==').extract()

# Generated at 2022-06-26 12:03:28.498361
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	obj.test()


# Generated at 2022-06-26 12:03:31.854156
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.match("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:03:33.792556
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE(None)
    return glide_ie

# Generated at 2022-06-26 12:04:11.478662
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    from ytdl.extractors.glide import GlideIE
    # Instantiate object for class GlideIE
    test_obj = GlideIE(downloader=None)
    # Check the instance type
    assert isinstance(test_obj, GlideIE)
    # Check the keys of dictionary returned by method _real_extract()

# Generated at 2022-06-26 12:04:24.370671
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:26.211961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME

# Generated at 2022-06-26 12:04:29.934933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:04:33.994384
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('GlideIE')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:04:40.638007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # given
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    # when
    glide_ie = GlideIE(url)
    # then
    assert glide_ie.url == url

# Generated at 2022-06-26 12:04:41.432556
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:42.991107
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().extractor_key() == 'GlideIE'

# Generated at 2022-06-26 12:04:48.795849
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract_info_from_url()
    ie.extract_info_from_url(ie._VALID_URL)
    ie.extract_info_from_url(ie._TEST['url'])

# Generated at 2022-06-26 12:04:50.734140
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-26 12:06:02.078397
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie.IE_DESC

# Generated at 2022-06-26 12:06:07.388482
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:06:11.936924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-26 12:06:22.076444
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    # Test the GlideIE Constructor
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:31.708657
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = GlideIE._TEST.get('url')
    test_md5 = GlideIE._TEST.get('md5')

    # test constructor of class GlideIE
    GlideIE_ins = GlideIE()

    # test _TEST and IE_DESC
    assert (GlideIE._TEST, GlideIE.IE_DESC) == GlideIE_ins.test()

    # test _VALID_URL
    assert GlideIE_ins._VALID_URL == GlideIE._VALID_URL

    # test _real_extract
    assert GlideIE_ins._real_extract(test_url) == GlideIE._TEST

# Generated at 2022-06-26 12:06:40.541844
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:06:44.373557
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie

# Generated at 2022-06-26 12:06:52.982929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:07:02.355308
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-26 12:07:03.184318
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:09:41.513847
# Unit test for constructor of class GlideIE
def test_GlideIE():
	video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	#video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
	#test_ie = InfoExtractor()
	test_GlideIE = GlideIE(test_ie)
	return test_GlideIE


# Generated at 2022-06-26 12:09:42.109867
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:09:43.793919
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()

# Generated at 2022-06-26 12:09:49.516358
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:09:52.590901
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert isinstance(glide, GlideIE)


# Generated at 2022-06-26 12:09:55.164941
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-26 12:09:59.600029
# Unit test for constructor of class GlideIE
def test_GlideIE():
    module=__import__("glide")
    GlideIE = module.GlideIE
    glide_ie = GlideIE()
    assert isinstance(glide_ie, GlideIE) is True
    # GlideIE doesn't have _VALID_URL
    assert isinstance(glide_ie._VALID_URL, str) is False



# Generated at 2022-06-26 12:10:02.992773
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie is not None

# Generated at 2022-06-26 12:10:06.884375
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert (ie.IE_NAME == 'glide')
    assert (ie.IE_DESC == 'Glide mobile video messages (glide.me)')