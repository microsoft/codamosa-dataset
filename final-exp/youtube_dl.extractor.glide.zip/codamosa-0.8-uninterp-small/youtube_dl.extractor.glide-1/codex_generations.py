

# Generated at 2022-06-26 12:00:09.761509
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0.__init__()

# Generated at 2022-06-26 12:00:12.055565
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:15.058848
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-26 12:00:15.824542
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(1)

# Generated at 2022-06-26 12:00:20.142824
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor with no argument must return an object of GlideIE
    assert(str(type(glide_i_e_0)) == "<class '__main__.GlideIE'>")
    # _VALID_URL must be a compiled regular expression
    assert(str(type(glide_i_e_0._VALID_URL)) == "<class '_sre.SRE_Pattern'>")
    # _TEST must be a dictionary
    assert(str(type(glide_i_e_0._TEST)) == "<type 'dict'>")
    # _TEST must be a dictionary
    assert(str(type(glide_i_e_0._TEST['url'])) == "<type 'unicode'>")

# Generated at 2022-06-26 12:00:22.057518
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:00:30.696450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import re
    import urllib2

    resp = urllib2.urlopen(r"'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='")
    webpage = resp.read()

    title = glide_i_e_0._html_search_regex(r'<title>(.+?)</title>', webpage, 'title', default=None) or glide_i_e_0._og_search_title(webpage)

# Generated at 2022-06-26 12:00:32.929632
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:34.858018
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:38.375028
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
# Testing whether the GlideIE instantiation creates the appropriate object
    assert_true(isinstance(glide_i_e, GlideIE))



# Generated at 2022-06-26 12:00:44.937939
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ifile = "../test/test_data/test.txt"
    ofile = "../test/test_data/test.json"
    glideoe = GlideIE(ifile, ofile)
    assert glideoe.inputfile == "../test/test_data/test.txt"
    assert glideoe.outputfile == "../test/test_data/test.json"
    return


# Generated at 2022-06-26 12:00:51.483742
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.id == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:00:54.218398
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert 'GlideIE' == extractor.__class__.__name__


# Generated at 2022-06-26 12:01:01.513841
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==' 
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == "Damon's Glide message"

# Generated at 2022-06-26 12:01:12.379576
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
   

# Generated at 2022-06-26 12:01:16.069214
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:01:21.612687
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert i.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:26.572082
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:27.392038
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:28.837773
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()


# Generated at 2022-06-26 12:01:36.286543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert "unit test" == "unit test"

# Generated at 2022-06-26 12:01:40.790999
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create object to call method _real_extract()
    glide_ie = GlideIE()
    # Create a test url
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Call _real_extract() method of class GlideIE
    glide_ie._real_extract(url)

# Generated at 2022-06-26 12:01:43.920016
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-26 12:01:53.936322
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:59.770599
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    inst.get_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    inst.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert inst

# Generated at 2022-06-26 12:02:02.864527
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._html_search_regex([''], '<title>(.+?)<\/title>', 'title')

# Generated at 2022-06-26 12:02:05.372730
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://www.youtube.com')

# Generated at 2022-06-26 12:02:09.419073
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:02:11.517933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("")
    assert ie is not None

# Generated at 2022-06-26 12:02:18.718202
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'GlideIE'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:02:34.011090
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for the constructor of GlideIE()."""
    GLIDE_IE = GlideIE()
    assert GLIDE_IE is not None

# Generated at 2022-06-26 12:02:38.828652
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_inst = ie()
    assert ie_inst._VALID_URL == ie_inst._TEST['url']
    assert ie_inst._TEST['id'] == ie_inst._VALID_URL

# Generated at 2022-06-26 12:02:43.092193
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC

# Generated at 2022-06-26 12:02:49.475532
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    A simple test to check if the constructor of this class has changed
    """
    ie = GlideIE()
    # If this test fails, please change the class name back to GlideIE
    # and report the issue on GitHub
    assert ie.__class__.__name__ == "GlideIE", ie.__class__.__name__

# Generated at 2022-06-26 12:02:59.555404
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = GlideIE.IE_DESC
    ie.IE_NAME = GlideIE.IE_NAME
    ie._VALID_URL = GlideIE._VALID_URL
    ie._TESTS = GlideIE._TESTS

    for (expected_ie, url) in [(GlideIE, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')]:
        assert ie == expected_ie
        assert ie.suitable(url)


# Generated at 2022-06-26 12:03:09.159539
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()._extract_info('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') 
    assert info['id'] is 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['title'] is "Damon's Glide message"
    assert info['url'] is not None
    assert info['thumbnail'] is not None

# Generated at 2022-06-26 12:03:10.257558
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('Glide', 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-26 12:03:21.611605
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:24.890959
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie == None


# Generated at 2022-06-26 12:03:31.134614
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g_instance = GlideIE(None)

    assert g_instance._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert g_instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert g_instance.age_limit == 0


# Generated at 2022-06-26 12:04:00.660493
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert "GlideIE" == GlideIE.__name__


# Generated at 2022-06-26 12:04:03.962945
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:04:07.489443
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:08.096525
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-26 12:04:15.171461
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global IE_DESC
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:16.028953
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import GlideIE
    assert check_inheritance(GlideIE, InfoExtractor)

# Generated at 2022-06-26 12:04:18.486421
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test GlideIE Class constructor
    """
    GlideIE()

# Generated at 2022-06-26 12:04:19.494910
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-26 12:04:21.961990
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert (x.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-26 12:04:32.261736
# Unit test for constructor of class GlideIE
def test_GlideIE():
    args = {'ie': 'glide', 'link': 'http://share.glide.me/J3qB4p4Bd4t4+Dtb7+0JVA=='}
    glide_video_info_extractor = InfoExtractor( **args )
    video_url = glide_video_info_extractor.ie._download_webpage(algo=glide_video_info_extractor.ie._match_id, **args)

# Generated at 2022-06-26 12:05:37.358400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import ExtractorError
    try:
        GlideIE()
    except ExtractorError as e:
        assert False, 'Test for GlideIE constructor failed with message: %s' % e.msg

# Generated at 2022-06-26 12:05:48.145349
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for valid URL
    i = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:05:52.586882
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert(str(instance.__class__) == "<class 'youtube_dl.extractor.glide.GlideIE'>")


# Generated at 2022-06-26 12:05:53.637157
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:05:57.901720
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:07.908566
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:06:12.999529
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", {})

# Generated at 2022-06-26 12:06:22.469111
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    glides = [
        "http://share.glide.me/B3s_p_G7yJdbvj8WG4x4Fw==",
        "http://share.glide.me/1Aaik7YYdg2mFbwH6UJSmQ==",
        "http://share.glide.me/Kjb5td-yv0Iygwj3zSTpJw==",
        "http://share.glide.me/egJlOI63FoFwf3zq0pRT1w==",
        "http://share.glide.me/RJd0Q2z8gU6C1UHWMK_LTg==",
    ]

    for glide in glides:
        ie_result = ie

# Generated at 2022-06-26 12:06:32.903396
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:41.972128
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:09:08.424921
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE

# Generated at 2022-06-26 12:09:14.432584
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    obj = GlideIE()
    res = obj._real_extract(url)

# Generated at 2022-06-26 12:09:15.913571
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE==GlideIE())

# Generated at 2022-06-26 12:09:17.636870
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()

# Generated at 2022-06-26 12:09:22.492420
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test class constructor."""
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(ie._VALID_URL, basestring)
    assert isinstance(ie.IE_DESC, basestring)
    assert ie.IE_NAME is None
    assert isinstance(ie.REPORT_HTML_OK, bool)
    assert ie.REPORT_VIDEO_DOWNLOADED, bool
    assert isinstance(ie._TEST, dict)

# Generated at 2022-06-26 12:09:32.699149
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:09:43.347606
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:09:49.201096
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'thumbnail': 're:^https?://.*?\\.cloudfront\\.net/.*\\.jpg$', 'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'title': "Damon's Glide message", 'ext': 'mp4'}}

# Generated at 2022-06-26 12:09:50.932765
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test( GlideIE )

# Generated at 2022-06-26 12:10:00.742201
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'