

# Generated at 2022-06-26 12:00:10.572842
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()

# Generated at 2022-06-26 12:00:11.580783
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 'GlideIE' == GlideIE.__name__


# Generated at 2022-06-26 12:00:13.360081
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:14.691405
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:15.858423
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), GlideIE)


# Generated at 2022-06-26 12:00:17.437349
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(glide_i_e_0.IE_DESC == "Glide mobile video messages (glide.me)")


# Generated at 2022-06-26 12:00:20.479924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:21.147600
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()

# Generated at 2022-06-26 12:00:23.722615
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception:
        assert False


# Generated at 2022-06-26 12:00:24.854829
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    pass

# Generated at 2022-06-26 12:00:31.440065
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Check whether the GlideIE object is created correctly
    instance = GlideIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-26 12:00:39.048713
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie=GlideIE(u'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract(u'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print('GlideIE constructor '+str(ie.embed_url))
    print('GlideIE constructor '+str(ie.url))
    print('GlideIE constructor '+str(ie.title))
    print('GlideIE constructor '+str(ie.description))
    print('GlideIE constructor '+str(ie.duration))
    print('GlideIE constructor '+str(ie.id))
    print('GlideIE constructor '+str(ie.extractor))

# Generated at 2022-06-26 12:00:46.546147
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glideIE = GlideIE()
	assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert glideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:00:47.976356
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-26 12:00:55.763253
# Unit test for constructor of class GlideIE
def test_GlideIE():
    logdebug("\nTESTING GLIDE.ME")
    
    assert( str(GlideIE.IE_DESC) == "Glide mobile video messages (glide.me)" )
    assert( GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)' )
   
    logdebug("GlideIE instance: {}\n\
              IE_DESC: {}\n\
              _VALID_URL: {}".format(
              GlideIE, GlideIE.IE_DESC,
              GlideIE._VALID_URL))

test_GlideIE()

# Generated at 2022-06-26 12:00:59.164626
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE(0)

    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:03.554030
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:03.886222
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-26 12:01:05.384489
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    GlideIE(None)

# Generated at 2022-06-26 12:01:09.215671
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None, None)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:24.482163
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gl = GlideIE(1, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:01:31.556665
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    expected_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    actual_id = ie._match_id(url)
    assert expected_id == actual_id, 'Expected id: ' + expected_id + ', Actual id: ' + actual_id

# Generated at 2022-06-26 12:01:39.165999
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:41.357082
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('glideshare', 'glide.me')

# Generated at 2022-06-26 12:01:44.972001
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideie = GlideIE()
    test = glideie._VALID_URL
    print(test)
    
    
    
    

# Generated at 2022-06-26 12:01:53.335706
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.IE_NAME == 'glide'
    assert g.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert g.VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert g.TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert g.TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:01:56.395811
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/hDT0zPX9j0FZzM5S5HT5Fw==")

# Generated at 2022-06-26 12:01:57.630404
# Unit test for constructor of class GlideIE
def test_GlideIE():
    InfoExtractor.test_constructor(GlideIE)

# Generated at 2022-06-26 12:01:59.191439
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL.match('http://glide.me/video-id') is not None

# Generated at 2022-06-26 12:01:59.967661
# Unit test for constructor of class GlideIE
def test_GlideIE():
	pass

# Generated at 2022-06-26 12:02:13.932667
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE({}, {})

# Generated at 2022-06-26 12:02:22.683280
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.IE_DESC == "Glide mobile video messages (glide.me)"
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:25.656473
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://vimeo.com/1234')
    assert isinstance(ie, GlideIE)

# Generated at 2022-06-26 12:02:33.139667
# Unit test for constructor of class GlideIE
def test_GlideIE():
    def test_url(url):
        GlideIE._match_id(GlideIE(), url)

    valid_urls = [
        ("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="),
        ("http://share.glide.me/0bEcN1vX8W/"),
        ("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="),
        ("https://share.glide.me/0bEcN1vX8W/"),
    ]
    for url in valid_urls:
        yield test_url, url

# Generated at 2022-06-26 12:02:35.620063
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:02:37.888297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(InfoExtractor())
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

#Unit tests for method _real_extract() of class GlideIE

# Generated at 2022-06-26 12:02:39.846155
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_Str = GlideIE(
        _downloader=None,
        _match_id=None,
        url=None
    )
    test_Str.initialize()
    return

# Generated at 2022-06-26 12:02:41.583621
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:02:53.396382
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:54.799796
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie is not None

# Generated at 2022-06-26 12:03:19.605209
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:03:24.231976
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("Constructor of class GlideIE")
    GlideIE("GlideIE", "Glide mobile video messages (glide.me)", "glide.me")


# Generated at 2022-06-26 12:03:28.849393
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor._VALID_URL is not None
    assert info_extractor.IE_NAME is not None
    assert info_extractor.IE_DESC is not None

# Generated at 2022-06-26 12:03:29.882297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('asdf')

# Generated at 2022-06-26 12:03:39.070334
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    url = obj._TEST['url']
    assert url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    r = obj._real_extract(url)
    assert r['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert r['title'] == "Damon's Glide message"

# Generated at 2022-06-26 12:03:44.918976
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert hasattr(ie, '_TEST')
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	test = ie._TEST
	test_url = test['url']
	test_md5 = test['md5']
	test_info_dict = test['info_dict']
	assert test_info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
	assert test_info_dict['ext'] == 'mp4'
	assert test_info_dict['title'] == "Damon's Glide message"
	

# Generated at 2022-06-26 12:03:47.098575
# Unit test for constructor of class GlideIE
def test_GlideIE():
	result = GlideIE()
	assert(result is not None)

# Generated at 2022-06-26 12:03:53.837361
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    expected_result = 'http://d31g9uudhkpkdg.cloudfront.net/glide/video/UZF8zlmuQbe4mr+7dCiQ0w/UZF8zlmuQbe4mr+7dCiQ0w.mp4'
    ie = GlideIE(test_url)
    ie.download()
    assert ie.video_url == expected_result

# Generated at 2022-06-26 12:03:56.996543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    InfoExtractor(GlideIE._VALID_URL).extract(GlideIE._VALID_URL)

# Generated at 2022-06-26 12:04:01.098938
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == 'glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:04:53.954987
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE()._VALID_URL).startswith(r'https?://share\.glide\.me/')

# Generated at 2022-06-26 12:04:55.466147
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test(GlideIE)

# Generated at 2022-06-26 12:04:59.597937
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print('test_GlideIE: Class GlideIE is OK, '
          'and its methods are working!')


# Generated at 2022-06-26 12:05:00.578586
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE()

# Generated at 2022-06-26 12:05:05.365503
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:05:08.778543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:05:10.646165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-26 12:05:19.331438
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This test is for the constructor of class GlideIE
    # Test cases for the constructor with invalid url
    invalid_url_list = [
        'https://www.youtube.com/watch?v=8J-Vq3x3qnE', # Youtube url
        'https://glide.me/', # main url
        'https://glide.me/faq', # main url with faq
        'https://share.glide.me/', # share url
        'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==/', # share url with invalid id
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==/video.mp4', # share url with invalid id and extension
    ]

# Generated at 2022-06-26 12:05:25.807893
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:05:36.165335
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Setup a class object for testing
    GlideIE_test = GlideIE(downloader=None)
    # Test url handle functions
    url1 = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    url2 = 'http://share.glide.me/'
    assert GlideIE_test._match_id(url1) == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE_test._match_id(url2) is None


# Generated at 2022-06-26 12:07:35.906181
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test class constructor of GlideIE"""
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'glide.me'

# Generated at 2022-06-26 12:07:38.709235
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL(GlideIE._TEST['url']) is True

# Generated at 2022-06-26 12:07:43.827679
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import unittest

# Generated at 2022-06-26 12:07:51.811028
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test from http://www.youtube.com/watch?v=5y5N5xKF5N0.
    # testing for IE_DESC can be removed after enough tests for other IEs.
    assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')
    # Test videos.
    # Parameter extractor is the extraction unit.
    # Parameter video_id is the key of each video.
    extractor = GlideIE()
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # Test for _real_extract(url).
    # Parameter url is the link of video.

# Generated at 2022-06-26 12:07:54.068109
# Unit test for constructor of class GlideIE
def test_GlideIE():
	g = GlideIE(None)

# Generated at 2022-06-26 12:07:59.069152
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert 'glide.me' in ie.IE_NAME
    assert ie.IE_DESC in ie.IE_NAME
    assert ie.VALID_URL == GlideIE._VALID_URL


# Generated at 2022-06-26 12:08:03.175165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # GlideIE constructor should throw exception when called with wrong parameter
    try:
        GlideIE(url=None)
    except TypeError as e:
        assert isinstance(e, TypeError)


# Generated at 2022-06-26 12:08:11.621947
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Description:
        Unit test for constructor of class GlideIE
    """
    result = GlideIE()
    assert result._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:08:21.470827
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:08:30.864505
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.set_downloader(None)
    ie.set_progress_hook(None)
    ie.set_sleep_interval(None)
    ie.set_socket(None)
    ie.set_proxy(None)
    ie.set_user_agent(None)
    ie.set_opener(None)
    ie.set_download_retry_max(None)
    ie.set_download_retry_sleep(None)
    ie.set_download_retry_continued_sleep(None)
    ie.set_download_max_filesize(None)
    ie.set_download_min_filesize(None)
    ie.set_download_ratelimit(None)
    ie.set_download_with_resume(None)
    ie.set_report