

# Generated at 2022-06-26 12:00:09.299870
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


test_GlideIE()

# Generated at 2022-06-26 12:00:10.509775
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass



# Generated at 2022-06-26 12:00:13.426814
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert test_case_0() == None

if __name__ == '__main__':
    import sys
    sys.exit(test_GlideIE())

# Generated at 2022-06-26 12:00:20.504906
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_1 = GlideIE()
    assert glide_i_e_1.IE_NAME == 'glide'
    assert glide_i_e_1.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_i_e_1._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:00:22.548359
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()


# Generated at 2022-06-26 12:00:24.363916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_1 = GlideIE()


# Generated at 2022-06-26 12:00:25.720862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().run_test('_GlideIE')



# Generated at 2022-06-26 12:00:27.318146
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create instance of GlideIE
    glide_i_e_0 = GlideIE()


# Generated at 2022-06-26 12:00:29.482563
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE() != None 


# Generated at 2022-06-26 12:00:31.440952
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()


# Generated at 2022-06-26 12:00:35.647592
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:00:43.673467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    u = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert u._match_id('http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w=') == 'UZF8zlmuQbe4mr-7dCiQ0w='
    assert u._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:00:49.278346
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Real/non-unit test that checks that Glide works as expected (can scrape
    # and extract the video URL)
    GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')



# Generated at 2022-06-26 12:00:53.306305
# Unit test for constructor of class GlideIE
def test_GlideIE():
	url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	ie = GlideIE()

# Generated at 2022-06-26 12:00:56.478955
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")


# Generated at 2022-06-26 12:00:57.739810
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests constructor of class GlideIE
    GlideIE()

# Generated at 2022-06-26 12:01:04.145846
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Constructor test
    """
    ie = GlideIE()
    # currently empty
    assert(ie.IE_NAME == 'GlideIE')
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')



# Generated at 2022-06-26 12:01:08.198924
# Unit test for constructor of class GlideIE
def test_GlideIE(): 
    ie = GlideIE(GlideIE.ie_key())
    assert isinstance(ie, GlideIE)
    assert ie.ie_name() == GlideIE.ie_key()

# Generated at 2022-06-26 12:01:12.401358
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert(glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:01:14.952840
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:33.057596
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #print("test_GlideIE\n")
    glideIE = GlideIE()
    glideIE._html_search_regex = lambda self, pattern, string, name: pattern
    data = glideIE._real_extract('', '', '', '')
    assert data.get('id', '') == ''
    assert data.get('title', '') == ''
    assert data.get('url', '') == ''
    assert data.get('thumbnail', '') == ''

    glideIE._html_search_regex = lambda self, pattern, string, name, default: name
    glideIE._og_search_title = lambda self, s: 'og_title'
    glideIE._og_search_video_url = lambda self, s: 'og_video_url'

# Generated at 2022-06-26 12:01:33.891158
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:41.217389
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    expected_title = "Damon's Glide message"
    extracted_title = ie.IE_DESC
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST["url"] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-26 12:01:52.848971
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Testing URL using class function _match_id
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    expected_video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    video_id = ie._match_id(test_url)
    assert video_id == expected_video_id
    # Testing URL using class function _real_extract
    info_dict = ie._real_extract(test_url)
    assert info_dict['id'] == expected_video_id
    assert info_dict['ext'] == 'mp4'
    assert info_dict['title'] == "Damon's Glide message"

# Generated at 2022-06-26 12:01:53.866984
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.ie_key() == 'Glide'

# Generated at 2022-06-26 12:02:06.873528
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("")._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE("")._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE("")._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE("")._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE("")._TEST['info_dict']['ext'] == 'mp4'
    assert Gl

# Generated at 2022-06-26 12:02:12.745602
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(GlideIE._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': 're:^https?://.*?\\.cloudfront\\.net/.*\\.jpg$', }})

# Generated at 2022-06-26 12:02:18.759568
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Unit test for constructor method of class GlideIE
    '''
    glide = GlideIE()
    expected_result = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert(glide._VALID_URL == expected_result)

# Generated at 2022-06-26 12:02:24.419621
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for class GlideIE, which should inherit from InfoExtractor
    assert issubclass(GlideIE, InfoExtractor)
    # Test for method '_real_extract'
    assert hasattr(GlideIE, '_real_extract')

# Generated at 2022-06-26 12:02:28.871349
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    test_input = r'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_ie._TEST["url"] == test_input

# Generated at 2022-06-26 12:02:43.016889
# Unit test for constructor of class GlideIE
def test_GlideIE():
	g = GlideIE(None)
	assert g is not None

# Generated at 2022-06-26 12:02:53.937510
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:55.361614
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()

# Generated at 2022-06-26 12:03:03.642281
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:04.928186
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:03:06.937442
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(object)
    assert isinstance(ie, GlideIE)

# Generated at 2022-06-26 12:03:15.016143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Expected values
    valid_url = ie._VALID_URL
    ie_desc = ie.IE_DESC
    ie_extract = ie._real_extract
    # Test for unexisting elements
    assert ie.BRIGHTCOVE_URL_TEMPLATE == None
    assert ie.SUCCESS_CODE == 0
    assert ie.fb_video_data == None
    # Test for existing elements
    assert ie.geo_verification_headers == None
    assert ie.IE_NAME == "glide"
    assert ie.res == None
    assert ie.socket == None

# Generated at 2022-06-26 12:03:15.904418
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-26 12:03:18.759940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        assert False, 'Unit test for class GlideIE fails'


# Generated at 2022-06-26 12:03:20.763403
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # GlideIE should be working
    assert 'Glide mobile video messages' == GlideIE.IE_DESC

# Generated at 2022-06-26 12:03:47.100297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:03:47.947464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-26 12:03:51.951631
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._downloader = None
    ie.report_warning
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == ie.IE_DESC
    assert ie.is_suitable(ie._VALID_URL)

# Generated at 2022-06-26 12:04:04.504530
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/([A-Za-z0-9\\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._T

# Generated at 2022-06-26 12:04:13.795475
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:17.877954
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") != False

# Generated at 2022-06-26 12:04:19.492565
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('')


# Generated at 2022-06-26 12:04:20.940456
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:04:23.709478
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    >>> from .pytube import YouTube
    >>> YouTube('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==').title
    "Damon's Glide message"
    """
    pass

# Generated at 2022-06-26 12:04:29.650835
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE
    instance = class_('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert instance._VALID_URL == class_._VALID_URL


# Generated at 2022-06-26 12:05:41.778319
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit test for constructor of class GlideIE
    extractor = GlideIE()
    assert extractor.IE_NAME == GlideIE.IE_NAME
    assert extractor.IE_DESC == GlideIE.IE_DESC
    # The following test only works if a global variable is set at the start of the script
    #assert extractor.IE_VERSION == GlideIE.IE_VERSION
    assert extractor._VALID_URL == GlideIE._VALID_URL
    assert extractor.__name__ == GlideIE.__name__
    assert extractor.parse_qs("http://youtube.com/?v=QH2-TGUlwu4&hl=pt") == {'v': ['QH2-TGUlwu4'], 'hl': ['pt']}

# Generated at 2022-06-26 12:05:46.847583
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:05:48.899008
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE(InfoExtractor()) is not None)

# Generated at 2022-06-26 12:05:51.139795
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-26 12:05:54.476923
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:05:55.742820
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, InfoExtractor)

# Generated at 2022-06-26 12:05:58.578712
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Success
    success = True
    try:
        GlideIE()
    except:
        success = False

    assert success, "GlideIE constructor failed"


if __name__ == '__main__':
    import sys
    sys.exit(test_GlideIE())

# Generated at 2022-06-26 12:06:02.434273
# Unit test for constructor of class GlideIE
def test_GlideIE():
    Glide = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:06:04.640178
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'glide'


# Generated at 2022-06-26 12:06:05.497339
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-26 12:08:21.095912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide = GlideIE()
    # Test method _proto_relative_url
    assert glide._proto_relative_url('//example.com/test') == 'http:example.com/test'
    # Test method _real_extract
    assert glide._real_extract(url)['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._real_extract(url)['title'] == "Damon's Glide message"

# Generated at 2022-06-26 12:08:25.181505
# Unit test for constructor of class GlideIE
def test_GlideIE():
  url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
  glide = GlideIE()
  glide._real_extract(url)

# Generated at 2022-06-26 12:08:29.325724
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:08:37.494881
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiation of class GlideIE
    glide = GlideIE()
    # Test of function _real_extract of class GlideIE
    print('Testing GlideIE._real_extract:')
    # Call to function _real_extract of class GlideIE
    glide._real_extract(glide._TEST['url'])

# Test for constructor of class GlideIE
test_GlideIE()

# Generated at 2022-06-26 12:08:38.600979
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:08:50.306320
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:08:53.694750
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:08:58.221415
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    GlideIE()._real_extract(url)

# Generated at 2022-06-26 12:09:04.210750
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-26 12:09:08.848702
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'