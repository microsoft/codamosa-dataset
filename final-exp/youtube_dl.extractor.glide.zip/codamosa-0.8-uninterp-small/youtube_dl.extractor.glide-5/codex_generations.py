

# Generated at 2022-06-26 12:00:09.761997
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()

# Generated at 2022-06-26 12:00:18.170365
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if (glide_i_e_0.IE_DESC != 'Glide mobile video messages (glide.me)'):
        raise

    if (glide_i_e_0._VALID_URL != r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'):
        raise


# Generated at 2022-06-26 12:00:20.469552
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass


# Generated at 2022-06-26 12:00:21.969567
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        assert isinstance(GlideIE(),InfoExtractor)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-26 12:00:25.441211
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    if type(glide_i_e) != GlideIE:
        raise AssertionError('Object of type GlideIE is not created.')


# Generated at 2022-06-26 12:00:26.503607
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE() is not None


# Generated at 2022-06-26 12:00:27.354777
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()

# Generated at 2022-06-26 12:00:31.225928
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    # begin add your unit test here
    # end of your unit test


# Generated at 2022-06-26 12:00:32.055711
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-26 12:00:35.498814
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_1 = GlideIE(default_Extractor=glide_i_e_0)


# Generated at 2022-06-26 12:00:39.052660
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:00:45.060797
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:00:50.643350
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE

    url = "https://share.glide.me/RZHnPnEkY+mmKq3qm2nDxQ=="
    assert ie._match_id(url) == 'RZHnPnEkY+mmKq3qm2nDxQ=='

# Generated at 2022-06-26 12:00:59.926130
# Unit test for constructor of class GlideIE
def test_GlideIE():
	"""
	GlideIE should return a dictionary of metadata about the video 
	"""

	# no video should be found and no video ID should be returned
	glide = GlideIE()
	video_id = glide.extract("https://www.random.com")
	assert video_id == None
	
	# video should be found and its video ID should be returned
	# video has ID 'UZF8zlmuQbe4mr+7dCiQ0w==' with title "Damon's Glide message"
	glide = GlideIE()
	video_id = glide.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:01:11.790858
# Unit test for constructor of class GlideIE
def test_GlideIE():
    Video = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    md5 = '4466372687352851af2d131cfaa8a4c7'
    Video._download_webpage(url, 'video_id')
    Video._download_webpage(url, 'video_id')
    video = Video._real_extract(url)
    assert video['url'] == 'https://s3.amazonaws.com/glide-videos/video_id/Original.mp4'
    assert video['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:01:16.962202
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).IE_NAME == 'glide'
    assert GlideIE(None).IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:01:20.811545
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.md5 == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-26 12:01:24.375108
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 12:01:26.944442
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == "Glide mobile video messages (glide.me)"
    

# Generated at 2022-06-26 12:01:30.185625
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:37.566768
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie

# Generated at 2022-06-26 12:01:38.490522
# Unit test for constructor of class GlideIE
def test_GlideIE():
	instance = GlideIE()

# Generated at 2022-06-26 12:01:40.619538
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    return "OK"

# Test to check the API starts

# Generated at 2022-06-26 12:01:45.346422
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests for the basic constructor
    try:
        GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==")
    except:
        assert False
    assert True



# Generated at 2022-06-26 12:01:49.882337
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert 'Glide' in glide.IE_DESC
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-26 12:01:52.148779
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == "Glide"

# Generated at 2022-06-26 12:02:03.120702
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Unit test for constructor of class GlideIE
    '''
    ie = GlideIE()
    # Check that GlideIE object is instantiated
    assert ie
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:07.386748
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test if the constructors creates
    # the expected object
    assert GlideIE.suitable(
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:10.464775
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:15.670574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # https://github.com/rg3/youtube-dl/issues/8486
    assert GlideIE(None)._VALID_URL == GlideIE.__dict__['_VALID_URL']

# Generated at 2022-06-26 12:02:32.293798
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert "GlideIE" in ie.IE_DESC
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:02:33.611133
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == GlideIE.IE_DESC._VALID_URL

# Generated at 2022-06-26 12:02:34.565184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie,InfoExtractor)
    print ('Pass!')

# Generated at 2022-06-26 12:02:36.070013
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('a', 'b')

# Generated at 2022-06-26 12:02:39.047353
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .extractors import GlideIE
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:42.148957
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE()._VALID_URL == GlideIE._VALID_URL)

# Generated at 2022-06-26 12:02:45.933390
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(ie)

# Generated at 2022-06-26 12:02:49.349852
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:53.935023
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Can't use the assertTrue function here since the method is expected to return a boolean not an AssertionError
    if isinstance(ie, InfoExtractor):
        return True
    assert False

# Generated at 2022-06-26 12:02:55.363067
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert dict.items(GlideIE._TEST)

# Generated at 2022-06-26 12:03:19.606083
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:03:25.705451
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC

    ie.IE_NAME
    ie.IE_VERSION
    ie.IE_DESC

    ie._VALID_URL
    ie._WORKING
    ie._TESTS

# Generated at 2022-06-26 12:03:35.136446
# Unit test for constructor of class GlideIE

# Generated at 2022-06-26 12:03:36.151855
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert isinstance(GlideIE(), GlideIE)


# Generated at 2022-06-26 12:03:40.207218
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:53.183205
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    expected_output = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    actual_output = glide_ie._TEST
    # Check the generated test case
    assert actual_output == expected_output

# Generated at 2022-06-26 12:03:54.898821
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-26 12:04:05.847049
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("Test constructor of class GlideIE")
    x = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert x.IE_DESC == "Glide mobile video messages (glide.me)"
    assert x._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert x._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert x._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-26 12:04:06.974962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE().get_info(url='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')['title'] == "Damon's Glide message")

# Generated at 2022-06-26 12:04:08.015511
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:04:59.263814
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-26 12:05:00.304983
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:05:02.179618
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC

# Generated at 2022-06-26 12:05:06.119071
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # These tests have been commented because they were never executed.
    # They were intended to test that GlideIE.__init__ calls InfoExtractor.__init__, but this is not the case.
    # x = GlideIE()
    # assert(isinstance(x, InfoExtractor))
    return

# Generated at 2022-06-26 12:05:11.224884
# Unit test for constructor of class GlideIE
def test_GlideIE():
	try:
		if GlideIE() != None:
			return 1
	except AssertionError as e:
		return str(e)
	except:
		return 1


# Generated at 2022-06-26 12:05:19.534533
# Unit test for constructor of class GlideIE
def test_GlideIE():
	"""
	Runs a test using a hard-coded URL of a Glide clip.
	"""
	
	# import csv
	from datetime import datetime
	from sys import argv
	from os import path, stat
	from urllib2 import urlopen
	from shutil import rmtree
	
	# Set up file paths
	code_path = path.dirname(path.abspath(argv[0]))
	resources_path = code_path[:code_path.rfind('/')] + "/resources"
	
	# Read in configs
	with open(path.join(resources_path, 'configs.csv'), 'r') as f:
		reader = csv.DictReader(f)
		tweet_info = []

# Generated at 2022-06-26 12:05:20.780970
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test = GlideIE()
	test.test()

# Generated at 2022-06-26 12:05:26.025754
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie.IE_DESC == GlideIE.IE_DESC
    assert ie._TEST == GlideIE._TEST

# Generated at 2022-06-26 12:05:37.192742
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:05:44.965974
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        url_extract_info = GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    except:
        assert False, 'test_GlideIE() failed'
    else:
        assert True
# End of unit test

# Generated at 2022-06-26 12:07:40.106191
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:07:41.364544
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-26 12:07:46.289862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.__dict__.get('_VALID_URL') == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:07:47.061040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:07:50.613957
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:08:01.259985
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE.GlideIE = GlideIE()
    test_GlideIE.actual_result = test_GlideIE.GlideIE._download_webpage('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:08:08.714477
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test if Glide constructor works."""
    # No exception should be thrown for valid arguments
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # This should fail with ValueError exception
    GlideIE("http://www.youtube.com/watch?v=BaW_jenozKc")

# Generated at 2022-06-26 12:08:13.360252
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/FWVfIyQ2QGue7CjKRNk-Vg==')
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-26 12:08:18.767925
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiating a GlideIE object
    gie = GlideIE()
    # Accessing protected property
    assert gie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:08:22.802237
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='