

# Generated at 2022-06-26 12:00:09.091586
# Unit test for constructor of class GlideIE
def test_GlideIE():
    yield (test_case_0)

# Generated at 2022-06-26 12:00:11.389733
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("Testing constructor of GlideIE")


# Generated at 2022-06-26 12:00:12.731217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()


# Generated at 2022-06-26 12:00:16.305559
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global glide_i_e_0
    try:
        assert(glide_i_e_0)
    except NameError:
        assert False
    except:
        assert True


# Generated at 2022-06-26 12:00:17.621041
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case_0()


# Generated at 2022-06-26 12:00:24.858792
# Unit test for constructor of class GlideIE
def test_GlideIE():
    
    res_id = glide_i_e_0.IE_DESC
    res_id = glide_i_e_0._VALID_URL
    res_id = glide_i_e_0._TEST
    res_id = glide_i_e_0._real_extract(url)

# Generated at 2022-06-26 12:00:26.966410
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"

# Testing if URL is valid or not.

# Generated at 2022-06-26 12:00:30.602898
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    assert glide_i_e is not None


# Generated at 2022-06-26 12:00:36.937755
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = GlideIE()
    assert result.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert result._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:00:37.877607
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_0 = GlideIE()

# Generated at 2022-06-26 12:00:44.744209
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Check if the constructor of GlideIE properly sets the IE_DESC value
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:00:45.583071
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:00:48.518628
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:00:58.220267
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # assert_equal(list, list)
    g3 = GlideIE("", "")
    assert g3.IE_DESC == "Glide mobile video messages (glide.me)"
    assert g3._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:00:59.663050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:08.733113
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glideie.IE_NAME == 'Glide'
    assert glideie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glideie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:09.576756
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:01:22.442270
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:01:34.659877
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create a GlideIE object that checks the url
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glidei = GlideIE(url)

    # Check the correct initialization of the object
    assert glidei.IE_DESC == "Glide mobile video messages (glide.me)"
    assert glidei._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glidei.REMOVE_HTML_TAGS == re.compile(r'(<!--.*?-->|<[^>]*>|\t|\n)', re.DOTALL)
    assert glidei.IE_NAME == "GlideIE"


# Generated at 2022-06-26 12:01:39.088960
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc == 'Glide mobile video messages (glide.me)'
    assert ie.suitable(None)
    assert ie.working()


# Generated at 2022-06-26 12:01:54.710307
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == "Glide mobile video messages (glide.me)"
    expected_valid_url = 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie._VALID_URL == expected_valid_url

# Generated at 2022-06-26 12:01:59.770634
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
test_GlideIE()

# Generated at 2022-06-26 12:02:10.149024
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert GlideIE._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"
    assert GlideIE._TEST['info_dict']['id'] == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert GlideIE._TEST['info_dict']['ext'] == "mp4"
    assert GlideIE._TEST['info_dict']['title'] == "Damon's Glide message"

# Generated at 2022-06-26 12:02:17.676227
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import InfoExtractor
    import GlideIE
    infoExtractor = InfoExtractor()
    glideIE = GlideIE.GlideIE(infoExtractor)
    assert glideIE.ie_key() == "Glide"
    assert glideIE.ie_desc() == "Glide mobile video messages (glide.me)"


# Generated at 2022-06-26 12:02:29.052275
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$'}}

# Generated at 2022-06-26 12:02:32.219524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    GlideIE(None)


# Generated at 2022-06-26 12:02:42.106859
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_NAME == "Glide")
    assert(ie.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    #Test _real_extract fucntion
    assert(ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==').get('id') == 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:02:43.530489
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE is not None

# Generated at 2022-06-26 12:02:44.332144
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:02:49.180036
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-26 12:03:08.733900
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:09.733059
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ins = GlideIE();

# Generated at 2022-06-26 12:03:11.808076
# Unit test for constructor of class GlideIE
def test_GlideIE():

    x = GlideIE()
    assert x

# Generated at 2022-06-26 12:03:15.397516
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(issubclass(GlideIE, InfoExtractor))
    assert(GlideIE.IE_DESC)
    assert(GlideIE._VALID_URL)


# Generated at 2022-06-26 12:03:17.211912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide.me'

# Generated at 2022-06-26 12:03:24.085308
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert (instance.IE_NAME == 'glide')
    assert (instance.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert (instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:03:25.341222
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:03:28.987085
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('test_GlideIE')
    print(ie.IE_DESC)

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-26 12:03:41.949818
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == "glide"
    assert obj.IE_DESC == "Glide mobile video messages (glide.me)"
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj._is_valid_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == True
    assert obj._is_valid_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=") == False

# Generated at 2022-06-26 12:03:47.390728
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:04:17.509251
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url)

# Generated at 2022-06-26 12:04:21.004316
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:04:33.994352
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
    assert(ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:04:38.953277
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:04:48.086029
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:04:49.406056
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()



# Generated at 2022-06-26 12:04:50.246330
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:51.993544
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("")

# Generated at 2022-06-26 12:04:54.398304
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test that GlideIE can be instantiated properly
    object_ = GlideIE(None)
    assert object_ is not None

# Generated at 2022-06-26 12:04:59.053200
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        print("Testing GlideIE()")
        ie = GlideIE()
    except:
        print("Exception while testing GlideIE()")
    #print("Test finished successfully")

# Generated at 2022-06-26 12:06:09.800504
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
# Unit test to see if the url is valid

# Generated at 2022-06-26 12:06:21.418418
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    #assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    #assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    #assert obj._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    #assert obj._TEST['info_dict

# Generated at 2022-06-26 12:06:31.987531
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.ie_key() == 'Glide'
    assert GlideIE.IE_NAME == 'glide'
    assert GlideIE.ie_key() == 'Glide'
    assert GlideIE.extractor_key == 'glide'


# Generated at 2022-06-26 12:06:32.753189
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC

# Generated at 2022-06-26 12:06:33.226961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:06:35.108142
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE({})
    if not isinstance(instance, GlideIE):
        raise Exception("GlideIE constructor failed")

# Generated at 2022-06-26 12:06:41.445030
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    
    # Check if keys of '_TEST' are equal with the attributes of object ie
    for key in ie._TEST:
        assert key in ie.__dict__
    
    # Check if values of '_TEST' are equal with the attributes of object ie
    for key in ie._TEST:
        value = ie._TEST[key] 
        assert value == ie.__dict__[key]

# Generated at 2022-06-26 12:06:43.528558
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:52.002589
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from unittest import TestCase, main

    class TestGlideIE(TestCase):
        def setUp(self):
            self.glide_ie = GlideIE()
        def test_constructor(self):
            self.assertEqual(self.glide_ie._VALID_URL, GlideIE._VALID_URL)
            self.assertEqual(self.glide_ie._TEST, GlideIE._TEST)
            self.assertEqual(self.glide_ie.IE_NAME, GlideIE.IE_NAME)
            self.assertEqual(self.glide_ie.IE_DESC, GlideIE.IE_DESC)
    main(verbosity=2)

# Generated at 2022-06-26 12:07:00.687875
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Unit test the method _real_extract()
    info = ie._real_extract(url)
    # Unit test the method _match_id()
    match_id = ie._match_id(url)
    # Unit test the method _download_webpage()
    webpage = ie._download_webpage(url, match_id)

    assert info['id'] == match_id
    assert webpage.find('Damon') > -1

# Generated at 2022-06-26 12:09:31.908475
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie
	

# Generated at 2022-06-26 12:09:32.875130
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:09:37.372739
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-26 12:09:38.171231
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 1

# Generated at 2022-06-26 12:09:40.287630
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE()._test_extract_info('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:09:42.310726
# Unit test for constructor of class GlideIE
def test_GlideIE():
	arg1 = 'Glide'
	test1 = "test"
	test_class = GlideIE(test1)
	assert test_class.IE_NAME == arg1

# Generated at 2022-06-26 12:09:48.400505
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    gie = GlideIE()
    print("Test for GlideIE\nURL is %s" % url)
    print("ID is %s" % gie._match_id(url))
    print("URL is %s" % gie.IE_DESC.encode('utf-8'))
    print("Valid URL is %s" % gie._VALID_URL)
    print("TEST is %s" % gie._TEST)
    webpage = gie._download_webpage(url, gie._match_id(url))
    print("webpage is %s" % webpage)

# Generated at 2022-06-26 12:09:54.134634
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = GlideIE()._real_extract(GlideIE._TEST['url'])
    assert result['url'] == url
    assert result['title'] == title
    assert result['md5'] == md5
    assert result['thumbnail'] == thumbnail

# Generated at 2022-06-26 12:09:57.841716
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert('GlideIE' == obj.IE_NAME)
    assert('Video message' == obj.IE_DESC)
    assert(obj.IE_VERSION == '1.0.0')

# Generated at 2022-06-26 12:10:07.818224
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Test case for constructor of class GlideIE. """

    # Test parameter url is string type
    url = 'http://share.glide.me/DpuJyd2GQJuYrA2jw7RPMQ=='
    glide = GlideIE(url=url)
    assert isinstance(glide, GlideIE)
    assert glide._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
