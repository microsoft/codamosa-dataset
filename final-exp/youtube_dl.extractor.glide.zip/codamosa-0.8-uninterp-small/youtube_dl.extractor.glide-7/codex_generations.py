

# Generated at 2022-06-26 12:00:09.630242
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()  


# Generated at 2022-06-26 12:00:11.923285
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()

# Generated at 2022-06-26 12:00:19.217745
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:00:20.913862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass


# Generated at 2022-06-26 12:00:21.909993
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e_1 = GlideIE()


# Generated at 2022-06-26 12:00:25.157347
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()
    video_id = glide_i_e._match_id


# Generated at 2022-06-26 12:00:26.200294
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE() is not None


# Generated at 2022-06-26 12:00:28.212194
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert_equal(
        GlideIE.IE_DESC,
        'Glide mobile video messages (glide.me)',
        )


# Generated at 2022-06-26 12:00:40.525422
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert_equals(glide_i_e_0.IE_DESC, 'Glide mobile video messages (glide.me)')
    assert_equals(glide_i_e_0._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-26 12:00:42.552352
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_i_e = GlideIE()


# Generated at 2022-06-26 12:00:48.160507
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:00:58.083750
# Unit test for constructor of class GlideIE
def test_GlideIE():
    expected_GlideIE = ("GlideIE(info_dict={'ext': 'mp4', 'id': u'UZF8zlmuQbe4mr+7dCiQ0w=='," 
      + "'thumbnail': u'http://d3j3lscq9q2uux.cloudfront.net/u/UZF8zlmuQbe4mr+7dCiQ0w==.mp4.jpg',"
      + "'title': u\"Damon's Glide message\"},"
      + "ie=<class '__main__.GlideIE'>, url=u'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')")


# Generated at 2022-06-26 12:01:00.173411
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE(None)

# Generated at 2022-06-26 12:01:11.894466
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests valid url
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.valid_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.valid_url("http://share.glide.me/uL7x4XNnQVyRJ+1NwyS7Sg==")
    assert ie.valid_url("http://share.glide.me/ZUDDmHtBQlW+WCbtfJHOMw==")

    # Tests invalid url
    assert not ie.valid_url("http://share.glide.me/")

# Generated at 2022-06-26 12:01:16.445741
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:01:17.242000
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE("https://www.youtube.com/")


# Generated at 2022-06-26 12:01:18.726037
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert str(obj) == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-26 12:01:21.392958
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# testing for invalid case
	assert GlideIE(None, "www.example.com") is None

	assert GlideIE(None, "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") is not None

# Generated at 2022-06-26 12:01:25.182825
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:01:35.510449
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:01:44.972702
# Unit test for constructor of class GlideIE
def test_GlideIE():
  g = GlideIE()
  assert isinstance(g, InfoExtractor)


# Generated at 2022-06-26 12:01:54.630644
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # unit test for constructor of class GlideIE
    # - test for creating an instance of GlideIE
    video_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glide_instance = GlideIE(url)
    # - test for field ie_desc
    assert glide_instance._ie_desc ==  "Glide mobile video messages (glide.me)"
    # - test for field ie_key
    assert glide_instance._ie_key ==  "Glide"
    # - test for field ie_desc

# Generated at 2022-06-26 12:01:56.999481
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-26 12:01:57.985700
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    GlideIE()

# Generated at 2022-06-26 12:02:06.911431
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import unittest as ut

    class TestGlideIE(ut.TestCase):
        def setUp(self):
            self.url     = 'https://share.glide.me/PZo7W8XkCjK7th5dd5w5wA=='
            self.glideIE = GlideIE()

        def test_extract(self):
            self.glideIE.extract(self.url)
            pass

    ut.main(verbosity=2)


# Generated at 2022-06-26 12:02:13.592779
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME == "GlideIE"
    assert GlideIE._VALID_URL ==  r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.IE_DESC ==  "Glide mobile video messages (glide.me)"

# Generated at 2022-06-26 12:02:22.566058
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    assert inst._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:02:28.082015
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #assert GlideIE(object)._VALID_URL == '/^https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)$/'
    GlideIE(object)

# Generated at 2022-06-26 12:02:40.773201
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:02:44.802808
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test ID
    GlideIE(None)._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # Test invalid ID
    GlideIE(None)._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w")
    # Test invalid URL
    GlideIE(None)._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+")
    # Test matching values
    GlideIE(None)._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # Test _proto_relative_url
    Gl

# Generated at 2022-06-26 12:02:59.356028
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-26 12:03:12.266645
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:15.299738
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:03:19.931594
# Unit test for constructor of class GlideIE
def test_GlideIE():
  test_GlideIE = GlideIE()
  assert test_glide.name == 'glide'
  assert test_glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:28.986880
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)

    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

    assert ie._real_extract(ie._TEST['url']) == ie._TEST

# Generated at 2022-06-26 12:03:36.638425
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test class constructor for GlideIE"""
    ie_obj = GlideIE()
    assert ie_obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie_obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:43.286060
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # If a GlideIE object is created by this constructor,
    # then after its being called, the '_VALID_URL' of its
    # instance must be equal '_VALID_URL' in the source file
    # of the GlideIE class.
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:03:45.417733
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test function for constructor of class GlideIE"""
    GlideIE(None, None)

# Generated at 2022-06-26 12:03:46.269475
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:03:48.457765
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE({})._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-26 12:04:17.068174
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test instantiation
    GlideIE()

# Generated at 2022-06-26 12:04:20.560544
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE('glide')

# Generated at 2022-06-26 12:04:21.224677
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:31.035583
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test function for GlideIE constructor

    Parameters:
        None

    Returns:
        Nothing

    Raises:
        Nothing

    """

    # Test constructor
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'www\.glide\.me/\w+'


# Generated at 2022-06-26 12:04:32.223413
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide != None
    

# Generated at 2022-06-26 12:04:32.903673
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:33.628603
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:04:35.157616
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE


# Generated at 2022-06-26 12:04:38.513451
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:04:43.765802
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	print(ie)
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-26 12:05:59.104291
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    if ie is None or str(type(ie)) != "<class 'youtube_dl.extractor.glide.GlideIE'>":
        raise Exception("Problem with constructor GlideIE")

# Generated at 2022-06-26 12:06:04.408545
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Testing constructor with empty argument
    try:
        ie = GlideIE()
    except Exception as e:
        assert e.args[0] == "Expected URL argument"


# Generated at 2022-06-26 12:06:12.300029
# Unit test for constructor of class GlideIE
def test_GlideIE():
	import sys
	import hashlib
	sys.path.append('../../..')
	from youtube_dl.utils import *
	from youtube_dl.extractor import *
	url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	result = {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4',
	    'title': u"Damon's Glide message",
	    'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
	}
	ie = GlideIE()
	assert_equal(result,ie.extract(url))

# Generated at 2022-06-26 12:06:22.208808
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:06:24.690955
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    #Test the object constructor for class GlideIE
    GlideIE_object = GlideIE(url)
    #Test that the class object was initialized properly
    assert GlideIE_object.url == url
    assert GlideIE_object.ie_key() == 'Glide'

# Generated at 2022-06-26 12:06:27.838636
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-26 12:06:31.392603
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import GlideIE
    ie = GlideIE()
    assert ie != None

# Generated at 2022-06-26 12:06:34.180580
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()

# Generated at 2022-06-26 12:06:41.870984
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Contructor of GlideIE tests"""
    # There should exist test data in the following format
    # {
    #   'additional_info' : {},
    #   'url': '',
    #   'note': '',
    #   'playlist': False/True,
    # }
    # You can also put some additional information in 'additional_info'
    # if you need in your test.
    # Noted that the test data should be placed in the same folder
    # as the class which is being tested and the filename should be
    # classname_test.json
    # Currently, this test is the same as test_InfoExtractor
    return test_InfoExtractor(GlideIE, [])

# Generated at 2022-06-26 12:06:52.063173
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
     Test for class GlideIE
    """
    #URL to test on
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glideInstance = GlideIE()
    assert glideInstance._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)", "Valid Url is not as expected"
    assert glideInstance.IE_DESC == "Glide mobile video messages (glide.me)", "IE Description is not as expected"
    assert glideInstance.IE_NAME == "Glide", "IE Name is not as expected"
    assert glideInstance._TEST["url"] == url, "Test url is not as expected"

# Generated at 2022-06-26 12:09:42.816995
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:09:43.258108
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:09:49.131547
# Unit test for constructor of class GlideIE
def test_GlideIE():
	info_extractor = GlideIE('Glide')
	assert info_extractor.IE_NAME == 'Glide'
	assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-26 12:09:50.261244
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-26 12:09:53.855131
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-26 12:09:58.524007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-26 12:10:06.880700
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE('test')
    assert e.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert e.IE_NAME == 'glide'
    assert e._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

test_GlideIE()