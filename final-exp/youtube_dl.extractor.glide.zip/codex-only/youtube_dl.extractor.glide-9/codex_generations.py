

# Generated at 2022-06-24 12:26:45.988401
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.Object.__name__ == 'GlideIE'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:26:56.698264
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Just to be sure that it is loading the class."""
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.__class__ == GlideIE
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL  == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:26:57.321066
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-24 12:27:00.630357
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:01.613817
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE()


# Generated at 2022-06-24 12:27:04.709673
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide mobile video messages'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:27:08.653360
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, GlideIE)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.VALID_URL == 'glide.me'


# Generated at 2022-06-24 12:27:18.975496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Create an object of the class to be tested
    glide_test = GlideIE()

    #Check the type of object created
    assert type(glide_test) is GlideIE

    # Check the value of the attributes of the object created
    # Test that object was not created with deault values
    assert glide_test.ie_key != InfoExtractor.ie_key
    assert glide_test.ie_desc != InfoExtractor.ie_desc
    assert glide_test.extractor_key != InfoExtractor.extractor_key
    assert glide_test.suitest_result != InfoExtractor.suitest_result
    assert glide_test.webpage_url != InfoExtractor.webpage_url
    assert glide_test.webpage_bytes != InfoExtractor.webpage_bytes

# Generated at 2022-06-24 12:27:25.569789
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Check that a default GlideIE object is created
    try:
        glide_ie = GlideIE()
    except Exception as exc:
        print("Error: could not create GlideIE")
        raise exc

    # Check GlideIE.extract() method
    try:
        glide_ie.extract(_TEST['url'])
    except Exception as exc:
        print("Error: could not extract video from Glide")
        raise exc

if __name__ == '__main__':
    # Unit test GlideIE class
    test_GlideIE()

# Generated at 2022-06-24 12:27:26.435255
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE



# Generated at 2022-06-24 12:27:28.878958
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:31.585755
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Constructor of class GlideIE should return an object of class GlideIE
	ie = GlideIE()
	assert type(ie) == GlideIE


# Generated at 2022-06-24 12:27:34.095384
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==','','','','','','','','','','','')

# Generated at 2022-06-24 12:27:42.144540
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)', "GlideIE.IE_DESC value incorrect"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', "GlideIE._VALID_URL value incorrect"

# Generated at 2022-06-24 12:27:45.469287
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:46.438035
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:49.067726
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create an instance of class GlideIE
    ie = GlideIE()

    # Check whether it is an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:27:51.897919
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:27:53.103722
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert not GlideIE() == None

# Generated at 2022-06-24 12:27:55.722577
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')



# Generated at 2022-06-24 12:27:56.770355
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:28:06.645238
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie=GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:17.021103
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:19.081950
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Test class GlideIE """

    # GlideIE inherits from InfoExtractor.
    assert issubclass(GlideIE, InfoExtractor)

# Generated at 2022-06-24 12:28:20.210163
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glides = GlideIE()


# Generated at 2022-06-24 12:28:23.224942
# Unit test for constructor of class GlideIE
def test_GlideIE():
  #glide = GlideIE(InfoExtractor())
  glide = GlideIE()
  assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
  assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-24 12:28:23.793190
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:24.383576
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:25.010475
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:27.518980
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract(str)

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:28:32.769530
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
        GlideIE()._real_extract(url)
        print("The constructor of class GlideIE worked properly.")
    except Exception:
        print("The constructor of class GlideIE failed.")
        return False
    return True


# Generated at 2022-06-24 12:28:33.386913
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie != None

# Generated at 2022-06-24 12:28:41.384453
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create and instance of class GlideIE
    inst = GlideIE()
    
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Download the webpage from the given url
    webpage = inst._download_webpage(url, 'UZF8zlmuQbe4mr+7dCiQ0w==')

    # Test the title regex pattern
    title_pattern = inst._html_search_regex(r'<title>(.+?)</title>', webpage, 'title', default=None)

    assert title_pattern != None
    # Test the video url regex pattern

# Generated at 2022-06-24 12:28:42.214933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()


# Generated at 2022-06-24 12:28:44.367629
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testobj = GlideIE()
    assert testobj != None
    print('Test passed')


# Generated at 2022-06-24 12:28:46.025229
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance_of_class = GlideIE()
    
    assert isinstance(instance_of_class, GlideIE)

# Generated at 2022-06-24 12:28:46.610621
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:48.247878
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_class = GlideIE()
    assert test_class.IE_NAME.lower() == 'glide.me'

# Generated at 2022-06-24 12:28:48.824539
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE()

# Generated at 2022-06-24 12:28:49.680068
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-24 12:28:55.701718
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    if ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)':
        print ('Test of GlideIE constructor is passed')
    else:
        print ('Test of GlideIE constructor is failed')

# Generated at 2022-06-24 12:28:58.014299
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:29:09.419248
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.file_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.title == 'Damon\'s Glide message'

# Generated at 2022-06-24 12:29:10.397119
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-24 12:29:13.456546
# Unit test for constructor of class GlideIE
def test_GlideIE():
  x = GlideIE()
  if not x==None:
    print('[+] Unit test for GlideIE passed!!')
  else:
    print('[-] Unit test for GlideIE failed!!')


# Generated at 2022-06-24 12:29:16.712615
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE.test_GlideIE()

# Generated at 2022-06-24 12:29:20.454818
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test instantiation of object
    GlideIE(GlideIE._VALID_URL)

# test method _real_extract of class GlideIE

# Generated at 2022-06-24 12:29:28.518169
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    g = GlideIE()
    assert g._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:31.547146
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit-test for GlideIE
    """
    ie = GlideIE()
    assert ie.IE_DESC
    assert ie._VALID_URL

# Generated at 2022-06-24 12:29:32.298543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:29:38.366287
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert test.IE_NAME == 'Glide'
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-24 12:29:43.274076
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'glide'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:29:47.400387
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiation test
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:29:48.440996
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert True == ie._print_info()

# Generated at 2022-06-24 12:29:51.279832
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gIE = GlideIE()
    assert_equals(gIE.IE_DESC, 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:29:57.620244
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.ie_key() == 'Glide', "Failed to retrieve the key of the Glide class"
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)', \
        "Failed to retrieve the description of the Glide class"


# Generated at 2022-06-24 12:30:04.875911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #test general instance creation
    ie = GlideIE()

    #test URL regex
    ie._VALID_URL = r'(?:https?://|)share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    m = ie._match_id('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert m == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    m = ie._match_id('share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert m == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    m = ie

# Generated at 2022-06-24 12:30:13.696281
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    info_dict = ie._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert info_dict["title"] == "Damon's Glide message"
    assert info_dict["id"] == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert len(info_dict["thumbnail"]) > 0
    assert info_dict["ext"] == "mp4"
    assert len(info_dict["url"]) > 0

# Generated at 2022-06-24 12:30:14.342325
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 1 == 1

# Generated at 2022-06-24 12:30:16.432623
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-24 12:30:26.039167
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC ==  'Glide mobile video messages (glide.me)'
    assert ie.validate_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == True
    assert ie.validate_url("https://share.glide.me/") == False
    assert ie.validate_url("http://www.youtube.com/watch?v=BaW_jenozKc") == False
    assert ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") is not None


# Generated at 2022-06-24 12:30:28.431219
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor test
    try:
        ie = GlideIE()
        assert ie is not None
    except:
        assert False

# Test for method _real_extract of class GlideIE

# Generated at 2022-06-24 12:30:30.707940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('glide.me')
    assert(str(ie) == "<class 'youtube_dl.extractor.glide.GlideIE'>")

# Generated at 2022-06-24 12:30:39.304590
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Test getters
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.get_id() == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.get_url() == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Test getters

# Generated at 2022-06-24 12:30:40.061176
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:41.222697
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, InfoExtractor)

# Generated at 2022-06-24 12:30:49.419855
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE._downloader)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    info_dict = ie._TEST['info_dict']
    assert info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:30:49.895341
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:00.621375
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:02.470615
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert 'glide.me' in obj.IE_NAME

# Generated at 2022-06-24 12:31:03.757328
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).IE_NAME == 'GlideIE'

# Generated at 2022-06-24 12:31:09.653651
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not ie.suitable('http://share.glide.me/')

# Generated at 2022-06-24 12:31:11.940147
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE()
    video._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    pass

# Generated at 2022-06-24 12:31:15.564263
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:16.499401
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    print("\nUnit test of GlideIE constructor complete!")

# Generated at 2022-06-24 12:31:18.739063
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.IE_DESC)


# Generated at 2022-06-24 12:31:28.598731
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    The following unit test tests the constructor of GlideIE.
    """

# Generated at 2022-06-24 12:31:29.744619
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:34.652768
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r"https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:31:36.659995
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url= 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()
    ie.extract(url)

# Generated at 2022-06-24 12:31:38.201637
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create object of class GlideIE
    glide = GlideIE()
    assert(glide.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:31:41.622125
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:31:44.661307
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:31:48.091184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test case for testing constructor of class GlideIE
    """
    test_obj = GlideIE
    assert isinstance(test_obj, object)


# Generated at 2022-06-24 12:31:57.653942
# Unit test for constructor of class GlideIE
def test_GlideIE(): 
    format1 = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==","")
    #test for constructor
    if format1 == None: 
        print("test_GlideIE: constructor test passed")

    format2 = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7daa","")
    #test for constructor
    if format2 == None: 
        print("test_GlideIE: constructor test failed")


# # Unit test for constructor of class GlideIE
# def test_classGlideIE(): 
#     format1 = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==","")
#     #

# Generated at 2022-06-24 12:32:04.936167
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    # Test matching
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr')

    # Test not matching
    assert not ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr/')
    assert not ie.suitable('https://share.glide.me/UZF8zlmuQbe4mr/')

# Generated at 2022-06-24 12:32:06.080139
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), GlideIE)


# Generated at 2022-06-24 12:32:14.021519
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from tutorial import xmodule_runtime  # pylint: disable=import-error

    # This is for testing only
    # this function is not in the class definition
    def setUp():
        runtime = xmodule_runtime.XModuleRuntime()
        field_data = DictFieldData({'data': '{}'})
        scope_ids = ScopeIds('user', block_type='library_content', def_id='content')
        return runtime, field_data, scope_ids

    runtime, field_data, scope_ids = setUp()

    # Create an instance of GlideIE
    glide_ie = GlideIE (runtime, field_data, scope_ids)
    assert glide_ie is not None

# Generated at 2022-06-24 12:32:15.968827
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = ie._VALID_URL

# Generated at 2022-06-24 12:32:22.109078
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE(None)
    e.IE_DESC = 'Test'
    e._TEST = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

    class Dict(dict):
        def __init__(self):
            self

# Generated at 2022-06-24 12:32:29.320575
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie != None

    # Test for extract_id is not necessary because URL is not
    # canonicalized.

    # Test for _VALID_URL is not necessary because of the
    # implementation of _VALID_URL and _match_id.

    # Test for _TEST is not necessary because of the implementation
    # of _TEST

    # Test for _real_extract is not necessary because of the
    # implementation of _real_extract

# Generated at 2022-06-24 12:32:38.751812
# Unit test for constructor of class GlideIE
def test_GlideIE():
    params = {

    }
    extractor = GlideIE()
    assert_equal(extractor._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:32:47.040593
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_video = GlideIE()
    assert test_video.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_video._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test_video._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert test_video._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:32:47.556057
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:58.712786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global glideIE
    c = GlideIE(None)
    print("c.IE_DESC ="+ c.IE_DESC)
    assert c.IE_DESC == 'Glide mobile video messages (glide.me)'
    print("c._VALID_URL = "+ c._VALID_URL)
    assert c._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    print("c._TEST =")
    print(c._TEST)
    #assert c._TEST == 
    if(c._TEST == None):
        print("c._TEST is None")
    else:
        print("c._TEST is not None")

# Generated at 2022-06-24 12:33:01.124613
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert isinstance(instance._TEST, dict) == True

# Generated at 2022-06-24 12:33:01.819818
# Unit test for constructor of class GlideIE
def test_GlideIE():
	#Constructor of class GlideIE
	GlideIE(None)
	

# Generated at 2022-06-24 12:33:03.340173
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:13.900094
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("Testing constructor of GlideIE")
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST.get('url') == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST.get('md5') == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:33:22.538730
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Unit tests for methods

# Generated at 2022-06-24 12:33:26.176816
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE([])
    # Test the properties of an instantiated object
    assert obj._VALID_URL == GlideIE._VALID_URL
    assert obj.IE_DESC == "Glide mobile video messages (glide.me)"



# Generated at 2022-06-24 12:33:27.832978
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:33:35.525533
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Simple unit test for class GlideIE
    """

    # This URL will download a video at:
    # http://d2p9i9f7mzm1wm.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/7bfa09e0-a715-11e3-a7f0-09fde98d6ef0/6c351e70-a715-11e3-a7f0-09fde98d6ef0/720p.mp4
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    # Let's create a GlideIE object with this url
    glide_ie_obj = GlideIE(url)

    # Let's

# Generated at 2022-06-24 12:33:38.022892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert(ie.IE_DESC=="Glide mobile video messages (glide.me)")


# Generated at 2022-06-24 12:33:40.151207
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:42.781152
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.get_max_bitrate() is None


# Generated at 2022-06-24 12:33:49.926753
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie._real_extract('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie._real_extract('http://share.glide.me/0m0j7G9XJ6U+7TN0ti-kUw==')
    ie._real_extract('https://share.glide.me/0m0j7G9XJ6U+7TN0ti-kUw==')

# Generated at 2022-06-24 12:33:51.158475
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._real_initialize()

# Generated at 2022-06-24 12:33:51.937805
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())._TEST

# Generated at 2022-06-24 12:33:58.917773
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.initialize()

    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == url

    info_dict = ie._TEST['info_dict']
    assert info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info_dict['ext'] == 'mp4'

# Generated at 2022-06-24 12:33:59.971061
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    return test

# Generated at 2022-06-24 12:34:00.551131
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:01.800458
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST['url'] == GlideIE._VALID_URL

# Generated at 2022-06-24 12:34:02.353500
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:10.420676
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Non compliant URL
    url = "http://glide.me/amsterdam/yogamsterdam/videos/1051389"
    try:
        GlideIE(url)
    except Exception as e:
        assert type(e) == ValueError

    # Valid URL
    url = "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glide = GlideIE(url)
    assert glide.ie_key() == "Glide"
    assert glide.IE_DESC == "Glide mobile video messages (glide.me)"
    assert glide.VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-24 12:34:15.330823
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    glide_ie._download_webpage("http://share.glide.me/CYoxJzKqsW8XvZzAEWtjmw==", "CYoxJzKqsW8XvZzAEWtjmw==")
    glide_ie._match_id("http://share.glide.me/CYoxJzKqsW8XvZzAEWtjmw==")
    glide_ie._real_extract("http://share.glide.me/CYoxJzKqsW8XvZzAEWtjmw==")

# Generated at 2022-06-24 12:34:16.779353
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide = GlideIE()


# Generated at 2022-06-24 12:34:24.359827
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:35.061073
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:36.436662
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == "Glide"

# Generated at 2022-06-24 12:34:37.154811
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:38.901680
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # execute code in "init" function (__init__)
    # of the class
    GlideIE()


# Generated at 2022-06-24 12:34:42.017119
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('GlideIE').IE_DESC == GlideIE.IE_DESC

# Generated at 2022-06-24 12:34:42.937918
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:43.531703
# Unit test for constructor of class GlideIE
def test_GlideIE():
     assert GlideIE()

# Generated at 2022-06-24 12:34:48.065080
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE('http://share.glide.ch/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:57.020875
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert extractor._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert extractor._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert extractor._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert extractor._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:34:57.477339
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:00.613578
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.ie_key() is 'Glide'
    assert ie.ie_desc() is 'Glide mobile video messages'

# Generated at 2022-06-24 12:35:04.498737
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Arrange
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    Glide_ie = GlideIE()

    # Act
    Glide_ie._real_extract(url)

    # Assert
    assert True

# Generated at 2022-06-24 12:35:06.220921
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    GlideIE(InfoExtractor)


# Generated at 2022-06-24 12:35:17.221185
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:21.706011
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable("") == False
    assert GlideIE.suitable("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == True
    assert GlideIE.suitable("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == True


# Generated at 2022-06-24 12:35:23.511531
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:35:25.648487
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from __main__ import GlideIE
    ie = GlideIE()

# Generated at 2022-06-24 12:35:36.718499
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test constructor
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    info_dict = glide._TEST['info_dict']
    assert info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
   

# Generated at 2022-06-24 12:35:39.542242
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Check if class successfully created
    assert GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') is not None

# Generated at 2022-06-24 12:35:41.192192
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME =="GlideIE"

# Generated at 2022-06-24 12:35:44.886940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


#Unit test for _real_extract of class GlideIE

# Generated at 2022-06-24 12:35:46.689654
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:35:47.952240
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._real_extract(GlideIE._TEST['url'])

# Generated at 2022-06-24 12:35:50.032288
# Unit test for constructor of class GlideIE
def test_GlideIE():
    _GlideIE = GlideIE()


# Generated at 2022-06-24 12:35:59.040664
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_details = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

    test_object = GlideIE()

    test_object._download_webpage(\
        test_details['url'], test_details['id'])


# Generated at 2022-06-24 12:36:00.361689
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE

# Generated at 2022-06-24 12:36:01.594177
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(data.info_extractor_common__downloader)

# Generated at 2022-06-24 12:36:03.141165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:36:04.943771
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert glideIE is not None
    assert glideIE.IE_DESC is not None



# Generated at 2022-06-24 12:36:05.803875
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:36:08.189247
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:36:14.513199
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:18.516674
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE._match_id('UZF8zlmuQbe4mr+7dCiQ0w==') ==
            'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE._match_id('not-a-glide-url') is None

# Generated at 2022-06-24 12:36:22.592408
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Testing constructor of class GlideIE
    t = GlideIE()
    assert(t.IE_NAME is not None)
    assert(t.IE_DESC is not None)
    assert(t._VALID_URL is not None)
    assert(t._TEST is not None)


# Generated at 2022-06-24 12:36:23.236765
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:36:24.827437
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.ie_key() == 'Glide')

# Generated at 2022-06-24 12:36:28.240335
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        import glide_dl
    except ImportError:
        try:
            import glide_dl
        except:
            raise("pycryptodome is required")
    assert(GlideIE("https://share.glide.me/"))


# Generated at 2022-06-24 12:36:31.256333
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.ie_key() == 'Glide'

# Generated at 2022-06-24 12:36:33.610208
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:36:42.926997
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Run this test to get the unit test report
    """
    obj = GlideIE()
    assert obj.IE_NAME == 'Glide'
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'