

# Generated at 2022-06-24 12:26:51.434357
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_dict = { 'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': { 'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$'}}
    glide = GlideIE(test_dict)

# Generated at 2022-06-24 12:26:53.757870
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert g.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:26:56.727676
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test the constructor of the class
    obj = GlideIE(GlideIE.IE_DESC, GlideIE._VALID_URL)
    # Check for the JSON data, which is expected in this case
    assert obj.json is not None
    # Check for the video URL
    assert obj.video_url is not None
    # Check for the title
    assert obj.title is not None

# Generated at 2022-06-24 12:27:08.070101
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://(?:www\.)?share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:18.227513
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)

    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)', "Test IE_DESC"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', "Test VALID_URL"

# Generated at 2022-06-24 12:27:18.707907
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:20.501408
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', {})


# Generated at 2022-06-24 12:27:30.263458
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # The GlideIE constructor is called with parameters
    # (GlideIE, bool, unicode). The following is the workaround
    # to instantiate the class by calling the constructor of
    # super class InfoExtractor (a workaround for python 2.x).
    # ref. https://stackoverflow.com/a/11762437
    ie = InfoExtractor.__new__(GlideIE)
    ie.initialize()

    # assert nothing raises
    GlideIE({'test_suitable': False})
    GlideIE({'test_suitable': True})

    # assert nothing raises
    GlideIE({'test_suitable': False}).suitable('')
    GlideIE({'test_suitable': True}).suitable('')

    # assert that expected method is called

# Generated at 2022-06-24 12:27:39.775825
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_Glide = GlideIE()
    test_Glide = ie_Glide._TEST

# Generated at 2022-06-24 12:27:41.114662
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:27:45.091802
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == GlideIE._VALID_URL
    assert GlideIE(None).IE_DESC == GlideIE._IE_DESC
    assert GlideIE(None)._TEST == GlideIE._TEST

# Generated at 2022-06-24 12:27:47.950663
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._real_extract(url)
    assert True

# Generated at 2022-06-24 12:27:51.574217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Make sure that all methods can be called
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:02.439800
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE({})
    assert i.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:10.290367
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:28:16.554558
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    assert ie._match_id('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._match_id('http://share.glide.me/2s-McTZ_SfWEU6SgU6OWoQ==') == '2s-McTZ_SfWEU6SgU6OWoQ=='
    assert ie._match_id('https://share.glide.me/R1Mv+JpsQDWQ2nh8BkW9qA==') == 'R1Mv+JpsQDWQ2nh8BkW9qA=='
    assert ie._match

# Generated at 2022-06-24 12:28:17.081595
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:28:18.429322
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).IE_NAME == 'glide'

# Generated at 2022-06-24 12:28:25.441272
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(i, InfoExtractor)
    assert i.IE_DESC == GlideIE.IE_DESC
    assert i._VALID_URL == GlideIE._VALID_URL
    assert i._TEST == GlideIE._TEST
    assert i._download_webpage.__name__ == 'GlideIE._download_webpage'
    assert hasattr(i, '_real_extract')

# Generated at 2022-06-24 12:28:25.739811
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:27.475487
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:28:29.325948
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE({})
    assert GlideIE({'ie': 'Glide'})


# Generated at 2022-06-24 12:28:38.034760
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glidetest = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

    glide_ie = GlideIE()

    assert glide_ie.ie_key() == 'Glide'

# Generated at 2022-06-24 12:28:39.563941
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:28:40.071380
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:46.246823
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_NAME = 'glide'
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie.IE_PATTERN = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    ie.http_headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'}


if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:28:51.075906
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE()
    e._download_webpage = lambda url1, url2: '<title>Glide Video</title><source src="http://example.com/video.mp4" />'
    assert e._real_extract('http://www.example.com') == {'id': 'http://www.example.com', 'title': 'Glide Video', 'url': 'http://example.com/video.mp4'}

# Generated at 2022-06-24 12:29:01.125858
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-24 12:29:06.719334
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gl = GlideIE()
    assert gl._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert gl.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:11.460718
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for a valid url
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:29:23.281874
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == "Glide mobile video messages (glide.me)"
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert obj._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['info_dict']['ext']

# Generated at 2022-06-24 12:29:25.455064
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE._downloader, {})
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:29:35.208409
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert (ie.get_video_url() == 'http://v3.glidedata.com/media/UZF8zlmuQbe4mr+7dCiQ0w==.mp4')
    assert (ie.get_video_thumbnail_img() == 'http://d2jwvk8jmb4nm4.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==-U6BpFhdJG7jCudbZuN7ZnQ/5471758_512x512_v2.jpg')
    assert (ie.get_video_title() == "Damon's Glide message")

# Generated at 2022-06-24 12:29:37.753315
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    GlideIE = 'test'
    import ytdl_glide
    ytdl_glide.GlideIE

# Generated at 2022-06-24 12:29:38.596038
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert isinstance(instance, GlideIE) == True


# Generated at 2022-06-24 12:29:48.002393
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor = GlideIE
    test_url = 'https://share.glide.me/VDpPb8moQhG6bK_83X1X9A=='
    instance = constructor(test_url)
    assert instance.url == test_url
    assert instance.IE_KEY == 'Glide'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance.VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert instance.BASE_URL == 'http://share.glide.me'
    assert instance.check_proto == True
    assert instance.check_valid_url == False

# Generated at 2022-06-24 12:29:48.769751
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-24 12:29:51.686116
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:53.175479
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	assert obj.IE_NAME == 'glide'

# Generated at 2022-06-24 12:30:02.760191
# Unit test for constructor of class GlideIE
def test_GlideIE():
    tests = [
        {
            'input': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'title': "Damon's Glide message",
            'thumbnail': r'http://.*?\.cloudfront\.net/.*\.jpg',
        },
        {
            'input': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w',
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w',
            'title': '',
            'thumbnail': None,
        },
    ]
    for test in tests:
        print

# Generated at 2022-06-24 12:30:09.932798
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:30:12.736846
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.extract()

test_GlideIE()

# Generated at 2022-06-24 12:30:14.090208
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie == GlideIE

# Unit test

# Generated at 2022-06-24 12:30:16.518898
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE().extract_info_from_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:30:27.204750
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("https://share.glide.me/", {})
    assert GlideIE("http://share.glide.me/", {})
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", {})
    assert GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", {})
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", {})
    assert not GlideIE("http://share.glide.me/UZF8z#lmuQbe4mr+7dCiQ0w==", {})
    assert not GlideIE

# Generated at 2022-06-24 12:30:30.421603
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #print('Testing class GlideIE')
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE().extract(url)
    #print('Test Passed!')

# Generated at 2022-06-24 12:30:31.762760
# Unit test for constructor of class GlideIE
def test_GlideIE():
	print("unit test for constructor")
	g = GlideIE()


# Generated at 2022-06-24 12:30:33.057400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME in GlideIE.gen_extractors()

# Generated at 2022-06-24 12:30:41.180382
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Set up a DummyExtractor to be used in GlideIE
    import re
    import codecs
    from .common import DummyExtractor
    from .common import ExtractorError
    from .common import SearchInfoExtractor
    from .common import UnsupportedUrlError

    class DummyIE(DummyExtractor):
        """Dummy extractor for GlideIE unit test"""
        _VALID_URL = r'(?i)http://.*'

# Generated at 2022-06-24 12:30:49.382734
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Unit test for constructor of class GlideIE.
    '''
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:52.516976
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test constructor of class GlideIE
    """
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    GlideIE(url)
    

# Generated at 2022-06-24 12:30:55.835525
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE('http://www.glide.me', 'Glide mobile video messages (glide.me)')
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:07.371357
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC=='Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL==r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url']=='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5']=='4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id']=='UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:31:11.349907
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract( 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==' )
    ie.extract( 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==' )

# Generated at 2022-06-24 12:31:14.993961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        assert(GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==').extract() is not None)
        print("GlideIE constructor is working fine.")
    except Exception as e:
        print("GlideIE constructor is not working properly: %s" % (str(e)))


# Generated at 2022-06-24 12:31:26.174747
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == 'glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:28.937118
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==';
    GlideIE()._real_extract(url)
    GlideIE().suitable(url)

# Generated at 2022-06-24 12:31:32.843205
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:31:34.918931
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:31:38.625546
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_NAME == 'glide.me'
    assert glide.IE_DESC == GlideIE.IE_DESC
    assert glide._VALID_URL == GlideIE._VALID_URL
    assert glide._TEST == GlideIE._TEST

# Generated at 2022-06-24 12:31:41.994279
# Unit test for constructor of class GlideIE
def test_GlideIE():
	url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
	obj = GlideIE(url)
	assert isinstance(obj, GlideIE)

# Generated at 2022-06-24 12:31:45.362073
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    assert GlideIE().IE_DESC == GlideIE._IE_DESC

# Generated at 2022-06-24 12:31:46.764971
# Unit test for constructor of class GlideIE
def test_GlideIE():
    _ = GlideIE()

# Generated at 2022-06-24 12:31:49.323531
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == GlideIE

# Generated at 2022-06-24 12:31:50.108024
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert("GlideIE" == GlideIE({}, {})._TYPE)

# Generated at 2022-06-24 12:31:52.412888
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .test_common import TestCommon

    ie = TestCommon.construct_IE('Glide')

    assert isinstance(ie, GlideIE)

# Generated at 2022-06-24 12:32:03.171734
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # mock an instance of GlideIE for testing
    GlideIE_test = GlideIE('test', {})
    assert GlideIE_test._VALID_URL == GlideIE._VALID_URL,\
        'Regular expression error: the _VALID_URL should be %s.' % GlideIE._VALID_URL
    assert GlideIE_test._TEST == GlideIE._TEST,\
        'Regular expression error: the _TEST should be %s.' % GlideIE._TEST
    assert GlideIE_test._download_webpage(url, 'UZF8zlmuQbe4mr+7dCiQ0w==') == GlideIE._download_

# Generated at 2022-06-24 12:32:06.442254
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # assert GlideIE.__name__ == 'GlideIE'
    # assert GlideIE.ie_key() == 'Glide'
    # assert GlideIE.ie_key() == 'glide'
    assert GlideIE.ie_key() == 'Glide'

# Generated at 2022-06-24 12:32:07.768968
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    test = GlideIE()

# Generated at 2022-06-24 12:32:16.430891
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:32:18.367093
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:32:20.084572
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:32:25.343269
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._match_id("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie._real_extract("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:32:32.127701
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:32:35.680360
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor(GlideIE.ie_key())
    ie.extract('http://share.glide.me/q3cmn6lwQ+iRJmE0F6+DRg==')
    assert ie is not None

# Generated at 2022-06-24 12:32:37.209642
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE(None)._VALID_URL == GlideIE._VALID_URL)

# Generated at 2022-06-24 12:32:39.144590
# Unit test for constructor of class GlideIE
def test_GlideIE():
    c = GlideIE()
    c.IE_DESC
    c._VALID_URL
    c._TEST

# Generated at 2022-06-24 12:32:47.405953
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test when url is http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==
    glideIE = GlideIE()
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)' 

# Generated at 2022-06-24 12:32:50.549998
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert isinstance(GlideIE, InfoExtractor)
    glide_ie = GlideIE(url)
    assert isinstance(glide_ie, InfoExtractor)
    assert glide_ie.url == url



# Generated at 2022-06-24 12:33:01.756778
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('Not used')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:06.327381
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie.valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:33:17.290846
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE_constructor_test_result = GlideIE()
    assert GlideIE_constructor_test_result.IE_NAME == 'Glide'
    assert GlideIE_constructor_test_result.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE_constructor_test_result._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:21.653185
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests GlideIE.__init__() with correct URL argument
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Tests GlideIE.__init__() with URL argument which is invalid
    assert GlideIE('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-24 12:33:22.248433
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()

# Generated at 2022-06-24 12:33:31.721527
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_NAME == '{0}.{1}'.format("glide", "GlideIE"))
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:33:32.391220
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE

# Generated at 2022-06-24 12:33:37.565727
# Unit test for constructor of class GlideIE
def test_GlideIE():
	print(GlideIE._TEST['url'])
	# url = GlideIE._TEST['url']
	# g = GlideIE(url)
	# print("g",g)
	# video_id = g._match_id(url)
	# print("video_id",video_id)

test_GlideIE()

# Generated at 2022-06-24 12:33:43.233991
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Description:    Unit test for class GlideIE
    """
    glideIE = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    from pprint import pprint
    pprint(glideIE._real_extract(glideIE.url))

# Generated at 2022-06-24 12:33:48.781579
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glide.name == 'GlideIE'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:58.359340
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert(g.IE_DESC == 'Glide mobile video messages (glide.me)'
    )
    assert(g._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(g._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(g._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
    assert(g._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:00.459325
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    inst.suite()
    assert inst


if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:34:08.972545
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_ = GlideIE()
    expected_video_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    expected_video_url = "http://d2q3q3i48jh0zi.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/0.mp4"
    expected_thumbnail = "http://d2q3q3i48jh0zi.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/0_thumb.jpg"
    expected_title = "Damon's Glide message"
    expected_webpage = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

   

# Generated at 2022-06-24 12:34:09.888184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:10.764176
# Unit test for constructor of class GlideIE
def test_GlideIE():
    I_E_Object = GlideIE()
    assert isinstance(I_E_Object, InfoExtractor)

# Generated at 2022-06-24 12:34:13.586603
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Get Glide video"""
    glide = GlideIE()
    glide.get_video('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:22.876821
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.id == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie.url == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie.title == "Damon's Glide message"
    assert ie.thumbnail == "https://d3q5qwv5e2jx8b.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/snapshot.jpg"

# Generated at 2022-06-24 12:34:33.386262
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert GlideIE.IE_NAME == 'glide'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:34:38.255213
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    return

# Generated at 2022-06-24 12:34:39.050807
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('glide')

# Generated at 2022-06-24 12:34:43.486814
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:51.762483
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This unit test is currently commented out because, when run
    outside of youtube-dl, it fails, yet it completes successfully
    when run as part of youtube-dl.  This is because the test
    function is the last function called and so the global
    _downloader = None statement in youtube-dl/__main__.py is
    called and the error message incorrectly appears to indicate
    that the unit test has failed.
    """
    #ie = GlideIE()
    #ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:52.306418
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:54.197838
# Unit test for constructor of class GlideIE
def test_GlideIE():
  '''constructor of class GlideIE'''
  ie = GlideIE()
  ie._match_id('test_url')

# Generated at 2022-06-24 12:34:55.832562
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(None)._VALID_URL, str)


# Generated at 2022-06-24 12:34:58.408387
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_NAME == 'glide:glide')
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')


# Generated at 2022-06-24 12:35:02.912214
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:35:09.774961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == "Glide"
    assert instance.IE_DESC == "Glide mobile video messages"
    assert instance._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert instance._TEST["url"] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert instance._TEST["md5"] == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-24 12:35:19.644687
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert True
# # A test for retrieving video url as well as title of the video
# def test_extract_GlideIE():
# 	GlideIE = main()
# 	TestGlideIE = GlideIE.GlideIE({
# 		'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
# 	})
# 	# Testing the video url
# 	assert TestGlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
# 	# Testing the video title
# 	assert TestGlideIE.title == "Damon's Glide message"

# All the testing goes here
# if __name__ == "__main

# Generated at 2022-06-24 12:35:21.904166
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:35:28.525151
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:31.972640
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    

# Generated at 2022-06-24 12:35:34.616000
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:35:35.189793
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)


# Generated at 2022-06-24 12:35:39.954781
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/video/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not GlideIE.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-24 12:35:45.411743
# Unit test for constructor of class GlideIE
def test_GlideIE():
    data = {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='}
    GlideIE().set_info(data, data)
    assert '<GlideIE Glide mobile video messages (glide.me)>' == GlideIE().__str__()


# Generated at 2022-06-24 12:35:46.552520
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-24 12:35:53.240374
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.__name__ == 'GlideIE'
    assert GlideIE.__doc__ == 'Glide mobile video messages (glide.me)'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:35:57.085009
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url)
    assert True


# Generated at 2022-06-24 12:36:02.618539
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test construction of class GlideIE"""
    ie = GlideIE(InfoExtractor())
    assert ie.IE_NAME == 'glide'

    # Test valid URL
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    # Test invalid URL
    ie.extract('http://share.glide.me/')

# Generated at 2022-06-24 12:36:03.779511
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:36:07.193380
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'^https?://share.glide.me/[A-Za-z0-9\-=_+]+$'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-24 12:36:09.753399
# Unit test for constructor of class GlideIE
def test_GlideIE():
    exp = GlideIE()
    assert (exp.IE_NAME == GlideIE.IE_NAME and
            exp.IE_DESC == GlideIE.IE_DESC and
            exp._VALID_URL == GlideIE._VALID_URL)

# Generated at 2022-06-24 12:36:11.990392
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert str(ie) == "Glide Mobile Video Messages (glide.me)"

# Generated at 2022-06-24 12:36:13.144503
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()



# Generated at 2022-06-24 12:36:19.533228
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # example url from the first test in
    # https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/glide.py
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glideIE = GlideIE()
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:36:20.707715
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    assert test_GlideIE != None

# Generated at 2022-06-24 12:36:22.818043
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:36:28.700306
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Delete the glide in the current folder if it exists
    # to avoid test failure.
    glide = 'glide.me.py'
    if os.path.exists(glide):
        os.remove(glide)

    # Construct a GlideIE object
    obj = GlideIE()
    # Check if it's the instance of GlideIE
    assert isinstance(obj, GlideIE), 'It should be a GlideIE instance'
    # Check if the attribute _VALID_URL is set
    assert obj._VALID_URL is not None, 'The attribute _VALID_URL must be set'
    # Check if the attribute IE_NAME is set to 'glide'
    assert obj._VALID_URL is not None, 'The attribute IE_NAME must be set to \'glide\''
    # Check if the attribute IE_

# Generated at 2022-06-24 12:36:30.585825
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:40.991786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'