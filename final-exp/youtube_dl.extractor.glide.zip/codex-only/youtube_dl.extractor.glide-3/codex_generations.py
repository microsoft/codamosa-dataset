

# Generated at 2022-06-24 12:26:46.975576
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import GlideIE
    from youtube_dl.utils import ExtractorError
    from nose.tools import assert_raises
    from nose import tools # setattr works with tools
    from utils import fake_urlopen
    response = "response"
    url1 = "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    url2 = "https://share.glide.me/qwerty"
    GlideIE._download_webpage = fake_urlopen(response)
    GlideIE._search_regex = lambda self, pattern, string, name=None, default=None, fatal=True: ('video URL', 'url')

# Generated at 2022-06-24 12:26:48.350173
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:26:50.050890
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()

# Generated at 2022-06-24 12:26:51.226302
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:26:59.886988
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-24 12:27:10.052405
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:11.579973
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:27:20.606125
# Unit test for constructor of class GlideIE
def test_GlideIE():

	# Bad input arguments
	assert not GlideIE.suitable('http://www.dailymotion.com/video/x2xfs2_')
	assert not GlideIE.suitable('http://www.youtube.com/watch?v=_')
	assert not GlideIE.suitable('http://www.youtube.com/watch?v=y_')
	assert not GlideIE.suitable('http://www.youtube.com/watch?v=___')

	# Good input arguments
	assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	assert GlideIE.suitable('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

	# Create constructor

# Generated at 2022-06-24 12:27:22.626455
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    test_instantiation_with_class_only(ie)


# Generated at 2022-06-24 12:27:29.344889
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert isinstance(ie._TEST, dict)



# Generated at 2022-06-24 12:27:34.287630
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == "Glide"
    assert GlideIE().IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE()._VALID_URL == "^https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)$"

# Generated at 2022-06-24 12:27:35.225671
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:35.827178
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:36.710218
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://www.glide.me/")


# Generated at 2022-06-24 12:27:37.467342
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:27:40.784180
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert(str(glide) == "<class 'youtube_dl.extractor.glide.GlideIE'>")

# Generated at 2022-06-24 12:27:43.180914
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:27:51.688791
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    import sys
    import pprint
    pprint.pprint(ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="))
    # assert(ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == \
    #        {
    #     'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
    #     'thumbnail': 'https://glidemediacdn.glide.me/recording/UZF8zlmuQbe4mr+7dCiQ0w==/thumbnail.jpg',
    #     'title': "Damon's Glide message",
   

# Generated at 2022-06-24 12:27:54.660067
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # This will cause a failure if test_GlideIE is not a function
    assert ie._real_extract == GlideIE._real_extract

# Generated at 2022-06-24 12:28:04.552531
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract_id('http://go.glide.me/share?id=UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract_id('http://no.share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract_id('http://no.share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:07.442097
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 'https://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w-' == GlideIE._VALID_URL

# Generated at 2022-06-24 12:28:09.436034
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if not hasattr(GlideIE, '_call_api'):
        return
    te = GlideIE()
    assert te.IE_DESC

# Generated at 2022-06-24 12:28:12.522109
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert a._VALID_URL

# Generated at 2022-06-24 12:28:13.409942
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-24 12:28:23.523476
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None, None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:24.870346
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie


# Generated at 2022-06-24 12:28:27.692464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    pass

# Generated at 2022-06-24 12:28:29.545324
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE.
    """
    GlideIE()

# Generated at 2022-06-24 12:28:33.490174
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #given
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    #when
    glideIE = GlideIE(url)

    #then
    assert isinstance(glideIE, InfoExtractor)


# Generated at 2022-06-24 12:28:41.465149
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:42.344142
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert True

test_GlideIE()

# Generated at 2022-06-24 12:28:44.498374
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._download_webpage('abc', 'abc') # pylint: disable=protected-access

# Generated at 2022-06-24 12:28:45.793412
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie != None

# Generated at 2022-06-24 12:28:53.860508
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    # Test the values of some member variables
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', \
        '_VALID_URL is wrong'
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', \
        '_TEST is wrong'
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7', \
        '_TEST is wrong'

# Generated at 2022-06-24 12:29:00.304042
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        glide_ie = GlideIE(GlideIE._VALID_URL)
        assert glide_ie.IE_DESC == GlideIE.IE_DESC
        assert glide_ie.ie_key() == 'Glide'
    except Exception as err:
        print("ERROR:  GlideIE constructor failed with message %s\n" %str(err))
        raise err

# Unit test to extract video information from glide.me site, then download the video

# Generated at 2022-06-24 12:29:11.514843
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:14.939331
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Glide mobile video messages"""
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE().extract(url)

# Generated at 2022-06-24 12:29:25.757563
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    print("Unit testing on URL: http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # test run on URL
    glide_ie.run('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    #dict = glide_ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    #print("Unit testing of real_extract with URL: http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    #glide_ie._real_extract('http://share.glide.me

# Generated at 2022-06-24 12:29:35.382547
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert g._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert g._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert g._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert g._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:29:38.509306
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:41.996234
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE() # Create object
    assert(glide._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\\-=_+]+)')

# Generated at 2022-06-24 12:29:46.875419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class SubGlideIE(GlideIE):
        def __init__(self, *args, **kwargs):
            self.test_class_attr_is_fine = True
            super(SubGlideIE, self).__init__(*args, **kwargs)
    sub_glide_ie = SubGlideIE()
    assert sub_glide_ie.test_class_attr_is_fine

# Generated at 2022-06-24 12:29:49.143155
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # To test for the constructor of GlideIE
    # Constructor of GlideIE is tested by making an object of the class GlideIE
    # object is created for class GlideIE
    glideIE = GlideIE()

# Generated at 2022-06-24 12:29:56.736456
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if not GlideIE().suitable('share.glide.me'):
        print("The test case of GlideIE is not suitable")
    else:
        print("The test case of GlideIE is suitable")
    GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:30:01.885971
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE
    """
    # base case without params
    ie = GlideIE()

    # base case with params
    ie = GlideIE(params={})

    # base case with empty params
    ie = GlideIE(params={'test': 1, 'test2': None, 'test3': '', 'test4': True})

    return ie

# Generated at 2022-06-24 12:30:03.174363
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'

# Generated at 2022-06-24 12:30:10.169161
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide._TEST[0] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._TEST[1] == '4466372687352851af2d131cfaa8a4c7'
    assert glide._TEST[2]['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._TEST[2]['ext'] == 'mp4'


# Generated at 2022-06-24 12:30:11.481690
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for class GlideIE"""
    GlideIE()

# Generated at 2022-06-24 12:30:12.457554
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE
    

# Generated at 2022-06-24 12:30:14.560689
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:30:22.477243
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'


# Generated at 2022-06-24 12:30:23.896900
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:30:34.004917
# Unit test for constructor of class GlideIE
def test_GlideIE():
    sample_instantiation = GlideIE(None)
    assert sample_instantiation
    assert sample_instantiation._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert sample_instantiation.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:30:37.447549
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST
    assert ie._real_extract == GlideIE._real_extract

# Generated at 2022-06-24 12:30:38.716230
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-24 12:30:42.029572
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE._create_youtube_ie())._WORKING == True

#Unit test for _real_extract of class GlideIE

# Generated at 2022-06-24 12:30:50.096100
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj.IE_NAME == 'glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:00.911086
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE('glide', {}, GlideIE.IE_DESC)
    assert inst.name == 'glide'
    assert inst.ie_key() == 'glide'
    assert inst.ie_desc == GlideIE.IE_DESC
    assert inst.valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert inst.valid_url('http://www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == False
    assert inst.valid_url('http://share.glide.me/a')
    assert inst.valid_url('http://www.glide.me/a') == False

# Generated at 2022-06-24 12:31:04.155450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.constructor == GlideIE



# Generated at 2022-06-24 12:31:07.471298
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:09.888427
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==").IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:11.230648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:31:13.222204
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Initiate a GlideIE object
    ie = GlideIE()
    #assert GlideIE.name == "glide"
    assert ie.IE_NAME == "glide"

# Generated at 2022-06-24 12:31:14.785631
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:31:22.292013
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    GlideIE._download_webpage = lambda self, _, __: "<html><title>Hello World</title></html>"
    GlideIE._og_search_title = lambda self, _: "Hello World!"
    GlideIE._search_regex = lambda self, _, __, ___, ____, default: default
    GlideIE.suitable = lambda cls, url: False
    GlideIE.__init__(GlideIE, {})

# Generated at 2022-06-24 12:31:24.147589
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # constructor for class GlideIE
    assert isinstance(GlideIE("GlideIE"), object)

# Generated at 2022-06-24 12:31:25.872195
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test case: GlideIE is the constructor of class GlideIE
    assert GlideIE is InfoExtractor

# Generated at 2022-06-24 12:31:29.880861
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    # Test 1
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    test_dict = {'url': url}
    obj = GlideIE(InfoExtractor())
    res = obj._real_extract(url)
    assert res


# Generated at 2022-06-24 12:31:40.353211
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:43.825037
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE._VALID_URL == GlideIE.extract_info('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')['url'])

# Generated at 2022-06-24 12:31:52.628273
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE('mp4', 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'https://d1lz5w6trshd2f.cloudfront.net/video/static/blogs/2015/7/5/146211/261256637/video.mp4?version=1', 'http://d1lz5w6trshd2f.cloudfront.net/video/static/blogs/2015/7/5/146211/261238208/thumbnail.jpg?version=1', '4466372687352851af2d131cfaa8a4c7')

# Generated at 2022-06-24 12:31:56.383939
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:00.836769
# Unit test for constructor of class GlideIE
def test_GlideIE():
  ie = GlideIE()
  assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
  assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:04.933425
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:32:05.947346
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #TODO: implement test
    assert False

# Generated at 2022-06-24 12:32:12.132450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    a = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    b = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert a == b, "Test constructor of class GlideIE: FAILED"
# Add a dot "." to print the result of the unit testing

# Generated at 2022-06-24 12:32:13.422758
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE(InfoExtractor()) != None)

# Generated at 2022-06-24 12:32:20.925760
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/6VpUdDy_V7KjBUDcRCAp7g==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='



# Generated at 2022-06-24 12:32:32.934848
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:42.164604
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor of class InfoExtractor takes in a video URL to an info extractor
    # and retrieve relevant data about the video.
    glide = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:51.504777
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:32:54.320910
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE(GlideIE.IE_NAME, {})
    assert(e.params['extractor']=='Glide')

# Generated at 2022-06-24 12:33:04.066467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Test the GlideIE constructor
    '''
    extractor = GlideIE('test')
    assert extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:12.047516
# Unit test for constructor of class GlideIE
def test_GlideIE():
	"""
	Unit test for constructor of class GlideIE
	"""
	print('Running unit test for GlideIE')
	self = InfoExtractor({})
	self.IE_DESC = 'Glide mobile video messages (glide.me)'
	self._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	print(self)
	print(self.IE_DESC)
	print(self._VALID_URL)
	print(self.rating_count)
	return self

# Generated at 2022-06-24 12:33:17.531296
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert issubclass(GlideIE, InfoExtractor)
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:18.840965
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE._downloader).IE_NAME == "Glide"

# Generated at 2022-06-24 12:33:21.911552
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Arrange
	url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

	# Act
	GlideIE(url)

	# Assert


# Generated at 2022-06-24 12:33:24.658958
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:26.305680
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE()._VALID_URL, type(r'https://example.com'))

# Generated at 2022-06-24 12:33:26.875035
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-24 12:33:28.136524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, GlideIE)

# Generated at 2022-06-24 12:33:29.484353
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._match_id(url)

# Generated at 2022-06-24 12:33:33.922747
# Unit test for constructor of class GlideIE
def test_GlideIE():
    expected_result = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }
    GlideIE_inst = GlideIE()
    assert GlideIE_inst._TEST == expected_result

# Generated at 2022-06-24 12:33:37.319584
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = GlideIE()
    assert infoExtractor.IE_NAME == 'glide.me'
    assert infoExtractor.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:42.255896
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    info_extractor = GlideIE()
    assert info_extractor.IE_NAME == 'glide'
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-24 12:33:46.628911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.url == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="


# Generated at 2022-06-24 12:33:48.579885
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:33:51.063469
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE(cachedwebpage=True)
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:54.560534
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:33:58.546542
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    gi = GlideIE()
    assert gi.IE_NAME == "Glide"
    assert gi.IE_DESC == "Glide mobile video messages (glide.me)"
    assert gi._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:00.637927
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:34:09.112053
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert ie._TEST.get('url') == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert ie._TEST.get('md5') == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:34:15.102072
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()
    ie.extract(url)
    ie.extract(url)
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()
    ie.extract(url)
    

# Generated at 2022-06-24 12:34:16.480964
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:34:24.020444
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:25.346901
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:34:27.754478
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if __name__ == '__main__':
        test = GlideIE()

        test._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:37.897257
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = GlideIE()
    assert infoExtractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert infoExtractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:39.587135
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"



# Generated at 2022-06-24 12:34:44.448684
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    instance = GlideIE()
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:34:49.914713
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    assert inst._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert inst.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:34:59.340185
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:35:05.169441
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    assert ie.__class__ == GlideIE
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.LOGIN_URL is None
    assert ie.LOGGED_IN is None

# Generated at 2022-06-24 12:35:15.016079
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()._build_url_result()
    assert info['id']=='UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['ext']=='mp4'
    assert info['title']=="Damon's Glide message"
    assert info['thumbnail']=='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==/thumbnail/1280x720_5' or info['thumbnail']=='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==/thumbnail/960x640_5'

# Generated at 2022-06-24 12:35:15.936266
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()

# Generated at 2022-06-24 12:35:24.105889
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_inst = GlideIE()
    assert_eq(test_inst.IE_DESC, "Glide mobile video messages (glide.me)")
    assert_eq(test_inst._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert_eq(test_inst._TEST['url'], "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert_eq(test_inst._TEST['md5'], "4466372687352851af2d131cfaa8a4c7")

# Generated at 2022-06-24 12:35:28.235282
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glideIE = GlideIE()
    assert(glideIE.ie_key() == 'Glide')
    assert(glideIE.ie_desc() == 'Glide mobile video messages (glide.me)')
    assert(glideIE.valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True)
    assert(glideIE.valid_url('http://www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') != True)
    

# Generated at 2022-06-24 12:35:33.177949
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Sample to produce output for unittest
# http://share.glide.me/6XDU6NQcQZe5rHOgJF5h5w==
# http://share.glide.com/6XDU6NQcQZe5rHOgJF5h5w==

# Generated at 2022-06-24 12:35:43.241517
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE({})
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:51.294929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:35:55.362532
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    


# Generated at 2022-06-24 12:35:58.629154
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == (
        r'https?://share\.glide\.me/'
        '(?P<id>[A-Za-z0-9\-=_+]+)'
    )

# Generated at 2022-06-24 12:36:02.302970
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==");

# Test for method _search_regex of class GlideIE 

# Generated at 2022-06-24 12:36:10.271527
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:11.136048
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:36:16.318895
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glideIE = GlideIE(url)
    assert glideIE.url == url
    assert glideIE.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:36:17.759514
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie != None


# Generated at 2022-06-24 12:36:27.820360
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:28.701058
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:36:29.743561
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:36:40.345711
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE('http://share.glide.me/RdlO7lKGQf6VyOu_ruD5Yw==')
    assert a != None, "Failed to initialize GlideIE class"
    assert a._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', "Failed to initialize _VALID_URL"
    assert a.IE_DESC == 'Glide mobile video messages (glide.me)', "Failed to initialize IE_DESC"
    assert a._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', "Failed to initialize _TEST url"
    assert a._T