

# Generated at 2022-06-24 12:26:42.761608
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

    assert obj.IE_DESC == GlideIE.IE_DESC
    assert obj._VALID_URL == GlideIE._VALID_URL
    assert obj._TEST == GlideIE._TEST

# Generated at 2022-06-24 12:26:44.954761
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_NAME == "Glide")

# Generated at 2022-06-24 12:26:50.719208
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor.IE_NAME == 'glide'
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:26:53.268465
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Tests that the constructor of class GlideIE  works
    """
    m = GlideIE()
    assert m.IE_DESC == "Glide mobile video messages (glide.me)"


# Generated at 2022-06-24 12:26:54.872773
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()

# Generated at 2022-06-24 12:26:57.151873
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:27:03.231982
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:27:11.845450
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
	assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:27:20.773268
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert(isinstance(test, InfoExtractor))
    URL = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert(test._match_id(URL) == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    webpage = test._download_webpage(url, 'test')
    assert(test._search_regex(
        r'<source[^>]+src=(["\'])(?P<url>.+?)\1',
        webpage, 'video URL', default=None,
        group='url') is not None)

   

# Generated at 2022-06-24 12:27:30.446586
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    #assert GlideIE._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$'}}
    #
    # constructor of class GlideIE

# Generated at 2022-06-24 12:27:31.220352
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:40.345578
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE(None)
    assert IE.__name__ == 'GlideIE'
    assert IE.VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:43.181402
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:46.150004
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test if GlideIE is constructed"""
    a = GlideIE(GlideIE.create_ie())
    assert a is not None, "Failed to construct GlideIE"


# Generated at 2022-06-24 12:27:50.069045
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gi = GlideIE()
    assert gi.IE_NAME is None or gi.IE_NAME == ''
    assert gi.IE_DESC is None or gi.IE_DESC == ''
    assert gi._VALID_URL is None or gi._VALID_URL.strip() == ''
    #assert gi._TEST is None

# Generated at 2022-06-24 12:27:55.629737
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:27:59.194361
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')
    except Exception:
        assert False, 'GlideIE constructor broken or unit test not refactored'
    assert True

# Generated at 2022-06-24 12:28:00.195006
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)


# Generated at 2022-06-24 12:28:02.062812
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide_ie = GlideIE();
	assert glide_ie != None;


# Generated at 2022-06-24 12:28:05.801337
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._ANNOTATIONS_REGEX == r'<a[^>]+data-annotation[^>]+data-value=(["\'])(?P<url>.+?)\1'


# Test for GlideIE._proto_relative_url

# Generated at 2022-06-24 12:28:10.181021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.IE_NAME == 'glide'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:28:16.440693
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:28:26.328280
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:34.996625
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert_equal(ie.IE_DESC, 'Glide mobile video messages (glide.me)')
    assert_equal(ie._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:28:38.804922
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:28:42.435820
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test to check if GlideIE has the required IE_DESC

    Initialising class GlideIE and using
    assertEquals function to check the required value
    """
    test_class = GlideIE(InfoExtractor())
    assert test_class.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:28:44.233806
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert type(g) is GlideIE

# Generated at 2022-06-24 12:28:46.962761
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert 'glide.me' in ie.IE_DESC

# Generated at 2022-06-24 12:28:48.249094
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    GlideIE()

# Generated at 2022-06-24 12:28:52.211821
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'glide'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:28:53.136501
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj != None

# Generated at 2022-06-24 12:28:55.512618
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('https://share.glide.me/6WKjJgL+ZotzF-au8OxrYg==')

# Generated at 2022-06-24 12:29:07.062037
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")._TEST == {
            'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
            'md5': '4466372687352851af2d131cfaa8a4c7',
            'info_dict': {
                'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
                'ext': 'mp4',
                'title': "Damon's Glide message",
                'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
            }
        }
# test_GlideIE()

# Generated at 2022-06-24 12:29:07.838993
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE.create_ie_instance()) is not None

# Generated at 2022-06-24 12:29:09.182916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'

# Generated at 2022-06-24 12:29:12.954419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    TestCase = type("TestCase", (unittest.TestCase,), { "a":5 })
    class ConstructorTest(TestCase):
        def setUp(self):
            self.ie = GlideIE()
    ConstructorTest("test_setUp").runTest()

# Generated at 2022-06-24 12:29:16.185584
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url=video_url)

# Generated at 2022-06-24 12:29:17.516410
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()


# Generated at 2022-06-24 12:29:22.564979
# Unit test for constructor of class GlideIE
def test_GlideIE():
    data = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert 'http://' + data.url == data.video_url
    assert data.title == "Damon's Glide message"


# Generated at 2022-06-24 12:29:23.145815
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-24 12:29:26.221313
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideie = GlideIE()
    assert glideie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glideie.IE_NAME == 'glide'

# Generated at 2022-06-24 12:29:29.078152
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:29:30.100634
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'share.glide.me'



# Generated at 2022-06-24 12:29:30.476969
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:29:32.050264
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(InfoExtractor())
    ie._real_initialize()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:29:33.442150
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE(False)
    assert x != None

# Generated at 2022-06-24 12:29:41.267030
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_ogv = GlideIE().test_ogv
    test_ogv('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    test_ogv('http://share.glide.me/ZX-L5F5b5h5MwGb5_RgYBg==')
    test_ogv('http://share.glide.me/-BvlxNEBwfQyR-BDRUpD-g==')

# Generated at 2022-06-24 12:29:47.517360
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:29:49.173335
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:29:55.594821
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == 'GlideIE'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:29:57.764860
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test if it is initialized successfully
    w = GlideIE()
    assert isinstance(w, GlideIE)


# Generated at 2022-06-24 12:29:58.803963
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(1,2)

# Generated at 2022-06-24 12:30:05.630947
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    # Test a valid URL
    GlideIE(test_GlideIE.__name__, _VALID_URL,
            _TEST.get('info_dict', {}),
            _TEST.get('expected_warnings', []))
    # Test an invalid URL
    GlideIE(test_GlideIE.__name__, 'http://www.youtube.com/watch?v=123456789',
            _TEST.get('info_dict', {}),
            _TEST.get('expected_warnings', []))

# Generated at 2022-06-24 12:30:07.382038
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(isinstance(GlideIE(None)._downloader, InfoExtractor))

# Generated at 2022-06-24 12:30:11.752467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE._VALID_URL = ie._VALID_URL
    GlideIE._TEST = ie._TEST
    assert ie.suitable(url)

# Generated at 2022-06-24 12:30:13.073764
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from youtube_dl.extractor import GlideIE
    assert GlideIE

# Generated at 2022-06-24 12:30:15.529162
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert isinstance(obj,GlideIE)
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:30:17.245390
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:30:18.593708
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(InfoExtractor()), InfoExtractor)

# Generated at 2022-06-24 12:30:28.501842
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # to check whether the constructor is declared exactly once
    # if this fails, check the class definition in GlideIE above
    assert hasattr(GlideIE, '__init__'), 'No constructor declared'
    assert hasattr(GlideIE.__init__, '__code__'), 'Constructor is not a function'
    assert GlideIE.__init__.__code__.co_argcount == 2, 'GlideIE.__init__() should take exactly 2 arguments (self and url)'
    
    # to check whether the IE_DESC is declared exactly once
    # if this fails, check the class definition in GlideIE above
    assert hasattr(GlideIE, 'IE_DESC'), 'IE_DESC is not declared'

# Generated at 2022-06-24 12:30:31.183318
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:30:35.316886
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(downloader=None)
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
test_GlideIE()

# Generated at 2022-06-24 12:30:41.014814
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert a.id == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert a.legal_urls == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert a.name == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:30:49.239557
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_instance = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert test_instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:50.329053
# Unit test for constructor of class GlideIE
def test_GlideIE():
    s = GlideIE()
    assert isinstance(s, GlideIE)

# Generated at 2022-06-24 12:30:51.891774
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from glide import GlideIE

test_GlideIE()
print('Tests passed')

# Generated at 2022-06-24 12:30:54.755844
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(InfoExtractor(None))._real_extract(url)

# Generated at 2022-06-24 12:31:01.265509
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(InfoExtractor())
    assert ie.name == "Glide (video messages)"
    assert ie.ie_key == "Glide"
    assert ie.IE_DESC == ie.ie_key + ' mobile video messages (glide.me)'
    assert ie.supported_extensions == ['mp4']
    assert ie.info_dict is None
    assert ie.default_extension == 'mp4'


# Generated at 2022-06-24 12:31:03.318582
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:31:03.896275
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:08.576911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    info_dict = GlideIE()._real_extract(GlideIE._TEST['url'])
    assert info_dict == GlideIE._TEST['info_dict']
# TODO test_GlideIE()

# Generated at 2022-06-24 12:31:10.674910
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:31:13.496469
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Tests constructor of class GlideIE
    Run all test by calling `python -m unittest discover -p "*_test.py"`
    """
    import unittest

    unittest.main(module=__name__, buffer=True, exit=False)

# Generated at 2022-06-24 12:31:17.099158
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test fuction GlideIE with valid URL
    # Given invalid URL
    validURL = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # When we create GlideIE object
    try:
        GlideIE(validURL)
        # Then we see the object is created successfully
        assert(True)
    except:
        # Or we got unexpected error
        assert(False)

# Generated at 2022-06-24 12:31:23.287254
# Unit test for constructor of class GlideIE
def test_GlideIE():
    webrtc_object = GlideIE()
    assert webrtc_object.IE_NAME == 'Glide'
    assert webrtc_object.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert webrtc_object._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:24.771021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:31:32.520467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert_raises(TypeError, GlideIE, None)
    assert_raises(TypeError, GlideIE, "")
    assert_raises(TypeError, GlideIE, "UZF8zlmuQbe4mr+7dCiQ0w==")
    assert_raises(TypeError, GlideIE, None)
    assert_raises(TypeError, GlideIE, False)
    assert_raises(Exception, GlideIE, True)
    assert_raises(Exception, GlideIE, "")
    assert_raises(Exception, GlideIE, "UZF8zlmuQbe4mr+7dCiQ0w==")
    assert_raises(Exception, GlideIE, None)
    assert_raises(Exception, GlideIE, False)

# Generated at 2022-06-24 12:31:32.935070
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:42.881793
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = "Description"
    ie._TEST = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    assert ie.ie_key() == 'glide'
    assert ie.IE_DES

# Generated at 2022-06-24 12:31:45.949445
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:31:46.972122
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()

# Generated at 2022-06-24 12:31:48.389925
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None, None, None)


# Generated at 2022-06-24 12:31:49.747328
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:31:52.628500
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:31:53.835468
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:31:55.161182
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor for GlideIE:
    assert GlideIE()

# Generated at 2022-06-24 12:32:04.722429
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if __name__ == "__main__":
        # Create object GlideIE
        obj = GlideIE()

        # Create an object which contains all information of the video
        video_info = obj._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

        # Assert the testcase using assertEqual
        assert video_info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
        assert video_info['title'] == 'Damon\'s Glide message'

# Generated at 2022-06-24 12:32:06.815747
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.ie_key() == 'Glide'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:14.757279
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor of class InfoExtractor uses mojibake.compat.str_to_bytes which will return an ascii-encoded string,
    # so we have to use unicode string as url.
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glide_ie = GlideIE(InfoExtractor())
    assert glide_ie._match_id(url) == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert glide_ie._real_extract(url).get("id") == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:32:15.551712
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print(ie)

# Generated at 2022-06-24 12:32:18.747771
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._download_webpage('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:32:20.838517
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:32:28.947139
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This unit test checks the class constructor of class GlideIE.
    """
    # Test the constructor of class GlideIE
    glide_ie = GlideIE()
    assert_equal(glide_ie.ie_key(), 'Glide')
    assert_equal(glide_ie.ie_desc(), 'Glide mobile video messages (glide.me)')
    assert_true(glide_ie.ie_uses_netloc())
    assert_true(isinstance(glide_ie._VALID_URL, str))


# Generated at 2022-06-24 12:32:30.712848
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance


# Generated at 2022-06-24 12:32:31.541280
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    assert(inst is not None)


# Generated at 2022-06-24 12:32:39.648040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    title = 'Damon\'s Glide message'
    thumbnail = 'https://d2lzf7bw4h4l4m.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/0.jpg'
    video_url = 'https://d2lzf7bw4h4l4m.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/video.mp4'
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:32:41.564327
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(None)
    assert obj.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:32:42.190076
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-24 12:32:42.595156
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE

# Generated at 2022-06-24 12:32:50.015782
# Unit test for constructor of class GlideIE
def test_GlideIE():
    self = InfoExtractor()
    glideIE = GlideIE()
    # test give web page url of a glide video 
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video = glideIE.extract(self._fake_url_test(url))
    assert video['id']  == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert video['ext'] == 'mp4'
    assert video['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:32:52.271186
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(params={'ie': 'Glide'})
    assert ie.ie == 'Glide'

# Generated at 2022-06-24 12:32:54.473344
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:32:57.794851
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance == GlideIE()
    assert instance.IE_NAME == 'glide'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:02.373243
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': 're:^https?://.*?\\.cloudfront\\.net/.*\\.jpg$'}}

# Generated at 2022-06-24 12:33:04.845260
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.IE_NAME == "glide")
    assert(GlideIE.IE_DESC == "Glide mobile video messages (glide.me)")
    

# Generated at 2022-06-24 12:33:05.929770
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert isinstance(instance, GlideIE)

# Generated at 2022-06-24 12:33:11.634830
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==")
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr_7dCiQ0w==")
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr=7dCiQ0w==")
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w")

# Generated at 2022-06-24 12:33:16.918116
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Simple unit test for the GlideIE class
    print("Testing class GlideIE")

    # Sample URL for a Glide video
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    # Testing GlideIE constructor
    glide_ie = GlideIE()

    # Calling the appropriate function to extract information from the video
    info_dict = glide_ie._real_extract(test_url)

    # Asserting the returned information
    assert info_dict['_type'] == "url_transparent"
    print("Extracted info:")
    for key, value in info_dict.iteritems():
        print(key, ":", value)


# Generated at 2022-06-24 12:33:18.264422
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE(object).get_info_extractor()

# Generated at 2022-06-24 12:33:28.104081
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:32.188824
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:33:36.620020
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:47.940569
# Unit test for constructor of class GlideIE
def test_GlideIE():
    success = False
    try:
        glideIE = GlideIE()
        success = True
    except Exception:
        pass

    assert success
    # Unit test for _real_extract method of class GlideIE
    glideIE = GlideIE()
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Test using valid URL
    real_extract_success = False
    try:
        real_extract = glideIE._real_extract(url)
        real_extract_success = True
    except Exception:
        pass
    assert real_extract_success

    # Test using invalid URL
    real_extract_fail_success = True

# Generated at 2022-06-24 12:33:57.600454
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # pylint: disable=protected-access
    # Test that the GlideIE is correctly setup, with the correct methods
    ie = GlideIE()

    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:06.506847
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE()._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE()._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:34:13.346397
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert glide._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._TEST['info_dict']['ext'] == 'mp4'
    assert glide._TEST['info_dict']['title']

# Generated at 2022-06-24 12:34:23.357857
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # given
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # when
    glide_ie = GlideIE()
    # then
    assert glide_ie.IE_NAME == 'Glide'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:26.351991
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        glideIE = GlideIE('', '')
        assert(glideIE is not None)
        assert(True)
    except AssertionError:
        print ('Unit test for constructor of class GlideIE failed and threw an AssertionError!')

# Generated at 2022-06-24 12:34:36.356386
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:36.888511
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:38.826258
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://glide.me/')
    ie.get_video_url()
    ie.get_video_info()

# Generated at 2022-06-24 12:34:43.075392
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:34:53.263214
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert_equal(glide._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:34:53.813789
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert True

# Generated at 2022-06-24 12:34:55.084794
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie



# Generated at 2022-06-24 12:34:59.339777
# Unit test for constructor of class GlideIE
def test_GlideIE():
    uut = GlideIE()
    assert uut.IE_NAME == 'Glide'
    assert uut.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert uut._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:07.631961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:18.630802
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE()
    class_name = a.__class__.__name__
    # check public class attributes
    assert a.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert a._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:19.093483
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:21.226686
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    instance.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:35:21.743919
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert True

# Generated at 2022-06-24 12:35:24.646275
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_DESC is 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL is 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:35:27.897837
# Unit test for constructor of class GlideIE
def test_GlideIE():
    input = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    output = GlideIE._VALID_URL
    assert GlideIE._match_id(input)

# Generated at 2022-06-24 12:35:36.719112
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()
    ie_result = ie.extract(url)
    assert ie_result
    assert ie_result['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie_result['url'] == 'http://s3-us-west-2.amazonaws.com/glidemessagebucket/UZF8zlmuQbe4mr+7dCiQ0w==.mp4'

# Generated at 2022-06-24 12:35:37.590885
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:40.793991
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .test_glide import TestGlide
    test = TestGlide()

# Generated at 2022-06-24 12:35:42.446643
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        pass
    else:
        print("Expected Exception")

# Generated at 2022-06-24 12:35:45.713900
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL.match("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:35:52.656255
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:36:01.023835
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_NAME = "glide"
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:01.644464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:36:02.372599
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:36:09.250035
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Case for 'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(InfoExtractor)._download_webpage = lambda self, url: open('test_file_for_GlideIE.html', 'r').read()
    GlideIE(InfoExtractor)._html_search_regex = InfoExtractor._html_search_regex
    GlideIE(InfoExtractor)._og_search_title = InfoExtractor._og_search_title
    GlideIE(InfoExtractor)._proto_relative_url = InfoExtractor._proto_relative_url
    GlideIE(InfoExtractor)._search_regex = InfoExtractor._search_regex
    GlideIE(InfoExtractor)._og_search_video

# Generated at 2022-06-24 12:36:11.566463
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Constructor test
    """
    GlideIE()


# Generated at 2022-06-24 12:36:13.184675
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE(info_dict={'id': 0, 'title': '', 'url': '', 'thumbnail': ''}) is not None)

# Generated at 2022-06-24 12:36:15.558036
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE._downloader)._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:36:16.004835
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:36:19.507091
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Check that _VALID_URL is set
    assert ie._VALID_URL is not None
    # Check that _TEST is set
    assert ie._TEST is not None


# Generated at 2022-06-24 12:36:21.152728
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:36:22.915212
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:31.320431
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

    ie = GlideIE()
    ie.download(test['url'])
    assert ie.extract(test['url']) == test['info_dict']

# Generated at 2022-06-24 12:36:32.846485
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert 'GlideIE()' == repr(GlideIE())


# Generated at 2022-06-24 12:36:40.469574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create instance of GlideIE (constructor test)
    glide = GlideIE();

    # To run the unit tests:
    #
    #    nosetests youtube_dl/extractor/glide.py
    #
    # For verbose output:
    #
    #    nosetests -v youtube_dl/extractor/glide.py
    #
    # For enabling debug messages, set youtube_dl logger level to debug:
    #
    #    nosetests -s youtube_dl/extractor/glide.py
    assert(glide != None)