

# Generated at 2022-06-24 12:26:53.109471
# Unit test for constructor of class GlideIE
def test_GlideIE():

    from glide import GlideIE
    from mirror_tube.utils import HEADRequest

    glide = GlideIE()
    glide_request = HEADRequest('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    glide_request.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36')

    def test_real_download():

        def test_extractor(self, test_download=True, *args, **kwargs):
            """Test extractors.
            If test_download is True, test download too.
            """

# Generated at 2022-06-24 12:27:01.035402
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glide.com/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glide.io/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glid.es/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glid.is/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:04.026924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE.ie_key())
    assert ie.ie_key() == 'Glide'
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:27:12.288698
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:27:13.594072
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE();
    assert glideIE.IE_DESC

# Generated at 2022-06-24 12:27:14.180598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-24 12:27:16.943040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(ie, GlideIE)

# Generated at 2022-06-24 12:27:20.361520
# Unit test for constructor of class GlideIE
def test_GlideIE():
	extractor = GlideIE()
	result = extractor.result()
	assert extractor.name == 'Glide'
	assert extractor.url_name == 'glide.me'
	assert extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert result == None


# Generated at 2022-06-24 12:27:30.092058
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:27:39.673779
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    assert test_GlideIE.name == 'GlideIE'
    assert test_GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test_GlideIE._TEST.get('md5') == '4466372687352851af2d131cfaa8a4c7'
    assert test_GlideIE._TEST.get('info_dict').get('id') == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:27:45.093496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.extract()['title'] == "Damon's Glide message"
    assert ie.extract()['id'] == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:27:46.952817
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Test for constructor of class GlideIE
test_GlideIE()

# Generated at 2022-06-24 12:27:54.684864
# Unit test for constructor of class GlideIE
def test_GlideIE(): 
    info_extractor = GlideIE()
    assert info_extractor
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'

    assert info_extractor._TEST
    #test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    #assert info_extractor._TEST['url'] == test_url
    #assert info_extractor._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"
    #assert info_extractor

# Generated at 2022-06-24 12:27:57.712731
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create instance of class GlideIE
    glide_ie = GlideIE()
    # Run unit test for constructor on instance of class GlideIE
    assert(glide_ie is not None)



# Generated at 2022-06-24 12:28:04.154755
# Unit test for constructor of class GlideIE
def test_GlideIE():
        # If a regex match occurs and exception is thrown.
        def test_GlideIE_match():
            assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
            
        # If the regex match does not occur, the test is passed.
        def test_GlideIE_no_match():
            assert GlideIE('http://example.com/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:11.425978
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import GlideIE
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:28:21.333477
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    # This one should fail as it is not a Glide video URL
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_VERSION == '1.0.0'
    # This one should fail as it is not a Glide video URL
    assert ie.VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # This one should fail as it is not a Glide video URL

# Generated at 2022-06-24 12:28:29.235312
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Read the MD5 hash at the top of this file, change the test_GlideMD5Val
    # to that value, and then run this test. This will update the MD5 hash
    # value in the file.
    test_GlideMD5Val = '4466372687352851af2d131cfaa8a4c7'
    glide = GlideIE()
    this_test = glide._TEST
    glide._real_extract(this_test['url'])
    assert 'md5' in this_test
    assert this_test['md5'] == test_GlideMD5Val

# Generated at 2022-06-24 12:28:29.814267
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-24 12:28:38.336927
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME in ('Glide', 'Glide mobile video messages (glide.me)')
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj.NAME == 'Glide'
    assert obj.DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:40.804616
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:41.691705
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("glide series")

# Generated at 2022-06-24 12:28:50.354664
# Unit test for constructor of class GlideIE
def test_GlideIE(): 
    gie = GlideIE() 
    assert gie.IE_NAME == "GlideIE"
    assert gie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert gie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # execute _real_extract function
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    gie._real_extract(url)

# Generated at 2022-06-24 12:29:00.561702
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # When unit testing, extractors are called without the global context
    #  Information.
    # The following is used to emulate the global context.
    # It should be implemented in every IE.
    # They need to provide the information that is expected to be provided by
    #  the global context.
    import inspect
    from ytdl_base_test import extractor_for_test
    from ytdl_base_test import glob_context_for_test

# Generated at 2022-06-24 12:29:02.048881
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE() # noqa
    assert isinstance(obj, GlideIE)

# Generated at 2022-06-24 12:29:13.456665
# Unit test for constructor of class GlideIE
def test_GlideIE():
    tst = GlideIE()
    assert tst.IE_NAME == 'Glide'
    assert tst.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert tst._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:24.765639
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:29:26.156505
# Unit test for constructor of class GlideIE
def test_GlideIE():
    Glide = GlideIE()

# Generated at 2022-06-24 12:29:26.774472
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:29:30.366269
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:29:31.025007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    b = GlideIE()

# Generated at 2022-06-24 12:29:35.729386
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:43.237531
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_test = ie._TEST
    l = len(ie_test['url'])
    video_id = ie_test['url'][l:l-12]
    webpage = ie._download_webpage(ie_test['url'], video_id)
    assert ie_test['md5'] == ie._get_md5_from_webpage(webpage, video_id)
    assert ie_test['info_dict'] == ie._extract_info_dict_from_webpage(webpage, video_id)

# Generated at 2022-06-24 12:29:51.001805
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ''' Constructor test for GlideIE '''
    obj = GlideIE()
    assert obj.IE_NAME == GlideIE.IE_NAME
    assert obj.IE_DESC == GlideIE.IE_DESC
    assert obj._VALID_URL == GlideIE._VALID_URL
    assert obj._TEST == GlideIE._TEST
    assert obj._download_webpage == GlideIE._download_webpage
    assert obj._match_id == GlideIE._match_id
    assert obj._proto_relative_url == GlideIE._proto_relative_url
    assert obj._search_regex == GlideIE._search_regex
    assert obj._html_search_regex == GlideIE._html_search_regex
    assert obj._og_search_title == GlideIE._og_

# Generated at 2022-06-24 12:30:01.303721
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test case for 'url':
    # http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==
    # Test case for 'md5':
    # 4466372687352851af2d131cfaa8a4c7
    # Test case for 'info_dict':
    # {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title':
    # "Damon's Glide message", 'thumbnail': re:^https?://.*?\.cloudfront\.net/.*\.jpg$
    glide_ie = GlideIE()

# Generated at 2022-06-24 12:30:01.887276
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:05.232962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', str(ie._VALID_URL)


# Generated at 2022-06-24 12:30:08.297748
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of class GlideIE
    # 
    # Input: GlideIE,
    # Expected Output: None
    # Actual Output: None
    GlideIE()


# Generated at 2022-06-24 12:30:18.507560
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:30:24.253975
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/-jmEJhEVJR+2RfRgjkcEZA=='
    id = ie._match_id(url) 
    info_dict = ie._real_extract(url)
    assert(id == info_dict['id'])


# Generated at 2022-06-24 12:30:26.220894
# Unit test for constructor of class GlideIE
def test_GlideIE():
    l = GlideIE()
    l.extract

# Generated at 2022-06-24 12:30:35.014734
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:45.194081
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__name__ == 'GlideIE'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:48.360394
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This will throw an exception if GlideIE is not constructed successfully
    ie = GlideIE()
    print("Successfully constructed GlideIE")
    print("URL regex: ", ie._VALID_URL)

# Calling main function to execute all unit tests
if __name__ == "__main__":
    test_GlideIE()

# Generated at 2022-06-24 12:30:49.384083
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    assert GlideIE.__name__ == 'GlideIE'

# Generated at 2022-06-24 12:30:57.560614
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Create a new instance of InfoExtractor
    ie = InfoExtractor()

    #Make a dummy url
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'

    #Make a new instance of the class GlideIE
    #passing in the url, ie, and the requested video id
    glideIE = GlideIE(url, ie, 'BaW_jenozKc')
    #Check to see if the video id matches the expacted video id
    assert glideIE._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:31:00.573061
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("GlideIE", "Glide mobile video messages (glide.me)")

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:31:04.583855
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-24 12:31:06.289440
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #test a GlideIE object
    GlideIE()

# Generated at 2022-06-24 12:31:08.702899
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    glide_ie_obj = GlideIE()
    assert glide_ie_obj is not None


# Generated at 2022-06-24 12:31:16.230920
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    webpage = ie._download_webpage(url, "test-id")
    assert webpage is not None
    title = ie._html_search_regex(r'<title>(.+?)</title>', webpage, 'title', default=None) or ie._og_search_title(webpage)
    assert title is not None
    video_url = ie._proto_relative_url(ie._search_regex(r'<source[^>]+src=(["\'])(?P<url>.+?)\1', webpage, 'video URL', default=None, group='url')) or ie._og_search_video_url(webpage)
    assert video_

# Generated at 2022-06-24 12:31:26.808797
# Unit test for constructor of class GlideIE
def test_GlideIE():
	try:
		width = input('Enter the width of your video: ')
		height = input('Enter the height of your video: ')
		aspect_ratio = width/height
		if(aspect_ratio >= 1.7 and aspect_ratio <= 1.8):
			print('Video is HD')
		else:
			print('Video is not HD')
		if(width >= 1920 and height >= 1080):
			print('Video is 1080P')
		elif(width >= 1280 and height >= 720):
			print('Video is 720P')
		else:
			print('Video is not HD')
	except:
		print('Error with aspect ratio')

# Generated at 2022-06-24 12:31:29.863015
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Simple call to constructor should not fail
    test_object = GlideIE()
    # Check that it inherits from InfoExtractor
    assert isinstance(test_object, InfoExtractor)


# Generated at 2022-06-24 12:31:40.353567
# Unit test for constructor of class GlideIE
def test_GlideIE():
	import json
	import requests

# Generated at 2022-06-24 12:31:51.507002
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE(GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='))
    assert glide.IE_NAME == 'Glide'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert glide

# Generated at 2022-06-24 12:32:00.492804
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glide_ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glide_ie.ie_key() == 'Glide'
    assert glide_ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert glide_ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:32:07.503484
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t=GlideIE()
    assert t._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert t.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:10.560506
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    assert GlideIE().IE_DESC == GlideIE._IE_DESC
    #assert GlideIE()._TEST == GlideIE._TEST

# Generated at 2022-06-24 12:32:18.646532
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:22.046408
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-24 12:32:24.830580
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", {})

# Generated at 2022-06-24 12:32:32.881887
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')

    # test functions of class InfoExtractor.
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True
    assert ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc') == False

# Generated at 2022-06-24 12:32:36.686627
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Test GlideIE initialization """
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url)

if(__name__ == '__main__'):
    test_GlideIE()

# Generated at 2022-06-24 12:32:37.480223
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-24 12:32:46.213034
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC ==  'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL ==  r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:49.280949
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:32:56.659159
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:00.668453
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:33:11.318712
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.name == 'Glide mobile video messages (glide.me)'
    assert ie.description == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:12.965403
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:33:18.401757
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    # Initialize GlideIE object
    glideIE = GlideIE(GlideIE.IE_NAME)
    
    # Result should be True
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:28.091715
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:28.463708
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:33:32.981426
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:35.364312
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-24 12:33:40.295671
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:42.496901
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie is not None


# Generated at 2022-06-24 12:33:45.091782
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()

# Generated at 2022-06-24 12:33:55.571847
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE('http://www.glide.me/video/54a75343bbe1d80b3e8b4569')
    assert e.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert e.ie_key() == 'Glide'
    assert e.report_warning.call_count == 0
    assert e._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert e.working == True

# Generated at 2022-06-24 12:33:59.253695
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:06.187424
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide = GlideIE()
    assert glide.urls_match(glide_url) == True
    assert glide.suitable(glide_url) == True
    assert glide._get_url_basename(glide_url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._match_id(glide_url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:34:16.946928
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:24.815083
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert obj._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['info_dict']['ext'] == 'mp4'
    assert obj._TEST['info_dict']['title']

# Generated at 2022-06-24 12:34:26.869792
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj != None


# Generated at 2022-06-24 12:34:29.987585
# Unit test for constructor of class GlideIE
def test_GlideIE():
    parser = GlideIE()
    # Constructor of class GlideIE
    assert parser._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:34.163294
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="),
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="))

# Generated at 2022-06-24 12:34:37.379839
# Unit test for constructor of class GlideIE
def test_GlideIE():
  ie = GlideIE()
  ie.IE_DESC
  ie._VALID_URL
  ie._TEST

if __name__ == '__main__':
  test_GlideIE()

# Generated at 2022-06-24 12:34:38.211870
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = InfoExtractor(GlideIE)

# Generated at 2022-06-24 12:34:39.306161
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:34:46.766520
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_GlideIE = GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==", urlopen, urlretrieve)

    assert class_GlideIE.IE_NAME == 'share.glide.me'
    assert class_GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:49.657842
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:50.181944
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:34:54.953512
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:57.909343
# Unit test for constructor of class GlideIE
def test_GlideIE():
    temp = GlideIE()
    assert(temp._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-24 12:34:59.418728
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE(InfoExtractor())
    except TypeError:
        assert False

# Generated at 2022-06-24 12:35:02.954598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:35:04.817339
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC == "Glide mobile video messages (glide.me)")

# Generated at 2022-06-24 12:35:05.648016
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:35:16.997992
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    test_info = ie._TEST;
    input_url = test_info['url'];
    input_id = ie._match_id(input_url);
    test_info['id'] = input_id;
    webpage = ie._download_webpage(input_url, input_id);
    title = ie._html_search_regex(
        r'<title>(.+?)</title>', webpage,
        'title', default=None) or ie._og_search_title(webpage);
    video_url = ie._proto_relative_url(ie._search_regex(
        r'<source[^>]+src=(["\'])(?P<url>.+?)\1',
        webpage, 'video URL', default=None,
        group='url')) or ie._

# Generated at 2022-06-24 12:35:22.297597
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:22.795425
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:26.570826
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")


# Generated at 2022-06-24 12:35:27.648775
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:35:39.054971
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Contructor of test class
    ie = GlideIE()

    # Check attribute 'IE_DESC'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

    # Check attribute '_VALID_URL'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

    # Check attribute '_TEST'

# Generated at 2022-06-24 12:35:40.562929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:35:47.354928
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assertEquals(x.IE_DESC, "Glide mobile video messages (glide.me)")
    assertTrue("None" in x._download_webpage("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", "UZF8zlmuQbe4mr+7dCiQ0w=="))

# Generated at 2022-06-24 12:35:50.508756
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().get_url() == 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:35:53.241681
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:35:55.946280
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    GlideIE is initialized properly
    '''
    GlideIE(None)

# Generated at 2022-06-24 12:36:04.862303
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/zW4c9Xt+Q4y/JjDd/W/Sg=='
    assert ie.suitable(url)
    assert ie.IE_NAME == 'glide'
    url = 'http://share.glide.me/ABcde12345'
    assert ie.suitable(url)
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:07.635863
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Construct GlideIE
    ie = GlideIE()

    # Check if is_id_valid exists
    assert hasattr(ie, 'is_id_valid')

    # Check if extract exists
    assert hasattr(ie, 'extract')

# Generated at 2022-06-24 12:36:13.520470
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    url = 'http://share.glide.me/%s' % video_id
    # Test standard case
    info_dict = GlideIE()._real_extract(url)
    assert info_dict['url'] == 'https://glide-app.globalfndev.com/mp4/%s' % video_id
    assert info_dict['title'] == "Damon's Glide message"
    assert info_dict['id'] == video_id
    assert info_dict['thumbnail'].endswith('.jpg')


# Generated at 2022-06-24 12:36:21.667527
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:24.925519
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
	assert ie.IE_NAME == 'Glide_Mobile'
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:36:26.248065
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-24 12:36:27.899624
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:29.953790
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') is not None

# Generated at 2022-06-24 12:36:38.486748
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/(some-video-id)')
    ie.IE_NAME = 'Glide'
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # url does not matter
    url = 'https://share.glide.me/(some-video-id)'
    # test for constructor
    assert ie._match_id(url) != None


# Generated at 2022-06-24 12:36:48.032798
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE.IE_NAME == 'Glide mobile video messages')
    assert (GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert (GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')