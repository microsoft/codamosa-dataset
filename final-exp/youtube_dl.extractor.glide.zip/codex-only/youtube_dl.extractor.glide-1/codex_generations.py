

# Generated at 2022-06-24 12:26:44.159614
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class TestGlideIE(GlideIE):
        def _download_webpage(self, url, video_id):
            return '<title>%(video_id)s</title>' % locals()

        def _proto_relative_url(self, url):
            return url

    assert TestGlideIE()._real_extract(
        "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")['title'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:26:45.042724
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return

# Generated at 2022-06-24 12:26:48.653408
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == url


# Generated at 2022-06-24 12:26:51.392141
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:26:57.321283
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(downloader=None)
    search = ie._search_regex
    not_exists_search_regex = ie._search_regex
    assert search('a', 'b', 'c', 'd') == 'd'
    assert search('<title>(.+?)</title>', '<title>test</title>', 'title', default='test') == 'test'
    assert search('<title>(.+?)</title>', '<title>test</title>', 'title') == 'test'
    assert search(r'<title>(.+?)</title>', '<title>test</title>', 'title') == 'test'
    assert search(r'<title>(.+?)</title>', '<title class="test">test</title>', 'title') == 'test'
    assert search

# Generated at 2022-06-24 12:27:02.619813
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Construct a GlideIE object
    gie = GlideIE()

    # Check if it is an instance of InfoExtractor class
    assert isinstance(gie, InfoExtractor)

    # When called without parameters, the result should be None
    assert gie._download_webpage() == None

# Generated at 2022-06-24 12:27:04.888594
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:06.047295
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE.__init__(GlideIE())

# Generated at 2022-06-24 12:27:07.639693
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("")
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:27:17.612248
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:18.236892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:18.974908
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE()
    video.initialize()

# Generated at 2022-06-24 12:27:19.412879
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:27:29.076392
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext']

# Generated at 2022-06-24 12:27:31.081493
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    print(obj._TEST)
    print(obj._VALID_URL)

# Generated at 2022-06-24 12:27:32.422815
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import make_extractor
    return make_extractor(GlideIE)

# Generated at 2022-06-24 12:27:33.382721
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:27:35.150870
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This function checks whether this class can be initialized or not.
    """
    _ = GlideIE()

# Generated at 2022-06-24 12:27:37.172754
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global glideie
    glideie = GlideIE()
    assert 'GlideIE' in repr(glideie)


# Generated at 2022-06-24 12:27:37.641297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:48.788831
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:27:59.987296
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('format', 'msg-format')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST.get('url') == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST.get('md5') == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:28:00.736339
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gie = GlideIE()
    assert gie is not None

# Generated at 2022-06-24 12:28:03.345022
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:28:13.035763
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Tests the constructor of class GlideIE"""
    # Test invalid parameters
    invalid_IEs = [
        # None,
        # '',
        # 1,
        # [],
        # {},
        # (),
        # False,
        # True,
    ]
    for invalid_IE in invalid_IEs:
        assert None == GlideIE(invalid_IE)
    # Test valid parameters
    valid_IEs = [
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
    ]
    for valid_IE in valid_IEs:
        assert isinstance(GlideIE(valid_IE), GlideIE)


# Generated at 2022-06-24 12:28:18.131918
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Successful construction
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

    # Failing construction
    try:
        GlideIE("http://share.glide.me/")
    except:
        return True
    return False

# Function to call unit test

# Generated at 2022-06-24 12:28:28.174217
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:28:37.660067
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE.ie_key(GlideIE._VALID_URL)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:41.384264
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    assert GlideIE(None) is not None
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert GlideIE(InfoExtractor(None)).suitable(url)


# Generated at 2022-06-24 12:28:41.892647
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:51.112191
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME == 'Glide'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:51.686875
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:29:01.852359
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:03.022203
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._download_webpage()

# Generated at 2022-06-24 12:29:05.675348
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor = GlideIE
    assert constructor('http://example.com') is not None


# Generated at 2022-06-24 12:29:16.296345
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert IE.IE_NAME is "glide"
    assert IE.IE_DESC is "Glide mobile video messages (glide.me)"
    assert IE._VALID_URL is "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-24 12:29:18.496832
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:29:23.703775
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:29:24.920208
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_class = GlideIE(None)
    assert test_class



# Generated at 2022-06-24 12:29:32.248865
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_object = GlideIE()
    assert ie_object.IE_NAME == 'Glide'
    ie_object2 = GlideIE(IE_NAME = 'Glide')
    assert ie_object2.IE_NAME == 'Glide'
    assert ie_object2.IE_DESC == GlideIE.IE_DESC
    assert ie_object2._VALID_URL == GlideIE._VALID_URL
    assert ie_object2._TEST == GlideIE._TEST

# Generated at 2022-06-24 12:29:33.327537
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)


# Generated at 2022-06-24 12:29:34.924433
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, InfoExtractor)

# Generated at 2022-06-24 12:29:38.413897
# Unit test for constructor of class GlideIE
def test_GlideIE():
	from .common import GlideIE
	GlideIE('http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w==')


# Generated at 2022-06-24 12:29:44.020542
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:29:51.457018
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:54.665445
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE._TEST, None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:29:55.254324
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert()

# Generated at 2022-06-24 12:29:57.032532
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:30:04.232806
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST["info_dict"]["ext"] == GlideIE._test_ie_result(GlideIE._TEST)["info_dict"]["ext"]
    assert GlideIE._TEST["info_dict"]["title"] == GlideIE._test_ie_result(GlideIE._TEST)["info_dict"]["title"]
    assert GlideIE._TEST["info_dict"]["url"] == GlideIE._test_ie_result(GlideIE._TEST)["info_dict"]["url"]
    assert GlideIE._TEST["info_dict"]["thumbnail"] == GlideIE._test_ie_result(GlideIE._TEST)["info_dict"]["thumbnail"]

# Generated at 2022-06-24 12:30:06.092472
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:30:09.973192
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test
    """
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    gie = GlideIE()
    gie._real_extract(url)

# Generated at 2022-06-24 12:30:10.958029
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE


# Generated at 2022-06-24 12:30:13.023671
# Unit test for constructor of class GlideIE
def test_GlideIE():
  assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:30:22.807003
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    expected_info_dict = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }
    ie = GlideIE()
    actual_info_dict = ie._real_extract(test_url)
    assert actual_info_dict == expected_info_dict


# Generated at 2022-06-24 12:30:24.898568
# Unit test for constructor of class GlideIE
def test_GlideIE():	
	assert(GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='))

# Generated at 2022-06-24 12:30:26.884163
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert isinstance(ie,InfoExtractor) == True


# Generated at 2022-06-24 12:30:35.745765
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:38.665393
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages'

# Generated at 2022-06-24 12:30:41.309972
# Unit test for constructor of class GlideIE
def test_GlideIE():
	a = GlideIE()
	assert a.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:30:45.914176
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor(downloader=None, ie_key='Glide')
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    assert ie.suitable(url)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:30:48.083929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('test_GlideIE')
    assert ie.ie_key() == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:30:49.107638
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE()
    e._real_extrac

# Generated at 2022-06-24 12:30:49.596938
# Unit test for constructor of class GlideIE
def test_GlideIE():
	pass

# Generated at 2022-06-24 12:31:00.234097
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:31:00.821795
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:05.508899
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:31:08.787065
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://www.share.glide.me/something')
    assert ie.VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:31:12.926366
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    # Test URL
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE(url)
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:31:13.677520
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE is not None

# Generated at 2022-06-24 12:31:14.914302
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert str(type(GlideIE)) == "<class '__main__.GlideIE'>"

# Generated at 2022-06-24 12:31:15.946773
# Unit test for constructor of class GlideIE
def test_GlideIE():
    _GlideIE = GlideIE()

# Generated at 2022-06-24 12:31:24.089308
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Constructor test
    """
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:26.851063
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test constructor of class GlideIE
    assert GlideIE()

if __name__ == '__main__':
    # test if constructor of class GlideIE works
    test_GlideIE()

# Generated at 2022-06-24 12:31:37.468720
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    ie.i = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie.id = 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:31:48.764332
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:31:53.118180
# Unit test for constructor of class GlideIE
def test_GlideIE():

    g = GlideIE()

    assert(g.IE_NAME == 'Glide')
    assert(g.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(g._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:31:54.567963
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        assert False


# Generated at 2022-06-24 12:31:56.752738
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    assert(IE.IE_DESC == 'Glide mobile video messages (glide.me)')


# Generated at 2022-06-24 12:31:57.343306
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:59.207157
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE(InfoExtractor)
    except:
        assert False

# Generated at 2022-06-24 12:32:06.727788
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for GlideIE
    """
    # Test with an invalid url
    # https://developer.glide.me/api/action/record/get
    result = GlideIE()._download_webpage("glideIE_test_url", None, "test_post_data")
    assert result == "test_post_data", "Failed to return data with invalid url"

    # Test with an url with wrong schema
    url = "wrongschema://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    result = GlideIE()._download_webpage(url, None, "test_post_data")
    assert result == "test_post_data", "Failed to return data with url with wrong schema"

# Generated at 2022-06-24 12:32:07.725104
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE().info();

# Generated at 2022-06-24 12:32:12.873100
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie.IE_NAME
    ie.NAME
    ie.VALID_URL
    ie.get_domain()
    ie.get_url_pattern()
    ie.get_valid_thumbnail()
    ie.get_og_url_patterns()
    ie.get_og_video_url_patterns()
    ie.get_og_video_thumbnail_url_patterns()

# Generated at 2022-06-24 12:32:14.433938
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME == 'glide'
    assert GlideIE.IE_DESC

# Generated at 2022-06-24 12:32:15.581136
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # check if it is constructed without exception
    GlideIE()

# Generated at 2022-06-24 12:32:16.198756
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:16.893385
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:27.445316
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Check GlideIE() constructor is working.
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:37.782236
# Unit test for constructor of class GlideIE
def test_GlideIE():
  obj = GlideIE()
  assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:42.506366
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST
    ie.IE_NAME
    ie.IE_DESC
    ie.webpage_read_content
    ie._download_webpage
    ie._search_regex
    ie.url_result
    ie.suitable
    ie.ie_key

# Generated at 2022-06-24 12:32:44.778168
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Import test code as module
    m = __import__(__name__)
    # Run unit test for constructor of class GlideIE
    m.test_GlideIE()

# Generated at 2022-06-24 12:32:46.140840
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)._download_webpage("https://glide.me", "")

# Generated at 2022-06-24 12:32:48.198940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    with pytest.raises(TypeError):
        GlideIE(object())
    with pytest.raises(TypeError):
        GlideIE(InfoExtractor)

# Generated at 2022-06-24 12:32:53.951770
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # constructor of class GlideIE
    ie = GlideIE()
    iex = InfoExtractor()
    # Attributes of ie and iex should be the same
    assert(ie.IE_DESC == iex.IE_DESC)
    assert(ie._VALID_URL == iex._VALID_URL)
    assert(ie._TEST == iex._TEST)

# Generated at 2022-06-24 12:32:56.105926
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie._TEST['url']

# Generated at 2022-06-24 12:32:57.099297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()


# Generated at 2022-06-24 12:32:59.247211
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(x)



# Generated at 2022-06-24 12:33:08.327225
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:09.853186
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE({})._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:33:10.982769
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:33:12.180778
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:14.551966
# Unit test for constructor of class GlideIE
def test_GlideIE():
  Test = GlideIE("Test Name")
  assert Test.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:22.810854
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:33:23.719034
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()



# Generated at 2022-06-24 12:33:32.583216
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import InfoExtractor
    from .common import MockRequest
    from .common import url_basename

    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    class FakeResult(object):
        headers = {'location': 'http://somewhere.org/abc.mp4'}

    class FakeIE(InfoExtractor):
        def _real_download(self, url):
            return FakeResult()

    ie = FakeIE(MockRequest(url_basename(url)))
    info_dict = ie._real_extract(url)
    assert info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:34.172580
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:33:34.848035
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 'GlideIE' in globals()

# Generated at 2022-06-24 12:33:44.894317
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$'}}


# Generated at 2022-06-24 12:33:51.508859
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test = {
		'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
		'md5': '4466372687352851af2d131cfaa8a4c7',
		'info_dict': {
			'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
			'ext': 'mp4',
			'title': "Damon's Glide message",
			'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
		},
	}
	
	glide_ie = GlideIE()
	glide_ie._download_webpage = lambda x,y: ''
	

# Generated at 2022-06-24 12:34:00.683100
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    assert t
    assert t._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert t.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert t._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert t._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:34:02.681643
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE.IE_DESC, GlideIE._VALID_URL, GlideIE._TEST).result()

# Generated at 2022-06-24 12:34:06.588535
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:08.409193
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test constructor of class GlideIE
    """
    GlideIE()

# Generated at 2022-06-24 12:34:12.661367
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE(None, None)
    assert g.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert g._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:13.768547
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:14.661804
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Simple unit test for GlideIE
    """
    GlideIE()

# Generated at 2022-06-24 12:34:16.316961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        return 'Not GlideIE'
    return 'GlideIE'

# Generated at 2022-06-24 12:34:18.066696
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(None)
    print(obj.IE_DESC)
    #assert len(obj.IE_DESC) > 0

# Generated at 2022-06-24 12:34:22.648781
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:27.687759
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test the constructor of class GlideIE"""

    # Test for GlideIE
    test_IE_GlideIE = GlideIE(GlideIE._downloader, GlideIE._TEST['url'])

    # Test for GlideIE._VALID_URL
    assert(test_IE_GlideIE._VALID_URL == GlideIE._VALID_URL)

    # Test for GlideIE._TEST
    assert(test_IE_GlideIE._TEST == GlideIE._TEST)

# Generated at 2022-06-24 12:34:32.797191
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_info = GlideIE.ie_key()

    # Check expected values
    assert ie_info['ie_desc'] == "Glide mobile video messages (glide.me)"

    # Partial match
    assert ie_info['url'] == "http://share.glide.me/"

    # No match
    assert ie_info['url'] != "http://nope.glide.me/"

# Generated at 2022-06-24 12:34:36.811686
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:44.168236
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj.IE_DESC == "Glide mobile video messages (glide.me)"
    assert test_obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test_obj._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert test_obj._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"
    assert test_obj._TEST['info_dict']['id'] == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:34:53.924677
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()

    assert(glideIE.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:34:59.910225
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for a valid URL
    ie = GlideIE('http://share.glide.me/HdG0Zcgw6F8=')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # No tests yet for the real_extract function
    assert ie.__class__ == InfoExtractor

# Generated at 2022-06-24 12:35:04.133840
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:04.660880
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:10.888752
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:35:16.156239
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://www.share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:35:18.346656
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test that class is well initialized
    glide_ie = GlideIE('http://www.glide.me/message/UZF8zlmuQbe4mr+7dCiQ0w==/')
    assert glide_ie is not None
    assert glide_ie.ie_key() == 'Glide'

# Generated at 2022-06-24 12:35:19.762271
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:35:27.983496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(GlideIE._TEST['url'], GlideIE._TEST['md5'])
    i = GlideIE._TEST
    url = i['url']
    md5 = i['md5']
    print('url: ', url)
    print('md5: ', md5)

    # test with Extractor constructor
    e = GlideIE()
    print(e.extract(url))
    print('*' * 30)

    # test with InfoExtractor constructor
    ie = InfoExtractor()
    print(ie.extract(url))

# Generated at 2022-06-24 12:35:29.031745
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        return 0
    else:
        return 1

# Generated at 2022-06-24 12:35:29.644391
# Unit test for constructor of class GlideIE
def test_GlideIE():
    globals()['GlideIE']

# Generated at 2022-06-24 12:35:32.210321
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:35:40.042195
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # If a class method is static and is not referenced, it won't be considered in the coverage
    # Therefore, we have to create at least 1 instance of that class
    ie = GlideIE()
    assert ie.__class__.__name__ == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:42.369298
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:35:43.891699
# Unit test for constructor of class GlideIE
def test_GlideIE():
    __name__ == '__main__'
    GlideIE()

# Generated at 2022-06-24 12:35:51.680523
# Unit test for constructor of class GlideIE
def test_GlideIE():
    c = GlideIE("")
    assert c._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert c._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert c._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert c._TEST['info_dict']['id'] == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert c._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:35:55.400495
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not GlideIE.suitable('http://othersite.com/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:35:58.283432
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()
    assert(GlideIE().suitable(url))

# Generated at 2022-06-24 12:36:01.639070
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._real_extract(url)

# Generated at 2022-06-24 12:36:05.839589
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        # Testing URL
        test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
        # Testing Glide
        glide = GlideIE()
        # Testing if video exists
        glide._real_extract(test_url)
    except:
        print ("Invalid video URL: %s" % test_url)


if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:36:06.636462
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE

# Test API of class GlideIE

# Generated at 2022-06-24 12:36:08.814621
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:36:10.807519
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tested URL from GlideIE._TEST
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    GlideIE(test_url)

# Generated at 2022-06-24 12:36:14.165790
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test class's constructor
    glide_ie = GlideIE()
    assert glide_ie.ie_key() == 'glide'
    assert glide_ie.ie_desc() == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:16.234116
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).IE_NAME == 'Glide'

# Generated at 2022-06-24 12:36:19.505430
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(InfoExtractor()).extract(url)

# Generated at 2022-06-24 12:36:20.338871
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:36:23.326251
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:31.566406
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE()
    assert e._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert e.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert e._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert e._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:36:33.565654
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:35.046702
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_NAME == 'glide'

# Generated at 2022-06-24 12:36:43.682596
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create extractor
    ie = GlideIE()
    # Retriever
    assert ie._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # Test download video and metadata
    t = ie._download_webpage('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'UZF8zlmuQbe4mr+7dCiQ0w==')