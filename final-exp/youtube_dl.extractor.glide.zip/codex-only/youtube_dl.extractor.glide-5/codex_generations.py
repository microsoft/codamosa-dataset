

# Generated at 2022-06-24 12:26:40.185371
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE


# Generated at 2022-06-24 12:26:43.099011
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:26:54.019904
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(InfoExtractor())
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:26:57.299768
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:08.744294
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:09.878880
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:11.901598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    obj = GlideIE()
    assert(obj.ie_key() == 'Glide')

# Generated at 2022-06-24 12:27:14.782020
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE("http://www.youtube.com/watch?v=BaW_jenozKc")
    assert (instance.glide_id == "BaW_jenozKc")

# Generated at 2022-06-24 12:27:22.482205
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test that GlideIE is a correct information extractor.
    """
    info_extractor = GlideIE()
    assert info_extractor.IE_NAME == 'glide'
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:25.119536
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-24 12:27:31.620546
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    from .common import _build_request
    ie = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    request_obj = _build_request(url)
    query = ie._real_extract(request_obj)
    assert query["url"] == "http://d26h4f4uj2siau.cloudfront.net/video.mp4?UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:27:32.950982
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"

# Generated at 2022-06-24 12:27:34.334047
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert glideIE is not None

# Generated at 2022-06-24 12:27:42.314442
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import FakeYDL
    from .common import make_mock_extractor, extractor_test_cases

    # If a video doesn't have phone number, GlideIE should not be used
    cases = extractor_test_cases(GlideIE, GlideIE._TEST)
    url = cases[0]['url']
    fake_ydl = FakeYDL()
    fake_ydl.params[GlideIE.IE_NAME] = [url]
    fake_ydl.add_info_extractor(GlideIE)
    spy_downloader = make_mock_extractor(GlideIE, url)(fake_ydl, url)
    spy_downloader.add_default_info_extractors()
    spy_downloader.extract_info()
    assert spy_downloader.info_extractor

# Generated at 2022-06-24 12:27:48.443088
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC.startswith('Glide mobile video messages')
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:49.314422
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:27:53.154173
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-24 12:27:54.608603
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #This is to instantiate GlideIE class.
    a = GlideIE()

# Generated at 2022-06-24 12:27:57.217546
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert 'Glide' == ie.IE_NAME
    assert 'Glide mobile video messages (glide.me)' == ie.IE_DESC

# Generated at 2022-06-24 12:28:07.051772
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:08.256781
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 'video-thumbnail' == GlideIE._VALID_URL

# Generated at 2022-06-24 12:28:09.605360
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor is not None

# Generated at 2022-06-24 12:28:15.027068
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['url'].endswith('mp4')
    assert info['thumbnail'].endswith('.jpg')

# Generated at 2022-06-24 12:28:16.010594
# Unit test for constructor of class GlideIE
def test_GlideIE():
	objGlideIE = GlideIE()


# Generated at 2022-06-24 12:28:18.858117
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Example of what you would put in the unit test file.
    """
    glide_ie = GlideIE()
    glide_ie.download(glide_ie._TEST['url'])

# Generated at 2022-06-24 12:28:19.424705
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:28:20.868416
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).IE_NAME == 'glide'

# Generated at 2022-06-24 12:28:22.995007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:27.692868
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Equivalence partitioning:
    #   when the constructor is called, that a GlideIE object is created
    #   with valid data
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert GlideIE(url)



# Generated at 2022-06-24 12:28:28.831122
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:28:34.332723
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    url = 'http://share.glide.me/aBcDeFgH'
    id = 'aBcDeFgH'
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert i._match_id(url) == id

# Generated at 2022-06-24 12:28:42.267096
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(compat_str(""), compat_str(""))._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE(compat_str(""), compat_str("")).IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:28:44.409586
# Unit test for constructor of class GlideIE
def test_GlideIE():
    construct1 = GlideIE

    construct2 = InfoExtractor

    assert construct1 == construct2


# Generated at 2022-06-24 12:28:46.786735
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test construction of GlideIE
    obj = GlideIE(u'test_GlideIE')
    assert not obj is None, "constructor of class GlideIE should not return None"

# Generated at 2022-06-24 12:28:47.214544
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-24 12:28:48.320950
# Unit test for constructor of class GlideIE
def test_GlideIE():
	video_glide_ie = GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:28:59.429095
# Unit test for constructor of class GlideIE
def test_GlideIE():
    "Construct GlideIE object"
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:00.954325
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie is not None


# Generated at 2022-06-24 12:29:02.049437
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Object creation
    obj = GlideIE()

# Generated at 2022-06-24 12:29:13.457829
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._vali_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert GlideIE._vali_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=")
    assert GlideIE._vali_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w")
    assert not GlideIE._vali_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=+")

# Generated at 2022-06-24 12:29:20.710914
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global my_test_GlideIE
    from __main__ import my_test_GlideIE
    my_test_GlideIE = GlideIE()
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    my_test_GlideIE.suitable(test_url)
    my_test_GlideIE.extract(test_url)

# Generated at 2022-06-24 12:29:25.570954
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glideIE = GlideIE()
    assert(glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert("Video clips and self-recorded videos" in glideIE.__doc__)


# Generated at 2022-06-24 12:29:27.013568
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Test to make sure that the class is not empty

# Generated at 2022-06-24 12:29:36.040664
# Unit test for constructor of class GlideIE
def test_GlideIE():
    res=GlideIE()._real_extract(GlideIE._TEST['url'])

# Generated at 2022-06-24 12:29:38.080767
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie.IE_NAME

# Generated at 2022-06-24 12:29:47.593859
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE().IE_DESC == "Glide mobile video messages (glide.me)"
	assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:49.248935
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:29:54.916690
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    try:
        GlideIE()
    except Exception as e:
        assert(False, "Test class GlideIE failed ---> " + str(e))

# Generated at 2022-06-24 12:30:03.486675
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Test case of class GlideIE
    '''
    import sys
    import os
    import tempfile
    import shutil
    
    assert(sys.version_info >= (3,0))
    
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    

# Generated at 2022-06-24 12:30:07.420143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Run the unit test
    gie_unit_test = GlideIE()
    assert gie_unit_test._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert gie_unit_test.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:30:13.315704
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_\+]+)'

# Generated at 2022-06-24 12:30:14.336130
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # TODO

# Generated at 2022-06-24 12:30:16.936648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("Glide mobile video messages (glide.me)", "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:30:19.656417
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract(r'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:30:20.886989
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:21.522736
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:25.068865
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit test for constructor of class GlideIE
    obj = GlideIE()
    # Validate that public an protected members are created
    assert (obj._match_id(obj._VALID_URL) is not None)
    assert (obj._real_extract is not None)

# Generated at 2022-06-24 12:30:26.924193
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of class GlideIE
    import GlideIE
    x = GlideIE.GlideIE()

# Generated at 2022-06-24 12:30:27.977172
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE().IE_DESC, unicode)

# Generated at 2022-06-24 12:30:32.025846
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_NAME == 'glide'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:34.401574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test GlideIE constructor."""

    url_obj = GlideIE(u'url')
    assert url_obj.ie_key() == 'Glide'

# Generated at 2022-06-24 12:30:35.972401
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert issubclass(GlideIE, InfoExtractor)


# Generated at 2022-06-24 12:30:41.393437
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://www.youtube.com/user/CBS')
    assert ie.IE_NAME == 'Glide'
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:30:43.664245
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    assert ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:30:44.220333
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:51.780184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:30:54.211733
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Testing constructor class GlideIE.
    """
    ie_obj = InfoExtractor(GlideIE)
    assert ie_obj.ie_key() == 'Glide'

# Generated at 2022-06-24 12:30:57.213552
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Basic test for constructor of class GlideIE
    """
    glide = GlideIE("123")
    assert glide.IE_NAME == 'glide'

# Generated at 2022-06-24 12:31:01.593822
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "GlideIE"
    assert ie.IE_SHORT_NAME == "GlideIE"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"



# Generated at 2022-06-24 12:31:04.628032
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # testing simple case
    # works well
    GlideIE(None)._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:31:13.995039
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global glideIE
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:15.634568
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test GlideIE
    """
    instance = GlideIE()
    instance.extract('')

# Generated at 2022-06-24 12:31:17.570425
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE()


# Generated at 2022-06-24 12:31:25.916389
# Unit test for constructor of class GlideIE
def test_GlideIE():
    content = "Damon's Glide message: http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    extractor = GlideIE()
    res = extractor.extract(content)

    assert(res[0]['url'] == "http://media.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==-low.mp4")
    assert(res[0]['id'] == "UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:31:28.690286
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor)._VALID_URL == GlideIE._VALID_URL
    assert GlideIE(InfoExtractor)._TEST == GlideIE._TEST
    assert GlideIE(InfoExtractor).IE_DESC == GlideIE.IE_DESC

# Generated at 2022-06-24 12:31:35.341968
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = GlideIE()
    assert infoExtractor.IE_NAME == 'glide'
    assert infoExtractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert infoExtractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert infoExtractor._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert infoExtractor._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:31:39.872945
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()
    assert info._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert info.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:42.031303
# Unit test for constructor of class GlideIE
def test_GlideIE():
	try:
		glide_ie = GlideIE()
	except AttributeError:
		glide_ie = None
	assert glide_ie

# Generated at 2022-06-24 12:31:46.204091
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inputUrl = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    expected = GlideIE(inputUrl, None)
    print(expected)

# Generated at 2022-06-24 12:31:47.227481
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:31:49.401197
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:31:53.830669
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:57.432428
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Asserts that a GlideIE instance can be created"""
    # Instantiates a GliDE Information Extractor
    glide_ie = GlideIE();
    # Asserts that the class of the instance is GlideIE
    assert glide_ie.__class__ == GlideIE;

# Generated at 2022-06-24 12:31:59.661824
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:07.128907
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE(GlideIE(), 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    output = test_GlideIE._real_extract('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:32:08.472367
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().ie_key() == 'Glide'

# Generated at 2022-06-24 12:32:09.752436
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of GlideIE
    from . import GlideIE
    GlideIE()

# Generated at 2022-06-24 12:32:18.049800
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE(None).IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:25.494106
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    #assert glide_ie.url == 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_ie.valid_url()
    

# Generated at 2022-06-24 12:32:27.328549
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj_GlideIE = GlideIE()

# Generated at 2022-06-24 12:32:33.350838
# Unit test for constructor of class GlideIE
def test_GlideIE():
	from class_GlideIE import GlideIE
	from urlparse import urlparse
	glide = GlideIE()
	url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	result = urlparse(url)
	assert result.netloc == 'share.glide.me'


# Generated at 2022-06-24 12:32:34.768916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:32:35.938394
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert isinstance(instance, GlideIE)

# Generated at 2022-06-24 12:32:36.423044
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:39.611105
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiate the object by class GlideIE
    object_GlideIE = GlideIE();
    # Check if the object is a GlideIE
    assert (isinstance(object_GlideIE, GlideIE));

# Generated at 2022-06-24 12:32:43.214282
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert (ie.extract('https://share.glide.me/nj9oFID0QJ2Ck-ERpoOe4w==') is not None)
    assert (ie.extract('https://share.glide.me/') is None)

# Generated at 2022-06-24 12:32:47.132855
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:47.915002
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-24 12:32:52.877290
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:55.745184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideie = GlideIE()
    glideie.IE_NAME
    glideie.IE_DESC
    glideie._VALID_URL

# Generated at 2022-06-24 12:32:56.760012
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None, None)

# Generated at 2022-06-24 12:33:05.688699
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    url = 'http://share.glide.me/%s' % video_id

# Generated at 2022-06-24 12:33:08.632915
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_DESC
    assert instance._VALID_URL
    assert instance._TEST

# Generated at 2022-06-24 12:33:18.885742
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:19.704178
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:33:23.166562
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE(InfoExtractor())
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:32.401818
# Unit test for constructor of class GlideIE
def test_GlideIE():
    r = GlideIE(0)
    assert r.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert r._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:37.001542
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/([A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:33:46.298438
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(
        "Unit test for GlideIE starts"
    )
    test_GlideIE = GlideIE()
    video_id = test_GlideIE._match_id(
        "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    )
    print(
        "GlideIE constructor: video_id: {video_id}".format(
            video_id=video_id
        )
    )
    print(
        "Unit test for GlideIE ends"
    )
    return video_id


# Generated at 2022-06-24 12:33:49.001258
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:33:49.578319
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-24 12:33:53.747575
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:33:56.533566
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test non-existing URL first
    GlideIE('http://glide.me/s/i9X0c/')
    GlideIE('https://share.glide.me/qTtTzvbSRbiWd9Xtsh3q1Q==')

# Generated at 2022-06-24 12:33:58.452834
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import GlideIE
    ie = GlideIE()
    assert ie.IE_DESC== 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:59.344144
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-24 12:34:02.096522
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # test the constructor class
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:34:03.750394
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
        assert True
    except Exception:
        assert False



# Generated at 2022-06-24 12:34:07.897551
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    testUrl = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:13.264877
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE(GlideIE.ie_key())
    assert g.IE_NAME == 'Glide'
    assert g.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:14.402046
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE()


# Generated at 2022-06-24 12:34:16.453692
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    glideIE = GlideIE()
    assert glideIE.ie_key() == 'Glide'

# Generated at 2022-06-24 12:34:25.959893
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # test if the test file has been loaded correctly by comparing the number of
    # properties.
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
   

# Generated at 2022-06-24 12:34:31.152550
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:37.731033
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w')
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w?')
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w/')

# Generated at 2022-06-24 12:34:43.393237
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test with a proper URL
    try:
        GlideIE(url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    except AssertionError:
        assert False, "Test with a proper URL failed"

    # Test with a wrong URL
    try:
        GlideIE(url = "http://ftp.heanet.ie/mirrors/ftp.gimp.org/pub/www//gimp/win32/")
        assert False, "Test with a wrong URL failed"
    except:
        pass

# Generated at 2022-06-24 12:34:53.500418
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:54.070410
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:55.702770
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance  = GlideIE()
    test_GlideIE.__name__ = "test GlideIE"
    return instance

# Generated at 2022-06-24 12:35:04.579362
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert instance._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert instance._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:35:10.749397
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert obj._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['info_dict']['ext'] == 'mp4'
    assert obj._TEST['info_dict']['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:35:12.491633
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:35:13.086432
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:14.034173
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:35:22.736739
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:35:25.876219
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
        assert True
    except:
        assert False


# Generated at 2022-06-24 12:35:36.939828
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:37.734064
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE()

# Generated at 2022-06-24 12:35:46.161855
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # first ensure class GlideIE is defined
    ie = InfoExtractor.get_info_extractor('GlideIE')

    # test video url
    video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    actual_video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='

    # test regex and method _real_extract

# Generated at 2022-06-24 12:35:56.501565
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # first test with non-http URL
    assert ie.url_result('share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', ie.ie_key()) is None
    # url is valid but not share.glide.me, so this should be invalid
    assert ie.url_result('http://google.com', ie.ie_key()) is None
    # now test with valid GlideIE URL
    assert ie.url_result('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', ie.ie_key()) is not None
    # now test with https

# Generated at 2022-06-24 12:35:57.979521
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:36:03.620782
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')
	assert(GlideIE.IE_NAME == 'Glide')
	assert(GlideIE.IE_SHORT_NAME == 'glide')
	assert(GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:36:11.283541
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    info_dict = ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert 'UZF8zlmuQbe4mr+7dCiQ0w==' == info_dict.get('id')
    assert 'Damon\'s Glide message' == info_dict.get('title')
    assert r'^https://.*?\.cloudfront\.net/.*\.jpg$' == info_dict.get('thumbnail')
    assert r'^http.*?\.mp4' == info_dict.get('url')

# Generated at 2022-06-24 12:36:20.494956
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from GlideIE import GlideIE
    from nose.tools import assert_equal

    IE = GlideIE()
    assert_equal(IE.IE_NAME, 'Glide')
    assert_equal(IE.IE_DESC, 'Glide mobile video messages (glide.me)')
    assert_equal(IE._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:36:21.860721
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None, None)



# Generated at 2022-06-24 12:36:23.867162
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE({"1": GlideIE}).ie_key() == 'Glide'

# Generated at 2022-06-24 12:36:31.798940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:41.794517
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'