

# Generated at 2022-06-24 12:26:47.810406
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert i.ie_key()=="Glide"
    assert i.ie_desc()=="Glide mobile video messages (glide.me)"
    assert i._VALID_URL=="https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert i._TEST['url']=="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert i._TEST['md5']=="4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-24 12:26:51.102392
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie is not None

# Generated at 2022-06-24 12:26:52.984916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for constructor of class GlideIE.
    # Make sure the object has been created successfully.
    glide_ie = GlideIE()
    pass

# Generated at 2022-06-24 12:26:54.950795
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:27:06.390987
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # pylint: disable = protected-access
    GlideIE._TEST = {}
    GlideIE(InfoExtractor())._download_webpage = lambda *args, **kwargs: (b'<title>Glide</title>', None)
    GlideIE(InfoExtractor())._download_webpage = lambda *args, **kwargs: (b'<title>Title</title>', None)
    GlideIE(InfoExtractor())._download_webpage = lambda *args, **kwargs: (b'<title>Title</title>', None)
    GlideIE(InfoExtractor())._download_webpage = lambda *args, **kwargs: (b'<title>Title</title>', None)

# Generated at 2022-06-24 12:27:12.836244
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE(None)
    assert info._TEST == {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }


# Generated at 2022-06-24 12:27:14.228624
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Constructor test"""
    GlideIE()


# Generated at 2022-06-24 12:27:22.167842
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == u'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Test TEST dictionary
    assert 'url' in ie._TEST
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert 'md5' in ie._TEST
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert 'info_dict' in ie._TEST
    assert 'id' in ie._T

# Generated at 2022-06-24 12:27:28.837713
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Unit test for constructor of class GlideIE """
    glide_ie = GlideIE()

    # When IE name provided is Glide,
    # Then class should be initialized successfully
    try:
        assert glide_ie != None
    except AssertionError:
        print("AssertionError raised when trying to initialize GlideIE")
        raise


# Generated at 2022-06-24 12:27:31.541743
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception as exception:
        import sys
        print(exception)
        sys.exit(-1)


# Generated at 2022-06-24 12:27:32.522055
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://youtube.com')

# Generated at 2022-06-24 12:27:33.091772
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:27:36.476048
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:40.376450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:27:44.085323
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # constructor without any arguments
    ie = GlideIE()
    # check if it is an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)
    # check if it is registered
    assert ie.ie_key() in InfoExtractor._ies

# Generated at 2022-06-24 12:27:45.310450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:27:50.558872
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(downloader=None)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    # Unit test for method GlideIE._real_extract(self, url)
    assert ie._real_extract(None) == {}

# Generated at 2022-06-24 12:27:53.371736
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:00.145127
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:28:03.470391
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('', {}, {})
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:28:13.877564
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Verify if class name is the same as the one given by the metaclass
    assert (GlideIE.__name__ == 'GlideIE'), 'Class name defined incorrectly'

    #Testing GlideIE.IE_DESC
    actual_desc = GlideIE.IE_DESC
    expected_desc = 'Glide mobile video messages (glide.me)'
    assert (actual_desc == expected_desc), 'Description of GlideIE is not properly set'

    #Testing GlideIE._VALID_URL
    valid_url = GlideIE._VALID_URL
    expected_valid_url = (r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:28:16.461228
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE(GlideIE._downloader, GlideIE._TEST['url'])
    assert inst._WORKING == True

# Generated at 2022-06-24 12:28:18.166879
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:19.124712
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# TODO implement test
	pass

# Generated at 2022-06-24 12:28:21.290962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:28:22.213432
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert issubclass(GlideIE, InfoExtractor)

# Generated at 2022-06-24 12:28:24.376279
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_desc = ie.IE_DESC
    assert ie_desc == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:28:25.011240
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:29.850978
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_name = ie.__class__.__name__
    if ie_name == 'GlideIE':
        print("%s constructor() - pass\n" % ie_name)
    else:
        print("%s constructor() - fail\n" % ie_name)


# Generated at 2022-06-24 12:28:32.769455
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except AssertionError:
        pass
    else:
        raise AssertionError("Unit test for constructor of class GlideIE failed")


# Generated at 2022-06-24 12:28:34.286354
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Unit test for constructor of class GlideIE. """
    video = GlideIE()
    print(video)

# Generated at 2022-06-24 12:28:40.345848
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # example url: http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE().extract(url)
    # test video URL and title extraction
    GlideIE().extract(url)
    # example for broken video URL and missing title
    GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w')

# Generated at 2022-06-24 12:28:41.124497
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:41.969791
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(GlideIE)

# Generated at 2022-06-24 12:28:44.453974
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC.encode('utf-8') == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:28:52.975229
# Unit test for constructor of class GlideIE
def test_GlideIE():
    "Test constructor of class GlideIE."
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-24 12:28:53.960879
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE() is not None

# Generated at 2022-06-24 12:29:01.950232
# Unit test for constructor of class GlideIE
def test_GlideIE():
    response = requests.get('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie = GlideIE('glide.me', 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.extractor_key == 'GlideIE'
    # assert ie.content == response.content


# Generated at 2022-06-24 12:29:06.617926
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    x = GlideIE().match(url)
    assert x != None
    

# Generated at 2022-06-24 12:29:09.508954
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._real_extract(url)

# Generated at 2022-06-24 12:29:10.855630
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test for class GlideIE"""
    GlideIE()



# Generated at 2022-06-24 12:29:22.656017
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(None)
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:23.232806
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:29:28.755634
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:29:36.484109
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for class GlideIE
    print("testcase for GlideIE")
    # Test case for class GlideIE
    test_case = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    # Actual test of class GlideIE
    glide_ie = GlideIE()

# Generated at 2022-06-24 12:29:41.127492
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:42.086801
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # TODO
    pass

# Generated at 2022-06-24 12:29:43.013166
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE().extract('')

# Generated at 2022-06-24 12:29:48.071751
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Test for the main function _real_extract
    GlideIE._real_extract(obj, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:29:54.914964
# Unit test for constructor of class GlideIE
def test_GlideIE():
  glide_url = "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
  glide = GlideIE()
  # Check if url is valid
  assert (glide._VALID_URL in glide_url)
  assert (glide.suitable(glide_url))
  # Check if there is a description.
  assert (glide.IE_DESC)


# Generated at 2022-06-24 12:29:56.073338
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:30:04.134369
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video_id = ie._match_id(url)
    webpage = ie._download_webpage(url, video_id)
    title = ie._html_search_regex(r'<title>(.+?)</title>', webpage, 'title', default=None) or ie._og_search_title(webpage)
    video_url = ie._proto_relative_url(ie._search_regex(r'<source[^>]+src=(["\'])(?P<url>.+?)\1', webpage, 'video URL', default=None, group='url')) or ie._og_search_video_url(webpage)
    thumbnail = ie._

# Generated at 2022-06-24 12:30:11.465995
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:15.429156
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # When creating GlideIE object it should first use
    # given _VALID_URL
    ie = GlideIE(GlideIE._VALID_URL)

    # Then it should extract ID from this url
    assert ie._match_id(GlideIE._VALID_URL) == GlideIE._TEST['url']

# Generated at 2022-06-24 12:30:16.389056
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()



# Generated at 2022-06-24 12:30:27.095410
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
        raise AssertionError("GlideIE object created for invalid url.")
    except AssertionError as e:
        print("[Pal.sp.GlideIE]: 1st: %s" % e)
    try:
        GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    except AssertionError as e:
        raise AssertionError("[Pal.sp.GlideIE]: 2nd: %s" % e)

# Generated at 2022-06-24 12:30:28.896686
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:30:29.452852
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE()

# Generated at 2022-06-24 12:30:31.094865
# Unit test for constructor of class GlideIE
def test_GlideIE():
    _test_ie_constructor(lambda *args, **kwargs: GlideIE(*args, **kwargs))

# Generated at 2022-06-24 12:30:33.822666
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert glideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:36.532245
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:30:37.396504
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Test Constructor
    GlideIE()

# Generated at 2022-06-24 12:30:40.160672
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import GlideIE

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:30:41.560709
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__name__ == 'GlideIE'


# Generated at 2022-06-24 12:30:44.175218
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:30:51.751496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ieClass = GlideIE('https://share.glide.me/aBcDeFgHiJkLmNoPqRsTuWvXyZ12345+6-7=8')
    ieObject = ieClass.getResult()
    if ieObject['id'] != 'aBcDeFgHiJkLmNoPqRsTuWvXyZ12345+6-7=8':
        raise AssertionError('Wrong id ' + ieObject['id'])
    if ieObject['url'] != 'https://share.glide.me/aBcDeFgHiJkLmNoPqRsTuWvXyZ12345+6-7=8':
        raise AssertionError('Wrong url ' + ieObject['url'])
    if ieObject['title'] != None:
        raise

# Generated at 2022-06-24 12:30:52.343521
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE().download

# Generated at 2022-06-24 12:30:54.065962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Constructor test for class GlideIE"""
    glide = GlideIE()
    print(glide)

# Generated at 2022-06-24 12:30:56.279500
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        assert False, 'IE is not constructed'

# Generated at 2022-06-24 12:30:57.213808
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()



# Generated at 2022-06-24 12:31:02.239691
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # To test the constructor you need
    # to define the object
    test = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Assert there are no errors in the constructor
    assert test


# Generated at 2022-06-24 12:31:03.182757
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:04.482064
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:31:05.354623
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE()

# Generated at 2022-06-24 12:31:14.313192
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = GlideIE()
    assert infoExtractor.IE_DESC == "Glide mobile video messages (glide.me)"
    assert infoExtractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:15.009824
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = GlideIE()
    pass

# Generated at 2022-06-24 12:31:17.642475
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == "Glide"

# Generated at 2022-06-24 12:31:21.759039
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
#test for _real_extract function

# Generated at 2022-06-24 12:31:27.506762
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('abc')
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie.IE_DESC == GlideIE.IE_DESC
    assert ie._downloader == None
    assert ie.IE_NAME == 'glide:glide'
    assert ie.ie_key() == 'Glide'
    assert ie.ie_key() in ie._DOWNLOAD_IINFO
    assert ie._type == 'video'


# Generated at 2022-06-24 12:31:29.990247
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC and ie.IE_DESC.strip()
    assert ie.VALID_URL and ie.VALID_URL.strip()

# Generated at 2022-06-24 12:31:32.538327
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.urls
    ie.md5_sums
    ie.get_info()

# Generated at 2022-06-24 12:31:32.964886
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:38.890328
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor.YOUTUBE_IE_KEY, InfoExtractor.YOUTUBE_API_KEY)
    assert GlideIE(InfoExtractor.YOUTUBE_IE_KEY, InfoExtractor.YOUTUBE_API_KEY)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:42.653090
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_video = GlideIE()
    assert glide_video._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:53.042877
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:03.213008
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:03.598046
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert True

# Generated at 2022-06-24 12:32:12.378957
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:14.352549
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None).assertRaisesRegex(ValueError, 'Invalid Glide URL', 'http://www.google.com')

# Generated at 2022-06-24 12:32:17.095463
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert bool(GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')) is True
    assert bool(GlideIE.suitable('http://share.glide.me/')) is False

# Generated at 2022-06-24 12:32:19.334702
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:32:20.664165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().ie_key() == 'Glide'

# Generated at 2022-06-24 12:32:29.165599
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test for GlideIE"""
    glide_ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert type(glide_ie._VALID_URL) == unicode
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._TEST.has_key('url')
    assert glide_ie._TEST.has_key('md5')
    assert glide_ie._TEST.has_key('info_dict')

# Generated at 2022-06-24 12:32:33.245181
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert hasattr(GlideIE, 'IE_NAME')
    assert hasattr(GlideIE, '_VALID_URL')
    assert hasattr(GlideIE, 'extract')
    assert hasattr(GlideIE, '_real_extract')

# Generated at 2022-06-24 12:32:35.682747
# Unit test for constructor of class GlideIE
def test_GlideIE():
  ie = GlideIE()
  assert len(ie._TESTS) == 1
  assert ie.IE_NAME == "glide"

# Generated at 2022-06-24 12:32:39.144833
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages'
    ie._VALID_URL = r'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:32:41.052662
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('abc')
    assert ie.RE_ID_MATCH == GlideIE._VALID_URL



# Generated at 2022-06-24 12:32:42.294182
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor(''))


# Generated at 2022-06-24 12:32:46.488807
# Unit test for constructor of class GlideIE
def test_GlideIE():
    expected_results = GlideIE._TEST
    url = expected_results['url']
    glideIE = GlideIE(info_dict=None)
    assert glideIE.suitable(url)
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:32:50.424810
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ieObj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ieObj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ieObj.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:32:57.494496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        # Create an instance of GlideIE
        glide = GlideIE()
        print("glide is an instance of GlideIE")

        # Create an instance of InfoExtractor
        info_extractor = InfoExtractor()
        print("info_extractor is an instance of InfoExtractor")
    except:
        print("Something went wrong")

# Call to the function "test_GlideIE"
test_GlideIE()

# Generated at 2022-06-24 12:32:57.847332
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:33:02.771018
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This test checks video properties and also if there is any video
    # on the video URL.
    g = GlideIE()
    d = g._real_extract(g._TEST['url'])
    d1 = {}
    for key, value in g._TEST['info_dict'].items():
        d1[key] = d[key]
    assert d1 == g._TEST['info_dict']

# Generated at 2022-06-24 12:33:06.064680
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:17.115294
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE().try_download_and_decode('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert len(ie) > 0
    assert ie['url'] == "https://d1opms6zj7jotq.cloudfront.net/production/21f04213-5ee3-4c8e-a5cb-26f4d065baed.mp4"
    assert ie['thumbnail'] == "https://d2w1k97jkwo5pz.cloudfront.net/production/21f04213-5ee3-4c8e-a5cb-26f4d065baed.jpg"
    assert ie['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:33:20.715533
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not GlideIE.suitable('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w')

# Generated at 2022-06-24 12:33:30.756202
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # If a constructor is called with all required arguments and
    # the arguments are of the expected types and values,
    # create_and_get_info_extractor() will return an instance of the
    # information extractor it creates, otherwise it will return None.
    # Here we test if an instance of GlideIE is successfully created.
    ie = InfoExtractor.create_and_get_info_extractor('GlideIE', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(ie, GlideIE)

    # If the constructor is called with any argument of the wrong type
    # or with an argument of the right type with a value that is
    # out of range of the allowed values,
    # create_and_get_info_extractor() will

# Generated at 2022-06-24 12:33:34.124962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert extractor is not None
    assert extractor.IE_DESC.startswith('Glide mobile video messages (glide.me)')



# Generated at 2022-06-24 12:33:38.959334
# Unit test for constructor of class GlideIE
def test_GlideIE():
	c = GlideIE()
	#c._real_extract("https://share.glide.me/KjJKTMLeSQG0MWYJlT-Tdw==")

# Generated at 2022-06-24 12:33:49.058665
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:52.117679
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:55.219666
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    ID = ie._match_id(url)

# Generated at 2022-06-24 12:34:01.626293
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert video._match_id("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert video._download_webpage("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==","UZF8zlmuQbe4mr+7dCiQ0w==") != None

# Generated at 2022-06-24 12:34:06.445802
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This is a bad way to test GlideIE
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE(url)
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:34:13.914580
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # TODO: improve this test
    obj = GlideIE()
    print (obj)

    # Test the Glide sample video
    obj = GlideIE(u'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print (obj.get_video_url())

    url = obj.get_video_url()
    print (obj.get_video_md5(url))


if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:34:15.369007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test that the class GlideIE could be created"""
    GlideIE()

# Generated at 2022-06-24 12:34:19.847380
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:22.694698
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:34:24.395457
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_DESC == "Glide mobile video messages (glide.me)"


# Generated at 2022-06-24 12:34:26.734036
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("GlideIE","Glide mobile video messages (glide.me)")

# Generated at 2022-06-24 12:34:28.726145
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create an instance of class GlideIE
    glide_ie = GlideIE()

#Unit test for GlideIE._real_extract

# Generated at 2022-06-24 12:34:31.057926
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("Glide")
    assert ie.ie_key() == "Glide"

# Generated at 2022-06-24 12:34:40.070538
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiate the class, which automatically finds the information
    # required for using the extractor.
    extractor = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    extractor.initialize()

    # Extract and return a list of information about the video.
    info = extractor.extract(extractor.url)
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['ext'] == 'mp4'
    assert info['title'] == u"Damon's Glide message"

# Generated at 2022-06-24 12:34:43.898610
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create instance of class GlideIE
    glide_ie = GlideIE()

    # Test if instance created correctly
    assert isinstance(glide_ie, GlideIE)

# Generated at 2022-06-24 12:34:46.389022
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('glide')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:34:56.117817
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# The url and IE is as defined in the class above.
	info_extractor = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

	# info() is a method of InfoExtractor class.
	# It returns a list of dictionaries, each of which contain information about the video.
	# Extract the dictionary corresponding to the first video (video_id = 'UZF8zlmuQbe4mr+7dCiQ0w==').
	# It is a dictionary with keys ['id', 'title', 'url', 'thumbnail']
	# Thumbnail is just a url to the thumbnail image.
	# The url is the url to the video file to be downloaded.
	video_info = info_extractor.info()[0]

# Generated at 2022-06-24 12:34:57.374150
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    #print obj.get_class_type()


# Generated at 2022-06-24 12:35:02.315182
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/Glide1')
    assert ie
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:35:03.761889
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        raise


# Generated at 2022-06-24 12:35:09.249217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE()
    assert a.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert a._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert a._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert a._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'


# Generated at 2022-06-24 12:35:19.350702
# Unit test for constructor of class GlideIE
def test_GlideIE():
    m = GlideIE()
    assert m.IE_NAME == 'Glide.me'
    assert m.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert m.VALID_URL == GlideIE._VALID_URL
    test = m._TEST

# Generated at 2022-06-24 12:35:30.882476
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Initialize and extract Glide."""
    
    # Input
    url = "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    
    # Expected Output
    expected_title = "Damon's Glide message"
    expected_url = "https://d1wdrzvo7tcrjh.cloudfront.net/videos/UZF8zlmuQbe4mr+7dCiQ0w==.mp4"
    expected_thumbnail = "https://d1wdrzvo7tcrjh.cloudfront.net/pics/UZF8zlmuQbe4mr+7dCiQ0w==.jpg"
    
    # Class instantiation
    glide_ie = GlideIE()
    
    # Actual

# Generated at 2022-06-24 12:35:35.513892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Make sure that all the inheritance is happening
    assert GlideIE.__base__ == InfoExtractor
    # Make sure that the IE is initializing without any errors
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:35:41.164317
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:35:46.757153
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test GlideIE constructor
    glide_ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(glide_ie._VALID_URL)
    print(glide_ie._TEST)
    # test GlideIE constructor

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:35:47.997409
# Unit test for constructor of class GlideIE
def test_GlideIE():
    c = GlideIE()
    c._real_extract()

# Generated at 2022-06-24 12:35:51.709479
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"


# Generated at 2022-06-24 12:35:53.495147
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    ie = GlideIE()
    ie._real_extract(ie._TEST['url'])
    ie = GlideIE(InfoExtractor._downloader)
    ie._real_extract(ie._TEST['url'])

# Generated at 2022-06-24 12:35:57.165991
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:59.645137
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')



# Generated at 2022-06-24 12:36:02.064978
# Unit test for constructor of class GlideIE
def test_GlideIE():
    InfoExtractor.test_Video_mobj(GlideIE, 'http://www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:36:08.719530
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This unit test tests both the constructor of class GlideIE and the method
    _real_extract by comparing its output (info_dict) to the expected output.
    """
    expected_info_dict = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }

    info_dict = GlideIE()._real_extract(
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    assert expected_info_dict == info_dict

# Generated at 2022-06-24 12:36:10.318423
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:36:12.361319
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert_true(ie is not None)


# Generated at 2022-06-24 12:36:16.652688
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# The GlideIE constructor has no arguments, but since the purpose of this test is to check if
	# the constructor is being called, let's instantiate the class and then delete it.
	_ = GlideIE() # noqa: F841
	del GlideIE

# Generated at 2022-06-24 12:36:18.799432
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Testing constructor of class GlideIE
    obj = GlideIE()
    assert not obj is None

# Generated at 2022-06-24 12:36:27.612916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie._VALID_URL == GlideIE._VALID_URL)
    print("PASS: _VALID_URL checked out")
    assert(ie._TEST == GlideIE._TEST)
    print("PASS: _TEST checked out")
    assert(ie.IE_DESC == GlideIE.IE_DESC)
    print("PASS: IE_DESC checked out")

    # Test for extractor
    ie._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    print("PASS: _real_extract checked out")

test_GlideIE()

# Generated at 2022-06-24 12:36:29.954024
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:36:31.112245
# Unit test for constructor of class GlideIE
def test_GlideIE():
  assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-24 12:36:33.917270
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE(unicode)
    except TypeError as e:
        return
    raise Exception('invalid type: {0}'.format(type(unicode)))

# Generated at 2022-06-24 12:36:43.075481
# Unit test for constructor of class GlideIE