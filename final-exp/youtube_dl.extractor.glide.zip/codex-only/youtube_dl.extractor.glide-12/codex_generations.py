

# Generated at 2022-06-24 12:26:43.704532
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor should not raise any exception
    GlideIE()

# Generated at 2022-06-24 12:26:44.174741
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:26:46.959275
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit Object creation test__init__() function"""
    ie = GlideIE()
    assert ie.name == ie.IE_NAME
    assert ie.ie_key() == ie.IE_NAME.lower()
    assert ie.search_key_re() == ie.IE_NAME.lower()
    assert ie.ie_desc() == ie.IE_DESC



# Generated at 2022-06-24 12:26:53.236110
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

    #Test _TEST['info_dict']

# Generated at 2022-06-24 12:26:53.930808
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert True

# Generated at 2022-06-24 12:26:55.612514
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    test.test()

# Generated at 2022-06-24 12:27:03.482864
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case = GlideIE._TEST

    actual = GlideIE()._real_extract(test_case['url'], test_case['md5'])
    assert actual['id'] == test_case['info_dict']['id']
    assert actual['title'] == test_case['info_dict']['title']
    assert actual['url'] == test_case['info_dict']['url']
    assert actual['thumbnail'] == test_case['info_dict']['thumbnail']

# Generated at 2022-06-24 12:27:04.935487
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.ie_key() == 'glide'

# Generated at 2022-06-24 12:27:09.737219
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.ie_key() == 'Glide'
    assert GlideIE.ie_key(GlideIE._VALID_URL) == 'Glide'
    assert GlideIE.ie_key('') != 'Glide'
    assert GlideIE.extractor(GlideIE._VALID_URL) == GlideIE
    assert GlideIE.extractor('') != GlideIE

# Generated at 2022-06-24 12:27:13.453939
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Purpose:
    Verify fields of class GlideIE.
    """
    glide = GlideIE()

    assert isinstance(glide._VALID_URL, basestring)
    assert isinstance(glide._TEST, dict)
    assert isinstance(glide._TEST['url'], basestring)
    assert isinstance(glide._TEST['md5'], basestring)
    assert isinstance(glide._TEST['info_dict'], dict)

# Generated at 2022-06-24 12:27:15.178303
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(None, None)
    assert isinstance(obj, GlideIE)

# Generated at 2022-06-24 12:27:17.569639
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:27:23.794064
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import re
    import copy

    # Constructor test
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert isinstance(ie._VALID_URL, (str, unicode))
    assert isinstance(ie._VALID_URL, (str, unicode))

    # File test
    import os.path

    test_file = os.path.join('test', 'test.mp4')

    # Unit tests for _match_id()

# Generated at 2022-06-24 12:27:26.788188
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:37.343901
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._download_webpage = lambda url: url
    ie._og_search_title = lambda text: 'Title'
    ie._og_search_video_url = lambda text: 'http://example.com/video.mp4'
    ie._og_search_thumbnail = lambda text: 'http://example.com/image.jpg'

    # valid_url with valid video_id
    valid_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    data = ie._real_extract(valid_url)
    assert data['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert data['title'] == 'Title'

# Generated at 2022-06-24 12:27:48.462059
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests that __init__ inherited from InfoExtractor returns a GlideIE object with the right properties
    ie = GlideIE()
    # Checks for a GlideIE object
    assert ie.__class__.__name__ == 'GlideIE'
    # Checks for the class attributes of ie
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)' # Checks that the attribute _VALID_URL has the correct value

# Generated at 2022-06-24 12:27:59.588644
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:08.753272
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of class GlideIE
    # Test case 1
    # Test constructor without any options
    info_extractor = GlideIE()
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert info_extractor._NETRC_MACHINE == 'glide'
    # Test case 2
    # Test constructor with options
    # Assign option '_VALID_URL' with a regex string
    regex_str = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Assign option '_NETRC_MACHINE' with a string
    machine = 'glide'
    # Create an

# Generated at 2022-06-24 12:28:10.884747
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'glide'

# Generated at 2022-06-24 12:28:17.095004
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Test cases
    GlideIE._TEST = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

# Generated at 2022-06-24 12:28:27.120400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-24 12:28:36.307163
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:42.083972
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)' 

# Generated at 2022-06-24 12:28:47.450664
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True
    assert GlideIE.IE_NAME == 'glide'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE.IE_VERSION == '1.2.1'


# Generated at 2022-06-24 12:28:49.397131
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Ensure correct instantiation of GlideIE().
    # Call assert true to verify that the constructor does not fail.
    assert (True)

# Generated at 2022-06-24 12:28:51.377945
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:29:01.431306
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # See http://pyunit.sourceforge.net/pyunit.html
    # for a description of basic unit test syntax
    # with python

    # The constructor for the class to be tested,
    # needs to be tested
    gIE = GlideIE('')
    # The dictionary returned by the
    # _extract_url method
    # needs to be tested
    dictExtracted = gIE._extract_url(
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    # Tests
    # The type of the returned dictionary
    # must be dict
    assert type(dictExtracted) is dict
    # dictExtracted must contain the key 'id'
    assert 'id' in dictExtracted.keys()
    # dictExtracted must contain the key

# Generated at 2022-06-24 12:29:08.596117
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE.IE_DESC is not None, 'Scraper class is not inherited'
	assert GlideIE.IE_DESC is not None, 'Scraper name constant is not set'
	Scraper = GlideIE()
	assert Scraper.IE_DESC is not None, 'IE_DESC class attribute is not set'
	assert Scraper.IE_DESC is not None, 'IE_DESC class attribute is not set'

# Generated at 2022-06-24 12:29:14.985864
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Url given by the developer in the comment of the link bellow
    # https://github.com/rg3/youtube-dl/pull/3228/commits/c6a14d6f117b496eaccd8a8afcc7c80b48de22d4
    url = 'http://share.glide.me/X5C5xQxrww+r5bHB1aLO1g=='
    GlideIE()._real_extract(url)

# Generated at 2022-06-24 12:29:25.793070
# Unit test for constructor of class GlideIE
def test_GlideIE():

    glide_ie = GlideIE()
    glide_ie.extractor = "video.glide.me" # setting explicit extractor value

# Generated at 2022-06-24 12:29:30.884804
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)._download_webpage(
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:29:31.659902
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print(ie)

# Generated at 2022-06-24 12:29:35.007375
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE('url', True, True, True)
    expected_glide = 'glide'
    actual_glide = class_.IE_NAME
    assert actual_glide == expected_glide

# Generated at 2022-06-24 12:29:35.556354
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:29:45.856844
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:29:48.934351
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    ie.extract()

# Generated at 2022-06-24 12:30:00.063717
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    assert test_GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert test_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:01.743730
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:30:09.365866
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-24 12:30:19.398849
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()

# Generated at 2022-06-24 12:30:28.958231
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:32.267888
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ig = GlideIE()
    assert ig.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ig._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:33.190354
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:30:41.276192
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE
    instance_GlideIE = class_()
    assert isinstance(instance_GlideIE, InfoExtractor)
    # Test the constructor of class GlideIE
    test_GlideIE_no_params = class_()
    assert isinstance(test_GlideIE_no_params, InfoExtractor)
    test_GlideIE_empty_params = class_(dict())
    assert isinstance(test_GlideIE_empty_params, InfoExtractor)

# Generated at 2022-06-24 12:30:43.198442
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, GlideIE)


# Generated at 2022-06-24 12:30:50.777170
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for video with video file name stored in a JavaScript variable
    GlideIE(None)._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    # Test for video with video file name stored in property 'og:video'
    GlideIE(None)._real_extract('http://share.glide.me/k-lk4s2Qi2BzG4e_TtiS')

    # Test for video with video file name stored in property 'og:video:secure_url'
    GlideIE(None)._real_extract('http://share.glide.me/o5G5eCk8QcaY5YhgsZVu1g==')

# Generated at 2022-06-24 12:30:51.237350
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:52.984648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:57.561298
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:30:58.753217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:31:09.892284
# Unit test for constructor of class GlideIE
def test_GlideIE():

	# Sample URL used to test GlideIE as a constructor.
	url1 = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	url2 = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

	# Expected values when using URL1 and URL2.
	expected1_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
	expected2_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='

	# Setting the expected values for class GlideIE when URL1 is used.
	ie1 = GlideIE(expected1_id)
	ie1.url = url1

	# Extract

# Generated at 2022-06-24 12:31:12.260533
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)

    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:13.606245
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Confirm that GlideIE returns class instance
    assert isinstance(GlideIE(), InfoExtractor)


# Generated at 2022-06-24 12:31:16.972638
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit test for GlideIE.__init__
    assert GlideIE.__doc__ is not None

    # Unit test for GlideIE._real_extract()
    extractor = GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')
    assert extractor.test() == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:31:26.934966
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie.valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not ie.valid_url('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not ie.valid_url('http://notshare.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not ie.valid_url('http://share.glide.me/')

# Generated at 2022-06-24 12:31:27.714814
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:34.472418
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert obj._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['info_dict']['ext'] == 'mp4'
    assert obj._TEST['info_dict']['title'] == "Damon's Glide message"
    assert obj._

# Generated at 2022-06-24 12:31:35.762568
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:40.466308
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:51.590060
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE(InfoExtractor)
	assert ie.IE_NAME == "glide"
	assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
	assert "glide.me" in ie._VALID_URL

# Generated at 2022-06-24 12:31:55.064312
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', {})

# Generated at 2022-06-24 12:31:57.889735
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.ws.run_until_complete(ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='))

# Generated at 2022-06-24 12:31:58.509823
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None);
    assert True;

# Generated at 2022-06-24 12:31:59.475888
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:32:03.295752
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:05.808279
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE();
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	print('Test for class GlideIE is passed')


# Generated at 2022-06-24 12:32:14.757541
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:21.353805
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:33.432328
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert g._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert g._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert g._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert g._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:32:38.117834
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    id = ie._match_id(url)
    assert id == 'UZF8zlmuQbe4mr+7dCiQ0w=='

#test_GlideIE()

# Generated at 2022-06-24 12:32:46.733963
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global assert_raises
    assert_raises = getattr(__builtins__, '__import__')('pytest').raises

    # Check instance with single exception
    glide = GlideIE()
    assert_raises(TypeError, glide.extract, 'https://www.glide.me')
    assert_raises(TypeError, glide.extract, 'https://www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert_raises(TypeError, glide.extract, 'https://www.glide.me/video/UZF8zlmuQbe4mr+7dCiQ0w==')

    # Check instance with multiple exceptions
    glide = GlideIE()

# Generated at 2022-06-24 12:32:48.165003
# Unit test for constructor of class GlideIE
def test_GlideIE():
	unitTest = GlideIE()

if __name__ == '__main__':
	test_GlideIE()

# Generated at 2022-06-24 12:32:49.860173
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'


# Generated at 2022-06-24 12:32:53.733969
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:54.856903
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:32:56.007962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:57.184143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE
    instance = class_()
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:01.883444
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert(instance.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(instance.__name__ == "GlideIE")
    assert(instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:33:05.308002
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    web_page = t._download_webpage(url, "UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:33:10.482891
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glide_ie = GlideIE()
    assert(glide_ie.IE_NAME == "glide")
    assert(glide_ie.IE_DESC == "Glide mobile video messages (glide.me)")


# Generated at 2022-06-24 12:33:20.137860
# Unit test for constructor of class GlideIE
def test_GlideIE():
    videoURL = "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    video_id = videoURL[videoURL.rfind('/')+1:]
    title = "Damon's Glide message"

    assert(GlideIE(downloader = None)._match_id(videoURL) == video_id)
    assert(GlideIE(downloader = None)._match_id('randomUrl') is None)
    assert(GlideIE(downloader = None)._proto_relative_url('https://randomUrl') == None)
    assert(GlideIE(downloader = None)._proto_relative_url('//randomUrl') == 'randomUrl')

# Generated at 2022-06-24 12:33:25.380421
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME == "glide"
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE._VALID_URL == r'^https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)$'



# Generated at 2022-06-24 12:33:26.305534
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE is not None

# Generated at 2022-06-24 12:33:27.227753
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE is not None

# Generated at 2022-06-24 12:33:27.792194
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:33:28.849332
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("2")


# Generated at 2022-06-24 12:33:31.125818
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie.IE_NAME
    ie.VERSION
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-24 12:33:42.496840
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.is_suitable("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # NOTE: this test currently fails, because the video requires an API key,
    # which is not shipped with the test, see https://github.com/rg3/youtube-dl/issues/6684#issuecomment-240790677
    # but the URL is valid and have content
#    ie.download("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:33:45.091279
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import GlideIE
    test_object = GlideIE.GlideIE()

# Generated at 2022-06-24 12:33:45.996626
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()

# Generated at 2022-06-24 12:33:47.861617
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
        assert False
    except TypeError:
        pass

# Generated at 2022-06-24 12:33:49.666448
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC ==  'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:50.412927
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('GlideIE')
    ie.extract()

# Generated at 2022-06-24 12:33:52.435036
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Check for basic initialization
    ie = GlideIE()
    assert ie != None
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:34:01.589331
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Setup
    import pytest
    import re

    # Act
    ie = GlideIE()

    # Assert
    assert ie._VALID_URL == re.compile(r'(?i)(?:https?:)?//share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:34:09.068894
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:34:09.625221
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:10.709483
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(object)

# Generated at 2022-06-24 12:34:20.750657
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:34:23.567163
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:30.621889
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert len(obj.IE_DESC) > 0
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert obj._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['info_dict']['ext'] == 'mp4'
   

# Generated at 2022-06-24 12:34:32.588143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    GlideIE("title", "video_url", "thumbnail", "video_id")

# Generated at 2022-06-24 12:34:39.198230
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:44.500923
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('glide', {})
    assert ie.ie_key() == 'glide'
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:34:54.141369
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test for constructor of class GlideIE"""
    # Test on a video that is public
    video = GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert video['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert video['url'] == 'http://cdn.glide.me/glide/UZF8zlmuQbe4mr+7dCiQ0w==/UZF8zlmuQbe4mr+7dCiQ0w==.mp4'
    assert video['title'] == 'Damon\'s Glide message'

# Generated at 2022-06-24 12:34:55.744280
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == ie.ie_key() == 'glide'

# Generated at 2022-06-24 12:34:59.897150
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test to test the GlideIE constructor
    """
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_VERSION == '0.0.1'

# Generated at 2022-06-24 12:35:07.567047
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(ie._VALID_URL)
    print(ie._TEST['url'])
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:35:09.399050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Initialize class
    GlideIE()

# Generated at 2022-06-24 12:35:11.033819
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test if can initialize
    GlideIE()

# Generated at 2022-06-24 12:35:20.303074
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:21.997748
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:35:25.694839
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:35:28.148651
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE()._VALID_URL == "https?://share.glide.me/(?P<id>[A-Za-z0-9\-=_+]+)")

# Generated at 2022-06-24 12:35:32.699364
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("")
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-24 12:35:34.397596
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL

# Generated at 2022-06-24 12:35:34.978092
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:35:43.105023
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test with require_title=True
    assert GlideIE(require_title=True)._TEST == (
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        '4466372687352851af2d131cfaa8a4c7',
        {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    )

# Generated at 2022-06-24 12:35:45.056287
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).IE_NAME == 'glide'

# Generated at 2022-06-24 12:35:47.667334
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ieClass = GlideIE
    x = ieClass("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(x.__class__ == GlideIE)

# Generated at 2022-06-24 12:35:57.785857
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:36:07.001518
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://www.glide.me', {})
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:10.907378
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:12.709956
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert(test.IE_DESC)


# Generated at 2022-06-24 12:36:19.817018
# Unit test for constructor of class GlideIE
def test_GlideIE():
    { 'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'info_dict': {'ext': 'mp4', 'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$', 'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'title': "Damon's Glide message" }, 'params': {'skip_download': True}, 'md5': '4466372687352851af2d131cfaa8a4c7' }

# Generated at 2022-06-24 12:36:27.737903
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Basic test: instantiate GlideIE and fetch first video.

    This is a basic unit test with a purpose to not let GlideIE class
    constructor break.
    """
    video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video_ids = [
        'UZF8zlmuQbe4mr+7dCiQ0w==',
    ]
    for video_id in video_ids:
        ie = GlideIE()
        ie.extract(video_url)
        assert ie.extract_videos(video_url)

# Generated at 2022-06-24 12:36:30.586576
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # These tests don't need network or disk access, but should still
    # raise useful errors if the unit test is run accidentally with
    # the wrong python interpreter.
    GlideIE()
    assert True

# Generated at 2022-06-24 12:36:40.991972
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:43.551050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    t = type(ie)
    assert t.__name__ == 'GlideIE'
