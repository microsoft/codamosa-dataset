

# Generated at 2022-06-24 12:26:39.215184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:26:44.282519
# Unit test for constructor of class GlideIE
def test_GlideIE():
    unit_test = GlideIE(GlideIE.ie_key(), 'GlideIE', 'Glide mobile video messages (glide.me)', False)
    try:
        assert unit_test.ie_key() == 'GlideIE'
        assert unit_test.ie_desc() == 'Glide mobile video messages (glide.me)'
        assert unit_test.working() == False
    except AssertionError:
        print(AssertionError)


# Generated at 2022-06-24 12:26:44.730833
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:26:47.759498
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie._TEST['url'] == ie.url


# Generated at 2022-06-24 12:26:58.116809
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Simple unit test for GlideIE
    """
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    tests = ie._TEST.values()
    assert tests[0] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert tests[1] == '4466372687352851af2d131cfaa8a4c7'
    assert tests[2]['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
   

# Generated at 2022-06-24 12:27:01.279069
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Checks if class GlideIE can be instantiated
	ie = GlideIE('http://url.com/')
	assert ie is not None

# Generated at 2022-06-24 12:27:03.068497
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.__name__ == "GlideIE")



# Generated at 2022-06-24 12:27:11.759292
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE("EqKjm0+m1gQVQxXs3qMV8A==")._real_extract("http://share.glide.me/EqKjm0+m1gQVQxXs3qMV8A==")["url"] == "https://v-sec.glide.me/vod/EqKjm0%2Bm1gQVQxXs3qMV8A%3D%3D/1559490287905/media_file.mp4")

# Generated at 2022-06-24 12:27:20.741008
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.test_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.test_url('http://share.glide.me/jK1IxE2sQsZ_BXE=')
    assert ie.test_url('http://share.glide.me/0T3bst23PpOZDei_')
    assert ie.test_url('http://share.glide.me/0T3bst23PpOZDei_')
    assert ie.test_url('http://share.glide.me/jK1IxE2sQsZ_BXE=')

# Generated at 2022-06-24 12:27:27.973531
# Unit test for constructor of class GlideIE
def test_GlideIE():
	'''
		test_GlideIE takes a GlideIE object, and download this video.
		Then check if the downloaded file is mp4 or not.
		Finally if the file extension is mp4, print 'pass' and delete the file, or print 'fail'.
	'''
	extractor_test = GlideIE()
	extractor_test.download(extractor_test.url)

# Generated at 2022-06-24 12:27:28.837543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('youtube')

# Generated at 2022-06-24 12:27:31.541760
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    return

    test_object = GlideIE()
    assert test_object is not None
    return



# Generated at 2022-06-24 12:27:36.595517
# Unit test for constructor of class GlideIE
def test_GlideIE():
    object = GlideIE(params={'VideoID': 10, 'Title': 'Test'}, url='http://www.youtube.com/watch?v=BaW_jenozKc')
    assert object.params['VideoID'] == 10 and object.params['Title'] == 'Test' and object.url == 'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-24 12:27:40.782895
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:27:50.282693
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .test_main_tools import random_string
    video_id = random_string(50)
    video_url = 'http://share.glide.me/' + video_id
    tester = GlideIE(None)
    assert tester.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert tester._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert tester.IE_NAME == 'Glide'
    assert tester.IE_SHORT_NAME == 'Glide'

# Generated at 2022-06-24 12:27:52.065416
# Unit test for constructor of class GlideIE
def test_GlideIE():
    toTest = GlideIE()
    assert(type(toTest) is not None)

# Generated at 2022-06-24 12:27:53.269104
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
# Unit test ends here

# Generated at 2022-06-24 12:27:56.721174
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()(url)

# Generated at 2022-06-24 12:27:58.122549
# Unit test for constructor of class GlideIE
def test_GlideIE():  
    GlideIE("Unit test for constructor of class GlideIE")

# Generated at 2022-06-24 12:28:02.887231
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE({})
    assert class_
    assert class_.IE_NAME == "Glide"
    assert class_.IE_DESC == "Glide mobile video messages (glide.me)"
    assert class_.VALID_URL == GlideIE._VALID_URL
    assert class_.TEST == GlideIE._TEST

# Generated at 2022-06-24 12:28:03.843551
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert ie is not None

# Generated at 2022-06-24 12:28:06.986867
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:10.052910
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Tests string comparison GlideIE class constructor
    """
    # condition for class GlideIE
    ie = GlideIE()
    ie_desc = ie.IE_DESC
    ie_desc_true = "Glide mobile video messages (glide.me)"

    # assert statement for class GlideIE
    assert ie_desc == ie_desc_true

# Generated at 2022-06-24 12:28:15.790593
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    # test one valid URL
    video = ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert video is not None

    # test one invalid URL
    assert ie.extract('http://share.glide.me/foo') is None

# Generated at 2022-06-24 12:28:25.440974
# Unit test for constructor of class GlideIE
def test_GlideIE():
    filename, ie_data = GlideIE().get_data('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert filename == "Damon's Glide message.mp4"
    assert ie_data['id'] == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie_data['title'] == "Damon's Glide message"
    assert ie_data['url'] == "http://glb-s3-us-east-1-serving.glb.prod.media.aws.glb.prod.glideme.com/video/UZF8zlmuQbe4mr+7dCiQ0w==.mp4"

# Generated at 2022-06-24 12:28:27.520267
# Unit test for constructor of class GlideIE
def test_GlideIE():
        assert GlideIE(GlideIE.ie_key())==GlideIE(GlideIE.ie_key())

# Generated at 2022-06-24 12:28:28.086219
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:29.588711
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ins = GlideIE()
	assert (ins != None)

# Generated at 2022-06-24 12:28:38.615948
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:42.574758
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # To verify the constructor of class GlideIE, we
    # can test to pass correct url parameter and see if instance
    # of class GlideIE is returned. If it is not an instance of class
    # GlideIE, then we can conclude that the constructor is not working
    # as expected.
    assert isinstance(GlideIE('http://test'), GlideIE)

# Generated at 2022-06-24 12:28:51.111876
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Unit test description'
    print("Class constructor:")
    print("    IE_DESC: {}".format(ie.IE_DESC))
    print("    IE_NAME: {}".format(ie.IE_NAME))
    print("    _VALID_URL: {}".format(ie._VALID_URL))
    print("    _TEST: {}".format(ie._TEST))
    url = ie._TEST['url']
    print("    url: {}".format(url))
    print("    video_id: {}\n".format(ie._match_id(url)))

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:28:53.435679
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test(GlideIE, [
            'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='])

# Generated at 2022-06-24 12:28:56.193896
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST

# Generated at 2022-06-24 12:28:57.420397
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(True)

# Generated at 2022-06-24 12:28:58.699178
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    test.IE_DESC

# Generated at 2022-06-24 12:29:06.666812
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:29:07.641263
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:29:10.501771
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).get_testcases()[-1]['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:29:12.784393
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    # Assert that GlideIE is an instance of InfoExtractor.
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:29:13.406433
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:29:15.382926
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from pytube import YouTube
    assert type(YouTube(GlideIE._TEST['url'])) == YouTube

# Generated at 2022-06-24 12:29:26.076488
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = InfoExtractor.extract_info(r'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', None, GlideIE.IE_NAME)
    assert result['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert result['url'] == 'https://d1vxzfl6dq1mjg.cloudfront.net/2016/05/05/UZF8zlmuQbe4mr+7dCiQ0w==.mp4'
    assert result['title'] == 'Damon&#39;s Glide message'

# Generated at 2022-06-24 12:29:30.414198
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:29:31.382481
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__name__ == 'GlideIE'


# Generated at 2022-06-24 12:29:32.121062
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE({})



# Generated at 2022-06-24 12:29:43.235042
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:44.155152
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:29:45.441650
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._SUCCESS == 'SUCCESS'

# Generated at 2022-06-24 12:29:50.404846
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:29:54.716530
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testGlideIE = GlideIE(None)
    assert testGlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:29:55.304155
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:29:55.956898
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:00.761640
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor(GlideIE)
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:30:08.416986
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['info_dict']['ext'] == 'mp4'
    assert GlideIE._TEST['info_dict']['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:30:14.095351
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:30:14.672444
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-24 12:30:25.480803
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:34.269245
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create object class GlideIE
    test_ie = GlideIE()
    assert test_ie.IE_NAME == 'glide' # Property IE_NAME should be 'glide'
    assert test_ie.IE_DESC == 'Glide mobile video messages (glide.me)' # Property IE_DESC should be 'Glide mobile video messages (glide.me)'
    assert test_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)' # Property _VALID_URL should be 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:44.942906
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:30:52.692761
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import make_test

# Generated at 2022-06-24 12:30:55.246162
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:31:00.574166
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Sample URL from http://glide.me/
    sample_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    # Constructor
    ie = GlideIE(sample_url)
    # Information extraction
    assert ie.extract() == ie._TEST

# Generated at 2022-06-24 12:31:03.849181
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:31:07.147567
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert x is not None

# Generated at 2022-06-24 12:31:15.102292
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test video URL
    video_URL = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    # Initialize GlideIE class with all dependent variables
    glide_IE = GlideIE({})

    # Extract the video URL from the webpage of Glide
    info_dict = glide_IE._real_extract(video_URL)

    # Assert that the video URL is extracted correctly

# Generated at 2022-06-24 12:31:15.734026
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass


# Generated at 2022-06-24 12:31:19.072561
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:31:20.474525
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-24 12:31:21.896605
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import GenericIE
    GenericIE("Glide")

# Generated at 2022-06-24 12:31:30.631894
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:40.804212
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._TEST = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

# Generated at 2022-06-24 12:31:43.018575
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test GlideIE constructor."""
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:31:48.091808
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.VALID_URL == GlideIE._VALID_URL
    assert ie.TEST == GlideIE._TEST

# Generated at 2022-06-24 12:31:48.671468
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-24 12:31:49.278273
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert True

# Generated at 2022-06-24 12:31:49.874690
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie

# Generated at 2022-06-24 12:31:57.883413
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    if ie.IE_DESC != "Glide mobile video messages (glide.me)":
        print("IE_DESC")
        return False
    if ie._VALID_URL != r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)':
        print("_VALID_URL")
        return False
    if ie._TEST['url'] != "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==":
        print("_TEST['url']")
        return False

# Generated at 2022-06-24 12:31:58.288549
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:06.471665
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Test class GlideIE
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

    # Test member function extract_from_webpage()
    test_result = ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    assert test_result['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert test_result['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:32:10.638094
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share.glide.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:12.050137
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:32:19.684372
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:24.881912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:27.586928
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE._real_extract(GlideIE(), "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:32:28.839195
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-24 12:32:31.660695
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from . import GlideIE
    print(GlideIE)

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:32:32.721784
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE(InfoExtractor()))

# Generated at 2022-06-24 12:32:36.837961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert GlideIE.IE_NAME == 'glide'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE.IE_KEY == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:45.603202
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''A unit test for the setUp method in the GlideIE class.
    '''
    # Create an instance of the GlideIE class
    glide_ie = GlideIE()

    # Create an instance of the InfoExtractor class
    info_extractor = InfoExtractor("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

    # Check if the instance variables are initialised correctly
    assert glide_ie.SUFFIX == ""
    assert glide_ie.IE_NAME == "glide:share"
    assert glide_ie.IE_DESC == "Glide mobile video messages"

# Generated at 2022-06-24 12:32:46.935218
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert isinstance(obj,GlideIE)

# Generated at 2022-06-24 12:32:48.023232
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gl = GlideIE('glide', )
    assert gl

# Generated at 2022-06-24 12:32:59.248824
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE_DESC = 'Glide mobile video messages (glide.me)'
    VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:04.616435
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == 'glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj.REQUESTS_HEADERS is not None
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert len(obj._TESTS) == 1


# Generated at 2022-06-24 12:33:05.898525
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert type(extractor) is GlideIE

# Generated at 2022-06-24 12:33:09.797439
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
# End of unit test

# Generated at 2022-06-24 12:33:12.313149
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Construct a instance of GlideIE
    glideIE = GlideIE()
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:33:17.068012
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:19.465598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE(GlideIE.ie_key())
    assert glide_ie
    assert glide_ie._DOWNLOAD_WEBPAGE_HANDLE

# Generated at 2022-06-24 12:33:29.295075
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #There is no way to test without actual URLs, so if you call this function, it will print extracted data in form of dictionary
    extractor = GlideIE()
    #extractor.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    #extractor.extract("http://share.glide.me/v/56f81349e4b0b3c604bd03d9/56f92e5fe4b0a564864a5e5f/56f92e5fe4b0a564864a5e68")
    #extractor.extract("http://share.glide.me/v/56e2f7dfe4b07a0e089043eb/56e3093fe4b07a0e089

# Generated at 2022-06-24 12:33:31.245329
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    GlideIE should be created by class Glide
    """
    assert(GlideIE.IE_NAME == '%s' % 'Glide')

# Generated at 2022-06-24 12:33:43.233884
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:44.566419
# Unit test for constructor of class GlideIE
def test_GlideIE():
	instance = GlideIE()
	instance.create()

# Generated at 2022-06-24 12:33:46.299078
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE.ie_key())
    ie.IE_DESC

# Generated at 2022-06-24 12:33:49.488076
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # testing for GlideIE constructor
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
    # Unit test for _real_extract method of class GlideIE

# Generated at 2022-06-24 12:33:58.566464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    video = ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # check if class GlideIE will return a video with id 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert video['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # check if class GlideIE will return a video with title 'Damon's Glide message'
    assert video['title'] == 'Damon\'s Glide message'


# Generated at 2022-06-24 12:34:07.472216
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert test_obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:10.938115
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert x.IE_DESC == 'Glide mobile videomessages'

# Generated at 2022-06-24 12:34:17.645626
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, 'IE_DESC')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert hasattr(ie, '_TEST')


# Generated at 2022-06-24 12:34:26.729913
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Test case to check if the class constructor is setting the variables correctly
    '''
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:34:28.008038
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    extractor = ie._real_extract

# Generated at 2022-06-24 12:34:28.951239
# Unit test for constructor of class GlideIE
def test_GlideIE():
    InfoExtractor("GlideIE","")

# Generated at 2022-06-24 12:34:33.675018
# Unit test for constructor of class GlideIE
def test_GlideIE():
	from __main__ import GlideIE
	ei_obj = GlideIE(GlideIE.ie_key())
	assert ei_obj.ie_key() == 'Glide'
	assert ei_obj.IE_NAME == 'Glide'
	assert ei_obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:34:40.336353
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Testing constructor of class GlideIE
    """
    ie = GlideIE(GlideIE._VALID_URL,GlideIE._TEST)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:34:44.079561
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST


# Generated at 2022-06-24 12:34:48.065042
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Constructor test
    """
    glide_ie = GlideIE('http://www.glide.me/video/unique_id')
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:34:51.979263
# Unit test for constructor of class GlideIE
def test_GlideIE():
    res = GlideIE()
    assert res.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert res._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:52.929945
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:34:54.512466
# Unit test for constructor of class GlideIE
def test_GlideIE():
    TestGlideIE = GlideIE(InfoExtractor)
    TestGlideIE.suite()

# Generated at 2022-06-24 12:34:57.827751
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == GlideIE.IE_DESC
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST

# Generated at 2022-06-24 12:35:00.323268
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:03.211538
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gl = GlideIE()
    assert gl._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:03.900532
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    

# Generated at 2022-06-24 12:35:07.391846
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:12.490850
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    test_instance = GlideIE()
    assert test_instance._VALID_URL == "https?://share.glide.me/(?P<id>[A-Za-z0-9\-=_+]+)"


# Generated at 2022-06-24 12:35:21.523264
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor with URL as a parameter
    # Return a GlideIE with video_id as None
    assert GlideIE(GlideIE.ie_key()) == GlideIE(GlideIE.ie_key(), None, None, None, None)
    # Return a GlideIE with video_id as url
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE(GlideIE.ie_key(), url) == GlideIE(GlideIE.ie_key(), url, None, None, None)
    # Return a GlideIE with video_id as url and video_url as url

# Generated at 2022-06-24 12:35:27.008827
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:35:29.015090
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:35:30.644259
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://www.glide.me/video/bob')

# Generated at 2022-06-24 12:35:33.660233
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    assert hasattr(IE, '_VALID_URL')

# Generated at 2022-06-24 12:35:34.792201
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:36.009139
# Unit test for constructor of class GlideIE
def test_GlideIE():
    list_extractor = GlideIE()

# Generated at 2022-06-24 12:35:37.685537
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    GlideIE()

# Generated at 2022-06-24 12:35:41.411888
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:35:46.019710
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:35:48.260220
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    GlideIE(url)

# Generated at 2022-06-24 12:35:58.249600
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
   #assert ie.URL_PATTERNS == [r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)']
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:58.805081
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:36:00.995002
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:36:07.223617
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE(GlideIE.IE_DESC)
    IE.options = {'extract_flat': True, 'extract_flat_skip': True}
    IE.exclude = [r'http://something.com', r'http://something2.com']
    IE.url = r'http://something3.com'
    IE.params = {'height': 123, 'width': 456}
    IE.headers = {'User-Agent': 'Custom user agent'}
    IE.extract(r'http://something4.com')



# Generated at 2022-06-24 12:36:18.120491
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Note that the URL below is not a valid Glide video URL
    # I just use it to test the regex function of "IE_DESC"
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:19.224345
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    
    

# Generated at 2022-06-24 12:36:28.690718
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext']

# Generated at 2022-06-24 12:36:31.398263
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:41.569245
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE(None).IE_DESC == "Glide mobile video messages (glide.me)")
    assert(GlideIE(None)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')