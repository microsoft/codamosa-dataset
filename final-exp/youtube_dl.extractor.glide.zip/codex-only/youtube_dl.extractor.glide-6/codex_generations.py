

# Generated at 2022-06-24 12:26:40.930192
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.initialize()

# Generated at 2022-06-24 12:26:52.756060
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test for constructor of GlideIE class
    """
    glide_ie_test = GlideIE()
    assert glide_ie_test._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie_test.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie_test._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_ie_test._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'



# Generated at 2022-06-24 12:26:53.850246
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# What is the purpose of this part?
# I will look up the unit testing of python.

# Generated at 2022-06-24 12:26:57.113747
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = InfoExtractor()
    assert info_extractor.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True

# Generated at 2022-06-24 12:27:03.179052
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# test_GlideIE()

# Generated at 2022-06-24 12:27:05.406069
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:06.778085
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    print(type(obj))


# Generated at 2022-06-24 12:27:09.047851
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:27:13.800149
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.ie_key() == 'Glide'
    assert GlideIE.ie_key('url') == 'Glide'
    assert GlideIE.ie_key('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'Glide'

# Generated at 2022-06-24 12:27:15.090298
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Initialize the instance
    GlideIE()

# Generated at 2022-06-24 12:27:22.657858
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE(None)
    assert x.IE_DESC == "Glide mobile video messages (glide.me)"
    assert x._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:24.802504
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:26.247840
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE('test').IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:27:31.859999
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Initialize an object of class GlideIE
    glideie = GlideIE(None)

    # Test properties of class GlideIE
    assert glideie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glideie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:33.999369
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE.IE_DESC)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:27:37.757382
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert isinstance(glideIE, GlideIE)
    assert glideIE.IE_NAME == "GlideIE"
    assert glideIE.IE_DESC == "Glide mobile video messages (glide.me)"



# Generated at 2022-06-24 12:27:41.391867
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj is not None

# Generated at 2022-06-24 12:27:43.045619
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(issubclass(GlideIE, InfoExtractor))

# Generated at 2022-06-24 12:27:46.354898
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL is not None
    assert GlideIE._TEST is not None
    assert GlideIE.IE_DESC is not None
    assert GlideIE.__name__ is not None

# Generated at 2022-06-24 12:27:52.153153
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import test_details
    from .common import test_ie
    import random
    import string
    import urllib2
    url = 'http://share.glide.me/U'
    url += ''.join(random.choice(string.ascii_uppercase + string.digits +
                                 string.ascii_lowercase) for _ in range(12))
    url += '=='
    ie = test_ie(GlideIE)
    try:
        details = test_details(ie, url)
    except urllib2.HTTPError:
        assert False

# Generated at 2022-06-24 12:27:55.898556
# Unit test for constructor of class GlideIE
def test_GlideIE():
    exp = GlideIE()
    assert(exp.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(exp._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-24 12:28:02.749530
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==' == ie._url

# Generated at 2022-06-24 12:28:03.305266
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:04.014419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:28:06.823181
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL
    assert ie.IE_DESC
    assert ie._TEST

# Generated at 2022-06-24 12:28:13.816111
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie=GlideIE()
    ie2=InfoExtractor()
    assert ie.IE_NAME=='glide'
    assert ie.IE_DESC=='Glide mobile video messages (glide.me)'
    assert ie.VALID_URL==r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.TEST['url']=='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.TEST['md5']=='4466372687352851af2d131cfaa8a4c7'
    assert ie2.IE_NAME!='glide'

# Generated at 2022-06-24 12:28:17.861652
# Unit test for constructor of class GlideIE
def test_GlideIE():
    d = object()
    g = GlideIE(d)
    assert g.ie_key() == 'Glide'
    assert g.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert g._downloader is d


# Generated at 2022-06-24 12:28:18.514149
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE

# Generated at 2022-06-24 12:28:19.085388
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-24 12:28:22.302554
# Unit test for constructor of class GlideIE
def test_GlideIE():
    sample_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(sample_url)._real_extract(sample_url)

# Generated at 2022-06-24 12:28:32.512142
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(_print_debug=False)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:40.415898
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Testing is successful when no assertion fails
    assert (GlideIE(InfoExtractor._downloader)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert (GlideIE(InfoExtractor._downloader).IE_DESC == 'Glide mobile video messages (glide.me)')
    assert (GlideIE(InfoExtractor._downloader)._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert (GlideIE(InfoExtractor._downloader)._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')

# Generated at 2022-06-24 12:28:46.279320
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE

    # Basic test with known URL
    assert ie()._match_id(ie._TEST['url']).startswith('UZF8zlmuQbe4mr')

    # Test URL with invalid ID
    assert not ie()._match_id('http://share.glide.me/')

    # Test URL with extra things after the ID
    assert ie()._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==something-else') == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:28:46.662255
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:28:51.830123
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Tests for constructor of class GlideIE."""
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:52.760732
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-24 12:29:03.259067
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert glideIE.IE_NAME == 'glide'
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:14.646743
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert GlideIE._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-24 12:29:15.661480
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:29:26.256099
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:30.227228
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        a = GlideIE()
    except Exception as e:
        print ("Failed to instantiate GlideIE")
        raise(e)


# Generated at 2022-06-24 12:29:40.548460
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    assert glideIE.IE_NAME == 'Glide'
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glideIE.URL_REGEX == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:29:46.663499
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test with a valid URL
    valid_url = GlideIE._TEST['url']
    valid_extractor = GlideIE(GlideIE())
    assert valid_extractor.suitable(valid_url)
    assert GlideIE.suitable(valid_url)

    # Test with a bad URL
    invalid_url = 'https://bad.url.com'
    invalid_extractor = GlideIE(GlideIE())
    assert not invalid_extractor.suitable(invalid_url)

# Generated at 2022-06-24 12:29:47.818840
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE
    except:
        raise

# Generated at 2022-06-24 12:29:52.886576
# Unit test for constructor of class GlideIE
def test_GlideIE():
	""" Unit test for GlideIE """
	from ytdl.extractors import GlideIE
	y = GlideIE(True)
	if y == None:
		print('Error: cannot initialize GlideIE class')
		exit(1)
	else:
		print('Success: GlideIE class was initialized')


# Generated at 2022-06-24 12:30:01.487965
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # These are not valid GlideIE links.
    invalid_links = [
        'http://glide.me/',
        'http://glide.me/c/b/6/',
        'https://glide.me/#!/get-glide',
    ]
    for invalid_link in invalid_links:
        assert not GlideIE.suitable(invalid_link)
    # These links are valid
    valid_links = [
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==']
    for valid_link in valid_links:
        assert GlideIE.suitable(valid_link)

# Generated at 2022-06-24 12:30:02.421091
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE() # constructor of class GlideIE

# Generated at 2022-06-24 12:30:02.984952
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:04.547023
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie_object = GlideIE();

# Generated at 2022-06-24 12:30:05.434337
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();



# Generated at 2022-06-24 12:30:07.605722
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:30:09.821433
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(InfoExtractor())
    ie.IE_DESC = "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:30:10.813378
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # A simple test case
    assert GlideIE({})

# Generated at 2022-06-24 12:30:21.717858
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:22.333679
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:27.167897
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    expected_url = 'http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D'
    assert expected_url == ie._download_webpage(url, None)

# Generated at 2022-06-24 12:30:28.230251
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:30:29.113805
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:30:35.221325
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # check for abstract class
    from pytube.compat import unicode

    obj=GlideIE(unicode('http://www.youtube.com/watch?v=BaW_jenozKc'), 'youtube')
    #assert isinstance(obj.url, unicode)
    assert obj.ie_key() == 'Glide'
    assert obj.video_id == 'BaW_jenozKc'


if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-24 12:30:45.395337
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert g._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:46.519115
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC
    assert GlideIE._VALID_URL
    assert GlideIE._TEST

# Generated at 2022-06-24 12:30:55.248619
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test initial constructor with static method.
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:58.381220
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:30:59.632017
# Unit test for constructor of class GlideIE
def test_GlideIE():
    muster = GlideIE()

# Generated at 2022-06-24 12:31:00.236652
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:01.220487
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:02.240312
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:03.891874
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:04.484815
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert True

# Generated at 2022-06-24 12:31:05.355539
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:31:08.909694
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""

    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==';
    ie = GlideIE()
    ie.match(url);

# Generated at 2022-06-24 12:31:12.452536
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE()
    assert a._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert a.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:18.837986
# Unit test for constructor of class GlideIE
def test_GlideIE():
    InfoExtractor.get_info(url="http://share.glide.me/f_dI_wfg+YzJQcx8M+ihFA==")
    GlideIE.suitable(url="http://share.glide.me/f_dI_wfg+YzJQcx8M+ihFA==")
    InfoExtractor.get_info(url="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    GlideIE.suitable(url="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:31:21.941658
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Unit test for constructor of class GlideIE """
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:26.342070
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert(glide.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-24 12:31:27.616758
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except NameError:
        pass

# Generated at 2022-06-24 12:31:28.439897
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:31:33.137466
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    print(glideIE)
    print(glideIE.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='))

# Generated at 2022-06-24 12:31:34.429955
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:31:35.757713
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-24 12:31:36.629043
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide_ie = GlideIE()
	assert glide_ie is not None

# Generated at 2022-06-24 12:31:37.036023
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:37.761678
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE, "GlideIE class does not exist"


# Generated at 2022-06-24 12:31:42.700960
# Unit test for constructor of class GlideIE
def test_GlideIE():
    with InfoExtractor() as ie:
        assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
        assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
        

# Generated at 2022-06-24 12:31:53.081875
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url= 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glideIE= GlideIE()
    assert glideIE._VALID_URL==r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glideIE.IE_DESC=='Glide mobile video messages (glide.me)'
    assert glideIE._VALID_URL==r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glideIE._download_webpage(url, video_id=None)

# Generated at 2022-06-24 12:31:53.567912
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:56.672584
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert t._regex_matches(t._VALID_URL, url) is not None

# Generated at 2022-06-24 12:32:04.721553
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert glide._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:32:05.215335
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:14.105004
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glide_ie = GlideIE(url)
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert glide_ie._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"
    assert glide_ie._

# Generated at 2022-06-24 12:32:14.913616
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE()
    assert a is not None

# Generated at 2022-06-24 12:32:15.694640
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:32:17.634638
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test normal constructor
    glide = GlideIE()
    # Test no args constructor. This can be removed when refactoring.
    GlideIE(glide)

# Generated at 2022-06-24 12:32:23.802987
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of class GlideIE
    # Create an object clip of class GlideIE
    clip = GlideIE()
    # Create an object url of class str
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Check if url is same as one of the url from _VALID_URL
    assert(url in clip._VALID_URL)


# Generated at 2022-06-24 12:32:26.904952
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:32:27.588684
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE()

# Generated at 2022-06-24 12:32:33.141455
# Unit test for constructor of class GlideIE
def test_GlideIE():
	_GlideIE = GlideIE()

	assert _GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert _GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:35.245208
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test the constructor of class GlideIE
    # It should not throw any exception
    GlideIE()

# Generated at 2022-06-24 12:32:44.017847
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # testing valid urls
    ie._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie._match_id('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # testing invalid urls
    assert ie._match_id('http://share.glide.me/UZF8z lmuQbe4mr+7dCiQ0w==') is None
    assert ie._match_id('http://share.glide.me/UZF8zlm&uQbe4mr+7dCiQ0w==') is None

# Generated at 2022-06-24 12:32:44.859537
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:46.212774
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    return obj

test = test_GlideIE()
print(test)

# Generated at 2022-06-24 12:32:47.080147
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:52.506029
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:56.257976
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:32:57.648378
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:32:59.387400
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:33:06.459821
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Negative test: Note the URL is missing glide
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE(url)
    assert(ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(ie._download_webpage.im_class == InfoExtractor)
    assert(ie._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie._real_extract != None)

# Generated at 2022-06-24 12:33:12.174820
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST == GlideIE._TEST
    assert ie._TESTS == [GlideIE._TEST]

# Generated at 2022-06-24 12:33:16.166437
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ''' Test the constructor of class GlideIE '''
    glide_ie = GlideIE()
    assert glide_ie.ie_key() == 'Glide'
    assert glide_ie.ie_desc() == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:20.573598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'glide'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:33:21.075806
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-24 12:33:27.876281
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor()
    GlideIE(ie)
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.suitable('http://glt.io/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not ie.suitable('http://share.glide.me/')
    assert not ie.suitable('http://glide.me/')

# Generated at 2022-06-24 12:33:28.932386
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL

# Generated at 2022-06-24 12:33:36.097200
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glideIE = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:42.160007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "https://tracker.glide.me/link/UZF8zlmuQbe4mr+7dCiQ0w==?s=UZF8zlmuQbe4mr+7dCiQ0w%3D%3D"
    ie.extract(url)

# Generated at 2022-06-24 12:33:43.721153
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor of class GlideIE is tested in common.py
    pass

# Generated at 2022-06-24 12:33:45.353943
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        glide_ie = GlideIE()
        print('GlideIE() is inialized')
    except Exception as err:
        print('Error during instancing: {0}'.format(err))


# Generated at 2022-06-24 12:33:51.732552
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide_ie = GlideIE()
	assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert glide_ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:52.300714
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:33:52.743278
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:33:55.240440
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == GlideIE.IE_DESC
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST

# Generated at 2022-06-24 12:33:55.754293
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:33:56.323169
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE

# Generated at 2022-06-24 12:34:00.148525
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:08.729649
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:09.711239
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()

# Generated at 2022-06-24 12:34:12.285730
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    assert GlideIE()._TEST == GlideIE._TEST


# Generated at 2022-06-24 12:34:22.376365
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiation of class GlideIE
    ie = GlideIE()
    # Declare url variable with url of video to download
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Call method _real_extract and store result in info dictionary
    info = ie._real_extract(url)
    # Check if the key 'title' is in the info dictionary
    assert 'title' in info
    # Check if the key 'id' is in the info dictionary
    assert 'id' in info
    # Check if the key 'thumbnail' is in the info dictionary
    assert 'thumbnail' in info
    # Check if the key 'url' is in the info dictionary
    assert 'url' in info
    # Check if the value for the key 'title

# Generated at 2022-06-24 12:34:25.239632
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # verify that the attributes of the instance ie are initialized as expected
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:34:32.125469
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()

# Generated at 2022-06-24 12:34:32.832980
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert type(GlideIE()) == GlideIE

# Generated at 2022-06-24 12:34:34.653980
# Unit test for constructor of class GlideIE
def test_GlideIE():
	try:
		G = GlideIE()
		print("Constructor of GlideIE")
	except:
		print("Constructor of GlideIE")


# Generated at 2022-06-24 12:34:40.982381
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:34:52.022018
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:54.647004
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(_initialize=False)
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:35:03.595781
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import unittest
    
    # Tests for _search_regex function
    class Test(unittest.TestCase):
    
        def test_regex(self):
            assert GlideIE()._search_regex(r'<title>(.*?)</title>', '<title>test text</title>', 'title') == 'test text'
            assert GlideIE()._search_regex(r'<title>(.*?)</title>', '<title>test text</title>', 'other than title') == None
            assert GlideIE()._search_regex(r'<title>(.*?)</title>', '<title>test text', 'title') == None # No </title>

# Generated at 2022-06-24 12:35:06.695469
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This is a unit test to ensure that the constructor of class GlideIE works properly.
    """
    ie = GlideIE()
    assert ie.IE_NAME == "glide"

# Generated at 2022-06-24 12:35:07.971066
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if GlideIE() is None:
        print("Error: instantiating GlideIE")

# Generated at 2022-06-24 12:35:12.307069
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:12.904263
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:14.568314
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    instance = isinstance(ie, InfoExtractor)
    assert instance == 1

# Generated at 2022-06-24 12:35:18.543031
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")


# Generated at 2022-06-24 12:35:29.563141
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:40.833448
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Basic unit test for class GlideIE"""

# Generated at 2022-06-24 12:35:49.374206
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(GlideIE._VALID_URL.match('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') != None)
	assert(GlideIE._VALID_URL.match('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') != None)
	assert(GlideIE._VALID_URL.match('http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==') != None)
	assert(GlideIE._VALID_URL.match('http://share.glide.me/UZF8zlmuQbe4mr_7dCiQ0w==') != None)

# Generated at 2022-06-24 12:35:52.194448
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GIE = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    GIE.extract()

# Generated at 2022-06-24 12:35:53.837328
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-24 12:35:58.975518
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:00.624054
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:36:05.722330
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE().get_info(r"http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="), dict)
    assert GlideIE().get_info(r"http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")["id"] == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:36:07.229691
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:36:09.034022
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE(None)
    assert x.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:36:15.796800
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE()._call_api(['http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='])
    assert video['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert video['title'] == 'Damon\'s Glide message'

# Generated at 2022-06-24 12:36:16.489917
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:36:17.207951
# Unit test for constructor of class GlideIE
def test_GlideIE():
	pass


# Generated at 2022-06-24 12:36:23.369085
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Basic unit test for GlideIE """
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # The following call is expected to succeed (no exceptions raised).
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")


# Generated at 2022-06-24 12:36:24.971630
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert issubclass(GlideIE, InfoExtractor) == True


# Generated at 2022-06-24 12:36:25.935268
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == "Glide"

# Generated at 2022-06-24 12:36:26.731183
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    inst.test()

# Generated at 2022-06-24 12:36:28.861807
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:36.016497
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:36:38.339702
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
