

# Generated at 2022-06-24 12:26:42.489376
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_extract(ie._TEST.get('url'))
    ie.IE_DESC

# Generated at 2022-06-24 12:26:44.928192
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:26:46.135496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download(ie._TEST)

# Generated at 2022-06-24 12:26:46.766241
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:26:47.955593
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('glide:UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:26:48.473561
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:26:57.827350
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    try:
        # test _real_extract function
        info_extractor._real_extract(
            'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
        # test _match_id function
        assert(info_extractor._match_id(
            'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    except:
        assert(False)
    else:
        assert(True)


# Generated at 2022-06-24 12:27:00.371916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie == "Glide", ie.IE_DESC

# Generated at 2022-06-24 12:27:03.776911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    GlideIE constructor unit test
    """

    glide_ie = GlideIE(None)

    assert glide_ie.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:27:12.184626
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert isinstance(GlideIE._VALID_URL, str)
    assert not isinstance(GlideIE._VALID_URL, unicode)

# Generated at 2022-06-24 12:27:17.527567
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Unit tests for GlideIE"""

    # Arrange
    video_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    url = "http://share.glide.me/" + video_id
    glide_ie = GlideIE()

    # Act
    glide_info = glide_ie.extract(url)

    # Assert
    assert glide_info["id"] == video_id

# Generated at 2022-06-24 12:27:21.424278
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test_object = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	print(test_object.IE_DESC)
	print(test_object._VALID_URL)
	print(test_object._TEST)
	print(test_object._TEST['url'])

# Generated at 2022-06-24 12:27:25.868502
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert len(GlideIE._TESTS) == 1
    for url in GlideIE._TESTS:
        test = GlideIE._TESTS[url]
        if 'info_dict' in test:
            continue
        # test if the expected values match a returned value
        assert GlideIE._match_id(url) == test['id']

# Generated at 2022-06-24 12:27:33.110268
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert(glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(glide._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
    assert(glide._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(glide._TEST['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-24 12:27:35.175219
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
       GlideIE()
    except Exception as e:
       assert False, str(e)

# Generated at 2022-06-24 12:27:35.839756
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(dict()) is not None

# Generated at 2022-06-24 12:27:37.366693
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:27:43.223316
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import pytest
    GlideIE('GlideIE', 'Glide mobile video messages (glide.me)')
    GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:45.048728
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE()
    assert len(video.IE_DESC) > 0


# Generated at 2022-06-24 12:27:47.244946
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_obj = GlideIE()
    print("Test passed")

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:27:48.458353
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:27:49.316739
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:27:52.175299
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj_1 = GlideIE()
    assert test_obj_1._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:27:55.417881
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-24 12:27:56.473320
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE


# Generated at 2022-06-24 12:27:59.961552
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Create the class to be tested
	class_ = GlideIE
	# Create an instance of the class to be tested
	obj = class_()
	# Check if the computed property _VALID_URL is the same as 'r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)''
	assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:28:02.666210
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:04.444386
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE().to_screen("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:28:14.816187
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert( ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)' )
	assert( ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==' )
	assert( ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7' )

# Generated at 2022-06-24 12:28:18.249015
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')



# Generated at 2022-06-24 12:28:23.391106
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test class constructor"""
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:28:25.489860
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:28:27.256218
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print('Testing GlideIE constructor')
    GlideIE_object = GlideIE()

# Generated at 2022-06-24 12:28:29.807346
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide=GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)', 'Error in GlideIE class'


# Generated at 2022-06-24 12:28:30.730537
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:28:34.512537
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == 'glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj.IE_VERSION == '0.0.1'

# Unit test to verify that _VALID_URL is a valid URL

# Generated at 2022-06-24 12:28:35.641745
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).IE_NAME in ('share.glide.me',)

# Generated at 2022-06-24 12:28:36.749654
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, object)


# Generated at 2022-06-24 12:28:37.512307
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._download_webpage('','')

# Generated at 2022-06-24 12:28:39.602410
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('Glide', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') is not None

# Generated at 2022-06-24 12:28:42.015305
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    class_name = str(test.__class__).split('.')[-1].replace('>', '').replace('\'', '')
    assert class_name == 'GlideIE'

# Generated at 2022-06-24 12:28:42.557424
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:46.521675
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(InfoExtractor).suitable(url) 
    GlideIE(InfoExtractor).extract(url)

# Generated at 2022-06-24 12:28:48.082837
# Unit test for constructor of class GlideIE
def test_GlideIE():
    temp_glide_ie = GlideIE(InfoExtractor)
    assert temp_glide_ie

# Generated at 2022-06-24 12:28:53.479721
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for constructor of class GlideIE
    # Create object of GlideIE
    obj = GlideIE()
    # Check for presence of _VALID_URL
    assert hasattr(obj,"_VALID_URL") == True
    # Check for presence of IE_DESC
    assert hasattr(obj,"IE_DESC") == True


# Generated at 2022-06-24 12:28:55.511764
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Unit test for constructor of class GlideIE
    '''
    GlideIE()

# Generated at 2022-06-24 12:29:00.947670
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._html_search_meta('title', '<title>yo</title>') == 'yo'

# Generated at 2022-06-24 12:29:03.022151
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE("Glide")
    assert obj.IE_NAME == "Glide"

# Generated at 2022-06-24 12:29:04.652852
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()


# Generated at 2022-06-24 12:29:15.383661
# Unit test for constructor of class GlideIE
def test_GlideIE():
    Glide = GlideIE()
    Glide.IE_DESC = 'Glide mobile video messages (glide.me)'
    Glide._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:16.859298
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()


# Generated at 2022-06-24 12:29:19.793566
# Unit test for constructor of class GlideIE
def test_GlideIE():
  test = GlideIE()
  test = test.test()
  test = test.test()
  assert(test)

# Generated at 2022-06-24 12:29:25.793805
# Unit test for constructor of class GlideIE
def test_GlideIE():
    G = GlideIE()
    assert G.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')['title'] == "Damon's Glide message" 
    assert G.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')['id'] == "UZF8zlmuQbe4mr+7dCiQ0w==" 


# Generated at 2022-06-24 12:29:28.306071
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()

if __name__ == "__main__":
    test_GlideIE()

# Generated at 2022-06-24 12:29:31.698783
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Basic unit test for GlideIE"""
    # this is a constructor call
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:29:33.711594
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:29:37.237683
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:47.084281
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test URL
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # Instantiate class and call _real_extract method
    glide_video = GlideIE()
    info_dict = glide_video._real_extract(url)

    # Test title
    assert info_dict['title'] == "Damon's Glide message"
    # Test URL
    assert info_dict['url'] == 'https://d1wc0ojlf2kfcl.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==.mp4'
    # Test thumbnail

# Generated at 2022-06-24 12:29:48.440931
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    GlideIE(None) # should not raise any exception

# Generated at 2022-06-24 12:29:50.396519
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().ie_key() == 'Glide'

# Generated at 2022-06-24 12:30:00.537048
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:09.057590
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._VALID_URL_RE == (r'https?://(?:www\.)?share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:30:10.484652
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:30:21.325781
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    GlideIE constructor unit test
    """
    glideIE = GlideIE(None)
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:30:21.956217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:22.576102
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:31.180557
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_GlideIE = GlideIE()
    assert class_GlideIE.IE_NAME == 'glide'

    assert class_GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

    assert class_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

    assert class_GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    assert class_GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'


# Generated at 2022-06-24 12:30:34.971517
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert x._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:30:36.843034
# Unit test for constructor of class GlideIE
def test_GlideIE():
	x = GlideIE()

# Generated at 2022-06-24 12:30:40.626379
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Args:
        -
    Returns:
        -
    Raises:
        -
    '''
    GlideIE()


# Generated at 2022-06-24 12:30:45.914973
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['info_dict']['title'] == "Damon's Glide message"


# Generated at 2022-06-24 12:30:46.343132
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:46.760937
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:30:48.770230
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('www.share.glide.me')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-24 12:30:49.806478
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "GlideIE"

# Generated at 2022-06-24 12:30:51.389032
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:30:59.179257
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not GlideIE.suitable('https://share.glide.me/')
    assert not GlideIE.suitable('https://share.glide.me/login')
    assert GlideIE.suitable(
        'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w%3D%3D')

# Generated at 2022-06-24 12:31:00.184122
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()
	

# Generated at 2022-06-24 12:31:01.821758
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE() # type: GlideIE



# Generated at 2022-06-24 12:31:06.732488
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE('GlideIE')
    info = info_extractor.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:31:10.112825
# Unit test for constructor of class GlideIE
def test_GlideIE():

    class FakeInfoExtractor(GlideIE):
        pass

    ie = FakeInfoExtractor()

    # test GlideIE.extract()
    assert ie.extract(ie._TEST['url']) == ie._TEST


# Generated at 2022-06-24 12:31:11.883465
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE()
    assert e.IE_DESC == 'Glide mobile video messages (glide.me)'
    

# Generated at 2022-06-24 12:31:17.969306
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie.video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    result = ie.extract()
    assert result['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert result['title'] == "Damon's Glide message"
    assert re.match(r'https?://.*?\.cloudfront\.net/.*\.jpg$', result['thumbnail'])
    assert re.match(r'https?://.*?\.cloudfront\.net/.*\.mp4$', result['url'])

# Generated at 2022-06-24 12:31:28.091412
# Unit test for constructor of class GlideIE
def test_GlideIE():
   # First constructor test
   test_GlideIE = GlideIE()
   assert test_GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
   assert test_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:28.524875
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:39.446075
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE.
    """
    # Test constructor with correct url
    url = "http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D"
    glide = GlideIE(url)
    assert glide.url == url
    assert glide._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

    # Test constructor with url not matching regex
    url = "http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D/test"
    glide = GlideIE(url)
    assert glide.url == None

# Generated at 2022-06-24 12:31:48.141722
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create instance of GlideIE class
    ie = GlideIE()

    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:31:49.540929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).IE_NAME == "Glide"


# Generated at 2022-06-24 12:31:53.392659
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST == ie.TEST
    assert ie.IE_NAME == ie.ie_key()


# Generated at 2022-06-24 12:31:57.348344
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test that the constructor of class GlideIE is working
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:31:57.932205
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:59.206171
# Unit test for constructor of class GlideIE
def test_GlideIE():
	"""
	Unit test for constructor of class GlideIE
	"""
	assert(isinstance(GlideIE(), InfoExtractor))

# Generated at 2022-06-24 12:32:01.326135
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance= GlideIE('')
    assert isinstance(instance, GlideIE)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:32:03.877855
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-24 12:32:08.560952
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_obj = GlideIE()
    assert isinstance(glide_obj, GlideIE)
    assert hasattr(glide_obj, '_VALID_URL')
    assert hasattr(glide_obj, 'IE_NAME')
    assert hasattr(glide_obj, '_TEST')
    assert hasattr(glide_obj, 'IE_DESC')



# Generated at 2022-06-24 12:32:17.101028
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Construct a GlideIE class
    ie = GlideIE()
    # Construct a GlideIE class and check if it's an instance of InfoExtractor class
    assert isinstance(ie, InfoExtractor)
    # Unit tests for methods in class GlideIE
    ie = GlideIE()
    info = ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:32:23.552906
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE.
    """
    glide_ie = GlideIE()
    assert glide_ie.IE_NAME == 'glide'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'(https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+))'

# Generated at 2022-06-24 12:32:25.848791
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:32:36.595300
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:32:38.681876
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    

# Generated at 2022-06-24 12:32:44.595662
# Unit test for constructor of class GlideIE
def test_GlideIE():
    w = GlideIE('test','test','test','test','test','test','test')
    assert w.name == 'test'
    assert w.title == 'test'
    assert w.description == 'test'
    assert w.thumbnail == 'test'
    assert w.duration == 'test'
    assert w.uploader == 'test'
    assert w.timestamp == 'test'
    assert w.uploader_id == 'test'
    assert w.view_count == 'test'
# test_GlideIE()

# Generated at 2022-06-24 12:32:55.429135
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # test _real_extract()
    # Test 1
    test = ie._real_extract(ie._TEST['url'])
    assert test['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert test['ext'] == 'mp4'
    assert test['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:33:01.404976
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Check if the url is properly parsed
    url = ie._VALID_URL
    res = ie._extract_url(url)
    expRes = ie._TEST['url']
    #assert res == expRes, \
        #"The url extracted is different from the expected value"
    assert res == expRes

# Generated at 2022-06-24 12:33:12.132086
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie=GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:33:13.541633
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert not issubclass(GlideIE, InfoExtractor)

# Generated at 2022-06-24 12:33:15.594936
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie is not None

# unit test for url

# Generated at 2022-06-24 12:33:18.121049
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.set_handle_redirect('none')


if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:33:24.590703
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import unittest
    #assert_raises(...)

# Generated at 2022-06-24 12:33:26.609443
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:33:27.183121
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:33:29.994671
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:33.294245
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # object of class GlideIE
    GlideIE
    # object of class InfoExtractor
    InfoExtractor
    # use assertIsInstance instead of assertTrue since assertTrue is deprecated
    # assertTrue(isinstance(glideIE, InfoExtractor))
    assertIsInstance(GlideIE, type)

# Generated at 2022-06-24 12:33:34.582947
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:33:46.425070
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:56.282267
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert_equal(ie._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert_equal(ie._TEST['url'], 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert_equal(ie._TEST['md5'], '4466372687352851af2d131cfaa8a4c7')
    assert_equal(ie._TEST['info_dict']['id'], 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:33:56.852793
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:05.858207
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert InfoExtractor.remove_start
    assert InfoExtractor.suitable
    assert InfoExtractor._download_webpage
    assert InfoExtractor._search_regex
    assert InfoExtractor._html_search_regex
    assert InfoExtractor.report_warning
    assert InfoExtractor._download_webpage
    #assert InfoExtractor._search_regex
    #assert InfoExtractor._html_search_regex
    #assert InfoExtractor.report_warning
    #assert InfoExtractor._download_webpage
    #assert InfoExtractor._search_regex
    #assert InfoExtractor._html_search_regex
    #assert InfoExtractor.report_warning
    #assert InfoExtractor._download_webpage
    #assert InfoExtractor._search_regex
    #assert InfoExtractor._html_search_regex


# Generated at 2022-06-24 12:34:10.528857
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()
    info.url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    info._real_extract(info.url)

# Generated at 2022-06-24 12:34:13.730158
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE = GlideIE()
    GlideIE_list = dir(GlideIE)
    is_init = "__init__" in GlideIE_list
    assert is_init == True, "Wrong class GlideIE"

# Generated at 2022-06-24 12:34:16.990363
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # type: () -> None
    """Unit tests for constructor of class GlideIE"""
    ie = GlideIE('Glide mobile video messages (glide.me)')
    # TODO: Add tests for method '_real_extract' of class GlideIE

# Generated at 2022-06-24 12:34:20.542059
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_NAME == "GlideIE"
    assert ie.IE_DESC == "Glide"
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-24 12:34:28.509359
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:38.556964
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:41.298992
# Unit test for constructor of class GlideIE
def test_GlideIE():
  test = GlideIE(GlideIE.IE_DESC, GlideIE._VALID_URL, GlideIE._TEST)
  if not (isinstance(test, object)):
    raise AssertionError("Incorrect constructor of class GlideIE")

# Generated at 2022-06-24 12:34:41.985858
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:34:45.045242
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:34:47.678251
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    # assert that the class has a valid description
    assert isinstance(ie.IE_DESC, str)

# Generated at 2022-06-24 12:34:52.627935
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL =="https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)" 
    assert glide.extractor_key =="Glide" 
    assert glide.IE_NAME =="Glide" 
    assert glide.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-24 12:35:01.411818
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:35:04.817761
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert type(extractor) == GlideIE
    assert extractor.IE_NAME == 'Glide'
    assert extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    

# Generated at 2022-06-24 12:35:06.537844
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:35:07.332251
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:17.309058
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    expected = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'title': "Damon's Glide message",
        'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }
    infoExtractor = GlideIE()
    actual = infoExtractor._real_extract(url)
    if actual != expected:
        raise AssertionError('Expect: %s, Actual: %s' % (expected, actual))
    print('Pass')

# Generated at 2022-06-24 12:35:17.690965
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:22.905872
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:34.792565
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Please install the package pylint-django(pip install pylint-django) to your virtualenv
    # and then run pylint test_GlideIE.py in the terminal.
    assert str(ie.__class__) == '__main__.GlideIE' , 'Name of the class is wrong.'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)', 'Description of the class is wrong.'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', 'Regular expression for valid URL is wrong.'

# Generated at 2022-06-24 12:35:39.185471
# Unit test for constructor of class GlideIE
def test_GlideIE():
    Globals.download_command = 'id'
    Globals.download_retcode = 0
    ie = GlideIE()
    result = ie._download_webpage('url','videoId')
    expected = 'id -o "-" "url"'
    assert result == expected


# Generated at 2022-06-24 12:35:40.686935
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:35:49.497575
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test that GlideIE correctly populates the inherited
    # class variables for description, valid URL and the test dictionary.
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:35:58.641863
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glideIE = GlideIE(InfoExtractor)
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    id = glideIE._match_id(url)
    webpage = glideIE._download_webpage(url, id)
    title = glideIE._html_search_regex(
        r'<title>(.+?)</title>', webpage,
        'title', default=None) or glideIE._og_search_title(webpage)

# Generated at 2022-06-24 12:36:07.748301
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Create the GlideIE object
	glide_ie = GlideIE()
	# Test the URL and the ObjectID, returns an object
	test_video = glide_ie.extract(glide_ie._TEST['url'])
	# Test the URL, returns an object
	test_video_url = glide_ie._download_webpage(glide_ie._TEST['url'], glide_ie._TEST['info_dict']['id'])
	# Test the URL and the ObjectID, returns the title
	test_video_search_title = glide_ie._og_search_title(test_video_url)
	# Test the URL and the ObjectID, returns the url of the video
	test_video_search_url = glide_ie._og_search_video_url(test_video_url)
	#

# Generated at 2022-06-24 12:36:09.837322
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert hasattr(instance, 'IE_DESC')

# Generated at 2022-06-24 12:36:15.559482
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gie = GlideIE()
    assert gie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert gie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # assert gie._TEST is something

# Generated at 2022-06-24 12:36:25.389778
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Basic test to check whether the constructor of GlideIE class
    """
    website = GlideIE()
    assert website.IE_NAME == 'Glide'
    assert website.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert website._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:27.109090
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE.ie_key()).ie_key() == 'Glide'

# Generated at 2022-06-24 12:36:28.417706
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:36:31.061851
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
        Check if GlideIE can be instantiated
    '''
    instance = GlideIE('youtube', 'youtube.com')
    assert isinstance(instance, GlideIE)

# Generated at 2022-06-24 12:36:33.861031
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE(1)._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:34.476142
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE()

# Generated at 2022-06-24 12:36:36.523098
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:36:38.485986
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.ie_key() == 'Glide'
    

# Generated at 2022-06-24 12:36:45.228403
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glideie = GlideIE()
	print('test GlideIE')
	assert glideie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert glideie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert glideie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert glideie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'