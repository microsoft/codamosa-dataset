

# Generated at 2022-06-24 12:26:41.966775
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        print("Creation of GlideIE() failed")
        assert False

# Generated at 2022-06-24 12:26:44.258592
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    print('done')


# Generated at 2022-06-24 12:26:45.129019
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:26:55.871864
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.extract == GlideIE._real_extract
    #assert ie.get_video_id("UZF8zlmuQbe4mr+7dCiQ0w==") == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    #assert ie._TEST == {"url": "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", "md5": "4466372687352851af2d131cfaa

# Generated at 2022-06-24 12:27:01.613959
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    :return: None
    """
    if __name__ == '__main__':
        glide_ie = GlideIE()

# Generated at 2022-06-24 12:27:11.111818
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:12.841934
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # No need to create the object, just check that the constructor doesn't
    # throw an exception
    ie = GlideIE()

# Generated at 2022-06-24 12:27:21.366109
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL== 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:22.483112
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:27:31.324116
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:33.824732
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test_GlideIE = GlideIE()
	test_GlideIE.IE_DESC
	test_GlideIE._VALID_URL
	test_GlideIE._TEST

# Generated at 2022-06-24 12:27:36.955172
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:27:42.246983
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for the extraction of a GlideIE video
    ie = GlideIE()
    ie.extract(ie._TEST['url'])
    # Test for the extraction of a GlideIE video from webpage
    ie = GlideIE()
    ie.extract('https://share.glide.me/')

# Generated at 2022-06-24 12:27:51.138510
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:02.063946
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    assert obj.IE_NAME is not None
    assert obj.IE_DESC == GlideIE.IE_DESC
    assert obj.IE_VERSION == '1.0'
    assert obj.VALID_URL == GlideIE._VALID_URL
    assert obj.REAL_URL == GlideIE._REAL_URL
    assert obj.IE_KEY == 'Glide'

    assert obj.params is not None
    assert obj.name is None
    assert obj.title is None
    assert obj.description is None
    assert obj.thumbnail is None
    assert obj.uploader is None
    assert obj.uploader_id is None
    assert obj.ext is None


# Generated at 2022-06-24 12:28:03.638113
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor for basic initialization
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:28:06.044549
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()

# Generated at 2022-06-24 12:28:08.578703
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    test = GlideIE()._real_extract(url)
    return test

# Generated at 2022-06-24 12:28:17.334852
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    except Exception as e:
        print("Failed to create GlideIE object")
        return 1
    print("Successfully created GlideIE object")
    return 0

# Run unit test for GlideIE
if __name__ == "__main__":
    print("Testing GlideIE")
    if test_GlideIE() == 0:
        print("All tests passed")
        exit(0)
    else:
        print("Test(s) failed")
        exit(1)

# Generated at 2022-06-24 12:28:27.395361
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:28:37.078768
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = InfoExtractor
    assert IE.ie_key() == 'glide'
    assert IE.ie_key() in IE._AVAILABLE_INFOSECTIONS
    assert IE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert IE.IE_NAME == 'glide'
    assert IE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:41.442048
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .test_utils import ytdl

    class FakeOptions(object):
        def __init__(self):
            self.default_search = None
            self.quiet = False

    options = FakeOptions()

    yt = ytdl(options)

    # the URL should be accepted.
    assert yt.extract_info(
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:28:46.024892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.name == "Glide"
    assert ie.IE_DESC
    assert ie.IE_NAME
    assert ie.ie_key()
    assert ie._VALID_URL
    assert ie._TEST
    assert ie.IE_BR
    assert ie.SUFFIX
    assert ie._WORKING

# Generated at 2022-06-24 12:28:46.576356
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This should create a valid object
    GlideIE()

# Generated at 2022-06-24 12:28:48.889747
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    class_instance = GlideIE()
    assert isinstance(class_instance, InfoExtractor)


# Generated at 2022-06-24 12:28:51.993886
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import HEADRequest
    GlideIE = HEADRequest._request_class
    assert GlideIE is not None
    return GlideIE

# Generated at 2022-06-24 12:28:59.701125
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)

    url = 'http://share.glide.me/v/UZF8zlmuQbe4mr+7dCiQ0w=='

    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST

    # _match_id
    assert ie._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='

    # _real_extract
    assert ie._real_extract(url) == GlideIE._TEST['info_dict']

# Generated at 2022-06-24 12:29:00.389594
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:29:03.212224
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test for constructor of class GlideIE
    """
    print("test GlideIE")
    ie=GlideIE()
    assert ie.name == 'glide'

# Generated at 2022-06-24 12:29:05.822794
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x.IE_NAME == 'glide'



# Generated at 2022-06-24 12:29:13.800395
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gi = GlideIE(None, {})
    assert gi.ie_key() == "Glide"
    assert gi.ie_desc() == "Glide mobile video messages (glide.me)"
    assert gi.valid_url("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert gi.valid_url("not a url") is False
    assert gi.valid_url("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:29:16.662761
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:29:21.266983
# Unit test for constructor of class GlideIE
def test_GlideIE():
	"""
	  Unit test for GlideIE
	"""
	g = GlideIE()
	assert g.IE_DESC == "Glide mobile video messages (glide.me)"


test_GlideIE()

# Generated at 2022-06-24 12:29:24.040450
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE(__name__)._VALID_URL == 'https?://share.glide.me/(?P<id>[A-Za-z0-9\\-=_+]+)'

# Generated at 2022-06-24 12:29:34.829284
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # namer for temporary file loading
    def tempname(filename):
        return filename

    from .common import compat_urllib_parse_unquote_plus
    import re
    import os
    from .common import fs_encode
    # for security, we run the tests in a temporary folder
    os.chdir(os.path.join('build', 'test'))
    if not os.path.exists('tmp'):
        os.mkdir('tmp')

    # constructor
    glide = GlideIE(tempname)
    assert glide != None, "glide is empty"

    # downloader
    glide = GlideIE(tempname)
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video_id = glide._match

# Generated at 2022-06-24 12:29:45.193554
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:29:46.669371
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:49.985189
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._search_regex(None, None, None, None, None)
    assert GlideIE(None)._html_search_regex(None, None, None, None)
    assert GlideIE(None)._proto_relative_url(None)
    assert GlideIE(None)._match_id(None)

# Generated at 2022-06-24 12:30:00.498323
# Unit test for constructor of class GlideIE
def test_GlideIE():
   if __name__ == '__main__':
    IE_DESC = 'Glide mobile video messages (glide.me)'
    _VALID_URL = r'https?://share.glide.me/(?P<id>[A-Za-z0-9\-=_+]+)' 

# Generated at 2022-06-24 12:30:05.232975
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    return "test_GlideIE successful"

# Generated at 2022-06-24 12:30:15.298299
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$'}}
    assert ie.IE_DESC

# Generated at 2022-06-24 12:30:26.039730
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if __name__ == '__main__':
        import os.path
        import sys
        sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir)))
    from compat import compat_b64decode
    from extractors import compress_opener
    from ytdl.util import js_to_json
    from extractors import GlideIE

    ie = GlideIE(compress_opener())
    info = ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:30:30.589653
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE().get_info(url, download=False)
    assert ie['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:30:34.696909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for normal url.
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glideIE = GlideIE()
    assert glideIE._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='



# Generated at 2022-06-24 12:30:36.244964
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Unit test for constructor of class GlideIE.
    '''
    GlideIE()

# Generated at 2022-06-24 12:30:38.609361
# Unit test for constructor of class GlideIE
def test_GlideIE():
        glideIE_instance = GlideIE()
        if (glideIE_instance.IE_DESC == GlideIE.IE_DESC):
            assert True
        else:
            assert False


# Generated at 2022-06-24 12:30:42.281629
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:43.539480
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()    # should not raise exception

# Generated at 2022-06-24 12:30:45.109515
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'



# Generated at 2022-06-24 12:30:47.182091
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    glide._match_id("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:30:48.271567
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide_instance = GlideIE()

# Generated at 2022-06-24 12:30:57.165457
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj._TEST == {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    return test_obj


# Generated at 2022-06-24 12:30:59.330708
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ieInstance = GlideIE()
    print(ieInstance.IE_DESC)
# Test for getVideoInfo

# Generated at 2022-06-24 12:31:02.388139
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:31:08.826410
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert IE.IE_NAME == 'Glide.me'
    assert IE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert IE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:09.737005
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()


# Generated at 2022-06-24 12:31:11.421193
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:31:11.904056
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-24 12:31:12.405601
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:31:18.096523
# Unit test for constructor of class GlideIE
def test_GlideIE():    # pylint: disable=missing-docstring
    args = { 'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'info_dict': { 'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$' }, 'md5': '4466372687352851af2d131cfaa8a4c7' }
    glide_ie = GlideIE(**args)
    assert glide_ie is not None

# Generated at 2022-06-24 12:31:18.839618
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:22.250422
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:28.557954
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Glide video test
    """
    i = GlideIE()

    #Test Information extraction
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert i.suitable(url) == True
    info = i.extract(url)
    assert info["id"] == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert info['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:31:36.933716
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    t = type(ie)
    assert issubclass(t, InfoExtractor)
    assert t.__name__ == 'GlideIE'
    assert t.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert t._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:31:39.000862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).IE_DESC == "Glide mobile video messages (glide.me)"


# Generated at 2022-06-24 12:31:41.622389
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie is not None

# Generated at 2022-06-24 12:31:44.295348
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") is not None

# Generated at 2022-06-24 12:31:54.607973
# Unit test for constructor of class GlideIE
def test_GlideIE():

	glideIE = GlideIE()
	assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert glideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:57.106847
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    # with assertion
    ie = GlideIE()
    assert ie
    assert ie.IE_DESC

# Generated at 2022-06-24 12:31:58.935215
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except NameError:
        pass

# Generated at 2022-06-24 12:32:02.112109
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, GlideIE)

# Test to make sure '_real_extract' function works
# Test function for '_real_extract' function in class GlideIE

# Generated at 2022-06-24 12:32:11.883408
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    t._download_webpage
    t._html_search_regex
    t._match_id
    t._og_search_thumbnail
    t._og_search_title
    t._og_search_video_url
    t._proto_relative_url
    t._real_extract
    t._search_regex
    t._VALID_URL
    t.IE_DESC
    t.suitable
    t.expected_warnings
    t.add_ie
    t.ie_key
    t.ie_name
    t.test()
    t.test_globals()
    t.test_Cookie().__doc__
    t.test_Cookie().__init__()
    t.test_Cookie().__module__
    t.test_C

# Generated at 2022-06-24 12:32:12.765025
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:17.911050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of class GlideIE:
    # def __init__(self, ie_key=None):
    o = GlideIE(None)

    # Test method 'suitable' of class GlideIE:
    # def suitable(self, *args, **kwargs):
    assert o.suitable(None, None, None)

    # Test method 'url_result' of class GlideIE:
    # def url_result(self, *args, **kwargs):
    assert o.url_result(None)

# Generated at 2022-06-24 12:32:19.983463
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert(glide.IE_DESC == "Glide mobile video messages (glide.me)")

# Generated at 2022-06-24 12:32:22.949491
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('Glide', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:32:34.279375
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    url = 'https://share.glide.me/%s' % video_id

    # test GlideIE constructor
    glide_ie = GlideIE(url)
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie._TEST['url'] == url
    assert glide_ie._TEST['info_dict']['id'] == video_id

    extraction = glide_ie._real_extract(url)

# Generated at 2022-06-24 12:32:36.160145
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:37.596792
# Unit test for constructor of class GlideIE
def test_GlideIE():

    valid = GlideIE()

    assert valid.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:39.235846
# Unit test for constructor of class GlideIE
def test_GlideIE():
    intf = GlideIE()
    assert (intf != None)

# Generated at 2022-06-24 12:32:45.052272
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testObj = GlideIE()
    # Checking whether the video was extracted properly  
    assert testObj.IE_DESC == "Glide mobile video messages (glide.me)"
    assert testObj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert testObj._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:32:56.008332
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': 're:^https?://.*?\\.cloudfront\\.net/.*\\.jpg$'}}
    return

# Generated at 2022-06-24 12:32:57.530605
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:33:00.117285
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST
    ie._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:33:01.449810
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    test.suite()



# Generated at 2022-06-24 12:33:10.434708
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    info_dict = {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    assert(test_GlideIE._real_extract(url) == info_dict)


# Generated at 2022-06-24 12:33:14.508024
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_NAME == ie.__class__.IE_NAME)
    assert(ie.IE_DESC == ie.__class__.IE_DESC)
    assert(ie._VALID_URL == ie.__class__._VALID_URL)


# Generated at 2022-06-24 12:33:18.969826
# Unit test for constructor of class GlideIE
def test_GlideIE():
    with open("data.txt", "r") as f:
        url = f.readline()
        url = url.strip()
    video = GlideIE()
    video.extract(url)
    assert video.title is not None
    assert video.url is not None
    assert video.thumbnail is not None

# Generated at 2022-06-24 12:33:20.999449
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_inst = ie['Glide']
    assert ie_inst._VALID_URL == ie_inst._TEST['url']

# Generated at 2022-06-24 12:33:26.349899
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'GlideIE'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:33:34.541794
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Description:
        Constructor of class GlideIE.
    Args:
        None
    Returns:
        None
    """
    import re

    group_dict = {'id': 'UZF8zlmuQbe4mr+7dCiQ0w=='}
    glide_ie = GlideIE(group_dict)

    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:42.597964
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert result._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert result._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:44.340520
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    GlideIE()

# Generated at 2022-06-24 12:33:46.828349
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:47.653332
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 'GlideIE' in locals()

# Generated at 2022-06-24 12:33:53.746967
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glide.name == 'glide.me'
    assert glide.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide.id == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:34:02.892051
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:07.451961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_NAME == 'glide'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:14.039353
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:14.734642
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:15.281288
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import glide
    assert(glide.__version__)

# Generated at 2022-06-24 12:34:16.227868
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("GlideIE")

# Generated at 2022-06-24 12:34:24.540272
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    # test data extraction routines
    
    # test format
    format = ie._format
    assert format is not None

    # test url extraction
    url = ie.getUrl()
    assert url is not None

    # test media id extraction
    mediaid = ie.getMediaID()
    assert mediaid == 'UZF8zlmuQbe4mr+7dCiQ0w=='

    # test title extraction
    title = ie.getTitle()
    assert title == "Damon's Glide message"

# Generated at 2022-06-24 12:34:26.736461
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:34:28.347936
# Unit test for constructor of class GlideIE
def test_GlideIE():
	e = GlideIE()
	assert isinstance(e, GlideIE)
	

# Generated at 2022-06-24 12:34:33.093464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gie = GlideIE()
    assert gie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert gie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:39.307321
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:34:42.152325
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Testing GlideIE constructor"""
    # Instance not None
    assert GlideIE(object) is not None

# Generated at 2022-06-24 12:34:43.668892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie is not None


# Generated at 2022-06-24 12:34:52.854872
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide = GlideIE(InfoExtractor())
	assert glide.IE_NAME == 'Glide'
	assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert glide._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:34:53.726655
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)


# Generated at 2022-06-24 12:35:02.494009
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:03.056307
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:05.832962
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for GlideIE"""
    print("Creating Test Object")
    glideIE_test = GlideIE({})

    print("Running _real_extract")
    glideIE_test._real_extract({})

    print("Done")

# Generated at 2022-06-24 12:35:09.266182
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:35:11.269359
# Unit test for constructor of class GlideIE
def test_GlideIE():
	yie = GlideIE()
	assert yie != None

# Generated at 2022-06-24 12:35:12.999233
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 12:35:21.924388
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_info = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    glide_ie = GlideIE()
    assert glide_ie._TEST == test_info

# Generated at 2022-06-24 12:35:33.272922
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert obj._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': 're:^https?://.*?\\.cloudfront\\.net/.*\\.jpg$'}}
	return obj.IE

# Generated at 2022-06-24 12:35:39.997624
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # The url given in the GlideIE._TEST attribute is not accessible
    # from outside of India. Use another url that is accessible from
    # anywhere.
    post_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()
    ie_result = ie.extract(post_url)
    assert ie_result


# Generated at 2022-06-24 12:35:48.535807
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # GlideIE has been implemented in 2017.11.22
    # https://github.com/rg3/youtube-dl/pull/12204

    # Since glide.me is alive and GlideIE is not special in any way,
    # it is not specially tested.
    # (youtube-dl/youtube_dl/extractor/glide.py)
    # The only one test in GlideIE is using a hard-coded URL.
    # (youtube-dl/youtube_dl/extractor/test/test_glide.py)

    # No exception should be thrown by GlideIE:
    ie = GlideIE(None)
    # No exception should be thrown by _VALID_URL:
    assert ie._VALID_URL is not None

# Generated at 2022-06-24 12:35:51.527613
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert ie._VALID_URL == ie.VALID_URL and ie._TEST == ie.TEST

# Generated at 2022-06-24 12:35:58.355048
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    #ie.extract("http://share.glide.me/rD_rTmTpTbe4mr+7dCiQ0w==") # How to add a test case to check exception is raised or not?
    #ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") # How to add a test case to check exception is raised or not?

# Generated at 2022-06-24 12:35:59.953877
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:36:01.206807
# Unit test for constructor of class GlideIE
def test_GlideIE():
    host = GlideIE()
    assert host.ie_key() == 'Glide'

# Generated at 2022-06-24 12:36:02.091391
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()



# Generated at 2022-06-24 12:36:10.074946
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test the constructor of class GlideIE 
    #
    # Create a GlideIE object (using the testing url) and check that the id is correct
    from .common import GlideIE
    from .test_common import model_test
    from .compat import compat_urllib_parse
    from .extractor import gen_extractors
    glideIE = model_test(
        gen_extractors(),
        GlideIE,
        compat_urllib_parse.urlparse('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='),
        u'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:36:12.622206
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)
    assert True

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:36:21.237159
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # These values are from the _TEST object
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # These values are from the _TEST object
    expected_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    # These values are from the _TEST object
    expected_title = "Damon's Glide message"
    # These values are 
    expected_long_title = "Damon's Glide message"

    # Create a new instance of GlideIE
    glideIE = GlideIE()

    # Save the actual id and title returned by the class
    actual_id = glideIE._match_id(url)

# Generated at 2022-06-24 12:36:22.283076
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie != None

# Generated at 2022-06-24 12:36:30.933586
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    assert IE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert IE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:41.227328
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
    assert(ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie._TEST['info_dict']['ext'] == 'mp4')
    assert(ie._TEST['info_dict']['title'] == "Damon's Glide message")