

# Generated at 2022-06-24 12:26:45.728815
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:26:47.114744
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	assert obj.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:26:52.045136
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:26:54.097521
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .test_classes import TestClass
    test_instance = TestClass()
    assert test_instance.constructorTest() == test_instance

# Generated at 2022-06-24 12:27:01.421236
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # URL for which GlideIE is necessary
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # URL for which GlideIE is not necessary
    url1 = 'https://www.youtube.com/watch?v=PewagDg6U88'
    #instantiate GlideIE
    glide_inst = GlideIE()
    #Test if URL is GlideIE
    assert glide_inst.suitable(url) == True
    #Test if URL is not GlideIE
    assert glide_inst.suitable(url1) == False
    #Test if URL is not GlideIE
    assert glide_inst.suitable('https://glide.me/') == False
    #Test if URL is not GlideIE
    assert glide_

# Generated at 2022-06-24 12:27:05.245494
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("\tUnit test for class GlideIE")
    url = "http://share.glide.me/"
    GlideIE(url)
    print("\tUnit test for class GlideIE is finished")


# Generated at 2022-06-24 12:27:14.606327
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Test case for invalid URL
	a = GlideIE("https://www.youtube.com/watch?v=zKRxI_7c_28")
	assert not a.is_valid()

	# Test case for valid URL
	b = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
	assert a.is_valid()
	assert a.id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
	assert a.title == "Damon's Glide message"
	assert a.thumbnail == r're:^https?://.*?\.cloudfront\.net/.*\.jpg$'

# Generated at 2022-06-24 12:27:21.050156
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # create a class GlideIE instance
    glide_ie = GlideIE()

    # output the description of IE_DESC
    if glide_ie.IE_DESC:
        print (glide_ie.IE_DESC)
    else:
        print ("No description for the GlideIE.")

    # output the supported URL regular expression string
    if glide_ie._VALID_URL:
        print (glide_ie._VALID_URL)
    else:
        print ("No supported URL regular expression string.")

if __name__ == "__main__":
    # execute the unit test
    test_GlideIE()

# Generated at 2022-06-24 12:27:23.065487
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor
    GlideIE(None)  # self parameter only needed for inheritance

# Generated at 2022-06-24 12:27:31.647719
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__name__ == 'GlideIE'
    assert GlideIE.__doc__ == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:40.630331
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.test()['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.test()['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:27:41.248006
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-24 12:27:42.101263
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(True)

# Generated at 2022-06-24 12:27:44.704982
# Unit test for constructor of class GlideIE
def test_GlideIE():
    globals()['GlideIE']('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==').extract()

# Generated at 2022-06-24 12:27:47.582454
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert (ie.IE_NAME == ie.ie_key())
    assert (ie.IE_DESC == ie.get_info_extractor_desc())
    return


# Generated at 2022-06-24 12:27:55.188040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # 1. Testing file share.glide.me/KsOnsPQ8-ME0I_rx9Y0Lkg==
    print("Unit Test for GlideIE - Testing file share.glide.me/KsOnsPQ8-ME0I_rx9Y0Lkg==")
    glideIE = GlideIE()
    url = "http://share.glide.me/KsOnsPQ8-ME0I_rx9Y0Lkg=="
    # Getting the webpage from input url
    webpage = glideIE._download_webpage(url, "share.glide.me/KsOnsPQ8-ME0I_rx9Y0Lkg==")
    # Testing the title, url, thumbnail url and id

# Generated at 2022-06-24 12:27:59.544245
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME != None
    assert GlideIE.IE_DESC != None
    assert GlideIE.IE_VERSION != None
    assert GlideIE._VALID_URL != None
    assert GlideIE._TEST != None
    assert GlideIE.__name__ != None
    

# Generated at 2022-06-24 12:28:08.723835
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:28:10.011137
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiation
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-24 12:28:20.699161
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:21.947419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'

# Generated at 2022-06-24 12:28:22.536495
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:23.175923
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:24.466406
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print

# Generated at 2022-06-24 12:28:34.401291
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    # Test common extractor use cases
    glide.test_common()
    # Test constructor of base class
    glide.test_base_class()
    glide.test_return_expected_data()
    glide.test_return_expected_fields()
    glide.test_return_expected_data_for_proto_relative_urls()
    glide.test_return_expected_data_for_proto_relative_urls_and_og_urls()
    glide.test_return_expected_data_for_proto_relative_urls_and_og_urls()
    glide.test_return_expected_data_for_multiple_og_urls()
    glide.test_return_expected_data_with_title_no_url()
    glide.test_return_expected_data_

# Generated at 2022-06-24 12:28:37.037940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Test valid URL
    # FIXME: "InvalidGlideUrl" error occurs from the server.
    # Test invalid URL
    # ie.extract("http://share.glide.me/")

# Generated at 2022-06-24 12:28:44.616082
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test constructor of class GlideIE
    """
    # Constructor with no arguments
    ie = GlideIE()

    # Constructor with one argument
    assert ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    # Constructor with two arguments
    ie = GlideIE(http_headers=True, params=True)

    # Constructor with three arguments
    ie = GlideIE(http_headers=True, query={'key1': 'value1'}, params=True)

    # Constructor with four arguments
    ie = GlideIE(http_headers=True, query={'key1': 'value1'},
                 params=True, gdata=True, age_limit=18)

# Generated at 2022-06-24 12:28:53.122546
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Make sure the GlideIE constructor works (it hasn't been this way)
    IE_DESC = 'Glide mobile video messages (glide.me)'
    VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:56.590006
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor of class GlideIE
    globals()["GlideIE"](InfoExtractor())
    # Test when url is None
    assert globals()["GlideIE"](InfoExtractor())._real_extract(None) is None

# Generated at 2022-06-24 12:29:08.075819
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(False)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    ie._download_webpage = lambda url, video_id: '<title>Damon\'s Glide message</title>'
    ie._html_search_regex = lambda pattern, string, name, default: 'Damon\'s Glide message'
    ie._og_search_title = lambda webpage: ''
    ie._search_regex = lambda pattern, string, name, default, group: 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:29:09.822956
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:14.646800
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test that extension 'mp4' is return from url ending with .mp4
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide_ie = GlideIE(url)
    ext = glide_ie._get_ext()
    assert(ext == 'mp4')

# Generated at 2022-06-24 12:29:21.752904
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor.get_info_extractor(GlideIE.IE_NAME)
    
    # Try some invalid URLs and make sure that they fail
    try:
        ie.extract(GlideIE._VALID_URL)
        raise RuntimeError('Invalid URL has not failed')
    except ValueError:
        pass
    
    # Try a valid URL and make sure that it works
    ie.extract(GlideIE._TEST['url'])

# Generated at 2022-06-24 12:29:22.744839
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()



# Generated at 2022-06-24 12:29:26.439322
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ret = GlideIE({'_type': 'url', 'url': 'http://share.glide.me/x'})
    assert (ret.ie_key() == 'Glide')
    assert (ret.ie_desc() == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:29:35.757654
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test to ensure class constructor of class GlideIE is working as intended
    """
    ie = GlideIE()
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(len(ie._TEST) == 3)
    assert(ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')

# Generated at 2022-06-24 12:29:45.361522
# Unit test for constructor of class GlideIE
def test_GlideIE():

    from youtube_dl.utils import unescapeHTML

    # valid URL
    glide = GlideIE({})
    assert glide._match_id(
        glide.ie_key(),
        'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == \
        'UZF8zlmuQbe4mr+7dCiQ0w=='

    # invalid URL
    glide = GlideIE({})
    assert glide._match_id(
        glide.ie_key(),
        'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') != \
        'XXXXXXXX'


# Generated at 2022-06-24 12:29:47.042754
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    obj = GlideIE('GlideIE', ie._VALID_URL)

# Generated at 2022-06-24 12:29:47.595173
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-24 12:29:58.522066
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info['title'] == "Damon's Glide message"
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:30:00.060933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Summary of GlideIE class
    """
    ie = GlideIE()

# Generated at 2022-06-24 12:30:03.172938
# Unit test for constructor of class GlideIE
def test_GlideIE():
    c = GlideIE()
    c._match_id("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:30:04.418196
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (type(GlideIE({})) == GlideIE)

# Generated at 2022-06-24 12:30:05.938998
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:30:07.911593
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    print(GlideIE())




# Generated at 2022-06-24 12:30:18.058491
# Unit test for constructor of class GlideIE
def test_GlideIE():
  IE = GlideIE()
  assert IE.IE_NAME == 'glide'
  assert IE.IE_DESC == 'Glide mobile video messages (glide.me)'
  assert IE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:19.444646
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test that Glider constructor works properly
    GlideIE()

# Generated at 2022-06-24 12:30:27.557310
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    video_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    glide_ie = GlideIE()
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert glide_ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Unit

# Generated at 2022-06-24 12:30:31.898086
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    assert test_GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test_GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:30:32.827722
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE()

# Generated at 2022-06-24 12:30:33.778369
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:30:35.404150
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Check if constructor created object
    GlideIE_test = GlideIE()


# Generated at 2022-06-24 12:30:45.556505
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(
        'Glide mobile video messages (glide.me)',
        'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'Glide')
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:30:47.191445
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:50.379703
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    assert t._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert t.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:30:50.849235
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:02.334894
# Unit test for constructor of class GlideIE
def test_GlideIE():
        'Test the constructor of class GlideIE'
        url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
        glide_ie = GlideIE()
        glide_ie._match_id(url)
        glide_ie._download_webpage(url, 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:31:03.623165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("Glide mobile video messages (glide.me)")

# Generated at 2022-06-24 12:31:13.219294
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:13.679039
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:16.196646
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._downloader.params['noprogress']

    # Test whether the _VALID_URL regex matches the given url
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-24 12:31:24.990115
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Constructor test
    """
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj.ie_key() == 'Glide'
    assert obj.content_id(GlideIE._VALID_URL) == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj.content_id(GlideIE._VALID_URL, {}) == 'UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-24 12:31:26.681834
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	assert_equal(ie.IE_NAME, 'glide')

# Generated at 2022-06-24 12:31:37.233049
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glideIE = GlideIE()
    assert glideIE.IE_NAME == 'glide'
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    #assert glideIE._TITLE_RE == r'<title>(.+?)</title>'
    #assert glideIE._VIDEO_URL_RE == r'<source[^>]+src=(["\'])(?P<url>.+?)\1'
    #assert glideIE._THUMB_RE == r'<img[^>]+id=["\']video-thumbnail["\'

# Generated at 2022-06-24 12:31:44.155422
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:31:48.389997
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Constructor test for class GlideIE
    """
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:49.770191
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie != None


# Generated at 2022-06-24 12:31:54.525794
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = GlideIE()
    assert infoExtractor.IE_NAME == 'glide.me'
    assert infoExtractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert infoExtractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:56.362139
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).IE_NAME == 'glide'


# Generated at 2022-06-24 12:32:03.254159
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    t._download_webpage('test', 'test')
    t._search_regex('test','test', 'test', 'test')
    t._html_search_regex('test','test', 'test', 'test')
    t._og_search_title('test')
    t._og_search_video_url('test')
    t._og_search_thumbnail('test')
    t._proto_relative_url('test')
    t._match_id('test')
# end of unit test

# Generated at 2022-06-24 12:32:04.083872
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert 'GlideIE' in globals()

# Generated at 2022-06-24 12:32:06.317807
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:32:12.916868
# Unit test for constructor of class GlideIE
def test_GlideIE():
    module = 'extractor.glide'
    className = 'GlideIE'
    Test.Initialize(module, className)
    Test.AddTestCase("test_constuctor", Test.UnitTest.TestCase(module, className, "test_constuctor"))
    Test.AddTestCase("test_real_extract", Test.UnitTest.TestCase(module, className, "test_real_extract"))
    Test.AddTestCase("test_parse_vid", Test.UnitTest.TestCase(module, className, "test_parse_vid"))


# Generated at 2022-06-24 12:32:15.727931
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_extractor = GlideIE(InfoExtractor)

    assert video_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:17.099816
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE("GlideIE", "GlideIE")
    assert "InfoExtractor" in repr(obj)

# Generated at 2022-06-24 12:32:26.857563
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide = GlideIE()
    assert glide.suitable(video_url)

    # it doesn't work on New Glide message
    assert not glide.suitable('http://giphy.com/gifs/a-taste-of-eden-greentea-green-tea-ice-cream-3o6nUYTldyOG3Pq3Tq')

    # it doesn't work on account page
    assert not glide.suitable('https://www.glide.me/glide/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:32:27.540211
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:30.766357
# Unit test for constructor of class GlideIE
def test_GlideIE():
    u"""
    Test for constructor of class GlideIE
    """
    result = GlideIE()
    assert isinstance(result, GlideIE)
    

# Generated at 2022-06-24 12:32:35.025217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:32:35.791625
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('GlideIE')

# Generated at 2022-06-24 12:32:36.907910
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.__name__ == "GlideIE")


# Generated at 2022-06-24 12:32:40.499332
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable("http://share.glide.me/myvideo") == True
    assert GlideIE.IE_NAME == "Glide"
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"


# Generated at 2022-06-24 12:32:41.595935
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:32:44.381771
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.ie_key() == 'glide'
    assert GlideIE.ie_key() == 'glide'
    assert GlideIE.ie_key() == 'glide'
    assert GlideIE.ie_key() == 'glide'

# Generated at 2022-06-24 12:32:51.097691
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:53.683576
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:56.254088
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.ie_key() == 'Glide'
    assert i.IE_DESC is not None

# Generated at 2022-06-24 12:32:58.034707
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(type(GlideIE()).__name__ == 'GlideIE')



# Generated at 2022-06-24 12:33:00.121955
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test GlideIE constructor
    """
    glideIE = GlideIE()
    assert glideIE is not None



# Generated at 2022-06-24 12:33:07.199210
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC is not None
    assert ie._VALID_URL is not None
    assert ie._download_webpage is not None
    assert ie._match_id is not None
    assert ie._real_extract is not None
    assert ie._og_search_title is not None
    assert ie._og_search_thumbnail is not None
    assert ie._og_search_video_url is not None
    assert ie._proto_relative_url is not None
    assert ie._search_regex is not None
    assert ie._html_search_regex is not None

# Generated at 2022-06-24 12:33:10.619496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Simple test of created object - representation
    """
    test_object = GlideIE()
    # test __str__ method
    print(test_object)

# Generated at 2022-06-24 12:33:11.875535
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:33:16.213249
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url, video_id)

# Generated at 2022-06-24 12:33:18.357307
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This is just to test the class constructor. No actual test of the website.
    ie = GlideIE()
    ie.IE_DESC

# Generated at 2022-06-24 12:33:23.889457
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # constructor args: info_extractor, ie_key, ie_desc
    ie = GlideIE(InfoExtractor, 'glide', GlideIE.IE_DESC)
    assert ie.IE_KEY == 'glide'
    assert ie.IE_DESC == GlideIE.IE_DESC
    assert ie.VALID_URL == GlideIE._VALID_URL
    assert ie.TEST == GlideIE._TEST

# Generated at 2022-06-24 12:33:25.060907
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global glide
    glide = GlideIE()

# Generated at 2022-06-24 12:33:27.090327
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert test_obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:29.176485
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(InfoExtractor.get_info_extractor(GlideIE.ie_key()) is not None)


# Generated at 2022-06-24 12:33:36.249794
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST["url"] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST["md5"] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST["info_dict"]["id"] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:39.122184
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE(None, None)
	# Test that constructor raises no errors
	ie.extract()


# Generated at 2022-06-24 12:33:42.104590
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE("GlideIE")
	assert ie.IE_NAME == "GlideIE"
	

# Generated at 2022-06-24 12:33:45.091934
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Checks if GlideIE is a subclass of InfoExtractor
    assert issubclass(GlideIE, InfoExtractor)


# Generated at 2022-06-24 12:33:55.220625
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(info['id'] == "UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(info['title'] == "Damon's Glide message")
    assert(info['url'] == "//video.glide.me/recording/UZF8zlmuQbe4mr+7dCiQ0w==.mp4")
    assert(info['thumbnail'] == "//video-thumb.cloudfront.net/6d5b6fce-9595-11e3-a32a-f23c91c6e1aa.jpg")

# Generated at 2022-06-24 12:33:58.200922
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # pylint: disable=protected-access
    assert GlideIE._VALID_URL == GlideIE.IE_DESC



# Generated at 2022-06-24 12:33:59.702721
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:01.332942
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.IE_NAME == 'glide'


# Generated at 2022-06-24 12:34:02.975389
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_instance = GlideIE()
    assert isinstance(test_instance, InfoExtractor)

# Generated at 2022-06-24 12:34:03.589002
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:04.244378
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('')

# Generated at 2022-06-24 12:34:04.767549
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:06.308892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert InfoExtractor(GlideIE._VALID_URL)._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:34:09.370527
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try :
        GlideIE({})
    except Exception as e :
        print (e)
        assert False
    else:
        assert True

# Generated at 2022-06-24 12:34:16.811379
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    exp_output = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }
    glide = GlideIE()
    output = glide._real_extract(test_url)
    assert exp_output == output

# Generated at 2022-06-24 12:34:19.755143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(1)
    assert obj.name == 'Glide'
    assert obj.ie_key() == 'Glide'
    assert obj.param_template is None
    assert obj.supported_protocols == ['http']
    assert obj.supported_qualities == ['default']

# Generated at 2022-06-24 12:34:21.792337
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_key()

# Generated at 2022-06-24 12:34:22.829405
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:34:27.035527
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(
        None).IE_NAME == GlideIE.IE_NAME
    assert GlideIE(
        None).IE_DESC == GlideIE.IE_DESC
    assert GlideIE(
        None)._VALID_URL == GlideIE._VALID_URL
    assert GlideIE(
        None)._TEST == GlideIE._TEST


# Generated at 2022-06-24 12:34:27.963967
# Unit test for constructor of class GlideIE
def test_GlideIE(): assert hasattr(GlideIE, '_VALID_URL')

# Generated at 2022-06-24 12:34:31.371116
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()
    ie.extract(url)

# Generated at 2022-06-24 12:34:39.484264
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide = GlideIE()
	assert glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert glide._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
	assert glide._TEST['info_dict'] == {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon's Glide message", 'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$'}


# Generated at 2022-06-24 12:34:42.649785
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Call GlideIE constructor with initial parameters
    assert GlideIE('GlideIE', 'glide.me')

# Generated at 2022-06-24 12:34:43.256725
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:43.853960
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:34:53.762507
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:55.744911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:34:56.314812
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:00.824543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    
    # Create test object
    ie = GlideIE()
    
    # Create test url for glide.me videos
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    
    # Check if expected http response is set
    assert(ie.expected_http_response(url) == 200)



# Generated at 2022-06-24 12:35:01.494455
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:05.206710
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-24 12:35:06.290339
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:35:09.444775
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test class constructor
    ie = GlideIE()

    # Test it can handle a valid URL
    test_GlideIE_valid_url(ie)


# Generated at 2022-06-24 12:35:12.583788
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:35:21.598075
# Unit test for constructor of class GlideIE
def test_GlideIE():
	global ie, url, ie_opts, ie_c, ie_desc
	
	ie = GlideIE()
	url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:35:29.703086
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    #Assert that the expected information is extracted from a sample URL
    assert ie._match_id('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._match_id('https://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==') == 'UZF8zlmuQbe4mr-7dCiQ0w=='

# Generated at 2022-06-24 12:35:32.698338
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:35:36.488229
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==');
    assert ie != null;


# Generated at 2022-06-24 12:35:45.007906
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    info = ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['ext'] == 'mp4'
    assert info['title'] == "Damon's Glide message"
    assert info['thumbnail'] is not None
    assert info['thumbnail'].startswith('http')
    assert info['thumbnail'].endswith('.jpg')
    assert info['url'] is not None
    assert info['url'].startswith('http')
    assert info['url'].endswith('.mp4')

# Generated at 2022-06-24 12:35:51.893344
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert test.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:53.877324
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        x = GlideIE(0)
    except:
        assert False, "Fail to construct GlideIE object"


# Generated at 2022-06-24 12:35:56.746901
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract(GlideIE._TEST['url'])

# Generated at 2022-06-24 12:35:58.154928
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # assert constructor exists
    GlideIE


# Generated at 2022-06-24 12:35:58.717497
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:36:01.723465
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/FwDU1ke6uN+6T9LSVu8p6A==")


# Generated at 2022-06-24 12:36:02.268823
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:36:10.206829
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:36:19.874138
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:36:23.190999
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:36:26.247149
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .construct_test import construct_test
    constructor_test_class = construct_test(GlideIE)
    constructor_test_class.test_GlideIE()
    constructor_test_class.test_suite()

# Generated at 2022-06-24 12:36:36.391683
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie_object = GlideIE()
    assert ie_object.IE_NAME == 'glide'
    assert ie_object.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie_object._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:37.544258
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(False)


# Generated at 2022-06-24 12:36:38.581695
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:36:39.473937
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:36:41.939453
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'


if __name__ == '__main__':
    test_GlideIE()