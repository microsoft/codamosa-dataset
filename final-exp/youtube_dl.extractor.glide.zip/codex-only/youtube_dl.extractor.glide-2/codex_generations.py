

# Generated at 2022-06-24 12:26:46.509816
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:26:48.313503
# Unit test for constructor of class GlideIE
def test_GlideIE():
    newobj = GlideIE()
    assert isinstance(newobj._downloader.cache, newobj._downloader.FileCache)

# Generated at 2022-06-24 12:26:50.366282
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("constructed object of class GlideIE")

# Generated at 2022-06-24 12:26:57.225064
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test Valid url
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    valid = GlideIE()._match_id(url)
    assert valid == "UZF8zlmuQbe4mr+7dCiQ0w=="
    # Test Invalid url
    url = "http://share.glide.me/"
    valid = GlideIE()._match_id(url)
    assert valid == None
    # Test get_video_info
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    info = GlideIE.get_video_info(url)

# Generated at 2022-06-24 12:27:08.692003
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:09.672363
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:12.614329
# Unit test for constructor of class GlideIE

# Generated at 2022-06-24 12:27:15.466375
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', {'username': 'abcdef', 'password': '12345'})

# Generated at 2022-06-24 12:27:24.406824
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test GlideIE constructor"""
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:24.964231
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:27:27.053904
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-24 12:27:37.426929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-24 12:27:45.596564
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    # cannot run ie._real_extract(ie._TEST) since it requires network access
    # can only unittest on _VALID_URL and IE_DESC

# Generated at 2022-06-24 12:27:53.788972
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE.ie_key())
    assert ie.ie_key() == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:55.972119
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of class GlideIE
    testObj = GlideIE('')
    assert isinstance(testObj, GlideIE)

# Generated at 2022-06-24 12:27:58.222387
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None, 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:07.934377
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:10.471339
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:28:11.643143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie == GlideIE
    assert ie.ie_key() == 'Glide'

# Generated at 2022-06-24 12:28:14.598998
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ''' Test constructor of class GlideIE '''
    ie = GlideIE()
    ie.IE_DESC
    ie.IE_NAME
    ie._VALID_URL
    ie.IE_VERSION
    ie._TESTS

# Generated at 2022-06-24 12:28:21.082125
# Unit test for constructor of class GlideIE
def test_GlideIE():
  """
  Test class for GlideIE class
  """
  test_instance = GlideIE()
  expected_title = "Damon's Glide message"
  expected_id = "UZF8zlmuQbe4mr+7dCiQ0w=="

  assert test_instance._TEST['info_dict']['title'] == expected_title
  assert test_instance._TEST['info_dict']['id'] == expected_id


# Generated at 2022-06-24 12:28:31.089124
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests instantiation of class GlideIE with a URL for a glide video message
    glide = GlideIE()
    assert glide.IE_NAME == 'glide'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:33.611006
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test instantiation of GlideIE object
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, GlideIE)

# Generated at 2022-06-24 12:28:35.792434
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 12:28:41.839859
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    This test is meant to be run by nosetests.
    '''
    

# Generated at 2022-06-24 12:28:42.726923
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test(GlideIE)


# Generated at 2022-06-24 12:28:45.934806
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:46.520196
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:48.159458
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert isinstance(instance, GlideIE)


# Generated at 2022-06-24 12:28:59.239679
# Unit test for constructor of class GlideIE
def test_GlideIE():
	g = GlideIE()
	g.IE_DESC = 'Glide mobile video messages (glide.me)'
	g._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:01.949756
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        glide = GlideIE()
    except:
        print("Error in initializing GlideIE")
        return False
    return True

# Generated at 2022-06-24 12:29:04.559811
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:07.208103
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:29:08.173481
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass



# Generated at 2022-06-24 12:29:19.691955
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:29:27.943004
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
   

# Generated at 2022-06-24 12:29:35.090583
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:45.066574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from unittest.case import TestCase
    from youtube_dl.compat import compat_str

    class TestGlideIE(TestCase):
        def test_constructor(self):
            self.assertIsInstance(
                GlideIE({'extractor': 'Glide'}),
                InfoExtractor)
            self.assertIsInstance(
                GlideIE({'extractor': compat_str('Glide')}),
                InfoExtractor)
            self.assertIsInstance(
                GlideIE({'extractor': 'GlideIE'}),
                InfoExtractor)
            self.assertIsInstance(
                GlideIE({'extractor': compat_str('GlideIE')}),
                InfoExtractor)

    TestGlideIE('test_constructor').run()

# Generated at 2022-06-24 12:29:49.024560
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test for constructor of class GlideIE
    # get class GlideIE
    GlideIE_class = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # get title of this video
    title = GlideIE_class.IE_DESC
    # print("title: %s" % title)
    # assert title is not null
    assert title is not None


# Generated at 2022-06-24 12:29:51.280749
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie


# Generated at 2022-06-24 12:29:56.441110
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glide.me/T1A0gViRTFKxOc8sZLQ_Zg==')

# Generated at 2022-06-24 12:29:57.422139
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x is not None

# Generated at 2022-06-24 12:30:00.965819
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:30:09.083929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # url is valid url
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # extract id from url
    id = GlideIE()._match_id(url)
    assert isinstance(id, str)
    assert id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # extract content from webpage
    webpage = GlideIE()._download_webpage(url, id)
    assert isinstance(webpage, str)
    # find the title
    title = GlideIE()._html_search_regex(
            r'<title>(.+?)</title>', webpage,
            'title', default=None)
    assert isinstance(title, str)

# Generated at 2022-06-24 12:30:11.213311
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(video_id)

# Generated at 2022-06-24 12:30:15.209994
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE()._VALID_URL == \
        'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:21.220891
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:30:24.814380
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test object GlideIE
    obj = GlideIE()
    assert obj.ie_key() == 'Glide'

    # Test object GlideIE
    obj = GlideIE(GlideIE.ie_key())
    assert obj.ie_key() == 'Glide'

# Generated at 2022-06-24 12:30:27.199716
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:30:30.860816
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Positive test
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    info = ie.extract(url)
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['title'] == "Damon's Glide message"
    assert info['thumbnail'] != None
    assert info['url'] != None
    # Negative test
    url = 'http://www.test.com/test.com'
    try:
        info = ie.extract(url)
        raise AssertionError('Failed to catch error of inavlid id.')
    except:
        pass

# Generated at 2022-06-24 12:30:32.116654
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:30:40.480234
# Unit test for constructor of class GlideIE
def test_GlideIE():
   glide = GlideIE()
   assert isinstance(glide, InfoExtractor)
   assert glide.EXTENSIONS == ('mkv', 'mp4', 'mov', 'ogv', 'ogg', 'webm', 'wmv')
   assert glide.IE_NAME == 'glide.me'
   assert glide.VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
   assert glide.WEBPAGE_URL == 'https://glide.me/app/%s'
   assert glide.ie_key() == 'glide:%s'

# Generated at 2022-06-24 12:30:46.139399
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test = {
		'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
		'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        },
		'params': {
			'format': 'bestvideo'
		}
	}

	from youtube_dl.YoutubeDL import YoutubeDL
	import os
	from os.path import relpath
	

# Generated at 2022-06-24 12:30:54.657515
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:56.846161
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("Executing unit test for class GlideIE")
    glide = GlideIE("GlideIE")

# Generated at 2022-06-24 12:30:59.835541
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:31:10.569097
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # GlideIE._VALID_URL should be a string
    assert isinstance(ie._VALID_URL, str)
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    # GlideIE._TEST should be a dict
    assert isinstance(ie._TEST, dict)

# Generated at 2022-06-24 12:31:12.899033
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE(InfoExtractor)._VALID_URL==r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:15.947092
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:19.781489
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:31:23.906998
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE = GlideIE()
    assert GlideIE.IE_NAME == 'Glide'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE.IE_CODE == 'Glide'


# Generated at 2022-06-24 12:31:30.388389
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    url = 'https://share.glide.me/6GP-V6U1jKUu_o9QKW8RcA=='
    #md5 = '4466372687352851af2d131cfaa8a4c7'
    ie = GlideIE()
    ie._call_downloader(url)
    #ie.download(url)


if __name__ == '__main__':
    import sys
    test_GlideIE()

# Generated at 2022-06-24 12:31:35.056558
# Unit test for constructor of class GlideIE
def test_GlideIE():
    
    url = 'http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w=='
    GlideIE_test = GlideIE()
    GlideIE_test._match_id(url)
    assert True

# Generated at 2022-06-24 12:31:40.804225
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("https://share.glide.me/2QtLHJtWQ0uAZE0N_Zjzkw==")
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie.url_re.pattern == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:43.403564
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__name__ == 'GlideIE'
    assert GlideIE.IE_NAME == 'Glide'


# Generated at 2022-06-24 12:31:53.566155
# Unit test for constructor of class GlideIE
def test_GlideIE():

    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    test_instance = GlideIE()
    video_id = test_instance._match_id(url)
    webpage = test_instance._download_webpage(url, video_id)
    title = test_instance._html_search_regex(
            r'<title>(.+?)</title>', webpage,
            'title', default=None) or test_instance._og_search_title(webpage)

# Generated at 2022-06-24 12:31:57.235319
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:06.082236
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_glideIE = GlideIE()
    assert test_glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==' in test_glideIE._TEST['url']
    assert test_glideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert 'UZF8zlmuQbe4mr+7dCiQ0w==' in test_glideIE._TEST

# Generated at 2022-06-24 12:32:10.897215
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """test_GlideIE"""
    glideIE = GlideIE()
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glideIE.IE_NAME == 'glide'
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:32:18.873613
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:19.882401
# Unit test for constructor of class GlideIE
def test_GlideIE():
        ie = GlideIE()
        assert ie is not None

# Generated at 2022-06-24 12:32:23.853970
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:32:26.959776
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:32:32.986318
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert (ie.IE_NAME == 'Glide')
    assert (ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert (ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-24 12:32:36.832951
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'glide'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == GlideIE._VALID_URL

# Class test case for GlideIE class

# Generated at 2022-06-24 12:32:42.123028
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # pylint: disable=line-too-long
    # pylint: disable=invalid-name
    ie = GlideIE('')
    # pylint: enable=line-too-long
    # pylint: enable=invalid-name
    # No need to test anything since GlideIE class will be used only as a
    # superclass and the real work will happen in other classes
    # that inherit from GlideIE

# Generated at 2022-06-24 12:32:43.665552
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie,InfoExtractor)


# Generated at 2022-06-24 12:32:50.266980
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    info_dict = {
        'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
        'ext': 'mp4',
        'title': "Damon's Glide message",
        'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
    }
    assert ie.extract() == info_dict

# Generated at 2022-06-24 12:32:56.555033
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:32:59.481316
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:02.557683
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:33:03.424873
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-24 12:33:07.098283
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:33:13.755032
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    # file_dict key saved in 
    # {'class':'GlideIE', 'filename':'youtube.py'}
    assert glide_ie.ie_key() == 'GlideIE'
    assert glide_ie.ie_key() != 'GlideIETTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT'



# Generated at 2022-06-24 12:33:18.448661
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Ensure that we're able to create an instance of the class
    instance = GlideIE()
    assert instance is not None
    # Just confirm that it is an instance of the correct class
    assert isinstance(instance, GlideIE)
    print('Success!')
    
if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:33:19.384654
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(GlideIE())

# Generated at 2022-06-24 12:33:20.491517
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test_Glide = GlideIE()
	print (test_Glide)

# Generated at 2022-06-24 12:33:25.067345
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert 'Glide' in ie.IE_NAME
    assert ie.IE_DESC
    assert ie._VALID_URL
    assert ie.app_version
    assert ie.app_version_regex
    assert ie.app_version_string
    assert ie._TEST

# Generated at 2022-06-24 12:33:26.843068
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
 

# Generated at 2022-06-24 12:33:28.092260
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:33:35.099872
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:33:40.393738
# Unit test for constructor of class GlideIE
def test_GlideIE():   
    # Object created
    obj = GlideIE()
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:33:42.205529
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-24 12:33:50.433208
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import GlideIE
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # testing video download
    ie._download_webpage = lambda a, b : open("test.html").read()
    video_info = ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert video_info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert video_info['title'] == "Damon's Glide message"

# Generated at 2022-06-24 12:33:59.657428
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    # Test sample video from README.md
    # http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.title == "Damon's Glide message"
    assert ie.id == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:34:04.431628
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Test that the class can be called
	print("Calling class GlideIE")
	obj = GlideIE()
	#print obj.proto_relative_url("https://../test")
	return True

if __name__ == '__main__':
    if test_GlideIE():
        print("Success testing class GlideIE")
    else:
        print("Testing of class GlideIE failed")

# Generated at 2022-06-24 12:34:08.501021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_NAME == 'glide')
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:34:09.581199
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-24 12:34:13.634561
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE(InfoExtractor())
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    test_GlideIE.suitable(url)
    test_GlideIE.extract(url)

# Generated at 2022-06-24 12:34:23.649485
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test with GlideIE URL
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:25.122852
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Just make the constructor of class GlideIE work if run directly as a script"""
    GlideIE()

# Generated at 2022-06-24 12:34:31.018374
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result = GlideIE()
    assert result.IE_NAME == 'Glide'
    assert result.name != None
    assert result.IE_DESC != None
    assert result.VALID_URL != None
    assert result.TEST != None
    assert result.BROADCASTER != None
    assert result.IE_KEY != None
    assert result.is_suitable != None

# Generated at 2022-06-24 12:34:36.113183
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/([A-Za-z0-9\-=_+]+)'

# Unit tests for the 'test_GlideIE' function (test_GlideIE.test_test_GlideIE)

# Generated at 2022-06-24 12:34:43.751603
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == "glide"
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:34:46.336164
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	# Test to ensure that the constructor of the IE classes have been called
	assert (ie is not None)

# Generated at 2022-06-24 12:34:48.888519
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"



# Generated at 2022-06-24 12:34:50.246069
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    inst.download(inst._TEST['url'])
    assert True

# Generated at 2022-06-24 12:34:52.646605
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:34:53.854407
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor.IE_NAME

# Generated at 2022-06-24 12:34:56.528324
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    assert IE.IE_NAME == 'glide'
    assert IE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:35:05.320589
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:07.020407
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE(GlideIE.ie_key())


# Generated at 2022-06-24 12:35:07.558457
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-24 12:35:18.587855
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:35:19.145882
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE

# Generated at 2022-06-24 12:35:20.962193
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:35:30.180151
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test(GlideIE, {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    })

# Generated at 2022-06-24 12:35:31.535202
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-24 12:35:34.871767
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')



# Generated at 2022-06-24 12:35:44.392986
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    test = ie._TEST
    assert test['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert test['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert test['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:35:53.014686
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import os, sys, inspect
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)
    from yt_downloader import YTDownloader
    # Class GlideIE creation test
    glide_ie = GlideIE({})
    # Instance method _real_extract test
    #glide_ie._real_extract({'url':'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='})

# Generated at 2022-06-24 12:35:55.481879
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL ==  r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:00.138693
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Provided by: https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/common.py
	# YouTube URLs can be handled by common codebase
	# URLS can be directly passed to common constructor
    assert GlideIE(GlideIE.common) is not None

# Generated at 2022-06-24 12:36:07.217266
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:18.194215
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._match_id('http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==') == 'UZF8zlmuQbe4mr-7dCiQ0w=='
    assert GlideIE._match_id('http://share.glide.me/UZF8zlmuQbe4mr_7dCiQ0w==') == 'UZF8zlmuQbe4mr_7dCiQ0w=='

# Generated at 2022-06-24 12:36:28.015335
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_NAME == 'glide'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:36:33.609697
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ifile = "/Users/penglu/Desktop/test.html"
    with open(ifile, 'r') as f:
        html = f.read()
        extractor = GlideIE()
        #extractor._type = 'html'
        #extractor._webpage = html
        extractor._html_search_regex(r'<title>(.+?)</title>', html, 'title', default=None)

# Generated at 2022-06-24 12:36:37.042341
# Unit test for constructor of class GlideIE
def test_GlideIE():
	from .common import InfoExtractor
	from .glide import GlideIE
	from .generic_downloader import GenericDownloader
	glide = GlideIE()
	assert(isinstance(glide, GenericDownloader))

# Generated at 2022-06-24 12:36:41.760237
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'glide:glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'