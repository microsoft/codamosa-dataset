

# Generated at 2022-06-24 12:26:38.926765
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:26:41.059370
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Testing GlideIE constructor
    my_ie = GlideIE()
    assert my_ie.__class__.__name__ == "GlideIE"


# Generated at 2022-06-24 12:26:45.210216
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:26:45.717881
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE

# Generated at 2022-06-24 12:26:46.482942
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:26:47.870892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert str(ie.__class__) == '__main__.GlideIE', 'Class of IE has not been initialized properly'

# Generated at 2022-06-24 12:26:49.403501
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True

# Generated at 2022-06-24 12:26:58.857801
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from pprint import pprint

    # Internally generated test
    def GlideIE_unit_test_1(self):

        # This is the URL of a Glide video that is 6 seconds duration
        test_urls = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

        ie = GlideIE(self)

        # Call to extract the actual video URL
        ie_result = ie.extract(test_urls)

        # A sample result set of video URLs to compare against

# Generated at 2022-06-24 12:27:00.740232
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test = GlideIE()
	test.test()

# Generated at 2022-06-24 12:27:10.491908
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:11.795015
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie



# Generated at 2022-06-24 12:27:14.782293
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:17.153566
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test for constructor of class GlideIE"""
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D')


# Generated at 2022-06-24 12:27:19.388610
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:27:21.525948
# Unit test for constructor of class GlideIE
def test_GlideIE():
    globals()['GlideIE']('Glide', {'id': 'UZF8zlmuQbe4mr+7dCiQ0w=='})

# Generated at 2022-06-24 12:27:23.736685
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    ie = GlideIE()
    assert ie is not None


# Generated at 2022-06-24 12:27:24.666033
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE({})

# Generated at 2022-06-24 12:27:26.690232
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_NAME == 'glide')
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-24 12:27:31.356456
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    GlideIE = custom_GlideIE = type('custom_GlideIE', (GlideIE,), dict(GlideIE.__dict__))
    GlideIE = custom_GlideIE(InfoExtractor._downloader)
    assert isinstance(GlideIE, InfoExtractor)

# Generated at 2022-06-24 12:27:33.478317
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # just for run test
    GlideIE('K9IWX7VhO6J0Dj7wRA8z1w==')

# Generated at 2022-06-24 12:27:35.127616
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Just testing the class constructor
    x = GlideIE()
    assert x

# Generated at 2022-06-24 12:27:42.561738
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# def glide_download(url, output_dir='.', merge=True, info_only=False, **kwargs):
#     """Download Glide videos (glide.me)
#
#     Args:
#         url (str): Glide video page URL
#         output_dir (str): Location to save the video
#         merge (bool): Merge the video parts if there are multiple video parts
#         info_only (bool): Print video information only
#
#     Returns:
#         Undetermined
#     """
#     GlideIE().download(url, output_dir, merge, info_only, **kwargs)

# Generated at 2022-06-24 12:27:51.285456
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:27:54.013863
# Unit test for constructor of class GlideIE
def test_GlideIE():
    G = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:28:04.079225
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.ie_key() == 'Glide'
    assert glide_ie._TEST.get('url') == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide_ie._TEST.get('md5') == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:28:05.411148
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:06.986850
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # We are not testing the correct working of the constructor in this unit test
    pass

# Generated at 2022-06-24 12:28:07.531414
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:28:17.949516
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for titles
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    url = 'http://share.glide.me/' + video_id

    # Case 1: Test with title in title tag
    webpage = '<title>Damon&#39;s Glide message</title>'
    ie = GlideIE(url)
    assert ie._search_regex(r'<title>(.+?)</title>', webpage, 'title') == "Damon's Glide message"

    # Case 2: Test with title in og:title tag
    webpage = '<meta property="og:title" content="Download Glide" />'
    ie = GlideIE(url)
    assert ie._og_search_title(webpage) == 'Download Glide'

   

# Generated at 2022-06-24 12:28:21.252730
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide=GlideIE()
	glide._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
	print("Success")

#test_GlideIE()

# Generated at 2022-06-24 12:28:25.232650
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glide = GlideIE()
    assert glide._match_id(url) == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:28:29.676271
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE({})
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:28:30.962327
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__name__ == "GlideIE"

# Generated at 2022-06-24 12:28:32.468591
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE({})
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-24 12:28:36.825241
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._match_id(ie.IE_NAME) == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:28:37.562785
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('www')


# Generated at 2022-06-24 12:28:45.333566
# Unit test for constructor of class GlideIE
def test_GlideIE():
    b = GlideIE()
    b.get_url_from_web_page()
    b.get_url_from_web_page(url="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    b.get_url_from_web_page(url="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w")
    b.get_url_from_web_page(url="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=")

# Generated at 2022-06-24 12:28:46.295187
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()._real_extract(url)

# Generated at 2022-06-24 12:28:47.212940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, InfoExtractor)

# Generated at 2022-06-24 12:28:50.152407
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    # Test asserts for the constructor
    assert ie != None
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:29:00.387906
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:29:02.620322
# Unit test for constructor of class GlideIE
def test_GlideIE():
        test_class = GlideIE()
        assert test_class

# Unit test to check if url as input returns its corresponding webpage as output

# Generated at 2022-06-24 12:29:04.755015
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE("")
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 12:29:07.011553
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), GlideIE)
# Test that glide.me URLs with a proper ID can be extracted

# Generated at 2022-06-24 12:29:09.134567
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit test for constructor of class GlideIE
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:29:09.681446
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:29:11.293788
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-24 12:29:23.100710
# Unit test for constructor of class GlideIE
def test_GlideIE():

    args={'url_test':'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
          'expected_md5':'4466372687352851af2d131cfaa8a4c7',
          'expected_type':'video',
          'id_test':'UZF8zlmuQbe4mr+7dCiQ0w==',
          'ext_test':'mp4'}

    obj = GlideIE(**args)

    obj.url_test = args['url_test']
    obj.id_test = args['id_test']
    obj.ext_test = args['ext_test']

    result = obj.extract()


# Generated at 2022-06-24 12:29:25.000761
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') is not None

# Generated at 2022-06-24 12:29:26.628949
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, GlideIE)

# Generated at 2022-06-24 12:29:35.840309
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:36.726810
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:29:41.356498
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-24 12:29:49.801865
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE._VALID_URL == r'(?i)(?:https?://)?share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:29:57.764740
# Unit test for constructor of class GlideIE
def test_GlideIE():
    E = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    expected = "UZF8zlmuQbe4mr+7dCiQ0w=="
    actual = E._match_id(url)
    if(actual == expected):
        print("Test passed, got expected: " + expected)
    else:
        print("Test failed, expected: " + expected + " and got: " + actual)


# Generated at 2022-06-24 12:29:59.700778
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-24 12:30:00.439925
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:30:02.835423
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .extractor import Extractor
    assert isinstance(GlideIE(Extractor()), Extractor)

# Generated at 2022-06-24 12:30:04.765174
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:30:07.963026
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:09.088578
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()


# Generated at 2022-06-24 12:30:19.038712
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-24 12:30:22.041186
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:30:23.794821
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test GlideIE class's constructor
    from .common import GlideIE
    assert GlideIE

# Generated at 2022-06-24 12:30:28.030313
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst_GlideIE = GlideIE()
    assert inst_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:31.359148
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(u'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    title = ie.extract()['title']
    assert title == "Damon's Glide message"

# Generated at 2022-06-24 12:30:39.876808
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST["url"] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST["md5"] == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-24 12:30:47.675543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/glide/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.ie_key() == 'Glide'
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.suitable(ie.url)
    assert not ie.suitable('http://nonexistent.test/')

    assert ie.url_transparent(ie.url)
    assert ie.url_transparent('http://example.com/')
    assert not ie.url_transparent('http://example.com/')


# Generated at 2022-06-24 12:30:48.737828
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor).ie_key() == 'Glide'

# Generated at 2022-06-24 12:30:54.309116
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert hasattr(ie, '_TEST')


# Generated at 2022-06-24 12:30:58.652620
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:30:59.934836
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide  = GlideIE()

# Generated at 2022-06-24 12:31:00.911304
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:31:03.093480
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-24 12:31:04.762161
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:06.517096
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide'

# Generated at 2022-06-24 12:31:08.202233
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    assert GlideIE()

# Generated at 2022-06-24 12:31:10.860392
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This is an example of Glidemobile video message
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._real_extract(url)

# Generated at 2022-06-24 12:31:13.181606
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glideObj = GlideIE()
	assert glideObj._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-24 12:31:14.459900
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    obj = GlideIE({'extractor':ie}, None) # instantiate your class

# Generated at 2022-06-24 12:31:16.788724
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Constructor test
    """
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:31:17.946701
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE

# Generated at 2022-06-24 12:31:18.566153
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:31:22.030600
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor()
    ie.add_info_extractor(GlideIE())
    ie.extract("http://share.glide.me/bubbzzzG;RExHmEt+w==")

# Generated at 2022-06-24 12:31:24.945488
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.get_url_regex() == ('https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:31:32.638257
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	assert obj._GLIDE_URL_TEMPLATE == 'http://share.glide.me/%s'
	assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:31:35.450702
# Unit test for constructor of class GlideIE
def test_GlideIE():
	url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
	assert GlideIE(InfoExtractor).suitable(url)

# Generated at 2022-06-24 12:31:36.376869
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-24 12:31:43.448692
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # url with no video url, no title
    url = 'http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D'
    ie.extract(url)
    # url with video url, no title
    url = 'http://share.glide.me/UZF9jVu4Q8e4mr%2B7dCiQ0w%3D%3D'
    ie.extract(url)

# Generated at 2022-06-24 12:31:49.231002
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test with a valid URL
    Globals.get_info_extractor(GlideIE._VALID_URL)._real_extract(GlideIE._TEST['url'])
    # Test with an invalid URL
    Globals.get_info_extractor("http://www.google.com/")._real_extract("http://www.google.com/")

# Generated at 2022-06-24 12:31:51.917430
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert isinstance(obj, InfoExtractor)
    assert hasattr(obj, '_VALID_URL')
    assert hasattr(obj, 'IE_NAME')

# Generated at 2022-06-24 12:32:03.089061
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    extractor = GlideIE()

# Generated at 2022-06-24 12:32:04.342636
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:32:13.253397
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == InfoExtractor.ie_key_map['glide']
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    Test = ie._TEST

# Generated at 2022-06-24 12:32:14.874834
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of class GlideIE
    ie = GlideIE()
    # Test type of ie
    assert ie.IE_DESC

# Generated at 2022-06-24 12:32:15.369422
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:32:20.619313
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE(InfoExtractor()).IE_NAME == 'glide')
    assert(GlideIE(InfoExtractor()).IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(GlideIE(InfoExtractor())._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:32:21.538710
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)

# Generated at 2022-06-24 12:32:29.266437
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE(__name__)._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

## Unit test for method of class GlideIE
#def test_real_extract(self):
#    GlideIE(__name__)._real_extract(r'https?://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:32:38.721096
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-24 12:32:45.818720
# Unit test for constructor of class GlideIE
def test_GlideIE():
  # Try for a Glide video url
  url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
  ie = GlideIE(url)
  assert ie._VALID_URL == GlideIE._VALID_URL
  assert ie._TEST == GlideIE._TEST
  # Try catching the exception
  try:
    # Try for an invalid url
    url = "http://www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    ie = GlideIE(url)
  except:
    pass
  else:
    raise

# Generated at 2022-06-24 12:32:56.905373
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('')
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:05.792301
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()

    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:11.321066
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-24 12:33:12.216615
# Unit test for constructor of class GlideIE
def test_GlideIE():
    the_result = GlideIE()


# Generated at 2022-06-24 12:33:14.979045
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:19.949573
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:33:23.463288
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, GlideIE)
    assert ie.IE_NAME == "GlideIE"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"


# Generated at 2022-06-24 12:33:32.656121
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = GlideIE._TEST['url']
    ie = GlideIE()
    video_id = ie._match_id(url)

    webpage = ie._download_webpage(url, video_id)

    title = ie._html_search_regex(
        r'<title>(.+?)</title>', webpage,
        'title', default=None) or ie._og_search_title(webpage)
    video_url = ie._proto_relative_url(ie._search_regex(
        r'<source[^>]+src=(["\'])(?P<url>.+?)\1',
        webpage, 'video URL', default=None,
        group='url')) or ie._og_search_video_url(webpage)

# Generated at 2022-06-24 12:33:34.733011
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL
    assert ie.IE_DESC

# Generated at 2022-06-24 12:33:36.173756
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    assert IE.IE_NAME == 'glide'

# Generated at 2022-06-24 12:33:38.277910
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()

# Generated at 2022-06-24 12:33:39.619232
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-24 12:33:49.446466
# Unit test for constructor of class GlideIE
def test_GlideIE():
	#initialization
	ie = GlideIE()
	#value checking
	assert ie.IE_NAME == 'glide'
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:33:52.525535
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    except:
        print("error in loading GlideIE")

# Generated at 2022-06-24 12:33:53.478441
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE


# Generated at 2022-06-24 12:33:54.808847
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert isinstance(extractor, GlideIE)


# Generated at 2022-06-24 12:33:56.437808
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glideIE = GlideIE(common_info_extractor)

if __name__ == "__main__":
	test_GlideIE()

# Generated at 2022-06-24 12:34:00.238740
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Make sure the constructor for GlideIE works.
    sut = GlideIE()
    expected_ie_desc = "Glide mobile video messages (glide.me)"
    actual_ie_desc = sut.ie_desc()
    assert expected_ie_desc == actual_ie_desc


# Generated at 2022-06-24 12:34:01.504591
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().ie_key() == 'Glide'

# Generated at 2022-06-24 12:34:06.094982
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    ie._VALID_URL = 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:10.214228
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.__class__.__name__ == 'GlideIE'
    assert ie.IE_NAME == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-24 12:34:15.007786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    testUrl = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    testID = GlideIE._VALID_URL_RE.match(testUrl)
    assert ie._match_id(testUrl) == testID, ie._match_id(testUrl)

# Generated at 2022-06-24 12:34:24.738334
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')

# Generated at 2022-06-24 12:34:27.497506
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie=GlideIE()
	assert isinstance(ie, GlideIE)
	assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:34:28.096640
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE();

# Generated at 2022-06-24 12:34:29.813472
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test GlideIE"""

    # Check normal constructor of class GlideIE
    assert "GlideIE()"

# Generated at 2022-06-24 12:34:34.888580
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:34:43.137771
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    If a GlideIE object is created, are the instance variables being set
    to expectations?
    """
    extractor = GlideIE()
    assert extractor._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:53.297558
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:34:56.998633
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """test for 'GlideIE'"""
    test_object = GlideIE()
    #assert test_object.filename is not None
    #assert test_object.extract is not None
    #assert test_object.dl is not None
    #assert test_object.url is not None


# Generated at 2022-06-24 12:35:03.652172
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE()._build_info(
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        '4466372687352851af2d131cfaa8a4c7',
        'UZF8zlmuQbe4mr+7dCiQ0w==',
        'mp4',
        "Damon's Glide message",
        r'^https?://.*?\.cloudfront\.net/.*\.jpg$'
    )

    assert info is not None
    assert info['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-24 12:35:10.223453
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Variable _TEST is global because we don't want to lose its
    # contents
    global _TEST
    _TEST = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    # Call constructor of GlideIE
    ie = GlideIE

# Generated at 2022-06-24 12:35:15.989726
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    glide = GlideIE()
    assert_equal(glide.IE_NAME, 'glide.me')
    assert_equal(glide.IE_DESC, 'Glide mobile video messages (glide.me)')
    assert_equal(glide._VALID_URL, 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-24 12:35:20.221200
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-24 12:35:20.739099
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-24 12:35:23.195810
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-24 12:35:25.239064
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test Glide constructor
    GlideIE(1)

# Generated at 2022-06-24 12:35:29.986565
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test with valid Glide url.
    ie = GlideIE('https://share.glide.me/DZtHaRzRQ1e4mr+7dCiQ0w==')
    assert ie != None
    # Test with invalid Glide url.
    ie = GlideIE('https://share.glide.me/')
    assert ie == None

# Generated at 2022-06-24 12:35:30.841199
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-24 12:35:32.796621
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'



# Generated at 2022-06-24 12:35:33.362158
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-24 12:35:43.363932
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.get_url_regex() == GlideIE._VALID_URL)
    assert(ie.get_url_regex() != 'wrong')
    GlideIE._TEST['url'] = 'http://share.glide.me/abc'
    assert(ie.extract('http://share.glide.me/abc') != 'wrong')
    assert(ie.extract('http://share.glide.me/abc') != None)
    assert(ie.get_url_regex() != None)
    assert(ie.is_suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True)

# Generated at 2022-06-24 12:35:51.349843
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractorTest
    from .common import InfoExtractor
    from .common import InfoExtractorTest
    from .common import InfoExtractorTest
    from .common import InfoExtractorTest
    from .common import InfoExtractorTest
    from .common import InfoExtractorTest
    from .common import InfoExtractorTest
    from .common import InfoExtractorTest
    from .common import InfoExtractorTest
    from .common import InfoExtractor
    from .common import InfoExtractorTest
    from .common import InfoExtractorTest
    from .common import InfoExtractor
    from .common import InfoExtractorTest
    from .common import InfoExtractor
    from .common import InfoExtractorTest
    from .common import Info

# Generated at 2022-06-24 12:35:59.882988
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE(None)

    assert glide.get_test()[0] == {
            'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
            'md5': '4466372687352851af2d131cfaa8a4c7',
            'info_dict': {
                'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
                'ext': 'mp4',
                'title': "Damon's Glide message",
                'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
            }
        }

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-24 12:36:00.738184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE().IE_DESC


# Generated at 2022-06-24 12:36:01.723001
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(callable(GlideIE))

# Generated at 2022-06-24 12:36:02.748559
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from Glide import GlideIE

# Generated at 2022-06-24 12:36:09.578475
# Unit test for constructor of class GlideIE
def test_GlideIE():
    tem = GlideIE()
    assert tem.name() == 'Glide'
    assert tem.description() == 'Glide mobile video messages (glide.me)'
    assert tem.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert tem._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-24 12:36:12.542996
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-24 12:36:13.592903
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie is not None

# Generated at 2022-06-24 12:36:21.712135
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ext = GlideIE()
    assert(ext.IE_NAME == 'glide')
    assert(ext.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(ext._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-24 12:36:22.734442
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print(ie.IE_DESC)


# Generated at 2022-06-24 12:36:31.233786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    iExtractor = GlideIE()
    assert iExtractor.IE_NAME == "Glide"
    assert iExtractor.IE_DESC == "Glide mobile video messages (glide.me)"
    assert iExtractor.IE_VERSION == ">=0.21.0"
    assert iExtractor.IE_URL == "https://www.glide.me/"
    assert iExtractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert iExtractor._TEST[
        'url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-24 12:36:33.227167
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("GlideIE")
    assert ie.name == "GlideIE"

# Generated at 2022-06-24 12:36:35.777250
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')