

# Generated at 2022-06-12 17:24:53.151631
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-12 17:25:02.925236
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:05.026821
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:25:16.549428
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"

# Generated at 2022-06-12 17:25:19.357605
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert ('GlideIE', True, []) == InfoExtractor._call_ie('glide:UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:20.021584
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE()

# Generated at 2022-06-12 17:25:29.191798
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.ie_key() == 'glide'
    assert GlideIE.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:37.598355
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:25:40.638284
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE
    assert class_._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:42.301564
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:54.323695
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    # test the unit test :-)
    assert test_GlideIE.__name__ == 'test_GlideIE', 'Test must be called test_GlideIE'
    # create instance of class
    instance = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # assert that IE may be used on the URL
    assert instance._VALID_URL == GlideIE._VALID_URL, 'URL matches expression'
    # assert that IE extracts the ID from the URL
    assert instance._match_id(instance._VALID_URL) == GlideIE._TEST['url'], 'ID extracted'
    # assert that IE may be used for the extracted ID
    assert instance._real_ext

# Generated at 2022-06-12 17:25:54.822543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:57.635578
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:02.918585
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Just test the constructor
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Just test the constructor, but with an invalid URL
    GlideIE('http://share.glide.me/')
    pass

# Generated at 2022-06-12 17:26:04.376911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE
    instance = class_()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-12 17:26:12.889351
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:17.668667
# Unit test for constructor of class GlideIE
def test_GlideIE():
    media_url = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')._download_webpage('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(media_url)

# Generated at 2022-06-12 17:26:19.413681
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:26:32.528691
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inputs = [
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==',
        'http://share.glide.me/UZF8zlmuQbe4mr_7dCiQ0w==',
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==/',
    ]

    result = GlideIE(inputs, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert result.name is 'Glide'

# Generated at 2022-06-12 17:26:40.441358
# Unit test for constructor of class GlideIE
def test_GlideIE():

    import sys, os
    import inspect
    sys_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, sys_path)
    from ytb_extractor import GlideIE

    # create a object
    glide_ie = GlideIE()

    # print all members of object
    print_members = [attr for attr in dir(glide_ie) if not callable(getattr(glide_ie, attr)) and not attr.startswith("__")]

    print("All members of object GlideIE:")
    for member in print_members:
        print("{}: {}".format(member, getattr(glide_ie, member)))

    # print all functions
    print

# Generated at 2022-06-12 17:26:53.152913
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC is not None
    assert GlideIE.IE_NAME is not None
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE.IE_NAME == "Glide"


# Generated at 2022-06-12 17:26:59.557900
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # For cases where the regexes matching the video ID in _VALID_URL do
    # not match the given URL, ensure that GlideIE raises the expected
    # exception
    from ..utils import ExtractorError
    url = 'http://share.glide.me/AnInvalidID'
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL
    with pytest.raises(ExtractorError) as excinfo:
        ie.suitable(url)
        assert 'Invalid Glide ID' in str(excinfo)

# Generated at 2022-06-12 17:27:00.066304
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:03.309582
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        assert isinstance(GlideIE(), InfoExtractor) == True
    except:
        assert True == False

# Generated at 2022-06-12 17:27:05.831036
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

if __name__ == '__main__':
    # Unit test
    test_GlideIE()

# Generated at 2022-06-12 17:27:13.928079
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("https://")
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:14.491279
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-12 17:27:16.959347
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url)

# Generated at 2022-06-12 17:27:17.459734
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:19.424823
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import FakeYDL
    from . import GlideIE
    ydl = FakeYDL()
    GlideIE(ydl)(GlideIE._TEST['url'])

# Generated at 2022-06-12 17:27:36.560349
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Test for correct metadata extraction
    
    metadata = {'extractor': 'Glide',
                'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
                'title': "Damon's Glide message",
                'url': 'http://d3f7izc8d8scx0.cloudfront.net/glide/UZF8zlmuQbe4mr+7dCiQ0w==.mp4',
                'thumbnail':'https://d3f7izc8d8scx0.cloudfront.net/glide/UZF8zlmuQbe4mr+7dCiQ0w==.jpg'}
    
    

# Generated at 2022-06-12 17:27:38.931878
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Dummy'
    assert ie.IE_DESC == 'Dummy'

# Generated at 2022-06-12 17:27:47.428580
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert x.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:27:54.098833
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.title == 'Damon\'s Glide message'
    assert ie.thumbnail == 'http://thumbs.cloudfront.net/u/UZF8zlmuQbe4mr+7dCiQ0w==-M-480x480.jpg'

# Generated at 2022-06-12 17:27:58.312626
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj.__class__.__name__ == 'GlideIE'

# Generated at 2022-06-12 17:27:59.269078
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("GlideIE", "glide.me")

# Generated at 2022-06-12 17:28:09.048938
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:09.772923
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:28:13.130440
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:28:13.543770
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-12 17:28:40.633011
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE."""
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    # Should be raised ValueError, since the url is invalid
    try:
        GlideIE('www.invalid_url.com/foo_bar')
    except ValueError:
        pass

    # Should be raised ValueError, since the url is invalid
    try:
        GlideIE('www.invalid_url.com/foo_bar')
    except ValueError:
        pass

    # Should not raise ValueError, since the url is valid
    try:
        GlideIE(url)
    except ValueError:
        raise Exception('Should not raise ValueError, since the url is valid.')


# Generated at 2022-06-12 17:28:47.303194
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .test_caption import _TEST

    ie = GlideIE(GlideIE._VALID_URL, {'_downloader': _TEST['downloader']})
    # test the result of _match_id
    assert ie._match_id(GlideIE._VALID_URL) == _TEST['url']
    assert ie._match_id(_TEST['url']) == _TEST['url']
    # test the result of _real_extract
    assert ie._real_extract(_TEST['url']) == _TEST

# Generated at 2022-06-12 17:28:48.413862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiate object
    GlideIE(None, None)

# Generated at 2022-06-12 17:28:54.831290
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Test that _VALID_URL is set
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Test that _TEST is set

# Generated at 2022-06-12 17:28:58.071922
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # just test the GlideIE constructor
    # real test are in GlideTest.test_real_video
    GlideIE()

# Generated at 2022-06-12 17:29:06.364649
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE(url)
    assert ie.url == url
    assert isinstance(ie.IE_DESC, str)
    assert ie.IE_NAME == ie.IE_DESC
    assert ie.CONFIG_REQUEST_HEADERS.get('User-Agent')
    assert ie.CONFIG_REQUEST_HEADERS.get('X-Requested-With')
    assert ie.CONFIG_REQUEST_HEADERS.get('Accept')
    assert ie.CONFIG_REQUEST_HEADERS.get('Accept-Language')
    assert ie.CONFIG_REQUEST_HEADERS.get('Accept-Charset')
    assert ie.CONFIG_REQUEST_HEADERS.get

# Generated at 2022-06-12 17:29:11.749688
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test that class GlideIE is an instance of the class InfoExtractor
    is_instance_of_info_extractor = isinstance(GlideIE, InfoExtractor)
    # test that class GlideIE is an instance of the class InfoExtractor
    assert is_instance_of_info_extractor, "class GlideIE is not an instance of the class InfoExtractor"

# Generated at 2022-06-12 17:29:14.197843
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """GlideIE empty constructor"""
    ie = GlideIE(None)

    # test title
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:29:25.740940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:29:27.707050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gl = GlideIE()
    assert isinstance(gl, GlideIE)

# Test if the url actually exists and is correct

# Generated at 2022-06-12 17:29:57.356505
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE()
    assert(a)

# Generated at 2022-06-12 17:30:00.632844
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://www.google.com/', 'http://www.google.com/')

# Generated at 2022-06-12 17:30:09.241597
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:14.709649
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test the constructor of class GlideIE
    """
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide_ie = GlideIE(url)
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:30:20.192931
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:30:20.979072
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE();


# Generated at 2022-06-12 17:30:28.283549
# Unit test for constructor of class GlideIE
def test_GlideIE():
    result_GlideIE = GlideIE()
    assert result_GlideIE.IE_NAME == 'Glide'
    assert result_GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert result_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:31.165726
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:32.459305
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:30:34.755699
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    assert t._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:31:51.311524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    raise NotImplementedError('Test not yet implemented.')

# Generated at 2022-06-12 17:31:53.526762
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == GlideIE.IE_NAME
    assert ie.IE_DESC == GlideIE.IE_DESC


# Generated at 2022-06-12 17:31:54.556068
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-12 17:31:55.168940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-12 17:31:57.724748
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    test.executor()
    assert test._VALID_URL =='https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:31:58.651365
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Verify that an instance of class GlideIE was successfully constructed
    assert GlideIE()

# Generated at 2022-06-12 17:32:05.275297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # It has the same constructors of InfoExtractor

    # test for the _VALID_URL parameter
    obj = GlideIE(GlideIE._VALID_URL)

    assert obj._VALID_URL == GlideIE._VALID_URL
    assert obj._TEST == GlideIE._TEST
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert obj._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:32:07.931018
# Unit test for constructor of class GlideIE
def test_GlideIE():
    youtube_ie = GlideIE(GlideIE._downloader)
    assert youtube_ie.IE_NAME == GlideIE.IE_NAME
    assert youtube_ie.IE_DESC == GlideIE.IE_DESC
    assert youtube_ie._VALID_URL == GlideIE._VALID_URL
    assert youtube_ie._TEST == GlideIE._TEST

# Generated at 2022-06-12 17:32:08.584722
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-12 17:32:09.675414
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-12 17:34:50.861892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    glide = GlideIE()
    assert glide.name == 'glide'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'