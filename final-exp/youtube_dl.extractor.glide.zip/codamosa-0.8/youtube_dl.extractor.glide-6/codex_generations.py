

# Generated at 2022-06-12 17:24:55.848311
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit tests for the class with some input values, we want to make sure that
    the inside of the class is working as expected
    """
    GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:24:59.382785
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:00.921943
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        assert False, "Error while initializing GlideIE"

# Generated at 2022-06-12 17:25:03.536327
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glideIE = GlideIE()
    return True


# Generated at 2022-06-12 17:25:08.747067
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:11.314582
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor = 'class GlideIE({}):'.format('InfoExtractor')
    assert constructor in GlideIE.__repr__()

# Generated at 2022-06-12 17:25:17.661184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:25:19.630595
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(GlideIE)

# Example of usage GlideIE
if __name__ == '__main__':
    test = GlideIE().extract(GlideIE._TEST['url'])
    print(test)

# Generated at 2022-06-12 17:25:22.130517
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Unit test for constructor of class GlideIE """
    GlideIE()

# Generated at 2022-06-12 17:25:23.985619
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test case of GlideIE class
    return GlideIE

# Generated at 2022-06-12 17:25:36.355996
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:36.850616
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:43.496254
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    expected_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.URL == expected_url
    #assert ie.extractor_key == 'Glide'


# Generated at 2022-06-12 17:25:49.926468
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = (~GlideIE)(GlideIE._TEST['url'])
    assert url.md5 == GlideIE._TEST['md5'], \
        "Metadata 'md5' should be extracted correctly"
    assert url.info_dict == GlideIE._TEST['info_dict'], \
        "Metadata 'info_dict' should be extracted correctly"
    assert url.id == GlideIE._TEST['info_dict']['id'], \
        "Metadata 'id' should be extracted correctly"

# Generated at 2022-06-12 17:25:55.645174
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()

    if callable(getattr(instance, '_real_extract', None)):
        instance._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    assert(hasattr(instance, '_TEST'))
    assert(hasattr(instance, 'IE_DESC'))
    assert(hasattr(instance, '_VALID_URL'))


# Generated at 2022-06-12 17:25:57.201959
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 17:26:07.464497
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    extractor = GlideIE(url)
    assert extractor.title == "Damon's Glide message"
    assert extractor.id == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-12 17:26:15.300685
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test with a non-Glide URL
    ie = GlideIE()
    test_url = "http://www.youtube.com/watch?v=dsgw7"
    assert ie.suitable(test_url) == False

    # Test with a Glide URL
    ie = GlideIE()
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie.suitable(test_url) == True

# Generated at 2022-06-12 17:26:16.528336
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """GlideIE should initialize correctly."""
    # Init GlideIE object
    GlideIE()

# Generated at 2022-06-12 17:26:20.415977
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'http://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    

# Generated at 2022-06-12 17:26:27.045947
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-12 17:26:36.616972
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor = GlideIE('GlideIE')
    assert constructor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert constructor.IE_NAME == 'glide'
    assert constructor.VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:40.834744
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test for the default constructor of GlideIE
    test = GlideIE()
    assert test is not None
    # Test for the constructor with input video url of GlideIE
    test = GlideIE(url='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert test is not None

# Generated at 2022-06-12 17:26:44.823488
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Basic test for class GlideIE
    """
    glide_ie = GlideIE()
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:48.301616
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/fTADT6eoU6OxGx6xFQ1mXQ==')
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:59.371710
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:27:06.510561
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE.expect_name = 'GlideIE'
    test_GlideIE.expect_desc = 'Glide mobile video messages (glide.me)'
    test_GlideIE.expect_valid_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    test_GlideIE.expect_type = 'generic'
    test_GlideIE.expect_ie = 'Glide'
    test_GlideIE.expect_extract = 'http://videos-b-3.glide.me/036/030/123487d8-baa0-11e4-aeb4-00a3a4c4d4b4.mp4'

    # Construct an instance of GlideIE

# Generated at 2022-06-12 17:27:07.762817
# Unit test for constructor of class GlideIE
def test_GlideIE():
    b = GlideIE()
    assert b


# Generated at 2022-06-12 17:27:08.696576
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-12 17:27:11.759937
# Unit test for constructor of class GlideIE
def test_GlideIE():
    out = GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert out['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:27:36.164298
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:38.519727
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:27:44.846387
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Tests the constructor of class GlideIE.
    """
    from urllib import quote
    from .common import klass_to_test

    info_extractor = klass_to_test['youtube'](None)

    glide_url = 'http://share.glide.me/' + quote('UZF8zlmuQbe4mr+7dCiQ0w==')
    info_extractor._download_webpage(glide_url, 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:27:46.910348
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE()._VALID_URL == GlideIE()._VALID_URL

# Generated at 2022-06-12 17:27:54.415470
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test
    """
    glide = GlideIE()
    glide.IE_DESC                                           # returns 'Glide mobile video messages (glide.me)'
    glide._VALID_URL                                       # returns 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    glide._TEST                                            # returns {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 'title': "Damon

# Generated at 2022-06-12 17:27:59.493355
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from youtube_dl.utils import tests
    from youtube_dl.extractor import gen_extractors_by_class

    tests.add_os_env_var('http_proxy', '127.0.0.1:8118')
    for ie in gen_extractors_by_class(GlideIE):
        assert ie._downloader is not None, ie.IE_NAME + ' not initialized'
        ie._downloader.http.close()
    tests.del_os_env_var('http_proxy')

# Generated at 2022-06-12 17:28:02.438695
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:28:02.929752
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:28:03.447424
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:28:07.699417
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE()
    ie_result = ie.extract(url)
    assert ie_result is not None

# Generated at 2022-06-12 17:28:45.546032
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:28:51.867862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST
    ie._TEST.get('expect_warnings')
    ie.IE_NAME
    ie.work()
    ie.extract()
    ie.extract_from_url()
    ie.geet_url()
    ie.get_url()
    ie.get_video_info()
    ie.get_video_info_from_url()
    ie.get_video_info_from_url_handle()
    ie.get_video_info_from_url_handle_no_download()

# Generated at 2022-06-12 17:28:53.404441
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE("test")
    assert isinstance(instance, GlideIE)
    with pytest.raises(AttributeError):
        instance.test()


# Generated at 2022-06-12 17:28:55.284464
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Test constructor GlideIE """
    assert GlideIE

# Generated at 2022-06-12 17:28:58.430894
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/ZqXdN10pRZiRnxRyysfx-w==')

# Generated at 2022-06-12 17:28:59.024835
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:29:06.996117
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import unittest

    class TestGlideIE(unittest.TestCase):
        def test_GlideIE(self):
            glide_info_extractor = GlideIE()
            self.assertEqual(glide_info_extractor.IE_DESC, 'Glide mobile video messages (glide.me)')
            self.assertEqual(glide_info_extractor._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
            self.assertEqual(len(glide_info_extractor._TEST), 4)
            self.assertTrue(isinstance(glide_info_extractor._TEST['url'], str))

# Generated at 2022-06-12 17:29:08.142745
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-12 17:29:14.082661
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Test constructor of class GlideIE.
    """
    # This video has a title in the meta information on the video-page
    url_1 = 'http://share.glide.me/BKZR2QZ-T++TvB8Wb3AqEg=='
    # Video has no title in the meta-information on the video-page
    url_2 = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # This video has a http-link in the meta-information on the video-page
    url_3 = 'http://share.glide.me/RgRNWQi1SkKIV_I4X4DtSw=='
    # This video has a https-link in the meta-information on the video-page


# Generated at 2022-06-12 17:29:16.262323
# Unit test for constructor of class GlideIE
def test_GlideIE():
    tester = GlideIE()
    assert tester



# Generated at 2022-06-12 17:30:24.916037
# Unit test for constructor of class GlideIE
def test_GlideIE():
    tmp = GlideIE()
    assert tmp.IE_NAME == 'glide'
    assert tmp.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert tmp._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:28.562476
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    i = GlideIE()
    results = i.extract(url)
    assert results["id"] == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert results["title"] == "Damon's Glide message"


# Generated at 2022-06-12 17:30:29.521332
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:30:31.571272
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:33.628415
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-12 17:30:35.459184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:30:39.394446
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:41.922738
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_class = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:30:44.932574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:30:47.854930
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert len(ie.TESTS) == 1

# Generated at 2022-06-12 17:33:23.495886
# Unit test for constructor of class GlideIE
def test_GlideIE():
    entry1 = GlideIE({'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='})
    assert entry1
    assert entry1.params()

    entry2 = GlideIE({'url': 'http://share.glide.me/9ZF8zlmuQbe4mr+7dCiQ0w=='})
    assert entry2
    assert entry2.params()

# Generated at 2022-06-12 17:33:24.216183
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(info_dict={})

# Generated at 2022-06-12 17:33:28.852161
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:33:31.325598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('www.user.org',{})
    assert (ie.ie_key() == 'Glide')

# Generated at 2022-06-12 17:33:33.440286
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    glide = GlideIE._TEST
    info_extractor._match_id(glide['url'])

# Generated at 2022-06-12 17:33:35.391241
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.get_info.__name__ == 'get_info'

# Generated at 2022-06-12 17:33:42.628333
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    # Create an instance of class GlideIE
    glide_ie = GlideIE()

    # Check IE description
    assert(glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)')

    # Check valid URL regex
    match = re.match(glide_ie._VALID_URL, "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(match.group() == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")


# Generated at 2022-06-12 17:33:44.427873
# Unit test for constructor of class GlideIE
def test_GlideIE():
    globals()['GlideIE']('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:33:47.834479
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    expected_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    actual_id = ie._match_id(url)
    assert expected_id == actual_id


# Generated at 2022-06-12 17:33:48.567492
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie != None