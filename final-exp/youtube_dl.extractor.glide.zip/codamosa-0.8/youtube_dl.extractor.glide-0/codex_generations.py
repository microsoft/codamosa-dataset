

# Generated at 2022-06-12 17:24:55.488651
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    expected = (GlideIE._VALID_URL, 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert (test_GlideIE._VALID_URL, test_GlideIE._match_id(test_GlideIE._VALID_URL)) == expected

test_GlideIE()

# Generated at 2022-06-12 17:24:58.469062
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    glide.glide_extractor("https://share.glide.me/7V5W5n5YZV/nZF5_hX4W4")

# Generated at 2022-06-12 17:24:59.269952
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	obj.extract()

# Generated at 2022-06-12 17:25:01.034778
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()
    #test_GlideIE.extractor()
    return test_GlideIE


# Generated at 2022-06-12 17:25:12.654020
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Tests with good URLs
    url1 = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    url2 = 'http://share.glide.me/-s8FcHwACAXxXXPHFFlgmg=='
    url3 = 'http://share.glide.me/f8Gc0HwACAXxXXPHFFlgmg=='
    glide1 = GlideIE(url1)
    glide2 = GlideIE(url2)
    glide3 = GlideIE(url3)
    glide1.IE_DESC == 'Glide mobile video messages (glide.me)'
    glide2.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:25:13.705931
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()



# Generated at 2022-06-12 17:25:15.684420
# Unit test for constructor of class GlideIE
def test_GlideIE():
	try :
		GlideIE("https://share.glide.me/81NhRbz9PxWIW-rkfNpAVw==")
		return True
	except Exception:
		return False

# Generated at 2022-06-12 17:25:26.368384
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide mobile video messages (glide.me)"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:27.889252
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())._download_webpage()

# Generated at 2022-06-12 17:25:32.665385
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE()
    assert(IE.IE_NAME == 'glide')
    assert(IE.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(IE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-12 17:25:41.424578
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert(glide != None)

# Generated at 2022-06-12 17:25:42.210288
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:43.805319
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    assert ie.IE_NAME == "GlideIE";

# Generated at 2022-06-12 17:25:53.197399
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from unittest import TestCase
    from youtube_dl import YoutubeDL
    from youtube_dl.utils import ExtractorError

    with YoutubeDL({}) as ydl:
        assert ydl.extract_info('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', download=False)['title'] == "Damon's Glide message"

        GlideIE._VALID_URL = 'not a valid url'
        with TestCase.assertRaises(TestCase, ExtractorError) as cm:
            ydl.extract_info('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', download=False)

# Generated at 2022-06-12 17:25:58.050859
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import sys
    import types

    def test_constructor(self):
        glide1 = GlideIE(self.extractor_info)
        assert_true(isinstance(glide1, InfoExtractor))
        assert_equal(glide1.IE_NAME, 'glide')
        assert_equal(glide1.IE_DESC, 'Glide mobile video messages (glide.me)')

    GlideIE.test_constructor = types.MethodType(test_constructor, GlideIE)
    unittest.main(argv=[sys.argv[0]])


# Generated at 2022-06-12 17:26:00.553924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE."""
    assert GlideIE()

# Generated at 2022-06-12 17:26:01.598021
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)._download_webpage()

# Generated at 2022-06-12 17:26:04.635475
# Unit test for constructor of class GlideIE
def test_GlideIE():
	url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	ie = GlideIE(url)
	print (ie.extract_info())
# Unit test
test_GlideIE()

# Generated at 2022-06-12 17:26:07.186484
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
	assert ie.IE_NAME == "Glide"

# Generated at 2022-06-12 17:26:10.331532
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit test for constructor of class GlideIE
    assert GlideIE

# Generated at 2022-06-12 17:26:19.993496
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
	assert GlideIE()._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:27.814925
# Unit test for constructor of class GlideIE
def test_GlideIE():
  import unittest
  from types import ModuleType

  class TestGlideIE(unittest.TestCase):
    def test_GlideIE(self):
      assert isinstance(GlideIE, type), 'It is not type'
      assert isinstance(GlideIE, ModuleType), 'It is not module'

  TestGlideIE().test_GlideIE()

# Generated at 2022-06-12 17:26:38.904647
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    info_extractor.IE_DESC = "Glide mobile video messages (glide.me)"
    info_extractor._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:40.053574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC

# Generated at 2022-06-12 17:26:41.004569
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlobieIE()
	print(obj.__dict__)

# Generated at 2022-06-12 17:26:41.613713
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:26:46.296779
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    test_glide_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.suitable(test_glide_url)
    match = ie._VALID_URL_RE.match(test_glide_url)
    assert match
    assert match.groupdict()['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    #TODO: test _real_extract
    pass

# Generated at 2022-06-12 17:26:53.138273
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Get test data
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    webpage = '<html><body>GlideIE webpage</body></html>'

    # Create an instance of GlideIE
    glide = GlideIE()
    glide.IE_NAME = 'glide'
    glide.IE_DESC = 'Glide mobile video messages (glide.me)'
    glide._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:56.170473
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:58.579982
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test1 = GlideIE()
    assert set(test1.IE_DESC.split(' ')) == {'Glide', 'video', 'messages', 'mobile', '(glide.me)'}

# Generated at 2022-06-12 17:27:12.906507
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 'glide' in GlideIE.IE_NAME

# Generated at 2022-06-12 17:27:14.448183
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:18.765032
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiation
    glide = GlideIE()
    # Testing call
    glide.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Testing private method
    glide._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:27:22.217112
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract(GlideIE._TEST['url'])

# Generated at 2022-06-12 17:27:23.637050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:24.561591
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None).IE_NAME == 'glide'


# Generated at 2022-06-12 17:27:25.490116
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .extractor.GlideIE import GlideIE
    glide = GlideIE()
    assert glide is not None

# Generated at 2022-06-12 17:27:30.098617
# Unit test for constructor of class GlideIE
def test_GlideIE():
    check = GlideIE()
    check.IE_DESC = 'Glide mobile video messages (glide.me)'
    check._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:34.247239
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._real_initialize()
    GlideIE()._real_extract(test_url)

# Generated at 2022-06-12 17:27:44.616844
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:22.202145
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create an instance of GlideIE
    video_ie = GlideIE()

    # Extract video information
    video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    video = video_ie.extract(video_url)

    # Display relevant information
    print("Video URL: " + video_url)
    print("Title: " + video['title'])
    print("ID: " + video['id'])

# Generated at 2022-06-12 17:28:27.628035
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r'^https://',
        }
    }

    ie = GlideIE()

    assert ie.suitable(test['url']) is True
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-12 17:28:33.083982
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Test with a valid URL
    ie = GlideIE({})
    assert isinstance(ie, GlideIE)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:38.949834
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.__class__.__name__ == 'GlideIE'
    assert ie.interest_urls == ['http://share.glide.me/']


# Generated at 2022-06-12 17:28:48.719818
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:51.580803
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert len(ie._TEST) == len(ie.IE_DESC)

# Generated at 2022-06-12 17:28:52.872581
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Unit tests for class GlideIE

# Generated at 2022-06-12 17:28:57.167534
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test GlideIE.__init__() constructor
    print("Test GlideIE.__init__() constructor")
    assert True


# Generated at 2022-06-12 17:28:59.836019
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:29:02.252653
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #assert isinstance(vars()["GlideIE"], type(InfoExtractor))
    assert isinstance(vars()["GlideIE"], type(GlideIE))


# Generated at 2022-06-12 17:30:03.626008
# Unit test for constructor of class GlideIE
def test_GlideIE(): assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:30:10.804447
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')

# Generated at 2022-06-12 17:30:11.526450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:30:15.910356
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_name = "GlideIE"
    # Check if class exist
    if (class_name in globals()):
        # Create instance of class
        instance = globals()[class_name]()
        # Check if class have expected methods
        assert hasattr(instance, "_real_extract")
        assert hasattr(instance, "IE_DESC")
        assert hasattr(instance, "_VALID_URL")
        assert hasattr(instance, "_TEST")

# Generated at 2022-06-12 17:30:20.111895
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(issubclass(GlideIE, InfoExtractor))
    IE = GlideIE()
    assert(IE.ie_key() == 'Glide')
    assert(IE.ie_desc() == 'Glide mobile video messages (glide.me)')
# Test URL

# Generated at 2022-06-12 17:30:23.720541
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', True)

# Generated at 2022-06-12 17:30:30.406371
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    assert t.IE_DESC == "Glide mobile video messages (glide.me)"
    assert t._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:35.154848
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    test_result = ie.IE_DESC + ' ' + ie._VALID_URL

    assert test_result == 'Glide mobile video messages (glide.me) https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:30:35.874848
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ins = GlideIE()
    assert ins != None

# Generated at 2022-06-12 17:30:36.505861
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:33:21.649509
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:33:24.955411
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:33:36.395551
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.valid_url == True
    assert ie.extractor_key == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:33:39.450481
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:33:40.329330
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor('glide'))

# Generated at 2022-06-12 17:33:47.184486
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:33:56.937908
# Unit test for constructor of class GlideIE
def test_GlideIE():
    _GlideIE = GlideIE()
    assert_equal(_GlideIE.ie_key(), 'Glide')
    assert_equal(_GlideIE._VALID_URL, r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert_equal(_GlideIE.IE_DESC, 'Glide mobile video messages (glide.me)')
    assert_equal(_GlideIE._TEST['url'], 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert_equal(_GlideIE._TEST['md5'], '4466372687352851af2d131cfaa8a4c7')

# Generated at 2022-06-12 17:34:00.916117
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor1 = GlideIE()
    # Test attributes
    assert info_extractor1.IE_DESC is not None
    assert info_extractor1._VALID_URL is not None
    assert info_extractor1._TEST is not None

# Generated at 2022-06-12 17:34:04.069382
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Field description is specified in the same field as description
    constructor = GlideIE(InfoExtractor())
    result = constructor.IE_DESC
    assert result == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:34:09.664965
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # When constructed, it should call the InfoExtractor's constructor
    # When constructed, it should set the class' name to the IE_NAME constant in its class
    # When constructed, it should set the class to the IE_DESC constant in its class
    # When constructed, it should set the class' supported_protocols to the SUPPORTED_PROTOCOLS constant in its class
    # When constructed, it should set the class to the NEW_WORK_FUNC constant in its class
    # When constructed, it should set the class' _VALID_URL to the REGEX in its class
    # When constructed, it should set the class' _NETRC_MACHINE to the NETRC_MACHINE constant in its class
    pass

