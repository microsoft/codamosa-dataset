

# Generated at 2022-06-12 17:24:57.472821
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:24:58.389035
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()


# Generated at 2022-06-12 17:25:00.784254
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    if (ie.ie_key() != 'Glide') or (ie.IE_NAME != 'Glide'):
        raise AssertionError("Assertion failed")

# Generated at 2022-06-12 17:25:03.277374
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.IE_NAME
    ie.IE_DESC
    ie

# Generated at 2022-06-12 17:25:08.037750
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide_ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	
	assert glide_ie.ie_key() == 'Glide'
	assert glide_ie.ie_desc() == 'Glide mobile video messages (glide.me)'
	assert glide_ie.info_dict() == {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 'ext': 'mp4', 
	'title': "Damon's Glide message", 'thumbnail': "http://d1s1sjpoag0v65.cloudfront.net/postcover/U/Z/UZF8zlmuQbe4mr+7dCiQ0w==.jpg"}

# Generated at 2022-06-12 17:25:15.046311
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_NAME == "glide"
    assert glide_ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.__version__ == "0.1.1"

# Generated at 2022-06-12 17:25:25.969374
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Make sure that the GlideIE constructor is working as it should.
    """
    # Test with all expected REs
    # url
    GlideIE._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # _TEST entry

# Generated at 2022-06-12 17:25:29.002426
# Unit test for constructor of class GlideIE
def test_GlideIE():
    myGlideIE = GlideIE()
    assert myGlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-12 17:25:37.459665
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    test = ie._TEST
    assert test['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert test['md5'] == '4466372687352851af2d131cfaa8a4c7'
    info_dict = test['info_dict']
    assert info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:25:39.341490
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    obj = ie.suite()

# Generated at 2022-06-12 17:25:52.240329
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test constructor of class GlideIE
    """
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.suitable == (lambda x: False)
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-12 17:25:56.272230
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:26:02.541554
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:05.346926
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:26:08.054348
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    tests = ie._TEST
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:10.533238
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:26:11.085750
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-12 17:26:13.555924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        instance = GlideIE()
    except Exception as e:
        assert e.message == "Class GlideIE must define _VALID_URL"


# Generated at 2022-06-12 17:26:20.845091
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Inititiate an object of class GlideIE.
    glide_ie = GlideIE()
    # Test the assertion of class GlideIE.
    assert(glide_ie.IE_DESC) == 'Glide mobile video messages (glide.me)'
    # Test the assertion of class GlideIE.
    assert(glide_ie._VALID_URL) == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Test the assertion of class GlideIE.

# Generated at 2022-06-12 17:26:24.833480
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video = GlideIE()
    video.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:28.724192
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:26:39.751396
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    ie = GlideIE(url)
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    test = ie._TEST
    assert test["url"] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert test["md5"] == "4466372687352851af2d131cfaa8a4c7"
    info_dict = test["info_dict"]
    assert info_

# Generated at 2022-06-12 17:26:41.462525
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i is not None

# Generated at 2022-06-12 17:26:43.814366
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert isinstance(obj, GlideIE)
    

# Generated at 2022-06-12 17:26:47.022411
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

    GlideIE()._real_extract(test_url)

# Generated at 2022-06-12 17:26:53.700706
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
    assert(GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:55.509102
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test(GlideIE)

#Unit test for _real_extract of class GlideIE

# Generated at 2022-06-12 17:26:57.952083
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance._VALID_URL is not None
    assert instance._TEST['url'] is not None
    assert instance._TEST['md5'] is not None

# Generated at 2022-06-12 17:27:02.730724
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:27:12.285956
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:24.058965
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit test for class GlideIE
    # Define a GlideIE
    glide_ie = GlideIE()
    # Check its description
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    # Check its valid_url
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Check its test url/md5/info_dict
    glide_test = glide_ie._TEST
    assert glide_test['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:27:26.154287
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-12 17:27:27.222553
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:34.722950
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Attempt to create an instance of GlideIE
	# with an invalid URL as a parameter
	# It should raise a ValueError when attempting to access attributes of the 
	# instance
	try:
		test = GlideIE("test.com")
		assert(False)
	except ValueError:
		assert(True)

	# Attempt to create an instance of GlideIE with a valid URL as a parameter
	# It should not raise any errors
	try:
		test = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
		assert(True)
	except ValueError:
		assert(False)

	# Attempt to create an instance of GlideIE with the string "random_string"
	# It should raise a ValueError when

# Generated at 2022-06-12 17:27:37.485040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("test.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:27:40.668871
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert g.match(url)

# Generated at 2022-06-12 17:27:41.231231
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:42.172251
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-12 17:27:47.365191
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC
    assert ie._VALID_URL
    assert ie._TEST



# Generated at 2022-06-12 17:27:49.811792
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:28:06.866383
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # To test the constructor, we will create a GlideIE object
    # and see whether the object is an instance of the class InfoExtractor
    ie = GlideIE()
    assert ie is not None
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:28:07.368775
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:28:10.438557
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()
	assert(obj.IE_DESC == "Glide mobile video messages (glide.me)")

# Generated at 2022-06-12 17:28:18.092991
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.title == "Damon's Glide message"

# Generated at 2022-06-12 17:28:18.855677
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide'

# Generated at 2022-06-12 17:28:25.465719
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.ExtractVideoID("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.ExtractVideoTitle("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.ExtractThumbnail("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.ExtractVideoURL("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie.ExtractVideoInfo("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    ie

# Generated at 2022-06-12 17:28:32.217006
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert e._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert e.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert e._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert e._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:28:38.464668
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import expected
    from .common import list_equals
    from .common import assertEquals

    actual = expected(GlideIE())
    assertEquals(actual, {
        'valid': [
            'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        ],
        'invalid': [
            'http://www.glide.me/',
        ],
    })

# Generated at 2022-06-12 17:28:41.231299
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_test = GlideIE()
    assert glide_test != None
    assert "glide" in repr(glide_test)

# Generated at 2022-06-12 17:28:41.701054
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:29:11.058221
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    obj = ie.get_info_extractors()
    obj.sort()
    assert obj[0] == (ie._VALID_URL, ie)

# Generated at 2022-06-12 17:29:11.954579
# Unit test for constructor of class GlideIE
def test_GlideIE():
    me = GlideIE()
    print(me.IE_DESC)

# Generated at 2022-06-12 17:29:14.048811
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Check whether access to class GlideIE is successful.
    # Enable the following test when necessary.
    # info_extractor = GlideIE()
    pass

# Generated at 2022-06-12 17:29:17.358831
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(isinstance(GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='), InfoExtractor))

# Generated at 2022-06-12 17:29:19.510229
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from youtube_dl.extractor.glide import GlideIE
    # Expect to construct an object of class GlideIE
    glide = GlideIE()

# Generated at 2022-06-12 17:29:29.760130
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glide_ie = GlideIE(url)
    assert(glide_ie.test_mode)
    assert(glide_ie.video_info['url'] == "http://d2xjf360gisth.cloudfront.net/videos/2014/05/13/6237/6237.0.mp4")
    assert(glide_ie.video_info['title'] == "Damon's Glide message")
    assert(glide_ie.video_info['thumbnail'] == "http://d2xjf360gisth.cloudfront.net/videos/2014/05/13/6237/thumbnails/thumb.0.jpg")

# Generated at 2022-06-12 17:29:36.599841
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE

    If you change the test, remember to update the expected md5 in _TEST
    """
    import os
    import tempfile
    filepath = os.path.join(tempfile.gettempdir(), "test.mp4")
    ie = GlideIE()
    ie.download(GlideIE._TEST['url'], filepath)

    import hashlib
    md5 = hashlib.md5()
    md5.update(open(filepath, 'rb').read())
    assert(md5.hexdigest() == GlideIE._TEST['md5'])

# Generated at 2022-06-12 17:29:45.328454
# Unit test for constructor of class GlideIE
def test_GlideIE():
    myGLIDE = GlideIE(None)
    assert myGLIDE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert myGLIDE.IE_NAME == 'glide'
    assert myGLIDE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:55.829662
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    GlideIE
    ie_obj = GlideIE(downloaded_webpage='<img id="video-thumbnail" src="https://d1232czg9hy918.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/screen.jpg">\
        <source id="video" src="http://d1232czg9hy918.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/video.mp4">')
    info_dict = ie_obj._real_extract(r'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:30:01.530810
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:31:26.307921
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.name == "Glide mobile video messages (glide.me)"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert ie._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"
    assert ie._

# Generated at 2022-06-12 17:31:32.417764
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Happy path
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

    # URL is missing video ID
    assert_raises_regex(
        RegexMatchError, 'Unsupported URL',
        GlideIE, 'http://share.glide.me/')


# Generated at 2022-06-12 17:31:40.281054
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # construct a new GlideIE
    ie = GlideIE(browser_user_agent='UA')
    ie.url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie.ie_key = 'Glide'
    ie.video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    ie.video_url = None
    try:
        ie.dl_webpage('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'UZF8zlmuQbe4mr+7dCiQ0w==')
        assert False
    except:
        assert True
    assert ie.video_url != None


# Unit

# Generated at 2022-06-12 17:31:42.346387
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE_test = GlideIE()
    assert IE_test.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:31:43.740968
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:31:52.446270
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
    assert(ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie._TEST['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-12 17:31:56.807974
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == GlideIE._TEST['url']
    assert GlideIE(GlideIE._VALID_URL).IE_DESC == GlideIE._TEST['info_dict']['title']
    assert GlideIE(GlideIE._VALID_URL).IE_NAME == GlideIE._TEST['info_dict']['id']

# Generated at 2022-06-12 17:32:03.004979
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_key()

test_cases = [
    'http://share.glide.me/UZF8zlmuQbe4mr~7dCiQ0w==',
    'http://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==',
    'http://share.glide.me/UZF8zlmuQbe4mr_7dCiQ0w==',
    'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
]


# Generated at 2022-06-12 17:32:08.498583
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from tests.test_downloader.test_common import get_testcases
    testcase = get_testcases().get('glide:UZF8zlmuQbe4mr+7dCiQ0w==')
    assert testcase.id() == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert testcase.title() == "Damon's Glide message"
    assert testcase.thumbnail() == 'http://d2vfzl6a5l9buu.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==/thumbnail-83466c2e8641c46fe0ccd8f829e93c3a.jpg'

# Generated at 2022-06-12 17:32:15.433142
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:46.520828
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    test.download('http://share.glide.me/AXc4y4xERe2iqXjb6e2QAQ==')
    test.download('http://share.glide.me/AXc4y4xERe2iqXjb6e2QAQ==')
    test.download('http://share.glide.me/AXc4y4xERe2iqXjb6e2QAQ==')
    test.download('http://share.glide.me/AXc4y4xERe2iqXjb6e2QAQ==')


# Generated at 2022-06-12 17:34:49.933006
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test GlideIE class
    """
    # Constructor test for class GlideIE
    instance = GlideIE(_initialize=False)
    assert isinstance(instance, GlideIE)