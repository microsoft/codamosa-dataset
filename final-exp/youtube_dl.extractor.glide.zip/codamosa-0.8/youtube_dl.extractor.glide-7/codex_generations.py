

# Generated at 2022-06-12 17:24:52.720280
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE(SampleIE('GlideIE'))

# Generated at 2022-06-12 17:25:02.564531
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert(test_obj.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(test_obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-12 17:25:14.241376
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extract = InfoExtractor()
    glide = GlideIE.GlideIE({}, info_extract)
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:25:20.396789
# Unit test for constructor of class GlideIE
def test_GlideIE():
    dummy_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    result = GlideIE()._real_extract(dummy_url)
    assert result['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert result['title'] == "Damon's Glide message"
    assert result['url'] == "http://video-us-west-1.cdn.glide.me/content/UZF8zlmuQbe4mr+7dCiQ0w==/UZF8zlmuQbe4mr+7dCiQ0w==.mp4"

# Generated at 2022-06-12 17:25:22.753049
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-12 17:25:25.044770
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Make sure the string of class GlideIE doesn't change
    assert GlideIE.__name__ == "GlideIE"



# Generated at 2022-06-12 17:25:28.086182
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test that verifies the GlideIE object is created succesfully
    """
    assert GlideIE

# Generated at 2022-06-12 17:25:33.507297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Given
    q = GlideIE()

    # Then
    assert q.IE_NAME == 'Glide'
    assert q.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert q._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert q._TEST


# Generated at 2022-06-12 17:25:36.816704
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    glide.IE_DESC
    glide.IE_NAME
    glide._VALID_URL
    glide._TEST
    glide._downloader
    glide.test()
    glide._real_initialize()
    glide._real_extract(glide._TEST['url'])

# Generated at 2022-06-12 17:25:48.318522
# Unit test for constructor of class GlideIE
def test_GlideIE():
	testObj = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
	print("test_GlideIE")
	assert testObj.IE_DESC == 'Glide mobile video messages (glide.me)', "Test for class GlideIE: IE_DESC()"
	assert testObj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', "Test for class GlideIE: _VALID_URL()"

# Generated at 2022-06-12 17:25:58.700719
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:07.657991
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    yt = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert yt.expected_results == 1
    assert yt.result_counter == 0
    assert yt.progress_hooks == []
    assert yt.params == {'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'}
    assert yt.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert yt.params is not None

# Generated at 2022-06-12 17:26:11.774828
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:14.261326
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == GlideIE._VALID_URL
    assert GlideIE(InfoExtractor()).IE_DESC == GlideIE.IE_DESC

# Generated at 2022-06-12 17:26:17.040672
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print('testing GlideIE')
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)', 'test failed'
    print('passed')


# Generated at 2022-06-12 17:26:17.970284
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, InfoExtractor)

# Generated at 2022-06-12 17:26:19.753441
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:27.741167
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE('GlideIE', 'Glide Mobile Video').IE_DESC == 'Glide mobile video messages (glide.me)'
	assert GlideIE('GlideIE', 'Glide Mobile Video')._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:26:38.904127
# Unit test for constructor of class GlideIE
def test_GlideIE():
    og_search_results = {
        "description" : "Glide — Video Chat Messenger",
        "title" : "Damon's Glide message"
    }
    video_url_res = 'https://media2.glide.me/media/UZF8zlmuQbe4mr+7dCiQ0w==/2015-03-04-01-02-18-040633.mp4'

# Generated at 2022-06-12 17:26:43.710379
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Constructor should not raise an exception
	ie = GlideIE()

# Generated at 2022-06-12 17:26:57.916572
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    # Test that GlideIE has the same variables as in its module
    assert t.IE_NAME == GlideIE.IE_NAME
    assert t.IE_DESC == GlideIE.IE_DESC
    assert t._VALID_URL == GlideIE._VALID_URL
    assert t._TEST == GlideIE._TEST

# Generated at 2022-06-12 17:26:59.907562
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Constructor test"""
    ie = GlideIE()
    assert ie.IE_NAME == 'glide:share'

# Generated at 2022-06-12 17:27:11.397730
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:20.192816
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    expected_md5 = "4466372687352851af2d131cfaa8a4c7"
    expected_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    expected_title = "Damon's Glide message"
    expected_thumbnail = r"https?://.*?\.cloudfront\.net/.*\.jpg"
    ie = GlideIE()
    result = ie.extract(test_url)
    assert expected_md5 == result["md5"]
    assert expected_id == result["id"]
    assert expected_title == result["title"]

# Generated at 2022-06-12 17:27:32.673987
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:36.752697
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert (GlideIE.IE_NAME == 'glide')

# Generated at 2022-06-12 17:27:38.097051
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # this will fail if setting class variables fail
    instance = GlideIE()

# Generated at 2022-06-12 17:27:40.060853
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:27:48.051842
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""

    GlideIE_object = GlideIE()
    assert GlideIE_object.IE_DESC == 'Glide mobile video messages (glide.me)'

    assert GlideIE_object._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:27:54.276845
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie._TEST['md5'] == ie._test_result_video('UZF8zlmuQbe4mr+7dCiQ0w==')['md5']

# Generated at 2022-06-12 17:28:18.855767
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:19.343214
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:28:25.849753
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:28:27.978213
# Unit test for constructor of class GlideIE
def test_GlideIE():
  """Constructor of class GlideIE should return an instance of GlideIE"""
  glideIE = GlideIE()
  assert isinstance(glideIE, GlideIE)

# Generated at 2022-06-12 17:28:29.466766
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create instance of class GlideIE
    assert InfoExtractor.new(GlideIE) is not None

# Generated at 2022-06-12 17:28:31.174316
# Unit test for constructor of class GlideIE
def test_GlideIE():
  try:
    a = GlideIE()
  except:
    assert False
  assert isinstance(a, InfoExtractor)

# Generated at 2022-06-12 17:28:34.816413
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE('local', 'url')


# Generated at 2022-06-12 17:28:37.523980
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Basic unit test to just instantiate the class and make sure it is not
       broken.
    """
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:28:44.149397
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:28:49.058620
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        t = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
        assert isinstance(t,GlideIE)
    except TypeError:
        print(TypeError)
        exit(1)
    except:
        print("Unexpected error:", sys.exc_info()[0])
        exit(1)


# Generated at 2022-06-12 17:29:26.299103
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE(None)
    assert test_obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:30.894972
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == GlideIE._VALID_URL
    assert GlideIE(InfoExtractor())._TEST == GlideIE._TEST
    assert GlideIE(InfoExtractor()).IE_NAME == GlideIE.IE_NAME
    assert GlideIE(InfoExtractor()).IE_DESC == GlideIE.IE_DESC

# Generated at 2022-06-12 17:29:37.630197
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    return GlideIE()._real_extract(test['url'])

# Generated at 2022-06-12 17:29:46.036384
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:29:56.000125
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Testcase for testing constructor of GlideIE class"""
    GLIDE_TEST = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    """Testing GlideIE constructor"""

# Generated at 2022-06-12 17:29:59.874617
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    GlideIE = GlideIE()
    print(GlideIE)

# Generated at 2022-06-12 17:30:00.631911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:30:03.105490
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:30:04.191309
# Unit test for constructor of class GlideIE
def test_GlideIE():
	testclass = GlideIE()
	return True


# Generated at 2022-06-12 17:30:05.591371
# Unit test for constructor of class GlideIE
def test_GlideIE():
    b = GlideIE()
    assert (b != None)
# End class test


# Generated at 2022-06-12 17:31:26.568075
# Unit test for constructor of class GlideIE
def test_GlideIE():
    for _ in range(10):
        test_GlideIE.GlideIE = GlideIE()
        test_GlideIE.GlideIE_video = test_GlideIE.GlideIE.extract(test_GlideIE.GlideIE.IE_DESC)
        test_GlideIE.GlideIE_ext = test_GlideIE.GlideIE_video['ext']
        test_GlideIE.GlideIE_id = test_GlideIE.GlideIE_video['id']
        assert test_GlideIE.test['ext'] == test_GlideIE.GlideIE_ext
        assert test_GlideIE.test['id'] == test_GlideIE.GlideIE_id
    print ('Test passed')


# Test GlideIE
test_GlideIE.test = test_Glide

# Generated at 2022-06-12 17:31:29.809468
# Unit test for constructor of class GlideIE
def test_GlideIE():
    out = GlideIE().IE_DESC
    assert out == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:31:30.753410
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-12 17:31:36.111052
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test case using values from _TEST dictionary
    GlideIE().extract(_TEST['url'])
    # test case using a new url
    GlideIE().extract('http://share.glide.me/SXPdnlKsTp+ZpevTw8+sWQ==')
    # test case with wrong url
    GlideIE().extract('http://share.glide.me/')

# Generated at 2022-06-12 17:31:41.926596
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glide.me/VZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:31:44.923022
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE('Glide', 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(e, GlideIE)
    assert e.name== 'Glide'
    assert e.url =='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:31:46.176597
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None, None) != None

# Generated at 2022-06-12 17:31:48.496754
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:31:49.229451
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE is not None

# Generated at 2022-06-12 17:31:55.304597
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Note that this unit test is bound to fail due to Glide's
    # inconsistent way of generating video URLs
    video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._test_valid_url(video_url, '4466372687352851af2d131cfaa8a4c7',
                              'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:34:24.523368
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # How do I get a test video?
    GlideIE()

# Generated at 2022-06-12 17:34:27.782565
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE(None, None)
    except:
        assert False, 'constructor of class GlideIE called'

# Unit test to check url field of class GlideIE

# Generated at 2022-06-12 17:34:31.208961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:34:35.064346
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glide.me/NWE4MmI3NTY4MmY1YTMzZmM3ZDdiYmFlNzllMjkxNw==')


# Generated at 2022-06-12 17:34:36.343792
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)

# Generated at 2022-06-12 17:34:37.997148
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:34:43.772713
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiating
    glide_ie = GlideIE()
    # regex_match function
    regex_match = glide_ie._VALID_URL
    assert regex_match == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # _match_id function
    match_id = glide_ie._match_id
    assert match_id == GlideIE._VALID_URL
    # _real_extract function
    real_extract = glide_ie._real_extract
    assert real_extract == GlideIE._real_extract

# Generated at 2022-06-12 17:34:45.804676
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj != None

# Generated at 2022-06-12 17:34:51.282415
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # pylint: disable-msg=C0111
    ie = GlideIE('Glide')
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'