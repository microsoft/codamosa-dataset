

# Generated at 2022-06-12 17:24:50.141070
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:24:58.625903
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # skip test if GlideIE is not available
    if not 'GlideIE' in locals():
        raise Exception("GlideIE unavailable")
    # create a test for GlideIE constructor
    ie = GlideIE(None)
    # verify that GlideIE is a subclass of InfoExtractor
    if not issubclass(type(ie), InfoExtractor):
        raise Exception("constructor test failed: GlideIE")


# Generated at 2022-06-12 17:25:00.403365
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:25:06.519866
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:08.193257
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ret = GlideIE()
    assert isinstance(ret, object)

# Generated at 2022-06-12 17:25:10.022899
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test that class can be instantiated
    GlideIE()

# Generated at 2022-06-12 17:25:11.920165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE == InfoExtractor.registry.get(
            'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:23.735077
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_initialize()
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    TEST_URL = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(ie._match_id(TEST_URL) == 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:34.765687
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE =  GlideIE()
    assert glideIE.ie_key() == 'glide'
    assert glideIE.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert glideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glideIE.valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glideIE.video_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:25:46.514084
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Unit test for constructor of class GlideIE
    '''
    glide = GlideIE()

    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:58.949221
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # pylint: disable=protected-access
    GlideIE._download_webpage('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE._search_regex(
        r'<source[^>]+src=(["\'])(?P<url>.+?)\1',
        '<html><source src=\'http://yourdomain.com/yourvideo.mp4\'></html>',
        'video URL', default=None, group='url')

# Generated at 2022-06-12 17:26:00.642786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:26:09.161466
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:26:12.658968
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:20.297245
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_html_search_regex')
    assert hasattr(ie, '_og_search_title')

# Generated at 2022-06-12 17:26:23.218508
# Unit test for constructor of class GlideIE
def test_GlideIE():
  GlideIE

if __name__ == '__main__':
  test_GlideIE()

# Generated at 2022-06-12 17:26:25.003695
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-12 17:26:35.244836
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:37.285177
# Unit test for constructor of class GlideIE
def test_GlideIE():
    st = GlideIE()
    assert st.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:47.470363
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:02.247811
# Unit test for constructor of class GlideIE
def test_GlideIE():
	extractor = GlideIE("")

# Generated at 2022-06-12 17:27:11.979694
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:12.948589
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), GlideIE)

# Generated at 2022-06-12 17:27:23.775679
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title']

# Generated at 2022-06-12 17:27:29.196263
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # The class should be initialized with a file and a domain
    GlideIE("www.google.com","google.com")
    GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==","share.glide.me")

# Generated at 2022-06-12 17:27:40.671085
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==?utm_source=facebook&utm_medium=share-sms')
    assert GlideIE().extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==#utm_source=facebook&utm_medium=share-sms')
    assert GlideIE().extract('http://glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:27:52.169014
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:57.676070
# Unit test for constructor of class GlideIE
def test_GlideIE():
    e = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(e, GlideIE)
    # This is an extractor test, not an IE test so we
    # don't really care about the result
    # assert e._extract<something>

# Generated at 2022-06-12 17:28:03.041403
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test case1:
    #   Test when video URL is given as an argument
    #   If video URL is given, the video should be extracted
    sample_video_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    sample_video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='

    glide_ie = GlideIE(sample_video_url)
    glide_entry = glide_ie._real_extract(sample_video_url)
    assert glide_entry['id'] == sample_video_id
    assert glide_entry['title'] == "Damon's Glide message"

# Generated at 2022-06-12 17:28:05.447572
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:28:50.266283
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:58.912677
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test existing glide video share
    assert len(GlideIE._TEST) == 4
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['info_dict']['ext'] == 'mp4'
    assert GlideIE._TEST['info_dict']['title'] == "Damon's Glide message"

# Generated at 2022-06-12 17:29:02.341720
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    This is a test for the GlideIE constructor.
    """
    try:
        GlideIE(_print=True)
    except NameError:
        raise
    except TypeError:
        assert False, "Invalid GlideIE constructor"


# Generated at 2022-06-12 17:29:03.573737
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie != None, 'GlideIE constructor failed'

# Generated at 2022-06-12 17:29:05.087120
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()) is not None

# Generated at 2022-06-12 17:29:08.767194
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor of class GlideIE.
    # Test object
    wget = Wget(GlideIE())
    # Test output
    assert wget.__str__().startswith("<class GlideIE@")


# Generated at 2022-06-12 17:29:10.293436
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._NAME == "Glide"

# Generated at 2022-06-12 17:29:12.101879
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    # test if name was defined
    assert instance.ie_key() == 'glide'

# Generated at 2022-06-12 17:29:23.668898
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for GlideIE class constructor
    """
    glide = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:29:25.014098
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for GlideIE"""
    GlideIE()

# Generated at 2022-06-12 17:30:34.447591
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info = GlideIE(1)._real_extract("")
    assert info["id"] == ""
    assert info["title"] == ""
    assert info["url"] == ""
    assert info["thumbnail"] == ""

# Generated at 2022-06-12 17:30:35.155924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:30:38.185380
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global ieInstance
    ieInstance = GlideIE()
    assert ieInstance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ieInstance.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:30:39.875398
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    #assert obj.__class__.__name__ == 'GlideIE'
    return obj

# Generated at 2022-06-12 17:30:45.575634
# Unit test for constructor of class GlideIE
def test_GlideIE():
    for url in [
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'http://share.glide.me/hyXYxwiKrJE',
    ]:
        print(GlideIE(url)._download_webpage(url, 'id'))

# Generated at 2022-06-12 17:30:47.336574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test if GlideIE is initialized with correct module as argument
    assert InfoExtractor.__bases__[0].__name__ == "object"

# Generated at 2022-06-12 17:30:49.772836
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert(x.IE_DESC == "Glide mobile video messages (glide.me)")

# Generated at 2022-06-12 17:30:55.971298
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://foo')
    assert ie.URL_PATTERN == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.__name__ == 'GlideIE'

# Generated at 2022-06-12 17:31:00.955014
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Invalid URL.
    assert not GlideIE.suitable("http://example.com/video.mp4")

    # Valid URL.
    assert GlideIE.suitable("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

    # An instance.
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.long_description() == "Glide (glide.me) mobile video messages"
    assert ie.suitable("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert not ie.suitable("http://example.com/video.mp4")

# Generated at 2022-06-12 17:31:03.993029
# Unit test for constructor of class GlideIE
def test_GlideIE():
    me = GlideIE()
    assert me._match_id(me) == me._VALID_URL

# Generated at 2022-06-12 17:32:22.103761
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    # Asserting the class name
    assert instance.IE_NAME == 'GlideIE'
    # Asserting the class description
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    # Asserting the valid url pattern
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:32:23.745612
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:32:25.743790
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide = GlideIE()
    glide.extract(url)

# Generated at 2022-06-12 17:32:26.685693
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Constructor test """
    assert GlideIE(GlideIE._VALID_URL)

# Generated at 2022-06-12 17:32:28.574395
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(False)
    assert ie._download_webpage('http://test.com', 'example', 'test') == None

# Generated at 2022-06-12 17:32:31.609269
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:32:34.399567
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE(GlideIE._downloader, {})
    assert(isinstance(a, GlideIE))
    assert(a.ie_key() == 'Glide')


# Generated at 2022-06-12 17:32:34.890198
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:32:35.663991
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()



# Generated at 2022-06-12 17:32:36.721697
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert hasattr(ie, 'report_warning')