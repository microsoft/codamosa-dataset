

# Generated at 2022-06-12 17:24:52.391462
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._match_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie._real_extract('http://share.glide.me/UZF8zZmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:24:52.958392
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:24:56.445052
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://www.youtube.com/watch?v=BaW_jenozKc").IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:24:57.690184
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(True)

# Generated at 2022-06-12 17:25:01.672930
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(ie.IE_NAME == 'glide')
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-12 17:25:03.287781
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:04.816025
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import datetime
    GlideIE(datetime)
    

# Generated at 2022-06-12 17:25:16.330723
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideie = GlideIE()
    assert glideie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:22.229589
# Unit test for constructor of class GlideIE
def test_GlideIE():
    run_test_IE_constructor(GlideIE)

if __name__ == "__main__":
    try:
        from . import test_GlideIE
        test_GlideIE.main()
        test_GlideIE.main(verb=2)
    except ImportError as err:
        print("Could not run tests:", err)

# Generated at 2022-06-12 17:25:23.302012
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE()

# Generated at 2022-06-12 17:25:32.908736
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')


# Generated at 2022-06-12 17:25:35.640415
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Create a test object
	testGlideObj = GlideIE()
	# Check if it is the correct type
	assert isinstance(testGlideObj, InfoExtractor)

# Generated at 2022-06-12 17:25:40.545503
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:25:50.381821
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._PROXY == 'http://localhost:8118'


# Generated at 2022-06-12 17:25:56.365613
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Setup the GlideIE module and run
    the constructor test logic
    """
    glide_ie = GlideIE()
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.IE_NAME == 'glide'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:25:58.519659
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glideIE = GlideIE()
	assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert glideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:26:01.732087
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == ''
    assert GlidIE._VALID_URL == ''
    assert GlideIE._TEST == ''

# Generated at 2022-06-12 17:26:05.257499
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:26:11.126286
# Unit test for constructor of class GlideIE
def test_GlideIE():
	#Testing GlideIE
	print("\n==== Testing GlideIE ====")
	
	glide_ie = GlideIE()

	assert glide_ie.IE_NAME == 'glide'
	assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	
	print("==== Successfully tested GlideIE ====")

# Generated at 2022-06-12 17:26:17.341036
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == GlideIE._VALID_URL
    assert GlideIE(InfoExtractor())._download_webpage == InfoExtractor._download_webpage
    assert GlideIE(InfoExtractor())._match_id(GlideIE._TEST['url']) == GlideIE._TEST['info_dict']['id']
    assert GlideIE(InfoExtractor())._TEST == GlideIE._TEST
    assert GlideIE(InfoExtractor()).IE_DESC == GlideIE._VALID_URL

test = GlideIE

# Generated at 2022-06-12 17:26:38.557786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_DESC == "Glide mobile video messages (glide.me)"
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert instance._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert instance._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7"
    assert instance._TEST['info_dict']['id'] == "UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-12 17:26:41.377282
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()


# Generated at 2022-06-12 17:26:41.939166
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:26:43.834953
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testObj = GlideIE()

# Generated at 2022-06-12 17:26:49.564113
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(ie)
    print(ie.IE_DESC)
    print(ie.ie_key())
    print(ie.IE_NAME)
    print(ie._VALID_URL)
    print(ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='))

# Generated at 2022-06-12 17:26:50.638673
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-12 17:26:51.331189
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:00.995604
# Unit test for constructor of class GlideIE
def test_GlideIE():
	info = GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	assert info['id'] == "UZF8zlmuQbe4mr+7dCiQ0w=="
	assert info['title'] == "Damon's Glide message"
	assert info['url'] == "//s3-us-west-1.amazonaws.com/glide-user-files/media/UZF8zlmuQbe4mr+7dCiQ0w==.mp4"
	assert info['thumbnail'] == "//d3t87zm5a5iq5c.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==.jpg"

# Generated at 2022-06-12 17:27:07.423732
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:16.528892
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 17:27:29.788890
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE() != None

# Generated at 2022-06-12 17:27:41.186848
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create GlideIE instance
    GlideIEInstance = GlideIE()
    
    # Test the url constructor
    assert GlideIEInstance._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    
    # Test the test dictionary

# Generated at 2022-06-12 17:27:48.307524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.ie_key() == 'Glide'
    assert glide_ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert glide_ie.ie_version() == '0.0.1'
    assert glide_ie.is_suitable(url='https://share.glide.me/asfasfas123123asfasf') == True
    assert glide_ie.is_suitable(url='https://share.glide.me/SOME_NOT_EXISTING_ID') == False
    assert glide_ie.is_suitable(url='http://www.youtube.com/watch?v=BaW_jenozKc') == False

# Generated at 2022-06-12 17:27:50.754216
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_video = GlideIE()
    assert test_video.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:27:54.506845
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:28:01.365571
# Unit test for constructor of class GlideIE
def test_GlideIE():
  video_info = GlideIE()
  video_info._download_webpage = lambda url, video_id: '<html></html>'
  video_info._search_regex = lambda regex, text, name, default, group: 'http://glide.me'
  video_info._match_id = lambda url: 'jxkwjv'

  video_info.ie_key = 'GlideIE'
  expected_result = {'id': 'jxkwjv',
                     'url': 'http://glide.me',
                     'ie_key': 'GlideIE',
                     'thumbnail': None,
                     'title': None}
  assert expected_result == video_info.extract('http://share.glide.me/jxkwjv')


# Generated at 2022-06-12 17:28:02.853392
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(GlideIE)
    x=GlideIE()
    print(x)

# Generated at 2022-06-12 17:28:05.889805
# Unit test for constructor of class GlideIE
def test_GlideIE():
	"""
	Unit test for constructor of class GlideIE
	"""
	glide_ie = GlideIE(None);
	assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)';

# Generated at 2022-06-12 17:28:08.484006
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test creating the object with a wrong initial url
    InfoExtractor.extract('http://www.example.com/')
    # Test creating a GlideIE instance
    InfoExtractor.extract('http://share.glide.me/')

# Generated at 2022-06-12 17:28:12.356037
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http:://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.url == 'http:://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:28:49.389588
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test case to check whether it creates an instance or not
    GlideIE()


# Generated at 2022-06-12 17:28:58.839751
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:29:00.810813
# Unit test for constructor of class GlideIE
def test_GlideIE():
	IE = GlideIE()

# Generated at 2022-06-12 17:29:04.438165
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.get_info('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:29:14.182680
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:18.299815
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._downloader = None
    ie._download_webpage = lambda *args, **kwargs: 'test webpage'
    try:
        ie.extract('test url')
    except Exception:
        assert False

# Generated at 2022-06-12 17:29:28.750274
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:31.663926
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 17:29:32.633337
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:29:35.029050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._real_extract(url)
    assert True

# Generated at 2022-06-12 17:30:49.323524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-12 17:30:49.776934
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:30:57.363051
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Unit test for constructor of class GlideIE
    '''
    glideIE = GlideIE()

    if not isinstance(glideIE, InfoExtractor):
        assert False, 'Not instance of InfoExtractor'

    if glideIE.IE_NAME not in InfoExtractor.ie_key_map:
        assert False, 'Invalid ie_key_map'

    if not (glideIE.IE_DESC and glideIE.IE_DESC.strip()):
        assert False, 'Invalid IE_DESC'


# Generated at 2022-06-12 17:30:59.219613
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor of class GlideIE has no required arguments
    GlideIE()

# Generated at 2022-06-12 17:31:06.673218
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #testing by passing a url to the constructor
    #constructor should return an instance of GlideIE

    testclass = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(testclass,GlideIE)
    assert testclass.IE_NAME == 'Glide'
# Test 8 end

# Test 9 start

# Generated at 2022-06-12 17:31:16.131738
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    test_cases = GlideIE._TEST

# Generated at 2022-06-12 17:31:20.864441
# Unit test for constructor of class GlideIE
def test_GlideIE():
    globals()['InfoExtractor'] = InfoExtractor
    info = GlideIE()
    assert info.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:31:24.611707
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testVideo = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    GlideIE_extractor = GlideIE()

    return (GlideIE_extractor._VALID_URL and GlideIE_extractor._match_id(testVideo))

# Generated at 2022-06-12 17:31:30.060606
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj._TEST
    return True


# Generated at 2022-06-12 17:31:35.524970
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor.ie_key() == 'glide'
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:08.785598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:34:13.488365
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(info_extractor.extract())
    assert info_extractor.extract() == {'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
                                        'ext': 'mp4',
                                        'title': "Damon's Glide message",
                                        'thumbnail': 're:^https?://.*?\.cloudfront\.net/.*\.jpg$'}

# Generated at 2022-06-12 17:34:14.655631
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert "instance of" in repr(ie)

# Generated at 2022-06-12 17:34:15.800887
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance._VALID_URL

# Generated at 2022-06-12 17:34:16.766712
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)._real_extract("")

# Generated at 2022-06-12 17:34:19.432158
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("\nTest ID \"UZF8zlmuQbe4mr+7dCiQ0w==\" on GlideIE")
    GlideIE()
    print("GlideIE unit test completed.")

# Generated at 2022-06-12 17:34:28.801297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # No link
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # With link
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:34:29.825801
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # TODO: Add more tests
    pass

# Generated at 2022-06-12 17:34:33.099450
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-12 17:34:34.680834
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()