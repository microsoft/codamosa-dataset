

# Generated at 2022-06-12 17:24:59.568281
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert g._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert g._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:25:06.073707
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    assert 'Glide mobile video messages (glide.me)' == test.IE_DESC
    assert 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)' == test._VALID_URL
    assert 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==' == test._TEST['url']
    assert '4466372687352851af2d131cfaa8a4c7' == test._TEST['md5']
    assert 'UZF8zlmuQbe4mr+7dCiQ0w==' == test._TEST['info_dict']['id']

# Generated at 2022-06-12 17:25:08.746436
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie
    assert ie._DOWNLOADER_VERSION
    assert ie._match_id
    assert ie.IE_DESC

# Generated at 2022-06-12 17:25:10.400014
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable(GlideIE._VALID_URL) is True

# Generated at 2022-06-12 17:25:11.532951
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()



# Generated at 2022-06-12 17:25:14.349737
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE
        .suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='))

# Generated at 2022-06-12 17:25:15.829835
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE == InfoExtractor._make_ie('GlideIE')

# Generated at 2022-06-12 17:25:18.408557
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Single test to see if class GlideIE is able to constructor a GlideIE object with url
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

test_GlideIE()

# Generated at 2022-06-12 17:25:19.882309
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert test_GlideIE.__name__ == 'test_GlideIE'

# Generated at 2022-06-12 17:25:23.604845
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:31.750347
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:25:39.534930
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.ie_key() == 'Glide'
    assert glide_ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert glide_ie.IE_NAME == 'Glide'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:40.083520
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:51.150235
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test case for constructor of class GlideIE
    """
    # Test on valid URL
    glide_ie = GlideIE(url="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==",
    print_error=False)

# Generated at 2022-06-12 17:25:51.693534
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-12 17:25:56.764411
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # URL for the test video
    TEST_URL = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    # Test the constructor of class GlideIE
    glideIE = GlideIE(GlideIE.ie_key())

    # Validate that the object constructed is indeed an instance object of class GlideIE
    assert(isinstance(glideIE, GlideIE))


# Generated at 2022-06-12 17:25:57.596754
# Unit test for constructor of class GlideIE
def test_GlideIE():
  GlideIE('GlideIE', 'test_url')

# Generated at 2022-06-12 17:26:02.539928
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/ UZF8zlmuQbe4mr+7dCiQ0w==')
    GlideIE("http://share.glide.me/ UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:26:03.153415
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:26:04.954916
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Simple test for GlideIE
    """
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:11.987172
# Unit test for constructor of class GlideIE
def test_GlideIE():
   GlideIE()

# Generated at 2022-06-12 17:26:15.557397
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'http://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:26:17.200610
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-12 17:26:19.210423
# Unit test for constructor of class GlideIE
def test_GlideIE():
    construction = GlideIE('GlideIE')
    assert construction.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:21.376301
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor(GlideIE.__name__)
    assert ie.ie_key() == GlideIE.ie_key()
    assert ie.suitable(GlideIE._VALID_URL)

    # Some other tests will be done in test_downloader.py

# Generated at 2022-06-12 17:26:24.496250
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        assert False, "Constructor for class GlideIE failed."


# Generated at 2022-06-12 17:26:34.914460
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import GlideIE
    from .test_common import get_testdata_file
    import json
    
    #print GlideIE
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glideIE = GlideIE() 
    
    headers = {'User-Agent': 'Mozilla Chrome/34.0.1847.137'}
    params = {"video_id" : "UZF8zlmuQbe4mr+7dCiQ0w=="}

    # create a request object and call glideIE
    glideIE.url_result(url, headers, params)
    #print glideIE
    #print glideIE._type
    #print glideIE._video_id
    #print glideIE._api_url


# Generated at 2022-06-12 17:26:43.863732
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:47.061805
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None, None)
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-12 17:26:48.445863
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert_equal(GlideIE._VALID_URL, GlideIE._TEST['url'])


# Generated at 2022-06-12 17:27:12.049771
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from ..amf import amf_read


# Generated at 2022-06-12 17:27:13.397966
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('Test case')

# Generated at 2022-06-12 17:27:21.084283
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:25.548222
# Unit test for constructor of class GlideIE
def test_GlideIE():
    o = GlideIE()
    o.IE_DESC
    o._VALID_URL
    o._TEST
    o._real_extract(o._TEST['url'])

# Generated at 2022-06-12 17:27:36.699004
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:38.274188
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-12 17:27:39.824446
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), InfoExtractor)


# Generated at 2022-06-12 17:27:43.554234
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert instance._match_id(url) == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:27:44.994267
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        tmp = GlideIE()
    except:
        assert False, "Failed to instantiate GlideIE"

# Generated at 2022-06-12 17:27:50.704011
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test end-to-end of constructor
    glide_instance = GlideIE()
    assert(glide_instance.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(glide_instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-12 17:28:22.432539
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:28:31.279816
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }
    test_obj = GlideIE()
    test_obj.url = test['url']
    extracted = test_obj.extract_info(test['url'])

# Generated at 2022-06-12 17:28:36.836940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert 'glide:UZF8zlmuQbe4mr+7dCiQ0w' == (
        GlideIE()._extract_id('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w'))

# Generated at 2022-06-12 17:28:38.525331
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE('')
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError due to empty URL'

# Generated at 2022-06-12 17:28:44.288036
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert_equal(ie._VALID_URL, "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)")
test_GlideIE()

# Generated at 2022-06-12 17:28:52.173884
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:28:53.966773
# Unit test for constructor of class GlideIE
def test_GlideIE():
    check_initialized(GlideIE)

# Generated at 2022-06-12 17:29:04.682603
# Unit test for constructor of class GlideIE
def test_GlideIE():

	# Test case 1
	obj = GlideIE()
	assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	
	# Test case 2
	obj = GlideIE()

# Generated at 2022-06-12 17:29:08.557773
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class QtIE(GlideIE):
        IE_NAME = 'qt'
    QtIE().suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') # should not raise an error

# Generated at 2022-06-12 17:29:12.176718
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor)._VALID_URL == (
    r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')



# Generated at 2022-06-12 17:30:16.884508
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', 'expected format for _VALID_URL'
    #assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'expected format for _TEST'
    #assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7', 'expected format for _TEST'
    #assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==', 'expected format for _TEST

# Generated at 2022-06-12 17:30:25.346090
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert (obj.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert (obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-12 17:30:31.745646
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #Constructor for GlideIE takes url and IE name
    extractor=GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'Glide')
    info=extractor._real_extract(extractor._url) #extract only takes url as argument
    #Asserts that the id of video is correct
    assert info['id'] == u'UZF8zlmuQbe4mr+7dCiQ0w=='
    #Asserts that the title is correct
    assert info['title'] == u"Damon's Glide message"
    #Asserts that the video url is correct

# Generated at 2022-06-12 17:30:33.348978
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # If this raises an exception, then there's a problem
    GlideIE()

# Generated at 2022-06-12 17:30:34.033103
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .test_downloader import options
    GlideIE(options)

# Generated at 2022-06-12 17:30:38.096890
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:44.408500
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide:share'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST is not None

# Generated at 2022-06-12 17:30:45.031749
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:30:47.495137
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url)


# Generated at 2022-06-12 17:30:52.710861
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:33:37.053598
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE()
    assert a.IE_DESC == "Glide mobile video messages (glide.me)"
    assert a._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==' in a._TEST['url']
    assert a._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert a._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:33:47.229351
# Unit test for constructor of class GlideIE
def test_GlideIE():
	from youtube_dl.YoutubeDL import YoutubeDL
	test_object = YoutubeDL()

	# From http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==
	test_urls = [
		('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', {
			'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
			'title': 'Damon\'s Glide message',
			'ext': 'mp4',
			'thumbnail': r're:^.*cloudfront.net/.*\.jpg$'
		}),
	]
	for url, info in test_urls:
		result = test

# Generated at 2022-06-12 17:33:56.961313
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i


# test GlideIE object
test_obj = GlideIE()

# Test case with url and hash of mp4 video

# Generated at 2022-06-12 17:33:58.912341
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(GlideIE)

# Generated at 2022-06-12 17:34:02.429674
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test constructor
    glide = GlideIE(None)
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:09.039299
# Unit test for constructor of class GlideIE
def test_GlideIE():
    object1 = GlideIE(InfoExtractor._downloader, 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert object1.get_media()['thumbnail'] == 'https://glide-eu.akamaized.net/v1/glide/UZF8zlmuQbe4mr-7dCiQ0w/' \
                                               'background.jpg'
    assert object1.get_media()['ext'] == 'mp4'
    assert object1.get_media()['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert object1.get_media()['title'] == "Damon's Glide message"

# Generated at 2022-06-12 17:34:11.215235
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:34:16.731197
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Tests for GlideIE
	ie = GlideIE()
	# This is a https url.
	ie.extract("https://share.glide.me/GtW8Ft7cQbqP77qdwqD_sw==")
	# This is a http url.
	ie.extract("http://share.glide.me/GtW8Ft7cQbqP77qdwqD_sw==")

# Generated at 2022-06-12 17:34:24.218042
# Unit test for constructor of class GlideIE
def test_GlideIE():
    class_ = GlideIE("GlideIE")
    assert class_.IE_DESC == "Glide mobile video messages (glide.me)"
    assert class_._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:26.382911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), GlideIE) == True
