

# Generated at 2022-06-12 17:25:00.704812
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "GlideIE", ie.IE_NAME
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)", ie.IE_DESC
    assert ie._VALID_URL == "r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'", ie._VALID_URL

# Generated at 2022-06-12 17:25:02.355323
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gl = GlideIE()
    assert(gl.IE_DESC == "Glide mobile video messages (glide.me)")



# Generated at 2022-06-12 17:25:10.832966
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.SUFFIX == '.+'
    assert isinstance(ie._TEST, dict)
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:25:14.079819
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:25:15.871791
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    assert hasattr(GlideIE, '_download_webpage')
    assert hasattr(GlideIE, '_match_id')


# Generated at 2022-06-12 17:25:21.697847
# Unit test for constructor of class GlideIE
def test_GlideIE():
	c = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	assert c._VALID_URL == 'http://share.glide.me/(?P<id>[A-Za-z0-9\-=_]+)'


# Generated at 2022-06-12 17:25:23.943933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:29.379788
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    expected = 'GlideIE - Glide mobile video messages (glide.me)'
    assert ie.description == expected

# Generated at 2022-06-12 17:25:30.065659
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:32.538381
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") != None


# Generated at 2022-06-12 17:25:40.312455
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:25:42.748973
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None, None)._test_extractor()

# Generated at 2022-06-12 17:25:45.718079
# Unit test for constructor of class GlideIE
def test_GlideIE():
    global GlideIE
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:54.555574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC = 'Glide mobile video messages (glide.me)'
    ie._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:57.046648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE()
    glideIE.to_screen('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:00.729206
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE()._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:01.313563
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:26:02.220339
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_NAME

# Generated at 2022-06-12 17:26:04.904067
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert GlideIE._VALID_URL == GlideIE.VALID_URL
	assert GlideIE.__name__ == 'GlideIE'


# Generated at 2022-06-12 17:26:05.882413
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(True)

# Generated at 2022-06-12 17:26:17.864508
# Unit test for constructor of class GlideIE
def test_GlideIE():
        # Test with a real Glide video ID
        glide_video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
        glide_video_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
        glide_video_title = "Damon's Glide message"
        youtube_dl_ie = GlideIE()
        assert glide_video_id == youtube_dl_ie._match_id(glide_video_url)

# Generated at 2022-06-12 17:26:19.874843
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:30.134888
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # create an object of class GlideIE
    GlideIE_object = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    # see if the returned object is of the class GlideIE
    assert(isinstance(GlideIE_object, GlideIE))
    # see if the returned object has the correct url attribute
    assert(GlideIE_object.url=="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:26:40.020908
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    # test information extraction
    info_dict = ie._real_extract(ie._TEST['url'])
    assert info_dict['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert info_dict['title'] == "Damon's Glide message"
    assert info_dict['url'] == 'https://s3-us-west-2.amazonaws.com/glideme/UZF8zlmuQbe4mr+7dCiQ0w==.mp4'
    assert info_dict['thumbnail'] == 'https://d2g2c6dxkoh4l9.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==gif.jpg'

# Generated at 2022-06-12 17:26:42.613887
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:26:46.890074
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE(['glide.me/Test'])
    print(glideIE.IE_DESC)
    print(glideIE._TEST)
    print(glideIE._VALID_URL)
    print(glideIE._real_extract)


# Generated at 2022-06-12 17:26:47.701792
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE("www.example.com")

# Generated at 2022-06-12 17:26:57.685954
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    g = GlideIE()
    assert g.ie_key() == "Glide"
    assert g.IE_DESC == "Glide mobile video messages (glide.me)"
    assert g.suitable(url) == True
    assert g.IE_NAME == "Glide"
    assert g._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:01.356472
# Unit test for constructor of class GlideIE
def test_GlideIE():
  # Call constructor of GlideIE, which is the class being tested
  glide_ie = GlideIE()

  # Check if instance was initialized correctly
  #assert glide_ie.IE_NAME == "GlideIE"

  return True

# Getters for private fields of GlideIE

# Generated at 2022-06-12 17:27:05.519039
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:27:19.932318
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == 'https?://share.glide.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:27:21.179412
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:26.640515
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    # Constructor test for class GlideIE
    ie = GlideIE(GlideIE.ie_key())
    # Unit test for ie.extract()
    ie.extract(ie.url)

# Generated at 2022-06-12 17:27:32.015801
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    glide_ie = GlideIE()
    e = glide_ie._VALID_URL
    i = glide_ie.IE_DESC
    assert e == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert i == "Glide mobile video messages (glide.me)"


# Generated at 2022-06-12 17:27:42.935369
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie = GlideIE(url)
    assert ie.ie_key() == 'Glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'
    assert ie.valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert not ie.valid_url(
        'https://play.google.com/store/apps/details?id=me.lyft.android&hl=en')
    assert not ie.valid_url('https://youtu.be/if5p5d8yBH8')

# Generated at 2022-06-12 17:27:47.364272
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'glide'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:27:47.984707
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:50.637870
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:55.532966
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gie = GlideIE()
    assert gie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:27:59.684895
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of GlideIE"""

    GlideIE(InfoExtractor(
        {
            "IE_NAME" : GlideIE,
            "IE_DESC" : 'Glide mobile video messages (glide.me)',
            "_VALID_URL" : r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)',
        },
        {}))

# Generated at 2022-06-12 17:28:40.633031
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:28:41.764809
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-12 17:28:50.710810
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:53.543836
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:28:55.161376
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie._TEST['url']
    assert ie._TEST['info_dict'] == ie._real_extract(ie._TEST['url'])

# Generated at 2022-06-12 17:29:00.809779
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == 'glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:29:03.534379
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = InfoExtractor()
    glide_ie = info_extractor._ies['glide']()
    assert glide_ie.IE_NAME == 'Glide'


# Generated at 2022-06-12 17:29:05.068172
# Unit test for constructor of class GlideIE
def test_GlideIE():
    d = GlideIE()

# Generated at 2022-06-12 17:29:08.428297
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:14.320743
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_class = GlideIE()
    assert test_class.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_class._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:10.609463
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'http://glide.me'

# Generated at 2022-06-12 17:30:17.303475
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:25.438776
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This test is a rewrite of the same test in youtube_dl/test/extractor/test_glide.py
    # to use more generic functions from the InfoExtractor class.
    from .test_common import InfoExtractorTest
    from .test_common import MockHttpServer

    MP4_FILE = 'test.mp4'
    expect_headers = {
        'Content-Length': str(len(b'File content')),
        'Content-Type': 'video/mp4',
    }
    total_bytes = len(b'File content') * 8
    glide_ie = InfoExtractorTest.create_ie(GlideIE, 'glide')

# Generated at 2022-06-12 17:30:26.916261
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:30:32.754512
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gi = GlideIE()
    # This is a randomly generated id of glide video from their site
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # It is possible to create a mock version of the site to glean information
    # from or to create a mock version of the downloader
    webpage = gi._download_webpage(
        'http://share.glide.me/' + video_id, video_id)
    gi._download_webpage(webpage, video_id)
    # A more direct way of testing the constructor is to check if
    # _search_regex on the webpage returns the appropriate values.

# Generated at 2022-06-12 17:30:34.929217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:36.493436
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == "Glide"
    assert GlideIE().IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-12 17:30:38.404928
# Unit test for constructor of class GlideIE
def test_GlideIE():
    some_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()

# Generated at 2022-06-12 17:30:41.400238
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE().suitable(url)

# Generated at 2022-06-12 17:30:42.309615
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-12 17:33:05.131069
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-12 17:33:06.130593
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-12 17:33:08.972830
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Test declaration and initialization of GlideIE class
    ie = GlideIE()
    ie.real_extract(url='', webpage='')
    ie.real_extract(url='', webpage='')

# Generated at 2022-06-12 17:33:17.101217
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test constructor without parameter
    glide = GlideIE()
    assert glide.IE_NAME == 'Glide'
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert len(glide._TESTS) == 1

# Generated at 2022-06-12 17:33:20.042690
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url)

# Generated at 2022-06-12 17:33:26.613263
# Unit test for constructor of class GlideIE
def test_GlideIE():
	b = GlideIE()
	assert b.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert b._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert b._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert b._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
	assert b._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
	assert b._TEST['info_dict']['ext']

# Generated at 2022-06-12 17:33:31.274271
# Unit test for constructor of class GlideIE
def test_GlideIE():
    s = GlideIE()
    assert (s._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:33:38.452752
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:33:41.884094
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:33:43.407855
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #check if GlideIE is constructed by InfoExtractor class
    ie = GlideIE()
    assert(isinstance(ie,InfoExtractor))