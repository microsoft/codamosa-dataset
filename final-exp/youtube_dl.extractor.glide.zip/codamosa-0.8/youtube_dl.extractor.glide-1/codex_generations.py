

# Generated at 2022-06-12 17:24:55.710741
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-12 17:24:56.600983
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(GlideIE())

# Generated at 2022-06-12 17:24:57.150226
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    return True

# Generated at 2022-06-12 17:25:04.595499
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE(InfoExtractor)
    info_dict = g._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:05.001415
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:15.257330
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test extraction of a message
    GlideIE().extract("https://share.glide.me/bzA4j4yMReW6U_p6YBlX9g==")  # Returns a video with .mp4 file extension

    # Test extraction of a video
    GlideIE().extract("https://share.glide.me/MZaVQO1gQ5C5q3xqz5GptA==")  # Returns an mp4 video

    # Test extraction of a screenshot
    GlideIE().extract("https://share.glide.me/rT1ZL-hcRd-pj75FnFwZAQ==")  # Returns a png image

# Generated at 2022-06-12 17:25:17.710865
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit test of constructor of class GlideIE
    extractor = GlideIE()
    assert (extractor.IE_NAME == 'Glide.me')

# Generated at 2022-06-12 17:25:22.229937
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)', "Problem with class constructor test."

# Generated at 2022-06-12 17:25:32.841592
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:40.432682
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:25:53.117803
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:54.094416
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_NAME

# Generated at 2022-06-12 17:25:55.853520
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._TEST == ie._TESTS[0]

# Generated at 2022-06-12 17:26:01.366148
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('GlideIE', 'Glide mobile video messages (glide.me)')
    GlideIE('GlideIE', 'Glide mobile video messages (glide.me)', info_dict={'id': 'UZF8zlmuQbe4mr+7dCiQ0w=='})


# Generated at 2022-06-12 17:26:04.976317
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    test_glide_ie = GlideIE._TEST
    test_url = test_glide_ie['url']
    assert test_url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-12 17:26:06.386375
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    assert GlideIE().IE_DESC == GlideIE._IE_DESC

# Generated at 2022-06-12 17:26:17.058527
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC == "Glide mobile video messages (glide.me)"
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:19.010968
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('Glide', 'glide.me')
    assert ie.ie_key() == 'Glide'
    asse

# Generated at 2022-06-12 17:26:21.599621
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # The created_at field is kind of hard to fake since it's a unix timestamp
    glide_ie = GlideIE(dict(url='https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', _type='url'))

    assert glide_ie.created_at is None

# Generated at 2022-06-12 17:26:33.111441
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://www.youtube.com/')
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:43.645280
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._TEST == {
        'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'md5': '4466372687352851af2d131cfaa8a4c7',
        'info_dict': {
            'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
            'ext': 'mp4',
            'title': "Damon's Glide message",
            'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
        }
    }

# Generated at 2022-06-12 17:26:46.815239
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE = GlideIE();
    assert(IE.IE_NAME == 'Glide');
    assert(IE.IE_DESC == 'Glide mobile video messages (glide.me)')


# Generated at 2022-06-12 17:26:50.349004
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)")
    assert(GlideIE._TEST["url"] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")


# Generated at 2022-06-12 17:26:51.388748
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE is not None

# Generated at 2022-06-12 17:26:54.061186
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide = GlideIE()
	assert isinstance(glide, GlideIE)


# Generated at 2022-06-12 17:26:58.208459
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.get_dict_of_IE_DESC(), 'Glide mobile video messages'
    assert ie.get_dict_of__VALID_URL(), 'https?://share.glide.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:02.508462
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "GlideIE"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:27:12.153319
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:14.196798
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie != None

# Generated at 2022-06-12 17:27:15.066303
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None)

# Generated at 2022-06-12 17:27:27.659752
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide = GlideIE()
	assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:27:33.615340
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == 'glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == obj.VALID_URL
    assert obj._TEST == obj.TEST
    assert obj._TESTS == obj.TESTS
    assert obj.BR_DESC == 'glide.me'


# Generated at 2022-06-12 17:27:36.058857
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor())._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-12 17:27:40.574070
# Unit test for constructor of class GlideIE
def test_GlideIE():

    # Constructor of class InfoExtractor
    _InfoExtractor = InfoExtractor()
    # Constructor of class GlideIE
    _GlideIE = GlideIE(_InfoExtractor)
    assert _GlideIE.IE_DESC == _GlideIE.IE_DESC



# Generated at 2022-06-12 17:27:48.364065
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:27:51.083658
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("Testing constructor of class GlideIE.")
    GlideIE("GlideIE")
    print("Constructor of class GlideIE is correct.")


# Generated at 2022-06-12 17:27:57.599629
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert i.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:02.998007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:05.687607
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert str(GlideIE()) == GlideIE.IE_DESC
    assert repr(GlideIE()) == GlideIE.IE_DESC


# Generated at 2022-06-12 17:28:11.148800
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE(None)
    assert test_obj.ie_key() == 'Glide' # Test function ie_key()
    assert test_obj.ie_desc() == 'Glide mobile video messages (glide.me)' # Test function ie_desc()
    assert test_obj.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True # Test function suitable()
    assert test_obj.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') == True # Test function suitable()

# Generated at 2022-06-12 17:28:35.191845
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:28:36.102219
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()



# Generated at 2022-06-12 17:28:37.457355
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testGlideIE = GlideIE()

# Generated at 2022-06-12 17:28:44.104417
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == 'GlideIE'
    assert instance.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:28:46.865118
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # create an object of the class GlideIE
    glide_ie = GlideIE()
    # verify if extractor class is GlideIE
    assert glide_ie.__class__.__name__ == "GlideIE"

# Generated at 2022-06-12 17:28:51.489317
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.suitable('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.get_urls('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:28:59.605405
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test class name and properties
    assert hasattr(GlideIE, 'ie_key')
    assert GlideIE.ie_key == 'GlideIE'
    assert hasattr(GlideIE, 'ie_desc')
    assert GlideIE.ie_desc == 'Glide mobile video messages (glide.me)'
    assert hasattr(GlideIE, '_VALID_URL')
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert hasattr(GlideIE, '_TEST')
    assert isinstance(GlideIE._TEST, dict) == True

# Generated at 2022-06-12 17:29:01.196120
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:29:03.573097
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:29:04.516955
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:29:32.633038
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:29:37.525439
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D")
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"
    assert ie.IE_NAME == "How to use GlideIE"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"


# Generated at 2022-06-12 17:29:45.948583
# Unit test for constructor of class GlideIE
def test_GlideIE():
    testVideo = GlideIE()
    assert testVideo._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert testVideo.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:29:47.355558
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-12 17:29:50.180648
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except:
        assert False, 'Unit test for constructor of class GlideIE failed'

if __name__ == "__main__":
    test_GlideIE()

# Generated at 2022-06-12 17:29:56.553641
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Testing "Glide mobile video messages (glide.me)"
    test_urls = ['http://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D', 'https://share.glide.me/UZF8zlmuQbe4mr%2B7dCiQ0w%3D%3D']
    for test_url in test_urls:
        print('Testing URL: %s' % test_url)
    ie.extract(test_url)

# Generated at 2022-06-12 17:30:07.095097
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:30:10.135134
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests that the constructor of the class GlideIE is working
    # properly by creating a GlideIE and checking its
    # name.
    glideIE = GlideIE()
    assert(glideIE.ie_key() == 'Glide')

# Generated at 2022-06-12 17:30:12.581679
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:30:18.057790
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('http://share.glide.me/n5nSb5f+SXe-eiD1fV7+Nw==')
    ie.extract('http://share.glide.me/3VX6I+U6TQ2+uxgTq3J8xA==')
    ie.extract('http://share.glide.me/ASFCYP0pTOGkW-a8_xajEg==')
    ie.extract('http://share.glide.me/t4QVb4+4Q56FJ5hmOzE21g==')
    ie.extract

# Generated at 2022-06-12 17:31:36.104429
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Test for type of instance
    assert isinstance(ie, GlideIE)

# Generated at 2022-06-12 17:31:41.241314
# Unit test for constructor of class GlideIE
def test_GlideIE():
  obj = GlideIE("http://share.glide.me/7jJoGGxB_8MUvSKAF0ZuGA==")
  assert obj.REPORT_NUM_FILE_DOWNLOAD == 0
  assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
  assert obj._VALID_URL == '^https?://share\.glide\.me/([A-Za-z0-9\-=_+]+)$'
  assert obj.params == {'skip_download': True, 'force_generic_extractor': True}
  assert obj.name == 'GlideIE'

# Generated at 2022-06-12 17:31:42.893694
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST

# Generated at 2022-06-12 17:31:43.598463
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-12 17:31:45.414206
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:31:49.620879
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.__class__ == GlideIE
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST


# Generated at 2022-06-12 17:31:50.290330
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:31:52.182572
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    glide = GlideIE(glide)
    assert isinstance(glide, InfoExtractor)

# Generated at 2022-06-12 17:31:53.166044
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_GlideIE = GlideIE()

# Generated at 2022-06-12 17:31:58.112067
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""
    new_object = GlideIE()
    assert new_object.IE_NAME == 'Glide'
    assert new_object.IE_DESC == 'Glide mobile video messages'
    assert new_object._VALID_URL == GlideIE._VALID_URL
    assert new_object._TEST == GlideIE._TEST
    assert new_object.__name__ == 'Glide'
    return new_object



# Generated at 2022-06-12 17:34:41.346379
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://glide.me/video/id')
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://(?:www\.)?glide\.me/video/(.+)'

# Unit tests for _real_extract of class GlideIE

# Generated at 2022-06-12 17:34:43.021395
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None, None)
    assert ie.IE_DESC is not None

# Generated at 2022-06-12 17:34:44.070287
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test = GlideIE()
	assert test

# Generated at 2022-06-12 17:34:52.686542
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    print(ie.IE_DESC);
    video_id = "UZF8zlmuQbe4mr+7dCiQ0w=="
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    res = ie._real_extract(url)
    print('video_id: ', video_id)
    print('url: ', url)
    print('title: ', res['title'])
    print('url: ', res['url'])
    print('thumbnail: ', res['thumbnail'])

test_GlideIE()