

# Generated at 2022-06-12 17:24:51.124141
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:24:53.228179
# Unit test for constructor of class GlideIE
def test_GlideIE():

    ie = GlideIE()

    if ie is None:
        assert False, "Object construction test for class GlideIE failed"
    else:
        assert True

# Generated at 2022-06-12 17:24:54.025862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-12 17:24:54.969522
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return True

# Generated at 2022-06-12 17:25:03.434481
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie._VALID_URL == '(?i)(?P<url>https?://(?:www\.)?glide\.me/(?:messages/video|.*?video=)[A-Za-z0-9\-=_\+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages'
    assert ie._TEST['url'] == 'http://glide.me/messages/video/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:25:07.142481
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This code is just for test of constructor of class GlideIE
    # Check that the IE key is correct
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Check that the IE name is correct
    assert GlideIE.ie_key() == 'glide.me'
    # Check that the IE description is correct
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-12 17:25:09.776851
# Unit test for constructor of class GlideIE
def test_GlideIE():
    _test = GlideIE()
    assert _test.IE_NAME == 'glide'
    assert _test.IE_DESC

# Generated at 2022-06-12 17:25:17.923801
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glideie = GlideIE("http://www.glide.me")
    assert glideie.url == "http://share.glide.me"
    glide_url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert glideie.IE_NAME == "GlideIE"
    # Check if glideie.valid_url() returns true for supported URL
    assert glideie.valid_url(glide_url)

# Generated at 2022-06-12 17:25:20.534882
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")._VALID_URL == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-12 17:25:29.345746
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:32.950419
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:37.833909
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == ie.IE_DESC
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'test')
    assert ie.IE_NAME == 'test'

# Generated at 2022-06-12 17:25:38.738715
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE(None) is not None)

# Generated at 2022-06-12 17:25:40.968498
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    assert inst.IE_DESC
    assert inst._VALID_URL

# Generated at 2022-06-12 17:25:43.496254
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE(1)
    assert isinstance(a, InfoExtractor)


# Generated at 2022-06-12 17:25:46.706257
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from youtube_dl.extractor.Glide import GlideIE
    assert GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:48.094572
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE._VALID_URL)

# Generated at 2022-06-12 17:25:56.925322
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:01.508318
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # TODO:
    # Test _download_webpage
    # Test _real_extract
    # Test _search_regex
    # Test _proto_relative_url
    # Test _og_search_thumbnail
    pass

# Generated at 2022-06-12 17:26:04.209257
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE(InfoExtractor())._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:12.659759
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # A real url
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie.extract(url)

# Generated at 2022-06-12 17:26:16.314076
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._download_webpage(
        'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==',
        'UZF8zlmuQbe4mr+7dCiQ0w=='
    )


# Generated at 2022-06-12 17:26:23.536583
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Glide has several videos whose URLs are not in the GlideIE URL format.
    This tests that we can use the constructor for GlideIE,
    and that we can extract the video_id from these video URLs.

    """
    # Glide is only available in the mobile app
    # http://support.glide.me/entries/22210033-Where-can-I-find-the-web-version-of-Glide-
    # Therefore, video URLs look like this:
    glide_video_url = 'http://www.glide.me/v/YjViZWJmYjktMjhlZC00NGNmLWIzYWMtZDlmZDMwYzY0Yzdl/'

    # The video IDs used by GlideIE have this format:
    glide_video_id

# Generated at 2022-06-12 17:26:26.368424
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC

# Generated at 2022-06-12 17:26:27.881508
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide is not None

# Generated at 2022-06-12 17:26:38.904155
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(GlideIE.IE_DESC)
    assert ie.ie_key() == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:26:47.575547
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie._VALID_URL, str)
    assert ie.IE_NAME == 'glide.me'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:50.597726
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test the GlideIE constructor.
    """
    assert type(GlideIE(None)) == GlideIE

# Generated at 2022-06-12 17:26:52.333961
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # An empty string
    assert GlideIE(None, None, None, None, None)

# Generated at 2022-06-12 17:26:54.366699
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE('1', None), InfoExtractor)


# Generated at 2022-06-12 17:27:07.487265
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:27:08.235533
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-12 17:27:11.049268
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # The constructor of class InfoExtractor
    # takes a url to extract information.
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE(url)

# Generated at 2022-06-12 17:27:20.052037
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE.__name__ == 'GlideIE'

# Generated at 2022-06-12 17:27:23.223482
# Unit test for constructor of class GlideIE
def test_GlideIE():

    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:27:28.134737
# Unit test for constructor of class GlideIE
def test_GlideIE():
	_TEST_GLIDE = {
		'url': 'http://share.glide.me/?t=5&video_id=UZF8zlmuQbe4mr+7dCiQ0w==',
		'md5': '4466372687352851af2d131cfaa8a4c7',
		'info_dict': {
			'id': 'UZF8zlmuQbe4mr+7dCiQ0w==',
			'ext': 'mp4',
			'title': "Damon's Glide message",
			'thumbnail': r're:^https?://.*?\.cloudfront\.net/.*\.jpg$',
		}
	}
	assert _TEST_GLIDE['url'] == GlideIE._VALID_

# Generated at 2022-06-12 17:27:39.486729
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Constructor test
    """
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:45.679227
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:47.514072
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.IE_NAME == "Glide"

# Generated at 2022-06-12 17:27:49.256882
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == ie.IE_DESC

# Generated at 2022-06-12 17:28:08.688911
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor.IE_NAME == 'glide'
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:28:16.624013
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # URL without video id
    glideIE = GlideIE()
    assert glideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    # URL with video id
    glideIE = GlideIE(video_id='UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:28:18.951739
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create object with given url
    GlideIE(url="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")



# Generated at 2022-06-12 17:28:22.631079
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert type(ie) == GlideIE
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert len(ie._TEST) == 4


# Generated at 2022-06-12 17:28:31.368581
# Unit test for constructor of class GlideIE
def test_GlideIE():
	print("Constructor for class GlideIE \n")

	print("Extracting GlideIE extractor\n")

	url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
	ie = GlideIE()

	ie_result = ie.extract(url)

	print("Extraction of glide.me is successful")
	print("Title of video : " + ie_result['title'])
	print("URL of video : " + ie_result['url'])
	print("ID of video : " + ie_result['id'])
	print("Thumbnail of video : " + ie_result['thumbnail'])

	assert ie_result['title'] == "Damon's Glide message"

# Generated at 2022-06-12 17:28:37.621619
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Arrange
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    
    # Act
    result = str(ie)
    expected = 'Glide mobile video messages (glide.me)'

    # Assert
    assert result == expected 


# Generated at 2022-06-12 17:28:42.441714
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', {}, {'write_json_to_file': 'test_GlideIE_data.json'})


# Generated at 2022-06-12 17:28:47.878231
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ifilter = GlideIE()
    assert ifilter.IE_NAME == 'glide'
    assert ifilter.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ifilter._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-12 17:28:48.681929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(None) is not None

# Generated at 2022-06-12 17:28:51.962276
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide = GlideIE({})
	assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:29:22.252859
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from . import get_testcases
    for url, info in get_testcases(GlideIE, {'extract_flat': 'test'}).items():
        ie = GlideIE(url)
        assert ie.extract_flat(url) == info

# Generated at 2022-06-12 17:29:22.870028
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:29:23.487141
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    return glide

# Generated at 2022-06-12 17:29:26.298653
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==').IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:29:27.906795
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-12 17:29:36.386229
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:40.551001
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST

# Generated at 2022-06-12 17:29:42.452640
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Tests that a GlideIE object is created
    GlideIE('test_GlideIE', 'url', 'test')


# Generated at 2022-06-12 17:29:53.443287
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert g._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert g._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert g._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:29:54.263226
# Unit test for constructor of class GlideIE
def test_GlideIE():
	obj = GlideIE()

# Generated at 2022-06-12 17:31:15.283248
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-12 17:31:19.625696
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (
        GlideIE(InfoExtractor()).IE_DESC ==
        'Glide mobile video messages (glide.me)'
    )

# Generated at 2022-06-12 17:31:21.983316
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    # Add tests for constructor here
    # TODO: add tests for constructor
    return 0


# Generated at 2022-06-12 17:31:32.073617
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST.get('url') == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST.get('md5') == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:31:33.953624
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_instance = GlideIE()
    assert isinstance(test_instance, InfoExtractor) == True

# Generated at 2022-06-12 17:31:36.395383
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception as e:
        assert False, e.message

# Generated at 2022-06-12 17:31:42.990616
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE(None)._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert GlideIE(None)._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
	assert GlideIE(None)._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
	assert GlideIE(None)._TEST['info_dict']['ext'] == 'mp4'
	assert GlideIE(None)._TEST['info_dict']['title'] == "Damon's Glide message"

# Generated at 2022-06-12 17:31:43.730882
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-12 17:31:46.071289
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:31:46.539924
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE

# Generated at 2022-06-12 17:34:26.539466
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    assert(GlideIE().IE_NAME == 'Glide')

# Generated at 2022-06-12 17:34:27.546984
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(GlideIE.ie_key()).extractor_key() == "Glide"

# Generated at 2022-06-12 17:34:29.756676
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:31.467688
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.ie_key() == 'glide'
    assert GlideIE.ie_slug() == 'glide'

# Generated at 2022-06-12 17:34:32.324262
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'Glide'

# Generated at 2022-06-12 17:34:33.394115
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # should add unit tests for this class
    assert GlideIE is not None

# Generated at 2022-06-12 17:34:39.025422
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    expected_IE_DESC = "Glide mobile video messages (glide.me)"
    expected_VALID_URL = "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

# Generated at 2022-06-12 17:34:39.761940
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-12 17:34:45.772069
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""

    glide = GlideIE()

    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

    assert glide._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glide._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert glide._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
   