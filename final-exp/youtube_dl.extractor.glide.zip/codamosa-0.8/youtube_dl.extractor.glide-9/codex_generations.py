

# Generated at 2022-06-12 17:24:52.468381
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Check constructor of class GlideIE """
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", None)

# Generated at 2022-06-12 17:25:02.319362
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    # Test with invalid argument
    ie = GlideIE('')
    assert not ie.suitable('')
    assert ie.__name__ != ''
    assert ie.IE_NAME != ''
    assert ie.IE_DESC != ''
    assert ie.VALID_URL != ''
    assert ie._TESTS != []
    assert ie.SUCCESS.code == 'SUCCESS'

    # Test with valid argument
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    info = ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:05.156204
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie.extract('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:06.254445
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert len(GlideIE._TESTS) > 0

# Generated at 2022-06-12 17:25:12.169254
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gie = GlideIE()
    assert gie.IE_NAME == 'Glide'
    assert gie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert gie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:16.209448
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    inst = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert inst.ie_key() == 'Glide'

# Generated at 2022-06-12 17:25:23.777578
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:25:28.579563
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test the instantiation of GlideIE
    assert isinstance(GlideIE('UZF8zlmuQbe4mr+7dCiQ0w=='), InfoExtractor)

# Generated at 2022-06-12 17:25:31.469371
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9-=_+]+)'

# Generated at 2022-06-12 17:25:34.524757
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:50.103048
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:54.554694
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    GlideIE.ie
    GlideIE.ie_key
    GlideIE.ie_desc
    GlideIE.webpage_url
    GlideIE._VALID_URL
    GlideIE._TEST
    GlideIE.extract
    GlideIE.suitable
    GlideIE.get_video_info
    GlideIE.extract_from_url

# Generated at 2022-06-12 17:25:55.046726
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:55.754724
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:58.309124
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.extract()

# Generated at 2022-06-12 17:26:08.185866
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import os
    import utils
    from nose.tools import assert_raises
    from nose.plugins.skip import SkipTest

    # unit test for GlideIE
    # skip the unit test for GlideIE if ffmpeg is not in the path
    if not utils.check_executable('ffmpeg', ['-version']):
        raise SkipTest('ffmpeg is not available')

    # open the test video file
    test_video_file = os.path.join(os.getcwd(), 'GlideIE.test.mp4')
    with open(test_video_file, 'rb') as video_in:
        # test GlideIE constructor with dummy parameter
        with assert_raises(TypeError):
            ie = GlideIE(None, video_in)

        # test GlideIE constructor with dummy parameter

# Generated at 2022-06-12 17:26:15.300514
# Unit test for constructor of class GlideIE
def test_GlideIE():
    video_info_extractor = GlideIE()
    assert video_info_extractor.name == 'Glide'
    assert video_info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert video_info_extractor.url_re == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-12 17:26:22.060098
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
    assert(GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:33.507339
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if __name__ == "__main__":
        i = GlideIE()
        assert i._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
        assert i.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:34.395412
# Unit test for constructor of class GlideIE
def test_GlideIE():
        GlideIE(InfoExtractor())

# Generated at 2022-06-12 17:26:46.351168
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST

    assert ie._match_id("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==") == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._proto_relative_url("https://fyyd.de/a/b") == "//fyyd.de/a/b"



# Generated at 2022-06-12 17:26:47.174428
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glideIE = GlideIE()

# Generated at 2022-06-12 17:26:53.825024
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    test_values = glide_ie._TEST
    assert glide_ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert test_values['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert test_values['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert test_values['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='


# Generated at 2022-06-12 17:27:01.866448
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Audio Video Message for testing.
    url = 'http://share.glide.me/QE6oy1j6Rk+mOzwjRB2O5g=='
    glide_ie = GlideIE()

    # Get the video_data.
    video_data = glide_ie._download_webpage(url)

    # Check the video_data is there.
    assert video_data

    # Get the video_id.
    video_id = glide_ie._match_id(url)

    # Check the video_id is there.
    assert video_id

    # Get the title.

# Generated at 2022-06-12 17:27:06.667288
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST
    ie._real_extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:27:07.239497
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:11.321590
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # set the parameters of an instance of GlideIE
    video_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    url = 'https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:27:18.195283
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ## test constructor
    ie = GlideIE()

    ie = GlideIE("http://www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

    ie = GlideIE("https://www.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

    assert ie._VALID_URL ==  r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'




# Generated at 2022-06-12 17:27:19.284630
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-12 17:27:21.176238
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-12 17:27:44.033157
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj_GlideIE = GlideIE()
    assert(obj_GlideIE.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(obj_GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(obj_GlideIE._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(obj_GlideIE._TEST['md5'] == "4466372687352851af2d131cfaa8a4c7")

# Generated at 2022-06-12 17:27:53.444452
# Unit test for constructor of class GlideIE
def test_GlideIE():
	#Test the constructor of the class
	ie = GlideIE()
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert isinstance(ie._VALID_URL, unicode )
	assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:27:56.372106
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # TODO: Add unit tests to check if test information is valid.

    # Need a valid URL as input to complete test
    assert False == ie.suitable('http://example.com')

# Generated at 2022-06-12 17:27:59.123691
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Legal URL
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Illegal URL
    ie.extrac('http://share.glide.me/')

# Generated at 2022-06-12 17:28:09.048867
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:10.250524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE() != None

# Generated at 2022-06-12 17:28:12.389885
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie_inst = GlideIE()
	assert ie_inst._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:13.367208
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Create object of class GlideIE
	GlideIE()



# Generated at 2022-06-12 17:28:13.775053
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert True

# Generated at 2022-06-12 17:28:19.165041
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\\-=_+]+)'

# Generated at 2022-06-12 17:28:59.762033
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # This is only a smoke test to make sure that no exceptions are thrown when
    # creating an instance of the class (it can't happen, but hey...)
    GlideIE()


if __name__ == '__main__':
    # This is only a smoke test to make sure that no exceptions are thrown when
    # creating an instance of the class (it can't happen, but hey...)
    GlideIE()

# Generated at 2022-06-12 17:29:00.683603
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)

# Generated at 2022-06-12 17:29:02.385721
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:29:04.781247
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print("Start test for GlideIE")
    glideIE = GlideIE()
    print("End test for GlideIE\n")

# Test for method _real_extract of class GlideIE

# Generated at 2022-06-12 17:29:07.285172
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert (ie.IE_DESC)
    assert (ie._VALID_URL)
    assert (ie._TEST)

# Generated at 2022-06-12 17:29:08.388658
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:29:12.024068
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE().IE_NAME == 'glide'
    assert GlideIE().IE_SHORT_NAME == 'glide'
    assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:29:23.522193
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test object creation
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-12 17:29:32.247868
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE._TEST['info_dict']['ext'] == 'mp4'
    assert GlideIE._TEST['info_dict']['title'] == "Damon's Glide message"

# Generated at 2022-06-12 17:29:34.411143
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None).extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:30:50.369900
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    constructor_output = glide.__class__.__name__ == 'GlideIE'
    assert constructor_output == True

# Generated at 2022-06-12 17:30:52.469792
# Unit test for constructor of class GlideIE
def test_GlideIE():

    glide = GlideIE(GlideIE.ie_key())

# Generated at 2022-06-12 17:30:55.401896
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:31:00.731843
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import sys
    # Show the available methods and properties of our class

# Generated at 2022-06-12 17:31:04.163543
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except StandardError as e:
        assert False, "Unable to create GlideIE object"


# Generated at 2022-06-12 17:31:04.725033
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:31:06.585083
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:31:08.990366
# Unit test for constructor of class GlideIE
def test_GlideIE():
	test_GlideIE = GlideIE()

test_GlideIE()

# Generated at 2022-06-12 17:31:16.232861
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info=GlideIE()._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert info["title"]=="Damon's Glide message"
    assert info["url"].endswith("UZF8zlmuQbe4mr+7dCiQ0w==.mp4")
    assert info["id"]=="UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-12 17:31:20.906574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE()
    print(test)
    #assert(test.__class__.__name__ == 'GlideIE')
    return True


# Generated at 2022-06-12 17:33:56.983044
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:03.523588
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import unittest
    class TestGlideIE(unittest.TestCase):

        def setUp(self):
            self.glide = GlideIE(None)

        def test_constructor(self):
            self.assertTrue(self.glide)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGlideIE)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-12 17:34:04.714175
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = {"test": True}


test_GlideIE()


# Generated at 2022-06-12 17:34:07.085437
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ Test for class GlideIE """
    glide_ie = GlideIE(InfoExtractor._download_webpage)
    return str(glide_ie) == "<class 'utils.youtube_dl.extractor.glide.GlideIE'>"

# Generated at 2022-06-12 17:34:08.109441
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:34:09.817582
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:34:11.236643
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:11.938040
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Placeholder for an empty test
    return

# Generated at 2022-06-12 17:34:16.659882
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE().IE_NAME == 'glide.me')
    assert(GlideIE().IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')


# Generated at 2022-06-12 17:34:17.150162
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()