

# Generated at 2022-06-12 17:25:01.493474
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_case = GlideIE()
    assert test_case._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test_case.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:25:07.064690
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print('URL:%s, ID:%s, TITLE:%s, URL:%s' % (ie._TEST['url'], ie._TEST['info_dict']['id'], ie._TEST['info_dict']['title'], ie._TEST['info_dict']['url']))

# Production test of class GlideIE

# Generated at 2022-06-12 17:25:18.567328
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:20.857435
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert GlideIE(None).get_metadata().get('domain') == 'share.glide.me'

# Generated at 2022-06-12 17:25:22.701838
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()

# Generated at 2022-06-12 17:25:24.179307
# Unit test for constructor of class GlideIE
def test_GlideIE():
    share = GlideIE()
    assert(type(share) == GlideIE)

# Generated at 2022-06-12 17:25:26.840279
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance.IE_NAME == u'glide'
    assert instance.IE_DESC == u'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:25:31.343561
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:25:32.604899
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Arrange
	obj = GlideIE()
	
	# Act
	
	# Assert

# Generated at 2022-06-12 17:25:40.265194
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test constructor of class GlideIE"""

    glideIE = GlideIE()
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:48.227407
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert InfoExtractor(None).get_info_extractor(GlideIE.ie_key()) is not None

# Generated at 2022-06-12 17:25:50.174790
# Unit test for constructor of class GlideIE
def test_GlideIE():
	log.debug("Testing GlideIE")
	GlideIE()

if __name__ == "__main__":
	test_GlideIE()

# Generated at 2022-06-12 17:25:51.029751
# Unit test for constructor of class GlideIE
def test_GlideIE():
    my_test_object = GlideIE()

# Generated at 2022-06-12 17:25:51.623712
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:53.222371
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-12 17:26:03.679440
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:26:12.258056
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:20.021644
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:26:32.566179
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """ test the constructor of class GlideIE """
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    glide_ie = GlideIE(url)
    assert glide_ie.url == url
    assert glide_ie.name == "GlideIE"
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:39.120612
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('UZF8zlmuQbe4mr+7dCiQ0w==')
    expected_name = 'glide'
    if ie.IE_NAME != expected_name:
        raise AssertionError("Expected name %s, got %s" %
            (expected_name, ie.IE_NAME))
    expected_id = 'UZF8zlmuQbe4mr+7dCiQ0w=='
    if ie.IE_ID != expected_id:
        raise AssertionError("Expected id %s, got %s" %
            (expected_id, ie.IE_ID))

# Generated at 2022-06-12 17:26:55.291070
# Unit test for constructor of class GlideIE
def test_GlideIE():
    inst = GlideIE()
    assert inst.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:27:02.359072
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    result = ie._real_extract(url)
    assert result['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert result['title'] == "Damon's Glide message"
    assert result['url'] == '//cdn-cdn-22.glide.me/preview/video/UZF8zlmuQbe4mr+7dCiQ0w==.mp4'
    assert result['thumbnail'] == '//d2fxmvxkzmnj7o.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==.jpg'

# Generated at 2022-06-12 17:27:04.282827
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #constructor of class GlideIE
    GlideIE()

# Generated at 2022-06-12 17:27:06.187164
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:27:07.105214
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()
    assert True

# Generated at 2022-06-12 17:27:10.705151
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    :return:
    """
    glide_unit_test = GlideIE()
    url = glide_unit_test._VALID_URL
    match = glide_unit_test._match_id(url)

# Generated at 2022-06-12 17:27:20.022991
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:26.021042
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test cases for class methods and local functions
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')


test_GlideIE()

# Generated at 2022-06-12 17:27:30.478073
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:41.839416
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)

    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

    ie = GlideIE()

    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:28:21.105521
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # A test for the test. (I am meta)
    assert(GlideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(GlideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')
    assert(GlideIE._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(GlideIE._TEST['info_dict']['ext'] == 'mp4')
    assert(GlideIE._TEST['info_dict']['title'] == "Damon's Glide message")

# Generated at 2022-06-12 17:28:22.296130
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()


if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-12 17:28:26.520376
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    except NameError:
        print('GlideIE not defined')


# Generated at 2022-06-12 17:28:28.813807
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:28:31.793848
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(ie is not None)

# Generated at 2022-06-12 17:28:40.633250
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Set python2 compatible values of i/o
    global input, raw_input
    try:
        input = raw_input
    except NameError:
        pass
    # Import GlideIE
    from .glide import GlideIE
    # Create an instance of GlideIE
    glide_ie = GlideIE()
    # Create a glide videoData
    import json

# Generated at 2022-06-12 17:28:41.731753
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-12 17:28:50.709566
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.get_url() == 'http://www.glide.me/'
    assert ie.ie_key() == 'Glide'
    assert ie.get_desc() == 'Glide mobile video messages (glide.me)'
    assert ie.valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==') is True
    assert ie.valid_url('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w') is False
    assert ie.valid_url('http://share.glide.me/') is False

# Generated at 2022-06-12 17:28:52.575479
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:28:54.090364
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:29:22.397055
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide_ie = GlideIE()
    assert glide_ie.IE_NAME == "GlideIE"


# Generated at 2022-06-12 17:29:27.066571
# Unit test for constructor of class GlideIE
def test_GlideIE():
    singleton = GlideIE()

    assert(singleton.ie_key() == 'Glide')
    assert(singleton.IE_DESC == 'Glide mobile video messages (glide.me)')
    assert(singleton._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-12 17:29:34.335461
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Basic test for GlideIE constructor.
    This test asserts that the GlideIE class is constructed correctly and all
    internal properties are set to the correct values.
    """
    expected_value_dict = {
        '_VALID_URL': GlideIE._VALID_URL,
        'IE_NAME': 'glide',
        'IE_DESC': GlideIE.IE_DESC,
        '_TESTS': GlideIE._TEST,
        '_WORKING': False
    }
    ie = GlideIE()
    for key, value in expected_value_dict.items():
        assert ie.__dict__[key] == value

# Generated at 2022-06-12 17:29:35.872929
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:29:45.111247
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    assert glide.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert glide._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:45.948071
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:29:48.888615
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test the constructor for GlideIE
    """
    ie = GlideIE(True)
    assert ie is not None


# Generated at 2022-06-12 17:29:55.006268
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test case 1
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert GlideIE().suitable(url) is True, 'Test 1: Video is not from Glide'

    # Test case 2
    url = 'http://www.youtube.com/watch?v=_HSylqgVYQI'
    assert GlideIE().suitable(url) is False, "Test 2: Video is from Glide"

# Generated at 2022-06-12 17:29:56.356723
# Unit test for constructor of class GlideIE
def test_GlideIE():
    if __name__ == '__main__':
        glide_ie = GlideIE()

# Generated at 2022-06-12 17:29:59.818726
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Instantiating a GlideIE
    glide_ie = GlideIE()
    assert(glide_ie.IE_NAME == 'Glide')
    assert(glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)')
    # Instantiating other classes from GlideIE
    from .common import InfoExtractor
    info_extractor = InfoExtractor()
    assert(info_extractor.TEST == {})

# Generated at 2022-06-12 17:31:19.675043
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'

# Generated at 2022-06-12 17:31:20.273848
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:31:22.233756
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Asserts that the constructor is not None
    assert(GlideIE is not None)
    

# Generated at 2022-06-12 17:31:23.759786
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor()).IE_NAME == 'glide.me'


# Generated at 2022-06-12 17:31:24.579681
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(GlideIE._VALID_URL)

# Generated at 2022-06-12 17:31:28.563594
# Unit test for constructor of class GlideIE
def test_GlideIE():
    p = GlideIE(None).extract_info("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", None)
    assert(p["id"] == "UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:31:38.149067
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Unit tests
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Test subclass of InfoExtractor
    assert issubclass(GlideIE, InfoExtractor), 'GlideIE is a subclass of InfoExtractor'
    # Test content inside the constructor
    assert ie.ie_key() == 'GlideIE', 'ie_key returns GlideIE'
    assert ie.ie_desc() == 'Glide mobile video messages (glide.me)', 'ie_desc returns Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:31:44.385712
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    video = ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(video)
    assert video['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert video['title'] == "Damon's Glide message"
    assert video['url'] == 'http://api.glide.me/stream/UZF8zlmuQbe4mr+7dCiQ0w==?size=medium'
    assert video['thumbnail'] == 'http://b-fus.netdna-ssl.com/UZF8zlmuQbe4mr+7dCiQ0w==-thumb-640x360.jpg'
test_Glide

# Generated at 2022-06-12 17:31:46.139050
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:31:49.542047
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE()
    assert instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert instance._download_webpage == InfoExtractor._download_webpage

# Generated at 2022-06-12 17:34:28.840691
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('')
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:29.865151
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(True == True)

# Generated at 2022-06-12 17:34:30.690032
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor)

# Generated at 2022-06-12 17:34:34.415394
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj.IE_NAME == 'Glide'
    assert obj.IE_THUMBNAIL_URL_TEMPLATE == 'http://thumbs.glide.me/%s.jpg'
    assert obj.META_SITENAME == 'Glide'
    assert obj.META_SITEURL == 'http://glide.me'

# Generated at 2022-06-12 17:34:43.983872
# Unit test for constructor of class GlideIE
def test_GlideIE():
    IE_descrip = "Glide mobile video messages (glide.me)"
    Valid_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:47.195007
# Unit test for constructor of class GlideIE
def test_GlideIE():
    t = GlideIE()
    assert t.IE_NAME == 'glide'
    assert t.IE_DESC == 'Glide mobile video messages (glide.me)'