

# Generated at 2022-06-12 17:24:52.474055
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return GlideIE

# Generated at 2022-06-12 17:24:53.306557
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE()

# Generated at 2022-06-12 17:25:02.829253
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:25:14.509411
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test if GlideIE works"""
    glide=GlideIE();
    #assert glide.IE_DESC == 'Glide mobile video messages (glide.me)', "GlideIE.IE_DESC should be 'Glide mobile video messages (glide.me)'"
    glide.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:25:19.052673
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glideInstance = GlideIE()
    def test_method(self):
        """
        Undefined method to test '_real_extract' method of GlideIE
        """

# Generated at 2022-06-12 17:25:28.184529
# Unit test for constructor of class GlideIE
def test_GlideIE():
    '''
    Test function to test the constructor of class GlideIE
    '''
    # Test with an existing GlideIE video
    test_url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide = GlideIE()
    result = glide.suitable(test_url) 
    assert result, "Testing with existing GlideIE video"
    assert glide.IE_DESC, "Testing GlideIE's IE_DESC"
    assert glide._VALID_URL, "Testing GlideIE's _VALID_URL"
    assert glide._TEST, "Testing GlideIE's _TEST"

# Generated at 2022-06-12 17:25:32.622423
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert(ie.IE_DESC=='Glide mobile video messages (glide.me)')
    assert(ie._VALID_URL==r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-12 17:25:39.117416
# Unit test for constructor of class GlideIE
def test_GlideIE():
    x = GlideIE()
    assert x._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert x.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert x._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert x._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'


# Generated at 2022-06-12 17:25:45.621405
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-12 17:25:48.447383
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print(ie.format)
    print(ie.title)

# Generated at 2022-06-12 17:25:56.185095
# Unit test for constructor of class GlideIE
def test_GlideIE():
    gie = GlideIE()

    assert gie.IE_NAME == 'share.glide.me'
    assert gie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert gie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:26:06.515232
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Constructor test
    ie = GlideIE(InfoExtractor())
    assert ie.IE_NAME == 'GlideIE'
    #ie = GlideIE(InfoExtractor(downloader=None))
    #assert ie.IE_NAME == 'GlideIE'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    #assert ie._TEST == {'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==', 'md5': '4466372687352851af2d131cfaa8a4c7', 'info_dict': {'id': 'UZF8zlmuQbe4mr+7dC

# Generated at 2022-06-12 17:26:11.985126
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert glideIE.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:16.485509
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:23.649077
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Set instance of class GlideIE
    ie_instance = GlideIE()
    # Test instance of IE
    if(isinstance(ie_instance, InfoExtractor)):
        print("Instance is an instance of class InfoExtractor")
    else:
        print("Instance is not an instance of class InfoExtractor")
    # Test _VALID_URL variable is of type Regex Object
    if(isinstance(ie_instance._VALID_URL, RE_OBJECT)):
        print("_VALID_URL variable is of type RegexObject")
    else:
        print("_VALID_URL variable is not of type RegexObject")
    # Test _TEST variable is dictionary
    if(isinstance(ie_instance._TEST, dict)):
        print("_TEST variable is of type dict")
    else:
        print

# Generated at 2022-06-12 17:26:25.984181
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == ie.ie_key()

# Generated at 2022-06-12 17:26:29.487669
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.IE_NAME == 'Glide'



# Generated at 2022-06-12 17:26:31.377507
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideie = GlideIE()

# Generated at 2022-06-12 17:26:32.764399
# Unit test for constructor of class GlideIE
def test_GlideIE():
    
    # Test 1: create an instance
    Glide_IE = GlideIE()

    # Test 2: create an instance
    Glide_IE = GlideIE(GlideIE.ie_key(), 'Glide mobile video messages (glide.me)')

# Generated at 2022-06-12 17:26:41.612971
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # pylint: disable=too-few-public-methods
    """Unit test for constructor of class GlideIE"""
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:49.746875
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:00.168933
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Arrange
    url = 'http://share.glide.me/UZF8zlm'
    expected_id = 'UZF8zlm'
    expected_desc  = "Glide mobile video messages (glide.me)"
    expected_name = "Glide"
    expected_thumbnail = r're:^https?://.*?\.cloudfront\.net/.*\.jpg$'

    # Act
    glide_ie = GlideIE(url)

    # Assert
    assert glide_ie.IE_NAME == expected_name
    assert glide_ie.IE_DESC == expected_desc
    assert glide_ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:00.970340
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-12 17:27:05.380445
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.IE_DESC
    ie.IE_NAME
    ie.valid_url(ie._TEST['url'], ie.IE_NAME)

# Generated at 2022-06-12 17:27:13.573743
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE(GlideIE.IE_NAME, {'ie': GlideIE.IE_NAME, 'id': 'UZF8zlmuQbe4mr+7dCiQ0w==', 
                                  'url': 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='})

    assert i.ie == GlideIE.IE_NAME
    assert i.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert i.id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert i._VALID_URL == GlideIE._VALID_URL


# Generated at 2022-06-12 17:27:14.531902
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE(), GlideIE)

# Generated at 2022-06-12 17:27:21.618269
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:24.793666
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE() # called without arguments
    ie = GlideIE(GlideIE._VALID_URL) # called with url
    ie = GlideIE(ie=GlideIE(GlideIE._VALID_URL), ie_key='Glide') # called with ie and ie_key
    assert ie.IE_NAME == 'Glide'

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-12 17:27:25.709846
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:27:28.018953
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit test for constructor of class GlideIE"""

    glide = GlideIE()
    assert glide is not None


# Generated at 2022-06-12 17:27:47.715039
# Unit test for constructor of class GlideIE
def test_GlideIE():
  glide_ie = GlideIE(GlideIE._downloader, {}, False)
  assert glide_ie.suitable("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
  assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'
  assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:50.106251
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # In case of error, this will raise an AssertionError exception.
    # If no exception is raised, the test case has been successful.
    GlideIE()

# Generated at 2022-06-12 17:27:50.941374
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


# Generated at 2022-06-12 17:27:55.912096
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    except TypeError:
        print("Constructor of class GlideIE doesn't work")
        return

# Generated at 2022-06-12 17:27:56.797928
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print(ie)

# Generated at 2022-06-12 17:28:00.053937
# Unit test for constructor of class GlideIE
def test_GlideIE():
    g = GlideIE()
    assert g.IE_NAME == 'glide'
    assert g.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert g._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    

# Generated at 2022-06-12 17:28:01.506916
# Unit test for constructor of class GlideIE
def test_GlideIE():
	g = GlideIE()
	assert g != None

# Generated at 2022-06-12 17:28:09.729487
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import regex
    assert regex.compile(GlideIE._VALID_URL).match('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert regex.compile(GlideIE._VALID_URL).match('https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert regex.compile(GlideIE._VALID_URL).match('https://share.glide.me/UZF8zlmuQbe4mr-7dCiQ0w==')
    assert regex.compile(GlideIE._VALID_URL).match('https://share.glide.me/UZF8zlmuQbe4mr=7dCiQ0w==')

# Generated at 2022-06-12 17:28:11.485459
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/BtM7jLD+QxqXQgWfk8jH5Q==')

# Generated at 2022-06-12 17:28:20.914806
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #test_GlideIE()
    glideIE = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert glideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glideIE._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert glideIE._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:28:57.841467
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable(GlideIE._VALID_URL)
    assert not GlideIE.suitable(GlideIE._TEST)


# Generated at 2022-06-12 17:29:06.272749
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Unit Test for class: Video Test"""
    import json
    import re
    from test.test_downloader import TestDownloader
    from test.test_downloader import TestHTTPServer
    from test.test_downloader import TestServerHandler
    from test.test_downloader import TestServerThread
    from test.test_downloader import TestServerThreadHandler
    from test.test_downloader import TestServerThreadLauncher
    from test.test_downloader import TestYDL

    class TestTestGlideIE(TestServerThreadHandler):
        """Test Server Test Test Test Test Test Test Test Test Test Test Test Test Test Test """
        # TestTestGlideIE
        # TestTestTestGlideIE
        # TestTestTestTestGlideIE
        # TestTestTestTestTestGlideIE
        # TestTestTestTestTestTestGlideIE
       

# Generated at 2022-06-12 17:29:14.752460
# Unit test for constructor of class GlideIE
def test_GlideIE():
    info_extractor = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    assert info_extractor.suitable(url) is True
    assert info_extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert info_extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert info_extractor._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-12 17:29:18.345829
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE(_downloader=None, _matched_id='test')
    except Exception as e:
        assert False, 'GlideIE constructor failed for reason:\n' + str(e)


# Generated at 2022-06-12 17:29:21.104757
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._TEST
    assert obj._VALID_URL
    assert obj.IE_DESC


# Generated at 2022-06-12 17:29:24.694760
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Downloader test
    my_downloader = GlideIE()
    my_downloader.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:29:28.166293
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Write a test for constructor of class GlideIE"""
    test_GlideIE.test_done = True
    globals()['GlideIE'] = InfoExtractor
    return True

if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-12 17:29:36.597802
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    ie.extract(url)
    # After GlideIE._real_extract function is called, can retrieve the value of the id
    assert ie.id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    # After GlideIE._real_extract function is called, can retrieve the value of the title
    assert ie.title == "Damon's Glide message"
    # After GlideIE._real_extract function is called, can retrieve the value of the ext
    assert ie.ext == "mp4"
    # After GlideIE._real_extract function is called, can retrieve the value of the url

# Generated at 2022-06-12 17:29:39.795814
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE('/UZF8zlmuQbe4mr+7dCiQ0w=='), InfoExtractor)


# Generated at 2022-06-12 17:29:43.467749
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None, {}, {}, None)
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:30:57.257345
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Make sure GlideIE constructor returns an instance of GlideIE
    """
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(ie, GlideIE)


# Generated at 2022-06-12 17:30:58.788492
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(c=None)

# Generated at 2022-06-12 17:31:08.515025
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Test constructor of GlideIE
    """
    glide_ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(glide_ie.IE_DESC == "Glide mobile video messages (glide.me)")
    assert(glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert(glide_ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:31:09.494137
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)

# Generated at 2022-06-12 17:31:14.004027
# Unit test for constructor of class GlideIE
def test_GlideIE():
    tests = ['http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==']

    for item in tests:
        GlideIE().extract(item)

# Generated at 2022-06-12 17:31:17.049859
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-12 17:31:26.813191
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test case for URL: http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==
    assert GlideIE._TEST["url"] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

    t = GlideIE(GlideIE._TEST["url"])

    assert t._VALID_URL == "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)"

    assert t.IE_DESC == 'Glide mobile video messages (glide.me)'

    assert t.title() == "Damon's Glide message"



# Generated at 2022-06-12 17:31:27.293425
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:31:31.087337
# Unit test for constructor of class GlideIE
def test_GlideIE():
    extractor = GlideIE()
    assert extractor._VALID_URL == GlideIE._VALID_URL
    assert extractor._TEST == GlideIE._TEST

# Generated at 2022-06-12 17:31:33.400170
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-12 17:34:06.751829
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:09.651086
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-12 17:34:10.356269
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-12 17:34:12.298923
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'



# Generated at 2022-06-12 17:34:16.972336
# Unit test for constructor of class GlideIE
def test_GlideIE():
    uri = "http://share.glide.me/2c2vGxlIW8n0nEx1e9Cfvw=="
    ie = GlideIE(None)
    assert ie.IE_DESC != None
    assert ie._VALID_URL != None
    assert ie._TEST != None
    assert ie._real_extract(uri) != None

# Generated at 2022-06-12 17:34:24.425578
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # create an instance of GlideIE and run tests
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    glide_ie = GlideIE()
    # Test if the URL is in a valid format i.e.
    # https://share.glide.me/XXXX
    # where XXXX is an alphanumeric string
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # Test if the URL is valid
    # The function _VALID_URL_RE.match returns a match object
    assert glide_ie._VALID_URL_RE.match(url) is not None
    # Test if instance of Glide

# Generated at 2022-06-12 17:34:27.781468
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:34:28.765506
# Unit test for constructor of class GlideIE
def test_GlideIE():
	assert(GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)')


# Generated at 2022-06-12 17:34:31.873065
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj._TEST['url'] == "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="

# Generated at 2022-06-12 17:34:32.653133
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, InfoExtractor)