

# Generated at 2022-06-12 17:24:54.727220
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('','')
    assert ie is not None

# Generated at 2022-06-12 17:24:59.383548
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE({})
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:24:59.950439
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:01.349889
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "GlideIE"


# Generated at 2022-06-12 17:25:02.627772
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-12 17:25:06.058905
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie._real_extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:25:09.618512
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:11.702263
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE();
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:25:14.937717
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:25:16.383096
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/zjDvQ2hZQ0_ZY0GwOaI1Mg==')

# Generated at 2022-06-12 17:25:23.121080
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:29.669470
# Unit test for constructor of class GlideIE
def test_GlideIE():
    a = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert a.IE_NAME == 'Glide'
    assert a.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert a._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:38.534730
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    
    extractor = GlideIE()

    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    extractor._real_extract(url)

    assert extractor.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert extractor._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert extractor._TEST['url'] == url
    assert extractor._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:25:41.768373
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.download("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:25:43.336657
# Unit test for constructor of class GlideIE
def test_GlideIE():
  assert GlideIE('http://some_url.com')

# Generated at 2022-06-12 17:25:46.185792
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w'
    GlideIE(url)
    return

# Generated at 2022-06-12 17:25:51.628679
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # test url has a title in 'title' tag
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # test url has a title in 'og:title' tag
    ie = GlideIE()
    ie.extract('http://share.glide.me/W5L5Pj4nQH6t4NLyILWYXQ==')

# Generated at 2022-06-12 17:25:54.844922
# Unit test for constructor of class GlideIE
def test_GlideIE():
    print(InfoExtractor.get_info_extractors())
    # InfoExtractor.get_info_extractors()[GlideIE.ie_key()]()
    GlideIE()

# Generated at 2022-06-12 17:25:56.683773
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == ie._VALID_URL

# Generated at 2022-06-12 17:25:58.877019
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:26:12.616227
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert isinstance(GlideIE, InfoExtractor)


# Generated at 2022-06-12 17:26:15.223319
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:16.921496
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE is not None

if __name__ == "__main__":
    test_GlideIE()

# Generated at 2022-06-12 17:26:23.729862
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor=GlideIE()
    url='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    response = infoExtractor._real_extract(url)
    assert response['id'] =='UZF8zlmuQbe4mr+7dCiQ0w=='
    assert response['title']=="Damon's Glide message"
    assert response['url']=="https://d3l9q9q2rmz2ns.cloudfront.net/videos/UZF8zlmuQbe4mr.mp4"
    assert response['thumbnail']=="http://d3l9q9q2rmz2ns.cloudfront.net/images/icon-video-play-sm.png"

# Generated at 2022-06-12 17:26:33.155208
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE(False)
    assert obj.IE_NAME == 'Glide'
    assert obj.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert obj._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert obj._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert obj._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'


# Generated at 2022-06-12 17:26:40.625356
# Unit test for constructor of class GlideIE
def test_GlideIE():
    "Test for GlideIE"

    # Construct an instance of GlideIE
    glide_ie = GlideIE()

    # test _VALID_URL
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    # test _TEST

# Generated at 2022-06-12 17:26:42.572029
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test if GlideIE can be instantiated."""

    class GlideIE(InfoExtractor):
        IE_DESC = 'Glide mobile video messages (glide.me)'

    IE_Cls = GlideIE(None)

    assert IE_Cls.IE_NAME == 'glide'

# Generated at 2022-06-12 17:26:50.983063
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:54.301885
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:26:58.579125
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:27:15.938989
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:20.022244
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.__name__ == 'GlideIE'
    assert GlideIE.IE_NAME == 'Glide'
    assert GlideIE.IE_ID == 'Glide.me'
    assert GlideIE.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert GlideIE.VALID_URL == GlideIE._VALID_URL



# Generated at 2022-06-12 17:27:24.002900
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:27:36.162006
# Unit test for constructor of class GlideIE
def test_GlideIE():
    unit_test = GlideIE()
    unit_test.IE_DESC = 'Glide mobile video messages (glide.me)'
    unit_test._VALID_URL = r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:27:40.293089
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE(None)
    assert ie.IE_NAME == 'Glide'
    assert ie.IE_DESC == ie.IE_DESC
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie._TEST == GlideIE._TEST

# Generated at 2022-06-12 17:27:48.167876
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:27:58.887518
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE._AVAILABLE_DISPLAY_ID == 'id'
    assert GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:28:02.705980
# Unit test for constructor of class GlideIE
def test_GlideIE():
	glide = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
	assert glide!= None

# Generated at 2022-06-12 17:28:10.631999
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    data = ie._real_extract(url)
    assert(data['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w==')
    assert(data['title'] == "Damon's Glide message")
    assert(data['url'] == "http://d2q2q3qo8ns8qg.cloudfront.net/UZF8zlmuQbe4mr+7dCiQ0w==.mp4")

# Generated at 2022-06-12 17:28:11.131279
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:28:50.822574
# Unit test for constructor of class GlideIE
def test_GlideIE():
    passed = (GlideIE() != None)
    assert passed

# Generated at 2022-06-12 17:28:59.265669
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:01.536023
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert("GlideIE" == GlideIE.__name__)
    assert("InfoExtractor" == GlideIE.__base__.__name__)


# Generated at 2022-06-12 17:29:08.669330
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:15.637114
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie_desc = ie.IE_DESC
    ie_valid_url = ie._VALID_URL
    ie_test = ie._TEST
    assert ie_desc == 'Glide mobile video messages (glide.me)'
    assert ie_valid_url == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:29:26.559844
# Unit test for constructor of class GlideIE

# Generated at 2022-06-12 17:29:27.836856
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test = GlideIE(None)
    assert test


# Generated at 2022-06-12 17:29:30.505402
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.video_id == 'UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie.url == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:29:34.487071
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    print(ie)
    print(ie._TEST)
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    result = ie.extract(url)
    print(result)

# Generated at 2022-06-12 17:29:41.450358
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        # Initializing a valid URL
        GlideIE(url="http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    except Exception as e:
        msg = str(e)
        assert "Invalid URL: http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==" in msg
    try:
        # Initializing with empty URL
        GlideIE(url="")
    except Exception as e:
        msg = str(e)
        assert "Invalid URL: " in msg

# Generated at 2022-06-12 17:30:57.200788
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == "Glide"
    assert ie.IE_DESC == "Glide mobile video messages (glide.me)"

# Generated at 2022-06-12 17:30:57.830762
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:31:04.444287
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    GlideIE()._extract_url(url)
    return 0
 
if __name__ == '__main__':
    test_GlideIE()

# Generated at 2022-06-12 17:31:04.747360
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()

# Generated at 2022-06-12 17:31:06.890943
# Unit test for constructor of class GlideIE
def test_GlideIE():
  glide_ie_obj = GlideIE()
  string = glide_ie_obj._proto_relative_url('//share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
  assert string == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:31:17.826239
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from . import GlideIE
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.IE_NAME == 'glide'
    assert ie._VALID_URL == GlideIE._VALID_URL
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie.VIDEO_EXTENSIONS == ['mp4']
    assert ie.SUFFIX == 'm3u8'
    assert ie.IE_KEY == 'Glide'

# Generated at 2022-06-12 17:31:27.607769
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == ('Glide mobile video messages (glide.me)')
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:31:31.095055
# Unit test for constructor of class GlideIE
def test_GlideIE():
    import unittest
    test_obj = GlideIE(None)
    assert test_obj is not None


# Generated at 2022-06-12 17:31:31.981216
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:31:34.663089
# Unit test for constructor of class GlideIE
def test_GlideIE():
    def __init__(self, iExtractor):
        self.iExtractor = iExtractor

    def _download_webpage(self, url, iExtractor):
        pass

# Generated at 2022-06-12 17:34:06.578880
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:34:07.224065
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE is not None


# Generated at 2022-06-12 17:34:09.211470
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.IE_DESC is not 'glide.me'
    assert GlideIE.IE_DESC is not 'Glide mobile video messages (glide.me)'
    assert GlideIE.IE_DESC is not ''


# Generated at 2022-06-12 17:34:10.770636
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE('send.glide.me', 'www.glide.me')
    assert ie.IE_NAME == 'Glide'

# Generated at 2022-06-12 17:34:12.447147
# Unit test for constructor of class GlideIE
def test_GlideIE():
    #test for constructor for class GlideIE
    #assert GlideIE()._VALID_URL == 'https?://share.glide.me/'
    return

# Generated at 2022-06-12 17:34:21.301291
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:34:23.479261
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME == 'glide'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'


# Generated at 2022-06-12 17:34:29.009597
# Unit test for constructor of class GlideIE
def test_GlideIE():
    i = GlideIE()
    assert i.IE_DESC
    assert i._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert i.ie_key()
    assert i.ie_key() == "Glide"
    assert i.test()
    assert i.test().get('id')
    assert i.test().get('id') == "UZF8zlmuQbe4mr+7dCiQ0w=="
    assert i.test().get('md5')
    assert i.test().get('md5') == "4466372687352851af2d131cfaa8a4c7"
    assert i.test().get('info_dict')


# Generated at 2022-06-12 17:34:30.920235
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = InfoExtractor()
    ie._type = 'glide'
    assert ie._type == 'glide'

# Generated at 2022-06-12 17:34:32.617873
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Simple test to see if GlideIE class can be constructed.
    """
    ie = GlideIE()
    assert ie