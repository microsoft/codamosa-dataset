

# Generated at 2022-06-12 17:25:02.668037
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert len(ie._TEST) == 4
    assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'
    assert ie._TEST['info_dict']['id'] == 'UZF8zlmuQbe4mr+7dCiQ0w=='

# Generated at 2022-06-12 17:25:04.351569
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_NAME

# Generated at 2022-06-12 17:25:06.710723
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE();
    assert obj.name == 'Glide', 'expected Glide, got %s' % obj.name

# Generated at 2022-06-12 17:25:11.756424
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:25:12.386459
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:25:20.631326
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert isinstance(ie, GlideIE)
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, "IE_DESC") == True
    assert isinstance(ie.IE_DESC, str)
    assert hasattr(ie, "IE_NAME") == True
    assert isinstance(ie.IE_NAME, str)
    assert hasattr(ie, "ie_key") == True
    assert isinstance(ie.ie_key(), str)
    assert hasattr(ie, "extractor" )


# Generated at 2022-06-12 17:25:27.597053
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    # Test url from same domain
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    extractor = ie.suitable(url)
    assert extractor is not None, "Failed to detect url %s" % url
    # Test url from other domain
    url = "https://www.youtube.com/watch?v=RgKAFK5djSk"
    extractor = ie.suitable(url)
    assert extractor is None, "Should not detect incorrect url %s" % url

# Generated at 2022-06-12 17:25:30.484887
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # TODO: It is not clear for me how to write such a test.
    #       What would be the value of the url parameter?
    assert(GlideIE(url=None) is not None)

# Generated at 2022-06-12 17:25:31.517321
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()


test_GlideIE()

# Generated at 2022-06-12 17:25:34.239008
# Unit test for constructor of class GlideIE
def test_GlideIE():
    instance = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert isinstance(instance, GlideIE)


# Generated at 2022-06-12 17:25:41.889005
# Unit test for constructor of class GlideIE
def test_GlideIE():
	extractor = GlideIE(None)
	assert extractor != None

# Generated at 2022-06-12 17:25:43.768688
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (GlideIE.IE_DESC) == 'Glide mobile video messages (glide.me)'


# Generated at 2022-06-12 17:25:45.001135
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glideIE = GlideIE();

# Generated at 2022-06-12 17:25:47.963248
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert(GlideIE._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')

# Generated at 2022-06-12 17:25:49.928155
# Unit test for constructor of class GlideIE
def test_GlideIE():
	# Try to see whether or not GlideIE is initialized properly and no exceptions are raised when GlideIE::__init__() is invoked.
	assert GlideIE

# Generated at 2022-06-12 17:25:54.089473
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test GlideIE construction
    # Constructor of GlideIE takes a string as parameter
    glide_ie = GlideIE(url='http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    # Check whether the instance is GlideIE
    assert isinstance(glide_ie, GlideIE) == True

# Generated at 2022-06-12 17:25:56.184737
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """Test constructor of class GlideIE"""
    from .common import GlideIE

# Generated at 2022-06-12 17:25:58.005941
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")
    assert(ie.ie_key() == "Glide")
    assert(ie.ie_desc() == "Glide mobile video messages (glide.me)")



# Generated at 2022-06-12 17:26:01.266824
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:26:09.557675
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create an instance of GlideIE object
    obj = GlideIE()
    # Check obj is an instance of GlideIE
    if not isinstance(obj, GlideIE):
        raise TypeError('An instance of GlideIE is expected.')
    # Check type of obj._VALID_URL is string
    if not isinstance(obj._VALID_URL, str):
        raise TypeError('Expected string for obj._VALID_URL.')
    # Check type of obj.IE_DESC is string
    if not isinstance(obj.IE_DESC, str):
        raise TypeError('Expected string for obj.IE_DESC')
    # Check type of obj._TEST is dictionary
    if not isinstance(obj._TEST, dict):
        raise TypeError('Expected dictionary for obj._TEST')
    # Check

# Generated at 2022-06-12 17:26:17.799182
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (str(GlideIE(GlideIE._downloader)) == 'Glide mobile video messages (glide.me)')


# Generated at 2022-06-12 17:26:19.293729
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    # Unit test for GlideIE.ie_key
    asser

# Generated at 2022-06-12 17:26:32.489306
# Unit test for constructor of class GlideIE
def test_GlideIE():
	"""
	Unit test for constructor of class GlideIE
	"""
	ie = GlideIE()
	assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
	assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
	assert ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
	assert ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:26:40.441048
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE({})
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:26:41.207471
# Unit test for constructor of class GlideIE
def test_GlideIE():
    return

# Generated at 2022-06-12 17:26:42.835541
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_obj = GlideIE()
    assert "GlideIE" == test_obj.IE_NAME

# Generated at 2022-06-12 17:26:45.980854
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == 'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    


# Generated at 2022-06-12 17:26:47.478170
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:26:49.201594
# Unit test for constructor of class GlideIE
def test_GlideIE():
    pass

# Generated at 2022-06-12 17:26:51.532138
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:27:07.147973
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert (
        GlideIE._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    )
# Test case for class GlideIE, testing _proto_relative_url()

# Generated at 2022-06-12 17:27:07.720524
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:27:09.321241
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception as err:
        assert False, err


# Generated at 2022-06-12 17:27:11.435453
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')

# Generated at 2022-06-12 17:27:14.149998
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except Exception as e:
        print('TEST FAILED: %s' % e)

# Generated at 2022-06-12 17:27:15.662582
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    ie.extract(test_GlideIE.__name__)

# Generated at 2022-06-12 17:27:16.843468
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE()
    assert obj!=False


# Generated at 2022-06-12 17:27:18.268103
# Unit test for constructor of class GlideIE
def test_GlideIE():
    infoExtractor = GlideIE()
    assert infoExtractor.IE_NAME == "Glide"

# Generated at 2022-06-12 17:27:19.975970
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE()

# Generated at 2022-06-12 17:27:26.496936
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Create GlideIE instance and test its method extract
    # as well as access to its attributes and some of its method's response
    ie = GlideIE()
    ie.extract(ie._TEST['url'])
    assert ie._VALID_URL == ie._TEST['url']

# Generated at 2022-06-12 17:27:58.447085
# Unit test for constructor of class GlideIE
def test_GlideIE():
    url     = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    ie      = GlideIE()
    result  = ie.extract(url)
    '''
    print('result:', result)
    print('    id:', result['id'])
    print(' title:', result['title'])
    print('    url:', result['url'])
    print('thumb.:', result['thumbnail'])
    '''

# Generated at 2022-06-12 17:28:02.283292
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==", {})

# Generated at 2022-06-12 17:28:04.565095
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # a code snippet from glide.me
    assert isinstance(GlideIE('glide', 'glide.me'), GlideIE)

# Generated at 2022-06-12 17:28:05.134872
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE()

# Generated at 2022-06-12 17:28:06.674712
# Unit test for constructor of class GlideIE
def test_GlideIE():
    try:
        GlideIE()
    except AssertionError as e:
        assert False, e.message

# Generated at 2022-06-12 17:28:07.339440
# Unit test for constructor of class GlideIE
def test_GlideIE():
    constructor_test_for_ie(GlideIE)

# Generated at 2022-06-12 17:28:09.068441
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE(InfoExtractor) != None

# Generated at 2022-06-12 17:28:10.249655
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()

# Generated at 2022-06-12 17:28:11.034289
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(None)._real_initialize()

# Generated at 2022-06-12 17:28:12.053606
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL

# Generated at 2022-06-12 17:29:26.129672
# Unit test for constructor of class GlideIE
def test_GlideIE():
    from .common import GlideIE
    from .test_common import make_test_video_url_result
    ie = GlideIE()
    ie.IE_DESC = "Glide mobile video messages (glide.me)"
    ie._VALID_URL = "https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)$"

# Generated at 2022-06-12 17:29:29.439747
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # instantiate class
    ie = GlideIE()
    # test valid URL
    testURL = 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=='
    assert ie._VALID_URL == IE_DESC

# Generated at 2022-06-12 17:29:37.625868
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert (ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)')
    assert (ie._TEST['url'] == 'http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert (ie._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7')

# Generated at 2022-06-12 17:29:46.010585
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # tests Unittest
    import unittest
    # test GlideIE
    class TestGlideIE(unittest.TestCase):
        def test_can_handle_url(self):
            self.assertEqual(
                GlideIE.can_handle_url(
                    "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="),
                True)
            self.assertEqual(
                GlideIE.can_handle_url(
                    "https://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="),
                True)

# Generated at 2022-06-12 17:29:49.997516
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE()._VALID_URL == GlideIE._VALID_URL
    assert GlideIE().IE_NAME == 'glide'
    assert GlideIE().IE_DESC == GlideIE._VALID_URL

# Generated at 2022-06-12 17:29:54.076703
# Unit test for constructor of class GlideIE
def test_GlideIE():
    ie = GlideIE()
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert ie.IE_DESC == 'Glide mobile video messages (glide.me)'



# Generated at 2022-06-12 17:30:00.416174
# Unit test for constructor of class GlideIE
def test_GlideIE():
    line1 = 'GlideIE(InfoExtractor)'
    line2 = 'Creates an instance of GlideIE'
    line3 = 'which is an instance of InfoExtractor'
    line4 = 'that is an instance of YoutubePlaylistIE'
    line5 = 'which is an instance of YoutubeBaseInfoExtractor'
    line6 = 'which is an instance of InfoExtractor'
    realline1 = GlideIE.__init__.__doc__.split(':')[0]
    realline2 = GlideIE.__init__.__doc__.split(':')[1]
    realline3 = GlideIE.__init__.__doc__.split(':')[2]
    realline4 = InfoExtractor.__init__.__doc__.split(':')[2]
    reall

# Generated at 2022-06-12 17:30:04.221902
# Unit test for constructor of class GlideIE
def test_GlideIE():
	ie = GlideIE()
	# print(ie.extract_info())
	# print(ie._extract_info())
	# Check if the url is valid.

# Generated at 2022-06-12 17:30:11.445262
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    glide_ie = GlideIE()
    assert glide_ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert glide_ie.IE_DESC == 'Glide mobile video messages (glide.me)'

# Generated at 2022-06-12 17:30:13.606235
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """This is to test constructor of GlideIE class"""
    ie = GlideIE()
    assert ie.ie_key() == 'Glide'

# Generated at 2022-06-12 17:32:52.633423
# Unit test for constructor of class GlideIE
def test_GlideIE():
    obj = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    print (obj._VALID_URL)

# Generated at 2022-06-12 17:32:57.145790
# Unit test for constructor of class GlideIE
def test_GlideIE():
    assert GlideIE.suitable('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    ie = GlideIE('http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==')
    assert ie.extract_info()['title'] == "Damon's Glide message"


# Generated at 2022-06-12 17:32:58.186566
# Unit test for constructor of class GlideIE
def test_GlideIE():
    glide = GlideIE()
    expected = GlideIE.IE_DESC
    assert(glide.IE_DESC == expected)

# Generated at 2022-06-12 17:32:59.134223
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE(InfoExtractor())

# Generated at 2022-06-12 17:33:00.700767
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:33:02.129255
# Unit test for constructor of class GlideIE
def test_GlideIE():
    GlideIE("http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w==")

# Generated at 2022-06-12 17:33:03.008669
# Unit test for constructor of class GlideIE
def test_GlideIE():
	GlideIE(GLideIE.IE_NAME, False)


# Generated at 2022-06-12 17:33:11.844336
# Unit test for constructor of class GlideIE
def test_GlideIE():
    # Test when video_id is present in URL.
    url = "http://share.glide.me/UZF8zlmuQbe4mr+7dCiQ0w=="
    ie = GlideIE(url)
    assert ie._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'

# Generated at 2022-06-12 17:33:13.712927
# Unit test for constructor of class GlideIE
def test_GlideIE():
    test_instance = GlideIE()
    assert test_instance._VALID_URL == r'https?://share\.glide\.me/(?P<id>[A-Za-z0-9\-=_+]+)'
    assert test_instance._TEST['md5'] == '4466372687352851af2d131cfaa8a4c7'

# Generated at 2022-06-12 17:33:16.674865
# Unit test for constructor of class GlideIE
def test_GlideIE():
    """
    Unit test for constructor of class GlideIE
    """
    # Test with empty url
    assert(GlideIE() != None)

# Testing of download of video from Glide