

# Generated at 2022-06-25 07:07:59.284807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {}
    set_0 = {bool_0}
    float_0 = 630.61
    list_0 = [set_0]
    set_13 = {float_0}
    action_module_0 = ActionModule(bool_0, dict_0, set_0, float_0, set_13, list_0)
    tmp_0 = None
    task_vars_0 = {}
    result = action_module_0.run(tmp_0, task_vars_0)
    return result


# Generated at 2022-06-25 07:08:07.057334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0()

    bool_0 = True
    dict_0 = {}
    set_0 = {'g', 'E', 'a', 'L'}
    float_0 = 858.05
    list_0 = [set_0]
    action_module_0 = ActionModule(bool_0, dict_0, set_0, float_0, set_0, list_0)


# Generated at 2022-06-25 07:08:12.491749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    set_0 = {}
    list_0 = []
    list_1 = []
    action_module_0 = ActionModule(dict_0, list_0, list_1)
    assert type(action_module_0._display) == dict


# Generated at 2022-06-25 07:08:17.234688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up objects.
    bool_0 = True
    dict_0 = {}
    set_0 = set({})
    float_0 = 630.61
    list_0 = [bool_0]
    ActionModule(bool_0, dict_0, set_0, float_0, set_0, list_0)


# Generated at 2022-06-25 07:08:21.468023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '__init__')
    assert callable(ActionModule.__init__)
    test_case_0()


# Generated at 2022-06-25 07:08:27.929248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = not False
    dict_0 = {}
    set_0 = {}
    float_0 = 0.9209
    action_module_0 = ActionModule(bool_0, dict_0, set_0, float_0, set_0, set_0)
    action_module_0.run()
    assert set_0 == {}


# Generated at 2022-06-25 07:08:30.546799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule()
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:08:31.471889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:08:32.324408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:08:41.956115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_2 = True
    dict_0 = {}
    set_0 = {bool_2}
    float_0 = 13.67
    list_0 = []
    action_module_0 = ActionModule(bool_2, dict_0, set_0, float_0, set_0, list_0)
    action_module_0._task.async_val = True
    action_module_0._task.action = 'setup'
    action_module_0._connection.has_native_async = False
    dict_1 = {}
    dict_2 = {}
    dict_2['module_args'] = {}
    dict_2['module_name'] = 'setup'
    dict_1['invocation'] = dict_2
    action_module_0._task.action = 'setup'
    action_module_0

# Generated at 2022-06-25 07:08:51.506986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -3767
    list_0 = [int_0]
    str_0 = 'jvrze'
    bytes_0 = b'\x81\x0e\xae\xa7\xb0\x91\xafQL'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    action_module_0.run(tmp=null)


# Generated at 2022-06-25 07:08:59.875632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test classes...')
    print('Test methods...')
    print('Method of class ActionModule: ' + 'run')
    print('Test case...')
    print('Test 0...')
    print('Input parameters...')
    print('')
    print('Expected output...')
    print('True')
    print('Calculating...')
    result_0 = test_case_0()
    print('Checking...')
    print(result_0)
    print()
    print('Function call action_run() from file action_module.py...')
    print()
    print('Result of call test_case_0():')
    print('True')
    print('Verification...')
    assert(result_0 == True)


# Generated at 2022-06-25 07:09:03.607444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = (216)
    list_0 = [int_0]
    str_0 = '8PZz'
    bytes_0 = b'\x8b'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    var_0 = action_module_0.run()
    print(var_0)

# Generated at 2022-06-25 07:09:13.779961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = '_raw_params'
    module_args = 'chmod'
    module_vars_name = 'module_vars'
    task_vars_name = 'task_vars_name'
    wrap_async_name = 'wrap_async'
    tmp_name = 'tmp'
    ActionModule_ins = ActionModule(module_name, module_args,module_vars_name, task_vars_name, wrap_async_name, tmp_name)
    print(ActionModule_ins.module_name)
    print(ActionModule_ins.module_args)
    print(ActionModule_ins.module_vars)
    print(ActionModule_ins.task_vars)
    print(ActionModule_ins.wrap_async)
    print(ActionModule_ins.tmp)

# Generated at 2022-06-25 07:09:14.661046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:09:19.119831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Expected value returned by constructor.
    expected = None
    # Actual value returned by constructor.
    actual = None
    
    # Call tested method of constructor.
    test_case_0()
    
    # Tested method returns expected value.
    assert expected == actual


# Generated at 2022-06-25 07:09:23.184127
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test that the tmp argument is used
    tmp = 'my_temp_file.txt'
    action_module_0 = ActionModule(1, [], '', '', [], b'')
    result = action_module_0.run(tmp=tmp, task_vars={})
    assert tmp in result['tmp']

# Generated at 2022-06-25 07:09:23.690665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:09:30.648268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        int_0 = -4431
        list_0 = [int_0]
        str_0 = 'p3jkz'
        bytes_0 = b'\xc0\xfd\xc2P_47'
        action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
        var_0 = action_module_0.run()
    except Exception as exception_0:
        print(str(exception_0))

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:09:41.118964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3347
    list_0 = [int_0]
    str_0 = 'w_e'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, str_0)
    var_0 = action_module_0.action_async_val()
    var_1 = action_module_0.action_connection()
    var_2 = action_module_0.action_delegate_to()
    var_3 = action_module_0.action_delegated_vars()
    var_4 = action_module_0.action_environment()
    var_5 = action_module_0.action_name()
    var_6 = action_module_0.action_no_log()
    var_7 = action_module_

# Generated at 2022-06-25 07:09:49.946640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -4431
    list_0 = [int_0]
    str_0 = 'p3jkz'
    bytes_0 = b'\xc0\xfd\xc2P_47'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    var_0 = action_module_0.run()



# Generated at 2022-06-25 07:09:59.569736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_1 = -1923
    list_1 = [int_1]
    str_1 = ':@\'u'
    str_2 = 'rqXm['
    list_2 = [int_1]
    bytes_1 = b'\xd7\xb5\x12\xdfK'
    action_module_1 = ActionModule(int_1, list_1, str_1, str_2, list_2, bytes_1)
    assert (action_module_1.connection == int_1)
    assert (action_module_1.become == list_1)
    assert (action_module_1.become_method == str_1)
    assert (action_module_1.become_user == str_2)

# Generated at 2022-06-25 07:10:06.910646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2335
    list_0 = [int_0]
    str_0 = '~nPZ'
    bytes_0 = b'\xafa\xd3\x01\xfe\x9b\xfeIf!\x9c[\xda\x94\xf3\xc3\x99\x87\xd0\x9bO\xa2'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:10:11.213627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0

# Generated at 2022-06-25 07:10:21.267828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    assert action_module_0.task_vars == var_0
    assert action_module_0._supports_async == var_0
    assert action_module_0._supports_check_mode == var_0
    assert action_module_0._display.verbosity == var_0
    assert action_module_0.connection == var_0
    assert action_module_0.task_vars == var_0
    assert action_module_0.task_vars == var_0
    assert action_module_0.task_vars == var_0
    assert action_module_0.task_vars == var_0
    assert action_module_0.task_v

# Generated at 2022-06-25 07:10:26.149929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Declare variables for testing
    test_case = [0]
    for case in test_case:
        if case == 0:
            __default_tmpdir = None
            __default_task_vars = {}
            test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:10:32.357023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -6177
    list_0 = [int_0]
    str_0 = 'My name is {0}'.format(int_0)
    bytes_0 = b'\xf3\x7f\xde\xde\x9c\x17\x16'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)


# Generated at 2022-06-25 07:10:36.941535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -63942
    list_0 = []
    str_0 = '8J:W'
    bytes_0 = b"\xb0\x98\x08\x03"
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    var_0 = action_run()

if __name__=='__main__':
    test_case_0()

# Generated at 2022-06-25 07:10:43.849622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule constructor")
    int_0 = -231817194
    list_0 = None
    str_0 = 'n9o\x1b\x1b\x1b\x1b\x1b\x1b'
    str_1 = '9)h\x1b\x1b\x1b\x1b\x1b\x1b'
    list_1 = []
    bytes_0 = b'\x0b\xec\xcaA'
    result = action_module_0 = ActionModule(int_0, list_0, str_0, str_1, list_1, bytes_0)
    # Assert the result of class constructor is an instance of ActionModule
    assert isinstance(result, ActionModule)


# Generated at 2022-06-25 07:10:45.571789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert True
    except AssertionError as e:
        print("AssertionError !")
        print(e)


# Generated at 2022-06-25 07:10:58.395471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Function returned by decorator

# Generated at 2022-06-25 07:10:59.892779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.module_name == 'action'
    assert action_module_0.module_args == {}
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True

# Generated at 2022-06-25 07:11:02.742292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # var_0 = ActionModule()
    pass


# Generated at 2022-06-25 07:11:07.211946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Verify that the result of run method is None
    assert action_module_0.run() == None, 'ActionModule.run is failed'

# Generated at 2022-06-25 07:11:16.712113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1664
    list_0 = ['', 'g68']
    str_0 = '9'
    bytes_0 = b'\xcf\xde\xf0\xfe\xca\x8d\x9d\x80'
    component = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    assert component._supports_async == True, 'Fail: component._supports_async'
    assert component._supports_check_mode == True, 'Fail: component._supports_check_mode'

# Generated at 2022-06-25 07:11:18.371905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:11:26.173615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1663
    str_0 = 'vX8\x17'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(int_0, dict_0, str_0, str_0, dict_0, str_0)
    action_module_0.run()
    assert action_module_0.run() is None

# Generated at 2022-06-25 07:11:28.046751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()

    action_module_1.run()


# Generated at 2022-06-25 07:11:35.855415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1266
    list_0 = [int_0]
    str_0 = 't\xaa\xc1\xf6\x87'
    bytes_0 = b'\xbe\x87\xa8\x01\x9e\x10>'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 07:11:41.341215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1750
    list_0 = [int_0]
    str_0 = '\x1b\xe3\n1\xc6\xbd\xb0\xaa\xde\x19\xd1\xc2\xcd'
    bytes_0 = b'\xd8\xd6\x0f\x12\x1b\xeb\x0c\xc2\x01\xe0'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    assert action_module_0._supports_async is True


# Generated at 2022-06-25 07:12:05.887879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # [ ]
    # [ ]
    int_0 = 0
    list_0 = []
    str_0 = str()
    bytes_0 = bytes()
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    var_0 = action_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 07:12:14.638887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -26245
    list_0 = [int_0]
    str_0 = 'csb}'
    bytes_0 = b'j\xab\xd0\x16\x1b'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    action_module_0.run()

# Testing for class ActionModule

# Generated at 2022-06-25 07:12:21.074553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -73
    list_0 = [int_0]
    str_0 = 'peH+'
    bytes_0 = b'v\x7f\xd8\xab\xa5\x9dY'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    return

# Generated at 2022-06-25 07:12:25.209190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_0 = ActionModule(0, [0], 'p3jkz', 'p3jkz', [0], b'\xc0\xfd\xc2P_47')
    func_0 = ActionModule.run
    assert func_0(class_0) == None

# Generated at 2022-06-25 07:12:30.950524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -4431
    list_0 = [int_0]
    str_0 = 'p3jkz'
    action_module_1 = ActionModule(int_0, list_0, str_0, str_0, list_0)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 07:12:33.310310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

if __name__ == '__main__':
    # test for action_run()
    test_case_0()
    # Unit test for method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-25 07:12:38.231776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run()")
    action_module_0 = ActionModule(bool_0, bool_0)
    TestAnsibleModule_0 = TestAnsibleModule(bool_0, action_module_0)
    str_0 = TestAnsibleModule_0.run()

    assert(TestAnsibleModule_0 != None)

if __name__ == "__main__":
    print("Running tests on ActionModule.py")
    test_ActionModule_run()

# Generated at 2022-06-25 07:12:38.878953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:12:47.274221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -4431
    list_0 = [int_0]
    str_0 = 'p3jkz'
    bytes_0 = b'\xc0\xfd\xc2P_47'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    var_0 = action_module_0.run()

# Generates test case for method action_run of class ActionBase

# Generated at 2022-06-25 07:12:55.600225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -123
    list_0 = [int_0]
    str_0 = 'n8pzw'
    bytes_0 = b'\xf1\x0fP\x9b\xf1\x03'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:13:51.885496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -4431
    list_0 = [int_0]
    str_0 = 'p3jkz'
    bytes_0 = b'\xc0\xfd\xc2P_47'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:13:55.871412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except AssertionError:
        print('Test Failed')
    else:
        print('Test Passed')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:14:00.041674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    list_0 = []
    str_0 = 'd4_8'
    bytes_0 = b'\xd6'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    var_2 = action_module_0.run(0, 0)

    if var_2 == 0:
        return var_2
    return var_2

# Generated at 2022-06-25 07:14:02.753264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -4431
    list_0 = [int_0]
    str_0 = 'p3jkz'
    bytes_0 = b'\xc0\xfd\xc2P_47'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)

# Generated at 2022-06-25 07:14:04.718884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'cache_key'
    var_0 = action_module_0.run(str_0)


# Generated at 2022-06-25 07:14:15.833809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -6459
    list_0 = [int_0]
    str_0 = 'zmmym'
    bytes_0 = b'\x05s\x9f\xc9\x15\x0b'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)
    assert action_module_0._task.hostvars == list_0
    assert action_module_0._task.only_if == str_0
    assert action_module_0._task.not_if == str_0
    assert action_module_0._task.delegate_to == list_0
    assert action_module_0._task.async_val == int_0
    assert action_module_0._task.async_

# Generated at 2022-06-25 07:14:18.338863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert (action_module_0 != None)


# Generated at 2022-06-25 07:14:19.284417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:14:27.043868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 186
    list_0 = [int_0]
    str_0 = 'private'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, None)
    assert (action_module_0._task == int_0)
    assert (action_module_0._connection == list_0)
    assert (action_module_0._play_context == str_0)
    assert (action_module_0._loader == str_0)
    assert (action_module_0._templar == list_0)
    assert (action_module_0._shared_loader_obj == None)


# Generated at 2022-06-25 07:14:34.935245
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_1 = [1, 2, 3, 4, 5]
    str_1 = '1_L8n'
    action_module_1 = ActionModule(1, list_1, str_1, str_1, list_1, b'\x0b\xf2')
    action_module_1.run()
    class_0 = ActionModule
    action_module_2 = ActionModule(1, list_1, str_1, str_1, list_1, b'\x0b\xf2')
    action_module_2.run()
    action_module_3 = ActionModule(1, list_1, str_1, str_1, list_1, b'\x0b\xf2')
    action_module_3.run()

# Generated at 2022-06-25 07:16:35.856818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  try:
    str_0 = 'dR%=\x89t\x11j'
    # Creation of the object ActionModule with 4 arguments
    action_module_0 = ActionModule(str_0,str_0,str_0,str_0,str_0,str_0)
    # Call to the method run
    action_module_0.run()
  except Exception as e:
    print("Exception when calling run:")
    print(e)



# Generated at 2022-06-25 07:16:36.946269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

test_module()

# Generated at 2022-06-25 07:16:42.037516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'tL'
    tuple_0 = (str_0, )
    str_1 = 'I\xf6\xdfn{'
    bytes_0 = b'\x1f\x02\or\x81\xb4\x13\xc4'
    str_2 = 'S\xe8\xaa\x9e9\xbb\x8f\x1f'
    int_0 = 9810
    action_module_0 = ActionModule(tuple_0, str_1, int_0, str_2, tuple_0, bytes_0)
    var_0 = action_run(bytes_0)



# Generated at 2022-06-25 07:16:45.974407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run()
    var_0 = -4835
    list_0 = ["zZLfC", "o4w"]
    str_0 = 'y'
    bytes_0 = b'\xa9\x06%\xfc\xad\x86'
    action_module_0 = ActionModule(var_0, list_0, str_0, str_0, list_0, bytes_0)

# Wrapper for ActionModule

# Generated at 2022-06-25 07:16:46.551443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:16:54.569050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # for var_0, var_1 in zip(range(1, 200), range(2, 200, 2)):
        # if var_0 == var_1:
            # print(var_0, var_1)
        # else:
            # print(var_0)
    # var_2 = 1
    # while var_2 < 200:
        # if var_2 % 2:
            # print(var_2)
        # else:
            # print(var_2, ', ')
        # var_2 += 1
    # var_3 = 'true'
    # var_4 = True
    # print(var_3, var_4)
    # for var_2 in range(10, 20, 2):
        # print(var_2)
    var_2 = False

# Generated at 2022-06-25 07:16:58.230327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -7319
    list_0 = [-7319, -7319]
    str_0 = 'wh'
    bytes_0 = b'\xd4\xeb\xe1\xd4\x14\x83\x88\x80\x9b'
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, list_0, bytes_0)


# Generated at 2022-06-25 07:16:59.382431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        pass
    except:
        print ()


# Generated at 2022-06-25 07:17:04.239850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    print(var_0)

# Generated at 2022-06-25 07:17:11.303185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_1 = -959
    list_1 = [int_1]
    str_1 = 'gF6A'
    bytes_1 = b'\x9c\xfb\x82\x93\x83\xfe\xe4y'
    action_module_1 = ActionModule(int_1, list_1, str_1, str_1, list_1, bytes_1)
    tmp_1 = 'Tmp'
    task_vars_1 = 'TaskVars'
    var_1 = action_module_1.run(tmp_1, task_vars_1)

test_ActionModule()