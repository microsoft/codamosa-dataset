

# Generated at 2022-06-25 07:07:54.958404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

test_ActionModule = ActionModule()


# Generated at 2022-06-25 07:07:57.970040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None
    assert action._supports_async
    assert action._supports_check_mode

# Unit tests for run method of class ActionModule


# Generated at 2022-06-25 07:08:01.329033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = dict_0
    dict_2 = {}
    dict_2['skipped'] = False
    dict_2['invocation'] = dict_1
    dict_3 = dict_0
    dict_3['skipped'] = dict_1
    dict_3['invocation'] = dict_1
    dict_4 = dict_0
    dict_4['skipped'] = dict_1
    dict_4['invocation'] = dict_1
    dict_4['skipped'] = dict_1
    dict_4['invocation'] = dict_1
    dict_5 = dict_0
    dict_5['skipped'] = dict_1
    dict_5['invocation'] = dict_1
    dict_6 = dict_0
    dict_6['skipped'] = dict_1

# Generated at 2022-06-25 07:08:04.256601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({})

if __name__ == '__main__':
    for test_case in [test_case_0]:
        test_case()

# Generated at 2022-06-25 07:08:08.621342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.plugins.action import ActionModule
  action_module = ActionModule()

  # Pass a 1st test
  expr_list_0 = []
  for item in set_0:
    expr_list_0.append(item)


  # Pass a 2st test
  expr_list_2 = []
  for item in set_0:
    expr_list_2.append(item)


  # Pass a 3st test

# Generated at 2022-06-25 07:08:18.953481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    obj_0 = ActionModule(tmp_0, task_vars_0)
    assert isinstance(obj_0, ActionModule)
    assert isinstance(obj_0, object)
    assert not hasattr(obj_0, 'tmp')
    assert not hasattr(obj_0, 'task_vars')
    assert hasattr(obj_0, '_task')
    assert not hasattr(obj_0, '_display')
    assert not hasattr(obj_0, '_connection')
    assert not hasattr(obj_0, '_supports_check_mode')
    assert not hasattr(obj_0, '_supports_async')
    assert hasattr(obj_0, '_loader')

# Generated at 2022-06-25 07:08:20.031064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule_obj = ActionModule()


# Generated at 2022-06-25 07:08:26.082416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create empty object
    obj = ActionModule()

    # make test for object
    # no exception should be raised here
    try:
        obj.run()
    except Exception as e:
        print("Test exception raised: " + str(e))
        raise

    # Test for the case where $self->_task->async_val is not set and $self->_connection->has_native_async is not set
    # should raise an exception
    obj._task.async_val = None
    obj._connection.has_native_async = False
    # exception should be raised here
    try:
        obj.run()
        print("Exception not raised as expected")
    except Exception as e:
        pass

# Generated at 2022-06-25 07:08:27.022207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:08:37.179745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = {
        'module_args': {  'create_dest': True, 'type': 'user', 'name': 'foo', 'state': 'absent', 'update_password': 'always'},
        'module_name': 'user'
    }
    task_vars = {'ansible_facts': {'os_family': 'RedHat', 'deprecated_facts': {'ansible_distribution': 'RedHat', 'ansible_distribution_release': '7.0'}}}
    wrap_async = True
    self = ActionModule(params, task_vars, wrap_async)
    self.action = 'setup'
    result = self.run()
    assert result == {
        'failed': False,
        'skip_reason': 'Conditional result was False',
        'skipped': True
    }

# Generated at 2022-06-25 07:08:41.675188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert result is not None

test_case_0()

# Generated at 2022-06-25 07:08:45.326663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run("tmp", "task_vars")
    assert result is None


# Generated at 2022-06-25 07:08:46.875449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:08:49.927518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert_equal(action_module_0._supports_check_mode, True)
    assert_equal(action_module_0._supports_async, True)


# Generated at 2022-06-25 07:08:51.273394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)
    assert callable(ActionModule)

# Generated at 2022-06-25 07:08:52.584500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False  # TODO: implement your test here


# Generated at 2022-06-25 07:08:54.232599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    output = test_case_0()
    assert output == None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:56.223169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:08:57.578405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    # FIXME



# Generated at 2022-06-25 07:09:00.533448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    initialize = ActionModule()
    result = initialize.run()

    # assert result['_ansible_no_log'] == False
    assert result.get('invocation', {}).get('module_args') is  None
    # assert result['_ansible_verbose_override'] == True

# Generated at 2022-06-25 07:09:13.779335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call constructor of class ActionModule without parameters
    # Verify couple of attributes
    action_module_0 = ActionModule()
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0._display.verbosity >= 0
    assert action_module_0.set_options() == None
    assert action_module_0.run() == None
    assert action_module_0.load_options() == None
    assert action_module_0._task.no_log == False
    assert action_module_0._task.always_run == False
    assert action_module_0.get_connection() == None
    assert action_module_0.get_shell() == None
    assert action_module_0._task.delegate_to == None


# Generated at 2022-06-25 07:09:17.330952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {str_0: float_0}
    float_0 = None
    list_0 = [float_0]
    bytes_0 = b''
    str_1 = '\x80'
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0, bytes_0, str_1)
    assert action_module_0.__dict__ == {'task': {dict_0: float_0}}
    ActionModule(dict_0, bool_0, list_0, float_0, bytes_0, str_1)
    assert action_module_0.__dict__ == {'task': {dict_0: float_0}}

# Generated at 2022-06-25 07:09:27.139166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_1 = None
    dict_1 = {float_1: float_1, float_1: float_1, float_1: float_1, float_1: float_1}
    bool_1 = True
    list_1 = [float_1]
    bytes_1 = b

# Generated at 2022-06-25 07:09:37.374299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_10 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_10 = None
    dict_10 = {float_10: float_10, float_10: float_10, float_10: float_10, float_10: float_10}
    bool_10 = True
    list_10 = [float_10]
    bytes_10 = b

# Generated at 2022-06-25 07:09:47.729099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Constructor for class ActionModule is called')
    str_0 = 'aL-_&Z/l+RgC{;~'
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b'\x9a*i\x8ax\x19\xf7\xb0\xd5\x8e\xbd\x0b\xb5\xad\xfc\xc3\xcb\xf4\x12\x8b\xaa\x9e\x86\xdf/\x86\xb2\xbf\xfd'
    int_0 = 5

# Generated at 2022-06-25 07:09:59.264208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:10:07.604560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '!'
    float_0 = 0.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_1 = True
    list_0 = [float_0]
    bytes_0 = b''
    str_0 = '....'
    action_module_1 = ActionModule(dict_0, bool_1, list_0, float_0, bytes_0, str_0)
    action_module_0 = ActionModule(dict_0, bool_1, list_0, float_0, bytes_0, str_0)
    action_module_1._execute_module(str_1)

# Generated at 2022-06-25 07:10:08.432686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:10:15.968584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'tmp'
    task_vars = 'task_vars'
    # ToDo: implement test for private method run of class ActionModule
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None

# Generated at 2022-06-25 07:10:17.459110
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    result = run()
    assert(result == True)



# Test for a string input

# Generated at 2022-06-25 07:10:33.528362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['connection'] = dict()
    dict_1['connection']['_shell'] = dict()
    dict_1['connection']['_shell']['tmpdir'] = None
    dict_1['connection']['has_native_async'] = False
    dict_1['action'] = 'include_role'
    dict_1['_ansible_ignore_conditions'] = False
    dict_1['_ansible_no_log'] = False
    dict_1['_ansible_module_name'] = 'include_role'
    dict_1['_ansible_verbosity'] = 0
    dict_1['_ansible_version'] = '2.9.6'
    dict_1['_ansible_loop'] = False
   

# Generated at 2022-06-25 07:10:34.531789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #TODO: implement test
    pass

# Generated at 2022-06-25 07:10:36.129831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:10:46.756836
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:10:47.762747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:10:59.437865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:11:08.506486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:11:18.613124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Test fixtures
    #Test setup

    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True

# Generated at 2022-06-25 07:11:29.420713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    bool_0 = bool()
    list_0 = list()
    float_0 = float()
    bytes_0 = bytes()
    str_0 = str()
    action_module_0 = ActionModule(dict_0, bool_0, list_0)
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0)
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0, bytes_0)
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0, bytes_0, str_0)


# Generated at 2022-06-25 07:11:39.045602
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'type': '$^oWfK5^$', 'prompt': 'Enter passphrase for key \'%s\'', 'default': 'jKmXP1!!Z&'}
    bool_0 = True
    list_0 = ['PKCS#8', 'DSA', 'ssh-ed25519']
    float_0 = -0.151709843159
    bytes_0 = b'\xE6\x8D'
    str_0 = '!'
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0, bytes_0, str_0)
    assert action_module_0._task == dict_0
    assert action_module_0._connection == bool_0
    assert action_module_0._play_context == list_0


# Generated at 2022-06-25 07:11:59.093175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'N3AaS/F{Y2n0-!_'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = False
    list_0 = [str_0]
    float_0 = None
    bytes_0 = b'V@,Tn%'
    str_1 = 'N,P>n*Mqh?\x0c,w;'
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0, bytes_0, str_1)


# Generated at 2022-06-25 07:12:08.439229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:12:11.914777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Pu>|"9X}U@'
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b''
    str_1 = '!hplp+$9Hw&P'
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0, bytes_0, str_1)
    dict_1 = {str_1: dict_0, str_0: dict_0, str_1: dict_0, str_0: dict_0}

# Generated at 2022-06-25 07:12:12.724572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:12:20.135898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:12:23.693078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 07:12:34.262420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    # create object of class ActionModule with argument 
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0, bytes_0, str_1)
    assert type() == type(action_module_0)
    # test __init__() of class ActionModule
    assert type() == type(action_module_0)
    assert type() == type(action_module_0)
    assert type() == type(action_module_0)
    assert type() == type(action_module_0)
    assert type() == type(action_module_0)
    assert type() == type(action_module_0)
    assert type() == type(action_module_0)
    assert type() == type(action_module_0)
    assert type() == type

# Generated at 2022-06-25 07:12:43.538619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:12:48.604401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # initializing the object of ActionModule class
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True

# Generated at 2022-06-25 07:12:49.927925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ctypes
    test_case_0()


# Generated at 2022-06-25 07:13:20.302570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-25 07:13:26.277658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_1 = None
    dict_1 = {float_1: float_1, float_1: float_1, float_1: float_1, float_1: float_1}
    bool_1 = True
    list_1 = [float_1]
    bytes_1 = b

# Generated at 2022-06-25 07:13:32.460460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:13:41.017384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:13:51.301201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Q7V9XIs_nI=o4q:`^1'
    float_0 = 0.6451449488968773
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b'\x81%\xaa\xb2\xcf\xba\x83\xaf\x8c\xaf\x9b\xd9\xa6\xbc\xc1\xbc\xb6'
    str_1 = '[3{1<+!9'

# Generated at 2022-06-25 07:14:00.424482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:14:02.846419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    dict_0 = {}
    dict_1 = dict_0
    dict_0 = dict_1


# Generated at 2022-06-25 07:14:09.585317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:14:17.317172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:14:23.691400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    bool_0 = False
    list_0 = list()
    float_0 = 0.0
    bytes_0 = bytes()
    str_0 = str()
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0, bytes_0, str_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result is None


# Generated at 2022-06-25 07:15:21.748984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
        assert action_module_0 is not None
        print(action_module_0.__dict__['_action_type'])
    except:
        assert False
    finally:
        print('ActionModule unit test is done')

if __name__ == '__main__':
        test_case_0()

        test_ActionModule()

# Generated at 2022-06-25 07:15:27.873652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        str_0 = 'ac,<H5p5'
        action_module_0 = ActionModule(str_0)
        print(action_module_0.play_context) # 
        print(action_module_0.new_stdin) # 
    except Exception as e:
        print(e)



# Generated at 2022-06-25 07:15:37.219439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '#YXBpb3MtZ2FsYXh5'
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = False
    list_0 = [float_0]
    bytes_0 = b'G/:>/KjGF\x7f'
    str_1 = '!hplp+$9Hw&P'
    action_module_0 = ActionModule(dict_0, bool_0, list_0, float_0, bytes_0, str_1)
    var_0 = action_run(str_0)
    var_1 = action_run(bytes_0)

# Generated at 2022-06-25 07:15:43.048573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float('NaN')
    list_0 = ['M\xFA\x83\x8f', 'lk{', 'dno9g\x8b\x06', '7\x81\x8b\x8a', 'YUC\x07\x8a\x8c\x06', 'V\x83\x8f\x8c', '\x8a\x06\x8c']

# Generated at 2022-06-25 07:15:53.140078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare mock
    test_case = 'test_case_0'
    str_0 = ''
    bytes_0 = b''
    bool_0 = False
    float_0 = 0.0
    int_0 = 0
    dict_0 = {}
    list_1 = []
    dict_1 = {}
    str_1 = 'test_value_2'
    str_2 = 'test_value_3'
    str_3 = 'test_value_4'
    dict_2 = {str_1: str_2, str_3: dict_1}
    dict_3 = {'key_4': list_1, 'key_5': bool_0}
    dict_4 = {'key_6': float_0, 'key_7': int_0, 'key_8': dict_3}
   

# Generated at 2022-06-25 07:16:00.667475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:16:09.639158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:16:17.642115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {47.9: '<}2/;;g^~#', '_ansible_verbose_override': '_ansible_verbose_override', 'rc': 'rc', 'msg': 'msg'}
    bool_0 = True
    list_0 = ['o5', 'x', -3.8]
    float_0 = 0.7466004335958278
    bytes_0 = b'P\x14\x90\x10t\x0b\x07\x1d\x17\r\x1a\x9dA[\x13\x11\x01'
    str_0 = '|+;>s\\&^x<\x1d+\x03#'

# Generated at 2022-06-25 07:16:27.282795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0, float_0: float_0}
    bool_0 = True
    list_0 = [float_0]
    bytes_0 = b

# Generated at 2022-06-25 07:16:33.669242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '\n        Install one or more roles(``ansible-galaxy role install``), or one or more collections(``ansible-galaxy collection install``).\n        You can pass in a list (roles or collections) or use the file\n        option listed below (these are mutually exclusive). If you pass in a list, it\n        can be a name (which will be downloaded via the galaxy API and github), or it can be a local tar archive file.\n\n        :param artifacts_manager: Artifacts manager.\n        '
    float_1 = None
    dict_0 = {float_1: float_1, float_1: float_1, float_1: float_1, float_1: float_1}
    bool_1 = True
    list_1 = [float_1]
    bytes_1 = b