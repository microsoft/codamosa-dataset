

# Generated at 2022-06-25 07:07:57.045940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_1 = ActionModule(task=tmp, connection=tmp, play_context=tmp, loader=tmp, templar=tmp, shared_loader_obj=tmp)


# Generated at 2022-06-25 07:07:59.059420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -392
    action_module_0 = None
    var_0 = action_module_0.run(action_module_0)

# Generated at 2022-06-25 07:08:02.695214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True


# Generated at 2022-06-25 07:08:05.516258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -392
    action_module_0 = ActionModule(int_0,int_0)
    var_0 = test_case_0(action_module_0)

# Test case to verify functionality of run

# Generated at 2022-06-25 07:08:11.378549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -144
    action_module_0 = ActionModule(int_0, action_module_0)
    var_0 = action_module_0.run(action_module_0)

# Generated at 2022-06-25 07:08:13.611290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -422
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:08:14.990152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:08:16.772138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

test_ActionModule()

# Generated at 2022-06-25 07:08:26.224653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -817
    action_module_0 = ActionModule(int_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    action_module_0._remove_tmp_path(action_module_0._connection._shell.tmpdir)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    action_module_0._remove_tmp_path(action_module_0._connection._shell.tmpdir)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True

# Generated at 2022-06-25 07:08:28.772418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # fixture
    action_module_0 = ActionModule()

    # test
    test_case_0()



# Generated at 2022-06-25 07:08:33.165570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0 is not None

# Generated at 2022-06-25 07:08:38.093261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if(action_module_0 == None):
        raise AssertionError("Object not initialized properly")


# Generated at 2022-06-25 07:08:42.575960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_1 = None
    task_vars_2 = None
    result_3 = action_module_0.run(tmp_1, task_vars_2)
    result_4 = result_3
    return result_4 == None


if __name__ == '__main__':
    print(test_ActionModule_run())

# Generated at 2022-06-25 07:08:44.675015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Unit test to test run

# Generated at 2022-06-25 07:08:47.069303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run(None, None) == None

test_ActionModule_run()

# Generated at 2022-06-25 07:08:56.129215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars_0_0 = dict()
    result_data_0_0 = dict()
    result_data_0_0["invocation"] = dict()
    result_data_0_0["invocation"]["module_args"] = dict()
    result_data_0_0["skipped"] = True
    result_data_0_0["invocation"]["module_args"]["name"] = "bash"
    result_data_0_0["_ansible_verbose_override"] = False
    result_data_0_0["invocation"]["module_name"] = "shell"
    result_data_0_0["ansible_job_id"] = "1479494829.1550012"

# Generated at 2022-06-25 07:08:57.846708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:09:01.621298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    action_module_0 = ActionModule()
    tmp = None
    task_vars = TaskResult()
    assert action_module_0.run(tmp, task_vars) == {'invocation': {'module_name': 'setup'}, '_ansible_verbose_override': True}

# Generated at 2022-06-25 07:09:05.503610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # wrap_async type: bool
    wrap_async = False
    assert isinstance(action_module_1.run(task_vars=None, wrap_async=wrap_async), dict)
    assert isinstance(action_module_1.run(task_vars=None), dict)
    assert isinstance(action_module_1.run(wrap_async=wrap_async), dict)
    assert isinstance(action_module_1.run(), dict)

# Generated at 2022-06-25 07:09:07.149397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:09:11.316605
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert test_case_0()



# Generated at 2022-06-25 07:09:21.614581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = [str_0]
    float_0 = 2553.198262
    dict_0 = {'False': 1, 'True': str_0, 'None': int_0}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    assert_equal(action_module_0._supports_check_mode, True)
    assert_equal(action_module_0._supports_async, True)

# Generated at 2022-06-25 07:09:23.183940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:09:28.339300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = ['rexJ0:\x0cB:QH#=d']
    float_0 = 2553.198262
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)


# Generated at 2022-06-25 07:09:35.558589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = [str_0]
    float_0 = 2553.198262
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 07:09:39.139974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {}
    wrap_async = 1
    str_0 = '0|'
    list_0 = [str_0]
    var_0 = ActionModule(str_0, task_vars, wrap_async, list_0)
    assert isinstance(var_0, ActionModule)


# Generated at 2022-06-25 07:09:43.597045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'X'
    int_0 = -0
    list_0 = ['-8']
    float_0 = -0.76858
    float_1 = -0.894374
    dict_0 = {'name': ['-8'], 'key': 'X', 'value': -832}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_1, dict_0)

# Generated at 2022-06-25 07:09:51.215152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'gS6=D69XC#;V7L\n>4'
    int_0 = -7829
    list_0 = [str_0]
    float_0 = 2687.186698
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:09:52.358053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:10:02.542786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '`a2J~'
    int_0 = -2429
    list_0 = ['=\n#}X+', 'bvh8W5!n', '+RxG*', 'h\x10%']
    float_0 = 3223.457449

    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)

    try:
        var_0 = action_module_0.run()
        print(var_0)
    except Exception as exception_0:
        print(exception_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:10:18.849743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'test string'
    int_0 = 2
    list_0 = [str_0, int_0]
    float_0 = 1.1
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, float_0)
    assert action_module_0._name == str_0
    assert action_module_0._play_context.port == int_0
    assert action_module_0._task.args == list_0
    assert action_module_0._task.delegate_to == float_0
    assert action_module_0._task.delegate_facts == float_0


# Generated at 2022-06-25 07:10:23.829047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup for test_run()
    var_0 = -16944
    var_1 = 3640.02
    var_2 = 'list'
    action_module_0 = ActionModule(var_0, var_1, var_2)


# Generated at 2022-06-25 07:10:31.574205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = [str_0]
    float_0 = 2553.198262
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_run()
    return var_0

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:10:36.888930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Y\x11\x0b\x1f\x1e\r'
    int_0 = -500
    list_0 = [str_0]
    float_0 = 4939.0
    float_1 = -5.94597
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_1, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 07:10:46.781653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '2iB!=tP\x0b/S'
    int_0 = -7461
    list_0 = [str_0]
    float_0 = 4259.25105
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    action_module_0._supports_check_mode = True
    action_module_0._supports_async = True
    tmp_5 = None
    task_vars_5 = None
    result_1 = action_module_0.run(tmp_5, task_vars_5)
    list_1 = []
    list_2 = []
    dict_1 = {}

# Generated at 2022-06-25 07:10:49.054431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'Et*'
    int_1 = -662
    list_1 = [str_1]
    float_1 = -8935.878832
    action_module_1 = ActionModule(str_1, int_1, list_1, float_1, float_1, {})


# Generated at 2022-06-25 07:10:50.474518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:11:00.121097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule('x#D=?\x06RB', -1203, ['\x1b1@\x0dT', 'g%i"]\x04P3'], -1732.83746, -2169.29884, {})
    assert isinstance(var_0, ActionModule) is True
    assert var_0._supports_check_mode == True
    assert var_0._supports_async == True
    assert var_0._connection == 'x#D=?\x06RB'
    assert var_0._play_context == -1203
    assert var_0._task_vars == ['\x1b1@\x0dT', 'g%i"]\x04P3']
    assert var_0._loader == -1732.83746
    assert var_

# Generated at 2022-06-25 07:11:07.182027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = [str_0]
    float_0 = 2553.198262
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_run(tmp=dict_0, task_vars=action_module_0)

test_case_0()

# Generated at 2022-06-25 07:11:14.683442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '=.a'
    int_0 = 76
    list_0 = [str_0]
    float_0 = 6.74
    float_0 = 7.34
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)


# Generated at 2022-06-25 07:11:29.864045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case for constructor code coverage
    # Test case for constructor code coverage
    assert True


# Generated at 2022-06-25 07:11:37.548039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ','
    int_0 = -6590
    list_0 = [str_0]
    float_0 = -5596.593634
    dict_0 = {}
    action_module_1 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    tmp_0 = None
    task_vars_0 = {}
    var_0 = action_module_1.run(tmp_0, task_vars_0)
    return var_0

# Generated at 2022-06-25 07:11:43.767191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = range(26)
    list_0.append('arch')
    list_0.append('b64decode')
    list_0.append('b64encode')
    list_0.append('crln2br')
    list_0.append('dnsresolve')
    list_0.append('extract')
    list_0.append('int')
    list_0.append('mapfile')
    list_0.append('parse_clause')
    list_0.append('parse_kv')
    list_0.append('parse_kv_list')
    list_0.append('parse_url')
    list_0.append('path_split')
    list_0.append('path_unix')
    list_0.append('path_windows')

# Generated at 2022-06-25 07:11:50.987807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'd'
    int_0 = -1209
    list_0 = ['v']
    float_0 = 1058.163815
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    return action_module_0.run()

if __name__ == '__main__':
    print(test_ActionModule())

# Generated at 2022-06-25 07:12:00.321139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'F[:|\x1e\x1f]t\x02\x17\x04\x1e\x1d\x07\x19\x02\x01\x07\x1b\x1e\x1a\x1c\x17\x02\x01\x07\x12\x02\x1e\x1c\x1a\x02\x1e\x1c'
    int_0 = 2473

# Generated at 2022-06-25 07:12:06.361924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'P'
    int_0 = -115
    list_0 = [str_0]
    float_0 = 578.83668
    dict_0 = {'list_0': list_0, 'float_0': float_0, 'int_0': int_0}
    action_module_0 = ActionModule(str_0, 'S', [], dict_0, dict_0, dict_0)
    dict_1 = action_module_0.run()
    assert('changed' == dict_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:12:13.303047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        print(ActionModule.run(ActionModule, tmp='V7', task_vars=None))
    except Exception:
        print('ERROR: Exception')
    else:
        print('SUCCESSFUL: run')

test_ActionModule_run()

# Generated at 2022-06-25 07:12:17.576041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = var_0.run()

# Generated at 2022-06-25 07:12:19.235703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-25 07:12:24.782756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        str_0 = 'rexJ0:\x0cB:QH#=d'
        int_0 = -2384
        list_0 = [str_0]
        float_0 = 2553.198262
        dict_0 = {}
        # No exception is thrown, so test passes
        action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    except Exception:
        # Exception is thrown, so test fails
        raise AssertionError()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:12:58.085044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = [str_0]
    float_0 = 2553.198262
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    assert isinstance(action_module_0, ActionModule)
    action_run(action_module_0)


# Generated at 2022-06-25 07:13:05.429244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('>start test_ActionModule_run')
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = [str_0]
    float_0 = 2553.198262
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_run()
    print('>finish test_ActionModule_run')

# Generated at 2022-06-25 07:13:16.479486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -7402
    int_1 = 1680
    list_0 = [1259]
    float_0 = 9395.104267
    dict_0 = {}
    action_module_0 = ActionModule('', int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_module_0.run(int_0, int_1)
    print(var_0)

try:
    import ansible.utils.plugin_docs as plugin_docs

    documentation = plugin_docs.get_docstring(ActionModule, verbose=False,
                                              subtags=['options', 'examples', 'return'])
    # print(documentation)
except Exception:
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:13:20.202843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -238
    list_0 = []
    float_0 = 255.19826
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    assert type(action_module_0) == ActionModule

# Generated at 2022-06-25 07:13:24.195608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    result = action_module_0.run(tmp, task_vars)
    assert result == 'module'

# Generated at 2022-06-25 07:13:31.478076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '^$\x7f\xe4\x85\x9c\x96\xb6\xdc\x1cI\x8f\x94\xd5\x1d\xa9\x8d\x0f\xda\xf7D'
    int_0 = -1

# Generated at 2022-06-25 07:13:38.548974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'p\x0c\x12\x1d\x1c'
    int_0 = 1784
    list_0 = [str_0]
    float_0 = 4235.376735
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:13:46.196665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'bJ0:\x0cB:QH#=d'
    int_1 = -2384
    list_1 = [str_1]
    float_1 = 2553.198262
    dict_1 = {}
    action_module_1 = ActionModule(str_1, int_1, list_1, float_1, float_1, dict_1)
    tmp_1 = None
    task_vars_1 = None
    var_1 = action_module_1.run(tmp_1, task_vars_1)
    assert var_1 == None, 'value of returned object is not equal to None'

    int_2 = -2384
    list_2 = [str_1]
    str_2 = 'rexJ0:\x0cB:QH#=d'


# Generated at 2022-06-25 07:13:49.418536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None # If False
    return var_0

# Generated at 2022-06-25 07:14:00.129883
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:15:04.900172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = [str_0]
    float_0 = 2553.198262
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_module_0.run()
    print(var_0)

# Command line arguments
if __name__ == "__main__":

    # If a command line argument is provided, it will be treated as a test case identifier
    # and run only that test case. Otherwise, all test cases are executed.
    import sys
    args = sys.argv


# Generated at 2022-06-25 07:15:15.215180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'w\x8a*m\xa1'
    int_0 = -3980
    list_0 = []
    float_0 = -0.004914
    float_1 = 143.64
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_1, dict_0)
    assert action_module_0.task_vars == list_0

# Generated at 2022-06-25 07:15:19.400805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tw3/7,Ib=\x0b'
    int_0 = -1325
    list_0 = [str_0]
    float_0 = 2942.14
    float_1 = 0.03913
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_1, dict_0)


# Generated at 2022-06-25 07:15:23.018986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'rexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = [str_0]
    float_0 = 2553.198262
    float_1 = float_0
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_1, dict_0)


# Generated at 2022-06-25 07:15:28.790465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Sz=+X_FGF/:~0?'
    int_0 = -1299
    list_0 = [str_0]
    float_0 = 886.89
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_module_0.run()
    assert var_0 == None


# Generated at 2022-06-25 07:15:34.989587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'y/\x0cB:QH#=d'
    int_0 = 3840
    list_0 = [str_0]
    float_0 = 673.920815
    var_0 = 2553.198262
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, var_0, dict_0)

# Generated at 2022-06-25 07:15:40.693826
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test method run() of class ActionModule

    # Mock tmp
    tmp_mock = Mock()
    tmp_mock.__setattr__('ansible_tmp', 'tmp')

    # Mock task_vars
    task_vars_mock = Mock()

    # Test ActionModule class instantiation
    action_module_0 = ActionModule()

    # Test run method of ActionModule class
    # Test exception raise of run()
    with pytest.raises(ValueError) as excinfo:
        action_module_0.run(tmp=tmp_mock, task_vars=task_vars_mock)
    # Test that exception message is as expected
    assert str(excinfo.value) == 'Missing required arguments: data'

# Generated at 2022-06-25 07:15:43.248593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'RexJ0:\x0cB:QH#=d'
    int_0 = -2384
    list_0 = [str_0]
    float_0 = 2553.198262
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    return action_module_0


# Generated at 2022-06-25 07:15:44.667725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:15:53.366755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\xd6\x15\xf1\xd3\x0b\x07\xe9\x94\xe8\xad\xf2\x17\xbc\x08\x89\x05\x16%\xab\x11\x91'
    int_0 = -10367
    list_0 = [str_0]
    float_0 = 6091.286642
    dict_0 = {}
    action_module_0 = ActionModule(str_0, int_0, list_0, float_0, float_0, dict_0)
    var_0 = action_run()