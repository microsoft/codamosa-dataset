

# Generated at 2022-06-25 07:08:00.889338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = 0.2
    bytes_0 = b'\xd7\xcf\x96\xae'
    set_0 = {float_0, float_0}
    action_module_0 = ActionModule(dict_0, float_0, dict_0, bytes_0, dict_0, set_0)
    str_0 = 'test_ActionModule_attrib0'
    str_1 = 'test_ActionModule_attrib1'
    action_module_0._connection = str_0
    action_module_0._task = str_1

    dict_0 = {}
    float_0 = 0.2
    bytes_0 = b'\xd7\xcf\x96\xae'
    set_0 = {float_0, float_0}
    bool

# Generated at 2022-06-25 07:08:03.500856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ACTION_NAME = 'ActionModule.run'
    # 1, 2, 3
    ACTION_NAME = ACTION_NAME



# Generated at 2022-06-25 07:08:07.772901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = 0.2
    bytes_0 = b'\xd7\xcf\x96\xae'
    set_0 = {float_0, float_0}
    action_module_0 = ActionModule(dict_0, float_0, dict_0, bytes_0, dict_0, set_0)

# unit tests ends here


# Generated at 2022-06-25 07:08:11.767101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = 0.2
    bytes_0 = b'\xc7\xab\x84\xec'
    set_0 = {float_0, float_0}
    action_module_0 = ActionModule(dict_0, float_0, dict_0, bytes_0, dict_0, set_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:08:17.360672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = 0.2
    bytes_0 = b'\xd7\xcf\x96\xae'
    set_0 = {float_0, float_0}
    action_module_0 = ActionModule(dict_0, float_0, dict_0, bytes_0, dict_0, set_0)
    action_module_0.run()


# Generated at 2022-06-25 07:08:25.462521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = 0.07175426622887869
    bytes_0 = b'\x10\xf5\x99\xe5'
    set_0 = {float_0}
    action_module_0 = ActionModule(dict_0, float_0, dict_0, bytes_0, dict_0, set_0)

    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_3['invocation'] = dict_2
    dict_4 = {}
    dict_4['skipped'] = dict_3['invocation']
    dict_3['skipped'] = dict_4['skipped']
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}

# Generated at 2022-06-25 07:08:33.965185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = 0.03
    action_module_0 = ActionModule(dict_0, float_0, dict_0, bytes(), dict_0, set())
    float_0 = 1.456
    tmp = float_0
    task_vars = None
    # AssertionError: ({'invocation': {'module_name': 'debug', 'module_args': {}, 'module_lang': 'en_US.UTF-8', 'module_set_locale': True}, 'item': '', '_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_verbose_override': True, '_ansible_item_label': '', '_ansible_parsed': True, 'changed': False, 'invocation': {'module_

# Generated at 2022-06-25 07:08:35.634490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:44.487063
# Unit test for constructor of class ActionModule
def test_ActionModule():

    dict_0 = {}
    dict_1 = {}
    float_0 = 0.2
    bytes_0 = b'\xd7\xcf\x96\xae'
    set_0 = {float_0, float_0}
    action_module_0 = ActionModule(dict_0, float_0, dict_1, bytes_0, dict_0, set_0)

    assert action_module_0._task == dict_0
    assert action_module_0._connection == float_0
    assert action_module_0._play_context == dict_1
    assert action_module_0._loader == bytes_0
    assert action_module_0._templar == dict_0
    assert action_module_0._shared_loader_obj == set_0


# Generated at 2022-06-25 07:08:46.281069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test cases for variable action_module_0
    test_case_0()

if __name__ == '__main__':
    # unit tests for ActionModule
    test_ActionModule()
    sys.exit()

# Generated at 2022-06-25 07:08:51.828808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'test_ActionModule'
    var_1 = var_0 = str_0


# Generated at 2022-06-25 07:08:55.588832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_test_name = 'test_ActionModule_run'
    print('Test case: {}'.format(str_test_name))

    # Create target object
    ActionModule = ActionBase()

    # Call run of class ActionModule
    print('Call run of class ActionModule')
    ActionModule.run()


# Generated at 2022-06-25 07:08:56.792823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:09:04.239164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with results
    import sys, json
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    module_name = 'test_module'
    module_path = '../ansible/modules/system/ping.ps1'

    task1 = {
        'action': {
            '__ansible_module__': module_name,
            '__ansible_arguments__': ImmutableDict({"data":"test_json"}),
            '__ansible_action_args__': ImmutableDict({"module_path":module_path, "module_name":module_name}),
            '__ansible_fact_cache__': {}}
    }
    

# Generated at 2022-06-25 07:09:08.240899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ActionModule.run'
    run_0 = ActionModule.run(self, tmp=None, task_vars=None)
    return str_0

# Test method run of class ActionModule

# Generated at 2022-06-25 07:09:09.599353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME not yet implemented
    pass



# Generated at 2022-06-25 07:09:12.148090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test_case_0'
    str_1 = ActionModule.run(str_0)
    str_2 = 'test_case_0'
    assert (str_1 == str_2)

# Generated at 2022-06-25 07:09:13.718304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ActionModule.run'
    var_0 = str_0


# Generated at 2022-06-25 07:09:19.197993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = ActionModule()
    actionModule_instance_0 = ActionModule.run(var_2,var_0,var_1)
    assert str(actionModule_instance_0) == '<ansible.plugins.action.ActionModule object at 0x7f7875f841d0>'

# Generated at 2022-06-25 07:09:20.912223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == 'ActionModule.run'



# Generated at 2022-06-25 07:09:32.224186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Assert that the constructor is called correctly
    str_0 = 'h\xcc\x0d\xe4\x8c'
    list_0 = [str_0, str_0]
    bool_0 = True
    bytes_0 = b'\xbe\xfd\x9a\xdf\xdf\xd1\xda\xdf'
    float_0 = -0.0922
    set_0 = set()
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)

    # Assert that the fields are stored correctly
    assert action_module_0._supports_check_mode == False
    assert action_module_0._supports_as

# Generated at 2022-06-25 07:09:36.706852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor of class ActionModule')


# Generated at 2022-06-25 07:09:43.277709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'h\x1f2\x8b\x1d\x80'
    list_0 = [str_0, '1{$\x87\x81', str_0]
    bool_0 = True
    bytes_0 = b'S\xac\x15\x99\x0e\xc4\x15'
    float_0 = -1956.955
    set_0 = set()
    tuple_0 = (float_0, set_0)
    arg_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    var_0 = run(arg_0)


# Generated at 2022-06-25 07:09:52.455933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '_!m[j#'
    list_1 = [str_1, str_1]
    bool_1 = False
    bytes_1 = b'ZzwL\xf6\xf8\xda\x1d\x9a\xa3}B\x10'
    float_1 = -8432.5499
    set_1 = set()
    tuple_1 = (float_1, set_1)
    test_case_1 = ActionModule(str_1, list_1, bool_1, bytes_1, tuple_1, float_1)
    assert isinstance(test_case_1, ActionModule)


# Generated at 2022-06-25 07:09:56.897873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 12
    action_module_0 = ActionModule(int_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:10:07.869800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    string_0 = '%c'
    list_0 = [int(), int()]
    bool_0 = True
    bytes_0 = b'\xec\x07\xac\xc4\xed\xfb\xfe\xb2^\x89\x84\xcc\xf1\xbd\x9c\xc5\x1dY'
    tuple_0 = (42, 12.1)
    float_0 = -0.03623971926
    action_module_0 = ActionModule(string_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    assert action_module_0._connection.address == '%c'
    assert action_module_0._ds is not None
    assert action_module_0.task_vars == {}

# Generated at 2022-06-25 07:10:14.538100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'-5\\}[A\xed\xc5a\xc9'
    float_0 = 8.25
    set_0 = set()
    tuple_0 = (bytes_0, float_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:10:15.944276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Nothing should be returned if the module is executed successfully
    assert test_case_0() == None

# Generated at 2022-06-25 07:10:23.939414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Qi'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'qVHq[\xc8\xaf^'
    float_0 = -3740.01949
    set_0 = set()
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    str_1 = 'a'
    str_2 = 'i'
    str_3 = 'N'
    str_4 = ']'
    bytes_1 = b'9'

# Generated at 2022-06-25 07:10:31.614569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'iK'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'|l\x8c'
    float_0 = -5792.0875
    set_0 = set()
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    var_0 = action_run()


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:10:44.260073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input Parameters
    str_0 = 'R=a'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'qAs*\x7f\xce#]'
    tuple_0 = (float_0, set_0)
    float_0 = -3740.01949
    set_0 = set()
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    try:
        set_0 = set()
        result = action_module_0.run(tmp = set_0)
    except Exception as e:
        print('Caught exception: ' + str(e))

    assert result is not None

# Generated at 2022-06-25 07:10:46.535393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__module__ == 'ansible.plugins.action'
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.__qualname__ == 'ActionModule'

# Generated at 2022-06-25 07:10:53.827030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {
        "foo": 'bar'
    }
    # AssertionError: False is not true : Expected
    # assert_equal(self._execute_module(task_vars=task_vars), result)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:11:01.290230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'zk'
    list_0 = ['V', '6', 'Y', 'E', 'J', '6', 'U', '`', 'P', 'P']
    bool_0 = True
    bytes_0 = b'xH\x1f\n\xc3q'
    tuple_0 = (str_0, str_0)
    float_0 = -7761.93799
    action_module_1 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    var_0 = action_module_1.run(bool_0, list_0)
    assert_equals(var_0, None)

# Generated at 2022-06-25 07:11:12.886389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case with kwargs keyword missing
    str_0 = 'PW'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'W'
    float_0 = 0.664825705948275
    set_0 = set()
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    var_0 = action_module_0.run()
    # test case with kwargs being valid
    str_0 = '^'
    list_0 = [str_0, str_0]
    bool_0 = True

# Generated at 2022-06-25 07:11:18.993593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test ActionModule.run')
    str_0 = 'ast'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'[b\x8c\x8b\x0c\xc7\x85\x04\x9f\xe2'
    float_0 = -6137.04218
    set_0 = set()
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    test_case_0()

# Generated at 2022-06-25 07:11:30.327784
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:11:37.611156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'qw'
    list_1 = []
    bool_1 = False
    bytes_1 = b'|\xdf\x99\x83\xdd\x8c\xf9'
    float_1 = 11.940017
    tuple_1 = (float_1, float_1)
    set_1 = set()
    action_module_1 = ActionModule(str_1, list_1, bool_1, bytes_1, tuple_1, set_1)


# Generated at 2022-06-25 07:11:38.080801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-25 07:11:48.315071
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:12:05.163554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'D@'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'\xc0\x9e\x86\xddr\xbc\x05'
    float_0 = 4348.61106
    set_0 = set()
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    pk_0 = pk()
    var_0 = action_run(action_module_0, tmp=None, task_vars=pk_0)
    assert(var_0 == action_run())

# Generated at 2022-06-25 07:12:10.620268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [str_0, str_0]
    float_0 = -3740.01949
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    str_1 = '\x83j]\x93\xb3\xb0\x9c\xf6\x0b\x1f\xbf\xae'
    action_module_0.run(task_vars=str_1)

# Generated at 2022-06-25 07:12:12.508334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-25 07:12:19.844914
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:12:28.595706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '):'
    list_0 = [str_0, str_0]
    bool_0 = True
    bytes_0 = b'D(!1\x97W\x8e\xe3\x88'
    float_0 = 7137.595
    set_0 = {float_0, float_0}
    tuple_0 = (float_0, float_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    action_module_0.run()
    str_0 = 'xfy'
    list_0 = [str_0, str_0]
    bool_0 = False

# Generated at 2022-06-25 07:12:36.975757
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:12:42.532453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'new_module'
    list_0 = [str_0, str_0]
    bool_0 = True
    bytes_0 = b'\xbd\xf0\xed\x90\x81w\xd2\x82\x9d\x82\x98\x14\x96\xc6\x92\x82\x93\x94'
    tuple_0 = (5.5, bool_0)
    float_0 = -5.5
    if (ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0) is None):
        raise RuntimeError('Cannot find function ActionModule.')

# Generated at 2022-06-25 07:12:47.951983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'cC'
    list_0 = [str_0, str_0]
    bool_0 = True
    bytes_0 = b'\x19'
    float_0 = 0.378322806566189
    set_0 = set()
    tuple_0 = (bytes_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)

# Generated at 2022-06-25 07:12:58.109517
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # arguments for test
    str_0 = 'Qi'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'qVHq[\xc8\xaf^'
    float_0 = -3740.01949
    set_0 = set()
    tuple_0 = (float_0, set_0)

    # instance for test
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)

    # assertions
    assert action_module_0._shared_loader_obj is set_0
    assert action_module_0._task_vars is list_0
    assert action_module_0._task is tuple_0
    assert action_module_0._connection is float

# Generated at 2022-06-25 07:13:07.752242
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module = ActionModule()
  assert action_module._task
  assert action_module._connection
  assert action_module._play_context
  assert action_module._loader
  assert action_module._tempalte_uid
  assert action_module._tempalte_user
  assert action_module._remote_user
  assert action_module._connection_user
  assert action_module._shell
  assert action_module._module_compression
  assert action_module._pipelining
  assert action_module._supports_async
  assert action_module._supports_check_mode
  assert action_module._supports_no_log
  assert action_module._no_log
  assert action_module._module_name
  assert action_module._task_vars
  assert action_module._templar
  assert action_

# Generated at 2022-06-25 07:13:48.234316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'v'
    list_0 = ['Xj', str_0]
    bool_0 = True
    bytes_0 = b'\x1f\x16\x9a\x06\x93\x04\xc0\xbc\x89\xf5\xda\x90\xe9\x1b\xed\xc1\xc3\x1c\xa8\xcc\xe0\xbf\xcc\x8d\xa1\xfb\x87\x0e\x8c\x05'
    float_0 = -1180.1064
    set_0 = {str_0, str_0}
    tuple_0 = (set_0, float_0, float_0)

# Generated at 2022-06-25 07:13:53.359014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'V'
    list_0 = [str_0, str_0, str_0]
    bool_0 = True
    bytes_0 = b'\xab\xa58'
    float_0 = -15561.56082
    set_0 = set()
    tuple_0 = (list_0, tuple_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    action_module_0.run(tmp=None, task_vars=set_0)

if __name__ == '__main__':
    #test_case_0()
    #test_ActionModule_run()
    # test_action_base_run()
    pass

# Generated at 2022-06-25 07:14:01.696545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(action_module_0._task != None)
    assert(action_module_0._shared_loader_obj != None)
    assert(action_module_0._connection != None)
    assert(action_module_0._play_context != None)
    assert(action_module_0._loader != None)
    assert(action_module_0._templar != None)
    assert(action_module_0._task_vars != None)
    assert(action_module_0._task_vars_modified != None)
    assert(action_module_0._notified_handlers != None)
    assert(action_module_0._addons_paths != None)
    assert(action_module_0._fact_cache != None)

# Generated at 2022-06-25 07:14:07.544615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'fX\xbeA\x84\xbe'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'\x7f\x83\x03\x8a'
    float_0 = -1.94636
    set_0 = set()
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    test_case_0()


# Generated at 2022-06-25 07:14:16.063533
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:14:18.834376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_2 = action_run()
    return var_2


# Generated at 2022-06-25 07:14:27.851035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'E6n'
    list_0 = [str_0, str_0]
    bool_0 = True

# Generated at 2022-06-25 07:14:37.103904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # If a constructor of a class is called and there is no explicit return statement in its body, an object of the class is implicitly returned.
    str_0 = 't'
    list_0 = [str_0, str_0]
    bool_0 = True
    bytes_0 = b'\x1a\xc1\xbb'
    float_0 = -3.49839
    set_0 = set()
    tuple_0 = (float_0, set_0, str_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:14:44.962350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '@6\xa9{\x8e\xcb\x1c\xb4g'
    list_0 = ['dk3q$4', 'X\x8b+h\x1a\xad\x11\x1a\x81\xb7\x88']
    bool_0 = False
    bytes_0 = b'\xe6\x87\x10\xc4\x82\x9d\x8a\xbd\x13,\xdc\xef\x0b\xc5\x1c\x9b\x8e2C\xd2\xeb'
    float_0 = 8965.805049
    set_0 = set()

# Generated at 2022-06-25 07:14:52.113554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ')'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'\x07'
    float_0 = -2386.27
    set_0 = set()
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    str_1 = 'M'
    float_1 = -9609.4
    action_module_1 = ActionModule(str_1, float_1)
    str_2 = '\x02\x00'
    float_2 = -507.0
    tuple_1 = (str_2, float_2)

# Generated at 2022-06-25 07:15:59.964646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ']b'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'[0\x13\x1f\r\xff\xa6\xcf'
    float_0 = -9362.903115
    set_0 = set()
    tuple_0 = (float_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    var_0 = action_run()
    assert var_0 is not False
    action_module_0._task.async_val = True
    var_0 = action_run()
    assert var_0 is False


# Generated at 2022-06-25 07:16:08.379695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '8u'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'\x1e\xbb\x81\x80\xaa\xbc'
    float_0 = -4040.878345
    set_0 = set()
    tuple_0 = (bytes_0, float_0, float_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:16:16.788822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Cv'
    list_0 = [str_0, str_0]
    bool_0 = False
    bytes_0 = b'l\x17\xb7\x9a\x8f\x19\x1d'
    float_0 = -0.00470
    set_0 = set()
    tuple_0 = (bytes_0, set_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:16:24.569598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'gY]@'
    list_0 = [str_0, str_0]
    bool_0 = True
    bytes_0 = b'\xdd\xacn\xf5\x8d\x92K9\xbb'
    float_0 = -3024.208984
    set_0 = set()
    tuple_0 = (bytes_0, float_0)
    ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)


# Generated at 2022-06-25 07:16:27.482595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:16:33.136206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Oa'
    tuple_0 = (str_0, str_0)
    float_0 = -8488.3975
    set_0 = set()
    bytes_0 = b'M\xfa\x9e\xa6\xeb\x19\xbe$\x81\x8f\x90'
    list_0 = [tuple_0, set_0, tuple_0, bytes_0, str_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:16:37.894261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '5e'
    list_0 = [str_0, str_0]
    bool_0 = True
    bytes_0 = b'\xe3\x0e<t\x9a\x14\x95\xac'
    float_0 = -4343.010789
    set_0 = set()
    tuple_0 = (set_0, set_0)
    result = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0).run()
    assert result == None


# Generated at 2022-06-25 07:16:38.894054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO
    raise NotImplementedError()


# Generated at 2022-06-25 07:16:43.698800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: Implement test
    raise NotImplementedError


if __name__ == '__main__':
    import sys
    import os
    import unittest
    unittest.main()

# Generated at 2022-06-25 07:16:54.336458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'q_f\xdf\xc8\xebn\xf6\xb6\xc5\x17\x90'
    list_0 = []
    bool_0 = True
    bytes_0 = b'g\xbd\xd2\x83\x8d\x0c\xab\x9e\x03'
    float_0 = -0.2401097
    set_0 = set()
    tuple_0 = ('\x92\xb4\x7f\x19\xb2\x1fQ\x82\xd6'.encode('utf-8'), float_0)
    action_module_0 = ActionModule(str_0, list_0, bool_0, bytes_0, tuple_0, float_0)
    var_0 = action_run()
