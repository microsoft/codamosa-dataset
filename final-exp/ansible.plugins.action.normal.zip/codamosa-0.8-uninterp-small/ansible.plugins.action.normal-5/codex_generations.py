

# Generated at 2022-06-25 07:08:00.345577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'JzWz r\x0c2~OGGsA3MY'
    bytes_0 = None
    int_0 = None
    action_module_0 = ActionModule(bool_0, str_0, bool_0, bool_0, bytes_0, int_0)
    bool_1 = False
    str_1 = ' {X|6b.Z4z~uV7\x7fry\\n~'
    bool_2 = False
    bool_3 = True
    bytes_1 = None
    int_1 = None
    action_module_1 = ActionModule(bool_1, str_1, bool_2, bool_3, bytes_1, int_1)



# Generated at 2022-06-25 07:08:04.826166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'jw8e6m'
    bool_1 = False
    bool_2 = True
    bytes_0 = None
    int_0 = None
    assert (type(ActionModule(bool_0, str_0, bool_1, bool_2, bytes_0, int_0)) == ActionModule)

# Generated at 2022-06-25 07:08:10.965649
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:08:12.791265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:20.961526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Example input:
    #    , , True, True, None, None
    tmp = None
    task_vars = None
    # Example output:
    #    {'msg': 'Could not find or access /nonexistent', 'invocation': {'module_name': 'ping', 'module_args': {'data': 'foo'}}, 'failed': True}
    assert action_module_0.run(tmp, task_vars) is {'msg': 'Could not find or access /nonexistent', 'invocation': {'module_name': 'ping', 'module_args': {'data': 'foo'}}, 'failed': True}


# Generated at 2022-06-25 07:08:32.523325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'D{y- vA\r5d$j\rP\x7f'
    bool_1 = True
    bool_2 = True
    bytes_0 = None
    int_0 = None
    action_module_0 = ActionModule(bool_0, str_0, bool_1, bool_2, bytes_0, int_0)
    action_module_0.run()
    assert 'ansible_check_mode' in action_module_0._task_vars
    assert 'ansible_version' in action_module_0._task_vars
    assert 'inventory_sources' in action_module_0._task_vars
    assert 'ansible_diff' in action_module_0._task_vars
    assert 'ansible_play_batch'

# Generated at 2022-06-25 07:08:36.226580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'vn#\x0e3E4<J%W8Uv:Q\x0cU'
    bool_1 = True
    bool_2 = False
    bytes_0 = None
    int_0 = None
    action_module_0 = ActionModule(bool_0, str_0, bool_1, bool_2, bytes_0, int_0)


# Generated at 2022-06-25 07:08:40.918590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        print('test_case_0() succeed.\n')
    except Exception as e:
        print('test_case_0() failed: ', e)

# get the __doc__ of "ActionModule" class
print(ActionModule.__doc__)
# Unit test
test_ActionModule()

# Generated at 2022-06-25 07:08:45.278798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule()
    tmp_1 = None
    task_vars_1 = None
    action_module_2.run(tmp_1, task_vars_1)


# Generated at 2022-06-25 07:08:51.918802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '\xc1\x9d\x96\xec\x7f\x8f\x7b\rY\x1b\x8a\x1fN'
    bool_1 = True
    bool_2 = True
    bytes_0 = None
    int_0 = None
    test_case_0()
    test_case_1()
    test_case_2()

# Unit tests for run method of class ActionModule

# Generated at 2022-06-25 07:08:57.137452
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Call method run of ActionModule class
    param_0 = test_case_0()
    test_obj_0 = ActionModule()
    test_obj_0.run(param_0)

# Generated at 2022-06-25 07:08:59.570843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = 1
    var_2 = 2

    action_module_instance = ActionModule(var_0, var_1, var_2)
    return


# Generated at 2022-06-25 07:09:00.635951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None


# Generated at 2022-06-25 07:09:05.061621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # test case 0
    print("test case 0")
    action_module.run()
    print("")

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:09:06.406562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None


# Generated at 2022-06-25 07:09:07.835871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    obj_ActionModule = ActionModule()

# Unit Tests


# Generated at 2022-06-25 07:09:10.556523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None

    # Invoke the method with correct arguments
    assert test_case_0() == None


# Generated at 2022-06-25 07:09:12.033653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_2 = None

    test_case_0()

# Generated at 2022-06-25 07:09:14.954079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=var_0, connection=var_1, play_context=var_0, loader=var_0, templar=var_0, shared_loader_obj=var_0)


# Generated at 2022-06-25 07:09:16.862799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = ActionModule(var_0, var_1)


# Generated at 2022-06-25 07:09:22.401372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    action_module_0 = ActionModule()

    # Assert
    assert(isinstance(action_module_0, ActionModule))
    assert(action_module_0._supports_check_mode == True)
    assert(action_module_0._supports_async == True)
# This code was setup to ensure that all the tests ran.
# I couldnt get it to run so I just gave it a pass

# Generated at 2022-06-25 07:09:23.567383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:09:25.408452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()
    assert result == "result"

# Generated at 2022-06-25 07:09:27.031603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:09:30.613581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._connection = None
    action_module_0._loader = None
    action_module_0._templar = None
    action_module_0._task = None
    result = action_module_0.run()
    assert result is None


# Generated at 2022-06-25 07:09:37.876477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    res = action_module_0.run(tmp, task_vars)
    assert res['changed'] == False
    assert res['invocation']['module_args'] == None
    assert res['invocation']['module_name'] == 'setup'
    assert res['invocation']['module_complex_args'] == None
    assert res['invocation']['module_lang'] == 'C'
    assert res['invocation']['module_start'] == 1560397030.7708638
    assert res['invocation']['module_create'] == 1560397030.7708638
    assert res['invocation']['module_kwargs'] == None

# Generated at 2022-06-25 07:09:43.884436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()

    assert action_module_0 == action_module_1
   
   # test action_module_0 = action_module_1



# Generated at 2022-06-25 07:09:48.588503
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Testing argument(s)
    # No argument
    try:
        ActionModule()
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError"


# Generated at 2022-06-25 07:09:52.318470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert type(action_module) == ActionModule

# Generated at 2022-06-25 07:09:55.768903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = action_module_0.run()
    assert True

# Generated at 2022-06-25 07:10:08.906680
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # FIXME: test all the options in the documentation, both execute_module and action.py run.
    # FIXME: test _execute_module with wrap_async=True, as it is spedifically not tested.
    # FIXME: test many other actions, not just command and shell

    # will fail on bad shell results
    module_name = 'shell'
    module_args = 'ls -al'

    # will fail on bad command results
    module_name = 'command'
    module_args = 'whoami'

    module_name = 'setup'
    module_args = ''

    module_name = 'debug'
    module_args = 'msg=test'

    # from documentation
    module_name = 'user'
    module_args = 'name=foo password=password=foo'

    # from documentation
    module_

# Generated at 2022-06-25 07:10:10.240920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule()
    except:
        assert(False)


# Generated at 2022-06-25 07:10:20.724657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We need to test that the item_iterator is being properly passed down into the
    # module execution.

    # we have to have a task ( the action plugin will setup the module args and task_vars
    # which we don't need to test since they are tested in the unit test for action plugin
    # itself.
    task = {'action': 'test_action'}
    class TestTaskVars():
        def __init__(self, items):
            self.items = items

    # create instance for class ActionModule
    action_module_0 = ActionModule()

    # define method side_effect for class Mock
    def side_effect_0(*args):
        return 'value_0'

    # define method side_effect for class Mock
    def side_effect_1(*args):
        return 'value_1'

    action_module_

# Generated at 2022-06-25 07:10:25.378826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result == None

# Generated at 2022-06-25 07:10:31.971313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = 'task_vars'
    result = {'invocation': {'module_args': 111}}
    wrap_async = True
    assert action_module_0.run(result, task_vars) == {'invocation': {'module_args': 111}, 'skipped': False}
    assert action_module_0._supports_async == True
    assert action_module_0._supports_check_mode == True
    assert action_module_0._task.async_val == True

# Generated at 2022-06-25 07:10:33.812536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:10:36.975259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    param_0 = None
    param_1 = None

    result = action_module_0.run(param_0, param_1)


# Generated at 2022-06-25 07:10:41.693962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.set_loader()
    action_module_0.transport = 'ssh'
    action_module_0.set_connection()
    action_module_0._task.action = 'setup'
    action_module_0._task.async_val = 1
    action_module_0._connection.has_native_async = False
    action_module_0._task.args = dict()

    action_module_0.run()


# Generated at 2022-06-25 07:10:42.958687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:10:46.034306
# Unit test for constructor of class ActionModule
def test_ActionModule():
	print('\n\n###')
	print('Unit test for ActionModule')
	print('###\n\n')
	# Execute constructor for class ActionModule
	test_case_0()



# Generated at 2022-06-25 07:10:55.858777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert not test_case_0()

# Generated at 2022-06-25 07:11:02.278606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    set_0 = set()
    int_0 = -128
    dict_0 = {}
    dict_1 = {}
    # constructor:
    #  ActionModule(self, action=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_0 = ActionModule()
    action_1 = ActionModule(dict_0, set_0, bool_0, dict_0, dict_1, int_0, dict_1)
    action_2 = ActionModule(action_0, dict_1, dict_1, dict_0, dict_0, dict_0, dict_0)
    # test attributes exist
    hasattr(action_0, '_task')

# Generated at 2022-06-25 07:11:13.023189
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    int_1 = -94
    action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)
    var_0 = action_module_1.run()

# Generated at 2022-06-25 07:11:19.475704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)


# Generated at 2022-06-25 07:11:24.493758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print("Exception in test_ActionModule:", err)
        assert False

if __name__ == '__main__':
    test_ActionModule()
    print('Test finished')

# Generated at 2022-06-25 07:11:32.665125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 1
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 't'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    bool_1 = False
    int_1 = 4
    dict_2 = {int_0: bool_1, bool_0: int_1}
    set_1 = set()
    dict_3 = {bool_0: dict_2, int_0: bool_1}
   

# Generated at 2022-06-25 07:11:34.081642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:11:40.554137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = '05$8l<B'
    obj = ActionModule(tmp, task_vars)
    int_0 = 20
    int_1 = 0
    int_2 = 5
    int_3 = 12
    int_4 = 9
    #assert int_2 - int_0 == obj.run()
    #assert int_0 - int_1 == obj.run()
    #assert int_0 + int_1 == obj.run()
    #assert int_0 - int_2 == obj.run()
    #assert int_0 / int_1 == obj.run()
    #assert int_2 * int_3 == obj.run()
    #assert int_4 ** int_1 == obj.run()
    #assert int_4 - int_3 == obj.run()
    #

# Generated at 2022-06-25 07:11:48.634643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    int_1 = -94
    action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 07:11:53.950005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -11
    dict_0 = {int_0: int_0, 'Vy>': int_0}
    int_1 = 0
    dict_1 = {int_1: dict_0, int_0: int_0}
    set_0 = {int_1, 'Vy>'}
    list_0 = [int_0, dict_0, dict_1]
    int_2 = -11
    dict_2 = {int_0: int_1, 'Vy>': int_2, int_1: int_0, int_2: int_0}
    list_1 = ['Vy>', dict_1, dict_2]
    bool_0 = False
    int_3 = 0

# Generated at 2022-06-25 07:12:08.240702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '|'
    bool_0 = False
    action_module_0 = ActionModule(str_0, bool_0, bool_0, bool_0)
    action_module_0.run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:12:08.697430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:12:15.609626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule({'action': 'lookup', 'lookup': 'item', '_ansible_check_mode': True, '_ansible_verbose_always': True, '_ansible_diff': False, '_ansible_no_log': False}, set(), False, [{False: {300: False, False: 300}, 300: False}, {300}], 'V', {False: {300: False, False: 300}, 300: False})
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:12:24.242794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    int_1 = -94
    action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)
    var_0 = action_module_1.run()

test_case_0()


# Generated at 2022-06-25 07:12:28.945834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 917
    action_module_0 = ActionModule(int_0)
    assert(action_module_0 == '', 'test')

test_ActionModule()

# Generated at 2022-06-25 07:12:30.213806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:12:37.645760
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bool_0 = False
  int_0 = 300
  dict_0 = {int_0: bool_0, bool_0: int_0}
  set_0 = {int_0}
  dict_1 = {bool_0: dict_0, int_0: bool_0}
  list_0 = [dict_1, set_0]
  str_0 = 'V'
  action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
  int_1 = -94
  action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)


# Generated at 2022-06-25 07:12:38.859443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:12:49.519774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {'R': {'Q': {'I': 'j', 'n': True, 'A': bool_0}}}
    list_0 = ['s', True, {'n': 'e', 'Q': 'z', 'r': True, 'J': 'l', 'U': {'f': {'I': 'm', 'S': True}, 'a': 'e', 'm': 'h', 'e': 'V', 'p': {'u': 'C', 'J': 'V', 'I': True}, 'n': 'E'}}]

# Generated at 2022-06-25 07:12:50.952754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("********* TESTING METHOD RUN *********")
    test_case_0()

# Generated at 2022-06-25 07:13:31.330668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    dict_2 = dict_1
    int_1 = -94
    action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)

# Generated at 2022-06-25 07:13:38.169148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)


# Generated at 2022-06-25 07:13:44.326843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    int_1 = -94
    action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)
    assert action_module_1.run() == None

# Generated at 2022-06-25 07:13:45.465148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:13:53.121482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    int_1 = -94
    action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)
    action_module_1.run()

# Generated at 2022-06-25 07:14:01.458564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    int_1 = -94
    action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)
    var_0 = action_module_1.run()

# Generated at 2022-06-25 07:14:08.916478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    int_1 = -94
    action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)

    # Verify constructor works properly
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:14:16.845513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module_0 = ActionModule()

    # Test with 1 parameter
    list_0 = ['']
    action_module_1 = ActionModule(list_0)

    # Test with 2 parameters
    set_0 = {''}
    action_module_2 = ActionModule(set_0, list_0)

    # Test with 3 parameters
    bool_0 = False
    action_module_3 = ActionModule(action_module_2, set_0, bool_0)

    # Test with 4 parameters
    list_1 = [0]
    action_module_4 = ActionModule(action_module_3, action_module_1, list_1, bool_0)

    # Test with 5 parameters
    str_0 = '_'

# Generated at 2022-06-25 07:14:19.451902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert True
    except AssertionError as e:
        print(e)
    else:
        print("Testcase passed!")


# Generated at 2022-06-25 07:14:25.826227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    assert action_module_0.task != None
    assert action_module_0.connection != None
    assert action_module_0.play_context != None
    assert action_module_0.loader != None
    assert action_module_0.templar != None
    assert action_module

# Generated at 2022-06-25 07:15:20.025904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:15:24.230916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 600
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {bool_0}
    dict_1 = {int_0: dict_0, bool_0: int_0}
    list_0 = [dict_1, set_0]
    str_0 = 'w'
    action_module_0 = ActionModule(dict_0, list_0, bool_0, set_0, str_0, dict_1)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:15:27.908685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    list_0 = list()
    action_module_0 = ActionModule(dict_0, list_0, bool_0, list_0, str_0, dict_1)
    action_module_0.run()


# Generated at 2022-06-25 07:15:37.249019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bool_1 = False
    int_0 = 240
    int_1 = -11
    dict_0 = {bool_1: int_1, bool_0: bool_1}
    set_0 = {int_1, int_0}
    list_0 = [int_0, int_0, int_0, int_1, int_0]
    str_0 = 'Y'
    str_1 = '}kvh(pF,{'
    action_module_0 = ActionModule(str_1, set_0, bool_1, list_0, str_0, dict_0)
    assert(action_module_0.action == str_1)
    assert(action_module_0.attributes == set_0)

# Generated at 2022-06-25 07:15:38.427684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = ActionModule(bool_0)

# Generated at 2022-06-25 07:15:47.024468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = {'A': 0, 0: 'A'}
    arg_1 = {0}
    arg_2 = False
    arg_3 = [{False: {0: False, False: 0}, 0: False}, {0}]
    arg_4 = 'R'
    arg_5 = {False: {0: False, False: 0}, 0: False}
    action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
    assert len(action_module_0._task.args) == 0, "Assert #1"
    assert len(action_module_0._task.action_args) == 0, "Assert #2"
    ActionModule(action_module_0, arg_1, arg_2, arg_0)

# Generated at 2022-06-25 07:15:54.834126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 600
    dict_0 = {int_0: int_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: int_0}
    list_0 = [dict_1, set_0]
    str_0 = 'r'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    int_1 = -73
    action_module_1 = ActionModule(bool_0, int_0, int_1, action_module_0, int_1, action_module_0)
    test_case_0()
    var_0 = action_module_1.run()


# Generated at 2022-06-25 07:16:02.982236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    bool_0 = True
    int_0 = -9
    int_1 = -350
    list_0 = [int_1, int_0]
    str_0 = 'P'
    dict_0 = {int_1: list_0, int_0: str_0}
    action_module_0 = ActionModule(str_0, list_0, int_1, int_0, dict_0, bool_0)
    assert(hasattr(action_module_0, 'vars'))


# Generated at 2022-06-25 07:16:06.369981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-25 07:16:16.857137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 300
    dict_0 = {int_0: bool_0, bool_0: int_0}
    set_0 = {int_0}
    dict_1 = {bool_0: dict_0, int_0: bool_0}
    list_0 = [dict_1, set_0]
    str_0 = 'V'
    action_module_0 = ActionModule(dict_0, set_0, bool_0, list_0, str_0, dict_1)
    int_1 = -94
    action_module_1 = ActionModule(bool_0, int_0, bool_0, action_module_0, int_1, action_module_0)
    var_0 = action_module_1.run()
