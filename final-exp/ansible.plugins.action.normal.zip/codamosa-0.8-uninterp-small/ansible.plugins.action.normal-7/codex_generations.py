

# Generated at 2022-06-25 07:07:56.815821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(module_name=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_case_0()


# Generated at 2022-06-25 07:07:58.173616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        pass

# Generated at 2022-06-25 07:08:03.040571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'k2': {'k1': 'v2'}, 'k1': 'v1'}
    str_0 = 'k3'
    str_1 = 'v3'

    dict_0[str_0] = str_1

    assert dict_0 == {'k2': {'k1': 'v2'}, 'k1': 'v1', 'k3': 'v3'}

# Generated at 2022-06-25 07:08:04.561589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing: ActionModule")
    test_case_0()

# Main function that runs the unit test

# Generated at 2022-06-25 07:08:05.970039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 07:08:12.276107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print()
    print("#")
    print("# Test 'ActionModule' class method 'run'")
    print("#")
    task_vars_0 = {}
    tmp_0 = 'PU'
    ActionBase_0 = ActionBase()
    ActionModule_0 = ActionModule()
    dict_1 = ActionModule_0.run(tmp=tmp_0, task_vars=task_vars_0)
    print("#")
    print("# Returned :")
    print("#")
    print(dict_1)
    print("#")
    print("# Check properties of the returned object :")
    print("#")
    print("##")
    print("## Check the returned object is a 'dict' :")
    print("##")

# Generated at 2022-06-25 07:08:13.098586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj0 = ActionModule()
test_ActionModule()


# Generated at 2022-06-25 07:08:14.055334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:08:16.635869
# Unit test for constructor of class ActionModule
def test_ActionModule():

    print("\n"+60*'*')
    print('Testing ActionModule constructor')

    test_case_0()



# Generated at 2022-06-25 07:08:26.197994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2283.82
    str_0 = 'peer'
    str_1 = 'S*NE6na{stf'
    list_0 = [str_1, str_0, float_0]
    dict_0 = {list_0: float_0, float_0: str_0, float_0: str_0}
    str_2 = '=RkafYXCp"Ie`M`#'
    dict_1 = {str_1: str_1, str_2: str_2}
    list_1 = [dict_1, dict_0, dict_1]
    dict_2 = {str_1: str_0, str_0: list_1}
    instance_0 = ActionModule()
    res = instance_0.run(None, dict_2)


# Generated at 2022-06-25 07:08:29.924650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:08:31.422386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    print("action_module.run(): ", action_module.run())


# Generated at 2022-06-25 07:08:35.851703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0 = ActionModule()
    action_module_0.task_vars = dict()
    action_module_0.run()
    action_module_0 = ActionModule()
    action_module_0.task_vars = dict()
    action_module_0.run()


# Generated at 2022-06-25 07:08:38.835408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if not isinstance(action_module_0._supports_async, bool):
        raise AssertionError()

# Generated at 2022-06-25 07:08:40.791927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    result = action_module_0.run()
    assert result.get('changed') == False


# Generated at 2022-06-25 07:08:41.994653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # Nothing to test
    assert(True)


# Generated at 2022-06-25 07:08:42.848860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:08:50.724234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    import os
    import sys
    import __builtin__
    original__import__ = __builtin__.__import__

    def import_mock(name, *args, **kwargs):
        if name == 'ansible.plugins.action.ActionBase':
            return ActionBase()
        else:
            original__import__(name, *args, **kwargs)

    __builtin__.__import__ = import_mock

    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:08:54.041556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'load_file_common_arguments'), "ActionModule has no attribute load_file_common_arguments"
    assert hasattr(ActionModule, '_execute_module'), "ActionModule has no attribute _execute_module"



# Generated at 2022-06-25 07:08:56.081171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:09:07.497605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
    float_0 = 36

# Generated at 2022-06-25 07:09:17.679886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'*\xe7\x86'
    str_0 = 'action'
    list_0 = [bytes_0, str_0]
    str_1 = '<<'
    bytes_1 = b'\x9d'
    list_1 = [bytes_0, str_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
    float_0 = -1.13297071423
    tuple_0 = (dict_0, float_0)
    str_2 = 'W'
    str_3 = '~J'
    bool_0 = True

# Generated at 2022-06-25 07:09:27.480538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    dict_0 = None
    float_0 = 14239.947
    dict_1 = {
        'let\x1e': float_0,
    }
    tuple_0 = (dict_0, dict_1)
    str_0 = 'f\x18w\x04\x12\x1f\x1d\x1f\x1b\x15\x1a'
    str_1 = 'c\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1a\x1f'
    bool_0 = True
    action_module_0 = ActionModule(list_0, tuple_0, list_0, str_0, str_1, bool_0)
    list_

# Generated at 2022-06-25 07:09:37.403034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    action_module_0.run(None)

# Generated at 2022-06-25 07:09:44.678512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    assert type(action_module_0.connection) is str

# Generated at 2022-06-25 07:09:50.677602
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    list_0 = []
    list_1 = []
    list_2 = [list_0, list_1]
    str_0 = '/var/tmp/ansible/tmpuUdQFK'
    list_1.append(str_0)
    str_1 = 'p4.j4(qo'
    list_1.append(str_1)
    bytes_0 = b'\xdc\x9ev\xdf\x1d\x91\xd1'
    str_2 = 'x'
    list_1.append(bytes_0)
    list_1.append(str_2)
    str_3 = 's'
    list_1.append(str_3)
    str_4 = '_np'
    list_1.append(str_4)
    str_5

# Generated at 2022-06-25 07:09:59.723209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult

    task_result = TaskResult(None, None)
    result = task_result._result
    # for old behavior, this is going to be the module_name
    result['invocation'] = { "module_name": "test_module" }
    print("test_ActionModule_run: result")
    print(result)
    print("test_ActionModule_run: result")

    assert 'invocation' in result
    del result['invocation']


# Generated at 2022-06-25 07:10:07.589644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
    float_0 = 36

# Generated at 2022-06-25 07:10:15.782583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)


# Generated at 2022-06-25 07:10:22.758446
# Unit test for constructor of class ActionModule
def test_ActionModule():
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.playbook.play import Play
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.executor.playbook_executor import PlaybookExecutor
  from ansible.utils.vars import load_extra_vars
  from ansible.utils.vars import load_options_vars
  from ansible.utils.display import Display
  from ansible.plugins.loader import PluginLoader
  from ansible.errors import AnsibleError, AnsibleOptionsError

  display = Display()
  display.verbosity = 99

  loader = DataLoader()


# Generated at 2022-06-25 07:10:30.923914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    index = 0
    while index <= 10:
        test_case_0()
        index += 1

test_ActionModule_run()

# Generated at 2022-06-25 07:10:38.716572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'tb\x9e_\x91\xca\x1f\x84\xedD\x1cT\x19\xa5\xb9'

# Generated at 2022-06-25 07:10:40.545116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:10:46.479851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    dict_0 = None
    float_0 = 3613.9946
    tuple_0 = (dict_0, float_0)
    str_0 = 'Pa5@'
    str_1 = 'er4N|T>PFcz'
    bool_0 = False
    action_module_0 = ActionModule(list_0, tuple_0, list_0, str_0, str_1, bool_0)
    list_2 = []
    dict_1 = None
    float_1 = 84.46
    tuple_1 = (dict_1, float_1)
    str_3 = '''*w]'|g?O@\x05\x1c'_'''
    str_4 = 'D\x1f'
    bool_1 = True
    action_module_

# Generated at 2022-06-25 07:10:52.973554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # simple test
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
   

# Generated at 2022-06-25 07:10:56.296688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:11:07.573411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run(self, tmp=None, task_vars=None) : basic test
    bytes_0 = b'\x0e\x18\xd5\x99\xad\x11'
    str_0 = '*\t'
    list_0 = [bytes_0, bytes_0, str_0, bytes_0]
    str_1 = '1'
    bytes_1 = b'.\xe7)\x8e\x1b\x96'
    list_1 = [bytes_0, str_0, str_0, str_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
    float_0 = 1.0


# Generated at 2022-06-25 07:11:10.749837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:11:19.170666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
    float_0 = 36

# Generated at 2022-06-25 07:11:20.770260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:11:38.647424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)


# Generated at 2022-06-25 07:11:41.863830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:11:49.545030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [None]
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_1 = [bytes_0, bytes_0, bytes_0, str_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_1, bytes_0, bytes_0, None)
    assert len(action_module_0._task.action_args) == 0
    assert action_module_0._connection._shell.tmpdir == b'./ansible_Jmf6gn_'

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:11:59.321799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    list_0 = []
    dict_1 = None
    dict_1 = {'dest': 'module-name', 'required': False, 'default': '', 'choices': ['local', 'shell', 'raw'], 'aliases': [], 'type': 'str'}
    list_0.append(dict_1)
    dict_1 = {'dest': 'module_arguments', 'required': True, 'default': None, 'choices': None, 'aliases': [], 'type': 'list'}
    list_0.append(dict_1)
    dict_1 = {'dest': 'module_complex_args', 'required': False, 'default': None, 'choices': None, 'aliases': [], 'type': 'dict'}
    list_0.append(dict_1)

# Generated at 2022-06-25 07:12:05.539000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = ['', '\r', '\r\x87\x92K\xbf\x94\x10\xb8\x1d\xf5\xff', '\r\x87\x92K\xbf\x94\x10\xb8\x1d\xf5\xff', '\r\x87\x92K\xbf\x94\x10\xb8\x1d\xf5\xff']

# Generated at 2022-06-25 07:12:12.484782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    assert action_module_0._shared_loader_obj.get('vars').get

# Generated at 2022-06-25 07:12:17.816652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  run = ActionModule.run
  if run == '\x86\x1e\x1a\x94\xbc\xe6\x17\xb9\x8bv\xeb\x11\xaf\x8e\x1b\xd0':
    print("Correct output")
  else:
    print("Expected output to be '\\x86\\x1e\\x1a\\x94\\xbc\\xe6\\x17\\xb9\\x8bv\\xeb\\x11\\xaf\\x8e\\x1b\\xd0'")


# Generated at 2022-06-25 07:12:19.445285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test case is not executed because it depends on an existing task
    pass


# Generated at 2022-06-25 07:12:28.510903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = '7(o#'
    list_0 = [str_0, bytes_0]
    str_1 = 'xJ'
    bytes_1 = b'\xd7\x18\xe6\x15\xd1\xbf\x1a\x9b\\\x8d\x81'
    list_1 = [str_0, str_0, str_0, bytes_1]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    assert 'ansible_facts' in action_module_0

# Generated at 2022-06-25 07:12:36.329490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    dict_1 = None
    list_0 = [bytes_0, dict_0, dict_0, dict_0]
    str_0 = 'Pa5@'
    str_1 = 'er4N|T>PFcz'
    bool_0 = False
    action_module_0 = ActionModule(list_0, dict_0, dict_0, str_0, str_1, bool_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:13:07.987922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
    float_0 = 36

# Generated at 2022-06-25 07:13:10.531184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new instance of the class
    action_module = ActionModule()
    # Verify that the instance was correctly created
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-25 07:13:20.753827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    action_module_0.get_attributes()

# Generated at 2022-06-25 07:13:21.284555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:13:23.272814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:13:31.405345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_3 = ActionModule(list_0, list_0, list_0, str_1, bytes_1, list_1)

# Generated at 2022-06-25 07:13:39.986824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
    float_0 = 36

# Generated at 2022-06-25 07:13:43.693711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:13:51.897552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    action_module_0.run()
    action_module_0.run()


# Generated at 2022-06-25 07:13:55.872222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    list_0 = []
    var_0 = action_module_0.run(list_0)


# Generated at 2022-06-25 07:14:45.550829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False, "Test if the test_case_0 of the method run of the class ActionModule has passed"


# Generated at 2022-06-25 07:14:54.248579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'Z1:': '1', '\x8bQ\xa2\x9d\xfd': ';0-', '\xfb\xfb\x0b\x8f\xaf': 'R', 'T': 'p\x8b\\\xfc\x13', '\xef\x0e4\xef\x0e': 'a;\x19'}
    str_0 = '6\x15\x8eV\x1c\x0cr'
    str_1 = 'Ct\x0f'
    str_2 = '\xf7V\x1c\x9d'
    str_3 = ',b\x96'
    list_0 = [str_1, str_2, str_3]
    int_0 = -1741


# Generated at 2022-06-25 07:15:04.816943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\t\x96\xb1\xdc\xd5\x8f\x9a\x7f\xcc\xe2\x1c'
    str_0 = '"F'
    list_0 = [bytes_0, str_0]
    str_1 = 'h_z'
    bytes_1 = b'Z\x9by\x91\xac.\xd3\x96\x1b\xda\xd6\xa3'
    list_1 = [bytes_0, bytes_0, str_0, str_0, str_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)

# Generated at 2022-06-25 07:15:15.164220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_2 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
    float_0 = 36

# Generated at 2022-06-25 07:15:16.507407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Manual testing of class ActionModule

# Generated at 2022-06-25 07:15:24.526471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)
    list_2 = []
    dict_0 = None
    float_0 = 36

# Generated at 2022-06-25 07:15:33.586989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc3I\xb3\xeckI\xb1\x97\xfa(\xe8*r\xd3\x8d2\xc3sO'
    str_0 = 'C\rE*+:=OH[zz\\='
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]
    str_1 = ':R'
    bytes_1 = b'u|\x8a\x84\xfa'
    list_1 = [bytes_0, str_0, bytes_0, bytes_0]
    action_module_0 = ActionModule(bytes_0, list_0, list_0, str_1, bytes_1, list_1)


# Generated at 2022-06-25 07:15:39.910152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('\x1f', [])
    list_0 = []
    dict_0 = {'g:wM\x1c': '\x1f', '\x1f': [], '\x1f': '\x1f'}
    str_0 = 'C\rE*+:=OH[zz\\='
    str_1 = ':R'
    list_1 = [str_0, str_0, str_0, str_1]
    action_module_1 = ActionModule('\x1f', list_1, list_1)
    list_2 = []
    dict_1 = {'\x1f': [], '\x1f': '\x1f', '\x1f': '\x1f'}
    float_0 = 1967

# Generated at 2022-06-25 07:15:44.641981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:15:54.465996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._task.args == {}
    action_module_1 = ActionModule()
    assert action_module_1._task.action == 'meta'
    action_module_2 = ActionModule()
    assert action_module_2._task.name == 'meta'
    action_module_3 = ActionModule()
    assert action_module_3._task.action == 'meta'
    action_module_4 = ActionModule()
    assert action_module_4._task.action == 'meta'
    action_module_5 = ActionModule()
    assert action_module_5._task.action == 'meta'
    action_module_6 = ActionModule()
    assert action_module_6._task.action == 'meta'
    action_module_7 = ActionModule()
   