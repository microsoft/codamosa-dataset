

# Generated at 2022-06-25 07:07:57.124173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = 'E@1X wzC6RLxCCp'
    set_0 = {dict_0, bool_0, bool_0, dict_0}
    test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 07:07:58.212475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:07:59.060311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:08:01.784722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule_instance = ActionModule()
    assert actionModule_instance.run(None, None) == None


# Generated at 2022-06-25 07:08:08.450411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_0 = ActionModule(None, {'str_0': 'str_0', 'str_1': 'str_1', 'dict_0': {'str_0': 'str_0', 'str_1': 'str_1'}, 'str_2': 'str_2', 'str_3': 'str_3', 'str_4': 'str_4'}, None)
    class_0.run()
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 07:08:12.912589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule(dict_0, str_0, set_0, dict_0)


# Generated at 2022-06-25 07:08:22.350829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	#input
	tmp = None
	task_vars = None
	# output
	bool_0 = True
	dict_0 = {0: bool_0}
	# int_0 = 1
	set_0 = {bool_0, bool_0}
	str_0 = 'tQsV7T><c%`9yEKjB@'
	# str_1 = 'H]'
	str_2 = '@lx@{@q3|cu'
	str_3 = 'I'

	result = ActionModule.run(tmp, task_vars)
	assert (result == {result, result, result})
	# assert (result == {str_0, str_1, str_2})
	# assert (result == {str_0, str_1, str_2, str_3})


# Generated at 2022-06-25 07:08:26.023526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    instance = ActionModule()
    assert isinstance(instance, ActionModule)


# Generated at 2022-06-25 07:08:32.711149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Task_vars_0 should be defined here
    ActionModule_0 = ActionModule()
    ActionModule_0.run(task_vars=task_vars_0)
    # You should probably check the return types and other stuff here.


# Generated at 2022-06-25 07:08:38.361361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = bool(0)
    float_0 = float(0.0)
    float_1 = float(0.0)
    int_0 = int(0)
    int_1 = int(0)
    int_2 = int(0)
    int_3 = int(0)
    list_0 = [float_0, int_1]
    list_1 = [bool_0, bool_0]
    list_2 = [int_0, bool_0, bool_0]
    list_3 = [int_1, bool_0]
    set_0 = {float_0, int_2, bool_0}
    str_0 = 'r1r&w'
    str_1 = 'evXF+$xQ=!@M)%'

# Generated at 2022-06-25 07:08:44.736163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #first test
    print("testing constructor")
    action_module_0 = ActionModule()
    assert action_module_0


# Generated at 2022-06-25 07:08:49.581096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = {}
    data['tmp'] = None
    data['task_vars'] = None
    action_module_obj = ActionModule()
    data['returned'] = action_module_obj.run(**data['tmp'],**data['task_vars'])
    assert (data['returned'] == None)


# Generated at 2022-06-25 07:08:57.711412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the action_module with an async_val of False
    action_module = ActionModule()
    setattr(action_module._task, 'async_val', False)

    # Test the execution of an asynchronous module
    # Asynchronous modules should be wrapped in 'async_wrapper'
    setattr(action_module._connection, 'has_native_async', False)
    wrap_async = not action_module._connection.has_native_async
    result = action_module.run(task_vars={}, wrap_async=wrap_async)

    assert result.get('_ansible_module_name', '') == 'async_wrapper'

    # Test the execution of a synchronous module
    # Synchronous modules should not be wrapped in 'async_wrapper'

# Generated at 2022-06-25 07:09:00.362286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == {'invocation': {'module_args': {}}, 'changed': False, '_ansible_parsed': True}



# Generated at 2022-06-25 07:09:04.013112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #u = dict(name="ActionModule", _task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    u = dict(name="ActionModule", _task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module_0 = ActionModule(u)

# Generated at 2022-06-25 07:09:07.306316
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule()
  assert action_module_0 != None


# Generated at 2022-06-25 07:09:09.396014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:09:12.919303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_0 = ActionModule()
    # FIXME - mimic an instance of task.py and task_vars.py (!)
    task = None
    task_vars = None
    tmp = None
    assert action_module_run_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:09:14.581065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:09:17.680185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module, "No object returned"
    assert action_module.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-25 07:09:25.328286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:09:32.572723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_test = ActionModule()
    assert not action_module_test
    assert not action_module_test._supports_async
    assert action_module_test._supports_check_mode
    assert action_module_test._supports_async and not action_module_test._connection.has_native_async
    assert action_module_test._supports_check_mode and not action_module_test.check_mode

# Generated at 2022-06-25 07:09:38.007840
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Properly construct the object.
        action_module = ActionModule()
        assert action_module
    except Exception as e:
        print("ActionModule object construction failed: {}".format(e))
        assert False



# Generated at 2022-06-25 07:09:38.749707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 07:09:44.602262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._supports_check_mode = True
    action_module_0._supports_async = True
    task_vars_0 = dict()
    result = action_module_0.run(None,task_vars=task_vars_0)


# Generated at 2022-06-25 07:09:48.004860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.tmp = ''
    assert am.run(am.tmp) == {}


# Generated at 2022-06-25 07:09:54.565287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars_0 = {}
    tmp_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:09:56.502509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:09:57.854998
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:10:00.279189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    action_module = ActionModule()

    # Act
    action_module_run_actual = action_module.run()

    # Assert
    assert action_module_run_actual == None

# Generated at 2022-06-25 07:10:17.457427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    result = dict()
    tmp = None
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._supports_async = True
    result = action_module.run(tmp, task_vars)
    assert result == dict()

# Generated at 2022-06-25 07:10:20.005648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:10:23.779375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, object)
    assert isinstance(action_module_0, ActionBase)


# Generated at 2022-06-25 07:10:26.192917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print('test result: {0}'.format(action_module_0))


# Generated at 2022-06-25 07:10:31.451975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Default options
    options = dict()

    # Instantiate the module with the options
    module_obj = ActionModule(**options)

    # Invoke the run method
    method_return_value = module_obj.run()

    # Check if the return value is of the correct data type
    assert isinstance(method_return_value, dict)
    return True


# Generated at 2022-06-25 07:10:34.052729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
        assert True, 'ActionModule object should be created'
    except:
        assert False, 'ActionModule object should be created'


# Generated at 2022-06-25 07:10:37.130142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:10:39.301381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_1.run(tmp, task_vars)


# Generated at 2022-06-25 07:10:47.353574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # load test cases from module file
    from test.units.plugins.action.fixtures.test_ActionModule_run_cases import cases_list
    import sys

    def tc_function_0(_, __):
        pass

    def tc_function_1(_, __):
        pass
    # run every test case
    for index, test_case in enumerate(cases_list):
        print("Running test case #%d: %s" % (index, test_case["name"]))
        if test_case["function_to_patch"] == "tc_function_0":
            tc_function_0 = test_case["function_to_patch"]
        elif test_case["function_to_patch"] == "tc_function_1":
            tc_function_1 = test_case["function_to_patch"]

        test_

# Generated at 2022-06-25 07:10:51.511415
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Method run of class ActionModule returns an instance of type dict
    assert isinstance(ActionModule().run(), dict)

# Generated at 2022-06-25 07:11:15.614299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module


# Generated at 2022-06-25 07:11:18.852810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    try:
        result = action_module.run()
        assert result == {}
    except Exception:
        raise Exception

# Generated at 2022-06-25 07:11:22.755287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert type(action_module_0.run()) is dict


# Generated at 2022-06-25 07:11:31.494145
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_1 = ActionModule()

    assert action_module_1._task.action in C._ACTION_SETUP
    assert action_module_1._task.args.get('name') == 'Setup Module'
    assert action_module_1._task.async_val is None
    assert action_module_1._task.args.get('action') == 'Setup Module'
    assert action_module_1._task.args.get('action_plugin') == 'setup'
    assert action_module_1._task.args.get('module_name') == 'setup'
    assert action_module_1._task.local_action is False
    assert action_module_1._task.loop is None
    assert action_module_1._task.lazy is False

# Generated at 2022-06-25 07:11:35.119158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:11:36.267326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 07:11:47.134873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule(name='action_module_1')
    action_module_2 = ActionModule(name='action_module_2', display=True)
    action_module_3 = ActionModule(name='action_module_3', display=True, parent='parent')
    action_module_4 = ActionModule(name='action_module_4', display=True, parent=False)
    action_module_5 = ActionModule(name='action_module_5', display=True, parent=False, loop='loop', loop_args=None)
    action_module_6 = ActionModule(name='action_module_6', display=True, parent=False, loop='loop', loop_args={'key': 'value'})


# Generated at 2022-06-25 07:11:51.220505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test Code
    action_module_1 = ActionModule()
    action_module_1.run()

# Generated at 2022-06-25 07:12:00.391325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_text
    # prep of var used by ActionModule.__init__
    class _task:
      async_val = None
      action = "ACTION_TEST"
    # prep of var used by self._execute_module
    class _task_vars:
      def __init__(self):
        self.ansible_facts = dict()
        self.ansible_facts['os'] = dict()

# Generated at 2022-06-25 07:12:02.068377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()
    assert True


# Generated at 2022-06-25 07:12:51.305152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


if __name__ == '__main__':
    # TODO: unit tests do not use this, but ansible does
    import sys

    for test_case in [
        test_case_0
    ]:
        print(test_case)
        test_case()

    sys.exit(len(problems))

# Generated at 2022-06-25 07:12:52.854387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:12:54.180320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-25 07:12:59.299966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0


# Generated at 2022-06-25 07:13:08.236761
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # option of self._supports_check_mode
    ActionModule._supports_check_mode = True
    # option of self._supports_async
    ActionModule._supports_async = True
    # option of self._connection
    ActionModule._connection = ()
    # option of self._task
    ActionModule._task = True
    # option of self._loader
    ActionModule._loader = True
    # option of self._play_context
    ActionModule._play_context = True
    # option of self._shared_loader_obj
    ActionModule._shared_loader_obj = True
    # option of self._tmp
    ActionModule._tmp = True
    # option of self._remote_user
    ActionModule._remote_user = True
    # option of self._remote_pass
    ActionModule._remote_pass = True
   

# Generated at 2022-06-25 07:13:09.803137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-25 07:13:13.743747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:13:18.706740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    if result != None:
        print("test_case_1 passed")
    else:
        print("test_case_1 failed")

test_ActionModule_run()

# Generated at 2022-06-25 07:13:19.205064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:13:21.345324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert type(action_module_1) == ActionModule

# test for run function


# Generated at 2022-06-25 07:14:22.520437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.set_task()
    action_module_1.set__task()
    action_module_1.set_shared_loader_obj()
    action_module_1.set_connection()
    action_module_1.set__connection_info()
    action_module_1.set_loader()
    action_module_1.set__task_vars()
    action_module_1.set_tmp()
    action_module_1.set__play_context()
    action_module_1.set_playbook_basedir()
    action_module_1.set_play_context()
    action_module_1.set_task()
    action_module_1.set__task()
    action_module_1.set_shared_loader_obj()

# Generated at 2022-06-25 07:14:31.273273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.add_host import ActionModule
    from ansible.vars.task_vars import TaskVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json

    loader, inventory, variable_manager, loader, options, passwords, stdout_callback = ansible_runner.utils.prepare_ansible_runner('add_host')

# Generated at 2022-06-25 07:14:31.822579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:14:38.970650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ' adds a host to inventory and possibly a group if not there already '
    list_0 = []
    bytes_0 = b'\xe13\x11\xae{\xd7\x19\x84}\xde\x99\x86'
    str_1 = '{q^%S&,g%c*/8'
    action_module_0 = ActionModule(str_0, list_0, str_1, list_0, bytes_0, str_1)
    action_module_0.run()

# Generated at 2022-06-25 07:14:39.462783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not False

# Generated at 2022-06-25 07:14:45.727268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ' adds a host to inventory and possibly a group if not there already '
    list_0 = []
    bytes_0 = b'\xe13\x11\xae{\xd7\x19\x84}\xde\x99\x86'
    str_1 = '{q^%S&,g%c*/8'
    action_module_0 = ActionModule(str_0, list_0, str_1, list_0, bytes_0, str_1)
    # TODO: check the actual result of the run method
    #assert(action_module_0.run() == "?")


# Generated at 2022-06-25 07:14:47.867140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try: 
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 07:14:54.753416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '_#1n<5r5K|[5Z}@'
    list_0 = []
    list_1 = []
    str_1 = 'lS;,8W<%[A#C]K'
    bytes_0 = b'\xe13\x11\xae{\xd7\x19\x84}\xde\x99\x86'
    list_2 = []
    var_0 = ActionModule(str_0, list_0, str_1, list_1, bytes_0, str_1)
    var_1 = var_0.run()
    assert var_1 == list_2
    assert len(var_1) == 0

# Generated at 2022-06-25 07:15:05.151371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ' adds a host to inventory and possibly a group if not there already '
    var_1 = []
    var_2 = '{q^%S&,g%c*/8'
    var_3 = []
    var_4 = b'\xe13\x11\xae{\xd7\x19\x84}\xde\x99\x86'
    var_5 = '{q^%S&,g%c*/8'
    var_6 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_7 = 1
    var_8 = 1
    var_9 = 1
    var_10 = 1
    var_11 = 1
    var_12 = 0
    var_13 = 1
    var_14 = 0

# Generated at 2022-06-25 07:15:15.264067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ' adds a host to inventory and possibly a group if not there already '
    list_0 = []
    bytes_0 = b'\xe13\x11\xae{\xd7\x19\x84}\xde\x99\x86'
    str_1 = '{q^%S&,g%c*/8'
    action_module_0 = ActionModule(str_0, list_0, str_1, list_0, bytes_0, str_1)
    assert action_module_0.module_name == 'add_host', 'Expected "add_host", but got "{}"'.format(action_module_0.module_name)

# Generated at 2022-06-25 07:17:34.420954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ' adds a host to inventory and possibly a group if not there already '
    list_0 = []
    bytes_0 = b'\xe13\x11\xae{\xd7\x19\x84}\xde\x99\x86'
    str_1 = '{q^%S&,g%c*/8'
    action_module_0 = ActionModule(str_0, list_0, str_1, list_0, bytes_0, str_1)
    var_0 = action_run()
    if (var_0 is not None):
        print('{0}'.format(var_0))
        print('{0}'.format(var_0))
        print('{0}'.format(var_0))

if __name__ == "__main__":
    test_case_

# Generated at 2022-06-25 07:17:38.833852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ' adds a host to inventory and possibly a group if not there already '
    list_0 = []
    bytes_0 = b'\xe13\x11\xae{\xd7\x19\x84}\xde\x99\x86'
    str_1 = '{q^%S&,g%c*/8'
    action_module_0 = ActionModule(str_0, list_0, str_1, list_0, bytes_0, str_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:17:43.667000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ' adds a host to inventory and possibly a group if not there already '
    list_0 = []
    bytes_0 = b'\xe13\x11\xae{\xd7\x19\x84}\xde\x99\x86'
    str_1 = '{q^%S&,g%c*/8'
    action_module_0 = ActionModule(str_0, list_0, str_1, list_0, bytes_0, str_1)
    var_0 = action_run()
    assert var_0 == 0
    assert not action_module_0.supports_check_mode()
    assert action_module_0.supports_async()

# Generated at 2022-06-25 07:17:49.285161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Executing test run')
    # Initial return value
    res = None
    # Initializing variables
    param_tmp_0 = None
    # Executing function
    return_value = run(param_tmp_0, task_vars=None)
    # Checking if the returned value is as expected
    assert return_value == res
    # Return value assertion
