

# Generated at 2022-06-25 07:08:03.416619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    Data = [{}, {'invocation':{'module_args':{'_ansible_verbose_override':True}}}, 'C', (0, b'4'), {'invocation':{'module_args':{'_ansible_verbose_override':True}}}, {'invocation':{'module_args':{'_ansible_verbose_override':True}}}, 'l', 2, 'm', {'invocation':{'module_args':{'_ansible_verbose_override':True}}}]
    str_0 = '_async_dir'
    int_0 = 1660
    bytes_0 = b'wE'
    list_0 = None

# Generated at 2022-06-25 07:08:04.901704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:11.488542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  task = dict(A = 1, B = 2)
  task_vars = dict(A = 2, B = 1)
  tmp = None
  int_0 = 6
  list_0 = [True, False, True, True, True]
  str_0 = '_async_dir'
  str_1 = '_async_dir'
  int_1 = 1660
  bytes_0 = b'wE'
  bytes_1 = b'wE'
  list_1 = None
  action_module_0 = ActionModule(str_1, int_1, str_1, bytes_1, bytes_1, list_1)

  assert list_0 == action_module_0.run(tmp, task_vars), 'Expected different value than what was returned'

# Generated at 2022-06-25 07:08:18.143917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    str_0 = 'args'
    int_0 = 1252
    str_1 = 'action'
    bytes_0 = b'\x81\x8d'
    bytes_1 = b'\x82\x8d'
    list_0 = None
    action_module_0 = ActionModule(str_0, int_0, str_0, bytes_0, bytes_1, list_0)
    # Invoking run
    action_module_0.run()

# Generated at 2022-06-25 07:08:26.067485
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    str_0 = 'ActionModule(str_0, int_0, str_0, bytes_0, bytes_0, list_0)'
    int_0 = 0
    action_module_0 = ActionModule(str_0, int_0, str_0, '', '', None)
    action_module_0.args = '_async_dir'

    str_0 = 'C._ACTION_SETUP'
    action_module_0.action = 'ActionModule(str_0, int_0, str_0, bytes_0, bytes_0, list_0)'
    action_module_0.wrap_async = 0
    action_module_0.delegate_to = ''
    action_module_0._task_fields = []

    action_module_0.task_vars = dict()
    result = action

# Generated at 2022-06-25 07:08:34.363143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'bS'
    int_0 = 1694
    str_1 = 'z\x08\xa8\x8e'
    bytes_0 = b'o(R\x9f$('
    bytes_1 = b'y\x83\xdd\x07'
    list_0 = None
    action_module_0 = ActionModule(str_0, int_0, str_0, bytes_0, bytes_0, list_0)
    action_module_0.run(str_1, list_0)


# Generated at 2022-06-25 07:08:35.976534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(str, int, str, bytes, bytes, list)


# Generated at 2022-06-25 07:08:44.991433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'md5'
    int_0 = -33
    str_1 = '_ansible_keep_remote_files'
    bytes_0 = b'#'
    bytes_1 = b'^R@'
    list_0 = None
    action_module_0 = ActionModule(str_1, int_0, str_1, bytes_0, bytes_1, list_0)
    tmp_0 = '_ansible_parsed'

# Generated at 2022-06-25 07:08:54.658660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Modules/actions/action_plugins/action.py'
    int_0 = 1062
    str_1 = 'action_plugin'
    bytes_0 = b'run'
    bytes_1 = b'device'
    list_0 = None
    action_module_0 = ActionModule(str_0, int_0, str_1, bytes_0, bytes_1, list_0)
    # ['_supports_check_mode', '_supports_async', '_task', '_load_name', '_templar', '_connection', '_shell', '_display', '_connection_loader', '_loader', '_plugins', '_templar', '_connection_loader', '_display', '_connection', '_shell', '_task', '_loader', '_supports

# Generated at 2022-06-25 07:09:04.821259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '_async_dir'
    int_0 = 612
    bytes_0 = b'k\x0b'
    list_0 = None
    action_module_0 = ActionModule(str_0, int_0, str_0, bytes_0, bytes_0, list_0)
    tmp = None
    task_vars = None
    # Test with normal arguments
    result = action_module_0.run(tmp, task_vars)
    assert result is None, "Result does not match expected result"
    # Test with inputs having None values
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result is None, "Result does not match expected result"


# Generated at 2022-06-25 07:09:10.912260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    str_0 = ''
    action_module_0 = ActionModule(str_0, int_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 07:09:11.766541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:09:12.881908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:09:21.922843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    str_0 = ''
    action_module_0 = ActionModule(str_0, int_0, str_0, str_0, str_0, str_0)
    assert isinstance(action_module_0.DS, str) == False
    assert isinstance(action_module_0._task, object) == False
    assert isinstance(action_module_0._async_timeout, int) == True
    assert isinstance(action_module_0._display, str) == False
    assert isinstance(action_module_0._connection, object) == False
    assert isinstance(action_module_0._play_context, object) == False


# Generated at 2022-06-25 07:09:30.578812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    str_0 = ''
    action_module_0 = ActionModule(str_0, int_0, str_0, str_0, str_0, str_0)
    dict_0 = {}
    dict_0['changed'] = False
    dict_0['msg'] = ''
    dict_0['rc'] = 0
    dict_0['stderr'] = ''
    dict_0['stdout'] = ''
    dict_0['warnings'] = []
    dict_1 = {}
    dict_0['results'] = dict_1
    dict_2 = {}
    dict_0['invocation'] = dict_2
    dict_2['module_name'] = ''
    dict_2['module_args'] = dict_1
    dict_0['ansible_version'] = dict_1

# Generated at 2022-06-25 07:09:31.369822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 07:09:33.907502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = ''
    action_module_0 = ActionModule(str_0, int_0, str_0, str_0, str_0, str_0)
    action_module_0.run()


test_case_0()

# Generated at 2022-06-25 07:09:36.859818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = ''
    action_module_0 = ActionModule(str_0, int_0, str_0, str_0, str_0, str_0)
    result = action_module_0.run(None, None)

# Generated at 2022-06-25 07:09:42.341467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # First test
    int_0 = 0
    str_0 = ''
    action_module_0 = ActionModule(str_0, int_0, str_0, str_0, str_0, str_0)
    assert action_module_0._task.action == ''

    # Second test
    int_0 = 0
    str_0 = ''
    action_module_1 = ActionModule(str_0, int_0, str_0, str_0, str_0, str_0)
    assert action_module_1._task.action == ''


# Generated at 2022-06-25 07:09:45.729718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    str_0 = ''
    action_module_0 = ActionModule(str_0, int_0, str_0, str_0, str_0, str_0)

    # TODO: test for is_async. The assert is correct but the generated code is wrong



# Generated at 2022-06-25 07:09:58.196229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = -55.6887
    bytes_0 = b'\xa7\xae\xa1\x85\xad\xcb\x8b=\x9d\x95\xca\x1d\x93'
    str_0 = '<#5j\x1f<\x1c\x1d\x00\xf4'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_run()
    assert var_0 == {}

# Generated at 2022-06-25 07:10:00.616859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	assert True # TODO: implement your test here

if __name__ == '__main__':
    # prepare to run test cases
    setup()
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:10:06.185185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_2 = ()
    list_2 = [tuple_2]
    float_2 = 473.9
    bytes_2 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_2 = '+g:I>'
    action_module_1 = ActionModule(tuple_2, list_2, float_2, bytes_2, str_2, tuple_2)

    print('Test case passed successfully!')


# Generated at 2022-06-25 07:10:11.461083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    action_module_0.run(tmp = None, task_vars = None)

# Generated at 2022-06-25 07:10:16.669530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    param_0 = None
    param_1 = None
    action_module_0.run(param_0, param_1)


# Generated at 2022-06-25 07:10:23.021920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 937.45
    bytes_0 = b'\x12\x99\x0b\xe3\xf4\x8b\x81\x1a\xe6\x9f\x8d\xbd'
    str_0 = '&D9n\x1a'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_run()



# Generated at 2022-06-25 07:10:31.013591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_module_0.run()


# Test for class ActionModule

# Generated at 2022-06-25 07:10:38.279732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 80.7
    bytes_0 = b']\x125:1\xd7\xa4\xef\xb7\x9d\x93\xcc\xcd\xfc\xfa'
    str_0 = '\x0b\xdf\x9f\x1d\xc6\xe7\x8d'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:10:46.943855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_2 = ()
    list_2 = [tuple_2]
    float_1 = 596.9
    bytes_1 = b'\\\xf4\xa5\xae\xa4K\x8e\x12\xa4\x02\x8d\xb0\x85\x14\x84\x0f\xda\x13\xa4\xbb'
    str_1 = 'l=P<'
    tuple_3 = ()
    action_module_1 = ActionModule(tuple_2, list_2, float_1, bytes_1, str_1, tuple_3)
    var_3 = action_run()
    float_2 = 2.1

# Generated at 2022-06-25 07:10:57.114805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 370.5
    bytes_0 = b'\x99\x89\x04\x8d\xf9\xd9\xaf\x92\x13\xf0\xcf\xd6'
    str_0 = ';s\x96'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_module_0.run(tuple_0)
    assert var_0 == '<ActionModule | run (0.11s)>'
    assert isinstance(var_0, str)
    del var_0

# Generated at 2022-06-25 07:11:06.358931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 == 'hi there'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:11:16.927447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    extracted_dict_0 = action_module_0.run()
    assert extracted_dict_0 == None

# Generated at 2022-06-25 07:11:19.335608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')
    # TODO add code here to test method run


# Generated at 2022-06-25 07:11:30.348445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 0.8
    bytes_0 = b'\xda\xa9'

# Generated at 2022-06-25 07:11:38.142807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    assert action_module_0 is not None
    print('Passed: test_Action_module')

# Generated at 2022-06-25 07:11:42.171803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:11:51.786519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 241.8
    bytes_0 = b'\x87\x9e\x02\xe1\xd3\x08\x0b\xbd\xbd\xbd\xbd\xbd\xbd\xbd\xbd\xbd\xbd'
    str_0 = 'U;@'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:11:59.056508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_module_0.run()

# Test case for method run of class ActionModule

# Generated at 2022-06-25 07:12:08.241956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 961.9
    bytes_0 = b'\x1c\xdc\xf5\xb0\xb9\xca\x18\x9b1\xdeG\xa3\xd3\xe3\x15\x92'
    str_0 = '$!@X\x07\x1b,\x81\xbd\xe4\xa0\xf6(\x85'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_run()


# Testing #
# Test Cases #
# Test case for method run of class ActionModule


# Generated at 2022-06-25 07:12:12.341538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)


# Generated at 2022-06-25 07:12:33.775394
# Unit test for constructor of class ActionModule
def test_ActionModule():
  tuple_0 = ()
  list_0 = [tuple_0]
  float_0 = 473.9
  bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
  str_0 = '+g:I>'
  action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
  assert action_module_0._task.task_name == 'action' and action_module_0._task == tuple_0

# Function action_run

# Generated at 2022-06-25 07:12:40.823351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 774.7
    bytes_0 = b'\x8b\xd7\x14f\x92\xfc\x8a\x95\xeb\xcc\xdc\x8a\xf7\x83\xd3\xa1\xe1\xdb\x9e\xec\xe6}'
    str_0 = 'B<'
    var_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_1 = var_0.runner.tuple_0
    var_2 = var_0.runner.list_0
    var_3 = str(var_1 == var_2)
    assert var_

# Generated at 2022-06-25 07:12:46.745481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    float_0 = 621.3

# Generated at 2022-06-25 07:12:49.021429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    return action_module_0


test_case_0()

# Generated at 2022-06-25 07:12:58.332360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 864.5
    bytes_0 = b'wc\xed\x04\xb7\xfb\x89\x9d\x97\xd1\x90\xc4\xdf'
    str_0 = 'j4s'
    tuple_1 = (36, 69.37, None, False, str_0, 'j4s', ('+g:I>',), 69.37, '&;G\x10\x1e', bytes_0, None, '&;G\x10\x1e', None, 864.5, False, None, tuple_0, 69.37, tuple_0, 'j4s', None, bytes_0)

# Generated at 2022-06-25 07:13:00.193014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError):
        ActionModule()



# Generated at 2022-06-25 07:13:02.392336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()


# Generated at 2022-06-25 07:13:09.796903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert '_execute_module' in dir(ActionModule)
    assert '_remove_tmp_path' in dir(ActionModule)

#   @add_action_attribute
#   @options(TaskIncludeOptions)
#   def action_include(self, var_name=None, skip_tags=None, only_tags=None, module_vars=None, include_vars=None,
#                      include_tasks=None, loop_vars=None, loop=None, name=None):


#   @add_action_attribute
#   @options(TaskBlockOptions)
#   def action_block(self, block=None, rescue=None, always=None, name=None):


#   @add_action_attribute
#   @options(TaskMetaOptions)
#   def action_meta(self):
#       '

# Generated at 2022-06-25 07:13:18.763339
# Unit test for constructor of class ActionModule
def test_ActionModule():

    tuple_0 = (1, 2, 3)
    list_0 = [tuple_0]
    float_0 = 3.14
    bytes_0 = b'\x03\x01\x04\x01\x06\x01'
    str_0 = 'sh'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)

    if (action_module_0.action_name == 'sh'):
        if (action_module_0.action_name == 'sh'):
            assert True
        else:
            assert True
    else:
        assert False


# Generated at 2022-06-25 07:13:26.255335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 673.3
    bytes_0 = b'\xd1\xae\t\xe5\x8f\x1b\xec\xba\x99\x8a\xa6u\x01\xda\xfe\xc0'
    str_0 = 'x0\'"S'
    str_1 = '0l}e'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, str_1)
    var_0 = action_run()
    print(var_0)


# Generated at 2022-06-25 07:14:05.891183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    assert action_module_0.run(None, None) == None #todo : fixme

# Generated at 2022-06-25 07:14:13.579062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)

    assert action_module_0 is not None


# Generated at 2022-06-25 07:14:17.103922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = () # TODO: Find out what should be the output
    assert action_module_0.run(tmp=None, task_vars=None) == result

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:14:18.257371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:14:25.869912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    float_0 = 0.2339
    bytes_0 = b'\x92\xfc\x89\x04\x8b\x94\xfa\xf5\x1a\x01\x16\x13\x87\x9f'
    str_0 = '^j;U+'
    ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)


# Generated at 2022-06-25 07:14:31.819525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    action_module_0.run()

# Generated at 2022-06-25 07:14:38.971479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:14:47.014125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 0.09
    bytes_0 = b'\x1d\x0e\x02\t\x9a\x83\xff\xa4+\xd7\xcd\x08\x86\x15'
    str_0 = '9$\n'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:14:53.685745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)

    var_0 = action_module_0.run()
    assert var_0 == None, 'Return value of method run must be: None'

# Generated at 2022-06-25 07:14:54.930465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    action_module_0 = ActionModule(tuple_0)

# Generated at 2022-06-25 07:16:17.609189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)

# Generated at 2022-06-25 07:16:22.702242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()
    tuple_0 = ()
    list_0 = [tuple_0]
    action_module_0.run(tmp=tuple_0, task_vars=list_0)


# Generated at 2022-06-25 07:16:33.417111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    assert isinstance(action_module_0._task, object)
    assert isinstance(action_module_0._connection, object)
    assert isinstance(action_module_0._play_context, object)
    assert isinstance(action_module_0._loader, object)

# Generated at 2022-06-25 07:16:40.497753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_module_0.run()
    assert var_0 == None


# Generated at 2022-06-25 07:16:46.281659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:16:53.257828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
    var_0 = action_run()
#Test case for method run of class ActionModule
test_ActionModule_run()

# Generated at 2022-06-25 07:16:58.511483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # case 0
        tuple_0 = ()
        list_0 = [tuple_0]
        float_0 = 473.9
        bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
        str_0 = '+g:I>'
        action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)
        var_0 = action_run()
    except Exception as e:
        print('Test Fail: ', e)


# Generated at 2022-06-25 07:17:05.634350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)


# Generated at 2022-06-25 07:17:14.587291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 473.9
    bytes_0 = b'\xa4@)x\x18`\xf2\xc0\xef\xa5_\xdb\r\xb7'
    str_0 = '+g:I>'
    action_module_0 = ActionModule(tuple_0, list_0, float_0, bytes_0, str_0, tuple_0)


# Generated at 2022-06-25 07:17:19.125178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = [tuple_0]
    float_0 = 687.441
    bytes_0 = b'\x8d\xd1h\xcd\x05/\x92\x0b\xcb\x9cX\x00\xbc\xdbn'
    str_0 = '\\Y'
    tuple_1 = (list_0, float_0, bytes_0, str_0, tuple_0)
    action_module_0 = ActionModule(tuple_0, tuple_1, float_0, bytes_0, str_0, tuple_0)
