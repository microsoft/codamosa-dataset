

# Generated at 2022-06-25 07:07:56.504923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        a = ActionModule(None, None, None, None, None, None)
    except TypeError:
        pass # test passes
    else:
        assert False

# Generated at 2022-06-25 07:08:01.170932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    list_0 = []
    str_0 = 'GHI'
    action_module_0 = ActionModule(complex_0, list_0, complex_0, complex_0, complex_0, str_0)
    # test case for run method of class ActionModule
    test_case_0()

if __name__ == '__main__':
    # Unit test for class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 07:08:09.565312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    exec_rc_0 = 0
    exec_stdout_0 = 'stdout'
    exec_stderr_0 = 'stderr'
    exec_stdout_lines_0 = 'stdout\n'
    exec_stdout_lines_0 = exec_stdout_lines_0.split('\n')
    exec_ansible_module_results_0 = {'logs': exec_stdout_lines_0}
    exec_return_0 = (exec_rc_0, exec_stdout_0, exec_stderr_0)
    exec_module_1 = 'module'
    module_name_0 = 'module'
    module_name_0 = module_name_1
    exec_module_0 = exec_module_1
    exec_module_1 = 'module'
    module_name

# Generated at 2022-06-25 07:08:16.036711
# Unit test for constructor of class ActionModule
def test_ActionModule():

    complex_0 = None
    list_0 = []
    str_0 = 'GHI'
    action_module_0 = ActionModule(complex_0, list_0, complex_0, complex_0, complex_0, str_0)
    assert action_module_0 is not None
    assert action_module_0._task.action == 'GHI'

# Generated at 2022-06-25 07:08:23.050896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    list_0 = []
    str_0 = 'GHI'
    action_module_0 = ActionModule(complex_0, list_0, complex_0, complex_0, complex_0, str_0)
    param_0 = None
    param_1 = None
    result_0 = action_module_0.run(param_0, param_1)
    assert result_0 is None


# Generated at 2022-06-25 07:08:32.940142
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:08:39.595867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    list_0 = []
    str_0 = 'task_vars'
    dict_0 = {}
    action_module_0 = ActionModule(complex_0, list_0, complex_0, complex_0, complex_0, str_0)
    tmp = None
    task_vars = dict_0
    expect_val = dict_0
    actual_val = action_module_0.run(tmp, task_vars)

    assert actual_val == expect_val

# Generated at 2022-06-25 07:08:42.766095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    list_0 = []
    str_0 = 'GHI'
    action_module_0 = ActionModule(complex_0, list_0, complex_0, complex_0, complex_0, str_0)


# Generated at 2022-06-25 07:08:50.676667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ##################################################################################################################
    # argv = []
    # opts = []
    complex_0 = None
    list_0 = []
    str_0 = 'GHI'
    bool_0 = True

    action_module_0 = ActionModule(complex_0, list_0, complex_0, complex_0, complex_0, str_0)
    # print("Module: " + str(action_module_0) + ".")
    ##################################################################################################################


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:08:56.119839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0 is not None
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0._task is None
    assert action_module_0._connection is None
    assert action_module_0._play_context is None
    assert action_module_0._loader is None
    assert action_module_0._templar is None
    assert action_module_0._shared_loader_obj is None
    assert action_module_0._action == 'GHI'


# Generated at 2022-06-25 07:09:00.555368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    test_case_0()

# vim: ansible-0.0 ft=python-2.7

# Generated at 2022-06-25 07:09:04.151603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_1 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    assert action_module_0._supports_check_mode
    assert action_module_0._supports_async

# Generated at 2022-06-25 07:09:13.804776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_0._connection.has_native_async = True
    action_module_0._task.async_val = True
    action_module_0._task.action = 'ping'
    action_module_0._execute_module = lambda **kw: {'rc': 0, '_ansible_verbose_always': True}

# Generated at 2022-06-25 07:09:14.968250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 07:09:22.525037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
# Testing if the ActionModule throws an exception when required parameters are not passed
with pytest.raises(TypeError) as excinfo:
    action_module_0 = ActionModule()
# Test for '__init__'

# Generated at 2022-06-25 07:09:23.647235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    test_case_0()


# Generated at 2022-06-25 07:09:26.235229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    self = ActionModule(tmp, task_vars, tmp, task_vars, tmp, task_vars)


# Generated at 2022-06-25 07:09:33.718755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    action_module_1 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_5)
    var_6 = None
    var_7 = None
    var_8 = True
    var_9 = None
    action_module_2 = ActionModule(var_6, var_7, var_8, var_4, var_9, var_9)
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = True
    var_15 = True

# Generated at 2022-06-25 07:09:36.697513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    test_case_0()

# Generated at 2022-06-25 07:09:40.431675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_1 = ActionModule.ActionModule(var_0, var_0, var_0, var_0, var_1, var_1)



# Generated at 2022-06-25 07:09:48.198103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = test_case_0(var_0)
    wrap_async = test_case_0(var_0)
    assert True == True



# Generated at 2022-06-25 07:09:53.531202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    module = AnsibleModule()
    module.run()



# Generated at 2022-06-25 07:09:56.780313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:10:02.585520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test constructor of class ActionModule")
    var_0 = None
    action = ActionModule(var_0)


# Generated at 2022-06-25 07:10:11.894096
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:10:15.965860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_var = ActionModule()
    # Unit test for function run
    test_case_0()

# Generated at 2022-06-25 07:10:22.506503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test method run of class ActionModule')

    # Setup a test object
    ActionModule_obj = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Run run without parameters
    ActionModule_obj.run()
    # Run run with parameters
    ActionModule_obj.run(
        tmp=var_0, 
        task_vars=var_0
    )

# Generated at 2022-06-25 07:10:23.592238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:10:33.816495
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_case_0()

# class ActionModule(object):
#     name = "action"
#
#     def __init__(self, runner):
#         self.runner = runner
#         self.connection = None
#         self.transport = None
#         self.module_name = None
#         self.module_args = None
#
#         self.noop_on_check(runner)
#
#     def noop_on_check(self, runner):
#         self.supports_check_mode = True
#         if runner.noop_on_check(self):
#             self.runner = runner.check_mode_runner()
#             self.supports_check_mode = False
#
#     def run(self, conn, tmp, module_name, module_args, inject, complex_args

# Generated at 2022-06-25 07:10:34.784528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture_to_test = ActionModule()


# Generated at 2022-06-25 07:10:44.590790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = 'Vf\x8c'
    int_0 = -1445
    float_0 = -1.91750982381
    bytes_0 = b'I\xee\x15\xca'
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []

# Generated at 2022-06-25 07:10:45.189995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 07:10:52.184521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = 'D\xdc\xdd\xcc\x8b\xfe\xc13T'
    int_0 = 1604
    float_0 = -23.3
    bytes_0 = b'\xe1\xae\xf2\x1b\xec_\xb6\x14\x12\x8a\x17\xa6\xf7\xc1'
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []

# Generated at 2022-06-25 07:10:56.346687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)


# Generated at 2022-06-25 07:11:00.231736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except Exception:
        return False, False
    return True, True



if __name__ == '__main__':
    pass

# Generated at 2022-06-25 07:11:04.986532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if not isinstance(ActionModule(), ActionModule):
        raise AssertionError
    action_module_0 = ActionModule()
    str_0 = '@R\nl(-9-Xm-J'
    action_module_0.run(str_0)

# Generated at 2022-06-25 07:11:07.659532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    temp_variable_0 = None
    temp_variable_1 = None
    temp_variable_2 = None
    temp_variable_3 = None

# Testing configuration part
if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:11:16.689542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = 'f%c$L*m\\F\t=e'
    int_0 = 2679
    float_0 = -1.825446876
    bytes_0 = b"0\x8c\xcdY\xa4|\x90\x8a\xb4\xeb\x9f\x8f"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    assert action_module_1._connection == dict_0
    assert action_module

# Generated at 2022-06-25 07:11:26.696076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []
    bytes_1 = b'-\x9fG\xf3\xff\x91N\xb7\xcd^\xcfXn'
    action_module_2

# Generated at 2022-06-25 07:11:38.262843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule()
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []

# Generated at 2022-06-25 07:11:46.991008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:11:58.220747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_3 = None
    str_1 = 'T@T\xed\x80\x94\x96\x8e\x00\xb9\x01\xbd\xea'
    int_1 = -358
    float_1 = -2.473501
    bytes_2 = b'\xe8\xd1\x98\x88'
    action_module_4 = ActionModule(action_module_3, str_1, int_1, action_module_3, float_1, bytes_2)
    assert action_module_4 is not None

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:11:59.019087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:12:08.203724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []
    bytes_1 = b'-\x9fG\xf3\xff\x91N\xb7\xcd^\xcfXn'
    action_module_2

# Generated at 2022-06-25 07:12:18.093998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = 'q`\'\xe8\x05\x0f\x1e\xfc\x91\x0f\x19\xd1\x03\x9a\x11\xa1\x86\xca\xed\x0c\xe4\x1f\x9e'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"

# Generated at 2022-06-25 07:12:20.532456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:12:22.211033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except:
        assert True == False, "unexpected error"


# Generated at 2022-06-25 07:12:22.648905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-25 07:12:31.726187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_2 = ActionModule(bool_0, action_module_0, bool_0, dict_0, float_0, bytes_0)
    assert action_module_2 is not None

# Generated at 2022-06-25 07:12:35.253386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = { 'ansible_facts': {} }
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_module_0.run(tmp, task_vars)
    assert var_0 is None

# Generated at 2022-06-25 07:12:48.736476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:12:50.248773
# Unit test for constructor of class ActionModule
def test_ActionModule():
   test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:13:00.337131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = 'y\x8c\xec\xaa\xc4j\x8b\xf1\x90\xdc\x1f\x9e'
    int_0 = -2692
    float_0 = -224.072706
    bytes_0 = b'I\xd1\xed\x1e\xc1\xcb\x04\x0f\x9f\xf0\x9a\xab'

# Generated at 2022-06-25 07:13:01.821523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:13:02.738256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:13:09.998427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []
    bytes_1 = b'-\x9fG\xf3\xff\x91N\xb7\xcd^\xcfXn'
    action_module_2

# Generated at 2022-06-25 07:13:20.683752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '#\xcb\x93\xa8\x8b'
    int_0 = 7945
    float_0 = 3398.46
    bytes_0 = b'\xea\xc6\xbeZ\x98\xa1\xdbO\xbf\xf3\x9b\xb0'
    action_module_0 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    var_0 = action_module_0.run()
    bool_1 = True

# Generated at 2022-06-25 07:13:30.289950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Get parameters
    bool_0 = False
    action_module_0 = None
    bool_1 = False
    dict_0 = {bool_0: bool_1, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '^!\xa8Z'
    int_0 = -1847
    dict_1 = {str_0: str_0, int_0: int_0}
    float_0 = -1107.374957
    bytes_0 = b'\x1e\x81\xc8\xab'
    # Call constructor
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_1, float_0, bytes_0)


# Generated at 2022-06-25 07:13:39.854441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for AssertionError with message "no_log"
    from ansible.utils.vars import merge_hash
    action_module_0 = None
    bool_0 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []

# Generated at 2022-06-25 07:13:51.212105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []
    bytes_1 = b'-\x9fG\xf3\xff\x91N\xb7\xcd^\xcfXn'
    action_module_2

# Generated at 2022-06-25 07:14:25.499081
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []
    bytes_1 = b'-\x9fG\xf3\xff\x91N\xb7\xcd^\xcfXn'
    action_module_2

# Generated at 2022-06-25 07:14:35.565320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []
    bytes_1 = b'-\x9fG\xf3\xff\x91N\xb7\xcd^\xcfXn'
    action_module_2

# Generated at 2022-06-25 07:14:36.376674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:14:44.001544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_3 = None
    dict_1 = {action_module_3: action_module_3}
    str_1 = './test/test_files/test_module_dir'
    int_1 = 4
    dict_2 = {dict_1: dict_1, dict_1: dict_2, dict_2: dict_2}
    float_1 = -716.67
    bytes_2 = b'\x1e\xee\x88\xc2\xe3\x14\x11\xcc'
    action_module_4 = ActionModule(dict_1, str_1, int_1, dict_2, float_1, bytes_2)
    str_2 = '_execute_module'
    list_1 = ['module_name']

# Generated at 2022-06-25 07:14:45.623201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:14:54.313217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '}H\xfc\x7f\x0e\x7f\xdf;\x7f'
    int_0 = -364
    dict_0 = {str_0: int_0}
    str_1 = '\x9f\x08\xc4\x8a\x10\xfe\x86\x82\x8b\x82\x9f'
    bool_0 = False

# Generated at 2022-06-25 07:14:55.164164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:15:05.375832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = True
    var_1 = None
    var_2 = True
    var_3 = {var_0:var_0, var_1:var_1, var_1:var_2}
    var_4 = '@R\nl(-9-Xm-J'
    var_5 = 2167
    var_6 = -1173.654156
    var_7 = b"\x9c'\xd1"
    var_8 = ActionModule(var_3,var_4,var_5,var_3,var_6,var_7)
    var_9 = []
    var_10 = b'-\x9fG\xf3\xff\x91N\xb7\xcd^\xcfXn'

# Generated at 2022-06-25 07:15:15.375926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '11>|6PB`'
    int_0 = -2030
    float_0 = -10.58
    bytes_0 = b'\xa1\x93\xeb\x03\xb9\x8d\xfe'
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []
    bytes_1 = b'\x7f\xec,\xdc\x81\xb4'

# Generated at 2022-06-25 07:15:22.106619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    action_module_0 = None
    bool_1 = False
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, bool_1: bool_0}
    str_0 = 'R5\x11_z\x82\xdf\x92~\x87'
    int_0 = -1718
    float_0 = -89.71674
    bytes_0 = b'\xa5^\xb8\x07\r\xf7\xab\xc89\x07}\x83'
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []

# Generated at 2022-06-25 07:16:28.116334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Run unit tests
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:16:29.134633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:16:37.781090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {True: True, None: None, None: True}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    dict_1 = {True: True, None: None, None: True}
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_0 = ActionModule(dict_0, str_0, int_0, dict_1, float_0, bytes_0)
    assert action_module_0.tmp is None
    dict_2 = {True: True, None: None, None: True}
    str_1 = '@R\nl(-9-Xm-J'
    int_1 = 2167

# Generated at 2022-06-25 07:16:43.527449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []
    bytes_1 = b'-\x9fG\xf3\xff\x91N\xb7\xcd^\xcfXn'
    action_module_2

# Generated at 2022-06-25 07:16:47.823224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:16:55.164543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = None
    bool_1 = True
    dict_0 = {bool_0: bool_0, action_module_0: action_module_0, action_module_0: bool_1}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_1 = ActionModule(dict_0, str_0, int_0, dict_0, float_0, bytes_0)
    list_0 = []
    bytes_1 = b'-\x9fG\xf3\xff\x91N\xb7\xcd^\xcfXn'
    action_module_2

# Generated at 2022-06-25 07:16:57.254645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except Exception:
        assert False


# Generated at 2022-06-25 07:16:57.895487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_3 = ActionModule()


# Generated at 2022-06-25 07:17:07.374303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Fixture for ActionModule
    class ActionModule_fixture:
        @property
        def _play_context(self):
            return self.__play_context

        @_play_context.setter
        def _play_context(self, value):
            self.__play_context = value

        _play_context = None 

        @property
        def _loader(self):
            return self.__loader

        @_loader.setter
        def _loader(self, value):
            self.__loader = value

        _loader = None 

        @property
        def _templar(self):
            return self.__templar

        @_templar.setter
        def _templar(self, value):
            self.__templar = value

        _templar = None 


# Generated at 2022-06-25 07:17:16.235386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'((C&!@': '@R\nl(-9-Xm-J'}
    str_0 = '@R\nl(-9-Xm-J'
    int_0 = 2167
    dict_1 = {'((C&!@': '@R\nl(-9-Xm-J', str_0: int_0}
    float_0 = -1173.654156
    bytes_0 = b"\x9c'\xd1"
    action_module_0 = ActionModule(dict_0, str_0, int_0, dict_1, float_0, bytes_0)
    var_0 = action_module_0.run()
    assert isinstance(var_0, dict) == True
    assert var_0.get('action_result') is not None
   