

# Generated at 2022-06-25 07:07:51.960948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0emzAPx5_B'
    str_1 = 'd]0t0o'
    str_2 = 'mDh.Js'
    str_3 = '9\\\t'
    str_4 = 'M\x0bz*dC%c'
    str_5 = 'Xa/\n'
    bool_0 = False
    dict_0 = {str_3: str_3, str_2: bool_0, bool_0: bool_0, str_1: bool_0, bool_0: bool_0}
    dict_1 = {str_2: str_2, str_2: str_1, str_5: str_5, bool_0: bool_0, bool_0: bool_0}

# Generated at 2022-06-25 07:07:57.734398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 0.0001
    dict_0 = {float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)


# Generated at 2022-06-25 07:08:06.733832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'N-4sY\nm'
    float_0 = 0.0001
    dict_0 = {'stdout_lines': str_0}
    dict_1 = {'stdout_lines': str_0}
    str_1 = 'o\x0bz\x14c'
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_1, str_1, bool_0)
    dict_2 = {str_0: str_0}
    dict_3 = {'stdout_lines': str_0, 'stdout': str_0}
    dict_4 = {}
    dict_5 = {'stdout_lines': str_0}

# Generated at 2022-06-25 07:08:18.673790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Dps'
    float_0 = 0.0027
    dict_0 = {0.1437: str_0}
    dict_1 = {0.1437: str_0}
    str_2 = '+:f'
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_1, str_2, bool_0)

    # Test case with arguments
    str_0 = '/<U0dH^'
    float_0 = 0.3337
    str_1 = 'm~u\x7fc$'
    dict_0 = {0.0002: bool}
    dict_1 = {0.0002: bool}
    str_2 = '<v1tIN'
    bool_0 = False
   

# Generated at 2022-06-25 07:08:25.551561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'H1I[CXz'
    float_0 = 0.64111328125
    dict_0 = {float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    # TODO: fix this test
    #assert action_module_0._supports_async == True, 'Bug'
    #assert action_module_0._supports_check_mode == True, 'Bug'
    action_module_0._execute_module(dict_0, bool_0)
    action_module_0.run(str_0, dict_0)


# Generated at 2022-06-25 07:08:34.343047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']T6k'
    float_0 = 0.0047
    dict_0 = {}
    dict_1 = {}
    str_1 = '7Z[5\x0f7\x0f5\x7f'
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_1, str_1, bool_0)
    assert not action_module_0._supports_check_mode
    assert action_module_0._supports_async


# Generated at 2022-06-25 07:08:40.151876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 0.0001
    dict_0 = {float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 07:08:46.281216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ''
    float_0 = 0.0
    dict_0 = {}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:08:52.007298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 0.0001
    dict_0 = {float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    action_module_0.run(dict_0)



# Generated at 2022-06-25 07:08:58.807488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructing object of class ActionModule
    test_case_0()

######################################################################################
# Example test usage:
#
# pytest src/ansible/plugins/action/action.py -v --ssh-extra-args="-o StrictHostKeyChecking=no"
#
# To skip tests matching given substring, you can use pytest's -k option:
#
# pytest src/ansible/plugins/action/action.py -v -k "not test_case_0"
#
# To run all the tests except the ones matching the given substring, use -k 'not substring':
#
# pytest src/ansible/plugins/action/action.py -v -k "not test_case_0"
######################################################################################

# Generated at 2022-06-25 07:09:03.871432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:09:13.805295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'R4k4ku'
    float_0 = 0.5123260005906972
    dict_0 = {}
    str_1 = 'tvM7'
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_1, bool_0)
    dict_1 = {'z3qwg': 'hJE0j', '7Bm8pI': '0l0J', 'rVlxI8': 'wV7M', 'pth39': '+W8Xs', 'N18jDY': 'NyjK'}

# Generated at 2022-06-25 07:09:14.809780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None

# Unit test to check if test_case_0() is True

# Generated at 2022-06-25 07:09:17.175775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Don't know how to test method ActionModule.run -- you must provide working input
    assert false # write me!



# Generated at 2022-06-25 07:09:24.890083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '"R^\x0c\x0c'
    float_0 = 0.36
    dict_0 = {'v9_Z6U.\rqn': str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    action_module_0.run(tmp=float_0, task_vars=dict_0)
if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:09:30.290816
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test constructor(self, task, connection, play_context, loader, templar, shared_loader_obj):
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 0.0001
    dict_0 = {float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)



# Generated at 2022-06-25 07:09:37.540124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '\x13\x0b\x18O\x1bB\x1e#\x15K\x04'
    float_1 = 0.0012842107582909
    dict_1 = {float_1: str_1}
    bool_1 = False
    action_module_1 = ActionModule(str_1, float_1, dict_1, dict_1, str_1, bool_1)
    if (str_1 == '1O\x1e\x0b\x18\x11_#\x13L\x04'):
        print('The constructed object of ActionModule was verified.')
    else:
        print('Error! The constructed object of ActionModule cannot be verified.')

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:09:44.269904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 0.0001
    dict_0 = {float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    assert action_module_0.task == str_0
    assert action_module_0._play_context == float_0
    assert action_module_0._loader == dict_0
    assert action_module_0._templar == dict_0
    assert action_module_0.connection == str_0
    assert action_module_0.become == bool_0

# Generated at 2022-06-25 07:09:46.672299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:09:51.399300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'e\x0c@AG7BVwp'
    float_0 = 0.0001
    dict_0 = {float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)

    assert isinstance(action_module_0, ActionModule) == True


# Generated at 2022-06-25 07:09:55.093671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule.__module__)
    assert True

# Generated at 2022-06-25 07:10:05.563480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'B&D1j@'
    float_0 = 855.6831
    dict_0 = {float_0: str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    assert action_module_0.task == 'B&D1j@'
    assert action_module_0.connection == 855.6831
    assert action_module_0._task == 'B&D1j@'
    assert action_module_0._connection == 855.6831
    assert action_module_0._play_context == {855.6831: 'B&D1j@'}

# Generated at 2022-06-25 07:10:11.459800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '\x16\x10\x05\n\x11'
    float_1 = 0.1545
    dict_1 = {str_1: float_1}
    bool_1 = False
    str_2 = '\x0b\x1c\t\x1c\x0f'
    float_2 = 65.86
    dict_2 = {float_2: float_2, float_2: float_1}
    action_module_1 = ActionModule(str_2, float_1, dict_2, dict_2, str_2, bool_1)


# Generated at 2022-06-25 07:10:21.490334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._task == '<invalid task>'
    assert action_module_0._connection == '<invalid connection>'
    assert action_module_0._play_context == '<invalid play_context>'
    assert action_module_0._loader == '<invalid loader>'
    assert action_module_0._shared_loader_obj == '<invalid shared_loader_obj>'
    assert action_module_0._task_vars == '<invalid task_vars>'
    assert action_module_0._templar == '<invalid templar>'
    assert type(action_module_0.__dict__) == '<class \'dict\'>'
    assert type(action_module_0._shared_loader_obj)

# Generated at 2022-06-25 07:10:29.143344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:10:32.051749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert False
    except:
        action_module_1 = ActionModule(module_name)
        var_1 = action_module_1.run(self, tmp, task_vars)

# Generated at 2022-06-25 07:10:37.702136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:10:38.810497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:10:40.621433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()


# Generated at 2022-06-25 07:10:42.987030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    action_module_0.run(tmp=None, task_vars=None)



# Generated at 2022-06-25 07:10:55.360979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pass
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    assert isinstance(action_module_0, ActionModule, "Should be an instance of `ActionModule`")
    assert isinstance(action_module_0, object, "Should be an instance of `object`")


# Generated at 2022-06-25 07:10:59.993801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)



# Generated at 2022-06-25 07:11:06.532978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    assert(not action_module_0 == None)

# Generated at 2022-06-25 07:11:18.451769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    assert(action_module_0._task.action == str_0)
    assert(action_module_0._task.async_val == float_0)
    assert(action_module_0._task.async_poll_interval == dict_0)
    assert(action_module_0._task.async_seconds == dict_0)

# Generated at 2022-06-25 07:11:20.728202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:11:23.311011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() is None


# Generated at 2022-06-25 07:11:29.419573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:11:37.612604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '=&l\x0b#'
    float_0 = 401.89
    dict_0 = {str_0: float_0, float_0: float_0, str_0: str_0}
    dict_1 = {float_0: str_0, float_0: dict_0}
    str_1 = '\x18&H[\x1cg'
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_1, str_1, bool_0)



# Generated at 2022-06-25 07:11:39.903164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 07:11:42.198627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    var_0 = action_module_0.run(tmp = None, task_vars = None)
    return var_0


# Generated at 2022-06-25 07:11:55.606511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:12:00.432360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Arrange:')

    # Test for method run of class ActionModule
    print('Act:')

    test_case_0()

# Generated at 2022-06-25 07:12:05.254347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    name_module = 'module_name'
    name_module = 'module_name'
    name_module = 'module_name'
    name_module = 'module_name'
    name_module = 'module_name'
    name_module = 'module_name'
    action_module_0 = ActionModule(name_module, dict_module, dict_module, dict_module, str_module, bool_module)


# Generated at 2022-06-25 07:12:10.652342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    t_tmp = None
    t_task_vars = None
    action_module_0.run(t_tmp, t_task_vars)

# Generated at 2022-06-25 07:12:18.034122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '=dS8\x5cNp\x5b\x5bmb'
    float_0 = 416.45625
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    # need to implement test_run()
    return action_module_0



if __name__ == '__main__':
    action_module = test_ActionModule()
    print(action_module)
    print(action_module.run())

# Generated at 2022-06-25 07:12:23.073141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    var_0 = action_run(action_module_0)


# Generated at 2022-06-25 07:12:30.255376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    except AssertionError as e:
        print("AssertionError Occured in test_ActionModule(): "
              + str(e))
    except TypeError as e:
        print("TypeError Occured in test_ActionModule(): " +
              str(e))
        

# Generated at 2022-06-25 07:12:36.663164
# Unit test for constructor of class ActionModule
def test_ActionModule():
 
    list_0 = ['QF\x0c', '9$n', 't', '|', 'w']
    list_1 = ['V7', 'n', 'pM7*a9d', 'G.+', 'TK']
    bool_0 = False
    float_0 = 526.091
    float_1 = 887.797
    float_2 = 234.3181
    float_3 = 537.5194
    float_4 = 957.25
    float_5 = 560.0
    float_6 = 853.9255
    float_7 = 519.861
    float_8 = 889.0
    float_9 = 613.4
    float_10 = 564.6452
    float_11 = 738.3

# Generated at 2022-06-25 07:12:43.538243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)

# Generated at 2022-06-25 07:12:44.911862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp= None
    task_vars= None
    test_ActionModule= ActionModule(tmp, task_vars)
    assert test_ActionModule.__init__

# Generated at 2022-06-25 07:13:17.539859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)


# Generated at 2022-06-25 07:13:17.994039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:13:23.935329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '8'
    float_0 = 0.3626
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    var_0 = action_module_0.run()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:13:28.504833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    temp_0 = True
    dict_0 = {'temp_0': temp_0}
    action_module_0 = ActionModule(temp_0, temp_0, temp_0, temp_0, temp_0, temp_0)
    assert action_module_0.run(dict_0, dict_0) == dict_0


# Generated at 2022-06-25 07:13:32.625137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\\+\\+^\r)+Y]|\x0c'
    float_0 = 506.85726
    dict_0 = {float_0: str_0, float_0: str_0}
    dict_1 = {float_0: str_0, float_0: str_0}
    str_1 = '\\+\\+^\r)+Y]|\x0c'
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_1, str_1, bool_0)
    assert action_module_0 != None

# Generated at 2022-06-25 07:13:37.731917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_1 = 356.49062
    dict_1 = {float_1: str_1, float_1: str_1}
    action_module_1 = ActionModule(str_1, float_1, dict_1, dict_1, str_1, bool_1)



# Generated at 2022-06-25 07:13:39.103348
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Clear arguments for testing.
    test_run = ActionModule.run

    pass # Test case should not be passed.

# Generated at 2022-06-25 07:13:47.777292
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test constructor(name, connection, play_context, loader, templar, shared_loader_obj):

    name = 'test'
    connection = '1'
    play_context = '2'
    loader = '3'
    shared_loader_obj = '4'
    templar = '5'

    action_module = ActionModule(name,connection,play_context,loader,templar,shared_loader_obj)

    assert action_module.name == 'test'
    assert action_module.connection == '1'
    assert action_module.play_context == '2'
    assert action_module.loader == '3'
    assert action_module.shared_loader_obj == '4'
    assert action_module.templar == '5'


# Generated at 2022-06-25 07:13:51.631880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 356.49062
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    dict_0 = {float_0: str_0, float_0: str_0}
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, True)
    action_module_0.run()

# Generated at 2022-06-25 07:13:58.905033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    var_0 = action_module_0.run()

if __name__ == "__main__":
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 07:14:54.535389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.get_name == 'generic action plugin'
    assert isinstance(action_module_0.name, str)
    assert isinstance(action_module_0.task, dict)
    assert isinstance(action_module_0.task_vars, dict)

# Generated at 2022-06-25 07:15:05.009878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    assert action_module_0._task is dict_0
    assert action_module_0._connection is dict_0
    assert action_module_0._play_context is str_0
    assert action_module_0._loader is float_0
    assert action_module_0._templar is dict_0
    assert action_module_0._shared_loader_obj is float_0

# Generated at 2022-06-25 07:15:13.127529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    var_0 = action_module_0.run(float_0, dict_0)


# Generated at 2022-06-25 07:15:14.579667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:15:21.723079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[sMevvyF+v\x0c6@AG7BVwp'
    float_0 = 356.49062
    dict_0 = {float_0: str_0, float_0: str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)
    return True


# Generated at 2022-06-25 07:15:25.112901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert True == True



# Generated at 2022-06-25 07:15:28.434526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '5if5]#)'
    float_0 = 0.038808201
    dict_0 = {str_0: float_0, str_0: float_0}
    bool_0 = True
    return ActionModule(str_0, float_0, dict_0, dict_0, str_0, bool_0)

# Generated at 2022-06-25 07:15:35.606836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '_'
    float_1 = 0.318
    dict_1 = {float_1: str_1, str_1: str_1}
    dict_2 = {dict_1: str_1, str_1: str_1}
    str_2 = 'h'
    bool_0 = False
    action_module_1 = ActionModule(str_1, float_1, dict_1, dict_1, str_2, bool_0)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 07:15:38.752472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()



# Generated at 2022-06-25 07:15:43.230192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'shopping'
    float_0 = 9.4397
    str_1 = 'BZ6]G'
    bool_0 = True
    float_1 = 9.4397
    float_2 = 9.4397
    str_2 = 'BZ6]G'
    bool_1 = True
    action_module_0 = ActionModule(str_0, float_0, bool_0, bool_1, str_1, bool_0)
    str_3 = ''
    float_3 = 0
    bool_2 = False
    str_4 = ''
    bool_3 = False
    action_module_1 = ActionModule(str_3, float_3, bool_2, bool_3, str_4, bool_2)
    str_5 = ''
    float_4 = 0
