

# Generated at 2022-06-25 07:07:49.569063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '__init__')
    assert callable(ActionModule.__init__)
    ActionModule.__init__()


# Generated at 2022-06-25 07:07:53.930531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(bytes_0, list_0, set_0)
    assert (type(obj) == type(ActionModule(bytes_0, list_0, set_0)))


# Generated at 2022-06-25 07:07:55.467493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:07:59.409666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = 0
  test_case_0()
  for int_0 in range(16, 22, 7):
    try:
      test_case_0()
    except:
      pass
  else:
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:08:05.739319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    try:
        test_ActionModule()
    except Exception as e:
        print(e.message)
        print(e.args)
        print(e)

# Generated at 2022-06-25 07:08:10.675992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instance of class ActionModule
    obj = ActionModule()
    assert isinstance(obj, ActionModule)


# Generated at 2022-06-25 07:08:20.393096
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:08:20.986716
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-25 07:08:32.524540
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:08:42.148867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test simple case
    # Get root logger
    root = logging.getLogger()
    # Remove all handlers
    root.handlers = []
    # Create handler
    handler = logging.StreamHandler(sys.stdout)
    # Set level
    handler.setLevel(logging.DEBUG)
    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # Add formatter to handler
    handler.setFormatter(formatter)
    # Add handler to logger
    root.addHandler(handler)
    logger = logging.getLogger('ansible.runner.action_plugins.test_case_0.test_ActionModule_run.test_simple_case')
    list_0 = []
    bytes_0

# Generated at 2022-06-25 07:08:54.753767
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:09:04.848319
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:09:11.807454
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:09:22.074001
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:09:30.719617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    list_0 = [set_0, str_0, str_1]
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_1, str_2, set_0, list_0, bool_0)
    str_3 = ''
    str_4 = ''
    str_5 = ''
    list_1 = [set_0, str_3, str_4]
    str_6 = ''
    str_7 = ''
    action_module_1 = ActionModule(str_3, str_4, str_5, set_0, list_1, bool_0)
    str_8 = ''
    str_9 = ''
    str_10 = ''

# Generated at 2022-06-25 07:09:31.511306
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:09:32.258295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:09:42.276197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()

# Generated at 2022-06-25 07:09:49.422975
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:09:59.405088
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:10:11.092058
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:10:21.184500
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:10:32.476809
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:10:41.027905
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:10:47.515384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {1, 2, 3}

# Generated at 2022-06-25 07:10:51.013246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    construct_0 = ActionModule()
    print(construct_0)


# Generated at 2022-06-25 07:11:01.398694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()

# Generated at 2022-06-25 07:11:08.077849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'xIx7/F1T'
    str_1 = 'R8[LTW'
    str_2 = 'fDv]8q'
    set_0 = set()
    list_0 = [set_0, str_0, str_1]
    bool_0 = False
    action_module_0 = ActionModule(str_2, str_2, str_2, set_0, list_0, bool_0)
    task_vars = {}
    var_0 = action_module_0.run(task_vars=task_vars)

# Generated at 2022-06-25 07:11:18.042071
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:11:30.260186
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:11:45.634038
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:11:46.448039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1


# Generated at 2022-06-25 07:11:56.073328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # assert param is dict (z)
    # -- assume that dict is working
    # assert string is string (a)
    # -- assume that string is working
    # assert connection is instance of string (b)
    # -- assume that instance of string is working
    # assert host is string (c)
    # -- assume that string is working
    # assert task_vars is set (d)
    # -- assume that set is working
    # assert loader is list (e)
    # -- assume that list is working
    # assert play_context is bool (f)
    # -- assume that bool is working
    # ActionModule(z, a, b, c, d, e, f)
    pass


# Generated at 2022-06-25 07:11:58.105437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:12:07.724293
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:12:11.008339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule("Omar", "Redford", "Leslie", set([]), [set([])], False)


# Generated at 2022-06-25 07:12:18.957488
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:12:21.368552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    ansible_module = FakeAnsibleModule()
    with pytest.raises(NotImplementedError):
        action_module.run()


# Generated at 2022-06-25 07:12:28.620512
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:12:35.574315
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:13:08.853704
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:13:18.639908
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:13:24.572371
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:13:32.864319
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:13:39.422619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test ActionModule class.run...")
    set_0 = set()
    list_0 = [set_0, str_0, str_0]
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, list_0, bool_0)
    action_module_0.run(None, None)
    print("passed.")
    return 0

if __name__ == '__main__':
    count = test_ActionModule_run()
    print(count, "tests passed.")

# Generated at 2022-06-25 07:13:51.180541
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:14:00.259372
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:14:03.069533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    test_class = ActionModule()
    # Run method
    result = test_class.run()
    # AssertionError!


# Generated at 2022-06-25 07:14:09.740935
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:14:17.448764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = ['ansible.plugins.action.action_plugins']

# Generated at 2022-06-25 07:15:10.590265
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:15:20.557313
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:15:29.584198
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:15:38.398856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]

# Generated at 2022-06-25 07:15:44.018896
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:15:53.984435
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:16:00.745746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'module: shell'
    str_1 = 'test'
    str_2 = 'sh'
    set_0 = set()
    list_0 = [set_0, str_0, str_0, str_0]
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_1, str_0, set_0, list_0, bool_0)
    assert action_module_0 is not None
    assert action_module_0._connection is str_0
    assert action_module_0._module_args is str_0
    assert action_module_0._module_name is str_1
    assert action_module_0._module_opts is str_0
    assert action_module_0._supports_check_mode is bool_0
    assert action_

# Generated at 2022-06-25 07:16:09.716763
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:16:12.145040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:16:20.254391
# Unit test for constructor of class ActionModule