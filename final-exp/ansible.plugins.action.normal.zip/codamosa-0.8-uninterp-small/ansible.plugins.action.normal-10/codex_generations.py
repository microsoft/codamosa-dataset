

# Generated at 2022-06-25 07:08:00.029939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    int_0 = -64
    str_0 = '@'
    action_module_0 = ActionModule(bytes_0, dict_0, dict_0, int_0, str_0, dict_0)
    bytes_1 = None
    dict_1 = {bytes_1: bytes_1, bytes_1: bytes_1}
    dict_2 = {bytes_0: bytes_1, bytes_0: dict_1}
    dict_3 = {bytes_0: dict_1, bytes_0: bytes_1}
    action_module_0.run(bytes_1, dict_2)
    action_module_0.run(None, dict_3)


# Generated at 2022-06-25 07:08:08.653855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    dict_1 = {bytes_0: bytes_0, bytes_0: bytes_0}
    int_0 = -64
    str_0 = 'Ib'
    action_module_0 = ActionModule(bytes_0, dict_1, dict_1, int_0, str_0, dict_1)
    action_module_0._supports_async = True
    str_1 = 'f@'
    str_2 = 'w_'
    action_module_1 = ActionModule(bytes_0, dict_1, dict_1, int_0, str_0, dict_1)
    list_0 = ['f', '~']
    str_3 = 'i'

# Generated at 2022-06-25 07:08:13.928951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    int_0 = -64
    str_0 = '@'
    action_module_0 = ActionModule(bytes_0, dict_0, dict_0, int_0, str_0, dict_0)

    action_module_0.run()

# Generated at 2022-06-25 07:08:18.872213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    int_0 = -64
    str_0 = '@'
    action_module_0 = ActionModule(bytes_0, dict_0, dict_0, int_0, str_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 07:08:21.597058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert test_case_0() == None
    except AssertionError as e:
        print("Failed:", e)


# Generated at 2022-06-25 07:08:25.641941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 07:08:35.247312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    str_0 = 'w'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    int_0 = -64
    action_module_0 = ActionModule(bytes_0, dict_0, dict_0, int_0, str_0, dict_0)

    #Call the method
    result = action_module_0.run()

    assert result is not None

# Generated at 2022-06-25 07:08:44.455159
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:08:46.463055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None


# Generated at 2022-06-25 07:08:54.428225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0}
    int_0 = -64
    str_0 = '@'
    action_module_0 = ActionModule(bytes_0, dict_0, dict_0, int_0, str_0, dict_0)
    tmp_0 = None
    task_vars_0 = dict_0
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0['skipped'] == False

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 07:09:06.392734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a dummy context to use for testing
    context = {}
    context['provides'] = ['task_vars', 'tmp']

    # create a dummy task to use for testing
    task = {}
    task['action'] = 'setup'

    context['task'] = task

    # create a dummy configuration to use for testing
    config = {}
    config['action_plugins'] = '/Users/michael/projects/ansible/ansible/plugins/action'

    context['config'] = config

    # create a dummy variables to use for testing
    variables = {}
    variables['ansible_verbose'] = False

    # initialize the module with the dummy context
    # call the run method of the module

# Generated at 2022-06-25 07:09:08.242969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: write unit test for ActionModule
    # 	action_module_0 = ActionModule()
    pass

# Generated at 2022-06-25 07:09:11.729107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup

    action_module = ActionModule()

    # Execution

    # FIXME: action_module.run(tmp=None, task_vars=None)
    assert True

    # Assertion

    assert True


# Generated at 2022-06-25 07:09:13.199664
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert len(ActionModule.run.__func__.__code__.co_varnames) == 3

# Generated at 2022-06-25 07:09:18.442515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a ActionModule object
    action_module_1 = ActionModule()

    # Call method run of ActionModule object
    action_module_1.run()

if __name__ == '__main__':
    import sys
    import pytest

    sys.exit(pytest.main(["-s", __file__]))

# Generated at 2022-06-25 07:09:27.800836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = 'tmp_0'
    expected_result_0 = {'invocation': {'module_args': 'module_args_0'}, 'ansible_facts': {'ansible_facts_0': 'ansible_facts_0'}, 'changed': False, 'rc': 0, 'warnings': ['warnings_0', 'warnings_1'], 'stderr_lines': ['stder_lines_0'], 'warnings_lines': ['warnings_lines_0'], 'ansible_facts_lines': ['ansible_facts_lines_0'], 'stdout_lines': ['stdout_lines_0'], 'stderr': 'stderr_0'}

# Generated at 2022-06-25 07:09:30.989963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:09:31.863912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-25 07:09:37.158870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 07:09:42.305829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module_json_string = '{"_task":null,"_supports_check_mode":true,"_supports_async":true,"_shared_loader_obj":[]}'
    assert str(action_module) == action_module_json_string
    assert action_module._task == None
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module._shared_loader_obj == []


# Generated at 2022-06-25 07:09:50.754069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule: constructor")
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_run(action_module_0)

test_ActionModule()

# Generated at 2022-06-25 07:09:52.976371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:10:00.726446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = 1.0
    int_1 = -2198
    bool_2 = True
    bool_3 = True
    bool_4 = True
    bool_5 = False
    obj_0 = ActionModule(float_1, int_1, bool_2, bool_3, bool_4, bool_5)
    print(str(obj_0))
    print(str(obj_0))
    action_run()
    pass

if __name__ == "__main__":
    test_ActionModule()
    pass

# Generated at 2022-06-25 07:10:07.149320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Arguments of constructor : (1.0, -2198, True, True, True, True, False)
    if (___assertEqual(float_0, 1.0) and ___assertEqual(int_0, -2198) and ___assertEqual(bool_0, True) and ___assertEqual(bool_1, True) and ___assertEqual(action_module_0.async_val, True)):
        pass
    else:
        ___fail("Arguments of constructor : (1.0, -2198, True, True, True, True, False)")

test_case_0()
#test_ActionModule()

# Generated at 2022-06-25 07:10:13.699563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_run()
    if var_0 == false:
        print("OK")
    else:
        print("KO")

# Generated at 2022-06-25 07:10:20.044704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    # Fails test if constructor of class ActionModule does not
    #  set attribute _task to None
    assert var_0._task == None
    # Fails test if constructor of class ActionModule does not
    #  set attribute _supports_async to None
    assert var_0._supports_async == None
    # Fails test if constructor of class ActionModule does not
    #  set attribute _supports_check_mode to None
    assert var_0._supports_check_mode == None


# Generated at 2022-06-25 07:10:21.298310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:10:25.100773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_object = ActionModule()
    assert isinstance(action_module_object, ActionModule)
    print("Passed: ActionModule constructor test case")


# Generated at 2022-06-25 07:10:29.366709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    del action_module_0

# Generated at 2022-06-25 07:10:33.638596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:10:46.572381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Can't use assertIsNone since it would NOT work in Python 2.6
    assert run() == None

if __name__ == "__main__":
    import sys
    import traceback
    try:
        main()
    except:
        tb = sys.exc_info()
        traceback.print_tb(tb[2])

# Generated at 2022-06-25 07:10:53.580266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:10:56.072797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = test_case_0()

# Generated at 2022-06-25 07:10:56.627010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:10:59.780322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:11:00.272827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:11:06.809051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 20.66932
    int_0 = -17576
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    task_vars = {}
    var_0 = action_module_0.run(task_vars)
    assert var_0 == None, "%s != None" % var_0

# Generated at 2022-06-25 07:11:14.644882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_module_0.run()
    var_1 = action_run()

# Generated at 2022-06-25 07:11:17.896731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.048478033104
    int_0 = -388100258
    bool_0 = False
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)


# Generated at 2022-06-25 07:11:25.764860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    assert action_module_0 is not None
    var_0 = action_run()

# Generated at 2022-06-25 07:11:42.520514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._supports_check_mode is True
    assert action_module_0._supports_async is True

# Generated at 2022-06-25 07:11:46.512197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    unit_test_0 = ActionModule()


# Generated at 2022-06-25 07:11:48.226471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:11:50.638838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:11:55.493605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {
        'invocation': {
            'module_args': ''
        }
    }
    int_0 = -1560
    bool_0 = True
    # TODO: shit it's not working
    action_module_0 = ActionModule()
    var_1 = action_module_0.run(var_0, int_0, bool_0)

# Generated at 2022-06-25 07:12:02.776929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    action_module_0.run()
    var_0 = action_run()



# Generated at 2022-06-25 07:12:10.159576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    # ?
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    result_0 = None
    if (result_0):
        result_0 = None
    result_0
    var_0 = None
    var_1 = False
    var_2 = True
    # ?
    action_module_0 = ActionModule(var_0, var_1, var_2, var_1, var_2, var_2)
    var_0 = 'setup'
    if (var_0 in C._ACTION_SETUP):
        var_0 = True
    else:
        var_0
    # assert ? == var_0
    var_2 = False
    var_3 = True
    # assert

# Generated at 2022-06-25 07:12:12.565425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    # instantiate an object of class ActionModule
    action_module_0 = ActionModule(float_0)
    # debug to verify instance variables were set
    action_module_0._supports_check_mode = True
    action_module_0._supports_async = True


# Generated at 2022-06-25 07:12:15.229297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run()')

    action_module_0 = ActionModule()
    assert not action_module_0.run()

    print('Done!')

# Generated at 2022-06-25 07:12:17.411468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:12:43.720075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 1.0
    var_1 = -2198
    var_2 = True
    var_3 = True
    var_4 = True
    var_5 = False
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)


# Generated at 2022-06-25 07:12:47.610044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_run()

    assert var_0 is not None, "Cannot find expected result"

# Generated at 2022-06-25 07:12:50.367137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (action_module_0.get_internal_port == 3)
    assert (action_module_0.get_router_type == "")


# Generated at 2022-06-25 07:12:55.755988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)

# Generated at 2022-06-25 07:13:05.686518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    assert action_module_0.module_name == 'action', "Members can be assigned"
    assert action_module_0.action == 'action', "Members can be assigned"
    assert action_module_0.module_execution == 'hardcoded', "Members can be assigned"
    assert action_module_0.static == '/tmp', "Members can be assigned"


# Generated at 2022-06-25 07:13:10.671531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    assert action_module_0.task is not None
    assert action_module_0.connection is not None
    assert action_module_0.play_context is not None
    assert action_module_0.loader is not None
    assert action_module_0.templar is not None
    assert action_module_0.shared_loader_obj is not None


# Generated at 2022-06-25 07:13:17.316305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    action_run(action_module_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:13:19.422889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    action_module_0 = ActionModule(bool_0)
    var_0 = isinstance(action_module_run(action_module_0), dict)
    assert var_0

# Generated at 2022-06-25 07:13:21.364708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule()")
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:13:29.442099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._task == None
    assert action_module_0._connection == None
    assert action_module_0._play_context == None
    assert action_module_0._loader == None
    assert action_module_0._templar == None
    assert action_module_0._shared_loader_obj == None
    assert action_module_0._action == None
    assert action_module_0._playbook == None
    assert action_module_0._play_context == None
    assert action_module_0._task_vars == None
    assert action_module_0._task_vars == None
    assert action_module_0._loaded_vars_files == None
    assert action_module_0._task_vars == None
    assert action_module_0

# Generated at 2022-06-25 07:14:29.972550
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:14:32.230658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule(1.0, -2198, True, True, True, True)
    print(var_0)


# Generated at 2022-06-25 07:14:35.881811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        raise Exception('Exception')
    except:
        # OK, we're in a test.
        assert False, 'UnitTest failed.  Test generated exception'

# Generated at 2022-06-25 07:14:39.269650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    # Test that the constructor uses the class attributes correctly
    assert action_module_0.root_uuid_or_disk_id == 123
    assert action_module_0.in_migration == True
    assert action_module_0.task_vars is None
    assert action_module_0.action == 123
    assert action_module_0.transport == "file"
    assert action_module_0.connection is None
    assert action_module_0.play_context is None
    assert action_module_0.remote_user == "test"
    assert action_module_0.remote_pass == "test"
    assert action_module_0.remote_port == "test"
    assert action_module_0.remote_addr == "test"

# Generated at 2022-06-25 07:14:41.471713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert( isinstance( action_module_0, ActionBase ) )
    assert( action_module_0 != None )


# Generated at 2022-06-25 07:14:48.514410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ####
    #action_module_0 = ActionModule(1.0, -2198, True, True, True, True)
    #action_module_0.run()

    #assert action_module_0._task._connection._shell.expect_command.call_count == 0

    ####
    #action_module_0 = ActionModule(1.0, -2198, True, True, True, True)
    #action_module_0.run()

    #assert action_module_0._task._connection._shell.expect_command.call_count == 0
    assert True


# Generated at 2022-06-25 07:14:51.772854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)


# Generated at 2022-06-25 07:14:52.573381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 07:14:55.419366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    test_case_0()

# Generated at 2022-06-25 07:14:56.420166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:17:09.787530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    # action_module_0.run()
    return

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:17:15.121036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_module_0.run(tmp=None, task_vars=None)
    assert var_0.get('foo') == 'bar'

# Generated at 2022-06-25 07:17:19.404499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule(0, 0, False, False, False, False)
    # Class variable test_cases_2
    test_case_2 = []
    test_case_2.append(0)
    test_case_2.append(0)
    test_case_2.append(False)
    test_case_2.append(False)
    test_case_2.append(False)
    
    test_case_2.append(False)
    action_module_2 = ActionModule(*test_case_2)
    # Class variable test_cases_3
    test_case_3 = []
    test_case_3.append(0)
    test_case_3.append(0)
    test_case_3.append(False)
    test_case_3.append(False)

# Generated at 2022-06-25 07:17:20.901621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(1.1, -26, True, True, True, True)
    test_case_0()

# Generated at 2022-06-25 07:17:26.526071
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_module_0.run()
    return var_0

# Generated at 2022-06-25 07:17:34.922718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_run()
    var_1 = method_0()
    try:
        result_0 = action_module_0.run(var_0, var_1)
        assert result_0 == None
    except Exception as exception_0:
        print(exception_0)

# Generated at 2022-06-25 07:17:43.661863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    tmp = None
    var_0 = action_module_0.run(tmp)
    var_1 = action_module_0.run(tmp)
    assert var_1 == 'test'
    assert var_0 == var_1


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:17:45.968603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.0
    int_0 = -2198
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, int_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_run()