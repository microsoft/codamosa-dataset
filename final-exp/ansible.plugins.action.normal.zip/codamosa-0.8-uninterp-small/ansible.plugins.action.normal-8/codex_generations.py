

# Generated at 2022-06-25 07:07:57.734510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -225
    bytes_0 = b'\x9d\x10uh\xad,\\\xd7\x99\x18'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, int_0, dict_0, bytes_0, int_0, tuple_0)
    assert action_module_0.run() == {}

# Generated at 2022-06-25 07:08:03.678106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -225
    bytes_0 = b'\x9d\x10uh\xad,\\\xd7\x99\x18'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, int_0, dict_0, bytes_0, int_0, tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:08:05.112992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -735
    action_module_0 = ActionModule(int_0)



# Generated at 2022-06-25 07:08:09.832706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -225
    bytes_0 = b'\x9d\x10uh\xad,\\\xd7\x99\x18'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, int_0, dict_0, bytes_0, int_0, tuple_0)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:19.653386
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Variables for testing here
    int_0 = -225
    bytes_0 = b'\x9d\x10uh\xad,\\\xd7\x99\x18'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()

    # Tests here
    test_case_0()
    # check if instance(action_module_0, ActionModule)
    # check if action_module_0.run() is not undefined
    # check if action_module_0.action() is not undefined
    # check if action_module_0.display.deprecated() is not undefined
    # check if action_module_0.connection_name() is not undefined
    # check if action_module_0.display.deprecated() is not undefined
    # check if action_module_0.bypass_

# Generated at 2022-06-25 07:08:20.910326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# End of file

# Generated at 2022-06-25 07:08:32.233097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -225
    bytes_0 = b'\x9d\x10uh\xad,\\\xd7\x99\x18'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, int_0, dict_0, bytes_0, int_0, tuple_0)
    dict_0 = {}
    dict_1 = {'module': 'test'}
    dict_0['task_vars'] = dict_1
    tuple_1 = (dict_0, dict_0)
    dict_0 = {}
    dict_0['v'] = dict_1
    dict_1 = {}
    dict_1['task_vars'] = dict_0

# Generated at 2022-06-25 07:08:40.999758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -354
    bytes_0 = b'\x9f\x15\x1f\x86\x16\x17q\xe3\x8f\xcc\x12\x1b\x8f\xe3\xab\xb6\xd2\xa1\x16\xbd\x18\x9c\x8b\xa4\x17\x9744\xa4<\x10\x1a\x02M\x84\xf7\x9d\x1e\x1f\x04t\x0e\xa4\x04\x02'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()

# Generated at 2022-06-25 07:08:52.540593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1289183740
    bytes_0 = b'\xb1\x9d\x05\x8a\x1e\x82\x03\x02\xb8\xfd\xf0\x9b\x97\x1a\xfa\xde\x11\xb0\xfa\xac\x90\x82\x1b'
    dict_0 = {bytes_0: bytes_0}
    bytes_1 = b'\x9b\xf9\x00\xfc\x86\x01\xf2\x1e\x1c\xd8\x84p<\x14\x1a\x8e\x84\x0b\xf0\xe5$\x9c\x9d\xf4\x12'
    dict

# Generated at 2022-06-25 07:08:59.419676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -225
    bytes_0 = b'\x9d\x10uh\xad,\\\xd7\x99\x18'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, int_0, dict_0, bytes_0, int_0, tuple_0)


if __name__ == '__main__':
    # bit of a hack, but not sure how to test otherwise
    # keeps stderr empty and prevents output to stdout
    # used by pytest
    try:
        test_case_0()
        test_ActionModule()
        print("TEST SUCEEDED")
    except:
        print("TEST FAILED")

# Generated at 2022-06-25 07:09:06.988530
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test case of constructor
    test_case_0()


# Generated at 2022-06-25 07:09:11.975221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # try to run the class constructor, no exception should be raised
    try:
        test_case_0()
    except:
        # if there is an exception, print it out
        import traceback
        traceback.print_exc()
        # return 1 to indicate the test has failed
        return 1
    # if the test succeeds, return 0
    return 0

# run the unit test
exit_val = test_ActionModule()
exit(exit_val)

# Generated at 2022-06-25 07:09:18.525742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test: Constructor of class ActionModule")
    int_0 = -747
    action_module_0 = ActionModule(int_0)
    assert(isinstance(action_module_0, ActionModule))
    assert(action_module_0.run(None, None) == {})

    print("Unit test for class ActionModule complete")


# TEST_CASE_0:
test_case_0()
# TEST: Constructor of class ActionModule
test_ActionModule()

# Generated at 2022-06-25 07:09:27.869020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args_0 = ''
    int_0 = -735
    args_1 = ''
    test_case_0(int_0)
    action_module_0 = ActionModule(args_0)
    test_case_0(None)
    action_module_1 = ActionModule(args_0)
    test_case_0(int_0)
    action_module_2 = ActionModule(args_0, nargs_0=1)
    test_case_0(int_0)
    action_module_3 = ActionModule(args_0, nargs_0=1)
    test_case_0(int_0)
    action_module_4 = ActionModule(args_0, nargs_0=1)
    test_case_0(int_0)

# Generated at 2022-06-25 07:09:37.474229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -47
    dict_0 = {}
    dict_0['invocation'] = {}
    dict_0['invocation']['module_args'] = "Kj$"
    dict_0['_ansible_verbose_override'] = True
    dict_1 = {}
    dict_0['host_name'] = 'a1'
    dict_0['changed'] = True
    dict_0['invocation'] = dict_1
    dict_0['invocation']['module_args'] = "fsD"
    dict_0['_ansible_verbose_override'] = True
    dict_2 = {}
    dict_0['host_name'] = 'a1'
    dict_0['changed'] = True
    dict_0['invocation'] = dict_2

# Generated at 2022-06-25 07:09:39.763068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _0 = -869
    _1 = -131

    # Pass
    assert (ActionModule(_0) != None)

    # Pass
    assert (ActionModule(_1) != None)


# Generated at 2022-06-25 07:09:48.340147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -735
    action_module_0 = ActionModule(int_0)
    task_vars_0 = dict()
    str_0 = action_module_0.run(None, task_vars_0)
    assert isinstance(str_0, dict)
    assert str_0['skipped'] == False
    assert str_0['failed'] == False
    assert str_0['invocation']['module_name'] == 'command'
    assert isinstance(str_0, dict)
    assert str_0['changed'] == False
    assert str_0['warnings'] == []
    assert str_0['msg'] == 'non-zero return code'
    assert str_0['failed'] == False
    assert str_0['invocation']['module_name'] == 'command'
    assert str

# Generated at 2022-06-25 07:09:52.603007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -735
    action_module_0 = ActionModule(int_0)


# Generated at 2022-06-25 07:09:57.525993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {}
    action_module_0 = ActionModule(0)
    ret = action_module_0.run(tmp, task_vars)



# Generated at 2022-06-25 07:10:02.859796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Run the unit tests
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:10:07.208687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule()
    assert test is not None


# Generated at 2022-06-25 07:10:08.323271
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_case_0()

# Generates test suites

# Generated at 2022-06-25 07:10:11.468258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = dict()
    test_case_0(task_vars, tmp)

# Generated at 2022-06-25 07:10:16.365353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Function for testing constructor of ActionModule class"""
    if __name__ == '__main__':
        test_case_0()
    return 0


# Generated at 2022-06-25 07:10:19.607850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0


# Generated at 2022-06-25 07:10:23.183957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Complete this unit test
    module = ActionModule()
    module.run(tmp = None, task_vars = None)
    assert True


# Generated at 2022-06-25 07:10:27.112523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test signature
    int_0 = 0
    dict_0 = dict()
    dict_1 = dict()

    obj = ActionModule()
    assert isinstance(obj.run(int_0,dict_0,dict_1),dict)

    # test attributes

# Generated at 2022-06-25 07:10:28.032050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 07:10:31.451738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module != None


# Generated at 2022-06-25 07:10:34.236348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(connection=connection)
    action_module.run(tmp=tmp)


# Generated at 2022-06-25 07:10:41.026345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    tmp = None
    task_vars = None
    action_module.run(tmp, task_vars)
    return


# Generated at 2022-06-25 07:10:42.022907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert isinstance(result, ActionModule)



# Generated at 2022-06-25 07:10:42.875528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:10:44.229522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule() != None)


# Generated at 2022-06-25 07:10:45.999989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    int_1 = 1
    instance = ActionModule()


# Generated at 2022-06-25 07:10:47.284941
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Test Call
  test_case_0()

# Generated at 2022-06-25 07:10:51.472666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:11:00.753299
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:11:03.285184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule() is not None


# Generated at 2022-06-25 07:11:07.038638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_task_vars = {  }
    fake_str = ""
    fake_bool = True
    fake_int = 0
    fake__task = {  }
    fake_connection = {  }
    fake_connections = {  }
    fake__invocation = {  }
    fake_self = { '_task': fake__task, '_connection': fake_connection, '_connections': fake_connections, '_invocation': fake__invocation, }
    fake_tmp = None
    expected_result = ActionModule.run(fake_self, fake_tmp, fake_task_vars)
    assert expected_result == None


# Generated at 2022-06-25 07:11:21.113314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with patch('ansible.plugins.action.vars.ActionModule._execute_module'):
        with patch('ansible.plugins.action.vars.ActionModule._remove_tmp_path'):
            with patch('ansible.plugins.action.vars.super'):
                vars = {'ansible_connection':
                        {'has_native_async': False,
                         '_shell': {'tmpdir': '/tmp'},
                         'module_provision': False}}
                task_vars = {'ansible_check_mode': False,
                             'ansible_module_generated': True,
                             'ansible_module_name': 'setup'}
                obj = ActionModule(task_vars, vars)
                a = obj.run()
                assert obj._supports_check_mode == True
               

# Generated at 2022-06-25 07:11:27.304705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test method run of class ActionModule")
    play_context = PlayContext()
    task = Task()
    task.async_val = 0
    connection = Connection()
    connection.has_native_async = 0
    action_module = ActionModule()
    action_module._task = task
    action_module._connection = connection
    result = action_module.run()
    assert result == {}


# Generated at 2022-06-25 07:11:30.231844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ck_0 = ActionModule()
    int_0 = 0
    ck_0.run(tmp=int_0)

# Generated at 2022-06-25 07:11:36.416558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # Calling a constructor from base class
    action_base_obj = ActionBase()
    
    # Calling a constructor from class ActionModule with parameters
    action_module_obj = ActionModule(action_base_obj, 'action_module')

    # Unit test implementation

# Generated at 2022-06-25 07:11:39.828221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    print ("Test is finished successfully")


# Generated at 2022-06-25 07:11:43.158637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of class ActionModule
    test = ActionModule(task=test_case_0)
    task = test_case_0
    test = ActionModule(task)


# Generated at 2022-06-25 07:11:48.380883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an object
    obj = ActionModule(1, 2)

    # Run method of object
    obj.run(3, 4)

    # Return the result
    return

# Generated at 2022-06-25 07:11:56.202575
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # initialize a dict to store task_vars
    task_vars_value = {}

    # initialize a dict to store tmp
    tmp_value = {}

    # initialize a ActionModule obj
    actionmodule_obj = ActionModule(connection=None,
                                                task_uuid=None,
                                                loader=None,
                                                templar=None,
                                                shared_loader_obj=None)

    # run method without parameters, use default values
    actionmodule_obj.run(tmp_value, task_vars_value)

# Generated at 2022-06-25 07:11:59.293684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0


# Generated at 2022-06-25 07:12:02.877593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    # get a test example for var 'tmp'
    tmp = test_case_0()
    # get a test example for var 'task_vars'
    task_vars = test_case_0()
    # call function run with args (tmp, task_vars)
    am.run(tmp, task_vars)


# Generated at 2022-06-25 07:12:17.544199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0:
    test_var = input('Enter your test value please: ')
    test_case_0()

# test_ActionModule()

# Generated at 2022-06-25 07:12:22.792482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_object = ActionModule()

    # Test for case insensitivity in choice
    test_case_0()

    # Test for case insensitivity in choice
    # Test for the branch where wrap_async is False
    test_case_0()

    # Test for case insensitivity in choice
    # Test for the branch where wrap_async is False
    test_case_0()

    # Test for case insensitivity in choice
    # Test for the branch where wrap_async is False
    test_case_0()

# Generated at 2022-06-25 07:12:24.128464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 07:12:27.645624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod.run()


# Generated at 2022-06-25 07:12:31.584952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    test_case_0()
    test = ActionModule(tmp_0, task_vars_0)
    assert isinstance(test, ActionModule)
    assert test.run() is not None

test = ActionModule(None, None)
test.run()

# Generated at 2022-06-25 07:12:34.369400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arguments = {}
    arguments['tmp'] = None
    arguments['task_vars'] = None
    returnval = test_case_0()
    return returnval

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:12:35.291614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_1 = ActionModule()


# Generated at 2022-06-25 07:12:37.367565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(module_name='module_name')
    assert action_module.run(tmp=10, task_vars=50) == 0


# Generated at 2022-06-25 07:12:38.360426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None

# Generated at 2022-06-25 07:12:49.213212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_pattern = '*'
    config_file = './test_ansible_config.cfg'
    connection = 'smart'
    forks = 5
    module_name = 'setup'
    private_key_file = '/Users/danielmsheehan/.ssh/keys/id_rsa'
    look_for_keys = 'True'
    remote_user = 'dms'
    verbosity = 5
    ansible_python_interpreter = '/usr/local/bin/python2.7'

    C.DEFAULT_HOST_LIST         = host_pattern
    C.DEFAULT_HOST_LIST         = host_pattern
    C.DEFAULT_MODULE_NAME        = module_name
    C.DEFAULT_MODULE_PATH        = None
    C.DEFAULT_MODULE_SYNTAX     

# Generated at 2022-06-25 07:13:25.636341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a != None


# Generated at 2022-06-25 07:13:26.886113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:13:30.424881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        _action_module_0 = ActionModule()
        assert True, "Exception not thrown"
    except NotImplementedError:
        assert True
    except:
        assert False, "unexpected exception thrown"
    finally:
        raise NotImplementedError

if __name__ == '__main__':
    """
    Test for test_ActionModule
    """
    test_ActionModule()

# Generated at 2022-06-25 07:13:31.256210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:13:39.068316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.playbook.task import Task
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.executor.playbook_executor import PlaybookExecutor
  from ansible.inventory.manager import InventoryManager

  # Create a ActionModule object
  actionModule_0 = ActionModule(Task(), TaskQueueManager(None, PlaybookExecutor, InventoryManager))

  # Call method run of ActionModule object
  result = actionModule_0.run()
  print("run result is ", result)


# Main function
if __name__ == "__main__":
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 07:13:41.921448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # For each test case print out all the variables created after the test
    print ("\n")
    action_module = ActionModule()
    _result = action_module.run(1, 2)
    print ("_result: ", _result)
    print ("\n")

# Generated at 2022-06-25 07:13:49.331281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_0 = Ansible()
    task_vars_0 = test_case_0()
    action_base_0 = ActionBase(ansible_0, 'test_ActionModule', task_vars_0)
    action_module_0 = ActionModule(ansible_0, 'test_ActionModule', task_vars_0, action_base_0)
    assert(action_module_0._supports_check_mode == True)
    assert(action_module_0._supports_async == True)


# Generated at 2022-06-25 07:14:00.130231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new instance of ActionModule
    actionModule = ActionModule()
    # Check if actionModule is an instance of class ActionModule
    if not isinstance(actionModule, ActionModule):
        print("test_ActionModule(): FAIL")
        return
    # Check if actionModule is an instance of class ActionBase
    if not isinstance(actionModule, ActionBase):
        print("test_ActionModule(): FAIL")
        return
    # Check if actionModule's run() method is available
    if not callable(actionModule.run):
        print("test_ActionModule(): FAIL")
        return
    # Run run() method
    if not actionModule.run() == None:
        print("test_ActionModule(): FAIL")
        return
    print("test_ActionModule(): PASS")
    return


# Generated at 2022-06-25 07:14:00.819446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()


# Generated at 2022-06-25 07:14:02.880093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:14:32.090375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    tmp = None
    task_vars = None
    action_module = ActionModule(int_0, int_0, int_0)
    result = action_module.run(tmp, task_vars)

# Generated at 2022-06-25 07:14:35.029442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Unit test of ActionModule constructor")
    test_case_0()
    print("End of unit test")


# Generated at 2022-06-25 07:14:36.489431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:14:39.535027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule::run")

    # Set up test data
    wrap_async = True
    task_vars = {}

    # Create a mock object to track calls
    test = ActionModule()
    test.run(task_vars, wrap_async)

# Generated at 2022-06-25 07:14:41.200145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module_0 = ActionModule()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:14:46.556871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Generator which allows us to repeatedly test the body of the run method without having to re-create the instance.
    """
    while True:
        tmp = None
        task_vars = None

        # Test code goes here
        test_case_0()

        yield

# Generated at 2022-06-25 07:14:48.905898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    test_action_module_instance = ActionModule()
    test_action_module_instance.tmp = None
    test_action_module_instance.task_vars = None
    # Call the method
    test_action_module_instance.run()
    # Check results

# Generated at 2022-06-25 07:14:56.046299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {'var_0': 0, 'var_1': 1, 'var_2': 2}
    tmp_0 = ActionModule._remove_tmp_path(ActionModule._connection._shell.tmpdir)
    tmp_1 = {'var_0': 0, 'var_1': 1, 'var_2': 2}
    task_vars_1 = {'var_0': 0, 'var_1': 1, 'var_2': 2}
    tmp_2 = ActionModule._remove_tmp_path(ActionModule._connection._shell.tmpdir)
    tmp_3 = {'var_0': 0, 'var_1': 1, 'var_2': 2}
    task_vars_2 = {'var_0': 0, 'var_1': 1, 'var_2': 2}


# Generated at 2022-06-25 07:14:56.952514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()


# Generated at 2022-06-25 07:15:01.254050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule()
    except Exception:
        test_case_0()
    else:
        if action_module is None:
            test_case_0()

# Generated at 2022-06-25 07:16:14.540306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 07:16:16.294533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(connection='connection',
                                 play_context='play_context',
                                 loader='loader',
                                 templar='templar',
                                 shared_loader_obj='shared_loader_obj')
    assert action_module is not None


# Generated at 2022-06-25 07:16:18.386855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actmodule = ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:16:21.575342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()


# Generated at 2022-06-25 07:16:22.034206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:16:25.262707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 1
    int_0 = 0
    t = ActionModule(int_0)
    assert type(t) == ActionModule
    # Test case 2
    d = {'ONE':'1', 'TWO':'2', 'THREE':'3'}
    t = ActionModule(d)
    assert d == t

# Generated at 2022-06-25 07:16:26.405354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    testclass = ActionModule()
    testclass.run()


# Generated at 2022-06-25 07:16:27.119697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0


# Generated at 2022-06-25 07:16:29.166457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    params = dict()
    action_module_obj = ActionModule(task = dict(), connection = dict(), play_context = dict(), loader = None, templar = None, shared_loader_obj = None)


# Generated at 2022-06-25 07:16:33.450806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    action_module = ActionModule()
    int_0 = action_module.run()
