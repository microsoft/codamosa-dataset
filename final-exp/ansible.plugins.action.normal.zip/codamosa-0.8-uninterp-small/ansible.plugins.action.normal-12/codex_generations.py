

# Generated at 2022-06-25 07:07:57.773540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = None
    list_0 = [bytes_0, bytes_0, bytes_0]
    set_0 = set()
    str_0 = '6D1Q\\'
    action_module_0 = ActionModule(list_0, set_0, list_0, set_0, list_0, str_0)


# Generated at 2022-06-25 07:08:02.652935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = None
    list_0 = [bytes_0, bytes_0, bytes_0]
    set_0 = set()
    str_0 = '6D1Q\\'
    action_module_0 = ActionModule(list_0, set_0, list_0, set_0, list_0, str_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:08:06.401139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [None, '', '', '']
    set_0 = set()
    str_0 = '6D1Q\\'
    assert ActionModule(list_0, set_0, list_0, set_0, list_0, str_0).result == None


# Generated at 2022-06-25 07:08:11.504603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # c_0 is an instance of class ActionModule
    c_0 = ActionModule()
    assert c_0 is not None
    assert isinstance(c_0, ActionModule)


# Generated at 2022-06-25 07:08:12.625702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:08:22.078938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['skipped'] = True
    str_0 = '2\\A\\'
    dict_0['invocation']['module_args'] = str_0
    dict_1 = dict()
    dict_0['invocation'] = dict_1
    dict_0['invocation'] = dict_1
    dict_0['invocation']['module_args'] = str_0
    dict_0['invocation'] = dict_1
    dict_2 = dict()
    dict_0['invocation'] = dict_2
    dict_1['module_args'] = str_0
    dict_0['invocation'] = dict_1
    dict_1['module_args'] = str_0
    dict_0['invocation'] = dict_1

# Generated at 2022-06-25 07:08:28.505273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Module_0:
        def __init__(self, result=None, invocation=None, module_name='', module_args='', remote_user='', tmp=None):
            self.result = result
            self.invocation = invocation
            self.module_name = module_name
            self.module_args = module_args
            self.remote_user = remote_user
            self.tmp = tmp

    class Module_1:
        def __init__(self, result=None, invocation=None, module_name='', module_args='', remote_user='', tmp=None):
            self.result = result
            self.invocation = invocation
            self.module_name = module_name
            self.module_args = module_args
            self.remote_user = remote_user
            self.tmp = tmp


# Generated at 2022-06-25 07:08:37.814575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    list_0 = [bytes_0, bytes_0, bytes_0]
    set_0 = set()
    dict_0 = dict()
    str_0 = '6D1Q\\'
    action_module_0 = ActionModule(list_0, set_0, list_0, set_0, list_0, str_0)
    dict_1 = dict()
    dict_2 = dict()
    dict_2['invocation'] = dict()
    dict_1['module_args'] = dict_2
    dict_0['invocation'] = dict_1
    dict_3 = dict()
    dict_3['invocation'] = dict_2
    dict_4 = dict()
    dict_4['module_args'] = dict_1
    dict_0['invocation'] = dict_

# Generated at 2022-06-25 07:08:43.537607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Representation of variable task_vars from test case test_case_0
    task_vars = None
    bytes_0 = None
    list_0 = [bytes_0, bytes_0, bytes_0]
    set_0 = set()
    str_0 = '6D1Q\\'
    action_module_0 = ActionModule(list_0, set_0, list_0, set_0, list_0, str_0)
    result = action_module_0.run(task_vars)

# Generated at 2022-06-25 07:08:45.952599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Module was not called
    action_module_0 = ActionModule()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:56.698545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_1 = dict()
    list_0 = list()
    list_1 = list()
    bytes_0 = b':\x1eK'
    str_0 = "&'.K"
    str_1 = "&'.K"
    float_0 = 23.12
    float_1 = 23.12
    tuple_0 = (dict_1, list_1, bytes_0, dict_1, list_1)
    ActionModule(list_0, str_0, str_0, bytes_0, float_0, dict_0)
    ActionModule(tuple_0, str_1, str_1, bytes_0, float_1, dict_1)


# Generated at 2022-06-25 07:09:01.947966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    action_module_1.run()

# Generated at 2022-06-25 07:09:04.185155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:09:13.825656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    bool_0 = False
    instance_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    instance_1 = ActionModule(list_0, tuple_0, list_0, instance_0, list_0, bytes_0)
    assert isinstance(instance_0, ActionModule) == True
    assert isinstance(instance_1, ActionModule) == True


# Generated at 2022-06-25 07:09:16.711510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)


# Generated at 2022-06-25 07:09:26.569863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = None
    dict_0 = {float_1: float_1}
    tuple_0 = (dict_0,)
    list_0 = [float_1, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_0 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_0, dict_0)
    var_0 = action_run(list_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    var_1 = action_module_1.run()
    var_2 = action

# Generated at 2022-06-25 07:09:32.188311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '&'
    bool_0 = False
    bytes_0 = b'y\xaa)\x7f'
    float_1 = 1162.909
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:09:42.276941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_2 = None
    dict_1 = {float_2: float_2}
    tuple_1 = (dict_1,)
    list_1 = [float_2, tuple_1]
    str_1 = '\t>&\\_H'
    bool_1 = False
    bytes_1 = b'lDs'
    float_3 = 3608.275348
    action_module_2 = ActionModule(tuple_1, str_1, bool_1, bytes_1, float_3, dict_1)
    var_2 = action_run(list_1)
    action_module_3 = ActionModule(list_1, tuple_1, list_1, action_module_2, list_1, bytes_1)
    var_3 = action_module_3.run()


# Generated at 2022-06-25 07:09:48.551540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # Setup
        float_0 = None
        dict_0 = {float_0: float_0}
        tuple_0 = (dict_0,)
        list_0 = [float_0, tuple_0]
        str_0 = '\t>&\\_H'
        bool_0 = False
        bytes_0 = b'lDs'
        float_1 = 3608.275348
        action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
        
        # Invocation
        var_0 = action_module_0.run()
        
        # Verification
        assert var_0 is None
    except Exception:
        raise
    else:
        pass
    finally:
        # Teardown
        pass

# Generated at 2022-06-25 07:09:52.831359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = test_case_0()
    assert var_0 == True

# Generated at 2022-06-25 07:10:09.040926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create test object
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    var_0 = action_run(list_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    # Perform test
    var_1 = action_module_

# Generated at 2022-06-25 07:10:15.522444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(dict_0, str_0, bool_0, bytes_0, float_1, dict_0)

if __name__ == "__main__":
    try:
        test_case_0()
    except KeyError:
        print("KeyError")

# Generated at 2022-06-25 07:10:17.309822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as exception_0:
        print(exception_0)

test_ActionModule()

# Generated at 2022-06-25 07:10:21.876790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(dict_0, list_0, dict_0, dict_0, dict_0, dict_0)
    print(action_module_0.run())
    action_module_1 = ActionModule(tuple_0, list_0, dict_0, dict_0, dict_0, dict_0)
    print(action_module_1.run())


# Generated at 2022-06-25 07:10:23.341845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except:
        print("Exception in test_ActionModule_run")
        assert False

# Generated at 2022-06-25 07:10:24.802209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:10:34.236274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    var_0 = action_run(list_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    var_1 = action_module_1.run()

# Generated at 2022-06-25 07:10:36.486984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test 0
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 07:10:43.657247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    return action_module_0


# Generated at 2022-06-25 07:10:49.727542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    test_case_0()


# Generated at 2022-06-25 07:11:05.429165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    var_2 = action_module_2.run()

# Testing method run of class ActionModule with static data

# Generated at 2022-06-25 07:11:13.415343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    var_0 = action_run(list_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    var_1 = action_module_1.run()

# Generated at 2022-06-25 07:11:20.939863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    var_0 = action_module_1.run()



# Generated at 2022-06-25 07:11:21.869122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance_ActionModule = ActionModule()
    instance_ActionModule.run()

# Generated at 2022-06-25 07:11:25.397728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:11:33.802693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    return


# Generated at 2022-06-25 07:11:40.376011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    float_2 = float(float_0)
    float_3 = float(float_0)
    float_4 = float(float_0)
    str_1 = 'gJ5'
    bool_1 = False
    float_5 = float(float_0)

# Generated at 2022-06-25 07:11:48.570930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 4177.796772
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    var_0 = action_run(list_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    var_1 = action_module_1.run()
   

# Generated at 2022-06-25 07:11:59.272804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    var_0 = action_run(list_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    action_module_1.run()

test_case_0.test = test

# Generated at 2022-06-25 07:12:08.207229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    action_run(list_0)
    var_2 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0).run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:12:34.832617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)


# Generated at 2022-06-25 07:12:38.240627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = 'N\x1c#eL*y'
    bool_0 = True
    bytes_0 = b'3Wb'
    float_1 = 691.776822
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    action_module_0.run(list_0)


# Generated at 2022-06-25 07:12:49.118081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  float_0 = None
  dict_0 = {float_0: float_0}
  tuple_0 = (dict_0,)
  list_0 = [float_0, tuple_0]
  str_0 = '\t>&\\_H'
  bool_0 = False
  bytes_0 = b'lDs'
  float_1 = 3608.275348
  action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
  var_0 = action_run(list_0)
  action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
  var_1 = action_module_1.run()

# Generated at 2022-06-25 07:12:50.395182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:12:57.508139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor')
    float_3 = 2.08733913887
    list_1 = []
    bool_1 = True
    bytes_1 = b'y'
    float_4 = 7708.091222
    dict_1 = {}
    test_ActionModule_0 = ActionModule(list_1, float_3, bool_1, bytes_1, float_4, dict_1)
    print('Testing run')
    test_case_0()
    return 0

test_ActionModule()

# Generated at 2022-06-25 07:13:07.357816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    action_module_1 = ActionModule([str_0], str_0, dict_0, dict_0, dict_0, dict_0)
    action_module_2 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)


# Generated at 2022-06-25 07:13:13.385008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_0 = 3608.275348
    action_module_0 = ActionModule(dict_0, str_0, bool_0, bytes_0, float_0, dict_0)
    assert type(action_module_0) == ActionModule
    assert action_module_0._supports_async == True
    assert action_module_0._supports_check_mode == True


# Generated at 2022-06-25 07:13:16.513366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None


# Generated at 2022-06-25 07:13:17.255120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:13:25.643274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float('nan')
    float_1 = float('inf')
    float_2 = float('-inf')
    long_0 = long(17829)
    complex_0 = complex(258)
    complex_1 = complex(float_1, float_0)
    complex_2 = complex(float_2, float_2)
    complex_3 = complex(float_0, float_1)
    complex_4 = complex(float_1, float_1)
    complex_5 = complex(float_2, float_1)
    complex_6 = complex(float_0, float_2)
    complex_7 = complex(float_2, float_0)
    complex_8 = complex(float_1, float_2)
    complex_9 = complex(float_0, float_0)
    str_

# Generated at 2022-06-25 07:14:21.338968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2.31487683E+247
    bool_0 = False
    action_module_0 = ActionModule(float_0, bool_0)
    action_module_1 = ActionModule(float_0)
    var_0 = action_module_1.run(action_module_0)


# Generated at 2022-06-25 07:14:29.863577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    var_0 = action_run(list_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    var_1 = action_module_1.run()
    return var_1

# Generated at 2022-06-25 07:14:36.271731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import HashableUserDict
    from ansible_collections.notstdlib.moveitallout.tests.units.compat.mock import Mock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule

    wrap_async = False
    task_vars = list()
    module_name = 'user'
    module_args = {}

    mock_up_task = Mock(
        async_val=wrap_async,
        action='user',
        args=module_args,
        delegate_to='localhost',
        name='user',
        action_args={},
        delegate_facts=False,
    )

# Generated at 2022-06-25 07:14:41.666091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)


# Generated at 2022-06-25 07:14:49.385266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  try:
    dict_0 = {}
    tuple_0 = ()
    list_0 = []
    str_0 = 'test'
    bool_0 = False
    bytes_0 = b'lDs'
    float_0 = 3608.275348
    action_module_0 = ActionModule(list_0, str_0, bool_0, bytes_0, float_0, dict_0)
    var_0 = action_module_0.run()
    return 'Good job!'
  except AssertionError as e:
    return 'Assertion error: ' + str(e)
  except Exception as e:
    return 'Error: ' + str(e)

# Generated at 2022-06-25 07:14:55.912928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    action_run(list_0)
    var_0 = action_module_0.run()


if (__name__ == '__main__'):
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:15:05.286965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -0
    float_0 = -8.0
    complex_0 = -1.11j
    int_1 = 12
    bytes_0 = b'\x03-g'
    set_0 = {int_1, complex_0}
    tuple_0 = (complex_0, int_0, float_0, int_1, set_0, bytes_0)
    str_0 = '\x1b'
    action_module_0 = ActionModule(tuple_0, str_0)
    var_0 = action_run(tuple_0)
    action_module_1 = ActionModule(int_1, float_0)
    var_1 = action_module_1.run()


# Generated at 2022-06-25 07:15:15.311438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    s = b'\x88\x88\x88\x88'

# Generated at 2022-06-25 07:15:21.203254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    action_module_0 = ActionModule(tuple_0, '\t>&\\_H', False, b'lDs', 3608.275348, dict_0)
    var_0 = action_module_0.run()
    action_module_1 = ActionModule(tuple_0, '\t>&\\_H', False, b'lDs', 3608.275348, dict_0)
    var_1 = action_module_1.run()
    assert var_0 == var_1


# Generated at 2022-06-25 07:15:30.870352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '=gkF'
    bool_0 = False
    bytes_0 = b'*aU'
    float_1 = 5967.6
    action_module_0 = ActionModule(list_0, str_0, bool_0, bytes_0, float_1, dict_0)
    action_module_1 = ActionModule(list_0, list_0, action_module_0, list_0, tuple_0, bytes_0)
    assert type(action_module_1) == ActionModule
    assert action_module_1.run() == None

# Generated at 2022-06-25 07:17:43.667320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    var_0 = action_run(list_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    var_1 = action_module_1.run()



# Generated at 2022-06-25 07:17:47.671462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check the run method of action module
    str_0 = 'E?nH'
    bool_0 = True
    bytes_1 = b'x'
    float_0 = 8807.72984
    dict_2 = {str_0: str_0}
    list_1 = [bool_0, bytes_1]
    list_0 = [list_1, float_0, dict_2]
    tuple_0 = (bool_0, list_0)
    # Call the method using template values
    action_module_0 = ActionModule(tuple_0, bytes_1, float_0, float_0, float_0, bytes_1)
    # Check the result of method run
    assert_equal(action_module_0.run(), None)



# Generated at 2022-06-25 07:17:55.580856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0}
    tuple_0 = (dict_0,)
    list_0 = [float_0, tuple_0]
    str_0 = '\t>&\\_H'
    bool_0 = False
    bytes_0 = b'lDs'
    float_1 = 3608.275348
    action_module_0 = ActionModule(tuple_0, str_0, bool_0, bytes_0, float_1, dict_0)
    var_0 = action_run(list_0)
    action_module_1 = ActionModule(list_0, tuple_0, list_0, action_module_0, list_0, bytes_0)
    var_1 = action_module_1.run()