

# Generated at 2022-06-25 07:07:57.928915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if (test_ActionModule.__doc__ is not None):
        print (test_ActionModule.__doc__)
    obj = ActionModule()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()

if ((__name__ == '__main__') and (__package__ is None)):
    test_ActionModule()

# Generated at 2022-06-25 07:07:59.692426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: this is not the right way to test the function
    ActionModule.run('tmp_arg', 'task_vars_arg')

# Generated at 2022-06-25 07:08:01.123434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:08:03.374383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:07.936113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    instance_0 = ActionModule()
    task_vars_0 = dict()
    result_0 = instance_0.run(tmp=None, task_vars=task_vars_0)
    str_0 = '&\x0c"REJC@\na'
    dict_0 = {str_0: str_0}
    dict_1 = {dict_0: str_0}
    assert (result_0 == dict_1)

# Generated at 2022-06-25 07:08:16.572776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule constructor")
    task_mock = __importer__.mock('ansible.playbook.task.Task.Task')
    connection_mock = __importer__.mock('ansible.playbook.play_context.PlayContext.PlayContext')

# Generated at 2022-06-25 07:08:23.076444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule()
    test_case_0.__call__ = lambda: None
    obj_0.run = test_case_0
    class Class_0:
        pass
    dict_0 = { 'env': Class_0}
    dict_1 = { 'run_once': Class_0}
    obj_0.run({ 'task_vars': dict_0}, dict_1)


# Generated at 2022-06-25 07:08:23.832749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for constructor of class ActionModule
    assert ActionModule.run is not None

# Generated at 2022-06-25 07:08:33.524442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'd4N4\x1b'
    str_1 = '*QKs@D'
    str_2 = 'T~Tm'
    str_3 = 'n)P'
    str_4 = 'f`'
    str_5 = '8'
    str_6 = 'P%\x08'
    str_7 = '\x1b'
    str_8 = '\x0c'
    str_9 = 'Sa'
    str_10 = '\x1b`'
    str_11 = '\x0b'
    str_12 = '\x0b'
    str_13 = '\x0b'
    str_14 = '\x1b'
    str_15 = '\x0b'
    str_16 = '_'

# Generated at 2022-06-25 07:08:34.695665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:08:45.783934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    dict_0 = dict()
    dict_0['skipped'] = False
    dict_1 = dict()
    dict_2 = dict()
    dict_2['module_args'] = False
    dict_1['invocation'] = dict_2
    dict_0 = dict(dict_0, **dict_1)
    dict_1 = dict()
    dict_1['meta'] = dict_2

# Generated at 2022-06-25 07:08:51.595598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:08:56.798235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test_value'
    bool_0 = True
    bool_1 = True
    list_0 = [bool_0, bool_1]
    int_0 = -1906
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_module_0.run()
    assert var_0


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 07:09:02.298879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    assert not action_module_0
    var_0 = action_run()
    assert var_0 == 1

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:09:10.043417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    tmp = None
    task_vars = None

    # Setup expected results
    tmp = None
    task_vars = None

    # Perform the test
    test_case_0()

    # Verify results
    print("Comparing actual results to expected results...")
    assert tmp == tmp
    assert task_vars == task_vars
    print("Test successful")

# Run tests
test_ActionModule_run()

# Generated at 2022-06-25 07:09:14.299465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule('calling kinit with pexpect for principal %s', bool_0, bool_1, list_0, int_0, list_0)
    


# Generated at 2022-06-25 07:09:22.644526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global str_0
    str_0 = 'calling kinit with pexpect for principal %s'
    global bool_0
    bool_0 = False
    global bool_1
    bool_1 = False
    global list_0
    list_0 = [bool_0, bool_1]
    global int_0
    int_0 = -2616
    global action_module_0
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:09:27.139602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test environment
    print('\nUnit test for ActionModule::run')
    var_0 = 'x'
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = ActionModule.run(action_module_0, var_0, var_0)



# Generated at 2022-06-25 07:09:33.237473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule(
        'calling kinit with pexpect for principal %s',
        False,
        False,
        [
            False,
            False
        ],
        -2616,
        [
            False,
            False
        ]
    )
    var_0.run()

# Generated at 2022-06-25 07:09:38.759164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -10780
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    action_module_0.run()
    action_module_0.run(task_vars=1)
    action_module_0.run(tmp=1)
    action_module_0.run(task_vars=1, tmp=1)
    action_module_0.run(tmp=1, task_vars=1)
    action_module_0.run(tmp=1, task_vars=1, tmp=1)

# Generated at 2022-06-25 07:09:52.873945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0.inject == list_0
    assert action_module_0.connection == list_0
    assert action_module_0.task == list_0
    assert action_module_0.loader == list_0

# Generated at 2022-06-25 07:09:59.511529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:10:07.404275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dskcpb_'
    bool_0 = True
    bool_1 = True
    list_0 = [bool_1, bool_0]
    int_0 = -9079
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    int_1 = -15079
    str_1 = 'Kqe'
    str_2 = 'gZKjU'
    int_2 = -27294
    str_3 = 'Vqu'
    int_3 = -21000
    int_4 = 0
    str_4 = 'y'
    str_5 = 'b'
    int_5 = -12072
    int_6 = -4804

# Generated at 2022-06-25 07:10:15.930696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    assert action_module_0.action_name == 'calling kinit with pexpect for principal %s'
    assert action_module_0.bypass_checks == False
    assert action_module_0.supports_check_mode == False
    assert action_module_0.supports_async == False
    assert action_module_0.shell == [False, False]
    assert action_module_0.no_log == -2616
   

# Generated at 2022-06-25 07:10:19.885727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)


# Generated at 2022-06-25 07:10:27.948674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    # test_case_0
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_run()
    print("Test case passed")

# Generated at 2022-06-25 07:10:33.816224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:10:40.921267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_run()
    action_module_0._remove_tmp_path(action_module_0._connection._shell.tmpdir)
    var_1 = action_module_0.do_engine_shutdown()
    assert var_1 == 0


# Generated at 2022-06-25 07:10:41.660767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructor_test_case_0()


# Generated at 2022-06-25 07:10:45.030826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 07:11:04.645505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_module_0.run()
    assert var_0 == None




# Generated at 2022-06-25 07:11:07.848884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = None
    action_module_1 = ActionModule(tmp, task_vars)
    if action_module_0 != action_module_1:
        raise Exception


# Generated at 2022-06-25 07:11:10.393986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare variables for test
    tmp = None
    task_vars = None
    result = None

    # Run test
    result = ActionModule.run(tmp, task_vars)

    # Confirm result
    # assert result == expected

# Generated at 2022-06-25 07:11:12.254811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:11:17.603751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'jXJ/Pq/GbqIaWeuV+zQG5R5l5TB'
    bool_0 = True
    bool_1 = True
    list_0 = [bool_0, bool_1]
    int_0 = -1665
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    hash_0 = action_module_0.run()

# Generated at 2022-06-25 07:11:20.644978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:11:22.838400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1


# Generated at 2022-06-25 07:11:27.742663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)

# Generated at 2022-06-25 07:11:36.952556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    str_0 = 'calling kinit with pexpect for principal %s'
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    str_1 = 'action__nrpe_static'
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:11:44.775728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    gvar_0 = action_module_0


# Generated at 2022-06-25 07:12:10.916263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    # do nothing, just test creation
    # assert_equal(expected, ActionModule.run(self, tmp=None, task_vars=None))
    raise NotImplementedError()



# Generated at 2022-06-25 07:12:16.331801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    str_0 = 'taskname'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1, bool_1]
    int_0 = -1983
    list_1 = [int_0, int_0, int_0]
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_1)
    var_7 = action_module_0.run(var_0, var_1, var_2, var_3, var_4, var_5, var_6)

# Unit

# Generated at 2022-06-25 07:12:24.299528
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test normal case when param1 < param2,
    # and param1, param2 are integer and string respectively
    assert check_ActionModule('abc', -1, 'abc', -1, -1, 23) == True

    # Test normal case when param1 > param2,
    # and param1, param2 are integer and string respectively
    assert check_ActionModule('abc', -1, 'abc', -1, -1, -34) == True

    # Test normal case when param1 < param2,
    # and param1, param2 are strings
    assert check_ActionModule('abc', -1, 'abc', 'abc', 'abc', 'abc') == True

    # Test normal case when param1 > param2,
    # and param1, param2 are strings

# Generated at 2022-06-25 07:12:34.992142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    import os
    import sys
    import ansible.plugins.action as action
    import ansible.utils as util
    if sys.version_info < (3, ):
        import __builtin__ as builtins
    else:
        import builtins
    import ansible.module_utils as module_util
    import ansible.module_utils.urls as urls
    x = action.ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    # test for get option
    test_name = 'test_name'
    x.get_option(test_name)
    # test for no_log option
    x.no_log_vals.add('test_value')
    # test for _load_params
    x._load_params()
    # test for _execute

# Generated at 2022-06-25 07:12:37.751005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global var_0
    str_0 = None
    arg = str_0
    # TODO: Note: "var_0 = ActionModule(arg)" cannot be used because of method calls in the arguments
    # assert var_0 == None


# Generated at 2022-06-25 07:12:45.900704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    # val_0 = None
    # action_module_0.run(val_0)

# Generated at 2022-06-25 07:12:51.686978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 07:12:57.479637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 07:13:04.081156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexcept for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:13:10.603107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    action_module_0.run()


if __name__ == '__main__':
    # unit tests
    test_case_0() ## ActionModule.run

    # Report
    num_tests = 2
    num_passed = 2
    num_failed = 0
    print("%d/%d tests passed" % (num_passed, num_tests))

# Generated at 2022-06-25 07:14:07.020660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    tmp = None
    task_vars = None
    var_0 = action_run(tmp, task_vars)
    print(var_0)


# Generated at 2022-06-25 07:14:07.456737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:14:10.390471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 07:14:12.614006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexcept for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    run()


# Generated at 2022-06-25 07:14:17.361622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:14:26.827678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    action_module_0.action_module()
    str_1 = 'calling kinit with pexpect for principal %s'
    bool_2 = False
    bool_3 = False
    list_1 = [bool_2, bool_3]
    int_1 = -2616
    action_module_1 = ActionModule(str_1, bool_2, bool_3, list_1, int_1, list_1)
    action_

# Generated at 2022-06-25 07:14:32.944395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = True
    bool_1 = True
    list_0 = [bool_0, bool_1]
    int_0 = 2616
    list_1 = list_0
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_1)


# Generated at 2022-06-25 07:14:35.879762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for a integer arguement
    test_case_0()
    # Test for a string arguement

test_ActionModule()

# Generated at 2022-06-25 07:14:39.828188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if action_module_0.supports_async != False:
        var_0 = 1
    if action_module_0.supports_check_mode != False:
        var_0 = 1
    if action_module_0.root_tmp_path != '/tmp/ansible':
        var_0 = 1


# Generated at 2022-06-25 07:14:41.200136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 != None


# Generated at 2022-06-25 07:16:44.696187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Calling kinit with the default principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2933
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)


# Generated at 2022-06-25 07:16:46.056557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # get an instance of ActionModule class
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:16:55.312418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 
    # Set up mock
    # 
    import tempfile
    temp_file = tempfile.NamedTemporaryFile(delete=False)

    def side_effect(self, value):
        return temp_file.name

    mock_tmp = MagicMock(side_effect=side_effect)

# Generated at 2022-06-25 07:17:00.173775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'pycurl.version_info'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 07:17:02.494416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None


# Generated at 2022-06-25 07:17:07.408099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_module_0.run()

test_case_0()

# Generated at 2022-06-25 07:17:09.785787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        print("Failed for constructor of ActionModule")

# unit test for the run method of class ActionModule

# Generated at 2022-06-25 07:17:15.408529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    var_0 = action_module_0.run()
    return var_0


# Generated at 2022-06-25 07:17:16.137631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True



# Generated at 2022-06-25 07:17:20.367839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'calling kinit with pexpect for principal %s'
    bool_0 = False
    bool_1 = False
    list_0 = [bool_0, bool_1]
    int_0 = -2616
    action_module_0 = ActionModule(str_0, bool_0, bool_1, list_0, int_0, list_0)
    action_run()
    # Check that the correct values have been set
    assert action_module_0._task.async_val == False
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
