

# Generated at 2022-06-25 07:07:59.135244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_1 = {}
    dict_1[str_0] = str_1
    dict_0[str_0] = dict_1
    dict_1 = {}
    dict_1[str_1] = str_0
    dict_0[str_1] = dict_1
    module_0 = ActionModule(dict_0)
    assert module_0._supports_check_mode == True, 'assert module_0._supports_check_mode is True'
    assert module_0._supports_async == True, 'assert module_0._supports_async is True'


# Generated at 2022-06-25 07:08:05.402363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test might fail with a connection issue, in that case it's probably a firewall issue.
    set_0 = set({})
    def test_case_0():
        bool_0 = True
        str_0 = 'Y'
        str_1 = ''
        bool_1 = False
        dict_0 = {}
        set_0 = {bool_0, str_0, dict_0, str_0}
        return set_0
    str_0 = ActionModule.run()
    assert str_0 == set_0



# Generated at 2022-06-25 07:08:07.839255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create instance
    test_ActionModule = ActionModule()
    value = test_ActionModule._task
    # check if the correct values are set
    assert value is not None, 'should not be None'

# Generated at 2022-06-25 07:08:13.657713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #
    # 'binary' is interpreted as a string when passed to a function.
    #
    action = ActionModule(connection=None, task=None, loader=None, templar=None, shared_loader_obj=None, on_unsupported_module=None, module_name=None, module_args=None, task_vars=None, wrap_async=None)
    #
    # Accessing class variables
    #
    action.module_name= str_0
    #
    # Return a dictionary of functions
    #
    action_dict = action.run()
    #
    # Accessing class variables
    #
    action.module_name= str_0
    #
    # Return a dictionary of functions
    #
    action_dict = action.run()
    #
    # Accessing class variables
    #

# Generated at 2022-06-25 07:08:22.925182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = ActionModule()

# Generated at 2022-06-25 07:08:30.825303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        if not C.DEFAULT_KEEP_REMOTE_FILES:
            ActionModule(str_0, str_1, bool_0)
            ActionModule(str_0, str_1, bool_0)
        else:
            ActionModule(str_0, str_1, bool_0)
            ActionModule(str_0, str_1, bool_0)
    except:
        ActionModule(str_0, str_1, bool_0)
        ActionModule(str_0, str_1, bool_0)

if __name__ == '__main__':
    while True:
        test_case_0()

# Generated at 2022-06-25 07:08:34.217495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = {}
    # Executes the run method to test it.
    test_case_0()
    # Add any additional tests
    ActionModule.run(self=None, task_vars=task_vars, tmp=tmp)

# Generated at 2022-06-25 07:08:35.506722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Unit tests for class ActionBase

# Generated at 2022-06-25 07:08:43.985621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = set_0
    task_vars = set_0
    str_0 = '@'
    str_1 = 'm'
    str_2 = 'q'
    str_3 = 'c'
    str_4 = 'O'
    str_5 = 'U'
    str_6 = 'o'
    dict_0 = {str_4: str_4, str_5: str_6, str_2: str_0, str_3: str_1, str_1: str_4}

    c_0 = ActionModule()
    c_0.run(tmp, task_vars)
    c_1 = ActionModule()
    c_1.run(dict_0, str_1)


# Generated at 2022-06-25 07:08:45.540102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(0, 0)


# Generated at 2022-06-25 07:08:49.427004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 07:08:53.570001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0_task_vars = dict()

    action_module_0 = ActionModule()
    rv = action_module_0.run(task_vars=arg_0_task_vars)
    if rv is True:
        print("PASS")
    else:
        print("FAIL")
    return rv

# Generated at 2022-06-25 07:08:55.553687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:08:57.948576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
#    action_module_0 = ActionModule()

    action_module_0.set_loader()
    results = action_module_0.run()

# Generated at 2022-06-25 07:08:59.457324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:09:04.218248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # These three calls should pass
    try:
        ActionModule()
        ActionModule()
        ActionModule()

    except Exception:
        # This test case should not throw any exception
        return False
    else:
        return True


# Generated at 2022-06-25 07:09:07.345114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, object)


# Generated at 2022-06-25 07:09:10.179962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # action_module_0.run(None, None)
    # TODO: Add more unit tests here


# Generated at 2022-06-25 07:09:11.450663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()



# Generated at 2022-06-25 07:09:16.129041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    print(result)



if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:09:24.299049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result == None


# Generated at 2022-06-25 07:09:32.323700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.task_vars == None
    assert action_module.connection == None
    assert action_module.disable_lookup == False
    assert action_module.noop_task_vars == None
    assert action_module.wrap_async == None
    assert action_module.task_vars == None
    assert action_module.wrap_async == None
    assert action_module.module_vars == {}
    assert action_module.noop_task_vars == None
    assert action_module.transport == None
    assert action_module.noop_task_vars == None
    assert action_module.module_vars == {}
    assert action_module.task_vars == None
    assert action_module.transport == None

# Generated at 2022-06-25 07:09:36.641634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\n")
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:09:37.115124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:09:38.207252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:09:42.324332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a_module_0 = ActionModule()
    assert a_module_0 is not None, "Construtor of ActionModule failed"


# Generated at 2022-06-25 07:09:45.858908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test basic functionality of method run for class ActionModule
    '''
    action_module_0 = ActionModule()
    # TODO: create object of class Task and set self._task.async_val = None.
    task_vars = []
    # TODO: add parameter tmp to method run.
    # TODO: add parameter wrap_async to method _execute_module.
    r

# Generated at 2022-06-25 07:09:48.722983
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()
    if action_module_0.supports_check_mode is True:
        print("Everything went well")
    else:
        print("Testcase failed")


# Generated at 2022-06-25 07:09:52.318985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_testcase = ActionModule()
    assert action_module_testcase

# Generated at 2022-06-25 07:09:56.263493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_obj = ActionModule()
    assert actionmodule_obj is not None


# Generated at 2022-06-25 07:10:03.384535
# Unit test for constructor of class ActionModule
def test_ActionModule():
  case = 0
  # Test case 0
  test_case_0()
  return True

# Generated at 2022-06-25 07:10:07.403716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_module_0.run(None, None)

# Generated at 2022-06-25 07:10:15.949719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule.__author__)
    print(ActionModule.__doc__)
    print(ActionModule._supports_async)
    print(ActionModule._supports_check_mode)
    print(ActionModule.run())
    print(ActionModule._remove_tmp_path)
    print(ActionModule.action_loader({"var1": "var2"}))
    print(ActionModule.get_action_class)
    print(ActionModule.get_action_class)
    print(ActionModule.get_action_class('action_module_0', 'action_module_0', 'action_module_0', 'action_module_0', 'action_module_0', 'action_module_0'))

# Generated at 2022-06-25 07:10:21.656112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 537.0
    set_0 = {}
    list_0 = []
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    assert action_module_0.run() == {}, 'Return value of method run of class ActionModule is unexpected value'


# Generated at 2022-06-25 07:10:32.537654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = 1198.0
    set_1 = {float_1}
    list_1 = [float_1]
    dict_1 = {}
    action_module_1 = ActionModule(float_1, float_1, set_1, list_1, dict_1, set_1)
    var_0 = action_module_1.run()
    # FUTURE: better to let _execute_module calculate this internally?
    wrap_async = action_module_1._task.async_val and not action_module_1._connection.has_native_async
    # do work!
    var_0 = merge_hash(var_0, action_module_1._execute_module())
    # hack to keep --verbose from showing all the setup module result
    # moved from setup module as now we filter out all

# Generated at 2022-06-25 07:10:33.536867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:10:34.532539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:10:42.555135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    assert action_module_0._task is float_0
    assert action_module_0._connection is float_0
    assert action_module_0._play_context is set_0
    assert action_module_0._loader is list_0
    assert action_module_0._templar is dict_0
    assert action_module_0._shared_loader_obj is set_0
    assert action_module_0._supports_async is True
    assert action_module_0._supports_check_mode is True


# Generated at 2022-06-25 07:10:49.176563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    assert action_module_0._execute_module == False
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0._supports_async == False


# Generated at 2022-06-25 07:10:54.240971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 546.63
    float_1 = 1198.0
    set_0 = {float_0}
    list_0 = [float_1]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_1, set_0, list_0, dict_0, set_0)


# Generated at 2022-06-25 07:11:09.630865
# Unit test for constructor of class ActionModule
def test_ActionModule():
  try:
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
  except:
    assert False


# Generated at 2022-06-25 07:11:14.309538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    var_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)


# Generated at 2022-06-25 07:11:20.820139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 528.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_module_0.run(float_0, float_0)

# Generated at 2022-06-25 07:11:29.868189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test to see if the main method of class ActionModule works
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    float_1 = float_0 * float_0
    action_module_0.action_run(float_1, float_0)
    action_module_0.action_run(set_0, list_0)
    action_module_0.action_setup(dict_0, set_0, list_0)

# Generated at 2022-06-25 07:11:30.996237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = test_case_0()
    assert result == None

# Generated at 2022-06-25 07:11:37.451326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:11:40.364654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:11:46.625968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = test_case_0()
    assert True

# Generated at 2022-06-25 07:11:48.600114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Tested in test_case_0
    pass


# Generated at 2022-06-25 07:11:53.608945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    action_run_0 = action_module_2.run()
    assert action_run_0 == dict_2


# Generated at 2022-06-25 07:12:18.435847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    #assert_equal(action_module_0.run(), None)


# Generated at 2022-06-25 07:12:21.839769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)


# Generated at 2022-06-25 07:12:25.964449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 4.8
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    dict_0 = action_module_0.run()

# Generated at 2022-06-25 07:12:32.475547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1351.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    action_module_0._execute_module(task_vars=dict_0)
    action_module_0.run(task_vars=dict_0)


import inspect



# Generated at 2022-06-25 07:12:37.011149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_module_0.run()


test_case_0()

# Generated at 2022-06-25 07:12:40.398955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_run()
    assert var_0 == None

test_ActionModule_run()

# Generated at 2022-06-25 07:12:46.342734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "w"
    str_1 = "<g"
    str_2 = "^"
    str_3 = "F+"
    str_4 = "n"
    str_5 = "Z"
    str_6 = "N*"
    str_7 = "w"
    str_8 = " l"
    str_9 = "6"
    str_10 = "yh"
    str_11 = "r"
    str_12 = "J"
    str_13 = "8"
    str_14 = "w@"
    str_15 = "()"
    float_0 = 1864.0
    float_1 = 1943.0
    float_2 = 976.0

# Generated at 2022-06-25 07:12:47.910677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert test_case_0() == None
    except AssertionError:
        raise

# Generated at 2022-06-25 07:12:53.233303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 86.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:12:55.904563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 798.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    # public method test
    test_case_0()


# Generated at 2022-06-25 07:13:51.610189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)


# Generated at 2022-06-25 07:13:58.172479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for constructor of class ActionModule
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    tmp_0 = None
    task_vars_0 = None
    action_run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:14:01.870844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:14:03.115136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True, "Test for ActionModule completed successfully"



# Generated at 2022-06-25 07:14:06.765873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 8114.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    action_module_0.run(float_0)

# Generated at 2022-06-25 07:14:15.959029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1325.0
    list_0 = ['d', '1', 'G', 'd', '1', 'G']
    list_1 = [float_0, 'o', 'G', 'd', '1', 'G', float_0, 'o', 'G', 'd']
    tuple_0 = (list_0, list_0)
    tuple_1 = (list_0, tuple_0, list_1, list_1, tuple_0, tuple_0)
    list_2 = [list_1, float_0, float_0]
    dict_0 = {}

    #case 0
    float_1 = 684.0
    set_0 = {float_0}
    list_3 = [float_1]
    dict_1 = {}

# Generated at 2022-06-25 07:14:26.232815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 1.7986931348623157E308
    var_1 = 1.7986931348623157E308
    var_2 = {var_0}
    var_3 = [var_0]
    var_4 = {}
    var_5 = {'Name': 'ansible', 'Version': '2.4.2.0', 'User': 'root'}
    var_6 = {var_0, var_1, var_2, var_3, var_4, var_5}
    var_7 = {var_0}
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)

# Generated at 2022-06-25 07:14:29.354841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_1.run(float_0, float_0, set_0, list_0, dict_0, set_0)

# Generated at 2022-06-25 07:14:34.384264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    assert(action_module_0._supports_check_mode == True)


# Generated at 2022-06-25 07:14:42.288786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 498.0
    float_1 = 1388.0
    float_2 = 540.0
    float_3 = 1687.0
    float_4 = 1731.0
    float_5 = 1418.0
    float_6 = 1437.0
    set_0 = {float_0}
    list_1 = [float_1]
    action_module_0 = ActionModule(float_2, float_3, set_0, list_1, None, set_0)
    assert action_module_0._supports_check_mode == True

if __name__ == '__main__':
    import sys
    import utils

# Generated at 2022-06-25 07:16:49.935054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    test_case_0()

test_ActionModule()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 07:16:53.649706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except NameError:
        print(NameError)
    except TypeError:
        print(TypeError)
    except AttributeError:
        print(AttributeError)
    except ValueError:
        print(ValueError)
    except Exception:
        print(Exception)
    else:
        return action_module_0


# Generated at 2022-06-25 07:16:57.417218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_module_0.run(dict(), dict())
    assert var_0 == None


# Generated at 2022-06-25 07:16:58.838291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0).__name__ == "ActionModule"


# Generated at 2022-06-25 07:16:59.735616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    add(8, 4)



# Generated at 2022-06-25 07:17:05.812730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1426.2
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 07:17:09.506741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:17:17.631238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(1198.0, 1198.0, {1198.0}, [1198.0], {}, {1198.0})
    assert action_module_0._supports_check_mode == True
    assert action_module_0.module_name == 'action_module'
    assert action_module_0._supports_async == True
    assert action_module_0._task == 1198.0
    assert action_module_0._connection == 1198.0
    assert action_module_0._play_context == {1198.0}
    assert action_module_0._loader == [1198.0]
    assert action_module_0._templar == {}
    assert action_module_0._shared_loader_obj == {}
    assert action_module_0._task_v

# Generated at 2022-06-25 07:17:20.959953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)


# Generated at 2022-06-25 07:17:27.245441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1198.0
    set_0 = {float_0}
    list_0 = [float_0]
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, set_0, list_0, dict_0, set_0)
    var_0 = action_run()
    assert var_0 == 0.0, 'Expected value of var_0 to be 0.0'