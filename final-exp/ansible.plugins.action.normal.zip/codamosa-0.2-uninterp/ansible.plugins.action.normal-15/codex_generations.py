

# Generated at 2022-06-17 09:20:07.988839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal
    import ansible.plugins.action.copy
    import ansible.plugins.action.template
    import ansible.plugins.action.debug
    import ansible.plugins.action.setup
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible.plugins.action.script
    import ansible.plugins.action.include
    import ansible.plugins.action.include_tasks
    import ansible.plugins.action.include_role
    import ansible.plugins.action.async_status
    import ansible.plugins.action.async_wrapper
    import ansible.plugins.action.pause
    import ansible.plugins.action.wait_for
    import ansible.plugins.action.add_host
    import ansible.plugins.action

# Generated at 2022-06-17 09:20:14.926451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.connection.local import Connection
    from ansible.plugins.loader import module_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 09:20:15.556722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:17.234885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:18.691225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am is not None


# Generated at 2022-06-17 09:20:32.172683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_

# Generated at 2022-06-17 09:20:33.094590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:20:47.165392
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:47.725425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:50.770592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:20:55.136386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:21:04.892615
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:08.699156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:21:17.645677
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:20.402924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:22.622795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:21:26.427338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Check if the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:21:29.141099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None) is not None

# Generated at 2022-06-17 09:21:29.739449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:41.640929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader plugin
    shared_loader_plugin = MockSharedLoaderPlugin()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock strategy plugin
    strategy_plugin = MockStrategyPlugin()
    # Create a mock display plugin
    display_plugin = MockDisplayPlugin()
    # Create a mock callback plugin
    callback_plugin = MockCallbackPlugin()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock

# Generated at 2022-06-17 09:21:57.546144
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:59.777442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:02.474629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:22:06.362427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True


# Generated at 2022-06-17 09:22:16.779365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class ShellModule
    shell_module = ShellModule()

    # Create an instance of class Shell
    shell = Shell()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class Inventory
    inventory = Inventory()

    # Create an instance of class VariableManager
    variable_

# Generated at 2022-06-17 09:22:17.774622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:32.178642
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:45.899636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid action
    action = ActionModule(None, 'ping', None, None, None, None, None)
    assert action.action == 'ping'
    assert action.action_loader == None
    assert action.action_plugins == None
    assert action.action_stdout == None
    assert action.action_stderr == None
    assert action.action_warnings == None
    assert action.action_deprecations == None
    assert action.action_loader_name == None
    assert action.action_loader_class == None
    assert action.action_loader_module == None
    assert action.action_loader_args == None
    assert action.action_loader_kwargs == None
    assert action.action_loader_options == None
    assert action.action_loader_context == None
    assert action.action_loader_

# Generated at 2022-06-17 09:22:46.548633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:52.303545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:23:14.019954
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:23:20.953479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
   

# Generated at 2022-06-17 09:23:21.645566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:23:23.653737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:23:24.202810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:28.504200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:23:29.462804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:23:31.685788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:32.604307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:23:36.902748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no_log
    # Test with wrap_async
    # Test with wrap_async and no_log
    # Test with wrap_async and no_log and async_val
    # Test with wrap_async and no_log and async_val and has_native_async
    # Test with wrap_async and no_log and async_val and has_native_async and action in C._ACTION_SETUP
    pass

# Generated at 2022-06-17 09:24:07.127587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsibleOptions
    ansible_options = AnsibleOptions()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module_2 = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module_3 = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module_4 = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module_5 = AnsibleModule()

    # Create an instance

# Generated at 2022-06-17 09:24:09.065434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:24:11.534011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:24:23.409391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE

# Generated at 2022-06-17 09:24:32.848996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    #

# Generated at 2022-06-17 09:24:36.692835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:24:39.688397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default values
    action_module = ActionModule(None, None)
    assert action_module is not None
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True

# Generated at 2022-06-17 09:24:50.332480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, variable_manager, action_plugin)
    # Create a mock task variables
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Create a mock wrap async
    wrap_async = MockWrapAsync()
    # Create a mock tmp
    tmp = MockTmp()
    # Call method run of class ActionModule

# Generated at 2022-06-17 09:24:59.620021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:25:09.693259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, variable_manager, play_context, action_plugin)
    # Create a mock task variables
    task_vars = MockTaskVars()
    # Call the method run of class ActionModule
    action_module.run(task_vars)
    # Check if the method run of class ActionModule has been called
    assert action_module.run.called

# Generated at 2022-06-17 09:26:01.653729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:26:04.597904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:26:13.522161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 09:26:15.658065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:26:27.384961
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:28.494779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:29.399195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:32.954239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:26:35.106997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:40.789090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:28:44.268413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:54.195498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-17 09:28:57.215512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:28:58.534708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:29:01.821678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:29:08.442198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:29:10.847417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:29:14.336874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:29:22.164260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default values
    action_module = ActionModule(None, None, None, None)
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module._task == None
    assert action_module._connection == None
    assert action_module._play_context == None
    assert action_module._loader == None
    assert action_module._templar == None
    assert action_module._shared_loader_obj == None
    assert action_module._task_vars == None
    assert action_module._tmp == None
    assert action_module._task_vars == None
    assert action_module._tmp == None
    assert action_module._task_vars == None
    assert action_module._tmp == None
    assert action_module._task_v

# Generated at 2022-06-17 09:29:23.484661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)