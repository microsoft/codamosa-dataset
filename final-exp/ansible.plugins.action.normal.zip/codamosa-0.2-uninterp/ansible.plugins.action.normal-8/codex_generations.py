

# Generated at 2022-06-17 09:19:58.016946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No test for method run of class ActionModule"

# Generated at 2022-06-17 09:19:59.264453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:20:09.198687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('MockTask', (object,), {
        'async_val': None,
        'action': 'setup',
    })()

    # Create a mock connection
    mock_connection = type('MockConnection', (object,), {
        'has_native_async': False,
        '_shell': type('MockShell', (object,), {
            'tmpdir': 'tmpdir',
        })(),
    })()

    # Create a mock module
    mock_module = type('MockModule', (object,), {
        '_execute_module': lambda self, task_vars, wrap_async: {'key': 'value'},
        '_remove_tmp_path': lambda self, tmpdir: None,
    })()

    # Create a mock action

# Generated at 2022-06-17 09:20:10.194725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:20:10.984370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:21.228320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection
    task = MockTask()
    connection = MockConnection()

    # Create a mock action module
    action_module = ActionModule(task, connection)

    # Create a mock result
    result = {'skipped': False, 'invocation': {'module_args': {'a': 1, 'b': 2}}}

    # Create a mock task_vars
    task_vars = {'a': 1, 'b': 2}

    # Call the run method of the action module
    result = action_module.run(result, task_vars)

    # Assert that the result is correct
    assert result == {'skipped': False, 'invocation': {'module_args': {'a': 1, 'b': 2}}}


# Generated at 2022-06-17 09:20:32.185585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal
    import ansible.playbook.task
    import ansible.utils.vars
    import ansible.utils.template
    import ansible.utils.vars
    import ansible.vars.hostvars
    import ansible.vars.unsafe_proxy
    import ansible.vars.vars_cache
    import ansible.vars.vars_plugin
    import ansible.vars.vars_loader

    # create a fake task
    task = ansible.playbook.task.Task()
    task.action = 'setup'
    task.async_val = 0
    task.args = {}
    task.delegate_to = None
    task.delegate_facts = False
    task.environment = {}
    task.first_available_file = None


# Generated at 2022-06-17 09:20:36.987360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.loader import action_

# Generated at 2022-06-17 09:20:38.113272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:20:41.026479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:51.537996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection
    task = MockTask()
    connection = MockConnection()

    # Create a mock action module
    action_module = ActionModule(task, connection)

    # Create a mock result
    result = {'invocation': {'module_args': 'test_module_args'}}

    # Create a mock task_vars
    task_vars = {'test_task_vars': 'test_task_vars'}

    # Call method run of class ActionModule
    result = action_module.run(task_vars=task_vars, result=result)

    # Assert that the result is correct
    assert result == {'invocation': {}, 'test_task_vars': 'test_task_vars'}


# Generated at 2022-06-17 09:21:03.567421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:21:04.059197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:04.552070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:07.591407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:10.016505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-17 09:21:20.048119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class ShellModule
    shell_module = ShellModule()

    # Create an instance of class Shell
    shell = Shell()

    # Create an instance of class ShellModule
    shell_module = ShellModule()

    # Create an instance of class Shell
    shell = Shell()

    # Create an instance of class ShellModule
    shell_module = ShellModule()

    # Create an instance of class Shell
    shell = Shell()

    # Create an instance of class

# Generated at 2022-06-17 09:21:24.079999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:21:31.245417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.plugins.loader import connection

# Generated at 2022-06-17 09:21:32.469842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:47.260866
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:48.721296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:22:00.506909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task object
    task = MockTask()

    # create a mock connection object
    connection = MockConnection()

    # create a mock action plugin object
    action_plugin = MockActionPlugin()

    # create a mock module object
    module = MockModule()

    # create a mock module object
    module_result = MockModuleResult()

    # create a mock task_vars object
    task_vars = MockTaskVars()

    # create a mock tmp object
    tmp = MockTmp()

    # create a mock wrap_async object
    wrap_async = MockWrapAsync()

    # create a mock result object
    result = MockResult()

    # create a mock result object
    result_new = MockResult()

    # create a mock result object
    result_new_new = MockResult()

    # create a

# Generated at 2022-06-17 09:22:12.748167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-17 09:22:22.467259
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:31.136468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import range
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 09:22:32.181344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:33.312857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:22:33.866297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:38.900010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:22:50.603212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:53.545531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:56.074362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:23:03.642974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:23:05.437394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:23:06.599690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 09:23:07.283378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:23:17.220076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:23:18.290544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:23:22.876894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:23:46.996259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:48.198134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:23:55.267158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module is not None
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None
    assert action_module._action is None
    assert action_module._task_vars is None
    assert action_module._play_context is None
    assert action_module._loaded_from is None
    assert action_module._task_ds is None
    assert action_module._task_ds is None

# Generated at 2022-06-17 09:24:05.058483
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:18.223213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock action module
    action_module = ActionModule()

    # Create a mock task
    task = dict()
    task['async'] = 0
    task['async_val'] = 0
    task['action'] = 'setup'

    # Create a mock connection
    connection = dict()
    connection['has_native_async'] = False

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()
    result['invocation'] = dict()
    result['invocation']['module_args'] = 'test'

    # Create a mock wrap_async
    wrap_async = False

    # Create a mock execute_module
    execute_module = dict()
    execute_module['_ansible_verbose_override'] = True

   

# Generated at 2022-06-17 09:24:18.967326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:31.412269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, module, action_plugin)
    # Create a mock result
    result = MockResult()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Call method run of class ActionModule
    action_module.run(tmp, task_vars)
    # Assert that method run of class ActionModule was called
    assert action_module.run_called
    # Assert that method run of class ActionModule was

# Generated at 2022-06-17 09:24:38.904493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test setup
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 09:24:40.070300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:24:40.615400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:44.400097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:25:45.567227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:25:54.866334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock action plugin
    action_plugin = MockActionPlugin()
    # create a mock action module
    action_module = ActionModule(task, connection, action_plugin, 'test_module_name', 'test_module_args', 'test_module_path')
    # create a mock task_vars
    task_vars = {'test_task_vars_key': 'test_task_vars_value'}
    # create a mock result
    result = {'test_result_key': 'test_result_value'}
    # create a mock tmp
    tmp = 'test_tmp'
    # create a mock wrap_async
    wrap_async = True
    # create a mock execute_

# Generated at 2022-06-17 09:26:06.480029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Set the attributes of the class PlayContext
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.check_mode = False
    play_context.diff = False
    play_context.network_os = 'ios'
    play_context.remote_addr = '10.10.10.10'
    play_context.remote_user = 'admin'
    play_context.timeout = 10

    # Set the attributes of the class

# Generated at 2022-06-17 09:26:14.871083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils
    module_utils_loader = MockModule

# Generated at 2022-06-17 09:26:18.257560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:26:27.987058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play_context, loader, module, '/path/to/tmp')
    # Create a mock task vars
    task_vars = dict()
    # Create a mock result
    result = dict()
    # Create a mock tmp
    tmp = None
    # Call the method run of class ActionModule
    result = action_plugin.run(tmp, task_vars)
    # Check if the result is the expected one
    assert result == dict()


# Generated at 2022-06-17 09:26:28.501545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:37.270485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='shell', args='ls'))
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task == task
    assert action._connection == None
    assert action._play_context == None
    assert action._loader == None
    assert action._templar == None
    assert action._shared_loader_obj == None
    assert action._supports_async == True
    assert action._supports_check_mode == True

    # Test with a invalid task
    task = dict(action=dict(module='shell', args='ls'), async_val=10)

# Generated at 2022-06-17 09:26:49.750093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:29:08.253732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import ActionModuleComponent
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-17 09:29:13.117009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:29:22.008208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_ActionModule_run: test run method of class ActionModule
    # mock task and connection
    task = Mock()
    connection = Mock()
    # mock task_vars
    task_vars = dict()
    # mock result
    result = dict()
    # mock wrap_async
    wrap_async = False
    # mock execute_module
    execute_module = dict()
    # mock module_args
    module_args = dict()
    # mock invocation
    invocation = dict()
    # mock skipped
    skipped = False
    # mock async_val
    async_val = False
    # mock has_native_async
    has_native_async = False
    # mock _ansible_verbose_override
    _ansible_verbose_override = True
    # mock _task
    _

# Generated at 2022-06-17 09:29:24.770293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:29:26.223677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:29:29.909252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:31.094881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:29:33.524437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-17 09:29:35.989891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:29:37.961339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()