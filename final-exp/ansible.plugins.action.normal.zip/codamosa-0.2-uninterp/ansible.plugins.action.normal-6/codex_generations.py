

# Generated at 2022-06-17 09:20:05.106081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action module
    action_module = ActionModule(task, connection, module)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock result
    result = MockResult()
    # Set the result of the run method of the action module
    action_module.run(tmp, task_vars)
    # Check if the result is correct
    assert result == action_module.run(tmp, task_vars)


# Generated at 2022-06-17 09:20:08.919984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:20:09.959966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_ActionModule_run() is not implemented yet
    pass

# Generated at 2022-06-17 09:20:12.389881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:20:22.014448
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:25.620499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-17 09:20:27.035570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:27.902061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:29.273599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:35.631861
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:41.074237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:42.583019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:43.226618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:46.202650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:20:47.120454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:52.963256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock action base
    action_base = MockActionBase()
    # Create a mock module_utils path
    module_utils_path = MockModuleUtilsPath()
    # Create

# Generated at 2022-06-17 09:20:54.779532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:04.721242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.async_val = False
    task.action = 'setup'

    # Create a mock connection
    connection = mock.Mock()
    connection.has_native_async = False

    # Create a mock module
    module = mock.Mock()
    module.run.return_value = dict(
        ansible_facts=dict(
            a=1,
            b=2,
        ),
        changed=True,
        skipped=False,
    )

    # Create a mock loader
    loader = mock.Mock()
    loader.get_basedir.return_value = '/path/to/ansible/module'

    # Create a mock ActionBase
    action_base = mock.Mock()
    action_base._task = task
    action

# Generated at 2022-06-17 09:21:15.495737
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:27.496627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 09:21:34.967666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)
    assert am is not None

# Generated at 2022-06-17 09:21:45.438738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:21:55.664962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host

# Generated at 2022-06-17 09:21:59.607281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:00.457694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:22:08.922877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True

    # Test with arguments
    am = ActionModule(connection=None, runner_queue=None, task_queue=None, loader=None, play_context=None, shared_loader_obj=None, variable_manager=None)
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-17 09:22:14.133095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default args
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:22:23.145571
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:25.236136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode == True
    assert module._supports_async == True

# Generated at 2022-06-17 09:22:33.225099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils


# Generated at 2022-06-17 09:22:53.020046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('MockModule', (object,), {'run': lambda self, tmp=None, task_vars=None: {'skipped': False}})
    # Create a mock object for the connection class
    mock_connection = type('MockConnection', (object,), {'has_native_async': False})
    # Create a mock object for the task class
    mock_task = type('MockTask', (object,), {'async_val': False})
    # Create a mock object for the action base class

# Generated at 2022-06-17 09:23:00.757991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:23:01.475148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:02.313502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:13.978447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:23:15.130925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:16.002860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:23:17.748517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:23:29.737991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action module
    action_module = ActionModule(task, connection, module)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Call the run method of the action module
    result = action_module.run(tmp, task_vars)
    # Assert that the result is not None
    assert result is not None


# Generated at 2022-06-17 09:23:32.032942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:24:02.251293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and action module
    task = MockTask()
    action_module = ActionModule(task, MockConnection())

    # Create a mock result
    result = {'invocation': {'module_args': 'test'}}

    # Run the action module
    result = action_module.run(task_vars={}, tmp=None, task_vars=None)

    # Assert that the result is correct
    assert result == {'invocation': {'module_args': 'test'}, 'changed': True}


# Generated at 2022-06-17 09:24:04.531496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:24:10.731346
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:11.167005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:12.185966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:24:23.837517
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:26.860798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:27.955181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:24:38.530494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import shutil
    import json
    import pytest
    import ansible.plugins.action
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 09:24:47.576875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:25:49.844895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:25:56.255849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action module
    action_module = ActionModule(task, connection, module)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Call the method run of class ActionModule
    action_module.run(tmp, task_vars)


# Generated at 2022-06-17 09:26:03.592021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default values
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

    # Test with custom values
    action_module = ActionModule(supports_check_mode=False, supports_async=False)
    assert action_module._supports_check_mode == False
    assert action_module._supports_async == False

# Generated at 2022-06-17 09:26:04.368699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:04.905376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:06.413969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:07.229198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:26:08.942775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:26:10.207254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:26:11.302634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:28:22.459093
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:28:26.058761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:28:32.222881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock action module
    action_module = ActionModule(task, connection, action_plugin, module)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock wrap_async
    wrap_async = MockWrapAsync()
    # Create a mock invocation
    invocation = MockInvocation()
    # Create a mock module_args
    module_args = MockModuleArgs()
    # Create a mock

# Generated at 2022-06-17 09:28:42.295291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module action
    action_module = ActionModule()
    # Create a mock object for the task
    task = Mock()
    # Create a mock object for the connection
    connection = Mock()
    # Create a mock object for the task_vars
    task_vars = Mock()
    # Create a mock object for the result
    result = Mock()
    # Create a mock object for the wrap_async
    wrap_async = Mock()
    # Create a mock object for the tmp
    tmp = Mock()
    # Create a mock object for the invocation
    invocation = Mock()
    # Create a mock object for the module_args
    module_args = Mock()
    # Create a mock object for the module_args
    module_args = Mock()
    # Create a mock object for the module_args
    module_

# Generated at 2022-06-17 09:28:53.879579
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:29:02.023948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_a_line
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-17 09:29:12.056542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:29:21.221685
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:29:21.729608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:31.793349
# Unit test for constructor of class ActionModule