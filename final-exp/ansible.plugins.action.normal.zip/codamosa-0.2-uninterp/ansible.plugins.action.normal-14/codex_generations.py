

# Generated at 2022-06-17 09:20:07.548144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = {
        'async': 0,
        'async_val': 0,
        'action': 'setup',
        'args': {},
        'delegate_to': None,
        'delegate_facts': False,
        'notify': [],
        'register': 'shell_out',
        'run_once': False,
        'when': True
    }

    # Create a mock connection
    connection = {
        'has_native_async': False,
        '_shell': {
            'tmpdir': '/tmp/ansible-test'
        }
    }

    # Create a mock loader
    loader = {
        '_basedir': '/tmp/ansible-test'
    }

    # Create a mock play context

# Generated at 2022-06-17 09:20:08.562269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:20:09.312156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:20:10.935463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-17 09:20:12.666454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:13.650235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:14.786477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:20:24.243933
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:26.898242
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:27.419686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:31.897700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:32.639516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:47.164726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-17 09:20:47.725662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:01.471977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock variable manager
    variable_manager = MockVariableManager()

    # Create an action module
    action_module = ActionModule(task, connection, play_context, loader, variable_manager)

    # Test the constructor
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._play_context == play_context
    assert action_module._loader == loader
    assert action_module._templar == variable_manager._templar
    assert action_module._shared_loader_obj == loader
    assert action_module._action == task

# Generated at 2022-06-17 09:21:03.881030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:21:04.900418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:21:15.495898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_

# Generated at 2022-06-17 09:21:16.404217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:18.391197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-17 09:21:33.299767
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:34.053489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:44.692738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 09:21:48.990752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module._task == None
    assert action_module._connection == None
    assert action_module._play_context == None
    assert action_module._loader == None
    assert action_module._templar == None
    assert action_module._shared_loader_obj == None

# Generated at 2022-06-17 09:21:49.825957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:21:51.994504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:22:02.574925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleTaskVars
    ansible_task_vars = AnsibleTaskVars()

    # Create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsibleConnectionShell
    ansible_connection_shell = AnsibleConnectionShell()

    # Set the attributes of the AnsibleConnectionShell instance
    ansible_connection_shell.tmpdir = "tmpdir"

    # Set the attributes of the AnsibleConnection instance
    ansible_connection._shell = ansible_connection_shell

    # Set the attributes

# Generated at 2022-06-17 09:22:13.293820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:22:13.937917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:15.336841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:22:33.971302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:22:38.510029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:22:38.957404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:42.894938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:52.488489
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:52.931532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:58.063509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True
    assert am._task == None
    assert am._connection == None
    assert am._play_context == None
    assert am._loader == None
    assert am._templar == None
    assert am._shared_loader_obj == None

# Generated at 2022-06-17 09:23:03.531126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:23:06.764106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:23:16.934639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module action plugin
    mock_action_module = ActionModule()

    # Create a mock object for the module connection plugin
    mock_connection = MockConnection()

    # Create a mock object for the module task plugin
    mock_task = MockTask()

    # Create a mock object for the module task plugin
    mock_task_vars = MockTaskVars()

    # Set the attributes of the mock object for the module action plugin
    mock_action_module._supports_check_mode = True
    mock_action_module._supports_async = True
    mock_action_module._connection = mock_connection
    mock_action_module._task = mock_task

    # Set the attributes of the mock object for the module connection plugin
    mock_connection.has_native_async = False

    # Set the attributes of the

# Generated at 2022-06-17 09:23:44.121229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:23:53.685354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:04.030559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:24:11.406574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, module, action_plugin)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Create a mock tmp
    tmp = MockTmp()
    # Call method run of class ActionModule
    action_module.run(tmp, task_vars)
    # Check if method run of class ActionModule was called
    assert action_module.run.called


# Generated at 2022-06-17 09:24:13.888263
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode == True
    assert module._supports_async == True

# Generated at 2022-06-17 09:24:15.302527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No test for method run of class ActionModule"

# Generated at 2022-06-17 09:24:29.296914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:38.620226
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:48.410427
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:49.944722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:25:49.921221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:25:55.640631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no_log
    # Test with wrap_async
    # Test with wrap_async and no_log
    # Test with wrap_async and no_log and async_val
    # Test with wrap_async and no_log and async_val and has_native_async
    # Test with wrap_async and no_log and async_val and has_native_async and _task.action in C._ACTION_SETUP
    pass

# Generated at 2022-06-17 09:25:56.026962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:00.630725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:26:01.572446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:26:04.874381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:26:06.401545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:26:14.799918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
   

# Generated at 2022-06-17 09:26:27.270059
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:28.167063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:28:42.781584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import ActionModuleComponent
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
   

# Generated at 2022-06-17 09:28:45.580964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:28:46.574811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:28:53.752835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:29:01.944665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import ishashable

# Generated at 2022-06-17 09:29:05.073435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:29:06.004164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:29:10.056622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:11.461389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:29:21.139217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_