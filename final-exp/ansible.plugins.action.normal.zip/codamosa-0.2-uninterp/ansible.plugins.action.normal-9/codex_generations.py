

# Generated at 2022-06-17 09:20:04.257575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:20:14.623924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:20:15.349895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:22.933734
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:33.851793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:20:39.470618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am is not None
    assert am._supports_check_mode is True
    assert am._supports_async is True

# Generated at 2022-06-17 09:20:41.171164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:42.088128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:50.922105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    # Create a mock connection
    mock_connection = MockConnection()
    # Create a mock module
    mock_module = MockModule()
    # Create a mock task_vars
    mock_task_vars = MockTaskVars()
    # Create a mock wrap_async
    mock_wrap_async = MockWrapAsync()
    # Create a mock result
    mock_result = MockResult()
    # Create a mock tmp
    mock_tmp = MockTmp()
    # Create a mock skipped
    mock_skipped = MockSkipped()
    # Create a mock invocation
    mock_invocation = MockInvocation()
    # Create a mock module_args
    mock_module_args = MockModuleArgs()
    # Create a mock async_val
    mock_as

# Generated at 2022-06-17 09:20:51.568246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:55.011371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:02.025662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.file import ActionModule as FileActionModule
    from ansible.plugins.action.lineinfile import ActionModule as LineinfileActionModule
    from ansible.plugins.action.template import ActionModule as TemplateActionModule

# Generated at 2022-06-17 09:21:02.522934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:03.004712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:09.870080
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:10.743472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:20.341094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal as normal
    import ansible.plugins.action.copy as copy
    import ansible.plugins.action.command as command
    import ansible.plugins.action.debug as debug
    import ansible.plugins.action.setup as setup
    import ansible.plugins.action.ping as ping
    import ansible.plugins.action.script as script
    import ansible.plugins.action.shell as shell
    import ansible.plugins.action.system as system
    import ansible.plugins.action.wait_for as wait_for
    import ansible.plugins.action.raw as raw
    import ansible.plugins.action.file as file
    import ansible.plugins.action.synchronize as synchronize
    import ansible.plugins.action.git as git
    import ansible.plugins.action.win

# Generated at 2022-06-17 09:21:22.213436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:21:24.227385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:21:33.331870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils finder
    module_utils_finder = MockModuleUtilsFinder()
    # Create a mock module_utils path
    module_utils_path = MockModule

# Generated at 2022-06-17 09:21:42.416903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-17 09:21:49.424890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:21:50.843933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:02.387598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import ActionModuleComponent
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars


# Generated at 2022-06-17 09:22:04.545583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 09:22:06.512522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:07.137368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:08.538451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:10.505093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:22:21.710747
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:32.794103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:22:33.595735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:22:37.248026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:22:50.299011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil
    import sys
    import json
    import yaml
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.action.normal import ActionModule as am
    from ansible.plugins.action.normal import ActionBase as ab
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-17 09:22:51.639906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:59.840871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module
    class MockModule:
        def __init__(self):
            self.async_val = False
            self.action = 'setup'
            self.connection = MockConnection()

    # Create a mock object for the connection
    class MockConnection:
        def __init__(self):
            self.has_native_async = False

    # Create a mock object for the task
    class MockTask:
        def __init__(self):
            self.async_val = False
            self.action = 'setup'
            self.connection = MockConnection()

    # Create a mock object for the task_vars
    class MockTaskVars:
        def __init__(self):
            self.task_vars = {}

    # Create a mock object for the action_base

# Generated at 2022-06-17 09:23:01.964994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:23:13.783048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:23:16.330861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:23:17.153364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:23:47.169274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True

    # Test with arguments
    am = ActionModule(connection=None, task=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-17 09:23:49.688764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:23:55.903066
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:23:59.047494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:23:59.795495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:24:08.081609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:11.683297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Check if the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:24:13.269890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None) is not None

# Generated at 2022-06-17 09:24:16.683463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:24:17.470646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:25:16.763486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='shell', args='ls'))
    connection = dict(module_name='local')
    play_context = dict(become=False, become_method=None, become_user=None, check_mode=False, diff=False)
    loader = None
    templar = None
    shared_loader_obj = None

    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._play_context == play_context
    assert action_module._loader == loader
    assert action_module._templar == templar
    assert action_module._shared_loader_obj == shared_loader_obj

# Generated at 2022-06-17 09:25:25.464717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-17 09:25:26.638209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:25:28.038926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:25:29.525945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:32.682982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:25:38.867096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class Connection
    connection = Connection()

    # Set the attribute _task of action_module to task
    action_module._task = task

    # Set the attribute _connection of action_module to connection
    action_module._connection = connection

    # Call method run of action_module
    action_module.run()


# Generated at 2022-06-17 09:25:39.469553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:25:41.554430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:52.523964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True
    assert am._supports_async_timeout == False
    assert am._supports_async_poll_interval == False
    assert am._supports_async_poll_interval_seconds == False
    assert am._supports_async_max_time == False
    assert am._supports_async_max_time_seconds == False
    assert am._supports_async_log_path == False
    assert am._supports_async_stdout_callback == False
    assert am._supports_async_stdout_lines == False
    assert am._supports_async_stdout_lines_delta == False
    assert am._supports

# Generated at 2022-06-17 09:27:40.327488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:27:41.325693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 09:27:46.698140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object
    mock_self = ActionModule()
    # Create a mock object
    mock_tmp = None
    # Create a mock object
    mock_task_vars = None
    # Call method run of class ActionModule
    result = mock_self.run(tmp=mock_tmp, task_vars=mock_task_vars)
    # Assertion
    assert result == None

# Generated at 2022-06-17 09:27:53.151897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal
    import ansible.plugins.action.copy
    import ansible.plugins.action.template
    import ansible.plugins.action.unarchive
    import ansible.plugins.action.synchronize
    import ansible.plugins.action.get_url
    import ansible.plugins.action.file
    import ansible.plugins.action.lineinfile
    import ansible.plugins.action.assemble
    import ansible.plugins.action.debug
    import ansible.plugins.action.script
    import ansible.plugins.action.service
    import ansible.plugins.action.shell
    import ansible.plugins.action.yum
    import ansible.plugins.action.apt
    import ansible.plugins.action.pip
    import ansible.plugins.action.git

# Generated at 2022-06-17 09:27:53.968710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:27:54.800787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:27:55.275264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:27:58.419422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:28:00.427520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default values
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-17 09:28:06.468312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader plugin
    shared_loader_plugin = MockSharedPluginLoader()
    # Create an action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_plugin)
    # Assert that the action module is not None
    assert action_module is not None
