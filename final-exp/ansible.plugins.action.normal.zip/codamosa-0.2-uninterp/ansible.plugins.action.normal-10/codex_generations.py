

# Generated at 2022-06-17 09:20:05.282529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:20:08.071562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:20:08.609232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:09.093371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:09.558162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:20.585116
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:24.320753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-17 09:20:32.284975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object
    class MockTask():
        def __init__(self):
            self.async_val = False
            self.action = 'setup'

    class MockConnection():
        def __init__(self):
            self.has_native_async = False

    class MockPlayContext():
        def __init__(self):
            self.check_mode = False
            self.no_log = False

    class MockLoader():
        def __init__(self):
            self.path_exists = False

    class MockVariableManager():
        def __init__(self):
            self.extra_vars = {}

    class MockModule():
        def __init__(self):
            self.params = {}


# Generated at 2022-06-17 09:20:37.487954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-17 09:20:41.495619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:20:44.779697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:45.469294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:47.208573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-17 09:20:48.647238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:21:01.684188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils finder
    module_utils_finder = MockModuleUtilsFinder()
    # Create a mock action base
    action_base = MockActionBase()
   

# Generated at 2022-06-17 09:21:02.558421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:03.653827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:21:15.542853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    import ansible.plugins.action.normal
    import ansible.plugins.action.copy
    import ansible.plugins.action.template
    import ansible.plugins.action.shell
    import ansible.plugins.action.script
    import ansible.plugins.action.debug
    import ansible.plugins.action.setup
    import ansible.plugins.action.command
    import ansible.plugins.action.file
    import ansible.plugins.action.synchronize
    import ansible.plugins.action.fetch
    import ansible.plugins.action.async_status
    import ansible.plugins.action.async_wrapper
    import ansible.plugins.action.include
    import ansible.plugins.action.include_vars
    import ansible.plugins.action.meta

# Generated at 2022-06-17 09:21:19.604954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:21:29.560993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock variable manager
    variable_manager = MockVariableManager()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()

    # Create a mock action module

# Generated at 2022-06-17 09:21:45.548284
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:46.542347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:21:56.114522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:22:00.080427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:22:12.438067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:22:14.993336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:22:28.008306
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:39.976887
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:22:51.187314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:22:53.699421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:05.656711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-17 09:23:06.379792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:06.753396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:10.152093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:23:18.730798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionModule()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module_utils finder
    module_utils_finder = MockModuleUtilsFinder()
    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils path
    module_utils_path = MockModule

# Generated at 2022-06-17 09:23:20.428735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:21.410400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-17 09:23:31.809802
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:23:32.661230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:23:38.950286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution

# Generated at 2022-06-17 09:24:04.699678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:24:05.788529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:24:18.294976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('module', (object,), {'run': lambda self: 'test'})
    # Create a mock object for the connection class
    mock_connection = type('connection', (object,), {'has_native_async': False})
    # Create a mock object for the task class
    mock_task = type('task', (object,), {'async_val': False})
    # Create a mock object for the ActionBase class
    mock_action_base = type('action_base', (object,), {'run': lambda self, tmp, task_vars: {}, '_execute_module': lambda self, task_vars, wrap_async: {}, '_remove_tmp_path': lambda self, tmpdir: {}})
    # Create an instance of the ActionModule

# Generated at 2022-06-17 09:24:27.808202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:31.892171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() == None

# Generated at 2022-06-17 09:24:39.239820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:24:44.454390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:46.406666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:49.660492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:24:50.278804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:49.159805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:49.763317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:58.432593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module._task == None
    assert action_module._connection == None
    assert action_module._play_context == None
    assert action_module._loader == None
    assert action_module._templar == None
    assert action_module._shared_loader_obj == None
    assert action_module._task_vars == None
    assert action_module._tmp == None
    assert action_module._task_vars_template_wrapper == None
    assert action_module._task_vars_template_wrapper_args == None
    assert action_module._task_vars_template_wrapper_kwargs == None
    assert action_module._task

# Generated at 2022-06-17 09:26:02.018310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:26:03.862278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Check if the instance is created
    assert action_module is not None

# Generated at 2022-06-17 09:26:12.341960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader plugin
    shared_loader_plugin = MockSharedLoaderPlugin()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock strategy plugin
    strategy_plugin = MockStrategyPlugin()
    # Create a mock terminal plugin
    terminal_plugin = MockTerminalPlugin()
    # Create a mock callback plugin
    callback_plugin = MockCallbackPlugin()
    # Create a mock connection plugin
    connection_plugin = MockConnectionPlugin()
    # Create a

# Generated at 2022-06-17 09:26:12.872634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:14.250016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-17 09:26:27.232411
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:29.541426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:28:37.627570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-17 09:28:38.198736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:28:39.736684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am is not None


# Generated at 2022-06-17 09:28:46.889104
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:28:49.563633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:50.121454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:52.773791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:28:53.402756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:54.891961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:28:57.215238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass