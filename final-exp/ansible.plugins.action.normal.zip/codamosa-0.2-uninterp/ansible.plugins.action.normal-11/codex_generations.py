

# Generated at 2022-06-17 09:20:07.509254
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:07.989455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:09.630225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:20:10.097205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:15.231782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:20:24.435680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    import os
    import sys
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    with open(path, 'w') as f:
        f.write("[defaults]\n")
        f.write("roles_path = %s\n" % tmpdir)
        f.write("library = %s\n" % tmpdir)
       

# Generated at 2022-06-17 09:20:25.059940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:27.246453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:20:28.661736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:20:36.802918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_

# Generated at 2022-06-17 09:20:49.486332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-17 09:21:00.368141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
   

# Generated at 2022-06-17 09:21:02.119494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 09:21:09.213822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

# Generated at 2022-06-17 09:21:19.863385
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:23.151165
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:21:24.008597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:25.389397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:21:27.344719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:21:35.466653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_

# Generated at 2022-06-17 09:21:46.000827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, module, action_plugin)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Create a mock wrap_async
    wrap_async = MockWrapAsync()
    # Create a mock tmp
    tmp = MockTmp()
    # Call method run of class ActionModule
    action_module.run(tmp, task_vars)
    # Check if method run of class ActionModule was called
   

# Generated at 2022-06-17 09:21:47.298927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:21:58.928562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:22:00.751775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    assert am is not None

# Generated at 2022-06-17 09:22:04.680450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:06.265943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:22:06.883842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-17 09:22:07.923773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:22:12.019980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:22.007636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    #

# Generated at 2022-06-17 09:22:35.711837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for ActionModule.run
    assert False

# Generated at 2022-06-17 09:22:38.924471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:41.120447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 09:22:43.362153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:52.674755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock object for the module
    module = ActionModule()
    # create a mock object for the connection
    connection = Connection()
    # create a mock object for the task
    task = Task()
    # create a mock object for the task_vars
    task_vars = TaskVars()
    # create a mock object for the tmp
    tmp = None
    # set the attributes of the mock object for the connection
    connection._shell = Shell()
    connection._shell.tmpdir = 'tmpdir'
    connection.has_native_async = False
    # set the attributes of the mock object for the task
    task.async_val = False
    # set the attributes of the mock object for the task_vars
    task_vars.action = 'action'
    # set the attributes of the mock object for the module
   

# Generated at 2022-06-17 09:22:56.250611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule
    """
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-17 09:23:02.711215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, module, action_plugin)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Call the run method of the action module
    action_module.run(tmp, task_vars)


# Generated at 2022-06-17 09:23:14.018137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock action module
    action_module = ActionModule(task, connection)
    # Create a mock result
    result = MockResult()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Call method run
    action_module.run(result, task_vars)
    # Check if method run of class ActionModule was called
    assert action_module.run_called == True
    # Check if method run of class ActionBase was called
    assert action_module.run_called_ActionBase == True
    # Check if method _execute_module was called
    assert action_module._execute_module_called == True
    # Check if method _remove_tmp_path was called


# Generated at 2022-06-17 09:23:15.175486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:16.370146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:23:51.887571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    # Create a mock connection
    mock_connection = MockConnection()
    # Create a mock task_vars
    mock_task_vars = MockTaskVars()
    # Create a mock module_name
    mock_module_name = MockModuleName()
    # Create a mock module_args
    mock_module_args = MockModuleArgs()
    # Create a mock module_executable
    mock_module_executable = MockModuleExecutable()
    # Create a mock module_name
    mock_module_name = MockModuleName()
    # Create a mock module_path
    mock_module_path = MockModulePath()
    # Create a mock module_name
    mock_module_name = MockModuleName()
    # Create a mock module_name
    mock_module_

# Generated at 2022-06-17 09:23:54.333717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-17 09:23:57.176586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:24:01.330790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid action
    action = ActionModule(dict(action='setup'))
    assert action.action == 'setup'

    # Test with an invalid action
    action = ActionModule(dict(action='invalid'))
    assert action.action == 'invalid'

# Generated at 2022-06-17 09:24:04.149037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:05.574564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-17 09:24:08.438427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:24:19.264127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:26.766848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid action
    action = ActionModule(None, None, 'ping', None, None, None, None, None, None)
    assert action._task.action == 'ping'

    # Test with an invalid action
    action = ActionModule(None, None, 'invalid', None, None, None, None, None, None)
    assert action._task.action == 'invalid'

# Generated at 2022-06-17 09:24:37.780565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 09:25:34.577916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:35.713041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:25:43.879598
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:25:44.602096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:25:53.372072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock action plugin
    action_plugin = MockActionPlugin()
    # create a mock module
    module = MockModule()
    # create a mock module_utils
    module_utils = MockModuleUtils()
    # create a mock module_utils.basic
    module_utils_basic = MockModuleUtilsBasic()
    # create a mock module_utils.basic.AnsibleModule
    module_utils_basic_AnsibleModule = MockModuleUtilsBasicAnsibleModule()
    # create a mock module_utils.basic.AnsibleModule.exit_json
    module_utils_basic_AnsibleModule_exit_json = MockModuleUtilsBasicAnsibleModuleExitJson()
    # create a mock

# Generated at 2022-06-17 09:25:58.811742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:25:59.945773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:00.545162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:01.160366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:03.870518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:01.748680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:28:02.566939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:28:08.719595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

# Generated at 2022-06-17 09:28:17.673004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, action_plugin)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock result
    result = MockResult()
    # Create a mock wrap_async
    wrap_async = MockWrapAsync()
   

# Generated at 2022-06-17 09:28:18.238157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:28:30.877406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:28:41.489883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, action_plugin)
    # Run the method run of the class ActionModule
    result = action_module.run()
    # Check the result
    assert result == {'skipped': False, 'invocation': {'module_name': 'mock_module'}, '_ansible_verbose_override': True}

# Unit test

# Generated at 2022-06-17 09:28:44.949264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:28:54.376546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    import ansible.constants as C
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:28:57.392857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)