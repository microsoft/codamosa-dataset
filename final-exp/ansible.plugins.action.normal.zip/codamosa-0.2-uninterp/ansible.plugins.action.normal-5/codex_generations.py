

# Generated at 2022-06-17 09:20:10.195680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = {
        'async': 0,
        'async_val': 0,
        'action': 'setup'
    }

    # Create a mock connection
    connection = {
        'has_native_async': False
    }

    # Create a mock loader
    loader = {
        '_basedir': '',
        '_get_basedir': lambda: '',
        '_get_file_args': lambda: {},
        'path_dwim': lambda: ''
    }

    # Create a mock play context

# Generated at 2022-06-17 09:20:21.044513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook import Play
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars


# Generated at 2022-06-17 09:20:22.359625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:20:33.632477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_2 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_3 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_4 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_5 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_6 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_7 = MockActionPlugin()
   

# Generated at 2022-06-17 09:20:47.341944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import shutil
    import ansible.plugins.action
    import ansible.plugins.action.copy
    import ansible.plugins.action.template
    import ansible.plugins.action.unarchive
    import ansible.plugins.action.file
    import ansible.plugins.action.script
    import ansible.plugins.action.yum
    import ansible.plugins.action.apt
    import ansible.plugins.action.service
    import ansible.plugins.action.command
    import ansible.plugins.action.setup
    import ansible.plugins.action.ping
    import ansible.plugins.action.raw
    import ansible.plugins.action.win_command
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_file

# Generated at 2022-06-17 09:20:48.186396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:50.009109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:51.529338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:54.405877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:20:55.286308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:00.107475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:08.366096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    # Create a mock connection
    mock_connection = MockConnection()
    # Create a mock action module
    mock_action_module = MockActionModule(mock_task, mock_connection)
    # Create a mock task vars
    mock_task_vars = MockTaskVars()
    # Create a mock result
    mock_result = MockResult()
    # Create a mock wrap async
    mock_wrap_async = MockWrapAsync()
    # Create a mock execute module
    mock_execute_module = MockExecuteModule()
    # Create a mock remove tmp path
    mock_remove_tmp_path = MockRemoveTmpPath()
    # Create a mock tmp
    mock_tmp = MockTmp()
    # Call the run method of the action module
    mock_

# Generated at 2022-06-17 09:21:18.215208
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:20.256344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:21.910025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:21:22.694524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:23.566063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:27.275482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Check if the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:21:35.435413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:21:37.203050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:49.728757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action module
    action_module = ActionModule(task, connection, module)
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Create a mock wrap async
    wrap_async = MockWrapAsync()
    # Create a mock execute module
    execute_module = MockExecuteModule()
    # Create a mock remove tmp path
    remove_tmp_path = MockRemoveTmpPath()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock skipped
    skipped = MockSkipped()
    # Create a mock invocation


# Generated at 2022-06-17 09:21:50.749981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:21:52.781787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no_log
    # Test with wrap_async
    # Test with wrap_async and no_log
    pass

# Generated at 2022-06-17 09:21:56.952311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:21:58.930523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:05.614192
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:07.471800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:13.101688
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:13.739899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:14.784274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this unit test
    pass

# Generated at 2022-06-17 09:22:33.664804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task object
    task = MockTask()
    # create a mock connection object
    connection = MockConnection()
    # create a mock action plugin
    action_plugin = MockActionModule()
    # create a mock module plugin
    module_plugin = MockModulePlugin()
    # create a mock module loader
    module_loader = MockModuleLoader()
    # create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # create a mock action base object
    action_base_obj = MockActionBase()
    # create a mock action base object
    module_utils_obj = MockModuleUtils()
    # create a mock action base object
    module_obj = MockModule()
    # create a mock action base

# Generated at 2022-06-17 09:22:35.903488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:49.165159
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:23:01.419024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
   

# Generated at 2022-06-17 09:23:02.219761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:04.268842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:23:05.493354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:23:07.113151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:23:08.196391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:23:10.642158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:23:39.739330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_2 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_3 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_4 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_5 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_6 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_7 = MockActionPlugin()

# Generated at 2022-06-17 09:23:52.040636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_

# Generated at 2022-06-17 09:23:57.033422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:24:06.180936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default values
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module._task == None
    assert action_module._connection == None
    assert action_module._play_context == None
    assert action_module._loader == None
    assert action_module._templar == None
    assert action_module._shared_loader_obj == None
    assert action_module._task_vars == None
    assert action_module._tmp == None
    assert action_module._task_vars_tmp == None
    assert action_module._tmp_path == None
    assert action_

# Generated at 2022-06-17 09:24:07.011801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:24:08.244327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:09.209465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:24:18.112773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock action module
    action_module = ActionModule(task, connection)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Create a mock wrap_async
    wrap_async = MockWrapAsync()
    # Create a mock tmp
    tmp = MockTmp()
    # Call the method run of class ActionModule
    action_module.run(tmp, task_vars)


# Generated at 2022-06-17 09:24:27.549475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, variable_manager)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Call method run of class ActionModule
    result = action_plugin.run(tmp, task_vars)
    # Check the result

# Generated at 2022-06-17 09:24:31.631147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-17 09:25:26.099708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:25:38.414230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
   

# Generated at 2022-06-17 09:25:42.512058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:25:44.357772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 09:25:49.593284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()
    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()
    # Set the attribute _task of action_module to ansible_task
    action_module._task = ansible_task
    # Set the attribute _connection of action_module to ansible_connection
    action_module._connection = ansible_connection
    # Create a dictionary
    tmp = {}
    # Create a dictionary
    task_vars = {}
    # Call method run of action_module with parameters tmp and task_vars
    result = action_module.run(tmp, task_vars)
    # Check if result is equal to {}
    assert result == {}


# Generated at 2022-06-17 09:25:50.415028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:25:58.029208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    mock_ActionModule = ActionModule(None, None, None, None)
    # Create a mock object of class Task

# Generated at 2022-06-17 09:26:02.706850
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:12.044414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock play context object
    play_context = MockPlayContext()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader = MockSharedLoader()
    # Create a mock variable manager object
    variable_manager = MockVariableManager()
    # Create a mock module_utils loader object
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock action plugin object

# Generated at 2022-06-17 09:26:13.055565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-17 09:28:11.107396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:14.395424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:23.413371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 09:28:31.527462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal
    import ansible.plugins.action.copy
    import ansible.plugins.action.setup
    import ansible.plugins.action.template
    import ansible.plugins.action.file
    import ansible.plugins.action.lineinfile
    import ansible.plugins.action.assemble
    import ansible.plugins.action.stat
    import ansible.plugins.action.debug
    import ansible.plugins.action.get_url
    import ansible.plugins.action.uri
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_template
    import ansible.plugins.action.win_file
    import ansible.plugins.action.win_lineinfile
    import ansible.plugins.action.win_get_url
    import ansible

# Generated at 2022-06-17 09:28:42.571283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:28:45.580341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:28:50.119836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:28:52.774874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:28:53.402789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:54.705080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No test for method run of class ActionModule"