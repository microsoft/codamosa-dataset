

# Generated at 2022-06-17 09:20:08.374701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.include import Include
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-17 09:20:08.884113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:14.409959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:20:23.576259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    # Create a mock connection
    mock_connection = MockConnection()
    # Create a mock module
    mock_module = MockModule()
    # Create a mock action plugin
    mock_action_plugin = MockActionPlugin()
    # Create a mock action module
    mock_action_module = MockActionModule()
    # Create a mock task_vars
    mock_task_vars = MockTaskVars()
    # Create a mock result
    mock_result = MockResult()
    # Create a mock tmp
    mock_tmp = MockTmp()
    # Create a mock wrap_async
    mock_wrap_async = MockWrapAsync()

    # Set the attributes of the mock objects
    mock_task.action = 'setup'
    mock_task.async_val

# Generated at 2022-06-17 09:20:32.829023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('MockModule', (object,), {'run': lambda self, tmp=None, task_vars=None: {'skipped': True}})
    # Create a mock object for the connection class
    mock_connection = type('MockConnection', (object,), {'has_native_async': False})
    # Create a mock object for the task class
    mock_task = type('MockTask', (object,), {'async_val': False})
    # Create a mock object for the action base class

# Generated at 2022-06-17 09:20:34.082054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:40.272439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:20:41.347771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:42.426049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:44.645281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:20:53.009902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:20:54.778939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:55.288135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:04.985565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Create a mock invocation
    invocation = MockInvocation()
    # Create a mock module_args
    module_args = MockModuleArgs()
    # Create a mock wrap_async
    wrap_async = MockWrapAsync()
    # Create a mock tmp
   

# Generated at 2022-06-17 09:21:07.674418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:13.307117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-17 09:21:15.430974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:21:17.286065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-17 09:21:24.486876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    a = ActionModule()
    assert a._supports_check_mode == True
    assert a._supports_async == True

    # Test with arguments
    a = ActionModule(connection=None, task=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a._supports_check_mode == True
    assert a._supports_async == True

# Generated at 2022-06-17 09:21:25.907076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:34.175785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Check if the instance is of type ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:21:37.886980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:21:38.490943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:47.390626
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:59.607048
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:00.508032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:22:02.872233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:22:13.478545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = Mock()
    mock_task.async_val = False
    mock_task.action = 'setup'

    # Create a mock connection
    mock_connection = Mock()
    mock_connection.has_native_async = False
    mock_connection._shell.tmpdir = 'tmpdir'

    # Create a mock module
    mock_module = Mock()
    mock_module.run.return_value = {'ansible_facts': {'test': 'test'}}

    # Create a mock loader
    mock_loader = Mock()
    mock_loader.get_basedir.return_value = 'basedir'

    # Create a mock play context
    mock_play_context = Mock()
    mock_play_context.check_mode = False

    # Create a mock variable manager
    mock

# Generated at 2022-06-17 09:22:14.967350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:22:18.355607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:22:33.239034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:22:40.921583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create an action module
    action_module = ActionModule(task, connection, module, action_plugin)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Call method run of class ActionModule
    result = action_module.run(task_vars=task_vars)
    # Assert that the result is equal to the expected result

# Generated at 2022-06-17 09:22:51.670362
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:52.468971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:22:53.850533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:55.124958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:22:56.060920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:01.584633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, module, action_plugin)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Create a mock wrap_async
    wrap_async = MockWrapAsync()
    # Create a mock tmp
    tmp = MockTmp()
    # Call the method run of class ActionModule
    action_module.run(tmp, task_vars)


# Generated at 2022-06-17 09:23:13.621789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:23:21.229050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock module object
    module = MockModule()
    # Create a mock action plugin object
    action_plugin = ActionModule(task, connection, module)
    # Create a mock task_vars object
    task_vars = MockTaskVars()
    # Create a mock tmp object
    tmp = MockTmp()
    # Call method run of class ActionModule
    result = action_plugin.run(tmp, task_vars)
    # Assert that the result is a dictionary
    assert isinstance(result, dict)


# Generated at 2022-06-17 09:23:53.462118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_2 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_3 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_4 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_5 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_6 = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_7 = MockActionPlugin()
   

# Generated at 2022-06-17 09:23:55.155020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:24:04.996338
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:12.346937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.init import Inventory
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars


# Generated at 2022-06-17 09:24:17.925941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    a = ActionModule()
    assert a._supports_check_mode == True
    assert a._supports_async == True

    # Test with arguments
    a = ActionModule(connection=None, task=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a._supports_check_mode == True
    assert a._supports_async == True

# Generated at 2022-06-17 09:24:18.745442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:19.998116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:21.351760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:24:32.194961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('MockModule', (object,), {'run': lambda self, tmp=None, task_vars=None: {'skipped': False, 'invocation': {'module_args': 'test'}}})
    # Create a mock object for the connection class
    mock_connection = type('MockConnection', (object,), {'has_native_async': False})
    # Create a mock object for the task class
    mock_task = type('MockTask', (object,), {'async_val': False})
    # Create a mock object for the action base class

# Generated at 2022-06-17 09:24:39.480705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal as action_normal
    import ansible.plugins.action.copy as action_copy
    import ansible.plugins.action.template as action_template
    import ansible.plugins.action.shell as action_shell
    import ansible.plugins.action.command as action_command
    import ansible.plugins.action.setup as action_setup
    import ansible.plugins.action.script as action_script
    import ansible.plugins.action.include as action_include
    import ansible.plugins.action.include_role as action_include_role
    import ansible.plugins.action.include_tasks as action_include_tasks
    import ansible.plugins.action.pause as action_pause
    import ansible.plugins.action.wait_for as action_wait_for

# Generated at 2022-06-17 09:25:42.311278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils finder
    module_utils_finder = MockModuleUtilsFinder()
    # Create a mock action base

# Generated at 2022-06-17 09:25:50.561281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

    # Test with arguments
    action_module = ActionModule(task=1, connection=2, play_context=3, loader=4, templar=5, shared_loader_obj=6)
    assert action_module._task == 1
    assert action_module._connection == 2
    assert action_module._play_context == 3
    assert action_module._loader == 4
    assert action_module._templar == 5
    assert action_module._shared_loader_obj == 6

# Generated at 2022-06-17 09:25:52.627353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:55.882207
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:00.180030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:26:01.200071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    assert False

# Generated at 2022-06-17 09:26:11.936603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class under test
    action_module = ActionModule()
    # create a mock object to replace the one the class under test depends on
    mock_task = Mock()
    # set the attributes of the mock object
    mock_task.action = 'setup'
    mock_task.async_val = None
    # bind the mock object to the class under test
    action_module._task = mock_task
    # create a mock object to replace the one the class under test depends on
    mock_connection = Mock()
    # set the attributes of the mock object
    mock_connection.has_native_async = False
    # bind the mock object to the class under test
    action_module._connection = mock_connection
    # create a mock object to replace the one the class under test depends on
    mock_execute_module = Mock()

# Generated at 2022-06-17 09:26:12.983452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:20.638474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:26:22.809876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:28:21.471421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:31.001865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create an action module
    action_module = ActionModule(task, connection, '/path/to/ansible/lib/ansible/modules/', 'test_module')

    # Check that the action module is correctly initialized
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._shared_loader_obj == '/path/to/ansible/lib/ansible/modules/'
    assert action_module._action_name == 'test_module'
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True


# Generated at 2022-06-17 09:28:31.789696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:39.895178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock action module object
    action_module = ActionModule(task, connection)
    # Create a mock result object
    result = MockResult()
    # Create a mock task_vars object
    task_vars = MockTaskVars()
    # Create a mock wrap_async object
    wrap_async = MockWrapAsync()
    # Call the run method of class ActionModule
    action_module.run(result, task_vars, wrap_async)


# Generated at 2022-06-17 09:28:46.990627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_

# Generated at 2022-06-17 09:28:49.560523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:59.793208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_

# Generated at 2022-06-17 09:29:00.235093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:02.252280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:29:03.033675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)