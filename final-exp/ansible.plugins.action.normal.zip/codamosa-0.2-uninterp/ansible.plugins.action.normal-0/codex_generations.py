

# Generated at 2022-06-17 09:20:08.285427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a fake task
    task = dict(action=dict(module='shell', args='ls'))
    # create a fake connection
    connection = dict(name='local', transport='local')
    # create a fake play context
    play_context = dict(become=False, become_method=None, become_user=None, check_mode=False, diff=False)

    # create the object under test
    action_module = ActionModule(task, connection, play_context, loader=None, templar=None, shared_loader_obj=None)

    # test the constructor
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._play_context == play_context
    assert action_module._loader == None
    assert action_module._templar == None
    assert action_

# Generated at 2022-06-17 09:20:10.194858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:20:10.984839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:12.947327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None) is not None

# Generated at 2022-06-17 09:20:22.418102
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:23.801814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:20:33.980929
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:39.132702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-17 09:20:40.753676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:20:41.348408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:51.435929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection
    task = MockTask()
    connection = MockConnection()

    # Create a mock action module
    action_module = ActionModule(task, connection)

    # Create a mock result
    result = dict(
        skipped=False,
        invocation=dict(
            module_args=dict(
                _ansible_verbose_override=True,
                _ansible_no_log=True,
            )
        )
    )

    # Create a mock task_vars
    task_vars = dict(
        _ansible_verbose_override=True,
        _ansible_no_log=True,
    )

    # Create a mock execute_module

# Generated at 2022-06-17 09:20:54.350460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-17 09:20:55.174174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:57.111800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:21:07.696570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal
    import ansible.playbook.task
    import ansible.vars.manager
    import ansible.utils.vars
    import ansible.utils.template
    import ansible.template
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.role_include
    import ansible.playbook.block
    import ansible.executor.task_queue_manager
    import ansible.executor.playbook_executor
    import ansible.plugins.loader
    import ansible.plugins.strategy
    import ansible.plugins.action
    import ans

# Generated at 2022-06-17 09:21:10.848329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-17 09:21:20.397824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 09:21:22.621945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:21:24.081408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:33.282136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock task queue manager
    task_queue_manager = MockTaskQueueManager()
    # Create a mock inventory
    inventory = MockInventory()
    # Create a mock strategy
    strategy

# Generated at 2022-06-17 09:21:40.180529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:21:41.008833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:41.559214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:42.183017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:43.329262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None) is not None

# Generated at 2022-06-17 09:21:46.367890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:47.326758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:47.911424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:00.080284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    # Create a mock connection
    mock_connection = MockConnection()
    # Create a mock module
    mock_module = MockModule()
    # Create a mock action plugin
    mock_action_plugin = MockActionPlugin()
    # Create a mock action module
    mock_action_module = ActionModule(mock_task, mock_connection, mock_module, mock_action_plugin)
    # Create a mock task_vars
    mock_task_vars = MockTaskVars()
    # Create a mock result
    mock_result = MockResult()
    # Create a mock wrap_async
    mock_wrap_async = MockWrapAsync()
    # Create a mock tmp
    mock_tmp = MockTmp()
    # Create a mock tmp_path
    mock_

# Generated at 2022-06-17 09:22:01.884420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:13.051754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:14.082191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:22:14.684729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:23.364125
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:36.159717
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:49.394765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True
    assert am._supports_async_timeout == True
    assert am._supports_async_poll_delay == True
    assert am._supports_async_poll_interval == True
    assert am._supports_async_timeout_sec == True
    assert am._supports_async_timeout_min == True
    assert am._supports_async_timeout_hours == True
    assert am._supports_async_timeout_days == True
    assert am._supports_async_timeout_weeks == True
    assert am._supports_async_timeout_months == True
    assert am._supports_async_timeout_years == True


# Generated at 2022-06-17 09:22:50.517413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:53.490131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:54.145743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:02.711374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:23:26.164640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:23:34.373737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 09:23:40.395195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True
    assert am._task == None
    assert am._connection == None
    assert am._play_context == None
    assert am._loader == None
    assert am._templar == None
    assert am._shared_loader_obj == None
    assert am._action == None
    assert am._task_vars == None
    assert am._tmp == None
    assert am._play_context == None
    assert am._loader == None
    assert am._templar == None
    assert am._shared_loader_obj == None
    assert am._connection == None
    assert am._task_vars == None
    assert am._tmp == None
    assert am._play_context == None


# Generated at 2022-06-17 09:23:52.405560
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:23:54.130238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:04.518570
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:05.948548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:24:18.294986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:22.234609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:24:23.043711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:16.602517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-17 09:25:17.511530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:25:25.998684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:25:27.984610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-17 09:25:40.191399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(
        task=dict(action='test'),
        connection=dict(host='localhost', port=22),
        play_context=dict(remote_addr='127.0.0.1'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

    # Test with invalid arguments
    try:
        action_module = ActionModule(
            task=dict(action='test'),
            connection=dict(host='localhost', port=22),
            play_context=dict(remote_addr='127.0.0.1'),
            loader=None,
            templar=None,
            shared_loader_obj=None
        )
        assert False
    except:
        assert True

# Generated at 2022-06-17 09:25:43.700447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:25:46.153712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:25:49.161742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:50.072946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:25:57.739156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock module
    module = MockModule()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock action module
    action_module = ActionModule(task, connection, module, action_plugin)

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Call method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert that the result is not None
    assert result is not None


# Generated at 2022-06-17 09:27:45.404701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:27:47.001385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:27:47.961311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None) is not None

# Generated at 2022-06-17 09:27:54.272646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    mock_ActionModule = ActionModule()

    # Create a mock object of class Task
    mock_Task = Task()

    # Create a mock object of class Connection
    mock_Connection = Connection()

    # Create a mock object of class Shell
    mock_Shell = Shell()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

# Generated at 2022-06-17 09:28:04.127026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import callback_loader

    # Create a mock task
    task = Task()
    task._role = None
    task.action = 'setup'
    task.args = {}
    task.async_val = None
    task

# Generated at 2022-06-17 09:28:07.244302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:28:09.429911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:28:10.924865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:28:21.488002
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:28:25.570016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass