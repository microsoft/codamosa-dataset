

# Generated at 2022-06-17 09:19:59.061611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:20:02.985064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:20:03.686359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:14.566856
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:20:23.937568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = {
        'action': 'setup',
        'async': 0,
        'async_val': 0,
        'delegate_to': None,
        'delegate_facts': False,
        'loop': None,
        'loop_args': None,
        'loop_control': {},
        'module_args': {},
        'name': 'setup',
        'notify': [],
        'register': 'setup_result',
        'retries': 3,
        'until': None,
        'until_retries': 5,
        'when': None,
    }

    # Create a mock connection

# Generated at 2022-06-17 09:20:24.598142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:28.198563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:20:28.994255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:29.463297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:37.521682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_

# Generated at 2022-06-17 09:20:50.127360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock variable manager object
    variable_manager = MockVariableManager()
    # Create a mock action plugin object
    action_plugin = MockActionModule()
    # Create a mock action plugin object
    action_plugin.task = task
    action_plugin.connection = connection
    action_plugin.loader = loader
    action_plugin.variable_manager = variable_manager
    # Create a mock result object
    result = MockResult()
    # Create a mock tmp object
    tmp = MockTmp()
    # Create a mock task_vars object
    task_vars = MockTaskVars()
    # Create a mock wrap_async object
    wrap

# Generated at 2022-06-17 09:20:51.530821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:52.156775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:03.996164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 09:21:15.965353
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:17.193582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:18.674616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:21:20.332614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:21.417461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:22.266118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:30.234484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-17 09:21:33.166793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a test object
    action_module = ActionModule()
    # Check if the object is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:21:33.969604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-17 09:21:44.614696
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:55.586145
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:57.744289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:22:10.855306
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:11.543855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:12.496754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-17 09:22:13.089618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:24.562305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:36.866160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 09:22:37.735458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:22:38.378261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:40.274930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:51.339544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    mock_task = type('MockTask', (object,), dict(action='MockAction', async_val=False))()
    # Create a mock connection
    mock_connection = type('MockConnection', (object,), dict(has_native_async=False))()
    # Create a mock play context
    mock_play_context = type('MockPlayContext', (object,), dict(check_mode=False))()
    # Create a mock loader
    mock_loader = type('MockLoader', (object,), dict(get_basedir=lambda x: '/path/to/playbook'))()
    # Create a mock variable manager
    mock_variable_manager = type('MockVariableManager', (object,), dict(get_vars=lambda x,y: dict(foo='bar')))()


# Generated at 2022-06-17 09:22:59.785823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp()

# Generated at 2022-06-17 09:23:01.375102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:13.459022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    import ansible.playbook.task
    import ansible.utils.vars
    import ansible.utils.template
    import ansible.utils.vars
    import ansible.vars
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.executor.task_queue_manager
    import ansible.executor.playbook_executor
    import ansible.plugins.loader
    import ansible.plugins.connection.local
    import ansible.plugins.connection.ssh
    import ansible.plugins.strategy.linear
    import ansible.plugins.strategy

# Generated at 2022-06-17 09:23:15.051872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:23:48.445213
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:23:51.054086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 09:24:03.831513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_

# Generated at 2022-06-17 09:24:04.668891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:24:05.717912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:24:18.259195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default values
    module = ActionModule()
    assert module._supports_check_mode == True
    assert module._supports_async == True
    assert module._connection == None
    assert module._task == None
    assert module._loader == None
    assert module._templar == None
    assert module._shared_loader_obj == None
    assert module._connection_loader == None
    assert module._play_context == None
    assert module._loaded_fragment_name == None
    assert module._task_vars == None
    assert module._templar._available_variables == None
    assert module._task.action == None
    assert module._task.args == None
    assert module._task.async_val == None
    assert module._task.async_seconds == None
    assert module._task.delegate

# Generated at 2022-06-17 09:24:23.096615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:24:32.764641
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:33.330046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:44.087141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:25:52.607704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:25:56.282004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:25:58.706196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:26:08.778057
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:26:09.531392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:13.130913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:26:15.106268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-17 09:26:19.264682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-17 09:26:22.023764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:26:32.013904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal as action_normal
    import ansible.plugins.connection.local as connection_local
    import ansible.plugins.loader as loader
    import ansible.vars.manager as vars_manager
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars

# Generated at 2022-06-17 09:28:39.534426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:46.752900
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:28:50.337124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:28:52.088676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:00.565904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    import os
    import json


# Generated at 2022-06-17 09:29:01.605026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:29:11.871616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_ActionModule_run: tests run method of class ActionModule

    # create an instance of the class ActionModule
    action_module = ActionModule()

    # create an instance of the class Task
    task = Task()

    # create an instance of the class Connection
    connection = Connection()

    # create an instance of the class PlayContext
    play_context = PlayContext()

    # create an instance of the class AnsibleModule
    ansible_module = AnsibleModule()

    # create an instance of the class AnsibleModule
    ansible_module_2 = AnsibleModule()

    # create an instance of the class AnsibleModule
    ansible_module_3 = AnsibleModule()

    # create an instance of the class AnsibleModule
    ansible_module_4 = AnsibleModule()

    # create an instance of the class AnsibleModule


# Generated at 2022-06-17 09:29:12.857737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:21.728015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a fake task
    task = dict(action=dict(module='shell', args='ls'))
    # create a fake play
    play = dict(hosts='localhost', gather_facts='no', tasks=[task])
    # create a fake loader
    loader = dict(path='/tmp')
    # create a fake variable manager
    variable_manager = dict(extra_vars=dict(hostvars=dict()))
    # create a fake inventory
    inventory = dict(host_list=[dict(name='localhost', port=22)])
    # create a fake connection
    connection = dict(host='localhost', port=22)
    # create a fake shell
    shell = dict(tmpdir='/tmp')
    # create a fake connection plugin
    connection_plugin = dict(connection=connection, shell=shell)
    # create a fake

# Generated at 2022-06-17 09:29:22.229532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass