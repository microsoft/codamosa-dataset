

# Generated at 2022-06-17 09:20:10.287932
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:10.987025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:13.285342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the method run of class ActionModule
    # Setup
    # Test
    # Assert
    pass

# Generated at 2022-06-17 09:20:17.447994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule()
    assert action_module is not None
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:20:24.167227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    mock_task.async_val = False
    mock_task.action = 'setup'

    # Create a mock connection
    mock_connection = MockConnection()
    mock_connection.has_native_async = False

    # Create a mock module
    mock_module = MockModule()

    # Create a mock action
    mock_action = MockAction()
    mock_action._task = mock_task
    mock_action._connection = mock_connection
    mock_action._execute_module = mock_module.run

    # Create a mock task_vars
    mock_task_vars = MockTaskVars()

    # Test run method of class ActionModule
    result = mock_action.run(task_vars=mock_task_vars)

# Generated at 2022-06-17 09:20:26.186354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:20:34.752709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock module
    module = MockModule()

    # Create a mock action module
    action_module = ActionModule(task, connection, module)

    # Create a mock task_vars
    task_vars = {}

    # Execute the method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert the result

# Generated at 2022-06-17 09:20:39.681710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._supports_check_mode == True
    assert a._supports_async == True

# Generated at 2022-06-17 09:20:49.819113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module_utils finder
    module_utils_finder = MockModuleUtilsFinder()
    # Create a mock module_utils loader
    module_utils_loader = MockModuleUtilsLoader()
    # Create a mock module_utils path
    module_utils_path = MockModule

# Generated at 2022-06-17 09:20:51.485715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:55.174004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:56.541837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:00.361346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-17 09:21:03.001252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:21:04.058189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None) is not None

# Generated at 2022-06-17 09:21:05.076228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:21:08.247297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_ActionModule_run()
    # TODO: implement this
    pass

# Generated at 2022-06-17 09:21:11.308624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:21:12.595239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:20.478834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, variable_manager, action_plugin)
    # Create a mock result
    result = MockResult()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Call the run method of the action module
    action_module.run(result, task_vars)


# Generated at 2022-06-17 09:21:27.887801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:29.257474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:29.881957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:31.396765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:21:43.000511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import ActionModuleComponent
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:21:55.429702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    am = ActionModule()
    # Create an instance of class Task
    t = Task()
    # Create an instance of class TaskExecutor
    te = TaskExecutor()
    # Create an instance of class Connection
    c = Connection()
    # Create an instance of class PlayContext
    pc = PlayContext()
    # Create an instance of class Play
    p = Play()
    # Create an instance of class Playbook
    pb = Playbook()
    # Create an instance of class Runner
    r = Runner()
    # Create an instance of class DataLoader
    dl = DataLoader()
    # Create an instance of class Inventory
    i = Inventory()
    # Create an instance of class VariableManager
    vm = VariableManager()
    # Create an instance of class VaultSecret
    vs = VaultSecret()
   

# Generated at 2022-06-17 09:22:03.789805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('', (), {})()
    mock_module.run = ActionModule.run
    mock_module.run.__doc__ = ActionModule.run.__doc__
    mock_module.run.__name__ = ActionModule.run.__name__

    # Create a mock object for the module class
    mock_module_class = type('', (), {})()
    mock_module_class.run = ActionModule.run
    mock_module_class.run.__doc__ = ActionModule.run.__doc__
    mock_module_class.run.__name__ = ActionModule.run.__name__

    # Create a mock object for the module class
    mock_module_class_2 = type('', (), {})()

# Generated at 2022-06-17 09:22:13.998613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-17 09:22:16.017332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:18.127543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:22:33.336339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:22:33.813965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:38.898102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None) is not None

# Generated at 2022-06-17 09:22:47.799676
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:58.624871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils.basic
    module_utils_basic = MockModuleUtilsBasic()
    # Create a mock module_utils.basic.AnsibleModule
    module_utils_basic_AnsibleModule = MockModuleUtilsBasicAnsibleModule()
    # Create a mock module_utils.basic.AnsibleModule.exit_json
    module_utils_basic_AnsibleModule_exit_json = MockModuleUtilsBasicAnsibleModuleExitJson()
    # Create a mock

# Generated at 2022-06-17 09:22:59.736278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:12.970140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock module
    module = MockModule()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock action module
    action_module = ActionModule(task, connection, module, action_plugin)

    # Create a mock task_vars
    task_vars = {}

    # Call method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert that the result is correct

# Generated at 2022-06-17 09:23:22.815529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no_log set to True
    task_vars = dict(no_log=True)
    tmp = None
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    result = action_module.run(tmp, task_vars)
    assert result.get('invocation', {}).get('module_args') is None
    assert result.get('skipped') is False
    assert result.get('_ansible_verbose_override') is True

    # Test with no_log set to False
    task_vars = dict(no_log=False)
    tmp = None

# Generated at 2022-06-17 09:23:24.753597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:23:29.997998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:24:04.019939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:06.977350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:24:18.431988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock result
    result = MockResult()
    # Create a mock invocation
    invocation = MockInvocation()
    # Create a mock

# Generated at 2022-06-17 09:24:27.918491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-17 09:24:38.528787
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:48.956082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    # Create a mock connection
    mock_connection = MockConnection()
    # Create a mock action plugin
    mock_action_plugin = MockActionPlugin()
    # Create a mock action module
    mock_action_module = ActionModule(mock_task, mock_connection, mock_action_plugin._shared_loader_obj)
    # Create a mock result
    mock_result = MockResult()
    # Create a mock task_vars
    mock_task_vars = MockTaskVars()
    # Create a mock wrap_async
    mock_wrap_async = MockWrapAsync()
    # Create a mock tmp
    mock_tmp = MockTmp()
    # Call the method run of class ActionModule

# Generated at 2022-06-17 09:24:49.889158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:50.553316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:59.692518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:25:02.973830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:26:08.379374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:26:09.328124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:16.834710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:26:20.409764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Check if the instance is created
    assert action_module is not None

# Generated at 2022-06-17 09:26:33.352080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_

# Generated at 2022-06-17 09:26:35.388347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:26:36.735431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:26:45.826101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleError
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:26:57.580144
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:59.948406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionBase
    mock_action_base = ActionBase()
    # Create a mock object of class ActionModule
    mock_action_module = ActionModule()
    # Create a mock object of class ActionModule
    mock_action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-17 09:29:12.825189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:29:20.970651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, module, action_plugin)

    # Call method run of class ActionModule
    result = action_module.run()

    # Assert that the result is correct
    assert result == {'invocation': {'module_name': 'mock_module'}, 'changed': False, '_ansible_verbose_override': True}


# Generated at 2022-06-17 09:29:22.124437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:29:25.142401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:29:32.918298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, module, action_plugin)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)
    # Assert result is not None
    assert result is not None


# Generated at 2022-06-17 09:29:37.393925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:29:44.161768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    import ansible.constants as C
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves import StringIO

# Generated at 2022-06-17 09:29:54.388510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    import ansible.plugins.action.normal as action_normal
    import ansible.utils.vars as ansible_vars
    import ansible.utils.module_docs as ansible_module_docs
    import ansible.utils.template as ansible_template
    import ansible.utils.path as ansible_path
    import ansible.utils.display as ansible_display
    import ansible.utils.unicode as ansible_unicode
    import ansible.utils.unsafe_proxy as ansible_unsafe_proxy
    import ansible.utils.unsafe_proxy.wrap_var as ansible_unsafe_proxy_wrap_var
    import ansible.utils.unsafe_proxy.UnsafeText as ansible_unsafe_proxy_UnsafeText

# Generated at 2022-06-17 09:29:56.603537
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:30:04.118627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict()
    task['async'] = 0
    task['async_val'] = 0
    task['action'] = 'setup'

    # Create a mock connection
    connection = dict()
    connection['has_native_async'] = False

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock _task
    _task = dict()
    _task['async'] = 0
    _task['async_val'] = 0
    _task['action'] = 'setup'

    # Create a mock _connection
    _connection = dict()
    _connection['has_native_async'] = False

    # Create a mock _supports_check_mode