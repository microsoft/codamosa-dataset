

# Generated at 2022-06-17 09:20:05.279420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock variable manager
    variable_manager = MockVariableManager()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create an action module
    action_module = ActionModule(task, connection, loader, variable_manager, action_plugin)

    # Create a mock result
    result = MockResult()

    # Create a mock task variables
    task_vars = MockTaskVars()

    # Call method run of class ActionModule
    action_module.run(result, task_vars)

    # Assert that method run of class ActionModule was called
    assert action_module.run.called

    # Assert that method run of

# Generated at 2022-06-17 09:20:14.703126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    sys.path.append('/home/ansible/ansible/lib/ansible/plugins/action')
    from ActionModule import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:20:24.121862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:20:33.241902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:20:47.244633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:20:48.987778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:20:51.091046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:21:03.215171
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:04.310572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:21:15.390370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no_log
    action_module = ActionModule()
    action_module._task = {'async_val': None, 'action': 'setup'}
    action_module._connection = {'has_native_async': False}
    action_module._remove_tmp_path = lambda x: None
    action_module._execute_module = lambda x, y: {'skipped': False}
    result = action_module.run(tmp=None, task_vars=None)
    assert result['invocation'] == {}

    # Test with async
    action_module = ActionModule()
    action_module._task = {'async_val': 10, 'action': 'setup'}
    action_module._connection = {'has_native_async': False}

# Generated at 2022-06-17 09:21:20.185494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:21:30.854897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock action module
    action_module = ActionModule(task, connection)
    # Create a mock result
    result = MockResult()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock wrap_async
    wrap_async = MockWrapAsync()
    # Call the method run of the action module
    action_module.run(tmp, task_vars)


# Generated at 2022-06-17 09:21:31.807173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:33.250459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:21:35.451125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:21:36.574681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:48.193508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-17 09:21:49.004409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-17 09:21:49.631163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:50.651859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:58.929579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:21:59.575609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:11.795835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:22:19.639747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig

# Generated at 2022-06-17 09:22:20.595856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:22:25.351260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:22:37.208055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:22:49.393443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default values
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

    # Test with custom values
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, supports_check_mode=False, supports_async=False)
    assert action_module._supports_check_mode == False
    assert action_module._supports_async == False

# Generated at 2022-06-17 09:23:01.419039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:23:04.101361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:23:23.654729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task
    task = {'action': 'setup', 'async': 0, 'async_val': 0, 'delegate_to': None, 'delegate_facts': True, 'register': 'test', 'run_once': False}
    # Create a fake connection
    connection = {'has_native_async': False}
    # Create a fake loader
    loader = {'_basedir': '/home/vagrant/ansible/lib/ansible/plugins/action'}
    # Create a fake variable manager
    variable_manager = {'_fact_cache': {}, '_extra_vars': {}, '_options': {'fact_caching': 'memory'}}
    # Create a fake play context

# Generated at 2022-06-17 09:23:27.923347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:23:35.613118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action plugin
    action_plugin_run = MockActionPluginRun()
    # Create a mock action plugin
    action_plugin_run_execute_module = MockActionPluginRunExecuteModule()
    # Create a mock action plugin
    action_plugin_run_execute_module_run = MockActionPluginRunExecuteModuleRun()
    # Create a mock action plugin
    action_plugin_run_execute_module_run_execute_module = MockActionPluginRunExecuteModuleRunExecuteModule()
   

# Generated at 2022-06-17 09:23:36.606957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:23:42.217297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:23:53.355655
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:03.997540
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:04.902065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:24:10.972193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_playbook_vars

# Generated at 2022-06-17 09:24:18.813766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:40.120611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:41.968782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:24:48.112325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:24:49.513223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:51.187412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:24:51.809832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:54.337085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:24:54.879606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:58.638147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 09:25:09.540507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {'async_val': 'async_val'}
    action_module._connection = {'has_native_async': False}
    action_module._remove_tmp_path = lambda x: None
    action_module._execute_module = lambda x, y: {'result': 'result'}
    action_module._task.action = 'action'
    action_module._task.action_args = {'module_args': 'module_args'}
    action_module._task.action_args.update({'module_args': 'module_args'})
    action_module._task.action_args.update({'module_args': 'module_args'})

# Generated at 2022-06-17 09:26:00.674194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:26:04.434722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:26:13.324925
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:20.722157
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:30.236293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.connection.ssh import Connection
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:26:38.356993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    from ansible.compat.tests import mock
    from ansible.compat.tests.mock import patch
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import merge_hash

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self._task = mock.Mock()
            self._connection = mock.Mock()
            self._task.async_val = None
            self._task.action = 'setup'
            self._task.async_val = None
            self._task.no_log = False
            self._connection.has_native_async = False
            self._connection._shell.tmpdir = '/tmp/ansible'
            self._task.async_val = None

# Generated at 2022-06-17 09:26:46.906444
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:57.778452
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:27:06.684187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
   

# Generated at 2022-06-17 09:27:07.404522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-17 09:29:18.749950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task to test the method run of class ActionModule
    mock_task = MockTask()
    mock_task.async_val = False
    mock_task.action = 'setup'

    # Create a mock connection to test the method run of class ActionModule
    mock_connection = MockConnection()
    mock_connection.has_native_async = False

    # Create a mock ansible_module to test the method run of class ActionModule
    mock_ansible_module = MockAnsibleModule()

    # Create a mock module_executor to test the method run of class ActionModule
    mock_module_executor = MockModuleExecutor()

    # Create a mock task_vars to test the method run of class ActionModule
    mock_task_vars = MockTaskVars()

    # Create a mock tmp to test the method run of

# Generated at 2022-06-17 09:29:20.928372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:32.046373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action = ActionModule(task, connection, module)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock wrap_async
    wrap_async = MockWrapAsync()

    # Call the method run of class ActionModule
    result = action.run(tmp, task_vars)

    # Assert that the result is not None
    assert result is not None


# Generated at 2022-06-17 09:29:34.351426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:29:36.518604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a ActionModule object
    am = ActionModule()
    # Call method run of class ActionModule
    am.run()

# Generated at 2022-06-17 09:29:37.007910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:37.905373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this test
    pass

# Generated at 2022-06-17 09:29:39.123794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:29:42.608576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:43.725572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)