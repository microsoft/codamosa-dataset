

# Generated at 2022-06-17 09:19:56.880724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:19:57.570242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:08.177830
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:14.003274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action module
    action_module = ActionModule(task, connection, module)
    # Create a mock task variables
    task_vars = {}
    # Create a mock result
    result = {}
    # Call method run of class ActionModule
    action_module.run(task_vars=task_vars, result=result)
    # Assert that method run of class ActionModule has been called
    assert action_module.run_called
    # Assert that method run of class ActionModule has been called with the correct parameters
    assert action_module.run_called_with == (task_vars, result)


# Generated at 2022-06-17 09:20:22.799343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action.normal import ActionModule

# Generated at 2022-06-17 09:20:24.522317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None) is not None

# Generated at 2022-06-17 09:20:25.783039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:20:34.446113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import ActionModuleComponent
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:20:37.190831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:48.686301
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:53.590502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:20:54.968112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:20:55.766807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:05.226630
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:07.674920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-17 09:21:19.482828
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:21:29.535837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal as action_normal
    import ansible.plugins.action.copy as action_copy
    import ansible.plugins.action.template as action_template
    import ansible.plugins.action.file as action_file
    import ansible.plugins.action.synchronize as action_synchronize
    import ansible.plugins.action.script as action_script
    import ansible.plugins.action.debug as action_debug
    import ansible.plugins.action.setup as action_setup
    import ansible.plugins.action.command as action_command
    import ansible.plugins.action.shell as action_shell
    import ansible.plugins.action.include as action_include
    import ansible.plugins.action.include_role as action_include_role
    import ansible.plugins.action.include_

# Generated at 2022-06-17 09:21:30.077938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:33.086476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)._supports_async == True
    assert ActionModule(None, None, None, None)._supports_check_mode == True

# Generated at 2022-06-17 09:21:44.030902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:21:50.225189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:50.846237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:02.093999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self.mock_module_path = os.path.join(os.path.dirname(__file__), 'mock_modules')
            sys.path.append(self.mock_module_path)

        def tearDown(self):
            sys.path.remove(self.mock_module_path)


# Generated at 2022-06-17 09:22:02.723397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:13.443376
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:21.121914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_v

# Generated at 2022-06-17 09:22:23.278877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:22:36.104275
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:22:36.703514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:37.250570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:49.907587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:53.749579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:22:55.375662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 09:22:57.808126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:22:58.775461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:23:03.570253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-17 09:23:04.331239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:05.048194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:23:06.212241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No test for ActionModule.run"

# Generated at 2022-06-17 09:23:16.597411
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:23:52.553379
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:23:54.336182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:55.227309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:23:58.433395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:24:06.538604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 09:24:07.557255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:24:18.536635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader plugin
    shared_loader_plugin = MockSharedLoaderPlugin()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock shell
    shell = MockShell()
    # Create a mock ansible runner
    ansible_runner = MockAnsibleRunner()
    # Create a mock task executor
    task_executor = MockTaskExecutor()
    # Create a mock task queue manager
    task_queue_manager = MockTaskQueueManager()

# Generated at 2022-06-17 09:24:31.267865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:24:38.825922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, action_plugin)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock result
    result = MockResult()
    # Create a mock invocation
    invocation = MockInvocation()
    # Create a mock module_args

# Generated at 2022-06-17 09:24:39.242065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:25:38.483577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:25:41.705111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:25:45.525291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:25:46.710909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:25:57.893230
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:08.458297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase

# Generated at 2022-06-17 09:26:09.403384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:10.247093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this unit test
    assert False

# Generated at 2022-06-17 09:26:17.466816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader plugin
    shared_loader_plugin = MockSharedLoaderPlugin()
    # Create a mock action base
    action_base = ActionBase(task, connection, play_context, loader, templar, shared_loader_plugin)
    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_plugin)
    # Check if the instance is an instance of ActionModule

# Generated at 2022-06-17 09:26:18.529619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:28:26.884923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:28:30.824797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-17 09:28:32.552493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:28:33.658709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:28:35.464278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:28:37.251786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:28:41.500778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule()
    assert action_module.__class__.__name__ == 'ActionModule'
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module._supports_async_timeout == False

# Generated at 2022-06-17 09:28:44.217491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:28:54.168120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, templar, loader)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock result
    result = MockResult()
    # Create a mock wrap_async
    wrap_async = MockWrapAsync()
    # Create a mock invocation
    invocation = MockInvocation()
    # Create a mock module_args

# Generated at 2022-06-17 09:28:55.277567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass