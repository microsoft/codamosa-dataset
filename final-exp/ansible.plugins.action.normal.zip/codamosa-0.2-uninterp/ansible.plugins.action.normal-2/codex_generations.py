

# Generated at 2022-06-17 09:20:10.516527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:20:11.058744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:21.538387
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:33.277461
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:20:34.173271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:48.025145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:20:50.002967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:20:55.362691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-17 09:20:56.431588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:02.483488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default values
    am = ActionModule(None, None, None, None, None, None)
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-17 09:21:11.189460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_task_vars_files
   

# Generated at 2022-06-17 09:21:13.454818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None) is not None

# Generated at 2022-06-17 09:21:14.075019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-17 09:21:15.058446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:21:16.053141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:17.288104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:21:28.195459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock action module
    action_module = ActionModule(task, connection)
    # Create a mock task variables
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()
    # Call method run of class ActionModule
    action_module.run(result, task_vars)
    # Check if method run of class ActionModule was called
    assert action_module.run.called
    # Check if method run of class ActionBase was called
    assert action_module.run.call_count == 2
    # Check if method run of class ActionBase was called with the right parameters

# Generated at 2022-06-17 09:21:35.718375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module
    module = ActionModule()

    # Create a mock object for the connection
    connection = Connection()

    # Create a mock object for the task
    task = Task()

    # Create a mock object for the task_vars
    task_vars = TaskVars()

    # Create a mock object for the tmp
    tmp = Tmp()

    # Create a mock object for the wrap_async
    wrap_async = WrapAsync()

    # Create a mock object for the result
    result = Result()

    # Create a mock object for the invocation
    invocation = Invocation()

    # Create a mock object for the module_args
    module_args = ModuleArgs()

    # Create a mock object for the _ansible_verbose_override
    _ansible_verbose_override = AnsibleVer

# Generated at 2022-06-17 09:21:37.981078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:21:46.739546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock action module
    action_module = ActionModule(task, connection, module)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)
    # Assert that the result is equal to the expected result
    assert result == {'invocation': {'module_name': 'mock_module'}, '_ansible_verbose_override': True}


# Generated at 2022-06-17 09:21:53.249672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:21:55.657315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:22:05.178273
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:22:12.879070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True
    assert am._task == None
    assert am._connection == None
    assert am._play_context == None
    assert am._loader == None
    assert am._templar == None
    assert am._shared_loader_obj == None
    assert am._task_vars == None
    assert am._tmp == None
    assert am._task_vars_tmp == None
    assert am._task_vars_tmp_file == None
    assert am._task_vars_tmp_file_name == None
    assert am._task_vars_tmp_file_args == None
    assert am._task_vars_tmp_file_args_name == None
    assert am._

# Generated at 2022-06-17 09:22:22.549146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    import ansible.plugins.action.normal
    import ansible.plugins.action.copy
    import ansible.plugins.action.template
    import ansible.plugins.action.debug
    import ansible.plugins.action.script
    import ansible.plugins.action.include
    import ansible.plugins.action.include_tasks
    import ansible.plugins.action.include_role
    import ansible.plugins.action.include_vars
    import ansible.plugins.action.pause
    import ansible.plugins.action.wait_for
    import ansible.plugins.action.async_status
    import ansible.plugins.action.meta
    import ansible.plugins.action.setup
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
   

# Generated at 2022-06-17 09:22:24.249182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:22:32.244508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class DataLoader
    data_loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class TaskQueueManager
    task_queue_manager = TaskQueueManager()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Playbook
    playbook = Play

# Generated at 2022-06-17 09:22:44.644803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid module
    module = ActionModule()
    module._task = {'action': 'setup'}
    module._connection = {'has_native_async': False}
    module._execute_module = lambda x, y: {'result': 'success'}
    result = module.run()
    assert result['result'] == 'success'

    # Test with a valid module
    module = ActionModule()
    module._task = {'action': 'setup'}
    module._connection = {'has_native_async': True}
    module._execute_module = lambda x, y: {'result': 'success'}
    result = module.run()
    assert result['result'] == 'success'

# Generated at 2022-06-17 09:22:45.259116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:22:47.855225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:23:01.676085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:23:13.662030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class to test
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # create a mock for the method _execute_module
    action_module._execute_module = Mock(return_value={'ansible_facts': {'test': 'test'}})
    # create a mock for the method _remove_tmp_path
    action_module._remove_tmp_path = Mock()
    # create a mock for the method run of class ActionBase
    action_module.run = Mock(return_value={'skipped': False, 'invocation': {'module_args': {'test': 'test'}}})
    # call the method under test
    result = action_module.run()
    # assert

# Generated at 2022-06-17 09:23:23.571676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid action
    action = ActionModule(dict(action='ping'))
    assert action.action == 'ping'
    assert action.action_type == 'normal'
    assert action.action_plugin_name == 'ping'
    assert action.action_plugin_type == 'action'
    assert action.action_loader_name == 'ping'
    assert action.action_loader_class == 'ActionModule'
    assert action.action_loader_module_name == 'ansible.plugins.action.ping'
    assert action.action_loader_module_path == 'ansible/plugins/action/ping.py'
    assert action.action_loader_module_qualname == 'ansible.plugins.action.ping.ActionModule'
    assert action.action_loader_module_package == 'ansible.plugins.action'

# Generated at 2022-06-17 09:23:32.932456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a dummy task
    from ansible.playbook.task import Task
    task = Task()
    task._role = None
    task.action = 'setup'
    task.args = {}
    task.async_val = 0
    task.notify = []
    task.delegate_to = None
    task.loop = None
    task.loop_args = None
    task.when = None
    task.register = None
    task.ignore_errors = False
    task.tags = []
    task.run_once = False
    task.any_errors_fatal = False
    task.no_log = False
    task.always_run = False
    task.changed_when = None
    task.failed_when = None
    task.until = None
    task.retries = 0

# Generated at 2022-06-17 09:23:33.432838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:39.713860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 09:23:40.527478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:52.526016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('module', (object,), {'run': lambda self, tmp=None, task_vars=None: {'skipped': False, 'invocation': {'module_args': {'a': 'b'}}}})
    # Create a mock object for the connection class
    mock_connection = type('connection', (object,), {'has_native_async': False})
    # Create a mock object for the task class
    mock_task = type('task', (object,), {'async_val': False})
    # Create a mock object for the ActionBase class

# Generated at 2022-06-17 09:23:54.282641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:23:55.228084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:16.727152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:30.051187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:24:31.892484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:24:32.363830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:36.864766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:24:44.818809
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:24:46.404679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:24:51.096979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:24:53.684046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-17 09:25:01.342300
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:25:59.211074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    test_action_module = ActionModule()
    assert test_action_module is not None
    assert test_action_module._supports_check_mode is True
    assert test_action_module._supports_async is True

# Generated at 2022-06-17 09:25:59.984740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:00.589006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:26:10.050668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.plugins.action import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 09:26:20.299459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object
    mock_self = type('', (), {})()
    mock_self.run = ActionModule.run
    mock_self._supports_check_mode = True
    mock_self._supports_async = True
    mock_self._task = type('', (), {})()
    mock_self._task.async_val = False
    mock_self._connection = type('', (), {})()
    mock_self._connection.has_native_async = False
    mock_self._task.action = 'setup'
    mock_self._execute_module = lambda x, y: {'changed': True}
    mock_self._remove_tmp_path = lambda x: None
    mock_self._connection._shell = type('', (), {})()

# Generated at 2022-06-17 09:26:33.352072
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:39.828313
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:26:48.388897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'

# Generated at 2022-06-17 09:26:50.366289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:26:53.666410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:28:58.598339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:29:01.528259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:29:03.171017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:29:09.420948
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:29:21.277057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal as action_normal
    import ansible.plugins.action.copy as action_copy
    import ansible.plugins.action.template as action_template
    import ansible.plugins.action.synchronize as action_synchronize
    import ansible.plugins.action.lineinfile as action_lineinfile
    import ansible.plugins.action.file as action_file
    import ansible.plugins.action.get_url as action_get_url
    import ansible.plugins.action.uri as action_uri
    import ansible.plugins.action.shell as action_shell
    import ansible.plugins.action.script as action_script
    import ansible.plugins.action.service as action_service
    import ansible.plugins.action.apt as action_apt

# Generated at 2022-06-17 09:29:24.432169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:29:25.774565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:29:33.530243
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:29:37.500442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:29:38.598158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None