

# Generated at 2022-06-11 12:03:10.483197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:03:11.309296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# STUB - ONLY RUN WITH NOSE
	pass

# Generated at 2022-06-11 12:03:13.697818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {}

    at = ActionModule()
    result = at.run(result)

    print (result)

# Unit test entry
if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-11 12:03:14.792817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "There is no unit test implemented for this class"

# Generated at 2022-06-11 12:03:15.262418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:03:24.857516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    import ansible.plugins.action
    module = ansible.plugins.action.ActionModule(None,None,None,None)
    assert module.run(task_vars={'a':1},tmp='b') == {'skipped': True}
    assert module.run(task_vars={'a':1},tmp={'a':1,'c':2}) == {'skipped': True}
    assert module.run(task_vars={'a':1},tmp={'a':0}) == {'skipped': False, 'invocation': {'module_args': {}}}
    assert module.run(task_vars={'a':1},tmp={'a':1}) == {'skipped': False, 'invocation': {'module_args': {}}}

# Generated at 2022-06-11 12:03:27.838693
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # FIXME: write tests
    # FIXME: this is a stub
    # FIXME: this should be a functional test
    # FIXME: needs unit tests
    pass

# Generated at 2022-06-11 12:03:36.590518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    result = {}
    result['invocation'] = {}
    result['invocation']['module_args'] = {}
    result_expected = result
    result = ActionModule().run(result,  {})
    if json.dumps(result) != json.dumps(result_expected):
        print("test_ActionModule_run FAILED")
        print("result      : " + json.dumps(result))
        print("result_expected: " + json.dumps(result_expected))
    else:
        print("test_ActionModule_run PASSED")

test_ActionModule_run()

# Generated at 2022-06-11 12:03:44.806744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule
    """
    import json
    import os
    import sys

    sys_path = sys.path
    # test read_config_file('ansible')
    sys.path.append(os.getcwd() + '/../')
    # test read_config_file('ansible')
    sys.path.append(os.getcwd() + '/../../')

    # create a new instance of ActionModule
    # private method: __init__(self, task, connection, play_context, loader, templar, shared_loader_obj)
    # which is called when an instance of ActionModule is initialized, needs to be tested
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action.normal import PluginLoader

    # pylint: disable=unused-variable

# Generated at 2022-06-11 12:03:49.655564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    def verify_vars(instance):
        assert(instance._supports_check_mode)
        assert(instance._supports_async)

    # Check that the constructor worked
    action_plugin=ansible.plugins.action.ActionModule(None, None, None, None)
    verify_vars(action_plugin)


# Generated at 2022-06-11 12:03:53.732576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = ActionModule()
  result = module._execute_module()
  assert result == {}

# Generated at 2022-06-11 12:03:55.177289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(module_name='test_ActionModule', module_args='args') is not None

# Generated at 2022-06-11 12:03:55.686233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:03:56.665869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Do not use
    raise Exception("Not implemented")

# Generated at 2022-06-11 12:04:08.277085
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockTask:
        def __init__(self):
            self.action = None
            self.async_val = None

    class MockConnection:
        def __init__(self):
            self._shell = MockShell()
            self.has_native_async = False
            self.has_pipelining = False

    class MockShell:
        def __init__(self):
            self.tmpdir = None

    class MockActionBase:
        def __init__(self):
            self.task = MockTask()
            self._connection = MockConnection()

        def _execute_module(self, **kwargs):
            return {'test_data': 'TEST DATA'}

        def _remove_tmp_path(self, path):
            pass

    a = MockActionBase()

# Generated at 2022-06-11 12:04:14.368471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Configure test environment
    module = ActionModule(None, None, None, None, None, None, None, None)

    # Run the method with no arguments - return value and side effect
    ret = module.run()
    assert ret == {}

    # Run the method with invalid arguments - return value and side effect
    ret = module.run(tmp=None, task_vars=None)
    assert ret == {}

# Generated at 2022-06-11 12:04:24.574214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # validate our assumptions about 'has_native_async'
    assert ActionBase._config_module._shell_plugin.has_native_async == False, 'ActionBase._config_module._shell_plugin.has_native_async should be False'

    # wrap_async should be True, i.e. wrap the module execution in a background process
    assert ActionModule._supports_async == True, 'ActionModule._supports_async should be True'
    assert ActionModule._supports_check_mode == True, 'ActionModule._supports_check_mode should be True'
    assert ActionModule._task.async_val == 600, 'ActionModule._task.async_val should be 600'

# Generated at 2022-06-11 12:04:34.732072
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_name = 'TestActionModule'
    test_task = lambda: None
    setattr(test_task, 'name', test_name)
    test_args = dict(x=1, y=2)
    test_inject = dict(a=10, b=20)

    amb = ActionModule(task=test_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert amb.task.name == test_name
    assert amb.connection is None
    assert amb.play_context is None
    assert amb.loader is None
    assert amb.templar is None


# Generated at 2022-06-11 12:04:46.691284
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set values for variables for test
    tmp = None
    task_vars = {}
    wrap_async = False
    result = {}
    invocation = {}
    module_args = {}
    # add values to invocation
    invocation.update({
        'module_args': module_args
    })
    # add values to result
    result.update({
        'invocation': invocation,
        'skipped': False
    })

    # Create a class Mock to test method run of class ActionModule
    class MockActionModule(ActionModule):
        def __init__(self):
            # set values for variables for test
            self._supports_check_mode = True
            self._supports_async = True

        # Create a mock of method run of class ActionModule

# Generated at 2022-06-11 12:04:56.077833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a ActionModule subclass to test its constructor
    class TestActionModule(ActionModule):
        pass

    # Create a subclass of the connection plugin class to avoid creating
    # the connection plugin class.  Also, avoid creating the action plugin
    # base class.  This makes it easier to call the ActionModule constructor.
    class TestConnection(object):
        has_native_async = True

    # Mock task object
    class MockTask(object):
        async_val = None
        action = 'action_module'

    # Create a task object
    task = MockTask()

    # Create a subclass of the main class for Ansible plugins
    class TestAnsiblePlugin(object):
        def __init__(self, connection, module_name, module_args, task, tmp, delete_remote_tmp=True):
            self._shell = connection
           

# Generated at 2022-06-11 12:05:12.251427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_configs


# Generated at 2022-06-11 12:05:16.438411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('setup', 'myhost')
    assert action_module._task.action == 'setup', 'ActionModule constructor fails to initialize action'
    assert action_module._task.delegate_to == 'myhost', 'ActionModule constructor fails to initialize delegate_to'


# Generated at 2022-06-11 12:05:19.599793
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test object creation
    adhoc_action = ActionModule()

    # test super call
    assert adhoc_action._supports_check_mode
    assert adhoc_action._supports_async

# Generated at 2022-06-11 12:05:22.497792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule({})
    assert mod._supports_check_mode == True
    assert mod._supports_async == True
    assert mod._connection._shell.tmpdir != None

# Generated at 2022-06-11 12:05:32.260328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.plugins.loader import action_loader

    action = ActionModule(task='dummy', connection=None, play_context=None, loader=action_loader, templar=None, shared_loader_obj=None)

    # CmdModule
    module = AnsibleModule(argument_spec=dict(command='ls'))
    setattr(module, 'action_plugin', action)
    setattr(module, '_connection', Connection('local'))


# Generated at 2022-06-11 12:05:32.804435
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert True

# Generated at 2022-06-11 12:05:43.704019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test if ActionModule.run() raises NotImplementedError
    host = "someHost"
    task = object()
    connection = object()
    play_context = object()
    loader = object()
    templar = object()
    shared_loader_obj = object()

    # create ActionModule object
    actionModule = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    # check if it is instance of ActionModule
    assert(isinstance(actionModule, ActionModule))

    try:
        # run actionModule.run()
        result = actionModule.run()
        # no result expected
        assert(result == None)
    except NotImplementedError as e:
        assert(False)
    except Exception as e:
        assert(False)

# Generated at 2022-06-11 12:05:46.072706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test the constructor for class ActionModule"""
    mod = ActionModule()
    assert mod._supports_check_mode is True
    assert mod._supports_async is True

# Generated at 2022-06-11 12:05:56.237012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # dummy module
    module = type('module', (object,), {'run': lambda self: 'hello world'})

    # mock task
    module_name = 'test_module'
    async_val = False
    noop_val = False
    noop_flag = '--noop'
    action_name = 'test_action'
    action = ActionModule(task={'action': action_name, 'async': async_val})

    # mock connection
    connection = type('connection', (object,), {'has_native_async': False})()
    action._connection = connection

    # mock task executor
    task_vars = {'ansible_check_mode': False}
    action._execute_module = lambda x, y: {'test_key': 'test_value'}

    result = action.run

# Generated at 2022-06-11 12:06:00.387627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    in_data = {}
    from ansible.plugins.action import ActionModule
    a = ActionModule(task=in_data, connection=in_data, play_context=in_data, loader=in_data, templar=in_data, shared_loader_obj=in_data)
    assert a

# Generated at 2022-06-11 12:06:12.716192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-11 12:06:23.090214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    import json
    pl = PlayContext()
    pl.connection = 'local'
    pl.become_method = 'sudo'
    tr = TaskResult('host', 'play', 'task')
    tr.set_loader(pl)
    tr.task._role = 'rolename'
    tr.task.action = 'setup'
    tr.task.action = 'shell'
    tr.task.task_vars = {}
    tr.task.no_log = False
    am = ActionModule(pl, tr)
    tr.action_args = {}
    tr.action_args['name'] = 'ping'
    tr.task_vars['ansible_' + tr.connection] = {}
   

# Generated at 2022-06-11 12:06:23.988358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert True

# Generated at 2022-06-11 12:06:24.949113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # TODO: implement
  pass

# Generated at 2022-06-11 12:06:25.798832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    con = ActionModule()
    assert con != None

# Generated at 2022-06-11 12:06:28.157309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode == True
    assert module._supports_async == True
    assert module.DEFAULT_TIMEOUT == 10

# Generated at 2022-06-11 12:06:33.691989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._task.async_val = None
    am._task.action = 'setup'
    am._connection.has_native_async = False
    # this is a mock to test the return value
    am._execute_module = lambda task_vars, wrap_async: {'result': 'Some result'}
    assert am.run(None, None) == {'result': 'Some result'}

# Generated at 2022-06-11 12:06:34.661134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(runner=None) is not None

# Generated at 2022-06-11 12:06:37.467210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_mod is not None

# Generated at 2022-06-11 12:06:46.873239
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #
    # Unit test for method `run` of class `ActionModule`.
    #
    # @prerequisite: `connection` plugin should be loaded and
    #                should support `has_native_async` method.
    #
    # @steps:
    #  1. Prepare mocks.
    #  2. Create an object of `ActionModule` class.
    #  3. Execute method `run` of `ActionModule` class.
    #
    # @assert: Method should be executed without any exception.
    #


    # 1. Prepare mocks.
    import ansible.plugins.connection as connection
    connection.Connection = connection.ConnectionMock
    connection.ConnectionMock.has_native_async.return_value = False

    from ansible.plugins.action import ActionModule


# Generated at 2022-06-11 12:07:11.218992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid input
    #test_module = AnsibleModule({'name': 'test'})
    #test_task = AnsibleTask(test_module)
    pass

# Generated at 2022-06-11 12:07:13.416854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing the constructor of ActionModule()")
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-11 12:07:22.387087
# Unit test for constructor of class ActionModule
def test_ActionModule():
      action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
      assert action.name is None
      assert action.short_description is None
      assert action.version is None
      assert action.supports_check_mode 
      assert action.supports_async is True
      assert action._task is None
      assert action.task is None
      assert action._shared_loader_obj is None
      assert action._loader is None
      assert action._templar is None
      assert action._connection is None
      assert action._play_context is None
      assert action.LOAD_CALLBACK_PLUGINS is False
      assert action.LOAD_TASK_PLUGINS is False

# Generated at 2022-06-11 12:07:24.448699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #TODO: actually write a test, not just an empty list.
    test_action_module = ActionModule([])
    assert test_action_module

# Generated at 2022-06-11 12:07:25.002488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:07:25.755796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:07:26.322289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:07:27.939697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_obj = ActionModule()
    test_obj.run()
# End of test_ActionModule_run

# Generated at 2022-06-11 12:07:37.327620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'localhost'
    hostname = 'localhost'
    port = 22
    connection = 'testconnection'
    name = 'testname'
    task = 'testtask'
    play_context = 'testplaycontext'
    loader = 'testloader'
    shared_loader_obj = 'testsharedloaderobj'
    variable_manager = 'testvariablenmanager'
    templar = 'testtemplar'
    delete_remote_tmp = True

    testActionModule = ActionModule(host, hostname, port, connection, name, task, play_context, loader, shared_loader_obj, variable_manager, templar, delete_remote_tmp)

    assert testActionModule.connection == connection
    assert testActionModule._task == task
    assert testActionModule._loader == loader
    assert testActionModule._shared_loader_

# Generated at 2022-06-11 12:07:37.936848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:08:29.453312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:08:32.876225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_mod._supports_check_mode == True
    assert action_mod._supports_async == True

# Generated at 2022-06-11 12:08:41.038663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We need to mock __init__ before we can mock run.
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Constructor for ActionModule to test.

# Generated at 2022-06-11 12:08:42.142322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule('setup')
    assert a

# Generated at 2022-06-11 12:08:50.867932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.module_common import ModuleParameters
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection import ConnectionBase

    class Test_ConnectionBase(ConnectionBase):
        has_native_async = True

        def _connect(self):
            return self

        def exec_command(self, cmd, tmp_path, sudoable=False, executable='/bin/sh', in_data=None, su=None, su_user=None):
            return 0, '', '', ''


# Generated at 2022-06-11 12:08:52.045635
# Unit test for constructor of class ActionModule
def test_ActionModule():

    r = ActionModule()
    assert r != None

# Generated at 2022-06-11 12:08:53.888743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule._supports_check_mode == True
    assert actionModule._supports_async == True

# Generated at 2022-06-11 12:09:02.962363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import __main__ as main
    import ansible.plugins.action.normal

    myclass = ansible.plugins.action.normal.ActionModule(
        'setup',
        'tmp',
        {'_ansible_verbose_always': True, 'ansible_check_mode': True},
        'localhost',
        'connection',
        False,
        {}
    )

    from ansible.runner.return_data import ReturnData
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.script import InventoryScript
    from ansible.vars import VariableManager

    myclass._supports_async = True
    myclass._supports_check_mode = True


# Generated at 2022-06-11 12:09:03.462492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:09:12.376558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import json
    import tempfile
    import shutil

    from ansible.plugins.action import ActionBase

    class MyActionModule(ActionModule):
        pass

    #TODO: This assert needs to be fixed
    assert MyActionModule.run is not ActionModule.run
    assert MyActionModule.run.__doc__ == ActionModule.run.__doc__

    def _execute_module(task_vars, wrap_async=None):
        return {"dummy": 'dict'}

    def _remove_tmp_path(path):
        return None

    sys.path.append(os.path.join(os.path.dirname(__file__),"../../../"))
    from ansible.compat.tests import unittest

# Generated at 2022-06-11 12:11:18.991699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 12:11:20.670486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Just execute action module in a certain way
    ActionModule('mod_name', 'Action', {'test_var': 'some test var'}).run()

# Generated at 2022-06-11 12:11:22.028720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 12:11:24.354690
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule()

    assert action._supports_check_mode is True
    assert action._supports_async is True

# Generated at 2022-06-11 12:11:26.403437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._supports_check_mode == True
    assert a._supports_async == True
    assert a._display.deprecate.called_count == 0

# Generated at 2022-06-11 12:11:28.400870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test started")
    #This test will fail since the function is not implemented
    action_module = ActionModule()
    print("test finished")
    assert action_module.run() == None

# Generated at 2022-06-11 12:11:35.756274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    task = mock.MagicMock()
    task._role = None
    task._role_name = None
    task.async_val = None
    task.action = None

    tmp = mock.MagicMock()
    task_vars = mock.MagicMock()
    wrap_async = None

    connection = mock.MagicMock()
    connection.has_native_async = False
    connection._shell = mock.MagicMock()
    connection._shell.tmpdir = None

    action_base = ActionModule(task, connection, 'fake_play_context', loader='fake_loader', templar='fake_templar', shared_loader_obj=None)
    action_base._supports_async = True
    action_base._supports_check_mode = True
    action_base._execute

# Generated at 2022-06-11 12:11:36.199206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-11 12:11:38.529107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    inner_class = ActionModule.ActionModule
    # TODO: fix this test
    # assert(inner_class.SUPPORTS_CHECK_MODE == True)
    # assert(inner_class.SKIP_HOST_LOOP == True)

# Generated at 2022-06-11 12:11:39.511989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None)._supports_async