

# Generated at 2022-06-11 12:03:18.796569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleActionFail
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.loader import action_loader
    import json
    import os

    def mock_execute_module(task_vars, wrap_async):
        return {'out': 'test', 'rc': 0}

    def mock_task(action):
        class Task:
            async_val = False
            action = action

            def __init__(self):
                self.args = {}

        return Task()

    def mock_connection(has_native_async):
        class Connection:
            _shell = os

            def has_native_async(self):
                return has_native_async

        return Connection()


# Generated at 2022-06-11 12:03:30.038924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_result import TaskResult
    test_run = ActionModule(None,None)
    inv = dict(action='test', module='test_module', module_args='test_module_args')
    tmp = None
    task_vars = dict()

    result = test_run.run(tmp,task_vars)
    assert result == dict(task_result=TaskResult(action='test', module='test_module', module_args='test_module_args', task=None))

    assert result['task_result'].invocation == dict(action='test', module='test_module', module_args='test_module_args')

# Generated at 2022-06-11 12:03:33.293359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a action_module object
    action_module = ActionModule()
    # check if the object is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 12:03:42.757310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test to check the execution of the function run in class ActionModule"""

    import sys
    import os
    import pytest
    from os.path import dirname, abspath, join, isdir
    from mock import MagicMock, Mock, patch
    from io import StringIO
    from ansible.module_utils.ansible_release import __version__
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-11 12:03:51.834962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import errors
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_success
    from units.mock.plugins import mock_action_base_execute_module
    from units.mock.plugins import TestModule
    from units.mock.vars import AnsibleVars
    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    import sys
    import json

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-11 12:03:59.086737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import StringIO

    context = PlayContext()
    context._play_context = context
    parser = C.OptionParser(
        connection='local',
        module_path='/foo/bar',
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        syntax=None,
        start_at_task=None
    )

# Generated at 2022-06-11 12:04:01.087331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    value = 101

    # check if returned value is correct
    assert value == 101, 'Returned value is incorrect'

# Generated at 2022-06-11 12:04:04.018506
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

#
# This is a helper for code below that does some mockups for objects for testing purposes.
#

# Generated at 2022-06-11 12:04:07.040705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.__dict__['_supports_check_mode'] == True
    assert module.__dict__['_supports_async'] == True

# Generated at 2022-06-11 12:04:18.584231
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = dict()
    import ansible.plugins.action.normal
    test_ActionModule = ansible.plugins.action.normal.ActionModule(
        task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # test with normal task when action plugin has been initialized with ActionModule._supports_async = True
    task_vars = dict()
    test_ActionModule._supports_async = True
    test_ActionModule._task.async_val = 0
    test_ActionModule._connection.has_native_async = False
    result = test_ActionModule.run(tmp=None, task_vars=task_vars)
    assert result.get('async_val') == 0

    # test with async task when action

# Generated at 2022-06-11 12:04:28.281524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert not action._supports_check_mode
    assert not action._supports_async
    assert action.DEFAULT_TIMEOUT is not None
    assert action.DEFAULT_REMOTE_TMP is not None
    assert action.DEFAULT_LOCAL_TMP is not None
    assert action.default_poll_interval is not None
    #assert action._config is not None
    #assert action._task is not None
    assert action._loader is not None
    assert action._templar is not None
    assert action._shared_loader_obj is not None

# Generated at 2022-06-11 12:04:39.933597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Use a specific host
    my_host = Host("test")

    # Set some defaults
    my_group = Group("test")
    my_host.set_variable("ansible_ssh_host", "test.example.com")
    my_group.add_host(my_host)
    my_host.set_variable("ansible_ssh_pass", "foobar")
    my_host.set

# Generated at 2022-06-11 12:04:42.986495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # initialize module with given parameters
    action = ActionModule(task=dict(async_val=False), connection=dict(has_native_async=False))
    assert action is not None

# Generated at 2022-06-11 12:04:47.275013
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create an instance of the action module object
    action_module = ActionModule('setup', { 'module_name': 'ping' })

    # set module_name attribute
    action_module._args = {'module_name': 'setup'}
    action_module._task = ''

    # invoke run() method
    action_module.run()

# Generated at 2022-06-11 12:04:56.925267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #raise ImportError()
    import sys
    sys.path.append( '../../')
    from ansible.plugins.loader import action_loader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 12:04:58.389183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionBase)



# Generated at 2022-06-11 12:04:59.666576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x._supports_check_mode == True

# Generated at 2022-06-11 12:05:01.361408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 12:05:12.070528
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print('Unit test for method run of class ActionModule')

    # Mock the configuration file to make unit tests work.
    from ansible import constants
    from ansible.utils.display import Display
    display = Display()
    constants.DEFAULT_TRANSFORM_INVALID_GROUP_CHARS = None
    constants.DEFAULT_TRANSFORM_INVALID_GROUP_CHARS_REPLACE = None

    # Temporary variables.
    # Mock imports and modules.
    import __builtin__
    # import ansible.constants
    # import ansible.plugins.action.ActionBase
    import ansible.module_utils.common.collections

    # Mock constants.
    MODULE_NAME = 'fake'
    MODULE_ARGS = 'fake'
    MODULE_COMPLEX_ARGS = 'fake'
    MODULE_REQUIRES

# Generated at 2022-06-11 12:05:23.076701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible
    from ansible import constants
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    my_module_args = dict(foo='bar')

    # Set options
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    options = Options(connection='smart', module_path='/path/to/mymodules', forks=10, become=None, become_method=None, become_user=None, check=False, diff=True)
    constants.DEFAULT_MODULE_PATH = '/path/to/mymodules'
    constants.DEFAULT_KEEP_REMOTE_FILES = True

    # Testtuple

# Generated at 2022-06-11 12:05:35.552484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.common.json

    t = Task()
    t.action = 'ping'
    t.async_val = 1
    t._connection = {}
    t._connection._shell = {}
    t._connection._shell.tmpdir = '/a/path'

    am = ActionModule(t, {})
    am._supports_check_mode = True
    am._supports_async = True

    res = am.run(None, {})
    assert res['skipped'] == False

    am._task.action = 'test'

    res = am.run(None, {})
    assert res['skipped'] == True

# Generated at 2022-06-11 12:05:36.547356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-11 12:05:46.893622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Connection:
        def __init__(self):
            pass

        def has_native_async(self):
            return not True
    class Task:
        def __init__(self):
            self.action = C._ACTION_SETUP
            self.async_val = not True
    class TaskVars:
        def __init__(self):
            self.task_vars = dict()
            self.module_vars = dict()
    class PlayContext:
        def __init__(self):
            self.verbosity = 1
            self.check_mode = not True
            self.no_log = not True
            self.network_os = 'ios'
    class Play:
        def __init__(self):
            self.connection = 'local'
            self.shell = 'ssh'
            self.any

# Generated at 2022-06-11 12:05:48.017147
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule(None, None)

# Generated at 2022-06-11 12:05:48.997928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-11 12:05:53.966530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    test_module = ActionModule(task=None, connection=None, play_context=None, task_vars=task_vars, loader=None, templar=None, shared_loader_obj=None)
    task_vars = test_module.vars
    assert 'ansible' in task_vars



# Generated at 2022-06-11 12:06:03.240975
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set up test data
    facts = {"ansible_facts": {}}
    task_vars = {"ansible_facts": facts}
    connection = {"connection": "Mock"}
    result = {"result": {"foo": "bar"}}

    # create and initialize mocks
    runner = ActionModule("mock_action")
    _tmp_path = "mock_tmp_path"
    _execute_module_result = {"result": {"foo": "bar"}}

    # setup runner
    runner._connection = connection
    runner._task_vars = task_vars
    runner._task = {"async": ""}

    # mock _execute_module

# Generated at 2022-06-11 12:06:06.951448
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create a instance of the class to test
    mod = ActionModule()

    # should raise exception if task_vars is not defined
    try:
        mod.run()
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-11 12:06:19.377925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing the ActionModule constructor")

    # Create an object of class ActionBase
    actionBase = ActionBase()

    # Create an object of class ActionModule

# Generated at 2022-06-11 12:06:26.531703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class Host_1(Host):
        def __init__(self, hostname, port, variables=None):
            super(Host_1, self).__init__(hostname, port)
            self.set_variable("ansible_python_interpreter", "/usr/bin/python")

# Generated at 2022-06-11 12:06:40.297867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    actionModule = ActionModule()

    # Assert default values
    assert actionModule._supports_check_mode is True
    assert actionModule._supports_async is True

# Generated at 2022-06-11 12:06:49.588504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def __init__(self):
        self.action = None
        self.async_val = False
    def _execute_module(self, **kwargs):
        return False
    def _remove_tmp_path(self, **kwargs):
        return True
    def update_cache_if_changed(self, **kwargs):
        return True
    def _transfer_str(self, **kwargs):
        return True
    def _handle_warnings(self, **kwargs):
        return True
    ActionModule._execute_module = _execute_module
    ActionModule.__init__ = __init__
    ActionModule._remove_tmp_path = _remove_tmp_path
    ActionModule.update_cache_if_changed = update_cache_if_changed
    ActionModule._transfer_str = _transfer_str
    Action

# Generated at 2022-06-11 12:06:50.558336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    #
    #
    assert False

# Generated at 2022-06-11 12:06:52.464499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-11 12:06:55.363450
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule()
    assert isinstance(action, ActionModule)
    assert action._supports_check_mode == True
    assert action._supports_async      == True



# Generated at 2022-06-11 12:06:55.937493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:06:58.180802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(name=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-11 12:07:03.100040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an actionmodule with dummy arguments
    am = ActionModule(
        connection='None',
        module_name='shell',
        args='ls',
        task_vars={},
        injected=False,
        runner_enable_callback=False,
        loader=None,
        shared_loader_obj=None,
        templar=None,
    )
    assert isinstance(am, ActionBase)

# Generated at 2022-06-11 12:07:09.696615
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    result = dict(skipped="")
    wrap_async = True
    invocation = dict(module_args="test_args")
    task_vars = dict()
    action_plugin = ActionModule()
    import pdb;pdb.set_trace()
    action_plugin._task = dict(async_val=wrap_async,action="")
    result = merge_hash(result, action_plugin._execute_module(task_vars=task_vars, wrap_async=wrap_async))

    assert result == dict()

# Generated at 2022-06-11 12:07:10.257008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:07:41.939789
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mod = ActionModule()
    print ("Test for No.1")
    mod._execute_module = lambda x: {"a":1}

    mod._task = {"action": "setup"}
    res = mod.run( task_vars={}, tmp="./tmp" )
    assert res == {"a":1, "_ansible_verbose_override": True}

    mod._task = {"action": "something", "async": 42}
    mod._connection = { "has_native_async": True }
    res = mod.run( task_vars={}, tmp="./tmp" )
    assert res == {"a":1, "_ansible_verbose_override": False}

    print ("Test for No.2")
    mod._task = {"action": "something"}

# Generated at 2022-06-11 12:07:45.000080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleTest(ActionModule):
        pass

    # Test ActionModule constructor
    action_module = ActionModuleTest(None, {}, {}, None)
    assert action_module._supports_check_mode
    assert action_module._supports_async

# Generated at 2022-06-11 12:07:47.334073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create object of ActionModule
    a = ActionModule(None, None)
    # check if the object is instance of ActionModule
    assert isinstance(a, ActionModule)


# Generated at 2022-06-11 12:07:54.774037
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    actionModule = ActionModule(1)
    actionModule._task = 1
    actionModule._task.async_val = None
    actionModule._task.action = "_ansible_test"
    actionModule._supports_async = True
    actionModule._supports_check_mode = True
    actionModule._connection = None
    actionModule._connection._shell = None
    actionModule._connection._shell.tmpdir = None

    # First run should just return the result
    actionModule.run("tmp test", "task_vars test")

    # Second run should just return the result
    actionModule.run("tmp test", "task_vars test")

# Generated at 2022-06-11 12:08:03.645694
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import AnsibleVars
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    #from ansible.vars.unsafe_proxy import UnsafeProxy
    #from ansible.vars.hostvars import HostVars

    class MockVars(AnsibleVars):
        def get_vars(self, loader, path, entities, cache=True):
            return {}

    class MockTemplar(Templar):
        def __init__(self, loader, shared_loader_obj=None):
            self._available_variables = {}

        def template(self, data):
            return data

    class MockTask(object):
        async_val = None


# Generated at 2022-06-11 12:08:13.466019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Mine(object):
        pass
    module_args = {
        "chdir": "/root",
        "module_name": "ping",
        "module_args": {
            "data": "pong"
        }
    }

    task_vars = {}
    tmp = "/tmp"

    module = Mine()
    module._task = Mine()
    module._task.action = "ping"
    module._task.environment = {}
    module._task.args = {}
    module._task.async_val = 10
    module._task.notify = []
    module._task.until = []
    module._task.run_once = False
    module._task.delegate_to = None
    module._task.first_available_file = None
    module._task.local_action = "ping"
    module

# Generated at 2022-06-11 12:08:22.436734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    sys.path.insert(0, os.path.dirname(__file__) + "/../")  # local clone of module
    from ansible.plugins.action import ActionModule
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.task_vars import TaskVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    module = 'ping'
    forks = 10
    connection = 'smart'
    remote_user = 'root'
    task_vars = dict(a=1, b=2)  # could be TaskVars()
    verbosity = 0

   

# Generated at 2022-06-11 12:08:33.505201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {'action': 'foo'}
    task_vars = {'foo': 'bar'}
    tmp = 'baz'

    # Set up mock class for ActionBase
    class ActionBaseMock(ActionBase):
        def run(self, tmp=None, task_vars=None):
            pass

        def _execute_module(self, *args, **kwargs):
            pass

        def _remove_tmp_path(self):
            pass

    mock_action_base = ActionBaseMock(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result = mock_action_base.run(tmp=tmp, task_vars=task_vars)
    assert result['_ansible_verbose_override']

# Generated at 2022-06-11 12:08:41.433308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Loading modules as we are testing a module in this action plugin
    import ansible.modules.system.ping as module
    import io

    # Initialize required objects
    context = PlayContext()

# Generated at 2022-06-11 12:08:42.225194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "TODO: write unit test"

# Generated at 2022-06-11 12:09:40.550815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule's run method")
    action_module = ActionModule()
    action_module._remove_tmp_path = mock.Mock()
    action_module._execute_module = mock.Mock()
    action_module.run()
    action_module._execute_module.assert_called_once()

# Generated at 2022-06-11 12:09:41.541030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    assert am != None

# Generated at 2022-06-11 12:09:43.051355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(NotImplementedError):
        assert ActionModule._execute_module()

# Generated at 2022-06-11 12:09:45.552721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionmodule is not None


# Generated at 2022-06-11 12:09:47.610976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule(None, None, None, None)
    assert action_module

# Generated at 2022-06-11 12:09:51.750462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = None
    mock_connection = None
    mock_play_context = None
    mock_loader = None
    mock_templar = None
    test_action_module = ActionModule(mock_task, mock_connection, mock_play_context, mock_loader, mock_templar)
    assert test_action_module is not None
    del test_action_module

# Generated at 2022-06-11 12:10:00.059450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # set up our test data
    action_name = "Shell"
    params = {"overwrite" : True}
    task_name = "Test task 1"
    task_vars = {}
    sources = ["test1.txt", "test2.txt"]
    dest = "/tmp/test.txt"
    tmp = "/tmp"
    # set up our test env
    action_instance = ActionModule(action_name, params, task_name, task_vars, tmp, sources, dest)
    # check result
    # assert action_instance._name == action_name
    assert action_instance._name == 'file' # this should be the real module name
    assert action_instance._task_name == task_name
    assert action_instance._task_vars == task_vars
    assert action_instance._tmp == tmp

# Generated at 2022-06-11 12:10:01.122830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None)
    assert a is not None

# Generated at 2022-06-11 12:10:05.308819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action='ping', async_val=10, async_jid='123'),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict()
    )
    assert action_module._supports_async is True
    assert action_module._supports_check_mode is True

# Generated at 2022-06-11 12:10:06.118909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass
#print ActionModule()

# Generated at 2022-06-11 12:12:24.046052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:12:24.868012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule("module", "play_hosts"))

# Generated at 2022-06-11 12:12:32.621936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_connection_vars = {}
    mock_connection_vars['_shell'] = {'tmpdir': '/home/gabry3795/mock_tmpdir'}
    mock_connection_vars['has_native_async'] = True
    mock_connection_vars['module_implementation_preferences'] = ['smart', 'ssh']
    mock_connection = type('', (object,), mock_connection_vars)
    mock_task_vars = {}

    mock_task = {
        'async_val': '1800',
        'action': 'setup',
        'args': 'ansible.builtin.setup'
    }

    mock_task_vars['task_vars'] = mock_task
    mock_task_vars['SECURITY'] = {}
    mock_task_v

# Generated at 2022-06-11 12:12:35.032715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print()
    print('--Unit test for method run of class ActionModule')
    # test modules/actions/__init__.py
    # def run(self, tmp=None, task_vars=None): 
    # 
    # pass
    pass

# Generated at 2022-06-11 12:12:42.970849
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:12:50.865286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initalization of ActionModule object
    am = ActionModule()

    # Set the object property
    am._supports_check_mode = True
    am._supports_async = True
    am._task = {}
    am._task.async_val = False
    am._connection = {}
    am._connection.has_native_async = False
    am.run()

    # Set the object property
    am._supports_check_mode = True
    am._supports_async = True
    am._task = {}
    am._task.async_val = True
    am._connection = {}
    am._connection.has_native_async = False
    am.run()

    # Set the object property
    am._supports_check_mode = True
    am._supports_async = True


# Generated at 2022-06-11 12:12:51.495511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return True

# Generated at 2022-06-11 12:12:52.248285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()

# Generated at 2022-06-11 12:12:58.858546
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys

    class ActionModule(object):

        _actions = ['setup']

        def __init__(self, action, module_dirs=[]):

            self.action = action
            self.module_dirs = module_dirs

        def run(self, tmp=None, task_vars=None):

            return {'action': self.action}

    setup_action = ActionModule('setup')
    assert setup_action.run(None, None)

    non_action = ActionModule('ping')
    with pytest.raises(SystemExit):
        non_action.run(None, None)

    print("Unit test for method run of class ActionModule done")


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 12:13:05.492469
# Unit test for method run of class ActionModule