

# Generated at 2022-06-11 12:03:11.764508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module.run(None, None) is not None

# Generated at 2022-06-11 12:03:12.663455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert True

# Generated at 2022-06-11 12:03:15.260536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._supports_async = True
    module._supports_check_mode = True
    result = module.run()
    if result is None:
        raise AssertionError("ActionModule.run() returned None")

# Generated at 2022-06-11 12:03:24.053575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    action = ActionModule(load_plugins=False)
    func_name = 'test_ActionModule_run'
    tmp = func_name + '_tmp'
    task_vars = dict(ANSIBLE_JINJA2_NATIVE=True)
    result = dict(skipped=True)
    wrap_async = False
    action._supports_check_mode = True
    action._supports_async = True
    result = merge_hash(result, action._execute_module(task_vars=task_vars, wrap_async=wrap_async))
    print(result)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:03:35.630372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    class TestActionModule(ActionModule):
        TRANSFERS_FILES = False

        def run(self, tmp=None, task_vars=None):
            module_fixed_arguments = self._task.args.copy()
            # don't pass the non-module_fixed_arguments in to the module
            if 'non_module_fixed_arguments' in module_fixed_arguments:
                del module_fixed_arguments['non_module_fixed_arguments']
            return super(TestActionModule, self).run(tmp, task_vars)
        def _execute_module(self, tmp=None, task_vars=None, wrap_async=None):
            return {'a': 1}

    task = Task()

# Generated at 2022-06-11 12:03:44.277639
# Unit test for method run of class ActionModule
def test_ActionModule_run():

     task_vars = dict(
        ansible_ssh_host='127.0.0.1',
        ansible_ssh_pass='pass',
        ansible_ssh_port=22,
        ansible_ssh_user='user',
        ansible_sudo_pass='pass',
        ansible_become_pass='pass',
    )


# Generated at 2022-06-11 12:03:47.775631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.strategy.linear import ActionModule as ActionModule
    # task_vars = {}
    # c = ActionModule(task_vars)
    # res = c.run()
    # assert res['changed'] == True
    pass

# Generated at 2022-06-11 12:03:56.334229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import merge_hash
    import ansible.plugins.action.normal as normal
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.playbook_executor import PlaybookExecutor

    task = Task()
    task.action = "normal"
    task.async_val = 1
    task.async_seconds = 5
    task.reaches_hosts = True
    task

# Generated at 2022-06-11 12:03:58.369358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule")
    module = ActionModule(runner)
    assert module


# Generated at 2022-06-11 12:04:00.277199
# Unit test for constructor of class ActionModule
def test_ActionModule():
   actionmodule = ActionModule()
   assert type(actionmodule) == ActionModule


# Generated at 2022-06-11 12:04:06.308938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert issubclass(ActionModule, ActionBase) is True
    assert issubclass(ActionModule, ActionBase) is True

# Generated at 2022-06-11 12:04:06.987123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:04:10.943475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    print(am._supports_async)
    print(am._supports_check_mode)
    print(am.target)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:04:12.862516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('name', {'module_args': 'foo'}, 'connection', 'action')

# Generated at 2022-06-11 12:04:23.225194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    from ansible.plugins.action import ActionModule
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group

    host = Host(name="localhost")
    group = Group(name="ungrouped")
    group.add_host(host)
    task = Task()
    task.set_loader(None)
    variable_manager = VariableManager()
    variable_manager.set_inventory(None)
    action_plugin = ansible.plugins.action.ActionModule(task, variable_manager)
    action_plugin._add_host(host)
    action = ActionModule(task, variable_manager)
    assert action is not None

# Generated at 2022-06-11 12:04:26.128626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a._supports_async
    assert a._supports_check_mode

# Generated at 2022-06-11 12:04:36.792900
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # mock the imports
    class MockActionModule:
        _supports_check_mode = False
        _supports_async = False
        def __init__(self):
            self._task = None
            self._connection = None
    old_ax = ActionModule
    ActionModule = MockActionModule

    # mock the _execute_module method
    import copy
    tmp = copy.deepcopy(result)
    tmp['ok'] = True
    tmp['result'] = 'yay'
    old_ex_mod = ActionModule._execute_module
    ActionModule._execute_module = lambda self, **kwargs: tmp

    # mock the run method
    old_ac_run = ActionBase.run
    ActionBase.run = lambda self, tmp, task_vars: result

    # mock the super() method

# Generated at 2022-06-11 12:04:48.171930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    config_manager = ConfigManager()
    config_manager._update_vars({'host_key_checking': False})
    config_manager._update_vars({'retry_files_enabled': False})
    config_manager._update_vars({'forks': 10})
    mock_loader = config_manager._loader
    mock_inventory = InventoryManager(loader=mock_loader, sources='localhost,')
    mock_play_context = PlayContext()
    # NOTE:
    # This test needs a module_utils module to be present, because
    # some base class initializations fail without it.
    #
    # Prior to Ansible 2.8 this module_utils file

# Generated at 2022-06-11 12:04:49.343956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None)
    assert module != None

# Generated at 2022-06-11 12:04:59.579586
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.normal as action_normal
    from ansible.module_utils.six import StringIO
    import sys

    # mock class for the parent of ActionModule
    class Parent(object):
        pass

    # mock class for the connection of ActionModule
    class Connection(object):
        def __init__(self):
            self._shell = None

        def set_shell(self, shell):
            self._shell = shell

        def has_native_async(self):
            return False

        def close(self):
            pass

    # mock class for the shell of ActionModule
    class Shell(object):
        def __init__(self):
            self.tmpdir = None

        def _create_tmp_path(self):
            fp = StringIO()
            self.tmpdir = fp
            return f

# Generated at 2022-06-11 12:05:08.738020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test ActionModule constructor

    """
    module = ActionModule(dummy_connection, 'dummy_inventories')
    assert module._supports_async == True
    assert module._supports_check_mode == True

# Generated at 2022-06-11 12:05:19.340623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an object
    a = ActionModule(loader=None, variable_manager=None, task_queue=None)
    # no exception
    res = a.run(tmp=None, task_vars=None)
    # return is a dictionary
    assert isinstance(res, dict)
    # following keys are present
    assert 'skipped' in res
    # but return value is actually a number
    assert isinstance(res['skipped'], int)
    # no exception
    assert a.run(tmp=None, task_vars=dict()) is not None
    # no exception
    assert a.run(tmp=None, task_vars=dict(action_plugin_task_vars=dict())) is not None
    # no exception

# Generated at 2022-06-11 12:05:23.373504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection=None, task=None, loader=None, play_context=None)
    assert am._supports_check_mode == True
    assert am._supports_async == True
    assert am._display.name() == 'None'

# Generated at 2022-06-11 12:05:26.989649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with open('ansible/plugins/action/setup.py') as f:
        code = compile(f.read(), 'ansible/plugins/action/setup.py', 'exec')
        exec(code)

# test_ActionModule()

# Generated at 2022-06-11 12:05:31.181715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup a test class
    class TestActionModule:
        def run(self, tmp=None, task_vars=None):
            return {'skipped': 'skipped'}

    test_ActionModule = ActionModule(TestActionModule)
    assert test_ActionModule.run() == {'skipped': 'skipped'}

# Generated at 2022-06-11 12:05:31.837272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:05:33.644401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    mock_exec = MockActionModule()
    assert mock_exec is not None
    """

# Generated at 2022-06-11 12:05:34.290467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:05:44.952585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test ActionModule's method run  """

    import sys
    import ansible.plugins.action

    action = ansible.plugins.action.ActionModule(
        task=dict(action='run', async_=1, async_status_output=False, async_files=None, async_seconds=False),
        connection=dict(transport='dummy'),
        play_context=dict(become=False),
        loader=None,
        variable_manager=None,
        templar=None
    )
    action._add_cleanup_task = lambda: sys.exit(1)

    # We take 1 as input
    action._execute_module = lambda task_vars=None, wrap_async=False: 1

    # We expect 1 as result
    result = action.run(tmp=1, task_vars=2)

# Generated at 2022-06-11 12:05:55.092606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class AnsibleActionModuleTest:
        class ActionModule:
            pass
        class task:
            async_val = False
            class action:
                value = 'test'
                def __eq__(self, t):
                    return self.value == t
        class _task:
            action = 'test'
            class async_val:
                value = True
                def __bool__(self):
                    return self.value
            async_val = async_val()
        class _connection:
            def _shell_plugin(self):
                return None
            class _shell:
                tmpdir = None
            class has_native_async:
                value = False
                def __bool__(self):
                    return self.value
            has_native_async = has_native_async()
        _task = _task()
        _

# Generated at 2022-06-11 12:06:18.673047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.ini import InventoryParser
    from ansible.parsing.dataloader import DataLoader
    # Create a dummy task to test ActionModule
    # Our dummy task has two tasks one normal task and one block task
    # Each task has two handlers
    # Each handler has one task in it
    # This is used to verify that all handlers have been called
    in_host = Host('10.0.2.15')

# Generated at 2022-06-11 12:06:19.250326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-11 12:06:20.169109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(FakeTask(), FakeConnection()) != None

# Generated at 2022-06-11 12:06:27.038722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.jsonobjects as json
    import ansible.plugins.action as action

    # Instantiate a mock object to test the action module
    mock_connection = action.connection_loader.get('local', class_only=True)()
    mock_task = action.task_loader.get(dict(action='command'), class_only=True)()
    mock_task.task_vars = {}
    mock_task.action = 'command'
    mock_action = action.action_loader.get('command', class_only=True)()
    mock_action._supports_check_mode = True
    mock_action._supports_async = True
    mock_action._task = mock_task
    mock_action._connection = mock_connection

    # Mock the methods which can throw errors
    mock_action._execute_module

# Generated at 2022-06-11 12:06:36.569626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    from ansible.plugins.loader import action_loader

    fake_loader = action_loader.ActionLoader()
    fake_task = None
    fake_play_context = PlayContext()
    fake_inventory = InventoryManager([], [])
    fake_variable_manager = VariableManager([], [])


# Generated at 2022-06-11 12:06:37.268477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:06:46.575109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    # Set up all objects needed to run the module
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, 'hosts')
    play_context = {}

    play_source = dict(
        name="test play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict()))
        ]
    )

    # Create the

# Generated at 2022-06-11 12:06:47.660468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Hello, world!")

# Generated at 2022-06-11 12:06:56.825995
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Creating a mock object of ansible.parsing.dataloader.DataLoader class
    mock_loader = MagicMock()
    # Creating a mock object of ansible.parsing.vault.VaultSecret class
    mock_vault_secret = MagicMock()
    # Creating a mock object of ansible.parsing.vault.VaultLib class
    mock_vault_lib = MagicMock()
    # Creating a mock object of ansible.utils.vars.VariableManager class
    mock_variable_manager = MagicMock()
    # Creating a mock object of ansible.inventory.manager.InventoryManager class
    mock_inventory_manager = MagicMock()
    # Creating a mock object of ansible.plugins.loader.ActionModule class

# Generated at 2022-06-11 12:07:03.098713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.set_options({"module_name" :"test_module"})
    module.set_args({"test_arg" : "test"})
    assert module.run(task_vars={}) == {u'changed': False, u'_ansible_no_log': False, u'_ansible_module_name': u'test_module', u'_ansible_verbose_always': True, u'_ansible_module_args': u'{"test_arg": "test"}'}

# Generated at 2022-06-11 12:07:34.414266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(
        task={"action": "test", "async": 300},
        connection={"conn_tls_get_certs": True, "conn_host": "localhost"},
        play_context={"no_log": True, "become": False, "become_method": "sudo", "become_user": "root"},
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert m.task == {"action": "test", "async": 300}
    assert m.connection == {"conn_tls_get_certs": True, "conn_host": "localhost"}
    assert m.no_log == True
    assert m._become == False
    assert m._become_method == "sudo"

# Generated at 2022-06-11 12:07:34.967103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-11 12:07:44.869821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    a = ActionModule()
    # Set attributes of instance a
    a._supports_async = True
    a._supports_check_mode = True
    a._task = '_task'
    a._connection = '_connection'
    # Set the return value of mock method _execute_module()
    a._execute_module = Mock(return_value='_execute_module()')
    # Set the return value of mock method async_val()
    a._task.async_val = Mock(return_value=True)
    # Set the return value of mock method has_native_async()
    a._connection.has_native_async = Mock(return_value=False)
    # Set the return value of mock method run()

# Generated at 2022-06-11 12:07:45.783070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('', {}, {})

# Generated at 2022-06-11 12:07:55.060486
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible import constants as C
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

    # Test for method run of class ActionModule
    # Test for sub class of class ActionModule
    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            super(ActionModule, self).run(tmp, task_vars)
            self._supports_check_mode = True
            self._supports_async = True
            result = {'skipped': True}
            wrap_async = self._task.async_val and not self._connection.has_native_async

# Generated at 2022-06-11 12:07:56.379105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("action_plugin :: action.run")
    # FIXME: not implemented

# Generated at 2022-06-11 12:07:58.759350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    pass

# Generated at 2022-06-11 12:08:04.440559
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six.moves.builtins import set
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    action = ActionModule({}, {'_ansible_verbose_always': True}, DataLoader(), None, Play(), Task(), None)
    assert action._supports_check_mode == True
    assert action._supports_async == True

# Generated at 2022-06-11 12:08:08.666821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  test_action = ActionModule()
  print("test_ActionModule_run -- TESTING")

  run_result = test_action.run()
  print("  run_result = %s" % (run_result))

  assert 'skipped' in run_result
  assert run_result['skipped'] == False

# Generated at 2022-06-11 12:08:09.219815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:09:09.397432
# Unit test for constructor of class ActionModule
def test_ActionModule():
   assert True

# Generated at 2022-06-11 12:09:10.532570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() == {}


# Generated at 2022-06-11 12:09:15.085926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a action_module object and test it
    module_name = "ping"
    args = dict()
    task_vars = dict()
    tmpdir = "tmpdir"
    wrap_async = True

    action_module = ActionModule()
    # test the following function
    result = action_module._execute_module(task_vars, wrap_async)
    #assert result == 'result'

# Generated at 2022-06-11 12:09:17.173061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule constructor')
    ActionModule()
    print('Success!')
    print()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:09:18.907173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('In method run')
    print('module is')
    print(ActionModule)

# Generated at 2022-06-11 12:09:25.739212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.connection.local import Connection
    from ansible.plugins.action.normal import ActionModule
    from ansible.task import Task
    from ansible import inventory

    host = inventory.host.Host(name="testhost")
    task = Task(action=dict(module="ping"))
    conn = Connection(host=host)
    action_plugin = ActionModule(task, conn)

    assert(action_plugin)
    assert(action_plugin._task)
    assert(action_plugin._connection)
    assert(action_plugin._task._ds)
    assert(action_plugin._task.action)

# Generated at 2022-06-11 12:09:36.181780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansibledoc.ansible_module import ActionModule
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansibledoc.vars import VariableManagerExtra
    from ansible.executor.task_queue_manager import TaskQueueManager

    action = ActionModule(
        task=dict(action='shell'),
        connection='local',
        play_context=PlayContext(),
        loader=None,
        templar=Templar(),
        shared_loader_obj=None)
    action._task.action = 'shell'

# Generated at 2022-06-11 12:09:43.011888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    # Test ActionModule()
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    action_module._remove_tmp_path(None)
    action_module._execute_module(task_vars=None, wrap_async=False)
    action_module.setup(task_vars=None)
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:09:44.255997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am is not None

# Generated at 2022-06-11 12:09:52.837160
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class Start:

        def __init__(self, fake_task, fake_connection, fake_play_context, fake_loader, fake_templar, fake_shared_loader_obj):
            self.task = fake_task
            self.connection = fake_connection
            self.play_context = fake_play_context
            self.loader = fake_loader
            self.templar = fake_templar
            self.shared_loader_obj = fake_shared_loader_obj

    class FakeTask:

        def __init__(self):
            self.action = 'fake-action'
            self.async_val = None

    class FakeConnection:

        def __init__(self):
            self.has_native_async = False

    class FakePlayContext:

        def __init__(self):
            self.verb

# Generated at 2022-06-11 12:12:12.677028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:12:13.520536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:12:21.533627
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ############ Mock Task, then action plugin ############
    task_vars = {}
    tmp = None
    result = {}
    async_val = True
    test_task = MockTask()
    test_task.async_val = async_val
    test_action = MockAction(task=test_task, connection=MockConnection(), result=result, tmp=tmp)

    ############ Call run of MockAction ############
    test_action.run(tmp=tmp, task_vars=task_vars)

    ############ Assertions ############
    assert test_action.run_called == True
    assert test_action.run_called_with == {'tmp': None, 'task_vars': {} }
    assert test_action.tmp_paths_called == True
    assert test_action.tmp_

# Generated at 2022-06-11 12:12:27.628397
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Instantiate class ActionModule
    a = ActionModule()

    # Instantiate class ActionBase
    b = ActionBase()
    # The main task sponsor is return
    task_vars = b._get_vars(None, None)
    print(task_vars)
    # Temporary directories created with the temporary name
    tmp = "/tmp/tmp.wCgZd4JZH4"
    # The main task sponsor is return
    result = a.run(tmp, task_vars)
    print(result)


# test
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:12:35.130983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.loader import connection_loader, module_loader
    import ansible.constants as C


    C.HOST_KEY_CHECKING = False

    module_name = 'ping'
    module_args = ''
    module_kwargs = { 'data': 'hello world' }
    module_class = module_loader.get(module_name)
    module_connection = connection_loader.get('local', class_only=True)()
    task_uuid = 'test_action_module'
    task_vars = { 'ansible_ssh_host': '127.0.0.1' }

    play_context = PlayContext()

# Generated at 2022-06-11 12:12:36.448660
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass
# Unit tests for method run of class ActionModule

# Generated at 2022-06-11 12:12:38.394578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Starting test_ActionModule_run')
    # TODO: Add test case
    print('Finished test_ActionModule_run')
    return


# Generated at 2022-06-11 12:12:46.114639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    mock_loader1 = unittest.mock.MagicMock()
    mock_loader1.load_from_file.return_value = dict(
        _raw_params='',
        _uses_shell=False,
        _binary_argv=None,
        _async_timeout=600,
        _async_jid=None,
        _uses_delegation=False,
        _delegate_to=None,
        _environment=None,
        _no_log=None)

    mock_loader2 = unittest.mock.MagicMock()

# Generated at 2022-06-11 12:12:46.660573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
      pass

# Generated at 2022-06-11 12:12:53.701625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    #Create a dataloader object
    loader = DataLoader()
    #Create an inventory object
    inventory = InventoryManager(loader=loader, sources=None)
    #Create a variable manager object
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    #Create a task object