

# Generated at 2022-06-11 12:03:15.701551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.task import Task
    connection = Connection(play_context = dict(become="root", become_method="su"))
    task = Task()
    action_module = ActionModule(connection = connection, task = task, play_context = dict(become="root", become_method="su"))
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 12:03:25.562326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor with min args
    a = ActionModule('/some/fake/path', 'name', 'module')
    assert a._task.action == 'name'
    assert a._task.args == 'module'

    # test constructor with args
    a = ActionModule('/some/fake/path', 'name', 'module', 'timeout', 'poll', 'action', 'async', 'delegate_to', 'transport', 'notify', 'first_available_file', 'creates', 'remote_user', 'become', 'become_method', 'environment', 'no_log')
    assert a._task.action == 'name'
    assert a._task.args == 'module'
    assert a._task.async_val == 'async'
    assert a._task.delegate_to == 'delegate_to'
   

# Generated at 2022-06-11 12:03:29.423495
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule('name', 'Connection')
    assert module.name == 'name'
    assert module._connection == 'Connection'
    assert module._supports_async == False
    assert module._supports_check_mode == False



# Generated at 2022-06-11 12:03:30.874631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    return True

# Generated at 2022-06-11 12:03:32.416654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-11 12:03:34.030666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._supports_check_mode = True
    module._supports_async = True
    result = module.run(tmp=None, task_vars=[])
    assert result, result

# Generated at 2022-06-11 12:03:35.528839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The constructor of the class itself is tested
    assert ActionModule is not None

# Generated at 2022-06-11 12:03:44.213087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    r = {}
    r['_ansible_parsed'] = True
    r['invocation'] = {}
    r['invocation']['module_name'] = 'file'
    r['invocation']['module_args'] = 'test1'
    r['invocation']['module_complex_args'] = 'test2'
    r['invocation']['module_build_core'] = True

    cls = ActionModule()
    cls.run(r)

    assert r['invocation']['module_name'] == 'file'
    assert 'module_args' not in r['invocation']
    assert 'module_complex_args' not in r['invocation']
    assert 'module_build_core' not in r['invocation']


# Generated at 2022-06-11 12:03:44.920791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()

# Generated at 2022-06-11 12:03:50.437287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_fields = {'become': False, 'become_method': u'disable', 'become_user': None, 'async': 0, 'async_val': None, 'setup_task': None, 'delegate_to': None}
    task =  ActionModule(task_fields, '123')

    result = task.run(None, None)

    assert result == {'failed': True, 'msg': 'Not implemented yet.'}

# Generated at 2022-06-11 12:03:59.883686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    play_context = PlayContext()
    play_context._running_as_admin = True
    play_context._connection = 'local'

    # Specify all the parameters including those that are not used.
    t = Task()
    t._role = None
    t.action = 'copy'
    t.args = {}
    t.async_val = 0
    t.become = None
    t.become_method = None
    t.become_user = None
    t.check_mode = False
    t

# Generated at 2022-06-11 12:04:11.751740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.module_common import ModuleManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

   

# Generated at 2022-06-11 12:04:16.448943
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

    assert not action_module._supports_check_mode
    assert not action_module._supports_async

    # TODO(retr0h): How to test without the class knowledge of AnsibleBase?
    # assert action_module._task.async_val == "1"

# Generated at 2022-06-11 12:04:17.079560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:04:20.218241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(connection=None, task=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionModule is not None

# Generated at 2022-06-11 12:04:27.559050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_vars = dict(var1='test_var1', var2='test2')
    my_task = dict(action=dict(module='setup', args=''))
    my_task_vars = dict(var1=1, var2=2)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[my_task]
    )


# Generated at 2022-06-11 12:04:32.483250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cls = ActionModule
    assert cls._task == None, cls._task
    assert cls._connection == None, cls._connection
    assert cls._loader == None, cls._loader
    assert cls._templar == None, cls._templar
    assert cls._shared_loader_obj == None, cls._shared_loader_obj

# Generated at 2022-06-11 12:04:34.373515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # NOTE: method tested by test/units/plugins/action/test_action_plugins.py
    pass

# Generated at 2022-06-11 12:04:46.382489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest2
    from ansible import constants as C
    from ansible.module_utils.six import PY3
    from ansible.plugins.action.builtin import ActionModule
    from ansible.utils.vars import merge_hash

    from collections import namedtuple
    from ansible.module_utils.six import iteritems, string_types
    from ansible.module_utils._text import to_bytes, to_text

    TestModule = namedtuple("TestModule", ["name", "args", "params", "result", "has_native_async", "async_val"])


# Generated at 2022-06-11 12:04:47.335435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run not yet implemented")

# Generated at 2022-06-11 12:04:55.043026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg = {}
    obj = ActionModule(arg)
    assert obj.__class__.__name__ == ActionModule.__name__

# Generated at 2022-06-11 12:05:05.120143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    #### setup mock object
    #
    am = ActionModule()
    #
    #### success return
    #
    # expected return

# Generated at 2022-06-11 12:05:08.300374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action as action
    actionModule = action.ActionModule(action.ActionBase())
    print("ActionModule.run:", actionModule.run)
    assert actionModule.run != None


# Generated at 2022-06-11 12:05:18.929053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    args = dict(args=dict(a=1))
    host = '127.0.0.1'
    task = Task(action='test', args=args, async_val=10, async_seconds=10)
    play_context = PlayContext()
    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    action = ActionModule(task, play_context, variable_manager, loader=None)
    assert action._task == task
    assert action._connection is None
    assert action._tqm is None
    assert action._loader is None

# Generated at 2022-06-11 12:05:19.601376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Pass
    pass

# Generated at 2022-06-11 12:05:20.212148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:05:30.785671
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create mock objects
    mock_task = type('MockTask', (object,), dict(action='fake_action', async_val=False))
    mock_connection = type('MockConnection', (object,), dict(has_native_async=True, _shell=type('MockShell', (object,), dict(tmpdir='fake_tmpdir'))))

    # create class instance
    action_module = ActionModule(mock_task, mock_connection, 'fake_loader', 'fake_templar', 'fake_shared_loader_obj')


    # verify class attributes are as expected
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module._connection.has_native_async == True
    assert action_module._task.action == mock

# Generated at 2022-06-11 12:05:33.086634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    # Constructor of class ActionModule
    action_module = mock.Mock(spec=ActionModule)
    assert action_module

# Generated at 2022-06-11 12:05:41.930387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(action='not_a_real_module',
                     task=dict(action='not_a_real_module',
                               args=dict(),
                               async_val=10000,
                               ),
                     connection=dict(
                         module_name='not_a_real_module',
                         _shell=dict(
                             tmpdir=dict(
                             )
                         ),
                         has_native_async=True,
                     ),
                     )
    assert(a.task.action == 'not_a_real_module')
    assert(a._connection.has_native_async == True)


# Generated at 2022-06-11 12:05:43.355259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.setup_task()
    m.run()

# Generated at 2022-06-11 12:06:00.977986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ActionModule constructor
    action = 'async'
    task = object()
    connection = object()
    play_context = object()
    loader = object()
    templar = object()
    shared_loader_obj = None
    test_ActionModule = ActionModule(action, task, connection, play_context, loader, templar, shared_loader_obj)
    print(test_ActionModule)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:06:02.058940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d={"skipped": False, "invocation": {}}
    act=ActionModule(d, None, None, None)
    assert act is not None

# Generated at 2022-06-11 12:06:06.432082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mytmp = '/tmp/mytmp'
    mytask_vars = { 'mytask_vars': True }
    am = ActionModule(None, mytmp, mytask_vars)
    assert am._connection is None
    assert am._task_vars == mytask_vars
    assert am._tmp == mytmp

# Generated at 2022-06-11 12:06:07.003681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:06:08.443959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    assert am is not None

# Generated at 2022-06-11 12:06:09.133791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:06:10.667781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert type(module) == ActionModule

# Generated at 2022-06-11 12:06:13.992722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    # do nothing, just check that no error is raised at this time.
    assert (m.run() is not None)

# Generated at 2022-06-11 12:06:16.245950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-11 12:06:24.730156
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class ActionModuleTest(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(ActionModuleTest, self).run(tmp, task_vars)

    class ActionBaseTest(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(ActionModuleTest, self).run(tmp, task_vars)

    class TaskTest():
        action = 'action'
        async_val = True

    class ConnectionTest():
        has_native_async = True

    class TaskObjTest():
        async_val = True
        action = 'action'

    connectionTest = ConnectionTest()
    taskTest = TaskTest()
    actionModuleTest = ActionModuleTest()
    actionModuleTest._task = taskTest
    actionModuleTest._connection = connectionTest


# Generated at 2022-06-11 12:06:56.487859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Initialize Task and Connection variables
    import ansible.playbook
    import ansible.inventory
    import ansible.runner
    import ansible.callbacks
    import ansible.utils.template
    import ansible.errors
    import os
    task_vars_=dict()
    in_=ansible.inventory.Inventory(["/etc/ansible/hosts"])
    task_vars_['inventory_dir']=in_.basedir()
    task_vars_['_ansible_socket']=dict()
    task_vars_['_ansible_socket']['host']='localhost'
    task_vars_['_ansible_socket']['port']='22'
    task_vars_['_ansible_socket']['user']='vagrant'

# Generated at 2022-06-11 12:07:05.618851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.vars
    import ansible.plugins.action
    fake_ansible_vars_merge_hash = lambda x,y: {'test': 123}
    fake_ansible_plugins_action_ActionBase_run = lambda x, y: {'test2': 123}
    fake_ansible_plugins_action_ActionBase_run_module = lambda x, y: {'test3': 123}
    fake_ansible_utils_vars_merge_hash = ansible.utils.vars.merge_hash
    fake_ansible_plugins_action_ActionBase_run = ansible.plugins.action.ActionBase.run
    fake_ansible_action_module = ActionModule(dict(), "test")
    ansible.utils.vars.merge_hash = fake_ansible_vars

# Generated at 2022-06-11 12:07:08.198362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, {}, None, None, None, None)
    result = action.run()

    # test for assert.
    assert result == {'result': 'success'}

# Generated at 2022-06-11 12:07:09.610475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod != "AnsibleError"

# Generated at 2022-06-11 12:07:16.340112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instance of class ActionModule
    my_module = ActionModule()
    
    # Unittest for action module with tmp_path
    my_module.run('/tmp', {'a':'b','c':'d'})
    
    # Unittest for action module with task_vars
    my_module.run(task_vars={'a':'b','c':'d'})
    
    # Unittest for action module with multiple args
    my_module.run('/tmp', task_vars={'a':'b','c':'d'})

# Generated at 2022-06-11 12:07:17.976313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with problem
    module = ActionModule()
    module.id = 1

    module.id = 0

# Generated at 2022-06-11 12:07:20.253474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    print(action_module.run())

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:07:29.557111
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.inventory.host
    import ansible.parsing.dataloader
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.template
    import ansible.vars.manager

    from ansible.plugins.loader import action_loader

    action_module_class = action_loader.get('setup', class_only=True)
    assert issubclass(action_module_class, ActionModule)

    # Create a host for unit test below
    host = ansible.inventory.host.Host(name="test_host")

    # Create a dataloader for unit test below
    data_loader = ansible.parsing.dataloader.DataLoader()

    # Create a variable_manager for unit test below

# Generated at 2022-06-11 12:07:39.067711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""

    import pytest
    import ansible
    import ansible.plugins.action.normal
    import ansible.plugins.action.normal
    import ansible.plugins
    import ansible.plugins
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.vars
    import ansible.template
    import ansible.template
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.base
    import ansible.inventory
    import ansible.executor
    import ansible.executor.task_queue_manager
    import ansible.executor.task_result
    import ansible.utils.vars
    import ansible.utils.vars

# Generated at 2022-06-11 12:07:42.467928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test ActionModule constructor"""
    obj = ActionModule('some_module')
    assert obj._supports_check_mode == True
    assert obj._supports_async == True
    assert obj.module_name == 'some_module'

# Generated at 2022-06-11 12:08:39.534969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n[*] test_ActionModule_run")
    assert False

# Generated at 2022-06-11 12:08:47.242164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Runs the test_ActionModule_run() function with the following
    values:
    1. test_ActionModule_run.test1 = tmp = namedtuple('tmp',
        ['path'])()
    2. test_ActionModule_run.test1 = task_vars = dict()

    Tests
    1. test_ActionModule_run.test1 = Runs the run() method of the
        ActionModule class with tmp = namedtuple('tmp',
        ['path'])() and task_vars = dict() and returns a True
    """

    tmp = namedtuple('tmp', ['path'])()
    task_vars = dict()

    test = ActionModule().run(tmp, task_vars)
    assert test


# Generated at 2022-06-11 12:08:53.386115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    arguments = { 'module_name':'ping', 'module_args':{ 'data': 'test'}}
    task = dict(action=dict(__ansible_arguments__=arguments))
    plugin = ActionModule(task, dict())
    result = plugin.run(task_vars={'foo': 'bar'})
    result = json.loads(result)
    assert result['invocation']['module_name'] == 'ping'
    assert result['invocation']['module_args'] == {}
    assert result['foo'] == 'bar'

# Generated at 2022-06-11 12:08:54.838603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unittest for action_plugin.ActionModule._run()
    """
    pass

# Generated at 2022-06-11 12:08:55.461015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:08:55.967167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:08:57.097147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: mock this out
    pass

# Generated at 2022-06-11 12:09:04.610839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing with data that should return true, that is it succeeds
    # Testing with data that should return false, that is it fails
    # Expected result: A dictionary containing all the results including changed with value of True
    plugin = ActionModule()
    plugin._supports_check_mode = True
    plugin._supports_async = True
    result = plugin.run()

    assert result['changed'] == True

    # Testing with data that should return false, that is it fails
    plugin = ActionModule()
    plugin._supports_check_mode = False
    plugin._supports_async = False
    result = plugin.run()

    assert result['changed'] == False


# Generated at 2022-06-11 12:09:05.170542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:09:10.535230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.vars as vars
    import ansible.plugins.action.acme_modules as acme_modules

    vars_obj = vars.VarsModule()
    conn_obj = acme_modules.ConnectionModule()
    act_obj = acme_modules.ActionModule()

    a = ActionModule(vars = vars_obj, connection=conn_obj, action=act_obj)
    assert a is not None, "Failed to create ActionModule instance."

# Generated at 2022-06-11 12:11:23.743477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:11:24.395133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:11:25.186837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-11 12:11:32.590764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import __builtin__ as builtins      # pylint: disable=redefined-builtin
    import sys
    import os
    from ansible.plugins.action import ActionBase

    mock_loader1 = "loader1"               # pylint: disable=invalid-name
    mock_play_context = "play_context"     # pylint: disable=invalid-name
    mock_new_stdout = "new_stdout"         # pylint: disable=invalid-name
    mock_new_stdin = "new_stdin"           # pylint: disable=invalid-name
    mock_connection = "connection"         # pylint: disable=invalid-name
    mock_task_vars = "task_vars"           # pylint: disable=invalid-name

# Generated at 2022-06-11 12:11:34.480939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test case checks if the ActionModule class can be constructed or not.
    """
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-11 12:11:41.654933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import become_loader, vars_loader, action_loader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVarsModule
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    host_proto = Host("test_host", port=22)
    host_proto

# Generated at 2022-06-11 12:11:43.036874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule()
    am = ActionModule()
    print("ActionModule()", am)

# Generated at 2022-06-11 12:11:47.913475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import module_utils.urls as urllib2
    import ansible.plugins.action.normal as ansible_action_normal
    from ansible.plugins.action.normal import ActionModule as ActionModule_normal

# Generated at 2022-06-11 12:11:55.056466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    f = ActionModule()
    args = {
        'invocation': {
            'module_name': 'ping',
            'module_args': {
                'data': 'hello world'
            }
        },
        '_ansible_parsed_module_args': {
            'data': 'hello world'
        },
        'changed': True,
        '_ansible_no_log': False,
        '_ansible_ignore_errors': False,
        '_ansible_module_name': 'ping',
        '_ansible_module_set_localdisk': False,
        '_ansible_module_name': 'ping'
    }
    f._task.action = 'debug'
    f._task.async_val = 3
    f._task.args = args
    f._connection.has

# Generated at 2022-06-11 12:11:57.010406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor test
    """

    # Create a new object to test methods
    obj_module = ActionModule()

    # Test the constructor works
    assert obj_module != None