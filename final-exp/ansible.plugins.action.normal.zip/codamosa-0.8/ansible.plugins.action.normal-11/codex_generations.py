

# Generated at 2022-06-11 12:03:17.524596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile

    def _tempfile_maker():
        '''
        Used for mocking a temporary file.
        '''
        return tempfile.NamedTemporaryFile(delete=True).name
    old_tempfile_maker = ActionBase._make_tmp_path
    ActionBase._make_tmp_path = _tempfile_maker

    # Instantiate ActionBase
    actionBase = ActionBase()

    # Create local variables
    tmp = os.getcwd()
    task_vars = dict()

    # Set up
    new_connection = DummyConnection()
    actionBase._connection = new_connection
    new_task = DummyTask()
    actionBase._task = new_task

    # Run test
    actionBase.run(tmp, task_vars)

    # Remove mock
    ActionBase._make

# Generated at 2022-06-11 12:03:28.271989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import copy
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    if not boolean(os.environ.get('ANSIBLE_UNIT_TESTS')):
        pytest.skip("skipped because ANSIBLE_UNIT_TESTS is not set", allow_module_level=True)
    module_loader, pac=module_loader_finder.find_plugin()

# Generated at 2022-06-11 12:03:32.348860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionmodule
    assert isinstance(actionmodule, ActionModule)

# Generated at 2022-06-11 12:03:38.041523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_connection = MagicMock()

    mock_task = MagicMock()
    mock_task.async_val = False
    mock_task.action = "test_action"

    task_result = ActionModule(mock_connection, mock_task, loader=None, templar=None, shared_loader_obj=None).run(task_vars = {})
    assert task_result == {}


# Generated at 2022-06-11 12:03:45.525369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test data
    class ReturnData:
        def __init__(self, skipped, invocation, module_args, async_val, connection_has_native_async):
            self.skipped = skipped
            self.invocation = invocation
            self.module_args = module_args
            self.async_val = async_val
            self.connection_has_native_async = connection_has_native_async

            # Create a test module arguments
            self.module_args = {
                "key1": "value1",
                "key2": 2,
                "key3": True
            }
            self.module_args = {
                "async": "10",
                "poll": "10",
                "connect_timeout": "10"
            }


    class TaskVars:
        pass

   

# Generated at 2022-06-11 12:03:48.560339
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action = ActionModule(resident=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
  assert isinstance(action, ActionModule)


# Generated at 2022-06-11 12:03:56.859125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=anomalous-backslash-in-string
    from ansible.module_utils.basic import AnsibleModule
    
    test_dict = dict(
        _ansible_verbose_override=True,
        _ansible_no_log=False,
        _ansible_debug=False,
        msg='hello', # module_name.py
    )

    if isinstance(test_dict, dict):
        # pylint: disable=redefined-variable-type
        test_dict = AnsibleModule(argument_spec=dict()).ansible_module.do_jsonify(test_dict)
        
    assert isinstance(test_dict, str)

    actual = ActionModule().run(task_vars=dict(), tmp='/tmp')
    expected = test_dict
    
   

# Generated at 2022-06-11 12:03:57.458726
# Unit test for constructor of class ActionModule
def test_ActionModule():
	pass

# Generated at 2022-06-11 12:04:05.502286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_dict={"hostvars": {}}
    a = ActionModule(task=test_dict, connection=test_dict, play_context=test_dict, loader=test_dict, templar=test_dict, shared_loader_obj=test_dict)
    assert a._task == test_dict
    assert a._connection == test_dict
    assert a._play_context == test_dict
    assert a._loader == test_dict
    assert a._templar == test_dict
    assert a._shared_loader_obj == test_dict

# Generated at 2022-06-11 12:04:07.581769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('test','test','test','test',{}, 'test', 'test',False,False)

# Generated at 2022-06-11 12:04:21.780899
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create a mock object of the super class.
    connection = object()
    module_name = object()
    task_vars = object()
    loader = object()
    paths = object()
    templar = object()
    shared_loader_obj = object()
    task_ds = object()

    # Create an object of class ActionModule
    obj = ActionModule(connection, 
                       module_name, 
                       task_vars, 
                       loader, 
                       paths, 
                       templar, 
                       shared_loader_obj, 
                       task_ds)

    # Assertions
    assert obj._connection == connection
    assert obj._task_vars == task_vars
    assert obj._loader == loader
    assert obj._templar == templar
    assert obj._shared_loader_obj == shared

# Generated at 2022-06-11 12:04:22.709603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module

# Generated at 2022-06-11 12:04:26.942454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    tmp = None
    task_vars = None

    result = module.run(tmp, task_vars)

    if not result.get('skipped'):
        assert result == 'skipped'
    else:
        print(result)


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:04:37.471714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # _shared_loader_obj = '_shared_loader_obj'
    # _connection = '_connection'
    # _task = '_task'
    # _subset = '_subset'
    # _play_context = '_play_context'
    # _loader = '_loader'
    # _templar = '_templar'
    # _task_vars = '_task_vars'
    # _tmp = '_tmp'
    # _parent_args = '_parent_args'
    # _parent_result = '_parent_result'
    # _parent_executed = '_parent_executed'
    # _play_context_path = '_play_context_path'
    action_module = ActionModule()
    assert action_module.name == 'meta'

# Generated at 2022-06-11 12:04:41.705019
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    result = module.run(tmp="tmp", task_vars=True)
    assert result['invocation'].has_key('module_args') == False

# Generated at 2022-06-11 12:04:50.407319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test = os.path.dirname(__file__) + "/../unit/test_action.py"
    if not os.path.exists(test):
        raise AssertionError("No such file %s" % test)
    module_utils_path = os.path.dirname(__file__) + "/../../lib/ansible/module_utils/"
    module_path = os.path.dirname(__file__) + "/../../lib/ansible/modules/"
    test_loader = unittest.TestLoader()
    test_suite = test_loader.discover(module_path, pattern = "test_*.py", top_level_dir = None)
    result = unittest.TextTestRunner(verbosity=2).run(test_suite)
    return result.wasSuccessful()

# Generated at 2022-06-11 12:04:51.945272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am is not None

# Generated at 2022-06-11 12:04:53.032636
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

# Generated at 2022-06-11 12:05:03.175205
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    c = dict(connection='connection', module_args=dict(foo='bar', bam='baz'))
    m = dict(
        connection='connection',
        _ansible_check_mode=False,
        _ansible_verbosity=2,
        _ansible_no_log=False,
        _ansible_debug=False,
        name='name',
        action='action',
        delegate_to='delegate_to',
        async_val='async_val',
        async_jid='async_jid',
        environment=dict(a='1'),
        _ansible_builtin_path='/path/to/the/ansible/builtin',
        _ansible_version=dict(a='1', b='2', c='3'),
    )

# Generated at 2022-06-11 12:05:03.765844
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-11 12:05:16.919985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(action_module) == ActionModule
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module._supports_async_timeout == True
    assert action_module._shared_loader_obj == None

# Generated at 2022-06-11 12:05:28.072948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import sys
    import ansible
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    class MockTask(object):
        async_val = False
    mock_task = MockTask()

    class MockConnection(object):
        def has_native_async(self):
            return False
        class _shell(object):
            tmpdir = "foo_tmp_path"
    mock_connection = MockConnection()

    class MockTaskVars(object):
        def __init__(self, invocation=None, module_args=None, ansible_check_mode=False):
            if invocation is None:
                self.invocation = dict()
                if module_args is not None:
                    self.invocation['module_args']

# Generated at 2022-06-11 12:05:35.258314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run: x2')
    #1
    try:
        ActionModule.run(ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None))
    except TypeError as e:
        raise Exception('test_ActionModule_run: 1 do not except a TypeError')
    except Exception as e:
        pass
    #2
    try:
        ActionModule.run(ActionModule(task=1, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None))
    except TypeError as e:
        raise Exception('test_ActionModule_run: 2 do not except a TypeError')
    except Exception as e:
        pass
    #3

# Generated at 2022-06-11 12:05:45.807844
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import os, errno
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.task_queue_manager import TaskQueueManager

    ############################
    # # unit testing for ActionModule
    #  1) create a connection and an action plugin instance
    #  2) create a set of dummy data for the various methods of ActionModule
    #  3) loop through the various methods of ActionModule and check for returned values
    #     for each one.

    plugin = ActionModule(None,None)
    # define connection class to simulate a connection
    # connection class needs a few methods
    #  1) class init - will be called to create an instance of the class
    #  2) open
    #  3) close
    #  4

# Generated at 2022-06-11 12:05:55.914349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    import ansible.plugins
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.included_file
    import ansible.playbook.handler
    import ansible.playbook.handler_task_include
    import ansible.playbook.conditional
    import ansible.template
    import ansible.vars.manager
    import ansible.parsing.dataloader
    from ansible.inventory.host import Host

# Generated at 2022-06-11 12:05:57.365232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(load_shel_plugins=False)
    assert x is not None

# Generated at 2022-06-11 12:05:58.448079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("unit test for ActionModule class run")
    pass

# Generated at 2022-06-11 12:06:00.507213
# Unit test for constructor of class ActionModule
def test_ActionModule():
	'''
	Test constructor of class ActionModule
	'''
	action_mod = ActionModule()
	assert action_mod is not None


# Generated at 2022-06-11 12:06:00.919931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:06:03.380052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for no_log for module_args
    mod_mock = None
    mod_mock = ActionModule(mod_mock)
    task_vars = {}
    result = {'invocation': {'module_args': "abcd"}}
    assert mod_mock.run(tmp=None, task_vars=task_vars) == result

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-11 12:06:21.465725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    task_vars, play_context = dict(), dict(
        remote_addr='127.0.0.1',
        remote_user='test_user',
        password='test_pass',
        connection='test_connection'
    )

    am = ActionModule(task=dict(action='test_shell'))
    task_vars['ansible_facts'] = dict()

    assert am.run(None, task_vars)



# Generated at 2022-06-11 12:06:25.025902
# Unit test for constructor of class ActionModule
def test_ActionModule():
	path = 'test/test_actionmodule.py'
	runner = action.ActionModule(path)
	# TODO: add unittest for other methods and fields
	assert_equal(runner.path, path)
	assert_equal(runner.noop_values, ['NULL', 'nil', 'none'])

# Generated at 2022-06-11 12:06:27.244367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test Class Constructor: ActionModule")
    the_actionmodule = ActionModule()
    assert(the_actionmodule.__class__.__name__ == 'ActionModule')

# Generated at 2022-06-11 12:06:29.494796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None)
    assert isinstance(a, ActionModule)
    assert a.run(None, None).get('skipped')

# Generated at 2022-06-11 12:06:32.436448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(action='setup'), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert module._task.action == 'setup'

# Generated at 2022-06-11 12:06:33.746183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert isinstance(m,ActionModule)

# Generated at 2022-06-11 12:06:34.621457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-11 12:06:36.612389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._supports_check_mode is True
    assert a._supports_async is True

# Generated at 2022-06-11 12:06:37.631240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-11 12:06:43.861194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    args = {'a': 1, 'b': 2, 'c': [3,4,5]}
    task_vars = {'a':6,'b':[5,5,5]}
    action_module.run(args, task_vars)
    assert(args=={'a':1, 'b':2, 'c':[3,4,5]})
    assert(task_vars=={'a':6,'b':[5,5,5]})

# Generated at 2022-06-11 12:07:08.488574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, '_execute_module')

# Generated at 2022-06-11 12:07:10.926480
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mod = ActionModule()

    result = mod.run(tmp=None, task_vars=None)
    assert result == None

# testing run
test_ActionModule_run()

# Generated at 2022-06-11 12:07:20.090448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unit
    import os
    import socket
    import sys
    import time
    from mock import patch

    test_action_module = unit.AnsibleModule()
    test_action_module.params = {'action': 'run',
                                 'test': 'test'}
    test_action_module.action = 'run'

    # create a mock task that holds test_action_module
    test_task = unit.AnsibleTask()
    test_task.action = 'run'
    test_task.async_val = 2
    test_task.async_seconds = 10
    test_task.async_poll_interval = 3
    test_task.action_plugin = test_action_module

    # create a mock connection, with a mock shell that has a mock tmp_path

# Generated at 2022-06-11 12:07:21.302097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    # constructor must simply return
    assert True == True

# Generated at 2022-06-11 12:07:23.082005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    as action plugins run in their own forks, they cannot be unit tested
    """
    pass

# Generated at 2022-06-11 12:07:25.043895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:07:34.247006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The test assumes that the method run is called with the option
    # -k and -K.
    AM=ActionModule()
    tmp=None
    entered_ask_pass=0
    entered_ask_become_pass=0
    def test_ask_pass():
        nonlocal entered_ask_pass
        entered_ask_pass+=1
    def test_ask_become_pass():
        nonlocal entered_ask_become_pass
        entered_ask_become_pass+=1
    task_vars={'ansible_ask_pass': test_ask_pass,
               'ansible_become_pass': test_ask_become_pass}
    result=AM.run(tmp=tmp, task_vars=task_vars)
    assert result['skipped'] is False

# Generated at 2022-06-11 12:07:44.037344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    
    plugins = ansible.plugins
    # We will work with a connection for the local host
    connection = ansible.plugins.connection.local.Connection(play_context=None)
    # We will use a local InventoryManager
    inventory = InventoryManager(loader=None, sources=None)
    # We will use a local TaskQueueManager
    queue_manager = TaskQueueManager(
        inventory=inventory,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
    )
    # We will use a temporary playbook
    import tempfile


# Generated at 2022-06-11 12:07:44.994659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule("", "", "", "", "")

# Generated at 2022-06-11 12:07:54.224077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            module_name = dict(type='str'),
            module_args = dict(type='str'),
            module_path = dict(type='str')
        )
    )

    # Mock Objects
    class MockTask:
        async_val = False

    class MockConnection:
        has_native_async = False

        def _shell_expand_path(self, path):
            return path

        def _remove_tmp_path(self, path):
            pass

        def _shell_quote(self, arg):
            return arg

        def _shell_expand_path(self, arg):
            return arg

    class MockPlayContext:
        check_mode = False
        diff = False
        _clean_copy = False
        _extravars = dict()


# Generated at 2022-06-11 12:09:00.561638
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task

    tmp = "fake temp dir"
    task_vars = {}
    action_module = ActionModule(task=Task())
    result = action_module.run(tmp=tmp, task_vars=task_vars)

    assert result.get('failed') == False
    assert result.get('skipped') == False
    assert result.get('action_module') == True
    assert result.get('invocation') == {'module_args': {}, 'module_name': 'action_module'}

    if result.get('invocation', {}).get('module_args'):
        del result['invocation']['module_args']

    # do work!

# Generated at 2022-06-11 12:09:02.040236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action =  ActionModule()
    assert action.run() == None

# Generated at 2022-06-11 12:09:10.167169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Arguments:
        def __init__(self):
            self.task_vars = dict()
            self.task_vars['test'] = 'test_value'
    args = Arguments()
    action = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    action_module = ActionModule(
        action=action,
        connection=connection,
        play_context=play_context,
        loader=loader,
        templar=templar,
        shared_loader_obj=shared_loader_obj
    )
    assert action_module._execute_module(task_vars=args.task_vars)['test'] == 'test_value'

# Generated at 2022-06-11 12:09:10.710659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:09:12.912302
# Unit test for method run of class ActionModule
def test_ActionModule_run():  # noqa: F811
    # Initialize the instance
    am = ActionModule()

    # TODO: use a mock obj
    # call run
    am.run(None, None)

# Generated at 2022-06-11 12:09:20.766235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for the class ActionModule
    """
    import sys

    if sys.version_info[:2] == (2, 6):
        # FIXME: This is actually wrong.  We should be mocking the super class.
        # That is not possible however because unittest.mock is not available in
        # Python 2.6.  We should still fix this though, as it is technically
        # wrong.
        mock_super_class = object
    else:
        from unittest.mock import Mock
        mock_super_class = Mock

    # Construct ActionModule object
    action_module = ActionModule()

    # test the run() method
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:09:29.473199
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:09:33.604526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Dummy module name
    mod_name = 'setup'
    # Dummy module arguments
    mod_args = None

    # Assert that constructor runs with no error
    action_plugin = ActionModule(mod_name, mod_args)

# Generated at 2022-06-11 12:09:43.170930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import ansible.constants as C
    import ansible.utils.vars as V
    import ansible.plugins.action as action
    import ansible.task
    import ansible.play
    import ansible.playbook
    import ansible.plugins.connection.local
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import ansible.vars.manager
    from ansible.module_utils._text import to_native
    from ansible.compat.tests import unittest

    class MockModuleAction(action.ActionModule):
        pass


# Generated at 2022-06-11 12:09:50.188511
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # testing constructor
    player = ActionModule()
    # testing whether attributes are being set up properly or not
    assert player._task_vars == ""
    assert player._templar == ""
    assert player._tmp == ""
    assert player._connection == ""
    assert player._shell == ""
    assert player._loader == ""
    assert player._module_name == ""
    assert player._module_args == ""
    assert player._task.action == ''
    assert player._play_context == ""
    assert player._loaded_module_source == ""
    assert player._task.async_val == 0
    assert player._connection.has_native_async == False

# Generated at 2022-06-11 12:12:14.517063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, share_loader_obj=None)
    assert a

# Generated at 2022-06-11 12:12:22.609825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    import json
    
    # constants from the ansible module
    from ansible import constants as C

    # import class AnsibleAction
    from ansible.executor.task_executor import ActionModule

    # for creating task and task_vars
    from ansible.playbook.task import Task

    # for creating connection
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.play_context import PlayContext
    
    # setting up the connection
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = PlayContext()
    connection = 'local'

    # setting up the task
    task = Task()
    task.action = 'command' 

# Generated at 2022-06-11 12:12:30.343332
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:12:35.191230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._execute_module.return_value = {'status': 'Executed'}
    module._remove_tmp_path.return_value = False
    module._task.action = 'action'
    module._connection.has_native_async = False
    module._connection._shell.tmpdir = 'tmpdir'
    assert module.run(task_vars=dict()) == {
        '_ansible_verbose_override': False,
        'status': 'Executed',
    }

# Generated at 2022-06-11 12:12:38.216109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Load module
    from ansible.plugins import action
    import ansible.plugins.action.normal

    assert action.ActionModule == ansible.plugins.action.normal.ActionModule, "action.ActionModule should match with ansible.plugins.action.normal.ActionModule"

# Generated at 2022-06-11 12:12:40.054588
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a module instance
    module = ActionModule()

    # Check the method does not return anything.
    assert module.run() is None

# Generated at 2022-06-11 12:12:47.626418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test for the method `run` of class `ActionModule`
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
   

# Generated at 2022-06-11 12:12:51.626736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    task = TaskInclude()
    play_context = PlayContext()
    loader = DataLoader()

    am = ActionModule(task, play_context, loader)
    assert am

# Generated at 2022-06-11 12:12:52.329156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 12:12:55.859611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    a = action_loader.get('setup', class_only=True)
    assert type(a) == ActionModule
    assert a.action == 'setup'
    assert a.action_type == 'normal'

    a = action_loader.get('file', class_only=True)
    assert a.action == 'file'
    assert a.action_type == 'normal'