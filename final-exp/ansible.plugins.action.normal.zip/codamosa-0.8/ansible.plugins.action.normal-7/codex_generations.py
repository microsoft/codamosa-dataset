

# Generated at 2022-06-11 12:03:08.906382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 12:03:16.304872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    results_callback = TaskQueueManager._unused_callback
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    hostvars = dict()

    module_name = 'command'
    module_args = dict()
    module_args['_raw_params'] = 'ls -l'
    module_args['_uses_shell'] = True

# Generated at 2022-06-11 12:03:19.538199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test constructor of class ActionModule.

    Note: All testcases are written in ansible/test/unit/plugins/action/test_action_module.py.
    @precondition: None
    @postcondition: None
    """
    assert ActionModule._task_has_async_val_changed

# Generated at 2022-06-11 12:03:29.370331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    sys.path.append('tests/unit')
    from test_initialize import test_action_module

    retValue = test_action_module()

    assert retValue["invocation"] == {'module_name': 'ping'}

# Note : test_ActionModule_run() needs to be run as a python script
# for the imports to work when it is called as a module
if __name__ == "__main__":
    import sys
    sys.path.append('tests/unit')
    from test_initialize import test_action_module

    retValue = test_action_module()

    assert retValue["invocation"] == {'module_name': 'ping'}

# Generated at 2022-06-11 12:03:40.276125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test supported parameters
    module_args = {"action":"ping", "module_args":{"data":"foo"}}
    action = ActionModule(None, module_args, False)
    assert action._task.action == "ping", "failed to init ActionModule or setting action"

    # test default values
    assert "ping.py" == action._task.module_name, "failed to set module name"
    assert "ping" == action._task._role, "failed to set role name"
    assert False == action._task.async_val, "failed to set async_val"
    assert "copy" == action._transfer_strategy, "failed to set transfer strategy"

    # test validation
    module_args = {"action":"ping", "module_args":{"data":"foo"}}
    action = ActionModule(None, module_args, False)
   

# Generated at 2022-06-11 12:03:49.456403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self, spec):
            self.spec = spec

        def signature(self):
            return self.spec

    def fake_load_module_spec(name, path, conditional=None, inject=True, annotate=True):
        if conditional:
            return None
        if name == 'badmodule':
            raise Exception()

# Generated at 2022-06-11 12:03:52.123002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeActionModule(ActionModule):
        def run(a, b):
            pass

    t = FakeActionModule()
    assert t.__class__ == FakeActionModule
    assert t.run(None, None) == ({}, {})



# Generated at 2022-06-11 12:03:59.279338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    si = {}
    si['async_val'] = False
    from ansible.plugins.connection.local import Connection
    connection = Connection(si)
    si['connection'] = connection
    si['delegate_to'] = 'test'
    si['name'] = 'test'
    si['async_val'] = False
    si['action'] = 'setup'
    si['play'] = {}
    si['play']['hosts'] = 1
    si['play']['bogus'] = False
    si['play']['max_fail_percentage'] = None
    si['play']['remote_user'] = None
    si['play']['timeout'] = 10
    si['play']['gather_facts'] = 'test'
    si['play']['serial'] = 1

# Generated at 2022-06-11 12:03:59.906457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:04:01.564376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")
    print()
    module = ActionModule()

# Generated at 2022-06-11 12:04:15.988594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task = {
        'async_val' : None,
        'action' : '',
    }
    class TestActionModule(ActionModule):
        def _execute_module(self, tmp=None, task_vars=None, wrap_async=None):
            return {'module_result' : 'test_module_result'}

    test_connection = None
    test_play_context = {'verbosity' : 0, 'check_mode' : False}

    action_module = TestActionModule(task=test_task, connection=test_connection, play_context=test_play_context)
    task_vars = {}
    result = action_module._execute_module(task_vars=task_vars)
    assert result['module_result'] == 'test_module_result'

# Generated at 2022-06-11 12:04:24.979296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a object of class ActionModule.
    action_module = ActionModule(None, None, None)

    # Calling the method run with arguments task_vars, tmp and wrap_async.
    # Creating a dictionary to pass as an argument to run.
    task_vars = {"skipped":False,"ansible_facts":{}}
    # Creating a dictionary to pass as an argument to run.
    tmp = {"skipped":False,"ansible_facts":{}}
    # Creating a bool to pass as an argument to run.
    wrap_async = True
    # Calling run method of class ActionModule and storing the resut to result.
    result = action_module.run(tmp, task_vars)
    # Print result
    print (result)

# Generated at 2022-06-11 12:04:25.503610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert None

# Generated at 2022-06-11 12:04:27.919026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Inputs
    #
    #
    # Outputs
    #
    #
    # Source
    #
    #
    pass

# Generated at 2022-06-11 12:04:29.305373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: write unit test for ActionModule.run
    assert True is True

# Generated at 2022-06-11 12:04:41.296294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pdb
    import ast

    module = "os_server"
    wrap_async = False
    module_args = {}
    module_args['name'] = "s1"
    module_args['wait'] = True
    task_vars = {}

    action_module = ActionModule(module, module_args, tmpdir=None, wrap_async=wrap_async, task_vars=task_vars)

    data = action_module.run(tmp=None, task_vars=None)
    #pdb.set_trace()
    # assert "invocation" in data
    # assert "module_name" in data["invocation"]
    # assert "os_server" == data["invocation"]["module_name"]
    #pdb.set_trace()
    # assert "host" == data

# Generated at 2022-06-11 12:04:41.992314
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:04:44.213082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate class
    a = ActionModule()
    
    # Check if it is instance of ActionBase
    assert isinstance(a, ActionBase)

# Generated at 2022-06-11 12:04:46.291918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:04:52.725724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule({}, {}, {})
    m._supports_async = True
    task_vars = {
        'ansible_version': {},
        'ansible_facts': {
            'command_warnings': []
        },
        'ansible_play_hosts': {
            'localhost': {}
        }
    }
    mod_args = None
    tmp = None
    m._execute_module = lambda task_vars, tmp, wrap_async=False: {'skipped': False}
    m._task = {'async': 0}
    m._connection = {'has_native_async': False}
    result = m.run(tmp, task_vars)

# Generated at 2022-06-11 12:05:00.073079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am.supports_check_mode == True

# Generated at 2022-06-11 12:05:10.407105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params=dict(
        task_vars={},
        tmp=None,
        wrap_async=False
    )

# Generated at 2022-06-11 12:05:11.011508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:05:21.783957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a TestActionModule instance
    am = TestActionModule()

    # Create a TestTaskExecutor instance
    te = TestTaskExecutor()

    # Set the _task attribute of the TestActionModule instance
    # to the TestTaskExecutor instance
    am._task = te

    # Create a TestConnection instance
    tc = TestConnection()

    # Set the _connection attribute of the TestTaskExecutor instance to
    # the TestConnection instance
    te._connection = tc

    # Set the injected_into attribute of the TestActionModule instance
    am.injected_into = None

    # Set the action attribute of the TestTaskExecutor instance to
    # 'setup'
    te.action = "setup"

    # Set the module_style attribute of the TestConnection instance to
    # 'old'
    tc.module_style = "old"



# Generated at 2022-06-11 12:05:30.272904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod_name = 'tests.unit.plugins.modules.test_copy.copy'
    args = {'src': '/tmp/src', 'dest': '/tmp/dest', 'remote_src': False, 'module_args': 'src=/tmp/src dest=/tmp/dest remote_src=False'}
    
    am = ActionModule(None, mod_name, args=args)

    assert am.task_vars == {}
    assert am._task.action == 'copy'
    assert am._task.module_name == mod_name
    assert am._task.loop is None
    assert am._task.module_args == args

    return am


# Generated at 2022-06-11 12:05:32.502763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule("dummy", "dummy", "dummy", "dummy")
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 12:05:34.324706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 12:05:34.920009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:05:45.605548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    module_name = "ping"
    arguments = ""
    task = Task()
    task.action = module_name
    task.args = arguments

    variable_manager = VariableManager()
    inventory = InventoryManager()

# Generated at 2022-06-11 12:05:55.677465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class mock_connection(object):
        
        def has_native_async(self):
            return True
        
        def _shell(self):
            return self
        
        def tmpdir(self):
            return True
        
    class mock_task(object):
        
        def __init__(self, args):
            self.action = args["action"]
        
        def async_val(self):
            return True
        
    class object_task_vars(object):
        pass
        
    class mock_result(object):
        
        def __init__(self, args):
            self.skipped = args["skipped"]
            self.invocation = args["invocation"]
            
        def get(self, arg):
            return self.arg
        

# Generated at 2022-06-11 12:06:12.789568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    # The assert equals fails because the actual value is not a string but a <class 'ansible.vars.unsafe_proxy.UnsafeProxy'>
    # The expected value is a string
    # assert ActionModule(None, None).__str__() == "<ActionModule (ActionBase)>"
    pass

# Generated at 2022-06-11 12:06:18.621932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Creating data for test
    obj_1 = ActionModule()
    obj_1._supports_check_mode = True
    obj_1._supports_async = True
    tmp = None
    task_vars = None
    # Calling run() method
    obj_1.run(tmp, task_vars)




# Generated at 2022-06-11 12:06:22.136650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # run with no param - should be ok
    am = ActionModule()
    # run without any param, should fail
    failed = False
    try:
        am = ActionModule(1, None, None)
    except AssertionError:
        failed = True
        pass
    assert failed, "Should have failed with assertion error"

# Generated at 2022-06-11 12:06:31.476935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action="action_module", args=dict(action="foo", value="bar")),
        connection=MockConnection(),
        play_context=dict(remote_addr="1.2.3.4")
    )

    assert module.task.action == "action_module"
    assert module.task.args.action == "foo"
    assert module.task.args.value == "bar"
    assert module.play_context.remote_addr == "1.2.3.4"


from ansible.plugins.connection.ssh import Connection as SSHConnection
from ansible.plugins.connection.network_cli import Connection as NetworkCliConnection
from ansible.plugins.connection.paramiko_ssh import Connection as ParamikoConnection
from ansible.plugins.connection.local import Connection as LocalConnection

# Generated at 2022-06-11 12:06:35.066942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # module = c
    # args = [None, None, None]
    # classname = 'ActionModule'
    # action = ansible.plugins.action.ActionModule(module, args, classname)
    return

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:06:44.624152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    print("Constructor of ActionModule")
    # Unit test for constructor with option: connection
    connection = None
    action_module = ActionModule(connection=connection)
    assert action_module._connection is connection, \
        "connection of action_module is not equal to connection"

    # Unit test for constructor with option: task_loader
    task_loader = None
    action_module = ActionModule(task_loader=task_loader)
    assert action_module._task_loader is task_loader, \
        "task_loader of action_module is not equal to task_loader"

    # Unit test for constructor with options: connection and task_loader
    action_module = ActionModule(connection=connection, task_loader=task_loader)
    assert action_module._connection is connection

# Generated at 2022-06-11 12:06:45.513531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule is not None)

# Generated at 2022-06-11 12:06:48.621288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test requires python>=3
    import unittest
    class TestActionModuleRun(unittest.TestCase):
        def test_execution(self):
            pass
    unittest.main()


# Generated at 2022-06-11 12:06:49.835571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.module_name == 'action'

# Generated at 2022-06-11 12:06:50.477472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:07:16.544921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Obviously they're going to test this function in Ansible and not a generic library.
    # Just set the variable to False so that we don't see the stupid "test not found" message.
    # This variable is defined in the class above.
    test_ActionModule_run.ran = False

# Generated at 2022-06-11 12:07:17.858336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    print(ActionModule())

# Generated at 2022-06-11 12:07:19.109122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule({}, {})
    assert am is not None

# Generated at 2022-06-11 12:07:28.364972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    myhost = "myhost"
    myhost2 = "myhost2"
    myhost3 = "myhost3"
    myhost4 = "myhost4"

    # create a variable manager which will be shared throughout
    variable_manager = ansible.vars.VariableManager()
    variable_manager.extra_vars = {
        "my_var1":"hello_world",
        "my_var2":"goodbye_world"
    }
    
    # create a host and add it to the variable manager

# Generated at 2022-06-11 12:07:28.970818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:07:31.289575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule({})
    tmp = {}
    task_vars = {}
    result = m.run(tmp, task_vars)
    assert result == {}

# Generated at 2022-06-11 12:07:40.876880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test stubs
    class MockModuleResult:
        def __init__(self, *args, **kwargs):
            pass

# Generated at 2022-06-11 12:07:50.106699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up default config
    C._set_defaults()

    # set up default config
    C._set_defaults()
    action_module = ActionModule(None)
    result = {}
    task_vars = {}
    result = merge_hash(result, action_module._execute_module(task_vars=task_vars, wrap_async=True))
    assert result == {}, 'test_ActionModule_run failed!'

    result = {}
    if not result.get('invocation', {}).get('module_args'):
        result = merge_hash(result, action_module._execute_module(task_vars=task_vars, wrap_async=True))
        assert result == {}, 'test_ActionModule_run failed!'

    result = {}

# Generated at 2022-06-11 12:07:59.447781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=too-many-statements
    import copy
    from units.mock.procenv import replace_env_pass, replace_env_fail
    from units.mock.procenv import patch_get_bin_path, reset_get_bin_path
    from ansible.utils.vars import merge_hash
    from ansible import constants as C
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule
    from ansible.vars.unsafe_proxy import wrap_var

    def _execute_module(task_vars=None, wrap_async=False):
        return dict(failed=False)

    def _connection(self):
        return None


# Generated at 2022-06-11 12:07:59.995431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:08:57.634369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:09:05.835573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    my_task = Task()
    my_task._role = None
    my_task._block = None
    my_loader = DataLoader()
    my_inventory = InventoryManager("localhost,", loader=my_loader)
    my_variable_manager = VariableManager("localhost,", loader=my_loader, inventory=my_inventory)
    test_action_module = ActionModule(my_task, my_variable_manager, loader=my_loader, shared_loader_obj=my_loader)
    assert test_action_module is not None

# Generated at 2022-06-11 12:09:07.085664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(name='test_action', shared=False, connection='local')

# Generated at 2022-06-11 12:09:07.614192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:09:16.124829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import action_loader

    # test without fail_on_missing_implementation
    old_fail_on_missing_implementation = C.ACTION_PLUGIN_FAIL_ON_MISSING_IMPLEMENTATION
    C.ACTION_PLUGIN_FAIL_ON_MISSING_IMPLEMENTATION = False
    result = action_loader._create_action_plugin('test_action_module')
    assert isinstance(result, ActionModule)
    C.ACTION_PLUGIN_FAIL_ON_MISSING_IMPLEMENTATION = old_fail_on_missing_implementation

    # test with fail_on_missing_implementation
    old_fail_on_missing_implementation = C.ACTION_PLUGIN_FAIL_ON_MISSING_IMPLEMENTATION
    C.ACTION

# Generated at 2022-06-11 12:09:16.628103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()

# Generated at 2022-06-11 12:09:25.539562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as action
    import ansible.playbook.task as task
    import ansible.playbook.play_context as play_context
    from collections import namedtuple

    Connection = namedtuple('Connection', ('has_native_async',))
    MyTask = namedtuple('MyTask', ('async_val', 'action',))
    
    # Necessary for module_args to be valid parameter for execute_module()
    tmp = None
    task_vars = None
    # Necessary for result to be a valid parameter for execute_module()
    result = {'invocation': {'module_args': None}}
    
    # Create an action

# Generated at 2022-06-11 12:09:27.410438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of ActionModule class must return a ActionModule object.
    """
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 12:09:28.218082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:09:37.522083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initializing test variables
    module_name = 'linux_ls'
    module_args = 'ls -l'
    result = {'rc': 0, 'stdout': '', 'stderr': '', 'invocation': {'module_args': module_args}}
    action = ActionModule(module_name, module_args)

    result_copy = result.copy()
    tmp = None
    task_vars = None
    result = action.run(tmp, task_vars)

    assert result_copy == result
    assert action._task.module_name == module_name
    assert action._task.module_args == module_args
    assert action._task.action == module_name

# Generated at 2022-06-11 12:11:52.231087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:11:57.554140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    mock_connection = MagicMock()
    mock_task = MagicMock()
    mock_task.async_val = False
    mock_task.action = 'setup'
    action = ActionModule(mock_connection, mock_task)
    result = action.run()
    assert result == {'_ansible_no_log': False, '_ansible_verbose_override': True, 'failed': False}
    assert action._task.action == 'setup'
    assert action._task.async_val == False

# Generated at 2022-06-11 12:11:59.431039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.__doc__ == ActionBase.__doc__

# Generated at 2022-06-11 12:12:03.911156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    import ansible.constants as C
    action_module._task = {"async_val":None}
    action_module._connection = {"has_native_async":True}
    action_module._task.async_val = None
    action_module._connection.has_native_async = False
    action_module._supports_async = True
    assert action_module.run() == {}

# Generated at 2022-06-11 12:12:04.667848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-11 12:12:10.706453
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class MockConnection(object):
        def __init__(self):
            self.tmpdir = '/tmp'
            self.has_native_async = False
        def _shell_noop(self, tmp):
            pass

    class MockTask(object):
        def __init__(self):
            self.async_val = False
            self.action = 'copy'

    mock_connection = MockConnection()
    mock_task = MockTask()

    try:
        action_module = ActionModule(mock_connection, mock_task)
    except Exception as e:
        assert False, "Unexpected exception has been raised constructing ActionModule"

# Generated at 2022-06-11 12:12:11.817799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.supports_check_mode

# Generated at 2022-06-11 12:12:12.261959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:12:13.920858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('', '', '', dict())
    assert isinstance(module, ActionModule)
    assert isinstance(module, ActionBase)

# Generated at 2022-06-11 12:12:15.694695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Make some assertions on the constructor of the class ActionModule
    """ 
    a = ActionModule()
    assert a != None

