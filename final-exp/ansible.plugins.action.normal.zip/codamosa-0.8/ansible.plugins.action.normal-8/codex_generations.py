

# Generated at 2022-06-11 12:03:17.558746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    import ansible.plugins.action.generic
    a = ansible.plugins.action.generic.ActionModule({})
    a._task = {'async_val': None, 'action': 'command'}
    a._connection = {'has_native_async': False}
    class tmp():
        def __init__(self):
            self.stdout = "test1"
    a._low_level_execute_command = tmp()
    result = a.run(tmp=None, task_vars={})
    assert result['stdout'] == 'test1'

# Generated at 2022-06-11 12:03:28.272255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_conn = FakeConnection()
    module_list = [{'host':'127.0.0.1','name':'fail','port':22}]
    task_list = [{'action':'fail','name':'fail','args':module_list}]
    my_play = FakePlay('play_name',task_list)
    my_task = my_play.tasks()
    my_task.next()
    my_action = ActionModule(my_task,my_conn,'127.0.0.1')
    assert my_action.task == my_task
    assert my_action.connection == my_conn
    assert my_action.host == '127.0.0.1'
    assert my_action.module_name == 'fail'

# Generated at 2022-06-11 12:03:39.415008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import pytest
    from ansible.module_utils.six import PY3

    # Create the required object(s)
    test_obj = ActionModule()
    test_obj._supports_check_mode = True
    test_obj._supports_async = True

    # Set required attribute(s)
    test_obj._connection = os
    test_obj._loader = os
    test_obj._connection.has_native_async = False
    test_obj._task = os
    test_obj._task.async_val = True

    # Execute the run() method
    if PY3:
        exec("from ansible.plugins.action import ActionBase")
        result = test_obj.run()
        assert result == ActionBase.run(test_obj, None, None)


# Generated at 2022-06-11 12:03:48.105528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    task_vars = {
        "foo": "bar",
        "hello": "world",
        "myvar": {
            "key": "value",
        },
    }
    class action_base_mock:
        async_val = False
        _task = {
            "action": "foo",
        }
        _connection = {
            "_shell": {
                "tmpdir": "tmp1234",
            },
            "has_native_async": False,
        }
        def _execute_module(self, task_vars, wrap_async):
            results = {
                '_ansible_verbose_override': True,
            }
            return results
        def _remove_tmp_path(self, path):
            pass

# Generated at 2022-06-11 12:03:56.031589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_task = {
        'async': 1,
        'async_val': 1,
        'action': 'setup'
    }
    fake_loader = {
        'host_list': 'localhost',
        '_basedir': 'base_dir'
    }
    fake_connection = {
        'has_native_async': False
    }
    fake_ds = {
        'module_name': None,
        'module_complex_args': 'a b=c',
        'module_args': 'a b=c',
        'module_vars': 'system'
    }
    actionModule = ActionModule(fake_task, fake_connection, fake_loader, fake_ds)
    assert actionModule

# Generated at 2022-06-11 12:03:59.270641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp, task_vars):
            return super(TestActionModule, self).run(tmp, task_vars)

    assert TestActionModule()

# Generated at 2022-06-11 12:04:01.759213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode == True
    assert module._supports_async == True

# Generated at 2022-06-11 12:04:13.521830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_object = object()

    class TestActionModule(ActionModule):
        def _execute_module(self, *args, **kwargs):
            print(args)
            print(kwargs)
            return 'test_run'

    class TestActionModule2(ActionModule):
        def _execute_module(self, *args, **kwargs):
            print(args)
            print(kwargs)
            return 'test_run'

    class TestActionModule3(ActionModule):
        def _execute_module(self, *args, **kwargs):
            print(args)
            print(kwargs)
            return 'test_run'

    class TestActionModule4(ActionModule):
        def _execute_module(self, *args, **kwargs):
            print(args)
            print(kwargs)

# Generated at 2022-06-11 12:04:21.223450
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    fixture = ActionModule()
    module_args_task_vars = {'test_key': 'test_value'}

    result = fixture.run(tmp=None,
                         task_vars=module_args_task_vars)

    # TODO: test for the behavior of this object in the case of creating a
    #       temp file.
    # TODO: test the other behaviors of this object.
    #       Behavior of this object is very difficult to test.

    # Assert
    assert result['test_key'] == 'test_value'

# Generated at 2022-06-11 12:04:22.130948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:04:26.847536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Tests constructors of ActionModule class
    """
    m = ActionModule(None, None)
    assert m is not None

# Generated at 2022-06-11 12:04:27.917427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule([], dict())

# Generated at 2022-06-11 12:04:28.561340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:04:40.376442
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    m = ActionModule()
    m._supports_check_mode = True
    m._supports_async = True
    m._task.async_val = False
    m._connection.has_native_async = False
    m._task.action = C._ACTION_SETUP
    m._task.args = {}
    m._task.action = "setup"
    m.runner = MagicMock()
    m._remove_tmp_path = MagicMock()
    m._connection._shell.tmpdir = "TEMPDIR"
    result = {'invocation': {'module_args': {'key': 'value'}}}
    task_vars = {}
    m._execute_module = MagicMock()
    m._execute_module.return_value = {'key1': 'result1'}
    assert m

# Generated at 2022-06-11 12:04:43.743075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_test = ActionModule(None)
    assert action_module_test._supports_check_mode == True
    assert action_module_test._supports_async == True



# Generated at 2022-06-11 12:04:51.615487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    data_loader = DataLoader()
    inventory = InventoryManager(loader=data_loader, sources="localhost,")
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)

    play_source = dict(
        name = "Ad-Hoc",
        hosts = "localhost",
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='/usr/bin/ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

# Generated at 2022-06-11 12:04:53.961574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod._supports_check_mode is True
    assert mod._supports_async is True

# Generated at 2022-06-11 12:05:03.987000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a class of module with parameters
    dummy = {'action': 'test','port': 22, 'user': 'test_user'}
    input = [{'test_name':'test_1','test':dummy}]
    expected_result = [{'test_name':'test_1','test':{'action': 'test','port': 22, 'user': 'test_user'}}]

    # create an object of ActionModule
    action_module = ActionModule(input[0]['test'],input[0]['test']['action'],input[0]['test']['user'])

    # Test1: Test the ActionModule constructor
    assert action_module.action == input[0]['test']['action'] and action_module.task.action == input[0]['test']['action']

# Generated at 2022-06-11 12:05:04.721187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:05:06.080206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module

# Generated at 2022-06-11 12:05:13.244750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set vars for the test.
    # TODO: Implement me.
    pass


# Generated at 2022-06-11 12:05:14.240318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None)

# Generated at 2022-06-11 12:05:25.445061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of ActionModule class
    am = ActionModule()

    # Create an instance of AnsibleTask
    task = AnsibleTask()

    # Create an instance of AnsibleModule
    ams = AnsibleModule()

    # Create an instance of AnsibleConnection
    conn = AnsibleConnection()

    # Call _configure_module method
    am._configure_module(module_name = ams)

    # Call _execute_module method
    am._execute_module(module_name = ams)

    # Call _load_params method
    am._load_params(module_name = ams)

    # Call _compute_environment_string method
    am._compute_environment_string(module_name = ams)

    # Call _compute_module_args method

# Generated at 2022-06-11 12:05:26.473756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert (x != None)

# Generated at 2022-06-11 12:05:27.450414
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Pass
  assert True


# Generated at 2022-06-11 12:05:29.524486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule({})._supports_check_mode)
    assert(ActionModule({})._supports_async)

# Generated at 2022-06-11 12:05:40.343046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_task = dict()
    fake_task['async_val'] = False
    fake_task['delegate_to'] = None
    fake_task['delegate_facts'] = False
    fake_task['notify'] = []
    fake_task['register'] = None
    fake_task['until'] = None
    fake_task['retries'] = 3
    fake_task['delay'] = 3
    fake_task['first_available_file'] = None
    fake_task['action'] = 'fake'
    fake_task['when'] = []
    fake_task['become'] = False

    fake_play_context = dict()
    fake_play_context['become'] = None
    fake_play_context['remote_addr'] = None
    fake_play_context['remote_user'] = None
    fake

# Generated at 2022-06-11 12:05:50.185742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'setup'

# Generated at 2022-06-11 12:05:51.132311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import types
    assert type(ActionModule()) == ActionModule

# Generated at 2022-06-11 12:05:54.610959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(('localhost', 'test'), { "action": "test", "module_name": "test_module" })
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-11 12:06:06.238144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:06:09.805674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest

    class TestActionModule(unittest.TestCase):
        module = ActionModule()

        def setUp(self):
            pass

    return unittest.defaultTestLoader.loadTestsFromTestCase(TestActionModule)

# Generated at 2022-06-11 12:06:19.957804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'test'
    task_vars = dict(
        ansible_connection='local'
    )
    a = ActionModule(module_name, {}, task_vars, True)

    # Test members
    assert a._supports_check_mode is True
    assert a._supports_async is True
    assert a._task.action == module_name
    assert a._task.args == {}
    assert a._task.async_val is True
    assert a._task.async_seconds == 0
    assert a._task.async_poll_interval == 10
    assert a._task.name == module_name

# Generated at 2022-06-11 12:06:26.195432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook import module_common
    
    action_plugin_loader = module_common._action_plugin_loader
    
    a = ActionModule(None, {}, action_plugin_loader=action_plugin_loader)
    
    assert type(a._supports_check_mode) == bool
    assert type(a._supports_async) == bool
    assert type(a._shared_loader_obj) == bool
    
    
    

# Generated at 2022-06-11 12:06:27.408567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule({})
    assert isinstance(x, ActionModule)

# Generated at 2022-06-11 12:06:28.009112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:06:28.981023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Implement
    pass

# Generated at 2022-06-11 12:06:38.425637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import os
    import tempfile

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-11 12:06:40.161691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None, 'The class ActionModule was not initialized.'

# Generated at 2022-06-11 12:06:49.466059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    # instantiate
    loader = DataLoader()
    tqm = TaskQueueManager(loader=loader)
    host = Host("127.0.0.3", port=22)

# Generated at 2022-06-11 12:07:20.584543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

    # Set up mock objects
    loader = DataLoader()
    variable_mgr = VariableManager()
    inventory = InventoryManager(loader, variable_mgr)
    variable_mgr.set_inventory(inventory)

    # Parse extra vars
    extra_vars = load_extra_vars(loader=loader, options={}, args=[])
   

# Generated at 2022-06-11 12:07:21.132787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("fuck")

# Generated at 2022-06-11 12:07:26.276469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(action=dict(module_name='shell', module_args='ls -lrt')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert am._supports_async == True
    assert am._supports_check_mode == True

# Generated at 2022-06-11 12:07:30.028448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.__main__ import ActionModule
    # test without constructor arguments
    am = ActionModule()
    # test with constructor arguments
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:07:37.274735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    t = Task()
    t._role = None
    t.args = {}
    t._ds = {}
    t.action = 'setup'

    pc =  PlayContext()
    pc._connection = "local"
    pc._play_context = pc
    t._play_context = pc

    am = ActionModule(t, connection='smart', play_context=pc, loader=None, templar=None, shared_loader_obj=None)
    assert am._play_context == pc


# Generated at 2022-06-11 12:07:38.666648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	action_module = ActionModule()
	action_module.run()

# Generated at 2022-06-11 12:07:47.997342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=too-many-function-args
    """ Unit test for constructor of class ActionModule """
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 12:07:49.958977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #constructor with no parameter
    a = ActionModule()
    assert a.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-11 12:07:51.734216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for class instantiation with no input.
    test_obj = ActionModule()
    assert test_obj is not None

# Generated at 2022-06-11 12:08:00.416691
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # constructor for class ActionModule
    action_module = ActionModule()

    # instance variables definition
    action_module._supports_check_mode = True
    action_module._supports_async = True

    result = {}

    # invocation is an instance of class Invocation
    invocation = {}

    # module_args is an instance of class ArgumentSpec
    module_args = {}

    invocation['module_args'] = module_args

    result['invocation'] = invocation

    result['skipped'] = False

    task_vars = {}

    tmp = None

    # call method run with parameters tmp, task_vars
    result = action_module.run(tmp, task_vars)

    # check if method run has been called with parameters tmp, task_vars
    assert result == {}

# Generated at 2022-06-11 12:09:00.093105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(connection=None, runner=None, task=None,loader=None, play_context=None)
    assert module.__class__.__name__ == "ActionModule"

# Generated at 2022-06-11 12:09:09.239736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import merge_hash
    from ansible.plugins.action.normal import action_plugin
    from ansible.plugins.action import ActionBase
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultSecret
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import connection_loader, module_loader, filter_loader

# Generated at 2022-06-11 12:09:10.370130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__
    assert ActionModule.run.__doc__

# Generated at 2022-06-11 12:09:18.939036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader.action_loader import ActionModule as ActionModuleClass
    from ansible.plugins import action_loader
    import sys
    import os
    import unittest
    import shutil
    class TestActionModule(unittest.TestCase):
        ''' making sure that ActionModule is properly constructed
            ActionModule should not be inherited so this test makes sure that
            constructor is properly initialized in __init__.py
        '''
        def setUp(self):
            self.__action_plugins_path = 'test_action_plugins'
            self.__action_plugins = 'action_plugins'
            self.__valid_plugins = ['__init__.py', 'debug.py', 'copy.py']

# Generated at 2022-06-11 12:09:20.226196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-11 12:09:20.730951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:09:23.721582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # NOTE: can not test action modules with the unit tests, because
    #       action modules require the whole set of global variables,
    #       for now. This can be fixed so that the action modules are
    #       unit tested.

# Generated at 2022-06-11 12:09:26.675114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action=ActionModule()
    assert isinstance(action, ActionModule)
    assert not action._supports_check_mode
    assert not action._supports_async
    assert action.ACTION.startswith("<ansible.plugins.action._")

# Generated at 2022-06-11 12:09:27.524335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:09:34.473856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' action_plugin.ActionModule.__init__() '''

    # Create an instance of ActionPlugin
    x = ActionModule(
        task=dict(action=dict(module_name='ping', module_args=dict(data='pong'))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        variable_manager=dict(),
        templar=dict()
    )

    # Assert that the object was created successfully
    assert isinstance(x, ActionModule)

# Generated at 2022-06-11 12:11:48.589100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # implement your test here

# Generated at 2022-06-11 12:11:55.735977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.executor.task_queue_manager import TaskQueueManager

    host_list = ['a.a.com', 'b.b.com', 'c.c.com']

# Generated at 2022-06-11 12:12:03.377294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection import ConnectionBase
    from ansible.executor import module_common
    from ansible.executor.playbook_executor import PlaybookExecutor
    import json

    module_name = 'test_action_module'
    module_args = 'foo=bar'
    task_vars = dict()

# Generated at 2022-06-11 12:12:04.227526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert repr(ActionModule(None, None, None))

# Generated at 2022-06-11 12:12:09.598040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    from ansible.plugins import action as a
    assert isinstance(a.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None), ActionModule)
    assert repr(a.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None))

# Generated at 2022-06-11 12:12:17.385671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils import plugins
    from ansible.inventory.host import Host

    class FakeActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(FakeActionModule, self).run(tmp, task_vars)

    class FakeTask():
        def __init__(self, async_action=None, async_seconds=None):
            self.async_action = async_action
            self.async_seconds = async_seconds

    class FakeRunner():
        def __init__(self, task=None, connection=None, play=None, options=None, variable_manager=None, loader=None, shared_loader_obj=None):
            self._task = task
            self._connection = connection

    # fake task for action module
    task = FakeTask()

    #

# Generated at 2022-06-11 12:12:18.312694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")
    assert False

# Generated at 2022-06-11 12:12:20.619872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection='none', play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(a, ActionBase)

# Generated at 2022-06-11 12:12:21.134754
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-11 12:12:29.014131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.display import Display

    # create necessary objects for setup