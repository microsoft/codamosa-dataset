

# Generated at 2022-06-11 12:03:12.161835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-11 12:03:18.831036
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    m = ActionModule('setup', {'gather_subset': ['!all'], '_ansible_verbose_always': False})
    r = m.run({'invocation': {'module_args': ''}})

    assert isinstance(r, dict) is True
    assert r['changed'] is False
    assert r['failed'] is False
    assert r['invocation']['module_args'] == ''
    assert r['invocation']['module_name'] == 'setup'
    assert r['skipped'] is False
    assert r['warnings'] == ['The value "!all" is an invalid value for gather_subset, using "all" instead']

# Generated at 2022-06-11 12:03:19.335343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:03:20.205084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert "ActionModule" in str(ActionModule)

# Generated at 2022-06-11 12:03:23.108795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  am = ActionModule('test')
  ret = am.run(tmp='test', task_vars={'test':'test'})
  assert True in ret

# Generated at 2022-06-11 12:03:34.664123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    t = Task()
    h = Host(name="test_host")
    g = Group(name="test_group")
    g.add_host(h)
    t.set_loader(None)
    t.host = h

    am = ActionModule(t, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert isinstance(am._task, Task)
    assert isinstance(am._connection, Connection)
    assert isinstance(am._loader, DataLoader)

    try:
        am._remove_tmp_path("/tmp/test")
    except OSError:
        pass
    assert not os

# Generated at 2022-06-11 12:03:43.708860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.netcommon import ShellModule
    from ansible.module_utils.common.network import NetworkModule
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.vars import combine_vars

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources='localhost,')

# Generated at 2022-06-11 12:03:52.977481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    tasks = [
        Task(),
        Task(),
    ]

    tasks[0].action = 'setup'
    tasks[0].async_val = 4321
    tasks[0].loop = 'play_hosts'
    tasks[0].delegate_to = '127.0.0.2'

    tasks[1].action = 'debug'
    tasks[1].loop = 'play_hosts'
    tasks[1].delegate_to = '127.0.0.3'

    test_play

# Generated at 2022-06-11 12:03:59.713442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # module_name, task, connection, play_context, loader, templar, shared_loader_obj
    mock_connection = "MockConnection"
    mock_templar = "MockTemplar"
    mock_task = "MockTask"
    action_module = ActionModule(module_name=None, task=mock_task, connection=mock_connection,
                                 play_context=None, loader=None, templar=mock_templar, shared_loader_obj=None)

    assert action_module._task == mock_task
    assert action_module._templar == mock_templar
    assert action_module._loader == None
    assert action_module._connection == mock_connection
    assert action_module._play_context == None
    assert action_module._shared_loader_obj == None

# Generated at 2022-06-11 12:04:02.771894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), 'normal', 'localhost', 'localhost', 'setup', None, 'root', 'None', '123456789', None, None, 'name', 'path') != None

# Generated at 2022-06-11 12:04:17.287195
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    set_module_args = dict(path='/tmp',state='absent')
    host_vars = dict(ansible_connection='local')

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    variable_manager.options_vars = dict()
    variable_manager.set_inventory(['testhost'])
    variable_manager.set_host_variable('testhost', host_vars)

    loader = action_loader.get('file', variable_manager=variable_manager)

    # Call the constructor of ActionModule class

# Generated at 2022-06-11 12:04:26.124280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.plugins.action.normal import ActionModule as action_module
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.utils.vars import merge_hash
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase

    sys.path.append('unit/utils')
    from test_runner import TestCallbackModule as test_callback_module

    # Create an instance of CallbackModule

# Generated at 2022-06-11 12:04:35.916289
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Using a default action plugin so we can mock it and rely on defaults
    from ansible.plugins.action.defaults import ActionModule
    import unittest2 as unittest

    class TestActionModuleClass(unittest.TestCase):

        def setUp(self):

            self.module = ActionModule()

        def tearDown(self):

            pass

        def test_run(self):

            # assert what is expected
            self.assertEqual(True, True)

    # run the tests
    unittest.main()


if __name__ == '__main__':
    try:
        test_ActionModule_run()
    except:
        # add any debug prints here so that they appear in unit test output
        raise

# Generated at 2022-06-11 12:04:39.777957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''

    :return: ActionModule
    '''
    mod = ActionModule()
    assert mod != None

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 12:04:43.270200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(connection=None, task=None)
    assert isinstance(action._supports_check_mode, bool)
    assert isinstance(action._supports_async, bool)

# Generated at 2022-06-11 12:04:44.311854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:04:46.078569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Unit test for constructor of class ActionModule')
    action_module = ActionModule()


# Generated at 2022-06-11 12:04:46.652556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:04:48.756217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Without any config
    obj = ActionModule(None, None, None, None)
    assert obj._supports_check_mode == True
    assert obj._supports_async == True

# Generated at 2022-06-11 12:04:50.618945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._supports_check_mode is True
    assert am._supports_async is True

# Generated at 2022-06-11 12:04:59.086200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiation of ActionModule
    actm = ActionModule(None, None, None, None, None)
    assert actm._supports_check_mode is True
    assert actm._supports_async is True

# Generated at 2022-06-11 12:05:00.791223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
#tests.append((test_ActionModule_run, dict(
#)))



# Generated at 2022-06-11 12:05:09.197249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  print("")

  from ansible.plugins.action import ActionModule
  at = ActionModule()

  # Test without tmp and task_vars
  print("Test without tmp and task_vars")
  at.run()

  # Test with tmp
  print("Test with tmp")
  at.run(tmp="some_tmp")

  # Test with tmp and task_vars
  print("Test with tmp and task_vars")
  at.run(tmp="some_tmp", task_vars="some_task_vars")

if __name__ == "__main__":
  # execute only if run as a script
  test_ActionModule_run()

# Generated at 2022-06-11 12:05:12.061076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(name='test', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:05:23.072902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set some enviroment variables,
    # FIXME: do we need more?
    import os
    os.environ['ANSIBLE_INVENTORY'] = 'inventory'
    os.environ['ANSIBLE_LIBRARY'] = 'library'
    os.environ['ANSIBLE_MODULE_UTILS'] = 'module_utils'
    os.environ['ANSIBLE_ROLES_PATH'] = 'roles_path'
    os.environ['ANSIBLE_ACTION_PLUGINS'] = 'action_plugins'
    os.environ['ANSIBLE_CACHE_PLUGIN'] = 'cache_plugin'
    os.environ['ANSIBLE_CALLBACK_PLUGINS'] = 'callback_plugins'
    os.environ['ANSIBLE_CONFIG'] = 'config'
    os.en

# Generated at 2022-06-11 12:05:24.501797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    # ActionModule constructor does not have any thing to test; for now

# Generated at 2022-06-11 12:05:33.375964
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pytest

    # TODO: mock all calls to other methods and classes
    #       to verify they are called with correct parameters
    #       and return correct results.
    try:
        from ansible.plugins.action.normal import ActionModule
    except ImportError as e:
        pytest.fail("Unable to import module")

    host_vars = dict()
    host_vars['ansible'] = dict()
    host_vars['ansible_fqdn'] = "localhost"
    host_vars['ansible_hostname'] = "localhost"

    module = ActionModule(None, dict(), False)

    result = dict()
    result['invocation'] = dict()
    result['invocation']['module_args'] = dict()
    result['invocation']['module_name'] = "ping"

   

# Generated at 2022-06-11 12:05:34.032319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:05:35.044761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule

# Generated at 2022-06-11 12:05:37.801150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-11 12:05:49.491432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # No need to test for this class because it is a generic class
    pass

# Generated at 2022-06-11 12:05:59.850878
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of ActionModule, overriding some of its methods
    class ActionModuleMock(ActionModule):
        def __init__(self, *args, **kwargs):
            self._shell = None
            self._connection = None
            self._task = None

            self.env = None
            self.args = None
            self.async_val = None

        def _execute_module(self, *args, **kwargs):
            return {'foo': 'bar'}

    a = ActionModuleMock('', 'action/test')

    task_vars = {
        'foo': 'bar'
    }

    # Unit test for method run of class ActionModule
    result = a.run(tmp='./tmp/', task_vars=task_vars)

# Generated at 2022-06-11 12:06:04.256173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock task
    mock_task = MagicMock()
    mock_task.action = 'setup'

    # Create mock result
    mock_result = dict(skipped=True)

    # Create mock connection
    mock_connection = MagicMock()
    mock_connection.has_native_async = False

    # Create mock _execute_module
    mock__execute_module = MagicMock()
    mock__execute_module.return_value = '_ansible_verbose_override'

    # Create mock _remove_tmp_path
    mock__remove_tmp_path = MagicMock()

    # Create mock _task
    mock__task = MagicMock()
    mock__task.async_val = False

    # Create mock _connection
    mock__connection = MagicMock()
    mock__connection._shell = Magic

# Generated at 2022-06-11 12:06:05.257190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:06:08.247354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructor_test = ActionModule('playbook', 'play', 'test', 'task', 'test')
    assert constructor_test._task == 'test'
    assert constructor_test._connection == 'test'

# Generated at 2022-06-11 12:06:19.791818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor import task_result
    from ansible.vars import VariableManager
    from ansible.plugins.action import ActionBase
    import ansible.plugins.action.ping as a

    task = Task()
    var_manager = VariableManager()
    var_manager.set_inventory(a.Connection())
    task.action = a.ActionModule('ping', {}, True, {})
    task.async_val = 30
    task_result = task.action._execute_module(var_manager, 'ping', True)
    assert(task_result == {'ddd': False, 'invocation': {}, 'ping': 'pong'})
    return task_result

# Generated at 2022-06-11 12:06:20.338097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)

# Generated at 2022-06-11 12:06:20.871030
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    return

# Generated at 2022-06-11 12:06:21.994473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("testing ActionModule constructor")
    x = ActionModule()
    assert x is not None

# Generated at 2022-06-11 12:06:27.561697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.module_name = 'test'
    m._supports_async = True
    m._supports_check_mode = True
    m._supports_encrypt = True
    m._supports_no_log = True
    m._supports_subset = True
    m._task = 'test'
    tmp = m.run(tmp='test', task_vars={})
    assert tmp['invocation']['module_name'] == 'test'

# Generated at 2022-06-11 12:06:58.006763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-11 12:06:58.988742
# Unit test for constructor of class ActionModule
def test_ActionModule():
  print("Implement action_module tester")

# Generated at 2022-06-11 12:06:59.562647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:07:00.782810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert type(module) == ActionModule

# Generated at 2022-06-11 12:07:05.393445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run() of class ActionModule
    """

    #import pdb; pdb.set_trace()

    #exec "from ansible.plugins.action.normal import ActionModule"
    #exec "a = ActionModule()"

    # Put tests here
    #
    #a.run(tmp='foo', task_vars='bar')
    pass

# Generated at 2022-06-11 12:07:14.999756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing creation of ActionModule")
    module =  ActionModule()
    print(module.__dict__)
    assert module.__dict__['_supports_check_mode'] == True
    assert module.__dict__['_supports_async'] == True
    assert module.__dict__['_task'] == None
    assert module.__dict__['_connection'] == None
    assert module.__dict__['_play_context'] == None
    assert module.__dict__['_loader'] == None
    assert module.__dict__['_templar'] == None
    assert module.__dict__['_shared_loader_obj'] == None
    assert module.__dict__['_task_vars'] == None
    assert module.__dict__['_block'] == None
    assert module.__dict__['_play']

# Generated at 2022-06-11 12:07:21.046159
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import connection_loader

    action = ActionModule({})
    action._supports_check_mode = True
    action._supports_async = True
    action._connection = connection_loader.get('netconf', {}, PlayContext(), None)

    result = action.run(tmp=None, task_vars=None)
    assert "skipped" in result
    assert result['skipped'] == True

# Generated at 2022-06-11 12:07:22.086906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run()

# Generated at 2022-06-11 12:07:31.332110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(connection=None,
                          play_context=None,
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)
    assert module._supports_check_mode
    assert module._supports_async

    assert {} == module.run(tmp='/tmp/ansible-tmp-1413626578.19-92713674435493',
                            task_vars=dict(action='setup'))
    assert {} == module.run(tmp='/tmp/ansible-tmp-1413626578.19-92713674435493',
                            task_vars=dict(action='setup'))


# Generated at 2022-06-11 12:07:37.983886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {'invocation': {'module_name': 'fake'}}
    module = ActionModule()
    result_expected = merge_hash(result, module._execute_module())
    assert result == result_expected

    module = ActionModule()
    result = {'invocation': {'module_name': 'fake', 'module_args': True}}
    module = ActionModule()
    result_expected = merge_hash(result, module._execute_module())
    del result_expected['invocation']['module_args']
    assert result == result_expected

# Generated at 2022-06-11 12:08:39.534792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    
    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0,os.path.dirname(test_dir))
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.action import ActionBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase


# Generated at 2022-06-11 12:08:41.739387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME:
    # Need to fix this test.  It is a temporary place holder until
    # I can get to it.
    #
    # ~ ptomulik@redhat.com
    assert True

# Generated at 2022-06-11 12:08:42.226882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:08:50.942958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTask:
        def __init__(self, action, verbosity):
            self.action = action
            self.verbosity = verbosity
            self.async_val = False
            self.no_log = False

    class FakePlayContext:
        def __init__(self):
            self.verbosity = 0
            self.no_log = False

    class FakeLoader:
        def get_basedir(self, play=None):
            return ""

    class FakeVariableManager:
        def get_vars(self, play=None, include_hostvars=True):
            return {'hostvars': {}}

        def get_vars_for_host(self, host):
            return {'hostvars': {}}

        def all_vars(self, loader=None, play=None):
            return

# Generated at 2022-06-11 12:08:59.591022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    path = __file__
    print(path)
    test_conn = types.SimpleNamespace()
    test_conn.has_native_async = False
    test_task = types.SimpleNamespace()
    test_task.async_val = False
    test_task.action = 'setup'
    test_task.tags = ["test"]
    test_task.args = dict()
    test_task._role = types.SimpleNamespace()
    test_task._role.name = "test_role"
    test_task._role.tags = ["test_role_tag"]
    test_task._role._role_path = os.path.dirname(path)
    test_task._role.tags = ["test_role_tag2"]

# Generated at 2022-06-11 12:09:08.734675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    result = dict(a=1)

    class FakeTask(object):
        def __init__(self):
            self.action = C._ACTION_SETUP
            self.async_val = 1
            #self._connection = None

    class FakeConnection(object):
        def __init__(self):
            self.has_native_async = False
            self._shell = dict(tmpdir="./tmp")

    class FakeExec(object):
        def __init__(self):
            self.call_count = 0
            self.result = dict(b=2)

        def __call__(self, task_vars=None, wrap_async=None):
            self.call_count += 1
            return self.result

    fake_task = FakeTask()

# Generated at 2022-06-11 12:09:09.242315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:09:17.600266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Mock_module ():
        def __init__(self):
            self._supports_check_mode = True
            self._supports_async = True

    class Mock_ActionBase ():
        def __init__(self):
            self._task = Mock_task()
            self._connection = Mock_connection()

        def run(self, tmp=None, task_vars=None):
            return dict(skipped=False)

        def _execute_module(self, task_vars=None, wrap_async=None):
            return dict(test_action_module="test_action_module")

        def _remove_tmp_path(self, tmpdir):
            pass

    class Mock_task ():
        async_val = True
        action = "setup"


# Generated at 2022-06-11 12:09:18.562401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:09:19.586477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-11 12:11:29.303121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError


# Generated at 2022-06-11 12:11:30.113821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-11 12:11:30.866249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 12:11:32.117624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing Action Module:")
    test_action_module = ActionModule()
    assert test_action_module

# Generated at 2022-06-11 12:11:32.592663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:11:34.215040
# Unit test for constructor of class ActionModule
def test_ActionModule():

    m = ActionModule()
    assert m.action_set_options is not None
    assert m.action_set_facts is not None

# Generated at 2022-06-11 12:11:41.385755
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Define unittest mocks
    class MockAnsibleModule():

        def __init__(self):
            self.params = {'module_name': 'test'}
            self.module_args = ''
            self.id = 'test'
            self.no_log = False
            self.modulul_name = 'test'
            self.error = False
            self.failjson = False
            self.success = False
            self.result = {'changed': False, 'invocation': {'module_args': ''}}

        def fail_json(self, msg):
            self.failjson = msg

        def exit_json(self, **kwargs):
            self.success = True
            self.result = kwargs

        def __getitem__(self, item):
            return ''


# Generated at 2022-06-11 12:11:48.218477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockConnection:
        def __init__(self):
            self.has_native_async = False

        def _shell_plugin_class(self):
            return 'text'

        def _shell_plugin_class(self):
            return 'text'

    class MockTask:
        def __init__(self):
            self.action = 'setup'
            self.async_val = None

    m_task = MockTask()
    m_connection = MockConnection()
    my_action_module = ActionModule(m_task, m_connection, '/path/to/playbook', '/path/to/playbook/module_utils')
    assert my_action_module._supports_check_mode is True
    assert my_action_module._supports_async is True

# Generated at 2022-06-11 12:11:55.314292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.connection_helper import ConnectionHelper
    from ansible.playbook.play import Play

    class MyActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            print("Executing action MyActionModule")
            return super(MyActionModule, self).run(tmp, task_vars)

        def _execute_module(self):
            print("Execute module " + self._task.action)
           

# Generated at 2022-06-11 12:11:55.768678
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert True == True