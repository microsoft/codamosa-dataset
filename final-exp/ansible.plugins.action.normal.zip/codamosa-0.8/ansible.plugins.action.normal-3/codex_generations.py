

# Generated at 2022-06-11 12:03:12.127882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.argument_spec == dict()
    assert am.supports_check_mode == True
    assert am.supports_async == True
    assert am._supports_async == True
    assert am._supports_check_mode == True

# Generated at 2022-06-11 12:03:13.663373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-11 12:03:16.910231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #ansible.utils.plugin_docs.standalone_docs('./lib/ansible/plugins/action/')
    module = ActionModule(connection=None, task=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-11 12:03:17.700274
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.constants

# Generated at 2022-06-11 12:03:28.493462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    task_vars = {}
    am = ActionModule(loader=loader, task=task, connection=connection, play_context=play_context, templar=templar, shared_loader_obj=shared_loader_obj)
    assert am
    assert am.loader == loader
    assert am.task == task
    assert am.connection == connection
    assert am.play_context == play_context
    assert am.templar == templar
    assert am.shared_loader_obj == shared_loader_obj
    assert am.connection_loader is None
    assert am.task_vars is not None
    assert am._templar == templar

# Unit test

# Generated at 2022-06-11 12:03:39.588582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    #Initialize all the needed parameters
    loader = DataLoader()
    inventory = InventoryManager(loader=loader,
                                 sources=["localhost"])
    variable_manager = VariableManager(loader=loader,
                                       inventory=inventory)
    play_context = PlayContext()
    play_source = {}

# Generated at 2022-06-11 12:03:46.181312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    c = {}
    c['__ansible_action_uuid'] = '28c7271c-9ad6-11e6-b8e8-64006a8064cc'
    setattr(c, '_executor', {})
    c['playbook_uuid'] = '81c1f1d2-9ad6-11e6-bd35-64006a8064cc'
    c['task_uuid'] = 'c791a5fc-9ad6-11e6-9e3f-64006a8064cc'
    c['task_uuid_retry'] = 'c791a5fc-9ad6-11e6-9e3f-64006a8064cc'
    c['task_name'] = 'bootstrap'

# Generated at 2022-06-11 12:03:48.606980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    ActionModule_instance = ansible.plugins.action.ActionModule()
    ActionModule_instance.run()

# Generated at 2022-06-11 12:03:49.884140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    assert isinstance(ActionModule, type)

# Generated at 2022-06-11 12:03:53.019269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None
    assert module._supports_async == True
    assert module._supports_check_mode == True
    assert module._task.async_val == None
    assert module._connection.has_native_async == False

# Generated at 2022-06-11 12:04:07.154183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule()
    tmp = 'tmp'
    async_val = 1
    has_native_async = False
    action = 'action'
    task_vars = {'a': 1}
    if async_val and not has_native_async:
        wrap_async = 1

    # test for variable tmp, should be None, so skipped
    action_module = ActionModule()
    class_result = action_module.run(tmp, task_vars)
    assert class_result == {'skipped': True}

    # test for variable wrap_async, should be True, so no _remove_tmp_path
    action_module = ActionModule()
    class_result = action_module.run(task_vars=task_vars, wrap_async=wrap_async)
    assert class_

# Generated at 2022-06-11 12:04:18.685373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        pass

    # note: here we have all task_vars but very few connection options and are trying to init
    # the action plugin. This is not meant to work, and is only here to test whether the action
    # plugin __init__ method is able to handle this situation, as is sometimes the case
    # in ansible-playbook, when no host is being targeted but we still want to run things like --list-hosts

    class TestConnection:
        def __init__(self):
            self.become = False

    test_connection = TestConnection()

    result = TestActionModule(
        task=dict(action='test'),
        connection=test_connection,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-11 12:04:21.823281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(a, ActionBase)

# Generated at 2022-06-11 12:04:31.413413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.plugins.strategy import ActionModule

    # TODO:
    # Use Python mock to replace objects below.
    # See https://github.com/ansible/ansible/pull/59064

# Generated at 2022-06-11 12:04:32.392339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action1 = ActionModule()

# Generated at 2022-06-11 12:04:33.074234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-11 12:04:40.512193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('name', 'connection', 'play_context')
    assert am._task.name == 'name'
    assert am._connection is 'connection'
    assert am._play_context is 'play_context'
    assert am._task.action is am.name
    assert am._ansible_version is None
    assert am._supports_check_mode is False
    assert am._supports_async is False


# Generated at 2022-06-11 12:04:41.298536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:04:42.837482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No test for method run"


# Generated at 2022-06-11 12:04:43.945520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-11 12:04:59.315621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module_name = 'testAction'
  module_path = '/home/muharrem/ansible/lib/ansible/modules/system/' + module_name + '.py'
  tmp_path = '/tmp'
  tmp_name = 'tmp_name'
  module_args = {'tmp_path':tmp_path, 'tmp_name':tmp_name}
  loop = True
  become_user = 'root'
  become = True
  become_method = 'sudo'
  become_exe = 'sudo'
  no_log = False
  check_mode = False

  class Task:
    _play = {}
    _play_context = {}
    async_val = False
    action = 'setup'

    def action_set(self, value):
      self.action = value


# Generated at 2022-06-11 12:05:02.294676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode == True
    assert module._supports_async == True

    module.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:05:06.351370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = DummyConnection()
    module_loader = DummyModuleLoader()
    play_context = DummyPlayContext()
    loader = DummyLoader()
    am = ActionModule(connection, module_loader, play_context, loader)
    # TODO add more tests, if possible


# Generated at 2022-06-11 12:05:17.117742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task = "task"
    module._connection = "connection"
    module._play_context = "play_context"
    module._task_vars = "task_vars"
    module._templar = "templar"
    module._loader = "loader"
    module._shared_loader_obj = "shared_loader_obj"
    module._connection_loader = "connection_loader"
    module._found_in_cache = "found_in_cache"
    module._task.action = "action"
    module._task.args = "task.args"
    module._task.async_val = "task.async_val"
    module._task.async_seconds = "task.async_seconds"
    module._task.notify = "task.notify"


# Generated at 2022-06-11 12:05:19.541190
# Unit test for constructor of class ActionModule
def test_ActionModule():
   '''
   Unit test for constructor of class ActionModule
   '''
   action_module = ActionModule()
   assert type(action_module) == ActionModule

# Generated at 2022-06-11 12:05:30.319145
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import sys
    import unittest

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.connection.local import Connection

    from ansible.executor.task_result import TaskResult

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager


    class TestActionModuleConstructor(unittest.TestCase):

        def setUp(self):

            self.loader = DataLoader()
            self.variable_manager = VariableManager

# Generated at 2022-06-11 12:05:34.524717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert hasattr(action, '_supports_async')
    assert action._supports_async, "Supports Async should be True"
    assert hasattr(action, '_supports_check_mode')
    assert action._supports_check_mode, "Check Mode should be True"

# Generated at 2022-06-11 12:05:35.579974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-11 12:05:36.164147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)

# Generated at 2022-06-11 12:05:46.621030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule class
    a = ActionModule(None, None, None)
    assert a.name == 'action'
    assert a.action_type == 'normal'
    assert a.async_val == False
    assert a.async_seconds == 30
    assert a.transport == 'smart'
    assert a.notify == []
    assert a.poll == 10
    assert a.sudo == False
    assert a.sudo_user == None
    assert a.sudo_pass == None
    assert a.sudo_exe == None
    assert a.sudo_flags == None
    assert a.sudo_arg == None
    assert a.su == False
    assert a.su_user == None
    assert a.su_pass == None
    assert a.su_exe == None
    assert a.su_flags == None

# Generated at 2022-06-11 12:06:05.127309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    #from ansible.playbook.block import Block
    #from ansible.playbook.role import Role
    #from ansible.playbook.play_context import PlayContext
    #from ansible.inventory.manager import InventoryManager
    #from ansible.vars.manager import VariableManager
    #from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 12:06:11.435299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_base = ActionBase()
    task_vars={} # TODO: use correct object of type dict
    action_module = ActionModule(task=action_base, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=task_vars)
    assert(type(result)==dict)

# Generated at 2022-06-11 12:06:14.466130
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:06:15.417712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

if __name__ == '__main__':
    # Test Module
    test_ActionModule()
    # Unit test for constructor of class ActionModule
    print('Test Success!')

# Generated at 2022-06-11 12:06:16.627203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod is not None

# Generated at 2022-06-11 12:06:24.862605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile
    import shutil
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    class TestHost(object):
        def __init__(self, hostname):
            self.name = hostname
           

# Generated at 2022-06-11 12:06:34.295434
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:06:43.813066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    check if the method return valid json
    '''
    import ansible.runners.action_plugins.setup as setup
    import ansible.plugins.action as action
    import ansible.Playbook.deprecated_DEFAULT_HOST_LIST as deprecated
    deprecated.DEFAULT_HOST_LIST = ['1.2.3.4']
    import ansible.inventory as inventory
    import ansible.vars.manager as manager
    import ansible.vars.hostvars as hostvars
    import ansible.errors as errors
    import ansible.utils.vars as vars
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-11 12:06:44.708338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-11 12:06:45.929769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-11 12:07:08.198678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:07:08.749918
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert ActionModule()

# Generated at 2022-06-11 12:07:18.059286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    class MockTaskQueueManager(TaskQueueManager):
        def  __init__(self, *args, **kwargs):
            super(MockTaskQueueManager, self).__init__(*args, **kwargs)

        def _queue_task(self, host, task, task_vars, play_context):
            print({'host': host, 'task': task, 'task_vars': task_vars, 'play_context': play_context})


# Generated at 2022-06-11 12:07:21.344803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:07:29.944108
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import unittest

    task_vars = dict(AA='AA', BB='BB', CC='CC')

    class ActionPlugin(ActionModule):

        def run(self, tmp=None, task_vars=None):
            return task_vars

    class TestActionModule(unittest.TestCase):
        def test_ActionModule(self):
            result = ActionPlugin().run(None, task_vars)
            assert (result['AA'] == 'AA')
            assert (result['BB'] == 'BB')
            assert (result['CC'] == 'CC')
            return

    TestActionModule().test_ActionModule()

if __name__ == '__main__':
    import sys
    sys.exit(test_ActionModule())

# Generated at 2022-06-11 12:07:31.565434
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    the_module = None

    the_module = ActionModule(the_module)

    assert the_module is not None

# Generated at 2022-06-11 12:07:32.855801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)


# Generated at 2022-06-11 12:07:33.417438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:07:34.964421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule())

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 12:07:44.911246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import module_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor


# Generated at 2022-06-11 12:08:40.523863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    tmp = task_vars = None
    result = module.run(tmp = tmp, task_vars = task_vars)
    assert result == {}

# Generated at 2022-06-11 12:08:44.804743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new instance of ActionModule
    act = ActionModule()

    # Check the _supports_check_mode is True
    assert act._supports_check_mode == True
    # Check the _supports_async is True
    assert act._supports_async == True

    print("Test action.py constructor - Successful")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:08:53.464040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
        not really a unit test but tests some methods
    """
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    from collections import namedtuple
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])

# Generated at 2022-06-11 12:09:02.536774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test_ActionModule: constructor of class ActionModule.
    """

    # Test with ansible 2.3.2.0
    config = dict(
        _ansible_no_log=False,
        _ansible_verbosity=4,
        ansible_loop_var='item',
        ansible_ssh_host='127.0.0.1',
        ansible_ssh_pass='pass',
        ansible_ssh_port=22,
        ansible_ssh_user='user',
    )


# Generated at 2022-06-11 12:09:03.655814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("")
    test_module = ActionModule()
    assert test_module is not None

# Generated at 2022-06-11 12:09:04.608584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None) is not None

# Generated at 2022-06-11 12:09:05.543523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-11 12:09:14.294745
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    result_data = {
        "msg": "action",
        "changed": "changed",
    }

    result = {
        "changed": "changed",
        "invocation": "invocation",
        "results": "results",
        "ansible_facts": "ansible_facts",
        "module_name": "name",
        "module_args": "args",
        "_ansible_no_log": False,
    }


# Generated at 2022-06-11 12:09:22.903845
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTQM:
        class FakeTask:
            async_val = None
            action = None

        class FakePlay:
            async_val = None

        class FakeLoader:
            pass

        class FakeData:
            pass

        class FakeConnection:
            class FakeShell:
                def __init__(self, tmpdir):
                    self.tmpdir = tmpdir

            has_native_async = True

            def __init__(self, tmpdir):
                self._shell = self.FakeShell(tmpdir)

        def __init__(self):
            self.task = self.FakeTask()
            self.play = self.FakePlay()
            self.loader = self.FakeLoader()
            self.shared_loader_obj = self.FakeLoader()
            self.variable_manager = self.FakeData()

# Generated at 2022-06-11 12:09:23.801669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 12:11:31.795612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleTestClass(ActionModule):
        pass

    action_mod = ActionModuleTestClass(None,None)
    assert action_mod is not None

test_ActionModule()

# Generated at 2022-06-11 12:11:32.282308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:11:33.801025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:11:40.968536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ _execute_module should catch a python excpetion"""

    import ansible.playbook
    import ansible.playbook.task
    import ansible.runner.return_data
    from units.mock.procenv import swap_stdin_and_argv
    from ansible.plugins.loader import action_loader

    (stdin, argv) = swap_stdin_and_argv(['foo', 'bar'])

    action = action_loader.get('ping', runner=ansible.runner.Runner())
    setup_info = ansible.playbook.SETUP_INFO
    setup_info['gather_subset'] = ['all']
    return_data = ansible.runner.return_data.ReturnData()
    return_data._host = "127.0.0.1"
    task = ansible.play

# Generated at 2022-06-11 12:11:42.760930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict()) is None

# Generated at 2022-06-11 12:11:46.043732
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    task = Task()
    play = Play()
    host = "127.0.0.1"

    assert ActionModule(task, play, host)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:11:47.596080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:11:48.036460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:11:54.861989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test ActionModule.run for a sample output."""
    fake_results = {'called_module': 'fake_module_name'}
    fake_ansible = {'playbook_dir': '/fake-playbook-path'}
    FakeActionModule = ActionModule(play_context=None, connection=None, loader=None, templar=None, shared_loader_obj=None)
    FakeActionModule._shared_loader_obj = fake_ansible
    fake_task_vars = {}
    FakeActionModule.run(tmp=None, task_vars=fake_task_vars)
    assert fake_task_vars['ansible_playbook_python'] == '/fake-playbook-path'
    assert fake_results['called_module'] == 'fake_module_name'

# Generated at 2022-06-11 12:12:02.532115
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #
    # setup various test data
    #
    tmp = '/tmp/dqf9a7/'
    task_vars = dict(
        ansible_connection='local',
        ansible_forks=5,
        ansible_inventory='bogus.py',
        ansible_ssh_user='dude',
    )
    async_val = False
    has_native_async = False
    action = 'setup'

    #
    # create a instance and invoke run method
    #
    instance = ActionModule(task=dict(async_val=async_val, action=action))
    instance._task = dict(async_val=async_val, action=action)
    instance._connection = dict(has_native_async=has_native_async)