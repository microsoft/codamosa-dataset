

# Generated at 2022-06-11 12:03:14.202651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader

    task_vars = dict()
    play_context = PlayContext()
    action_module = ActionModule(task=dict(), play_context=play_context, connection=None, loader=module_loader)

    result = action_module.run(task_vars=task_vars)
    assert isinstance(result, dict)
    assert result.get('invocation') is not None
    assert result.get('invocation').get('module_name') == 'action_module'
    assert result.get('invocation').get('module_args') is None

# Generated at 2022-06-11 12:03:23.377424
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test with setup module
    module = ActionModule()
    module._task.action = 'setup'
    module._task.async_val = False
    module._connection = Connection()
    module._connection._shell.tmpdir = '/tmp/testdir'
    module._remove_tmp_path = MagicMock()
    module._execute_module = MagicMock()

    _result = {
        'invocation': {
            'module_args': 'module_args'
        }
    }

    module._execute_module.return_value = 'execute_module'

    result = module.run('/tmp', 'task_vars')

    module._remove_tmp_path.assert_called_once_with('/tmp/testdir')

# Generated at 2022-06-11 12:03:24.003125
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert True

# Generated at 2022-06-11 12:03:25.511220
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert ActionModule(None, None, None, None, None, None) != None

# Generated at 2022-06-11 12:03:27.256799
# Unit test for constructor of class ActionModule
def test_ActionModule():
        my_class = ActionModule()
        assert my_class != None

# Generated at 2022-06-11 12:03:28.745606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()

# Unit test association with ActionBase class

# Generated at 2022-06-11 12:03:29.425623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-11 12:03:40.319113
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.errors import AnsibleActionFail
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar

    loader = DataLoader()

    # Arrange

    # Create the task to be executed.

# Generated at 2022-06-11 12:03:42.031509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('action','host','task','args','variables','remote','connection','play','loader','templar','shared_loader_obj')

# Generated at 2022-06-11 12:03:43.053881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('ActionModule')
    pass

# Generated at 2022-06-11 12:03:47.731920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    assert a.run() is not None

# Generated at 2022-06-11 12:03:56.301803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import module_loader

    class MyTask(object):
        def __init__(self):
            self.async_val = 0
            self.action = 'setup'
            self.args = dict()
            self.action_plugin = dict()
            self.action_plugin['name'] = 'setup'


# Generated at 2022-06-11 12:03:57.790519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(0, None, None, None, None, None)

# Generated at 2022-06-11 12:03:59.377648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() == None

# Generated at 2022-06-11 12:04:06.017927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('action', 'args', 'module')
    assert action._task is 'action'
    assert action._connection is 'args'
    assert action._loader is 'module'
    assert action._play_context is 'args'
    assert action._ds is None
    assert action._templar is None
    assert action._shared_loader_obj is None
    assert action._task_vars is None
    assert action._task_ds is None

# Generated at 2022-06-11 12:04:07.581433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)

# Generated at 2022-06-11 12:04:12.861821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    at = ActionModule(None, None, task_vars={})
    assert at.tmpdir is not None
    assert at.module_name is not None
    assert at.task is None
    assert at.task_vars is not None
    assert at.connection is None
    assert at.play_context is None
    assert at.loader is not None

# Generated at 2022-06-11 12:04:18.101945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test ActionModule constructor"""

    task = {'action': 'test_print_string'}
    # Create module object
    mod = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test run method
    assert 'msg' in mod.run()

# Generated at 2022-06-11 12:04:18.738102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:04:24.465612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# Create an instance of the class to be tested
	am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
	
	# Test for run success
	assert(am.run() == {'skipped' : True})
	
	# Test for failure due to invalid module
	assert(am.run(tmp=None, task_vars=None) == {'skipped' : True})

# Generated at 2022-06-11 12:04:41.592861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    test_action_module = ActionModule(
        task=Task(),
        connection='ssh',
        play_context=PlayContext(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert test_action_module is not None

## from ansible.playbook.play_context import PlayContext
## from ansible.playbook.block import Block
## test_action_module = ActionModule(
##     task=Task(),
##     connection='ssh',
##     play_context=None,
##     loader=None,
##     templar=None,
##     shared_loader_obj=None
## )

# Generated at 2022-06-11 12:04:46.164189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # creating an object of class ActionModule
    test_obj = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    # calling method run without any parameters
    test_obj.run()

# call test method
test_ActionModule_run()

# Generated at 2022-06-11 12:04:49.189876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = __import__('ansible.plugins.action', fromlist=['object'])
    action_module = getattr(mod, 'ActionModule')
    assert issubclass(action_module, ActionModule)
    assert action_module.__name__ == 'ActionModule'

# Generated at 2022-06-11 12:04:52.536894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule.__doc__)
    print(ActionModule.run.__doc__)
    print(ActionModule.get_checksum.__doc__)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:04:53.958830
# Unit test for constructor of class ActionModule
def test_ActionModule():
  module = ActionModule.from_task(task=dict(action='action'))

# Generated at 2022-06-11 12:04:54.551505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:04:55.194162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:04:59.848575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'test'
    action_plugin = ActionModule(None, None, 'test', 'test')

    # Take a look if test is a valid module name
    assert module_name in C.MODULE_REQUIRE
    assert action_plugin._supports_async == True
    assert action_plugin._supports_check_mode == True

# Generated at 2022-06-11 12:05:10.206353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Ansible internal objects
    variable_manager = VariableManager()
    loader = DataLoader()

    context._init_global_context(loader=loader)

    # Ansible internal objects
    variable_manager = VariableManager()
    loader = DataLoader()
    host = Host(name="127.0.0.1")
    group = Group()
    task = Task(action=dict(module="foo"))

    # ActionModule object

# Generated at 2022-06-11 12:05:10.877443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-11 12:05:23.522288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_action = ActionModule()
    assert my_action is not None


# Generated at 2022-06-11 12:05:26.372750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    remote_user = "local"
    a = ActionModule(loader=None, connection=None, play_context=None)
    assert isinstance(a, ActionBase)


# Generated at 2022-06-11 12:05:33.375488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.template import ActionModule

#Sample test case

# Generated at 2022-06-11 12:05:44.180269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up
    import ansible.plugins
    from ansible.plugins.action.test import ActionModuleTest
    import ansible.plugins.action.normal
    import ansible.plugins.action.special
    import ansible.plugins.action.__init__
    ansible.plugins.action.normal.ActionModule(None, {})
    ansible.plugins.action.special.ActionModule(None, {})
    ansible.plugins.action.__init__.ActionModule(None, {})
    import ansible.playbook.task_include
    m_task_vars = {}
    m_tmp = None
    module = ActionModuleTest()
    module.set_args("action_module")
    module.set_connection("")
    module.set_task("")
    module.set_loader("")
    module.set_

# Generated at 2022-06-11 12:05:45.857842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 12:05:55.955044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n--------begin-----------\n")
    #args = ['/etc/ansible/ansible.cfg']
    #config = ConfigLoader().load_from_file(os.path.expanduser(args[0]))
    #print("config:%s" % config)
    #argv = ['/usr/local/bin/ansible', '-m', 'copy', '-a', 'src=/etc/ansible/ansible.cfg dest=/tmp/ansible.cfg']
    #parser = PlaybookCLIRunner(args, argv).parse()
    #print("parser:%s" % parser)
    #playbook = Playbook().load(playbook_path='/usr/local/etc/ansible/playbooks/test.yml', variable_manager=VariableManager())
    #task = playbook[0].

# Generated at 2022-06-11 12:05:56.637001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:05:57.589684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Implement your unit tests here
    pass

# Generated at 2022-06-11 12:06:05.415856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.errors import AnsibleParserError

    # Run a playbook
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 12:06:05.999017
# Unit test for method run of class ActionModule
def test_ActionModule_run():  
    assert 1 == 1

# Generated at 2022-06-11 12:06:36.838606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule
    """
    import os
    import inspect
    import unittest
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)
    from lib.action import ActionBase
    from ansible.plugins.action import ActionModule
    from ansible.utils.color import stringc
    from ansible.utils.vars import merge_hash
    from ansible.parsing.yaml import objects
    from ansible.module_utils._text import to_text
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.common.text.converters import to_

# Generated at 2022-06-11 12:06:39.200636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None)
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True

# Generated at 2022-06-11 12:06:42.145530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule("Not_None.py", "setup", "host", "path", "async_val")
    assert action_module._task.action == "setup", "Task action is not setup"

# Generated at 2022-06-11 12:06:51.278417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Unit test for method run of class ActionModule")
    Task = action.Task
    ActionModule = action_plugins.ActionModule
    
    Task.async_val = False
    Task.async_seconds = 30
    Task.async_poll_interval = 5

    module_name = 'setup'
    module_args = ""
    module_args_hash = ""
    action_name = module_name
    _task = Task('action_module_setup', action=action_name, async_val=Task.async_val, async_seconds=Task.async_seconds, async_poll_interval=Task.async_poll_interval, args=module_args_hash)
    
    connection = connections.local.LocalConnection()
    module_vars = {}
    _task_vars = {}
    play

# Generated at 2022-06-11 12:06:52.920296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.connection
    assert am._task.action
    assert am._task.args

# Generated at 2022-06-11 12:07:02.055002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a dictionary which represents a task as loaded from a yaml file
    test_task = dict()
    test_task["action"] = dict()
    test_task["name"] = "Test name"
    test_task["async"] = 1
    test_task["async_val"] = 10
    test_task["iteritems"] = dict()
    test_task["register"] = "test_register"
    test_task["ignore_errors"] = False
    test_task["notify"] = list()
    test_task["tags"] = list()
    test_task["until"] = list()

    # Create a dictionary which represents the modified main dictionary
    test_task_vars = dict()
    test_task_vars["test_var"] = "test_value"

    # Create a ActionModule object
    test_action

# Generated at 2022-06-11 12:07:04.429480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:07:06.453580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._supports_check_mode is True
    assert am._supports_async is True

# Generated at 2022-06-11 12:07:07.051401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:07:07.697604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("hello")

# Generated at 2022-06-11 12:08:00.612135
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader

    host = Host(name='use1')
    task = Task()
    task.action = 'shell'
    task.async_val = 0
    task.async_seconds = 10
    task_vars = dict()
    variable_manager = VariableManager()
    dataloader = DataLoader()
    action = action_loader.get('shell', task, host, task_vars, variable_manager=variable_manager, loader=dataloader)

    assert action._supports_check_mode is True

# Generated at 2022-06-11 12:08:02.457852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for param_name in ('skipped', 'invocation', 'module_args'):
        assert hasattr(ActionModule, param_name)

# Generated at 2022-06-11 12:08:12.157624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Fixtures
    class ActionModuletest:
        @staticmethod
        def run(tmp=None, task_vars=None):
            return 1, 2

        @staticmethod
        def _supports_check_mode():
            return True

        @staticmethod
        def _supports_async():
            return True

        @staticmethod
        def _execute_module(task_vars=None, wrap_async=True):
            pass

        @staticmethod
        def _remove_tmp_path(task_vars=None):
            pass

        @staticmethod
        def _task():
            return True

        @staticmethod
        def _connection():
            return True

        @staticmethod
        def _task():
            return True

        @staticmethod
        def _task():
            return True


# Generated at 2022-06-11 12:08:13.101369
# Unit test for constructor of class ActionModule
def test_ActionModule():
    u = ActionModule()
    assert u is not None

# Generated at 2022-06-11 12:08:14.263690
# Unit test for constructor of class ActionModule
def test_ActionModule():

    am = ActionModule(None, None, None)
    assert am


# Generated at 2022-06-11 12:08:15.050852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None), ActionModule)

# Generated at 2022-06-11 12:08:25.210045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Imports
    from ansible.plugins import module_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    import json
    import os
    import copy

    # We create some variables to be used
    module_name = "north.py"
    module_path = "./test/units/modules/test/action_plugins/"
    module_args = "a=1 b=2"
    tmp = '/tmp/tmp.XXXXXXXXXX'

# Generated at 2022-06-11 12:08:33.505062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set 'ActionModule.run' class level attribute
    ActionModule.run = 'test class'
    # Create a class object
    a_obj = ActionModule()
    # Access 'ActionModule.run' class level attribute
    assert a_obj.run == 'test class'
    # Set '_save_unhandled_errors' instance attribute
    a_obj._task_vars = 'test instance'
    # Access '_save_unhandled_errors' instance attribute
    assert a_obj._task_vars == 'test instance'
    # Call object method 'run' and compare result
    assert a_obj.run() == 'test instance'

# Generated at 2022-06-11 12:08:40.691034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate object of class ActionModule
    action_module = ActionModule(connection=None, task_included_var=None, task_vars_params={"ansible_verbosity":1})
    # Call method run
    # result = action_module.run(tmp=None, task_vars=None)
    result = to_text(action_module.run(tmp=None, task_vars=None), errors='surrogate_then_replace').strip()
    print("*** Result from call to method run of class ActionModule: result=%s" % result)

if __name__ == "__main__":
    # Run Unit test for method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-11 12:08:49.278848
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:10:49.939568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-11 12:10:53.170631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # make sure we have the correct object instance
    x = ActionModule(task={"action": "ping", "version_added": 2.1}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    assert x._supports_check_mode == True
    assert x._supports_async == True


# Generated at 2022-06-11 12:10:58.745319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    m._remove_tmp_path = MagicMock()
    m._task = None
    m._connection = None
    m._connection.has_natiove_async = True
    m._execute_module = MagicMock()
    setattr(m._execute_module, "return_value", {})

    result = m.run(false, {"ansible_check_mode": True})
    eq_(result, {})


# Generated at 2022-06-11 12:11:00.429205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode is True
    assert module._supports_async is True

# Generated at 2022-06-11 12:11:08.404485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Create a test fixture
    #

    # Subclass ActionModule to make a concrete instance
    class TestActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            print("Args: ")
            for arg in args:
                print(arg)
            print("Kwargs: ")
            for k, v in kwargs.items():
                print("{0}: {1}".format(k, v))
            self.execute_module = Mock()
            return super(TestActionModule, self).__init__(*args, **kwargs)

        def execute_module(self, *args, **kwargs):
            print("Args: ")
            for arg in args:
                print(arg)
            print("Kwargs: ")

# Generated at 2022-06-11 12:11:09.213125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-11 12:11:10.253339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule is not None


# Generated at 2022-06-11 12:11:10.798732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-11 12:11:19.621983
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action

    # Create mocks
    configuration = ansible.plugins.action.ActionBase._configuration

    class mock_ActionBase(ansible.plugins.action.ActionBase):
        def __init__(self, temp_arg):
            self._configuration = temp_arg
        def run(self, tmp=None, task_vars=None):
            return True

    class my_class(ActionModule):
        def __init__(self, args):
            self._configuration = configuration
            self.run = mock_ActionBase(configuration)
            self.run.run = mock_ActionBase(configuration)
            self._connection = mock_ActionBase(configuration)
            self._connection.has_native_async = mock_ActionBase(configuration)

# Generated at 2022-06-11 12:11:21.056365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)
    assert isinstance(a, ActionBase)