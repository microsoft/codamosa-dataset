

# Generated at 2022-06-11 12:03:12.236981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:03:14.954228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    result = {}
    result['invocation'] = {}
    result['invocation']['module_args'] = {}
    act_mod = ActionModule()
    assert isinstance(act_mod, ActionModule)

# Generated at 2022-06-11 12:03:17.016414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    mod = ActionModule(None, {}, {}, None)
    assert mod is not None
    assert mod._supports_async

# Generated at 2022-06-11 12:03:23.054725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Tests the object creation
    am = ActionModule()
    assert isinstance(am, ActionModule)
    assert hasattr(am, 'run')
    assert hasattr(am, '_supports_check_mode')
    assert hasattr(am, '_supports_async')
    assert hasattr(am, '_execute_module')
    assert hasattr(am, '_remove_tmp_path')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:03:34.613871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
# Retrieve the current value of the variable 'tmp'
    tmp = getattr(ActionModule, "tmp")
# Destroy the variable 'tmp'
    del ActionModule.tmp
# Create the variable 'tmp' with value 'None'
    ActionModule.tmp = None
# Retrieve the current value of the variable 'task_vars'
    task_vars = getattr(ActionModule, "task_vars")
# Destroy the variable 'task_vars'
    del ActionModule.task_vars
# Create the variable 'task_vars' with value 'None'
    ActionModule.task_vars = None
# Retrieve the current value of the variable 'tmp'
    tmp = getattr(ActionBase, "tmp")
# Destroy the variable 'tmp'
    del ActionBase.tmp
# Create the variable 'tmp' with value 'None'


# Generated at 2022-06-11 12:03:36.908132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert(action._supports_check_mode)
    assert(action._supports_async)

# Generated at 2022-06-11 12:03:37.990164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()

# Generated at 2022-06-11 12:03:44.456916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_name = 'host_name'
    port = '22'
    connection = 'ssh'
    remote_user = 'remote_user'
    transport = 'transport'
    _task = '_task'
    _connection = '_connection'

    # test executable with name
    am = ActionModule(host_name, port, connection, remote_user, transport, _task)

    assert am.task_vars == {}
    assert am._shared_loader_obj is None
    assert am._task_vars_params is None
    assert am._task is _task
    assert am._connection is _connection
    assert am._play_context is None

# Generated at 2022-06-11 12:03:48.910613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.__module__ == 'ansible.plugins.action.core'
    assert action_module.__class__.__name__ == 'ActionModule'
    assert action_module.name == 'core'
    assert action_module._supports_check_mode
    assert action_module._supports_async

# Generated at 2022-06-11 12:03:49.534796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:03:56.917901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test that an instance of the ActionModule class can be created."""

    # Construct the object
    action_module = ActionModule('setup', {}, {}, task_uuid='c7b27a5e-a7d9-434f-a7dd-f03993d11a38', loader=None, templar=None, shared_loader_obj=None)

    # Test that the object was properly initialized
    assert action_module


# Generated at 2022-06-11 12:04:01.708882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test constructor with parameters """

    print("Construct ActionModule class object with parameters")
    
    result = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert result is not None, "ActionModule constructor failed"

# Generated at 2022-06-11 12:04:02.317258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()

# Generated at 2022-06-11 12:04:03.826398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule({},{'WANT_JSON': False},{})

# Generated at 2022-06-11 12:04:04.503044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1

# Generated at 2022-06-11 12:04:07.096441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # parametrize test method
    parametrize = [(None, None)]
    # execute test method
    run(parametrize)

# Generated at 2022-06-11 12:04:08.678610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert isinstance(x, ActionModule)

# Generated at 2022-06-11 12:04:09.317178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:04:09.927288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:04:10.838805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 12:04:17.686807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-11 12:04:22.457473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = {}
    action_base = ActionBase(connection, "/tmp/test", {})
    action_module = ActionModule(connection, "/tmp/test", {}, action_base, {})
    # Check that class is constructed correctly
    assert action_base == action_module._parent_action

# Test the ActionModule.run() with a simple setup module

# Generated at 2022-06-11 12:04:22.981188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:04:23.541471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:04:33.506019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.context import CLIARGS
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import ansible.vars
    from ansible.vars.manager import VariableManager

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=CLIARGS['inventory']),
        variable_manager=VariableManager(),
        loader=DataLoader(),
    )

# Generated at 2022-06-11 12:04:34.573292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:04:46.549093
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:04:55.785277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.plugins.loader import action_loader
  from ansible.utils.color import stringc
  import os

  test_task_vars = {
    'test_module_arguments': {
      'name': 'test',
      'state': 'test',
      'message': 'test',
      'tmp': '/nonexists',
      '_ansible_no_log': True,
    },
    'test_task_vars': "test"
  }
  test_module_name = "debug"
  test_module_path = "%s.py" % "debug"

# Generated at 2022-06-11 12:04:59.267747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule

    p = ActionModule()

    # Not sure how to unit test this because it depends on a lot of things
    # so for now just test that it doesn't throw an exception.
    p.run()

# Generated at 2022-06-11 12:05:00.964827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    assert am.run(task_vars={}) == {}


# Generated at 2022-06-11 12:05:22.345009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    task_vars = dict()
    task_vars["test_var"] = "test_var"
    task_vars["test_var2"] = "test_var2"
    
    # mock up a task

# Generated at 2022-06-11 12:05:32.227495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    # Mock objects for ActionModule.run()
    task = mock.Mock(spec=Task)
    task.loop = None
    task_vars = dict(
        ansible_check_mode=False,
        ansible_verbosity=2,
        jinja2_native=True,
        ansible_version=dict(full='2.0'),
        ansible_module_name='ping',
        ansible_module_args=dict(data='pong'),
        ansible_module_set_locale=False,
    )
    connection = mock.Mock()
    connection.transport = 'ssh'
    connection.has_pipelining = False
    connection.has_native_

# Generated at 2022-06-11 12:05:33.177382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement this
    pass

# Generated at 2022-06-11 12:05:43.963706
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action.normal import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader

    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-11 12:05:53.745388
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def set_connection(connection):
        connection._shell.tmpdir = "/some/path"

    mocker, action_module = mock_action_module(getattr(ActionModule, 'run'))
    # create the mocks
    module_mock = mocker.patch(MODULE_PATH)
    connection_mock = mocker.MagicMock()
    connection_mock.has_native_async.return_value = False
    get_connection_mock = mocker.patch('ansible.plugins.loader.ConnectionBase.get')
    get_connection_mock.return_value = connection_mock
    remove_tmp_path_mock = mocker.patch('ansible.plugins.action.ActionModule._remove_tmp_path')

# Generated at 2022-06-11 12:06:03.101695
# Unit test for constructor of class ActionModule
def test_ActionModule():
  from ansible.plugins.action.normal import ActionModule
  from ansible.parsing.dataloader import DataLoader
  from collections import namedtuple
  from ansible.inventory.manager import InventoryManager

  def execute_module():
    return {'foo':'bar'}
    
  class Connection:
    def __init__(self):
      self._shell = namedtuple('_shell', 'tmpdir')
    def has_native_async(self):
      return True
    def _remove_tmp_path():
      pass
    def _shell_escape():
      pass

  class Task:
    def __init__(self):
      self.async_val = False

  class PlayContext:
    def __init__(self):
      self.network_os = None
      self.become = False
  

# Generated at 2022-06-11 12:06:15.669942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    module = ActionModule(
        task = {},
        connection = {'_shell': {'tmpdir': 'testdir'}, 'has_native_async': True},
        forks = 0,
        play_context = {},
        loader = {},
        templar = {},
        shared_loader_obj = {},
        default_vars = {'gather_subset': ['all'],
                'gather_timeout': 10},
        task_vars = {},
    )

    assert module._supports_check_mode is True
    assert module._supports_async is True
    assert module._connection._shell.tmpdir == 'testdir'

    result = module.run()

# Generated at 2022-06-11 12:06:20.908778
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create an instance of class ActionModule
    action_module = ActionModule(100, "localhost")

    # Test action_module name, it should be 'ping'
    assert action_module.NAME == 'ping'

    # Test action_module host, it should be 'localhost'
    assert action_module.host == 'localhost'

    # Test action_module port, it should be 100
    assert action_module.port == 100

# Generated at 2022-06-11 12:06:27.480723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    from ansible.plugins.action import ActionModule

    # Unit test: example output from get_url
    # FIXME: no test for failed result or split output
    # FIXME: can't find example module output with multiple (non-json) lines at the end

# Generated at 2022-06-11 12:06:28.500669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Unimplemented"

# Generated at 2022-06-11 12:06:51.869452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Can be used to test constructor of class ActionModule
    ActionModule()


# Generated at 2022-06-11 12:07:00.979338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook import Playbook
    from ansible.executor.playbook_executor import PlaybookExecutor

    # We need some fake modules
    PlaybookExecutor.module_loader = FakeModuleLoader()

    # We need a fake inventory that returns a playbook
    inventory = FakeInventory()

    # We need a fake playbook that returns a playbook
    playbook = FakePlaybook(inventory)

    # We need a fake executor to run
    executor = FakeExecutor(playbook, inventory)

    # We need a fake state to run
    state = FakeState()
    state.add_task(executor.run_next_task)

    # We need a fake runner to run
    runner = FakeRunner(state)

    # We need a loader to load the playbook
    loader = FakeLoader()

    # We need a variable manager for

# Generated at 2022-06-11 12:07:10.463504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Return a valid Ansible task result for method run of class ActionModule
    """
    actionModule = ActionModule()

    result =  {
        "item": "",
        "item_loop": {},
        "res": {
            "changed": False,
            "failed": False,
            "meta": {
                "num_changed": 0,
                "num_tasks": 0
            }
        },
        "tmp": "test_template_default_temp_test",
        "tmp_path": "/Users/pmario/Development/repos/ansible/test/test_template_default_temp_test"
    }


# Generated at 2022-06-11 12:07:14.495751
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.action import ActionBase
    import __builtin__
    setattr(__builtin__, '__file__', '/path/to/ansible')

    x = ActionModule(None, None, '/path/to/ansible')

    assert x._supports_check_mode is True

# Generated at 2022-06-11 12:07:17.489608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    # No Exception Raised
    test_module = ActionModule({}, ImmutableDict(ansible_facts={}), None, {})

# Generated at 2022-06-11 12:07:26.721596
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    results = {
        'ansible_facts': {}
    }
    module_name = 'test_module'
    task_vars = {
        'ansible_facts':{'test': 'value'}
    }
    tmp = 'test_tmp'
    my_action_module = ActionModule(module_name,{}, tmp, False, False, True, task_vars, False)

    assert module_name == my_action_module.module_name
    assert module_name == my_action_module.name
    assert True == my_action_module.noop_on_check(task_vars=task_vars)
    assert my_action_module.module_args is not None

    results = my_action_module.run(tmp, task_vars)
    assert results is not None


# Generated at 2022-06-11 12:07:28.322752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_spec = dict()
    x = ActionModule(arg_spec)
    assert x is not None

# Generated at 2022-06-11 12:07:29.602184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Pass
    pass

# Unit test to execute the run method of class ActionModule

# Generated at 2022-06-11 12:07:31.247484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(connection=None, task=None)
    assert action_module is not None

# Generated at 2022-06-11 12:07:32.158010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:08:22.560419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    print(am._task_vars)

# Generated at 2022-06-11 12:08:23.070519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:08:31.937950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock

    am = ActionModule()

    tmp = None
    task_vars = {}

    # initialize am
    am.setup = mock.MagicMock()

    # run am._execute_module
    am._execute_module = mock.MagicMock()
    am._execute_module.return_value = {}

    # run am._remove_tmp_path
    am._remove_tmp_path = mock.MagicMock()

    # am.run - could be better to mock all the other methods that come up
    am.run(tmp, task_vars)

    assert am._execute_module.call_count == 1

# Generated at 2022-06-11 12:08:40.421043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.connection.local import Connection
    from ansible.vars.manager import VariableManager

    task_vars = dict(
        ansible_connection='local',
        ansible_inventory='inventory',
        ansible_playbook_python='/usr/bin/python',
        ansible_ssh_user='lamanchou',
        ansible_module_name='command',
        ansible_module_args='foo'
    )

    class FakeTask:
        def __init__(self):
            self.action='command'
            self.async_val=False

    action_mod = ActionModule(connection=Connection(task_vars=VariableManager(loader=None, variables=task_vars)))

    action_mod._task = FakeTask()

# Generated at 2022-06-11 12:08:45.039143
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test with a task that has no_log set to true
    task = AnsibleActionModule(no_log=True)
    task.action = "ping"
    task.action_args = dict(data="Pong")
    result = task.run()    
    assert "invocation" in result, "result should have invocation after run"
    assert "module_args" not in result["invocation"], "result should NOT have module_args after run with no_log"

# Generated at 2022-06-11 12:08:45.674931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 0 == 0

# Generated at 2022-06-11 12:08:54.191244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest

    class TestActionModule(unittest.TestCase):

        def test_run(self):
            action_module = globals()["ActionModule"]()

            tmp=None
            task_vars=None

            result = action_module.run(tmp, task_vars)
            self.assertIsInstance(result, dict)
            self.assertIs(result.get('skipped'), None)
            self.assertIs(result.get('invocation', {}).get('module_args'), None)
            self.assertIs(result.get('_ansible_verbose_override'), None)

    module_name = os.path.splitext(os.path.basename(__file__))[0]

    suite = unittest.TestSuite()

# Generated at 2022-06-11 12:09:03.305083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.module_utils.six import with_metaclass
    from ansible.playbook.play_context import PlayContext

    # Add all plugins under a test directory
    add_all_plugin_dirs('test/utils/plugins')

    import ansible.plugins.action.test

    # get an instance of a test action plugin
    plugin_instance = ansible.plugins.action.test.ActionModule('test', {}, PlayContext())

    # create an action plugin
    class ActionModuleTest(with_metaclass(ActionModule, ActionModule)):
        pass

    # get an instance of a test action plugin
    amt_instance = ActionModuleTest('test', {'a': 'b'}, PlayContext())

    # compare ansible types
    assert type

# Generated at 2022-06-11 12:09:12.186039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host

    host = Host('192.168.1.1')
    my_task = action_loader.get('ping', host)

    my_action_module = ActionModule(my_task, connection=None)
    
    assert(my_action_module is not None)

    assert(my_task.action == 'ping')
    assert(my_task.name == 'ping')
    assert(my_task.action_args == {'data':'hello'})
    assert(my_task.args == {'data':'hello'})

    my_task.action_args = {'data':'hello'}
    my_task.args = {'data':'hello'}


# Generated at 2022-06-11 12:09:14.065285
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action.normal import ActionModule

    # FIXME: method run of class ActionModule needs a unit-test

    pass

# Generated at 2022-06-11 12:11:20.661606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)

# Generated at 2022-06-11 12:11:29.446701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six import StringIO
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.ios.ios import ios_argument_spec
    from ansible.module_utils.network.ios.ios import get_config
    from ansible.module_utils.network.ios.ios import get_capabilities

# Generated at 2022-06-11 12:11:36.452846
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:11:42.052197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    kwargs = {'task':'task', 'connection':'connection', 'play_context':'play_context', 'loader':'loader', 'templar':'templar', 'shared_loader_obj':'shared_loader_obj'}
    t = ActionModule(**kwargs)
    assert t._task == 'task'
    assert t._connection == 'connection'
    assert t._play_context == 'play_context'
    assert t._loader == 'loader'
    assert t._templar == 'templar'
    assert t._shared_loader_obj == 'shared_loader_obj'

# Generated at 2022-06-11 12:11:45.735519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of ActionModule class
    actmod = ActionModule()

    # create tmp and task_vars variables
    _tmp = []
    _task_vars = []

    # execute method run of class ActionModul
    result = actmod.run(tmp, task_vars)

    # check the result is correct
    assert result == True



# Generated at 2022-06-11 12:11:52.755948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    tmp, action_module_obj, ansible_connection_obj = None, None, None

# Generated at 2022-06-11 12:11:53.214554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:11:56.789268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import imp
    import tempfile
    
    # Create a temporary file to store the test code
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write the code to the temporary file

# Generated at 2022-06-11 12:12:04.369745
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:12:09.704820
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pytest
    from ansible import errors
    from ansible.plugins.action.normal import ActionModule as ActionNormalModule

    # ansible.errors.AnsibleActionFail: explicit failure
    with pytest.raises(errors.AnsibleActionFail, match=r'.* explicit failure$'):
        ActionNormalModule().run()

    # ansible.errors.AnsibleActionFail: explicit failure
    with pytest.raises(errors.AnsibleActionFail, match=r'.* explicit failure$'):
        ActionNormalModule().run(ampy_async=True)