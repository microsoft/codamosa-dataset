

# Generated at 2022-06-11 12:03:10.864294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._supports_async == True
    assert action_module._supports_check_mode == True


# Generated at 2022-06-11 12:03:14.411894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    action_module = ActionModule()
    if(type(action_module) != ActionModule):
        print("Error: ActionModule constructor error")
        assert False
    print("ActionModule constructor OK")
    assert True

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:03:15.224702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule(None, None, None, None)

# Generated at 2022-06-11 12:03:24.806414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test setUp
    import os
    import sys

    ANSIBALLZ_PATH = os.path.join(os.path.dirname(__file__), '../../../lib/ansiballz')
    if ANSIBALLZ_PATH is not None:
        sys.path.append(ANSIBALLZ_PATH)

    from ansible.plugins.action.normal import ActionModule

    action_module = ActionModule(None, None, None, None, None)

    # test scenario with empty variables
    tmp=None
    task_vars=None
    try:
        action_module.run(tmp, task_vars)
    except Exception as e:
        print("TestCase1:Failed")
        print(e)

    # test scenario where 'tmp' is not empty
    tmp={"test":"test"}


# Generated at 2022-06-11 12:03:36.341579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = ({ 'ansible_ssh_host': '35.163.24.186' }, { 'workdir': '/tmp' }, { 'playbook_dir': '/opt/ansible' })
    mock_conn = { '_shell': { 'tmpdir': '/tmp/tmp_file.txt' } }
    # Hacky way to mock datastructures
    @staticmethod
    def mock_static_method(task):
        return task

    # Implementing the abstract class ActionBase
    class ActionBaseMocked(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return { 
                'skipped': False,
                'invocation': {
                    'module_args': 'arguments',
                }
            }
    
    # Implementing the abstract class ActionBase

# Generated at 2022-06-11 12:03:37.012481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:03:40.276870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('test_connection', 'setup', 'test_playbook')
    assert am._connection == 'test_connection'
    assert am._task.action == 'setup'
    assert am._play_context.playbook == 'test_playbook'

# Generated at 2022-06-11 12:03:41.438054
# Unit test for constructor of class ActionModule
def test_ActionModule():
	# Constructor of return type ActionModule
	test_constructor = ActionModule()

# Generated at 2022-06-11 12:03:42.983553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None, None, None, None, None, None)
    assert actionModule is not None

# Generated at 2022-06-11 12:03:45.644872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a
    assert type(a) == ActionModule
    assert a.__class__ == ActionModule


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:03:56.734376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' ActionModule.run()

    Unit tests for module ansible.plugins.action.ActionModule.
    '''

    # create mock objects for what is needed
    module_name = 'mock.module.name'
    task_vars = {'mock_task_var': 'mock_value'}
    _task = mock.MagicMock()
    _task.async_val = 'async_val'
    _task.action = 'action'
    _task.no_log = True
    tmp_dir = '/tmp/ansible-tmp-1450375132.92-147468671393176'
    _connection = mock.MagicMock()
    _connection.has_native_async = False
    _connection._shell.tmpdir = tmp_dir

    # create mock object for what is not needed

# Generated at 2022-06-11 12:03:57.314390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:04:05.844000
# Unit test for constructor of class ActionModule
def test_ActionModule():

    print ("Test: constructor of class ActionModule")

    test_action_module = ActionModule(load_plugin_mgr_obj(), '/home/user/ansible/module_utils/actions/', 'module', 'args', 'host')

    # returned True if the user has asked to step through the playbook
    #assert isTrue(test_action_module.is_playbook_debugger_enabled())
    #assert test_action_module.run_once() == False
    #assert test_action_module.noop_on_check(None) == False



# Generated at 2022-06-11 12:04:08.364317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is a test for method run of class ActionModule
    """
    # Fixture - definition of variables used in test
    # TODO
    pass

# Generated at 2022-06-11 12:04:10.282003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule:
    - _execute_module
    - _remove_tmp_path
    """
    pass

# Generated at 2022-06-11 12:04:21.738364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import ansible.plugins
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 12:04:24.778885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(
        runner=ActionModule,
        task=ActionModule,
        connection=ActionModule,
        play_context=ActionModule,
        loader=ActionModule,
        templar=ActionModule,
        shared_loader_obj=ActionModule,
    )

# Generated at 2022-06-11 12:04:26.986566
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    '''
    Unit test for method run of class ActionModule in module ansible.plugins.action.action
    '''

    pass


# Generated at 2022-06-11 12:04:29.692324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=dict(), connection=dict())
    assert a._supports_check_mode == True
    assert a._supports_async == True

# Generated at 2022-06-11 12:04:32.254153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-11 12:04:48.933405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("testing method run of class ActionModule")

# Generated at 2022-06-11 12:04:57.125177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()
    actionmodule._display.verbosity = 4
    actionmodule.tmp = None
    actionmodule._task = None
    actionmodule._connection = None
    actionmodule._tmp_path = '/home/ansible/ansible/test/results/tmp'
    actionmodule._remove_tmp_path = lambda self, value: None
    actionmodule._execute_module = lambda self, value, wrap_async: value
    actionmodule._task = 'setup'
    actionmodule._task.args = None
    actionmodule._task.action = 'setup'
    result = actionmodule.run()
    assert result['invocation'] == {}

# Generated at 2022-06-11 12:05:06.976948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    t = Task()
    t._role = None
    t._block = None
    t.action = 'setup'
    t.args = dict()
    t.args.update(dict(gather_subset='min'))
    t._role_name = None
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager._extra_vars = dict()
    variable_manager.set_inventory(Inventory(loader=DataLoader()))
    variable_manager._played_tasks = []
    t.set_loader(DataLoader())

# Generated at 2022-06-11 12:05:17.770433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the object under test
    action_module_object = ActionModule()

    # Set some global parameters
    setattr(action_module_object, "_connection", "connection")
    setattr(action_module_object, "_task", "task")

    # Create mock objects
    class ActionBase_run_mock(object):
        # Mock function 'run'
        def run(self, tmp=None, task_vars=None):
            if tmp == "tmp_mock":
                return "result_mock"
            else:
                return "result_unexpected"
    action_base_run_mock_obj = ActionBase_run_mock()


# Generated at 2022-06-11 12:05:21.084637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule("test_module", "test_module_args", "test_module_file", "test_module_file_args", "test_module_file_slug")
    assert action_module is not None

# Generated at 2022-06-11 12:05:25.014900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	from ansible.plugins.action import ActionModule
	action = ActionModule
	# test_task_vars = dict()
	# assert action.run(action, tmp=None, task_vars=test_task_vars) == dict()

# Generated at 2022-06-11 12:05:28.350518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.connection.local import Connection as LocalConnection
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    connection = LocalConnection('1.2.3.4', None)
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = connection.play_context

# Generated at 2022-06-11 12:05:28.764406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x is not None

# Generated at 2022-06-11 12:05:39.292517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #from mock import Mock

    m_task_vars = {'inventory_hostname': 'test1'}
    m_tmp = 'tmp'
    m_connection = 'connection'
    m_play_context = {'check_mode': True, 'verbosity': 3}

    am = ActionModule(m_tmp, m_task_vars, m_connection, m_play_context)

    print("am._supports_check_mode: ")
    print(am._supports_check_mode)
    print("am._supports_async: ")
    print(am._supports_async)

    print("am._task: ")
    print(am._task)
    print("am._tmp: ")
    print(am._tmp)
    print("am._connection: ")

# Generated at 2022-06-11 12:05:40.402444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    print(module.run())

# Generated at 2022-06-11 12:06:01.418950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing import DataLoader

    module = AnsibleModule(
        argument_spec = dict(
            module_name=dict(type='str'),
            module_args=dict(default='', type='str')
        ),
        supports_check_mode=False
    )

    # create an action plugin instance
    action_plugin = ActionModule(module, '/home/foo/ansible', DataLoader())

    # create a task where the action is the name of the action plugin class
    def noop():
        pass

# Generated at 2022-06-11 12:06:02.094405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {}, {})

# Generated at 2022-06-11 12:06:04.474330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._supports_check_mode is True
    assert a._supports_async is True

# Generated at 2022-06-11 12:06:16.940800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            self.mock_run = self.mock_execute_module = self.mock_load_module = lambda *x,**y: {'rc':0}
            return super(MockActionModule, self).__init__(*args, **kwargs)

        def run(self, *args, **kwargs):
            return super(MockActionModule, self).run(*args, **kwargs)

        def load_module(self, *args, **kwargs):
            return self.mock_load_module(*args, **kwargs)

        def execute_module(self, *args, **kwargs):
            return self.mock_execute_module(*args, **kwargs)

    mock_task = dict()
   

# Generated at 2022-06-11 12:06:18.713075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:06:26.512322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create object module object
    obj_module = ActionModule()
    # Sample task_vars data
    task_vars_dict = {'localhost':
                          {'ansible_ssh_user': 'vagrant', 'ansible_ssh_pass': 'vagrant'}
                      }
    # Sample tmp data

# Generated at 2022-06-11 12:06:27.408635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass


# Generated at 2022-06-11 12:06:28.008980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:06:29.811929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert hasattr(a,'run')
    assert hasattr(a,'_execute_module')

# Generated at 2022-06-11 12:06:31.684167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 12:07:02.588144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule()
    assert ac
    assert ac.async_val == False
    assert ac.connection._shell.tmpdir == "/tmp/ansible-tmp-1469398219.98-224072090261777"
    assert ac.connection.has_native_async == False
    assert ac.noop_val == False
    assert ac.notify_handler == None
    assert ac.playbook_dir == "/home/travis/build/ansible/ansible/"
    assert ac.remove_tmp == True
    assert ac.shell == None
    assert ac.shell_executable == ""
    assert ac.tmpdir == "/tmp/ansible-tmp-1469398219.98-224072090261777"
    assert ac.tmpdir_lock == None

# Generated at 2022-06-11 12:07:11.260707
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test stub
    class ActionModuleSubclass(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return dict()

    # Test case 1
    module = ActionModuleSubclass(
        # Task instance
        Task(),
        # Connection instance
        Connection(),
        # Play Context instance
        PlayContext(),
        # Shared Plugin Loader instance
        SharedPluginLoader(),
        # Options
        Options(),
        # Ansible Runner
        Runner(),
        # Task name
        'Test'
    )
    # Run ActionModule function
    resp = module.run()
    # Assertion
    assert not resp.get('skipped')
    # Assertion
    assert not resp.get('invocation').get('module_args')

# Generated at 2022-06-11 12:07:18.704552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    task_vars = {}
    tmp = '/tmp'
    action_base = ActionBase(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    if action_base is not None:
        result = action_module.run(tmp, task_vars)
        print(result)
    else:
        pass


# Generated at 2022-06-11 12:07:27.939348
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Setup args sent to constructor
    task_queue_manager = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None

    # the class is created
    action_module = ActionModule(task_queue_manager, connection, play_context, loader, templar, shared_loader_obj)
    # modules_on_controller is set to false
    assert action_module._connection.modules_on_controller is False
    # supports_check_mode is set to True
    assert action_module._supports_check_mode is True
    # supports_async is set to True
    assert action_module._supports_async is True
    # supports_async is set to True
    assert action_module._return_formats is ['python-dict']

# Generated at 2022-06-11 12:07:37.327764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task = Task()
    action._task.async_val = 0
    action._task.action = 'include'
    action._connection = Connection()
    action._connection._shell = Shell()
    action._connection._shell.tmpdir = "/tmp"
    action._remove_tmp_path = MagicMock()
    action._execute_module = MagicMock(return_value = {'result': []})
    action._task.async_val = 10
    assert action.run() == {'result': []}
    # FIXME: https://github.com/ansible/ansible/issues/32573
    # action._task.async_val = None
    # assert action.run() == {'result': []}
    action._task.action = 'setup'

# Generated at 2022-06-11 12:07:46.762903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with asynchronous task
    task_vars = dict()
    host_vars = dict(ansible_connection='ssh')
    action_plugin_class = 'action.plugin.module'
    tmp = '/tmp'
    async_val = 10
    task_vars['ansible_verbosity'] = 0
    task_vars['ansible_module_name'] = 'copy'
    task_vars['ansible_module_args'] = dict(src='/source/file', dest='/dest/file')
    task_vars['ansible_job_id'] = 'job_id_1'
    task = dict(async_val=async_val)
    connection = dict()
    action_plugin = ActionModule()
    action_plugin_connection = ActionBase()
    action_plugin._supports_check_

# Generated at 2022-06-11 12:07:54.980913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    ActionModule unit test stub.
    """
    module_args = {}
    from ansible.plugins.connection import Connection
    p = ActionModule(connection=Connection())
    assert p._task == None
    assert p._connection == Connection()
    assert p._shared_loader_obj == None
    assert p._loader == None
    assert p._templar == None
    assert p._play_context == None
    assert p._task_vars == None
    assert p._tmp == None
    assert p._supports_async == True
    assert p._supports_check_mode == True
    assert p._task_vars == None
    assert p._tmp == None
    assert p._tmpdir == None

# Generated at 2022-06-11 12:07:56.269599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert type(action_module) is ActionModule

# Generated at 2022-06-11 12:07:56.814953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-11 12:08:06.153615
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = {}

    #Test to see whether the class ActionModule has been implemented
    test_object = ActionModule(None,None)


# Generated at 2022-06-11 12:09:03.115438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:09:05.374279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    action_module = ansible.plugins.action.action_module.ActionModule(connection=None)
    assert action_module is not None

# Generated at 2022-06-11 12:09:08.495589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Create a instance of ActionModule
    '''

    am = ActionModule()

    assert am._supports_check_mode == True
    assert am._supports_async == True
    assert am._connection == None

# Generated at 2022-06-11 12:09:09.318209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-11 12:09:09.822448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:09:11.419989
# Unit test for constructor of class ActionModule
def test_ActionModule():
        action = ActionModule()
        assert action.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:09:12.644535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

    print(a._get_handler())

# Generated at 2022-06-11 12:09:13.876236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert(a is not None)

# Generated at 2022-06-11 12:09:14.406216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:09:15.198428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule is not None)

# Generated at 2022-06-11 12:11:25.443729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None
    print(a)


# Generated at 2022-06-11 12:11:27.434216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod._supports_check_mode
    assert mod._supports_async
    assert mod._supports_async is True
    assert mod._supports_check_mode is True

# Generated at 2022-06-11 12:11:35.065903
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    from ansible.module_utils.common.removed import removed

    C.HOST_KEY_CHECKING = False
    C.RETRY_FILES_ENABLED = False

    class TestTask(object):
        def __init__(self):
            self.action = 'echo'
            self.area = 'test'
            self.name = 'test_actionmodule_run'
            self.no_log = False

# Generated at 2022-06-11 12:11:35.755829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 12:11:36.451491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:11:37.668523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-11 12:11:38.690020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #TODO: Implement unittest for ActionModule
    pass

# Generated at 2022-06-11 12:11:46.201596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    import ansible.module_utils.basic
    
    am = ansible.plugins.action.ActionModule(
        {
            "ANSIBLE_MODULE_ARGS": {
                "module_name": "test",
                "module_args": { "stuff": "hello" }
            },
            "ANSIBLE_MODULE_NAME": "test",
            "ANSIBLE_MODULE_ARGS": {"stuff": "hello"},
            "ANSIBLE_MODULE_CONSTANTS": {},
            "ANSIBLE_MODULE_KWARGS": {}
        },
        "test",
        {}
    )
    assert isinstance(am, ansible.plugins.action.ActionModule)
    
    

# Generated at 2022-06-11 12:11:53.216687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook import Play
    from ansible.playbook import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task 
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    from ansible.executor.task_result import TaskResult
    from ansible.executor import module_common, task_executor
    from ansible.utils.display import Display 
    
    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()

    results = []
    result = TaskResult(host=Host(name='server'), task=Task())

# Generated at 2022-06-11 12:12:00.745675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_init(self, *args, **kwargs):
        self.action = 'yum'
        self._task.action = 'yum'
        self.action_plugin = 'yum'
        self._task.action_plugin = 'yum'
        self.action_loader = 'yum'
        self._task.action_loader = 'yum'
        self.action_wrapper = 'yum'
        self._task.action_wrapper = 'yum'
        self.action_mod = 'yum'
        self._task.action_mod = 'yum'
        self.action_debug = 'yum'
        self._task.action_debug = 'yum'
        self.action_warnings = 'yum'
        self._task.action_warnings = 'yum'