

# Generated at 2022-06-11 12:03:15.338039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_task = ActionModule()
    m_module = ActionModule()
    m_task.task_vars = {'a': 1, 'b':2}
    m_task.action = 'test'
    m_task.module = 'mock'
    m_task.module_args = {}
    m_task.no_log = True
    m_task.setup_args = {}
    m_task.connection = 'testconnection'
    m_task.async_val = 0
    m_task.loop = 'testloop'
    m_module._task = m_task
    m_module._connection = "testconnection"
    m_module._execute_module(m_task.task_vars, wrap_async=False)


# Generated at 2022-06-11 12:03:16.267959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__

# Generated at 2022-06-11 12:03:26.349049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    global test_action_plugin_run_result
    test_action_plugin_run_result = None
    class TestModuleRunner(ActionBase):
        def _execute_module(self, module_name=None, module_args=None, tmp=None, task_vars=None, wrap_async=None):
            global test_action_plugin_run_result
            test_action_plugin_run_result = {'result': 'ok'}


    c = connection_loader.get('local', {})

# Generated at 2022-06-11 12:03:27.037831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:03:38.289501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins

    # Fixture can supply any value needed by the test case
    def _create_task(action='ping', async_val='2', connection='smart', module_name='ping', module_args='data=hello world', module_complex_args=dict(data='hello world'), module_lang='python', module_set_locale=dict(LC_ALL='C', LANG='C')):
        from ansible.playbook.task import Task
        from ansible.playbook.block import Block
        from ansible.playbook.role import Role
        from ansible.playbook.role.include import IncludeRole

        # Create a dummy parent block for the task
        dummy_block = Block()
        # Set the dummy block's role to be a dummy role.
        dummy_block._role = Role()

        # Create a dummy task

# Generated at 2022-06-11 12:03:39.673831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module is not None

# Generated at 2022-06-11 12:03:42.139950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('/path/to/ansible/lib', 'connector', dict(), 'task')
    assert action.module_name == 'connector'
    assert action.task == 'task'

# Generated at 2022-06-11 12:03:51.468140
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Fake parameters
    user  = 'testuser'
    dir   = '/tmp'
    files = [ '/a', '/b' ]
    module_name = 'testmodule'

    # Create action_module
    action_module = ActionModule(ActionModule.name)
    action_module._connection = Mock_connection()

    # Create task object
    task = Mock_task(user=user, dir=dir, files=files)

    # Create task_vars dict
    task_vars = dict(var1='value1', var2='value2')

    # Call action_module.run(), and get the result
    _result = action_module.run(task_vars=task_vars, task=task)

    # Assert that the result is not None
    assert(_result)
    assert(isinstance(_result, dict))

# Generated at 2022-06-11 12:03:52.230459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('connector', 'task')

# Generated at 2022-06-11 12:03:53.906392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)  # If this is true, the instantiation was successful.

# Generated at 2022-06-11 12:03:58.930373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action1 = ActionModule()
    result = action1._execute_module()
    assert result['action'] == 'action1'

# Generated at 2022-06-11 12:04:10.384044
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import merge_hash

    action_module = ActionModule('', 'localhost', '', {})

    result = dict(
        msg="",
        # one of these will match the plugin name
        modified=False, changed=False, failed=False, skipped=False,
        # one of these will be the executed module name
        invocation=dict(module_args={}, module_name='abc')
    )

    # FUTURE: better to let _execute_module calculate this internally?
    wrap_async = False

    # do some work
    # FIXME: what is the correct test here?
    result_new = merge_hash(result, action_module._execute_module(task_vars={}, wrap_async=wrap_async))

    # hack

# Generated at 2022-06-11 12:04:12.198341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module



# Generated at 2022-06-11 12:04:13.315282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-11 12:04:14.713670
# Unit test for constructor of class ActionModule
def test_ActionModule():
  with pytest.raises(Exception) as excinfo:
    action = ActionModule()

# Generated at 2022-06-11 12:04:24.786393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import merge_hash
    from ansible.parsing.yaml.loader import AnsibleLoader, AnsibleUnsafeLoader
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.cli.adhoc import AdHocCLI
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    module_loader.add_

# Generated at 2022-06-11 12:04:35.070300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # --- module_utils/json_utils.py
    class TestJsonUtils:
        def __init__(self):
            pass
        def _from_json(self, json_string):
            return json_string
        def _from_yaml(self, yaml_string):
            return yaml_string

    # --- module_utils/parsing/convert_bool.py
    class TestConvertBool:
        def __init__(self):
            pass
        def __call__(self, value, strict=True):
            if value == "True":
                return True
            elif value == "False":
                return False
            else:
                return value

    # --- plugins/action/__init__.py

# Generated at 2022-06-11 12:04:35.807349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-11 12:04:36.901201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    

# Generated at 2022-06-11 12:04:48.246797
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    from ansible.playbook.handler.task import HandlerTask
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    from ansible.vars.hostvars import HostVars



# Generated at 2022-06-11 12:04:54.892378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:04:55.493072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:04:56.431139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:05:01.850024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    tmp = 'replace this with output of tempfile.mkdtemp'
    task_vars = {}
    result = am.run(tmp, task_vars)
    assert(result['invocation']['module_args'] == None)
    assert(result['changed'] == False)
    assert(result['failed'] == False)
    assert(result['skipped'] == False)

# Generated at 2022-06-11 12:05:02.808079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Pass
    module = ActionModule()

# Generated at 2022-06-11 12:05:04.113415
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert isinstance(am, ActionBase)

# Generated at 2022-06-11 12:05:10.155739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with invalid argument
    assert ActionModule.__init__() is not None
    assert ActionModule.get_connection() is not None
    assert ActionModule.get_loader() is not None
    assert ActionModule.get_variable_manager() is not None
    assert ActionModule.get_loader() is not None
    assert ActionModule.get_templar() is not None
    assert ActionModule.get_action_plugin() is not None

# Generated at 2022-06-11 12:05:11.861917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__, "Module docstring missing"



# Generated at 2022-06-11 12:05:13.297002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test if the test_ActionModule_run function runs"

# Generated at 2022-06-11 12:05:14.286443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mc = ActionModule(None)
    assert mc != None

# Generated at 2022-06-11 12:05:26.998628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    ActionModule(mock.MagicMock())

# Generated at 2022-06-11 12:05:28.344985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-11 12:05:30.405037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance/object of class ActionModule
    obj = ActionModule()
    # call function run of class ActionModule
    obj.run()

# Generated at 2022-06-11 12:05:32.634758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actModule = ActionModule(None, None, None)
    assert actModule.run(tmp=None, task_vars=None) != None

# Generated at 2022-06-11 12:05:34.874273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of ActionModule """
    action = ActionModule()
    assert action.MODULE_COMPLEX_ARGS == {}

# Generated at 2022-06-11 12:05:45.563253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = "copy"
    module_args = {}
    module_args["src"] = "/tmp/source_file"
    module_args["dest"] = "/tmp/dest_file"
    action_name = "action_test"
    action = ActionModule(action_name)
    action._task_fields = {}
    action._task = {}
    action._task["action"] = action_name
    action._task["async"] = 0
    action._task["async_val"] = 10
    action._task["args"] = module_args
    action._connection = {}
    action._connection._shell = {}
    action._connection._shell.tmpdir = "/tmp"
    action._connection._shell.can_exec = False
    action._connection.has_native_async = False

# Generated at 2022-06-11 12:05:46.121670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:05:51.395050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.__init__ is not ActionBase.__init__
    assert not hasattr(ActionModule, '_supports_check_mode')
    assert not hasattr(ActionModule, '_supports_async')
    assert not hasattr(ActionModule, '_supports_wait_for')
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 12:05:52.468583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME
    pass

# Generated at 2022-06-11 12:05:53.020913
# Unit test for constructor of class ActionModule
def test_ActionModule():
	obj = ActionModule()

# Generated at 2022-06-11 12:06:24.162037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock modules
    import __builtin__ as builtins

    class MockSubprocess:
        """
        Mock class for subprocess
        """
        def __init__(self, cmd, shell=True, env=None, stdin=None, stdout=None, stderr=None, cwd=None, timeout=None):
            pass

        def communicate(self):
            return "output", "error"

    class MockPopen(object):
        """
        Mock class for subprocess.Popen
        """
        PIPE = None

        def __new__(cls, *args, **kwargs):
            return MockSubprocess(*args, **kwargs)


# Generated at 2022-06-11 12:06:33.608103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import constants
    from ansible.utils.vars import combine_vars
    am = ActionModule(task=dict(vars={'a':1}, action=dict(args={'a': 2}), noop_task={'a': 3}), connection=dict(host='test_host', port=1234), play_context=dict(become=False, become_user='test_user'))
    assert am._task.action == 'action'
    assert am._task.action_args == {'a': 2}
    assert am._task.action_keys == ['a']
    assert am._task.name == 'action'
    assert am._task.vars == {'a': 1}
    assert am._connection.host == 'test_host'
    assert am._connection.port == 1234
    assert am._

# Generated at 2022-06-11 12:06:43.014754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-11 12:06:43.635636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:06:52.633371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    import os
    import json
    import sys

    test_play = 'playbooks/action-plugin-test.yml'
    test_inventory = 'playbooks/test-inventory.ini'
    test_output = 'playbooks/test-output.json'

    test_data_loader = DataLoader()
    test_variable_manager = VariableManager()
    test_inventory_manager = InventoryManager(loader=test_data_loader, sources=[test_inventory])

    test

# Generated at 2022-06-11 12:07:01.835707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    #from ansible.inventory.host import Host, Group
    #from ansible.inventory.group import Group

    # Check: _execute_module
    # Check: _low_level_execute_command
    # Check: _load_name_to_path_map
    # Check: _module_name_from_path
    # Check: _get_action_handler

    #from ansible.plugins.action import ActionBase

    #from ansible.plugins.callback.default import CallbackModule
    #from ansible.plugins.connection.ssh import Connection
    #from ansible.plugins.connection.paramiko_ssh import Connection as ParamikoSSH
    #from ansible.plugins.connection.local import

# Generated at 2022-06-11 12:07:05.959436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing variables for test
    pm = ActionModule()
    pm.task_vars = {}
    module_args = {}
    pm.task_vars["module_args"] = module_args
    pm.result = {}

    # Executing test
    # Checking that method run returns correct value
    assert pm.run() == pm.result

# Generated at 2022-06-11 12:07:15.509353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    
    # init objects
    play_context = PlayContext()
    task_queue_manager = TaskQueueManager(inventory=InventoryManager(loader=None, sources=''))

    # init action module
    action_module = ActionModule(
        task=dict(action=dict(module_name="ping", module_args=dict(data="pong"))),
        play_context=play_context,
        connection=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    result = action_module.run(tmp=None, task_vars=None)

    # check result
   

# Generated at 2022-06-11 12:07:24.577659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Let us test run method of class ActionModule with temp file
    # creating a temporary file
    tmp_file_obj = None
    temp_dir = tempfile.gettempdir()
    temp_file = tempfile.NamedTemporaryFile(delete=False, dir=temp_dir)
    temp_file.write("test")
    temp_file.close()
    if os.path.exists(temp_file.name):
        # storing the name of the temporary file into a variable
        tmp_file_obj = tempfile.NamedTemporaryFile(dir=temp_dir)
        tmp_file_obj.name = temp_file.name
    tmp = tmp_file_obj.name
    # creating an instance of class ActionModule
    action_module = ActionModule()
    # creating a instance of class Task

# Generated at 2022-06-11 12:07:25.506283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:08:16.509253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:08:27.417880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook
    import ansible.inventory
    import ansible.playbook.task
    import ansible.executor.task_result

    pb = ansible.playbook.PlayBook()
    play = pb.get_playbook('/my/test/foo.yml', {}, [])
    inventory = ansible.inventory.Inventory('/my/test/inventory')
    play.set_loader(pb._loader)
    play.set_inventory(inventory)
    play.set_variable_manager(ansible.playbook.VariableManager(loader=pb._loader, inventory=inventory))

    task = ansible.playbook.task.Task()
    task._role = None
    task._role_name = None
    task._parent = None
    task._block = None
    task._play = play
   

# Generated at 2022-06-11 12:08:30.836079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import combine_vars

    action = ActionModule(AnsibleModule)

    assert 'skipped' not in action.run()

# Generated at 2022-06-11 12:08:32.633360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default arguments
    module = ActionModule()

    # Test with custom arguments
    module = ActionModule(self)

# Generated at 2022-06-11 12:08:40.851282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    if sys.version_info >= (3,0):
        from io import StringIO
    else:
        from StringIO import StringIO
    connection = StringIO()
    task_queue = StringIO()


# Generated at 2022-06-11 12:08:49.473430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os.path
    import sys
    import inspect
    import types
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from unit.ansible_test.test_action_module import ActionBaseTest
    module_name = inspect.stack()[0][3]
    module_meta = __import__(module_name)
    module_class = getattr(module_meta, module_name)

# Generated at 2022-06-11 12:08:50.576244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()
    assert actionmodule is not None

# Generated at 2022-06-11 12:08:51.241709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:08:52.045490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 12:09:00.714855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class MockConnection():
        def __init__(self):
            self.cur_path = "path"
            self.shell = None
            self.has_native_async = False

    class MockTask(Task):
        def __init__(self):
            self.async_val = False

    class MockPlay(Play):
        def __init__(self):
            self.connection = MockConnection()

    class MockPlaybook():
        def __init__(self):
            self.hostvars = {}


# Generated at 2022-06-11 12:11:17.327121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # make a test module
    M = ActionModule()

    # set up a mock connection and task
    C = connection_loader.get('local', {})
    T = Task()

    # set up a mock task to use
    T._role = None
    T._task = Dict()
    T._task.action = 'setup'
    T._task.async_val = 0
    T._task.args = Dict()
    T._task.args.module_name = 'setup'
    T._task.args.module_args = 'foo=bar'
    T._task.no_log = False

    # set up a mock context to use
    CTX = Dict()
    CTX.connection = C
    CTX.task = T

# Generated at 2022-06-11 12:11:18.141891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-11 12:11:18.583106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:11:19.302539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None,None)

# Generated at 2022-06-11 12:11:19.748017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:11:20.625771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:11:24.418202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    (action, args, task_vars) = ('setup', {}, {})
    action_obj = ActionModule(action, args, task_vars)
    assert isinstance(action_obj, ActionModule)
    # assert action_obj.run() == {}

# Generated at 2022-06-11 12:11:24.925607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:11:25.630115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()


# Generated at 2022-06-11 12:11:33.057581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize the class
    action_module = ActionModule()
    # Check if _supports_check_mode is true
    assert action_module._supports_check_mode is True
    # Check if _supports_async is true
    assert action_module._supports_async is True
    # Check if _connection is assigned
    assert action_module._connection is not None
    # Check if _task is assigned
    assert action_module._task is not None
    # Check if _shell is assigned
    assert action_module._shell is not None
    # Check if _display is assigned
    assert action_module._display is not None
    # Check if _loader is assigned
    assert action_module._loader is not None
    # Check if _templar is assigned
    assert action_module._templar is not None

