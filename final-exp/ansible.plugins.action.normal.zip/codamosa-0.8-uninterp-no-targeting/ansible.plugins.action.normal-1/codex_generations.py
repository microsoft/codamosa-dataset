

# Generated at 2022-06-21 02:26:38.856146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    tmp = "/var/lib/jenkins/workspace/simple_playbook/tmp"
    task_vars = dict(test_var = 'testing')
    module.run(tmp=tmp, task_vars=task_vars)
    # Test will fail if assert error is raised

# Generated at 2022-06-21 02:26:42.991611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {"a": "1", "b": "2", "c": "3"}
    action_module = ActionModule()
    result = action_module.run(tmp=None, task_vars=task_vars)
    # Verify by test result of method run of class ActionModule
    assert(result == task_vars)

# Generated at 2022-06-21 02:26:45.273675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None)
    assert type(action_module).__name__ == "ActionModule"

# Generated at 2022-06-21 02:26:53.955126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    arg_spec = dict(
        name=dict(type='str', default="foo"),
        state=dict(type='str', default="absent")
    )
    m._task = dict(
        async_val=None, 
        action="file", 
        is_async=False, 
        args=dict(src="foo.txt", dest="/tmp/foo.txt"),
        module_args=dict(src="foo.txt", dest="/tmp/foo.txt")
    )

# Generated at 2022-06-21 02:27:05.842456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host

    play_context = PlayContext()
    host = Host('localhost')
    play_context.set_task_and_variable_override(host, 'all', 'test')

    play = Play().load({
        'name': 'test',
        'connection': 'local',
        'hosts': 'localhost',
        'tasks': [{
            'action': 'mytest',
            'myarg': 'myval'
        }]}, loader=None, variable_manager=None, loader_cache=None)

    t = Task()
    t._role = None
    t

# Generated at 2022-06-21 02:27:16.827054
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    # create a base task and a play context
    TASK = dict(
        action=dict(
            module='ping',
            args=dict()
        )
    )
    TASK_DS = dict(
        action=dict(
            module='debug',
            args=dict(
                msg='{{ source_file }} should exist'
            )
        )
    )
    TASK_BS = dict(
        action=dict(
            module='setup',
            args=dict()
        )
    )

# Generated at 2022-06-21 02:27:17.659084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:27:26.171751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict(a=1, b=2.0, c=True, d="asdf", e=[1,2,3], f=dict(a=1, b=2))),
        connection=dict(),
        play_context=dict(deprecated_flags=dict(loglevel=0, check=False)),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert module._task.action == 'setup'
    assert module._task.args == dict(a=1, b=2.0, c=True, d="asdf", e=[1,2,3], f=dict(a=1, b=2))
    assert module._connection.name == ''
    assert module._loader.name == ''
    assert module

# Generated at 2022-06-21 02:27:31.816557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._supports_check_mode = True
    module._supports_async = True
    result = module.run()
    # Negative test, check for False is used to confirm that the run method
    # is returning True.
    assert(False != result.get('skipped'))
    assert(result.get('skipped'))

# Generated at 2022-06-21 02:27:36.064454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule("", "", "", "", "")
    action_module.run()

# Generated at 2022-06-21 02:27:41.419701
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create an instance of class Connection and test if it actually is one by checking for the attributes it should have
    action_module = ActionModule()
    assert type(action_module) == 'ActionModule'

    # check for all required attributes
    assert hasattr(action_module, 'run')

# Generated at 2022-06-21 02:27:43.879755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule.
    """
    pass

# Generated at 2022-06-21 02:27:54.296403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name="ping"
    task="ping"
    task_vars={
             "var1":"value1",
             "var2":"value2",
             "var3":"value3"
             }
    tmp="abc123"
    def exec_module(module_name, mod_args, inject=None, complex_args=None, persist_files=False,
        delete_remote_tmp=True, gather_subset=None, module_vars=None):
        return "success"
    #module_exec_results = AnsibleModule().exec_module(module_name=module_name, mod_args=mod_args, inject=inject, complex_args=complex_args, persist_files=persist_files,
    #    delete_remote_tmp=delete_remote_tmp, gather_subset=gather_subset

# Generated at 2022-06-21 02:28:02.866847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    # Patch for method ActionModule.run.
    def new_run(self, tmp=None, task_vars=None):

        print("\nIn mock run")

        # Check if the param tmp is of type dict.
        if type(tmp) is not dict:
            tmp = {'result': 'success'}

        return tmp


    old_run = ActionModule.run
    ActionModule.run = new_run
    result = ActionModule.run(None)
    assert result == {'result': 'success'}
    ActionModule.run = old_run
    print('test_ActionModule_run: pass')

    # Put your test code here.

    print('test_ActionModule_run: pass')



# Generated at 2022-06-21 02:28:12.249865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.ansible_command import AnsibleCommand
    from ansible.module_utils.ansible_module import CommandRunner
    import os
    import re
    import __main__
    import sys

    # Setup
    setattr(__main__, '__file__', 'ansible-test')
    command_spec = CommandRunner(module_name='test', module_args=dict(test='test_value'))
    command_runner = AnsibleCommand(command_spec)
    am = ActionModule(task=command_runner, connection='test')
    am._connection = type('connection', (object,), {'has_native_async': False})

    # Test #1 - async_val = False, wrap_async = False

# Generated at 2022-06-21 02:28:20.448244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    _tmp = None
    _task_vars = None
    _connection = None
    _play_context = None
    _loader = None
    _templar = None
    _shared_loader_obj = None

    # constructor of ActionModule
    action_module = ActionModule(_connection, _play_context, _loader, _templar, _shared_loader_obj)

    # execute method run of ActionModule
    action_module.run(_tmp, _task_vars)

# Generated at 2022-06-21 02:28:21.046520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:28:29.419859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    log('Setting up ActionModule_run')
    task_vars = {'var': 'foo'}
    host = Host('127.0.0.1')
    host.set_task_var('var', 'test')
    host.set_task_var('inventory_hostname', 'test')
    host.set_task_var('inventory_hostname_short', 'test')
    host.set_task_var('ansible_ssh_host', 'test')
    host.set_task_var('ansible_shell_type', 'csh')
    host.set_task_var('ansible_python_interpreter', '/usr/bin/python')
    host.set_task_var('ansible_python_version', '2.6')
    task = Task()
    task.host = host
    connection = Connection

# Generated at 2022-06-21 02:28:30.097556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:28:31.545592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:39.357272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Connection(object):
        pass
    class Task(object):
        pass
    action_module = ActionModule(Connection, Task)
    print(action_module)
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:28:39.805331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:53.659994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\nStart testing ActionModule ...")
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.role_include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    connection = Connection(PlayContext())
    task = Task()
    play_iterator = PlayIterator()

    # Create inventory
    host = Host(name="test_host")
    group = Group(name="test_group")
    group.add_host(host)

# Generated at 2022-06-21 02:28:54.550154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:29:00.099303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_mock = MagicMock()
    module_mock._remove_tmp_path = MagicMock()
    module_mock._execute_module = MagicMock(return_value={})
    module_mock.result = "some_result"
    module_mock.task_vars = dict(a="a", b="b")
    module_mock._supports_async = True
    module_mock._supports_check_mode = True
    module_mock._task = MagicMock()
    module_mock._task.async_val = True
    module_mock._task.action = "setup"
    module_mock._connection = MagicMock()
    module_mock._connection._shell = MagicMock()

# Generated at 2022-06-21 02:29:04.832181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.__class__.__name__ == 'ActionModule'
    assert am._supports_check_mode == True
    assert am._supports_async == True
    assert am._supports_async_timeout == False
    assert am._supports_no_log == False

# Generated at 2022-06-21 02:29:08.348685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(sub_type='shell', task_class=MyTask, action_class=MyAction, task_vars={'hostvars': {'host1': {'host1_var1': 'host1_val1'}}})
    m.run()

# Generated at 2022-06-21 02:29:17.160601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    shared_loader_obj = DummySharedPluginLoaderObj()
    connection_plugins_path_obj = DummyConnectionPluginsPathObj()
    variable_manager_obj = DummyVariableManagerObj()
    loader_obj = DummyLoaderObj()
    ds = DummyDataStore()
    task_vars = dict(
        ansible_ssh_host='dummy_ssh_host',
        ansible_ssh_pass='dummy_ssh_pass'
    )
    display = Display()
    module_name = 'test_name'
    task = DummyTask(
        connection='test_connection',
        action=module_name,
        module_args='test_module_args',
        async_val=False,
        async_timeout=120,
        register='test_register',
    )
    play_context = Play

# Generated at 2022-06-21 02:29:27.114356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test for constructor of class ActionModule '''
    action = { 'ANSIBLE_MODULE_ARGS': {'foo': 'bar'} }
    task = { 'action': action, 'async': 0, 'async_val': 0 }
    task_vars = { 'ansible_version': {'full': 'version', 'major': 1, 'minor': 8, 'revision': 0, 'string': 'version'}, 'ansible_check_mode': False }
    tmp = '/tmp'
    runner = {}
    play_context = {}
    connection = {}
    loader = {}
    templar = {}
    shared_loader_obj = {}
    action_plugin = ActionModule(task, runner, play_context, connection, templar, shared_loader_obj, loader)

# Generated at 2022-06-21 02:29:31.004421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule({}, {}, {}, {})
    assert not mod
    assert mod._supports_check_mode
    assert mod._supports_async

# Generated at 2022-06-21 02:29:46.433887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._supports_check_mode = True
    module._supports_async = True
    result = module.run(tmp=None, task_vars=None)
    del result

# Generated at 2022-06-21 02:29:48.834058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run: No implicit test for run")
    assert True == True


# Generated at 2022-06-21 02:29:52.147930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(shell=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-21 02:29:59.393394
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Inorder to pass the test, calling out the same method with different parameters,
    # so that all the code block inside is called atleast once.
    action_module = ActionModule('test', 'test', 'test', 'test', 'test')

    # return the method to test it
    return action_module.run



# Generated at 2022-06-21 02:30:04.735841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task  = {"async_val":"None", "async_seconds": "60"}
    connection = {}
    action_module = ActionModule(task, connection )

    task_vars = {}
    tmp = "None"
    result = action_module.run(tmp ,task_vars )
    assert result['empty'] == 'empty'
    assert result['invocation']['module_name'] == 'setup'
    assert result['ansible_facts'] == 'ansible_facts'
    assert result['invocation']['module_args'] == 'module_args'



# Generated at 2022-06-21 02:30:10.471916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Executing test_ActionModule_run')
    # Initialise a dummy action module
    action_module = ActionModule(None, None, None, None)
    # Run the unit test
    result = action_module.run(None, None)
    # If we get past the unit test, return True
    return True


# Generated at 2022-06-21 02:30:21.261313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule(
        argument_spec=dict()
    )

    a = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    a._supports_check_mode = False
    a._supports_async = False
    a.set_loader(loader=None)
    a.set_task_and_variable_override(task=None, variables=dict())
    a.set_task(task=None)
    a._execute_module(task_vars=dict())
    a._execute_module(task_vars=dict(), wrap_async=True)

# Generated at 2022-06-21 02:30:24.054693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Units tests for class ActionModule
    '''
    action_module = ActionModule()

# Generated at 2022-06-21 02:30:25.565191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:30:32.540735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = {
        'test_host': {
            'ansible_connection': 'local',
            'ansible_host': 'localhost',
            'ansible_ssh_host': 'localhost',
            'ansible_python_interpreter': 'python',
            'ansible_shell_type': 'sh',
            'ansible_user': 'root',
            'inventory_hostname': 'test_host',
            'inventory_hostname_short': 'test_host',
            'group_names': [
                'test_group'
            ]
        }
    }


# Generated at 2022-06-21 02:31:01.365312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module1 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # test action_module1 object attributes
    assert action_module1._supports_async == True
    assert action_module1._supports_check_mode == True
    assert action_module1.action == 'action'
    assert action_module1.action_loader == None
    assert action_module1.action_path == ['/Users/brandontracy/PycharmProjects/Ansible/lib/ansible/plugins/action']
    assert action_module1.display.deprecated_message == None
    assert action_module1.display.deprecated_warning == None
    assert action_module1.display.display == None
    assert action_module

# Generated at 2022-06-21 02:31:02.360905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule(connection=conn)
    assert (instance != None)

# Generated at 2022-06-21 02:31:06.832572
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule('module_args')

    # Modules
    module.module_name = "copy"
    module.module_args = "src=file dest=file_1"
    module.run()

# Generated at 2022-06-21 02:31:08.274163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-21 02:31:09.393057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:31:10.230190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:31:14.146061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    ansible/plugins/action/__init__.py ActionModule()
    '''

    assert ActionModule(None, None, None)._supports_async == True
    assert ActionModule(None, None, None)._supports_check_mode == True

    action = ActionModule('test_data', 'test_connection', 'test_play_context')
    assert action._supports_async == True
    assert action._supports_check_mode == True

# Generated at 2022-06-21 02:31:21.922737
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.loader
    mod_path = 'ansible.plugins.action.builtin'
    mod = ansible.plugins.loader.action_loader.get(mod_path, class_only=True)

    # Case 1: Successful run
    mock_connection = ansible.plugins.loader.connection_loader.get('local', class_only=True)
    mock_loader = ansible.plugins.loader.action_loader
    mock_play = ansible.playbook.play.Play()
    mock_task = ansible.playbook.task.Task()
    mock_task._connection = mock_connection
    mock_task._loader = mock_loader
    mock_task._ansible_verbose_override = False
    mock_task._async_val = True
    mock_task._delegate_to = None


# Generated at 2022-06-21 02:31:24.973625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(load_attr=True)
    assert action.__class__.__name__ == 'ActionModule'
    assert action._supports_check_mode == True
    assert action._supports_async == True
    assert action._load_attr == True

# Generated at 2022-06-21 02:31:28.963216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule """
    from ansible.playbook.task import Task
    from ansible.plugins import module_loader
    from ansible.vars.hostvars import HostVars

    action_module = ActionModule(Task(), module_loader, connection=None)
    assert(type(action_module) == ActionModule)



# Generated at 2022-06-21 02:32:45.925789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    assert isinstance(ActionModule(None, None, None), ActionModule)
    assert isinstance(to_text(ActionModule(None, None, None)), string_types)
    assert isinstance(merge_hash(None, None), dict)

# Generated at 2022-06-21 02:32:46.633500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:32:47.818271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:32:52.255106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleTest(ActionModule):
        def __init__(self):
            pass
    am = ActionModuleTest()
    # This should not raise any exception
    assert am is not None

# Generated at 2022-06-21 02:32:54.105473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None,'module','some args') is not None

# Generated at 2022-06-21 02:33:01.707799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.plugins.action.normal import ActionModule as NormalAction 

    am = NormalAction(Task(), None, None, None)

    am._connection = DummyConnection()
    am._task = DummyTask()
    am._task.async_val = 12
    am._loader = DummyLoader()
    am._templar = DummyTemplar()
    am._shared_loader_obj = DummySharedLoaderObj()
    am._task_vars = {'ansible_check_mode': False}

    ansible_vars = am.run(tmp=None, task_vars={'ansible_check_mode': False})

    assert(ansible_vars['ansible_facts']['test_fact'] == "test_fact")

# D

# Generated at 2022-06-21 02:33:10.445594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import sys

    test_case_class = None

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            print("Running action module: " + self.action)
            return(super(TestActionModule, self).run(tmp, task_vars))

    class TestActionModule_TestCase(unittest.TestCase):
        def setUp(self):
            self.test_case = self

    if unittest.__version__ < '2.0.0':
        test_case_class = TestActionModule_TestCase

# Generated at 2022-06-21 02:33:14.521085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #constructor is used only create a new instance of class ActionModule.
    try:
        ActionModule()
    except Exception as e:
        raise AssertionError("Instantiating class ActionModule should not raise an exception" + str(e))

# Generated at 2022-06-21 02:33:18.156626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.supports_check_mode is True
    assert action.supports_async is True

# Generated at 2022-06-21 02:33:19.703565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action != None

# Generated at 2022-06-21 02:35:18.332853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    this test is a fake, does not really test anything
    """
    # set up test class
    my_test = ActionModule()
    from ansible.module_utils.basic import AnsibleModule
    my_test.task = AnsibleModule()
    print(my_test.task)
    # test run method
    print(my_test.run())


# Generated at 2022-06-21 02:35:19.283616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:35:26.367907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = FakeConnection()
    conn._shell = FakeShell()

    m = ActionModule(connection=conn, action='foo')
    m._task = FakeTask()
    m._execute_module = FakeExecuteModule()

    res = m.run()
    assert res == {'changed': True, 'invocation': {'module_name': 'foo'}}

    assert not conn._shell.tmpdir_created


# Generated at 2022-06-21 02:35:35.551772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    am = ActionModule()

    # Test failure when run is called with None as the required parameters
    result = am.run(None, None)
    assert result.get('failed') == True

    result = am.run(None, {})
    assert result.get('failed') == True

    result = am.run('temp', None)
    assert result.get('failed') == True

# Generated at 2022-06-21 02:35:36.244041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:35:47.847146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule
    """
    task_vars = dict(
        ansible_connection='local',
        ansible_ssh_user='root',
        ansible_ssh_port=22,
        ansible_ssh_pass='password',
    )

    AM = ActionModule(task=dict(action='command'), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert AM._play_context == dict()
    assert AM._task == dict(action='command')
    assert AM._loader == None
    assert AM._templar == None
    assert AM._shared_loader_obj == None
    assert AM._connection == dict()
    assert AM._low_level_connection_name == 'local'
    assert AM._low_level_connection

# Generated at 2022-06-21 02:35:57.734632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create the file names for test
    test_task_vars_file = 'test_task_vars'
    test_result_file = 'test_result'
    # create the test object
    my_test = ActionModule()
    # create the test variables
    my_test_task_vars = {'a': 1, 'b': 2, 'c': 3}
    # call the function run
    my_return_value = my_test.run(task_vars=my_test_task_vars)
    # we expect that the function run returns the message 'ok'
    assert my_return_value['msg'] == 'ok'
    assert my_return_value['changed'] is False
    # assert that the data are correct

# Generated at 2022-06-21 02:36:03.543249
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:36:08.915158
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:36:18.202604
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.module_utils._text import to_text

    # setup test Environment
    C.DEFAULT_HASH_BEHAVIOUR = 'merge'
    results_expected = dict(
        changed=True,
        failed=False,
        msg='Hello',
        skipped=False,
        invocation=dict(module_name='echo'),
        ansible_facts=dict(first_fact='first',
                           second_fact='second'))

    # setup test ActionBase
    dummy_env = dict(TEST_ENV='TEST_ENV')
    dummy_task = Task()
    dummy_task.environment = dummy