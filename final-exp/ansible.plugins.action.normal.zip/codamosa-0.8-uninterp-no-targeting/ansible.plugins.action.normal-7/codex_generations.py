

# Generated at 2022-06-21 02:26:40.169908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default argument
    a = ActionModule()
    assert isinstance(a, ActionModule)

    # Test with given argument
    b = ActionModule(None)
    assert isinstance(b, ActionModule)

# Generated at 2022-06-21 02:26:40.971547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:26:41.599941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:26:43.430194
# Unit test for constructor of class ActionModule
def test_ActionModule():
	aa = ActionModule('', '', '', '', '')

# Generated at 2022-06-21 02:26:52.173725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    import ansible.constants as C
    import ansible.plugins.action.normal as a
    from ansible.plugins.loader import action_loader

    C.HOST_KEY_CHECKING = False
    # Create a HostManager and set it as HostManager.

# Generated at 2022-06-21 02:26:53.490155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:27:05.590152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    import ansible.utils.module_docs as module_docs
    import os


# Generated at 2022-06-21 02:27:07.711792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert hasattr(module, 'run')

# Generated at 2022-06-21 02:27:14.182471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class A:
        def __init__(self):
            self.task = Task(None, [])
            self.task.action = 'copy'
            self.task.async_val = 'free'
            self.connection = ConnectionBase()
            self.connection._shell = ShellModule('/tmp')
    a = ActionModule(A())
    assert(hasattr(a, 'run'))

# Generated at 2022-06-21 02:27:22.094220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import merge_hash
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.result import ResultProcessor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import constants as C
    # This will be called once

# Generated at 2022-06-21 02:27:35.693591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionBase(object):
        def run(self, *args, **kwargs):
            return args[1]

    class ActionModule(object):
        def __init__(self):
            self._connection = None
            self._supports_async = False
            self._supports_check_mode = False
            self._task = None
        def run(self, tmp=None, task_vars=None):
            # do work!
            # FUTURE: better to let _execute_module calculate this internally?
            wrap_async = self._task.async_val and not self._connection.has_native_async
            result = self._execute_module(task_vars=task_vars, wrap_async=wrap_async)
            if result.get('skipped'):
                self._remove_tmp

# Generated at 2022-06-21 02:27:37.460486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')


# Generated at 2022-06-21 02:27:46.063999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._supports_async = True

    action_module._task.async_val = False
    action_module._connection.has_native_async = True
    # FIXME: what is this?
    action_module.ds = {}

    action_module._task.action = 'setup'

    # test first part of run
    result = action_module.run(None, None)
    assert result.get('skipped') == True
    assert result.get('invocation', {}).get('module_args') == None 

    # test second part of run
    # FIXME: what to do about connection_get_shell?
    action_module._connection.tmpdir = '/tmp'
    result = action_module.run

# Generated at 2022-06-21 02:27:51.972220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    task = mock.MagicMock()
    task.action = 'setup'

    action_plugin = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # invoke
    action_plugin.run(tmp=None, task_vars=None)

    # assert
    assert action_plugin._execute_module is not None
    assert action_plugin._task.action in C._ACTION_SETUP
    assert action_plugin._task.action == 'setup'
    assert action_plugin._task.async_val is not None

# Generated at 2022-06-21 02:27:52.437976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:27:53.547407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None


# Generated at 2022-06-21 02:28:03.033679
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import json
    import pprint
    import mock
    import os
    import shutil
    import sys

    mock_verbose = True

    # prepare system to test functions
    mock_tmp_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible-test-run')
    mock_connection = mock.Mock()
    mock_shell = mock.Mock()
    mock_shell.tmpdir = None
    mock_connection._shell.tmpdir = mock_tmp_dir
    mock_connection._shell.has_native_async = False
    mock_task = mock.Mock()
    mock_task.action = 'setup'
    mock_task.async_val = 1
    mock_task_vars = {'ansible_facts': {}}
    mock_action_plugin = mock

# Generated at 2022-06-21 02:28:08.486939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test run method of class ActionModule
    action = ActionModule(None, None, None, None, None)
    action._supports_check_mode = True
    aciton._supports_async = True
    
    result = action.run(None, None)

# Generated at 2022-06-21 02:28:09.920264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)


# Generated at 2022-06-21 02:28:13.420424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Method run of class ActionModule not implemented.")

# Generated at 2022-06-21 02:28:27.859833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json, shutil, tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary directory inside the temporary directory
    tmpdir_1 = tempfile.mkdtemp(dir = tmpdir)

    # Create a temporary file inside the temporary directory
    f = tempfile.NamedTemporaryFile(dir=tmpdir_1)

    # Temporary file for the inventory
    inventory = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    inventory.write(b'localhost ansible_connection=local')
    inventory.close()

    # Create a temporary file containing some fake content
    filename = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    filename.write(b"content of file")
    filename.close()

    # Write resource files to

# Generated at 2022-06-21 02:28:30.010050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    assert m.run() == {}

# Generated at 2022-06-21 02:28:30.942431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:28:31.790161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: add tests
    return True

# Generated at 2022-06-21 02:28:44.526497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule('/test-path/test', 'test', args={'my-key': 'my-value'})
    task_vars = {'ansible_check_mode': True}

    class MockHost(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def supports_native_async(self):
            return False

    class MockConnection(object):
        def __init__(self, tmpdir, has_native_async):
            self._shell = MockHost(tmpdir)
            self.has_native_async = has_native_async

        def get_host_variables(self, task_vars, play_context):
            return task_vars

        def get_option(self, name):
            return None


# Generated at 2022-06-21 02:28:45.953054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:28:52.119041
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class TestActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

    test_ActionModule = TestActionModule({}, {}, {}, {}, {}, {})
    test_ActionModule.run(tmp, task_vars)

# Generated at 2022-06-21 02:29:03.991285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = type('Task',(object,),{})
    setattr(task,'async_val',False)
    loader = type('Loader',(object,),{})
    setattr(task,'loader',loader)
    setattr(task,'name','action')
    setattr(task,'loop',False)
    setattr(task,'run_once',False)
    setattr(task,'_role_defaults',{})
    play_context = type('PlayContext',(object,),{})
    setattr(task,'_play_context',play_context())
    tmp = type('TmpPath',(object,),{})
    setattr(task,'_connection',None)
    sr = type('SetupResult',(object,),{})
    setattr(task,'_setup_cache',sr())

# Generated at 2022-06-21 02:29:11.807757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import collections

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))

    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase

    # The following mock class is used for the unit testing of the method run


# Generated at 2022-06-21 02:29:12.508335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 0

# Generated at 2022-06-21 02:29:24.884705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    assert module is not None

# Generated at 2022-06-21 02:29:31.886097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test ActionModule(task, connection, play_context, loader, templar, shared_loader_obj=None)
    task = {}
    connection = {}
    play_context = {}
    loader = {}
    templar = {}
    _ActionModule = ActionModule(task, connection, play_context, loader, templar)

# test skips and no_log

# Generated at 2022-06-21 02:29:32.268774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:44.023753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.action
    import ansible.playbook.task
    import ansible.utils.template


# Generated at 2022-06-21 02:29:45.447235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method run of class ActionModule
    """
    action_module = ActionModule()
    assert False
    #TODO

# Generated at 2022-06-21 02:29:53.366207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_result import TaskResult

    # construct fake task exec
    play_context = PlayContext()
    play = Play().load({}, variable_manager={}, loader=None)
    task = Task()


# Generated at 2022-06-21 02:30:04.098607
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Import the modules that we need
    import sys
    sys.path.append('../../')

    import unittest

    import ansible.plugins
    import ansible.plugins.action
    from ansible.plugins.action import ActionModule
    #import mock

    #from ansible.module_utils.six import StringIO
    #from ansible.module_utils.six import PY3


# Generated at 2022-06-21 02:30:07.292355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Invoke constructor of class ActionModule
    actionModuleObj =  ActionModule(None,None,None,None,None)
    assert actionModuleObj is not None

# Generated at 2022-06-21 02:30:14.933380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule_run_ActionModule(ActionModule):
        def _execute_module(self, task_vars=None, wrap_async=None):
            return {'test': '_execute_module'}
        def run(self, tmp=None, task_vars=None):
            return super(ActionModule_run_ActionModule, self).run(tmp, task_vars)
    class ActionModule_run_Connection(object):
        def __init__(self):
            self.has_native_async = False
        def _shell(self):
            class Connection_shell(object):
                def __init__(self):
                    self.tmpdir = 'tmpdir'
            return Connection_shell()
    class ActionModule_run_Task(object):
        def __init__(self):
            self.async_val

# Generated at 2022-06-21 02:30:20.242506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Is ActionModule().run() callable?
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True,
    )

    assert callable(ActionModule().run())

    # Does ActionModule().run() return without error and do we have a result that's not None?
    result = module.run()

    assert result is not None

# Generated at 2022-06-21 02:30:43.024234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:30:43.885314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:30:53.665997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test only one module, there is separate test for _execute_module method
    # here we need to test whether _execute_module is called with proper parameters
    module_name = 'test_module'
    args = {}
    module_class_obj = MockModule()
    module_class_obj.run.return_value = {}
    module_class = Mock()
    module_class.return_value = module_class_obj
    action_class_obj = ActionModule(connection=None,
                                    task=None,
                                    task_vars=None,
                                    tmpdir=None,
                                    module_name=module_name,
                                    module_args=args,
                                    module_class=module_class,
                                    )
    action_class_obj.run(task_vars=None)

# Generated at 2022-06-21 02:31:00.186378
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Invalid module_name
    try:
        action = ActionModule('action_module', 'module_name', 'module_args')
    except ValueError as e:
        assert e.args == ('module_name cannot be empty',)

    # Invalid module_args
    try:
        action = ActionModule('action_module', 'module_name', None)
    except ValueError as e:
        assert e.args == ('module_args cannot be empty',)

# Generated at 2022-06-21 02:31:02.233025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:31:03.762722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-21 02:31:04.602867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:31:06.609979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No errors raised
    ActionModule._execute_module(task_vars=None)

# Generated at 2022-06-21 02:31:17.353585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # import ansible.builtin.plugins.action.command
    test_task = dict(
        action=dict(
            module='ping',
            args=dict(
                data='pong'
            )
        )
    )
    test_task_vars = dict()
    test_connection = dict()

    action_module = ActionModule(task=test_task, connection=test_connection, play_context=dict())
    # assert isinstance(action_module._task, ansible.plugins.task.Task) is True
    # assert isinstance(action_module._connection, ansible.plugins.connection.Connection) is True

# Generated at 2022-06-21 02:31:26.338962
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.plugins.action.normal
    import ansible.plugins.action.copy
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible.plugins.action.script
    from ansible.playbook.task import Task

    theTask = Task()
    action = ansible.plugins.action.normal.ActionModule(task=theTask, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert(action is not None)

    action = ansible.plugins.action.copy.ActionModule(task=theTask, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert(action is not None)

    action = ansible.plugins.action

# Generated at 2022-06-21 02:32:35.274115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m is not None

# Generated at 2022-06-21 02:32:40.468263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.plugins.loader import module_loader
    from ansible.plugins.connection.local import Connection
    import ansible.constants as C
    import tempfile
    import shutil
    import os
    import json

    # create a temporary directory for test
    tmp_dir = tempfile.mkdtemp()
    test_module_path = os.path.join(tmp_dir, 'test_module.py')
    test_module_filename = os.path.basename(test_module_path)

    # create a test module file

# Generated at 2022-06-21 02:32:50.946207
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os
    import sys
    import unittest

    import ansible.plugins.action
    import ansible.plugins.action.wrap_async
    import ansible.plugins.action.normal

    ####################################################################################
    # (1) test ActionModule.run (with async=False)
    ####################################################################################

    class TestActionModule(unittest.TestCase):

        def setUp(self):

            # prepare the environment
            if not os.path.exists('./test_results'):
                os.makedirs('./test_results')

            if not os.path.exists('./test_results/normal'):
                os.makedirs('./test_results/normal')

            # set up test results
            self.result_stdout = './test_results/normal/'

# Generated at 2022-06-21 02:33:00.424843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")
    # Simple test of ActionModule_run based on ENV vars,
    # and your .ansible.cfg file.

    # FIXME: Verify a TaskQueueManager creation here.
    # FIXME: We need a verbose option for this framework too.

    if 'ANSIBLE_TEST_REMOTE_HOST' in os.environ:
        os.environ['ANSIBLE_REMOTE_TEMP'] = '%s/test_ansible_remote_tmp' % (os.environ['ANSIBLE_REMOTE_TEMP'],)
        os.environ['ANSIBLE_LOCAL_TEMP'] = '%s/test_ansible_local_tmp' % (os.environ['ANSIBLE_LOCAL_TEMP'],)
        # We use ClassName and object_name based

# Generated at 2022-06-21 02:33:02.563971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for class ActionModule should not raise any exceptions
    ActionModule()

# Generated at 2022-06-21 02:33:10.666362
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins import module_loader

    # if we did not get a task, make one
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    module_name = 'shell'
    args = dict(test="test_value")
    task_vars = dict(user="user_value")

    # create the module object
    module = module_loader.get(module_name, connection='local', module_args=args, task_vars=task_vars, loader=action._loader)

    # initialize the module
    module.check_mode = False
    module.no_log = False
    module.run()

    # create a result object to use


# Generated at 2022-06-21 02:33:19.364396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        from ansible.utils.vars import merge_hash
        from ansible.plugins.action import ActionBase
    except ImportError:
        print('Cannot test ActionModule because of import error')
        return
    try:
        from ansible.utils.vars import combine_vars
        from ansible.utils.vars import merge_hash
    except ImportError:
        print('Cannot test ActionModule because of import error')
        return

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    vault = VaultLib([])
    vault_secret = VaultSecret('', vault.secrets[0])
    vault_password = VaultPassword('', vault_secret)


# Generated at 2022-06-21 02:33:20.886484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 02:33:30.427091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    python -m testtools.run \
    tests.unit.test_action_plugins.test_ActionModule
    """
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action.setup import ActionModule as SetupModule
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import set_all_plugin_loaders
    from ansible import constants as C

    results = []

    def __mock_execute_module(self, *args, **kwargs):
        results.append([args, kwargs])
        return {'skipped': False}

    # Have to remove all plugins to ensure the ones we add are found.
    loaders = list(get_all_plugin_loaders())
    set_all_plugin_loaders([])

# Generated at 2022-06-21 02:33:31.885513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-21 02:35:37.860483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            async_val=1,
            action='some action',
        ),
        connection=dict(
            has_native_async=False,
        ),
        play_context=dict(
            check_mode=True,
        )
    )
    assert module.run()

# Generated at 2022-06-21 02:35:44.801855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is a test to check the method run of class ActionModule
    """

    # result is class Result , which has attribute skipped
    result = Result()
    # ansible is initialized 
    ansib= Ansible()
    # result is updated with skipped attributes
    ansib.run(result)
    # skipped is not none
    assert result.skipped is not None

# Generated at 2022-06-21 02:35:46.016762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-21 02:35:56.806585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    my_task = Task()
    my_task._role_name = "my_role"
    play_context = PlayContext()
    connection = 'local'
    new_stdin = False
    loader = 'xyz'
    templar = 'abc'

    am = ActionModule(my_task, connection, play_context, loader, templar, new_stdin)
    assert am._task == my_task
    assert am._connection == connection
    assert am._play_context == play_context
    assert am._loader == loader
    assert am._new_stdin == new_stdin
    assert am._templar == templar

# Generated at 2022-06-21 02:36:06.241450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_host = "localhost"
    my_task = None
    my_connection = None
    my_loader = None
    my_templar = None
    my_shared_loader_obj = None
    action_module = ActionModule(my_host, my_task, my_connection, my_loader, my_templar, my_shared_loader_obj)
    assert action_module.task_fixups() == []
    assert action_module.task_vars() == dict()
    assert action_module.templar() is not None
    assert action_module.loader() is not None

# Generated at 2022-06-21 02:36:08.128232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None)
    assert a

# Generated at 2022-06-21 02:36:14.439280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.action = 'setup'
    x = module.run(tmp='test', task_vars=dict(a='b'))
    assert x['invocation']['module_name'] == 'setup'
    assert x['invocation']['module_args'] == 'test', x

# Generated at 2022-06-21 02:36:15.820873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-21 02:36:17.858702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, 'Unit test not implemented'



# Generated at 2022-06-21 02:36:28.316538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    def fake_set_module_args(module_name, module_args=None, task_vars=None, wrap_async=None):
        return None
    module._set_module_args = fake_set_module_args

    def fake_set_task_vars(task_vars):
        return None
    module._set_task_vars = fake_set_task_vars

    def fake_add_cleanup_task(cleanup_task):
        return None
    module._add_cleanup_task = fake_add_cleanup_task

    def fake_verify_checksum(path, remote_md5):
        return None
    module._verify_checksum = fake_verify_checksum

    def fake_supports_async(self):
        return True
