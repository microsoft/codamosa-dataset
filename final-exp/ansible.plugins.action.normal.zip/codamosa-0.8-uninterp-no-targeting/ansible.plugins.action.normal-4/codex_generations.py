

# Generated at 2022-06-21 02:26:44.561373
# Unit test for method run of class ActionModule
def test_ActionModule_run():

        # Execute method run of class ActionModule
    # Set up arguments of method run of class ActionModule
    tmp = None
    task_vars = None
    wrap_async = None

    # Isolate and set up mocked objects

        # acquire parent class mocked object 
    mocked_ActionBase = ActionBase()

        # acquire _execute_module method of ActionModule class
    mocked_ActionModule__execute_module = ActionModule()._execute_module
    mocked_ActionModule__execute_module.return_value = 42  
        # acquire _remove_tmp_path method of ActionModule class
    mocked_ActionModule__remove_tmp_path = ActionModule()._remove_tmp_path
    mocked_ActionModule__remove_tmp_path.return_value = None

        # acquire run method of ActionBase class
    mocked_ActionBase_run = ActionBase().run

# Generated at 2022-06-21 02:26:48.058126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext

    host = Host('testhost')
    play_context = PlayContext()
    task = ActionModule(host, play_context)

    print("Testing run function of class ActionModule")
    print("====")

    assert task.run(tmp=None, task_vars=None) == {}, "should be an empty dictionary"

# Generated at 2022-06-21 02:26:53.631791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_mock = {"foo": "bar"}
    module_name = "test_action"
    action_mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_mod._task = module_mock
    assert type(action_mod)==ActionModule
    assert action_mod._task==module_mock

# Generated at 2022-06-21 02:26:55.246246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:27:01.455994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common.removed import removed
    removed()

    # setup

    # the test task
    task = Task()

    # the test action plugin
    action = ActionModule()

    # the test task queue manager
    tqm = TaskQueueManager()
    tqm._stdout_callback = lambda x: None
    tqm._verbose = True

    # the test playbook executor

# Generated at 2022-06-21 02:27:02.333521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:27:15.321768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run()")

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader
    import ansible.playbook.task_include as task_include
    module_name = 'ping'
    task = task_include.TaskInclude.load(dict(action=module_name))
    action_module_name = 'ansible.plugins.action.' + task.action
    print("action_module_name: %s" % action_module_name)
    action_cls = action_loader.get(action_module_name, task, connection=None, play_context=None, loader=None, templar=None)

# Generated at 2022-06-21 02:27:23.057349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    kwargs = {
        'action_plugins': 'test_plugins/test_action',
    }

    # Create a mock for 'ActionBase' class
    class MockActionBase():
        def run():
            pass

    # Instantiate an object with module's arguments
    action_base_obj = ActionBase()

    # Object to mock 'ActionBase.run' method
    run_obj = MockActionBase()

    # Set return value for 'ActionBase.run' method
    run_obj.run.return_value = result = dict()

    # Create a mock for 'ActionModule' class
    class MockActionModule():
        def __new__(cls, *args, **kwargs):
            return run_obj

    # Mock 'ActionModule' class constructor
    action_module_obj = MockActionModule()

    # Call method under test


# Generated at 2022-06-21 02:27:25.491874
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
  assert(len(am.run()) > 0)

# Generated at 2022-06-21 02:27:26.065003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:27:38.583395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = "localhost"
    connection = None
    module_name = "Command"
    task_vars = {}
    wrap_async = False
    shell = None
    args = "{'_uses_shell': False, '_raw_params': 'date'}"
    task_vars['ansible_facts'] = {}
    task_vars['ansible_facts']['ansible_all_ipv4_addresses'] = ['192.168.3.3']
    task_vars['ansible_facts']['ansible_architecture'] = 'x86_64'
    task_vars['ansible_facts']['ansible_distribution'] = 'CentOS'
    task_vars['ansible_facts']['ansible_distribution_release'] = '7.6.1810'


# Generated at 2022-06-21 02:27:40.018062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('setup')
    assert am._task == 'setup'

# Generated at 2022-06-21 02:27:41.589344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:27:44.641709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    res = mod.run(None, None)
    assert res == None

# Generated at 2022-06-21 02:27:51.577993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule
    mod = ActionModule(AnsibleModule(argument_spec={}), task={})
    assert mod


if __name__ == '__main__':
    ma = ActionModule(None, dict(action='setup', module_name='setup'))
    print(ma.run(task_vars=dict(ansible_facts=dict(test_var='test fact'))))

# Generated at 2022-06-21 02:28:01.915038
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_inventory_file
    from ansible.utils.vars import load_playbook_vars

# Generated at 2022-06-21 02:28:04.644173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module=ActionModule()
    data = dict(action = dict(module = "echo", args = "args1"))
    result = action_module.run(data)
    assert result == dict(action = dict(module = "echo", args = "args1"))

# Generated at 2022-06-21 02:28:13.231102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t_Args = dict(
        module_name='test_module1',
        module_args = dict(
            test_arg1='test_module1_arg1',
            test_arg2='test_module1_arg2'
            ),
        module_exec_path=None
        )

    tMod = ActionModule(task=t_Args, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert tMod._task.action == 'test_module1'
    assert tMod._task.args == dict (
        test_arg1='test_module1_arg1',
        test_arg2='test_module1_arg2'
        )

# Generated at 2022-06-21 02:28:16.058598
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert am.__class__.__name__ == "ActionModule"

# Generated at 2022-06-21 02:28:16.971538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:33.982510
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class fake_task:

        def __init__(self):
            self.action = 'test'
            self.async_val = False

    class fake_connection:

        def __init__(self):
            self.has_native_async = True

    class fake_self:

        def __init__(self):
            self._task = fake_task()
            self._connection = fake_connection()
            self._supports_check_mode = True
            self._supports_async = True
    
    module = ActionModule()
    module.run = ActionBase.run
    module._execute_module = ActionBase._execute_module
    module._remove_tmp_path = ActionBase._remove_tmp_path

    result = module.run(fake_self())
    assert result == {}

# Generated at 2022-06-21 02:28:46.676012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    from ansible.module_utils.facts.system.distribution import Distribution

    from ansible.plugins.action.normal import ActionModule

    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactRetriever
    from ansible.module_utils.facts.utils import get_file_content

    # Create a distribution object
    # source: https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/system/distribution.py#L202
    distribution_obj = Distribution()
    distribution_obj.name = 'Ubuntu'

    # Create a DistributionFactRetriever object
    # source: https://github.com/ansible/ansible/blob/devel/lib/ans

# Generated at 2022-06-21 02:28:58.384256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible_mikrotik.inventory import Host
    from ansible_mikrotik.plugins.connection.mikrotik import Connection
    from ansible_mikrotik.modules import ActionModule

    host = Host(name='router', port=8728)
    connection = Connection(host)
    action_module = ActionModule(connection)

    assert action_module is not None
    print("ActionModule unit test 1: OK")

    # test if the ActionModule class object has these methods
    assert hasattr(action_module, 'run')
    assert hasattr(ActionModule, '_execute_module')
    assert hasattr(ActionModule, '_remove_tmp_path')
    print("ActionModule unit test 2: OK")

#test_ActionModule()

# Generated at 2022-06-21 02:29:00.444925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None

# Generated at 2022-06-21 02:29:02.040117
# Unit test for constructor of class ActionModule
def test_ActionModule():
	mod = ActionModule("task")
	assert mod

# Generated at 2022-06-21 02:29:10.420939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = MockTask()
    mock_task.async_val = False
    mock_task.action = "some_action"
    mock_connection = MockConnection()
    mock_actionbase = MockActionBase(mock_task, mock_connection)
    assert mock_actionbase.run(tmp=None, task_vars=None) == "result3"

    mock_task = MockTask()
    mock_task.async_val = True
    mock_task.action = "some_action"
    mock_connection = MockConnection()
    mock_actionbase = MockActionBase(mock_task, mock_connection)
    assert mock_actionbase.run(tmp=None, task_vars=None) == "result4"

    mock_task = MockTask()
    mock_task.async_val = True


# Generated at 2022-06-21 02:29:12.940260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 02:29:16.051387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    BaseAction = ActionModule()
    assert BaseAction is not None

# Generated at 2022-06-21 02:29:21.815071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action = ActionModule()
    except NameError:
        # expected, since ActionModule isn't a real class
        assert True
    except ImportError:
        # expected, since ActionModule isn't a real class
        assert True
    else:
        assert False

# Generated at 2022-06-21 02:29:23.573121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:29:42.838188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = mock.Mock()
    runner = mock.Mock()
    task = mock.Mock()
    tmp = 'tmp'
    task_vars = {'tvar1': 'tv1', 'tvar2': 'tv2'}
    action = ActionModule(connection, runner, task, tmp, task_vars)
    assert connection == action._connection
    assert runner == action._runner
    assert task == action._task
    assert tmp == action._task.tmp
    assert task_vars == action.task_vars

# Generated at 2022-06-21 02:29:43.608052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:44.433006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:45.761556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-21 02:29:46.580071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:52.707264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.normal
    import ansible.playbook.task
    import ansible.utils.vars
    action = ansible.plugins.action.normal.ActionModule(ansible.playbook.task.Task(None, None))
    assert action.run(None, None) == {}
    assert action.run(tmp="test1", task_vars={"test": "test2"}) == {}
    assert type(action.run(tmp="test1", task_vars={"test": "test2"})) == ansible.utils.vars.CombinedDict


# Generated at 2022-06-21 02:29:54.245283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(False)

# Generated at 2022-06-21 02:30:00.398544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor sets these variables
    action_module = ActionModule(
        task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True


# Generated at 2022-06-21 02:30:12.442039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    context.CLIARGS = {}
    context._init_global_context()

    inventory = InventoryManager(
        loader=None,
        sources=None,
    )

    variable_manager = VariableManager()

    loader = DataLoader()

    play_context = PlayContext()


# Generated at 2022-06-21 02:30:22.751152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    model = dict(
        async_val = True,
        connection = dict(
            has_native_async = True,
            _shell = dict(tmpdir='/tmp'),
        ),
        action = 'shell',
    )
    m = ActionModule(dict(_task=model))
    m.run(task_vars=dict(ansible_distribution='redhat'))

# Generated at 2022-06-21 02:30:53.885414
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock class
    class MockAnsibleModule:

        def run_command(self):
            return (0, "Success", "Success")

        def load_file_common_arguments(self, params):
            return {'path': '/tmp/test123/'}

    # Mock class
    class MockAnsibleConnection:

        def __init__(self):
            self._shell = MockAnsibleModule()

    # Mock class
    class MockAnsibleTask:

        def __init__(self):
            self.async_val = False

    # Mock class
    class MockAnsibleTaskVars:

        def __init__(self):
            self.params = {
                'path': '/tmp/test123/'
            }

        def get_vars(self):
            return self.params

    #

# Generated at 2022-06-21 02:30:56.555780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None)
    assert action_module is not None

# Generated at 2022-06-21 02:31:04.393459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = MagicMock()

# Generated at 2022-06-21 02:31:05.271362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:31:06.089478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:31:10.811441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This test is only to make sure that ActionModule constructor doesn't throw any exception

    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-21 02:31:13.767868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None)
    assert(a is not None)
    assert(a.get_name() == 'ActionModule')

# Generated at 2022-06-21 02:31:14.575961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:31:18.045115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, tempfile=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-21 02:31:22.135733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print()
    print("Test constructor of class ActionModule")
    action_module = ActionModule()
    print(action_module._supports_check_mode)
    assert action_module._supports_check_mode == True
    print(action_module._supports_async)
    assert action_module._supports_async == True
    print()

# Generated at 2022-06-21 02:32:27.645941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 02:32:38.778552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    yml_data = """
---
- name: action test
  hosts: all
  connection: local
  gather_facts: false

  tasks:
    - name: test
      debug:
        msg: hello world
  """

    task_queue_manager = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
    )
    play_context = task_queue_manager._play_context
    new_stdin = None
    shared

# Generated at 2022-06-21 02:32:50.498406
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import playbook_executor
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Load test variables
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/plugins/action/ansible_inventory.ini'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbooks = [ 'test/unit/plugins/action/test_playbook.yml' ]
    variable_manager.extra_vars = dict(my_var='my_value')
    pbex = PlaybookExec

# Generated at 2022-06-21 02:32:53.831084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:32:55.196398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # command 'unittest' is not yet implemented

# Generated at 2022-06-21 02:32:56.268475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:32:57.154148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:33:09.410741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    setattr(C, 'DEFAULT_MODULE_LANG', 'en')
    setattr(C, 'DEFAULT_REMOTE_TMP', '/tmp/')
    setattr(C, 'DEFAULT_REMOTE_USER', 'john')
    setattr(C, 'DEFAULT_MODULE_PATH', '.')
    setattr(C, 'DEFAULT_SUDO_USER', 'bob')
    setattr(C, 'DEFAULT_SUDO_EXE', '/usr/bin/sudo')
    setattr(C, 'DEFAULT_ASK_SUDO_PASS', False)
    setattr(C, 'DEFAULT_SUDO', False)
    setattr(C, 'DEFAULT_SUDO_PASS', False)
    setattr(C, 'DEFAULT_SU', False)
   

# Generated at 2022-06-21 02:33:14.712116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()

    # TODO: write real tests for this class. Until then, this is a placeholder for
    #       some of the code that existed in the base class.
    # test trivial {'skipped': True} path
    # test self._task.async_val and not self._connection.has_native_async
    # test else: path
    assert True

# Generated at 2022-06-21 02:33:18.442686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    print("Testing ActionModule constructor")
    assert isinstance(m, ActionBase)
    print("Passed")



# Generated at 2022-06-21 02:35:16.236716
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ 
        Test constructor of class ActionModule
    """ 

    # Get initializes ActionModule
    ####################################################

    module = ActionModule()



# Generated at 2022-06-21 02:35:28.053143
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:35:31.077468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

#Unit test for run() of ActionModule class

# Generated at 2022-06-21 02:35:32.417491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule_run")


# Generated at 2022-06-21 02:35:33.777090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cons = ActionModule()
    assert cons is not None

# Generated at 2022-06-21 02:35:40.729030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    @staticmethod
    def execute_module(task_vars, wrap_async):
        if task_vars["skip"] == True:
            return {'skipped': True}
        else:
            return {'invocation': {'module_args': task_vars["args"]}}

    class MockRunner:
        class ActionModule():
            def _execute_module(self, task_vars, wrap_async):
                return execute_module(task_vars, wrap_async)

    class MockConnection:
        # _shell is initialized below
        class _shell:
            class MockTmpdir():
                def __str__(self):
                    return "TestTmpdir"
            tmpdir = MockTmpdir()

        class MockHasNativeAsync():
            def __bool__(self):
                return False

# Generated at 2022-06-21 02:35:49.183966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars import Variable
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.model import Model
    from ansible.executor.stats import AggregateStats
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-21 02:35:53.108894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    my_actionModule = ActionModule(None, None, None, None)
    assert isinstance(my_actionModule, ActionModule)

# Generated at 2022-06-21 02:35:53.937287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:35:56.355776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate class ActionModule()
    action_module = ActionModule(task=None, connection=None, templar=None,loader=None)
    # Assert True to confirm the instantiation
    assert True

