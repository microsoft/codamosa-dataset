

# Generated at 2022-06-21 02:26:44.062431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up values for constructor
    action_base = None
    shared_loader_obj = None
    path_loader_obj = None
    connection_obj = None
    play_context_obj = None
    new_stdin = None
    loader_obj = None
    templar_obj = None
    task_vars = {"key1": "value1", "key2": "value2"}
    tmp = "tmp.txt"
    delegate_to = None
    no_log = None
    run_once = False
    transport = None
    become_method = None
    become_user = None
    become_pass = None
    become_exe = None
    become_flags = None
    become_info = None
    sudo_user = None
    sudo_pass = None
    sudo_exe = None

# Generated at 2022-06-21 02:26:47.339292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct ActionModule object
    #
    #  Passing the 'None' value for `runner` parameter is no longer supported.
    #  The caller should pass a runner object instead.
    am = ActionModule(runner=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:26:48.089055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj != None

# Generated at 2022-06-21 02:26:51.399229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:26:55.087508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = MagicMock()
    am = ActionModule(mock_task, {})
    assert am.run() ==  am._execute_module()

# Generated at 2022-06-21 02:26:59.275066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class K: pass
    class V: pass

    x = ActionModule(K(), V())
    assert x._task == K()
    assert x._connection == V()

# Generated at 2022-06-21 02:27:04.601763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = type('mock_task', (), {'action': C._ACTION_SETUP})
    mock_connection = type('mock_connection', (), {})
    action_module = ActionModule(mock_task, mock_connection)
    assert isinstance(action_module._task, type(mock_task))
    assert isinstance(action_module._connection, type(mock_connection))

# Generated at 2022-06-21 02:27:16.347475
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:27:22.447373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.connection = FakeConnection()
    a.task = FakeTask(name='fake_task')
    a.task.args = dict()
    a.task.action = 'fake_action'
    a.task.async_val = 1
    a.task_vars = dict()
    out = a.run()
    assert out == dict(rc=1)


# Generated at 2022-06-21 02:27:24.329430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:27:37.533726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # the ActionModule test only pass on non-Windows system (due to the 
    # limited capability of unittest.mock on Windows)
    import sys, unittest
    if sys.platform.startswith('win'):
        return
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.action.normal import ActionModule as NormalActionModule
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.executor.task_result import TaskResult

# Generated at 2022-06-21 02:27:46.100719
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockActionBase:
        def run(self):
            return {}

        def _execute_module(self):
            return True

    class MockConnection:
        def has_native_async(self):
            return False

    class MockTask:
        def __init__(self):
            self.async_val = True

    class MockTaskVars:
        def __init__(self):
            self.ansible_facts = {}

    # Setup test data
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module._remove_tmp_path = True
    action_module._remove_tmp_path = True
    action_module._task = MockTask()
    action_module._connection = MockConnection() 

    #

# Generated at 2022-06-21 02:27:53.652110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_task = MockTask()
    m_task.action = 'taction'
    m_task.async_val = 1
    
    if sys.version_info >= (3,0):
        m_task.action = 'taction'
    else:
        m_task.action = unicode('taction', 'utf8')
    m_task.async_val = 1
    
    m_connection = MockConnection()
    m_connection.has_native_async = True
    
    m_action = MockActionModule(vars_files=['/path/to/file.yml'])
    m_action._task = m_task
    m_action._connection = m_connection

    assert m_action.run() == {'results': {'results': 'Successful Mock'}}

# Generated at 2022-06-21 02:27:54.712929
# Unit test for constructor of class ActionModule
def test_ActionModule():
	module = ActionModule()
	assert module is not None

# Generated at 2022-06-21 02:27:55.397530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-21 02:28:03.564924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn_local = {'module_name': 'local', 'module_class': 'Connection', '_play_context': None, '_play': None, '_task': None, '_connection': None, 'port': None, 'host': None, 'remote_user': None, 'remote_pass': None, 'remote_port': None, 'private_key_file': None, 'password': None, 'executable': '', '_shell': None, '_subprocess': None, '_reload_conn': None, '_new_stdin': None, '_shell_type': None}
    obj = ActionModule(conn_local)
    return obj

# Generated at 2022-06-21 02:28:13.109336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a fake ansible module called test_module
    temp_module = dedent('''
    #!/usr/bin/python
    def main():
        import os
        print({"changed": False, "invocation": {"module_name": os.path.basename(__file__)}})
    ''')
    create_module(temp_module)

# Generated at 2022-06-21 02:28:13.580348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:23.306328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = type('MockAnsibleTask', (object,), {'async_val': None, 'action': None, 'always_run': None})()
    mock_shell= type('MockAnsibleShell', (object,), {'tmpdir': None, 'executable': None})()
    mock_connection = type('MockAnsibleConnection', (object,), {'has_native_async':None, '_shell': mock_shell})()
    object = ActionModule(mock_task, mock_connection, None, None)
    assert object is not None

# Generated at 2022-06-21 02:28:24.087548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:36.739113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved

    # test action plugin inherits from ActionBase
    assert issubclass(ActionModule, ActionBase)

    # test action plugin is an instance of ActionBase
    assert isinstance(ActionModule, ActionBase)
    assert isinstance(ActionModule(), ActionBase)

    # test action plugin run method is overridden
    assert ActionModule().run != ActionBase.run

    # test action plugin run method
    assert ActionModule().run() == {}
    assert ActionModule().run(tmp=None, task_vars=HostVars()) == {}
    assert ActionModule().run(tmp=None, task_vars=HostVars(host_specific_var=Reserved(hostvars=True))) == {}

# Generated at 2022-06-21 02:28:47.880210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock
    mock_from_play_context = {}
    mock_from_play_context.accelerate = True
    mock_from_play_context.accelerate_ipv6 = False
    mock_from_play_context.become = False
    mock_from_play_context.become_user = 'root'
    mock_from_play_context.connection = 'local'
    mock_from_play_context.diff = False
    mock_from_play_context.forks = 100
    mock_from_play_context.inventory_hostname = 'localhost'
    mock_from_play_context.local_tmp = '/root/.ansible/tmp'
    mock_from_play_context.module_name = 'ping'

# Generated at 2022-06-21 02:28:53.659766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.action_name = 'action'
    action_module.action_path = 'action_plugins'
    action_module._task_vars = dict()
    action_module._templar = dict()
    action_module._loader = dict()
    action_module._connection = dict()
    action_module._task = dict()
    tmp = 'temp'
    task_vars = dict()
    result = action_module.run(tmp, task_vars)

# Generated at 2022-06-21 02:28:54.137853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:28:55.010289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:29:01.331510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiation testing
    try:
        # Check if object is initialized properly
        obj = ActionModule()
        assert obj
        # Check if class is derived from proper super class
        assert issubclass(ActionModule,ActionBase)
    except Exception as e:
        print("Error in instantiating ActionModule class",e)
        assert False

# Generated at 2022-06-21 02:29:02.202870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-21 02:29:10.546228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils._text import to_bytes
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor import task_result
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from collections import namedtuple, defaultdict
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-21 02:29:12.663042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()

    assert mod is not None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:29:15.150519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 02:29:36.487867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import ansible.utils.vars
    import ansible.plugins.action
    import ansible.plugins.action.standard
    import ansible.utils.vars

    task_vars = {}
    action = ansible.plugins.action.standard.ActionModule()
    action.task = ansible.playbook.task.Task()
    action.task.async_val = 0
    action.task.action = u'setup'
    action.task._role = None
    action.task.args = {}

# Generated at 2022-06-21 02:29:45.676060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.stats import AggregateStats
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import find_action_plugin
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host

    display = Display()
    display.verbosity = 3

# Generated at 2022-06-21 02:29:54.936224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeConn(object):
        def __init__(self):
            self.has_native_async = None

        def __init__(self, *args, **kwargs):
            self.has_native_async = None

    class FakeTask(object):
        def __init__(self, *args, **kwargs):
            self.action = "fake action"
            self.async_val = None
            self.async_seconds = "fake async seconds"

    class FakePlay(object):
        def __init__(self, *args, **kwargs):
            self.tasks = []

    class FakePlaybook(object):
        def __init__(self, *args, **kwargs):
            self.become_method = "fake become method"


# Generated at 2022-06-21 02:29:55.751498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:30:04.830973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    module = sys.modules[__name__]

    task = {"action": {
            "__ansible_module__": "test",
            "__ansible_arguments__": "test",
            "__ansible_version__": "test",
            }
    }

    task_vars = {"test": "test"}

    plugin = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test when skipped and no module args
    task["action"]["__ansible_no_log__"] = "test"
    result = plugin.run(task_vars=task_vars, tmp=None)
    del task["action"]["__ansible_no_log__"]


# Generated at 2022-06-21 02:30:06.252970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 02:30:07.073639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:30:09.864847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:30:21.625184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	def _conn_exec_command(cmd, tmp=None, task_vars=None, wrap_async=False):
		print('_conn_exec_command: ' + str(cmd))
		result = super(ActionModule, self).run(tmp, task_vars)
		del tmp  # tmp no longer has any effect
		if not result.get('skipped'):
			if result.get('invocation', {}).get('module_args'):
				# avoid passing to modules in case of no_log
				# should not be set anymore but here for backwards compatibility
				del result['invocation']['module_args']
			# do work!

# Generated at 2022-06-21 02:30:30.665276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\nTest Case 1: Specific module")
    m = ActionModule(
        task = {'action': 'ping'},
        connection = 'local',
        play_context = {},
        loader = 'Loaded',
        templar = 'Templar',
        shared_loader_obj = None
    )

    print("\nTest Case 2: Generic module without parameters")
    m = ActionModule(
        task = {'action': 'copy', 'copy': 'ping'},
        connection = 'local',
        play_context = {},
        loader = 'Loaded',
        templar = 'Templar',
        shared_loader_obj = None
    )

    print("\nTest Case 3: Generic module with parameters")

# Generated at 2022-06-21 02:30:58.244646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    #super(ActionModule,self).run(tmp=None, task_vars=None)

    a = ansible.plugins.action.ActionModule(None, {}, None)
    a.run(None, None)
    a.run_safely(None, None, None)

# Generated at 2022-06-21 02:30:59.505158
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # FIXME: More test cases to be added
    pass

# Generated at 2022-06-21 02:31:01.024849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule() is not None

# Generated at 2022-06-21 02:31:09.405375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    testmodule = {'ANSIBLE_MODULE_ARGS': {'name': 'test'}}
    module = ActionModule()
    result = module.run(task_vars = {}, tmp = testmodule)
    print(result)
    assert 'greeting' in result['invocation']
    assert result['invocation']['module_name'] == "debug"
    assert result['invocation']['name'] == "test"


# Generated at 2022-06-21 02:31:10.747875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(0)



# Generated at 2022-06-21 02:31:20.604718
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class Mod():
        pass
    module_name = "test_module"
    args = dict(a=1)

    m = Mod()
    m.async_val = 1
    m.module_name = module_name
    m.module_args = args

    class T():
        def __init__(self):
            self.action = 'test_action'
            self.async_val = 1

    task = T()
    task.async_val = 1
    task.module_name = module_name
    task.module_args = args


    class M():
        def __init__(self):
            self.task = task
            self.task_vars = dict()

    m = M()

# Generated at 2022-06-21 02:31:28.900295
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:31:31.635454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    s = 'ECHO "hello world"'
    a = ActionModule(s)
    assert a.value == s

# Generated at 2022-06-21 02:31:32.425051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:31:41.826030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    try:
        from unittest import mock
    except ImportError:
        import mock
    import os
    import shutil
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    class Options:
        connection = 'ssh'
        module_path = ''
        forks = 10
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False

    class MyTask(object):
        def __init__(self):
            self.name = 'test_task'
            self.action = 'setup'
            self.async_val = 43200


# Generated at 2022-06-21 02:32:47.833217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_object = ActionModule()
    
    assert action_module_run_object != None

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:32:48.630073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:32:59.773951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_warnings

    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    from ansible.plugins.action import ActionModule

    mock_loader = DictDataLoader({
        "test_action.yml": """
- name: test_action
  connection: local
  hosts: localhost
  gather_facts: false
  tasks:
    - debug:
        msg: hello
""",
    })

    mock_inventory = HostVars(loader=mock_loader, variable_manager=VariableManager())

# Generated at 2022-06-21 02:33:02.218766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor test
    """
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-21 02:33:03.185856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:33:10.852897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import __builtin__
    from ansible.utils.vars import merge_hash
    from ansible.plugins.action.normal import ActionModule

    class ShellModule:
        def _execute_module(self, *args, **kwargs):
            return {
                'stdout': 'this is the standard output from the shell module',
                'stderr': 'this is the standard error from the shell module',
                'parsed': 'this is the parsed output from the shell modul',
                'rc': 0
            }

    shell = ShellModule()


# Generated at 2022-06-21 02:33:19.500909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Replaces module import
    class Connection(object):
        class conn_class(object):
            def has_native_async(self):
                return True

        def __init__(self, *args, **kwargs):
            self.conn = self.conn_class(*args, **kwargs)

        def has_native_async(self):
            return self.conn.has_native_async()

    class Task(object):
        invoked_by_cli = False
        async_val = 2
        action = 'setup'
        action_copying = 'setup'

        def __init__(self, *args, **kwargs):
            self._connection = Connection()


    class ActionBase(object):
        def run(self, tmp=None, task_vars=None):
            return {'skipped': True}

# Generated at 2022-06-21 02:33:28.271274
# Unit test for constructor of class ActionModule
def test_ActionModule():
	o = ActionModule(connection='ssh', shell='shell', async_val='-1', module_name='action', module_args={'a': 'b'}, task_vars={'a': 'b'})
	assert o.connection == 'ssh'
	assert o.shell == 'shell'
	assert o.async_timeout == '-1'
	assert o.module_name == 'action'
	assert o._task.action == 'action'
	assert o._task.args == {'a': 'b'}
	assert o.task_vars == {'a': 'b'}



# Generated at 2022-06-21 02:33:29.662284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:33:30.966756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The constructor of ActionModule class is called.
    class_action_module = ActionModule(task=dict(), connection=dict(),
            play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

# Generated at 2022-06-21 02:35:38.531178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for ActionModule run method"""
    # The following variables are a representation of the arguments passed to the ansible-playbook
    # For now we are passing empty values as we do not need that in this test
    # The 'task' and the 'connection' are mock objects as we do not need that in this test
    task_vars = dict()
    result = dict()
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Calling the method under test
    res = module.run(task_vars=task_vars, tmp=None, result=result)

    # Asserting the return value of the method
    assert res is not None
    assert res["skipped"] is False

# Generated at 2022-06-21 02:35:39.832789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:35:47.977853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        def _execute_module(self, task_vars=None, wrap_async=False):
            return dict(changed=True, msg="Executing module")

    task = dict(action=dict(module="test"), async_val=42)
    task_vars = dict()
    connection = "mock"
    m = TestActionModule(task, connection, play_context=dict(), loader=None, shared_loader_obj=None, final_q=None)
    assert m.run(task_vars=task_vars) == dict(changed=True, msg="Executing module")

# Generated at 2022-06-21 02:35:50.308599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a1 = ActionModule({}, {}).run(None, None)
    assert(a1 == None)

# Generated at 2022-06-21 02:35:52.097043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-21 02:35:59.721950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an empty result dictionary
    result = {}

    # Create a empty dictionary of task vars
    task_vars = {}

    # Create a empty list of args
    args = []
    
    # Define a module_name for module
    module_name = 'ping'

    # Call a run method of class ActionModule
    result = action_module.run(task_vars=task_vars, args=args, module_name=module_name)

    # Assertion for class ActionModule's method run
    assert isinstance(result, dict) is True
    assert 'invocation' in result
    assert 'module_name' in result['invocation']
    assert result['invocation']['module_name'] == 'ping'

# Generated at 2022-06-21 02:36:00.222053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule("","","")

# Generated at 2022-06-21 02:36:05.266849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct class object
    actionModule = ActionModule()
    # pass in test variables
    result = actionModule.run(task_vars = {'test_var': 'test_value'})

    # assert if test fails
    assert result['test_var'] == 'test_value'

# Generated at 2022-06-21 02:36:17.198250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'localhost'
    connection = None
    new_stdin = 'new_stdin'
    task = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    action_module = ActionModule(host, connection, new_stdin, task, play_context, loader, templar, shared_loader_obj)
    assert action_module is not None
    assert action_module._task is None
    assert action_module._play_context is None
    assert action_module._shared_loader_obj is None
    assert action_module._new_stdin == new_stdin
    assert action_module._templar == templar
    assert action_module._connection == connection
    assert action_module._loader == loader
    assert action_module._host == host


# Generated at 2022-06-21 02:36:28.225364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.result import ResultProcessor
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    actionm = ActionModule(task=Task(), connection='local', play=Play().load({'name': 'test_play', 'hosts': 'localhost', 'gather_facts': 'no'}, variable_manager=None, loader=None))
    actionm._supports_check_mode = True
    actionm._supports_async = False
    actionm._shared_loader_obj = None
    actionm._task._role = None