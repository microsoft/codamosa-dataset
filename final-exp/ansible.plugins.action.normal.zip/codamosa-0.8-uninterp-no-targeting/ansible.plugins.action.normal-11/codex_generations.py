

# Generated at 2022-06-21 02:26:36.957427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:26:37.752309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ast = ActionModule()

# Generated at 2022-06-21 02:26:40.905104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    action = ActionModule()
    assert action._task.async_val is None

# Generated at 2022-06-21 02:26:46.016204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.connection.connection_loader import ConnectionLoader
    from ansible.plugins.action.action_loader import ActionLoader
    from ansible.errors import AnsibleParserError

    class TestCallbackModule(CallbackBase):
        """
        Callback plugin for unit tests
        """
        def __init__(self, *args, **kwargs):
            super(TestCallbackModule, self).__init__(*args, **kwargs)

            self.notified = False
           

# Generated at 2022-06-21 02:26:55.246233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    stdout_mock = ["{u'changed': False, u'ping': u'pong'}"]
    subprocess_mock = Mock(**{'Popen.communicate.return_value': ('STDOUT', 'STDERR')})
    subprocess_mock.Popen().returncode = 0
    module_definition_mock = Mock()

    tmp_path_mock = Mock(**{'write.return_value':'1'})
    task_vars_mock = {'_ansible_module_name':'setup'}
    result_mock = {'invocation': {"module_args": "boot"}}

    action_module = ActionModule(subprocess_mock, tmp_path_mock, task_vars_mock)
    action_module.module_definition = module_definition_mock



# Generated at 2022-06-21 02:26:56.136522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: test for ActionModule.run
    assert True

# Generated at 2022-06-21 02:26:57.004975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:27:06.993711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import default_collectors

    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module._task = ActionModule()
    action_module._task.async_val = 1

    mock_module = type('ActionModule', (object,), {})
    mock_module_attrs = {
        'params': {},
        'USER': 'root'
    }
    mock_module = type('MockModule', (mock_module,), mock_module_attrs)

    action_module._connection = type('ActionModule', (object,), {'has_native_async': False})

    action_module._connection._shell = type

# Generated at 2022-06-21 02:27:07.873407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:27:08.733107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  0==0

# Generated at 2022-06-21 02:27:15.837993
# Unit test for constructor of class ActionModule
def test_ActionModule():

	# Import required modules
	from ansible.playbook.task import Task
	from ansible.playbook.play_context import PlayContext

	module = ActionModule()

	play_context = PlayContext()
	task = Task()
	task_vars = {}

	result = module.run(task_vars=task_vars)

	print("\nResult:\n{}".format(result))


if __name__ == '__main__':

	test_ActionModule()

# Generated at 2022-06-21 02:27:23.722528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import VariableManager
    from ansible.inventory.host import Host

# Generated at 2022-06-21 02:27:26.212753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert('_supports_check_mode' in am.__dict__)
    assert('_supports_async' in am.__dict__)

# Generated at 2022-06-21 02:27:38.019222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import mock
    import __builtin__
    import os.path

    mock_display = mock.MagicMock()

    class MockAnsibleModule:
        def __init__(self):
            self.params = None

        def fail_json(self, *args, **kwargs):
            print('Module failed: %s' % args[0])

    # sys.modules may contain C, so we can't use it
    sys.modules['ansible'] = __builtin__.__import__('ansible')
    sys.modules['ansible.plugins.action'] = __builtin__.__import__('ansible.plugins.action')
    sys.modules['ansible.plugins.action.ActionBase'] = __builtin__.__import__('ansible.plugins.action.ActionBase')

# Generated at 2022-06-21 02:27:40.521700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dm = ActionModule(task=dict(action=dict(module_name='shell')))
    assert dm
    assert hasattr(dm, '_supports_check_mode')
    assert hasattr(dm, '_supports_async')

# Generated at 2022-06-21 02:27:50.725951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock task
    mock_task = type("MockTask", (object,), {})
    mock_task.async_val = None
    # Mock connection
    mock_connection = type("MockConnection", (object,), {})
    mock_connection.has_native_async = False
    module = ActionModule()
    module._task = mock_task
    module._connection = mock_connection
    result = module.run()
    assert result == {'failed': True, 'msg': 'invalid invocation of the setup module'}

# Generated at 2022-06-21 02:27:52.601312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-21 02:28:01.427721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test constructor of ActionModule")
    # Create task
    task = {
        'action': {
        }
    }
    # Create task loader
    task_loader = False
    # Create connection
    connection = True
    # Create play context
    play_context = False
    # Create ansible templar
    templar = False
    # Create shared plugin loader
    shared_loader = False
    # Create loader
    loader = False

    action_module_instance = ActionModule(task, connection, play_context, templar, loader, shared_loader)
    assert action_module_instance is not None, "Test constructor of ActionModule, failed!"



# Generated at 2022-06-21 02:28:12.523689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock objects used to run the test
    task_vars = {}
    tmp = ''

# Generated at 2022-06-21 02:28:14.625219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module
    assert not action_module._supports_async
    assert not action_module._supports_check_mode

# Generated at 2022-06-21 02:28:21.388712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am is not None

# Generated at 2022-06-21 02:28:27.200840
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule()

    # Set fixture data
    module_args = {}
    tmp = "tmp"
    task_vars = ['vars']

    # Call method under test and verify result
    result = action.run(tmp, task_vars)

    assert result == {}

# Generated at 2022-06-21 02:28:31.107152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-21 02:28:37.512307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task_i=dict(), connection_i=dict(), play_context_i=dict(), loader_i=dict(), templar_i=dict(), shared_loader_i=dict())
    assert isinstance(action_module, ActionModule)
    print("ActionModule created successfully")

# Generated at 2022-06-21 02:28:39.557585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # idempotence test
    assert ActionModule._execute_module.im_func == ActionModule._execute_module.__func__

# test idempotence of the _execute module method for class ActionModule

# Generated at 2022-06-21 02:28:43.659855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Make sure that ActionModule.run() is a generator
    result = action_module.run(tmp=None, task_vars=None)
    answer = next(result)
    assert isinstance(answer, dict)

# Generated at 2022-06-21 02:28:44.482800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:28:45.321952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:28:48.371564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import constants as C
    assert C.DEFAULT_MODULE_PATH == ['/usr/share/ansible/', '/etc/ansible/']

# Generated at 2022-06-21 02:28:53.729531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(
        task=dict(action='AnyAction', async_val=0, delegate_to='127.0.0.1'),
        connection=dict(transport='local'),
        play_context=dict(remote_addr='127.0.0.1'),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None)
    from ansible.playbook.task import Task
    assert isinstance(a._task, Task)
    assert a._supports_async is True

# Generated at 2022-06-21 02:29:04.787202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:12.316234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import units.modules.utils.module_runner
    import units.modules.utils.module_runner_action
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.vars import ansible_module_args
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult

    args = ansible_module_args
    args.update(dict(ANSIBLE_MODULE_ARGS={'foo': 'bar'}))
    runner = units.modules.utils.module_runner.ModuleRunner(args, units.modules.utils.module_runner_action.ActionModule())

    pc = PlayContext()
    runner._task.update(ansible_module_args)
    runner

# Generated at 2022-06-21 02:29:25.372194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test constructor of class ActionModule"""
    # Test when ansible.cfg sets action_plugins to a non-existing directory
    action_plugin_dir = "/some/impossible/dir/that/will/never/ever/exist"
    action_plugins = 'action_plugins'
    C.config.set_constant('DEFAULT_ACTION_PLUGIN_PATH', action_plugin_dir)
    action_loader = ActionModule()
    assert action_loader._action_plugins == action_plugin_dir

    # Test when ansible.cfg sets action_plugins to an existing directory
    action_plugin_dir = './lib/ansible/plugins/action'
    C.config.set_constant('DEFAULT_ACTION_PLUGIN_PATH', action_plugin_dir)
    action_loader = ActionModule()
    assert action_loader._action

# Generated at 2022-06-21 02:29:26.674404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: test_ActionModule_run
    pass

# Generated at 2022-06-21 02:29:36.486525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Initialization
    object_run = ActionModule.run
    object_task = object_task()
    object_task.action = "setup"
    object_task.async_val = 123
    object_task.__dict__ = {"_delegate_to": "localhost", "action": "setup", "async": 123, "_role": None}
    object_connection = object_connection()
    object_connection.has_native_async = True
    object_run._task = object_task
    object_run._connection = object_connection
    tmp = None
    task_vars = None
    
    # Running of method run
    result = object_run(tmp, task_vars)

    # Assertion
    assert result == result

# Generated at 2022-06-21 02:29:37.830107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert(not module._supports_check_mode)
    assert(not module._supports_async)



# Generated at 2022-06-21 02:29:49.845263
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        import ansible.plugins.action.__init__
        from ansible.plugins.action.__init__ import ActionModule
    except:
        import sys
        import traceback
        exc_info = sys.exc_info()
    else:
        # class constructor test
        obj = ActionModule(None, None)
        print(obj)

        # instance variable test
        if hasattr(obj, "task") and isinstance(obj.task, object):
            print(obj.task)
        if hasattr(obj, "connection") and isinstance(obj.connection, object):
            print(obj.connection)
        if hasattr(obj, "shell") and isinstance(obj.shell, object):
            print(obj.shell)

        # instance method test

# Generated at 2022-06-21 02:29:55.142168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an action module object
    action_module_object = ActionModule()
    # Create a task object
    task_object = TestTask()
    # Create a connection object
    connection_object = TestConnection()
    # make a temporary directory
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Execute the run function of class ActionModule
    action_module_object.run(tmp=tmpdir, task_vars=(task_object, connection_object))


# Generated at 2022-06-21 02:30:04.613984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = 'fake_host'
    hostvars = {'fake_host': 'fake_host_vars'}
    module_name = 'fake_module_name'
    module_args = {'fake_module_arg': 'fake_module_arg_value'}
    task_vars = {
        'ansible_version': 'fake_version',
        'ansible_module_name': 'fake_module',
        'ansible_module_args': {'fake_module_arg': 'fake_module_arg_value'},
        'ansible_check_mode': 'fake_check_mode',
        'ansible_verbosity': 'fake_verbosity',
        'ansible_diff': 'fake_diff',
        'ansible_connection': 'fake_connection',
    }
    wrap_async = False

# Generated at 2022-06-21 02:30:13.037728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_result = {}
    module_args = {}
    task_vars = {}
    tmp = {}
    result = {}
    action = ActionModule()
    action.task_vars = task_vars
    action._task = task_result
    action._supports_check_mode = True
    action._supports_async = True
    action._connection = module_args
    action.wrap_async = tmp
    result = action.run(tmp, task_vars)
    assert result['invocation'] == {'module_name': 'setup'}
    assert result['invocation']['module_args']['filter'] == '*'

# Generated at 2022-06-21 02:30:39.436244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_name = 'hostname'
    controller = setup_controller_mock({'hostname': 'hostname'})
    remote_user = 'remote_user'
    connection = Connection(controller, host_name, remote_user)
    task = Task()
    action_module = ActionModule(task, connection, play_context=PlayContext())
    result = action_module.run()
    assert result == {'host_name': 'hostname', 'invocation': {'module_args': '', 'module_name': 'setup'}}
    assert result['invocation']['module_name'] == 'setup'

# Generated at 2022-06-21 02:30:44.002433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Create a new instance of ActionModule
    test_obj = ActionModule()

    #TODO: Unit test this method
    try:
        test_obj.run()
    except Exception as err:
        assert False, err.args

# Generated at 2022-06-21 02:30:45.895525
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test that run method returns expected result
    assert True == True

# Generated at 2022-06-21 02:30:55.232468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method ActionModule.run defined in Class ActionModule.
    """
    import os
    import types
    import unittest
    import imp

    # Module to test
    module = imp.load_source(
        'ansible.plugins.action.action_plugin',
        os.path.join(os.path.dirname(__file__), '../../../../../plugins/action/action.py')
    )

    # Test class
    class TestActionModule(unittest.TestCase):
        """
        Test class for ActionModule
        """
        def setUp(self):
            """
            Test action module setup
            """
            self.action_module = module.ActionModule(
                'setup',
                'root',
                {},
            )


# Generated at 2022-06-21 02:30:58.087888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    a = ansible.plugins.action.ActionModule(None, None)
    assert isinstance(a, ansible.plugins.action.ActionBase)

# Generated at 2022-06-21 02:30:59.382317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(load_patched_ansible_module=True)

# Generated at 2022-06-21 02:31:00.287714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:31:04.221644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a1 = ActionModule()
    assert a1._supports_check_mode == True
    assert a1._supports_async == True

# Generated at 2022-06-21 02:31:13.595254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = {'name': 'testhost'}
    hostname = 'testhost'
    task = {'action': 'testaction'}
    play_context = {'play_hosts': ['testhost']}
    connection_info = {'user': 'testuser', 'password': 'testpassword'}
    new_stdin = None
    connection = {}
    play = {}
    loader = {}
    templar = {}
    shared_loader_obj = {}
    action_plugin = ActionModule(host, hostname, task, play_context, connection_info, new_stdin, connection, play, loader, templar, shared_loader_obj)
    assert action_plugin.connection._connection_info == connection_info
    assert action_plugin.connection._task == task
    assert action_plugin.connection._task_vars

# Generated at 2022-06-21 02:31:15.070101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the ActionModule class so that we can use the run method
    actionModule = ActionModule()




# Generated at 2022-06-21 02:32:15.761079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:32:18.183874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = {}
    
    #test_actionmodule = ActionModule(tmp, task_vars)

#test_actionmodule = ActionModule()
#test_actionmodule.run()

#test_ActionModule()

# Generated at 2022-06-21 02:32:22.531768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    This function tests the method run of class ActionModule
    '''
    print('Testing method run of class ActionModule')
    mod = ActionModule()


# Generated at 2022-06-21 02:32:23.538873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:32:32.254528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host

    pc = PlayContext()
    task_queue_manager = TaskQueueManager(pc, lambda x: TaskResult(host=x, task=pc.task), hosts=[Host()], inventory=None)

    pc.module_name = 'action'
    pc.module_args = 'action'
    pc.task = 'task'
    pc.remote_addr = 'remote_addr'

    action = ActionModule()
    action._supports_check_mode = True
    action._supports_async = True

    action._task_queue_manager = task_queue_manager

# Generated at 2022-06-21 02:32:40.310096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize ActionModule object
    am = ActionModule()
    am._supports_check_mode = True
    am._supports_async = True
    am._connection = "test"
    task_vars = {
        "host_user": "test_user",
        "host_key_checking" : "0",
        "ansible_verbosity" : "0",
        "ansible_port" : "22",
        "host": "test"
    }
    # Call run method of ActionModule object.
    result = am.run(tmp=None, task_vars=task_vars)
    assert result["failed"] == True
    # Check the values of variables
    assert result["invocation"]["module_name"] == "setup"
    assert result["invocation"]["module_args"] == ''

# Generated at 2022-06-21 02:32:41.844125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:32:46.110235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:32:47.036637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 02:32:47.762161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:34:30.894118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of class ActionModule
    a = ActionModule({})
    # Call run method
    a.run()

# Generated at 2022-06-21 02:34:31.694271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:34:32.103674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:34:35.265347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._task.action == 'action'
    assert am._supports_check_mode is True
    assert am._supports_async is True

# Generated at 2022-06-21 02:34:35.970433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-21 02:34:38.670744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleTestClass(ActionModule):
        pass

    atc = ActionModuleTestClass()
    assert atc is not None

# Generated at 2022-06-21 02:34:40.580319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:34:48.750510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.basic import AnsibleModule

    # Create a task object
    task = Task()
    task._role = None
    task.action = 'setup'
    task.args = dict()
    task.async_val = 1
    task.async_seconds = 0

    # Create a play context object
    play_context = PlayContext()
    play_context.check_mode = True
    play_context.network_os = "ios"
    play_context.remote_addr = "192.0.0.1"
    play_context.remote_user = "fad"

# Generated at 2022-06-21 02:34:49.599936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:34:53.885061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run()")
    act_module = ActionModule()
    task_vars = None
    tmp = None
    act_module.run(tmp=None,task_vars=None)