

# Generated at 2022-06-21 02:26:35.372727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:26:39.272133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_object=None)
    assert m is not None

# Generated at 2022-06-21 02:26:40.637716
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:26:41.944877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    # FUTURE: write a test for this

# Generated at 2022-06-21 02:26:51.850403
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:26:58.629311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert type(a) == ActionModule
    assert hasattr(a, '_supports_check_mode')
    assert hasattr(a, '_supports_async')
    assert hasattr(a, '_task')
    assert hasattr(a, '_connection')
    assert hasattr(a, '_play_context')
    assert hasattr(a, '_loader')
    assert hasattr(a, '_shared_loader_obj')
    assert hasattr(a, '_final_q')
    assert hasattr(a, '_ds')
    assert hasattr(a, '_tmp')
    assert hasattr(a, '_templar')
    assert hasattr(a, '_loader')
    assert hasattr(a, '_display')

# Generated at 2022-06-21 02:27:01.098293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module =  ActionModule()
    action_module.run()
        

# Generated at 2022-06-21 02:27:04.211879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(0,0,0,0)
    assert(action_module)

# Generated at 2022-06-21 02:27:05.627198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	module = ActionModule()
	print("Unit test end")

# Generated at 2022-06-21 02:27:06.486037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return 0

# Generated at 2022-06-21 02:27:11.950086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO:
    ActionModule_instance = ActionModule()
    assert(ActionModule_instance.run()==1)

# Generated at 2022-06-21 02:27:16.667107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.__doc__ == 'runs a module'
    assert ActionModule.run.__name__ == 'run'
    assert ActionModule.run.__doc__ == 'runs a module'

# Generated at 2022-06-21 02:27:17.254960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:27:19.657306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    assert ActionModule(task='', connection='', tmp='', runner_one='', loader='')

# Generated at 2022-06-21 02:27:23.330233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
        Unit test for method run of class ActionModule
    """
    module = ActionModule()
    module._supports_check_mode = True
    module._supports_async = True
    result = module.run(tmp=None, task_vars=None)
    assert  result['changed']

# Generated at 2022-06-21 02:27:33.632374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule class
    action_module = ActionModule()

    # Create an instance of ActionBase class
    action_base = ActionBase()

    # Create an instance of AnsibleOptions class
    options = AnsibleOptions()

    # Create an instance of PlayContext class
    play_context = PlayContext()

    # Create an instance of TaskExecutor class
    task_executor = TaskExecutor()

    # Set value for attribute task_executor of object action_module
    action_module.task_executor = task_executor

    # Create an instance of SocketConnection class
    socket_connection = SocketConnection()

    # Set attribute prompt of object socket_connection
    socket_connection.prompt = 'ssh-mod-prompt'

    # Create an instance of SSH class
    ssh = SSH()

    # Set attributes of object ssh:

# Generated at 2022-06-21 02:27:35.431186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:27:44.811340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Temporary unit test, need to be removed after switch to pytest
    '''
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    assert action_module.SYSLOG_FACILITY == 0
    assert action_module.SYSLOG_IDENTIFIER == 0

    assert action_module.get_bin_path('test_module') == 'test_module'

    assert action_module.transport == 'local'

    assert action_module.SUPPORTED_FILTER_PLUGINS == ['convert_bash_to_ansible', 'convert_config_to_ansible']

    assert action_module.SUPPORTED_CALLBACK_PLUGINS == []


# Generated at 2022-06-21 02:27:55.067458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile
    from ansible.plugins.action.normal import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])

    current_dir = os.getcwd()
    variable_manager.set_inventory(inventory)

    p = tempfile._mktemp(dir=current_dir)
    with open(p, 'a') as f:
        f.write("""
        [localhost]
        localhost
        """)


# Generated at 2022-06-21 02:27:55.593530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("ActionModule")

# Generated at 2022-06-21 02:28:03.892466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None


# Generated at 2022-06-21 02:28:13.266282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    start_time = time.time()
    print("Starting Time for testing ActionModule.run(): %s" % start_time)
    thisdict = dict()
    thisdict["text"] = "testing Action.run"
    thisdict["_ansible_verbose_override"] = True
    thisdict["_ansible_verbose_always"] = True
    thisdict["_ansible_no_log"] = False
    thisdict["_ansible_debug"] = False
    thisdict["_ansible_debug_topics"] = ""
    thisdict["_ansible_ignore_errors"] = False
    thisdict["_ansible_action_timer"] = 0
    thisdict["_ansible_internal_poll_interval"] = True
    thisdict["_ansible_no_log"] = False

# Generated at 2022-06-21 02:28:23.306040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task = Task()

    passing_data = {'a': 1, 'b': 2}

    obj = ActionModule(task, variable_manager=variable_manager)
    ret = obj._execute_module(passing_data, wrap_async=True)
    assert(ret['failed'] == True)

# Generated at 2022-06-21 02:28:24.150740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(True)

# Generated at 2022-06-21 02:28:34.838876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock action path
    import os
    import sys
    from os import path
    from ansible.utils.display import Display

    display = Display()
    class MockActionPlugin(ActionModule):
        def __init__(self, display=display, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None):
            self._display = display
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj
            self.plugin_name = "test_plugin"

        def _execute_module(self, task_vars=None, wrap_async=False):
            mock_

# Generated at 2022-06-21 02:28:40.968538
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create a action module object for testing
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # unit test for method run of class ActionModule
    am.run()
    assert True

# Generated at 2022-06-21 02:28:42.187266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert (isinstance(module, ActionModule))

# Generated at 2022-06-21 02:28:50.723422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    construct_action_module = ActionModule(action_module_name = "debug",
                                           action_module_libs = "./lib",
                                           action_module_path = ".",
                                           action_module_args = {},
                                           action_module_config = {},
                                           connection = "",
                                           task = "",
                                           play_context = "",
                                           loader = "",
                                           templar = "",
                                           shared_loader_object = "")

# Generated at 2022-06-21 02:28:55.387560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None
    assert action_module._supports_async == True
    assert action_module._supports_check_mode == True
    

# Generated at 2022-06-21 02:29:05.187077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import time
    import shutil
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible import errors
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.common.collections import is_sequence
    from ansible.plugins.cache import FactCache
    from ansible.plugins.loader import action_loader

    # Mock OS environment
    temp_dir = tempfile.mkdtemp()
    os.environ['HOME'] = temp_dir
    os.environ['ANSIBLE_CONFIG'] = os.path.join(temp_dir, '.ansible.cfg')

# Generated at 2022-06-21 02:29:17.887446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-21 02:29:20.675890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # WHAT IS THE POINT TO THIS UNIT TEST?
    # It used to test _remove_tmp_path  being called, but that is not being called anymore (it's tested in call_module)
    # It used to test wrap_async but that is always false
    # It used to test wrap_async but wrap_async is not used anymore
    # It used to test wrap_async but wrap_async is not used anymore
    # It used to test wrap_async but wrap_async is not used anymore
    pass

# Generated at 2022-06-21 02:29:28.578813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.vars
    from ansible.utils.vars import AnsibleVars

    from ansible.plugins.action import ActionModule

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import string_types
    from ansible.plugins.action.normal import ActionModule as ActionModule_normal


    # Create the temporary directory
    import tempfile
    tmpdir = tempfile.mkdtemp()

    connection = CONNECTION_FACTORY(CONNECTION_INFO, CONNECTION_PASS)
    loader = MODULE_FACTORY
    templar = TEMPLAR_FACTORY
    play_context = PlayContext()
    play_context.check_mode = False

    tqm = None

# Generated at 2022-06-21 02:29:37.309211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins
    import ansible.utils.vars
    import ansible.utils.template
    import ansible.utils.module_docs

    a = ActionModule(None, None, None, None, None, None, None, None)
    assert a._supports_async == True
    assert a._supports_check_mode == True
    assert a._connection == None
    assert a._task == None
    assert a._loader == None
    assert a._templar == None
    assert a._shared_loader_obj == None
    assert a._play_context == None
    assert a._loaded_by == None
    assert a._task_vars == None
    assert a._target_host == None

    a = ActionModule(None, None, None, None, None, None, None, None)
    assert a._

# Generated at 2022-06-21 02:29:45.944069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import collections
    import sys
    import copy

    test_dir_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "..")
    sys.path.append(test_dir_path)

    from AnsiballZ_action import AnsiballZActionModule
    from test_utils import remove_tmp_path

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.executor import MockConnection

    # DictDataLoader instance

# Generated at 2022-06-21 02:29:47.241755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "TODO: Implement"

# Generated at 2022-06-21 02:29:48.224275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-21 02:29:49.326455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule ()
    print(action_module.__dict__)

# Generated at 2022-06-21 02:29:49.795875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

# Generated at 2022-06-21 02:29:57.091817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import subprocess
    import ansible.playbook.play
    import ansible.playbook.task_include
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager
    from ansible.module_utils.basic import AnsibleModule
    import ansible.constants as C


# Generated at 2022-06-21 02:30:22.175962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:30:32.786067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.plugins.loader import module_loader
    from ansible.utils.display import Display
    display = Display()
    loader = AnsibleLoader(None, True, 'utf-8')
    Options = ({})
    Options['connection'] = 'ssh'
    Options['module_path'] = None

# Generated at 2022-06-21 02:30:33.361024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:30:34.685896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule.run()")
    m = ActionModule()
    # TODO: Add test here
    print("finish test")

# Generated at 2022-06-21 02:30:39.955687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    #test_actionmodule_run=ActionModule()
    #test_actionmodule_run.run()
    #assert result.get('skipped') is True
    #assert result.get('invocation').get('module_args') is False

# Generated at 2022-06-21 02:30:42.291866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionmodule != None


# Generated at 2022-06-21 02:30:52.125892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    from ansible.executor.module_common import ModuleCommon
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleError
    from ansible.utils import vars
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    class FakeTask:
        async_val = None
        async_seconds = None
        action = ''
        def __init__(self):
            self.async_ = 0
            self.async_seconds = 0
        def set_loader(self, loader):
            pass
        def run(self, connection=None, play_context=None, task_vars=None):
            pass

# Generated at 2022-06-21 02:31:02.393209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import ansible.plugins.modules.setup
    import ansible.plugins.actions.setup
    import ansible.plugins.action
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy
    import ansible.utils.plugins
    import ansible.executor.task_result

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    ActionModule = ansible.plugins.action.ActionModule
    ActionBase = ansible.plugins.ActionBase
    SetupModule = ansible.plugins.modules.setup.ActionModule
    SetupAction = ans

# Generated at 2022-06-21 02:31:09.199597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    rd = {
        u'_ansible_parsed': True,
        u'_ansible_no_log': False,
        'invocation': {
            'module_name': 'command',
            'module_args': {
                'chdir': None,
                '_raw_params': 'uptime',
                '_uses_shell': True,
                'creates': None,
                'removes': None,
                'executable': None
            }
        }
    }

# Generated at 2022-06-21 02:31:17.079434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule.run() Test Case
    """

    import ansible.plugins.action

    # Load the module
    module = ansible.plugins.action.ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # Run the run() method
    result = module.run()

    # Check if result is empty
    assert(result == {})

# Generated at 2022-06-21 02:32:26.359401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # will raise an error when failing
    raise NotImplementedError()

# Generated at 2022-06-21 02:32:33.251770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import ansible.plugins.action.action as action
    action.ACTION_BASE_MODULE = 'copy'
    action.DEFAULT_ACTION = 'copy'

    module = action.ActionModule(load_plugins=False, async_poll_delay=10, async_timeout=1000)
    module._gather_facts = 'no'
    module._connection_plugins = None
    module._task = {'async_val': 10, 'action': 'copy', 'args': {'dest': './', 'content': 'Test'}}
    module._task_vars = None
    module._ds = None
    module._shared_loader_obj = None
    module._connection = None
    module._low_level_socket_timeout = 10
    module._templar = 'test'
    module._loader = 'test'

# Generated at 2022-06-21 02:32:34.705010
# Unit test for constructor of class ActionModule
def test_ActionModule():
  x = ActionModule()
  assert x

# Generated at 2022-06-21 02:32:40.901009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext

    from ansible.utils.vars import combine_vars

    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.plugins.connection.local import Connection as LocalConnection
    from ansible.plugins.connection.ssh import Connection as SSHConnection
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.action import ActionModule

    from ansible.utils.display import Display
    display = Display()


# # test setup
#
# PlayContext.CLIARGS = cli_args.parse_cli_args()


# Generated at 2022-06-21 02:32:45.731049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None
    )
    print(am)

# Generated at 2022-06-21 02:32:49.747264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = {'invocation': {'module_args': '{}'}}
    assert not ActionModule(result, {'task_vars': {'ansible_check_mode': False}}).result['_ansible_check_mode']
    assert ActionModule(result, {'task_vars': {'ansible_check_mode': True}}).result['_ansible_check_mode']

# Generated at 2022-06-21 02:32:55.776023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arrange
    task_vars = dict()
    _action_module = ActionModule()

    # Act
    _action_module.run(task_vars=task_vars)

    # Assert
    # TODO: implement some kind of assert
    assert True

# Generated at 2022-06-21 02:33:07.822786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(
        ansible_version=dict(
            full="2.0.0.2-final",
            major=2,
            minor=0,
            revision=0,
            string="2.0.0.2-final"
        ),
        ansible_python_version="2.7.5",
        module_complex_args=dict(
            _raw_params="9999",
            _uses_shell=False,
            _python_interpreter="",
            _ansible_version="2.0.0.2-final",
            param1=1,
            param2=[3,5],
            param3='True',
        ),
    )
    tmp = "/tmp/test_ansible_module.tmp"

# Generated at 2022-06-21 02:33:08.294736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:33:17.185381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = {'host' : 'localhost', 'port' : '22'}
    host = 'testhost'
    task = {}
    connection = {}
    play_context = {}
    shared_loader_obj = {}
    variable_manager = {}
    loader = {}

    action_mod = ActionModule(task, connection, play_context, shared_loader_obj, variable_manager, loader)

    action_mod._task = task
    action_mod._connection = connection
    action_mod._play_context = play_context
    action_mod._loader = loader
    action_mod._templar = None
    action_mod._shared_loader_obj = shared_loader_obj
    action_mod._variable_manager = variable_manager
    action_mod.task_vars = {}

# Generated at 2022-06-21 02:35:19.774092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False, "tests not implemented"

# Generated at 2022-06-21 02:35:28.959511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import ansible.constants as C
    import os
    import sys
    import json
    C.HOST_KEY_CHECKING = False
    C.DEFAULT_HOST_LIST = '/etc/ansible/hosts'
    def get_host_vars(hostname):
        hostVars = HostVars({}, variable_manager)

# Generated at 2022-06-21 02:35:31.412280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True
    # module = ActionModule()
    # assert module.run() == 'hello world'

# Generated at 2022-06-21 02:35:39.976065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import merge_hash
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.file import ActionModule
    #from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import ansible.plugins.loader as plugin_

# Generated at 2022-06-21 02:35:48.951466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    class Connection:
        def has_native_async(self):
            return False
        def _shell(self):
            class Shell:
                tmpdir = ""
            return Shell()
    class Task:
        async_val = False
        action = "test_action"
    class ModuleReturn:
        def __init__(self, module_data):
            self.result = module_data
    class ModuleManager:
        def __init__(self, module_data):
            self.module_data = module_data
            self.results = {}
            self.defaults = {}

# Generated at 2022-06-21 02:35:50.009659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if __name__ == "__main__":
        a = ActionModule()
        assert a is not None

# Generated at 2022-06-21 02:35:54.923521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.__getattribute__('_supports_check_mode')
    assert action.__getattribute__('_supports_async')

# Generated at 2022-06-21 02:36:01.003439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = '{"module_name": "debug", "module_args": {}}'
    x = ActionModule({"task": {"action": {"__ansible_action__": "debug", "module_name": "debug", "module_args": {}}}}, data)

# Generated at 2022-06-21 02:36:08.309459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # This is not a complete test but it should be enough to detect any
    # regression.
    #
    args = {'param':'value'}
    task = Task(action=dict(module='shell', args=args))
    runner = Runner(host_list=['host'], tasks=[task])
    runner._tqm.send_callback = Mock()
    runner._tqm.send_callback.return_value = (True, True)
    connection = Mock()
    connection.shell = Mock()
    connection.shell.run.return_value = (0, '', '', 'No such file or directory')
    runner._connection_cache = { 'host' : connection }

# Generated at 2022-06-21 02:36:09.745387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pm = ActionModule()
    pm.run()