

# Generated at 2022-06-21 02:26:36.513573
# Unit test for constructor of class ActionModule
def test_ActionModule():

    ActionModule()

# Generated at 2022-06-21 02:26:38.147779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None, None, None)


# Test run function of class ActionModule

# Generated at 2022-06-21 02:26:45.379231
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import datetime
    import json
    import os
    import shutil
    import time
    import tempfile

    import pytest

    from ansible.utils.vars import merge_hash

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess

    from ansible import context
    from ansible.plugins.loader import module_loader
    from ansible.plugins.connection.local import Connection as LocalConnection
    from ansible.vars.resolver import populate_facts

    from collections import namedtuple
    from ansible.executor.play_iterator import PlayIterator

    Facts = named

# Generated at 2022-06-21 02:26:46.047606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    assert module is not None

# Generated at 2022-06-21 02:26:47.895269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    acm = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:26:56.388762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from collections import namedtuple
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    Options = namedtuple('Options', ['connection','module_path', 'forks', 'become', 'become_method', 'become_user', 'check'])
    fake_options = Options(connection='local', module_path=None, forks=10, become=None, become_method=None, become_user=None, check=False)
    fake_loader = DataLoader()
    fake

# Generated at 2022-06-21 02:27:02.350088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    class MockModuleLoader():
        def get_basedir(self, path):
            return '/test_ActionModule'

        def get(self, path):
            class MockModule():
                def __init__(self, name):
                    self.name = name
                def run(self):
                    pass
                def __call__(self):
                    pass
            if path == 'test':
                return MockModule(path)
            else:
                raise AnsibleError("{0} is not a valid module".format(path))

    class MockConnection():
        def __init__(self):
            pass

       

# Generated at 2022-06-21 02:27:15.323181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_args = {'key': 'value'}
    action_module = ActionModule()
    action_module._task = MockTask(my_args)
    action_module._connection = MockConnection()
    action_module.run(task_vars={'key': 'value'})
    assert action_module._task.invocation['module_name'] == 'action_module'
    # Below is to check the result dict
    assert action_module.action_results['failed'] == False
    assert action_module.action_results['changed'] == True
    assert action_module.action_results['invocation']['module_name'] == 'action_module'
    assert action_module.action_results['invocation']['module_args'] == my_args

# The following classes are mocks of Ansible classes that are used by the action

# Generated at 2022-06-21 02:27:17.021448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 02:27:25.927411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action

    task_vars = {}
    get_module_path = ansible.plugins.action.ActionModule.get_module_path

    action = ansible.plugins.action.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.run(task_vars=task_vars)

    action = ansible.plugins.action.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action.get_module_path = lambda: None
    assert action.run(task_vars=task_vars)
    action.get_module_path = get_module_path

    action = ansible

# Generated at 2022-06-21 02:27:29.277827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:27:30.669079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:27:31.709631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-21 02:27:40.364932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_loader = unittest.mock.Mock()
    mock_loader.get_basedir.return_value = '/path/to/ansible/library'
    mock_task = unittest.mock.Mock()
    mock_task.async_val = 0
    mock_task.async_val = 0
    mock_task._connection.has_native_async = True
    mock_task.action = 'setup'
    mock_task._connection._shell.tmpdir = 'tmpdir'

    mock_config_manager = unittest.mock.Mock()
    am = ActionModule(mock_loader, mock_config_manager, '/path/to/ansible/library', 'setup.py')
    am._task = mock_task
    am._connection = mock_task._connection
    am._

# Generated at 2022-06-21 02:27:53.046752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task:
        async_val = False
    class Connection:
        has_native_async = False
    class Vars:
        ansible_connection = ""
    class TaskVars:
        hostvars = {}
    class Data:
        _task = Task()
        _connection = Connection()
        _play_context = Vars()
        _task_vars = TaskVars()
        _loader = ""
        def get_vars(self):
            return {}
        def get_vars(self, include_hostvars=False):
            return {}
    d = Data()
    a = ActionModule(d)
    #test tmp
    a.run(tmp='test')
    # test task_vars
    a.run(task_vars = {})


# Generated at 2022-06-21 02:28:02.448196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor

    task_vars = dict()
    play_context = PlayContext()
    task_executor = TaskExecutor()

    module_name = "test_module"
    action_module = ActionModule(task_executor, play_context, module_name, task_vars, tmp='/tmp/test')
    ret = action_module.run(task_vars)
    print("Ret: %s" % ret)

# Generated at 2022-06-21 02:28:11.866600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test ActionModule - run")
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    options = Mock()
    options.module_path = ''
    options.connection = 'smart'
    options.forks = 100
    options.become = None
    options.become_method = None
    options.become_user = None
    options.check = False
    options.diff = False
    options.private_key_file = None
    options.listhosts = None
    options.listtasks = None
    options.listtags = None
    options.syntax = None
    options.verbosity = 0
    play_context = PlayContext()
    play_context.become_

# Generated at 2022-06-21 02:28:21.751792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestClass(ActionModule):
        def __init__(self, a, b, c, d):
            super(TestClass, self).__init__(a,b,c,d)

        def _execute_module(self, **args):
            return {'test': 'success'}

    result = TestClass(None,None,None,None).run(tmp=None, task_vars=None)
    assert result.get('test') == 'success'
    assert result.get('invocation') == None

# Generated at 2022-06-21 02:28:34.110121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.action as action_loader

    # Setup test
    loader = action_loader.ActionModuleLoader()
    plugin = plugin_loader.find_plugin(to_bytes('ping'))
    action_plugin = plugin.get('action_plugin', loader)
    action_plugin.name = to_bytes('ping')
    action_plugin.action = to_bytes('ping')
    action_plugin.task = None
    action_plugin.connection = None
    action_plugin.runner = None
    action_plugin.play = None
    action_plugin._task = None
    action_plugin._templar = None
    action_plugin._loader = None
    action_plugin._shared_loader_obj = None


# Generated at 2022-06-21 02:28:46.763756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import MagicMock
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule

    # Test _$module_options method

# Generated at 2022-06-21 02:29:01.216460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None

    action = ActionModule({
        '_ansible_check_mode': True,
        '_ansible_verbosity': 3,
        '_ansible_debug': True,
        '_ansible_no_log': False,
        '_ansible_diff': False
    })

    # do test
    result = action.run(tmp, task_vars)

    # asserts
    assert result is not None

# Generated at 2022-06-21 02:29:02.545645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 02:29:03.475986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)

# Generated at 2022-06-21 02:29:15.549642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import shutil
    import tempfile
    import unittest

    from ansible import errors
    from ansible.executor import task_executor
    from ansible.plugins.action import ActionBase

    # @todo: this is a hack to get around cyclic import issues
    import ansible.plugins.action.copy

    class TestActionModule(unittest.TestCase):
        def setUp(self):
            self.connection_mock = {}
            self.task_executor_mock = task_executor.TaskExecutor()

        def tearDown(self):
            pass


# Generated at 2022-06-21 02:29:20.684186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule_instance = ActionModule('joe', 'boe')
    assert test_ActionModule_instance._task.action == 'joe'
    assert test_ActionModule_instance._task.args['name'] == 'boe'

# Generated at 2022-06-21 02:29:21.445971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None) is not None

# Generated at 2022-06-21 02:29:24.984834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am is not None
    assert am._supports_check_mode is True
    assert am._supports_async is True

# Generated at 2022-06-21 02:29:28.806141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._task.async_val == 0
    assert a._connection.has_native_async == False
    assert a._task.action == 'setup'

# Generated at 2022-06-21 02:29:31.766197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    output = mod.run()
    assert output == None, 'testActionModuleRun has failed to run'
# Unit test over

# Generated at 2022-06-21 02:29:43.396098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    results = []
    results.append(isinstance(ActionModule(), object))

    inventory = InventoryManager()
    variable_manager = InventoryManager()
    loader = DataLoader()

    host1 = Host('host1')
    host1.set_variable('ansible_connection', 'winrm')
    host1.set_variable('ansible_winrm_server_cert_validation', 'ignore')

# Generated at 2022-06-21 02:29:55.330961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:30:01.526691
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a test action plugin
    class ActionModuleTest(ActionModule):
        # Mock method _execute_module of class ActionModule
        def _execute_module(self, *args, **kwargs):
            return {'skipped': True}

    am = ActionModuleTest(dict(), dict())
    result = am.run()

    # Assert we received a skipped result
    assert result.get('skipped')

# Generated at 2022-06-21 02:30:02.282957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:30:10.195350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(action='setup', async_val=False, async_seconds=0),
        connection=dict(has_native_async=False),
        play_context=dict(check_mode=True, verbosity=0),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert (am.async_sleep_time == 0.001)

# Generated at 2022-06-21 02:30:12.160231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert ActionModule() != None
    except:
        assert False

# Generated at 2022-06-21 02:30:23.563929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    a = ActionModule()
    a._supports_check_mode = True
    a._supports_async = True
    a._connection = None
    a._task = Task()
    a._task._role = None
    a._task._block = None
    a._task._play = Play()
    a._task._play._included_files = {}
    a._task._loader = None
    a._task._role = None
    a._task._block = None
    a._task._play = Play()
    a._task._play._included_files = {}
    a._task.async_val = None
    a._task.action = 'action'
    a._task.args = {}

# Generated at 2022-06-21 02:30:24.915378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert True

# Generated at 2022-06-21 02:30:26.419406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ unit tests for method run of class ActionModule """
    raise NotImplementedError("No unit test implemented for ActionModule.run")

# Generated at 2022-06-21 02:30:27.353876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()

# Generated at 2022-06-21 02:30:29.901212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    print(m.run())

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:30:52.383200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()

# Generated at 2022-06-21 02:31:02.497216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.utils.vars import merge_hash

    def _execute_module(self, tmp=None, task_vars=None, wrap_async=False):
        test_hash = {
            'test_hash_key': 'test_hash_value',
            'test_hash_key2': 'test_hash_value2',
            'test_hash_key3': 'test_hash_value3'
        }
        return test_hash

    def _remove_tmp_path(self, path):
        return None

    test_task = Task()
    test_task.action = None
    test_task.async_val = None
    test_connection = ActionModule.Connection()

# Generated at 2022-06-21 02:31:02.968871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-21 02:31:09.588035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # import 'test_utils' to get a module reference
    import ansible.playbook.test_utils as test_utils
    from ansible.playbook import Playbook, PlaybookInclude, Task, ActionModule
    # create an instance of Playbook with a dummy play
    # as first argument
    test_args = {'connection': 'smart', 'host': 'dummy'}

# Generated at 2022-06-21 02:31:13.093130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule has no parameters
    """
    result = ActionModule()
    assert isinstance(result, ActionModule)


# Generated at 2022-06-21 02:31:14.345400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = None
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-21 02:31:21.384965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule as AM
    from ansible.plugins import module_loader
    from ansible.vars import TaskVars
    from ansible.playbook.task import Task

    task_vars = TaskVars(
        connection='local',
        no_log=['true'],
    )
    task = Task()
    task.action = 'setup'
    task.async_val = 1
    task.async_seconds = 7200
    action_module = AM(task, task_vars=task_vars)
    result = action_module.run(task_vars=task_vars)
    assert isinstance(result, dict)


# Generated at 2022-06-21 02:31:29.440129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import ansible.plugins.action
    from ansible.compat.tests import mock

    class FakeTask(object):
        def __init__(self):
            self.async_val = 'fakeasync'

    class FakeConnection(object):
        def __init__(self):
            self.has_native_async = ''

    class FakeRunner(object):
        def __init__(self):
            self.connection = FakeConnection()
            self.module_name = 'fake_module'
            self.module_args = {}
            self.module_lang = 'fakeshell'
            self.module_vars = {}
            self.module_full_args = {}
            self.noop_task = None
            self.noop_on_check = None

# Generated at 2022-06-21 02:31:31.164551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 02:31:32.942805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None) is not None

# Generated at 2022-06-21 02:32:38.306045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:32:42.519862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    action_module = ActionModule()
    assert action_module.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 02:32:44.046586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-21 02:32:53.831995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as action
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import get_all_plugin_loaders, find_plugin
    from ansible.errors import AnsibleError
    #from ansible.plugins.action.setup import ActionModule
    import yaml
    import pdb
    from collections import namedtuple


# Generated at 2022-06-21 02:33:01.604419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    from ansible.playbook.task import Task
    from ansible.plugins import plugin_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import TaskVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.executor.process.work_context import WorkContext

    t = Task()
    i = Host("test")
    i.vars = {}
    g = Group("test")
    g.vars = {}

    t_vars = TaskV

# Generated at 2022-06-21 02:33:03.099155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-21 02:33:10.814930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext

    class fake_task:
        class fake_loader:
            class fake_vars_manager:
                def __init__(self, *args, **kwargs):
                    self.extra_vars = {}

        def __init__(self, *args, **kwargs):
            self.loader = fake_task.fake_loader()
            self.async_val = 0
            self.action = 'setup'
            self.args = {}

    class fake_v2_task:
        class fake_loader:
            class fake_vars_manager:
                def __init__(self, *args, **kwargs):
                    self.extra_vars = {}

# Generated at 2022-06-21 02:33:15.740063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test constructor of class ActionModule")
    task_vars = dict()
    module = ActionModule(task=None, connection=None, \
                          play_context=None, loader=None, templar=None, shared_loader_obj=None)
    module.run(task_vars=task_vars)

test_ActionModule()

# Generated at 2022-06-21 02:33:19.798798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = '127.0.0.1'
    module_name = 'setup'
    module_args = {}
    module_class = 'setup'
    action = ActionModule(module_name, module_args, module_class)
    action.runner._task.async_val = True
    action.runner._task.action = 'setup'
    result = action.run()
    assert result['invocation']['module_name'] == 'setup'
    assert 'invocation' in result

# Generated at 2022-06-21 02:33:23.640629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(None, None, None, None)
    assert module is not None

# More tests

# Generated at 2022-06-21 02:35:29.022718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible import context
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.play_iterator import PlayIterator

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import module_loader

    from ansible.plugins.action import ActionBase


# Generated at 2022-06-21 02:35:36.188585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule()
    mock_module.params = {}
    mock_module.mock_name = 'mock_module'
    mock_module._ansible_debug = True
    mock_module._ansible_verbosity = 3
    mock_runner = ActionModule(task=mock_module)
    assert isinstance(mock_runner.run(task_vars=dict()), dict)

# Generated at 2022-06-21 02:35:47.849805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import json
    import ansible.plugins.action


# Generated at 2022-06-21 02:35:48.617195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:35:50.441975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, None)
    assert x is not None

# Generated at 2022-06-21 02:35:59.296357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='ping', args=dict()), ignore_errors='yes'),
        ]
    )

    # since the API is constructed for CLI it expects certain options to always be set, named tuple 'fakes' the args parsing options object

# Generated at 2022-06-21 02:36:07.291318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play

    t = Play().load(dict(name='test', hosts='all', gather_facts='no', tasks=[
            'stat'
        ]), variable_manager=None, loader=None)
    assert t is not None
    assert t[0].action == 'stat'
    assert t[0].module_name == 'stat'
    assert t[0]._get_action_handler() is not None
    assert t[0]._get_action_handler() == 'stat'
    assert t[0]._get_action_plugin() is not None
    assert t[0]._get_action_plugin() == 'stat'

# Generated at 2022-06-21 02:36:16.751472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test is to ensure the constructor of the class 'ActionModule'
    is working as expected
    """
    from ansible.plugins.action import ActionModule
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, share_loader=None)
    assert obj._supports_check_mode == True
    assert obj._supports_async == True
    assert obj._shared_loader_obj == None
    assert obj._loader == None
    assert obj._templar == None
    assert obj._task == None
    assert obj._connection == None
    assert obj._play_context == None

# Generated at 2022-06-21 02:36:20.309487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._supports_check_mode
    assert am._supports_async

# Generated at 2022-06-21 02:36:24.093342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class test_class:
        pass
    expected_result = True
    test = ActionModule(None, None, test_class())
    assert test
    return expected_result