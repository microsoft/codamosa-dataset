

# Generated at 2022-06-21 02:26:43.553208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestModule:
        def __init__(self):
            self.params = dict()
            self.common = dict()
            self.runner = dict()
            self.result = dict()
            self.tmp = dict()
            self.tmp_path = dict()
            self.delegate_to = None
            self.private = dict()

    # Test case 1: tmp_path is None
    task = TestModule()
    action_mod = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_mod._supports_check_mode = True
    action_mod._supports_async = True
    action_mod.run(tmp=None)
    assert action_mod._remove_tmp_path == None

# Generated at 2022-06-21 02:26:52.349140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    mock_task = lambda: None
    mock_task.async_val = None
    mock_task.args = None
    mock_task.action = None
    mock_task.become = False
    mock_task.become_method = None
    mock_task.become_user = None
    mock_task.check_mode = False
    mock_task.delegate_to = None
    mock_task.loop = None
    mock_task.name = None
    mock_task.no_log = []
    mock_task.notify = []
    mock_task.remote_user = None
   

# Generated at 2022-06-21 02:27:04.993979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    argument_spec = {'src':{'required':True, 'type': 'str'}, 'dest':{'required':True, 'type': 'str'}, 'mode':{'type': 'str'}}
    connection = None
    module_name = 'copy'
    become = None
    become_user = ''
    become_method = None
    become_exe = None
    become_flags = None
    action_args = {'async':None, 'become':become, 'become_user':become_user, 'become_method':become_method, 'become_exe':become_exe, 'become_flags':become_flags}

# Generated at 2022-06-21 02:27:16.559594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor import task_queue_manager
    from ansible.executor.task_result import TaskResult
    from ansible.executor import module_common as mod_common
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import merge_hash

    def _execute_module(self, conn=None, tmp=None, task_vars=None, wrap_async=False):
        
        ''' handler for module executions '''


# Generated at 2022-06-21 02:27:25.763732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils import basic
    import os
    import shutil
    import tempfile
    import stat

    tmp = tempfile.mkdtemp()
    if PY3:
        exec_path = os.path.join(tmp, "action.py")
    else:
        exec_path = os.path.join(tmp, "action.pyc")
    if PY3:
        exec_path = os.path.join(tmp, "action.py")
        execfile(exec_path, dict(__file__=exec_path))
    else:
        exec_path = os.path.join(tmp, "action.pyc")

# Generated at 2022-06-21 02:27:26.752973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test that result is merged with execution module
    pass

# Generated at 2022-06-21 02:27:27.785713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   action_module = ActionModule()


# Generated at 2022-06-21 02:27:29.319239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    assert m.run() == 'default'

# Generated at 2022-06-21 02:27:31.564144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Returns true if ActionModule constructor is instantiated"""
    test = ActionModule()
    assert test


# Generated at 2022-06-21 02:27:37.149049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test case 1
    # action_name = "foo"
    # task = ""
    # connection = ""

    results = ActionModule(action_name = "foo", task = "", connection = "")
    assert results._task.action == "foo"
    assert results._connection == ""
    assert results._task == ""
    assert results._loader
    assert results._templar
    assert results._shared_loader_obj


# Generated at 2022-06-21 02:27:41.589086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:27:46.396142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor function of the class ActionModule
    # action = ansible.plugins.action.ActionBase('setup.py', {'action': 'setup'}, '/opt/myansible/myinventory')
    pass

# Generated at 2022-06-21 02:27:57.931414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule

    a = ActionModule()

    class _task(object):
        async_val = True
        action = None

    class _connection(object):
        has_native_async = True

    class _play_context(object):
        check_mode = True
        no_log     = False

    #class _playbook_vars(object):
    #    pass

    class _loader(object):
        pass

    #class _variable_manager(object):
    #    pass

    a._task                  = _task()
    a._connection            = _connection()
    a._play_context          = _play_context()
    #a._playbook_vars         = _playbook_vars()
    a._loader                = _loader()
    #a._variable_manager

# Generated at 2022-06-21 02:27:59.164489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule class constructor
    s = ActionModule()
    assert True

# Generated at 2022-06-21 02:28:07.955583
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test: 
    # - Test valid case against the module 'ping'
    # - Simulate an error during the execution of the module 'ping'
    # - Check that the method self._execute_module is called
    # - Check that the method self._execute_module is not called

    # Import of class ActionModule and method _execute_module from ansible.plugins.action.ActionBase
    from ansible.plugins.action.ActionBase import ActionBase
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.errors import AnsibleModuleError
    from ansible.executor.task_result import TaskResult

    # Creation of a mock object of class ActionModule
    action_module = ActionModule.ActionModule()

    # Creation of a mock object of class ActionBase
    action_base

# Generated at 2022-06-21 02:28:18.670187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.result = {}
            self.changed = {}
            self.failures = []
        def __getattr__(self, key):
            return self.params[key]
        def exit_json(self, **kwargs):
            self.result.update(**kwargs)
            return self.result
        def fail_json(self, **kwargs):
            self.result.update(**kwargs)
            return self.result

    async_val = True
    class TestAnsibleTask(object):
        async_val = async_val
        environment = {}
        #def __init__(self, *args, **kwargs):

# Generated at 2022-06-21 02:28:20.534808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    create a mocked task, task_vars and connection to pass to the module and check that an action plugin
    :return:
    """

# Generated at 2022-06-21 02:28:29.077876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile
    import json
    import os
    import sys
    import datetime
    import shutil
    import copy

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Save the current directory
    oldpwd = os.getcwd()

    # Create and populate a temp ansible directory
    local_root = os.path.join(tmpdir, 'ansible')
    shutil.copytree('test/integration/files/ansible/', local_root)

    # cd into it
    os.chdir(local_root)

    # Create a copy of the test files which will be modified
    os.mkdir('roles')
    shutil.copytree('test/integration/files/roles/test_role', 'roles/test_role')
    shutil.copyfile

# Generated at 2022-06-21 02:28:36.779486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import StringIO
    from ansible.plugins.action.normal import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager

    connection = DummyConnection()
    task_queue_manager = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )

    ActionModule.run(self=ActionModule(task_queue_manager, connection, '/dummy/path'), tmp=None, task_vars=None)



# Generated at 2022-06-21 02:28:47.523910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test data
    dict_task_vars = {
        'name':'webserver',
        'nginx':{
            'pkg':['nginx'],
            'service':'nginx'
        },
        'apache':{
            'pkg':['httpd'],
            'service':'httpd'
        }
    }

    # test code
    result = ActionModule.run(self, tmp=None, task_vars=dict_task_vars)

    # check result
    if result.get('skipped'):
        print('The test result is: ' + result)
    else:
        # check wrap_async
        if self._task.async_val and not self._connection.has_native_async:
            wrap_async = True
        else:
            wrap_async

# Generated at 2022-06-21 02:28:54.547479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule._execute_module")
    pass

# Generated at 2022-06-21 02:28:56.000786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:28:57.168304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 02:29:05.739485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import mock

    class Fake_ActionModule_Mock(ActionModule):
        def __init__(self):
            super(Fake_ActionModule_Mock, self).__init__(mock.Mock(), mock.Mock(), 0)

        def run(self, tmp=None, task_vars=None):
            return super(Fake_ActionModule_Mock, self).run(tmp, task_vars)

    class Fake_ActionBase_Mock(ActionBase):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(Fake_ActionBase_Mock, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)


# Generated at 2022-06-21 02:29:15.928636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj._supports_check_mode == True
    assert obj._supports_async == True

    #param1: task_vars
    task_vars1 = {'test1':'test1'}
    assert obj.run(task_vars=task_vars1) == obj.run(task_vars=task_vars1)

    '''
    #param2: wrap_async
    wrap_async = True
    assert obj.run(wrap_async=wrap_async) == obj.run(wrap_async=wrap_async)
    '''


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:29:24.241490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    task = Task()

    module = ActionModule(task, variable_manager, loader)
    assert module is not None


# Generated at 2022-06-21 02:29:26.024135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m is not None

# Generated at 2022-06-21 02:29:26.821209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    main.main()

# Generated at 2022-06-21 02:29:28.493713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None)
    assert not am._supports_check_mode
    assert not am._supports_async


# Unit tests for other methods of class ActionModule

# Generated at 2022-06-21 02:29:36.974845
# Unit test for constructor of class ActionModule
def test_ActionModule():

    """
    Unit test for class ActionModule in action_plugins/action.py
    This unit test checks the following cases (in order):
        0. Class initialization
        1. Test run function
            1.1 Test run function with 'skipped' flag
            1.2 Test run function with success
            1.3 Test run function with failure

    :return: None
    """
    import sys
    import os
    import re
    import unittest
    import shlex
    import inspect

    # Our import
    sys.path.append(os.path.realpath(os.path.join(os.path.dirname(__file__), '..')))
    from action_plugins import action

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

# Generated at 2022-06-21 02:29:53.491399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = ActionModule(play_context=None,
                     connection=None,
                     task=None,
                     loader=None,
                     templar=None,
                     shared_loader_obj=None)
    assert d.run(tmp=None, task_vars=None) is not None

# Generated at 2022-06-21 02:30:02.230351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task = task
    action._connection = connection
    action._play_context = play_context

    result = action.run(tmp='/tmp/tmptmp', task_vars=task_vars)
    assert result['invocation']['env'] == {'foo': 'bar'}
    assert result['_ansible_check_mode'] is False
    assert result['_ansible_verbose_override'] is True
    assert result['failed'] is False
    assert result['skipped'] is False



# Generated at 2022-06-21 02:30:03.797496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    print(module)

# Generated at 2022-06-21 02:30:10.317194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Executing test for constructor of class ActionModule.')

    testObj = ActionModule()
    testObj._supports_check_mode = True
    testObj._supports_async = True

    result = testObj.run(tmp='', task_vars={})

    print('The result of the constructor test is:')
    print(result)

#test_ActionModule()

# Generated at 2022-06-21 02:30:21.768503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock TaskExecutor and Task
    class TaskExecutor:
        def __init__(self):
            self.setup_callback_called = False
            self.run_callback_called = False

        def setup_callback(self):
            self.setup_callback_called = True

        def run_callback(self):
            self.run_callback_called = True

    class Task:
        def __init__(self):
            self.async_val = False
            self.action = 'setup'
            self.ignore_errors = False

            # Mock method
            self.env = {
                        'HOME': '/home/myuser'
                        }

    # Create a mock Connection
    class Connection:
        def __init__(self):
            self._shell = TaskExecutor()
            self.has_native_async = True

# Generated at 2022-06-21 02:30:30.696993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.connection import Connection
    from ansible import play
    from ansible import inventory
    from ansible import module_loader
    from ansible import context
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    results_callback = None
    inven = inventory.Inventory(loader=loader, hosts=['localhost'])
    play_context = play.PlayContext()
    play_context.network_os = 'default'
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='echo "Hello"'))
        ]
    )

    play = play.Play().load

# Generated at 2022-06-21 02:30:43.026327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    import sys
    import os
    import pytest
    import __main__ as main
    # Define values for testing
    # result = {'invocation': {'module_args': 'test'}}
    # task_vars = {'ansible_check_mode': True}
    # task_vars = {'my_variable': 1}
    # task_vars = {'ansible_check_mode': True}
    # task_vars = {'my_variable': 1}
    # tmp = 1
    wrap_async = False
    # result = {'invocation': {'module_args': 'test'}}
    task_vars = {'ansible_check_mode': True}

# Generated at 2022-06-21 02:30:43.579536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:30:44.075950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO

# Generated at 2022-06-21 02:30:53.855091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock module for testing
    class MockModule():
        def run(self, tmp=None, task_vars=None):
            # FIXME: not too sure what to return here since we are testing the super class
            pass
    # mock task args for testing
    class MockTask():
        async_val = 0
    # mock task class for testing
    class MockTaskClass():
        async_val = None
    # mock connection class for testing
    class MockConnectionClass():
        def __init__(self):
            pass
        def has_native_async(self):
            return False
    # create mock connection
    mock_connection = MockConnectionClass()
    mock_connection._shell = MockModule()
    mock_connection._shell.tmpdir = "/tmp"
    # create mock task
    mock_task = MockTask()
    # create

# Generated at 2022-06-21 02:31:24.386992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # hack to run async tasks #
    import time
    import os

    class MockAsyncResult:

        def __init__(self, host):
            self.host = host
            self.pid = os.getpid()
            os.mkdir('/tmp/ansible_async/%d' % self.pid)

        def __str__(self):
            return '%s : %s' % ('/tmp/ansible_async/%d' % self.pid, self.host)

        def wait(self, timeout):
            return True

        def successful(self):
            return True

    class MockTask:

        def __init__(self):
            self.async_val = 5

    class MockConnection:

        def __init__(self):
            self._shell = None
            self.has_native_async

# Generated at 2022-06-21 02:31:29.933588
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult

    pc = PlayContext()
    task = Task()

    at = ActionModule(task, pc)

    assert at._supports_check_mode is True
    assert at._supports_async is True

    task_vars = dict()
    result = TaskResult(host=None, task=None, return_data=dict())

    tmp = None

    result = at.run(tmp, task_vars)

# Generated at 2022-06-21 02:31:41.097766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.cli.adhoc import AdHocCLI
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    import os
    import sys
    import json


# Generated at 2022-06-21 02:31:41.885408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:31:52.093520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create mock object for task_vars and for inventory
    t_vars = {'ansible_ssh_port':22}
    fake_class = type('fake_class',(object,),{})
    fake_socket = fake_class()
    fake_socket.closed = False
    fake_class2 = type('fake_class2',(object,),{})
    fake_connection = fake_class2()
    fake_connection.host = 'host_name'
    fake_connection.connected = True
    fake_connection.socket = fake_socket
    fake_connection.has_native_async = False

    # create mock object for task
    fake_task = fake_class()
    fake_task.async_val = False
    fake_task.action = 'action_name'

# Generated at 2022-06-21 02:32:00.038109
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:32:11.825779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    # TEST: test_ActionModule_run
    # Check that method run of class ActionModule runs correctly


    # 1) Define some variables to be used later
    # Fake values to be used
    fake_task_vars = {}
    fake_tmp = '/tmp/tmp123456'

    # Fake values from config defaults
    fake_shell_path = '/bin/sh'
    fake_executable = '/bin/sh'
    fake_ssh_executable = 'ssh'
    fake_scp_executable = 'scp'
    fake_sftp_executable = 'sftp'
    fake_fact_cache = '/tmp/ansible/fact_cache'
    fake_library = '/usr/share/ansible'

# Generated at 2022-06-21 02:32:19.559257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.plugins.connection.local import Connection
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils import context_objects as co
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.setup import ActionModule

# Generated at 2022-06-21 02:32:23.534615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor of class ActionModule
    mod = ActionModule()

# Generated at 2022-06-21 02:32:25.452931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    aModule = ActionModule()
    assert aModule is not None

# Generated at 2022-06-21 02:33:29.733898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for successful run
    class Task():
        def __init__(self):
            self.action = None
    class Connection():
        def __init__(self):
            self.has_native_async = True
    class PlayContext():
        def __init__(self):
            self.check_mode = None
    class ModuleExecutor():
        def __init__(self):
            self.dummy = None
    class _VariableManager():
        def __init__(self):
            self.dummy = None
    class _Shell():
        def __init__(self):
            self.tmpdir = "/tmp"
    class _Connection():
        def __init__(self):
            self._shell = _Shell()

# Generated at 2022-06-21 02:33:40.401820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Playbook

    loader = DataLoader()

    # Specifying inventory
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost')

    # Specifying Options

# Generated at 2022-06-21 02:33:40.801831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:33:43.621666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test of method run of class ActionModule """
    from ansible.plugins.action.normal import ActionModule
    # FIXME: test not written yet
    return

# Generated at 2022-06-21 02:33:44.619260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This is just sample code used for testing
    ActionModule('test')

# Generated at 2022-06-21 02:33:56.661942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from unittest import mock
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule

    am = ActionModule(
        task=mock.Mock(),
        connection=mock.Mock(),
        play_context=mock.Mock(),
        loader=mock.Mock(),
        templar=mock.Mock(),
        shared_loader_obj=None
    )
    am._supports_check_mode = True
    am._supports_async = True

    am.run(tmp=None, task_vars=None)

    assert ActionBase.run.called

    am._task.async_val = True
    am._task.async_seconds = 10
    am._task.poll = 10
    am._connection.has_native_as

# Generated at 2022-06-21 02:34:03.568723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock Connection
    class ConnectionMock:
        def __init__(self):
            self.has_native_async = False

        def _connect(self):
            pass

        def _shell_quote(self, string, quote_states=None, escape_backslashes=True):
            return string

    # Create a mock Task to use within the Action Module
    class TaskMock:
        def __init__(self):
            self.async_val = 10
            self.async_jid = "async_jid"

    # Create a mock TaskExecutor to use within the Action Module
    class TaskExecutorMock:
        def __init__(self):
            pass

    # Create a mock Runner to use within the Action Module
    class RunnerMock:
        def __init__(self):
            self

# Generated at 2022-06-21 02:34:10.292944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = { 'someslug' : 'bar' }
    module_name = 'test'
    module_args = { 'testarg': 'testval' }
    task_path = 'test.yml'
    loader = None
    tmp = '/tmp'
    result = { 'skipped': False }
 
    connection = ActionBase.connection
    my_action_module = ActionModule(connection=connection, every_shell=connection_shell, noop_on_check=False, become=False, task_vars=task_vars, module_name=module_name, module_args=module_args, task_path=task_path, loader=loader, task_uuid=uuid.uuid4().hex, tmp=tmp)

# Generated at 2022-06-21 02:34:10.808091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # no tests for now.
    pass

# Generated at 2022-06-21 02:34:19.263780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test of method run of class ActionModule'''

    # Create a mocker
    mocker = Mocker()

    # XFAIL(test_method_run)

    # Create a ActionModule object
    action_module = ActionModule(
        task=mocker.Mock(),
        connection=mocker.Mock(),
        play_context=mocker.Mock(),
        loader=mocker.Mock(),
        templar=mocker.Mock(),
        shared_loader_obj=mocker.Mock()
    )

    # Set an attribute of ActionModule object and create a mock of result
    action_module._supports_check_mode = True
    action_module._supports_async = True
    result = mocker.Mock()

    # Set a side_effect of ActionModule.run() method and