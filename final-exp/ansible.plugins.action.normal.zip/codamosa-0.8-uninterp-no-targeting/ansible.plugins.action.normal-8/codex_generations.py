

# Generated at 2022-06-21 02:26:42.200543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict(module_name='shell', module_args='ls')),
        connection=None,
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action.action_string == 'shell'
    assert action.task_vars == {}
    assert action.connection == None
    assert action.play_context == dict(check_mode=False)

# Generated at 2022-06-21 02:26:43.424442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "TODO"

# Generated at 2022-06-21 02:26:46.252315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _obj = ActionModule()
    _obj._supports_check_mode = False
    _obj._supports_async = False


# Generated at 2022-06-21 02:26:47.049267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:26:55.635385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    from ansible.module_utils.facts import Facts
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.common._collections_compat import Mapping
    facts = Facts(dict())
    data = ActionModule(action='setup')
    assert isinstance(data.module_args, Mapping)
    assert isinstance(data.action, str)
    assert isinstance(data.action, str)
    assert isinstance(data._task, Mapping)
    assert isinstance(data._task_vars, Mapping)
    assert isinstance(data._loader, Mapping)
    assert isinstance(data._connection, Mapping)
    assert isinstance(data._play_context, Mapping)
    assert isinstance(data._shared_loader_obj, Mapping)

# Generated at 2022-06-21 02:27:06.471958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible import context

    play_context = PlayContext()
    play_context.become = True
    play_context.become_user = 'test_user'
    play_context.verbosity = 5
    play_context.connection = 'local'

# Generated at 2022-06-21 02:27:17.035453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Runs a unit test on the ActionModule class and its constructor
    """
    import os
    import tempfile
    import shutil

    module_utils_path = os.path.dirname(__file__)
    parent_dir = os.path.dirname(module_utils_path)

    # Copy test module
    test_dir  = tempfile.mkdtemp()
    test_module_dir = os.path.join(test_dir, 'ansible', 'modules', 'test')
    test_module_path = os.path.join(test_module_dir, 'test_module.py')

    shutil.copytree(os.path.join(module_utils_path, 'ansible', 'modules'), os.path.join(test_dir, 'ansible', 'modules'))

    # Add test module to the

# Generated at 2022-06-21 02:27:18.922704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert False == module.run()

# Generated at 2022-06-21 02:27:24.362704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Result is a dict with:
    - changed
    - skipped
    - failed
    - passed
    - unreachable
    """

    module_mock = ActionModule("", "{}", {}, {}, {})
    test_vars = {"test_var": "hello"}
    result = module_mock.run(task_vars={"ansible_vars": test_vars})

    assert(result.get("skipped") == True)

# Generated at 2022-06-21 02:27:33.699488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(
            async_val=False,
            action='action',
        ),
        connection=dict(),
        play_context=dict(
            become=False,
            become_user='become_user',
            become_method='become_method',
            check_mode=False,
            diff_mode=False,
            remote_user='remote_user',
            password='password',
            private_key_file='private_key_file',
            timeout=300,
            shell='/bin/bash',
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Check repr
    assert repr(am) == "<ActionModule action='action'>"

    # Check _display
    # assert ap._display

# Unit

# Generated at 2022-06-21 02:27:37.977717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 02:27:46.342960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    from ansible import constants as C
    from ansible.module_utils.six import PY3
    if not PY3: import __builtin__ as builtins
    else: import builtins
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.template import Templar

    def _mock_action_loader(cls, task, connection, play_context):
        return cls(task, connection, play_context)

    class _Action(ActionBase):
        def __init__(self, task, connection, play_context):
            pass

        def run(self, tmp=None, task_vars=None):
            return {'skipped': True}


# Generated at 2022-06-21 02:27:55.397908
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import os
    import tempfile
    import shutil
    import json
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    from ansible.plugins.action import ActionBase


# Generated at 2022-06-21 02:28:04.924337
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_connection='local',
        ansible_ssh_user='root',
        ansible_ssh_pass='password',
        ansible_sudo_pass='sudo_pass',
        ansible_module_name='module_name',
        ansible_module_args='module_args',
    )
    task = dict(
        async_val = 123,
        action = 'action',
        loop = 'loop',
        loop_args = 'loop_args',
        module_name = 'module_name',
        module_args = {'M': 'A'},
        register = 'register',
        tags = 'tags',
        sudo = 'sudo',
        sudo_user = 'sudo_user',
        when = 'when',
    )

# Generated at 2022-06-21 02:28:06.275684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO
    return


# Generated at 2022-06-21 02:28:09.028739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task={}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})

# Generated at 2022-06-21 02:28:15.867989
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Constructor of class ActionModule without any parameter
    # Since the constructor of the parent class is called,
    # it is necessary to call the parent constructor.
    # ActionBase.__init__(self, task, connection, play_context, loader, templar, shared_loader_obj)
    action_module = ActionModule(
        task = {},
        connection = {},
        play_context = {},
        loader = {},
        templar = {},
        shared_loader_obj = {}
    )

    # Test __init__ method of class ActionModule
    assert action_module

# Generated at 2022-06-21 02:28:20.176027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the object that we will be testing and mock certain attributes
    am = ActionModule()
    am.action = "action_name"

    # TODO: flesh this out once/if we ever write tests.
    assert True

# Generated at 2022-06-21 02:28:20.715579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:23.305850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule()
    assert test_action_module is not None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:28:31.612410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:28:44.412249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {
        "action": "setup",
        "async_val": False,
        "ignore_errors": True,
    }
    action_module._connection = {}
    action_module._connection._shell = {
        "tmpdir": "test_tmpdir",
    }
    action_module._task_vars = {}
    action_module._remove_tmp_path = lambda tmp_path: print("tmp_path={}".format(tmp_path))

    action_module._execute_module = lambda task_vars, wrap_async=False: {
        "changed": False,
        "failed": False,
        "invocation": {
            "module_args": "test_module_args",
        },
    }

    result = action_module.run

# Generated at 2022-06-21 02:28:45.253162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:46.067010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-21 02:28:47.309915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None


# Generated at 2022-06-21 02:29:00.224327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    sys.path.append("test/units/plugins/action")
    from test_module import get_dict
    actionmodule = ActionModule()
    test_dict = get_dict("""{"invocation": {"module_name": "setup"}, 
                            "playbook": {"id": "123", "name": "install rails"}, 
                            "task": {"id": "456", "name": "setup"}, "play": {"id": "789", "name": "Rails"}}""")

    test_vars = get_dict("")
    result = actionmodule.run(task_vars=test_vars, tmp=None)
    assert result == test_dict
    assert result.get("invocation") == test_dict.get("invocation")

# Generated at 2022-06-21 02:29:03.733215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext(), loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 02:29:07.096476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    m = ActionModule('module', dict())
    m.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 02:29:16.874863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        pass
    # create mocked task object
    task = Task()
    task.async_val = 1
    task.register = 'test_register'
    # create mocked connection object
    conn = ConnectionBase()
    conn.has_native_async = False
    conn.host = 'host'
    conn.port = 'port'
    conn.local = 'local'
    conn.remote = 'remote'
    conn.executable = 'executable'
    conn.conn_id = 'conn_id'
    conn.shell = ShellModule()
    conn._shell.tmpdir = "/tmp/test"
    # create mocked module_executor object

# Generated at 2022-06-21 02:29:27.005665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Starting test_ActionModule_run")
    import ansible.plugins.action
    import ansible.plugins.action.normal
    import ansible.plugins.connection
    import ansible.plugins.connection.local
    import ansible.plugins.loader
    import ansible.utils.vars
    import ansible.utils.module_docs

    task_vars = dict()
    tmp = None
    action_module = ansible.plugins.action.ActionModule()
    action_module_normal = ansible.plugins.action.normal.ActionModule()
    action_module_normal._task = dict()
    action_module_normal._task['async_val'] = None
    local_connection = ansible.plugins.connection.ConnectionBase()
    action_module_normal._connection = local_connection
    ansible.plugins.loader.module

# Generated at 2022-06-21 02:29:39.628951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:29:40.626548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:51.521980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.module_utils.connection import Connection

    import os
    import mock
    import shutil
    import tempfile
    import textwrap
    import types

    def prepare_mocks(tmpdir):
        mock_conn = mock.Mock(spec=Connection)
        mock_conn.tmpdir = tmpdir
        mock_conn.module_implementation_preferences = ('shell', 'paramiko', 'ssh')
        mock_conn._shell.tmpdir = tmpdir

        mock_task = mock.Mock()

        return (mock_conn, mock_task)


# Generated at 2022-06-21 02:29:55.315557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor
    action_module = ActionModule()

    # assert that ActionModule object is constructed correctly
    assert (action_module is not None)

# Generated at 2022-06-21 02:30:04.690351
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:30:14.110469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {
        "msg": "hello world",
        "_ansible_verbose_always": True
    }

    def _execute_module(self, tmp=None, task_vars=None, wrap_async=False):
        return result

    class FakeActionModule(ActionModule):
        def __init__(self):
            pass

        def _execute_module(self, tmp=None, task_vars=None, wrap_async=False):
            return result

    # create a dummy object for the class
    ActionModule_obj = FakeActionModule()
    task_vars = {}
    tmp = None

    # call the run method
    exec_result = ActionModule_obj.run(tmp, task_vars)

    # the expected and actual results are the same
    assert exec_result == result

# Generated at 2022-06-21 02:30:15.098438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:30:23.701968
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # initialization
    action_module = ActionModule()
    action_module._remove_tmp_path = lambda x: True
    action_module._execute_module = lambda task_vars, wrap_async: dict(
        word='Hello',
        skipped=False,
        invocation=dict(module_args=None),
    )
    action_module.SUPPORTED_FILTERS = []
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module._name = 'test_module'

# Generated at 2022-06-21 02:30:31.438973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TestCase Data
    # Testing all the scenario where tmp is not given.
    module_args = {'_ansible_check_mode': False, '_ansible_verbosity': 4, '_ansible_no_log': False, 'command': '/usr/bin/systemctl is-active systemd-logind'}
    kwargs = {'module_args': module_args}
    res = {'invocation': {'module_args': module_args}, 'skipped': False}

    #Testing with the input parameters
    result1 = {}

# Generated at 2022-06-21 02:30:34.386072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action="testplugin1", async_val=True, environment=dict()),
        connection=dict(module_implementation_preferences=[]),
        play_context=dict(check_mode=False, diff=False),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module

# Generated at 2022-06-21 02:31:04.624715
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    """Test the run method of the ActionModule"""

    # Create an object of the ActionModule class
    action_module = ActionModule()

    # Mocking the super class methods
    action_module.run = super(ActionModule, action_module).run

    # Mocking the super class methods
    action_module.run_command = super(ActionModule, action_module).run_command

    # Mocking the super class methods
    action_module.run_command = super(ActionModule, action_module).run_command

    # Mocking the super class methods
    action_module.get_bin_path = super(ActionModule, action_module).get_bin_path

    # Mocking the super class methods
    action_module.get_bin_path = super(ActionModule, action_module).get_bin_path

    # Mocking the super class methods

# Generated at 2022-06-21 02:31:05.108323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:31:05.575571
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-21 02:31:06.597211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Test me
    pass


# Generated at 2022-06-21 02:31:07.597759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('test_path_1', dict(a=1, b=2))

# Generated at 2022-06-21 02:31:08.424802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:31:14.990236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    module = __import__('ansible.plugins.action.action_base').plugins.action.action_base.ActionBase.TestActionModule()
    module._LOADED_FROM_FILE = 'ansible.plugins.action.action_base'
    module._task = __import__('ansible.parsing.yaml.objects').parsing.yaml.objects.Task.Task()
    module._task.action = 'setup'
    
    tmp = 'tmp' # i.e '/tmp'
    
    
    if not module._task.async_val:
        # returns dummy result
        result = module.run(tmp=tmp, task_vars=None)
        print('result: {0}'.format(result))
        # skip as async is not supported
        assert not result.get('skipped')
       

# Generated at 2022-06-21 02:31:15.898885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    i = ActionModule()
    assert type(i) is ActionModule

# Generated at 2022-06-21 02:31:23.489193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(ansible_ssh_user='mdehaan')
    am = ActionModule(task=dict(action='setup'), connection=dict(user='mdehaan', host='localhost'), play_context=dict(remote_user='mdehaan', remote_addr='127.0.0.1'), loader=None, templar=None, shared_loader_obj=None)
    am.setup(task_vars=task_vars)
    print(am.run(task_vars=task_vars))

test_ActionModule()

# Generated at 2022-06-21 02:31:26.185469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    action_module = ActionModule(task=dict(action="test"), connection=None, play_context=dict())
    action_module.run()

# Generated at 2022-06-21 02:32:40.769821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = module.run(tmp=None, task_vars=None)

# --------------------------------------------------------------------------------
# Functional testing of class ActionModule
# --------------------------------------------------------------------------------
# Tested by the integration tests

# Generated at 2022-06-21 02:32:51.068249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import module_loader
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=''))
    module_name = 'test'
    task = Task()
    task.module_name = module_name
    task.action = 'setup'

# Generated at 2022-06-21 02:33:00.486765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_ActionModule_1
    actionmodule = ActionModule()
    assert actionmodule._supports_check_mode == True
    assert actionmodule._supports_async == True

    # test_ActionModule_2
    ctype = 'str'
    cvar = 'str'
    ccache = 'str'
    cinfo = 'str'
    cmodule = 'str'
    cmodule_args = 'str'
    cenv = 'str'
    ctmp_path = 'str'
    cwrap_async = 'str'
    c_execute_module_args = 'str'
    c_execute_module_kwargs = 'str'
    third_pass = 'str'
    remote_addr = 'str'
    remote_user = 'str'
    connection = 'str'
    runner = 'str'

# Generated at 2022-06-21 02:33:09.562573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    import ansible_collections.ansible.community.plugins.action.normal as normal_action_module
    import ansible.utils.vars as vars

    module_args = dict(
        name='foo',
        state='absent',
        test='not test'
    )
    set_module_args(module_args)
    # run test
    normal_action_module.ActionModule.run(normal_action_module.ActionModule(), dict(name='foo', state='absent', test='not test'), dict())
    # check results
    assert True

# Generated at 2022-06-21 02:33:10.382660
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-21 02:33:18.475226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Without any parameter
    actmod = ActionModule(None, None)

    # Expected values
    actmod._supports_check_mode = True
    actmod._supports_async = True

    # Call the run method
    tmp = None
    task_vars = None
    result = {}

    ret = actmod.run(tmp, task_vars)
    assert(ret == result)

    # Call run method with a result structure
    result = {
        'module_name': 'test',
        'invocation': {
            'module_args': 'test'
        }
    }
    ret = actmod.run(tmp, task_vars)
    assert(ret == result)


# Generated at 2022-06-21 02:33:27.736208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.ACTION_WARN == 'WARN'
    assert module.ACTION_FAILED == 'FAILED'
    assert module.RESULT_IGNORED == 'IGNORED'
    assert module.RESULT_OK == 'OK'
    assert module.RESULT_SKIPPED == 'SKIPPED'
    assert module.RESULT_UNREACHABLE == 'UNREACHABLE'
    assert module.RESULT_CHANGED == 'CHANGED'
    assert module.RESULT_FAILED == 'FAILED'
    assert module.RESULT_ERROR == 'ERROR'

# Generated at 2022-06-21 02:33:32.779148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(name='foo', task_vars={'a': {'b':1}})
    assert a is not None
    assert a.task_vars == {'a': {'b':1}}
    assert a.name == 'foo'

# Generated at 2022-06-21 02:33:33.528206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run(ActionModule, tmp=None, task_vars=None)

# Generated at 2022-06-21 02:33:41.575457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = 'hostname'

    action_plugin = ActionModule()
    action_plugin._task  = 'task_list'
    
    module_args = {'hostname':hostname}
    action_plugin._task.module_args = module_args

    action_plugin._connection = 'ssh'
    action_plugin._loader = 'ansible loader'
    
    task_vars = {'vars':'var_list'}
    result =  \
    {
        'invocation' : {
            'module_name':'name',
            'module_args':{
            }
        },
        'changed' : 'changed',
        '_ansible_parsed' : True
    }

    res = action_plugin.run(tmp=None, task_vars=task_vars)


# Generated at 2022-06-21 02:35:57.524312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action

    # create a mock object
    class MyActionModule(ansible.plugins.action.ActionModule):
        def run(self, tmp=None, task_vars=None):
            return None

    # test default values, set internally by Ansible
    action_module = MyActionModule()
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True

    # call the action module method
    result = action_module.run()

    # test the result
    assert result is None

# Generated at 2022-06-21 02:36:07.419381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=W0142
    # Too many return statements (12/6)
    import ansible.plugins.action
    import ansible.playbook.task
    import ansible.plugins.connection
    from ansible.modules.system import ping
    from ansible.utils.vars import combine_vars
    import ansible.vars.hostvars
    import ansible.inventory.host
    mock_connection = ansible.plugins.connection.Connection()
    mock_task = ansible.playbook.task.Task(
        name='testactionmodule', action='testactionmodule',
        args={'testactionmoduleargskey': 'testactionmoduleargsvalue',
              '_ansible_no_log': False, 'no_log': False})
    mock_task.async_val = False
    mock_task._

# Generated at 2022-06-21 02:36:08.788127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None) is not None

# Generated at 2022-06-21 02:36:16.923563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test the constructor of the class ActionModule"""
    print("\nConstructing a ActionModule object")
    action_module = ActionModule
    print("\nTesting the type of the object constructed")
    assert isinstance(action_module, ActionBase), "action_module should be of type ActionBase"
    print("\nTesting the type of the object constructed")
    assert issubclass(action_module, ActionBase), "action_module is not a subclass of ActionBase"
    print("\nTesting the constructor of the object")
    assert ActionModule is action_module, "Constructor of object does not work"

# Generated at 2022-06-21 02:36:18.269398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:36:26.988346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of the superclass
    action_base = ActionBase()
    # Use __new__ of the superclass to create an object of the ActionModule
    action_module = ActionModule.__new__(ActionModule)
    # Set the _task attribute to a dictionary
    action_module._task = {'action':'ping'}
    # Populate the __dict__ of the object with the attributes of the superclass object 
    action_module.__dict__.update(action_base.__dict__)
    # Invoke the run method of the object
    action_module.run()

# Generated at 2022-06-21 02:36:31.330347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arguments = dict(
        action=dict( module="test"),
        module_name="test"
    )
    action_mod = ActionModule()
    action_mod.setup(arguments, None)