

# Generated at 2022-06-23 08:08:09.826177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:08:16.280608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    x = ActionModule()
    assert x.__doc__ == '''A module that is used to execute complex operations.'''

# Generated at 2022-06-23 08:08:18.100185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_run_notimplemented

# Generated at 2022-06-23 08:08:27.645002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # testing without option --connection=local
    task_vars = dict(
        ansible_connection='local',
        ansible_python_interpreter='/usr/bin/env python',
        ansible_shell_type='fish',
        ansible_ssh_executable='ssh',
        ansible_ssh_extra_args='',
        ansible_ssh_pipelining=False,
        ansible_ssh_private_key_file=None,
        ansible_ssh_user='user',
        ansible_sudo='False',
        ansible_sudo_exe=None,
        ansible_sudo_flags='-H -S',
        ansible_sudo_password='password',
        ansible_sudo_user='user',
        ansible_user='user',
        ansible_user_id='user',
    )

# Generated at 2022-06-23 08:08:31.240387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:08:38.358001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockConnection(object):
        def __init__(self):
            self._shell = None
    class MockTask(object):
        def __init__(self):
            self.async_val = None

    mock_task = MockTask()
    mock_connection = MockConnection()
    # Test with empty argument
    am = ActionModule(task=mock_task, connection=mock_connection)
    result =  am.run(task_vars=None)
    assert result['skipped'] == True
    assert result['_ansible_verbose_override'] == False
    # Test with same value for async and task_vars argument
    am = ActionModule(task=mock_task, connection=mock_connection)
    result =  am.run(task_vars=None)
    assert result['skipped']

# Generated at 2022-06-23 08:08:45.510312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MyActionModule(ActionModule):

        def run(self, tmp=None, task_vars=None):
            return super(MyActionModule, self).run(tmp, task_vars)

    # setup the test interpreter class for comparison
    class TestClass(object):
        def __init__(self, var1, var2):
            self.var1 = var1
            self.var2 = var2

    # create the module constructor
    test_module = MyActionModule(task=TestClass("test_var1", "test_var2"), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # assert expected result
    assert test_module._task.async_val == None

# Generated at 2022-06-23 08:08:54.399337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_module = 'testmodule'
    test_args = {'test': 'arg'}
    action_module = ActionModule('task', 'connection', 'play_context', 'loader', 'templar', 'shared_loader_obj')
    action_module._task.action = test_module
    action_module._task.args = test_args

# Generated at 2022-06-23 08:08:58.793421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, {}, {}, None)
    assert am is not None

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-23 08:09:08.755988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    module_store = ActionModule._shared_loader_obj.module_loader._module_cache
    command_module = module_store.get('command')

    inventory = InventoryManager(loader=None, sources=["localhost"])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = None
    context = PlayContext()
    context.become = False
    context.become_user = None
    play_context = context
    new_stdin

# Generated at 2022-06-23 08:09:10.900792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert not module.INDEX, "Index of ActionModule should be empty"

# Generated at 2022-06-23 08:09:17.511316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # dict to serve as connection mock, needed for instantiating action
    connection_mock = {}

    # action modle to test
    action_module = ActionModule(connection_mock, "module_name", {})

    # assert operation
    assert action_module.name == "module_name"
    assert action_module.connection == connection_mock
    assert action_module._task == {}




# Generated at 2022-06-23 08:09:19.434946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.normal
    normal = ansible.plugins.action.normal.ActionModule()
    print(normal.run)

# Generated at 2022-06-23 08:09:27.797272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    # Create a new Task object so that Task.args can be initialized
    Task = type('Task', (object,), {})
    task = Task()

    # Create a new Connection object so that Connection.transport can be initialized
    Connection = type('Connection', (object,), {})
    connection = Connection()
    connection.transport = 'local'

    # Create a new AnsibleModuleLoader object so that AnsibleModuleLoader.module_args can be initialized
    AnsibleModuleLoader = type('AnsibleModuleLoader', (object,), {})
    ansiblemodule_loader = AnsibleModuleLoader()
    ansiblemodule_loader.module_args = '''"module_args": "name=my_var"'''

    # Create a new PlayContext object so that PlayContext

# Generated at 2022-06-23 08:09:29.518927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:09:30.643819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule,'run')

# Generated at 2022-06-23 08:09:38.376126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule = ActionModule()

# Generated at 2022-06-23 08:09:40.431154
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule('/tmp/test.py', 'test_host', '/tmp', 'freebsd', 'setup'))

# Generated at 2022-06-23 08:09:43.696748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule._task = {'async_val': False, 'action': 'include_role'}
    actionModule._connection = {'has_native_async': False}
    # TODO: Test with input
    actionModule.run()

# Generated at 2022-06-23 08:09:51.181237
# Unit test for constructor of class ActionModule
def test_ActionModule():

    def test_ActionBase_mock(self, connection, tmp, task_vars):
        return {'rc': 0}

    # Patch class ActionBase
    old_method = ActionBase._execute_module
    ActionBase._execute_module = test_ActionBase_mock

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run()
    assert result['rc'] == 0 and result

    # If test fails, restore the original method and fail the test
    ActionBase._execute_module = old_method
    assert False

# Generated at 2022-06-23 08:09:53.424999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: add unit test for constructor
    assert ActionModule


# Generated at 2022-06-23 08:10:05.252223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock_module_utils is an extension to the normal mock, which provides a mock loader.
    import sys
    try:
        import ansible.module_utils.common
        import ansible.module_utils.facts
        import ansible.module_utils.distribution
        import ansible.module_utils.urls
        import ansible.module_utils.six
    except ImportError as e:
        print("python-test-plugin: ModuleMock: import error for module %s (%s)" % (e.name, e), file=sys.stderr)
        raise

    from unittest.mock import patch, PropertyMock, Mock

    class _Connection(object):
        def _shell_class(self):
            _shell_class = Mock()
            _shell_class.has_native_async.return_value = False

# Generated at 2022-06-23 08:10:13.055760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up test env
    import sys
    import os

    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    import ansible

    # Instantiate a new module
    self = ActionModule()

    # load the module
    module_loader = ansible.plugins.loader.action_loader
    module = module_loader.get('ping')
    self._shared_loader_obj = module_loader

    # set some test vars
    result = {}
    tmp = None

# Generated at 2022-06-23 08:10:21.848029
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class TestClass(ActionModule):

        def _get_action_args(self, task_vars):
            return None

        def _execute_module(self, module_name=None, module_args=None, tmp=None, task_vars=None, wrap_async=False):
            return {'test': True}

    tc = TestClass()
    tc.task_vars = {'test': True}
    tc._supports_async = True
    tc._task = True
    tc._connection = True
    result = tc.run(tmp=None, task_vars=tc.task_vars)
    assert result, {"test": True}


# Generated at 2022-06-23 08:10:23.996768
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    assert ansible.plugins.action.ActionModule

# Generated at 2022-06-23 08:10:24.605099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:10:35.251394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.utils.vars import merge_hash

    loader = DataLoader()
    options = {'connection': 'local', 'module_path': '', 'forks': 1, 'become': False, 'become_method': None, 'become_user': None, 'check': False, 'diff': False}
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=None)


# Generated at 2022-06-23 08:10:44.173824
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test call to constructor with invalid task argument
    am = ActionModule(task=123, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test call to constructor with invalid connection argument
    am = ActionModule(task=None, connection=123, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test call to constructor with invalid play_context argument
    am = ActionModule(task=None, connection=None, play_context=123, loader=None, templar=None, shared_loader_obj=None)

    # Test call to constructor with invalid loader argument

# Generated at 2022-06-23 08:10:49.798988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.action.normal import ActionModule
    from ansible.parsing.metadata import extract_metadata, MetadataParser

    # Setup mock module args
    tmp_args_file = tempfile.NamedTemporaryFile()
    tmp_args_file.write(yaml.dump({'a': 'b'}))
    tmp_args_file.seek(0)
    args_file = tmp_args_file.name
    vault_password = VaultLib.new('test')
    vault_password.encrypt('VaultTestString')
    vault_pass = vault_password.encrypt('VaultTestString')
    vault_id = 'testvaultid'

# Generated at 2022-06-23 08:11:01.019196
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os.path
    import json

    import pytest

    from io import StringIO
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.ajson import AnsibleJSONEncoder

    from ansible.module_utils import basic

    from ansible.executor.module_common import ActionModule

    from ansible.plugins.action import ActionModule as ActionModulePlugin
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.plugins.action import ActionBase as MockActionBase
    from units.mock.plugins.action import Action

# Generated at 2022-06-23 08:11:02.519351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    test class constructor
    '''
    assert ActionModule(None, None, None, None) != None

# Generated at 2022-06-23 08:11:13.227058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Args:
        pass

    args = Args()
    args.connection = 'smart'
    args.become_user = 'root'
    args.module_name = 'user'
    args.module_path = '/path/to/modules'
    args.module_args = 'name=root group=wheel'
    args.forks = 5

    action_module = ActionModule(task=args, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_module.task == args
    assert action_module._played_task is False
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True


# Generated at 2022-06-23 08:11:14.790620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)

# Generated at 2022-06-23 08:11:15.397184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:11:25.619765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test module run method.
    Although we are not testing actual module run,
    we still need to setup some objects to make it pass.
    """
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.basic import AnsibleModule
    import ansible.constants as C

    class FakePlayContext:
        pass

    class FakeTask:
        def __init__(self):
            self.action = 'shell'
            self.async_val = None
            self.loop = 'with_items'
            self.become_user = 'root'
            self.delegate_to = 'localhost'
            self.connection = 'ssh'
            self.environment = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin"}
            self.no_

# Generated at 2022-06-23 08:11:33.891717
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock data and objects
    tmp = None
    task_vars = dict(_ansible_module_name='action',
                     _ansible_module_type='action',
                     _ansible_module_name_is_fq=['action'])
    module_result = dict(msg="Test Message",
                         err=False,
                         rc=0)
    wrap_async = False

    # Set up Mock objects
    action = ActionBase()
    action._task = MagicMock()
    action._task.async_val = False
    action._connection = MagicMock()
    action._connection.has_native_async = False
    action._execute_module = MagicMock(return_value={})
    action.async_wrapper = MagicMock()

    # Run the code to be tested
    result = action.run

# Generated at 2022-06-23 08:11:39.830289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(action=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print("\nActionModule_obj: ", action_module)


# Generated at 2022-06-23 08:11:49.139144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    s = "The quick brown fox jumped over the lazy dog"
    task_vars = {}
    tmp = "This is a test"
    # Setup mock class for test results
    class MockActionBase():
        _remove_tmp_path = True
        _supports_check_mode = True
        _supports_async = True
        _task = task_vars
        _connection = task_vars
        def run(self, tmp, task_vars):
            assert tmp == tmp
            assert task_vars == task_vars
            return s
        def _execute_module(self, task_vars, wrap_async):
            assert wrap_async == False
            assert task_vars == task_vars
            return s
        def _remove_tmp_path(self, tmp):
            assert tmp == tmp


# Generated at 2022-06-23 08:11:57.197466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None,
        connection='connection',
        play_context='play_context',
        loader='loader',
        templar='templar',
        shared_loader_obj=None
    )
    assert action_module._task is None
    assert action_module._connection == 'connection'
    assert action_module._play_context == 'play_context'
    assert action_module._loader == 'loader'
    assert action_module._templar == 'templar'
    assert action_module._shared_loader_obj is None

# Generated at 2022-06-23 08:12:09.038653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import tempfile
    from ansible.plugins.action.normal import ActionModule
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars

    #for debugging
    #logging.basicConfig(filename='/tmp/ansible.log', level=logging.DEBUG)

    # create the temporary file
    tmpfd, tmpfile = tempfile.mkstemp()
    os.close(tmpfd)

    # get the module_utils library path
    dir_of_this_file = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-23 08:12:09.994389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test running")
    assert True

# Generated at 2022-06-23 08:12:12.548196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:12:15.112361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule using mock task
    action_module = ActionModule(task=MockTask())

    assert True

# Generated at 2022-06-23 08:12:16.980926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # for now just check that it runs class constructor
    obj = ActionModule()

# Generated at 2022-06-23 08:12:18.298073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am != None

# Generated at 2022-06-23 08:12:27.814285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.action.normal import ActionModule as ActionModule_normal
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import tempfile
    import json
    #from __init__ import setup_logger
    import logging
    import pytest
   

# Generated at 2022-06-23 08:12:35.252139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=too-many-locals, unused-variable
    """
    Method run of class ActionModule depends on internal behavior of Ansible,
    so instead of testing exact content of results, we just check that some
    object which are expected to be present on certain conditions are present.

    :return:
    """

    module = ActionModule()
    module.load_name = 'test_action'
    module._task = MockTask(action='test', async_val=True)
    module._connection = MockConnection(has_native_async=False)

    result = module.run(None, None)

    # checking wrap_async
    assert result['wrap_async'] is True

    # checking it was passed to _execute_module
    assert 'wrap_async' in result['invocation']['module_args']



# Generated at 2022-06-23 08:12:36.734460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-23 08:12:37.718960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None,None)

# Generated at 2022-06-23 08:12:44.679621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a variable dictionary
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._options = Options()

    # Create a loader
    loader = DataLoader()

    # Create a variable manager, for tasks and variables
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}

    # Create the needed objects to create the new class
    task_uuid = "1234567890"
    task_queue_manager = None
    task = Task(task_uuid, datastructure=dict(name='test_action_module', action=dict(), args=dict(), async_val=0, poll=0))
    host = Host('testhost.example.com')

# Generated at 2022-06-23 08:12:46.787887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    assert True



# Generated at 2022-06-23 08:12:59.176334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy

    import ansible.plugins.action as action
    import ansible.plugins.action.debug as debug
    import ansible.utils.template as template

    import ansible.playbook.task as task
    import ansible.playbook.play_context as play_context
    import ansible.executor.task_result as task_result
    import ansible.executor.task_executor as task_executor

    import ansible.utils.vars as vars

    import ansible.vars.hostvars as hostvars


# Generated at 2022-06-23 08:13:12.298356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with patch.object(ActionBase, 'run') as mock_superrun:
        mock_superrun.return_value = { 'rc': 0 }
        a = ActionModule(None)
        a.task = { 'async': 10 }
        a.connection = { 'has_native_async': False }
        a._execute_module = Mock()

        result = a.run(tmp='x', task_vars='y')

        mock_superrun.assert_called_once_with('x', 'y')
        a._execute_module.assert_called_once_with(task_vars='y', wrap_async=True)

        assert result is a._execute_module.return_value, result

# Generated at 2022-06-23 08:13:21.961538
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import StringIO

    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    class FakeAction(ActionBase):

        def run(self, tmp=None, task_vars=None):
            return super(FakeAction, self).run(tmp, task_vars)


# Generated at 2022-06-23 08:13:27.954617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None
    assert isinstance(a, ActionModule)

# Generated at 2022-06-23 08:13:40.278127
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock object
    class mock_ActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return None

    mock_connection = Mock(spec=ActionBase)

    dunder_task = MagicMock()
    dunder_task.async_val = 1
    dunder_task.action = 'setup'

    mock_module = mock_ActionModule(mock_connection, dunder_task)

    class mock_GitRepo():
        def run(self, tmp=None, task_vars=None):
            self.async_val = 1
            self.action = 'setup'
            return None

    # Call the run method of module
    result = mock_module.run(tmp=None, task_vars=None)

    # Verify result
    assert result

# Generated at 2022-06-23 08:13:41.651633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return

# Generated at 2022-06-23 08:13:42.173107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:13:44.006569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module is not None

# Generated at 2022-06-23 08:13:47.341447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import module_loader

    module_loader.ActionModule = ActionModule

    am = ActionModule()
    print(am)
    print(am.__class__)

# Generated at 2022-06-23 08:13:47.944362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:13:51.637853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    # Test that the constructor is working
    task = Task()

    am = ActionModule(task, {})

    assert isinstance(am, ActionModule)
    assert am._connection is None

# Generated at 2022-06-23 08:13:59.572751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext

    action_common = PlayContext()
    action_common._task.async_val = 100
    action_common._task.action = 'test'

    test_common = ActionModule(action_common, 'test', {})

    assert test_common._supports_check_mode == True
    assert test_common._supports_async == True
    assert test_common._async_poll_interval == 10

    action_common._task.async_val = 0
    test_common = ActionModule(action_common, 'test', {})
    assert test_common._supports_async == True
    assert test_common._async_poll_interval == 10

# Generated at 2022-06-23 08:14:00.605791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# vim: set expandtab ts=4 sw=4 ai :

# Generated at 2022-06-23 08:14:02.141449
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Construct
    module = ActionModule()

    # Verify 
    assert module != None

# Generated at 2022-06-23 08:14:07.871716
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule.absolute_path("/some/module/file.py") == "/some/module/file.py"
    assert ActionModule.absolute_path("some/module/file.py") == "some/module/file.py"
    assert ActionModule.absolute_path("some/module/file.py", "/path/") == "/path/some/module/file.py"

# Generated at 2022-06-23 08:14:15.720324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask():
        async_val = False
        action = 'setup'
        def __init__(self):
            self.async_val = False
            self.action = 'setup'
    class MockConnection():
        async_val = False
        def __init__(self):
            self.async_val = False

    task = MockTask()
    connection = MockConnection()
    module_name = "ping"
    module_args = {}
    task_vars = {}

    # Without connection.has_native_async
    action_result = ActionModule(connection=connection, task=task, module_name=module_name, module_args=module_args, task_vars=task_vars)
    assert action_result is not None

    # With connection.has_native_async
    connection.has_

# Generated at 2022-06-23 08:14:22.219482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    x = {'ansible_check_mode': False, 'ansible_no_log': False, 'ansible_verbose': False}
    modules = {
        'setup': '/home/ansible/ansible/lib/ansible/modules/system/setup'
    }
    module_args = {'module_name': 'setup'}
    module_name = 'setup'
    persist_files = []
    module_paths = []
    _supports_check_mode = True
    _supports_async = True
    wrap_async = True

    #async_val = True
    #_connection._shell.has_native_async = False
    #ansible_connection = 'local'
    #_gather_facts = True
    #action = 'setup'
    #module_name = 'setup'

# Generated at 2022-06-23 08:14:32.957898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule_run")
    class ActionModuleTest(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(ActionModuleTest, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self.test_dict = {}

        def _execute_module(self, task_vars=dict, wrap_async=False):
            self.test_dict['has_native_async'] = self._connection.has_native_async
            return {'meta': {'has_native_async': self._connection.has_native_async}}


# Generated at 2022-06-23 08:14:34.738355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module is not None

# Generated at 2022-06-23 08:14:41.402310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor without arguments
    module = ActionModule()
    assert module._connection is None
    assert module._play_context is None
    assert module._task is None
    assert module._loader is None
    assert module._templar is None
    assert module._shared_loader_obj is None
    assert module._lookup_loader is None
    assert module._action is None
    assert module._task_vars is None
    assert module._runner_cache is None
    assert module._unreachable_hosts is None
    assert module._play is None
    assert module._collected_facts is None
    assert module._task_vars is None
    assert module._tmp is None
    assert module._task_vars_params is None
    assert module._task_vars_special is None
    assert module._block is None
    assert module._

# Generated at 2022-06-23 08:14:51.775188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import glob
    import os

    # Create test fixture
    action_base = ActionBase()
    action_base._shared_loader_obj = {'_basedir':os.path.dirname(__file__)}
    action_base._config_module = {}
    action_base._connection = 'local'
    action_base._task = {'action': 'setup', 'async_val': False, 'sudo': False, 'sudo_user': None, 'delegated_vars': {}}

    # Create instance of class ActionModule for method run to test
    action = ActionModule(action_base)
    action._connection = {'has_native_async': False}

    # Create the input parameters of method run
    tmp = 'test_tmp'

# Generated at 2022-06-23 08:14:52.370729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:14:53.771332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Returns:
        None
    """



# Generated at 2022-06-23 08:15:03.460759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    action_plugin = action_loader.get('command', class_only=True)
    assert action_plugin is ActionModule

    # data setup
    my_task = Task()
    my_task.action = 'command'
    my_task.args = dict(cmd='echo hello')
    my_task._ansible_version = (2, 3, 0)

    # variables setup
    my_variable_manager = VariableManager()

    # inventory setup - hostvars
    my_inventory_manager = InventoryManager(loader=DataLoader())
    my_inventory_

# Generated at 2022-06-23 08:15:08.879787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create instance of class ActionModule
    ActionModule_instance = ActionModule()

    # check if ActionModule_instance was created correctly
    assert isinstance(ActionModule_instance, ActionModule)

    # check if ActionBase.run() is called when creating instance of class ActionModule
    assert ActionModule_instance.run() == ActionModule_instance.run()

# Generated at 2022-06-23 08:15:19.441154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    sys.modules['_ansible_test_mocks'] = sys.modules[__name__]
    import ansible.plugins.action.test_module as test_module_action
    reload(test_module_action)
    mod = test_module_action.ActionModule({}, {'shell': {}})
    # call run method
    # run in check_mode
    ret = mod._execute_module(None, {}, check_mode=True)
    assert ret['changed'] == False
    assert ret['skipped']
    assert ret['msg'] == "skipping, since this module does not support check_mode"
    # run in async mode
    ret = mod._execute_module(None, {}, wrap_async=True)
    assert ret['async'] > 0
    # run in no_log mode
   

# Generated at 2022-06-23 08:15:32.361500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    import ansible.plugins.loader as plugin_loader

    # make a fake connection
    class MockConnection:
        def __init__(self, name):
            self.name = name

        def has_native_async(self):
            return True

    # make a fake module class
    class MockModule:
        def __init__(self, name):
            self.name = name

    # create some mock objects
    mock_task_result = TaskResult(host=MockConnection('testhost'), task=Task())

# Generated at 2022-06-23 08:15:35.388098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None,'',None,None,None,None)

# Generated at 2022-06-23 08:15:42.549477
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MyActionModule(ActionModule):

        def run(self, tmp=None, task_vars=None):
            print('tmp: {}'.format(tmp))
            print('task_vars: {}'.format(task_vars))
            assert tmp == 'tmp'
            assert task_vars == 'task_vars'
            return 'output'

    m = MyActionModule()
    output = m.run('tmp', 'task_vars')
    assert output == 'output'

# Generated at 2022-06-23 08:15:47.069396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()
    
    # Create an instance of AnsibleBase
    ansible_base = AnsibleBase()
    
    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()
    
    # Assign tmp, task_vars to variables for test
    tmp = "tmp"
    task_vars = "test_task_vars"
    
    # Run run method and store result in result
    result = action_module.run(tmp, task_vars)
    
    return

# Generated at 2022-06-23 08:15:49.413865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod is not None
    #assert mod.get_parser is not None
    #assert mod.parsed is not None
    assert mod._supports_check_mode is True
    assert mod._supports_async is True

# Generated at 2022-06-23 08:15:51.753209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("ActionModule init")
    assert ActionModule is not None

# Generated at 2022-06-23 08:15:59.389878
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # initialise a test class
    mock_loader = DictDataLoader({
        "test_playbook.yml": """
        - hosts: localhost
          roles:
            - test_role
        """,
        "test_role/tasks/main.yml": """
        - action: shell echo 'hi'
          register: output
        - debug: var=output.stdout
        """,
    })
    mock_inventory = Inventory(loader=mock_loader, variable_manager=VariableManager(), host_list='localhost,')
    mock_variable_manager = VariableManager()
    mock_variable_manager.set_inventory(mock_inventory)

    from ansible.playbook.play_context import PlayContext
    mock_options = Options()
    mock_options.connection = 'local'
    mock_options.module_

# Generated at 2022-06-23 08:16:03.186688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('TEST_ACTION_MODULE')
    # Test the constructor of ActionModule
    # there are no parameters to pass, therefore test is pass-through
    action_mod_1 = ActionModule()

# Generated at 2022-06-23 08:16:10.740639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ret = {'invocation': {'module_args': '', 'module_name': 'setup'}, 'changed': False, '_ansible_parsed': True}
    task_vars = {'ansible_facts': {}, 'ansible_check_mode': False}
    action_module = ActionModule()
    result = action_module.run({"task_vars": task_vars, "result": ret})
    assert result['invocation']['module_name'] == 'setup'
    assert result['changed'] == False

# Generated at 2022-06-23 08:16:11.408598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:16:15.716867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_action = ActionModule(
        task=dict(action='setup'),
        connection=dict(host='127.0.0.1', user='ubuntu', port=22, password='ansible')
    )

# Generated at 2022-06-23 08:16:25.204025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # run construct test case
    print("Run construct test case")
    
    # test variable
    module_name = "Test_AnsibleActionModule"
    module_args = ""
    task_vars = {}
    
    # test variable

# Generated at 2022-06-23 08:16:26.200193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No unit test implemented"

# Generated at 2022-06-23 08:16:28.768060
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # module_args is optional
    assert ActionModule(None, None, None, None)._task.action is not None

# Generated at 2022-06-23 08:16:38.240449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake args
    args = { 'module_path' : 'fake/module/path',
             'module_name' : 'fake_module',
             'module_args' : 'fake arg',
             'module_lang' : 'fake language'
           }
    # Create an object of class ActionModule
    ActionModuleObject = ActionModule(args, loader)
    # Check if the object is correctly created
    assert ActionModuleObject.module_name == 'fake_module', "ActionModule class constructor has error"
    assert ActionModuleObject.module_args == 'fake arg', "ActionModule class constructor has error"
    assert ActionModuleObject.module_lang == 'fake language', "ActionModule class constructor has error"



# Generated at 2022-06-23 08:16:43.134493
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create an instance of module
    module_obj = ActionModule()

    # Test _supports_async is set as expected
    assert module_obj._supports_async == True

    # Test _supports_check_mode is set as expected
    assert module_obj._supports_check_mode == True

    # Test run method
    assert 'msg' in module_obj.run()

    return

# Generated at 2022-06-23 08:16:54.616231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.normal import ActionModule

    class Host:
        def __init__(self, name):
            self.name = name

    class Loader:
        def __init__(self):
            pass

        def load_from_file(self, filename):
            loader = DictDataLoader()
            return loader.load_from_file(filename)

        def get_basedir(self, filename):
            return os.path.dirname(filename)

    class Task:
        def __init__(self, args):
            self.args = args

    class Connection:
        def __init__(self):
            self.conn_params = ImmutableDict()


# Generated at 2022-06-23 08:16:55.165850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   pass

# Generated at 2022-06-23 08:17:04.710282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.setup import ActionModule as ActionModule_setup
    A = ActionModule(ActionModule_setup, 'setup', False, {})
    # test normal
    A._connection = {'has_native_async':False}
    A._task = {'async':'1000', 'action':'setup', 'async_val':True}
    res = A.run()
    assert res == {'changed': False, 'msg': '', 'failed': False, 'skipped': False}
    assert A._supports_check_mode == True

# Generated at 2022-06-23 08:17:16.114198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_connection = 'mock_connection'
    mock_loader = 'mock_loader'
    mock_templar = 'mock_templar'
    mock_play = 'mock_play'
    mock_task = 'mock_task'
    mock_shared_loader_obj = 'mock_shared_loader_obj'
    mock_task_vars = {'ansible_facts': 'mock_task_vars'}
    a = ActionModule(mock_connection, mock_loader, mock_templar, mock_play, mock_task,
                     mock_shared_loader_obj)
    assert a._shared_loader_obj == mock_shared_loader_obj
    assert a._task._parent == mock_task
    assert a._connection == mock_connection

# Generated at 2022-06-23 08:17:27.162360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.normal import ActionModule
    from ansible.inventory import Host
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

    host = Host(name="localhost")
    task = Task()
    task_vars = {'a':'b'}
    combine_vars(task_vars, HostVars(host=host, variables=task_vars))
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host=host, varname='ansible_python_interpreter', value='/usr/bin/python')
    variable

# Generated at 2022-06-23 08:17:41.166048
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #mock class
    class WrapAsync:
        has_native_async = False

    #mock class
    class Connection:
        def __init__(self, async_val):
            self.has_native_async = async_val

    #mock class
    class Task:
        def __init__(self, async_val):
            self.async_val = async_val
            self.action = 'verbose'

    #mock class
    class ActionBase:
        def run(self, tmp=None, task_vars=None):
            return {'foo': 'bar'}

        def _execute_module(self, task_vars=None, wrap_async=False):
            return {'bar': 'foo'}

        def _remove_tmp_path(self, tmpdir):
            return

# Generated at 2022-06-23 08:17:49.129657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Method run of class ActionModule
    module = ActionModule()
    task_results = dict()
    results = dict(invocation=dict())
    tmp = {}
    task_vars = {}
    wrap_async = False
    result = module._execute_module(task_vars=task_vars, wrap_async=wrap_async)
    results = dict(ansible_facts={'ansible_local': {'inventory': {'paths': 'paths'}}})
    wrap_async = False
    result = module.run(tmp=tmp, task_vars=task_vars)
    results = dict()
    results = dict(invocation=dict(module_args='args'))
    tmp = {}
    task_vars = {}
    wrap_async = False
    result = module._execute

# Generated at 2022-06-23 08:17:49.932666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 08:18:00.068263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.stats import AggregateStats
    #from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    #from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    #from ansible.playbook.base import PlaybookBase
    #from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    #from ansible.playbook.block import Block
    #from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

# Generated at 2022-06-23 08:18:12.054719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.plugins.loader import _find_action_plugin
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import json
    import errno
    import subprocess

    cur_dir = os.path.dirname(os.path.realpath(__file__))
    test_file_path = os.path.join(cur_dir, "test.py")
    os.environ["ANSIBLE_REMOTE_TEMP"] = "/tmp"
