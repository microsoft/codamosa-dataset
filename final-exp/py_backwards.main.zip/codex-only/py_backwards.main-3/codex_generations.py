

# Generated at 2022-06-23 22:26:39.310251
# Unit test for function main
def test_main():
    import subprocess
    import tempfile

    def _test(_args, content, _result):
        with tempfile.NamedTemporaryFile('w', delete=False) as tmp:
            tmp.write(content)
            tmp.close()

        _args += ["-i", tmp.name,
                  "-t", "python2.7",
                  "-o", "output.py",
                  "-r", "",
                  "-d"]

        assert(subprocess.run("py-backwards " + " ".join(_args),
                              shell=True, check=True).returncode == _result)


# Generated at 2022-06-23 22:26:40.660634
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-23 22:26:45.853034
# Unit test for function main
def test_main():
    test_args = ['-i', 'test_resources/test_program.py', 
                 '-o', 'test_resources/test_output.txt', 
                 '-t', '3.5',
                 '-r', 'test_resources/',
                 '-d']
    assert main(test_args) == 0

# Generated at 2022-06-23 22:26:48.817170
# Unit test for function main
def test_main():
    sys.argv += ['--input', './tests/sample', '--output',
                 './tests/output', '--target', 'python36']
    assert main() == 0

# Generated at 2022-06-23 22:26:52.577473
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'test_data/test.py', '-o', 'test_data/new_test.py',
                '-t', '3.5']
    main()

# Generated at 2022-06-23 22:26:54.122985
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:26:56.244130
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:26:59.887403
# Unit test for function main
def test_main():
    sys.argv = [
        '',
        '-i', '../tests/sources',
        '-o', '../tests/output',
        '-t', '2.7'
    ]
    main()


# Generated at 2022-06-23 22:27:03.367614
# Unit test for function main
def test_main():
    assert main([]) == 2
    assert main(["-t", "2.7", "-i", "test/test.py", "-o", "test/test_out.py", "-r", "test"]) == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:13.178175
# Unit test for function main
def test_main():
    args = parser.parse_args(['-i', 'test_case/test.py', '-o', 'out.py', '-t','2.7', '-r', 'test_case/test.py'])
    init_settings(args)
    try:
        for input_ in args.input:
            result = compile_files(input_, args.output,
                                   const.TARGETS[args.target],
                                   args.root)
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1
    except exceptions.TransformationError as e:
        print(messages.transformation_error(e), file=sys.stderr)
        return 1

# Generated at 2022-06-23 22:27:22.631331
# Unit test for function main
def test_main():
    from pathlib import Path
    from tempfile import mkdtemp
    from shutil import rmtree
    test_dirs = {}
    test_dirs["root"] = mkdtemp()
    test_dirs["output"] = mkdtemp()
    test_dirs["input"] = mkdtemp()
    test_dirs["empty"] = mkdtemp()

    for folder in test_dirs.values():
        Path(folder).mkdir()

    Path(Path(test_dirs["input"]) / "empty_file.py").touch()
    Path(Path(test_dirs["input"]) / "file.py").touch()
    Path(Path(test_dirs["input"]) / "package" / "init.py").touch()

# Generated at 2022-06-23 22:27:23.518186
# Unit test for function main
def test_main():
    # TODO: Add unit test
    assert main() == 0

# Generated at 2022-06-23 22:27:33.131193
# Unit test for function main
def test_main():
    target = '2.7'
    input = 'py-backwards/tests/input'
    output = 'py-backwards/tests/output'
    root = 'py-backwards/tests'
    import sys, os
    old_argv = sys.argv
    try:
        sys.argv = ['py-backwards', '-i', input, '-o', output, '-t', target,
                    '-r', root]
        main()
    finally:
        sys.argv = old_argv
    assert os.path.isfile('py-backwards/tests/output/input.py')
    assert os.path.isfile('py-backwards/tests/output/__init__.py')

# Generated at 2022-06-23 22:27:34.149465
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:27:36.014917
# Unit test for function main
def test_main():
    assert False


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:41.153148
# Unit test for function main
def test_main():
    args = ["-i", "file1.py", "file2.py", "-o", "out_folder" "folder1.py",
            "folder2", "-t", "3.5", "-r", ".", "-d"]
    assert main(args) == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:41.709684
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:27:43.648731
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:52.186239
# Unit test for function main
def test_main():

    args = ['-i', 'test/input', '-o', 'test/output', '-t', '2.7']

    args2 = ['-i', 'test/input', '-o', 'test', '-t', '2.7']
    args3 = ['-i', 'test/input', '-o', 'test/output', '-t', '3.6']
    args4 = ['-i', 'test/input', '-o', 'test/output', '-t', '3.6', '-r', 'test/input']
    args5 = ['-i', 'test/input', '-o', 'test/output', '-t', '3.6', '-r', 'test/input', '-d']

    with patch.object(sys, 'argv', args):
        result = main()

# Generated at 2022-06-23 22:27:52.693634
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:53.226770
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:56.093278
# Unit test for function main
def test_main():
    args = sys.argv
    sys.argv = [args[0], "-t", "2.7", "-i", "/home/user/Desktop/py-backwards/test.py", 
    "-o", "/home/user/Desktop/py-backwards/test.py", "-r", "/home/user/Desktop/py-backwards/"]

    main()

    sys.argv = args

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:27:59.360019
# Unit test for function main
def test_main():
    with patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(input='tests/math.py', output='tests/output.py', debug=False, root=False, target='3.5')):
        x = main()
        assert x == 0

# Generated at 2022-06-23 22:28:10.670435
# Unit test for function main
def test_main():
    from unittest import mock
    from . import compiler
    import os
    import shutil

    with mock.patch.object(sys, 'argv', ['py-backwards', '-i', 'a', 'b', 'c',
                                         '-o', 'd', '-t', '2.7', '-r', 'e',
                                         '-d']):
        sys.argv = ['py-backwards', '-i', 'a', 'b', 'c', '-o', 'd', '-t',
                    '2.7', '-r', 'e', '-d']
        args = main()
        assert args.input == ['a', 'b', 'c']
        assert args.output == 'd'
        assert args.target == '2.7'
        assert args.root == 'e'

# Generated at 2022-06-23 22:28:12.266389
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:21.586363
# Unit test for function main
def test_main():
    # test normal execution
    from io import StringIO
    from . import settings
    import sys
    import os

    old_stdout = sys.stdout
    out = StringIO()
    sys.stdout = out

    main_argv = ['py-backwards', '-i', 'example.py', '-o', 'output', '-t', '3.5']
    if os.name == 'nt':
        main_argv = ['python.exe'] + main_argv
    main(main_argv)
    output = out.getvalue().strip()
    assert output == messages.compilation_result({'example.py': True})
    assert settings.DEBUG is False

    # test debug mode
    old_stdout = sys.stdout
    out = StringIO()
    sys.stdout = out

    main

# Generated at 2022-06-23 22:28:23.091941
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:27.071917
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'sources', '-o', 'sources_py2',
                '-d', '-r', 'root', '-t', 'py2']

    args = main()

    assert args == 0

# Generated at 2022-06-23 22:28:33.959257
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]]
    sys.argv.append('-i')
    sys.argv.append('tests/input')
    sys.argv.append('-t')
    sys.argv.append('3.4')
    sys.argv.append('-o')
    sys.argv.append('tests/output')
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:37.741234
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/test_input', '-o', 'test_output', '-t', '2', '-r', 'test_root']
    sys.exit(main())

# Generated at 2022-06-23 22:28:41.576113
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'tests/data/pybackwards/valid-with-comments.py',
        '-o', 'tests/data/pybackwards/valid-with-comments.out.py',
        '-t', '3.4'
    ]
    assert(main() == 0)


# Generated at 2022-06-23 22:28:50.270926
# Unit test for function main
def test_main():
    # everything is okay
    sys.argv = ['py-backwards', '-i', 'hello_backwards.py', '-o', 'output.py', '-t', '3.6']
    assert main() == 0
    # unknown target
    sys.argv = ['py-backwards', '-i', 'hello_backwards.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 1
    # unknown parameters
    sys.argv = ['py-backwards', '-i', 'hello_backwards.py', '-o', 'output.py', '-t', '3.6', '-R', 'root.py']
    assert main() == 1
    # unknown parameters

# Generated at 2022-06-23 22:28:58.419879
# Unit test for function main
def test_main():
    import os
    import tempfile
    import unittest

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.TemporaryDirectory()

        def test_input_not_exists(self):
            with self.assertRaises(SystemExit) as cm:
                main(['nosuchfile'])
            self.assertEqual(cm.exception.code, 1)

        def test_input_dir_empty(self):
            os.makedirs(os.path.join(self.tempdir.name, 'somedir'))

# Generated at 2022-06-23 22:28:58.998519
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 22:29:07.354664
# Unit test for function main
def test_main():
    def fake_argparse(args):
        class FakeArgs:
            def __init__(self):
                self.input = None
                self.output = None
                self.target = None
                self.root = None
                self.debug = None

        if not args:
            return FakeArgs()

        fake_args = FakeArgs()
        for arg in args:
            if arg[0] == '-i':
                fake_args.input = arg[1]
            elif arg[0] == '-o':
                fake_args.output = arg[1]
            elif arg[0] == '-t':
                fake_args.target = arg[1]
            elif arg[0] == '-r':
                fake_args.root = arg[1]

# Generated at 2022-06-23 22:29:11.509131
# Unit test for function main
def test_main():
    args = ['--input', 'foo.py', '--output', 'output.py',
            '--target', 'py34', '--debug']
    with pytest.raises(exceptions.CompilationError) as excinfo:
        main(args)
    excinfo.match(messages.syntax_error(
        'main(): EOL while scanning string literal'))

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:12.164944
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:29:14.817323
# Unit test for function main
def test_main():
    from . import __main__ as main_
    main_.main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:15.638104
# Unit test for function main
def test_main():
    assert main() != 0

# Generated at 2022-06-23 22:29:19.643075
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test_module', '-o', 'out_module', '-t',
                '3.5', '-r', 'root_module']
    assert main() == 0


# Generated at 2022-06-23 22:29:20.952748
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:28.135111
# Unit test for function main
def test_main():
    # Fake input file
    fake_input = "/fakefile"
    # Fake output file
    fake_output = "/fakeout"

    # Main function called with following arguments
    sys.argv = ["py-backwards",
                "-i", fake_input,
                "-o", fake_output,
                "-t", "3.7",
                "-d"]

    # Simulate the call to main
    main()


# Generated at 2022-06-23 22:29:31.785638
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "test/test_folders/test_folder", "-o", "test/test_folders/test_folder_out", "-t",  "2.7", "-r", "test/test_folders/test_folder_out"]
    e = None
    try:
        main()
    except SystemExit as f:
        e = f
    assert e == None


# Generated at 2022-06-23 22:29:33.827754
# Unit test for function main
def test_main():
    main()
    main(["-i","test.py","-o","test.out","-t","2.7","-r", "."])


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:29:34.538746
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:41.386398
# Unit test for function main
def test_main():
    from .test import mock_stdin
    from .test import mock_argv
    from .test import mock_stdout

    with mock_stdin() as stdin, mock_argv(['', '-i', 'a', '-o', 'b', '-t',
                                           '2.7', '-r', 'c', '-d']):
        with mock_stdout() as stdout:
            # It shouldn't raise exception
            assert main() == 0

    with mock_stdin() as stdin, mock_argv(['', '-i', 'a', '-o', 'b', '-t',
                                           '2.7', '-r', 'c']):
        with mock_stdout() as stdout:
            # It shouldn't raise exception
            assert main() == 0


# Generated at 2022-06-23 22:29:51.637992
# Unit test for function main
def test_main():
    assert main() == 1
    assert main('-i', 'compiler', '-o', 'compiler', '-t', '2.7') == 1
    assert main('-i', 'compiler', '-o', 'temp', '-t', '2.7') == 0
    assert main('-i', 'temp', '-o', 'compiler', '-t', '2.7') == 0
    with open('temp/compiler/__init__.py', 'w+') as f:
        f.write('sadasd')
    assert main('-i', 'temp', '-o', 'compiler', '-t', '2.7') == 1
    with open('temp/compiler/__init__.py', 'w+') as f:
        f.write('def test(): pass')

# Generated at 2022-06-23 22:29:53.438399
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:04.433496
# Unit test for function main
def test_main():
    import os
    import shutil
    import argparse
    import pytest
    from io import StringIO
    from contextlib import redirect_stdout
    from .tools import make_dirs
    from .conf import settings
    from . import exceptions
    from .__main__ import main

    def run_main(arguments: list, expected: int = 0,
                 expected_out: str = None) -> str:
        parser = argparse.ArgumentParser()
        parser.add_argument('-o', '--output', type=str, required=True,
                            help='output file or folder')
        args = parser.parse_args(arguments)
        settings.out_dir = make_dirs(args.output)
        settings.debug = True


# Generated at 2022-06-23 22:30:05.878440
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:12.533536
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/files/sample.py', '-o', 'test_out',
                '-t', '2', '-r', 'tests']
    main()
    assert (os.path.isfile('test_out/sample.py'))
    os.remove('test_out/sample.py')
    os.rmdir('test_out')

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:21.537181
# Unit test for function main
def test_main():
    from .test_run import test_main_01, test_main_02, test_main_03, \
        test_main_04, test_main_05, test_main_06, test_main_07, \
        test_main_08, test_main_09, test_main_10, test_main_11, \
        test_main_12, test_main_13, test_main_14, test_main_15, \
        test_main_16, test_main_17, test_main_18, test_main_19, \
        test_main_20, test_main_21, test_main_22, test_main_23
    assert test_main_01() == 0
    assert test_main_02() == 0
    assert test_main_03() == 0
    assert test_main_

# Generated at 2022-06-23 22:30:24.920344
# Unit test for function main
def test_main():
    out = py_backwards.main([])
    assert out == 1
    out = py_backwards.main(['-i', 'input', '-o', 'output', '-v', '3.6'])
    assert out == 1

# Generated at 2022-06-23 22:30:25.622348
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:26.245006
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:31.277829
# Unit test for function main
def test_main():
    source_files = [
        './backwards/const.py',
        './backwards/conf.py',
        './backwards/messages.py'
    ]
    with patch('argparse.ArgumentParser.parse_args', return_value=
        argparse.Namespace(
            output='__tests__/output',
            input=source_files,
            target='2.7',
            debug=True,
            root=abs('.')
        )
    ):
        assert main() == 0
        for filename in source_files:
            with open('{}.2.7'.format(filename)) as f:
                assert f.read() == open('__tests__/output/{}.py'.format(
                    filename.split('/')[1])
                ).read()



# Generated at 2022-06-23 22:30:34.687067
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'task1.py', '-t', '3.4', '-o', 'test.py']
    assert main() == 0


# Generated at 2022-06-23 22:30:44.094452
# Unit test for function main
def test_main():
    import sys
    # test input file
    sys.argv = ['py-backwards', '-i', 'test_compiler/test_file.py',
                '-o', 'test_compiler/result_file.py']
    assert main() == 1
    # test input folder
    sys.argv = ['py-backwards', '-i', 'test_compiler/test_folder',
                '-o', 'test_compiler/result_folder', '-t', '3.4']
    assert main() == 1
    # test output does not exist
    sys.argv = ['py-backwards', '-i', 'test_compiler/test_folder/test_file.py',
                '-o', 'test_compiler/no_result_file.py']
    assert main() == 1
    #

# Generated at 2022-06-23 22:30:51.704645
# Unit test for function main

# Generated at 2022-06-23 22:30:52.359805
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:56.960106
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.extend(['-i', 'tests/test.py', '-o', 'test.py', '-t', '3.5',
                     '--debug'])
    main()

# Generated at 2022-06-23 22:31:09.148196
# Unit test for function main
def test_main():
    import pytest
    from pybackwards._test.test_compiler import (
        get_root_path,
        get_test_file_path,
        get_test_file_output_path)

    # Test that compiler exits with correct return code on wrong input
    # file
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 2

    # Test that compiler exits with correct return code on file that doesn't
    # exists
    with pytest.raises(SystemExit) as e:
        main(['--input', get_test_file_path('nonexistent.py'),
              '--output', get_test_file_output_path('output.py'),
              '--target', '27'])
    assert e.value.code == 1

    # Test that compiler

# Generated at 2022-06-23 22:31:20.174844
# Unit test for function main
def test_main():
    import tempfile
    import os
    import shutil
    from .compiler import compile_files
    from .conf import settings
    import inspect

    # Fake args
    class args(object):
        def __init__(self, input=None, output=None, target=None, root=None, debug=False):
            self.input = input if input is not None else 'input'
            self.output = output if output is not None else 'output'
            self.target = target if target is not None else '2'
            self.root = root if root is not None else 'root' # if not given, it will be set to the path of the first input file
            self.debug = debug
    # create tmp folder
    TMP_DIR = tempfile.mkdtemp()

    # Create input files

# Generated at 2022-06-23 22:31:27.420334
# Unit test for function main
def test_main():
    argv = ['prog', '-i', 'in.py', '-o', 'out.py', '-t', '2.7']
    with patch('argparse.ArgumentParser.parse_args',
               return_value=('in.py', 'out.py', '2.7')):
        with patch('__builtin__.print') as print_mock:
            main()
            assert print_mock.call_args_list.pop(0) == \
                call('Compilation result: 0%')



# Generated at 2022-06-23 22:31:31.726231
# Unit test for function main
def test_main():
    args = ['py-backwards', '-i', 'tests/fixtures/1.py', '-o', 'compiled',
            '-t', '2.7', '-d', '1']
    assert main(args) == 0

# Generated at 2022-06-23 22:31:42.238968
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "--input", "tests/input/func_test.py", "--output", "tests/output/func_test.py", "--target", "2.7", "--debug", "--root", "../py-backwards/"]
    main()
    sys.argv = ["py-backwards", "--input", "tests/input", "--output", "tests/output", "--target", "2.7", "--debug", "--root", "../py-backwards/"]
    main()
    sys.argv = ["py-backwards", "--input", "tests/input/class_test.py", "--output", "tests/output/class_test.py", "--target", "3.5", "--debug", "--root", "../py-backwards/"]

# Generated at 2022-06-23 22:31:47.518464
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', './tests/input_folder', '-o',
                './tests/output_folder', '-t', '3.5', '-r', './tests',
                '-d']
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:48.500794
# Unit test for function main
def test_main():
    init_settings()
    main()

# Generated at 2022-06-23 22:31:57.129737
# Unit test for function main
def test_main():
    # Positive
    sys.argv = ['py-backwards', '-i', 'input-folder', '-o', 'output-folder',
                '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'input-file', '-o', 'output-file',
                '-t', '3.5']
    assert main() == 0

    # Negative
    sys.argv = ['py-backwards', '-i', 'input-file-doesnt-exists', '-o',
    'output-file', '-t', '3.5']
    assert main() == 1

# Generated at 2022-06-23 22:32:05.066922
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')

# Generated at 2022-06-23 22:32:14.843030
# Unit test for function main
def test_main():
    import pytest
    import io
    import os
    import sys

    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    with pytest.raises(Exception):
        main()

    res = main([])
    assert res == 1
    assert bool(sys.stderr.getvalue()) == True

    res = main(['-i', 'f', '-o', 'f', '-t', 'f'])
    assert res == 1
    assert bool(sys.stderr.getvalue()) == True


if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-23 22:32:24.977060
# Unit test for function main
def test_main():
    # Existing file
    main("-i" , "py_backwards/tests/code/conditions.py", "-o", "output", "-t", "2.7")
    main("-i", "py_backwards/tests/code/conditions3.py", "-o", "output", "-t", "2.7")

    # Non-existing file:
    # main("-i" , "py_backwards/tests/code/wrong.py", "-o", "output", "-t", "2.7")

    # File and dir as input
    main("-i" , "py_backwards/tests/code/conditions.py",
         "py_backwards/tests/code/functions", "-o", "output", "-t", "2.7")

    # Dir and file as input

# Generated at 2022-06-23 22:32:26.697507
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:27.516920
# Unit test for function main
def test_main():
    assert(main() == 0)

# Generated at 2022-06-23 22:32:32.378213
# Unit test for function main
def test_main():
    argv = ['-i', 'tests/source', '-o', 'tests/source-copy',
            '-t', '2.7', '-r', 'tests']
    # Exit code equals 0 if all is OK
    assert main(argv) == 0

# Generated at 2022-06-23 22:32:33.415026
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:32:37.004824
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'output.py',
                '-t', '3.6', '-r', 'root']
    assert main() == 0

# Generated at 2022-06-23 22:32:40.799496
# Unit test for function main
def test_main():
    assert main('arbitrary_file_name.py', '-i', 'arbitrary_file_name.py', '-o', 'arbitrary_file_name.py', '-t', 'python_3_6')==1

# Generated at 2022-06-23 22:32:51.530974
# Unit test for function main
def test_main():
    assert main('-h') == 0
    assert main('-i test_data/test.py -o test_data/test.out -t python36').\
        find('Succeed ') > 0
    assert main('-i test_data/test.py -o test_data/test.out -t python34 '
                '-r test_data/test.py').find('Succeed ') > 0
    assert main('-i test_data/test.py -o test_data/test.out -t python36 '
                '-r test_data/test.py').find('Succeed ') > 0
    assert main('-i test_data/test.py -o test_data/test.out -t python35 '
                '-r test_data/test.py').find('Succeed ') > 0

# Generated at 2022-06-23 22:33:02.878473
# Unit test for function main
def test_main():
    # Test 1
    # Test input: py-backwards -i input.py -o output.py -t 2.7 -r root
    sys.argv = ['py-backwards', '-i', 'input.py', '-o',
                'output.py', '-t', '2.7', '-r', 'root']
    main()
    assert sys.argv == ['py-backwards', '-i', 'input.py', '-o',
                        'output.py', '-t', '2.7', '-r', 'root']

    # Test 2
    # Test input: py-backwards -i input.py -o output.py -t 2.7 -r root -d

# Generated at 2022-06-23 22:33:03.372227
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:09.901640
# Unit test for function main
def test_main():
    # Case 1: Try input file
    sys.argv = [
        sys.argv[0],
        '-t', '3.5',
        '-o', '/Users/Mikolaj/Desktop/untitled2.py',
        '-i', 'tests/examples/examples_for_compiler/matmul_example.py',
    ]
    assert main() == 0
    sys.argv = [
        sys.argv[0],
        '-t', '3.5',
        '-o', '/Users/Mikolaj/Desktop/untitled2.py',
        '-i', 'tests/examples/examples_for_compiler/slice_example.py',
    ]
    assert main() == 0

# Generated at 2022-06-23 22:33:11.548559
# Unit test for function main
def test_main():
    return main()

# Generated at 2022-06-23 22:33:13.404895
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'testdata/input.py', '-o', 'testdata/input.py', '-t',
                '3.4', '-r', '.']
    main()

# Generated at 2022-06-23 22:33:17.444858
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_project/src', '-o', 'output',
                '-t', '2.7', '-r', 'test_project']
    main()
    assert True

# Generated at 2022-06-23 22:33:25.444557
# Unit test for function main
def test_main():
    if len(sys.argv) == 2:
        if sys.argv[1] == "true":
            sys.argv[1] = "-t"
            sys.argv.append('3.5.1')
            sys.argv.append('-i')
            sys.argv.append('/home/boris/Documents/py-backwards/tests/tests/example1.py')
            sys.argv.append('-o')
            sys.argv.append('/home/boris/Documents/py-backwards/tests/tests/example1out.py')
        if sys.argv[1] == "false":
            sys.argv[1] = "-t"
            sys.argv.append('3.5.1')
            sys.argv.append('-i')

# Generated at 2022-06-23 22:33:26.703358
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:29.402335
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/data/input/', '-o',
                'tests/data/output/', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-23 22:33:33.024384
# Unit test for function main
def test_main():
    args = ['__init__.py', '-i', 'a_test_file.py', '-o', 'output_file.py', '-t', '2.7']
    assert main(args) == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:37.931019
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests', '-o', 'output', '-t', '2.7', '-d']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:48.300375
# Unit test for function main
def test_main():
    from io import StringIO
    from .unit_test import compile_files as compile_files_test
    from .exceptions import InputDoesntExists, InvalidInputOutput
    compile_files_test.return_value = (('a', 'b'), ('c', 'd'), ('e', 'f'))
    input_ = ['/home/py-backwards/foo', '/home/py-backwards/bar']
    output = '/home/py-backwards/baz'
    target = '2.7'
    root = '/home/py-backwards'
    argv = ['-i', input_[0], input_[1], '-o', output, '-t', target, '-r', root]
    args = main(argv)

# Generated at 2022-06-23 22:33:58.632088
# Unit test for function main
def test_main():
    import io
    from contextlib import redirect_stdout
    from .compiler import compile_files

    f = io.StringIO()
    with redirect_stdout(f):
        sys.argv = ['-i', 'py_backwards/tests/syntax_errors.py', '-t', '3.5', '-o', 'output_file.py']
        main()
        sys.argv = ['-i', 'py_backwards/tests/logical_operators_example.py', '-t', '3.5', '-o', 'output_file.py']
        main()
        sys.argv = ['-i', 'tests/', '-t', '3.5', '-o', 'output_folder']
        main()

# Generated at 2022-06-23 22:34:03.138133
# Unit test for function main
def test_main():
    input_ = ['tests/input/p3.py']
    output_ = 'tests/output'
    target_ = 'py36'

    main()
    output_file = 'tests/output/p3.py'
    with open(output_file, 'r') as file:
        assert file.read() == 'def func(a, b, c=3, *args):\n' \
                              '    return (a, b, c, *args)\n'
    os.system('rm tests/output/p3.py')
    assert os.path.exists('tests/output/p3.py') == False

# Generated at 2022-06-23 22:34:03.728108
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:04.960872
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:13.779156
# Unit test for function main
def test_main():
    import argparse, contextlib, io, sys, types

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    test_argv = ['py-backwards', '-i', 'tests/tests2/test1.py', '-o', 'output/test.py', '-t', 'python2.7', '-r', 'tests']
    sys.argv = test_argv


# Generated at 2022-06-23 22:34:14.366461
# Unit test for function main
def test_main():
    print('No tests')

# Generated at 2022-06-23 22:34:22.846021
# Unit test for function main
def test_main():
    # Successful compilation
    args = ['-i', 'test/test_files/test_good.py', '-o', 'output_good.py',
            '-t', '27']
    sys.argv[1:] = args
    assert main() == 0
    # Fail compilation
    args = ['-i', 'test/test_files/test_bad.py', '-o', 'output_bad.py',
            '-t', '27']
    sys.argv[1:] = args
    assert main() == 1
    # File input and folder output
    args = ['-i', 'test/test_files/test_good.py', '-o', 'test/test_files',
            '-t', '27']
    sys.argv[1:] = args
    assert main() == 0
    # Folder

# Generated at 2022-06-23 22:34:33.630935
# Unit test for function main
def test_main():
    # If the file is not exist
    def side_effect(__):
        raise exceptions.InputDoesntExists
    if sys.version_info[0] == 3:
        with mock.patch('py_backwards.compiler.compile_files',
                        side_effect=side_effect):
            assert main() == 1

    # If the file is exist
    def side_effect(__):
        return 0
    if sys.version_info[0] == 3:
        with mock.patch('py_backwards.compiler.compile_files',
                        side_effect=side_effect):
            assert main() == 0

    # If the file is not exist
    def side_effect(__):
        raise exceptions.TransformationError

# Generated at 2022-06-23 22:34:35.692482
# Unit test for function main
def test_main():
    assert main() == 0
    # assert main() == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:36.333458
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:36.964541
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:38.928914
# Unit test for function main
def test_main():
    assert(main() == 0)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:39.572812
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:34:40.628862
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:34:45.203568
# Unit test for function main
def test_main():
    old_argv = sys.argv
    try:
        sys.argv = 'fake_script.py -i inputfile -o outputfile -t py3.7'.split()
        main()
    finally:
        sys.argv = old_argv


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:47.077716
# Unit test for function main
def test_main():
    import pytest

    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 22:34:50.954307
# Unit test for function main
def test_main():
    init_settings({'input': ['./tests/mock.py'], 'output': './output', 'target': '2.7', 'root': './tests', 'debug': False})
    main()
    assert True

# Generated at 2022-06-23 22:34:53.371063
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'SampleFiles/sample.py', '-o', 'output.py', '-t', 'py27']
    assert main() == 0

# Generated at 2022-06-23 22:34:59.357525
# Unit test for function main
def test_main():
    sys.argv = ["dummy", '-i', '../../tests/test_input/', '-o', '../../tests/test_output/', '-t', '3.5', '-r', '../../tests/']
    assert main() == 0
    sys.argv = ["dummy", '-i', '../../tests/test_input/', '-o', '../../tests/test_output/', '-t', '3.5', '-d']
    assert main() == 0
    sys.argv = ["dummy", '-i', '../../tests/test_input/', '-o', '../../tests/test_output/', '-t', '3.5', '-r', '../../tests/']
    assert main() == 0

# Generated at 2022-06-23 22:35:03.368654
# Unit test for function main
def test_main():
    # Test to ensure correct functionality
    sys.argv = [sys.argv[0], '-i', 'test_input/test.py', '-o', 'test.py',
                '-t', '2.7', '-r', '.', '-d']
    main()

# Generated at 2022-06-23 22:35:04.301715
# Unit test for function main
def test_main():
    args = main()
    assert args == 0

# Generated at 2022-06-23 22:35:06.754466
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/sources/a.py', '-o', 'out',
                '-t', 'py27']
    assert main() == 0

# Generated at 2022-06-23 22:35:11.329021
# Unit test for function main
def test_main():
    sys.argv[1] = '-i'
    sys.argv[2] = 'test.py'
    sys.argv[3] = '-o'
    sys.argv[4] = 'test_out.py'
    sys.argv[5] = '-t'
    sys.argv[6] = 'python2.7'
    main()

# Generated at 2022-06-23 22:35:16.831683
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py',
                '-i', 'tests',
                '-o', '__pycache__',
                '-t', '2.7']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:22.343081
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('../examples/simple/simple.py')
    sys.argv.append('-o')
    sys.argv.append('../examples/simple/simple_compiled.py')
    sys.argv.append('-t')
    sys.argv.append('3.4')
    sys.argv.append('-r')
    sys.argv.append('../examples/simple')
    main()


# Generated at 2022-06-23 22:35:28.083301
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'output.py', '-t', '36']
    assert main() == 0

# Global program entrance
if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:35:28.657887
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:33.874803
# Unit test for function main
def test_main():
    argv = sys.argv
    sys.argv = ['python3.7',
                '-i', 'my_source/my_source.py',
                '-o', 'my_destination/my_destination.py',
                '-t', 'python2.7',
                '-r', 'my_source/my_source.py']
    main()
    sys.argv = argv

# Generated at 2022-06-23 22:35:39.761031
# Unit test for function main
def test_main():
    import pytest
    import re
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as temp_dir:
        with open(os.path.join(temp_dir, 'a.py'), 'w') as f:
            f.write('# test file')
        with open(os.path.join(temp_dir, 'b.py'), 'w') as f:
            f.write('# test file')
        temp_folder = os.path.join(temp_dir, 'folder')
        os.mkdir(temp_folder)
        with open(os.path.join(temp_folder, 'a.py'), 'w') as f:
            f.write('# test file')
        with open(os.path.join(temp_folder, 'b.py'), 'w') as f:
            f

# Generated at 2022-06-23 22:35:40.248892
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:46.544337
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'sample_code.py', '-o',
                'sample_code_transformed.py', '-t', '2.7', '-r', '.']
    return main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:53.008181
# Unit test for function main
def test_main():
    import os
    import os.path
    import shutil
    import tempfile
    import unittest
    import sys

    tests_root = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                              'tests')

    def remove_dir(path):
        if os.path.exists(path):
            shutil.rmtree(path)

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()

        def tearDown(self):
            remove_dir(self.dir)

        def test_main(self):
            for target in const.TARGETS:
                test_dir = os.path.join(tests_root, 'python{}'.format(target))

# Generated at 2022-06-23 22:35:53.631686
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:35:54.254177
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:35:59.378960
# Unit test for function main
def test_main():
    print('Testing the function main()')

    sys.argv = ['py-backwards.py', '-i', './test_sources/', '-o', './test_output/', '-t', 'python2', '-r', './test_sources/']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:00.329075
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:03.705004
# Unit test for function main
def test_main():
    sys_argv = sys.argv.copy()
    sys.argv = ['py-backwards', '-i', 'tests', '-o', 'output',
               '-t', 'python_27']

    assert main() == 0

    sys.argv = sys_argv.copy()

# Generated at 2022-06-23 22:36:12.223365
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/demo.py', '-o', 'test/out.py',
                '-t', '3.6', '-r', 'test']
    assert main() == 0

    sys.argv = ['py-backwards', '-i', 'test/cant_read.py', '-o', 'test/out.py',
                '-t', '3.6', '-r', 'test']
    assert main() == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:22.874301
# Unit test for function main
def test_main():
    with patch('argparse.ArgumentParser.parse_args', return_value=
        argparse.Namespace(input=["file.py"], output= "file.py", target=
            "python2.7")):

        with patch('pybackwards.compiler.compile_files', return_value=3):
            with patch('sys.stdout', new=StringIO()) as fake_out:
                assert main() == 0
                assert fake_out.getvalue() == 'Compiled 3 files\n'


# Generated at 2022-06-23 22:36:32.045908
# Unit test for function main
def test_main():
    class MockArgs:
        def __init__(self):
            self.output = 'test_output.txt'
            self.target = '3.6'

    args = MockArgs()
    args.input = ['../tests/test_input.py']
    assert main() == 0
    os.remove(args.output)

    args.input = ['../tests/test_input.py']
    args.output = 'test_output.py'
    args.root = '../tests/'
    assert main() == 0
    os.remove(args.output)

    args.input = ['../tests/error_input.py']
    args.output = 'error_output.py'
    assert main() == 1
    os.remove(args.output)
