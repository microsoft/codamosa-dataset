

# Generated at 2022-06-23 22:26:32.919236
# Unit test for function main
def test_main():
    return 0

# Generated at 2022-06-23 22:26:37.556910
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', '../testsuite/test_big_sum.py',
                '-o', '../testsuite/test_big_sum.py', '-t', '2.7', '-r',
                '../testsuite/']
    assert main() == 0

# Generated at 2022-06-23 22:26:38.264910
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:39.278662
# Unit test for function main
def test_main():
    # TODO: implement unit test
    pass

# Generated at 2022-06-23 22:26:39.763262
# Unit test for function main
def test_main():
    assert 0 == main()

# Generated at 2022-06-23 22:26:40.830588
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:52.312529
# Unit test for function main
def test_main():
    import os
    import shutil
    from .const import TARGETS
    from .conf import settings

    assert main() == 1

    settings.debug = True

    assert 'python3.4' in TARGETS.keys()
    shutil.copytree('tests', 'tests1')
    os.chdir('tests1')
    assert main() == 1
    os.chdir('..')
    shutil.rmtree('tests1')

    assert 'python2.7' in TARGETS.keys()
    shutil.copytree('tests', 'tests2')
    os.chdir('tests2')
    assert main() == 1
    os.chdir('..')
    shutil.rmtree('tests2')

    assert 'python3.6' in TARGETS.keys()

# Generated at 2022-06-23 22:26:56.369073
# Unit test for function main
def test_main():
    # Run it with wrong argruments
    args = ['py-backwards.py', '-i', 'inp', '-o', 'out', '-t', '2.7']
    with pytest.raises(SystemExit) as e:
        main(args)

    assert e.type == SystemExit
    assert e.value.code == 2

    # Correct arguments
    args = ['py-backwards.py', '-i', 'inp', '-o', 'out', '-t', '3.4']
    main(args)

# Generated at 2022-06-23 22:26:57.457128
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:27:03.156198
# Unit test for function main
def test_main():
    '''
    Check if the parser works fine.
    '''
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append('file.py')
    sys.argv.append('-o')
    sys.argv.append('out')
    sys.argv.append('-t')
    sys.argv.append('3.3')
    assert main() == 1
    sys.argv.append('-r')
    sys.argv.append('root')
    assert main() == 1

# Generated at 2022-06-23 22:27:09.145553
# Unit test for function main
def test_main():
    # test if main function returns 1 for nonexistent input file
    assert main() == 1
    print("main function for nonexistent input file test completed successfully")

    # test if main function returns 1 for nonexistent output directory
    assert main() == 1
    print("main function for nonexistent output directory test completed successfully")

    # test main function for passing all the arguments properly in its
    # run-time
    assert main() == 0
    print("main function for passing all the arguments properly in its run-time")

# Generated at 2022-06-23 22:27:12.003089
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/compiler/resources/input_file.py',
                    '-o', 'tests/compiler/resources/out.py',
                    '-t', '3.4']
    main()

# Generated at 2022-06-23 22:27:12.855072
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:18.508151
# Unit test for function main
def test_main():
    import tempfile
    import os
    import shutil

    # Unit test for invalid output directory
    # with tempfile.TemporaryDirectory() as tmpdirname:
    #     try:
    #         main(['-i', os.path.join(tmpdirname, 'fakeinput.py'),
    #               '-o', os.path.join(tmpdirname, 'fakeoutput'),
    #               '-t', '3.6'])
    #         assert False
    #     except OSError:
    #         pass

    # Unit test for invalid input directory

# Generated at 2022-06-23 22:27:20.850282
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        sys.argv = ['fake', '-i', 'fake_input', '-o', 'fake_output', '-t', '3', '-r', 'fake_root', '-d', 'fake_debug']
        main()

# Generated at 2022-06-23 22:27:24.971855
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.extend(['-t', '2.7', '-i', 'tests/test-files/test.py', '-o', 'temp.py'])
    assert open('temp.py').read() == open('tests/test-files/test.py').read()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:30.746610
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('tests/fixtures/simple.py')
    sys.argv.append('-o')
    sys.argv.append('tests/out/simple.py')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    assert main() == 0


# Generated at 2022-06-23 22:27:31.364735
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:27:38.816421
# Unit test for function main
def test_main():
    # 1. Case - if input is file
    sys.argv = [sys.argv[0], '-i', 'test/compiler/test.py', '-o', 'output',
                '-t', '3.5', '-r', '.']
    assert main() == 0

    # 2. Case - if input is folder
    sys.argv = [sys.argv[0], '-i', 'test/compiler/', '-o', 'output/compiler',
                '-t', '3.5', '-r', '.']
    assert main() == 0

    # 3. Case - if folder is empty

# Generated at 2022-06-23 22:27:49.691129
# Unit test for function main
def test_main():
    import os

    test_dir = os.path.dirname(__file__)
    project_dir = os.path.join(test_dir, os.pardir)
    with open(os.devnull, 'wb') as devnull:
        oldstdout = sys.stdout
        sys.stdout = devnull
        try:
            stderr_str = sys.stderr.getvalue()
        finally:
            sys.stdout = oldstdout
    stderr_str = stderr_str.replace('\033[31m', '')
    stderr_str = stderr_str.replace('\033[39m', '')

    input_file = os.path.abspath(os.path.join(test_dir,
                                              'data/function.py'))
    output

# Generated at 2022-06-23 22:27:51.904878
# Unit test for function main
def test_main():
    try:
        assert __name__ == '__main__'
        assert main() == 0
    except AssertionError:
        print('AssertionError was raised')
        raise

# Generated at 2022-06-23 22:27:56.383845
# Unit test for function main
def test_main():
    # testing when there is no arguments given
    sys.argv = [sys.argv[0]]
    with pytest.raises(SystemExit) as pytest_e:
        main()
    assert pytest_e.type == SystemExit
    assert pytest_e.value.code != 0

    # testing when invalid target is given
    sys.argv = [sys.argv[0], '-i', 'input1.py', '-o', 'output.py', '-r',
                '.', '-t', '3.5']
    with pytest.raises(SystemExit) as pytest_e:
        main()
    assert pytest_e.type == SystemExit
    assert pytest_e.value.code != 0

    # testing when input doesn't exists

# Generated at 2022-06-23 22:28:01.867358
# Unit test for function main
def test_main():
    test_cases = [
        {
            "args": ["-i", "", "-o", "", "-t" "2.7"],
            "expect_error": True,
            "expect_error_type": exceptions.CompilationError
        },
        {
            "args": ["-i", "", "-o", "", "-t" "2.7"],
            "expect_error": False,
            "expect_error_type": exceptions.CompilationError
        }

    ]


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:04.494472
# Unit test for function main
def test_main():
    main()
    main()
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:09.103881
# Unit test for function main
def test_main():
    sys_argv = sys.argv
    sys.argv = sys.argv=['py-backwards', '-i', 'file.py', '-o', 'output.py',
                         '-t', '3.5']
    assert main() == 0
    sys.argv = sys_argv

# Generated at 2022-06-23 22:28:09.680530
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:28:10.587053
# Unit test for function main
def test_main():
    assert main() == 0
    #assert main() == 1

# Generated at 2022-06-23 22:28:12.855359
# Unit test for function main
def test_main():
    try:
        assert main() == 1
    except:
        assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:16.845779
# Unit test for function main
def test_main():
    # Create argparse argumnent
    args = ArgumentParser
    args.input = 'tests/test_module.py'
    args.output = 'tests/py36_module.py'
    args.target = '3.6'
    args.root = None
    #Test
    assert main(args) == 0

# Generated at 2022-06-23 22:28:18.999090
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:24.720299
# Unit test for function main
def test_main():
    init_settings(args)
    assert main(['-i', '../tests/test.py' ,'-o', '../dist/test.py', '-t', '2.7',
                 '-r', '../tests/']) == 0
    assert main(['-i', '../tests/test.py','-o', '../dist/test.py', '-t', '3.6',
                 '-r', '../tests/']) == 0

# Generated at 2022-06-23 22:28:27.039983
# Unit test for function main
def test_main():
    #print(main())
    assert True


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:30.988140
# Unit test for function main
def test_main():
    sys.argv = ['/home/asdf', '-i', '/home/A/..', '-o', '~', '-t', '3.6', '-r', 'src', '-d']
    assert(main() == 0)

# Generated at 2022-06-23 22:28:32.300638
# Unit test for function main
def test_main():
    init_settings(None)
    assert main() == 0

# Generated at 2022-06-23 22:28:36.749073
# Unit test for function main
def test_main():
    test_input = ['test/files/input_files/a.py', 'test/files/input_files/c.py']
    test_output = 'test/files/output_files/'
    test_target = '3.5'
    sys.argv = sys.argv[:1] + ['-i'] \
                     + test_input \
                     + ['-o', test_output] \
                     + ['-t', test_target]

    sys.exit(main())


# Generated at 2022-06-23 22:28:44.355549
# Unit test for function main

# Generated at 2022-06-23 22:28:54.253834
# Unit test for function main
def test_main():
    # Check bad arguments
    args = '-i test/invalid-argument.py -o output -t 2.7'.split()
    try:
        main(args)
    except SystemExit as e:
        assert e

    # Check compilation error
    args = '-i test/input/compilation-error.py -o output -t 2.7'.split()
    assert main(args) == 1

    # Check transformation error
    args = '-i test/input -o output -t 2.7'.split()
    assert main(args) == 1

    # Check input doesn't exists error
    args = '-i test/input/doesnt-exists.py -o output -t 2.7'.split()
    assert main(args) == 1

    # Check invalid input/output error

# Generated at 2022-06-23 22:28:55.414600
# Unit test for function main
def test_main():
    assert main() in (0, 1)

# Generated at 2022-06-23 22:28:55.977423
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:29:05.268792
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i', '../test_data/test1.py', '-o', 'test_data/test1_out.py', '-t', '2.7', '-d']

# Generated at 2022-06-23 22:29:08.346757
# Unit test for function main
def test_main():
    argv = sys.argv
    sys.argv = ['py-backwards', '-t', 'python27', '-i', 'test.py', '-o', 'out.py', '-r', '.']
    main()
    sys.argv = argv


# Generated at 2022-06-23 22:29:11.279341
# Unit test for function main
def test_main():
    args = ['py-backwards', '-i', 'tests', '-o', 'py36', '-t', 'py36', '-r', 'tests']
    assert main() == 0

# Generated at 2022-06-23 22:29:22.847935
# Unit test for function main
def test_main():
    import sys
    from io import StringIO
    from .conf import init_settings, settings
    from .compiler import compile_files
    init_settings(['dummy', '-i', 'test/test_data', '-o', 'test/result',
                   '-r', 'test', '-d', '-t', 'CPython37'])
    with open('compiler.py') as f:
        program = f.read()
    with open('test/test_data/test_data.py', 'w') as f:
        f.write(program)
    old_stdout = sys.stdout
    output = StringIO()
    sys.stdout = output
    compile_files('test/test_data/test_data.py', 'test/result',
                  'CPython37')
    assert output.getvalue

# Generated at 2022-06-23 22:29:29.920846
# Unit test for function main
def test_main():
    # Replace command line argv by unitest data
    sys.argv = [
        'py-backwards',
        '-i', 'tests/input/classes.py',
        '-o', 'output.py',
        '-t', '3.5'
    ]
    assert main() == 0
    assert main() == 0
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:30.607917
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:33.007582
# Unit test for function main
def test_main():
    args = ['py-backwards','-i','setup.py','-o','out','-t','2.7']
    assert main(args) == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:33.462011
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:40.574442
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:29:41.197953
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:51.437615
# Unit test for function main
def test_main():
    from .testutils import TestCase, MockFile

    class TestMain(TestCase):
        def test_main(self):
            f_in = ('f_in', 'f_out')
            f_out = ('f_out', 'f_in')

            files = [
                MockFile(None, f_in, 'abc'),
                MockFile(None, f_out, 'abc'),
                MockFile(None, f_in, 'def'),
                MockFile(None, f_out, 'def'),
                MockFile(None, f_in, 'ghi'),
                MockFile(None, f_out, 'ghi'),
            ]

            for f in files:
                f.open()


# Generated at 2022-06-23 22:29:53.085100
# Unit test for function main
def test_main():
    # TODO: Make unit test for main method
    pass

# Generated at 2022-06-23 22:30:04.180868
# Unit test for function main
def test_main():
    # Test input and output paths
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'output', '-t', '27',
                '-r', 'src']
    assert main() == 0

    # Test incorrect target version
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'output', '-t', '30',
                '-r', 'src']
    assert main() == 1

    # Test incorrect input file
    sys.argv = ['py-backwards', '-i', 'test_test1.txt', '-o', 'output', '-t', '27',
                '-r', 'src']
    assert main() == 1

    # Test incorrect output file

# Generated at 2022-06-23 22:30:04.802422
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:30:05.417817
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:08.015303
# Unit test for function main
def test_main():
    sys.argv = ['command', '-i', 'input.py', '-o', 'output.py', '-t', 'py26']
    main()
    assert True

# Generated at 2022-06-23 22:30:09.927712
# Unit test for function main
def test_main():
    pass
# -----------------

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:10.561008
# Unit test for function main
def test_main():
    print(main())

# Generated at 2022-06-23 22:30:16.207085
# Unit test for function main
def test_main():
    from . import tests
    from .conf import settings
    import os

    if os.path.exists(tests.DIR + '/result'):
        os.system('rm -r ' + tests.DIR + '/result')
    os.system('mkdir ' + tests.DIR + '/result')
    assert main() == 0
    assert settings.get_value('debug') is True


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:30:20.433534
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        assert main() == 0
        assert pytest_wrapped_e.type == SystemExit
        assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-23 22:30:22.210180
# Unit test for function main
def test_main():
    init_settings('tests/sources', 'tests/output', '2.7')
    main()

# Generated at 2022-06-23 22:30:22.849978
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:30:25.803094
# Unit test for function main
def test_main():
    try:
        # if __name__ == "__main__":
        #     main()
        main()
    except SystemExit:
        pass

# if __name__ == "__main__":
#     main()

# Generated at 2022-06-23 22:30:26.401249
# Unit test for function main
def test_main():
    # TODO: write unit test for function main
    pass

# Generated at 2022-06-23 22:30:27.124209
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:32.049102
# Unit test for function main
def test_main():
    # We want to test function print,
    # it can be done only with monkeypatching
    # and we can't use pytest fixtures because
    # they are created in two different processes
    from mock import patch

    def monkeypatch_print(s):
        pass

    with patch('builtins.print', monkeypatch_print):
        # Targeting code after print function
        with open('tests/output_folder/a.py', 'w'):
            pass
        with open('tests/input_folder/b.py', 'w'):
            pass

        args = ['tests/input_folder/b.py',
                '-o', 'tests/output_folder/a.py',
                '-t', 'py35',
                '-r', 'tests/input_folder/']
        assert main(args) == 0

# Generated at 2022-06-23 22:30:42.581472
# Unit test for function main
def test_main():
    '''
    Тестирование функции main()
    '''
    if args.input == True:
        assert compile_files('python.py', 'python36.py') == 0
        assert compile_files('python.py', 'python35.py') == 0
        assert compile_files('python.py', 'python34.py') == 0
        assert compile_files('python.py', 'python33.py') == 0
        assert compile_files('python.py', 'python32.py') == 0
        assert compile_files('python.py', 'python31.py') == 0
        assert compile_files('python.py', 'python30.py') == 0
        assert compile_files('python.py', 'python27.py') == 0

# Generated at 2022-06-23 22:30:43.187061
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:48.517489
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0],
                '-i', 'input_file',
                '-o', 'output_file',
                '-t', 'python2.7']
    assert main() == 1

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:53.252075
# Unit test for function main
def test_main():
    # Make sure main function works fine
    # Valid input
    sys.argv = ['', '-t', '2.7', '-i', 'test/test_data/valid_2.7/test.py',
                '-o', 'test/test_data/valid_2.7/test_out/test.py']
    assert main() == 0

# Generated at 2022-06-23 22:30:53.883831
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:01.015794
# Unit test for function main
def test_main():
    sys.argv = ["main","-i", "a.py", "-o", "b.py", "-t", "py35", "-r", "root"]
    assert main() == 0
    sys.argv = ["main","-i", "a.py", "-o", "b.py", "-t", "py35", "-r", "root"]
    assert main() == 0
    sys.argv = ["main","-i", "a.py", "-o", "b.py", "-t", "py35", "-r", "root"]
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:07.215770
# Unit test for function main
def test_main():
    input_ = 'test'
    output = 'out'
    target = '3.0'
    expect = 1
    assert main([input_, '-o', output, '-t', target]) == expect
    input_ = 'test'
    output = 'out'
    target = '3.8'
    expect = 0
    assert main([input_, '-o', output, '-t', target]) == expect

# Generated at 2022-06-23 22:31:13.115876
# Unit test for function main
def test_main():
    sys.argv.extend(["-i", "tests/input/test.py", "-o", "tests","-t", "2.7", "-r", "tests/input"])
    main()
    assert os.listdir(os.getcwd()+"/tests/input") != os.listdir(os.getcwd()+"/tests/")


# Generated at 2022-06-23 22:31:14.372496
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert(e.code==0)

# Generated at 2022-06-23 22:31:15.409398
# Unit test for function main
def test_main():
    pass
    

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:31:16.215827
# Unit test for function main
def test_main():
    # TODO
    return 0

# Generated at 2022-06-23 22:31:23.838788
# Unit test for function main
def test_main():
    # input tests
    with patch('sys.argv', ['app', '-o', 'test/test_result.py', '-i', 'test/test_input.py',
                            '-i', 'test/test_input2.py', '-t', '2.7']):
        assert main() == 0
    with patch('sys.argv', ['app', '-i', 'test/test_input.py', '-i2', '-t', '3.6']):
        assert main() == 1
    with patch('sys.argv', ['app', '-i', 'test/test_input.py', '-o', 'test/test_input.py', '-t', '3.6']):
        assert main() == 1

# Generated at 2022-06-23 22:31:25.382794
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:31:27.040163
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-23 22:31:31.186565
# Unit test for function main
def test_main():
    class Args:
        debug = False
        target = '3.4'
        input = [TEST_INPUT]
        output = TEST_OUTPUT
        root = None
    init_settings(Args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:40.274228
# Unit test for function main
def test_main():
    args = ['1.py', 'another.py', "doesn't exist.py"]
    input_ = 'test/test_input'
    output = 'test/test_output'
    target = '2.7'
    root = 'test'

    def fake_args(input, output, target, root):
        args = argparse.Namespace()
        args.input = input
        args.output = output
        args.target = target
        args.root = root
        args.debug = False
        return args

    args = fake_args(input_, output, target, root)
    try:
        main()
    except SystemExit:
        raise

    # Setting output to input
    args = fake_args(input_, input_, target, root)
    try:
        main()
    except:
        raise



# Generated at 2022-06-23 22:31:49.170911
# Unit test for function main
def test_main():

    # Test Arguments
    sys.argv = [
        'py-backwards',
        '-i', './tests/sources_py_backwards/',
        '-o', './tests/outputs_py_backwards/',
        '-t', '2.7'
    ]
    assert main() == 0

    sys.argv = [
        'py-backwards',
        '-i', './tests/sources_py_backwards/',
        '-o', './tests/outputs_py_backwards/',
        '-t', '3.6'
    ]
    assert main() == 0

    # Test Error

# Generated at 2022-06-23 22:31:52.254851
# Unit test for function main
def test_main():
    input_ = 'input'
    output = 'output'
    target = const.PY_36
    root = '/'
    args = ['program_name', '-i', input_, '-o', output, '-t', target, '-r', root]
    try:
        main(args)
    except SystemExit:
        pass

# Generated at 2022-06-23 22:31:52.820548
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:31:53.278593
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:56.286969
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'out', '-t', '3.4']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:57.799786
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:00.981898
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        print("exception: ", e.code)
        assert(e.code == 1)

# Generated at 2022-06-23 22:32:08.949176
# Unit test for function main
def test_main():
    input_ = ['tests/inp_folder', 'tests/inp_folder_correct']
    output = 'output'
    target = '2.7'
    root = '.'
    args = '-i'
    for i in input_:
        args += ' ' + i
    args += ' -o ' + output + ' -t ' + target + ' -r ' + root
    sys.argv = ['py_backwards.py'] + args.split()
    main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:11.691456
# Unit test for function main
def test_main():
    main()
    return


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:18.976717
# Unit test for function main
def test_main():
    from py_backwards.core.conf import settings
    from py_backwards.core import exceptions

    settings.debug = settings.target = settings.root = settings.output = settings.input = None
    with pytest.raises(exceptions.SettingsNotInitialized):
        main()

    settings.debug = False
    settings.target = "3.5"
    settings.root = 'C:\py-backwards\test'
    settings.input = 'in.py'
    settings.output = 'out.py'
    assert main() == 0

# Generated at 2022-06-23 22:32:19.612375
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:21.334911
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:23.119136
# Unit test for function main
def test_main():
    return main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:23.771623
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:25.529388
# Unit test for function main
def test_main():
    args1 = main()
    args2 = main()
    assert 0 == args1
    assert 0 == args2

# Generated at 2022-06-23 22:32:33.219552
# Unit test for function main
def test_main():
    from subprocess import Popen, PIPE
    from unittest import TestCase

    class TestPyBackwards(TestCase):
        def test_compilation(self):
            file_path = 'tests/compile_test.py'
            with open(file_path, 'w') as test_file:
                test_file.write('a = (1, 2, 3)\n')
                test_file.write('b = 1, 2, 3\n')
                test_file.write('c = "hello " + "world"\n')
                test_file.write('d = "hello " + str(1)\n')


# Generated at 2022-06-23 22:32:38.127170
# Unit test for function main
def test_main():
    example_argv = ['-i', 'main/main.py', '-o', 'main/main.pyc', '-t', '2.7', '-r', 'main', '-d', 'False']
    sys.argv = [sys.argv[0]] + example_argv
    assert main() == 0

# Generated at 2022-06-23 22:32:38.937122
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:43.084885
# Unit test for function main
def test_main():
    assert 1 == main(['-i', 'test.py', '-o', 'test2.py', '-t', '3.3'])

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:47.182160
# Unit test for function main
def test_main():
    args = ['py-backwards', '-i', 'py-backwards',
            '-o', 'py-backwards/tests/result', '-t', '2.7', '-d', '-r', 'py-backwards']
    sys.argv = args
    main()

# Generated at 2022-06-23 22:32:48.870907
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as excinfo:
        main()
    assert excinfo.value.code == 2

# Generated at 2022-06-23 22:32:49.985639
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:01.726659
# Unit test for function main
def test_main():
    # No args case
    #sys.argv = []
    #assert main() == 'Success'
    #sys.argv = []
    #assert main() == 'Success'
    #sys.argv = []
    #assert main() == 'Success'
    #sys.argv = []
    #assert main() == 'Success'
    #sys.argv = []
    sys.argv = ['pyBackwards', '--input', 'sample.py', '--output', 'sample.py.bak', '-t', '2.7']
    #assert main() == 'Success'
    assert main() == 0
    sys.argv = []
    #assert main() == 'Success'
    #assert main() == 'Success'
    #assert main() == 'Success'
    #assert main() == 'Success'
   

# Generated at 2022-06-23 22:33:02.210975
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:05.015763
# Unit test for function main
def test_main():
    args = ('--input=tests/sample --output=tests/output --target=3.5 -r ./'.split())
    assert main([sys.argv[0]] + args) == 0


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:33:10.930543
# Unit test for function main
def test_main():
    input = 'test1.py'
    output = 'test.py'
    target = '2.6'
    target2 = '3.4'
    root = 'test.py'
    root = 'test' 
    root = 'test.py'
    # function main is working
    assert main(['-i', input, '-o', output, '-t', target]) == 0
    # function main is working if you give invalid target
    assert main(['-i', input, '-o', output, '-t', target2]) == 1
    # function main is working if you give invalid root
    assert main(['-i', input, '-o', output, '-t', target, '-r', root]) == 1
    # function main is working if you give valid root

# Generated at 2022-06-23 22:33:21.271488
# Unit test for function main
def test_main():
    from io import StringIO
    import ast
    import shutil
    import os
    from . import compiler

    def get_result(args):
        out = StringIO()
        sys.stdout = out
        result = main(args)
        sys.stdout = sys.__stdout__
        return result, out.getvalue()


# Generated at 2022-06-23 22:33:21.772127
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:33:23.759320
# Unit test for function main
def test_main():
    main_args = main()
    main_args == 0
    # assert main_args == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:24.601582
# Unit test for function main
def test_main():
    assert main() == 0, "Unit test failed"

# Generated at 2022-06-23 22:33:25.114647
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:34.568597
# Unit test for function main
def test_main():
    # target= python3_6 - input = some_file.py - output = result_folder
    sys.argv = [sys.argv[0], "-i", "samples/inputs/some_file.py", "-o", "result_folder", "-t", "3.6"]
    assert main() == 0

    # target= python3_6 - input = samples - output = result_folder
    sys.argv = [sys.argv[0], "-i", "samples", "-o", "result_folder", "-t", "3.6"]
    assert main() == 0

    # target= python3_6 - input = samples - output = results
    sys.argv = [sys.argv[0], "-i", "samples", "-o", "results", "-t", "3.6"]

# Generated at 2022-06-23 22:33:46.141753
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:33:50.717380
# Unit test for function main
def test_main():
    args = parse_args(["-i", "inp.py",
                       "-o", "out.py",
                       "-t", "3.5"])
    settings = init_settings(args)
    res = compile_files(args.input, args.output, const.TARGETS[args.target])
    assert res[0] == 0
    assert res[1] == 0

# Generated at 2022-06-23 22:33:54.028022
# Unit test for function main
def test_main():
    sys.argv += ['-i', 'test/test.py', '-o', 'test/output', '-t', '3.4', '-r', 'test']
    assert main() == 0

# Generated at 2022-06-23 22:33:55.376264
# Unit test for function main
def test_main():
    import pytest
    # TODO: Add example usage
    pass

# Generated at 2022-06-23 22:33:56.894783
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'src', '-o', 'bin', '-t', '3.5', '-r', 'src', '-d']
    assert main() == 0

# Generated at 2022-06-23 22:33:57.489418
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:58.042216
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:03.753590
# Unit test for function main
def test_main():
    # Testing with a file
    sys.argv = ['py-backwards', '-i', 'tests/data/input.py', '-o', 'tests/data/output.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/data/input.py',
                '-o', 'tests/data/output.py', '-t', '2.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/data/input.py', '-o',
                'tests/data/output.py', '-t', '2.6']
    assert main() == 0

    # Testing with a folder

# Generated at 2022-06-23 22:34:06.816814
# Unit test for function main
def test_main():
    test_in = ["test1.py", "test2.py"]
    assert main(test_in, "./test", "3.7") == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:13.507433
# Unit test for function main
def test_main():
    inp = sys.stdin
    out = sys.stdout
    sys.stdin = open('tests/pip/input.txt', 'r')
    sys.stdout = open('tests/pip/output.txt', 'w')
    try:
        assert main() == 0
        assert open('tests/pip/output.txt', 'r').read() == open(
            'tests/pip/output_expected.txt', 'r').read()
    finally:
        sys.stdin = inp
        sys.stdout = out
        open('tests/pip/output.txt', 'w').close()

# Generated at 2022-06-23 22:34:18.662613
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test.py',
                '-o', 'tests/result.py', '-t', 'python3.5', '-r', 'tests']

    messages.reset()
    result = main()
    assert result == 0
    assert messages.output == ['Compiled and written 1 file, 0 skipped.']

# Generated at 2022-06-23 22:34:29.385484
# Unit test for function main
def test_main():
    from unittest.mock import MagicMock, patch
    import io
    from .exceptions import InputDoesntExists, PermissionError
    from .compiler import compile_files as mocked_compile_files
    mocked_compile_files = MagicMock(return_value=1)
    with patch('sys.stdout', new_callable=io.StringIO) as fake_stdout, \
         patch("argparse.FileType", side_effect=InputDoesntExists("")), \
         patch("sys.stderr", new_callable=io.StringIO) as fake_stderr:
        assert main() != 0
        fake_stderr.seek(0)
        exception = fake_stderr.read()
        assert exception == "Input file or folder doesn't exists!\n"
        assert mocked

# Generated at 2022-06-23 22:34:32.020551
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_files/', '-o', 'out/', '-t', '3.5', '-d']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:33.508920
# Unit test for function main
def test_main():
    init_settings(ArgumentParser().parse_args())
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-23 22:34:42.355337
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append('test/test_files')
    sys.argv.append('-o')
    sys.argv.append('test/output_folder')
    sys.argv.append('-t')
    sys.argv.append('3.6')
    sys.argv.append('-r')
    sys.argv.append('test/test_files')
    sys.argv.append('-d')
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:46.141805
# Unit test for function main
def test_main():
    # set up 
    sys.argv = [
            'py-backwards',
            '-i', './test/test.py',
            '-o', './test/test.py',
            '-t', '3.5',
            '-r', './test',
            '-d',
            ]
    main()
    # clean up
    os.remove('./test/test.py')

# Generated at 2022-06-23 22:34:51.476032
# Unit test for function main
def test_main():
    class args:
        input = ['test_input/await.py']
        output = 'test_output/await.py'
        target = '2.7'
        root = 'await.py'
        debug = False
    init_settings(args)
    assert main() == 0

# Generated at 2022-06-23 22:35:02.264670
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:35:04.504023
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        if e.code == 0:
            pass
        else:
            assert (e.code == 1)

# Generated at 2022-06-23 22:35:06.270276
# Unit test for function main
def test_main():
    # Parameter parser is tested in tests/argtest.py
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:08.085738
# Unit test for function main
def test_main():
    assert main() == 0
    
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:09.407537
# Unit test for function main
def test_main():
    """
    Unit tests for main.
    """
    pass

# Generated at 2022-06-23 22:35:14.239113
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'C:\\Users\\evgen\\projects\\py-backwards\\tests\\test.py',
                '-o', 'C:\\Users\\evgen\\projects\\py-backwards\\tests\\test2.py',
                '-t', 'python2', '--debug']

    assert main() == 0


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:35:18.052620
# Unit test for function main
def test_main():
    argv = sys.argv
    try:
        sys.argv = ['', '-i', 'tests/examples/add.py', '-o', 'output', '-t',
                    'py36', '-d', '-r', 'tests/examples']
        assert main() == 0
    finally:
        sys.argv = argv

# Generated at 2022-06-23 22:35:24.676750
# Unit test for function main
def test_main():
    # Test one file
    from unittest.mock import patch
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as mock_input, \
            NamedTemporaryFile() as mock_output, \
            patch('py_backwards.compiler.compile_files',
                  return_value={'code': 'code', 'deprecated': True,
                                'skipped': False}), \
            patch('sys.argv',
                  ['py-backwards', '-i', mock_input.name,
                   '-o', mock_output.name,
                   '-t', 'python35',
                   '-r', '/Users/user/project']):
        assert main() == 0

    # Test multiple files

# Generated at 2022-06-23 22:35:26.491530
# Unit test for function main
def test_main():
    try:
        exit(main())
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-23 22:35:28.911151
# Unit test for function main
def test_main():
    # Test that the compilation was successful
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:29.490118
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:30.108705
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:35:34.735372
# Unit test for function main
def test_main():
    input_ = sys.argv[0]
    output = "output.py"
    args = ArgumentParser('py-backwards')
    init_settings(args)
    compile_files(input_, output, 3.6)
    assert filecmp.cmp(input_, output)

# Generated at 2022-06-23 22:35:40.660074
# Unit test for function main
def test_main():
    main()
    main('-i main.py -o output.py -t 2.7')
    main('-i main.py -o output.py -t 3')
    main('-i main.py -o output.py -t 3.5')
    main('-i main.py -o output.py -t 3.6')
    main('-i main.py -o output.py -t 3.7')
    main('-i main.py -o output.py -t 3.8')
    main('-i main.py -o output.py -t 3.9')
    main('-i main.py -o output.py -t 4')
    main('-i main.py -o output.py -t 4.1')
    main('-i main.py -o output.py -t 4.2')

# Generated at 2022-06-23 22:35:47.889736
# Unit test for function main
def test_main():
	# Test case 1: input directory contains python files, output directory exists, debug flag is on
	assert main() == 0
	# Test case 2: input directory contains python files, output directory exists, debug flag is off
	assert main() == 0
	# Test case 3: input directory doesn't exist
	assert main() == 1
	# Test case 4: input and output directory are the same
	assert main() == 1
	# Test case 5: output directory doesn't exist
	assert main() == 1
	# Test case 6: debug flag is on
	assert main() == 0
	# Test case 7: input file doesn't exist
	assert main() == 1
	# Test case 8: output file doesn't exist
	assert main() == 1

# Generated at 2022-06-23 22:35:58.928069
# Unit test for function main
def test_main():
    from argparse import Namespace
    from pybackwards.const import TARGETS
    from pybackwards.conf import PY2, PY3, PY34

    argv = []
    sys.argv = argv
    main()
    assert sys.argv == argv
    sys.argv.append('-i')
    main()
    assert sys.argv == argv

    sys.argv.append('test_file')
    main()
    assert sys.argv == argv

    sys.argv.append('-o')
    main()
    assert sys.argv == argv

    sys.argv.append('-t')
    main()
    assert sys.argv == argv

    sys.argv.append('tests')
    main()
    assert sys.argv == argv



# Generated at 2022-06-23 22:36:01.900761
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards.py","-i","../tests/test_folder","-o","../tests/output","-t","3.5", "-r","../tests"]
    assert main() == 0

# Generated at 2022-06-23 22:36:13.558631
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as exc:
        main(['pyb', '-i', 'tests/integration/input_data/input1', '-o',
              'tests/integration/output/', '-t', '2'])
        assert exc.value.code == 0
    with pytest.raises(SystemExit) as exc:
        main(['pyb', '-i', 'tests/integration/input_data/input1', '-o',
              'tests/integration/output/', '-t', '2', '-r', 'tests/integration'])
        assert exc.value.code == 0

# Generated at 2022-06-23 22:36:17.440731
# Unit test for function main
def test_main():
    """
    Unit test for main function
    """
    sys.argv = ['py_backwards', '-i', 'tests/test_files/test.py', '-o', 'output/test.py', '-t', '2.7' ]
    assert main() == 0



# Generated at 2022-06-23 22:36:22.186775
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.extend(['-i', 'tests/fixtures/1.py',
                     '-i', 'tests/fixtures/2.py',
                     '-o', 'tests/output/',
                     '-t', '2.6'
                     ])
    assert main() == 0

###
if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:36:22.935482
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:23.627954
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:36:30.454394
# Unit test for function main
def test_main():
    target = '3.4'
    root = './tests/sample_package/'
    input_ = root + 'src/dir1/dir2/dir3/file.py'
    output = root + 'target'
    sys.argv = ['py-backwards', '-i', input_, '-o', output, '-t', target,
                '-r', root, '-d']
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:32.635494
# Unit test for function main
def test_main():
    assert (main() == 0)
if __name__ == '__main__':
    sys.exit(main())