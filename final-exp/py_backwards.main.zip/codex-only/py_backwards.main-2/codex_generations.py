

# Generated at 2022-06-23 22:26:41.722027
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')

    parser.add_argument('-i', '--input', type=str, nargs='+', required=True, help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True, help='output file or folder')
    parser.add_argument('-t', '--target', type=str, required=True, choices=const.TARGETS.keys(), help='target python version')
    parser.add_argument('-d', '--debug', action='store_true', required=False, help='enable debug output')

    args = parser.parse_args()
    
    assert(main() == 0)


# Generated at 2022-06-23 22:26:43.727864
# Unit test for function main
def test_main():
    #TODO: write tests
    return True


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:26:49.035909
# Unit test for function main
def test_main():
    argv = [sys.argv[0], "-i",
            "tests/integration/fixtures/module1.py",
            "tests/integration/fixtures/module2.py",
            "-o", "tests/integration/compiled_fixtures",
            "-t", "3.4",
            "-d"]

    main()

# Generated at 2022-06-23 22:26:59.832575
# Unit test for function main
def test_main():
    # Test 1
    sys.argv = ['py-backwards', '-t', '3.6', '-i', '/home/test.py', '-o', '/home',]
    init_settings(sys.argv)
    
    # Test 2
    sys.argv = ['py-backwards', '-t', '3.6', '-i', '/home', '-o', '/home',]
    init_settings(sys.argv)
    
    # Test 3
    sys.argv = ['py-backwards', '-t', '3.6', '-i', '/home/test.py', '-o', '/home/test1.py',]
    init_settings(sys.argv)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:06.817330
# Unit test for function main
def test_main():
    argv = ['-i',
            'test_resources/test_resources/test_module_1.py',
            'test_resources/test_resources/test_module_2.py',
            'test_resources/test_resources/test_module_3.py',
            '-o', 'test_resources',
            '-t', '2.7',
            '-r', 'test_resources']
    status = main()
    assert status == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:08.218198
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except:
        print("Error in file " + __file__)
        raise

# Generated at 2022-06-23 22:27:08.615154
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:09.288905
# Unit test for function main
def test_main():
    init_settings()
    assert main() == 1

# Generated at 2022-06-23 22:27:10.486055
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 22:27:11.029864
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:15.337421
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', './tests/test_main.py',
                '-o', './tests/test_main.py', '-t', '3', '-r',
                './tests/']

    assert(main() == 0)

# Generated at 2022-06-23 22:27:21.080023
# Unit test for function main
def test_main():
    """
    It's the main for testing.
    """
    import sys
    sys.argv[1] = '-i'
    sys.argv[2] = 'scr/tests/syntax'
    sys.argv[3] = '-o'
    sys.argv[4] = 'tests/output/'
    sys.argv[5] = '-t'
    sys.argv[6] = 'python35'
    main()


# Generated at 2022-06-23 22:27:22.089571
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except SystemExit:
        pass

# Generated at 2022-06-23 22:27:28.323082
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-23 22:27:37.253418
# Unit test for function main

# Generated at 2022-06-23 22:27:48.038145
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('input')
    sys.argv.append('-o')
    sys.argv.append('output')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    sys.argv.append('-r')
    sys.argv.append('root')
    sys.argv.append('--debug')
    main()
    del sys.argv[-1]
    del sys.argv[-1]
    del sys.argv[-1]
    del sys.argv[-1]
    del sys.argv[-1]
    del sys.argv[-1]
    del sys.argv[-1]
    del sys.argv[-1]



# Generated at 2022-06-23 22:27:58.766535
# Unit test for function main
def test_main():
    from io import StringIO
    from .compiler import compile_files, patch_ast
    from .conf import init_settings
    import const, messages, exceptions
    import os
    import shutil
    import tempfile


# Generated at 2022-06-23 22:28:02.243338
# Unit test for function main
def test_main():
    assert main(['-i', 'tests/input/', '-o', '/tmp/output/', '-t', '2.7', '-r', 'tests/']) == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:28:07.339065
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwords','-i', 'input', '-o', 'output', '-r', 'root' , 'target',
        '-d'
    ]
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:07.917579
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:18.090399
# Unit test for function main
def test_main():
    def test_case(argv, input, output, target, root, debug, expected):
        sys.argv = argv
        main()
        assert (init_settings.input == input)
        assert (init_settings.output == output)
        assert (init_settings.target == target)
        assert (init_settings.root == root)
        assert (init_settings.debug == debug)
        assert (init_settings.expected == expected)

    test_case(["py-backwards", "-i", "input", "-o", "output", "-t", "3.6",
             "-r", "root", "-d"], "input", "output", "3.6", "root", True,
             None)

# Generated at 2022-06-23 22:28:22.600417
# Unit test for function main
def test_main():
    sys.argv[1:] = [
        '--input', 'compiler/tests/additional tests',
        '--output', 'compiler/tests/additional tests',
        '--root', 'compiler/tests/additional tests',
        '--target', '2.7']
    assert main() == 0


# Generated at 2022-06-23 22:28:23.252242
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:25.148614
# Unit test for function main
def test_main():
    test_args = ["-i", "tests/test3.py", "-o", "tests/output", "-t", "python2"]
    main(test_args[1:])

# Generated at 2022-06-23 22:28:30.478342
# Unit test for function main
def test_main():
    main()
    main(['-h'])
    assert main(['-i', '--input']) == 1
    assert main(['-o', '--output']) == 1
    assert main(['-t', '--target']) == 1
    assert main(['-i', 'input.py', '-o', 'output.py', '-t', '2.7']) == 0

# Generated at 2022-06-23 22:28:36.390050
# Unit test for function main
def test_main():
    """
    >>> sys.argv = ['-i', 'test/resources/test.py', '-o', 'test/result/test.py', '-r', 'test', '-t', '3.7']
    >>> main() == 0
    True
    """
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:43.953925
# Unit test for function main
def test_main():
    # test_input_doesnt_exists.txt
    with open('test_input_doesnt_exists.txt', 'w') as f:
        f.close()
    file_string = open('test_input_doesnt_exists.txt').read()
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    main([sys.argv[0], '-i', 'test_input_doesnt_exists.txt', '-o',
          'test_input_doesnt_exists.txt', '-t', '3.6'])
    sys.stdout = sys.__stdout__
    assert capturedOutput.getvalue() == \
           file_string[:-1] + messages.compilation_result({}) + '\n'

# Generated at 2022-06-23 22:28:50.272435
# Unit test for function main
def test_main():
    # Check that main() returns 0 (success) on correct input
    correct_args = ["-i", "tests/input_examples/correct_code.py", "-o", "out.py", "-t", "3.6"]

    assert main(correct_args) == 0

    incorrect_args = ["-i", "incorrect_input.py", "-o", "out.py", "-t", "3.6"]

    assert main(incorrect_args) == 1

# Generated at 2022-06-23 22:28:57.468842
# Unit test for function main
def test_main():
    sys.argv = ['Compiler.py', '-i', 'test_files/test_file.py', '-o', 'out',
                '-t', '2.7', '-r', 'test_files']
    if(main() == 0):
        print('test passed')
    else:
        print('test failed')
    sys.argv = ['Compiler.py', '-i', 'test_files/test_file.py', '-o', 'out',
                '-t', '2.7', '-r', 'test_files']
    if(main() == 0):
        print('test passed')
    else:
        print('test failed')

# Generated at 2022-06-23 22:28:59.086640
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:59.664091
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:00.930917
# Unit test for function main
def test_main():
    assert main() == 1
    # TODO
    # assert main() == 0

# Generated at 2022-06-23 22:29:02.520146
# Unit test for function main
def test_main():
    args = main.__code__.co_varnames
    assert args == ('sys',)

# Generated at 2022-06-23 22:29:09.898976
# Unit test for function main
def test_main():
    import inspect
    import json
    import os
    import subprocess
    import tempfile
    import unittest

    # TODO: Use importlib.util.module_from_spec to create a module that will
    # be used as a sys.module to store project root
    class args:
        input = []
        output = ''
        target = ''
        root = ''
        debug = False

    class Tester(unittest.TestCase):
        def setUp(self):
            self.out_dir = tempfile.mkdtemp()
            args.output = self.out_dir

        def tearDown(self):
            for f in os.listdir(self.out_dir):
                path = os.path.join(self.out_dir, f)
                if os.path.isdir(path):
                    shutil

# Generated at 2022-06-23 22:29:13.692809
# Unit test for function main
def test_main():
    from unittest.mock import patch
    with patch('sys.argv', ["py-backwards", "-i", "py_backwards", "-o", "py_backwards_3.2", "-t", "3.2"]):
        assert main() == 0

# Generated at 2022-06-23 22:29:25.073250
# Unit test for function main
def test_main():
    from os import path
    from . import utils
    from .exceptions import InputDoesntExists
    from io import StringIO
    from pytest import raises
    '''
    Testing command line parameters.
    It is assumed that the input file exists and the folder for the output file
    exists.
    '''

    # ArgumentParserError
    with StringIO() as f:
        with raises(SystemExit):
            with utils.redirect_stdout(f):
                main()

    # File doesn't exist.
    with StringIO() as f:
        with raises(SystemExit):
            with utils.redirect_stdout(f):
                main([])
            assert f.getvalue() == messages.input_doesnt_exists([]) + '\n'

    # No target

# Generated at 2022-06-23 22:29:36.373217
# Unit test for function main
def test_main():
    """
    Unit test for function main
    :return:
    """
    sys.argv = ["py-backwards", "-i", "test/input/test.py", "-o",
                "test/output/test.py", "-t", "3.4"]
    assert main() == 0
    sys.argv = ["py-backwards", "-i", "test/input/test.py", "-o",
                "test/input/test.py", "-t", "3.4"]
    assert main() == 1
    sys.argv = ["py-backwards", "-i", "test/input/test.py", "-o",
                "test/output/test.py", "-t", "3.3"]
    assert main() == 1

# Generated at 2022-06-23 22:29:42.648108
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'tests/data/test1.py', '-o',
                'tests/data/result2.py', '-t', '2.7', '-r', 'tests']
    assert main() == 0

    sys.argv = ['py-backwards.py', '-i', 'tests/data/test1.py', '-o',
                'tests/data/result2.py', '-t', '2.7', '-r', 'tests', '-d']
    assert main() == 0


# Generated at 2022-06-23 22:29:42.996690
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:29:44.013929
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:29:54.057023
# Unit test for function main
def test_main():
    import io
    import sys
    from contextlib import redirect_stdout
    from unittest import TestCase

    from . import compiler
    from . import exceptions

    class TestMain(TestCase):

        def test_invalid_input_output(self):
            sys.argv = ['py-backwards', '-i', 'tests/test_data', '-o', 'python_2.7', '-t', 'py27']
            f = io.StringIO()
            with redirect_stdout(f):
                self.assertRaises(exceptions.InvalidInputOutput, main)

        def test_incorrect_input(self):
            sys.argv = ['py-backwards', '-i', 'incorrect_folder/', '-o', 'python_2.7', '-t', 'py27']

# Generated at 2022-06-23 22:29:56.754213
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'test1.py', '-o', 'test', '-t', '3.5']
    assert(main() == 0)

# Generated at 2022-06-23 22:30:03.460853
# Unit test for function main
def test_main():
    with tempfile.TemporaryDirectory() as temp_dir:
        file = os.path.join(temp_dir, 'source.py')
        with open(file, 'wb') as f:
            f.write(b'print("1")')
        with open(file, 'rb') as f:
            with open(file, 'wb') as g:
                g.write(b'print(1)')
        sys.argv = ['py-backwards', '-i', temp_dir, '-o', temp_dir, '-t',
                    'py36']
        main()
        assert main() == 0

# Generated at 2022-06-23 22:30:04.046230
# Unit test for function main
def test_main():
    assert main()==0

# Generated at 2022-06-23 22:30:14.661736
# Unit test for function main
def test_main():
    # Case 1: given file input and output
    sys.argv = ['-i', 'test_file.py', '-o', 'test_file.py', '-t', '3.7', '-d']
    assert main() == 0
    sys.argv = ['-i', 'test_file.py', '-o', 'test_file.py', '-t', '3.7']
    assert main() == 0

    # Case 2: given file input and folder output
    sys.argv = ['-i', 'test_file.py', '-o', 'test_files', '-t', '3.7', '-d']
    assert main() == 0
    sys.argv = ['-i', 'test_file.py', '-o', 'test_files', '-t', '3.7']

# Generated at 2022-06-23 22:30:23.405979
# Unit test for function main
def test_main():
    from subprocess import PIPE, Popen

    def run(args):
        return Popen('py-backwards {}'.format(args),
                     shell=True, stdout=PIPE, stderr=PIPE)

    # Normal work
    p = run('-i unit_tests/input/ -o unit_tests/output/ -t python27')
    p.wait(timeout=2)
    assert p.returncode == 0
    assert b'Compiled 0 files, skipped 0 files' in p.stdout.read()

    # Invalid python version
    p = run('-i unit_tests/input/ -o unit_tests/output/ -t python26')
    p.wait(timeout=2)
    assert p.returncode != 0

    # Invalid input/output

# Generated at 2022-06-23 22:30:23.712005
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:30.067515
# Unit test for function main
def test_main():
    # For this test, the current directory must be 
    # py-backwards/test/test_compiler/
    input_path = "test_files/test.py"
    output_path = "test_output.py"
    target_python = "2.7"
    # There is no root for this test
    root_path = None
    debug = True

    # We will call the main function
    results = main(input_path, output_path, target_python,
                   root_path, debug)
    # We compare the results with the file test_results/
    # test_output.py we should get the same results
    file_result = open("test_results/test_output.py", "r").read()
    file_compare_result = open("test_output.py", "r").read()

# Generated at 2022-06-23 22:30:31.505434
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-23 22:30:40.012930
# Unit test for function main
def test_main():
    assert main() == 0
    assert main(['-t', '2']) == 0
    assert main(['-i', 'test/test_files']) == 0
    assert main(['-o', 'py-backwards-test-folder/']) == 0
    assert main(['-i', 'test/test_files', '-o', 'py-backwards-test-folder/']) == 0
    assert main(['-i', 'test/test_files', '-o', 'py-backwards-test-folder/', '-t', '2']) == 0

# Generated at 2022-06-23 22:30:45.454122
# Unit test for function main
def test_main():
    # Arrange
    sys.argv.append("-i")
    sys.argv.append("tests/resources/input.py")
    sys.argv.append("-o")
    sys.argv.append("output.py")
    sys.argv.append("-t")
    sys.argv.append("3")
    # Act
    main()
    # Assert
    #if os.path.isfile("output.py"):
        #os.remove("output.py")
        #assert True

# Check if unit test is called directly
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:30:52.437005
# Unit test for function main
def test_main():
    sys.argv = [
        sys.argv[0],
        '-i', 'test_data/test.py',
        '-o', 'test_output_main.py',
        '-t', '2.7',
        '-r', 'test_data'
    ]
    assert main() == 0
    assert filecmp.cmp('test_output_main.py', 'test_data/test_main.py')
    os.remove('test_output_main.py')

# Generated at 2022-06-23 22:31:01.584156
# Unit test for function main
def test_main():
    from . import const, messages
    from .conf import init_settings, get_settings
    from .exceptions import CompilationError
    import tempfile
    import pytest

    def _save_files(content):
        file1 = tempfile.NamedTemporaryFile(mode='w', delete=False)
        file1.write(content)
        file1.close()
        file2 = tempfile.NamedTemporaryFile(mode='w', delete=False)
        file2.write(content)
        file2.close()
        return (file1.name, file2.name)

    def _remove_files(files):
        import os
        for file in files:
            os.remove(file)


# Generated at 2022-06-23 22:31:13.528110
# Unit test for function main
def test_main():

    def mock_parse_args(*args, **kwargs):
        class Namespace:
            pass
        args = Namespace()
        args.input = ['input']
        args.output = 'output'
        args.target = 'python2.7'
        args.root = None
        args.debug = False
        return args

    def mock_init_settings(*args, **kwargs):
        return None

    def mock_compile_files(*args, **kwargs):
        return None

    sys.argv = ['']

    parser_org = ArgumentParser.__init__
    ArgumentParser.__init__ = lambda self, *args, **kwargs: None
    parser_add_argument = ArgumentParser.add_argument
    ArgumentParser.add_argument = lambda self, *args, **kwargs: None
    parser_parse_

# Generated at 2022-06-23 22:31:23.499155
# Unit test for function main
def test_main():
    # no args
    sys.argv[1:] = []
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 2

    # invalid input
    sys.argv[1:] = ['-i', 'input.py', '-o', 'output.py', '-t', 'python2.7']
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 1

    # invalid output
    sys.argv[1:] = ['-i', 'tests/mock/input.py', '-o', 'invalid/output.py', '-t', 'python2.7']
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 1

    #

# Generated at 2022-06-23 22:31:25.615676
# Unit test for function main
def test_main():
    returncode = main()
    assert returncode == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:30.123204
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_input', '-o', 'test_output', '-t', 'py27', '-r', 'test_input']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:31.666647
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:32.366344
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:42.703121
# Unit test for function main
def test_main():
    # Test for argparse setup
    sys.argv = [sys.argv[0], '-i', 'input.py', '-o', 'output.py', '-t', '2.7']
    assert main() is 0

    sys.argv = [sys.argv[0], '-i', 'input.py', '-o', 'output.py', '-t', '2.7',
                '-d']
    assert main() is 0

    sys.argv = [sys.argv[0], '-i', 'input.py', '-o', 'output.py', '-t', '2.7',
                '-r', 'root']
    assert main() is 0

    sys.argv = [sys.argv[0]]
    assert main() is not 0


# Generated at 2022-06-23 22:31:47.362962
# Unit test for function main
def test_main():
    sys.argv = ["pybackwards", "-i", "test_input.py", "-o", "test_output.py", "-t", "2.7", "-r", "c:\\dir1\\dir2", "-d" ]
    assert main() == 0

# Generated at 2022-06-23 22:31:52.384273
# Unit test for function main
def test_main():
    input_files = ['tests/files/example_code.py']
    args = ['py-backwards', '-i', input_files[0], '-o', 'output.py', '-t', 'pyrhon27']
    with mock.patch('sys.argv', args):
        result = main()
        assert result == 1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:52.948965
# Unit test for function main
def test_main():
    main([])

# Generated at 2022-06-23 22:32:00.047322
# Unit test for function main
def test_main():
    from argparse import ArgumentParser, Namespace
    from unittest.mock import patch, call

    with patch('py_backwards.main.init_settings') as init_settings_mock, \
            patch('py_backwards.main.compile_files') as compile_files_mock, \
            patch('sys.stderr') as stderr_mock:
        compile_files_mock.side_effect = exceptions.CompilationError('test')
        init_settings_mock.side_effect = lambda x: x
        args = Namespace(debug=True, input=('in_',), output='out_',
                         target='py36', root=None)

        assert main() == 1
        assert init_settings_mock.mock_calls == [call(args)]
        assert compile_files_m

# Generated at 2022-06-23 22:32:00.842303
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:01.436907
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:12.250156
# Unit test for function main
def test_main():
    def import_lib():
        import py_backwards.compiler
        import py_backwards.conf
        import py_backwards.const
        import py_backwards.messages
        import py_backwards.exceptions

    assert main() == 0

    sys.argv = ['py-backwards', '-i', 'tests/test.py', '-o', '/dev/null', '-t', '2.7']
    import_lib()
    assert main() == 0

    sys.argv = ['py-backwards', '-i', 'tests/async.py', '-o', '/dev/null', '-t', '3']
    import_lib()
    assert main() == 0


# Generated at 2022-06-23 22:32:17.473956
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', 'tests/testdata/xxx.py', 'testdata/output/', '2.5']
    ret = main()
    sys.argv = ['py-backwards.py', 'tests/testdata/xxx.py', 'testdata/output/', '2.5', '-r', 'tests']
    ret = main()

# Generated at 2022-06-23 22:32:18.125387
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:27.901279
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:32:32.123261
# Unit test for function main
def test_main():
    try:
        import pytest
        pytest.main(['unittests/'])
    except SystemExit:
        return 0

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:32:41.720973
# Unit test for function main
def test_main():
    # Could not find input file
    old_sys = sys.argv
    sys.argv = [sys.argv[0], '-i', 'invalid_input', '-o', '', '-t', '2.6']
    assert main() == 1

    # Transformaion error
    sys.argv = [sys.argv[0], '-i', 'input.py', '-o', 'output.py', '-t', '2.6']
    assert main() == 1

    # Compilation error
    sys.argv = [sys.argv[0], '-i', 'input.py', '-o', '', '-t', '2.6']
    assert main() == 1

    # Permission error

# Generated at 2022-06-23 22:32:49.559175
# Unit test for function main
def test_main():
    argv = ['py-backwards', '-i', 'py_backwards/__init__.py', '-o',
            'test/out/__init__.py', '-t', '3.5', '-d']
    output = main()
    assert(output == 0)
    with open('test/out/__init__.py', 'r') as f:
        text = f.read()
        assert('from __future__ import annotations' in text)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:50.859801
# Unit test for function main
def test_main():
    assert(main() == 0)
#Unit test for function main

# Generated at 2022-06-23 22:33:01.477973
# Unit test for function main
def test_main():
    sys.argv = [
        sys.argv[0],
        '-i', 'tests/transforms/test_files/test_compiler_input.py',
        '-o', 'tests/transforms/test_files/test_compiler_output.py',
        '-t', '2'
    ]
    assert main() == 0
    sys.argv = [
        sys.argv[0],
        '-i', 'tests/transforms/test_files/test_compiler_input.py',
        '-o', 'tests/transforms/test_files/doesnt_exists',
        '-t', '2'
    ]
    assert main() == 1

# Generated at 2022-06-23 22:33:01.839175
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:02.303952
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:05.685376
# Unit test for function main
def test_main():
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:06.313405
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:09.797013
# Unit test for function main
def test_main():
    try:
        res = main()
    except exceptions.CompilationError:
        res = 1
    except exceptions.TransformationError:
        res = 2
    except exceptions.InputDoesntExists:
        res = 3
    except exceptions.InvalidInputOutput:
        res = 4
    except PermissionError:
        res = 5
    return res

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-23 22:33:21.154882
# Unit test for function main
def test_main():
    # Standard compilation
    main()

    # Compilation with debug output
    main(["-i", "../tests/input", "-o", "../tests/output", "-t", "27", "-r", "../tests/input/", "-d"])

    # Compilation with debug output and with bad target version
    main(["-i", "../tests/input", "-o", "../tests/output", "-t", "2.7", "-r", "../tests/input/", "-d"])

    # Compilation with debug output and with bad input folder
    main(["-i", "../tests/input_bad", "-o", "../tests/output", "-t", "27", "-r", "../tests/input/", "-d"])

    # Compilation with debug output and with bad output folder

# Generated at 2022-06-23 22:33:21.517122
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:33:28.551142
# Unit test for function main

# Generated at 2022-06-23 22:33:30.241935
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass # expected

# Generated at 2022-06-23 22:33:37.955618
# Unit test for function main
def test_main():
    # Test invalid output
    args = ['file1.py', '-o', 'output.py']
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(args)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1
    
    # Test a valid output
    args = ['file1.py', '-o', 'output_dir/file1.py',
            '-t', '2']
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(args)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0
    os.remove('output_dir/file1.py')
   

# Generated at 2022-06-23 22:33:43.236469
# Unit test for function main
def test_main():
    sys.argv = [
        'py_backwards.py', '-i', 'test/test.py', '-t', '2.7', '-o', 'test/test2.py', '-d', '-r', 'main'
    ]
    main()


if __name__ == '__main__':
    #test_main()
    sys.exit(main())

# Generated at 2022-06-23 22:33:48.692799
# Unit test for function main
def test_main():

    from .compiler import compile_files
    from .conf import settings
    from . import const, exceptions
    import pytest
    import sys
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main("test.py", "test_converted.py", "2.5")
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:58.801852
# Unit test for function main
def test_main():
    from .util import execute_from_files

    def test_success():
        print('test success')
        execute_from_files(main, 'test-root', 'test-output-root', '2.7',
                           exptected_retcode=0, debug=True)
        print()

    def test_success_no_root():
        print('test success no root')
        execute_from_files(main, '', 'test-output-root-no-root', '2.7',
                           exptected_retcode=0, debug=True)
        print()

    def test_invalid_root():
        print('test invalid root')
        execute_from_files(main, 'invalid-root', 'test-output-root', '2.7',
                           exptected_retcode=1)
       

# Generated at 2022-06-23 22:34:04.509695
# Unit test for function main
def test_main():
    try:
        assert main(["test.py"]) == 1, "No input file!"
    except  exceptions.InputDoesntExists:
        assert True
    except FileNotFoundError:
        assert True

    try:
        assert main(["test.py", "output.py"]) == 1, "No target!"
    except exceptions.TargetNotSelected:
        assert True
    except:
        assert False

    try:
        assert main(["test.py", "output.py", "python3.6"]) == 1, "Has errors!"
    except exceptions.CompilationError:
        assert True

    try:
        assert main(["test.py", "output.py", "python3.6", "--debug"]) == 1, "Has errors!"
    except exceptions.CompilationError:
        assert True


# Generated at 2022-06-23 22:34:05.055254
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:13.826223
# Unit test for function main
def test_main():
    from subprocess import run, PIPE
    from pathlib import Path
    from os import sep
    from tempfile import TemporaryDirectory

    path = Path(__file__).resolve().parents[1]
    test_dir = (path / 'examples' / 'unit_tests').absolute()

    with TemporaryDirectory() as dir:

        def _exec(command, input, output):
            process = run(command, cwd=dir, input=input, stdout=PIPE,
                          stderr=PIPE, encoding='ascii')

            assert process.returncode == 0

            with (Path(dir) / output).open('r') as file:
                text = file.read()

            assert process.stdout == 'OK\n'
            assert process.stderr == ''
            return text


# Generated at 2022-06-23 22:34:19.161669
# Unit test for function main
def test_main():
    from types import SimpleNamespace

    args = SimpleNamespace()
    args.input = ['/home/user/code/test_project/test.py']
    args.output = '/home/user/code/compiled'
    args.target = 'python2.7'
    args.root = '/home/user/code/test_project'
    args.debug = True
    assert main() == 0


# Generated at 2022-06-23 22:34:29.926911
# Unit test for function main
def test_main():
    import unittest
    import tempfile
    import shutil
    import os

    class TestLauncher(unittest.TestCase):
        def setUp(self):
            self.directory = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.directory)

        # Testcase for ok input file
        def test_input_file(self):
            path = os.path.join(self.directory, 'input.py')
            with open(path, 'w') as f:
                f.write('print(2 ** 3)')
            self.assertEqual(main(['-i', path, '-o', path, '-t', 'py36']), 0)

        # Testcase for nonexistent input file

# Generated at 2022-06-23 22:34:36.056614
# Unit test for function main
def test_main():
    # Test that help appears when no arguments are given
    try:
        main()
        assert False
    except SystemExit:
        pass

    # Test that help appears when bad arguments are given
    try:
        sys.argv = ['py-backwards', '-p', '--wrongs', 'wrong']
        main()
        assert False
    except SystemExit:
        pass

    # Test valid arguments
    sys.argv = ['py-backwards', '-i', 'file.py', '-o', 'file.py', '-t', '3.5']
    main()

    # Test that compilation error is caught
    sys.argv = ['py-backwards', '-i', 'file.py', '-o', 'file.py', '-t', '0.4']

# Generated at 2022-06-23 22:34:45.885207
# Unit test for function main
def test_main():
    from py_backwards.conf import settings

    assert main() == 1

    sys.argv = [sys.argv[0], '-i', 'test/data/test_code.py', '-o',
                'test/data/test_code.py', '-t', '3.5']
    assert main() == 1

    sys.argv = [sys.argv[0], '-i', 'test/data/test_code.py', '-o',
                'test/data/test_code.py', '-t', '3.5']
    settings.debug = True
    assert main() == 1

    sys.argv = [sys.argv[0], '-i', 'test/data/test_code.py', '-o', 'out',
                '-t', '3.5']


# Generated at 2022-06-23 22:34:56.627428
# Unit test for function main
def test_main():
    args = sys.argv
    # Test for error 'py-backwards: error: the following arguments are required: -i/--input', because missed parameter --i/--input
    test_args1 = [args[0], '-o', 'non_existent_folder', '-t', '3.5']
    sys.argv = test_args1
    assert main() == 2
    # Test for error 'py-backwards: error: the following arguments are required: -o/--output', because missed parameter --o/--output
    test_args2 = [args[0], '-i', 'non_existent_folder', '-t', '3.5']
    sys.argv = test_args2
    assert main() == 2
    # Test for error 'py-backwards: error: the following arguments are required: -t/--

# Generated at 2022-06-23 22:34:58.988713
# Unit test for function main
def test_main():
    print("This is a unit test for main function")

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:59.650990
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:01.009736
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:05.807103
# Unit test for function main
def test_main():
    # 1) Create the arguments array needed by the main function
    sys.argv = ['Test', '-i', 'input_file.py', '-o', 'output_file.py', '-t', '2.7']
    # 2) Call the main function
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:07.603158
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:11.754698
# Unit test for function main
def test_main():
    import pytest
    from argparse import ArgumentParser
    from .conf import init_settings

    init_settings()
    const.SETTINGS['debug'] = True
    assert main() == 1


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:22.494368
# Unit test for function main
def test_main():
    # Unittest for succesful compilation
    sys.argv = ['py-backwards', '-i', './pybackwards/tests/hello.py', '-o', 'out.py', '-t', 'python2.7']
    assert main() == 0
    # Unittest for unsuccesful compilation
    sys.argv = ['py-backwards', '-i', './pybackwards/tests/hello1.py', '-o', 'out.py', '-t', 'python2.7']
    assert main() == 1
    # Unittest for unsuccesful compilation
    sys.argv = ['py-backwards', '-i', './pybackwards/tests/hello2.py', '-o', 'out.py', '-t', 'python2.7']
    assert main()

# Generated at 2022-06-23 22:35:33.446991
# Unit test for function main
def test_main():
    from unittest import TestCase, mock
    from io import StringIO
    from sys import stdout
    from argparse import ArgumentParser, Namespace

    with mock.patch('sys.argv', ['py-backwards', '-i', 'a', '-o', 'b', '-t', 'c', '-r', 'd']):

        parser = ArgumentParser()
        parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                            help='input file or folder')
        parser.add_argument('-o', '--output', type=str, required=True,
                            help='output file or folder')

# Generated at 2022-06-23 22:35:39.390640
# Unit test for function main
def test_main():
    curr_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(curr_dir, const.TEST_DIR)

    with open(os.path.join(test_dir, 'test1.py')) as f:
        correct_code = f.read()

    sys.argv = ['py-backwards', '-i',
                os.path.join(test_dir, 'test_dir'),
                '-o', os.path.join(test_dir, 'test_dir_out'),
                '-t', '3.5',
                '-d'
                ]
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    main()
    sys.stdout = old_std

# Generated at 2022-06-23 22:35:41.079166
# Unit test for function main
def test_main():
    assert main() == 0, 'main() : output error'

# Generated at 2022-06-23 22:35:43.990220
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/data/plik.py',
                '-o', 'tests/data/example_new.py',
                '-t', '3.4']
    assert main() == 0

# Generated at 2022-06-23 22:35:49.970466
# Unit test for function main
def test_main():
    sys.setrecursionlimit(10000)
    args = ['py-backwards', '--input', './tests/resources/hello.py', '--target',
            '2.7', '--output', './tests/resources/compiled/', '--root', './tests/resources/']
    sys.argv = args
    sys.modules['__main__'].__spec__.name = '__main__'
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:00.530119
# Unit test for function main
def test_main():
    # test: parser error
    argv = []
    try:
        main()
        assert False
    except SystemExit:
        assert True

    # test: inputs errors
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        # test: input folder doesn't exist
        argv = ['-i', 'doesntexists', '-o', tmpdir, '-t', 'py36']
        try:
            main()
            assert False
        except SystemExit as e:
            assert e.code == 1

        # test: input doesn't exist
        argv = ['-i', 'doesntexists.py', '-o', tmpdir, '-t', 'py36']
        try:
            main()
            assert False
        except SystemExit as e:
            assert e.code == 1

       

# Generated at 2022-06-23 22:36:03.789012
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', '.\\test\\test_compiler.py', '-t', '3.5',
                '-o', '.\\temp\\test\\']
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:07.067158
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-o', 'output', '-i', 'input', '-t', '2.7', '-r', 'root']
    assert main() == 0

# Generated at 2022-06-23 22:36:07.735105
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:36:10.890167
# Unit test for function main
def test_main():
    argv = ['-i', 'test.py', '-o', 'test.py.out', '-t', '3.5']
    assert main(argv) == 0

# Generated at 2022-06-23 22:36:11.708006
# Unit test for function main
def test_main():
    runpy.run_module('py_backwards.main')

# Generated at 2022-06-23 22:36:13.440188
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:14.042749
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:36:22.599949
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    # Target version isn't valid
    result = main_with_args(['-i test_folder', '-o output', '-t 0', '-r root'])
    assert result == 2
    # Output doens't exist
    result = main_with_args(['-i test_folder', '-o output',
                            '-t python2.7', '-r root'])
    assert result == 1
    # Root doesn't exist
    result = main_with_args(['-i test_folder', '-o output',
                             '-t python2.7', '-r root/'])
    assert result == 1
    # Root and output is a file

# Generated at 2022-06-23 22:36:26.545328
# Unit test for function main
def test_main():
    args = ['py-backwards', '-o', 'output.py', '-i', 'input_1.py',
            '-i', 'input_2.py', '-t', '2.7']
    raise NotImplementedError

# Generated at 2022-06-23 22:36:33.262836
# Unit test for function main
def test_main():
    from pytest import raises
    from .tests import helpers
    from . import conf
    from .exceptions import CompilationError, TransformationError

    with helpers.test_data() as data:
        # Incorrect target
        with raises(SystemExit):
            conf.init_settings(helpers.args(data.root, '2.7', 'output', False))
            main()

        # Incorrect input
        with raises(SystemExit):
            conf.init_settings(helpers.args([data.root + '/fake'], '3.6',
                                      'output', False))
            main()

        # Incorrect output
        with raises(SystemExit):
            conf.init_settings(helpers.args([data.root + '/input'], '3.6',
                                      data.root + '/fake', False))
            main()

       