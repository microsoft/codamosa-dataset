

# Generated at 2022-06-23 22:26:25.488995
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:29.341134
# Unit test for function main
def test_main():
    try:
        assert main()==1
    except SystemExit as e:
        assert e.code == 1
    except Exception as e:
        raise e

# Generated at 2022-06-23 22:26:33.700870
# Unit test for function main
def test_main():
    args = sys.argv
    sys.argv = ['', "-i", "test-data/test.py", "-o", "test-data/test2.py", "-t", "2.7"]
    try:
        assert main() == 0
    finally:
        sys.argv = args

# Generated at 2022-06-23 22:26:35.198269
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:40.932375
# Unit test for function main
def test_main():
    #input
    sys.argv = ['/home/cave/Desktop/py-backwards/py_backwards/main.py',
                '-i', 'test/samples/util.py',
                '-t', '2.7',
                '-o', '/home/cave/Desktop/py-backwards/py_backwards/test/samples/util_2.7.py',
                '-d']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:26:45.908523
# Unit test for function main
def test_main():
    config = {'-i': 'test.py', '-o': 'test_out.py', '-t': '3.6', '-d': False}
    sys.argv.append('-h')
    sys.argv.extend([k for k in config])
    assert main() == 0

# Generated at 2022-06-23 22:26:46.641833
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:57.779990
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i=thoth/test_files/origin_files', '-o=thoth/test_files/modified_files', '-t=2.7', '-d=False']
    assert main() == 0
    sys.argv = ['py-backwards', '-i=thoth/test_files/origin_files', '-o=thoth/test_files/modified_files', '-t=2.6', '-d=False']
    assert main() == 1
    sys.argv = ['py-backwards', '-i=thoth/test_files/origin_files', '-o=thoth/test_files/modified_files', '-t=2.7', '-d=True']
    assert main() == 0

# Generated at 2022-06-23 22:27:01.742986
# Unit test for function main
def test_main():
    import os
    if os.path.exists('test.py') and os.path.exists('test_tr.py'):
        ret = os.system('python3 -m pytest tests/test_main.py')
        assert ret == 0
        os.remove('./test.py')
        os.remove('./test_tr.py')

# Generated at 2022-06-23 22:27:02.240770
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:10.816803
# Unit test for function main
def test_main():
    execute_args=["-i", "test/test_data/test.py", "-o", "test/test_data/test_out.py", "-t", "2.7", "-r", "test/test_data"]
    sys.argv.extend(execute_args)
    main()
    with open("test/test_data/test_out.py", "r") as test_out_file:
        test_out = test_out_file.read()
    with open("test/test_data/test_out_correct.py", "r") as test_out_correct_file:
        test_out_correct = test_out_correct_file.read()
    assert  test_out == test_out_correct

# Generated at 2022-06-23 22:27:18.316679
# Unit test for function main
def test_main():
    test_args = ['-i', 'tests/files/compile.py', '-o', 'tests/files/out.py', '-t', '2.7']
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    try:
        main(test_args)
    finally:
        sys.stdout = old_stdout
    assert 'Successfully compiled 1 file' in sys.stdout.getvalue()
    os.remove('tests/files/out.py')


# Generated at 2022-06-23 22:27:22.070064
# Unit test for function main
def test_main():
    tmp = sys.argv
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.6', '-r', 'root', '-d', 'debug']
    try:
        assert main() == 0
    finally:
        sys.argv = tmp

# Generated at 2022-06-23 22:27:27.795241
# Unit test for function main
def test_main():
    from io import StringIO
    from contextlib import redirect_stderr, redirect_stdout
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        sys.stdout = stdout = StringIO()
        sys.stderr = stderr = StringIO()
        path = os.path.join(tmpdir, 'test.py')

        with open(path, 'w') as f:
            f.write("def f() -> int: return 'test'")

        main()
        assert stderr.getvalue() == messages.input_doesnt_exists(path)
        assert stdout.getvalue() == ''
        stderr.close()

        stderr = StringIO()
        sys.stderr = stderr

# Generated at 2022-06-23 22:27:31.697145
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/data/file1.py', '-o', 'output_folder', '-t', '3.5', '--debug']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:32.818540
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:43.729925
# Unit test for function main
def test_main():
    try:
        import pytest
    except ImportError:
        print('Module pytest is required to run tests.')
        sys.exit(1)

    # test that compile works if no errors
    sys.argv[1:] = ['-i', 'tests/simple.py', '-o', 'output/',
                    '-t', 'python25']
    main()
    pytest.main(['-v', 'tests/'])

    # test that error message returns when input doesn't exist
    sys.argv[1:] = ['-i', 'not_exist', '-o', 'output/',
                    '-t', 'python25']
    assert main() == 1
    try:
        main()
    except SystemExit:
        pass

    # test that erorr message returns when input is dir

# Generated at 2022-06-23 22:27:47.334325
# Unit test for function main
def test_main():
    sys.argv = ["", '-i', 'test/test.py', '-o', 'test/test.out', '-t', '2.6']
    main()
    assert open('test/test.out').read() == open('test/test_out.py').read()

# Generated at 2022-06-23 22:27:48.104294
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:55.397864
# Unit test for function main
def test_main():
    save_argv = [i for i in sys.argv]
    sys.argv = ['py-backwards.py','-i','../examples/example_unittest/','../examples/example_unittest_output/','--target','2.7','--debug','--root','../examples/']
    test = main()
    sys.argv = [i for i in save_argv]
    assert test == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:27:56.219618
# Unit test for function main
def test_main():
    import pytest
    pytest.main()

# Generated at 2022-06-23 22:27:56.715881
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:28:00.074785
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i','./tests/resources/input.py',
                '-o','./tests/resources/output.py', '-t', '3.5',
                '-r', './tests/resources/', '-d']
    main()

# Generated at 2022-06-23 22:28:04.090889
# Unit test for function main
def test_main():
    from .test_output import main_output_for_all_targets
    main_output_for_all_targets()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:09.412057
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.argv.append('-i')
        sys.argv.append('/home/khmara/PycharmProjects/py-backwards/tests/input/')
        sys.argv.append('-o')
        sys.argv.append('/home/khmara/PycharmProjects/py-backwards/tests/output/unit_test_main/')
        sys.argv.append('-t')
        sys.argv.append('python2.7')

        assert main() == 1

# Generated at 2022-06-23 22:28:16.090129
# Unit test for function main
def test_main():
    argv = sys.argv
    sys.argv = ['py-backwards', '-i', 'test/input/test.py', '-o', 'test/output.py', '-t', '3.5', '-d']
    main()

    with open('test/output.py') as f:
        out = f.read()

    assert out == 'def foo():\n    return 1\n\ntest = foo\nprint(test.__annotations__)\n'

    sys.argv = argv
    os.remove('test/output.py')

# Generated at 2022-06-23 22:28:18.676303
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:23.464372
# Unit test for function main
def test_main():
    input = 'test_main.py'
    output = 'test_main.py.output'
    target = '3.5'

    sys.argv = ['py-backwards', '-i', input, '-o', output, '-t', target]

    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:25.518956
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'test.py', '-o', 'output',
                '-t', '2.7', '--debug']
    main()

# Generated at 2022-06-23 22:28:26.642311
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:31.539721
# Unit test for function main
def test_main():
    for flag in ['-i input.py -o output', 
                 '-i input.py -o output -t python3.6', 
                 '-i input.py -o output -t python3.6 -r root', 
                 '-i input.py -o output -t python3.6 -r root -d']:
        assert main(flag) == 0

# Generated at 2022-06-23 22:28:32.304493
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:40.434361
# Unit test for function main
def test_main():
    # file not exist
    try:
        main(['-i', 'file_not_exists', '-o', 'output_file', '-t', '3.6.0'])
    except exceptions.InputDoesntExists as e:
        pass
    except: raise
    # folder not exist
    try:
        main(['-i', 'folder_not_exists', '-o', 'output_folder', '-t', '3.6.0'])
    except exceptions.InputDoesntExists as e:
        pass
    except: raise

# Generated at 2022-06-23 22:28:48.344491
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:28:56.580528
# Unit test for function main
def test_main():
    argv = ['', ]
    sys.argv = argv
    assert main() == 1

    args = ['-i', '-o', '-t', '-d']
    flags = ['-i', 'input', '-o', 'output', '-t', '3.7', '-d']
    sys.argv = args + flags
    assert main() == 0

    args = ['-i', '-o', '-t']
    flags = ['-i', 'input', '-o', 'output', '-t', '3.7']
    sys.argv = args + flags
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:02.225284
# Unit test for function main
def test_main():
    # GIVEN
    with patch('sys.argv', ['py_backwards',
                            'test/test1.py',
                            'test/out',
                            '2.7']):
        # WHEN
        main()
        # THEN
        with open('../test/out/test1.py', 'r') as f:
            assert f.read() == 'for i in range(10):\n\tprint(i)\n'

# Generated at 2022-06-23 22:29:04.417998
# Unit test for function main
def test_main():
    args = main(['-i', 'test/test.py', '-t', '2.7', '-o', 'output/test.py'
    ])
    assert args == 0

# Generated at 2022-06-23 22:29:05.594034
# Unit test for function main
def test_main():
    assert main() == 0, "Something wrong"

# Generated at 2022-06-23 22:29:06.994130
# Unit test for function main
def test_main():
    # The function main() is tested in test_compiler
    pass

# Generated at 2022-06-23 22:29:08.863244
# Unit test for function main
def test_main():
    main(['-o', '-t', '-r', '-i'])


# Generated at 2022-06-23 22:29:10.451635
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:13.832832
# Unit test for function main
def test_main():
    args = {
        'input': ['test_file.py'],
        'output': 'test_file.py',
        'target': '3.5'
    }
    init_settings(args)
    assert main(args) == 0

# Generated at 2022-06-23 22:29:25.326949
# Unit test for function main
def test_main():
    assert main(['-i', './test/test.py', '-o', './test/test1.py', '-t', '3.5',
                 '-r', './test']) == 0
    assert main(['-i', './test/test.py', '-o', './test/test1.py', '-t', '2.7']) \
           == 0
    assert main(['-i', './test/test.py', '-o', './test/test1.py', '-t', '2.7',
                 '-r', './test']) == 0
    assert main(['-i', './test/test.py', '-o', './test/test1.py', '-t', '3.6']) \
           == 0

# Generated at 2022-06-23 22:29:31.415401
# Unit test for function main
def test_main():
    args = [
        '-i', 'tests/test_input',
        '-o', 'tests/test_output',
        '-t', 'py36',
        '-r', 'tests',
        '-d'
    ]
    assert main(args) == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:38.538402
# Unit test for function main
def test_main():
    # Compilation error
    with pytest.raises(SystemExit, match='1'):
        sys.argv = ['py-backwards', '-i', 'tests/data/raise.py',
                    '-o', 'out.py', '-t', '3.5']
        main()
    # Invalid output path
    with pytest.raises(SystemExit, match='1'):
        sys.argv = ['py-backwards', '-i', 'tests/data/raise.py',
                    '-o', ':', '-t', '3.5']
        main()
    # Compilation error

# Generated at 2022-06-23 22:29:48.889144
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', 'python2', '-d']
    main()
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', 'python34', '-d']
    main()
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', 'python36', '-d']
    main()
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', 'python37', '-d']
    main()

# Generated at 2022-06-23 22:29:51.241677
# Unit test for function main
def test_main():
  try:
    #f = open('sample/not_a_python.py', 'r')
    #main()
    main()
  except:
    assert False

# Generated at 2022-06-23 22:29:51.807139
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:29:59.711305
# Unit test for function main
def test_main():
    import shlex
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w') as temp:
        temp.write('print(2)\n')
        temp.flush()
        temp.seek(0)
        with tempfile.TemporaryDirectory() as temp_dir:
            args = shlex.split(f'{temp.name} -o {temp_dir} -t 2.7')
            assert main(args) == 0
            with open(temp_dir + '/' + temp.name.split('/')[-1], 'r') as file:
                assert 'print 2' in file.read()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:01.319865
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:01.887556
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:02.462199
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:13.033498
# Unit test for function main
def test_main():
    # Test for invalid arguments
    argv = ['py-backwards']
    assert main(argv) == 2
    
    argv = ['py-backwards', '-i', 'test/test/test.py']
    assert main(argv) == 2

    argv = ['py-backwards', '-o', 'test/test/test.py']
    assert main(argv) == 2
    
    argv = ['py-backwards', '-i', 'test/test/test.py', '-o', 'test/test/test.py']
    assert main(argv) == 2

    # Test for invalid input
    argv = ['py-backwards', '-i', 'test/test', '-o', 'test/test/test.py', '-t', '3.6']
    assert main

# Generated at 2022-06-23 22:30:21.024267
# Unit test for function main
def test_main():
    commandlist = ['py-backwards', '-i', 'settings.py', '-o', 'output', 
                    '-t', '3.4',
                    '-d']
    saved_stdout = sys.stdout
    try:
        out = open('./test_if_test_main_works.txt', 'w')
        sys.stdout = out
        sys.argv = commandlist
        assert main()  == 0
    finally:
        sys.stdout = saved_stdout
        out.close()
        # Removing the output file
        os.remove('./test_if_test_main_works.txt')

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-23 22:30:21.626159
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:23.052353
# Unit test for function main
def test_main():
    result_main = main()
    assert result_main == 0

# Generated at 2022-06-23 22:30:28.679484
# Unit test for function main
def test_main():
    try:
        sys.argv.append('-i')
        sys.argv.append('tests/test_data/valid.py')
        sys.argv.append('-o')
        sys.argv.append('test_output.py')
        sys.argv.append('-t')
        sys.argv.append('3.4')
        main()
        return True
    except Exception:
        return False

# Generated at 2022-06-23 22:30:39.537741
# Unit test for function main
def test_main():
    def test_arguments1():
        assert main(['-r', '.', '-o', 'out', '-t', '2.7', '-i', 'file.py']) == 0

    def test_arguments2():
        assert main(['-r', '.', '-o', 'out', '-t', '2.7', '-i', 'file.py', '-']) == 0

    def test_arguments3():
        assert main(['-r', '.', '-o', 'out', '-t', '2.7', '-i', 'file.py', '--']) == 0


# Generated at 2022-06-23 22:30:46.693241
# Unit test for function main
def test_main():
    # Test compilation
    sys.argv = ['py-backwards', '-i', 'tests/source',
                '-o', 'tests/target', '-t', "py34", '-d']

    args = main()
    assert args == 0

    # Test compilation with the root
    sys.argv = ['py-backwards', '-i', 'tests/source',
                '-o', 'tests/target', '-t', "py34", '-d', '-r',
                '/home/user/projects/py-backwards/']

    args = main()
    assert args == 0

    # Test compilation with the invalid file

# Generated at 2022-06-23 22:30:50.133446
# Unit test for function main
def test_main():
    import utils
    files = utils.get_test_files()
    for test_input, expected_output in files:
        try:
            _main_test(test_input, expected_output)
        except AssertionError as e:
            print('Test for file %s failed with %s' % (test_input, e))
            


# Generated at 2022-06-23 22:30:59.631611
# Unit test for function main
def test_main():
    # Test function when exception occurs
    def test_error(args, message):
        try:
            result = main(args)
            assert False, 'Should be an IOError'
        except IOError as error:
            assert error.message == message

    # Test function when warning occurs
    def test_warning(args, messages):
        result = main(args)
        assert result == 0
        for message in messages:
            assert message in sys.stderr.getvalue()

    # Test function when everything is ok
    def test_ok(args, message):
        result = main(args)
        assert result == 0
        assert message in sys.stderr.getvalue()
        assert sys.stdout.getvalue() == ''

    # Test function when parser error occurs

# Generated at 2022-06-23 22:31:08.041696
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import pytest
    from argparse import ArgumentParser

    from . import exceptions, const, messages

    tmp_dir = tempfile.mkdtemp()
    tmp_dir_out = os.path.join(tmp_dir, 'out')
    os.mkdir(tmp_dir_out)
    tests_root = os.path.join(os.path.dirname(__file__), 'tests')
    test_input_file = os.path.join(os.path.dirname(__file__),
                                   'tests', 'input', 'test.py')

    # File is compiled, but an error is made in the created file.

# Generated at 2022-06-23 22:31:08.719905
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:31:19.837452
# Unit test for function main
def test_main():
    import io
    from contextlib import redirect_stdout
    from .conf import settings

    out = io.StringIO()
    with redirect_stdout(out):
        main(['-d', '-i', 'tests/example/', '-o', 'tests/dst', '-t', '3.4'])

    assert out.getvalue() == messages.compilation_result(
        (1, 0, 0, 0, 0, 0, 0)
    )

    out = io.StringIO()
    with redirect_stdout(out):
        main(['-i', 'example.txt', '-o', 'example.txt', '-t', '3.4'])

    assert out.getvalue() == messages.input_doesnt_exists(['example.txt'])

    out = io.StringIO()


# Generated at 2022-06-23 22:31:28.980400
# Unit test for function main
def test_main():
    import pytest
    from io import StringIO
    from .conf import SETTINGS as settings

    def input_output(target):
        settings._target = target
        import sys
        sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', target]
        return sys.stdout.write(main())

    def test_target(target):
        output = StringIO()
        sys.stdout = output
        input_output(target)
        assert target in output.getvalue()

    test_target('2.7')
    test_target('3.4')
    test_target('3.5')
    test_target('3.6')

# Generated at 2022-06-23 22:31:32.538968
# Unit test for function main
def test_main():
    # If main function is them main function of program
    # sys.argv = ['py-backwards.py', '-i', 'help.py', '-o', 'a.py', '-t', '3.4']
    # main()
    assert True

# Generated at 2022-06-23 22:31:38.481144
# Unit test for function main
def test_main():
    args = sys.argv
    sys.argv = ['py-backwards.py','-i','_tests/for_compiler','_tests/for_compiler','_tests/for_compiler','_tests/for_compiler','_tests/for_compiler','-o','_tests/for_compiler','-t','27','-r','_tests/for_compiler','-d']
    assert main() == 0
    sys.argv = args

# Generated at 2022-06-23 22:31:41.250641
# Unit test for function main
def test_main():
    #test compile successful
    sys.argv = ['pybackwards.py', '-i', 'test_code_3.6.py', '-o', 'output', '-t', '3.5']
    assert main() == 0


# Generated at 2022-06-23 22:31:51.850469
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        test1_args = ['--input', '/home/user/file.py', '--output',
                                 '/home/user/compiled', '--target', '3.5']
        assert main(test1_args) == 0

        test2_args = ['--input', '/home/user/file.py', '--output',
                      '/home/user/compiled', '--target', '3.5', '--root',
                      '/home/user']
        assert main(test2_args) == 0

        test3_args = ['--input', '/home/user/file.py', '--output',
                      '/home/user/compiled', '--target', '2.7', '--root',
                      '/home/user']
        assert main(test3_args) == 0

# Generated at 2022-06-23 22:31:52.471691
# Unit test for function main
def test_main():
    return

# Generated at 2022-06-23 22:31:52.956028
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:01.478347
# Unit test for function main
def test_main():
    from .conf import settings
    result = main(['-t', 'python27', '-i', './test/test.py', '-o', './test/test3.py'])
    assert result == 0
    sys.path.insert(0, './test/')
    assert test() == [3, 4, 5, 6, 7, 8]
    del sys.path[0]
    result = main(['-t', 'python27', '-i', './test/test.py', '-o', './test'])
    assert result == 0
    sys.path.insert(0, './test/')
    assert test() == [3, 4, 5, 6, 7, 8]
    del sys.path[0]

# Generated at 2022-06-23 22:32:05.700279
# Unit test for function main
def test_main():
    # no arguments
    try:
        main()
    except SystemExit:
        pass
    # input, output, target
    result = main(['-i', 'input', '-o', 'output', '-t', 'py35'])
    assert result == 0

# Generated at 2022-06-23 22:32:11.018103
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',
                '-i', __file__,
                '-o', '.boo',
                '-t', '2.7',
                '-r', '.',
                '-d']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:19.939306
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/fixtures/if.py', '-o', 'out', '-t', '3.4']
    assert main() == 0

    sys.argv = ['py-backwards', '-i', 'tests/fixtures/cannot_open.py', '-o', 'out', '-t', '3.4']
    assert main() == 1

    sys.argv = ['py-backwards', '-i', 'tests/fixtures/not_file.py', '-o', 'out', '-t', '3.4']
    assert main() == 1

    # TODO add more tests for main()

# Generated at 2022-06-23 22:32:24.047197
# Unit test for function main
def test_main():
    test_args = ["-i","py_backwards","-o","py_backwards",
    "-t","python2","-r","py_backwards"]
    sys.argv[1:] = test_args
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:27.249699
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/input.py', '-o', 'tests/output.py',
                '-t', '3.5', '-d']
    assert main() == 0

# Generated at 2022-06-23 22:32:38.768377
# Unit test for function main
def test_main():
    # test wrong number of arguments
    with pytest.raises(SystemExit):
        main()
    # Test invalid input
    with pytest.raises(SystemExit):
        main(['/doesnt/exist.py', '-o', '-t', '2.7'])
    # Test invalid output
    with pytest.raises(SystemExit):
        main(['/doesnt/exist.py', '-o', '-t', '2.7'])
    # Test invalid root
    with pytest.raises(SystemExit):
        main(['/doesnt/exist.py', '-o', '-t', '-r', '2.7'])
    # Test invalid target

# Generated at 2022-06-23 22:32:39.301460
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:45.849212
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'test/test_data/test_function.py',
                    '-o', 'test/test_data/test_function_result.py',
                    '-t', '2.7', '-r', 'test/test_data']

    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:52.260715
# Unit test for function main
def test_main():
    # Check input file doesnt exists
    file = __file__.split('/')[-1]
    args = ['-i', file, '-o', 'test.py', '-r', file, '-t', '3.5']
    assert main(args) == 1

    # Check output file is not folder
    # 
    try:
        assert main([]) == 1
    except SystemExit:
        pass
    except:
        assert True
    else:
        assert False


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:03.158187
# Unit test for function main
def test_main():
    from .conf import settings

    try:
        main()
    except SystemExit as e:
        assert(e.code == 2)

    settings.root = 'tests/sample'
    main()

    main(['-i', 'a', '-i', 'b', '-t', '3.6', '-o', 'c'])
    main(['-i', 'a', '-i', 'b', '-t', '3.5', '-o', 'c'])
    main(['-i', 'a', '-i', 'b', '-t', '3.4', '-o', 'c'])

    settings.debug = True
    main(['-i', 'a', '-i', 'b', '-t', '3.6', '-o', 'c'])



# Generated at 2022-06-23 22:33:09.784871
# Unit test for function main
def test_main():
    with patch('argparse.ArgumentParser', spec=True) as parser:
        parser().parse_args.return_value = 'args'
        with patch('sys.exit', spec=True) as sys_exit:
            with patch('pyson.conf.init_settings', spec=True) as init_settings:
                init_settings.return_value = None
                with patch('pyson.compiler.compile_files', spec=True) as compile_files:
                    compile_files.return_value = 'result'
                    with patch('pyson.messages.compilation_result', spec=True) as messages:
                        messages.return_value = 'compilation_result'
                        main()
    parser().parse_args.assert_called_once_with()
    init_settings.assert_called_once_with('args')
    compile

# Generated at 2022-06-23 22:33:21.145205
# Unit test for function main
def test_main():
    import subprocess
    # Case 1
    # Testing normal flow
    input_file = "./test_input.py"
    output_file = "./test_output.py"
    args = ['py-backwards', '-i', str(input_file), '-o', str(output_file), '-t', '2.7']
    process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode('utf-8')
    err = err.decode('utf-8')
    assert out == "Compiled successfully: 1 files, 0 errors.\n"
    assert err == ""
    # Case 2
    # Testing wrong python version

# Generated at 2022-06-23 22:33:21.955768
# Unit test for function main
def test_main():
    init_settings(False)
    assert main() == 1

# Generated at 2022-06-23 22:33:22.499042
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:33:30.778579
# Unit test for function main
def test_main():
    init()

    # testing parser
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add

# Generated at 2022-06-23 22:33:37.771916
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards.py',
        '-i',
        '/Users/jakkapat/Python/py_backwards/tests/sample_code/test1.py',
        '/Users/jakkapat/Python/py_backwards/tests/sample_code/test2.py',
        '-o',
        '/Users/jakkapat/Python/py_backwards/tests/sample_code/test_output',
        '-t',
        '2.7',
        '--debug',
        '-r',
        '/Users/jakkapat/Python/py_backwards/tests/sample_code'
    ]
    main()

test_main()

# Generated at 2022-06-23 22:33:38.408801
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:39.089041
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:39.764624
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:33:40.388673
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:33:42.304570
# Unit test for function main
def test_main():
    raise NotImplementedError


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:42.927676
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:44.341816
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:45.031801
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:47.929759
# Unit test for function main
def test_main():
    sys.argv = [
        '--input', 'test/test_file', '--output', 'test/test_file_output',
        '--target', '3.4'
    ]
    assert main() == 0

# Generated at 2022-06-23 22:33:48.875354
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-23 22:33:58.963731
# Unit test for function main
def test_main():
    from random import randint
    from unittest.mock import patch
    from io import StringIO
    from time import time
    from os import chdir
    from os.path import exists, dirname, join, abspath

    curdir = abspath(dirname(__file__))
    chdir(curdir)

    # Unit test for function main
    def test_main():
        from argparse import ArgumentParser
        from random import random
        from unittest.mock import patch, call
        from io import StringIO
        from .compiler import compile_files
        from .conf import init_settings, get_settings
        from . import const, messages, exceptions


# Generated at 2022-06-23 22:33:59.508772
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:34:01.344988
# Unit test for function main
def test_main():
    sys.argv = ['Py-backwards','-i', 'test\\test.py', '-o', 'test\\backwards\\test.py', '-t', '2.7' ]
    assert main() == 0

# Generated at 2022-06-23 22:34:04.707000
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests', '-o', 'output', '-t', '3.4', '-r', 'tests']
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:34:05.274574
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:13.967863
# Unit test for function main
def test_main():
    sys_argv = sys.argv
    sys.argv = ['-i', 'input1', '-o', 'output']
    assert main() == 2

    sys.argv.extend(['-t', 'python2.7'])
    assert main() == 2

    sys.argv.append('-h')
    assert main() == 0

    sys.argv = ['-i', '.', '-o', 'output', '-t', 'python2.7']
    assert main() == 1

    sys.argv = ['-i', './test/test-files/test_fixtures/', '-o', 'output', '-t', 'python2.7']
    assert main() == 0


# Generated at 2022-06-23 22:34:22.639902
# Unit test for function main
def test_main():
    from argparse import Namespace
    from .conf import settings
    from . import const
    import tempfile
    import os
    import shutil
    from .utils import touch

    f = tempfile.TemporaryDirectory()
    d = tempfile.TemporaryDirectory()

    with open(os.path.join(f.name, 'a.py'), 'w') as fd:
        fd.write('x: int = 5')

    os.mkdir(os.path.join(d.name, 'b'))
    os.mkdir(os.path.join(d.name, 'c'))

# Generated at 2022-06-23 22:34:33.407311
# Unit test for function main
def test_main():
    import re
    import sys
    import subprocess

    assert main() == 0

    sys.argv = ['', '-i', 'tests/cli/require_source/',
                '-o', 'tests/cli/require_source_output/',
                '-t', 'python3.6',
                '-r', 'tests/cli/']

    with subprocess.Popen(['python3.5', '-m', 'py_backwards'],
                          stderr=subprocess.PIPE) as proc:
        _, err = proc.communicate()

        ret = re.search('3.6.*/foobar.py', err.decode())
        assert ret is not None


# Generated at 2022-06-23 22:34:41.044346
# Unit test for function main
def test_main():
    argv = sys.argv
    sys.argv += ["-i", "tests/test_1.py", "-o", "tests/test_1.py", "-r", "tests", "-t", "py35"]

    original_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        main()
        output = out.getvalue().strip()
        assert output == "Successfully compiled 1 source."
    finally:
        sys.stdout = original_stdout
        sys.argv = argv

# Generated at 2022-06-23 22:34:42.013655
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:48.655197
# Unit test for function main
def test_main():
    file = "D:/PycharmProjects/py-backwards/TESTS/test_src/test.py"
    output = "D:/PycharmProjects/py-backwards/TESTS/test_dst"
    target = "test"
    root = "D:/PycharmProjects/py-backwards/TESTS/test_src"
    debug = True

    init_settings(file,output,target,root,debug)

    try:
        for input_ in file:
            result = compile_files(input_,output, target, root)
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1

# Generated at 2022-06-23 22:34:53.584233
# Unit test for function main
def test_main():
    # Test with non-existent target
    sys.argv[2] = '3.5'
    try:
        assert main() == 1
    except NameError:
        assert False
    sys.argv.pop(2)
    sys.argv.insert(2, '3.6')
    try:
        assert main() == 1
    except NameError:
        assert False

# Generated at 2022-06-23 22:35:04.263342
# Unit test for function main
def test_main():
    # input is not a list
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(["-t", "3.6", "-i", "shapes", "-o", "shapes_target"])
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

    # input is not a string
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(["-t", "3.6", "-i", "shapes", "-o", "shapes_target", '-r'])
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

    # target is not a string

# Generated at 2022-06-23 22:35:05.706626
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    print(main())

# Generated at 2022-06-23 22:35:06.307509
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:08.610577
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'a.py', '-o', 'b.py', '-t', '3.5',
                '-d']
    main()
    main()

# Generated at 2022-06-23 22:35:10.246409
# Unit test for function main
def test_main():
    assert main(['-i', 'test', '-o', 'test', '-t', 'python2', '-r', 'test']) == 0

# Generated at 2022-06-23 22:35:16.216565
# Unit test for function main
def test_main():
    import os
    from tempfile import TemporaryDirectory
    from subprocess import run
    from shutil import copy2

    with TemporaryDirectory() as temp:
        print(temp)
        test_path = os.path.join(temp, 'test')
        os.mkdir(test_path)
        copy2(os.path.join('..', 'test', 'data', 'examples', 'test.py'),
              os.path.join(test_path, 'test.py'))
        result = run([sys.executable, '-m', 'py_backwards.main',
                      '-i', test_path, '-o', test_path,
                      '-t', 'python3.5'])
        assert result.returncode == 0, 'Run failed'

# Generated at 2022-06-23 22:35:25.468196
# Unit test for function main
def test_main():
    class MockParser:
        def __init__(self, args):
            self.args = args

        def parse_args(self):
            return self.args

    class MockCompiler:
        def __init__(self):
            self.call_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count += 1
            if args[0] == 'a/b/c':
                raise ValueError
            elif args[0] == 'a/b/c/d':
                raise FileNotFoundError
            elif args[0] == 'a/b/c/d/e':
                raise exceptions.CompilationError(
                    'test_exception', 'test_file', None, None)

# Generated at 2022-06-23 22:35:29.310135
# Unit test for function main
def test_main():
    sys.argv = ['cmd', '-i', 'pybackwards/tests/foo.py', '-o', 'pybackwards/tests/foo.py', '-t', '2.7']
    assert main() == 0


# Generated at 2022-06-23 22:35:30.696524
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-23 22:35:39.330897
# Unit test for function main
def test_main():
    input_ = 'test/test_files/good/good.py'
    output = 'test/test_files/output'
    args = ['py-backwards', '-i', input_,
            '-o', output, '-t', 'python2']
    sys.argv = args

    # Function main should return 0 if compilation was successful
    assert main() == 0, 'Expected 0 -- if successful'

    # Function main should return 1 if compilation was unsuccessful
    args[3] = 'test/test_files/output_wrong'
    sys.argv = args
    assert main() == 1, 'Expected 1 -- if unsuccessful'

# Generated at 2022-06-23 22:35:39.722572
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:42.244403
# Unit test for function main
def test_main():
    sys.argv = ['pyback', '-i', 'tests/input.py', '-o', 'tests/output.py', '-t', '3.4', '-r', 'tests']
    assert main() == 0

# Generated at 2022-06-23 22:35:47.306323
# Unit test for function main
def test_main():
    import types
    parser = main.__code__.co_varnames[0]
    assert parser in main.__defaults__
    assert type(main.__defaults__[parser]) == ArgumentParser

# Generated at 2022-06-23 22:35:50.195975
# Unit test for function main
def test_main():
    sys.argv = ['', '-o', 'test_files/output', '-i', 'test_files/example.py',
                '-t', '2.7', '-r', 'test_files']
    assert main() == 0


# Generated at 2022-06-23 22:36:00.728967
# Unit test for function main

# Generated at 2022-06-23 22:36:01.355202
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:36:13.262729
# Unit test for function main
def test_main():
    # test 1
    print("Testing 1")
    file = open("input_1.txt" , "w")
    file.write("def m():\n    pass")
    file.close()
    file = open("input_2.txt" , "w")
    file.write("class A:\n    def m():\n        pass")
    file.close()
    file = open("import_test.py", "w")
    file.write("import input_1\nimport input_2")
    file.close()
    sys.argv = ["py-backwards.py", "-i", "input_1.txt", "input_2.txt", "-o", "output_file.txt", "-t", "3.5", "-r", "root", "-d", "false"]

# Generated at 2022-06-23 22:36:19.512030
# Unit test for function main
def test_main():
    file_names = ["examples/foo.py", "examples/bar.py"]

    def _add_to_sys_argv(file_name):
        sys.argv.append(file_name)
    list(map(_add_to_sys_argv, file_names))
    sys.argv.append("--output")
    sys.argv.append("test_output")
    sys.argv.append("--target")
    sys.argv.append("3")

    assert main() == 0

# Generated at 2022-06-23 22:36:21.852097
# Unit test for function main
def test_main():
    # main()
    pass


# Code to execute unit test
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:36:28.661634
# Unit test for function main
def test_main():
    def copy_to_test_data(file_name):
        os.system(f'cp ./data/examples/{file_name} ./data/test/')

    # Test version 3
    # compile file
    if sys.platform == "linux":
        os.system('rm -rf ./data/test/*')
        copy_to_test_data('simple_test.py')
        copy_to_test_data('simple_test3.py')
        copy_to_test_data('parent.py')
        copy_to_test_data('child.py')
        sys.argv = ['py-backwards', '-i', './data/test', '-o', './data/test',
                    '-t', '3', '-r', './data/test', '-d']
        main()
       