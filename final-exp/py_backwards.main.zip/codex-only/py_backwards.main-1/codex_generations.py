

# Generated at 2022-06-23 22:26:39.351753
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from unittest import TestCase
    from . import test_main_mockdata as mock_data

    class TestMain(TestCase):
        def test_main_with_input_doesnt_exist(self):
            with patch('sys.argv', mock_data.with_input_doesnt_exist):
                with self.assertRaises(SystemExit) as cm:
                    main()
                self.assertEqual(cm.exception.code, 1)

        def test_main_with_invalid_output(self):
            with patch('sys.argv', mock_data.with_invalid_output):
                with self.assertRaises(SystemExit) as cm:
                    main()
                self.assertEqual(cm.exception.code, 1)


# Generated at 2022-06-23 22:26:43.472708
# Unit test for function main
def test_main():
    inp = ['tests/data/task_1.py']
    out = 'tests/data/task_1_py2.py'
    tgt = '2.7'
    assert main() == 0, 'Main func succesful'

# Generated at 2022-06-23 22:26:55.057731
# Unit test for function main
def test_main():
    import os
    import shutil

    args = sys.argv
    argv = ['py-backwards', '-i', '../py_backwards/tests/test_files/', '-o',
            '../py_backwards/tests/test_files/copy', '-t', '2']
    sys.argv = argv
    main()
    sys.argv = args

    # Check if files were copied
    assert os.path.exists('../py_backwards/tests/test_files/copy')
    assert os.path.exists('../py_backwards/tests/test_files/copy/test.py')
    assert os.path.exists('../py_backwards/tests/test_files/copy/test2.py')

# Generated at 2022-06-23 22:27:01.738642
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',
                '-i', 'examples/source/static.py',
                '-t', '3.5',
                '-o', 'examples/target/']
    main()

    sys.argv = ['py-backwards',
                '-i', 'examples/source',
                '-t', '3.5',
                '-o', 'examples/target/']
    main()

if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-23 22:27:02.289933
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 22:27:11.561264
# Unit test for function main
def test_main():
    with mock.patch.object(sys, 'argv', ['', '-i', './in.py', '-o',
                                         './out.py', '-t', '2.7']):
        mock_result = {
            'processed_files': 1,
            'ignored_files': 0,
            'error_files': 0,
            'ignored_folders': 0,
            'zero_size_files': 0,
            'target': '2.7'
        }
        with mock.patch.object(sys, 'stderr') as mock_stderr:
            assert main() == 0
            mock_stderr.write.assert_not_called()
        with mock.patch.object(sys, 'stdout') as mock_stdout:
            mock_stdout.write.assert_called

# Generated at 2022-06-23 22:27:20.122813
# Unit test for function main
def test_main():
    args = ['-i', 'test1.py', 'test2.py',
            '-r', 'test',
            '-o', 'test/a',
            '-t', '2.7']
    res = main(args)
    with open('test/a/test1.py.backup') as f:
        backup = f.read()

# Generated at 2022-06-23 22:27:21.401976
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:21.783447
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:28.142482
# Unit test for function main
def test_main():
    # create parser
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:27:28.699842
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:37.455387
# Unit test for function main
def test_main():
    # input_folder is the all the files for the test
    for input_folder in ['test/timeit']:
        #  output_folder is the expected output
        for output_folder in ['input_output']:
            with open(output_folder + '/timeit_output.py', 'r') as f:
                expected = f.read()
            if os.path.exists('timeit_output.py'):
                os.remove('timeit_output.py')
            main(argv=['-i', input_folder, '-o', 'timeit_output.py', '-t',
                       '27', '-r', 'test'])
            with open('timeit_output.py') as f:
                output = f.read()
            assert output == expected

# Generated at 2022-06-23 22:27:42.277137
# Unit test for function main
def test_main():
    from unittest import TestCase, mock
    from . import messages

    class MainTest(TestCase):

        @mock.patch.object(sys, 'argv', ['py-backwards.py', '-i', 'in', '-o', 'out'])
        @mock.patch('builtins.exit')
        def test_incorrect_args(self, exit_):
            main()
            exit_.assert_called_with(1)


# Generated at 2022-06-23 22:27:45.930298
# Unit test for function main
def test_main():
    sys.argv = 'py-backwards -r ../ob/tests -d -i input.py -o output.py -t 2.7'.split()
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:57.354644
# Unit test for function main
def test_main():
    input_ = ['./src/py_backwards/tests/test3.py']
    output = './src/py_backwards/tests/test3.py'
    target = '-t', 'py35'
    root = '-r', './src/py_backwards/tests/'
    parser = ArgumentParser('py-backwards')
    parser.add_argument('-i', '--input', type=str, nargs='+')
    parser.add_argument('-o', '--output', type=str)
    parser.add_argument('-t', '--target', type=str, choices=const.TARGETS.keys())
    parser.add_argument('-r', '--root', type=str)
    parser.add_argument('-d', '--debug', action='store_true')
   

# Generated at 2022-06-23 22:27:59.831425
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'main.py', '-o', 'out.py', '-t',
                '2.6']
    assert main() == 0

# Generated at 2022-06-23 22:28:05.690786
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'test_files/test_files_python_2.7',
        '-o', 'test_files/output_tmp',
        '-t', '2.7',
        '-r', 'test_files/test_files_python_2.7',
    ]
    assert main() == 0

# Generated at 2022-06-23 22:28:08.125486
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards",
                "-i", "tests/data/test.py",
                "-t", "2.7",
                "-o", "tests/data/test_output"]
    assert main() == 0

# Generated at 2022-06-23 22:28:12.202845
# Unit test for function main
def test_main():
    class _Cli:
        def __init__(self, input_, output, target):
            self.input = input_
            self.output = output
            self.target = target
            self.debug = False
            self.root = None

    class _ArgParse:
        def __init__(self, input_, output, target):
            self._cli = _Cli(input_, output, target)

        def parse_args(self):
            return self._cli

    class _Sys:
        def __init__(self):
            self.stderr = _Output()


# Generated at 2022-06-23 22:28:21.521502
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('tests/test_data/')
    sys.argv.append('-o')
    sys.argv.append('./output/')
    sys.argv.append('-t')
    sys.argv.append('Python27')
    sys.argv.append('-r')
    sys.argv.append('')
    sys.argv.append('-d')
    sys.argv.append('')
    try:
        result = main()
    except exceptions.InputDoesntExists:
        assert False
    except exceptions.InvalidInputOutput:
        assert False
    except exceptions.PermissionError:
        assert False
    assert result == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:25.982195
# Unit test for function main
def test_main():
    arg_dict = {
        'input': ['module.py'],
        'output': 'module.py',
        'target': '3.5',
        'root': '.',
        'debug': True
    }
    args = type('', (), arg_dict)()
    assert main() == 0

# Generated at 2022-06-23 22:28:28.312013
# Unit test for function main
def test_main():
    init_settings()
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:35.290488
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test_out.py', '-r', 'root/', '-t', '2.7', '-d']
    sys.stdout = open('output_test.txt', 'w')
    try:
        assert main() == 0
    except AssertionError:
        print('error in main')
    sys.stdout.close()

# Generated at 2022-06-23 22:28:38.942295
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/argparser-test-input.txt', '-o', 'tests/argparser-output.txt', '-t', '3.3']
    main().assert_equals(0)

# Generated at 2022-06-23 22:28:45.963910
# Unit test for function main
def test_main():
    import io
    from contextlib import redirect_stdout
    from ddt import ddt, data

    @ddt
    class TestClass(unittest.TestCase):

        @data(
            ['-i', 'incorrect_input', '-o', 'output', '-t', '33'],
            ['-i', 'input', '-o', 'output', '-t', 'incorrect_target'],
            ['-i', 'input', '-o', 'input', '-t', '27'],
            ['-i', 'input', '-o', 'output', '-t', '27'],
        )
        def test_function(self, test_data):
            sys.argv = test_data
            f = io.StringIO()
            with redirect_stdout(f):
                self.assertRa

# Generated at 2022-06-23 22:28:46.546587
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:48.167680
# Unit test for function main
def test_main():
    return main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:50.270818
# Unit test for function main
def test_main():
    print("test main")
    main()
    for i in range(5):
        print("test main")
        main()

# Generated at 2022-06-23 22:28:52.351579
# Unit test for function main
def test_main():
    with pytest.raises(AttributeError):
        main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:53.657619
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:58.938552
# Unit test for function main
def test_main():
    from .conf import settings

    sys.argv[1:] = ['-i', 'tests/backwards-test-pkg/test_package.py',
                    '-o', 'output', '-t', '2.7', '-r', 'output']

    assert main() == 0

    assert settings.INPUT == ['tests/backwards-test-pkg/test_package.py']
    assert settings.OUTPUT == 'output'
    assert settings.TARGET == '2.7'
    assert settings.ROOT == 'output'
    assert settings.DEBUG == False

# Generated at 2022-06-23 22:28:59.488445
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:29:03.481445
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test.py', '-o',
                'test/test-out.py', '-t', '2.7', '-r', 'test']
    assert main() == 0
    # assert os.system('python3 -m pytest test/test-out.py') == 0

# Generated at 2022-06-23 22:29:05.567974
# Unit test for function main
def test_main():
    sys.argv += ['-i', './examples/example.py', '-o', './examples/output.py', '-t', 'python27']
    main() == 0

# Generated at 2022-06-23 22:29:08.268165
# Unit test for function main
def test_main():
    init_settings(None)
    with open(const.TEST_DIR + '/input/test.py', 'w') as file:
        file.write('')

    try:
        main()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-23 22:29:18.271255
# Unit test for function main
def test_main():
    import os
    import shutil
    from .const import TARGETS
    here = os.path.dirname(os.path.abspath(__file__))
    test_dir = here + '/test'
    result_dir = here + '/test_result'
    tests = [
        test_dir + '/test.py',
        test_dir + '/test',
        'test.py',
        'test'
    ]
    targets = [
        TARGETS['2.7'],
        TARGETS['3.4'],
        TARGETS['3.5'],
        TARGETS['3.6']
    ]

    for test_in in tests:
        for target in targets:
            test_out = result_dir + '/test_' + target.name

# Generated at 2022-06-23 22:29:20.998973
# Unit test for function main
def test_main():
    test_args = ['py-backwards', '-i', '.', '-o', 'build', '-t', '2.7']
    res = main(test_args)
    assert res == 0

# Generated at 2022-06-23 22:29:21.904721
# Unit test for function main
def test_main():
    assert main() != None

# Generated at 2022-06-23 22:29:22.533118
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:29:34.233294
# Unit test for function main
def test_main():
    # Dummy command line parser
    class Args:
        def __init__(self, input, output, target, root):
            self.input = input
            self.output = output
            self.target = target
            self.root = root

    path_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    args = Args([os.path.join(path_root, 'test_programs', 'test.py')],
                os.path.join(path_root, 'test_programs', 'compiled'),
                'py36',
                path_root)
    init_settings(args)
    # Dummy exception
    class CompilationError(Exception):
        def __init__(self, msg):
            self.msg = msg


# Generated at 2022-06-23 22:29:34.706538
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:35.195375
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:38.439018
# Unit test for function main
def test_main():
    # The following call should raise an exception
    args = ['main.py', '-i', 'input.txt', '-o', 'output.txt', '-t', '3.3', '-r', '~/Desktop/SC2017']
    try:
        main(args)
    except:
        return True
    return False


# Generated at 2022-06-23 22:29:39.742936
# Unit test for function main
def test_main():
    # test python compiling
    assert main([]) == None

# Generated at 2022-06-23 22:29:40.396050
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:29:43.015362
# Unit test for function main
def test_main():
    sys.argv += ["-i", "src/examples", "-o", "out", "-t", "python2", "-d"]
    result = main()
    assert result == 0

# Generated at 2022-06-23 22:29:44.266140
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-23 22:29:44.942204
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:53.553971
# Unit test for function main
def test_main():
    try:
        import coverage
        import os
        cov = coverage.coverage(include=['py_backwards/main.py'])
        cov.start()
    except ImportError:
        pass

    import py_backwards.main
    if os.path.exists('test/test_main.py'):
        assert py_backwards.main.main() == 0
    else:
        assert py_backwards.main.main() == 1

    if os.path.exists('test/test_main.py'):
        assert py_backwards.main.main('-i', 'test/test_main.py',
                                      '-o', 'test/test_main.py2.3',
                                      '-t', '2.3') == 0
    else:
        assert py_backwards.main.main

# Generated at 2022-06-23 22:30:04.513579
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    assert main() != 0
    sys.argv = sys.argv[:1] + ['-i', './tests/input/no_such_file',
                               '-o', 'no_such_dir',
                               '-t', 'py27',
                               '-r', 'root']
    assert main() != 0
    sys.argv = sys.argv[:1] + ['-i', './tests/input/no_such_file',
                               '-o', 'no_such_dir',
                               '-t', 'py27',
                               '-r', 'root']
    assert main() != 0

# Generated at 2022-06-23 22:30:08.276146
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', './test/test_files/test.py',
                '-o', './test/test_files', '-t', '27']
    assert main() == 0

# Generated at 2022-06-23 22:30:09.589433
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:11.232138
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:20.513858
# Unit test for function main
def test_main():
    from .main import main
    import os
    import time
    import tempfile
    
    # Disable debug for tests
    const.DEBUG = False

    # Create temporary folder
    temp_folder_path = tempfile.mkdtemp()

    # Create first temporary file
    temp_file_name_1 = str(time.time())
    temp_file_path_1 = os.path.join(temp_folder_path, temp_file_name_1)
    with open(temp_file_path_1, 'w') as temp_file_1:
        temp_file_1.write('#!/usr/bin/env python\n' +
                          'a = (-1,) if 1 == 1 else (1, 2, 3)\n' +
                          'print(*a)')
        temp_file_1.flush()

   

# Generated at 2022-06-23 22:30:27.760644
# Unit test for function main
def test_main():
    # Positive test
    can_parse = False
    try:
        main()
    except SystemExit as e:
        if e.code == 1:
            can_parse = True
    assert can_parse

    # Negative test
    can_parse = True
    try:
        main(["--target", "python3", '-i', "./tests/test_data.py", '-o',
              "./tests/test_data.py"])
    except SystemExit as e:
        if e.code == 1:
            can_parse = False
    assert can_parse

# Generated at 2022-06-23 22:30:28.570972
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:36.312176
# Unit test for function main
def test_main():

    # Test 1: input doesn't exist
    class mocksys():
        class stdout:
            def writelines(self, *args, **kwargs):
                raise exceptions.InputDoesntExists()
    try:
        sys = mocksys()
        assert main() == 1
    except:
        pass


    # Test 2: invalid output
    class mocksys():
        class stdout:
            def writelines(self, *args, **kwargs):
                raise exceptions.InvalidInputOutput()  
    try:
        sys = mocksys()
        assert main() == 1
    except:
        pass


    # Test 3: no permission error
    class mocksys():
        class stdout:
            def writelines(self, *args, **kwargs):
                raise PermissionError()

# Generated at 2022-06-23 22:30:36.630118
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:30:44.875541
# Unit test for function main
def test_main():
    # 1. Testing with correct input and correct output
    # 1.1 Testing with 1 file and 1 folder
    sys.argv = ['py-backwards', '-i', 'py3.6.py', '-o', 'py3.5', '-t', '3.5',
                                             '-r', 'c:\programming']
    assert main() == 0
    # 1.2. Testing with multiple files and 1 folder
    sys.argv = ['py-backwards', '-i', 'py3.6.py', 'py3.6_2.py', '-o', 'py3.5', 
                                '-t', '3.5','-r', 'c:\programming']
    assert main() == 0
    # 1.3. Testing with multiple files and multiple folders

# Generated at 2022-06-23 22:30:46.837221
# Unit test for function main
def test_main():
    assert main() == 0
    
if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:47.528768
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:48.569460
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-23 22:30:52.537255
# Unit test for function main
def test_main():
    monkeypatch.setattr(sys, 'argv', ['-i', 'test/test2.py', '-o', 'test/test2.py', '-t', '3.5', '-r', 'test'])
    assert main() == 0



# Generated at 2022-06-23 22:30:55.933666
# Unit test for function main
def test_main():
    import sys
    import io

    old_sysout = sys.stdout
    sys.stdout = io.StringIO()
    main()
    sys.stdout = old_sysout

# Generated at 2022-06-23 22:31:03.578867
# Unit test for function main
def test_main():
    # Args: -i, -o, -t
    result = main(["-i", "project", "-o", "project", "-t", "3.5"])
    assert result == 0

    # Args: -i, -o, -t, -r
    result = main(["-i", "project", "-o", "project", "-t", "3.5", "-r", "app"])
    assert result == 0

    # Args: -i
    result = main(["-i", "project"])
    assert result == 0

    # Args: -i, -o
    result = main(["-i", "project", "-o", "project"])
    assert result == 0

    # Args: -i, -o, -t

# Generated at 2022-06-23 22:31:08.830750
# Unit test for function main
def test_main():
    # Set command-line arguments as if they were received
    sys.argv = ['', '-i', 'tests/compiler/__init__.py', '-o', 'tests/compiler/__init__.py', '-t', '3.5', '-r', 'tests']
    from .__main__ import main
    main()

# Generated at 2022-06-23 22:31:19.922438
# Unit test for function main
def test_main():
    source = 'tests/samples/sample.py'
    target = 'tests/samples/sample_result.py'
    args = '-i {} -t 3.5 -o {}'.format(source, target)
    query = '''python {} {}'''.format(sys.argv[0], args)
    print('Running query: ' + query)
    from subprocess import Popen, PIPE
    p = Popen(query, stdout=PIPE, stderr=PIPE, shell=True)
    stdout, stderr = p.communicate()
    print('stdout: ' + stdout.decode().rstrip())
    print('stderr: ' + stderr.decode().rstrip())

# Generated at 2022-06-23 22:31:21.670937
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:32.705670
# Unit test for function main
def test_main():
    # Testing main function with a valid input file
    sys.argv = ['py-backwards', '-i', 'compiler/test/test_files/valid.py',
                '-o', 'compiler/test/test_files', '-t', '2.7', '-d']
    assert main() == 0
    # Testing main function with a invalid input file
    sys.argv = ['py-backwards', '-i', 'compiler/test/test_files/invalid.py',
                '-o', 'compiler/test/test_files', '-t', '2.7', '-d']
    assert main() == 1
    # Testing main function with a invalid target file

# Generated at 2022-06-23 22:31:41.453269
# Unit test for function main
def test_main():
    import subprocess
    args = ["pybackwards", "-i", "test.py", "-o", "test_result.py", "-t", "35", "-r", "."]
    args2 = ["pybackwards", "-i", "test.py", "-o", "test_result.py", "-t", "27", "-r", "."]
    args3 = ["pybackwards", "-i", "test.py", "-o", "test_result.py", "-t", "36", "-r", "."]
    args4 = ["pybackwards", "-i", "test.py", "-o", "test_result.py", "-t", "37", "-r", "."]
    subprocess.call(args)
    assert subprocess.call(args2) == 1
    assert subprocess.call(args3) == 1


# Generated at 2022-06-23 22:31:42.073734
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:31:45.764624
# Unit test for function main
def test_main():
    sys.argv = ["py_backwards-3.6", "-i", "tests/sources/test1.py",
                "-o", "tests/sources/test1_output.py","-t","3.5"]
    assert main() == 0

# Generated at 2022-06-23 22:31:52.687542
# Unit test for function main
def test_main():
    sys.argv = ['', 'file.py']
    assert main() == 1
    sys.argv = ['', '-i', 'file.py', '-o', 'file.py', '-t', '36', '-r', './']
    assert main() == 0
    sys.argv = ['', '-i', 'file.py', '-o', 'file.py', '-t', '36', '-r', './']
    assert main() == 0


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:31:59.886705
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'test/source/test_file_1.py',
                '-o', 'test/output/test_file_1.py',
                '-t', '3.4']
    assert main() == 0
    assert os.path.exists('test/output/test_file_1.py')

    sys.argv = ['', '-i', 'test/source/test_folder',
                '-o', 'test/output/test_folder',
                '-t', '3.4']
    assert main() == 0
    assert os.path.exists('test/output/test_folder/test_file_1.py')
    assert os.path.exists('test/output/test_folder/test_file_2.py')


# Generated at 2022-06-23 22:32:10.678772
# Unit test for function main
def test_main():
    def run_main(args, *mocks):
        sys.argv = ['py_backwards'] + args
        with patch('py_backwards.conf.init_settings') as init_settings_mock:
            with patch('py_backwards.compiler.compile_files') as compile_files_mock:
                main()
                init_settings_mock.assert_called_once()
                compile_files_mock.assert_called_once_with(*mocks)
    run_main(['-i', 'a.py', 'b.py'], 'a.py b.py', './', const.TARGETS['27'], None)
    run_main(['-i', 'a.py'], 'a.py', './', const.TARGETS['27'], None)
    run_main

# Generated at 2022-06-23 22:32:17.174002
# Unit test for function main
def test_main():
    import pytest
    from argparse import ArgumentTypeError
    from .conf import init_arguments

    args = init_arguments()

    with pytest.raises(ArgumentTypeError):
        args.target('')
        args.target('3')

    with pytest.raises(ArgumentTypeError):
        args.target('3.3.3')

    with pytest.raises(ArgumentTypeError):
        args.target('3.6')

# Generated at 2022-06-23 22:32:18.596448
# Unit test for function main
def test_main():
    # Test from tests/compiler/test_main.py
    pass

# Generated at 2022-06-23 22:32:20.585680
# Unit test for function main
def test_main():
    r = main()
    assert r == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:21.993459
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:23.814354
# Unit test for function main
def test_main():
    assert main() == 0
    


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:27.390658
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', './pybackwards/tests/sources/', '-o', './pybackwards/tests/sources/', '-t', 'python27', '-d']
    assert main() == 0

# Generated at 2022-06-23 22:32:38.902878
# Unit test for function main
def test_main():
    # Test for wrong input
    assert main() == 1

    # Test for empty input
    assert main() == 1
    assert main('-i', '-o', '-t', '-r', '-d' == 1)
    assert main('-i', '-o', '-t', '-r' == 1)
    assert main('-i', '-o', '-t' == 1)
    assert main('-i', '-o' == 1)
    assert main('-i' == 1)

    # Test for correct input
    assert main() == 0
    assert main('-i', 'test.py', '-o', 'test.py-copy', '-t', '3.4', '-r' == 0)

# Generated at 2022-06-23 22:32:40.898775
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:41.677602
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:44.861874
# Unit test for function main
def test_main():
    assert main(['compiler.py', 'pbr/setup.cfg']) == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:50.296986
# Unit test for function main
def test_main():
    input_ = './test/test_input/test.py'
    output = './test/test_output/test.py'
    target = 'python2.7'
    root = './test/test_input'
    args = f'-i {input_} -o {output} -t {target} -r {root}'.split()
    sys.argv = args
    main()

# Uncomment for unit test
# test_main()

# Generated at 2022-06-23 22:33:02.080654
# Unit test for function main
def test_main():

    # Unit test for function main with incorrect input
    assert main() == 1
    # Unit test for function main with incorrect output
    assert main() == 1
    # Unit test for function main with existing output
    assert main() == 1
    # Unit test for function main with unexisting input
    assert main() == 1
    # Unit test for function main with empty input
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1

    # Unit test for function main with correct input
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0

# Generated at 2022-06-23 22:33:03.406801
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:09.925301
# Unit test for function main
def test_main():
    from . import utils, conf
    args = ['-i', 'tests', '-o', 'tests_out', '-t', 'py27', '-r', '.']
    status = main(args)
    assert status == 0
    assert utils.delete_dir('tests_out')
    assert os.path.exists('tests_out')

    assert utils.delete_dir('tests_out')
    args = ['-i', 'tests/test_compiler.py', '-o', 'tests_out', '-t', 'py27', '-r', '.']
    status = main(args)
    assert status == 0
    assert utils.delete_dir('tests_out')
    assert os.path.exists('tests_out')

    assert utils.delete_dir('tests_out')
   

# Generated at 2022-06-23 22:33:11.546186
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:16.032728
# Unit test for function main
def test_main():
    import pytest
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    # test if compiler compiles
    with captured_output() as (out, err):
        sys.argv = ['py-backwards', '-i', 'tests\\test_files\\simple.py', '-o', 'output.py', '-t', '36']
        main()
   

# Generated at 2022-06-23 22:33:24.371505
# Unit test for function main
def test_main():
    from tempfile import NamedTemporaryFile
    from os import path, remove, environ
    from .compiler import compile_files
    from .conf import init_settings
    from . import const


    _sys_args = sys.argv.copy()
    temp_folder = path.dirname(__file__)

    sys.argv = ['py-backwards', '-i', '-o', '-t', '-r']

    sys.argv[1] = path.join(temp_folder, 'tests', 'input')
    sys.argv[3] = '3.5'
    sys.argv[5] = 'tests/input'

    result = {'source_files': 0, 'transformed_files': 0, 'duplicates': 0}
    with NamedTemporaryFile() as f:
        sys

# Generated at 2022-06-23 22:33:33.981475
# Unit test for function main
def test_main():
    old_argv = sys.argv
    sys.argv = ['py-backwards.py']
    result = main()
    assert result == 2, "Error, bad input"
    sys.argv = ['py-backwards.py', '-i', 'f.py', '-o', 'f.py', '-t', '3.5']
    result = main()
    assert result == 1, "Error, no file with name f.py"
    sys.argv = ['py-backwards.py', '-i', 'unit_test.py', '-o',
                'unit_test.py', '-t', '3.5']
    result = main()
    assert result == 1, "Error, input and output are the same"

# Generated at 2022-06-23 22:33:38.605269
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/input/1.py',
                '-o', 'tests/output/1.py',
                '-t', '2.7']
    sys.exit(main())

# Generated at 2022-06-23 22:33:40.074576
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:44.038103
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'input',
        '-o', 'output',
        '-t', 'PY35',
        '-r', 'root',
        '-d'
    ]
    assert main() == 0

# Generated at 2022-06-23 22:33:52.330743
# Unit test for function main
def test_main():
    # Test for successful compilation
    sys.argv = ['py-backwards', 'tests/data/input', 'tests/data/output', '2']
    main()
    sys.argv = ['py-backwards', 'tests/data/input', 'tests/data/output', '3']
    main()
    sys.argv = ['py-backwards', 'tests/data/input', 'tests/data/output', '3.5']
    main()

    # Test for unsuccessful compilation
    sys.argv = ['py-backwards', 'tests/data/input', 'tests/data/output', '3.6']
    assert main() == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:01.814043
# Unit test for function main
def test_main():
    """
    Run the program main() and check the output
    """
    infile = '{}/tests/sources/test1.py'.format(os.getcwd())
    c = patch('sys.argv', ['py-backwards', '-i', infile, '-o', 'out', '-t', '2.7'])
    c.start()
    try:
        assert main() == 0
        with open('out/test1.py') as f:
            assert f.read() == 'def f(a, b):\n    return a + b'
        os.remove('out/test1.py')
        os.remove('out/__init__.py')
        os.removedirs('out')
    finally:
        c.stop()


# Generated at 2022-06-23 22:34:11.617535
# Unit test for function main

# Generated at 2022-06-23 22:34:13.557630
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:18.326248
# Unit test for function main
def test_main():
    import unittest.mock

    with unittest.mock.patch('sys.argv', ['py-backwards', '-i', 'test.py',
                                          '-o', 'test.out.py', '-t', '3.5']):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:23.148893
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'examples/func.py',
                '-o', 'output.py', '-t', '3.5']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:23.999250
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:29.818456
# Unit test for function main
def test_main():
    m = __import__('sys')
    sys.argv = ['py-backwards','-i', '/home/dev/Documents/python_compiler/backwards',
                '-o', '/home/dev/Documents/python_compiler/output', '-t', 'python35']
    main()
    assert (main() == 0)
    
if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:34:34.001560
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append('tests/data/source')
    sys.argv.append('-o')
    sys.argv.append('tests/data/output')
    sys.argv.append('-t')
    sys.argv.append('python27')
    sys.argv.append('-d')
    return


# Generated at 2022-06-23 22:34:35.693134
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:34:36.837184
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:34:43.763710
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/io_dir', '-t', '36', '-o', 'out',
                    '-r', 'tests/io_dir']
    import os
    if os.path.exists('out'):
        import shutil
        shutil.rmtree('out')
    assert(main())
    import subprocess
    assert(subprocess.call(['python', 'out/tests/io_dir/test.py']) == 1)

# Generated at 2022-06-23 22:34:44.213458
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:44.701722
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:34:55.119966
# Unit test for function main
def test_main():
    from io import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def capture():
        oldout = sys.stdout
        try:
            out = [StringIO(), StringIO()]
            sys.stdout = out[0]
            sys.stderr = out[1]
            yield out
        finally:
            sys.stdout = oldout
            sys.stderr = oldout

    with capture() as out:
        main(['./tests/invalid_input.py', '-o',
              './tests/output.py', '-t', '2.7', '-r', './tests'])
    assert 'InvalidInputError' in out[1].getvalue()


# Generated at 2022-06-23 22:34:56.044406
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-23 22:35:06.756885
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i fake_input', '-o fake_output', '-t py37']
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')

# Generated at 2022-06-23 22:35:13.672680
# Unit test for function main
def test_main():
    import sys
    import os
    from unittest.mock import Mock, patch

    class FakeArgparse:
        class FakeNamespace:
            pass

        @staticmethod
        def parse_args(*args):
            namespace = FakeArgparse.FakeNamespace()
            namespace.input = args[0]
            namespace.output = args[1]
            namespace.target = args[2]
            return namespace


# Generated at 2022-06-23 22:35:14.379307
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:22.907599
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/input/single_def.py', '-o',
                'compiled_file.py', '-t', '3.6', '-d']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/input/single_def.py', '-o',
                'compiled_file.py', '-t', '2.7', '-d']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/input/single_def.py', '-o',
                'compiled_file.py', '-t', '2.6', '-d']
    assert main() == 0



# Generated at 2022-06-23 22:35:24.370772
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:35:33.798484
# Unit test for function main
def test_main():
    sys.stderr.write = lambda x: None
    sys.stdout.write = lambda x: None

    class Args:
        input = ''
        output = ''
        target = ''
        root = ''

    args = Args()

    with open('compiler/tests/data/input.py', 'r') as f:
        expected_output = f.read()

    args.input = 'compiler/tests/data/input.py'
    args.output = 'compiler/tests/data/output.py'
    args.target = '2.7'
    args.root = 'compiler/tests/data'

    init_settings(args)
    compile_files(args.input, args.output, const.TARGETS[args.target],
                 args.root)


# Generated at 2022-06-23 22:35:41.104353
# Unit test for function main
def test_main():
    init_settings(ArgumentParser.parse_args(['-t', '2.7',
                                             '-i', '../tests/input/',
                                             '-o', '../tests/output2/',
                                             '-r', '../tests/input']))
    result = main()
    assert result == 0
    # and 5 files has been compiled to Python 2.7
    assert len(os.listdir('../tests/output2/')) == 5

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:42.244548
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:51.375415
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile

    # Create sandbox
    sandbox = tempfile.mkdtemp()
    os.mkdir(os.path.join(sandbox, 'source'))
    os.mkdir(os.path.join(sandbox, 'output'))
    os.mkdir(os.path.join(sandbox, 'invalid_output'))

    # Create test data
    open(os.path.join(sandbox, 'source', 'test.py'), 'w').close()
    open(os.path.join(sandbox, 'output', 'test.py'), 'w').close()

    # Test compilation
    assert(main() == 0)

    # Test compilation with error
    os.remove(os.path.join(sandbox, 'source', 'test.py'))

# Generated at 2022-06-23 22:35:52.039097
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:53.575694
# Unit test for function main
def test_main():
    args = ArgumentParser('py-backwards')
    assert main(args) == 1

# Generated at 2022-06-23 22:35:58.738411
# Unit test for function main
def test_main():
    try:
        main('-i', 'tests/data/library.py',
             '--output', '~',
             '--target', 'py35',
             '-r', 'tests/data/')
        print('main() Success!')
        return True
    except Exception as e:
        print(e)
        print('main() Failed!')
        return False

# Generated at 2022-06-23 22:36:06.269836
# Unit test for function main
def test_main():
    import os
    import shutil

    cwd = os.getcwd()
    input_ = 'tests/compilation_test_files/'
    output = 'tests/output'
    root = input_
    target = 'cpython27'

    try:
        shutil.rmtree(output)
    except Exception:
        pass

    program_args = ['-i', input_, '-o', output, '-t', target, '-r', root]

    assert main(program_args) == 0

    try:
        shutil.rmtree(output)
    except Exception:
        pass

    input_ = 'tests/compilation_test_files/t_3.6.py'
    program_args = ['-i', input_, '-o', output, '-t', target]
    assert main

# Generated at 2022-06-23 22:36:07.863138
# Unit test for function main
def test_main():
    assert main() == 1


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:13.439933
# Unit test for function main
def test_main():
    # Args
    sys.argv = ['py-backwards',
                '-i', 'tests',
                '-o', '.',
                '-t', '2.6',
                '-r', 'root']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:19.646985
# Unit test for function main
def test_main():
    import ast
    from .bin import const
    from py_backwards.bin import __main__ as main

    filename = 'test_bin.py'
    with open(filename, 'r') as f:
        tree = ast.parse(f.read())
    tree = main.compile_files(filename, filename + '_out', const.TARGETS['3.5'])
    assert ast.dump(tree) == ast.dump(main.compile_files(filename, filename + '_out', const.TARGETS['3.5']))

# Generated at 2022-06-23 22:36:20.280444
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:36:21.243455
# Unit test for function main
def test_main():
    init_settings(object)

# Generated at 2022-06-23 22:36:27.153182
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.argv', ['', '-i', 'input.py', 'output.py', '-t', 'py36']):
        with patch('sys.stdout', new=StringIO()) as fake_stdout:
            main()
            assert 'output.py' in fake_stdout.getvalue()

# Generated at 2022-06-23 22:36:27.830782
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:36:33.503658
# Unit test for function main