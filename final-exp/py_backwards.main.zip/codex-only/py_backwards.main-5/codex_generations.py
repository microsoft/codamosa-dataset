

# Generated at 2022-06-23 22:26:37.867328
# Unit test for function main
def test_main():
    print("Testing main")
    # Test case 1: Invalid input
    try:
        sys.argv = ["py-backwards.py","-i","/tmp/doesnt_exist.py","-o","/tmp/output.py","-t","2.7","-r","/tmp"]
        assert main() != 0
    except:
        print("ERROR: Test 1")
    # Test case 2: Invalid target version
    try:
        sys.argv = ["py-backwards.py","-i","/tmp/test.py","-o","/tmp/output.py","-t","2.8","-r","/tmp"]
        assert main() != 0
    except:
        print("ERROR: Test 2")
    # Test case 3: Invalid output

# Generated at 2022-06-23 22:26:40.287678
# Unit test for function main
def test_main():
    args = main.__wrapped__().__code__.co_varnames
    assert args == ('self', 'args')

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:26:51.771503
# Unit test for function main
def test_main():
    import unittest
    class TestMain(unittest.TestCase):
        def test_fail_to_compile_python3(self):
            retval = main(["--input", "tests/data/03_classes/01_init_with_args.py",
                           "--output", "tests/data/result.py",
                           "--target", "py36"])
            self.assertEqual(retval, 1)

        def test_compile_py27_to_py36(self):
            retval = main(["--input", "tests/data/03_classes/01_init_with_args.py",
                           "--output", "tests/data/result.py",
                           "--target", "py36",
                           "--root", "tests/data/root"])
            self

# Generated at 2022-06-23 22:27:01.936845
# Unit test for function main
def test_main():
    with patch('py_backwards.cli.ArgumentParser') as mock_parser:
        mock_parser().parse_args.return_value = mock()
        with patch('py_backwards.cli.init_settings') as mock_settings:
            with patch('py_backwards.cli.compile_files',
                       side_effect=exceptions.InputDoesntExists) as mock_compile:
                with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
                    main()
                    assert mock_stderr.getvalue() == messages.input_doesnt_exists([])

# Generated at 2022-06-23 22:27:02.788722
# Unit test for function main
def test_main():
    assert main() == 0, 'Compilation should succeed'

# Generated at 2022-06-23 22:27:03.328783
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:13.123490
# Unit test for function main
def test_main():
    from types import SimpleNamespace
    from .settings import Settings

    class Args:
        pass

    args = Args()

    def test_input(target):
        args.input = ['test_data/test_input.py']
        args.output = 'test_data/output.py'
        args.target = target
        init_settings(args)
        res = compile_files(args.input[0], args.output,
                            const.TARGETS[args.target],
                            None)
        assert res.succed == True and res.fail == 0 and res.skip == 0

    def test_output(target):
        args.input = ['test_data/test_input.py']
        args.output = 'test_data/output.py'
        args.target = target

# Generated at 2022-06-23 22:27:19.492402
# Unit test for function main
def test_main():
    import pytest
    import argparse
    import os
    import shutil

    os.mkdir('output')
    args = argparse.Namespace(
        input=['examples/print.py'],
        output='output',
        target='2.7',
        root= None,
        debug= None
    )
    assert main(args) == 0

    shutil.rmtree('output')

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:27.728603
# Unit test for function main
def test_main():

    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:27:28.843373
# Unit test for function main
def test_main():
    assert main([]) == 0

# Generated at 2022-06-23 22:27:30.696747
# Unit test for function main
def test_main():
    assert main(
        ) == 0, "Failed to run the code, please check your code and try again"

# Generated at 2022-06-23 22:27:37.455695
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append('examples/main.py')
    sys.argv.append('-o')
    sys.argv.append('compiled.py')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    sys.argv.append('-r')
    sys.argv.append('examples')
    sys.argv.append('-d')
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:42.320504
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/targets_test.py', 
        '-o', 'tests/targets_test.py', '-t', 'py26', '-r', 'tests']
    assert main() == 0

# Generated at 2022-06-23 22:27:47.657929
# Unit test for function main
def test_main():
    try:
        sys.argv = ['test_main.py',
                    '-i', './tests/input/ipy.py',
                    '-o', '/tmp/test.py',
                    '-t', '2.7',
                    '-r', './tests/']
        main()
    except SystemExit as e:
        # assert_equal(e.code, 1)
        print(e)

# Generated at 2022-06-23 22:27:58.506360
# Unit test for function main
def test_main():
    from .conf import reset_settings, get_settings
    from .lexer import collect_all_tokens
    from .tokens import TokenType
    from .nodes import RootNode, IndentationNode
    from .transformer import transform

    args = ['-i', '.', '-o', '.', '-t', 'python3.6']
    main(args)
    assert get_settings().root == '.'

    settings = get_settings()
    settings.debug = True
    main(args)
    assert settings.debug is True

    args = ['-i', 'nofile', '-o', '.', '-t', 'python3.6']
    main(args)
    assert settings.debug is False

    reset_settings()


# Generated at 2022-06-23 22:28:01.349262
# Unit test for function main
def test_main():
    args = ['--input', 'test',
            '--output', 'test',
            '--target', '3.4']
    assert main(args) == 0

# Generated at 2022-06-23 22:28:12.309268
# Unit test for function main
def test_main():
    #Test 1
    #Expected:
    #- Returns 1
    #- Stderr message has 'error'
    #- No stdout output
    sys.argv = ['py-backwards','-i', './path', '-o', './path', '-t', 'python2', '-r', './path']
    
    assert main() == 1
    assert (open('./stderr.txt', 'r').read()).find('error')
    assert (open('./stdout.txt', 'r').read()) == ""
    os.remove('./stderr.txt')
    
    
    #Test 2
    #Expected:
    #- Returns 0
    #- Stderr message has 'error'
    #- Stdout output

# Generated at 2022-06-23 22:28:19.551235
# Unit test for function main
def test_main():
    try:
        import sys
        import unittest.mock as mock
        from io import StringIO
        with mock.patch.object(sys, 'argv', ['py-backwards', '-o', 'test', '-t', '2.7', '-i', 'test.py']):
            with mock.patch(
                    'sys.stdout', new_callable=StringIO) as mock_out:
                main()
                assert mock_out.getvalue() == 'No input file(s) found\n'
    except:
        pass


# Generated at 2022-06-23 22:28:26.034720
# Unit test for function main
def test_main():
    try:
        compile_files("test_data/test_in.py","test_data/test_out.py",
                      const.TARGETS["3.4"])

    except exceptions.CompilationError as e:
        print(e)
    except exceptions.TransformationError as e:
        print(e)
    except exceptions.InputDoesntExists:
        print("Input file does not exist")
    except exceptions.InvalidInputOutput:
        print("Input and out paths are invalid")

# Generated at 2022-06-23 22:28:29.170918
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',
                '-i', 'test_input',
                '-o', 'test_output',
                '-t', '2.7']
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:34.304205
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/examples/simple_example.py', '-o', 'output.txt', '-t', 'python3.5', '-r', 'tests/examples/']
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:44.605819
# Unit test for function main
def test_main():
    settings.DEBUG_MODE_ENABLED = False
    sys.argv = sys.argv[:1] + ['-i', 'tests/examples/input', '-o',
                               'tests/examples/output', '-t', '3.5', '--root',
                               'tests/']
    assert main() == 0

    settings.DEBUG_MODE_ENABLED = False
    sys.argv = sys.argv[:1] + ['-i', 'tests/examples/input_error', '-o',
                               'tests/examples/output', '-t', '3.5', '--root',
                               'tests/']
    assert main() == 1

    settings.DEBUG_MODE_ENABLED = False

# Generated at 2022-06-23 22:28:54.509751
# Unit test for function main
def test_main():
    from .conf import settings
    import os
    def run_test(input_files, output, target):
        sys.argv = ['py-backwards.py', '-i'] + input_files + \
                   ['-o', output, '-t', target]
        assert main() == 0
        assert os.path.exists(settings.output_path)


# Generated at 2022-06-23 22:28:59.130013
# Unit test for function main
def test_main():
    test_args = [
        '-i', 'folder', '-o', 'fo', '-t', '2.7', '-r', 'root', '-d'
    ]
    with patch('builtins.print'):
        main(test_args)
        main(test_args)
        main(test_args)

# Generated at 2022-06-23 22:29:01.415732
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i',
        '../tests/fixtures/input.py',
        '-o',
        '../tests/fixtures/out',
        '-t',
        'py35'
    ]
    assert main() == 0


# Generated at 2022-06-23 22:29:01.792514
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:29:04.338718
# Unit test for function main
def test_main():
    res = main()
    if not res:
        print('Function main works fine.')
    else:
        raise Exception('Function main does not work.')

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:11.009797
# Unit test for function main
def test_main():
    from .pytest_backwards import parse

    assert main(['-i', 'test_input/test.py', '-o', 'test_input/b.py',
                 '-t', '3.4', '-d']) == 0
    with open('test_input/b.py') as f:
        assert f.read() == parse(
            '''
                from future.builtins.misc import str2

                print(str2('test'))

            ''')
    assert main(['-i', 'test_input/test.py', '-o', 'test_input', '-t', '3.4',
                 '-r', 'test_input']) == 0

# Generated at 2022-06-23 22:29:11.962404
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:22.583196
# Unit test for function main
def test_main():
    # noinspection PyProtectedMember
    assert main(['py-backwards']) == 2
    assert main(['py-backwards', '-h']) == 0
    assert main(['py-backwards', '-t', '3.5', '-i', 'input',
                 '-o', 'output']) == 1
    assert main(['py-backwards', '-t', '3.5', '-i', 'input', '-o', 'output',
                 '-d']) == 1

    # noinspection PyUnreachableCode
    assert main(['py-backwards', '-t', '2', '-i', 'input', '-o', 'output',
                 '-d']) == 0

# Generated at 2022-06-23 22:29:23.214067
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:34.881770
# Unit test for function main
def test_main():
    from .conf import config
    from unittest.mock import patch, Mock
    from . import compiler
    from . import messages
    from . import exceptions

    with patch('pback.compiler.compile_files') as compile_files_mock:
        with patch('pback.main.init_settings') as init_settings_mock:
            with patch('pback.main.ArgumentParser') as ArgumentParser_mock:
                with patch('pback.main.print') as print_mock:
                    ArgumentParser_mock.parse_args.return_value = Mock(
                        input=['test'],
                        output='test',
                        target='3.5',
                        root='root',
                        debug=True
                    )
                    init_settings_mock.return_value = ''
                    main()

                    init_settings

# Generated at 2022-06-23 22:29:35.459684
# Unit test for function main
def test_main():
    assert main() != 0

# Generated at 2022-06-23 22:29:40.942700
# Unit test for function main
def test_main():
    class Arguments:
        def __init__(self, input, output, target, root, debug):
            self.input = input
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    from .settings import settings
    sys.argv = ['py-backwards.py', '-i', 'input.py', '-o', 'output.py', '-t', 'python34', '-r', '', '-d', '']
    main()
    assert settings.TARGET == 'python34'
    assert settings.DEBUG

# Generated at 2022-06-23 22:29:43.516702
# Unit test for function main
def test_main():
    test_inputs = ['tests/test_inputs']
    test_output = 'tests/test_output'
    main(test_inputs)

# Generated at 2022-06-23 22:29:52.924044
# Unit test for function main
def test_main():
    # If a file is provided as input, asserts that the compiler works properly
    # If a directory is provided as input, asserts that the compiler works properly
    # If an invalid input/output combination is provided, asserts that an error is raised
    # If an invalid target version is provided, asserts that an error is raised
    # If a file that doesnt exists is provided as input, asserts that an error is raised
    # If a file that already exists is provided as output, asserts that an error is raised
    # If a directory that already exists is provided as output, asserts that an error is raised
    # If an input or output that doesnt exist is provided, asserts that an error is raised
    # If permissions are not enough to write a file, asserts that an error is raised
    assert main() == 0

# Generated at 2022-06-23 22:30:04.086208
# Unit test for function main
def test_main():
    input_list=['/home/mohamad/trunk/python/py-backwards-0.1.1/tests/test_in/test_in.py']
    output='/home/mohamad/trunk/python/py-backwards-0.1.1/tests/test_out/test_out.py'
    target='3.5'
    root='/home/mohamad/trunk/python/py-backwards-0.1.1/tests/test_in'
    args=Namespace(input=input_list, output=output, target=target, root=root, debug=False)
    init_settings(args)
    result = compile_files(input_list[0], output,
                   const.TARGETS[target], root)
    assert result == 1


# Generated at 2022-06-23 22:30:08.221860
# Unit test for function main
def test_main():
    init_settings({"-i":"first.txt -oabc.txt -tpython2.7 -rdir1 -d", "-output":"abc.txt", "-input":"first.txt","-target":"python2.7","-root":"dir1","-debug":True})
    assert main() == 0

# Generated at 2022-06-23 22:30:08.887179
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:30:18.597603
# Unit test for function main
def test_main():
    from io import StringIO
    from contextlib import redirect_stdout
    from sys import stderr
    from .compiler import compile_files, CompilationResult
    from .conf import init_settings

    # Test for invalid command-line arguments
    init_settings(['-i', 'input.py', '-o', 'output.py', '-t', '3.5'])
    assert main(['-i', 'input.py', '-o', 'output.py', '-t', '3.5']) == 0
    assert main(['-i', 'input.py', '-o', 'output.py']) != 0
    assert main(['-i', 'input.py', '-o', 'output.py', '-t', '3.5', '-d']) == 0

# Generated at 2022-06-23 22:30:20.338176
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:30.108940
# Unit test for function main
def test_main():
    from tempfile import TemporaryDirectory
    import os
    import subprocess
    from shutil import rmtree

    # create a temporary folder
    with TemporaryDirectory() as temp_folder:
        # create temp files
        file_name = 'temp_py_backwards.py'
        file_py = os.path.join(temp_folder, file_name)
        temp_file = open(file_py, 'w')

        # write content of the temp file
        temp_file.write('if True:\n    print(5)')
        temp_file.close()
        # create a tests directory within the temporary folder
        tests_folder = os.path.join(temp_folder, 'tests')
        os.mkdir(tests_folder)

        # return the current path and change to the temporary folder
        cur_path = os.getc

# Generated at 2022-06-23 22:30:32.148866
# Unit test for function main
def test_main():
    assert (main() == 0)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:42.651253
# Unit test for function main
def test_main():
    # Check correct input
    assert main(['--input', 'c:/file.py', '--output', 'c:/output/', '--target', '2.7']) == 0
    assert main(['-i', 'c:/file.py', '-o', 'c:/output/', '-t', '3.4']) == 0
    # Check invalid input
    assert main(['--input', 'c:/file.py', '--output', 'c:/output/', '--target', '3.3']) == 1
    assert main(['-i', 'c:/file.py', '-o', 'c:/output/', '-t', '2.6']) == 1
    assert main(['-i', 'c:/file.py', '-o', 'c:/output/', '-t', '3.8'])

# Generated at 2022-06-23 22:30:54.015049
# Unit test for function main
def test_main():
    assert 1 == main(['-i', 'tests/test_compilation/input.py'])
    assert 1 == main(['-i', 'tests/test_compilation/input.py', '-o', 'tests/test_compilation', '-t', 'python36'])
    assert 1 == main(['-i', 'tests/test_compilation/input.py', '-o', 'tests/test_compilation', '-t', 'python27'])
    assert 1 == main(['-i', 'tests/test_compilation/input.py', '-o', 'tests/test_compilation', '-t', 'python35'])
    assert 1 == main(['-i', 'tests/test_compilation/input.py', '-o', 'tests/test_compilation', '-t', 'python34'])

# Generated at 2022-06-23 22:30:58.985279
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/compiler/test.py', '-o', 'output',
                    '-t', 'py35', '-d']
    assert main() == 0
    return


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('Exit.')

# Generated at 2022-06-23 22:30:59.791739
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:00.446168
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:05.280036
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as excinfo:
        sys.argv = ['./py-backwards', '-i', 'main.py', '-o', 'compiled', '-t', '3.3']
        main()
    assert excinfo.value.code == 1


# Generated at 2022-06-23 22:31:05.977331
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:17.588933
# Unit test for function main
def test_main():
    sys.argv[1] = "tests/syntax_error.py"
    sys.argv[2] = "-i"
    sys.argv[3] = "tests/syntax_error.py"
    sys.argv[4] = "-o"
    sys.argv[5] = "tests/output.py"
    sys.argv[6] = "-t"
    sys.argv[7] = "python2.7"
    sys.argv[8] = "-r"
    sys.argv[9] = "tests"
    result = main()
    assert result == 1

    sys.argv[1] = "tests/transformation_error.py"
    sys.argv[2] = "-i"

# Generated at 2022-06-23 22:31:20.306954
# Unit test for function main
def test_main():
    target = '2.7'
    args = []
    args.append('-t')
    args.append(target)
    main(args)

# Generated at 2022-06-23 22:31:27.567541
# Unit test for function main
def test_main():
    target = '2.7'
    result = main(['--target', target])
    assert result == 0
    target = '3.0'
    result = main(['--target', target])
    assert result == 0
    target = '3.5'
    result = main(['--target', target])
    assert result == 0
    target = '3.6'
    result = main(['--target', target])
    assert result == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:38.781113
# Unit test for function main
def test_main():
    import io

    print(
        'Testing: py_backwards.main'
    )

    # Testing: default workers number
    print(
        '\tDefault workers number'
    )
    sys.argv = \
        [
            'py_backwards',
            '-i',
            'tests/res/fake.py',
            '-o',
            'test_output/test.py',
            '-t',
            '3.5'
        ]
    compile_files.workers_number_value = None
    assert main() == 0

    # Testing: output folder doesn\'t exist
    print(
        '\tOutput folder doesn\'t exist'
    )

# Generated at 2022-06-23 22:31:47.420558
# Unit test for function main
def test_main():
    class Args:
        pass
    args = Args()
    args.input = ['./test_input/test.py']
    args.output = './test_input/test1.py'
    args.target = '3.6'

    init_settings(args)
    try:
        result = compile_files(args.input[0], args.output,
                               const.TARGETS[args.target], None)
    except exceptions.InputDoesntExists:
        assert False

    output = open(args.output, 'r')
    output_text = ''.join(output.readlines())
    assert output_text == '# module decorator\nprint("test")\n'
    output.close()
    os.remove(args.output)

# Generated at 2022-06-23 22:31:54.528687
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('example/python3.6.py')
    sys.argv.append('-o')
    sys.argv.append('example/python3.6.py')
    sys.argv.append('-t')
    sys.argv.append('python2.7')
    sys.argv.append('-d')
    sys.argv.append('-r')
    sys.argv.append('example')
    assert main() == 0


# Run tests
# if __name__ == '__main__':
#     testMain()

# Generated at 2022-06-23 22:31:58.250402
# Unit test for function main
def test_main():
    args = ['-i', './tests/test_cases/',
            '-o', './tests/test_output/', 
            '-t', 'py35',
            '-r', './tests/']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:00.106754
# Unit test for function main
def test_main():
    assert(main() == 0)

# Generated at 2022-06-23 22:32:10.982055
# Unit test for function main
def test_main():
    # Correct usage
    # Inputs
    sys.argv = ['py-backwards', '-i', './test_input/test.py', '-o',
                './test_input/test.py', '-t', '3.5', '-d']
    # Expected
    assert main() == 0

    # Inputed file does not exist
    # Inputs
    sys.argv = ['py-backwards', '-i', 'nonexistentfile.py', '-o',
                './test_input/test.py', '-t', '3.5', '-d']
    # Expected
    assert main() == 1

    # Output file does not exist
    # Inputs

# Generated at 2022-06-23 22:32:21.365907
# Unit test for function main
def test_main():
    """ Unit test for function main """
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add

# Generated at 2022-06-23 22:32:30.537740
# Unit test for function main
def test_main():
    from . import test_helper
    from . import checker
    from .conf import Settings
    from .compiler import Transformations

    parser = ArgumentParser('test_py_backwards')
    parser.add_argument('input_folder', type=str,
                        help='input folder with tests')
    parser.add_argument('output_folder', type=str,
                        help='output folder with tests')
    parser.add_argument('target', type=str,
                        help='target python version')
    parser.add_argument('root', type=str, help='sources root')
    parser.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')
    args = parser.parse_args()

# Generated at 2022-06-23 22:32:41.000264
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:32:43.781955
# Unit test for function main
def test_main():
    assert main() == 0, 'main failed'


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:32:48.917249
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        assert True
    else:
        assert False

if __name__ == '__main__':
    sys.exit(main())

# the following code is to test the input and the output using the bash script
# t.sh to test all the input files and compare the outputs.

# Generated at 2022-06-23 22:33:00.277410
# Unit test for function main
def test_main():
    from .conf import TEST_DIR, EXAMPLES_DIR, set_settings
    from .utils import create_dir, remove_dir, find_dirs, remove_dirs
    from .examples import compile_examples
    from .run import _args

    create_dir(TEST_DIR)
    try:
        compile_examples()
        assert main() == 0
    finally:
        remove_dir(TEST_DIR)

    args = _args()
    create_dir(TEST_DIR)

# Generated at 2022-06-23 22:33:06.212386
# Unit test for function main
def test_main():
    # With normal mode argument
    sys.argv = ['-i', 'tests/', '-o', 'tests/', '-t', '2.7', '--root', 'tests/']
    result = main()
    assert result == 0

    # With normal mode argument
    sys.argv = ['-i', 'tests/', '-o', 'tests/', '-t', '2.7', '--root', 'tests/']
    result = main()
    a

# Generated at 2022-06-23 22:33:13.828518
# Unit test for function main
def test_main():
    # Create the input file
    string = "def func(num): number = 10 return number + num"
    input_ = './test_file.py'
    f = open(input_, 'w')
    f.write(string)
    f.close()

    # Create the output file
    output = './output_file.py'
    f = open(output, 'w')
    f.write('')
    f.close()

    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')

# Generated at 2022-06-23 22:33:23.199932
# Unit test for function main
def test_main():
    from os import remove
    from py_backwards.compiler import compile_files
    from py_backwards.conf import init_settings
    from exceptions import FileNotFoundError

    init_settings(['-i', 'tests/data/success', '-o', 'tests/data/results', '-t', '5'])
    result = compile_files('tests/data/success', 'tests/data/results', '5')
    assert result['total_files'] == 2
    assert result['total_lines'] == 3
    assert result['compiled_lines'] == 1
    assert result['compiled_lines_transformed'] == 1
    assert result['not_changed_lines'] == 1
    assert result['error_lines'] == 0
    assert result['compiled_files'] == 2
    assert result['failed_files'] == 0

   

# Generated at 2022-06-23 22:33:27.153434
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',
                '-i', 'test_data/test_dataset/test_one_file',
                '-o', 'test_data/test_output',
                '-t', '2.7',
                '-r', 'test_data/test_dataset']
    assert main() == 0

# Generated at 2022-06-23 22:33:34.245011
# Unit test for function main

# Generated at 2022-06-23 22:33:45.218351
# Unit test for function main
def test_main():
    from argparse import Namespace
    from .conf import SETTINGS
    import sys
    args = Namespace(input=['test_input/'], output='test_input/output',
                     target='2.7', root='test_input', debug=False)
    init_settings(args)

    assert SETTINGS.debug is False
    assert SETTINGS.input == ['test_input/']
    assert SETTINGS.output == 'test_input/output'
    assert SETTINGS.target == '2.7'
    assert SETTINGS.root == 'test_input'

    print(sys.stderr.getvalue())
    sys.stderr.truncate(0)
    sys.stderr.seek(0)

# Generated at 2022-06-23 22:33:49.533403
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'test_files/test_files_2.py', 'test_files/test_files_1.py',
        '-o', 'out',
        '-t', '3.4',
        '-r', 'test_files/'
    ]

    main()

# Generated at 2022-06-23 22:33:50.702463
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:51.301141
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:55.779234
# Unit test for function main
def test_main():
    cmd = ['py-backwards', '-i', 'examples/test.py', '-o', 'example_out.py', '-t', 'python2.7']
    assert main(cmd) == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:05.043556
# Unit test for function main
def test_main():
    import pytest
    from py_backwards.main import main
    # Combinations of arguments that should run without errors
    valid_args = [
        ('-i', 'tests/resources/valid.py', '-o', 'tests/results/valid.py',
         '-t', 'py36', '-r', 'tests/resources'),
        ('-i', 'tests/resources/valid.py', '-o', 'tests/results/valid.py',
         '-t', 'py36', '-r', 'tests/resources'),
        ('-i', 'tests/resources/valid.py', '-o', 'tests/results/valid.py',
         '-t', 'py36', '-r', 'tests/resources/valid.py')
    ]
    # Combinations of arguments that should run with errors
    invalid_args

# Generated at 2022-06-23 22:34:05.625915
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:14.156969
# Unit test for function main

# Generated at 2022-06-23 22:34:15.584414
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:17.987861
# Unit test for function main
def test_main():
    assert main(['sources/test_frontend.py']) == 0
    assert main(['sources/test_frontend.py']) == 0

# Generated at 2022-06-23 22:34:18.658760
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:34:25.706004
# Unit test for function main
def test_main():
    # Raises exception
    sys.argv = ['py-backwards', '-i', 'in', '-o', 'out']
    assert str(exceptions.CompilationError('')) in str(main())

    # Everything ok
    sys.argv = ['py-backwards', '-i', 'in', '-o', 'out', '-t', 'py26', '-r', 'root']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:26.436333
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:27.865535
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:36.600535
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:34:37.274462
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:34:37.906550
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:39.418914
# Unit test for function main
def test_main():
    main()
    main()

# Generated at 2022-06-23 22:34:46.544213
# Unit test for function main

# Generated at 2022-06-23 22:34:50.658818
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i', 'someprogram.py', '-o', 'someprogram', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-23 22:34:57.495072
# Unit test for function main

# Generated at 2022-06-23 22:35:01.055535
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        try:
            assert e.code == 0
            assert True
        except AssertionError:
            assert e.code == 1
            assert True
        except AttributeError:
            assert True

# Generated at 2022-06-23 22:35:11.078649
# Unit test for function main
def test_main():
    # test with file
    sys.argv = (
        'py_backwards -i example/input/timeit.py '
        '-o example/output/timeit.py '
        '-t python3.4 -r example/input/').split(' ')
    assert main() == 0

    # test with non existint file
    sys.argv = (
        'py_backwards -i /home/zijistark/example/input/ '
        '-o example/output/timeit.py '
        '-t python3.4 -r example/input/').split(' ')
    assert main() == 1

    # test with folder

# Generated at 2022-06-23 22:35:21.084697
# Unit test for function main
def test_main():
    class Case:
        def __init__(self, test, args):
            self.test = test
            self.args = args


# Generated at 2022-06-23 22:35:27.986891
# Unit test for function main
def test_main():
  # function main()
  stdout = sys.stdout
  sys.stdout = io.StringIO()

  current = os.getcwd()
  os.chdir('app')
  main()
  os.chdir(current)

  sys.stdout = stdout

# Generated at 2022-06-23 22:35:32.355763
# Unit test for function main
def test_main():
    input = 'sample.py'
    output = 'out'
    root = '.'
    target = 'py27'
    sys.argv = [ '', '-i', input, '-o', output, '-d', '', '-r', root, '-t', target]
    assert main() == 0
    os.remove(output)

# Generated at 2022-06-23 22:35:42.623992
# Unit test for function main
def test_main():
    from . import compiler
    from . import conf

    argv = ['-i', 'test', '-o', 'test_out', '-t', '2.7', '--debug', '-r',
            'test_root']
    with patch('sys.argv', argv):
        with patch('argparse.ArgumentParser.parse_args',
                   return_value=argparse.Namespace(**{
                       'input': 'test',
                       'output': 'test_out',
                       'target': '2.7',
                       'root': 'test_root',
                       'debug': True})):
            try:
                with patch.object(compiler.Compiler, 'compile_file',
                                   side_effect=exceptions.InputDoesntExists):
                    main()
            except SystemExit:
                pass
           

# Generated at 2022-06-23 22:35:48.734317
# Unit test for function main
def test_main():
    argv = ['a.py', 'b.py', '-o', 'out/', '-t', 'py26',
            '--root', 'src/']
    sys.argv = argv
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:49.347876
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:59.748594
# Unit test for function main
def test_main():
    import argparse
    argparse.ArgumentParser = _ArgumentParser
    settings.__init__()
    settings.DEBUG = True
    import os
    from . import conf
    from . import exceptions
    from . import compiler
    from . import messages
    from . import const
    from . import settings
    compiler.compile_files = compile_files
    settings.init_settings = init_settings
    conf.init_settings = init_settings
    os.path.exists = path_exists
    os.path.isdir = path_isdir
    os.path.isfile = path_isfile
    os.path.join = path_join
    os.path.abspath = path_abspath
    os.mkdir = mkdir
    os.makedirs = makedirs
    open = __builtin__

# Generated at 2022-06-23 22:36:03.206210
# Unit test for function main
def test_main():
    # Arrange
    sys.argv = ['py-backwards', 'tests/test_files/test_files.py', '-o', 'xxx', '-t', '3.4', '-r', 'tests/test_files']

    # Act
    main()

    # Assert
    assert True

# Generated at 2022-06-23 22:36:09.141622
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', '/home/al/Documents/repos/py-backwards/tests',
                '-o', '/home/al/Documents/repos/py-backwards/tests/output',
                '-r', '/home/al/Documents/repos/py-backwards/tests',
                '-t', 'python35']
    assert main() == 0

# Generated at 2022-06-23 22:36:17.482831
# Unit test for function main
def test_main():
    with open('test/compiled_2.py') as compiled_file:
        expected_result = compiled_file.read()

    sys.argv = ['py-backwards', '-i', 'test/test_2.py', '-o',
                'test/tmp.py', '-t', 'python2.7']
    assert main() == 0

    with open('test/tmp.py') as compiled_file:
        assert compiled_file.read() == expected_result


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:22.176217
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('./test.py')
    sys.argv.append('-o')
    sys.argv.append('./test2.py')
    sys.argv.append('-t')
    sys.argv.append('python27')
    exit(main())

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:26.662552
# Unit test for function main
def test_main():
    sys.argv = ['./py-backwards', '-i', 'path/to/input', '-o', 'path/to/output', '-t', 'python35', '-r', 'path/to/root', '-d']
    assert main() == 0