

# Generated at 2022-06-23 22:26:32.969375
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:26:34.454558
# Unit test for function main
def test_main():
    init_settings(ArgumentParser().parse_args(''))
    sys.argv = sys.argv[:1]
    main()

# Generated at 2022-06-23 22:26:41.451010
# Unit test for function main
def test_main():
    command_line_args = {
        "input": ["./tests/before/basic_file.py"],
        "output": "./tests/after",
        "target": "python2.7",
        "root": "tests/before",
        "debug": True
    }
    sys.argv = ["./py-backwards", "--input", command_line_args["input"][0],
                "--output", command_line_args["output"], "--target",
                command_line_args["target"], "--root", command_line_args["root"],
                "--debug", command_line_args["debug"]]
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:26:42.048191
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:26:43.618907
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:26:48.929441
# Unit test for function main
def test_main():
    """Test main function."""
    #TODO: Work on this test.
    #Mock input arg
    sys.argv = [sys.argv[0], '-i', 'test/', '-o', 'test/', '-t', '3.6', '-r', 'test/']
    assert main() == 0

# Generated at 2022-06-23 22:26:59.751086
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from py_backwards.main import main
    from py_backwards.conf import init_settings
    from py_backwards import const
    import sys
    init_settings(args)
    with patch.object(sys, 'exit') as mock_exit:
        with patch.object(sys, 'argv', ['py-backwards', '-i', 'test.py', '-o', 'result.py', '-t', '2.7', '-r', 'root']):
            main()
    assert(mock_exit.call_count == 1)
    assert(mock_exit.call_args[0][0] == 0)

# Generated at 2022-06-23 22:27:09.460370
# Unit test for function main
def test_main():
    def run(args, exit_code_expected):
        import io
        import sys

        # monkey patch sys.stdout
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        main_return = main(args)
        assert main_return == exit_code_expected, \
            f'Expected code {exit_code_expected}, got {main_return}'
        print(sys.stdout.getvalue())
        sys.stdout.close()
        sys.stdout = old_stdout

    run(['-h'], 0)
    run(['-i', 'this-does-not-exist'], 1)

# Generated at 2022-06-23 22:27:13.178370
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'abc.py', '-o', 'abc.py', '-t', '3.5', '-d']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:17.366798
# Unit test for function main
def test_main():
    # Arrange
    sys.argv = ['py-backwards','--input', 'file', 
    '--output', 'file', '--target', '3.4', '--debug', 'true']
    # Act
    x = main()
    #Assert
    assert x == 0

# Generated at 2022-06-23 22:27:19.731517
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',-o,'f.py',-t,'3.5',-i,'file.py']
    assert main() == 1

# Generated at 2022-06-23 22:27:24.630228
# Unit test for function main
def test_main():
    from argparse import Namespace
    from unittest.mock import patch
    from . import compiler

    args = Namespace(input='a.py', output='b.py', target='2.7', debug=False)
    with patch.object(args, 'input', new_callable=lambda: ['a.py']):
        with patch.object(args, 'output', new_callable=lambda: 'b.py'):
            with patch.object(compiler, 'compile_files'):
                main()

# Generated at 2022-06-23 22:27:30.365714
# Unit test for function main
def test_main():
    assert 2 == main(['-i', 'tests/compiler/test.py', '-o'])
    assert 0 == main(['-i', 'tests/compiler/test.py', '-o', 'tests/compiler/test.py', '-d', '-t', '2.7'])

if __name__ == '__main__':
	sys.exit(main(sys.argv[1:]))

# Generated at 2022-06-23 22:27:31.784670
# Unit test for function main
def test_main():
    assert main() == 0
    assert main() == None
    assert main() == -1

# Generated at 2022-06-23 22:27:40.658457
# Unit test for function main
def test_main():
    # Testing CLI functionality

    # Testing no args case
    try:
        main(None)
        assert False
    except SystemExit:
        assert True

    # Testing wrong input case
    try:
        main(['-i', 'a', '-o', 'b'])
        assert False
    except exceptions.InputDoesntExists:
        assert True

    # Testing wrong output case
    try:
        main(['-i', 'tests/res/syntax/simple.py', '-o', 'error/'])
        assert False
    except exceptions.InvalidInputOutput:
        assert True

# Generated at 2022-06-23 22:27:41.227405
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:27:45.051667
# Unit test for function main
def test_main():
    assert main(["../examples/simple_example.py", "../examples/simple_example.py"],
                "../examples/simple_example.py",
                "2.7",
                "../examples/simple_example.py") == 0

# Generated at 2022-06-23 22:27:46.459165
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:57.709829
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_py_backwards/test_input.py', '-o', 'output.py', '-t', '3.4', '-d']
    assert(main() == 0)
    sys.argv = ['py-backwards', '-i', 'test_py_backwards/test_input.py', '-o', 'output.py', '-t', '3.4']
    assert(main() == 0)
    sys.argv = ['py-backwards', '-i', 'test_input.py', '-o', 'output.py', '-t', '3.4', '-d']
    assert(main() == 1)

# Generated at 2022-06-23 22:28:01.038108
# Unit test for function main
def test_main():
    test_args1 = ['-i', 'single.py', '-o', 'output.py', '-t', 'py35', '-r', '.',]
    with patch.object(sys, 'argv', test_args1):
        assert 0 == main()
    test_args2 = ['-i', 'compiler', '-o', 'output/', '-t', 'py35', '-r', '.',]
    with patch.object(sys, 'argv', test_args2):
        assert 0 == main()
    test_args3 = ['-i', 'compilers', '-o', 'output/', '-t', 'py35', '-r', '.',]
    with patch.object(sys, 'argv', test_args3):
        assert 1 == main()


# Generated at 2022-06-23 22:28:12.012419
# Unit test for function main
def test_main():
    from .compiler import MockCompiler
    from .conf import get_settings, push_settings, pop_settings
    from .sources import push_context, pop_context
    from .exceptions import InputDoesntExists
    from contextlib import contextmanager
    import os
    import shutil
    import io
    import tempfile
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-23 22:28:21.388662
# Unit test for function main
def test_main():
    from types import ModuleType
    from .compiler import compile_files

    sys.modules['__main__'] = ModuleType('__main__')
    sys.modules['__main__'].__package__ = 'py_backwards'
    old_stdout = sys.stdout
    sys.stdout = TextOutput()

    compile_files = Mock(return_value=0)
    main()
    assert compile_files.called
    main(['test.py'], 'test.py', 'python36')
    assert compile_files.called
    main(['test.py'], 'test.py', 'python36', 'test')
    assert compile_files.called
    main(['test.py'], 'test.py', 'python36', 'test', '-d')
    assert compile_files.called


# Generated at 2022-06-23 22:28:32.794904
# Unit test for function main
def test_main():
    parser = ArgumentParser('py-backwards',
                            description='Python to python compiler that allows you to use some '
                                        'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:28:33.685789
# Unit test for function main
def test_main():
    assert main() == 1, 'Tests for main should pass'

# Generated at 2022-06-23 22:28:34.364525
# Unit test for function main
def test_main():
    return 0

# Generated at 2022-06-23 22:28:34.953923
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-23 22:28:36.498887
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:43.500669
# Unit test for function main
def test_main():
    parser = ArgumentParser()
    parser.add_argument('-o', '--output', type=str)
    args = parser.parse_args(args=['-o', 'ok'])

    file = 'test_file'
    with open(file, 'w') as f:
        f.write('a')

    main(['-i', file, '-o', 'test_file1', '-t', '2.7', '-r', '.'])


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:48.213588
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/items.py', '-o',
                'tests/items_test.py', '-t', '3.5', '-r', '/']
    assert main() == 0
    print('test_main - done!')

if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-23 22:28:52.121716
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', './tests/data/input/',
                '-o', './tests/data/output/',
                '-t', 'py2',
                '-d']
    assert main() == 0


# Generated at 2022-06-23 22:28:57.468017
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'input_folder', '-o', 'output_folder', '-t', '2.7', '-r', ',']
    main()
    sys.argv = ['py-backwards.py', '-i', 'input_folder', '-o', 'output_folder', '-t', '2.7', '-r', ',', '-d']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:03.233755
# Unit test for function main
def test_main():
    from io import StringIO
    from contextlib import (redirect_stdout, redirect_stderr)

    file = StringIO()
    with redirect_stdout(file), redirect_stderr(file):
        main()
    output = file.getvalue()
    print(output, end='')
    if output:
        assert 'not' in output
        assert '-h' in output
        assert '--help' in output
        return

    assert False

# Generated at 2022-06-23 22:29:03.734292
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:04.537363
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:07.845353
# Unit test for function main
def test_main():
    out = StringIO()
    with redirect_stdout(out):
        main()
    assert 'usage: py-backwards' in out.getvalue()
    assert 'Create an output file(or folder)' in out.getvalue()

# Generated at 2022-06-23 22:29:08.442897
# Unit test for function main
def test_main():
   assert main() == 0

# Generated at 2022-06-23 22:29:09.351838
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:14.963742
# Unit test for function main
def test_main():
    test_input_dir = 'test_dir_in'
    test_output_dir = 'test_dir_out'
    target = 'py36'
    root_dir = 'root'
    test_args = ['-i', test_input_dir, '-o', test_output_dir, '-t', target, '-r', root_dir]
    sys.argv[1:] = test_args
    main()
    assert 1

# Generated at 2022-06-23 22:29:26.583630
# Unit test for function main
def test_main():
    def _write_file(path, data):
        with open(path, 'wb') as file:
            file.write(data)

    sample_data = b'print("hello")'
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        # Make temp folder
        _write_file(os.path.join(temp_dir, 'main.py'), sample_data)

        # Prepare argument parser and run
        args = parser.parse_args(['-i', 'main.py', '-o', './out', '-t', '2.7'])
        result = main(temp_dir, args)
        assert result == 0

        # Prepare argument parser and run

# Generated at 2022-06-23 22:29:29.349408
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as exit_info:
        main()
    assert exit_info.value.code == 2

# Generated at 2022-06-23 22:29:33.376878
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', ['py-backwards', '-i', 'Input', '-o', 'Output', '-t', '3.5']):
        test_main = main()
        assert test_main == 0

#Test for Bad Input

# Generated at 2022-06-23 22:29:33.829362
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:34.357404
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:38.438807
# Unit test for function main
def test_main():
    argvbackup = sys.argv.copy()
    sys.argv = ['py-backwards', '-i', '../../tests/test_data/simple_tests/simple_test1.py', '-o', '../../tests/test_data', '-t', '35', '-r', '../../tests']
    main()
    sys.argv = argvbackup

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:48.890173
# Unit test for function main
def test_main():
    # compilation errors
    result1 = main()
    assert(result1 == 1)
    result2 = main(['-i', 'tests/data/fail.py', '-o', 'test', '-t', '34'])
    assert(result2 == 1)
    result3 = main(['-i', 'tests/data/', '-o', 'test', '-t', '36', '-r', ''])
    assert(result3 == 1)
    # other errors
    result4 = main(['-i', '', '-o', 'test', '-t', '36', '-r', ''])
    assert(result4 == 1)
    result5 = main(['-i', 'tests/data/', '-o', 'test/data/', '-t', '34', '-r', ''])
   

# Generated at 2022-06-23 22:29:50.223107
# Unit test for function main
def test_main():
    assert main() == 0
    assert main() == 1
    assert main() == 1

# Generated at 2022-06-23 22:29:59.675430
# Unit test for function main
def test_main():
    # Test 1:
    #   Input: ./test/test_data/test.py -o ./test/test_data/out.py -t 2.7
    #   Output: 0
    #
    argv = sys.argv[:]
    sys.argv[1:] = ['./test/test_data/test.py', '-o',
                    './test/test_data/out.py', '-t', '2.7']
    assert main() == 0
    sys.argv = argv[:]

    # Test 2:
    #   Input: ./test/test_data/test.py -o ./test/test_data/out.py -t 2.7 -d
    #   Output: 0
    #
    argv = sys.argv[:]

# Generated at 2022-06-23 22:30:00.453366
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:06.035377
# Unit test for function main
def test_main():
    f = open(os.path.join(const.BASE_DIR, 'test_main.tmp'), 'w')
    f.close()
    sys.argv = ['', '-i', 'py_backwards/tests/test_main.py', '-o', 'test_main.tmp', '-t', 'py34']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:11.541234
# Unit test for function main
def test_main():
    with mock.patch('argparse.ArgumentParser') as mock_argparse:
        main()

    mock_argparse.assert_called_with(description='Python to python compiler that allows you to use some '
                                                  'Python 3.6 features in older versions.',
                                     prog='py-backwards')


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:19.608082
# Unit test for function main
def test_main():
    """ Function that tests main function from module main
    """
    # init colorama
    init()

    # test incorrect input
    assert main(['-h']) == 0
    assert main(['-i', 'input', '-o', 'output', '-t', 'python36']) == 1
    assert main(['-i', 'input', '-o', 'output', '-t', 'python36', '-r', 'root']) == 1
    assert main(['-i', 'input', '-r', 'root']) == 1

    # test help
    assert main(['-h']) == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:30:29.813008
# Unit test for function main
def test_main():
    import os
    import copy
    import py_backwards
    import py_backwards.__main__
    import py_backwards.compiler
    import py_backwards.conf
    import py_backwards.exceptions
    import py_backwards.messages

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.dirname(test_dir)

    settings = {'input': [os.path.join(test_dir, 'test_data/test_suite')],
                'output': os.path.join(test_dir, 'test_data/output_test'),
                'target': '3.5',
                'debug': False,
                'root': None}
    settings_2 = copy.deepcopy(settings)
    settings

# Generated at 2022-06-23 22:30:39.489579
# Unit test for function main
def test_main():
    # Test for input does not exist
    sys.argv = ['py-backwards', '-i', 'tests/src/main.py', '-o', 'output', '-t', '35']
    assert main() == 1

    # Test for zero files compiled
    sys.argv = ['py-backwards', '-i', 'tests/src/no_files', '-o', 'output', '-t', '35']
    assert main() == 0

    # Test for ok
    sys.argv = ['py-backwards', '-i', 'tests/src/main.py', '-o', 'output', '-t', '35']
    assert main() == 0

# Generated at 2022-06-23 22:30:41.975862
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'input.py', '-o', 'output.py',
                    '-t', 'py27', '-r', 'root']
    assert main() == 0

# Generated at 2022-06-23 22:30:45.539589
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'dest', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-23 22:30:56.341241
# Unit test for function main
def test_main():
    sys.argv = ['prog', '-i', 'tests/syntax_errors.py', '-o', '/dev/null', '-t', '3.5', '-r', 'tests']
    sys.stdout = StringIO()
    sys.stderr = StringIO()
    main()
    assert sys.stdout.getvalue() == '''tests/syntax_errors.py compiled to /dev/null\n'''
    assert sys.stderr.getvalue().startswith("tests/syntax_errors.py:6:1: syntax error: unexpected EOF while parsing\n")
    sys.argv = ['prog', '-i', 'tests/syntax_errors_existst.py', '-o', '/dev/null', '-t', '3.5', '-r', 'tests']

# Generated at 2022-06-23 22:30:58.308812
# Unit test for function main
def test_main():
    reload(exceptions)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:10.008586
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/examples/test.py', '-o',
                'tests/examples/test_out.py', '-t', 'python3.4', '-r',
                'examples']
    sys.stdout = io.StringIO()
    main()
    assert 'Ok' in sys.stdout.getvalue()
    sys.stdout = sys.__stdout__
    sys.argv = [sys.argv[0]]

    sys.argv = [sys.argv[0], '-i', 'tests/examples/test.py', '-o',
                'tests/examples/test_out.py', '-t', 'python3.4', '-r',
                'examples', '-d']
    sys

# Generated at 2022-06-23 22:31:11.891515
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:15.765663
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'output.py',
                '-t', '2.7', '-r', '.']

    main()
    assert 1

# Generated at 2022-06-23 22:31:16.917916
# Unit test for function main
def test_main():
    res = main()
    assert res == 0
    return res

# Generated at 2022-06-23 22:31:22.069500
# Unit test for function main
def test_main():
    sys.argv = ['','-i', 'C:\\Users\\Elena\\Documents\\Informatik\\GitHub\\py-backwards\\py_backwards\\tests\\test_inputs\\good\\good_import.py',
    '-o', 'C:\\Users\\Elena\\Documents\\Informatik\\GitHub\\py-backwards\\py_backwards\\tests\\test_outputs\\good_output',
    '-t', 'python27']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:33.041009
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'output', '-t', 'python36']
    assert main() == 0
    sys.argv = ['py-backwards', '-d', '-i', 'test', '-o', 'output', '-t', 'python36']
    assert main() == 0
    sys.argv = ['py-backwards', '-d', '-i', 'test', '-o', 'output', '-t', 'python36', '-r', 'test']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'test', '-t', 'python36']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:33.565336
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:36.550119
# Unit test for function main
def test_main():
    assert main() == 0

# If this file is the main one, run the test
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:37.106808
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:40.629581
# Unit test for function main
def test_main():
    # Does not work. Can't test sys.argv
    #sys.argv = ['py-backwards', '-i', 'foo.py', '-o', 'bar', '-t', '2']
    #main()
    assert main() == 0

# Generated at 2022-06-23 22:31:42.905594
# Unit test for function main
def test_main():
    # This test is for testing the function of main
    try:
        if __name__ == "__main__":
            main()
    except Exception:
        print("Exception")

# Generated at 2022-06-23 22:31:48.748225
# Unit test for function main
def test_main():
    class MockArguments():
        def __init__(self):
            self.input = ['./tests/resources/this_is_file.py']
            self.output = './temp/'
            self.root = None
            self.target = '3.3'
    args = MockArguments()
    init_settings(args)

    assert main() == 0

# Generated at 2022-06-23 22:31:49.393383
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:57.338841
# Unit test for function main
def test_main():
    """
    Test for main function
    :return: void
    """
    class Args:
        input = ['src']
        output = 'bin'
        target = '3'
        root = None
        debug = False

    class mock_compiler:
        @classmethod
        def compile_files(cls, input_, output, target, root):
            if input_ != 'src':
                raise Exception()
            if output != 'bin':
                raise Exception()
            if target != const.TARGETS['3']:
                raise Exception()
            if root is not None:
                raise Exception()

    sys.modules['backwards.compiler'] = mock_compiler()

    assert main() == 0

    class Args:
        input = ['src']
        output = 'bin'
        target = '2'
       

# Generated at 2022-06-23 22:32:02.477752
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', './pybackwards/test.py',
                './pybackwards/test_out.py', '3.6']
    test_main.return_val = main()
    assert test_main.return_val == 0

# Run test only if it's not first run of program (otherwise it will call itself)
if __name__ != '__main__':
    test_main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:04.467169
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except Exception as e:
        raise e


# Generated at 2022-06-23 22:32:05.100214
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:32:10.116433
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'test/input/test.py',
                '-o', 'test/output/test.py',
                '-t', '2.7',
                '-r', 'test/input',
                '-d']
    assert main() == 0, 'function main returned incorrect value'

# Generated at 2022-06-23 22:32:10.866723
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:21.330531
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:32:27.485267
# Unit test for function main
def test_main():
    import os
    import subprocess
    import tempfile

    test_dir = os.getcwd()
    src = os.path.join(test_dir, 'test_files')
    dst = os.path.join(tempfile.mkdtemp(), 'test_compilation')
    os.mkdir(dst)

    sys.argv = ['python3', '-m', 'pcompiler', '-i', src, '-o', dst,
                '-t', '2.7', '-r', test_dir]
    main()

    return_code = subprocess.call(['python2', dst + '/test_file.py'])
    assert(return_code == 0)


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:32:38.972144
# Unit test for function main
def test_main():
    with patch('sys.argv', ['', '-i', 'py_backwards/tests/test_data', '-o', 'py_backwards/compiled/', '-t', '3.6', '-d', '-r', 'py_backwards/tests/']):
        assert main() == 0
        assert open('py_backwards/compiled/compiled', 'r').read() == open('py_backwards/tests/expected', 'r').read()
    with patch('sys.argv', ['', '-i', 'py_backwards/tests/test_data', '-o', 'py_backwards/compiled/', '-t', '3.6', '-d']):
        assert main() == 0

# Generated at 2022-06-23 22:32:43.135898
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output',
                '-t', 'py35', '-r', 'input/root']
    main()

# Generated at 2022-06-23 22:32:51.378686
# Unit test for function main
def test_main():
    sys.argv[1:] = ['--input', 'tests/resources/src',
                    '--output', 'tests/resources/dst',
                    '--target', '3.6']

    assert main() == 0, "Compilation failed"

    # remove the created folder
    shutil.rmtree('tests/resources/dst')

    sys.argv[1:] = ['--input', 'tests/resources/src',
                    '--output', 'tests/resources/dst',
                    '--target', '3.5']
    assert main() == 1, "Compilation succeeded"


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:00.808583
# Unit test for function main
def test_main():
    '''
    tests function `main` with an input script that imports `abc`
    '''
    # Create a dummy file
    script_name = 'dummy_script.py'
    with open(script_name, 'w') as f:
        f.write('import abc\n')

    # Create argument list
    sys.argv = [
        '',
        '-i', script_name,
        '-o', 'out.py',
        '-t', '2.7',
        '-d',
    ]

    main()
    os.remove(script_name)
    os.remove('out.py')

# Generated at 2022-06-23 22:33:01.827615
# Unit test for function main
def test_main():
    assert main([]) == 0

# Generated at 2022-06-23 22:33:10.763951
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1] + ['-i', os.path.join('test', 'test_input'),
                               '-o', os.path.join('test', 'test_output'),
                               '-t', '2.7',
                               '-r', 'test']
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    assert main() == 0
    assert sys.stdout.getvalue() == 'Файлов преобразовано: 4\n'
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__


# Generated at 2022-06-23 22:33:11.656371
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:16.371805
# Unit test for function main
def test_main():
    args = ['--input', 'test_files/examples', '--output', 'test_files/output', '--target', '2.7']
    try:
        main()
        assert False
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-23 22:33:17.898436
# Unit test for function main
def test_main():
    args = ['--input', 'test/test.py', '--output', 'test/test_out.py', '--target', '3.6']
    assert main(args) == 0

# Generated at 2022-06-23 22:33:23.796360
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append('input')
    sys.argv.append('-o')
    sys.argv.append('output')
    sys.argv.append('-t')
    sys.argv.append('3.4')
    sys.argv.append('-r')
    sys.argv.append('path')

    with pytest.raises(SystemExit) as e:
        main()

    assert e.value.code == 1

# Generated at 2022-06-23 22:33:24.234067
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:33.874730
# Unit test for function main
def test_main():
    try:
        main(['py-backwards', '-i', 'tests/example.py',
              '-o', 'tests/output.py', '-t', '3',
              '-r', 'tests'])
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1
    except exceptions.TransformationError as e:
        print(messages.transformation_error(e), file=sys.stderr)
        return 1
    except exceptions.InputDoesntExists:
        print(messages.input_doesnt_exists(args.input), file=sys.stderr)
        return 1

# Generated at 2022-06-23 22:33:34.466202
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:38.197974
# Unit test for function main
def test_main():
    sys.argv.extend(['-i', 'test', '-o', 'build', '-t', '3.5', '-r', '.'])
    assert main() == 0

# Generated at 2022-06-23 22:33:38.818170
# Unit test for function main
def test_main():
    assert main() is 0

# Generated at 2022-06-23 22:33:41.055039
# Unit test for function main
def test_main():
    # Assert that main function call results in 0 (success)
    assert main() == 0

# Generated at 2022-06-23 22:33:43.085424
# Unit test for function main
def test_main():
    """
    If no command line argument is passed to py-backwards it must return 1 due
    to parser.parse_args raising SystemExit.
    """
    assert main() == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:50.837103
# Unit test for function main
def test_main():
    # Args:
    #   verbose: bool, print debug messages
    #   input: str, input file or folder to compile
    #   output: str, output file or folder to compile
    #   target: str, target version of python
    #   root: str, root path
    # Returns:
    #   exit_code: int, exit code, 0 if all ok, 1 if some errors
    # Test 1:
    verbose = False
    input = 'input'
    output = 'output'
    target = '3.6'
    root = ''
    exit_code = 1
    # Test 2:
    verbose = True
    input = 'input'
    output = 'output'
    target = '3.6'
    root = ''
    exit_code = 0
    # Test 3:

# Generated at 2022-06-23 22:33:52.394130
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:53.977558
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:03.387725
# Unit test for function main
def test_main():
    parser = ArgumentParser('py-backwards')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')
    args = parser.parse_args()
   

# Generated at 2022-06-23 22:34:03.952773
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:34:08.354989
# Unit test for function main
def test_main():
    sys_argv = ['py-backwards','-i','tests/transformations/testfiles','-o','testfiles_out','-t','3']
    sys.argv = sys_argv
    main()
    assert 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:10.032009
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:21.009716
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import patch
    from .compiler import compile_files
    from . import exceptions
    import py_backwards as pb
    import os

    # Check that compilation error is handled properly
    class MyExceptionForCompilation(exceptions.CompilationError):
        pass
        
    with patch('py_backwards.compiler.compile_files',
               side_effect=MyExceptionForCompilation()):
        with patch('sys.stderr', StringIO()):
            assert main() == 1

    # Check that transformation error is handled properly
    class MyExceptionForTransformation(exceptions.TransformationError):
        pass


# Generated at 2022-06-23 22:34:22.948523
# Unit test for function main
def test_main():
    exit_code = main(['-h'])
    assert exit_code == 0

# Generated at 2022-06-23 22:34:23.595666
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:34:25.269841
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:34:27.468771
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:34:28.064379
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:28.653184
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:29.283565
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:32.601031
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/input', '-o', 'tests/output',
                '-t', '3.7', '-r', 'tests']
    assert main() == 0

# Generated at 2022-06-23 22:34:39.837173
# Unit test for function main
def test_main():
    test_args = sys.argv[:]
    sys.argv.append('-i')
    sys.argv.append('./tests')
    sys.argv.append('-o')
    sys.argv.append('./tests')
    sys.argv.append('-t')
    sys.argv.append('py36')
    result = main()
    assert result == 0
    sys.argv = test_args[:]


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:42.921519
# Unit test for function main
def test_main():
    assert main(["-i", "input_file", "-o", "input_file", "-t", "3.6"]) == 0
    

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:45.121009
# Unit test for function main
def test_main():
    """
    A function to test function main.

    :return: None
    """
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:46.590666
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:54.637530
# Unit test for function main
def test_main():
    if sys.version_info.major != 2 and sys.version_info.minor != 7:
        # Need to skip as Unit Test is running on python version other than 2.7
        return
    sys.argv = [
        'py-backwards',
        '-t', '2.7',
        '-i', 'tests/fixtures/test_arg.py',
        '-o', 'tests/tmp/output.py',
    ]
    result = main()
    assert(result == 0)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:05.225985
# Unit test for function main
def test_main():
    from unittest import mock

    test_input = ['test_input']
    test_output = 'test_output'
    test_target = const.TARGETS[const.PYTHON_36]

    test_root = 'test_root'
    test_args = mock.Mock()

    def args_side_effect(arg):
        if arg == 'input':
            return test_input
        elif arg == 'output':
            return test_output
        elif arg == 'target':
            return test_target

        assert False

    test_args.__getitem__.side_effect = args_side_effect
    test_args.root = test_root

    with mock.patch('pyb.compiler.compile_files') as compile_files_mock:
        compile_files_mock.return_

# Generated at 2022-06-23 22:35:08.532974
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', './tests/examples/functiontoset.py',
                   '-o', './tests/examples/output',
                   '-t', '2.7',
                   '-r', './tests/examples']
    assert main()==0

# Generated at 2022-06-23 22:35:14.909741
# Unit test for function main
def test_main():
    from . import cli

    # Case: No arguments
    args = cli.main(['-o', 'output_path', '-t', '2.7'])
    assert args.input == sys.argv[1:]
    assert args.output == ['output_path']
    assert args.targets == ['2.7']

    # Case: Too many arguments
    args = cli.main(['input_path', '-o', 'output_path', '-t', '2.7'])
    assert args.input == ['input_path']
    assert args.output == ['output_path']
    assert args.targets == ['2.7']

    # Case: Few arguments

# Generated at 2022-06-23 22:35:19.906235
# Unit test for function main
def test_main():
    out_ = StringIO()
    sys.stdout = out_
    main()
    sys.stdout = sys.__stdout__
    assert out_.getvalue() == ''

# Generated at 2022-06-23 22:35:20.452589
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:35:21.545824
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    assert main() == 0

# Generated at 2022-06-23 22:35:24.194548
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:30.063219
# Unit test for function main
def test_main():
    # Create fake input json file
    with open('input.json', 'w') as f:
        f.write('{ "key" : "value" }')

    # Run main function with fake arguments
    args = ('-i input.json -o output.json -t 2.7 -r test_folder').split()
    assert main(args) == 0

    # Remove fake input json file
    os.remove('input.json')

# Generated at 2022-06-23 22:35:40.582231
# Unit test for function main
def test_main():
    # Invalid inputs
    # Invalid target
    sys.argv = ['py_backwards.py', '-i', 'file.py', '-o', 'file.py',
                '-t', 'dummy', '-r', '']
    assert main() == 1
    # Too many arguments
    sys.argv = ['py_backwards.py', '-i', 'file.py', '-i', 'file.py',
                '-o', 'file.py', '-t', 'py36', '-r', '']
    assert main() == 1
    # Too little arguments
    sys.argv = ['py_backwards.py', '-i', 'file.py', '-t', 'py36',
                '-r', '']
    assert main() == 1
    # No arguments
    sys.arg

# Generated at 2022-06-23 22:35:46.057452
# Unit test for function main
def test_main():
    from unittest import mock

    mock_parser = mock. Mock()
    mock_parser.return_value = \
        mock.Mock(input=['my/folder', 'my/other/folder/with/file'],
                  output='my/output/folder',
                  target='Python35',
                  root='my/folder')
    with mock.patch('argparse.ArgumentParser', mock_parser):
        assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:52.801308
# Unit test for function main
def test_main():
    with patch('sys.argv', ['py-backwards', '-i', 'test',
                            '-o', 'test_out', '-t', '3.4']):
        with patch('sys.stdout', new=StringIO()) as fake_out:
            assert main() == 0
            assert "Compilation complete" in fake_out.getvalue()

    with patch('sys.argv', ['py-backwards', '-i', 'test',
                            '-o', 'test_out', '-t', '3.4']):
        with patch('sys.stdout', new=StringIO()) as fake_out:
            assert main() == 0
            assert "Compilation complete" in fake_out.getvalue()


# Generated at 2022-06-23 22:35:53.154031
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:57.575619
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/data/source.py', '-o', 'tests/data/out.py',
                '-t', '3.4']
    sys.exit(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:05.607007
# Unit test for function main
def test_main():
    import subprocess
    import os
    import sys
    import tempfile

    from .conf import settings

    # Check debug parameter work
    p = subprocess.run(
        [sys.executable, os.path.join(os.path.dirname(__file__),
                                      '__main__.py'),
         '-i', '__main__.py', '-o', os.devnull, '-t', '2.7',
         '-d'],
        env=dict(os.environ, PYTHONIOENCODING='UTF-8'),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=os.path.dirname(__file__))
    assert p.returncode == 0
    assert settings.DEBUG == True

    # Check

# Generated at 2022-06-23 22:36:17.135821
# Unit test for function main
def test_main():
    args = ArgumentParser()
    args.input = ['../test/test1.py', '../test/test2.py']
    args.output = '../test/test_out'
    args.target = '3.6'
    args.root = '../test'
    args.debug = True

    init_settings(args)

    try:
        for input_ in args.input:
            result = compile_files(input_, args.output,
                                   const.TARGETS[args.target],
                                   args.root)
        print(messages.compilation_result(result))
        return 0
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1

# Generated at 2022-06-23 22:36:17.637066
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:18.188923
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:18.724276
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:22.706454
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test.py', '-o', 'test/output.py',
                '-t', '3.5']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:30.454957
# Unit test for function main
def test_main():
    class Args():
        input = './test.py'
        output = './test.py'
        target = '3.6'
        root = './'
        debug = False

    target_output = """\033[34mTransformed 1 file(s).
    \033[32mSuccessfully transformed 1 file(s).
    \033[31mFailed to transform 0 file(s).
\033[0m"""

    assert main(Args) == 0
    f = open('./test.py', '+w')

# Generated at 2022-06-23 22:36:31.836974
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:34.326865
# Unit test for function main
def test_main():
    #Create args
    args = {"input": 'input.py', "output": 'output.py', "target": '2.7'}
    main()