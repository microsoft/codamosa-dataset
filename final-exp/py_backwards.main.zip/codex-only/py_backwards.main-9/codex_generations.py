

# Generated at 2022-06-23 22:26:32.409224
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'tests/data/text.py', '-o', 'a', '-t', '2.7', '-d', '-r', 'tests/data']
    assert main() == 0


# Generated at 2022-06-23 22:26:41.693020
# Unit test for function main
def test_main():
    init_settings(None)
    
    try:
        result = compile_files('samples\\test_2.py', 'samples\\test_2.py', const.TARGETS['3.5'], None)
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1
    except exceptions.TransformationError as e:
        print(messages.transformation_error(e), file=sys.stderr)
        return 1
    except exceptions.InputDoesntExists:
        print(messages.input_doesnt_exists(args.input), file=sys.stderr)
        return 1

# Generated at 2022-06-23 22:26:46.014183
# Unit test for function main
def test_main():
    args = ["-i", "file1.py", "-t", "2.7", "-o", "file2.py"]
    sys.argv.extend(args)
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:26:49.866398
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/py_for_tests/', '-o', 'out/',
                '-t', '34', '-r', 'tests/py_for_tests']
    main()

# Generated at 2022-06-23 22:27:00.957437
# Unit test for function main
def test_main():
    try:
        args = main('-t 2.7 -i tests/not-exists.py -o /tmp/foo.py'.split())
        assert args == 1
    except SystemExit:
        pass

    try:
        args = main('-t 2.7 -i tests/good_cases/if_else.py'.split())
        assert args == 0
    except SystemExit:
        pass

    try:
        args = main('-t 2.7 -i tests/good_cases/if_else.py -o /tmp/foo'.split())
        assert args == 1
    except SystemExit:
        pass


# Generated at 2022-06-23 22:27:01.486973
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:27:10.692388
# Unit test for function main
def test_main():
    import io
    from contextlib import redirect_stdout
    from os.path import join, dirname

    f = io.StringIO()
    with redirect_stdout(f):
        assert main(['main.py', '-i', join(dirname(__file__), 'tests', 'test1', 'inp.py'),
                          '-o', join(dirname(__file__), 'tests', 'test1', 'out.py'),
                          '-t', '3.5', '-r', dirname(__file__)]) == 1

# Generated at 2022-06-23 22:27:15.337562
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards.py',
        '-i', '../tmp/test/input',
        '-o', '../tmp/test/output',
        '-t', '3.5',
        '--debug'
    ]

    # Run main function
    main()

# Generated at 2022-06-23 22:27:24.044123
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:27:24.497245
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:34.562300
# Unit test for function main
def test_main():
    # Valid arguments
    sys.argv = ['-i', 'file.py', '-o', 'file.py',
                '-t', 'python2.7', '-d']
    assert main() == 0

    # Multiple inputs
    sys.argv = ['-i', 'file.py', 'file2.py', '-o', 'file.py',
                '-t', 'python2.7', '-d']
    assert main() == 0

    # Invalid target
    sys.argv = ['-i', 'file.py', '-o', 'file.py',
                '-t', 'python2.8', '-d']
    assert main() == 1

    # Both inputs not specified

# Generated at 2022-06-23 22:27:42.832429
# Unit test for function main
def test_main():
    args = ['main.py', '-i', 'tests/tests_parser/test_body/', '-o', 'output', '-t', 'py34', '-d', '-r', 'tests/tests_parser/test_body/']
    assert(main() == 0)
    args = ['main.py', '-i', 'tests/tests_parser/test_body/', '-o', 'output', '-t', 'py', '-d', '-r', 'tests/tests_parser/test_body/']
    assert(main() == 1)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:43.456669
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:27:45.201825
# Unit test for function main
def test_main():
    pytest.main()

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:27:53.403798
# Unit test for function main
def test_main():
    from argparse import Namespace
    from sys import argv
    argv_ = argv[:]
    argv.append('-i')
    argv.append('tests/source')
    argv.append('-o')
    argv.append('tests/output')
    argv.append('-t')
    argv.append('3.4')
    args = main()
    assert (args == 0)

    argv_2 = argv_[:]
    argv_.append('-i')
    argv_.append('tests/source')
    argv_.append('-o')
    argv_.append('tests/output')
    argv_.append('-t')
    argv_.append('3.6')
    args = main()
    assert (args == 0)

    argv_3 = argv

# Generated at 2022-06-23 22:27:57.690860
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('test/test_files/test_file.py')
    sys.argv.append('-o')
    sys.argv.append('test/test_files/test_out.py')
    sys.argv.append('-t')
    sys.argv.append('3.4')
    main()

# Generated at 2022-06-23 22:28:00.221718
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'input.py', '-o', 'output.py', '-t',
                    'python3.4', '-d', '-r', 'root']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:11.580098
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/resources/py2_input/src/', '-o',
                    'tests/resources/py2_output/', '-t', 'py2', '-r',
                    'tests/resources/']
    assert main() == 0

    sys.argv[1:] = ['-i', 'tests/resources/py2_input/src/', '-o',
                    'tests/resources/py3_output/', '-t', 'py3', '-r',
                    'tests/resources/']
    assert main() == 0


# Generated at 2022-06-23 22:28:21.039159
# Unit test for function main
def test_main():
	sys.argv.append('-i')
	sys.argv.append('C:/Users/bit-user/Desktop/Laboratory/PY-BACKWARDS/py_backwards_test/test_files/test.py')
	sys.argv.append('-o')
	sys.argv.append('C:/Users/bit-user/Desktop/Laboratory/PY-BACKWARDS/py_backwards_test/test_files/test_result.py')
	sys.argv.append('-t')
	sys.argv.append('2.7')
	sys.argv.append('-r')
	sys.argv.append('C:/Users/bit-user/Desktop/Laboratory/PY-BACKWARDS/py_backwards_test/test_files')

# Generated at 2022-06-23 22:28:21.716142
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:32.134137
# Unit test for function main
def test_main():
    from contextlib import redirect_stdout
    from io import StringIO
    assert main() == 0

    # Test wrong option
    f = StringIO()
    with redirect_stdout(f):
        main(['--input', 'path', '--output', 'path', '--target', '2.7', '--wrong_option'])
    assert f.getvalue() == 'usage: py-backwards [-h] -i INPUT [INPUT ...] -o OUTPUT -t TARGET\n' \
                           '                  [-r ROOT] [-d]\n' \
                           'py-backwards: error: unrecognized arguments: --wrong_option\n'


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:37.675625
# Unit test for function main
def test_main():
    class Args:
        def __init__(self, input, output, target, root=None, debug=False):
            self.input = input
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    sys.argv = ['py-backwards.py', '-i', 'test/test_files', '-o', 'test/out',
                '-t', 'py35']
    main()
    assert sys.argv == ['py-backwards.py', '-i', 'test/test_files', '-o', 'test/out',
                        '-t', 'py35']

# Generated at 2022-06-23 22:28:47.010616
# Unit test for function main
def test_main():
    result = main(["py-backwards", "-i", "./tests/example.py", "-o", "./tests", "-t", "2.7", "-r", "./tests", "-d", "True"])
    assert result == 1

    result = main(["py-backwards", "-i", "./tests/example.py", "-o", "./tests", "-t", "3.3", "-r", "./tests", "-d", "True"])
    assert result == 1

    result = main(["py-backwards", "-i", "./tests/example.py", "-o", "./tests", "-t", "3.4", "-r", "./tests", "-d", "True"])
    assert result == 1


# Generated at 2022-06-23 22:28:50.938407
# Unit test for function main
def test_main():
    args = ['test/test.py', '-i', 'test/test.py', '-o', 'test/test2.py', '-t', '35', '-r', 'test/']
    sys.argv = args
    main()
    assert 1 == 1

# Generated at 2022-06-23 22:28:58.853430
# Unit test for function main
def test_main():
    import os
    import shutil 
    import io
    import pytest
    os.system('python3 -m py_backwards.compiler')
    def test_good1_main():
        assert main() == 0
    def test_good2_main():
        assert main() == 0
    def test_good3_main():
        assert main() == 0
    def test_good4_main():
        assert main() == 0
    def test_good5_main():
        assert main() == 0
    def test_good6_main():
        assert main() == 0
    def test_good7_main():
        assert main() == 0
    def test_good8_main():
        assert main() == 0
    def test_good9_main():
        assert main() == 0

# Generated at 2022-06-23 22:29:01.886078
# Unit test for function main
def test_main():
    assert main() != 0 # Компиляция производится в отсутствии файлов
    return

# Generated at 2022-06-23 22:29:09.467998
# Unit test for function main

# Generated at 2022-06-23 22:29:14.060182
# Unit test for function main
def test_main():
    files = ['test0.py', 'test1.py', 'test2.py', 'test3.py']
    file = 'test.py'
    root = 'tests'
    result = 0
    for f in files:
        result = main()
        assert result == 0, 'Main function return not equal 0'



# Generated at 2022-06-23 22:29:22.744758
# Unit test for function main
def test_main():
    from .conf import set_debug, set_args, get_options
    from . import demo

    demo.make_demo()

    args_fail = '-i demo -o demo -t 2.7'.split()
    args_success = '-i demo -o demo/output -t 2.7'.split()

    set_debug(True)
    set_args(args_fail)
    assert main() == 1
    assert get_options() == get_options()

    set_args(args_success)
    assert main() == 0

    demo.clean_demo()
    assert main() == 1

# Generated at 2022-06-23 22:29:34.435912
# Unit test for function main
def test_main():
    input_ = '../tests/data/input'
    output = '../tests/data/output'
    target = '3.5'
    root = '../tests/data/root'
    debug = 'true'
    test_parameters = [input_, output, target, root, debug]
    assert main(test_parameters) == 0
    
    input_ = '../tests/data/input'
    output = '../tests/data/output'
    target = '3.5'
    root = '../tests/data/root'
    debug = 'true'
    test_parameters = [input_, output, target, root, debug]
    assert main(test_parameters) == 1
    
    input_ = '../tests/data/input'
    output = '../tests/data/output'
    target

# Generated at 2022-06-23 22:29:35.479487
# Unit test for function main
def test_main():
    result = main()
    assert result == 0, "True"

# Generated at 2022-06-23 22:29:36.093023
# Unit test for function main
def test_main():
    assert main()==0

# Generated at 2022-06-23 22:29:37.866967
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:38.796364
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        main()

# Generated at 2022-06-23 22:29:39.358774
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:29:46.125717
# Unit test for function main
def test_main():
    # TODO
    from .utils import get_project_path

    input_files = get_project_path('./tests/test_files/')
    output_files = get_project_path('./tests/test_files/')
    target = '27'
    root = get_project_path('./tests/')

    assert main(input_files, output_files, target, root, debug=False) == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:48.446795
# Unit test for function main
def test_main():
    result = main()
    if result == 0:
        print("Test passed")


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:29:49.756619
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:52.774474
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1] + ['-i', 'tests/script.py', '-o', 'output.py', '-t', '>=3.6', '-r', 'tests']
    main()

# Generated at 2022-06-23 22:29:58.840314
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards', '-i',
        'test_sources/transforms/test_import_syntax.py',
        '-o', 'test_sources/test_result.py',
        '-t', '3.6',
        '-r', 'test_sources/'
    ]
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:02.277224
# Unit test for function main
def test_main():
    sys.argv = ['pybw', '-i', 'input1', 'input2', '-o', 'output', '-t', '2.7',
                '-d', '-r', 'root']
    assert main() == 0

# Generated at 2022-06-23 22:30:09.140218
# Unit test for function main
def test_main():
    from unittest import mock
    from . import main
    with mock.patch('argparse.ArgumentParser.parse_args') as mock_parser:
        mock_parser.return_value = mock.Mock(
            input=['Mock', ],
            output='Mock',
            target='Mock',
            root='Mock',
            debug=False
        )
        with mock.patch('sys.stdout', new_callable=mock.Mock) as mock_stdout:
            assert mai

# Generated at 2022-06-23 22:30:17.878825
# Unit test for function main
def test_main():
    # Create a parser that can be used to instantiate the arguments parser.
    # The parser does not need to have the same options as the real one.
    parser = ArgumentParser('py-backwards')
    # Create the argparse.Namespace object that will be passed to the function
    # as a stand-in for the commandline arguments.
    args = parser.parse_args(['-i', 'tests/test.py', '-o', 'tests/test1.py', '-t', '3.5',])
    # We call the test function, passing the mocked arguments.
    # If the test case fails, the assert statement will raise an exception
    # and the test runner will stop and report the failure.
    assert main(args) == 0

# Generated at 2022-06-23 22:30:23.390314
# Unit test for function main
def test_main():
    args = [
        '-i', './tests/input/valid_input',
        '-o', '../tests/output/valid_output',
        '-t', 'py27',
        '-r', '../tests/input/valid_input'
    ]
    assert main(args) == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:23.815092
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:32.889401
# Unit test for function main
def test_main():
    # Command Line arguments
    sys.argv = [sys.argv[0], '-i', 'tests/languages/set/basic.py', '-o', 'tests/output/set.py', '-t', '3.4']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', 'tests/languages/set/basic.py', '-o', 'tests/output/set.py', '-t', '2.7']
    assert main() == 1
    sys.argv = [sys.argv[0], '-i', 'tests/languages/set/invalid.py', '-o', 'tests/output/set.py', '-t', '3.4']
    assert main() == 1

# Generated at 2022-06-23 22:30:35.144032
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-23 22:30:35.749882
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:30:44.537259
# Unit test for function main
def test_main():
    # Test no input
    sys.argv = ["py-backwards", "-t", "3.5", "-o", "test.py"]
    assert main() == 2

    # Test File doesn't exists
    sys.argv = ["py-backwards", "-t", "3.5", "-o", "test.py", "-i", "test.py"]
    assert main() == 1

    # Test Invalid Input/Output
    sys.argv = ["py-backwards", "-t", "3.5", "-o", "test.py", "-i", "test.py"]
    assert main() == 1

    # Test Permission error
    sys.argv = ["py-backwards", "-t", "3.5", "-o", "test.py", "-i", "test.py"]
    assert main() == 1

    #

# Generated at 2022-06-23 22:30:48.364984
# Unit test for function main
def test_main():
    class Args:
        def __init__(self):
            self.input = ['/home/test']
            self.output = '/home/test'
            self.target = 'python2'
            self.root = '/home/test'
            self.debug = True

    sys.argv = ['py-backwards']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:51.507997
# Unit test for function main
def test_main():
    class Stub(object):
        pass
    argv = Stub()
    argv.input = ['tests/main_tests/tests.py']
    argv.output = 'tests/main_tests/out.py'
    argv.target = '2.7'
    argv.debug = True
    argv.root = None

    # Test successful compilation
    assert main(argv) == 0

    # Test exception thrown
    argv.input = ['tests/main_tests/tests2.py']
    try:
        main(argv)
    except SystemExit as e:
        assert e.code == 1

# Generated at 2022-06-23 22:31:01.216901
# Unit test for function main
def test_main():
    from colorama import Fore, Back, Style
    from . import const
    # ----------- test for inputs different from py file -------------
    for input in ["a", "txt", "11", None]:
        try:
            main()
        except SystemExit:
            print(Fore.LIGHTWHITE_EX + "test for non-py file was passed" + Style.RESET_ALL)
            break
    # ----------- test for inputs not existing in filesystem -------------
    for input in ["NonExistingFile.py", "NonExistingFolde/NonExistingFile2.py"]:
        try:
            main()
        except SystemExit:
            print(Fore.LIGHTWHITE_EX + "test for non-existing file was passed" + Style.RESET_ALL)
            break
    # ----------- test for inputs not existing in filesystem 

# Generated at 2022-06-23 22:31:05.557956
# Unit test for function main
def test_main():
    sys.argv=['main.py', '-i', './tests/sample/input.py', '-o', './tests/sample/output.py', '-t', '3.5', '-r', './tests/sample/']
    assert 0 == main()

# Generated at 2022-06-23 22:31:07.158992
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        assert True

# Generated at 2022-06-23 22:31:07.869875
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:31:08.549795
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:08.965330
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:14.080269
# Unit test for function main
def test_main():
    # Args are invalid
    assert main(['-t']) == 2
    result = main(['-i', 'main.py', '-o', 'output', '-t', '2.7'])
    assert result == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:21.634331
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:31:32.663790
# Unit test for function main
def test_main():
    # Tests with invalid input
    with patch('builtins.input', return_value='n'):
        assert main() == 1
    with patch('builtins.input', return_value='n'):
        assert main(['-i', 'tests/data/invalid_input.py', '-o', '/tmp/',
                     '-t', '3.4']) == 1
    with patch('builtins.input', return_value='n'):
        assert main(['-i', 'tests/data/invalid_input.py', '-o', '/tmp/',
                     '-t', '3.4']) == 1

# Generated at 2022-06-23 22:31:34.627366
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 1

# Generated at 2022-06-23 22:31:36.707701
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:39.232620
# Unit test for function main
def test_main():
    arg_parser = ArgumentParser()
    args = arg_parser.parse_args([])
    assert main(args) == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:45.091496
# Unit test for function main
def test_main():
    # Error when input files doesnt exists
    print("test_main: Error when input files doesnt exists")

    # Error when input and output is the same or output file doesnt exists
    print("test_main: Error when input and output is the same or output file doesnt exists")
    # Error when permission error
    print("test_main: Error when permission error")
    # Compilation result
    print("test_main: Compilation result")

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:31:45.608495
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:31:50.039343
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'new.py', '-t',
                '2.7', '-r', 'py-backwards-dev']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:56.042816
# Unit test for function main
def test_main():
    # Test 1
    sys.argv = ["py-backwards", "-i", "tests/files/valid/Valid.py", "-o",
                "tests/files/output/Valid3.py", "-t", "3"]
    assert main() == 0
    # Test 2
    sys.argv = ["py-backwards", "-i", "tests/files/valid/Valid.py", "-o",
                "tests/files/output/Valid3.py", "-t", "3", "-r", "tests/files/valid/"]
    assert main() == 0

# Generated at 2022-06-23 22:31:56.580949
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:59.004958
# Unit test for function main
def test_main():
    args = ['--input', 'input.py', '--output', 'out.py', '--target', '3.6']
    sys.argv.extend(args)
    main()

# Generated at 2022-06-23 22:31:59.908822
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:06.949817
# Unit test for function main
def test_main():
    from py_backwards.tests import utils

    test_argv = ['py_backwards', '-i', 'tests/example_in.py', '-o', 'test_output.py',
		'-t', 'python36', '-r', 'tests']
    with utils.tempdir() as tmpdir:
        with utils.keep_dir(tmpdir):
            with utils.mock_argv(test_argv):
                main()

# Generated at 2022-06-23 22:32:08.661258
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:11.955053
# Unit test for function main
def test_main():
    import pytest
    sys.argv = ['py-backwards', '-i', 'test/input.py', '-o', 'test', '-t', '2.7']
    main()

# Generated at 2022-06-23 22:32:22.418634
# Unit test for function main
def test_main():
    assert main('-i ../tests/input -o ../tests/output -t 2.6 -r ../tests/input'.split()) == 0
    assert main('-i ../tests/input/unittest.py -o ../tests/output -t 2.6 -r ../tests/input'.split()) == 0
    assert main('-i ../tests/input/main.py -o ../tests/output -t 2.6'.split()) == 0

    assert main('-i ../tests/input/bad.py -o ../tests/output -t 2.6'.split()) == 1
    assert main('-i ../tests/input/bad_trans.py -o ../tests/output -t 2.6'.split()) == 1

# Generated at 2022-06-23 22:32:28.665593
# Unit test for function main
def test_main():
    assert main(['-i', 'C:/Users/Dp/Desktop/py3k-backwards/py3k-backwards/tests/real_app'
        ,'-o', 'C:/Users/Dp/Desktop/py3k-backwards/py3k-backwards/tests/real_app'
        , '-t','2'
        , '-r','C:/Users/Dp/Desktop/py3k-backwards/py3k-backwards/tests/real_app']) == 0

# Generated at 2022-06-23 22:32:31.829037
# Unit test for function main
def test_main():
    # TODO: Implement tests
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:32.430448
# Unit test for function main
def test_main():
  assert main() == 0

# Generated at 2022-06-23 22:32:36.003961
# Unit test for function main
def test_main():
    sys.argv = ['py_backwards', '--input', 'b.py', '--output', 'c.py', '--target', '3.4']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:40.667212
# Unit test for function main
def test_main():
    args = ['main.py',
            '-i', 'test/test',
            '-o','test/test_py2',
            '-t','2.7',
            '-d']
    sys.argv[1:] = args
    sys.exit(main())

if __name__ == "__main__":
    # test_main()
    sys.exit(main())

# Generated at 2022-06-23 22:32:43.460202
# Unit test for function main
def test_main():
    init_settings(namespace(debug=True, input=[], output='', target='', root=''))



# Generated at 2022-06-23 22:32:49.345466
# Unit test for function main
def test_main():
    args = ['-i', 'test_input_01.py', '-o', 'test_output.py', '-t', '3.4']
    assert main(args) == 0
    args = ['-i', 'test_input_00.py', '-o', 'test_output.py', '-t', '3.4']
    assert main(args) == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:00.911663
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:33:10.047103
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'foo.py', 'bar.py', '-o', 'out', '-t', '3.6']
    with patch('py_backwards.main.compile_files', side_effect=exceptions.TransformationError('message')):
        assert main() == 1

    with patch('py_backwards.main.compile_files', side_effect=exceptions.CompilationError('message')):
        assert main() == 1

    with patch('py_backwards.main.compile_files', side_effect=exceptions.InputDoesntExists()):
        assert main() == 1

    with patch('py_backwards.main.compile_files', side_effect=exceptions.InvalidInputOutput()):
        assert main() == 1


# Generated at 2022-06-23 22:33:13.323333
# Unit test for function main
def test_main():
    x = main()
    if x != 0:
        assert False

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:20.334386
# Unit test for function main
def test_main():
    assert main(["-i","fixtures/vision/models/faster_rcnn.py","-o","/home/jovyan/code/py-backwards/output/","-t","2.7","-r","/home/jovyan/code/py-backwards/fixtures/vision/models"]) == 0


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print(messages.keyboard_interrupt(), file=sys.stderr)
        sys.exit(1)

# Generated at 2022-06-23 22:33:22.507364
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:29.247251
# Unit test for function main
def test_main():
    def test_case(args, expected_output, expected_error=None,
                  expected_return_code=0):
        # Save stdout and stderr
        sys.stdout, sys.stderr = sys.__stdout__, sys.__stderr__

        # Override sys.stdout and sys.stderr
        sys.stdout = StringIO()
        sys.stderr = StringIO()

        # Run the code
        assert main(args.split()) == expected_return_code
        assert sys.stdout.getvalue() == expected_output
        if expected_error is not None:
            assert sys.stderr.getvalue() == expected_error

    # Tests for errors
    with open(path.join(app_dir, '../messages.py'), 'r') as f:
        messages_

# Generated at 2022-06-23 22:33:31.225884
# Unit test for function main
def test_main():
    """Main function test"""
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:32.067011
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:33:33.998660
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    res = main()
    sys.exit(res)

# Generated at 2022-06-23 22:33:45.756208
# Unit test for function main
def test_main():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        file_name = 'example.py'
        file_path = tmpdirname + '/' + file_name
        with open(file_path, 'w') as f:
            f.write('')

        sys.argv = ['py-backwards', '-i', file_path,
                    '-o', file_path + '.py3', '-t', '3.5']
        main()

        sys.argv = ['py-backwards', '-i', file_path, '-o', file_path, '-t',
                    '3.5']
        assert main() == 1


# Generated at 2022-06-23 22:33:54.621027
# Unit test for function main
def test_main():
    #test 1: file not found
    test = sys.argv[0]
    sys.argv = ['py-backwards','-i', 'test/test_input/  ', '-o',
                'test/test_output/', '-t', '3.5', '-d']
    assert main() != 0

    #test 2: input and output is the same directory
    sys.argv = ['py-backwards', '-i', 'test/test_input/test1.py', '-o',
                'test/test_input/test1.py', '-t', '3.5', '-d']
    assert main() != 0

    #test 3: input doesn't match output

# Generated at 2022-06-23 22:33:55.956316
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:56.628730
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:58.262089
# Unit test for function main
def test_main():
    assert main() == 1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:08.118990
# Unit test for function main
def test_main():
    input_ = 'tests/input/five.py'
    output = 'tests/output/five.py'
    target = '2'
    args = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    args.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    args.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    args.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')

# Generated at 2022-06-23 22:34:08.709699
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:13.673873
# Unit test for function main
def test_main():
    py_paths = [
        'tests/input/source/tests',
        'tests/input/source/tests/test_rfcalc.py',
    ]
    result_paths = [
        'tests/input/expected/tests',
        'tests/input/expected/tests/test_rfcalc.py',
    ]
    for py_path, result_path in zip(py_paths, result_paths):
        yield check_main, py_path, result_path



# Generated at 2022-06-23 22:34:17.640663
# Unit test for function main
def test_main():
    """
    Tests the main function of the program
    """
    # todo: figure out how to test sys.argv...
    # todo: add more tests
    # todo: add tests for return codes

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:25.125542
# Unit test for function main
def test_main():
    from py_backwards.conf import settings
    args = ['--input', 'test_data/test.py', '--output', 'test_data/test.pyc',
            '-t', '2.7']
    main()
    assert settings.DEBUG == False
    assert settings.OUTPUT == 'test_data/test.pyc'
    assert settings.TARGET == '2.7'
    assert settings.INPUT == ['test_data/test.py']
    assert settings.ROOT == None


# Generated at 2022-06-23 22:34:35.909700
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "main.py", "-o", "result.py", "-t", "2.7",
                "-r", "main.py", "-d"]
    delete_file("result.py")

# Generated at 2022-06-23 22:34:45.818659
# Unit test for function main
def test_main():
    from . import __main__
    import io
    import contextlib
    from .test import common
    from . import settings
    from .files import fix_path
    import sys

    settings.configure(
        input_path=[common.FIXTURE_PATH],
        output_path=common.OUTPUT_PATH,
        target='3.3'
    )

    common.remove_output_folder(common.OUTPUT_PATH)

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr

# Generated at 2022-06-23 22:34:56.546003
# Unit test for function main
def test_main():
    test_file = 'file.py'
    test_dir = 'dir'
    new_dir = 'dir2'
    new_file = 'file2.py'
    non_existent_dir = 'non_existent_dir'
    non_existent_file = 'non_existent_file.py'
    text = 'print("Hello World!")'
    import os
    import shutil
    open(test_file, 'w').write(text)
    os.mkdir(test_dir)
    os.mkdir(non_existent_dir)
    open(os.path.join(test_dir, test_file), 'w').write(text)
    success = 0
    try:
        main()
    except SystemExit as e:
        if e.code == success:
            pass
        else:
            raise e


# Generated at 2022-06-23 22:35:02.934742
# Unit test for function main
def test_main():
    from random import randrange
    from .conf import set_debug
    from . import run

    set_debug(True)
    run.main(['-t', '3.4', '-i', 'test_files', '-o', '.', '-d'])
    run.main(['-t', '3.4', '-i', 'test_files', '-o', '.'])

# Generated at 2022-06-23 22:35:03.468114
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:04.652431
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:05.812808
# Unit test for function main
def test_main():
    init_settings(ArgumentParser().parse_args([]))

    assert main() == 0

# Generated at 2022-06-23 22:35:08.752376
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]] + \
        '-i input1 input2 -o output -t "3.6" -r "/home/user" -d'.split()
    assert main() == 0


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:35:19.485872
# Unit test for function main
def test_main():
    from io import StringIO
    import os
    import shutil
    from .conf import settings
    temp_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp')
    os.makedirs(temp_dir, exist_ok=True)
    sys.argv = ['', '-i', 'tests/input.py', '-o', 'temp/output.py', '-t', '2.7', '-d']
    capturedOutput = StringIO()
    sys.stdout = capturedOutput
    main()
    sys.stdout = sys.__stdout__
    assert settings.debug is True

# Generated at 2022-06-23 22:35:20.475438
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:22.684479
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/syntax.py', '-o', 'test/result.py', '-t', '2_7', '-r', 'tests']
    assert main() == 0

# Generated at 2022-06-23 22:35:33.470528
# Unit test for function main
def test_main():
    from types import SimpleNamespace
    args = SimpleNamespace(
        input=['test\\test_files\\test_file_1.py'],
        output='test\\test_files\\output\\',
        target='2.7',
        root='test\\test_files'
    )
    init_settings(args)
    for input_ in args.input:
        result = compile_files(input_, args.output,
                               const.TARGETS[args.target],
                               args.root)

    assert result.success, \
        'Compilation of test file should be successful'
    assert os.path.isfile('test\\test_files\\output\\test_file_1.py'), \
        'Compiled file should be created'

# Generated at 2022-06-23 22:35:34.670148
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as e:
        main()
        assert e.message == 1

# Generated at 2022-06-23 22:35:37.598786
# Unit test for function main
def test_main():
    class Args:
        def __init__(self):
            self.input = ['/test_file/test.py']
            self.output = '/test_file/'
            self.root = '/test_file/'
            self.target = '3'
            self.debug = False

    main(Args())

# Generated at 2022-06-23 22:35:42.247839
# Unit test for function main
def test_main():
    assert main() != 0
    assert main() != 1
    assert main() != 2
    assert main() != 3

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:51.374606
# Unit test for function main
def test_main():
    from tempfile import TemporaryDirectory
    import shutil
    from pathlib import Path
    from .utils import copy_tree
    from .conf import settings

    def run_test(target, input_, output, exc=None):
        args = ['--target', target, '--input', input_, '--output', output]
        with TemporaryDirectory() as temp:
            if not input_.startswith('/'):
                input_ = Path(temp)/input_
            if not output.startswith('/'):
                output = Path(temp)/output
            copy_tree('tests/resources', temp)
            import py_backwards.main
            try:
                py_backwards.main.main(args)
                assert not exc
                assert output.exists()
            except SystemExit:
                assert exc
        settings.reset()



# Generated at 2022-06-23 22:35:53.729981
# Unit test for function main
def test_main():
    sys.argv = "py-backwards -i test.py -o output.py -t 2.7".split(" ")
    assert main() == 0

# Generated at 2022-06-23 22:35:55.691169
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    test_main()
    exit(main())

# Generated at 2022-06-23 22:35:59.064776
# Unit test for function main
def test_main():
    main(['-i', 'tests/compile_files_test.py', '-o', 'tests/results', '-t', '2'])

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:02.568441
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i',
        'tester.py',
        '-o',
        'output',
        '-t',
        '3.5',
    ]
    main()


# Generated at 2022-06-23 22:36:04.431812
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:12.052958
# Unit test for function main
def test_main():
    # Initialize compilers
    init_settings(None)
    result = compile_files('tests/examples/person.py', 'tests/output/person.py',
                   const.TARGETS['35'], None)
    print(result)
    assert result['same'] == 0
    assert result['new'] == 0
    assert result['modified'] == 1
    assert result['deleted'] == 0
    assert result['errors'] == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:20.137055
# Unit test for function main
def test_main():
    import subprocess
    import sys
    import os
    import shutil
    """Unit test for function main"""
    test_dir = os.path.dirname(os.path.dirname(__file__))
    test_dir = os.path.join(test_dir, "tests")
    test_dir = os.path.join(test_dir, "compiler")
    os.chdir(test_dir)

    assert main() == 0

    os.chdir("..")
    shutil.rmtree("output")

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-23 22:36:20.654458
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:23.167037
# Unit test for function main
def test_main():
    argv = ['-i', 'test', '-o', 'output', '-t', '2.7', '-r', 'sources']
    sys.argv = sys.argv[:1] + argv
    main()

# Generated at 2022-06-23 22:36:29.307009
# Unit test for function main
def test_main():
  old_sys = sys.argv
  sys.argv = ['py-backwards.py', '-i', 'tests/examples/__init__.py',
              'tests/examples/hello_world.py', '-o', 'tests/output',
              '-t', '2.7', '-r', 'tests/examples']
  sys.exit(main())
  sys.argv = old_sys