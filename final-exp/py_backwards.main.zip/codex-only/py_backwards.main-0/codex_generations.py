

# Generated at 2022-06-23 22:26:38.403281
# Unit test for function main
def test_main():
    sys.argv = ['', '-d', '-i', '-', '-o', '-', '-t', '3.6']
    # sys.stdin = io.StringIO('def f():\n    return x')
    # sys.stdout = io.StringIO()
    assert main() == 1, 'Return value is not 1.'


if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-23 22:26:39.137368
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:43.811600
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '--input', 'input_file/input.py', '--output',
                'output_file/output.py', '--target', '2.7', '--root',
                'root_dir/', '--debug', '--help']
    assert main() == 0

# Generated at 2022-06-23 22:26:44.489313
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:47.589068
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'README.md', '-o', 'output', '-t', '2']
    assert main() == 1

# Generated at 2022-06-23 22:26:50.734026
# Unit test for function main
def test_main():
    assert main() == 0
    assert main('-h') == 0

# Generated at 2022-06-23 22:26:51.569407
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:26:55.884867
# Unit test for function main
def test_main():
    args = [
        'pybackwards',
        '-t', '2.7',
        '-i', 'tests/test_simple.py',
        '-o', 'tests/test_output.py',
    ]
    assert main(args) == 0

# Generated at 2022-06-23 22:26:57.778937
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as ex:
        main()
    assert ex.value.code == 2

# Generated at 2022-06-23 22:27:01.786978
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'input.py', '-o', 'output.py', '-t', '3.6', '-r', '/Users/marc/anaconda3/envs/py36/bin/python', '-d', True]
    main()

# Generated at 2022-06-23 22:27:02.948170
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.exit(main())


# Generated at 2022-06-23 22:27:12.543825
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:27:15.516341
# Unit test for function main
def test_main():
    """
    Unit testing main function
    """
    # main()
    assert (main() == 0)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:16.089165
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:27:24.592602
# Unit test for function main
def test_main():
    # Test 1
    sys.argv = ['py-backwards', '-t', '3.3', '-o', 'out', '-i', 'in']
    assert main() == 0

    # Test 2
    sys.argv = ['py-backwards', '-t', '3.3', '-o', 'out', '-i', 'in', '-d']
    assert main() == 0

    # Test 3 - try to compile with not existing input
    sys.argv = ['py-backwards', '-t', '3.3', '-o', 'out', '-i', 'input']
    assert main() == 1

    # Test 4 - try to compile with not existing input

# Generated at 2022-06-23 22:27:25.079825
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:25.630201
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:26.758225
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:27:32.526740
# Unit test for function main
def test_main():
    test_argv = ['-i', 'src/py_backwards', '-o', 'build/py_backwards', '-t',
                 'py26', '-d']

    main()

    with open("build/py_backwards/__init__.py", "r") as file:
        assert file.read() == ""


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:33.930970
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:34.576173
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:40.488407
# Unit test for function main
def test_main():
    # Test case 1
    sys.argv[1:] = ['-i', 'test_py_backwards/example.py',
                    '-o', 'test_py_backwards/example.py',
                    '-t', '3.5']
    assert main() == 1

    # Test case 2
    sys.argv[1:] = ['-i', 'test_py_backwards/example.py',
                    '-o', 'test_py_backwards/example2.py',
                    '-t', '3.5']
    assert main() == 0

    # Test case 3
    sys.argv[1:] = ['-i', 'test_py_backwards/example.py',
                    '-o', 'test_py_backwards/example2.py',
                    '-t', '3.6']


# Generated at 2022-06-23 22:27:41.046698
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:41.622886
# Unit test for function main
def test_main():
    assert main() is 0

# Generated at 2022-06-23 22:27:43.151061
# Unit test for function main
def test_main():
    analysis = main()
    assert analysis == 0

# Generated at 2022-06-23 22:27:46.117226
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        print('test main')
        main()
test_main()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:50.014611
# Unit test for function main
def test_main():
    sys.argv = ["", "-i", "test.py", "-o", "test1.py", "-t", "3.5", "-r", "root", "-d"]
    assert(main() == 1)

# Generated at 2022-06-23 22:27:50.943348
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:27:59.900810
# Unit test for function main
def test_main():
	import unittest
	from unittest.mock import patch, call
	from io import StringIO

	class TestMain(unittest.TestCase):
		
		@patch('sys.stdout', new_callable=StringIO)
		def test_success(self, mock_stdout):
			with patch('py_backwards.compiler.compile_files') as mock_compile:
				mock_compile.return_value = 2
				assert main() == 0
				args, kwargs = mock_compile.call_args
				assert args == ('a', 'b', 'c', None)
				assert kwargs == {}
				assert mock_stdout.getvalue() == 'Compiled 2 files\n'

# Generated at 2022-06-23 22:28:02.733531
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', './tests/test.py', '-o', 'test.py', '-t', '2']
    main()

# Generated at 2022-06-23 22:28:08.480277
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'tests/fixtures/test.py',
                '-o', 'tests/foo/bar.py', '-t', 'python34', '-d']
    sys.exit(main())

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:18.264463
# Unit test for function main
def test_main():
    import os
    import shutil

    def run_compiler(command):
        init_settings(parser.parse_args(command.split()))
        return compile_files(
            input_,
            output,
            const.TARGETS[args.target],
            args.root
        )
    args = sys.argv[:]
    sys.argv = sys.argv[:1]
    parser = ArgumentParser('py-backwards')
    sys.argv = args
    file_path = os.path.dirname(__file__)
    input_ = os.path.join(file_path, 'test_data')
    output = os.path.join(file_path, 'test_data_out')

# Generated at 2022-06-23 22:28:27.662411
# Unit test for function main
def test_main():
    # Test for regular usage
    argv = [__file__, '-i', 'test/test_files/test.py', '-o', 'test/test_files/out.py', '-t', '27']
    assert main() == 0

    # Test for wrong argument
    argv = [__file__, '-i', 'test/test_files/test.py', '-o', 'test/test_files/out.py', '-t', 'wtf']
    assert main() == 2

    # Test for no input
    argv = [__file__, '-o', 'test/test_files/out.py']
    assert main() == 2


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:35.062783
# Unit test for function main
def test_main():
    sys.argv = [
        sys.argv[0],
        '-i', 'tests/data/root',
        '-o', 'output',
        '-t', 'python-2.7',
        '-r', 'tests/data/root'
    ]
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:38.099567
# Unit test for function main
def test_main():
    # Test for a correct compilation
    sys.argv = ['-i', 'tests/test_files/valid_file.py',
                '-o', 'tests/test_files/valid_file2.py',
                '-t', '2.7']
                
    assert main() == 0

# Generated at 2022-06-23 22:28:45.394033
# Unit test for function main
def test_main():
    import os
    import shutil
    import filecmp
    import tempfile
    import subprocess

    def test_input_folder(input_: str, output: str,
                          target: str, debug: bool = False) -> None:
        input_dir = os.path.dirname(os.path.abspath(__file__)) + '/input/' + input_
        output_dir = os.path.dirname(os.path.abspath(__file__)) + '/output/' + output
        result_dir = tempfile.mkdtemp()

        args = [sys.argv[0]]

        args.append('-i')
        args.append(input_dir)

        args.append('-o')
        args.append(result_dir)

        args.append('-t')
        args.append

# Generated at 2022-06-23 22:28:48.373968
# Unit test for function main
def test_main():
    assert main() == 0
    assert main(['--debug', './test_files', '-i', './test_files', '-t', '2', '-o', './out']) == 0

# Generated at 2022-06-23 22:28:54.717043
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-t', '3.5', '-i', 'test/testdata', '-o', 'test/testdata/out.py', '-r', 'test/testdata/']
    assert main() == 0

    sys.argv = ['py-backwards', '-t', '3.5', '-i', 'test/testdata', '-o', 'test/testdata/out', '-r', 'test/testdata/']
    assert main() == 0

# Generated at 2022-06-23 22:28:56.957761
# Unit test for function main
def test_main():
    # compile_file doesnt raise exception
    main()
    # compile_file raises exception
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:01.971294
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test/py_files/good_input.py', '-o', 'test/py_files/output/temp.py', '-t', 'python37', '-r', 'test/py_files', '-d', 'True']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:06.468877
# Unit test for function main
def test_main():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    sys.argv = ["", "-i", "input", "-o", "output", "-t", "2.7"]
    with patch('builtins.input', return_value="y"):
        assert main() == 0

    sys.argv = ["", "-i", "input", "-o", "output", "-t", "2.7"]
    with patch('builtins.input', return_value="y"):
        assert main() == 0

    sys.argv = ["", "-i", "input", "-o", "output", "-t", "2.7"]
    with patch('builtins.input', return_value="n"):
        assert main() == 1


# Generated at 2022-06-23 22:29:11.407874
# Unit test for function main
def test_main():
    sys_excepthook_backup = sys.excepthook

    def excepthook(type, value, traceback):
        sys_excepthook_backup(type, value, traceback)
        assert type is SystemExit
        assert value.code in [0, 1]

    sys.excepthook = excepthook
    parser = ArgumentParser()
    args = parser.parse_args([])
    assert main(args) in [0, 1]

# Generated at 2022-06-23 22:29:18.044958
# Unit test for function main
def test_main():
    sys.argv.append('some_folder')
    sys.argv.append('-o')
    sys.argv.append('some_folder_out')
    sys.argv.append('-t')
    sys.argv.append('py36')
    sys.argv.append('-d')
    sys.argv.append('-r')
    sys.argv.append('some_root')
    main()

# Generated at 2022-06-23 22:29:20.708441
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/', '-o', 'test_out/', '-t', '3']
    main()

# Generated at 2022-06-23 22:29:25.745138
# Unit test for function main
def test_main():
    init_settings(None)

    # result = execute_command(Command(args.input, args.output, args.target,
    #                                  args.debug, args.root))
    result = main()
    # result = run_pybackwards(args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:26.474253
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:27.334174
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:28.075630
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:29:38.599120
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from . import conf, exceptions
    from .settings import Settings
    from .tools import messages

    def mock_system_exit(code):
        raise SystemExit(code)


# Generated at 2022-06-23 22:29:44.542848
# Unit test for function main
def test_main():
    result = main()
    assert result == 1, "Should return non zero error code"
    result = main(['-i', 'test.py', '-o', 'output.py'])
    assert result == 1, "Should return non zero error code"
    result = main(['-i', 'test.py', '-o', 'output.py', '-t', 'py36'])
    assert result == 0, "Should return zero error code"

# Generated at 2022-06-23 22:29:45.142238
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:48.356883
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/sources', '-o', 'tests/sources', '-t', '2.7', '-r', 'tests', '-d']
    assert main() == 0

# Generated at 2022-06-23 22:29:58.261971
# Unit test for function main
def test_main():
    os.environ['INPUT'] = '../tests/fixtures/correct_syntax.py'
    os.environ['OUTPUT'] = '../tests/comp_files/correct_files/out.py'
    os.environ['TARGET'] = '3.5'
    os.system('python main.py')
    out = open(os.environ['OUTPUT'])
    res = out.read()

# Generated at 2022-06-23 22:30:03.104059
# Unit test for function main
def test_main():
    # Compile to Python 3.5
    command = 'python3 -m py_backwards input output -t 3.5'
    result = subprocess.run(command, shell=True, stdout=subprocess.PIPE)
    assert result.returncode == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:13.688633
# Unit test for function main
def test_main():
    from .compiler import compile_file
    from . import utils


# Generated at 2022-06-23 22:30:21.389875
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-t')
    sys.argv.append('3.5')
    sys.argv.append('-i')
    sys.argv.append('../tests/src/')
    sys.argv.append('-o')
    sys.argv.append('../tests/output/')
    sys.argv.append('-d')
    
    sys.argv.append('-r')
    sys.argv.append('../tests/src/')

    main()

if __name__ == '__main__':
    main()
    #test_main()

# Generated at 2022-06-23 22:30:31.079536
# Unit test for function main
def test_main():
    import tempfile
    from . import compiler
    from .conf import get_settings

    temp_dir = tempfile.TemporaryDirectory()

# Generated at 2022-06-23 22:30:33.235593
# Unit test for function main
def test_main():
  assert main() != -1

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:33.893008
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:35.500826
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-23 22:30:44.413794
# Unit test for function main

# Generated at 2022-06-23 22:30:48.906884
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'out',
                '-t', sys.version[:3]]
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'lol.py', '-o', 'out',
                '-t', sys.version[:3]]
    assert main() == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:49.400784
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:50.880945
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:51.395701
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:56.186943
# Unit test for function main
def test_main():
    global main
    from . import main
    import sys
    sys.argv = ['py-backwards', '--input', 'test/test_data', '--output', 'out', '--target', 'python-2', '--debug']
    main()


# Generated at 2022-06-23 22:30:58.021638
# Unit test for function main
def test_main():
    assert main() in [0, 1]

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:58.670018
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:30:59.550118
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:06.723469
# Unit test for function main
def test_main():
    class Wrapper:
        def __init__(self, path):
            self.path = path

        def open(self, mode):
            return open(self.path, mode)

    target = 'python3.8'
    args = Wrapper('./test_files/test_main.args')
    init_settings(args)
    compile_files(args.input, args.output, target, None)


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:31:08.760836
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'example/ex1.py', '-o', 'example/ex1.1.py', '-t', '2', '-r', 'example']
    assert main() == 0

# Generated at 2022-06-23 22:31:17.256291
# Unit test for function main
def test_main():
    main('-i', './tests/data/tests_dir_output/main.py', '-t', '3.6', '-o',
         './tests/data/tests_dir_output/main_output.py',
         '-r', './tests/data/tests_dir_output')
    with open('./tests/data/tests_dir_output/main_output.py') as f:
        assert f.read() == '1\n2\n3\n'

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:27.763947
# Unit test for function main
def test_main():
    try:
        if len(sys.argv) == 2 and sys.argv[1] == '-test':
            sys.argv.append('-i')
            sys.argv.append('example/good')
            sys.argv.append('-o')
            sys.argv.append('example/out')
            sys.argv.append('-t')
            sys.argv.append('3.4')
            sys.argv.append('-r')
            sys.argv.append('example')
            main()
            return True
        else:
            return False
    except SystemExit:
        return False

if __name__ == '__main__':
    if test_main():
        sys.exit(0)
    sys.exit(main())

# Generated at 2022-06-23 22:31:38.941894
# Unit test for function main
def test_main():
    import tempfile
    import os
    import shutil
    import time

    def check_output(basename, text):
        with open(os.path.join(test_directory, basename)) as f:
            assert f.read() == text
            f.close()

    def check_input(basename, text):
        with open(os.path.join(test_directory, basename)) as f:
            assert f.read() == text
            f.close()

    test_directory = tempfile.mkdtemp()

    with open(os.path.join(test_directory, 'input_1.py'), 'w+') as f:
        f.write('print(\'Hello World!\')')
        f.close()


# Generated at 2022-06-23 22:31:39.481811
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:46.443282
# Unit test for function main
def test_main():
    print('Test main')
    sys.argv.append('-i')
    sys.argv.append('test')
    sys.argv.append('-o')
    sys.argv.append('test')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    sys.argv.append('-r')
    sys.argv.append('test')
    sys.argv.append('-d')
    sys.argv.append('True')

    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:55.700979
# Unit test for function main
def test_main():
    class _Args:
        def __init__(self, input, output, target, root, debug):
            self.input = input
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    assert main(_Args(['test/test.py'], 'test/test2.py',
                      'py37', 'test/', False)) == 0
    assert main(_Args(['test/test.py'], 'test/test2.py',
                      'py36', 'test/', False)) == 0
    assert main(_Args(['test/test.py'], 'test/test2.py',
                      'py35', 'test/', False)) == 0

# Generated at 2022-06-23 22:31:56.917912
# Unit test for function main
def test_main():
    result1 = main()
    assert(result1 == 0)

# Generated at 2022-06-23 22:32:04.942920
# Unit test for function main
def test_main():
    # Test: Valid input, valid output, valid target, debug output, valid root
    sys.argv = ['py-backwards', '-i', 'samples', '-o', 'test-output', '-t', '2.7', '-d', '-r', 'samples' ]
    assert main() == 0

    # Test: Invalid input, invalid output, valid target, no debug output, no root
    sys.argv = ['py-backwards', '-i', 'invalid_input', '-o', 'invalid_output', '-t', '2.7']
    assert main() == 1

    # Test: Invalid input, valid output, valid target, no debug output, invalid root

# Generated at 2022-06-23 22:32:16.323429
# Unit test for function main
def test_main():
    from .tests.mock_classes import MockArgumentParser
    parser_mock = MockArgumentParser()
    import pybackwards.compiler

    # Test normal compilation
    def test_normal():
        args = parser_mock.parse_args({'input': ['tests/compiler_test.py'],
                                       'output': 'tests/output_test.py',
                                       'target': 'PY27',
                                       'root': 'tests'})
        init_settings(args)
        compiler_mock = pybackwards.compiler.Compiler()
        compiler_mock.compile_file = lambda _, in_, out, _1: (in_, out)
        pybackwards.compiler.Compiler = lambda *_, **__: compiler_mock
        assert main() == 0

    test_

# Generated at 2022-06-23 22:32:18.170462
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:23.794289
# Unit test for function main
def test_main():
    sys.argv = ['name.py', '-i', 'C:\\Users\\Василий\\PycharmProjects\\py_backwards\\tests\\compiler\\example.py', '-o', 'C:\\Users\\Василий\\PycharmProjects\\py_backwards\\tests\\compiler\\example1.py', '-t', '3.6']
    assert main() == 0


test_main()

# Generated at 2022-06-23 22:32:30.357984
# Unit test for function main
def test_main():
    input_mock = sys.modules['__main__'].__file__
    output_mock = input_mock.replace('py_backwards', 'py_backwards/tests')
    sys.argv = ['py-backwards', '-i', input_mock, '-o', output_mock, '-t',
                '2.7', '-r', '/Users/krzysztofSzewczyk/Desktop/py_backwards']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:35.273984
# Unit test for function main
def test_main():
    args = '-i "test/test_file.py" -o "test/output/" -t "3.5"'.split()
    test_args = sys.argv
    sys.argv = args
    code = main()
    sys.argv = test_args
    assert code == 0

# Generated at 2022-06-23 22:32:38.027111
# Unit test for function main
def test_main():
    input_ = ['testing/fixtures/example.py']
    output = 'testing/tmp'
    target = '2.7'
    assert main(input_, output, target) == 0

# Generated at 2022-06-23 22:32:49.558716
# Unit test for function main
def test_main():
    from . import utils
    from io import StringIO
    import sys
    import os

    ROOT = 'tests/input'
    TMP = 'tests/tmp'
    OUTPUT = os.path.join(TMP, 'main')
    sys.argv = ['py-backwards'] + [
        '-i', ROOT,
        '-o', OUTPUT,
        '-t', '2.7',
        '-r', ROOT]

    # Test compilation of file
    assert main() == 0
    assert os.path.exists(os.path.join(OUTPUT, 'hello.py'))

# Generated at 2022-06-23 22:32:53.426870
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i', 'test_input',
                '-o', 'test_output', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-23 22:33:04.200386
# Unit test for function main
def test_main():
    sys.argv = ['py_backwards.py',
                '-i', 'test/test.py',
                '-o', '__py_backwards_test_py/',
                '-t', '2.7',
                '-r', 'test/test_root/']
    assert main() == 0
    sys.argv = ['py_backwards.py',
                '-i', 'test/test.py',
                '-o', '__py_backwards_test2_py/',
                '-t', '3.4',
                '-r', 'test/test_root/']
    assert main() == 0

# Generated at 2022-06-23 22:33:07.869607
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('tests/example.py')
    sys.argv.append('-o')
    sys.argv.append('tests')
    sys.argv.append('-t')
    sys.argv.append('python3.4')
    sys.argv.append('-r')
    sys.argv.append('tests')
    main()

# Generated at 2022-06-23 22:33:08.459099
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:08.861050
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:33:17.324273
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test.py', '-o', './',
                '-t', '3.5', '-r', './']
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:17.840134
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:33:25.779271
# Unit test for function main
def test_main():
    from .testing import TestCompiler
    from unittest.mock import patch
    from . import settings
    import os

    src = os.path.join(os.path.dirname(__file__), 'test_sample.py')
    dest = os.path.join(os.path.dirname(__file__), 'test_sample.py')
    args = ['-i', src, '-o', dest, '-t', '3.5', '-r', '.']
    with patch.object(sys, 'argv', args):
        main()
    with open(dest, 'r') as f:
        expected = f.read()

# Generated at 2022-06-23 22:33:31.095241
# Unit test for function main
def test_main():
    import io
    import sys

    output = io.StringIO()
    sys.stdout = output

    input = io.StringIO('''
        def func():
            if True and not False:
                if 1 < 2:
                    print('hello')
                    import sys
                x = [1, 2, 3]
    ''')
    sys.stdin = input

    main()
    output = sys.stdout.getvalue().strip()
    assert "Hello" in output

    input = io.StringIO('''
        def func():
            x = dict()
            x['a'] = 'b'
    ''')
    sys.stdin = input

    main()
    output = sys.stdout.getvalue().strip()
    assert "Hello" in output

# Generated at 2022-06-23 22:33:32.280497
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:43.734827
# Unit test for function main
def test_main():
    input = '../examples/input'
    output = '../examples/output'
    root = '../examples'
    target = '2.7'
    debug = False

    init_settings
    try:
        for input_ in input:
            result = compile_files(input_, output,
                                   const.TARGETS[target],
                                   root)
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        assert False
    except exceptions.TransformationError as e:
        print(messages.transformation_error(e), file=sys.stderr)
        assert False

# Generated at 2022-06-23 22:33:53.050659
# Unit test for function main
def test_main():
    from subprocess import check_output
    assert check_output(['python', '-m', 'py_backwards', '-t', '3.5', '-i', 'py_backwards', '-o', '.'], universal_newlines=True).endswith('Compilation finished!\n')
    assert check_output(['python', '-m', 'py_backwards', '-t', '3.5', '-i', 'setup.py', '-o', '.'], universal_newlines=True).endswith('Compilation finished!\n')
    assert check_output(['python', '-m', 'py_backwards', '-t', '2.7', '-i', 'py_backwards', '-o', '.'], universal_newlines=True).endswith('Compilation finished!\n')

# Generated at 2022-06-23 22:33:57.655797
# Unit test for function main
def test_main():
    settings_value = settings
    try:
        sys.argv[1:] = ['--input', 'tests.py', '--target', '2.7', '--output', 'tests.pyc', '--debug']
        sys.exit(main())
    finally:
        sys.argv[1:] = []
        settings.update(settings_value)

# Generated at 2022-06-23 22:33:59.258733
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert(e == '0')

# Generated at 2022-06-23 22:34:09.200387
# Unit test for function main
def test_main():
    #empty command line
    sys.argv = [sys.argv[0], '-i', 'test_project/main.py', '-o', 'test_project/output', '-t', 'py34']
    main()
    sys.argv = [sys.argv[0], '-i', 'test_project/main.py', '-o', 'test_project/output', '-t', 'py35']
    main()
    sys.argv = [sys.argv[0], '-i', 'test_project/main.py', '-o', 'test_project/output', '-t', 'py36']
    main()

# Generated at 2022-06-23 22:34:09.830526
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:34:10.405485
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:34:19.410753
# Unit test for function main
def test_main():
    # Create a fake file path
    file_path = "test_fake_path"
    # Create a fake output path
    file_output = "test_fake_output"
    # Create a fake root path
    root = "test_fake_root"
    # Create a fake target
    target = "test_fake_target"
    # Create a fake debug
    debug = "test_fake_debug"

    sys.argv = ['', '-i', file_path, '-o', file_output, '-t', target, '-r', root, '-d', debug]
    assert main() == 0

# Generated at 2022-06-23 22:34:20.041444
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:20.698424
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:21.887849
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:22.712577
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:26.823420
# Unit test for function main
def test_main():
    try:
        main(['-i', 'fake_input', '-o', 'fake_output'])
    except SystemExit as err:
        assert err.code == 2

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:28.209467
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:28.845844
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:34:30.943906
# Unit test for function main
def test_main():
    # function calls main function with given parameters
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:35.000835
# Unit test for function main
def test_main():
    args = ['py-backwards', '-i', '../py_backwards/compiler.py', '-o', './output.py', '-t', '2.7', '-r', '../../']
    sys.argv = args
    main()

# Generated at 2022-06-23 22:34:36.067056
# Unit test for function main
def test_main():
    from . import tests
    tests.test_main()

# Generated at 2022-06-23 22:34:42.691615
# Unit test for function main
def test_main():
    with patch('backwards.cli.init_settings', autospec=True) as mock_init_settings, \
            patch('backwards.cli.compile_files', autospec=True) as mock_compile_files, \
            patch('backwards.cli.print', autospec=True) as mock_print:

        mock_init_settings.return_value = None
        mock_compile_files.return_value = None
        mock_print.return_value = None

        main()
        mock_print.assert_called()

# Generated at 2022-06-23 22:34:46.690839
# Unit test for function main
def test_main():
    sys.argv[1:] = [
        '-i', 'C:/Users/HP/Desktop/py-backwards/examples/ex1.py',
        'C:/Users/HP/Desktop/py-backwards/examples/ex2.py',
        '-o', 'C:/Users/HP/Desktop/py-backwards/examples/output/',
        '-t', 'python2', '-d'
    ]

# Generated at 2022-06-23 22:34:48.914059
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:49.902266
# Unit test for function main
def test_main():
    # TODO
    pass


# Generated at 2022-06-23 22:34:54.636808
# Unit test for function main
def test_main():
    args = ["-i", "assets/module1.py", "-o", "assets/module1_by.py",
            "-t", "3.5", "-r", "assets", "-d"]

    sys.argv[1:] = args
    sys.argv[0] = "py-backwards"
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:59.603623
# Unit test for function main
def test_main():
    program = os.path.abspath(sys.argv[0])
    result = subprocess.run(
        [program, '-h'],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    assert not result.returncode, 'Test failed'

# Generated at 2022-06-23 22:35:09.811882
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test-data/test_file.py', '-o',
                'test-data/output', '-t', 'python36']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', 'test-data/test_file.py', '-o',
                '_py-backwards/transforms/transform_files/files/', '-t',
                'python36']
    assert main() == 1
    sys.argv = [sys.argv[0], '-i',
                '_py-backwards/transforms/transform_files/files/', '-o',
                'test-data/output/', '-t', 'python36']
    assert main() == 0
    sys.arg

# Generated at 2022-06-23 22:35:15.971727
# Unit test for function main
def test_main():
    sys.argv = ['prog', '-i', '../examples/backwards.py', '-o', '../examples/backwards2.py', '-t', '2.7']
    main()
    assert open('../examples/backwards2.py').read() == open('../examples/backwards2_true.py').read()

# Generated at 2022-06-23 22:35:18.337530
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:35:19.453530
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:22.442962
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.argv = ['py-backwards.py','-i','./fixtures/test6.py', '-o',
                    '/py-backwards/fixtures/out.py', '-t','2']
        main()


# Generated at 2022-06-23 22:35:26.157834
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as e:
        main()
    assert e.type == SystemExit
    assert e.value.code == 2


# Generated at 2022-06-23 22:35:30.951035
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', os.path.abspath('./examples/orderdict.py'), '-o', './out', '-t', '2.7', '-d']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:32.765103
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:33.725560
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:37.795500
# Unit test for function main
def test_main():
    out = StringIO()
    sys.stderr = out
    main()
    output = out.getvalue().strip()
    assert output == 'usage: py-backwards [-h] -i INPUT [INPUT ...] -o OUTPUT -t TARGET [-r ROOT] [-d]\npy-backwards: error: the following arguments are required: -i/--input, -o/--output, -t/--target'

# Generated at 2022-06-23 22:35:42.779169
# Unit test for function main
def test_main():
    sys.argv =['py-backwards','-i','py3_syntax.py','-o','dist/py3_syntax.py','-t','2.7','-r','.']
    result = main()
    assert result == 0


# Generated at 2022-06-23 22:35:45.668257
# Unit test for function main
def test_main():
    assert main('~/Desktop/py-backwards/test/test.py',
                 '~/Desktop/py-backwards/test/test.py',
                 '~/Desktop/py-backwards/test/test.py') == 0
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:52.504950
# Unit test for function main
def test_main():
    import pytest
    from io import StringIO
    from contextlib import redirect_stdout
    with StringIO() as buf, redirect_stdout(buf):
        with pytest.raises(SystemExit):
            main()
        output = buf.getvalue()
        assert output == 'usage: py-backwards [-h] -i INPUT [INPUT ...] -o OUTPUT -t {2.7} ...\npy-backwards: error: the following arguments are required: -i/--input, -o/--output, -t/--target\n'

    with StringIO() as buf, redirect_stdout(buf):
        with pytest.raises(SystemExit):
            main(['-i', '1', '-t', '2.7', '-o', '2'])
        output = buf.getvalue()


# Generated at 2022-06-23 22:35:53.988242
# Unit test for function main
def test_main():
    init_settings(ArgumentParser().parse_args([]))
    assert main() == 0

# Generated at 2022-06-23 22:35:54.699320
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:55.339130
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:55.948077
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 22:35:58.539990
# Unit test for function main
def test_main():
    if sys.argv[0].endswith("py-backwards"):
        sys.argv[0] = "pytest"
        main()
        assert 0

# Generated at 2022-06-23 22:35:59.119549
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:00.581442
# Unit test for function main
def test_main():
    assert main() == 0


__all__ = ['main']

# Generated at 2022-06-23 22:36:04.084701
# Unit test for function main
def test_main():
    for testcase in [
        (['input'], 'output', '2.7', 1),
        (['input'], 'output', '3.5', 0),
        (['input'], 'output', '3.6', 0)
    ]:
        assert main(*testcase[:-1]) == testcase[-1]

# Generated at 2022-06-23 22:36:15.711309
# Unit test for function main
def test_main():
    """Unit test for function main()"""

    from tempfile import NamedTemporaryFile
    import shutil
    path = NamedTemporaryFile(mode='w+').name


# Generated at 2022-06-23 22:36:23.702484
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str, required=True,
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:36:29.960453
# Unit test for function main
def test_main():
    import os
    import pytest
    from .__main__ import main
    from .conf import settings
    from .utils import tmp_path
    from .runner import run_py
    from .compiler import compile_files
    from .exceptions import InputDoesntExists, InvalidInputOutput

    def _compile_files_mock(input, output, target, root):
        assert input == 'input'
        assert output == os.path.join(settings.OUTPUT_DIR, 'output.py')
        assert target == 'py36'
        assert root == None
        with tmp_path('output.py', 'input.py') as input_:
            with tmp_path('output.py') as output_:
                compile_files(input_, output_, target, root)
        return 2


# Generated at 2022-06-23 22:36:33.904264
# Unit test for function main
def test_main():
    sys.argv = ["", "-i", "test/impossible.py", "test/test.py", "-o", "test/output", "-t", "3.5"]
    assert main() == 0

if __name__ == "__main__":
    main()