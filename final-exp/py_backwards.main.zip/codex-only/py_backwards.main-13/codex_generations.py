

# Generated at 2022-06-23 22:26:34.142905
# Unit test for function main
def test_main():
    import pytest
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

# Generated at 2022-06-23 22:26:34.582308
# Unit test for function main
def test_main():
    init_settings()

# Generated at 2022-06-23 22:26:35.252620
# Unit test for function main
def test_main():
    init_settings(None)
    assert main() == 0

# Generated at 2022-06-23 22:26:38.081544
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i',
        'tests/test-sources/',
        '-o',
        'out/',
        '-t',
        '2.7'
    ]
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:26:38.505339
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:39.209419
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:26:41.244567
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:26:52.870922
# Unit test for function main
def test_main():
    test_parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    test_parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    test_parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    test_parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    test_parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    test_

# Generated at 2022-06-23 22:26:53.465169
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:26:58.956997
# Unit test for function main
def test_main():
    p = subprocess.Popen(
        ['python', '-m', 'py_backwards', '-i', 'py_backwards/tests/data/input.py',
         '-o', 'py_backwards/tests/data/output.py', '-t', '3.6'])
    assert p.returncode == 0, 'Program returns error'

# Generated at 2022-06-23 22:27:05.498904
# Unit test for function main
def test_main():
    from contextlib import contextmanager
    from io import StringIO
    from unittest.mock import patch, Mock

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
            
    with captured_output() as (out, err):
        main()
    output = out.getvalue().strip()
    assert output == "This program takes 2 or more arguments (1 given).\n"
    

# Generated at 2022-06-23 22:27:06.733881
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:27:13.097488
# Unit test for function main
def test_main():
    # Arrange
    sys.argv = ['py_backwards',
                '-i', 'test_data\\test.python',
                '-o', 'res.py',
                '-t', '3.6']

    # Act
    main()

    # Assert
    assert os.path.exists('res.py')

# Generated at 2022-06-23 22:27:14.411209
# Unit test for function main
def test_main():
    assert main() in [0, 1]

# Generated at 2022-06-23 22:27:22.484001
# Unit test for function main
def test_main():
    # Valid input
    input_args_valid = ["-i", "tests", "-o", "tests_compiled", "-t", "3.5", "-r", os.getcwd()]
    sys.argv[1:len(input_args_valid) + 1] = input_args_valid
    assert main() == 0
    # Invalid input
    input_args_invalid = ["-i", "tests_invalid", "-o", "tests_invalid_compiled", "-t", "3.5", "-r", os.getcwd()]
    sys.argv[1:len(input_args_invalid) + 1] = input_args_invalid
    assert main() == 1

# Generated at 2022-06-23 22:27:24.115298
# Unit test for function main
def test_main():
    assert main() == 0
    assert main("-i test_data/sources -o test_data/output -t 3.6") == 0

# Generated at 2022-06-23 22:27:25.110355
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    return [], []

# Generated at 2022-06-23 22:27:35.321425
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'py_backwards/tests/sample/normal_func.py',
                    '-o', 'temp_out', '-t', '2.7', '-d']
    assert main() == 0
    sys.argv[1:] = ['-i', 'py_backwards/tests/sample/bad_func.py',
                    '-o', 'temp_out', '-t', '2.7', '-d']
    assert main() == 1
    sys.argv[1:] = ['-i', 'py_backwards/tests/sample/bad_func.py',
                    '-o', 'temp_out', '-t', '2.7', '-d', '-r','py_backwards/tests/sample']
    assert main() == 1

# Generated at 2022-06-23 22:27:38.898125
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.6']
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:27:39.386035
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:27:46.308441
# Unit test for function main
def test_main():
    sys.argv = [
        sys.argv[0],
        '-i', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tests',
                           'input', 'test.py'),
        '-o', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tests',
                           'output'),
        '-t', '2.7'
    ]
    assert main() == 0

# Generated at 2022-06-23 22:27:47.200087
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:58.179337
# Unit test for function main

# Generated at 2022-06-23 22:28:03.096386
# Unit test for function main
def test_main():
    input_fold = "tests/input_tests"
    output_fold = input_fold + "_"
    target_ = "2.7"
    root_ = "root"
    debug_ = False
    asr_ = main()
    assert(asr_ == 0)



# Generated at 2022-06-23 22:28:13.627329
# Unit test for function main
def test_main():
    test_global = 0
    def test_compile_file(input_, output, target, root):
        global test_global
        test_global += 1
        print('Test {}, {}, {}, {}'.format(input_, output, target, root))
    with open(
            Path(__file__).parent / 'data' / 'compilation_test.py', 'w') as f:
        f.write('Test = 10')
    with open(
            Path(__file__).parent / 'data' / 'compilation_test2.py', 'w') as f:
        f.write('Test2 = 20')
    import py_backwards.compiler as compiler
    old_compile_files = compiler.compile_files
    compiler.compile_files = test_compile_file

# Generated at 2022-06-23 22:28:20.742916
# Unit test for function main
def test_main():
    sys.argv[1] = '-i'
    sys.argv[2] = 'test.py'
    sys.argv[3] = '-o'
    sys.argv[4] = 'out.py'
    sys.argv[5] = '-t'
    sys.argv[6] = '2'
    sys.argv[7] = '-r'
    sys.argv[8] = '.'
    sys.argv[9] = '-d'
    sys.argv[10] = 'True'
    main()

# Generated at 2022-06-23 22:28:21.360350
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:22.808194
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:30.932530
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.extend(['-i', 'test/examples/source.py', '-o',
                     'test/examples/output', '-t', '3.5'])
    main()
    sys.argv = sys.argv[:1]
    sys.argv.extend(['-i', 'test/examples/source.py', '-o',
                     'test/examples/output.py', '-t', '3.5'])
    main()

# Generated at 2022-06-23 22:28:36.826518
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', '../tests/backwards/data/input.py', '-o',
                '../tests/backwards/data/output.py', '-t', 'python2', '-r', 'root']
    
    assert main() == 0
    
if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:42.750272
# Unit test for function main
def test_main():
    # Test 1
    sys.argv = [sys.argv[0], '-i', './tests/test_input.py', '-o', './tests/test_output.py', '-t', '2.7', '-r', './tests/']
    assert main() == 0
    # Test 2
    sys.argv = [sys.argv[0], '-i', './tests/test_input.py', '-o', './tests/test_ouput.py', '-t', '2.7', '-r', './tests/']
    assert main() == 1

# Generated at 2022-06-23 22:28:43.145672
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:43.629249
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:45.348169
# Unit test for function main
def test_main():
    """Test main"""
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:55.163797
# Unit test for function main
def test_main():
    import os
    import shutil
    from typing import Set
    from .context import Context
    from .types import Module
    from . import utils

    def assert_file_contains(path: str, lines: Set[str]):
        with open(path) as f:
            for line, number in zip(f, range(1, len(lines) + 2)):
                assert line.strip() in lines, \
                    f"{path}:{number}: Line doesn't contain expected"

    def assert_file_doesnt_contain(path: str, lines: Set[str]):
        with open(path) as f:
            for line, number in zip(f, range(1, len(lines) + 2)):
                assert line.strip() not in lines, \
                    f"{path}:{number}: Line contains unexpected"

# Generated at 2022-06-23 22:28:58.734958
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_code', '-o', 'test_result',
                '-t', '3.5', '-r', 'test_code']
    assert main() == 0

# Generated at 2022-06-23 22:28:59.318662
# Unit test for function main
def test_main():
    print(main())

# Generated at 2022-06-23 22:29:02.309959
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_array.py', '-o', 'test_array.py', '-t', 'py27', '-r', 'test_root']
    main()

# Generated at 2022-06-23 22:29:02.675634
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:06.269439
# Unit test for function main
def test_main():
    inputs = [
        '-i',
        r'C:\Users\dudan\Desktop\py-backwards\integration_tests\input\tests.py',
        '-o',
        r'C:\Users\dudan\Desktop\py-backwards\integration_tests\output\tests.py',
        '-t',
        '3.4',
        '-r',
        r'C:\Users\dudan\Desktop\py-backwards\integration_tests\input',
    ]
    args = main()
    assert args == 0

# Generated at 2022-06-23 22:29:09.443187
# Unit test for function main
def test_main():
    init_settings(argparse.Namespace(
        input=['one', 'two'],
        output='out',
        target='3.4',
        root='sources_root',
        debug=True,
    ))
    assert main() == 0

# Generated at 2022-06-23 22:29:10.734214
# Unit test for function main
def test_main():
    global __name__
    __name__ = '__main__'
    assert main() == 0

# Generated at 2022-06-23 22:29:12.907185
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:17.136789
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '--input', 'test_compiler',
                '--output', 'test_compiler_out', '--target', 'python36']
    main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:22.636386
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i',
        'tests',
        '-o',
        '__pycache__',
        '-t',
        '3.3',
        '-r',
        '.'
    ]
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:23.684391
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:29:26.013757
# Unit test for function main
def test_main():
    init_settings(None)
    main()
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:27.332399
# Unit test for function main
def test_main():
    assert main() == 0
    assert main([]) == 2

# Generated at 2022-06-23 22:29:29.921060
# Unit test for function main
def test_main():
    print("Testing function main")
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:34.735444
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0],
                '-i', './input/py3/a.py',
                '-o', 'py2/a.py',
                '-t', 'Python 2.7']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:40.427943
# Unit test for function main
def test_main():
    stdin, stdout = sys.stdin, sys.stdout
    in_string = '''
3
3 -1 1
2 3 3
3 3 1
0 1 2
0 1 2

'''
    sys.stdin = StringIO(in_string)
    out = StringIO()
    sys.stdout = out
    solution(stdin, stdout)

    # print(out.getvalue(), file = sys.stderr)
    assert out.getvalue() == '10\n'
    sys.stdin, sys.stdout = stdin, stdout
    sys.stdin = stdin
    sys.stdout = stdout

# Generated at 2022-06-23 22:29:45.834423
# Unit test for function main
def test_main():
    if hasattr(sys, 'real_prefix'):
        print("Interpreter is in {} mode!")
        sys.exit(0)

    sys.argv = sys.argv[:1] + ["-i", "tests/simple.py", "-o", "tests/simple_new.py",
                               "-t", "3.5", "-r", "tests", "-d", ]
    assert main() == 0

# Generated at 2022-06-23 22:29:46.409350
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:56.129057
# Unit test for function main
def test_main():
    import subprocess
    import os
    import tempfile
    import shutil

    passed = True

    dir_path = os.path.dirname(os.path.realpath(__file__))

    tmp = tempfile.mkdtemp()

    # test compilation error
    try:
        subprocess.check_call(['py-backwards', '-i', dir_path + '/'
                                                  'data/code/error.py',
                               '-t', '2.7', '-o', tmp])
        passed = False
    except subprocess.CalledProcessError:
        pass

    if not passed:
        shutil.rmtree(tmp)
        print(messages.failed_test('test_main'))
        return

    # test transformation error

# Generated at 2022-06-23 22:30:07.095894
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from hypothesis import given, settings
    from hypothesis_datafixtures import data_fixtures
    from hypothesis_pytest.datafixtures import data
    from .fixtures import (
        test_files,
        output_file,
        target,
        root_folder,
        input_files,
    )
    from . import conf
    import os
    if conf.DEBUG:
        settings.load_profile("debug")


# Generated at 2022-06-23 22:30:15.227998
# Unit test for function main
def test_main():
    # target='python2.7'
    output = "output"
    input_ = "input"
    target = "python2.7"
    import pybackwards.compiler as compiler
    compiler.compile_files = lambda x, y, z, t: input_
    import pybackwards.messages as messages
    messages.compilation_result = lambda x: input_
    import pprint as pp
    sys.stdout = open("log.txt", "w")
    assert main()==0
    return 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:16.290719
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:17.914176
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:18.449141
# Unit test for function main
def test_main():
    assert main() is 1

# Generated at 2022-06-23 22:30:23.294077
# Unit test for function main
def test_main():
    from unittest.mock import patch
    import runpy
    with patch.object(runpy, 'run_path', return_value={}), \
         patch('builtins.print') as mock_print_function:
        assert main() == 0
        mock_print_function.assert_called_with("Everything's up to date")

# Generated at 2022-06-23 22:30:23.885824
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:30:24.565722
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        main()

# Generated at 2022-06-23 22:30:24.891122
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:30:30.275624
# Unit test for function main
def test_main():
    import sys
    import argparse
    from unittest.mock import patch

    def should_return_correct_value():
        with patch.object(sys, 'argv', ['py-backwards']):
            with patch('argparse.ArgumentParser.parse_args') as parse_mock:
                parse_mock.return_value = argparse.Namespace(
                    input = ['tests/files/input/2.py'],
                    output = 'tests/files/output',
                    target = 'python36',
                    root = None,
                    debug = False
                )
                assert main() == 0
                with open('tests/files/output/2.py') as f:
                    if f.read() != "3\n":
                        return False
                return True


# Generated at 2022-06-23 22:30:32.634904
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test.py', '-o', 'test/test.py',
                '-t', 'PY26']
    assert main() == 0

# Generated at 2022-06-23 22:30:34.658908
# Unit test for function main
def test_main():

    try:
        main()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-23 22:30:36.896123
# Unit test for function main
def test_main():
	assert main() == 0

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-23 22:30:40.587348
# Unit test for function main
def test_main():
    result = main(['-i', 'test/source/main.py', '-o', 'test/compiled/main.py', '-t', '3.0', '-r', 'test/source/'])
    assert (result == 0)

# Generated at 2022-06-23 22:30:49.253844
# Unit test for function main
def test_main():
    files = [
        'py-backwards/lib/utils.py',
        'py-backwards/lib/files.py',
        'py-backwards/settings.py',
    ]
    settings = {
        'input': files,
        'output': 'py3.5/lib',
        'target': '3.5',
        'root': 'lib'
    }

    args = main(settings)
    assert args.input == files
    assert args.output == 'py3.5/lib'
    assert args.target == '3.5'
    assert args.root == 'lib'

# Generated at 2022-06-23 22:30:51.140082
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:00.969595
# Unit test for function main

# Generated at 2022-06-23 22:31:12.876164
# Unit test for function main
def test_main():
    input1 = 'test_src/test_src/'
    input2 = 'test_src/test_src/file.py'
    output1 = 'test_src/test_src/output/'
    output2 = 'test_src/test_src/output/file.py'
    target = 'py35'
    root = 'test_src/'

    # Check input folder output folder
    sys.argv = ['py_backwards', '-i', input1, '-o', output1, '-t', target]
    assert main() == 0
    sys.argv = ['py_backwards', '-i', input1, '-o', output1, '-t', target,
                '-r', root]
    assert main() == 0

    # Check input file output folder

# Generated at 2022-06-23 22:31:17.373617
# Unit test for function main
def test_main():
    import argparse
    argparse.ArgumentParser.parse_args = lambda x, **kwargs: {
        'input': ['test/files_to_test/test_hello_world.py',
                  'test/files_to_test/tests/test_transformer.py'],
        'output': 'test/output',
        'target': 'py36',
        'debug': True,
        'root': 'test'
    }
    main()


# Generated at 2022-06-23 22:31:20.811360
# Unit test for function main
def test_main():
    """Test for main"""
    sys.argv = ['-i','tests/files/py_files/','tests/files/py27_files/','tests/files/py36_files/','-o','tests/files/out/','-t', 'py27']
    main()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:31:21.954163
# Unit test for function main
def test_main():
    assert main() != None


# Generated at 2022-06-23 22:31:30.069553
# Unit test for function main
def test_main():
    assert main() == 0


# Unit test
#def test_code_generation():
#    code = dedent('''
#    def foo(x, y):
#        return x + y
#
#    def bar(x: int, y: str) -> str:
#        return x * y
#    ''')
#    tree = ast.parse(code)
#    tree.__class__ = Module
#    result = generate_code(tree)
#    assert result == code


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:38.061613
# Unit test for function main
def test_main():
    original_sys_argv = sys.argv    # Save the original sys.argv to restore later
    sys.argv = ['./py-backwards', '-i','tests/fixtures/simple_program.py,', '-o','tests/fixtures/simple_program_compiled.py', '-t','3.6']
    assert main() == 0

    sys.argv = ['./py-backwards', '-i','tests/fixtures/simple_program.py,', '-o','tests/fixtures/simple_program_compiled.py', '-t','3.6']
    assert main() == 1


# Generated at 2022-06-23 22:31:46.903855
# Unit test for function main
def test_main():
    from pytest import raises
    import io
    import sys
    import os
    import contextlib
    from os import path
    from unittest import mock

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    # test exceptions

# Generated at 2022-06-23 22:31:48.317487
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:56.750303
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], "-i", "tests/test_data/test1.py", "-o", ".", "-t", "2"]
    main()

    sys.argv = [sys.argv[0], "-i", "tests/test_data/test1.py", "-o", ".", "-t", "3"]
    main()

    sys.argv = [sys.argv[0], "-i", "tests/test_data/test1.py", "-o", ".", "-t", "3.5"]
    main()

    sys.argv = [sys.argv[0], "-i", "tests/test_data/test1.py", "-o", ".", "-t", "3.6"]
    main()

# Generated at 2022-06-23 22:32:04.827102
# Unit test for function main
def test_main():
    # Target version not provided
    args = ['py-backwards', '-i', 'input', '-o', 'output', '-r', 'root']
    try:
        main(args)
        assert False
    except SystemExit:
        assert True

    # Target version not valid
    args = ['py-backwards', '-i', 'input', '-o', 'output',
            '-t', '3.3', '-r', 'root']
    try:
        main(args)
        assert False
    except SystemExit:
        assert True

    # Input file doesn't exists
    args = ['py-backwards', '-i', 'input', '-o', 'output',
            '-t', '3.2', '-r', 'root']
    sys.argv = args

# Generated at 2022-06-23 22:32:08.067512
# Unit test for function main
def test_main():
    arg_string = "-i example -o example_out -t python2 -r"
    sys.argv = arg_string.split()
    assert main() == 0


# Generated at 2022-06-23 22:32:08.694658
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:15.484808
# Unit test for function main
def test_main():
    input = "test_files/test_input.py"
    output = "test_files/test_input.py"
    target = "3_6"
    root = "test_files/root"
    debug = True

    sys.argv = ['py-backwards', '-i', input, '-o', output, '-t', target, '-r', root, '-d', debug]

    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:25.577220
# Unit test for function main
def test_main():
    from .compiler import compile_files
    from .conf import init_settings
    from . import exceptions

    def fake_compile_files(input_: str, output: str, target: tuple,
                           root: str) -> dict:
        fake_result = {'total': 3,
                       'compiled': 3,
                       'uncompiled': 0,
                       'failed': 0,
                       'skipped': ['file1', 'file2'],
                       'target': target,
                       'args': (input_, output, target, root)}
        return fake_result

    def fake_init_settings(args):
        pass

    old_compile_files = compile_files
    old_init_settings = init_settings

    compile_files = fake_compile_files
    init_settings = fake_init_settings


# Generated at 2022-06-23 22:32:36.698764
# Unit test for function main
def test_main():
    class Args(object):
        def __init__(self, input, output, target, root, debug):
            self.input = input
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    def check_main(input, output, target, root, debug, files_count):
        args = Args(input, output, target, root, debug)
        result = main(args)
        assert result == 0

        with open(output, 'r') as f:
            files = f.read().split('\n')
        assert files == ['test.py']+['']*files_count

    # With one file
    check_main(['test.py'], 'output.txt', '3.5', '', False, 0)

    # With folder
    os

# Generated at 2022-06-23 22:32:40.556238
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test\\test_files\\test_file.py',
                     '-o', 'compiled_file.py', '-t', '2.7', '-r',
                     'test\\test_files', '-d']
    assert main() == 0

# Generated at 2022-06-23 22:32:48.336790
# Unit test for function main
def test_main():
    # Unit test for function compile_files
    def test_compile_files():
        # This line isn't needed but we want this function to be unit tested
        # by itself so we are creating a fake main function
        def main():
            args = [None, None, None, 'example/example.py', 'out.py', '--verbose']
            result = compile_files(*args)
            print(messages.compilation_result(result))
        return main()
    test_compile_files()

# Generated at 2022-06-23 22:32:55.613459
# Unit test for function main
def test_main():
    # sys.argv.append("-i")
    # sys.argv.append("tests/sources/test.py")
    # sys.argv.append("-o")
    # sys.argv.append("tests/sources/output.py")
    # sys.argv.append("-t")
    # sys.argv.append("3.6")
    # result = main()
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:05.964758
# Unit test for function main
def test_main():
    args = sys.argv[1:]
    if "--test-module" in args:
        args.remove("--test-module")
    if "--test" in args:
        args.remove("--test")
    #test for function main for correct compilation
    sys.argv = ['py-backwards', '-i', 'tests/test_files/main.py', '-o',
                 'tests/test_files/output1.py', '-t', 'python2.7', '--test']
    assert main() == 0
    #test for function main for error in compilation

# Generated at 2022-06-23 22:33:14.740930
# Unit test for function main
def test_main():
    fake_file = 'fake'
    fake_folder = 'fake_folder'
    real_file = 'py-backwards/__init__.py'
    real_folder = 'py-backwards'

    # No args
    sys.argv = [sys.argv[0]]
    assert main() == 2

    # Wrong input
    sys.argv = [sys.argv[0], '-i', fake_file, '-o', fake_file, '-t', '27']
    assert main() == 1

    # Wrong output
    sys.argv = [sys.argv[0], '-i', real_file, '-o', fake_file, '-t', '27']
    assert main() == 1

    # Wrong target

# Generated at 2022-06-23 22:33:23.943466
# Unit test for function main
def test_main():
    from .tests.test_utils import mock_stdin, mock_sys_argv

    with mock_stdin(''), mock_sys_argv(''):
        assert main() == 1

    with mock_stdin(''), mock_sys_argv('-h'):
        assert main() == 0

    with mock_stdin(''), mock_sys_argv('-i {}'.format(__file__)):
        assert main() == 1

    with mock_stdin(''), mock_sys_argv('-i {} -o {}'.format(__file__, __file__)):
        assert main() == 1

    with mock_stdin(''), mock_sys_argv('-i {} -o {} -t 3.5'.format(__file__, __file__)):
        assert main() == 0



# Generated at 2022-06-23 22:33:26.412906
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'test.py',
                    '-o', 'test_out.py',
                    '-t', '3.5',
                    '-d',
                    '-r', './']
    main()

# Generated at 2022-06-23 22:33:31.649362
# Unit test for function main
def test_main():
    # Test for case when only input file is provided and there is compilation error
    class ExitClass(object):
        def __init__(self, exit_status):
            self.exit_status = exit_status

        def __enter__(self):
            pass

        def __exit__(self, exc_type, exc_value, traceback):
            print("%s" % exc_value)
            if isinstance(exc_value, SystemExit):
                self.exit_status = exc_value.code
            return True

    with ExitClass(1) as cm:
        sys.argv = ['py-backwards', '-i', 'tests/test_data/simple.py',
                    '-o', 'output/simple.py', '-t', 'py27']
        main()
        assert cm.exit_status == 1

    #

# Generated at 2022-06-23 22:33:35.617789
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', '/test/test.py', '-o', 'test/', '-t', '3.6']
    try:
        assert main() == 0
    except:
        main()

# Generated at 2022-06-23 22:33:36.431674
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:37.771284
# Unit test for function main
def test_main():
    import sys, os
    # TODO add test
    assert True

# Generated at 2022-06-23 22:33:48.160524
# Unit test for function main
def test_main():
    from tempfile import TemporaryDirectory
    from argparse import Namespace
    from . import utils
    def args(i, o, t):
        return Namespace(
            input=i, output=o, target=t, debug=False, root=None)

    with TemporaryDirectory() as tmpdirname:
        with open(utils.join(tmpdirname, 'file.py'), 'w') as f:
            f.write('print("hello, world!")')
        result = main()
        assert result == 0

        with open(utils.join(tmpdirname, 'file.py'), 'w') as f:
            f.write('print("hello, world!")')
        result = main(args(['file.py'], 'file.py', '3.5'))
        assert result == 1


# Generated at 2022-06-23 22:33:50.098360
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert(e.code == 1)

# Generated at 2022-06-23 22:33:50.697576
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:00.539726
# Unit test for function main
def test_main():
    def mock_parse_args(argv):
        parser = ArgumentParser()
        parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                            help='input file or folder')
        parser.add_argument('-o', '--output', type=str, required=True,
                            help='output file or folder')
        parser.add_argument('-t', '--target', type=str,
                            required=True, choices=const.TARGETS.keys(),
                            help='target python version')
        parser.add_argument('-r', '--root', type=str, required=False,
                            help='sources root')

# Generated at 2022-06-23 22:34:01.402511
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:34:04.749673
# Unit test for function main
def test_main():
    # TODO: fix this test
    pass
    #args = ["-i", "tests/test_data/test_main.py", "-o", "./", "-t", "3.6"]
    #assert main(args) == 1

# Generated at 2022-06-23 22:34:09.200961
# Unit test for function main
def test_main():
    try:
        assert sys.argv[1] == "tests"
    except (AssertionError, IndexError, AttributeError):
        assert False, "Unittest should be run from root directory."


if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-23 22:34:11.898758
# Unit test for function main
def test_main():
    sys.argv = [
        sys.argv[0],
        '-i',
        '.',
        '-o',
        '.',
        '-t',
        'python36'
    ]
    assert main() == 0

# Generated at 2022-06-23 22:34:21.693474
# Unit test for function main
def test_main():
    args = main.__wrapped__([])
    assert args == 2

    # args.input doesnt exists
    args = main.__wrapped__(['-i', 'nosuchfile', '-o', 'test.py', '-t', '3.6'])
    assert args == 1

    # input and output are a file
    args = main.__wrapped__(['-i', 'py', '-o', 'test.py', '-t', '3.6'])
    assert args == 1

    # input and output are directories
    args = main.__wrapped__(['-i', 'py', '-o', '.', '-t', '3.6'])
    assert args == 1

    # output directory doesnt exists

# Generated at 2022-06-23 22:34:22.712626
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:34:27.217803
# Unit test for function main
def test_main():
    # provide arguments to the argparser
    sys.argv[1:] = ['-i', 'a.py', '-o', 'b.py',
                    '-t', '2.7', '-r', '.', '-d']
    assert main() == 0


# Generated at 2022-06-23 22:34:36.109672
# Unit test for function main
def test_main():
    #when input file doesn't exist
    with pytest.raises(FileNotFoundError):
        args = argparse.Namespace(input = ['input.py'], output = 'output.py', target = '3.6', root = None, debug = False)
        init_settings(args)
        input_ = args.input[0]
        output_ = args.output
        target_ = const.TARGETS[args.target]

        result = compile_files(input_, output_, target_, args.root)

    #when input file is a directory
    with pytest.raises(IsADirectoryError):
        args = argparse.Namespace(input = ['tests/input'], output = 'tests/output.py', target = '3.6', root = None, debug = False)
        init_settings(args)

# Generated at 2022-06-23 22:34:38.291418
# Unit test for function main
def test_main():
    # test with no arguments
    #assert main() == parser.parse_args()
    return 0

# Generated at 2022-06-23 22:34:42.256104
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'project', '-o', 'project_lib',
                '-t', 'python_27']
    main()
    assert True


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:48.845643
# Unit test for function main
def test_main():
    from pyfakefs.fake_filesystem_unittest import TestCase
    from pyfakefs.fake_filesystem_unittest import Patcher
    from pyfakefs import fake_filesystem
    from unittest.mock import patch, MagicMock
    import argparse

    class MainTest(TestCase):
        def setUp(self):
            self.fs = fake_filesystem.FakeFilesystem()
            self.patch_open = patch('builtins.open', self.fs.open)
            self.patch_open.start()
            self.patch_os = patch('os.chmod', MagicMock())
            self.patch_os.start()
            sys.modules['py'] = MagicMock()
            self.parser = argparse.ArgumentParser()
            sys.modules['argparse'] = MagicMock()


# Generated at 2022-06-23 22:34:52.360513
# Unit test for function main
def test_main():
    class Args():
        def __init__(self):
            self.input = '.'
            self.output = '.cache'
            self.root = 'tests'
            self.target = '3.5'
    return main(Args())

# Generated at 2022-06-23 22:35:03.064314
# Unit test for function main
def test_main():
    sys.argv = ['prog', '-i', 'input', '-o', 'output', '-t', '3.5', '-r', 'root']
    sys.modules['pybackwards'].compiler.compile_files = None
    sys.modules['pybackwards'].conf.init_settings = None
    sys.modules['pybackwards'].exceptions.CompilationError = None
    sys.modules['pybackwards'].exceptions.TransformationError = None
    sys.modules['pybackwards'].exceptions.InputDoesntExists = None
    sys.modules['pybackwards'].exceptions.InvalidInputOutput = None
    sys.modules['pybackwards'].messages.syntax_error = None
    sys.modules['pybackwards'].messages.transformation_error = None
    sys

# Generated at 2022-06-23 22:35:10.897957
# Unit test for function main
def test_main():
    from contextlib import redirect_stderr, redirect_stdout

    from io import StringIO

    f = StringIO()

    # Valid result for multiple files
    with redirect_stderr(f):
        with redirect_stdout(f):
            assert main() == 0
            assert "There were 0 syntax errors" in f.getvalue()

    # Error with invalid output
    f = StringIO()
    with redirect_stderr(f):
        with redirect_stdout(f):
            assert main("example.py", "a/", "2.7") == 1
            assert "Invalid output folder" in f.getvalue()

    # Error with missing input
    f = StringIO()

# Generated at 2022-06-23 22:35:12.250121
# Unit test for function main
def test_main():
    assert main() == 0, 'not running'

# Generated at 2022-06-23 22:35:13.133108
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:20.376720
# Unit test for function main
def test_main():
    import pytest
    from os import remove
    from os.path import basename, splitext
    from typing import List

    def _main(*args: List[str], **kwargs) -> int:
        from .main import main
        return main()

    def get_output(filename: str) -> str:
        return f'{splitext(filename)[0]}_old{splitext(filename)[1]}'

    def remove_output(filename: str) -> None:
        remove(get_output(filename))

    # Correct compilation
    def test_correct_compilation():
        test_cases = [('test.py', 0), ('test', 0)]

# Generated at 2022-06-23 22:35:26.519091
# Unit test for function main
def test_main():
    try:
        assert os.path.exists(os.path.join(os.getcwd(), 'tests'))
    except AssertionError:
        return

    output_path = os.path.join(os.getcwd(), 'test_output')
    try:
        assert os.path.exists(output_path)
    except AssertionError:
        return

    # Test compilation of single file
    assert main([
        '-i', 'tests/single_file.py', '-o', output_path,
        '-t', 'python2.7'
    ]) == 0

    assert main([
        '-i', 'tests/single_file.py', '-o', output_path,
        '-t', 'python3.3'
    ]) == 0


# Generated at 2022-06-23 22:35:36.022193
# Unit test for function main
def test_main():
    input = 'py3test.py'
    output = 'pytest.py'
    root = 'pytest.py'
    target = 'python 2.7'
    assert main(input, output, target, root) == 0
    open('pytest.py', 'w').write('print(0)')
    assert main(input, output, target, root) == 1
    assert main(input, '', target, root) == 1
    assert main(input, output, '', root) == 1
    assert main('', output, target, root) == 1
    assert main(input, output, target, ' ') == 1
    print('All tests passed')


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:40.768698
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'output',
                '-t', 'python3.6', '-d']
    init_settings(main())


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:49.217827
# Unit test for function main
def test_main():
    sys.argv = ['main.py', '-i', 'main.py', '-o', 'abc', '-t', 'PY34',
                '-r', '.']
    assert main() == 1
    sys.argv = ['main.py', '-i', 'a.py', '-o', 'abc', '-t', 'PY34',
                '-r', '.']
    assert main() == 1
    sys.argv = ['main.py', '-i', 'main.py', '-o', 'abc', '-t', 'PY2']
    assert main() == 0

# Generated at 2022-06-23 22:35:53.784376
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',
				'-i', './tests/test-compilation/source/not_stdlib.py',
				'-t', '3',
			    '-o', './tests/test-compilation/source_gener.py']
    main()

#test_main()

# Generated at 2022-06-23 22:35:54.411678
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:36:03.790983
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:36:15.465977
# Unit test for function main
def test_main():
    from . import settings
    from . import const
    from . import messages
    from . import exceptions
    import pkgutil
    from os.path import dirname, join, abspath
    from .compiler import compile_files
    from .conf import init_settings
    settings.DEBUG = True
    for module_info in pkgutil.iter_modules([abspath(dirname(__file__))]):
        if module_info.name.startswith(const.TARGETS_PREFIX):
            settings.TARGET = module_info.name[len(const.TARGETS_PREFIX):]
            settings.ROOT = abspath(join(settings.PROJECT_ROOT, 'tests'))
            assert main() == 0
            settings.TARGET = None
    settings.DEBUG = False

# Generated at 2022-06-23 22:36:15.988152
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:36:21.008653
# Unit test for function main
def test_main():
    argv_backup = sys.argv
    sys.argv = ['py-backwards', '-i', 'examples/pip18/pip.py',
                '-o', 'pip18.py', '-t', '3.5', '-r', 'root/']
    assert main() == 0
    assert sys.argv == argv_backup

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:31.265311
# Unit test for function main
def test_main():
    # Test zero arguments
    sys.argv = ["pybackwards"]
    assert main() == 2

    # Test insufficient arguments
    sys.argv = ["pybackwards", "-i", "py3.py", "-o", "py2.py"]
    assert main() == 2

    # Test invalid target argument
    sys.argv = ["pybackwards", "-i", "py3.py", "-o", "py2.py", "-t", "python3"]
    assert main() == 2

    # Test non existing input file
    sys.argv = ["pybackwards", "-i", "py3.py", "-o", "py2.py", "-t", "python2"]
    assert main() == 1

    # Test non existing input file

# Generated at 2022-06-23 22:36:34.650200
# Unit test for function main
def test_main():
    assert main() == 0
    assert main('-i non_existent_file.py -o out.py -t 2.7'.split()) == 1
    sys.stdout = open('test_out.py', 'w')