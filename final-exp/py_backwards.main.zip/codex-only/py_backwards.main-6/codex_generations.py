

# Generated at 2022-06-23 22:26:36.503998
# Unit test for function main
def test_main():
    old_sys_argv = sys.argv
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py',
                '-t', '3.5', '-r', '.']
    main()
    sys.argv = old_sys_argv


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:26:37.102352
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:39.475803
# Unit test for function main
def test_main():
    args = ["-i", "input_msg.py", "-o", "output_msg.py", "-t", "3.6"]
    assert main(args) == 0

# Generated at 2022-06-23 22:26:40.328606
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:44.544452
# Unit test for function main
def test_main():
    args = ['py-backwards', '-i', 'test/input_test', '-o', 'test/output_test', '-t', '2.7', '-r', 'test/r_test']
    sys.argv = args
    main()
    pass

# Generated at 2022-06-23 22:26:45.248426
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:45.908820
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:51.512723
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'test', '-o', 'test', '-t', '2.7', '-r', 'test']
    assert main() == 0
    sys.argv = ['-i', 'test', '-o', 'test', '-t', '2.7', '-r', 'test', '-d']
    assert main() == 0

# Generated at 2022-06-23 22:26:53.168182
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:02.583077
# Unit test for function main
def test_main():
    from .test import TestCase
    from argparse import ArgumentParser

    class MockArgumentParser(ArgumentParser):
        def parse_args(self):
            class Args(object):
                input = 'test_input'
                output = 'test_output'
                target = 'test_target'
                root = None
                debug = False

            return Args()

    class MockSys:
        def __init__(self):
            self.stderr = []

        def stderr_write(self, text):
            self.stderr.append(text)

    class MockSettings:
        def __init__(self):
            self.debug = False

    class MockConst:
        class Target:
            def __init__(self):
                self.exc_info = None

            def __call__(self):
                raise

# Generated at 2022-06-23 22:27:03.787959
# Unit test for function main
def test_main():
    init_settings([])
    assert main() == 0


# Generated at 2022-06-23 22:27:06.341655
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'C:\\Users\\user\\_py-backwards\\test\\test_input\\test_input.py', '-o', 'C:\\test_output\\test_output.py', '-t', '3.6']
    assert main() == 0

# Generated at 2022-06-23 22:27:06.985951
# Unit test for function main
def test_main():
    assert main([]) == 0

# Generated at 2022-06-23 22:27:08.930144
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',
                '-i', 'test',
                '-o', 'result',
                '-t', 'python-3.6']
    assert main() == 0



# Generated at 2022-06-23 22:27:14.024832
# Unit test for function main
def test_main():
    # Test 1: Testing files
    sys.argv = ['py_backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/result.py', '-t', 'python36']
    assert main() == 0
    # Test 2: Testing folders
    sys.argv = ['py_backwards', '-i', 'test/test_files', '-o', 'test/test_files/result', '-t', 'python36']
    assert main() == 0
    # Test 3: Testing syntax error
    sys.argv = ['py_backwards', '-i', 'test/test_files/test_error.py', '-o', 'test/test_files/result_error.py', '-t', 'python36']
    assert main() == 1
    #

# Generated at 2022-06-23 22:27:14.472234
# Unit test for function main
def test_main():
    return None

# Generated at 2022-06-23 22:27:16.030008
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_input', '-o', 'test_output', '-t', '2']
    assert main() == 0


# Generated at 2022-06-23 22:27:24.527073
# Unit test for function main
def test_main():
    from .test.utils import FakeStdStreams
    from .exceptions import CompilationError

    with FakeStdStreams() as (out, err):
        assert(main() == 0)
        assert(out.getvalue() == 'All files were compiled or skipped.')
        assert(err.getvalue() == '')

    with FakeStdStreams() as (out, err):
        assert(main(['-i', 'main.py', '-o', 'out', '-t', '3.5', '-r', 'fake']) == 0)
        assert(out.getvalue() == 'All files were compiled or skipped.')
        assert(err.getvalue() == '')


# Generated at 2022-06-23 22:27:25.008431
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:25.457549
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:27:25.962285
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:27:36.144201
# Unit test for function main
def test_main():
    args = ['-i', 'tests/fixtures/code.py',
            '-o', 'tests/fixtures/output.py',
            '-t', '3.3',
            '-r', 'tests/fixtures']

    import argparse
    argv = sys.argv
    sys.argv = [''] + args
    parser = ArgumentParser()
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')

# Generated at 2022-06-23 22:27:41.404503
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/data/input_file.py',
                    '-o', 'tests/data/output_folder',
                    '-t', '2.7',
                    '-r', 'tests/data']
    exit_code = main()
    assert exit_code == 0

    sys.argv[1:] = ['-i', 'tests/data/input_file.py',
                    '-o', 'tests/data/output_folder',
                    '-t', '2.7',
                    '-r', 'tests/data']
    exit_code = main()
    assert exit_code == 0

    assert 0 == main()

# Generated at 2022-06-23 22:27:43.289107
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:48.375310
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from argparse import ArgumentParser
    import sys
    with patch.object(sys, 'argv', ["py-backwards","-i", "test_files/example.py", "-o", "test_files/result.py", "-t", "3.3", "-r", "test_files/"]):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:58.932750
# Unit test for function main
def test_main():
    # Create object for directory path
    class Args:
        def __init__(self, input_, output, target, root=None, debug=False):
            self.input = input_
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    # Tests for checking expected compilations in different cases
    test_passing = Args(['./tests/test_files/compiler/'], './tests/out/', '3.5')
    test_passing_single_file = Args(['./tests/test_files/compiler/'], './tests/out/',
                                    '3.5', debug=True)

# Generated at 2022-06-23 22:27:59.785591
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:28:01.810922
# Unit test for function main
def test_main():
    assert main() == 1

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:12.647868
# Unit test for function main
def test_main():
    from . import test

    def mock_argparse(input: list, output: str, target: str, root: str,
                      debug: bool):
        def parse_args():
            class Args:
                def __init__(self, input_, output_, target_, root_, debug_):
                    self.input = input_
                    self.output = output_
                    self.target = target_
                    self.root = root_
                    self.debug = debug_

            return Args(input_=input, output_=output, target_=target,
                        root_=root, debug_=debug)
        return parse_args

    # Test with proper input

# Generated at 2022-06-23 22:28:14.208067
# Unit test for function main
def test_main():
    assert main(["file.py", "file.py", "output.py", "2.7"]) == 1

# Generated at 2022-06-23 22:28:23.228641
# Unit test for function main
def test_main():

    ## Case 1:
    ## Compile u.py, the code is valid.
    ## Assert: main() == 0
    with open('u.py', 'w') as u:
        u.write("#!/usr/bin/env python\nprint(2)\n")
    args = ['./u.py', '-i', 'u.py', '-o', 'u.py', '-t', '3.3']
    assert main(args) == 0

    ## Case 2:
    ## Compile u.py, the code is not valid.
    ## Assert: main() == 1
    with open('u.py', 'w') as u:
        u.write("#!/usr/bin/env python\n2\n")

# Generated at 2022-06-23 22:28:27.234856
# Unit test for function main

# Generated at 2022-06-23 22:28:38.942477
# Unit test for function main
def test_main():
    # Test for all types of possible errors
    sys.argv = ['py-backwards', '-i', 'a', '-o', 'b', '-t', 'c', '-r', 'd']
    assert main() == 1
    sys.argv = ['py-backwards', '-i', 'a', '-o', 'b', '-t', 'c', '-r', 'd']
    sys.argv[-1] = '-d'
    assert main() == 1
    sys.argv = ['py-backwards', '-i', 'a', '-o', 'b', '-t', 'c', '-r', 'd']
    sys.argv[-2] = '-d'
    assert main() == 1
    # Tests for no errors

# Generated at 2022-06-23 22:28:47.670813
# Unit test for function main
def test_main():
    from .conf import settings
    from . import log

    sys.argv = ['py-backwards', '-i', 'example', '-o', 'example.out',
                '-t', 'py25', '-r', '.']
    assert main() == 0
    assert settings.input == ['example']
    assert settings.is_input_recursive
    assert settings.output == 'example.out'
    assert settings.is_output_recursive
    assert settings.target == 'py25'
    assert settings.debug
    assert settings.root == '.'
    assert log.prefix == 'example'
    assert log.debug_enabled

    sys.argv = ['py-backwards', '-i', 'example', '-o', 'example.out',
                '-t', 'py25', '-d']

# Generated at 2022-06-23 22:28:48.261721
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:49.284223
# Unit test for function main
def test_main():
    print("Test main")
    assert main() == 0

# Generated at 2022-06-23 22:28:50.176921
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:51.069493
# Unit test for function main
def test_main():
    print("main function test")
    assert main() == 0

# Generated at 2022-06-23 22:28:52.074304
# Unit test for function main
def test_main():
    # Not tested yet
    assert False

# Generated at 2022-06-23 22:28:58.853474
# Unit test for function main
def test_main():
    from .conf import settings
    from . import utils
    from .transforms.int_to_bool import int_to_bool_transform
    from .transforms.literal_concat import literal_concat_transform
    from .transforms.f_strings import f_strings_transform
    from .transforms.async_def import async_def_transform

    with utils.TemporaryDirectory() as td:
        input_file = td.get_file_path('test.py')
        output_file = td.get_file_path('test_out.py')
        test_file = td.get_file_path('test_file.txt')


# Generated at 2022-06-23 22:29:01.843932
# Unit test for function main
def test_main():
    """
    Test of function main, when the user provides an input that doesn't
    exist, the system returns a input doesn't exist error.
    """
    result=main()
    assert result == 1, "input doesn't exist"


# Generated at 2022-06-23 22:29:09.439615
# Unit test for function main
def test_main():
    input_tests = [
        (['input'], 'input'),
        (['input', 'output'], 'input, output'),
        (['input', '--output', 'output'], 'input, --output, output'),
        (['input', '-o', 'output'], 'input, -o, output')
    ]
    output_tests = [
        (['-o', 'output'], 'output'),
        (['--output', 'output'], 'output')
    ]
    target_tests = [
        (['-t', '3.2'], '3.2'),
        (['--target', '3.2'], '3.2')
    ]

# Generated at 2022-06-23 22:29:10.064443
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:10.681089
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:29:11.280876
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:16.335411
# Unit test for function main
def test_main():
    args = ['-i', '1.py', '-o', '1.py', '-t', '2.7', '-r', '.', '-d']
    sys.argv = args
    
    main()
    
if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-23 22:29:17.272689
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:29:17.843207
# Unit test for function main
def test_main():
    print(main())

# Generated at 2022-06-23 22:29:26.089429
# Unit test for function main

# Generated at 2022-06-23 22:29:26.813653
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:29:37.721736
# Unit test for function main
def test_main():
    if __name__ == 'main':
        raise RuntimeError('main must not be called from main.py')

    sys.argv.append('-i')
    sys.argv.append('a')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    sys.argv.append('-o')
    sys.argv.append('b')
    sys.argv.append('-r')
    sys.argv.append('b')

    import io
    stdout, stderr = sys.stdout, sys.stderr
    try:
        sys.stdout = io.StringIO()
        sys.stderr = io.StringIO()
        assert main() == 1
    finally:
        sys.stdout = stdout

# Generated at 2022-06-23 22:29:47.010162
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "tests", "-o", "tests", "-t", "2.7", "-r", "tests/resources"]
    assert main() == 0
    sys.argv = ["py-backwards", "-i", "tests", "-o", "tests", "-t", "2.7", "-r", "tests/resources", "-d"]
    assert main() == 0
    sys.argv = ["py-backwards", "-i", "tests", "-o", "tests", "-t", "2.7", "-r", "tests/resources"]
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:50.640764
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/resources/functions.py', '-o',
                'tests/resources/functions_out.py', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-23 22:30:00.758886
# Unit test for function main
def test_main():
    class MockInput:
        def __init__(self, args: list):
            self.args = args

    def mock_compile_files(input_: str, output: str, target: int,
                           root: str):
        return (input_, output, target, root)

    sys.argv = MockInput(['', '-i', '1', '-o', '2', '-t', '3.5', '-r',
                          '4'])
    exceptions.CompilationError = ValueError
    exceptions.TransformationError = TypeError
    exceptions.InputDoesntExists = LookupError
    exceptions.InvalidInputOutput = FileExistsError
    compile_files = mock_compile_files
    assert main() == 0

# Generated at 2022-06-23 22:30:11.187479
# Unit test for function main
def test_main():
    def _arg_parse(a:(str, str, str)):
        (input_, output, target) = a #type: ignore
        parser = ArgumentParser()
        parser.add_argument('-i', '--input', type=str,nargs='+', required=True,
                            help='input file or folder')
        parser.add_argument('-o', '--output', type=str, required=True,
                            help='output file or folder')
        parser.add_argument('-t', '--target', type=str, required=True,
                            choices=const.TARGETS.keys(),
                            help='target python version')

        args = parser.parse_args(['-i', input_, '-o', output, '-t', target])
        init_settings(args)
        return args

    args

# Generated at 2022-06-23 22:30:20.477137
# Unit test for function main
def test_main():
    from os import remove

    def run_py_backwards(*args):
        from io import StringIO

        backup = sys.stdout
        sys.stdout = StringIO()
        try:
            main(*args)
        except SystemExit as e:
            assert e.code == 0
        finally:
            sys.stdout = backup

    remove('tests/recursive_loop_output.py')
    run_py_backwards(
        ['-i', 'tests/recursive_loop.py', '-o',
         'tests/recursive_loop_output.py',
         '-t', 'py36'])
    with open('tests/recursive_loop_output.py') as f:
        s = f.read()
        assert 'async for' not in s
        assert 'async def' not in s


# Generated at 2022-06-23 22:30:30.241157
# Unit test for function main
def test_main():
    import os
    import shutil
    from . import settings

    # Test wrong input
    sys.argv = ['py-backwards.py', '--input', 'test.py', '--output', 'out.py']

    assert main() == 2

    # Now with right arguments
    sys.argv = ['py-backwards.py',
                '--input', 'test.py',
                '--output', 'out.py',
                '--target', '3.5']

    assert main() == 1

    sys.argv = ['py-backwards.py',
                '--input', 'test.py',
                '--output', 'out.py',
                '--target', '3.5',
                '--debug']
    assert main() == 1


# Generated at 2022-06-23 22:30:30.999462
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:41.960784
# Unit test for function main
def test_main():
    """Function that checks if the output of main is correct.
    """
    test_args = ['-i', 'tests/foo.py', '-o', 'tests/foo_output.py',
                 '-t', '2', '-r', 'tests/']

    saved_stdout = sys.stdout
    string_io = io.StringIO()
    sys.stdout = string_io
    sys.argv = [sys.argv[0]] + test_args
    main()
    sys.stdout = saved_stdout
    output = string_io.getvalue()

    test_result = 'tests/result.txt'
    with open(test_result) as f:
        result = f.read()

    assert output == result

    os.remove('tests/foo_output.py')

# Generated at 2022-06-23 22:30:42.677165
# Unit test for function main
def test_main():
    assert main() != 1

# Generated at 2022-06-23 22:30:43.655264
# Unit test for function main
def test_main():
    assert(main() == 1)

# Generated at 2022-06-23 22:30:55.141162
# Unit test for function main
def test_main():
    sys.argv = ['PyBackwards', '-i', 'test/test.py', '-o', 'test/output/', '-t', '2.7']
    assert main() == 0
    sys.argv = ['PyBackwards', '-i', 'test/test.py', '-o', 'test/output/', '-t', '2.7', '-r', 'test']
    assert main() == 0
    sys.argv = ['PyBackwards', '-i', 'test/test.py', '-o', 'test/output/', '-t', '2.7', '-r', 'root']
    assert main() == 1

# Generated at 2022-06-23 22:30:56.974352
# Unit test for function main
def test_main():
    with patch.object(sys, "argv", ["", "--input", "test/test1.py", "--output", "test/", "--target", "2.5"]):
        assert main() == 0

# Generated at 2022-06-23 22:30:57.971447
# Unit test for function main
def test_main():
    init()
    result = main()


# Generated at 2022-06-23 22:31:09.685660
# Unit test for function main
def test_main():
    def test_output(input_, output, target, root, debug,
                    expected_input, expected_output, expected_result):
        sys.argv = ['py-backwards',
                    '-i', input_,
                    '-o', output,
                    '-t', target,
                    '-r', root,
                    '-d', debug]
        try:
            res = main()
        except SystemExit:
            res = 0
        assert res == expected_result
        assert args.input == expected_input
        assert args.output == expected_output

    args: argparse.Namespace
    args = argparse.Namespace()

    test_output("test1", "test2", "2.7", "root", False,
                [] if sys.platform == "linux" else "test1", "test2", 0)


# Generated at 2022-06-23 22:31:11.558714
# Unit test for function main
def test_main():
    pass

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-23 22:31:12.222465
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:31:13.471151
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-23 22:31:19.743716
# Unit test for function main
def test_main():
    try:
        sys.argv = ['./py-backwards', '-i', 'test_inputs/function.py',
                    '-o', 'test_inputs/function_out.py',
                    '-t', 'Python36', '-r', 'test_inputs/']
        assert main() == 0
    except Exception as e:
        print(e)
        assert False

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:21.896666
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:32.917173
# Unit test for function main
def test_main():
    import tempfile
    import os
    import shutil

    def setup():
        inputs = os.path.join(tempfile.gettempdir(), 'inputs')
        os.mkdir(inputs)
        outputs = os.path.join(tempfile.gettempdir(), 'outputs')
        os.mkdir(outputs)
        return inputs, outputs

    def teardown():
        shutil.rmtree(tempfile.gettempdir())

    def case1(inputs_dir, outputs_dir):
        # one input, one output
        inp = 'a.py'
        print('def f() -> int: return 1', file=open(os.path.join(inputs_dir, inp), 'w'))

# Generated at 2022-06-23 22:31:40.219365
# Unit test for function main
def test_main():
    """
    main() unit test
    """
    from . import settings
    target = '2.7'
    settings.debug = True
    root = '.'

    class Args:
        def __init__(self):
            pass

        def parse_args(self):
            self.input = ['tests/sample_files/input_2.7', 'tests/sample_files/input_2.7/test.py']
            self.output = '.'
            self.target = target
            self.root = root
            self.debug = settings.debug
    args = Args()
    args = args.parse_args()
    init_settings(args)

# Generated at 2022-06-23 22:31:44.059142
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', './tests/data/assertions.py', '-o', './tests/data/assertions_out.py', '-t', '3.5', '-r', './tests/data']
    return main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:45.084834
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:47.709457
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'testing/test_files', '-o', 'output.py',
                    '-t', '3.6', '-r', 'App']
    assert main() == 0


# Generated at 2022-06-23 22:31:49.083517
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:51.733430
# Unit test for function main
def test_main():
    colorama.init()
    sys.argv[1:] = ['-i', 'test/modules/decorators.py',
                    '-o', 'test/output/decorators.py',
                    '-t', '3.4']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:52.219461
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:53.812781
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit): # type: ignore
        main()
    

# Generated at 2022-06-23 22:32:02.041752
# Unit test for function main
def test_main():
    import subprocess
    import os
    import shutil
    from .utils import get_files_from_dir, get_files_from_zip
    from .directory import Directory
    from .transformer import SourceFile
    from .conf import ROOT_DIR, TARGET_ROOT, TARGET_VERSION
    from .utils import replace_extension
    from .compiler import transform_file

    examples_filepath = os.path.join(ROOT_DIR, 'examples.zip')

    files = (
        get_files_from_zip(examples_filepath, '.py') +
        get_files_from_dir(os.path.join(ROOT_DIR, 'examples'))
    )

    target_dir = Directory(TARGET_ROOT)
    files_to_compile = []

# Generated at 2022-06-23 22:32:12.818457
# Unit test for function main
def test_main():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import remove
    from os.path import join

    def test(test_name: str, test_input: str, test_output: str,
             test_target: str, test_root: str,
             expected_output: str) -> bool:
        parser = ArgumentParser(
            'py-backwards',
            description='Python to python compiler that allows you to use some '
                        'Python 3.6 features in older versions.')
        parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                            help='input file or folder')
        parser.add_argument('-o', '--output', type=str, required=True,
                            help='output file or folder')
        parser.add_

# Generated at 2022-06-23 22:32:17.174062
# Unit test for function main
def test_main():
    # Args
    # -i,--input: test_files
    # -o,--output: /tmp/test_files_compiled
    # -t,--target: 3.7
    # -r,--root: ./test_files
    # -d,--debug: True
    main()

# Generated at 2022-06-23 22:32:19.029845
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:26.743910
# Unit test for function main
def test_main():
    # Check input doesnt exists
    sys.argv = ['', '-i', 'doesnt_exists.py', '-o', 'output.py',
                '-t', 'target', '-r', 'root']
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Check invalid output
    with tempfile.TemporaryDirectory() as tmpdirname:
        dirname = os.path.join(tmpdirname, 'dir')
        os.mkdir(dirname)

# Generated at 2022-06-23 22:32:27.206544
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:32:38.683068
# Unit test for function main
def test_main():
    # invalid input
    main_ = main()
    assert main_ == 2

    # invalid output
    _ = main(['-i', 'test.py', '-o', 'test1.py', '-t', '2.7'])
    assert _ == 1

    # invalid target
    _ = main(['-i', 'test.py', '-o', 'test1.py', '-t', '3'])
    assert _ == 2

    # no errors in a file
    _ = main(['-i', 'test.py', '-o', 'test1.py', '-t', '2.7'])
    assert _ == 0

    # syntax error

# Generated at 2022-06-23 22:32:39.530266
# Unit test for function main
def test_main():
    assert(main() == 0)
    return

# Generated at 2022-06-23 22:32:49.431574
# Unit test for function main
def test_main():
    class Args:
        input = ['test/test.py']
        output = 'out'
        target = '3.6'
        debug = False
        root = None
    args = Args()
    assert sys.argv == ['__main__.py']
    sys.argv = ['__main__.py', '-i', args.input[0], '-o', args.output, '-t',
                args.target, '-r', args.root]
    args = main()
    assert args.input == ['test/test.py']
    assert args.output == 'out'

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:50.344656
# Unit test for function main
def test_main():
    assert main() == 0



# Generated at 2022-06-23 22:32:53.911749
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'test_file_backwards.py',
                    '-o', 'output.py']
    assert main() == 0

# Generated at 2022-06-23 22:32:54.675513
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:00.131631
# Unit test for function main
def test_main():
    args = ['py-backwards', '-i', '../datas/sample/sample.py', '-o', '../datas/output', '-t', '2.7', '-r', '../datas/sample/sample.py']
    try:
        main()
    except SystemExit:
        pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:03.915367
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i',
        'tests/test_input/',
        'tests/test_output_3.6/',
        '-t',
        '3.6'
    ]
    assert main() == 0

# Generated at 2022-06-23 22:33:07.351233
# Unit test for function main
def test_main():
    testArgs = ['-i', './tests/test_input/print.py', '-o', './tests/test_output', '-t', '2.7',
                '-r', './tests/test_input']
    saveArgv = sys.argv
    sys.argv = testArgs
    assert main() == 0
    sys.argv = saveArgv

# Generated at 2022-06-23 22:33:11.323344
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',
                '-i', 'tests',
                '-o', 'tests/compilation_result',
                '-t', 'python35',
                '-r', 'tests/sources']
    assert main() == 0

# Generated at 2022-06-23 22:33:14.152032
# Unit test for function main
def test_main():
    os.system('coverage run -m py_backwards --input tests/input '
             '--output tests/output --target 2.6 --debug')

# Generated at 2022-06-23 22:33:20.013501
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('/')
    sys.argv.append('-o')
    sys.argv.append('/')
    sys.argv.append('-t')
    sys.argv.append('Python 3.5')
    sys.argv.append('-r')
    sys.argv.append('/')
    sys.argv.append('-d')
    main()

# Generated at 2022-06-23 22:33:20.897038
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:29.787324
# Unit test for function main
def test_main():
    from .compiler import compile_files
    from .conf import init_settings, settings
    
    def test_main_file():
        
        # Test 1 - execution of main function with input and output being files
        args_input = ['../py_backwards/examples/input.py']
        args_output = '../py_backwards/examples/output.py'
        args_target = '3.4'
        args_root = None
        args_debug = False
        
        assert main(args_input, args_output, args_target, args_root, args_debug) == 0
    
    def test_main_folder():
        
        # Test 2 - execution of main function with input and output being folders
        args_input = ['../py_backwards/examples/input']

# Generated at 2022-06-23 22:33:37.695162
# Unit test for function main
def test_main():
    # testing for invalid option
    sys.argv = ['py-backwards', '-l', '-o', 'out']
    if main() == 0:
        raise AssertionError

    # testing for required argument missing
    sys.argv = ['py-backwards', '-o', 'out']
    if main() == 0:
        raise AssertionError

    # testing for wrong file name
    sys.argv = ['py-backwards', '-i', 'not_existing_file', '-o', 'out']
    if main() == 0:
        raise AssertionError

    # testing for wrong file type
    sys.argv = ['py-backwards', '-i', 'tests/main_tests/__init__.py', '-o', 'out']
    if main() == 0:
        raise Ass

# Generated at 2022-06-23 22:33:48.115812
# Unit test for function main

# Generated at 2022-06-23 22:33:58.291389
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append('tests/test_cases/async_functions_django_error.py')
    sys.argv.append('-o')
    sys.argv.append('tests/test_cases/results/async_functions_django_error.py')
    sys.argv.append('-t')
    sys.argv.append('3.6')
    sys.argv.append('-r')
    sys.argv.append('/home/python-backwards/tests/test_cases')
    sys.argv.append('-d')
    sys.argv.append('true')
    main()


# Generated at 2022-06-23 22:33:59.545766
# Unit test for function main
def test_main():
    compilator = main()
    assert compilator == 0

# Generated at 2022-06-23 22:34:05.115371
# Unit test for function main
def test_main():
    # Positive test
    sys.argv = ['', '-i', 'py_backwards/tests/data/', '-o',
                'py_backwards/tests/data_out', '-t', '2.7', '-r', '/home/travis/build/NikitaSmorodnikov/py_backwards']
    assert main() == 0
    # Negative test
    sys.argv = ['', '-i', 'py_backwards/tests/data/invalid', '-o',
                'py_backwards/tests/data_out', '-t', '2.7', '-r',
                '/home/travis/build/NikitaSmorodnikov/py_backwards']
    assert main() != 0
    # Negative test

# Generated at 2022-06-23 22:34:09.541383
# Unit test for function main
def test_main():
    test_args = ["-i", "./tests/data/example_files/example.py", "-o", "./tests/data/example_files/example_target.py", "-t", "3.6", "-r", "./tests/"]
    assert main(test_args) == 0


# Generated at 2022-06-23 22:34:10.115517
# Unit test for function main
def test_main():
    assert main()==0

# Generated at 2022-06-23 22:34:21.085871
# Unit test for function main
def test_main():
    import pytest
    from pytest import raises
    from io import StringIO

    with raises(SystemExit):
        main(['py-backwards', '--help'])
    with raises(SystemExit):
        main(['py-backwards', '--input', 'input', '--output', 'output',
              '--target', '3.5'])

    with pytest.raises(SystemExit) as excinfo:
        main(['py-backwards', '--input', 'input', '--output', 'output',
              '--target', '3.5'])
    assert excinfo.value.code == 0


# Generated at 2022-06-23 22:34:32.026074
# Unit test for function main
def test_main():
    import os
    import rmtree
    import subprocess
    from .conf import settings
    from . import utils

    def _execute(input_filepath, output_filepath, target_version,
                 expected_result, test_root_dir):
        # Copy input into dir for testing
        input_filepath_copy = os.path.join(test_root_dir, 'input.py')
        assert input_filepath_copy != input_filepath
        shutil.copy(input_filepath, input_filepath_copy)

        # Run py-backwards

# Generated at 2022-06-23 22:34:35.153050
# Unit test for function main
def test_main():
    assert 1 == main(['py-backwards', '-i', 'file', '-o', 'folder'])
    assert 0 == main(['py-backwards', '-i', 'file', '-o', 'folder', '-t', '2.7'])

# Generated at 2022-06-23 22:34:45.492386
# Unit test for function main
def test_main():
    """
    At first, function main is tested with correct data, i.e. with correct input
    file (or files) (or folder) and correct output file (or folder). Then,
    firstly, wrong/bad output file (or folder) is tested and then wrong/bad
    input file (or folder) and then both wrong/bad input and output files
    (or folders) are tested.

    :return: None.
    """

    # Correct input file
    sys.argv = ['py-backwards', '-i', 'tests/test_files/simple_test.py', '-o',
                'output.txt', '-t', 'python-3.5']
    assert main() == 0
    assert os.path.isfile('output.txt')
    os.remove('output.txt')

    # Case with two input files.

# Generated at 2022-06-23 22:34:51.104729
# Unit test for function main
def test_main():
    argv = ['-i', 'tests/data/example.py', '-o', '/tmp/example_2.py', '-t', '2.6']
    try:
        main(argv)
        assert True
    except exceptions.CompilationError:
        assert True
    except exceptions.TransformationError as e:
        assert False

# Generated at 2022-06-23 22:34:52.093075
# Unit test for function main
def test_main():
    res = main()
    assert res == 0

# Generated at 2022-06-23 22:34:56.131223
# Unit test for function main
def test_main():
    # Create fake argv object
    sys.argv = [sys.argv[0], '-i', 'fakeinput', '-o',
                'fakeoutput', '-t', '3.5', '-r', '/fake/root',
                '-d']

    # Call main function
    result = main()
    assert result == 0

# Generated at 2022-06-23 22:34:57.577445
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:07.578871
# Unit test for function main
def test_main():
    input_files = 'test_files/settings_test_files/argparse.py'
    output_files = 'test_files/settings_test_files/tmp.py'
    target = '3.3'
    root = 'test_files/settings_test_files'
    cmd_res = 0

    sys.argv = ['py-backwards', '-i', input_files, '-o', output_files,
                '-t', target, '-r', root]
    with patch('sys.argv', sys.argv):
        with patch('sys.exit') as exit_mock:
            main()
            exit_mock.assert_called_once_with(cmd_res)


# Generated at 2022-06-23 22:35:08.939931
# Unit test for function main
def test_main():
    init_settings(ArgumentParser().parse_args([]))
    assert main() == 0

# Generated at 2022-06-23 22:35:18.506081
# Unit test for function main
def test_main():
    testArgs = ['-i', 'test_files/test_file.py', '-o', 'test_files/out.py', '-t', '2.7']
    sys.argv = sys.argv[:1] + testArgs
    assert main() == 0

    testArgs = ['-i', 'test_files/test_folder', '-o', 'test_files/test_folder_out', '-t', '2.4']
    sys.argv = sys.argv[:1] + testArgs
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:24.986887
# Unit test for function main
def test_main():
    import subprocess

    sys.argv = ['py-backwards',
                '-i', '../tests/fixtures/example_input.py',
                '-o', '../tests/fixtures/example_output.py',
                '-t', '3.5',
                '-r', '../tests']
    assert subprocess.run([sys.executable, '-m', 'backwards']).returncode == 0

    sys.argv = ['py-backwards',
                '-i', '../tests/fixtures/invalid/nonexistent_source.py',
                '-o', '../tests/fixtures/invalid/nonexistent_source_output.py',
                '-t', '3.5',
                '-r', '../tests']

# Generated at 2022-06-23 22:35:25.747441
# Unit test for function main
def test_main():
    returncode=main()
    assert returncode == 0

# Generated at 2022-06-23 22:35:28.170631
# Unit test for function main
def test_main():
    from tempfile import TemporaryDirectory, NamedTemporaryFile
    from .conf import settings, target


# Generated at 2022-06-23 22:35:38.591611
# Unit test for function main
def test_main():
    import unittest
    import unittest.mock
    class TestMain(unittest.TestCase):
        def setUp(self):
            self.argv = None
            self.parser = None

        def test_empty_input_returns_1(self):
            self.argv = ['-i', '', '-o', 'output.py', '-t', 'py27']
            with self.assertRaises(SystemExit) as err:
                with unittest.mock.patch('sys.argv', self.argv):
                    main()
            self.assertEqual(1, err.exception.code)


# Generated at 2022-06-23 22:35:47.341863
# Unit test for function main

# Generated at 2022-06-23 22:35:49.230439
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:50.019034
# Unit test for function main
def test_main():
    parser = main()
    assert parser == 0

# Generated at 2022-06-23 22:36:00.581472
# Unit test for function main
def test_main():
    # Test for an empty argument
    sys.argv = ['py-backwards']
    assert main() == 1

    # Test for argparse error
    sys.argv = ['py-backwards.py', '-p', 'bla-bla']
    assert main() == 2

    # Test for input doesn't exists
    sys.argv = ['py-backwards.py', '-i', 'bla-bla', '-o', 't.py',
                '-t', '3.5']
    assert main() == 1

    # Test for valid arguments
    sys.argv = ['py-backwards.py', '-i', 'test/test_data', '-o', 't.py',
                '-t', '3.5']
    assert main() == 0

    # Test for valid arguments with debug

# Generated at 2022-06-23 22:36:04.466320
# Unit test for function main
def test_main():
    # Test for input does not exists
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.6',
                '-d']
    assert main() == 1

    # Test for invalid input and output
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.6',
                '-d']
    assert main() == 1

    # Test for permission error
    sys.argv = ['py-backwards', '-i', 'tests/data/tests/examples/hello.py', '-o',
                '/output.py', '-t', '3.6', '-d']
    assert main() == 1

    # Test for syntax erorr
    sys

# Generated at 2022-06-23 22:36:06.475137
# Unit test for function main
def test_main():
    from unittest import TestCase

    class MainTests(TestCase):

        def test_compile_to_python37(self):
            main()

    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:08.534234
# Unit test for function main
def test_main():
    pass # TODO write the test

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:17.343696
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append('test_files/test.py')
    sys.argv.append('-o')
    sys.argv.append('test_files/unit_test_output')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    assert main() == 0
    sys.argv[4] = 'test_files/test1.py'
    assert main() == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:19.889699
# Unit test for function main
def test_main():
    sys.argv = ["", "-i", "tests/data/example.py", "-o", "tests/data/out", "-t", "2.7", "-r", "tests/data/"]
    assert main() == 0

# Generated at 2022-06-23 22:36:20.410749
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:30.912571
# Unit test for function main
def test_main():
    test_cases = [
        {'input': ['-i', 'tests/test_files/test1.py'],
         'target': ['3.6'],
         'output': ['-o', 'tests/test_files/output/'],
         'root': ['-r', 'tests/test_files/']},
        {'input': ['-i', 'tests/'],
         'target': ['2.7'],
         'output': ['-o', 'tests/test_files/output/'],
         'root': ['-r', 'tests/test_files/'],
         'debug': ['-d']}
    ]
    for test_case in test_cases:
        old_argv = sys.argv

# Generated at 2022-06-23 22:36:35.688975
# Unit test for function main
def test_main():
    # test arguments input and output
    result = main()
    assert(result == 1)

    # test arguments
    sys.argv[1:] = ['-i', '1.py', '-o', '2.py', '-t', '3.4', '-r', '4.py']
    result = main()
    assert(result == 1)