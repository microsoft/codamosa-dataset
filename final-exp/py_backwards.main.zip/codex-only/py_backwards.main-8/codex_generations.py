

# Generated at 2022-06-23 22:26:36.869011
# Unit test for function main
def test_main():
    from unittest.mock import patch
    with patch('sys.argv', ['py-backwards', '-i', 'test.py',
                            '-o', 'test.py.out', '-t', '27', '-r', '.']):
        assert main() == 0

# Generated at 2022-06-23 22:26:37.468325
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:26:39.142399
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        assert main() == 0


# Generated at 2022-06-23 22:26:44.436285
# Unit test for function main
def test_main():
    sys.argv = [
        sys.argv[0],
        '--input', 'inputs/test_function.py',
        '--output', 'inputs/test_function.py',
        '--target', 'python27',
        '--debug',
    ]
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:26:45.196554
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:56.421006
# Unit test for function main
def test_main():
    # Test 1. If target version is not valid, then it should return an error.
    sys.argv[1] = '-i'
    sys.argv[2] = 'input1.py'
    sys.argv[3] = '-o'
    sys.argv[4] = 'output.py'
    sys.argv[5] = '-t'
    sys.argv[6] = '0.0'
    assert main() == 1
    # Test 2. If there's no input file, then it should return an error.
    sys.argv[1] = '-i'
    sys.argv[2] = ''
    sys.argv[3] = '-o'
    sys.argv[4] = 'output.py'

# Generated at 2022-06-23 22:26:59.791954
# Unit test for function main
def test_main():
    # Argparse does not properly handle exception in main function
    try:
        main()
    except SystemExit:
        pass
    except Exception:
        assert False
    else:
        assert False


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:09.461390
# Unit test for function main
def test_main():
    import tempfile

    with tempfile.TemporaryDirectory() as dir:
        with open(dir+'/code.py', mode='w') as f:
            f.write('l = list(range(10))\nfor i in l:\n    print(i)')
        sys.argv = [sys.argv[0], '-i', dir+'/code.py', '-o', dir+'/code2.py', '-t', 'py37', '-d', '-r', '.']

        assert main() == 0
        assert open(dir+'/code2.py', mode='r').read() == '''l = list(range(10))
for i in l:
    print(i)
'''

# Generated at 2022-06-23 22:27:09.992922
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:20.198315
# Unit test for function main
def test_main():
    import pytest
    sys.argv = ['', '-i', 'test_input/test_input.py', '-o', 'test_output/', '-t',
                'py36', '-r', './test_input/', '-d']
    assert main() == 0

    sys.argv = ['', '-i', 'test_input/test_input.py', '-o', 'test_output/', '-t',
                'py33', '-r', './test_input/', '-d']
    assert main() == 1

    sys.argv = ['', '-i', 'test_input/test_input.py', '-o', 'test_output', '-t',
                'py36', '-r', './test_input/', '-d']
    assert main()

# Generated at 2022-06-23 22:27:21.778708
# Unit test for function main
def test_main():
    main = Main()
    assert main.main() == 1

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:28.144417
# Unit test for function main
def test_main():
    from . import settings
    import os
    import shutil

# Generated at 2022-06-23 22:27:31.556024
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/sources.py', '-o', 'test/output.py',
                '-t', '2.7', '-r', 'test']
    assert main() == 0

# Generated at 2022-06-23 22:27:32.844022
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:36.573907
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', 'foo.py', '-o', 'bar.py', '-t', '3.4']
    assert main() == 0


# Generated at 2022-06-23 22:27:37.184672
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:41.142615
# Unit test for function main
def test_main():
    import io
    import sys
    from contextlib import redirect_stdout

    def test_help():
        try:
            main()
        except SystemExit as e:
            assert e.code == 2

    def test_input_doesnt_exists():
        try:
            help_args = ['-t', '27', '-i', 'input.py', '-o', 'output.py']
            main(help_args)
        except SystemExit as e:
            assert e.code == 1

    def test_output_is_invalid():
        try:
            help_args = ['-t', '27', '-i', 'input.py', '-o', 'input.py']
            main(help_args)
        except SystemExit as e:
            assert e.code == 1


# Generated at 2022-06-23 22:27:42.229642
# Unit test for function main
def test_main():
    init_settings(None)
    main()

# Generated at 2022-06-23 22:27:44.327033
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass
    except BaseException:
        assert False
    else:
        assert True

# Generated at 2022-06-23 22:27:46.117588
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:52.756747
# Unit test for function main
def test_main():
    sys.argv[1:] = [
        '-t', 'py34',
        '-i', 'tests/fixtures/test_module.py',
        '-o', 'tests/fixtures/test_module.out.py',
        '-r', 'tests/fixtures/test_module.py',
        '--debug'
    ]

    result = main()
    assert result == 0

# Generated at 2022-06-23 22:27:55.187865
# Unit test for function main
def test_main():
    class Object:
        pass
    args = Object()
    args.input = [__file__]
    args.output = '/tmp'
    args.target = 'PY36'
 

# Generated at 2022-06-23 22:27:56.903084
# Unit test for function main
def test_main():
    # expected behavior, if target version is earlier then python version
    try:
        main()
    except SystemExit as e:
        assert e.code == 1

# Generated at 2022-06-23 22:28:01.132754
# Unit test for function main
def test_main():
    from tempfile import TemporaryDirectory
    from .compiler import compile_file
    from pathlib import Path
    from .conf import settings
    import shutil
    import os

    i = Path(__file__).parent / 'temp'
    o = TemporaryDirectory()

# Generated at 2022-06-23 22:28:03.139371
# Unit test for function main
def test_main():
    result = main()
    assert result is not None
    assert isinstance(result, int)
    assert result == 1

# Generated at 2022-06-23 22:28:13.667368
# Unit test for function main
def test_main():
    # Check if main function returns 1 when raises exception
    with patch('pybackwards.compiler.compile_files') as mock_compile_files:
        mock_compile_files.side_effect = exceptions.InputDoesntExists
        args = AttributeDict({
            'input': 'input', 'output': 'output', 'target': 'python-2.7', 'root': 'root'})
        assert main(args) == 1

    # Check if main function returns 0 when doesn't raises exception
    with patch('pybackwards.compiler.compile_files') as mock_compile_files:
        mock_compile_files.return_value = 1
        args = AttributeDict({
            'input': 'input', 'output': 'output', 'target': 'python-2.7', 'root': 'root'})


# Generated at 2022-06-23 22:28:15.184412
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:23.263228
# Unit test for function main
def test_main():
    source_path = os.path.join(os.path.dirname(__file__), 'examples')
    input_path = os.path.join(source_path, 'py3.6', 'list_comp.py')
    output_path = os.path.join(source_path, 'out.py')
    args = ArgumentParser().parse_args(['-i', input_path, '-o', output_path,
                                       '-r', source_path,
                                       '-t', 'Python 2.7'])
    init_settings(args)
    result = compile_files(input_path, output_path,
                           const.TARGETS[args.target], args.root)
    assert result == 1, result

# Generated at 2022-06-23 22:28:32.735998
# Unit test for function main
def test_main():
    import pytest
    from .compiler import _tests
    from . import exceptions

    pytest.main([__file__, "-v"])

    with pytest.raises(SystemExit) as exc_info:
        main()
    assert exc_info.value.code == 2

    class Input:
        def __init__(self, arg, arg_value):
            self.arg = arg
            self.arg_value = arg_value

        def __iter__(self):
            return iter((self.arg, self.arg_value))

    class MockedCompiledFile:
        def __init__(self, filepath):
            self.filepath = filepath

        def __str__(self):
            return self.filepath


# Generated at 2022-06-23 22:28:38.735606
# Unit test for function main
def test_main():
    from io import StringIO
    from sys import exit

    def fake_main():
        sys.exit = exit
        main()
    sys.exit = lambda code: None
    output = StringIO()
    sys.stdout = output
    fake_main()
    assert output.getvalue() == 'Backwards is not used in a script!\n'

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:40.797106
# Unit test for function main
def test_main():
    assert main() != 1
    if not os.path.exists("py2.py"):
        assert False

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:28:41.308532
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:28:42.327762
# Unit test for function main
def test_main():
    assert 0 == main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:45.812788
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/test_files/test.py',
                '-o', 'tests/test_files/test_result.py',
                '-t', '3.6']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:46.550017
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:56.021476
# Unit test for function main
def test_main():
    try:
        from docopt import docopt
    except:
        return
    help_string = '''Usage:
    py-backwards [options] -h | --help
    py-backwards [options] --input=<path> --output=<path>

Options:
    -h --help                         Show this screen.
    -i <path> --input=<file-path>     Input file or folder.
    -o <path> --output=<file-path>    Output file or folder.
    -t <version> --target=<version>   Target Python version.
    -r <path> --root=<path>           Sources root.
    -d --debug                        Enable debug output.
'''
    arguments = docopt(help_string, version='py-backwards 1.0')

# Generated at 2022-06-23 22:28:56.618684
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:59.838705
# Unit test for function main
def test_main():
    sys.argv[1:] = '-i test -o test/test.py -t 3.5'.split()
    assert not main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:03.752098
# Unit test for function main
def test_main():
    filename = 'unittest_main.py'
    with open(filename, 'w') as f:
        f.write("""
        print('''Hello world!''')
        """)
    sys.argv = ['', '-i', filename, '-o', 'unittest_main_out.py',
                '-t', '2.7', '-r', '.']
    assert main() == 0
    with open(filename) as f:
        assert f.read() == '\nprint("Hello world!")\n'


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:29:05.262595
# Unit test for function main
def test_main():
    import py_backwards
    assert main() == 0

# Generated at 2022-06-23 22:29:06.258359
# Unit test for function main
def test_main():
    pass
    # TODO

# Generated at 2022-06-23 22:29:16.242120
# Unit test for function main
def test_main():
    args = ArgumentParser('py-backwards')
    args.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    args.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    args.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    args.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    args.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')


# Generated at 2022-06-23 22:29:16.833011
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:17.752933
# Unit test for function main
def test_main():
    assert main() == 0 or 1

# Generated at 2022-06-23 22:29:23.163794
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', './tests/test_data/test_input/sample.py', '-o', './tests/test_data/test_output/sample.py',
                    '-t', '2.7']
    sys.argv.append('-r')
    sys.argv.append('../../')

    assert (main() == 0)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:25.075274
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/folder', '-o', 'test/output',
                '-t', '2.7', '-r', 'test']
    sys.argv.extend(['-d'])
    assert main() == 0

# Generated at 2022-06-23 22:29:25.858910
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:29:32.113508
# Unit test for function main
def test_main():
    """
    This unit test checks if main function works properly.
    """
    try:
        sys.argv = ['', '-t', '3.6', '-i', 'tests', '-o', 'test_output', '-r', 'tests', '-d']
        assert main() == 0
    except AssertionError:
        raise AssertionError('test_main() failed as expected')

# Generated at 2022-06-23 22:29:32.581689
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:36.445936
# Unit test for function main
def test_main():
    from .conf import settings
    from . import const

    settings.args = None
    settings.target = const.TARGETS['3.6']

    # Should fail
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

# Generated at 2022-06-23 22:29:42.443602
# Unit test for function main
def test_main():
    #test where input file or folder exists and output folder exists
    sys.argv = ['py_backwards.py','-i', 'test/test_data/test.py',
                '-o', 'test/test_data/test_result','-t', '2.7', '-r', 'test/test_data/test_result/test']
    assert main() == 0

    #test where input file or folder exists and output folder doesn't exist
    sys.argv = ['py_backwards.py','-i', 'test/test_data/test.py',
                '-o', 'test/test_data/test_result1','-t', '2.7', '-r', 'test/test_data/test_result/test']
    assert main() == 0

    #test where input file or folder doesn't exist


# Generated at 2022-06-23 22:29:45.088295
# Unit test for function main
def test_main():
    main()
    main(["-t", "3.6", "-i", "../test/test_files/test1.py", "-o", "result"])

# Generated at 2022-06-23 22:29:52.846559
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', '/Users/brunocasamassa/PycharmProjects/py-backwards/tests/example/example.py',
                    '-o', '/Users/brunocasamassa/PycharmProjects/py-backwards/tests/example',
                    '-t', 'py27', '-r',
                    '/Users/brunocasamassa/PycharmProjects/py-backwards/tests/example/example.py', '-d']
    print(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:04.081670
# Unit test for function main
def test_main():
    # these tests are not valid
    input = ['temp/test/test.py']
    output = 'temp/out'
    target = '3.3'
    root = 'temp/test'
    debug = False
    expected = 0
    assert main(input, output, target, root, debug) == expected
    expected = 0
    assert main(input, output, target, root, debug) == expected
    expected = 0
    assert main(input, output, target, root, debug) == expected
    expected = 0
    assert main(input, output, target, root, debug) == expected
    expected = 0
    assert main(input, output, target, root, debug) == expected
    expected = 0
    assert main(input, output, target, root, debug) == expected
    expected = 0

# Generated at 2022-06-23 22:30:04.697709
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:30:05.316770
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:09.507105
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/files/example.py', '-o', 'tests/files/example_result.py', '-t', '2.7', '-d', '-r', 'tests/files']
    main()
    assert True

# Generated at 2022-06-23 22:30:19.297239
# Unit test for function main
def test_main():
    import os
    test_dir = os.path.dirname(os.path.abspath(__file__))
    error_dir = os.path.join(test_dir, 'test_data', 'error')
    src_dir = os.path.join(test_dir, 'test_data', 'source')
    out_dir = os.path.join(test_dir, 'test_data', 'output')


# Generated at 2022-06-23 22:30:20.251472
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:20.859374
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:30:30.633523
# Unit test for function main
def test_main():
    import sys
    from io import StringIO
    from .config import Settings
    from . import exceptions
    args = type(
        '', (), {}
    )()
    args.input = ['test/test_compiler.py']
    args.output = '.'
    args.target = '2'
    args.root = '.'
    args.debug = True
    old_stdout = sys.stdout
    buff = StringIO()
    sys.stdout = buff
    init_settings(args)
    try:
        main()
    except exceptions.InputDoesntExists:
        pass
    buff.close()
    sys.stdout = old_stdout
    assert buff.getvalue() == 'Compiled: test/test_compiler.py\n'
    assert Settings.DEBUG is True


# Generated at 2022-06-23 22:30:41.772968
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'some_file.py',
                '-o', 'some_file.py', '-t', '2.7']
    assert main() == 1
    sys.argv = ['py-backwards', '-i', 'some_file.py',
                '-o', 'some_file.py', '-t', '3']
    assert main() == 1
    sys.argv = ['py-backwards', '-i', 'some_file.py',
                '-o', 'some_file.py', '-t', '3.4']
    assert main() == 1

# Generated at 2022-06-23 22:30:45.979265
# Unit test for function main
def test_main():
    import pytest
    sys.argv = ['dummy', '-i', 'tests/sample.py', '-o', 'out', '-t', '3.6']
    assert main() == 0

# Generated at 2022-06-23 22:30:56.657815
# Unit test for function main
def test_main():
    import os
    from pathlib import Path
    
    in_path = Path(os.path.abspath(__file__)).parent.parent / "tests" / "input"
    out_path = Path(os.path.abspath(__file__)).parent.parent / "tests" / "output"
    target_path = Path(os.path.abspath(__file__)).parent.parent / "tests" / "target"
    
    my_args = ['-i', str(in_path), '-o', str(out_path), '-t', 'python36', '-r', str(in_path)]
    
    main(my_args)
    
    assert os.path.isfile(str(out_path / Path('main.py')))

# Generated at 2022-06-23 22:30:59.198213
# Unit test for function main
def test_main():
    sys.argv = 'py-backwards -i test -o test -t 3.5'.split()
    #no assert because of sys.exit
    test_compile_files()


# Generated at 2022-06-23 22:31:00.338703
# Unit test for function main
def test_main():
    assert main()


# Generated at 2022-06-23 22:31:12.219878
# Unit test for function main
def test_main():
    # Testing happy path
    assert main() == 0

    # Testing compilation error
    assert main(['test/test_files/test_code.py', '-o', 'test.py',
                 '-t', 'py36', '-r']) == 1

    # Testing tranformation error
    assert main(['test/test_files/test_code.py', '-o', 'test.py',
                 '-t', 'py35', '-r']) == 1

    # Testing input doesnt exists
    assert main(['bla', '-o', 'test.py',
                 '-t', 'py36', '-r']) == 1

    # Testing invalid output

# Generated at 2022-06-23 22:31:15.235955
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        return 0
    return 1

# Asserts that unit test for function main is correct
assert test_main() == 0

# Generated at 2022-06-23 22:31:20.018922
# Unit test for function main
def test_main():
    sys.argv.pop(0)
    sys.argv.append("-i")
    sys.argv.append("py_backwards/tests/test_data/test_data.py")
    sys.argv.append("-o")
    sys.argv.append("/tmp/test_output.py")
    sys.argv.append("-t")
    sys.argv.append("3.5")
    main()
    assert True

# Generated at 2022-06-23 22:31:23.302744
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/fixtures/tuple_args.py',
                '-o', 'build',
                '-t', '3.4']
    main()

# Generated at 2022-06-23 22:31:28.527019
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'src/tests/resources/sample_1.py', '-o', 'dist/sample_1.py', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-23 22:31:38.062216
# Unit test for function main
def test_main():
    tmpdir = tempfile.TemporaryDirectory(prefix='py-backward-test-')
    with open(os.path.join(tmpdir.name, 'test.py'), 'w') as f:
        f.write('''def test():
    return {1, 2}
''')
    try:
        assert main(['test.py'], tmpdir.name) == 1
    finally:
        tmpdir.cleanup()

    tmpdir = tempfile.TemporaryDirectory(prefix='py-backward-test-')
    with open(os.path.join(tmpdir.name, 'test.py'), 'w') as f:
        f.write('def test():\n'
                '    return 1 + 2 * 3.0\n')

# Generated at 2022-06-23 22:31:39.927361
# Unit test for function main
def test_main():
    # TODO: написать тесты
    pass

# Generated at 2022-06-23 22:31:49.044323
# Unit test for function main
def test_main():
    from .cli import main

    class MockArgParser:
        def __init__(self):
            self.input = ["./input"]
            self.output = "./output"
            self.target = "python2.7"
            self.root = "./"
            self.debug = False

    class MockParser:
        def __init__(self):
            self.arguments = MockArgParser()

        def parse_args(self):
            return self.arguments

    # Return code is -1 when there is an error
    sys.argv = []
    assert main() == -1

    # No errors occur if there are no inputs to compile
    sys.argv = ['py-backwards', '-i', './input', '-o', './output', '-t', '2.7']

# Generated at 2022-06-23 22:31:49.677789
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:31:50.096739
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:58.609642
# Unit test for function main
def test_main():
    # Unit test for testing if all targets are correct
    for target in const.TARGETS:
        assert target in const.TARGETS

    # Unit test for testing if folder is invalid
    from contextlib import redirect_stdout
    from io import StringIO
    f = StringIO()
    with redirect_stdout(f):
        main(['-i', 'aasdasd', '-o', 'aasdasd', '-t', '2.7'])

    assert f.getvalue() == messages.input_doesnt_exists('aasdasd') + '\n'
    f.close()

    # Unit test for testing if output is invalid
    f = StringIO()

# Generated at 2022-06-23 22:31:59.860260
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:04.966827
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/_data/hello.py',
                '-o', 'tests/_output/hello.py',
                '-t', 'python2', '-d']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:09.957411
# Unit test for function main
def test_main():
    sys.argv[1:1] = ['-i', 'examples/example_folder',
                     '-o', 'examples/output',
                     '-t', '3.5',
                     '-r', 'examples/example_folder',
                     '-d', 'True' ]
    main()

# Generated at 2022-06-23 22:32:10.710162
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:13.028516
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'tests.py', '-o', 'output.py', '-t', '2.7']
    main()

# Generated at 2022-06-23 22:32:18.785888
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards.py',
        '-i',
        'pybackwards/compiler.py',
        '-o',
        'pybackwards/compiler.py',
        '-t',
        '3.5',
        '-d',
    ]
    res = main()
    assert res == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:26.480597
# Unit test for function main
def test_main():
    import pytest
    from .app import main

    if hasattr(main,'DEFAULT_SETTINGS'):
        del main.DEFAULT_SETTINGS

    def test_invalid_input(monkeypatch):
        def mock_argparser(argv):
            assert argv==[]
            return "Error"

        monkeypatch.setattr(main,'parse_arguments',mock_argparser)
        assert main([]) == 2

    def test_invalid_output(monkeypatch):
        def mock_argparser(argv):
            assert argv==[]
            return (["in"], "out", "incomp", "root", False)

        monkeypatch.setattr(main,'parse_arguments',mock_argparser)
        assert main([]) == 2


# Generated at 2022-06-23 22:32:28.496389
# Unit test for function main
def test_main():
    assert main() == 1

if __name__ == '__main__':  # pragma: no cover
    exit(main())

# Generated at 2022-06-23 22:32:30.707170
# Unit test for function main
def test_main():
    try:
        main()
    except NotImplementedError:
        pass

# Generated at 2022-06-23 22:32:31.868394
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:41.555402
# Unit test for function main
def test_main():
    from io import StringIO

    from .compiler import compile_files
    from .conf import init_settings
    from . import const
    from .exceptions import CompilationError, TransformationError, InputDoesntExists
    from . import messages

    class TestArgParse:
        def __init__(self, input, output, target, root, debug):
            self.input = input
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    assert main() == 1
    assert main(['-h']) == 0
    assert main(['-i', 'a', '-o', 'b', '-t', '2.7']) == 1

# Generated at 2022-06-23 22:32:42.190278
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:32:47.404373
# Unit test for function main
def test_main():
    assert main(['test.py', '-i', '__test_input__', '-o', '__test_output__', '-t', '3.5', '-r', '../']) == 0



if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:51.071269
# Unit test for function main
def test_main():
    sys.argv=[sys.argv[0], '-i', 'tests/example.py', '-o', 'tests/result.py',
              '-t', '2.7', '-r', 'tests/']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:02.829245
# Unit test for function main
def test_main():
    from .utils import temp_file
    import os
    import shutil
    from py_backwards.compiler import compile_file
    for target in const.TARGETS:
        with temp_file() as temp1, temp_file() as temp2:
            for input in [__file__, '.']:
                args = ['--input', input, '--output', temp1,
                        '--target', target]
                if main() != 0:
                    assert False
                with open(temp1) as f:
                    out = f.read()
                compile_file(__file__, temp2, const.TARGETS[target])
                with open(temp2) as f:
                    right_out = f.read()
                assert out == right_out
            shutil.rmtree(temp1)

# Generated at 2022-06-23 22:33:06.295841
# Unit test for function main
def test_main():
    args= ['--input','test1.py','--output','test_output','--target','3.5']
    assert main(args)
    args1= ['--input','test2.py','--output','test_output','--target','3.5']
    assert not main(args1)

# Generated at 2022-06-23 22:33:06.652297
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:08.034302
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    print('Please run \'python -m backwards\' instead of'
          '\'python3 backwards\'')

# Generated at 2022-06-23 22:33:14.679868
# Unit test for function main
def test_main():
    from pyb_setup import main
    from pyb_setup import messages
    from pyb_setup.conf import init_settings
    from pyb_setup.const import TARGETS
    from pyb_setup.compiler import compile_files
    import sys
    import inspect
    import os

    def mock_compile_files(input_, output, target, root):
        return

    def fake_compile_files(input_, output, target, root):
        return

    if not os.path.exists(os.getcwd() + '/testdata/'):
        os.makedirs('./testdata')
        sys.stderr.write('testdata dir created\n')


# Generated at 2022-06-23 22:33:17.183521
# Unit test for function main
def test_main():
    data = {}
    assert data == {}

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:25.243984
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import subprocess

    dir_path = os.path.dirname(os.path.realpath(__file__))
    test_data_dir_path = os.path.join(dir_path, 'tests')
    test_data_dir_path = os.path.join(test_data_dir_path, 'test_data')
    tmpdirname = tempfile.mkdtemp()
    src_dir_path = os.path.join(tmpdirname, 'src')
    dst_dir_path = os.path.join(tmpdirname, 'dst')

    def py_backwards(input_file, target):
        python = sys.executable

# Generated at 2022-06-23 22:33:27.030376
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit, match='1'):
        main()

# Generated at 2022-06-23 22:33:28.311940
# Unit test for function main
def test_main():
    init_settings(None)
    res = main()
    assert res == 0

# Generated at 2022-06-23 22:33:28.843611
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:35.651082
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'in', '-o', 'out', '-t', '2.7', '-d']
    from . import settings
    result = main()
    assert result == 0
    assert settings.SOURCE == 'in'
    assert settings.DESTINATION == 'out'
    assert settings.ROOT == 'in'
    assert settings.DEBUG
    assert settings.TARGET_VERSION == '2.7'
    sys.argv = [sys.argv[0]]
    result = main()
    assert result == 2

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:36.508976
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:33:38.460942
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# vim: tabstop=4 shiftwidth=4 expandtab

# Generated at 2022-06-23 22:33:38.910836
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:44.139103
# Unit test for function main
def test_main():
    import os, tempfile
    temp_dir = tempfile.mkdtemp()
    temp_file = "file.py"
    fi = open(os.path.join(temp_dir, temp_file), 'w')
    fi.write("a = 2\n")
    fi.close()
    args = parser.parse_args()
    assert main() == 0

# Generated at 2022-06-23 22:33:53.361506
# Unit test for function main

# Generated at 2022-06-23 22:33:54.029572
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:03.456086
# Unit test for function main
def test_main():
    # Test 1: valid compilation
    sys.argv = shlex.split('py-backwards -i test/test_compiler/input/ -o test/test_compiler/output/ -t 2.6')
    init_settings(sys.argv)

    result = main()
    assert(result == 0)

    # Test 2: failed compilation
    sys.argv = shlex.split('py-backwards -i test/test_compiler/input/ -o test/test_compiler/output/ -t 2.6')
    init_settings(sys.argv)

    result = main()
    assert(result == 1)

    # Test 3: input file doesn't exist

# Generated at 2022-06-23 22:34:05.784981
# Unit test for function main
def test_main():
    sys.argv = ["-i", "test/test_files/text.py", "-o", "text.py", "-t", "python27"]
    assert main() == 0

# Generated at 2022-06-23 22:34:14.259143
# Unit test for function main
def test_main():
    """
    Testing the main functionality
    """
    assert main(['-i', 'py-backwards/tests', '-o', 'py-backwards/tests/bin', '-t', '2.7']) == 0
    assert main(['-i', 'py-backwards/tests', '-o', 'py-backwards/tests/bin', '-t', '3.3']) == 0
    assert main(['-i', 'py-backwards/tests', '-o', 'py-backwards/tests/bin', '-t', '3.4']) == 0
    assert main(['-i', 'py-backwards/tests', '-o', 'py-backwards/tests/bin', '-t', '3.5']) == 0

# Generated at 2022-06-23 22:34:20.477601
# Unit test for function main
def test_main():
    import io
    from contextlib import redirect_stderr, redirect_stdout

    sys.stderr = io.StringIO()
    sys.stdout = io.StringIO()

    with redirect_stdout(sys.stdout), redirect_stderr(sys.stderr):
        assert main() == 0

    sys.stderr = sys.__stderr__
    sys.stdout = sys.__stdout__


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:21.459438
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:34:27.118228
# Unit test for function main
def test_main():
    argv = ['py-backwards', '-i', 'some-input', '-o', 'some-output',
            '-t', '2.7', '-r', '3.6', '-d']
    with patch.object(sys, 'argv', argv):
        try:
            main()
        except SystemExit:
            pass

# Generated at 2022-06-23 22:34:37.538936
# Unit test for function main
def test_main():
    # success
    sys.argv = [sys.argv[0], 'test_file.py', '-o', 'out', '-t', '2.7', '-r', 'src', '-d']
    main()

    # invalid output
    sys.argv = [sys.argv[0], 'test_file.py', '-o', 'out', '-t', '2.7', '-r', 'src', '-d']
    main()

    # invalid output
    sys.argv = [sys.argv[0], 'test_file.py', '-o', 'out', '-t', '2.7', '-r', 'src', '-d']
    main()

    # invalid target

# Generated at 2022-06-23 22:34:38.209353
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:39.467496
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:44.560927
# Unit test for function main
def test_main():
    import subprocess
    import os
    import shutil
    from os.path import join, exists
    from tempfile import mkdtemp
    import doctest

    old_path = sys.path[:]
    tmp_dir = mkdtemp()
    sys.path.insert(0, tmp_dir)
    try:
        result = subprocess.run(["py-backwards",
                        "--input", "tests/sources/input/compiler",
                        "--output", tmp_dir,
                        "--target", "2.7"],
                       stderr=subprocess.PIPE,
                       stdout=subprocess.PIPE)
    finally:
        sys.path = old_path
        if exists(tmp_dir):
            shutil.rmtree(tmp_dir)

    assert "Successfully compiled 5 files"

# Generated at 2022-06-23 22:34:54.913529
# Unit test for function main
def test_main():
    import pytest
    from io import StringIO

    # GIVEN an invalid input
    sys.argv = ['py-backwards',
                '--input', 'invalid_input_file',
                '--output', 'output_file',
                '--target', '2.7']

    # WHEN py-backwards is executed
    with StringIO() as buf, pytest.raises(SystemExit):
        with pytest.raises(ValueError):
            main()

    # THEN it should return the expected output
    expected = ['py-backwards: error: argument -i/--input: '
                'Input file or directory doesn\'t exists.\n']
    assert buf.getvalue().splitlines() == expected

    # GIVEN an invalid input and output

# Generated at 2022-06-23 22:35:02.514427
# Unit test for function main
def test_main():
    orig = sys.argv
    sys.argv = ['py_backwards', '-i', 'input', '-o', 'output',
                '-t', '2.7', '-r', 'root']
    init_settings()
    assert main() == 1
    sys.argv[3] = '../output'
    init_settings()
    assert main() == 1
    sys.argv[2] = 'input'
    init_settings()
    assert main() == 1
    sys.argv = orig

# Generated at 2022-06-23 22:35:06.362015
# Unit test for function main
def test_main():
    init_settings(["-i", "examples/test", "-o", "examples/output", "-t", "2.7"])
    result = compile_files("examples/test", "examples/output", const.TARGETS['2.7'], None)
    assert result.compiled == 6 and result.not_compiled == 0

# Generated at 2022-06-23 22:35:10.351534
# Unit test for function main
def test_main():
    assert main(['py-backwards', '-i', 'tests/input', '-o', 'tests/output', '-t', '2.7']) == 0
    assert main(['py-backwards', '-i', 'tests/input', '-o', 'tests/output', '-t', '3.6']) == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:16.869268
# Unit test for function main
def test_main():
    sys.argv.extend(['-i', '../tests/test_data/test_listcomps.py', '-o', '../tests/test_build/test_listcomps.py', '-t', '3.5'])
    # main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:24.003729
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]

    main()

    # no args
    assert main() == 2

    sys.argv = sys.argv[:1] + ['-i', 'tests/sources/valid_source.py',
                               '-o', 'output.py',
                               '-t', '3.4']
    assert main() == 0

    sys.argv = sys.argv[:1] + ['-i', 'tests/sources/wrong_source.py',
                               '-o', 'output.py',
                               '-t', '3.5']
    assert main() == 1


# Generated at 2022-06-23 22:35:26.114923
# Unit test for function main
def test_main():
    main()
    assert(main() == 0)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:35.496954
# Unit test for function main
def test_main():
    # Make sure that the list of input files have been read correctly
    args = main(["-i", "main.py", "other.py",
                 "-o", "output.py",
                 "-t", "3.5"])
    assert args.input == ["main.py", "other.py"]
    # make sure that invalid number of arguments passed
    with pytest.raises(SystemExit):
        main([])
    # make sure that invalid target passed
    with pytest.raises(SystemExit):
        main(["-i", "main.py", "other.py",
              "-o", "output.py",
              "-t", "3.6"])

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:37.007512
# Unit test for function main
def test_main():
    # check if there is no exception
    assert main() == 0

# Generated at 2022-06-23 22:35:41.833413
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')

# Generated at 2022-06-23 22:35:46.895289
# Unit test for function main
def test_main():
    assert main(['py_backwards', '-i', 'test.py ',
                 '-o', 'output.py', '-t', '3.5', '-r', 'root']) == 0

# Generated at 2022-06-23 22:35:49.911429
# Unit test for function main
def test_main():
    in_file = 'input/identity.py'
    out_file = 'output/out.py'
    target = '3.6'
    main(in_file, out_file, target)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:55.287593
# Unit test for function main
def test_main():
    try:
        sys.argv.append("-i")
        sys.argv.append("in")
        sys.argv.append("-o")
        sys.argv.append("out")
        sys.argv.append("-t")
        sys.argv.append("3.5")
        main()
    except SystemExit:
        pass

# Generated at 2022-06-23 22:35:58.686433
# Unit test for function main
def test_main():
    msg = '0'
    ret = -1
    try:
        ret = main()
    except Exception as ex:
        msg = str(ex)
    assert msg == '0', 'main failed'
    assert ret == 0, 'main failed'

# Generated at 2022-06-23 22:36:06.217456
# Unit test for function main
def test_main():
    input_ = ["test_input"]
    output_ = "test_output"
    target_ = "2.7"
    root_ = None

    testArgs = argparse.Namespace()
    testArgs.input = input_
    testArgs.output = output_
    testArgs.target = target_
    testArgs.root = root_
    testArgs.debug = False

    args = parser.parse_args(testArgs)

    try:
        result = compile_files(input_, output_, target_, root_)
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1
    except exceptions.TransformationError as e:
        print(messages.transformation_error(e), file=sys.stderr)
       

# Generated at 2022-06-23 22:36:10.719537
# Unit test for function main
def test_main():
    sys.argv = ['./py-backwards', '-i', 'test_file.py', '-o', 'test/test_output.py', '-t', '2.7', '-r', 'test/test_input', '-d']
    assert main() == 0

# Generated at 2022-06-23 22:36:11.438575
# Unit test for function main
def test_main():
  assert main() == 0

# Generated at 2022-06-23 22:36:15.660353
# Unit test for function main
def test_main():
    args = ['-i', 'tests/foo.py', '-o', 'tests/output_foo.py',
            '-t', '3.5', '-r', 'tests', '-d']
    sys.argv[1:] = args
    assert main() == 0

# Generated at 2022-06-23 22:36:23.674665
# Unit test for function main
def test_main():
    import sys
    from unittest.mock import Mock, patch
    from io import StringIO
    from .compiler import compile_files
    from .conf import init_settings


# Generated at 2022-06-23 22:36:24.590987
# Unit test for function main
def test_main():
    from . import test_main
    test_main.test_main()

# Generated at 2022-06-23 22:36:30.650798
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i', 'test_files/test1', 'test_files/test2',
                '-o', 'dist', '-t', '2.7', '-r', 'test_files/test_root',
                '-d']

    # Expected messages

# Generated at 2022-06-23 22:36:40.130519
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from . import compiler

    with patch('py-backwards.compiler.compile_files') as mock_compile_files:
        mock_compile_files.return_value = 5
        args = '''py-backwards -i  /home/user/tests/ -o /home/user/output.py
                    -t 2.7 -r /home/user/tests/'''
        main(args.split())
        mock_compile_files.assert_called_once_with(args.split()[2], args.split()[4],
                                      const.TARGETS[args.split()[6]],
                                      args.split()[8])

