

# Generated at 2022-06-23 22:26:34.473281
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 2


# Generated at 2022-06-23 22:26:36.590975
# Unit test for function main
def test_main():
    arguments = ["-i", "test_data/sources/test1.py", "-o", "test_data/sources/test1.py", "-t", "2.7"]
    try:
        main(arguments)
    except SystemExit as e:
        assert (e.code == 0)

# Generated at 2022-06-23 22:26:40.566679
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'C:\\Users\\ocp\\PycharmProjects\\untitled\\py-backwards', '-o', 'C:\\Users\\ocp\\PycharmProjects\\untitled\\py-backwards', '-t', 'py36']
    main()

# Generated at 2022-06-23 22:26:42.448438
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e)
    assert True

# Generated at 2022-06-23 22:26:54.141513
# Unit test for function main
def test_main():
    # Test 1
    # Compiles file into folder
    sys.argv = ["", "-i", "tests/data/test_file.py",
                "-o", "tests/data/test_output_folder",
                "-t", "2.7",
                "-r", "tests/data/"]

    # Checks if error code is 0 (success)
    assert main() == 0

    # Compiles folder into file
    sys.argv = ["", "-i", "tests/data/test_folder",
                "-o", "tests/data/test_output_file.py",
                "-t", "2.7",
                "-r", "tests/data/"]

    # Checks if error code is 0 (success)
    assert main() == 0

    # Test 2
    # Compiles folder into folder

# Generated at 2022-06-23 22:26:55.715582
# Unit test for function main
def test_main():
    # This module should return 1 on exit,
    # so tests only line coverage
    try:
        main()
    except SystemExit:
        assert True


# Generated at 2022-06-23 22:26:58.408495
# Unit test for function main
def test_main():
    #TODO: write unit tests for main function
    pass

if __name__ == "__main__":
    sys.exit(main())


# Generated at 2022-06-23 22:27:09.302950
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]]
    sys.argv.extend(["test/test_files/test.py", "-o", "test/test_files/test.py", "-t", "3.5"])
    assert main() == 0
    sys.argv.extend(["-d"])
    assert main() == 0
    sys.argv[1] = "test/test_files/test_no_tb_return.py"
    assert main() == 0
    sys.argv[1] = "test/test_files/test_no_tb_return.py"
    sys.argv[5] = "3.4"
    assert main() == 1
    sys.argv[5] = "3.5"

# Generated at 2022-06-23 22:27:15.996623
# Unit test for function main
def test_main():
    # Standart output
    try:
        # Create temp input directory
        with tempfile.TemporaryDirectory() as temp_input:
            # Create temp output directory
            with tempfile.TemporaryDirectory() as temp_output:
                # Create some text file
                with open(os.path.join(temp_input, 'example.txt'), 'wt') as fout:
                    print('Hello, world!', file=fout)

                # Run main function
                main()
    finally:
        pass


# Generated at 2022-06-23 22:27:19.082144
# Unit test for function main
def test_main():
    args = ['--input', 'test.py', '--output', 'test.py', '--target', '2.7']
    sys.argv = sys.argv[:1] + args
    main()

# Generated at 2022-06-23 22:27:19.946859
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:27:24.598661
# Unit test for function main
def test_main():
    # Because of argparse, main function can't be tested directly,
    # instead we're testing its caller.
    with tempfile.TemporaryDirectory() as tmpdir:
        import builtins
        builtins.argv = ['py-backwards',
                         '-i', './tests/sources/basic.py',
                         '-o', tmpdir,
                         '-t', '2.7']
        assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:25.080739
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:27:35.286794
# Unit test for function main
def test_main():
    with nested(
        patch('py_backwards.argparse.ArgumentParser.parse_args'),
        patch('py_backwards.conf.init_settings'),
        patch('py_backwards.compiler.compile_files'),
        patch('sys.stderr'),
        patch('sys.stdout'),
    ) as (
        parse_args, init_settings, compile_files, stderr, stdout
    ):
        parse_args.return_value = argparse.Namespace(
            input=['input', 'folder'],
            output='output',
            target='python',
            root='root',
            debug=False,
        )

# Generated at 2022-06-23 22:27:37.129037
# Unit test for function main
def test_main():
    x = main()
    return x == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:38.095059
# Unit test for function main
def test_main():
    assert main() == 0

# Execute the program
if __name__ == "__main__":
    sys.exit(main())

# End of file

# Generated at 2022-06-23 22:27:39.811628
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:51.052253
# Unit test for function main
def test_main():
    class args:
        input = "/Users/d.yermak/PycharmProjects/py_backwards/tests/input/syntax/async.py"
        output = "/Users/d.yermak/PycharmProjects/py_backwards/tests/output"
        target = "python27"
        root = "/Users/d.yermak/PycharmProjects/py_backwards/tests/input"

    init_settings(args)

    try:
        for input_ in args.input:
            result = compile_files(input_, args.output,
                                   const.TARGETS[args.target],
                                   args.root)
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1


# Generated at 2022-06-23 22:27:59.769562
# Unit test for function main
def test_main():
    import pytest
    from contextlib import redirect_stdout
    from io import StringIO
    assert main() == 1
    assert main(["-i", "test/00_samples/simple/simple.py", '-o', 'output1', '-t', '2.7']) == 0
    assert main(["-i", "tests/00_samples/simple/simple.py", '-o', 'output1', '-t', '2.7']) == 1
    assert main(["-i", "test/00_samples/simple", '-o', 'output2', '-t', '2.7']) == 0
    assert main(["-i", "test/00_samples/simple", '-o', 'output2', '-t', '2.7', '--debug']) == 0

# Generated at 2022-06-23 22:28:04.977912
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:10.938697
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.extend(['-i', 'tests/test_data/test_module.py',
                    '-o', 'build/output.py',
                    '-t', '2.7'])
    code = main()
    assert code == 0, 'code is not 0'

    sys.argv = sys.argv[:1]
    sys.argv.extend(['-i', 'tests/test_data/',
                     '-o', 'build/',
                     '-t', '2.7'])
    code = main()
    assert code == 0, 'code is not 0'

    sys.argv = sys.argv[:1]

# Generated at 2022-06-23 22:28:11.498958
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:16.530612
# Unit test for function main
def test_main():
    r = sys.argv
    sys.argv = ['programName','-i', 'E:\\university\\py-backwards\\doc\\examples\\3.6\\async_for.py','-o', 'E:\\university\\py-backwards\\doc\\examples\\3.6\\async_for.py','-t', '3.5']
    main()
    assert 1 == main()

# Generated at 2022-06-23 22:28:17.680909
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:24.688016
# Unit test for function main
def test_main():
    with open('/tmp/py-backwards.log', mode='w') as log:
        sys.stdout = log
        sys.stderr = log

        sys.argv[1:] = ['-i', 'test/test_files',
                        '-o', '/tmp/',
                        '-t', '3.5',
                        '-r', 'test/test_files',
                        '-d']
        assert main() == 0

        sys.argv[1:] = ['-i', 'test/test_files',
                        '-o', '/tmp/',
                        '-t', '3.5',
                        '-r', 'test/test_files']
        assert main() == 0


# Generated at 2022-06-23 22:28:25.292908
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:28:27.158663
# Unit test for function main
def test_main():
    args = main()
    assert args == 0


# Generated at 2022-06-23 22:28:38.892655
# Unit test for function main
def test_main():
    module = sys.modules['__main__']
    module.__package__ = ''
    import os

    logging.basicConfig(level='DEBUG')

    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_output = os.path.join(test_dir, 'output')
    if not os.path.exists(test_output):
        os.makedirs(test_output)

    os.chdir(test_dir)
    exit_code = main()
    assert exit_code == 0

    assert open(os.path.join(test_dir, 'test', 'success.py')).read() == open(
        os.path.join(test_output, 'test', 'success.py')).read()

# Generated at 2022-06-23 22:28:39.431776
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:28:47.898203
# Unit test for function main
def test_main():
    input_ = ['./tests/fixtures/input/' + str(x) for x in range(2, 12)]
    output_ = './tests/fixtures/output/' + '11'
  
    target_ = "python3.5"
    root_ = "./tests/fixtures/input/"
    debug_ = True
    args = argparse.Namespace(input=input_, output=output_, target=target_, root=root_, debug=debug_)
    init_settings(args)


# Generated at 2022-06-23 22:28:57.134479
# Unit test for function main
def test_main():
    import os
    import shutil
    os.makedirs('test/_compiler_tests', exist_ok=True)
    shutil.copy('test/test_compiler.py', 'test/_compiler_tests/')
    os.makedirs('test/_compiler_tests/t', exist_ok=True)
    shutil.copy('test/test_compiler_target.py', 'test/_compiler_tests/t/')

    # Run without required arguments
    try:
        main()
        assert False
    except SystemExit:
        pass
    except Exception:
        assert False

    # Run with different syntax errors
    res = main('-i test/_compiler_tests -o test/_compiler_tests/_output '
               '-t 2.7'.split())
    assert res == 1

    # Run with target

# Generated at 2022-06-23 22:29:06.157031
# Unit test for function main
def test_main():
    # input_ -> input, target -> cli_target
    import sys
    sys.argv[1:] = ['-i', 'tests/test_source_files/simple.py',
                    '-o', 'tests/output_files/input.py',
                    '-t', '3.6']

    # Shouldnt throw error
    main()
    def invalid_input_and_output():
        main()
    # Test InvalidInputOutput
    sys.argv[1:] = ['-i', 'tests/test_source_files/simple.py',
                    '-o', 'tests/output_files/simple.py',
                    '-t', '3.6',
                    '-i', 'tests/test_source_files/simple.py',
                    '-o', 'tests/output_files/simple.py']

# Generated at 2022-06-23 22:29:06.744227
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-23 22:29:10.123049
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'tests/input/py36/list_dir', '-o', 'out', '-t', '3.5', '-r',
                'tests/input/py36']
    assert main() == 0

# Generated at 2022-06-23 22:29:20.708397
# Unit test for function main
def test_main():
    # init_settings({'DEBUG':True, 'LOGGER': None})

    from . import __init__
    from .compiler import compile_files
    from .conf import init_settings

    sys.argv = ['py-backwards', '-i', '../tests/test_data/fib.py', '-o', '../tests/test_data/fib_compiled.py',
                '-t', 'python27']
    init_settings(vars(__main__.main()))
    f = compile_files('../tests/test_data/fib.py', '../tests/test_data/fib_compiled.py', const.TARGETS['python27'])
    assert f == 1

# Generated at 2022-06-23 22:29:21.591178
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:22.218899
# Unit test for function main
def test_main():
    assert main() != 1

# Generated at 2022-06-23 22:29:33.858666
# Unit test for function main
def test_main():
    from . import test
    from .parser import parser
    from .transformer import transformer
    from .writer import writer
    from . import compiler
    import pytest
    parser.parse_module=test.Mock(side_effect=exceptions.CompilationError('test'))
    transformer.transform=test.Mock(side_effect=exceptions.TransformationError('test'))
    compiler.compile_files = test.Mock(side_effect=exceptions.InputDoesntExists())
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 1
    parser.parse_module=test.Mock(return_value=None)
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 1
    transformer.transform

# Generated at 2022-06-23 22:29:34.537668
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:35.875391
# Unit test for function main
def test_main():
    a= main()
    if a == 1:
        assert True
    else:
        assert True

# Generated at 2022-06-23 22:29:38.041847
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/files/ast_test.py', '-o', '.', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-23 22:29:48.543565
# Unit test for function main
def test_main():
    from io import StringIO
    sys.stdout = StringIO()   # Redirect stdout
    assert(main() == 0)
    sys.stdout = sys.__stdout__
    sys.argv = ['py-backwards', '-i', 'tests/test.py']
    assert(main() == 1)
    sys.stdout = sys.__stdout__
    sys.argv = ['py-backwards', '-i', 'tests/test.py', '-p', '3']
    assert(main() == 1)
    sys.stdout = sys.__stdout__
    sys.argv = ['py-backwards', '-i', 'tests/test.py', '-p', '3', '-o', 'a.py']
    assert(main() == 1)

# Generated at 2022-06-23 22:29:49.890053
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:56.754438
# Unit test for function main
def test_main():
    sys.argv = ['/usr/local/bin/py-backwards', '-i', './py_backwards/compiler/tests/data/input/', '-o', './py_backwards/compiler/tests/data/output/', '-t', '2.7']
    main()
    assert 0 == len(os.listdir('./py_backwards/compiler/tests/data/output/'))

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:01.125225
# Unit test for function main
def test_main():
    with patch('sys.argv', ['py-backwards', '-i', 'file', '-o', 'out', '-t', '3', '-r', 'root']):
        assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:07.182039
# Unit test for function main
def test_main():
    # Unit test for empty input
    argv = ['-i', '', '-o', '', '-t', '', '-r', '']
    with pytest.raises(SystemExit):
        main(argv)

    # Unit test for non-existing file
    argv = ['-i', '', '-o', '', '-t', '', '-r', '', '-d']
    with pytest.raises(SystemExit):
        main(argv)

# Generated at 2022-06-23 22:30:07.796419
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:09.467318
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-23 22:30:19.012847
# Unit test for function main
def test_main():
    main()
    main(['py-backwards.py','-i', 'test/', '-o', 'test_out/', '-t', '3.6', '-r', '.', '-d'])
    main(['py-backwards.py', '-i', 'test/', '-o', 'test_out/', '-t', '3.6', '-r', '.'])
    main(['py-backwards.py', '-i', 'test/', '-o', 'test/', '-t', '3.6', '-r', '.'])
    main(['py-backwards.py', '-i', 'test/', '-o', 'test_out/', '-t', '3.6', '-r', '.', '-d'])

# Generated at 2022-06-23 22:30:27.752508
# Unit test for function main
def test_main():
    import sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (output, error):
        main()
        assert(output.getvalue().find("usage:") != -1)


# Generated at 2022-06-23 22:30:29.811107
# Unit test for function main
def test_main():
    '''
    >>> assert main()
    '''
    pass

if __name__ == "__main__":
    pass

# Generated at 2022-06-23 22:30:30.372630
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:41.306058
# Unit test for function main
def test_main():
    """
    This method tests the args parsing and the exceptions handling.
    """
    input_path = '/home/input.py'
    output_path = '/home/output.py'
    target_version = '3.6'
    # Test the wrong input or output path
    assert main(['-i', input_path, '-o', output_path,
                '-t', target_version]) == 1
    # Test the wrong target version
    assert main(['-i', '-', '-o', output_path,
                '-t', '3.6']) == 1
    # Test the regular case
    assert main(['-i', input_path, '-o', output_path,
                '-t', target_version]) == 0


# Generated at 2022-06-23 22:30:41.808499
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:46.838691
# Unit test for function main
def test_main():
    sys.argv[1:] = '-i main.py -o backwards/ -t 3.5 --root ./main.py'.split()
    #assert main(sys.argv[1:]) == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:49.148649
# Unit test for function main
def test_main():
    """
    This is a unit test for main, we do this with pytest, it will
    not print anything
    """
    main()

# Generated at 2022-06-23 22:30:56.302314
# Unit test for function main
def test_main():
    from contextlib import redirect_stdout

    init_settings(
        vars(ArgumentParser('').parse_args(
            ['--input', 'tests/resources/test_script.py',
             '--output', 'tests/resources/test_script.bkwd.py',
             '--target', 'py35',
             '--root', 'tests/resources/']))
    )
    assert main() == 0

    init_settings(
        vars(ArgumentParser('').parse_args(
            ['--input', 'tests/resources/test_script.py',
             '--output', 'tests/resources/test_script.bkwd.py',
             '--target', 'py35',
             '--root', 'tests/resources/']))
    )

# Generated at 2022-06-23 22:31:03.373448
# Unit test for function main
def test_main():
    from .test import fake_input
    from . import settings

    def set_input(arg):
        return fake_input(['-i', 'input.py',
                           '-o', 'output.py',
                           '-t', 'python2.7',
                           '-r', './',
                           '-d', arg])

    # With debug
    sys.argv = set_input('True')
    settings.debug = settings.Debug()
    assert main() == 0
    assert settings.debug.enabled

    # Without debug
    sys.argv = set_input('False')
    settings.debug = settings.Debug()
    assert main() == 0
    assert not settings.debug.enabled


# Generated at 2022-06-23 22:31:05.391726
# Unit test for function main
def test_main():
    #sys.argv = ['py_backwards.py']
    assert main() == 1, 'Program should work'

# Generated at 2022-06-23 22:31:07.441189
# Unit test for function main
def test_main():
    assert_equals(main(), 0)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:09.577522
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', 'python2',
                '-r', 'root', '-d']
    parser = main()
    assert parser

# Generated at 2022-06-23 22:31:20.501363
# Unit test for function main
def test_main():
    import os
    import pytest
    from . import compiler

    # Test for debug parameter
    args = ['py-backwards', '-i', '.', '-o', '/', '-t', 'PY27']
    assert main(args) == 0
    assert compiler._DEBUG is False
    args = ['py-backwards', '-i', '.', '-o', '/', '-t', 'PY27', '-d']
    assert main(args) == 0
    assert compiler._DEBUG is True

    # Test root parameter
    args = ['py-backwards', '-i', '.', '-o', '/', '-t', 'PY27', '-r', '/tmp']
    assert main(args) == 0
    assert compiler._ROOT is os.path.abspath('/tmp')
    args

# Generated at 2022-06-23 22:31:31.817219
# Unit test for function main
def test_main():
    def test_compile(input_, output, python_version, root):
        def side_effect(*args, **kwargs):
            return {
                ('compile_files', 'input_'): input_,
                ('compile_files', 'output'): output,
                ('compile_files', 'target'): python_version,
                ('compile_files', 'root'): root,
                ('compile_files', ): {
                    'input': input_,
                    'output': output,
                    'target': python_version,
                    'root': root,
                    'count': 1,
                    'skipped': 0
                }
            }[(args[0], *args[1:], *kwargs.values())]


# Generated at 2022-06-23 22:31:32.493807
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:41.314843
# Unit test for function main
def test_main():
    def _mock_parse_args(argv):
        class MockArgs():
            input = [argv[0]]
            output = argv[1]
            target = argv[2]
            root = None
            debug = False
        return MockArgs()

    # no exception
    sys.argv = ['py-backwards', 'test1.py',
                'test2.py', '--target=2.7']
    args = _mock_parse_args(sys.argv[1:])
    r = main()

    # exception
    sys.argv = ['py-backwards', 'test1.py',
                'test2.py', '--target=2.']
    args = _mock_parse_args(sys.argv[1:])
    r = main()



# Generated at 2022-06-23 22:31:42.312333
# Unit test for function main
def test_main():
    func = main()
    assert func == 0

# Generated at 2022-06-23 22:31:44.016463
# Unit test for function main
def test_main():
	assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:45.066343
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:54.814522
# Unit test for function main
def test_main():
    for option, target in [('-t', 'py2'), ('-t', 'py3')]:
        with open('temp.py', 'w') as temp:
            temp.write('print("Hello, World!")')
        try:
            main([option, target, '-d', '-i', 'temp.py', '-o', 'out.py', '-r', '.'])
            with open('out.py', 'r') as temp_out:
                assert temp_out.read() == 'print "Hello, World!"'
        except:
            raise AssertionError
        finally:
            os.remove('temp.py')
            os.remove('out.py')
    assert main([]) == 2

# Generated at 2022-06-23 22:31:55.337188
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:03.481814
# Unit test for function main
def test_main():
    import unittest
    from unittest.mock import patch, Mock
    class TestComputor(unittest.TestCase):

        def setUp(self):
            self.parser = Mock(return_value = Mock(
                input = ['input_1'], output = 'output_1',
                target = '3.5', debug = None, root = None))

        def test_good_case(self):
            with patch('pybackwards.main.init_settings'):
                with patch('pybackwards.main.compile_files') as compile_files:
                    compile_files.return_value = 'result'
                    with patch('pybackwards.main.print') as print_:
                        with self.assertRaises(SystemExit) as cm:
                            main()

# Generated at 2022-06-23 22:32:05.084699
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:12.276489
# Unit test for function main
def test_main():
    # If input/output are valid it should return 0
    assert main(['-i', 'tests/crash_course.py', '-o', 'tests/out.py', '-t', '3.5']) == 0

    # If input/output are not valid it should return 1
    assert main(['-i', 'tests/crash_course.py', '-o', 'tests/out.py', '-t', '3']) == 1

# Generated at 2022-06-23 22:32:22.280057
# Unit test for function main
def test_main():
    # No args
    sys.argv[1:] = []
    assert main() == 2

    # Too many args
    sys.argv[1:] = ['-j', '-o', '-p']
    assert main() == 2

    # Invalid target
    sys.argv[1:] = ['-t', 'python-1.0', '-o', 'a.py', '-i', 'b.py']
    assert main() == 2

    # Fileinput as diroutput
    sys.argv[1:] = ['-t', 'python-3.6', '-o', 'a.py', '-i', 'b.py']
    assert main() == 1

    # No output file
    sys.argv[1:] = ['-t', 'python-3.6', '-i', 'a.py']


# Generated at 2022-06-23 22:32:27.854941
# Unit test for function main
def test_main():
    const.TARGETS['test'] = (3, 5)
    assert main(input=['test'], output='test', target='test',
                debug=False, root=None) == 1
    assert main(input=['test'], output='test', target='test',
                debug=False, root='test') == 1
    assert main(input=['test'], output='test', target='test',
                debug=False, root='test') == 1

# Generated at 2022-06-23 22:32:39.359273
# Unit test for function main
def test_main():
    import os
    import shutil
    
    os.chdir('../')
    shutil.rmtree('test_folder', ignore_errors=True)
    shutil.rmtree('output_folder', ignore_errors=True)
    shutil.copytree('py_backwards/tests/files', 'test_folder')
    os.chdir('tests')

    os.chdir('files')
    assert main() == 0
    os.chdir('../')
    assert main() == 0
    os.chdir('../')
    assert main() == 0
    assert main() == 0
    
    shutil.rmtree('../test_folder', ignore_errors=True)
    shutil.rmtree('../output_folder', ignore_errors=True)
    

# Generated at 2022-06-23 22:32:40.301005
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:44.861543
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        if e.code == 0:
            return True
        else:
            return False
    except:
        return False

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:46.289629
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:47.687938
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:52.438179
# Unit test for function main
def test_main():
    args = ["-i", "helloWorld.py", "-o", "helloWorld.py", "-t", "3.7"]
    args1 = ["-i", "invalidName.py", "-o", "helloWorld.py", "-t", "3.7"]
    args2 = ["-i", "helloWorld.py", "-o", "helloWorld.py", "-t", "3.7"]
    assert main() == 1
test_main()

# Generated at 2022-06-23 22:33:03.302052
# Unit test for function main
def test_main():
    from subprocess import PIPE, Popen
    from os import path
    from shutil import rmtree
    import sys
    from io import StringIO
    import argparse
    from typing import List

    here = path.abspath(path.dirname(__file__))

    # Create the output folder
    output = path.join(here, 'tests/output')
    rmtree(output, ignore_errors=True)
    os.mkdir(output)

    # Configuration for each test

# Generated at 2022-06-23 22:33:04.696470
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:08.526011
# Unit test for function main
def test_main():
    args = ['-i', 'foo.txt', '-o', 'bar.txt', '-t', 'py35']
    stream = io.StringIO()
    sys.stdout = stream
    main(args)
    sys.stdout = sys.__stdout__
    assert stream.getvalue() == 'Please, specify input file or folder!\n'

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:14.151439
# Unit test for function main
def test_main():
    sys.argv = ["", "--input", "C:/Users/XIRU/PycharmProjects/typing.py", "--output", "C:/Users/XIRU/Desktop/test_folder/output", "--target", "3.5"]
    main()



# Generated at 2022-06-23 22:33:21.348753
# Unit test for function main
def test_main():
    sys.argv = [
        'main.py',
        '-i', './tests/sources/sample.py',
        '-o', './tests/sources/sample.py',
        '-t', '3.5'
    ]
    assert main() == 0

    sys.argv = [
        'main.py',
        '-i', './tests/sources/sample.py',
        '-o', './tests/sources/no-sample.py',
        '-t', '3.5'
    ]
    assert main() == 1

# Generated at 2022-06-23 22:33:21.965832
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:33:22.450628
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:23.023281
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:31.194506
# Unit test for function main
def test_main():
    try:
        compile_files('test/test_input.py', 'test/test_output.py', '--root test')
    except exceptions.InputDoesntExists:
        print(messages.input_doesnt_exists(args.input), file=sys.stderr)
        return 1
    except exceptions.InvalidInputOutput:
        print(messages.invalid_output(args.input, args.output),
              file=sys.stderr)
        return 1
    except PermissionError:
        print(messages.permission_error(args.output), file=sys.stderr)
        return 1
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1

# Generated at 2022-06-23 22:33:34.147120
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass
    else:
        assert False

if __name__ == '__main__':
    test_main()
    
#    main()

# Generated at 2022-06-23 22:33:35.565106
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:39.022122
# Unit test for function main
def test_main():
    args = ['-i', 'tests/input', '-o', 'tests/unittest_output', '-t', '3.6', '-d']
    assert main(sys.args) == 0

# Generated at 2022-06-23 22:33:46.660894
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['main.py', '-r', 'C:/Users/Zerbs/Documents/GitHub/py-backwards',
                '-t', '2.7', '-i', 'C:/Users/Zerbs/Documents/GitHub/'
                'py-backwards/examples/simple_fstring', '-o',
                'C:/Users/Zerbs/Documents/GitHub/'
                'py-backwards/examples/simple_fstring/output']
    sys.exit(main())

# test_main()

# Generated at 2022-06-23 22:33:56.858582
# Unit test for function main
def test_main():
    import os
    import shutil
    import subprocess
    import tempfile

    def check_result(result, exit_code):
        assert result.returncode == exit_code
        assert result.stdout
        assert result.stderr

    exit_code = 0
    test_dir = os.path.dirname(__file__)
    root = os.path.abspath(os.path.join(test_dir, '..'))
    text_dir = os.path.join(root, 'tests', 'text')


# Generated at 2022-06-23 22:34:02.503840
# Unit test for function main
def test_main():
    import argparse
    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 2
    assert exc.value.args == (2,)

    with pytest.raises(SystemExit) as exc:
        args = argparse.Namespace(input='foo', output='bar', target='python34')
        main(args)
    assert exc.value.code == 1
    assert exc.value.args == (1,)

# Generated at 2022-06-23 22:34:03.811819
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:34:12.083720
# Unit test for function main
def test_main():
    assert 1 == main(['-i', '../pyverchk', '-o', '../py-backwards/targets/2', '-t', '2'])
    assert 1 == main(['-i', '../pyverchk', '-o', '../py-backwards/targets/3', '-t', '3'])
    assert 1 == main(['-i', '../pyverchk', '-o', '../py-backwards/targets/2', '-t', '2'])
    assert 0 == main(['-i', '../pyverchk', '-o', '../py-backwards/targets/3', '-t', '3'])

# Generated at 2022-06-23 22:34:19.618074
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/a.py', '-o', 'out/',
                '-t', '3.4']
    init_settings(None)
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/a.py', '-o', 'out/',
                '-t', '3.4', '-d']
    init_settings(None)
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:30.368878
# Unit test for function main
def test_main():
    # test 1: test_input_is_None
    args = Namespace(input=None, output=None, target=None,
                     root=None, debug=False)
    main(args)
    # test 2: test_input_is_None
    args = Namespace(input="test", output=None, target=None,
                     root=None, debug=False)
    main(args)
    # test 3: test_input_is_None
    args = Namespace(input="test", output="test_out", target=None,
                     root=None, debug=False)
    main(args)
    # test 4: test_input_is_None
    args = Namespace(input="test", output="test_out", target="2.7",
                     root=None, debug=False)
    main(args)
   

# Generated at 2022-06-23 22:34:33.110646
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'test/test_input', '-o', 'test/test_output',
                    '-t', '2.7']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:43.381024
# Unit test for function main
def test_main():
    from .compiler.compiler import compile_from_string

    config = ArgumentParser('py-backwards')
    config.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    config.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    config.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    config.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:34:46.466990
# Unit test for function main
def test_main():
    sys.argv = ['py-backward', '-i', 'test/test_input/test.py',
                '-o', 'test/test_output/test.py',
                '-t', 'PY37', '-d', 'True']


# Generated at 2022-06-23 22:34:53.284145
# Unit test for function main
def test_main():

    # Create a mock object for sys.argv to test the main function
    class Args:
        input = ['test1.py']
        output = 'test.py'
        target = 'py27'
        debug = False

    sys.argv = ['py-backwards', '-i', Args.input[0], '-o', Args.output, '-t', Args.target]

    # Call main function
    result = main()

# Generated at 2022-06-23 22:34:54.179223
# Unit test for function main
def test_main():
    """Tests main function"""
    assert False

# Generated at 2022-06-23 22:35:04.804440
# Unit test for function main
def test_main():
    from tempfile import TemporaryDirectory
    import shutil
    from . import conf

    with TemporaryDirectory() as temp_dir:
        input_folder = temp_dir + '/input'
        output_folder = temp_dir + '/output'
        os.makedirs(input_folder)
        os.makedirs(output_folder)
        shutil.copy('examples/keywords.py', input_folder)
        shutil.copy('examples/mro.py', input_folder)
        shutil.copy('examples/annotations.py', input_folder)
        shutil.copy('examples/typing.py', input_folder)
        shutil.copy('examples/dataclasses.py', input_folder)
        shutil.copy('examples/fstrings.py', input_folder)

# Generated at 2022-06-23 22:35:06.938086
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i','../tests/tests.py', '-o','../tests/', '-t','python36']
    main()

# Generated at 2022-06-23 22:35:08.006449
# Unit test for function main
def test_main():
    import pytest

    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 22:35:16.497178
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2
    
    argv = ['-i', 'test_input' + os.sep + 'test_in.py', '-o', 
            'test_output' + os.sep + 'test_out.py', '-t', 'Python2']
    with patch.object(sys, 'argv', argv):
        with pytest.raises(SystemExit) as pytest_wrapped_e:
            main()
        assert pytest_wrapped_e.type == SystemExit
        assert pytest_wrapped_e.value.code == 0
    

# Generated at 2022-06-23 22:35:18.825365
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards','-i','tests/1.py', '-o', 'test.py', '-t', '3.5', '-r', '.']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:25.181857
# Unit test for function main
def test_main():
    with mock.patch('argparse.ArgumentParser.parse_args',
                    return_value=mock.Mock(
                        input=['input1.py'], output='output', target='py36',
                        debug=False)):
        with mock.patch('sys.stderr', new_callable=StringIO):
            assert main() == 1
        sys.stderr.write.assert_called_with(
            messages.syntax_error(exceptions.CompilationError('')))


# Generated at 2022-06-23 22:35:29.170830
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "tests/input.py", "-t", "py27", "-o", "output/"]
    sys.exit(main())


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:30.945612
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-23 22:35:33.874803
# Unit test for function main
def test_main():
    test_main._test_main()
    assert True

test_main._test_main = main
main = test_main

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:35:38.366325
# Unit test for function main
def test_main():
    from .compiler import compile_file

    old_sys_argv = sys.argv
    sys.argv = ['', '-i', 'py-backwards/test/test_main', '-o', 'py-backwards/test/test_main',
                '-t', '2.7', '-r', 'py-backwards/test/']

    main()

    sys.argv = old_sys_argv


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:40.968041
# Unit test for function main
def test_main():
    assert main() == -1

# Generated at 2022-06-23 22:35:41.993484
# Unit test for function main
def test_main():
    assert main(['-i', '-o', '-v'])

# Generated at 2022-06-23 22:35:51.231542
# Unit test for function main
def test_main():
    from .conf import get_settings 
    from .compiler import compile_files
    from .messages import compilation_result, syntax_error, transformation_error, input_doesnt_exists, invalid_output, permission_error
    from . import const, exceptions
    from colorama import Fore
    from functools import partial
    from typing import Dict

    _print = print

    # Mock function print that returns printed message
    # and additionally remembers printed color
    _printed: List[str] = []
    _colors: Dict[str, str] = {}

    def print(*args, **kwargs):
        text = ' '.join(str(arg) for arg in args) + '\n'

# Generated at 2022-06-23 22:35:56.559232
# Unit test for function main
def test_main():
    with patch('sys.argv', ['py-backwards',
                            '-i', 'tests/sample.py',
                            '-o', 'tests/sample_compiled.py',
                            '-t', '2.7',
                            '-r', 'tests/']):
        assert main() == 0
    exit = main()
    assert exit == 1

# Generated at 2022-06-23 22:36:04.960530
# Unit test for function main
def test_main():
    import io
    import contextlib
    import unittest

    @contextlib.redirect_stdout
    def capture_output(func):
        func()

    class MainTestCase(unittest.TestCase):
        def test_main(self):
            import sys
            from . import conf
            from . import exceptions
            from . import const
            from .compiler import compile_files

            class MockException(exceptions.BackwardsException):
                pass

            class MockArgs:
                input = 'input'
                output = 'output'
                target = 'py27'
                root = None
                debug = False

            def mock_init_settings(args):
                conf.DEBUG_MODE = MockArgs.debug


# Generated at 2022-06-23 22:36:05.887867
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:07.464768
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:11.152317
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/test.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-23 22:36:15.985510
# Unit test for function main
def test_main():
    # mocking sys.argv
    sys.argv = ["py-backwards", "-i", "./tests/in/my_folder",
          "-o", "./tests/out/",
          "-t", "2.7"]

    import py_backwards.__main__
    py_backwards.__main__.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:36:23.909011
# Unit test for function main
def test_main():
    # No arguments
    args = ['-i']
    if main(args) == 0:
        assert False

    # Invalid target
    args = ['-i', 'example.py', '-o', 'example1.py', '-t', '3.6']
    if main(args) == 0:
        assert False

    # Invalid input
    args = ['-i', 'example.py', '-o', 'example1.py', '-t', '2.7', '-d', '--root', '.']
    if main(args) == 0:
        assert False

    # Invalid output
    args = ['-i', 'example.py', '-o', '/example1.py', '-t', '2.7', '-d', '--root', '.']

# Generated at 2022-06-23 22:36:32.439470
# Unit test for function main
def test_main():
    test = []
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'result.py', '-t', '3.5', '-d', '-r', 'test.py']
    if __name__ == '__main__':
        test.append(main())
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'result.py', '-t', '3.5', '-r', 'test.py']
    if __name__ == '__main__':
        test.append(main())
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'result.py', '-t', '3.5', '-d']