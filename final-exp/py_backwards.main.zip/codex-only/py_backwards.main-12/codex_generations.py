

# Generated at 2022-06-23 22:26:41.346180
# Unit test for function main
def test_main():
    from .mock import argparse_mock, fileinput_mock, fileoutput_mock
    from .conf import settings
    from . import const, exceptions

    assert main() == 1

    parser = argparse_mock(
        ['-i', '-', '-t', 'py37', '-o', '-'])
    args = parser.parse_args()
    init_settings(args)

    fileinput_mock(['def foo():\n    pass'], args)
    fileoutput_mock([], args, 'w')

    result = compile_files('-', '-', const.TARGETS['py37'], args.root)
    # Get fake stdout
    stdout = sys.stdout.getvalue()
    sys.stdout.truncate(0)
    sys.stdout.seek

# Generated at 2022-06-23 22:26:52.872275
# Unit test for function main
def test_main():
    # Tests for invalid input:
    #   No input
    assert main([]) == 2
    #   No output
    assert main(['-i', 'foo.py']) == 2
    #   No target
    assert main(['-i', 'foo.py', '-o', 'foo.py']) == 2
    #   Invalid input
    assert main(['-i', 'foo.py', '-o', 'foo.py', '-t', '3.6']) == 1
    #   Invalid output
    assert main(['-i', 'foo.py', '-o', 'foo.py', '-t', '3.6', '-r', 'root']) == 1
    #   Invalid target

# Generated at 2022-06-23 22:26:53.515277
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:27:02.771004
# Unit test for function main
def test_main():
    #Tests -t parameter
    assert main() == 0
    #Tests -d parameter
    assert main() == 0
    #Tests -r parameter
    assert main() == 0
    #Tests -i and -o parameters
    assert main() == 0
    #Tests -i and -o parameters
    assert main() == 0
    #Tests -i and -o parameters
    assert main() == 0
    #Tests -i and -o parameters
    assert main() == 0
    #Tests -i and -o parameters
    assert main() == 0
    #Tests -i and -o parameters
    assert main() == 0
    #Tests -i and -o parameters
    assert main() == 0
    assert main() == 0
    assert main() == 0


if __name__ == "__main__":
    sys

# Generated at 2022-06-23 22:27:05.087135
# Unit test for function main
def test_main():
    print(main())


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:27:14.601078
# Unit test for function main
def test_main():
    # Test with valid arguments
    sys.argv = ['py-backwards', '-i', 'test/data/compiler/file1.py', '-o', 'compiler/output',
                '-t', '2.7', '-d']
    assert main() == 0

    # Test with invalid arguments
    sys.argv = ['py-backwards', '-i', 'test/data/compiler/file1.py', '-o', 'compiler/output',
                '-t', '2.7', '-d', '-i', 'compiler/output']
    assert main() != 0
    # Reset
    sys.argv = []
    # Test with invalid target

# Generated at 2022-06-23 22:27:21.162429
# Unit test for function main
def test_main():
    os.chdir(os.path.dirname(__file__))
    open('../test3/sum.py', 'w').write('def sum(a, b):\n return a + b\n')
    sys.argv = ['py-backwards', '-i', '../test3/', '-o', '../test1/',
                '-r', '../test3/', '-t', '2.7']
    main()
    assert os.path.isfile('../test1/sum.py')
    assert os.path.isfile('../test1/__init__.py')
    open('../test1/sum.py', 'r').read() == 'def sum(a, b):\n return a + b\n'
    open('../test1/__init__.py', 'r').read

# Generated at 2022-06-23 22:27:27.734777
# Unit test for function main
def test_main():
    # Test for success execution
    main()

    # Test for success for different output
    main(input=["tests/unit/examples/3.6.py"],
         output="tests/unit/examples/3.6_output.py",
         target="2.7")

    # Test for success for different input output
    main(input="tests/unit/examples",
         output="tests/unit/examples/output",
         target="2.7")

    # Test for exception with unknown input
    main(input=["tests/unit/examples/unknown.py"],
         output="tests/unit/examples/3.6_output.py",
         target="2.7")

    # Test for exception with unknown output

# Generated at 2022-06-23 22:27:28.468085
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:27:37.341892
# Unit test for function main
def test_main():
    # If function main is called with no argument,
    # a message is printed on the error ouput
    sys.argv.append('-h')
    import io
    import contextlib
    buffer_ = io.StringIO()
    with contextlib.redirect_stderr(buffer_):
        main()
    #sys.stdout.write(buffer_.getvalue())

# Generated at 2022-06-23 22:27:48.202168
# Unit test for function main
def test_main():
    dir = 'test_data/test_main/'
    if not os.path.exists(dir):
        os.makedirs(dir)
    with open(dir + 'test_file.py', 'w') as f:
        f.write('x*x')
    with open(dir + 'test_file2.py', 'w') as f:
        f.write('x**x')
    main()
    main(['-i', dir + 'test_file.py', '-o', dir + 'out_file.py', '-t', '3.5'])
    main(['-i', dir + 'test_file2.py', '-o', dir + 'out_file2.py', '-t', '3.5'])

# Generated at 2022-06-23 22:27:53.451589
# Unit test for function main
def test_main():
    args = sys.argv[1:]

    args.append('-i')
    args.append('test/test_input/test_input_1.py')
    args.append('-o')
    args.append('test/test_output/output.py')
    args.append('-t')
    args.append('py27')
    main()

# Generated at 2022-06-23 22:27:54.232789
# Unit test for function main
def test_main():
    assert main() == sys.exit(1)

# Generated at 2022-06-23 22:27:55.112449
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:59.452583
# Unit test for function main
def test_main():
    input = 'tests/really_simple_file.py'
    output = 'test.py'
    target = sys.version_info[0]
    argv = ['-i', input, '-o', output, '-t', str(target)]
    main(argv)
    assert os.path.exists(output)
    os.remove(output)

# Generated at 2022-06-23 22:28:04.926109
# Unit test for function main
def test_main():
    sys.argv = ['none', '-i' , '/Users/riika/Documents/python_scripts/Lab3/my' ,
    '-o', '/Users/riika/Documents/python_scripts/Lab3/out', '-t', '2.7',
    '-r', '/Users/riika/Documents/python_scripts/Lab3/my']
    #sys.argv = ['none', '-i', 'F:/PythonProjects/python-examples/my',
    # '-o', 'F:/PythonProjects/python-examples/my/out', '-t', '3.5',
    # '-r', 'F:/PythonProjects/python-examples/my']
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:28:06.153659
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:09.766650
# Unit test for function main
def test_main():
    sys.argv[1:] = '-i anaconda/tests -o anaconda/tests_bytecode -t 3.5 \
                   -r anaconda/tests -d'.split()
    assert main() == 0

# Generated at 2022-06-23 22:28:10.335324
# Unit test for function main
def test_main():
  assert main() == 0

# Generated at 2022-06-23 22:28:13.956006
# Unit test for function main
def test_main():
    sys.argv[1:] = ['--input=example/good/6.py',
                    '--output=tests/output.py',
                    '--target=3.5',
                    '--root=example/good',
                    '--debug']
    assert main() == 0
    assert sys.argv[1:] != []

# Generated at 2022-06-23 22:28:17.864195
# Unit test for function main
def test_main():
    sys.argv = ["-i", "tests/fixtures/test_module.py",
                "-o", "test_module.compiled",
                "-t", "2.7"]
    assert main() == 0


# Generated at 2022-06-23 22:28:24.778493
# Unit test for function main
def test_main():
    # Using sys to redirect stderr and stdout.
    sys.stderr = StringIO()
    sys.stdout = StringIO()

    # Test usage of program without param
    # Expect return error message
    main()
    out = sys.stderr.getvalue()
    assert out == messages.usage() + '\n'

    # Test usage of program with param -i without additional params
    # Expect return error message
    sys.stderr = StringIO()
    sys.stdout = StringIO()
    main(['-i'])
    out = sys.stderr.getvalue()
    assert out == messages.usage() + '\n'

    # Test usage of program with param -o without additional params
    # Expect return error message
    sys.stderr = StringIO()
    sys.stdout = String

# Generated at 2022-06-23 22:28:34.056281
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:28:41.304689
# Unit test for function main
def test_main():
    from io import StringIO
    from . import conf

    sys.argv = [
        'py-backwards',
        '-i', 'tests/foo.py',
        '-o', 'tests/foo.py',
        '-t', '3.3',
        '-r', 'tests',
        '-d',
    ]

    with StringIO() as s, StringIO() as e:
        sys.stdout = s
        sys.stderr = e
        result = main()
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__

        assert result == 0
        assert conf.DEBUG
        assert e.getvalue() == ''
        assert s.getvalue() == 'All files were compiled\n'

# Generated at 2022-06-23 22:28:44.587239
# Unit test for function main
def test_main():
    # check that an error occurs if input or output isn't specified
    assert main(['-t', '3']) == 2
    assert main(['-i', 'file.py', '-t', '3']) == 2
    assert main(['-i', 'file.py', '-o', 'res.py', '-t', '3']) == 2

# Generated at 2022-06-23 22:28:48.260381
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input_folder', '-o', 'output_folder', '-t', 'python36', '-r', 'root_folder']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:57.336922
# Unit test for function main

# Generated at 2022-06-23 22:28:58.338199
# Unit test for function main
def test_main():
    assert 1 == main()

# Generated at 2022-06-23 22:29:00.320738
# Unit test for function main
def test_main():
    args = main()
    assert args == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:01.586097
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:05.382398
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', '/tests/resources/foo.py',
        '-o', '/tests/resources/foo_out.py',
        '-t', '3.5',
        '-r', 'tests/resources'
    ]

    assert main() == 0

# Generated at 2022-06-23 22:29:15.443865
# Unit test for function main
def test_main():
    # Checking whether main function works with correct input
    sys.argv = ['py-backwards', '-i', 'examples', '-o', 'py_backwards_test',
                '-t', 'py36', '-r', 'examples']

    assert main() == 0

    # Checking whether main function works with incorrect input
    sys.argv = ['py-backwards', '-i', 'no_input', '-o', 'py_backwards_test',
                '-t', 'py36', '-r', 'examples']

    assert main() == 1

    # Checking whether main function works with incorrect output
    sys.argv = ['py-backwards', '-i', 'examples', '-o', 'examples',
                '-t', 'py36', '-r', 'examples']


# Generated at 2022-06-23 22:29:19.626916
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv += ['-i', 'tests/test_data/source/main.py', '-o', './output']
    sys.argv += ['-t', '2.7']
    sys.argv += ['-d', '']
    main()

# Generated at 2022-06-23 22:29:30.769611
# Unit test for function main
def test_main():
    if len(sys.argv) < 2:
        return
    if len(sys.argv) < 4:
        sys.argv += ["-i", sys.argv[-1]]
    if len(sys.argv) < 6:
        sys.argv += ["-o", sys.argv[-1]]
    if len(sys.argv) < 8:
        sys.argv += ["-t", sys.argv[-1]]
    if len(sys.argv) < 10:
        sys.argv += ["-r", sys.argv[-1]]
    if len(sys.argv) < 12:
        sys.argv += ["-d", sys.argv[-1]]
    main()

# Generated at 2022-06-23 22:29:37.941616
# Unit test for function main
def test_main():
    from tempfile import NamedTemporaryFile
    from glob import glob
    from os.path import join

    import pytest
    from subprocess import run, PIPE

    with NamedTemporaryFile('w') as ntf:
        ntf.write("""
        def p(x: int) -> str:
            return str(x)

        def main():
            print(p(100))
        """)
        ntf.flush()
        res = run([sys.executable, 'py-backwards.py',
                   '-t', 'python2.7', '-i', ntf.name, '-o', './'],
                  stdout=PIPE, stderr=PIPE)

        assert res.stderr == b''
        assert './' in res.stdout.decode()

# Generated at 2022-06-23 22:29:44.135416
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards'] + '-i input.py -o output.py -t py35'.split()
    main() # should raise an exception
    sys.argv = ['py-backwards'] + '-i input.py -o output.py -t py36'.split()
    main() # should raise an exception
    sys.argv = ['py-backwards'] + '-i input.py -o output.py -t py27'.split()
    main() # should raise an exception
    sys.argv = ['py-backwards'] + '-i fake.py -o output.py -t py27'.split()
    main() # should raise an exception

# Generated at 2022-06-23 22:29:52.735455
# Unit test for function main
def test_main():
    """
    Unit test for function main().
    """
    init_settings(['-i', 'test/test_main_compile_func_pos.py',
                   '-o', 'test/test_main_compile_func_pos_out.py',
                   '-t', '2.7'])
    main()
    init_settings(['-i', 'test/test_main_compile_func_neg.py',
                   '-o', 'test/test_main_compile_func_neg_out.py',
                   '-t', '2.7'])
    assert 1 == main()
    init_settings(['-i', 'test', '-o', 'test_out', '-t', '2.7', '-d'])
    main()

# Generated at 2022-06-23 22:29:53.471790
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:54.127184
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:58.012124
# Unit test for function main
def test_main():
    sys.argv = ['..', '-i', 'tests/input/', '-o', 'output.py', '-r',
                'tests/input/', '-d', '-t', 'python2.7']
    assert main() == 0

# Generated at 2022-06-23 22:30:02.229701
# Unit test for function main
def test_main():
    sys.argv.extend(['--input', 'tests/basic.py', '--output', 'src.py',
                     '--debug', '--target', '2.7'])
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:02.829082
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:13.411427
# Unit test for function main
def test_main():
    class TestException(Exception):
        pass

    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', 'py36',
                '-r', 'root']

    def run_unit_test(exception, msg, rc=1):
        try:
            main()
        except exception as e:
            assert msg == str(e)
        else:
            assert False, 'Exception {} not raised'.format(exception)
        assert rc == rc

    with patch('sys.argv', ['py-backwards', '-i', 'input']):
        run_unit_test(SystemExit, '2')

    with patch('sys.argv', ['py-backwards', '-o', 'output']):
        run_unit_test(SystemExit, '2')



# Generated at 2022-06-23 22:30:18.362564
# Unit test for function main
def test_main():
    sys.exit = lambda: None
    sys.argv = [
        'py-backwards',
        '--input',
        'tests/test_compiler/test_input',
        '--output',
        'tests/test_compiler/test_output',
        '--target',
        '3.5',
        '--debug'
    ]
    assert main() == 0

# Generated at 2022-06-23 22:30:19.791374
# Unit test for function main
def test_main():
    # Insert here some code to be tested
    pass


# Generated at 2022-06-23 22:30:22.979938
# Unit test for function main
def test_main():
    # Writing output to dev/null
    sys.stdout = open(os.devnull, "w")
    print(main())
    # Changing output back to default
    sys.stdout = sys.__stdout__


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:24.377216
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:28.454860
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "./test/test_files/test.py", "-o", "./output", "-t", "2"]
    main()
    assert sys.argv[2] == "-i"


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:30:28.853519
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:29.233548
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:30:29.814258
# Unit test for function main
def test_main():
    assert main()==0

# Generated at 2022-06-23 22:30:32.104706
# Unit test for function main
def test_main():
    main('-i test/fixtures/single_file -o test/fixtures/single_file_output -t 3_5'
         .split())

# Generated at 2022-06-23 22:30:40.788925
# Unit test for function main
def test_main():
    # if sys.argv[1] is not None and sys.argv[2] is not None:
    #   main(sys.argv[1], sys.argv[2])
    # else:
    #   print('Invalid Argument passed')
    #   if sys.argv[1] is None:
    #     arg1 = str(input('Enter argument 1: '))
    #   if sys.argv[2] is None:
    #     arg2 = str(input('Enter argument 2: '))
    #   main(arg1, arg2)
    
    assert main()== 0

# Generated at 2022-06-23 22:30:46.251213
# Unit test for function main
def test_main():
    argv = ['--input', 'test.py', '--output', 'test_out.py', '--target', 'py35']
    args = main(argv)
    assert args.input == 'test.py'
    assert args.output == 'test_out.py'
    assert args.target == 'py35'


# Generated at 2022-06-23 22:30:46.889851
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:47.344829
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:48.365597
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:48.908866
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:56.100430
# Unit test for function main
def test_main():
    from io import StringIO
    from os import curdir, sep, rmdir
    from tempfile import mkstemp
    from contextlib import contextmanager
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-23 22:31:03.671086
# Unit test for function main
def test_main():
    import io
    import tempfile

    source = io.BytesIO('\xef\xbb\xbfprint(lambda x: x+1)(2)'.encode('utf8'))
    with tempfile.NamedTemporaryFile(mode="wb") as target:
        sys.argv = ['py-backwards', '-i', source.name, '-o', target.name, '-t', '3.3', '-r', '']
        assert main() == 0
        assert target.read().decode('utf8') == '\xef\xbb\xbfprint(3)\n'

    # Test with directory

# Generated at 2022-06-23 22:31:06.714060
# Unit test for function main
def test_main():
    try:
        main('-i', './tests/resources/simple_file.py', '-o', './output')
        main('-i', './tests/resources/simple_file.py', '-o', './output', '-t', 'python27')
    except SystemExit as e:
        return e.code


# Generated at 2022-06-23 22:31:13.656651
# Unit test for function main
def test_main():
    import sys
    import io
    import pytest
    from unittest.mock import patch
    sys.stdout = io.StringIO()
    with patch('sys.argv', ['py_backwards', '-i', 'tests/sources', '-o', 'tests/sources_new', '-t', '3.5']):
        main()
        assert sys.stdout.getvalue() == 'Success\n'
    sys.stdout = io.StringIO()
    with patch('sys.argv',
               ['py_backwards', '-i', 'tests/sources', '-o', 'tests/test_file.py', '-t', '3.5']):
        main()
        assert sys.stdout.getvalue() == 'Success\n'
    sys.stdout = io.StringIO

# Generated at 2022-06-23 22:31:15.488343
# Unit test for function main
def test_main():
    sys.argv = [__file__, '-i', 'examples', '-o', 'output', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-23 22:31:16.954797
# Unit test for function main
def test_main():
    import os
    os.system('python -m unittest test_main.py')

# Generated at 2022-06-23 22:31:24.543877
# Unit test for function main
def test_main():
    args = ['-i', 'py-backwards/test/test_files/test.py', '-o',
            'py-backwards/test/test_files/test_out.py', '-t',
            'python3.5']
    sys.argv = sys.argv[:1] + args
    main()
    with open('py-backwards/test/test_files/test_out.py', 'r') as f:
        lines = f.readlines()
        assert any('unsupported' in line for line in lines)

# Generated at 2022-06-23 22:31:25.865486
# Unit test for function main
def test_main():
    assert main()

#test_main()

# Generated at 2022-06-23 22:31:31.468464
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'test/test_input/test.py',
                '-o', 'test/test_output/test.py', '-t', '27', '-d']
    assert main() == 0
    if os.path.exists('test/test_output/test.py'):
        os.remove('test/test_output/test.py')

# Generated at 2022-06-23 22:31:41.984735
# Unit test for function main
def test_main():
    from py_backwards.tests import test_utils
    assert test_utils.run_main('py_backwards.__main__.main') == 0
    assert test_utils.run_main('py_backwards.__main__.main',
                               ['-i', 'test/test_files/test_json.py',
                                '-o', 'test/test_files/test_json_output.py',
                                '-t', '2.7', '-r', 'test/test_files']) == 0

# Generated at 2022-06-23 22:31:42.505015
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:45.113450
# Unit test for function main
def test_main():
    pass
    #parser = ArgumentParser('py-backwards')


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:49.554376
# Unit test for function main
def test_main():
    command_line_args = ["-i", "tests/input/", "-o", "tests/output/", "-t", "3.4", "-r", "tests/root/", "-d"]
    sys.argv = command_line_args
    main()

if __name__ == '__main__':
    #test_main()
    sys.exit(main())

# Generated at 2022-06-23 22:31:57.829021
# Unit test for function main
def test_main():
    test = mock.Mock()
    test.add_argument = mock.Mock()
    test.parse_args = mock.Mock()
    test.parse_args.return_value = mock.Mock()
    test.parse_args.return_value.input = 'input'
    test.parse_args.return_value.output = 'output'
    test.parse_args.return_value.target = '3.3'
    test.parse_args.return_value.debug = False
    test.parse_args.return_value.root = ''

    main(test)
    ce = exceptions.CompilationError('Error:')
    pe = PermissionError('Permission error')
    ioe = exceptions.InputDoesntExists('Error:')
    iooe = exceptions.InvalidInputOutput('Error', 'Error')
   

# Generated at 2022-06-23 22:32:05.295066
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_files', '-o', 'test_output', '-t', '3.4']
    assert (main() == 0)
    sys.argv = ['py-backwards', '-i', 'test_files', '-o', 'test_output', '-t', '3.7']
    assert (main() == 0)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:06.710677
# Unit test for function main
def test_main():
    assert main("test.py", "dest.py", "Python26") == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:08.097514
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except:
        assert False

# Generated at 2022-06-23 22:32:17.915413
# Unit test for function main
def test_main():
    with patch('sys.argv', ['py-backwards', '--input', 'tests/compilation',
                            '--output', 'build_test','--target', '3.4',
                            '--root', 'tests']):
        main()
    assert os.path.exists('build_test')
    assert os.path.exists('build_test/__init__.py')
    assert os.path.exists('build_test/for_tests.py')
    assert os.path.exists('build_test/tests')
    assert os.path.exists('build_test/tests/__init__.py')
    assert os.path.exists('build_test/tests/for_tests.py')
    assert os.path.exists('build_test/tests/fibonacci.py')
   

# Generated at 2022-06-23 22:32:25.908233
# Unit test for function main
def test_main():
    parser = ArgumentParser()
    parser.add_argument('-i', type=str, nargs='+', required=True)
    parser.add_argument('-o', type=str, required=True)
    parser.add_argument('-d', action='store_true', required=False)
    parser.add_argument('-t', type=str, required=True,
                        choices=const.TARGETS.keys())
    parser.add_argument('-r', type=str, required=False)
    result = main()
    assert result == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:33.933188
# Unit test for function main
def test_main():
    # x = main("/home/danil93/src/py-backwards/src","/home/danil93/src/py-backwards/src/output.py","3.5")
    # assert x == 0
    # x = main("/home/danil93/src/py-backwards/src","/home/danil93/src/py-backwards/src/output.py","2.7")
    # assert x == 1
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:42.068029
# Unit test for function main
def test_main():
    # inputs = ['tests/data/source/python/unittest.py',
    #           'tests/data/source/python/unittest_types.py',
    #           'tests/data/source/python/unittest2.py']
    inputs = ['tests/data/source/python/']
    output = os.path.normpath('tests/data/source/python/tests/')
    target = 'python27'
    root = os.path.normpath(os.path.dirname(os.path.dirname(__file__)))
    args = Namespace(input=inputs, output=output, target=target, root=root)
    init_settings(args)

    assert main() == 0

# Generated at 2022-06-23 22:32:52.326441
# Unit test for function main
def test_main():
    args = '-i test_compiler/input/ -o test_compiler/output -t python2.7'
    arg = args.split(' ')
    init_settings(arg)
    try:
        for input_ in arg[1]:
            result = compile_files(input_, arg[3],
                                   const.TARGETS[arg[5]],
                                   arg[7])
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1
    except exceptions.TransformationError as e:
        print(messages.transformation_error(e), file=sys.stderr)
        return 1

# Generated at 2022-06-23 22:32:52.756294
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:55.169347
# Unit test for function main
def test_main():
    import pytest

    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 2


# Generated at 2022-06-23 22:32:59.715921
# Unit test for function main
def test_main():
    input_file = open("testfile","w")
    input_file.write("print(hello)")
    input_file.close()
    input_file = open("testfile2","w")
    input_file.write("print(hello)")
    input_file.close()
    assert main() == 1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:06.694089
# Unit test for function main
def test_main():
    with mock.patch('sys.argv',
                    ['py-backwards', '-t', '3.6', '-i', 'input', '-o',
                     'output']):
        with mock.patch('argparse.ArgumentParser.parse_args', return_value={
            'input': ['input'],
            'output': 'output',
            'target': '3.6',
            'root': '',
            'debug': True
        }):
            with mock.patch('builtins.input', return_value='y'):
                with mock.patch('pybackwards.compiler.compile_files',
                                return_value={
                                    'input': '', 'output': 'output/'}):
                    assert main() == 0


# Generated at 2022-06-23 22:33:07.143279
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:12.206611
# Unit test for function main
def test_main():
    init_settings()
    assert 0 == main(['-i', 'tests/test_data/', '-o', 'tests/output',
                      '-t', '2.7', '-r', 'tests'])
    assert 1 == main(['-t', '2.7'])
    assert 1 == main(['-i', 'tests/test_data/', '-o', 'tests/test_data',
                      '-t', '2.7', '-r', 'tests'])
    assert 1 == main(['-i', 'tests/test_data', '-o', 'tests/test_data',
                      '-t', '2.7', '-r', 'tests'])

# Generated at 2022-06-23 22:33:16.133603
# Unit test for function main
def test_main():
    import pytest
    sys.argv = ['py-backwards', '-i', '../tests', '-o', 'output', '-t', '36']
    assert main() == 0


# Generated at 2022-06-23 22:33:21.696696
# Unit test for function main
def test_main():
    input_ = [os.getcwd() + "\\tests\\test.py",
              os.getcwd() + "\\tests\\input\\test2.py"]
    output = os.getcwd() + "\\tests\\output"
    target = "2"
    root = os.getcwd()
    debug = True
    assert main(input_, output, target, root, debug) == 0

if __name__ == '__main__':
    code = main()
    sys.exit(code)

# Generated at 2022-06-23 22:33:28.712770
# Unit test for function main
def test_main():
    arguments = ['-i', 'test/source/test_1.py',
                 '-o', 'test/build/test_1.py',
                 '-t', '2.7',
                 '-r', 'test/source']

    # correct compilation
    assert main(arguments) == 0

    # incorrect python version
    arguments[5] = '3'
    assert main(arguments) == 1

    # pp.log.set_log_level(pp.log.LogLevel.DEBUG)

    # input file doesn't exist
    arguments[1] = 'test/source/does_not_exist'
    assert main(arguments) == 1

    # output doesn't exist
    arguments[1] = 'test/source/test_1.py'
    assert main(arguments) == 1

    # input is directory
   

# Generated at 2022-06-23 22:33:30.416608
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        main()

# Generated at 2022-06-23 22:33:31.640952
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:32.923467
# Unit test for function main
def test_main():
    # function main exists
    assert callable(main)


# Tests

# Generated at 2022-06-23 22:33:43.308569
# Unit test for function main
def test_main():
    old_stderr = sys.stderr
    print("Test_main.")
    try:
        old_argv = sys.argv
        sys.argv = ['py-backwards', '--input', 'tests/test_data', '--output',
                    'output_test_data', '--target', '3.4', '--root',
                    'output_test_data']
        out = StringIO()
        sys.stderr = out
        main()
        output = out.getvalue().strip().split('\n')[-1]
    finally:
        sys.argv = old_argv
        sys.stderr = old_stderr
    assert output == 'Compiled 11 files'

# Generated at 2022-06-23 22:33:43.751634
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:51.394688
# Unit test for function main
def test_main():
    # Testing argument without value
    sys.argv = [sys.argv[0], '-i', 'a b', '-o', 'c', '-t', '2.7']
    assert main() == 1

    # Testing argument without value
    sys.argv = [sys.argv[0], '-i', 'a', '-o', 'b', '-t', '2.7']
    assert main() == 1

    # Testing unknown argument
    sys.argv = [sys.argv[0], '-i', 'a', '-a']
    assert main() == 1

    # Testing unknown target
    sys.argv = [sys.argv[0], '-i', 'a', '-o', 'b', '-t', '2.6']
    assert main() == 1

    # Testing file

# Generated at 2022-06-23 22:33:53.841060
# Unit test for function main
def test_main():
    from unittest import mock

    with mock.patch('sys.argv', ['py-backwards', '-i', '1.py',
                                              '-o', 'output.py',
                                              '-t', '3.5',
                                              '-r', 'root',
                                              '-d']):
        main()

# Generated at 2022-06-23 22:34:03.303205
# Unit test for function main
def test_main():
    from tempfile import mkdtemp
    import os
    import shutil

    # Args for compiler
    args = ['init.py']
    temp_dir = mkdtemp()
    out_dir = mkdtemp()
    args.append('-i')
    args.append(temp_dir)
    args.append('-o')
    args.append(out_dir)
    args.append('-t')
    args.append('27')
    args.append('-r')
    args.append(temp_dir)

    # Prepare inputs
    os.mkdir(os.path.join(temp_dir, 'main'))
    with open(os.path.join(temp_dir, 'init.py'), 'w') as f:
        f.write('from main import main\nprint(main())')

# Generated at 2022-06-23 22:34:04.548157
# Unit test for function main
def test_main():
    ret = main()
    assert ret == 1
    assert ret != 0

# Generated at 2022-06-23 22:34:08.254433
# Unit test for function main
def test_main():
    sys.argv = [
        '',
        '-i', 'test/test_data/add.py',
        '-t', '3.6',
        '-o', 'test/test_output'
    ]
    assert main() == 0

# Generated at 2022-06-23 22:34:11.688053
# Unit test for function main
def test_main():
    args = ['-i', 'test/test3.py', '-o', '/Users/user/test', '-t', '2.7', '-r', 'test', '-d']
    assert main(args) == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:34:12.178631
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:34:15.519597
# Unit test for function main
def test_main():
    sys.argv = ['', "-i", "test/", "-o", "output/", "-t", "2.7", "-r", "test/"]
    assert main() == 0



# Generated at 2022-06-23 22:34:16.483472
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:20.595301
# Unit test for function main
def test_main():
    args = ['-i', './tests/input.py', '-o', './tests/output.py', '-t', 'python27', '-r', '.']
    assert main(args) == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:34:23.396809
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except SystemExit:
        pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:33.060401
# Unit test for function main
def test_main():
    parser = ArgumentParser()
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str, required=True,
                        help='target python version')
    parser.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')

    parser.parse_args()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:34:43.911343
# Unit test for function main
def test_main():
    from io import StringIO
    from os import remove
    from quit_compiler import quit_parser
    from quit_compiler.compiler import compile_files
    from quit_compiler.exceptions import InputDoesntExists, InvalidInputOutput
    from quit_compiler.conf import init_settings
    from quit_compiler.messages import permission_error, compilation_result, \
        input_doesnt_exists, invalid_output, syntax_error, transformation_error

    init_settings(None)

    # Testing compilation
    file_name = "test_file.py"

    file = open(file_name, "w")
    file.write("a = 10\nb = 20\nc = 30")
    file.close()

    out_stream = StringIO()
    sys.stdout = out_stream
    args = quit_

# Generated at 2022-06-23 22:34:54.095172
# Unit test for function main
def test_main():
    # Initializing the parser
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add_argument

# Generated at 2022-06-23 22:34:54.995678
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:34:57.523455
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'new.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-23 22:35:08.033175
# Unit test for function main
def test_main():
    input_ = "file.py"
    output = "file2.py"
    target = "2.7"
    result = main()
    assert result == 1
    input_ = "file.py"
    result = main()
    assert result == 1
    output = "file.py"
    result = main()
    assert result == 1
    target = "2.8"
    result = main()
    assert result == 0
    output = "file2.py"
    result = main()
    assert result == 0
    input_ = "test.py"
    result = main()
    assert result == 1
    input_ = "test2.py"
    result = main()
    assert result == 1
    input_ = "test3.py"
    result = main()
    assert result == 1

# Generated at 2022-06-23 22:35:08.535047
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:13.162825
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('test_file.py')
    sys.argv.append('-o')
    sys.argv.append('/home/user/test_file_out.py')
    sys.argv.append('-t')
    sys.argv.append('2')
    assert main() == 1


# Generated at 2022-06-23 22:35:14.499760
# Unit test for function main
def test_main():
    print('main')

# Generated at 2022-06-23 22:35:22.966151
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from io import StringIO

    with patch('sys.argv', ['-i', 'test.in', '-o', 'test.out', '-t', '2.7']):
        sys.stderr = StringIO()
        with patch('builtins.open', side_effect=FileNotFoundError):
            assert main() == 1

    with patch('sys.argv', ['-i', 'test.in', '-o', 'test.in', '-t', '2.7']):
        sys.stderr = StringIO()
        with patch('builtins.open', side_effect=PermissionError):
            assert main() == 1


# Generated at 2022-06-23 22:35:29.144020
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_inputs/test_main_input',
                '-o', 'tests/test_outputs/test_main_output', '-t', '2.5',
                '-r', 'tests']
    assert(main() == 0)


# Generated at 2022-06-23 22:35:35.123256
# Unit test for function main
def test_main():
    args = ['-i', 'test_data/test_input.py',
            '-o', 'test_data/test_output.py',
            '-t', '2.7']
    with patch.object(
            sys, 'argv', ['py-backwards'] + args):
        assert main() == 0

    with patch.object(
            sys, 'argv', ['py-backwards'] + args + ['-d']):
        assert main() == 0

# Generated at 2022-06-23 22:35:39.521376
# Unit test for function main
def test_main():
    args = ['--input','py-backwards/compiler/tests/io','--output','py-backwards/compiler/tests/output','--target','2.7','--root','py-backwards/compiler/tests/io']
    assert main(args) == 0

# Generated at 2022-06-23 22:35:43.590376
# Unit test for function main
def test_main():
    def run(args):
        _sys_argv = sys.argv
        sys.argv = args
        main()
        sys.argv = _sys_argv

    run(['test_main.py', '-i', 'input', '-o', 'output', '-t', 'py36'])

# Generated at 2022-06-23 22:35:46.157008
# Unit test for function main
def test_main():
    # Checking valid input
    try:
        main()
    except SystemExit:
        pass

    # Checking if pb-compiler is not a module
    assert sys.modules[__package__] is None
    assert sys.modules['pb-compiler'] is None

# Generated at 2022-06-23 22:35:46.668011
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:35:48.726830
# Unit test for function main
def test_main():
    assert main(["example.py", "example2.py"], "output.py", "Python2.7", "py2") == 0

# Generated at 2022-06-23 22:35:59.017581
# Unit test for function main
def test_main():
    test_args = sys.argv[1:]
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t',
                '2.7', '-r', 'sources-root']

    res = main()
    assert res == 0

    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t',
                '2.7']

    res_1 = main()
    assert res_1 == 0

    sys.argv = ['py-backwards', '-i', 'input.py', 'input1.py', '-o',
                'output.py', '-t', '2.7']

    res_2 = main()
    assert res_2 == 0



# Generated at 2022-06-23 22:35:59.692218
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:03.492095
# Unit test for function main
def test_main():
    args = argparse.Namespace(input='../tests/scripts/if_stmt_1.py', output='../tests/scripts/if_stmt_1_target.py',
                              target='3.4', root=None, debug=False)
    with mock.patch('argparse.ArgumentParser', autospec=True):
        assert main() == 0

# Generated at 2022-06-23 22:36:15.171120
# Unit test for function main
def test_main():
    from subprocess import Popen, PIPE, call
    from os.path import abspath, dirname, join
    from shutil import rmtree
    from tempfile import mkdtemp
    from textwrap import dedent

    temporary_root = mkdtemp()

    script_file = open(join(temporary_root, 'script.py'), mode='w')
    script_file.write(dedent("""\
        def my_function(n, m):
            print(n + m)
    """))
    script_file.close()


# Generated at 2022-06-23 22:36:16.604422
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:36:17.099341
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:22.667874
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i',
        'test/test_files/source_files',
        '-o',
        'test/test_files/results',
        '-t',
        '2.7'
    ]

    sys.stdout = StringIO()
    main()
    result = sys.stdout.getvalue()
    assert result == 'Successful compilation: test/test_files/source_files -> ' \
                     'test/test_files/results\n'

# Generated at 2022-06-23 22:36:31.954582
# Unit test for function main
def test_main():
    # Test case 1
    # Input: in - py-backwards -i src -o out -t python3.5 -r /
    # Expected result: True
    a = ['-i', 'src', '-o', 'out', '-t', 'python3.5', '-r', '/']
    assert main(a) == 0

    # Test case 2
    # Input: in - py-backwards -i src -o out -t python3.5
    # Expected result: True
    a = ['-i', 'src', '-o', 'out', '-t', 'python3.5']
    assert main(a) == 0

    # Test case 3
    # Input: in - py-backwards -i src -o out -t python3.5 -r / --debug
    # Expected result: True
