

# Generated at 2022-06-23 22:26:30.519717
# Unit test for function main
def test_main():
    assert main() == 0
    # assert main([]) == 0

# Generated at 2022-06-23 22:26:40.603417
# Unit test for function main
def test_main():
    from unittest.mock import call, patch
    from . import compiler, conf

    init_settings = conf.init_settings
    init_settings = patch('backwards.main.init_settings').start()
    compile_files = compiler.compile_files
    compile_files = patch('backwards.main.compile_files').start()

    argv = ['-i', 'input_file', '-o', 'output_file', '-t', '3.5', '-r',
            '/root/folder']
    with patch('sys.argv', argv):
        main()


# Generated at 2022-06-23 22:26:52.012500
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:27:02.086507
# Unit test for function main
def test_main():
    # Unit test for function main
    # input: [
    #     '-i', 'test\\compiler\\tests\\test1\\test.py', 
    #     '-o', 'test\\compiler\\tests\\test1\\test1_output.py', 
    #     '-t', 'python2', 
    #     '-r', 'test\\compiler', 
    #     '-d'
    # ]
    # expected output: 0
    assert main() == 0
    # input: [
    #     '-i', 'test\\compiler\\tests\\test1\\test.py', 
    #     '-o', 'test\\compiler\\tests\\test1\\test1_output.py', 
    #     '-t', 'python2', 
    #     '-r', 'test\\

# Generated at 2022-06-23 22:27:08.175616
# Unit test for function main
def test_main():
    target = 'python 2'
    args = ['-i', 'tests/fake_input_file.py', '-o', 'tests/fake_output_file.py',
            '-t', target]
    saved_argv = sys.argv
    sys.argv = [sys.argv[0]] + args
    assert main() == 0
    sys.argv = saved_argv

    target = 'python 3.6'
    args = ['-i', 'tests/fake_input_file.py', '-o', 'tests/fake_output_file.py',
            '-t', target]
    saved_argv = sys.argv
    sys.argv = [sys.argv[0]] + args
    assert main() == 1
    sys.argv = saved_argv

# Generated at 2022-06-23 22:27:11.290845
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards','-i','_test_files/test.py', '-o', '_test_files/test.out', '-t', '3.4', '-d']
    main()
    with open('_test_files/test.out') as f:
        content = f.readlines()
    assert content == ['print("Hello, world")\n', 'print((1,2,3))\n']

# Generated at 2022-06-23 22:27:18.491217
# Unit test for function main
def test_main():
    sys.argv = [
        sys.argv[0],
        '-i', sys.argv[0],
        '-o', 'test',
        '-t', '3.5',
        '-r', sys.argv[0],
    ]
    assert main() == 0
    sys.argv = [sys.argv[0]]
    try:
        main()
    except SystemExit:
        pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:19.126217
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:22.736184
# Unit test for function main
def test_main():
    sys.argv[1:] = ['--input=.', '--output=tests/files/', '--target=2.7']
    assert main() == 0
    sys.argv[1:] = ['--input=tests/files/', '--output=.', '--target=2.7']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:23.209054
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:25.722404
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as excinfo:
        #output = main(["--input", "bad_args"])
        main()
    #assert output == 1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:26.228679
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:27:36.307061
# Unit test for function main

# Generated at 2022-06-23 22:27:37.513676
# Unit test for function main
def test_main():
    result = main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:27:45.834403
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/examples/test_main.py', '-o', 'tests/examples/test_main_out.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/examples/test_main.py', '-o', 'tests/examples/test_main_out.py', '-t', '3.6']
    assert main() == 0



# Generated at 2022-06-23 22:27:51.310512
# Unit test for function main
def test_main():
    sys.argv = [
        'py_backwards',
        '-i', 'tests/input',
        '-o', 'tests/output',
        '-t', '3.5',
        '-r', 'tests/input',
        '-d'
    ]
    assert main() == 0

# Generated at 2022-06-23 22:27:59.796751
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], "-i", "tests/data/input/in1.py", "-o", "out.py",
                "-t", "2.7"]
    main()
    sys.argv = [sys.argv[0], "-i", "tests/data/input", "-o", "out1",
                "-t", "3.5"]
    main()
    sys.argv = [sys.argv[0], "-i", "tests/data/input", "-o", "tests/data/input/in1.py",
                "-t", "3.5"]
    main()
    sys.argv = [sys.argv[0], "-i", "tests/data/input", "-o", "out1",
                "-t", "3.4"]
    main()
   

# Generated at 2022-06-23 22:28:01.764851
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:12.647356
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:28:13.542881
# Unit test for function main
def test_main():
    # TODO
    pass

# Generated at 2022-06-23 22:28:18.798723
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i',
        './tests/test_data/test_coroutine.py',
        '-o',
        './tests/test_data/output',
        '-t',
        '2.7'
    ]
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:19.286120
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:21.010220
# Unit test for function main
def test_main():
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1

# Generated at 2022-06-23 22:28:26.241034
# Unit test for function main
def test_main():
    # if __name__ == '__main__':
    sys.argv = ['-i', 'tests/resources/source.py', '-o', 'out_test.py', '-t', '2.7']
    main()
    assert open('out_test.py').read() == open('tests/resources/python2.7/source.py').read()

# Generated at 2022-06-23 22:28:37.954975
# Unit test for function main
def test_main():
    value1 = ['-i', 'D:/PycharmProjects/py-backwards/tests/test_cases/simple_1.py', '-o', 'D:/PycharmProjects/py-backwards/tests/test_cases/out/simple_1_out.py', '-t', '2.7', '-d']
    sys.argv = sys.argv[:1] + value1

    test_main.argv = sys.argv
    assert main() == 0


# Generated at 2022-06-23 22:28:42.412830
# Unit test for function main
def test_main():
    sys.argv = [
        sys.argv[0],
        '-i', 'tests/units/sample_data/input/single_file',
        '-o', 'tests/units/sample_data/output',
        '-t', '3.5',
        '-r', 'tests/units/sample_data'
    ]
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:42.899919
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:28:48.393932
# Unit test for function main
def test_main():
    from .conf import settings
    from . import exceptions
    import os
    from os.path import join, abspath, dirname
    from shutil import rmtree
    from tempfile import mkdtemp
    from test.utils import calculate_hash, assert_hashes
    from argparse import Namespace
    sys.argv = ['py-backwards',
                '-i', 'test/sources/test_module.py',
                '-o', 'output.py',
                '-t', 'py2',
                '-r', 'test/sources']

    directory = mkdtemp()
    hash_dict = {}

# Generated at 2022-06-23 22:28:49.418248
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-23 22:28:51.424787
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:57.500950
# Unit test for function main
def test_main():
    class Args:
        def __init__(self, input_, output, target, root, debug):
            self.input = input_
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    i = Args(['py_backwards/tests/test_main.py'], 'py_backwards/tests',
             'python2.7', 'py_backwards/', True)
    r = main()
    assert r == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:02.561496
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'tests/sources/test.py',
        '-o', 'tests/output/test.py',
        '-t', 'py36',
        '-d',
        '-r', 'tests/sources/'
        ]
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:02.892721
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:04.758261
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

# Generated at 2022-06-23 22:29:09.450634
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_compilation_error.py', '-o', 'test_result.py', '-t', 'py27', '-r', 'test']
    result = main()
    assert 0 == result


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:14.714569
# Unit test for function main
def test_main():
    from unittest import mock
    from sys import stderr
    from colorama import Fore
    from .conf import settings
    from .exceptions import CompilationError, InputDoesntExists
    from .parse import SourceCode

    def _compile_files(input: str, output: str,
                       target: const.PythonVersion, root: str = None) -> \
            typing.List[SourceCode]:
        raise Exception()

    def _main(args: typing.List[str]) -> int:
        try:
            with mock.patch('sys.argv', args):
                ret = main()
        except SystemExit as e:
            ret = e.code
        return ret


# Generated at 2022-06-23 22:29:22.898105
# Unit test for function main
def test_main():
    init_settings(['py-backwards', '-i', 'test_compiler.py', '-o', 'test_compiler_out.py', '-t', '3.5', '-r', '.'])
    result = compile_files('test_compiler.py', 'test_compiler_out.py', const.TARGETS['3.5'], '.')
    assert result.compiled_files == 1
    with open('test_compiler_out.py') as f:
        assert 'f-strings' not in f.read()


# Generated at 2022-06-23 22:29:34.585893
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards","-i", "tests", "-o", "tests_out", "-t", "3.6", "-r", "tests"]
    assert main() == 0

    sys.argv = ["py-backwards","-i", "/home/not_exists", "-o", "tests_out", "-t", "3.6", "-r", "tests"]
    assert main() == 1

    sys.argv = ["py-backwards","-i", "tests", "-o", "tests/tests", "-t", "3.6", "-r", "tests"]
    assert main() == 1

    sys.argv = ["py-backwards","-i", "tests", "-o", "/home/not_exists/", "-t", "3.6", "-r", "tests"]

# Generated at 2022-06-23 22:29:35.054099
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:41.751762
# Unit test for function main
def test_main():
    import os
    import pytest
    from pathlib import Path
    import shutil

    def run_test(input, output, target, root, debug):
        sys.argv = [sys.argv[0]]
        if input:
            sys.argv.append("-i")
            sys.argv.append(input)
        if output:
            sys.argv.append("-o")
            sys.argv.append(output)
        if target:
            sys.argv.append("-t")
            sys.argv.append(target)
        if root:
            sys.argv.append("-r")
            sys.argv.append(root)
        if debug:
            sys.argv.append("-d")
        return sys.argv, main()


# Generated at 2022-06-23 22:29:43.983239
# Unit test for function main
def test_main():
    arg = ['./test/test_check/test_main.py', '-o', './test/test_output', '-t', '2.7', '-d']
    sys.argv = arg
    assert main() == 0, "main function is not working"

# Generated at 2022-06-23 22:29:52.859120
# Unit test for function main

# Generated at 2022-06-23 22:29:58.551361
# Unit test for function main
def test_main():
    sys.argv.append("-i")
    sys.argv.append("tests/test_case/fibo.py")
    sys.argv.append("-o")
    sys.argv.append("tests/test_case/output.py")
    sys.argv.append("-t")
    sys.argv.append("python3.5")
    assert main() == 0

# Generated at 2022-06-23 22:30:06.713945
# Unit test for function main
def test_main():
    if sys.executable != 'pytest':
        return
    sys.argv = ['py-backwards.py', '-i', 'tests/fixtures/simple_source.py',
                '-o', 'tests/fixtures/simple_source.py', '-t', '2.7']
    assert main() == 1
    sys.argv = ['py-backwards.py', '-i', 'tests/fixtures/simple_source.py',
                '-o', 'tests/fixtures/simple_source.py_transpiled.py',
                '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-23 22:30:10.087748
# Unit test for function main
def test_main():
    from .. import compiler, const, messages, exceptions, conf
    from colorama import init
    init()
    from argparse import ArgumentParser
    import sys

    assert main() == 1

main()

# Generated at 2022-06-23 22:30:10.717926
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:11.336997
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:17.414694
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 2
    assert 'show this help message' in sys.stderr.getvalue()
    sys.stderr.seek(0)
    sys.stderr.truncate(0)

    sys.argv.append('-h')
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 0



# Generated at 2022-06-23 22:30:28.035212
# Unit test for function main
def test_main():
    from .conf import SETTINGS
    from . import const
    main('-i', 'C:\\Users\\Marek\\Desktop\\train\\main.py', '-o',
         'C:\\Users\\Marek\\Desktop\\train\\main_out.py', '-t',
         '3.7', '-r', 'C:\\Users\\Marek\\Desktop\\train', '-d')
    assert SETTINGS['input'] == 'C:\\Users\\Marek\\Desktop\\train\\main.py'
    assert SETTINGS['output'] == 'C:\\Users\\Marek\\Desktop\\train\\main_out.py'
    assert SETTINGS['target'] == const.TARGETS['3.7']

# Generated at 2022-06-23 22:30:37.752919
# Unit test for function main
def test_main():
    test1 = ['py-backwards', '-i', 'sample', '-o', 'output', '-t', '3.5', '-r', '.', '-d']
    test2 = ['py-backwards', '-i', 'sample', '-o', 'output', '-t', '3.5', '-r', '.']
    test3 = ['py-backwards', '-i', 'sample', '-o', 'output', '-t', '3.5']
    test4 = ['py-backwards', '-i', 'sample', '-o', 'output', '-t', '3.5', '-d']
    test5 = ['py-backwards', '-i', 'sample', '-o', 'output', '-t', '3.6', '-r', '.']


# Generated at 2022-06-23 22:30:44.755669
# Unit test for function main
def test_main():
    import io
    import contextlib
    test_argv = ['argv', '-o', 'test/test1/tests/output',
                 '-i', 'test/test1/lib',
                 '-r', 'test/test1',
                 '-t', '3.4']
    test_stdout = io.StringIO()
    test_stderr = io.StringIO()
    with contextlib.redirect_stdout(test_stdout), \
        contextlib.redirect_stderr(test_stderr):
        main()
    assert test_stdout.getvalue() == 'Compiled 1 files\n'
    assert test_stderr.getvalue() == ''

# Generated at 2022-06-23 22:30:49.620883
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', '../source/main/dummy.py', '-o', '../output/dummy.py', '-t', '3.5', '-r', 'source']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:51.927625
# Unit test for function main
def test_main():
    args = main.__annotations__['return']
    assert args == int

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:52.993420
# Unit test for function main
def test_main():
    """
    Run function main
    """
    main()

# Generated at 2022-06-23 22:30:56.597495
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '--input', 'test_data', '--output', 'test_output',
                '--target', '3.5']
    main()

# Generated at 2022-06-23 22:31:00.242227
# Unit test for function main
def test_main():
    return main(['-i', 'tests/compiler_test_in/test_main.py',
                 '-o', 'build/tests/compiler_test_out/test_main.py',
                 '-t', '3.5',
                 '-r', 'tests/compiler_test_in',
                 '-d'])

# Generated at 2022-06-23 22:31:05.054310
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i', '..\\a.py', '-o', '..\\a2.py', '-t', '2.7', '-r', '..\\..\\']
    assert main() == 0
    os.remove('..\\a2.py')

# Generated at 2022-06-23 22:31:07.102029
# Unit test for function main
def test_main():
    raise NotImplementedError()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:12.111342
# Unit test for function main
def test_main():
    import sys
    sys.argv[1:] = ['-i', '../examples/for_py37.py', '-o', 'out', '-t',
                    '3.5', '-r', 'src']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:12.770314
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:14.472887
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:17.964366
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'examples/class_var.py', '-o', 'examples/output', '-t', '3.5', '-r', 'examples']
    assert main() == 0


# Generated at 2022-06-23 22:31:22.214700
# Unit test for function main
def test_main():
    assert main() == 1
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    # Write unit test for exceptions here

# Generated at 2022-06-23 22:31:23.220528
# Unit test for function main
def test_main():
    pass
    # TODO: Implementation

# Generated at 2022-06-23 22:31:24.640377
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:31:26.258962
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:31:27.143975
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:36.863480
# Unit test for function main
def test_main():
    from .. import const
    from . import __main__, exceptions
    from .conf import init_settings, get_settings
    for target in const.TARGETS:
        if target == '2.7':
            with pytest.raises(exceptions.InputDoesntExists):
                init_settings(namespace(input=['test/test_data/not_exists.py'],
                                        output='test/test_data/output.py',
                                        target=target))
            with pytest.raises(exceptions.InvalidInputOutput):
                init_settings(namespace(input=['test/test_data/invalid_output.py'],
                                        output='test/test_data/output.py',
                                        target=target))
            with pytest.raises(exceptions.CompilationError):
                init_

# Generated at 2022-06-23 22:31:37.388912
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:31:38.277958
# Unit test for function main
def test_main():
    """Function main test"""
    assert main() == 0

# Generated at 2022-06-23 22:31:42.532838
# Unit test for function main
def test_main():
    with mock.patch('sys.argv',
                    ['', '-i', 'tests/sample_project/app', '-o',
                     'tests/sample_project_out/app', '-t',
                     'python_35', '-r', 'tests/sample_project',
                     '-d']):
        main()

# Generated at 2022-06-23 22:31:47.934657
# Unit test for function main
def test_main():
    class ArgsFake:
        def __init__(self):
            self.input = "input"
            self.output = "output"
            self.target = "3.5"
            self.root = "root"
            self.debug = False

    assert main(ArgsFake) == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:55.587438
# Unit test for function main
def test_main():
    file_name = 'dummy_file.py'
    with open(file_name, 'w') as f:
        f.write('def func(): return\n')
    correct_output = 'def func():\n    return\n'
    out = io.StringIO()
    sys.stdout = out
    main(['-i', file_name, '-o', 'foo.py', '-t', '3.5'])
    output = out.getvalue().strip()
    os.remove(file_name)
    os.remove('foo.py')
    assert output == correct_output


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:32:03.682825
# Unit test for function main
def test_main():

    # Test the argparse exceptions
    sys.argv = ['', '-i', 'in_file.py', '-o', 'out_file.py']
    assert main() == 2
    sys.argv = ['', '-i', 'in_file.py', '-o', 'out_file.py',
                '-t', 'python2.7']
    assert main() == 2
    sys.argv = []
    assert main() == 2

    # Test the compilation error exception
    sys.argv = ['', '-i', 'tests/samples/syntax_error.py', '-o', 'out_file.py',
                '-t', 'python3.6']
    assert main() == 1

# Generated at 2022-06-23 22:32:05.293479
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:06.995195
# Unit test for function main
def test_main():
    args = ['--input', 'test_input.py', '--output', 'test_output.py',
            '--target', 'py36', '--debug']
    parser = main()
    assert parser == 0

# Generated at 2022-06-23 22:32:08.709344
# Unit test for function main
def test_main():
    pass

if __name__  == '__main__':
    exit(main())

# Generated at 2022-06-23 22:32:12.073240
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:14.560250
# Unit test for function main
def test_main():
    print("Testing main()")
    assert main() == 1
    print("main() passed unit test")


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:15.968922
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 22:32:21.219986
# Unit test for function main
def test_main():
    from .utils import get_data_path
    from .conf import get_settings
    main()
    assert get_settings().input == [get_data_path('data', 'test.py')]
    assert get_settings().output == get_data_path('data', 'test_out.py')
    assert get_settings().target == '2.7'


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:32:24.539299
# Unit test for function main
def test_main():

    mock_input = [1]

    def mock_main():
        mock_input.append(2)

    monkeypatch.setattr(sys, 'exit', mock_main)
    monkeypatch.setattr(sys, 'argv', ['test.py'])

    main()
    assert mock_input == [1,2]



# Generated at 2022-06-23 22:32:27.584990
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('/Users/sergii/Documents/py-backwards')
    sys.argv.append('-o')
    sys.argv.append('/Users/sergii/Documents/py-backwards')
    sys.argv.append('-t')
    sys.argv.append('python2')

    assert main() == 0

# Generated at 2022-06-23 22:32:39.052562
# Unit test for function main
def test_main():
    """This function is a unit test for function main()
    """
    import os
    import shutil
    import subprocess
    import tempfile
    import time

    def compare_file(filename1, filename2):
        """Compare two files.

        Return True if they are identical, false otherwise.
        """
        with open(filename1) as file1:
            with open(filename2) as file2:
                return file1.read() == file2.read()

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 22:32:39.570068
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:40.400494
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:40.998361
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:32:41.728665
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:32:47.783859
# Unit test for function main
def test_main():
    try:
        sys.argv = [
            '',
            '-i', 'tests/test_data/test.py',
            '-o', 'tests/test_data/test.pyc',
            '-t', '2.7',
        ]
        code = main()
    finally:
        del sys.argv

    assert code == 0


# Generated at 2022-06-23 22:32:54.824433
# Unit test for function main
def test_main():
    parser = ArgumentParser('py-backwards', description='Python to python compiler that allows you to use some Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=False,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=False,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=False, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:32:55.167861
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:00.597038
# Unit test for function main
def test_main():
    # creates the arguments
    test_args = ['py-backwards', '-i', 'test_programs/test_1.py', '-i', 'test_programs/test_2.py', '-o', 'test_programs/destination', '-t', '3.6']
    sys.argv = test_args
    main()
    assert True

# Generated at 2022-06-23 22:33:02.439610
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    # main()
    main()

# Generated at 2022-06-23 22:33:03.072177
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:09.697915
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'test_files/in/', '-o', 'test_files/out/',
                '-t', '37', '-r', 'test_files/in/']
    assert main() == 0
    sys.argv = ['-i', 'test_files/in/', '-o', 'test_files/out/',
                '-t', '37', '-r', 'test_files/in']
    assert main() == 1
    sys.argv = ['-i', 'test_files/in', '-o', 'test_files/out/',
                '-t', '37', '-r', 'test_files/in/']
    assert main() == 1

# Generated at 2022-06-23 22:33:12.424049
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:13.550088
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:33:16.862793
# Unit test for function main
def test_main():
    from . import __main__
    try:
        __main__.main()
        assert False
    except SystemExit as e:
        assert e.code == 1

# Generated at 2022-06-23 22:33:25.202058
# Unit test for function main
def test_main():
    # Test if main() returns 1 when compilation error
    sys.argv = ['py_backwards.py', '-i', 'tests/test_examples/example.py', '-o', 'tests/test_examples/example_compiled.py', '-t', '2.7']
    assert main() == 1

    # Test if main() returns 1 when transformation error
    sys.argv = ['py_backwards.py', '-i', 'tests/test_examples/example_invalid.py', '-o', 'tests/test_examples/example_compiled.py', '-t', '2.7']
    assert main() == 1

    # Test if main() returns 1 when input file doesn't exists

# Generated at 2022-06-23 22:33:34.568604
# Unit test for function main
def test_main():

    # Test Different invalid inputs and checking error messages printed

    # 1. Giving Invalid input type for args.input 
    # Expected Output: Input file or folder doesnot exist
    with pytest.raises(SystemExit) as exc_info:
        argv = ['-i','a.txt','a.txt','-o','a.txt','-t','3.6','--root','a.txt']
        parser = ArgumentParser(
            'py-backwards',
            description='Python to python compiler that allows you to use some '
                        'Python 3.6 features in older versions.')
        parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                            help='input file or folder')

# Generated at 2022-06-23 22:33:38.657411
# Unit test for function main
def test_main():
    sys.argv = ['py-backward', '-i', 'test_files', '-o', 'output',
                '-t', '3.5', '-r', '/home/']
    assert main() == 0

# Generated at 2022-06-23 22:33:39.282773
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:44.487603
# Unit test for function main
def test_main():
    input_ = '_input'
    output = '_output'
    target = '2.7'
    args = '-i '+input_+' -o '+output+' -t '+target
    main_ = main(args.split(' '))
    try:
        assert main_ == 0
    except:
        assert False


# Generated at 2022-06-23 22:33:45.221311
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:52.002620
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_files/test_file_valid.py', '-o', '.',
                '-r', 'test_files', '-t', '3.5']
    assert not main()
    sys.argv = ['py-backwards', '-i', 'test_files/test_file_valid.py', '-o', '.',
                '-r', 'test_files', '-t', '3.5', '-d']
    assert not main()
    sys.argv = ['py-backwards', '-i', 'test_files/test_file_invalid.py', '-o', '.',
                '-r', 'test_files', '-t', '3.5']
    assert main()

# Generated at 2022-06-23 22:33:53.567670
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:33:56.900939
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test', '-o', 'result', '-t', '2']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:33:59.877259
# Unit test for function main
def test_main():
    args = ['-i', 'tests/sources', '-o', 'tests/output', '-t', '2.7',
            '-r', 'tests/sources']
    sys.argv[1:] = args
    assert main() == 0

# Generated at 2022-06-23 22:34:02.416377
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py','--help'] # Fake command line argument
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:05.834002
# Unit test for function main
def test_main():
    sys.argv = ('py-backwards -i ./my_super_code.py '
                '-o ./transformed_code.py -t 2').split(' ')
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:14.285061
# Unit test for function main

# Generated at 2022-06-23 22:34:16.847345
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', '-t', '-r']
    assert main() is 0

# Generated at 2022-06-23 22:34:18.703123
# Unit test for function main
def test_main():
    args = main.__code__.co_varnames
    assert args == ('args',)

# Generated at 2022-06-23 22:34:19.299771
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:34:21.457651
# Unit test for function main
def test_main():
    assert(main() == 0)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 22:34:28.699740
# Unit test for function main
def test_main():
    input_ = ['../examples/python36.py']
    target = input_[0].split('/')[-1].split('.')[0]
    output_ = './output/'
    root_ = '.'
    sys.argv = ['pyb', '-i', input_[0], '-o', output_, '-t', target, '-r', root_]
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:30.771140
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "test.py", "-o", "test.py", "-t", "3.3", "-r", "sources"]
    out = main()
    assert out == 0

# Generated at 2022-06-23 22:34:33.972048
# Unit test for function main
def test_main():
    try:
        sys.argv = ['', '-i', 'source_files/test.py', '-o',
                    'output_files/test.py', '-t', '3.4']
        assert main() == 0
    except Exception as e:
        print(e)

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:34:44.775826
# Unit test for function main
def test_main():
    args = ['-o', '/tmp/output', '-t', '2.7', '-i', '/tmp/input']
    with patch('__main__.compile_files') as compile_files_mock:
        compile_files_mock.side_effect = [1, 0]
        assert main(args) == 1
        assert main(args) == 0

        args = ['-o', '/tmp/output', '-t', '2.7', '-i', '/tmp/input']
        with patch('argparse.ArgumentParser.print_help') as print_help_mock:
            main(args)
            print_help_mock.assert_called_once()

        assert main([]) == 2


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:46.180988
# Unit test for function main
def test_main():
    assert main() == 0
    return 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:56.999302
# Unit test for function main
def test_main():
    def run(argv: List[str], **kwargs) -> int:
        argv = ['py-backwards'] + argv
        sys.argv = argv
        return main()

    assert run(['-o', 'test', '-t', '2.7', '-d', 'tests/test_data'],
               input='tests/test_data', output='test', target='2.7',
               debug=True) == 0

    assert run(['-o', 'test', '-t', '3.5', '-d', 'tests/test_data'],
               input='tests/test_data', output='test', target='3.5',
               debug=True) == 0


# Generated at 2022-06-23 22:34:57.838330
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:01.757016
# Unit test for function main
def test_main():
    import pytest
    # Test wrong argument
    with pytest.raises(SystemExit):
        main(['-t', 'wrong'])
    # Test missing argument
    with pytest.raises(SystemExit):
        main(['-i', 'wrong'])

# Generated at 2022-06-23 22:35:03.224616
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:35:03.782782
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:35:04.602797
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:13.801905
# Unit test for function main
def test_main():
    from .conf import settings
    from .compiler import settings as compiler_settings

    init_settings({})
    settings.DEBUG = True
    compiler_settings.DEBUG = True

    # Test for bad input
    class Args:
        input = ('main.py',)
        output = 'output.py'
        target = 'py36'
    args = Args()
    main()

    # Test for bad input
    class Args:
        input = ('fail.py',)
        output = 'output.py'
        target = 'py36'
    args = Args()
    main()

    # Test for bad input
    class Args:
        input = ('fail.py',)
        output = 'output.py'
        target = 'py36'
    args = Args()
    main()

    # Test for

# Generated at 2022-06-23 22:35:16.739197
# Unit test for function main
def test_main():
    # Arrange
    sys.argv.extend(
        ['--input', 'tests/compiler/input/test_data',
         '--output', 'tests/compiler/output',
         '--root', 'tests/compiler/input',
         '--target', '3.3'])

    # Act
    result = main()

    # Assert
    assert result == 0

# Generated at 2022-06-23 22:35:21.110580
# Unit test for function main
def test_main():
    test_args = ['-t', 'py27', '-i', 'test', '-o', 'test_pybackwards', '-d', '-r', '']
    assert main(test_args) == 0

# Generated at 2022-06-23 22:35:27.361911
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'tests/app.py', '-o', 'out/app.py', '-t', '2.7']
    with patch('sys.stdout'):
        assert main() == 0

# Generated at 2022-06-23 22:35:36.524920
# Unit test for function main
def test_main():
    import os
    # Test sys.stdout is not None.
    assert sys.stdout is not None
    # Test sys.stdout.write is not None.
    assert sys.stdout.write is not None
    # Test sys.stderr is not None.
    assert sys.stderr is not None
    # Test sys.stderr.write is not None.
    assert sys.stderr.write is not None
    assert main() == 0
    # Test compiler can compile files.
    assert main() == 0
    # Test compiler can't compile folders.
    assert main() == 1
    # Test compiler can't compile files with incorrect arguments.
    assert main() == 1
    # Test compiler can't compile files with incorrect input.
    assert main() == 1
    # Test compiler can't compile files with incorrect output.

# Generated at 2022-06-23 22:35:40.040574
# Unit test for function main
def test_main():
    init_settings(builder='builder', mocks=['some.mock'], debug=True)
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:40.626740
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:44.654856
# Unit test for function main
def test_main():
    main(['-i', 'tests/source', '-o', 'tests/output', '-r', 'tests', '-t' '3.6'])
    main(['-i', 'tests/source/test_main.py', '-o', 'tests/output/test_main.py', '-r', 'tests', '-t' '3.6'])
    
if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:48.600135
# Unit test for function main
def test_main():
    args = {'input': 'test',
            'output': 'test',
            'target': 'test',
            'root': 'test',
            'debug': 'test'}
    sys.argv.extend(['-i', args['input'],
                    '-o', args['output'],
                    '-t', args['target'],
                    '-r', args['root'],
                    '-d'])
    assert main() == 0

# Generated at 2022-06-23 22:35:59.017569
# Unit test for function main
def test_main():
    # Check for debug option
    sys.argv = [sys.argv[0], '-i', const.EXAMPLE_FOLDER, '-o',
                const.UNITTEST_OUTPUT, '-t', '2.7', '-d']
    assert main() == 0

    # Check for not existing input
    sys.argv = [sys.argv[0], '-i', 'not_existing_input', '-o',
                const.UNITTEST_OUTPUT, '-t', '2.7']
    assert main() == 1

    # Check for invalid output
    sys.argv = [sys.argv[0], '-i', const.EXAMPLE_FOLDER, '-o',
                const.EXAMPLE_FOLDER, '-t', '2.7']


# Generated at 2022-06-23 22:36:04.325391
# Unit test for function main
def test_main():
    file_path = os.path.dirname(os.path.abspath(__file__))
    sys.argv = [
        sys.argv[0],
        '-i', os.path.join(file_path, '..', 'examples', 'base.py'),
        '-o', os.path.join(file_path, '..', 'examples', 'base.out.py'),
        '-t', '2.7',
        '-r', file_path
    ]
    main()

# Generated at 2022-06-23 22:36:08.532285
# Unit test for function main
def test_main():
    sys.argv = ['/home/ubuntu/.local/bin/py-backwards', '-i', 'test', '-o',
                'pybackwards/tests/output', '-t', 'python-3.6']
    assert main() == 0

# Generated at 2022-06-23 22:36:19.642076
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import io
    import sys
    from unittest.mock import patch
    import py_backwards.compiler
    import py_backwards.parser
    import py_backwards.transformer
    import py_backwards.conf
    import py_backwards.exceptions
    import py_backwards.messages
    from . import const

    source_dir = os.path.dirname(py_backwards.compiler.__file__)
    target_dir = os.path.join(source_dir, '..', 'target')

    def _parse():
        with open(os.path.join(source_dir, 'compiler.py')) as f:
            return py_backwards.parser.parse(f.read())


# Generated at 2022-06-23 22:36:20.168579
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:28.600814
# Unit test for function main
def test_main():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    sys.stdout = StringIO()
    sys.argv = ['py-backwards', '-i', 'test_dir', '-o', 'test_dir', '-t', '2.7']
    main()
    output = sys.stdout.getvalue()
    assert output == 'Done! Converted 0 files from python 3.6 syntax \
to python 2.7 syntax\n', 'Failed Unit test "main"'
    sys.stdout = sys.__stdout__

# Generated at 2022-06-23 22:36:31.582805
# Unit test for function main
def test_main():
    import unittest
    class MainTest(unittest.TestCase):
        def test_main(self):
            sys.argv = ['py-backwards', '-i', '/dummy/path', '-o', '/dummy/output', '-r', '', '-t', '3.5']
            self.assertEqual(main(), 1)
    unittest.main()