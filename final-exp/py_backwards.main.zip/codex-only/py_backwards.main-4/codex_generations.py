

# Generated at 2022-06-23 22:26:36.916065
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/input.py',
                    '-o', 'tests/output.py',
                    '-t', 'python2',
                    '-d']
    main()
    assert sys.argv[1:] == ['-i', 'tests/input.py',
                            '-o', 'tests/output.py',
                            '-t', 'python2',
                            '-d']

# Generated at 2022-06-23 22:26:40.583496
# Unit test for function main
def test_main():
    args = ArgumentParser().parse_args(['-i', './test/test_cases/test_case.py',
                                        '-o', './test/test_cases/test_case_out.py',
                                        '-t', '2', '-r', './test/test_cases'])
    init_settings(args)
    compile_files(args.input[0], args.output, const.TARGETS[args.target], args.root)
    assert open('./test/test_cases/test_case_out.py','r').read() \
        == open('./test/test_cases/test_case_expected_out.py','r').read()
    clean()


# Generated at 2022-06-23 22:26:41.071770
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:52.681109
# Unit test for function main

# Generated at 2022-06-23 22:26:53.113794
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:53.796280
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:26:54.564472
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:56.145222
# Unit test for function main
def test_main():
    from .main import main
    assert main() == 0

# Generated at 2022-06-23 22:26:56.789624
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:26:58.309487
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        assert main() == 0

# Generated at 2022-06-23 22:27:00.538894
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:03.658949
# Unit test for function main
def test_main():
    sys.argv = ['program', '-i', 'input.py', '-o', 'output.py', '-t', '2.7']
    assert main() == 1


if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-23 22:27:11.603321
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/fixtures/test_args/test_args.py',
                '-o', 'tests/fixtures/test_args/test_args_output.py',
                '-t', '3.5', '-r', 'tests/fixtures/test_args/']
    main()
    with open('tests/fixtures/test_args/test_args_output.py', 'r') as f:
        s = f.read()
        assert "print('a', 'b', end='')" in s

if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-23 22:27:21.691983
# Unit test for function main
def test_main():
    import mock
    from . import conf
    from . import messages

    assert main() == 0

    sys.argv = [sys.argv[0], '-i', 'input_file.py', '-o', 'output_file.py',
                '-t', '3.6', '-r', 'root_dir']

    with mock.patch('{}.compile_files'.format(__name__)):
        assert main() == 0

    with mock.patch('{}.compile_files'.format(__name__), side_effect=
                    exceptions.CompilationError('error')):
        assert main() == 1
        assert messages.syntax_error.error == 'error'


# Generated at 2022-06-23 22:27:31.318608
# Unit test for function main
def test_main():
    from .conf import init_settings
    from os import (
        getcwd,
        chdir,
        makedirs,
        remove)
    from py_backwards.messages import (
        input_doesnt_exists,
        invalid_output,
        permission_error,
        syntax_error,
        transformation_error,
        compilation_result
    )
    from py_backwards.tests.mock_argparse import MockArgumentParser, MockArgs
    import py_backwards.const as const
    from py_backwards.exceptions import (
        CompilationError,
        InputDoesntExists,
        TransformationError,
        InvalidInputOutput,
        DuplicateTargetError
    )
    from py_backwards.compiler import (
        compile_files,
        compile_file
    )

# Generated at 2022-06-23 22:27:31.913081
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:27:40.264656
# Unit test for function main
def test_main():
    temp_stdout = sys.stdout
    out = StringIO()
    sys.stdout = out
    main()
    assert out.getvalue() == "usage: py-backwards [-h] -i INPUT [INPUT ...] -o OUTPUT -t {3.6,3.7} [-r ROOT] [-d]\npy-backwards: error: the following arguments are required: -i/--input, -o/--output, -t/--target\n"



if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:27:51.467551
# Unit test for function main
def test_main():
    import subprocess
    from .compiler import remove_py_cache
    remove_py_cache()


# Generated at 2022-06-23 22:27:59.901235
# Unit test for function main
def test_main():
    # test correct compilation
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o',
                'test/test_output.py', '-r', 'test', '-t', '3.5']
    assert main() == 0
    assert os.path.exists('test/test_output.py')

    os.remove('test/test_output.py')

    # test compilation with no input file
    sys.argv = ['py-backwards', '-i', 'test//test_input.py', '-o',
                'test//test_output.py', '-r', 'test', '-t', '3.5']
    assert main() == 1

    os.remove('test/test_output.py')

    # test compilation with no output file
   

# Generated at 2022-06-23 22:28:02.002819
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:06.276493
# Unit test for function main
def test_main():
    import pytest
    from .common import remove_path
    # TODO: add more tests
    with remove_path('./test/smoke_test/output') as _:
        assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:11.245512
# Unit test for function main
def test_main():
    # Example input
    sys.argv = [sys.argv[0], '-i', '/input', '-o', '/output', '-t', '2.7',
                '-r', '/root', '-d']
    main()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:28:11.845424
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:28:14.682559
# Unit test for function main
def test_main():
    input_ = 'py_backwards'
    output = 'py_backwards'
    target = 'PyPy'
    root = 'py_backwards'
    debug = 'debug'
    assert main() == 0

# Generated at 2022-06-23 22:28:23.389079
# Unit test for function main
def test_main():
    original_stdout = sys.stdout
    sys.stdout = open(os.devnull, "w")

# Generated at 2022-06-23 22:28:32.900622
# Unit test for function main
def test_main():
    """Unit test for function main"""
    sys.argv = ['py-backwards', '-i', 'tests/test_easy.py', '-o', 'out.py',
                '-t', '2.7', '-d']
    main()
    assert os.path.isdir('out.py') == False

    file_path = os.path.join(os.path.dirname(__file__), 'test_easy.py')
    with open(file_path) as fin:
        indata = fin.read()

    file_path = Path(file_path).parents[1].joinpath('out.py')
    with open(file_path) as fin:
        outdata = fin.read()

    assert all(outdata.__contains__(item) for item in indata.split())

# Generated at 2022-06-23 22:28:33.340707
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:28:43.869285
# Unit test for function main
def test_main():
    class dummy_args:
        def __init__(self, input_, output, target, root = None, debug = False):
            self.input = input_
            self.output = output
            self.root = root
            self.target = target
            self.debug = debug

# Generated at 2022-06-23 22:28:48.754260
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i C:\\Program Files\\A\\B', '-i C:\\A\\B',
                '-o C:\\A\\B', '-t 2.7', '-r C:\\A\\B', '-d']
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:28:50.713698
# Unit test for function main
def test_main():
    """
    test_main is the function that tests the main function
    """
    assert main() == 0

# Generated at 2022-06-23 22:28:54.550891
# Unit test for function main
def test_main():
    sys.argv = ['args',
                '-i', 'tests/data/test_function_1.py',
                '-o', 'tests/data/test_function_1_result.py',
                '-t', '2.7',
                '-r', 'tests/data']
    assert main() == 0

# Generated at 2022-06-23 22:28:55.093190
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 22:28:55.624514
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:04.966615
# Unit test for function main
def test_main():
    import os
    import shutil
    from .conf import settings

    def _get_input_dir(source: str) -> str:
        return os.path.join(os.path.dirname(__file__), 'input', source)

    def _get_output_dir(output: str) -> str:
        return os.path.join(os.path.dirname(__file__), 'output', output)

    def _get_results_dir(source: str, output: str) -> str:
        return os.path.join(os.path.dirname(__file__), 'output',
                            '{}-to-{}-results'.format(source, output))


# Generated at 2022-06-23 22:29:05.340390
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:29:15.399601
# Unit test for function main
def test_main():
    # Test when all arguments are valid
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'output.py', '-t',
                'python2.6']
    assert main() == 0
    # Test when input file is not valid
    sys.argv = ['py-backwards', '-i', 'test1.py', '-o', 'output.py', '-t',
                'python2.6']
    assert main() == 1
    # Test when output file is not valid
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'output1.py', '-t',
                'python2.6']
    assert main() == 1
    # Test when target is not valid

# Generated at 2022-06-23 22:29:17.775457
# Unit test for function main
def test_main():
    # FIXME: make this test running in non-interactive mode
    return

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:20.905431
# Unit test for function main
def test_main():
    args = ['program', '-i', 'input_file', '-o', 'output_file', '-t', '2.7']
    with mock.patch.object(sys, 'argv', args):
        assert main() == 1

# Generated at 2022-06-23 22:29:32.873027
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_cases.py', '-o', 'output.py', '-t', '2.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_cases.py', '-o', 'output.py', '-t', '3.6']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_cases.py', '-o', 'output.py', '-t', '3.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_cases.py', '-o', 'output.py', '-t', '3.8']

# Generated at 2022-06-23 22:29:37.599398
# Unit test for function main
def test_main():
    test_input = 'test.py'
    test_output = 'test.pyc'
    test_target = 'py35'

    parser = ArgumentParser()
    init_settings(parser.parse_args(['-i', test_input, '-o', test_output, '-t', test_target]))
    try:
        compile_files(test_input, test_output, const.TARGETS[test_target], ".")
    except:
        assert(False)
    else:
        assert(True)

# Generated at 2022-06-23 22:29:41.663043
# Unit test for function main
def test_main():
    args = sys.argv
    sys.argv = ['py-backwards.py']
    with pytest.raises(SystemExit):
        main()
    sys.argv = ['py-backwards.py', '-t', '2.7', '-r', 'C:\somepath', '-d', 'someinput', 'someoutput']
    with pytest.raises(SystemExit):
        main()
    sys.argv = args


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:29:43.890845
# Unit test for function main
def test_main():
    sys.argv[1:] = ["-i", "test/unit/test_compiler.py", "-o", "test/unit/test_compiler.pyc", "-t", "3.6", "-r", "test/unit/"]
    assert main() == 0


# Generated at 2022-06-23 22:29:45.148426
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:29:49.351613
# Unit test for function main
def test_main():
    filename = "test_file.py"
    argv = sys.argv
    assert len(argv) == 1
    sys.argv = ["py-backwards", "-i", filename, "-o", filename, "-t", "3.6"]
    assert main() == 0
    sys.argv = argv

if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-23 22:29:53.091056
# Unit test for function main
def test_main():
    args = sys.argv
    sys.argv = ['-i', 'test/test_input', '-o', 'test/test_output',
                '-t', 'py27', '-r', 'test/test_input']
    assert main() == 0
    sys.argv = args

# Generated at 2022-06-23 22:30:04.230432
# Unit test for function main
def test_main():
    from unittest.mock import patch, call

    # check exit without args
    with patch('sys.argv', ['']), \
            patch('sys.exit') as mock_exit:
        main()
        assert call(1) in mock_exit.call_args_list

    # check exit with input and output, but without target
    with patch('sys.argv', ['', '-i', 'input', '-o', 'output']), \
            patch('sys.exit') as mock_exit:
        main()
        assert call(1) in mock_exit.call_args_list

    # check exit with input and target, but without output

# Generated at 2022-06-23 22:30:08.387670
# Unit test for function main
def test_main():
    error = 1
    assert error == main(['-i', 'input.py', '-o', 'output.py', '-t', '2.7', '-r', 'test'])

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:12.197716
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', '../tests/input/test.py', '-o',
                '../tests/output/test/', '-t', '2.7']
    main()

# Generated at 2022-06-23 22:30:19.371869
# Unit test for function main
def test_main():
    input_ = ['py-backwards/test_files/test.py']
    output = 'py-backwards/test_files/test_out.py'
    args = ['-i', input_, '-o', output, '-t', '37']
    assert main(args) == 0
    assert os.path.exists('py-backwards/test_files/test_out.py')
    os.remove('py-backwards/test_files/test_out.py')
    assert not os.path.exists('py-backwards/test_files/test_out.py')

# Generated at 2022-06-23 22:30:29.593078
# Unit test for function main
def test_main():
    import os
    import shutil
    import unittest
    import subprocess

    class MainTest(unittest.TestCase):
        def setUp(self):
            current_dir = os.path.dirname(os.path.abspath(__file__))
            self.input_dir = os.path.join(current_dir, "unittest_data")
            self.tmp_dir = os.path.join(current_dir, "tmp")
            self.output_dir = os.path.join(current_dir, "tmp", "output")
            self.python_dir = os.path.join(current_dir, "tmp", "python")

            if not os.path.exists(self.tmp_dir):
                os.mkdir(self.tmp_dir)

# Generated at 2022-06-23 22:30:29.968503
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:31.067018
# Unit test for function main
def test_main():
    exit_code = main()
    assert exit_code == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:41.997836
# Unit test for function main
def test_main():
    with patch('argparse.ArgumentParser.parse_args') as mock_args:
        mock_args.return_value = argparse.Namespace(
            input=['test', 'test2'], output='test3', target='3.5', debug=True,
            root='test4'
        )
        with patch('pybackwards._compiler.compile_files') as mock_compile:
            mock_compile.return_value = 4
            assert main() == 0
            mock_args.assert_called_once()
            mock_compile.assert_has_calls([
                call('test', 'test3', 3.5, 'test4'),
                call('test2', 'test3', 3.5, 'test4')
            ])

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:46.419555
# Unit test for function main
def test_main():
    args = ['-i', 'tests/compiler_test_modules', '-o', '_out', '-t', '3.4',
            '-r', 'tests/compiler_test_modules']
    main(args)

# Generated at 2022-06-23 22:30:46.849807
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:30:48.400822
# Unit test for function main
def test_main():
    if main() != 0:
        return "Test FAILED"

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:30:49.176662
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:50.634996
# Unit test for function main
def test_main():
    assert(main() == 0)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:30:54.905969
# Unit test for function main
def test_main():
    argv = [
        'py-backwards',
        '-i',
        'test/test.py',
        '-o',
        'test/out/',
        '-t',
        'python2',
    ]
    sys.argv = argv
    assert main() == 0


# Generated at 2022-06-23 22:30:59.128554
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'tests/files/py36/ifilter.py',
        '-o', 'tests/files/py36/ifilter_out.py',
        '-t', 'py36'
    ]
    main()


# Generated at 2022-06-23 22:31:00.074492
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:31:00.706220
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:02.377969
# Unit test for function main
def test_main():
    args = main.__annotations__
    assert args['return'] == int

# Generated at 2022-06-23 22:31:06.713822
# Unit test for function main
def test_main():
    test_input = {
        'input': ['file1', 'file2'],
        'output': 'file3',
        'target': '2.7',
        'root': None,
        'debug': False
    }
    assert main(test_input) == 0

# Generated at 2022-06-23 22:31:16.650076
# Unit test for function main
def test_main():
    from .main import main
    # Valid call
    input = ["my_script.py"]
    args = ["-i", input, "-o", "output", "-t", "3.5"]
    assert main(args) == 0

    # Invalide call, input file doesn't exist
    input = ["invalid_input.py"]
    args = ["-i", input, "-o", "output", "-t", "3.5"]
    assert main(args) == 1

    # Invalid call, invalid output
    output = "./../my_output"
    args = ["-i", input, "-o", output, "-t", "3.5"]
    assert main(args) == 1

# Generated at 2022-06-23 22:31:23.774992
# Unit test for function main
def test_main():
    from subprocess import Popen, PIPE
    from shutil import rmtree
    from tempfile import mkdtemp
    from os.path import join
    from io import TextIOWrapper

    tmp = mkdtemp()

# Generated at 2022-06-23 22:31:25.379438
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:31:25.965211
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:31:30.077123
# Unit test for function main
def test_main():
    try:
        main(['-i', 'test_data/test.py', '-o', 'test.py', '-t', '2.7',
              '-r', 'test_data', '-d'])
        assert True
    except SystemExit:
        assert False

# Generated at 2022-06-23 22:31:31.213727
# Unit test for function main
def test_main():
    # assert main() == 0
    pass

# Generated at 2022-06-23 22:31:36.747852
# Unit test for function main
def test_main():
    # Run main to compile a test.py file and a subfolder test1.py file
    sys.argv = ['py-backwards', '-i', 'test/test.py', 'test/sub', '-o', 'test/mba.py', '-t', '3.3', '-d', '-r', 'test']
    main()
    import test.mba

# Generated at 2022-06-23 22:31:42.663607
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile

    path = tempfile.mkdtemp()
    with open(os.path.join(path, "test.py"), "w") as f:
        f.write('print(1)')

    sys.argv = ['py-backwards', '-i', path, '-o', path, '-t', '2.6']

    #assert main() == 0
    shutil.rmtree(path)

# Generated at 2022-06-23 22:31:53.206939
# Unit test for function main
def test_main():
    def patch_input_output(input_, output, target, root, debug, sys_func):
        def patched_input(promt):
            if promt == 'Input file or folder: ':
                return input_
            if promt == 'Output file or folder: ':
                return output
            if promt == 'Target python version: ':
                return target
            if promt == 'Sources root: ':
                return root
            if promt == 'Enable debug output [y/n]: ':
                return 'y' if debug else 'n'
            assert False, 'Unexpected promt'

        sys_func.stdin.readline = patched_input


# Generated at 2022-06-23 22:32:01.745969
# Unit test for function main
def test_main():
    assert call([sys.executable, '-m', 'py_backwards', '-i', 'test/main.py', '-o', 'test/_main.py', '-t', '3.5', '-r', 'test']) == 0
    assert call([sys.executable, '-m', 'py_backwards', '-i', 'test/main.py', '-o', 'test/_main.py', '-t', '3.5']) == 0
    assert call([sys.executable, '-m', 'py_backwards', '-i', 'test/main.py', '-o', 'test/nonexisting/', '-t', '3.5']) == 1
    open_file = open('test/_main.py', 'r')
    file_content = open_file.read()


# Generated at 2022-06-23 22:32:02.393816
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-23 22:32:03.914420
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-23 22:32:06.998870
# Unit test for function main
def test_main():
    assert main() == 0
    sys.argv = ['py-backwards.py', '-i', '-', '-o', '-', '-t', '2']

# Generated at 2022-06-23 22:32:07.568984
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:11.276660
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    try:
        status = main()
    except SystemExit as e:
        status = e.code
    except:
        status = 255
    sys.exit(status)

# Generated at 2022-06-23 22:32:15.312926
# Unit test for function main
def test_main():
    import pytest
    from .__main__ import main

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code != 0

# Generated at 2022-06-23 22:32:19.621504
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',
                '-i', 'tests/tests/examples',
                '-o', 'tests/tests/result.py',
                '-t', '2.7',
                '-r', 'tests/tests/examples'
                ]

    assert main() == 0

# Generated at 2022-06-23 22:32:29.228009
# Unit test for function main
def test_main():
    # Test compilation of the non-existent file
    from mock import patch, call
    with patch('builtins.print') as mock_print:
        with patch('sys.stderr', new=mock_print):
            main()
            assert mock_print.call_count == 2
            assert mock_print.mock_calls[0] == call(
                'Input doesn\'t exists: [\'./non-existent-file\']')

    # Test compilation of the non-existent root directory
    with patch('builtins.print') as mock_print:
        with patch('sys.stderr', new=mock_print):
            main(['file.py', 'file2.py'], 'output', 'py2.5',
                 './non-existent-root')
            assert mock_print.call_count == 2


# Generated at 2022-06-23 22:32:30.041145
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:32.072350
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):  # pragma: no cover
        main()

# Generated at 2022-06-23 22:32:35.220764
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-t', '3.4', '-i', 'test/test.py', '-o', 'test/test_out.py']
    assert main() == 0

# Generated at 2022-06-23 22:32:35.852386
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:32:36.904392
# Unit test for function main
def test_main():
    # TODO: write
    pass

# Generated at 2022-06-23 22:32:37.636296
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 22:32:38.322772
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:32:40.445395
# Unit test for function main
def test_main():
    # TODO: test for all possible errors
    # TODO: test for successful run
    pass

# Generated at 2022-06-23 22:32:51.260121
# Unit test for function main
def test_main():
    def foo(argv, depth=0):
        sys.argv = [sys.argv[0]] + argv
        const.INDENT = depth
        code = main()
        const.INDENT = 0
        return code

    # main without arguments
    assert foo([]) == 1

    # main with invalid target
    assert foo(['-i', 'tests/test_data/main.py', '-o', 'output.py', '-t', '2']) == 1

    # main with invalid input
    assert foo(['-i', 'tests/test_data/main.py', '-o', 'output.py', '-t', '3']) == 1

    # main with non-existant input

# Generated at 2022-06-23 22:32:53.801673
# Unit test for function main
def test_main():
    pass
# Unit tests

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:33:04.527192
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-23 22:33:05.411319
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-23 22:33:09.490748
# Unit test for function main
def test_main():
    # Case where no input file is given
    sys.argv = ['py-backwards']
    with pytest.raises(SystemExit) as exit:
        main()
        assert exit.value.code == 2

    # Case where input file not found
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'test']
    with pytest.raises(SystemExit) as exit:
        main()
        assert exit.value.code == 1

# Generated at 2022-06-23 22:33:11.550767
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 22:33:21.620116
# Unit test for function main
def test_main():
    from os import mkdir, remove, rmdir
    from os.path import join, isfile
    from unittest.mock import patch

    def test_output(result: int, expected: int, args=None):
        if args is None:
            args = ['-i', join(dir_name, 'a.py'),
                    '-o', join(dir_name, 'out'),
                    '-t', '2.7']
        if result != expected:
            print('Test failed. ' + ' '.join(args))
            raise AssertionError()
        else:
            print('Test passed.')

    dir_name = '_tmp'
    mkdir(dir_name)

# Generated at 2022-06-23 22:33:22.194763
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:33:29.672124
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', r'tests/test_data_1.py', r'tests/test_data_2.py', '-o', r'tests/result_1.py','tests/result_2.py', '-t', '27']
    sys.argv = ['py-backwards', '-i', r'tests/test_data_3.py', '-o', r'tests/result_3.py', '-t', '35']
    sys.argv = ['py-backwards', '-i', r'tests/test_data_4.py', '-o', r'tests/result_4.py', '-t', '36']
    main()

# Generated at 2022-06-23 22:33:31.226041
# Unit test for function main
def test_main():
    pass
    #assert main() == 0, "Should return 0"

# Generated at 2022-06-23 22:33:33.760248
# Unit test for function main
def test_main():
    import io
    import sys
    sys.stdout = io.StringIO()
    assert main() == 0
    assert "is not supported" in sys.stdout.getvalue().strip()

# Generated at 2022-06-23 22:33:45.465462
# Unit test for function main
def test_main():
    # save old sys.argv
    old_sys_argv = sys.argv
    # attempt to compile simple.py
    sys.argv = ["py-backwards", '-i', 'examples/simple.py', '-o', 'tmp.pyc',
                '-t', '2.7']
    assert main() == 0
    # attempt to compile empty.py
    sys.argv = ["py-backwards", '-i', 'examples/empty.py', '-o', 'tmp.pyc',
                '-t', '2.7']
    assert main() == 0
    # attempt to compile nonexistent.py
    sys.argv = ["py-backwards", '-i', 'nonexistent.py', '-o', 'tmp.pyc',
                '-t', '2.7']

# Generated at 2022-06-23 22:33:49.403441
# Unit test for function main
def test_main():
    sys.argv[1:] = ['--input', './compiler/tests/file_source.py',
                    '--output', './compiler/tests/file_source_transformed.py',
                    '--target', '2.7',
                    '--debug']
    exit_code = main()
    sys.argv = sys.argv[:1]
    assert exit_code == 0

# Generated at 2022-06-23 22:33:50.910199
# Unit test for function main
def test_main():
    return

if __name__ == '__main__':  # pragma: no cover
    exit(main())

# Generated at 2022-06-23 22:34:00.757508
# Unit test for function main
def test_main():
    import os
    import shutil

    # check that main function work well
    with open('1.py', 'w') as f:
        f.write('var = 1\n')
    sys.argv = ['py-backwards', '-i', '1.py', '-o', '2.py', '-t', '3.5']
    main()
    with open('2.py', 'r') as f:
        assert 'var = 1\n' == f.read()
    os.remove('1.py')
    os.remove('2.py')

    # check that main function raise InputError if input file
    # is not exists
    with open('1.py', 'w') as f:
        f.write('var = 1\n')
    os.remove('1.py')
    sys.arg

# Generated at 2022-06-23 22:34:10.662252
# Unit test for function main
def test_main():
    import io
    import contextlib
    
    @contextlib.contextmanager
    def capture(command, *args, **kwargs):
        out, sys.stdout = sys.stdout, io.StringIO()
        try:
            command(*args, **kwargs)
            sys.stdout.seek(0)
            yield sys.stdout.read()
        finally:
            sys.stdout = out

    class FakeArgs:
        def __init__(self):
            self.input = ['input1', 'input2']
            self.output = 'output'
            self.target = 'py2'
            self.root = None
            self.debug = False
    args = FakeArgs()
    with capture(main, args = args) as output_:
        assert output_.count('\n') == 1


# Generated at 2022-06-23 22:34:14.550304
# Unit test for function main
def test_main():
    assert main(['-i', 'test/input/', '-o', 'test/output/', '-t', '2']) == 0


# Generated at 2022-06-23 22:34:22.328346
# Unit test for function main
def test_main():
    print(sys.argv)
    sys.argv.append('-i')
    sys.argv.append(r'C:\Users\SAI\iCloudDrive\Git\py-backwards\test')
    sys.argv.append('-o')
    sys.argv.append(r'C:\Users\SAI\iCloudDrive\Git\py-backwards\test2')
    sys.argv.append('-t')
    sys.argv.append('2.7')
    """
    try:
        main()
    except SystemExit:
        pass


if __name__ == '__main__':
    test_main()
    """
    main()

# Generated at 2022-06-23 22:34:22.959368
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:34:27.865097
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0],
                '-i', 'src/hello_world.py',
                '-o', 'out/hello_world.py',
                '-t', '2.7']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:34:33.933763
# Unit test for function main
def test_main():
    sys.argv = ['main.py', '-i', 'doc/examples', '-o', 'tests/result',
                '-t', 'Python2', '-r', 'doc/examples']
    assert main() == 0
    sys.argv = ['main.py', '-i', 'doc/examples', '-o', 'tests/result',
                '-t', 'Python3', '-r', 'doc/examples']
    assert main() == 0

# Generated at 2022-06-23 22:34:38.611450
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i',
        'tests/source',
        '-o',
        'tests/dest',
        '-t',
        '3.5'
    ]
    exit_code = main()
    assert exit_code == 0

# Generated at 2022-06-23 22:34:39.891833
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 22:34:43.128431
# Unit test for function main
def test_main():
    argv = sys.argv
    try:
        sys.argv = ['py-backwards', '-i', 'test\test.py', '-o', 'test\output',
                    '-t', '2.7', '-d']
        assert main() == 0
    finally:
        sys.argv = argv

# Generated at 2022-06-23 22:34:44.880736
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:34:45.983121
# Unit test for function main
def test_main():
    # Only for coverage
    init_settings(ArgumentParser().parse_args([]))

# Generated at 2022-06-23 22:34:56.721519
# Unit test for function main
def test_main():
    sys.argv = ['',"-i", "tests/input_examples/multiple_files",
                "-o", "tests/output",
                "-t", "2.7",
                "-d"]
    assert main() == 0

    sys.argv = ['',"-i", "tests/input_examples/multiple_files",
                "-o", "tests/output",
                "-t", "2.7",
                "-d",
                "-r", "tests/input_examples/multiple_files"]
    assert main() == 0

    sys.argv = ['',"-i", "tests/input_examples/multiple_files"]
    assert main() != 0


# Generated at 2022-06-23 22:34:58.727853
# Unit test for function main
def test_main():
    # TODO
    return True


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:09.129187
# Unit test for function main
def test_main():
    # default
    test_input = ["test/test.py","test/test.py"]
    test_output = "test/output.py"
    test_target = "2.7"
    sys.argv = ["py-backwards","-i",test_input[0],"-i",test_input[1],"-o",test_output,"-t",test_target]
    main()

    # specific
    test_input = ["test/test.py","test/test.py"]
    test_output = "test/output.py"
    test_target = "2.7"
    sys.argv = ["py-backwards","-i",test_input[0],"-i",test_input[1],"-o",test_output,"-t",test_target,"-r","root", "-d"]
    main()

# Generated at 2022-06-23 22:35:10.044587
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-23 22:35:11.181489
# Unit test for function main
def test_main():
    # TODO: add test code
    pass

# Generated at 2022-06-23 22:35:14.150308
# Unit test for function main
def test_main():
    assert(main() == 0)

# Generated at 2022-06-23 22:35:14.721789
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:24.575233
# Unit test for function main
def test_main():
    try:
        # Test without arguments
        main()
    except SystemExit:
        assert True, "Handled SystemExit"
    except Exception as e:
        assert False, "Expected SystemExit, not " + str(e)

    try:
        # Test with invalid input
        main(['-i', 'invalid', '-o', 'out', '-t', '2'])
    except SystemExit:
        assert True, "Handled SystemExit"
    except Exception as e:
        assert False, "Expected SystemExit, not " + str(e)

    import os
    import shutil
    from os.path import join
    from .conf import settings

    settings.ROOT = os.getcwd()
    DIR_NAME = "py-backwards-tests"
    settings.DIR_NAME = DIR_NAME

# Generated at 2022-06-23 22:35:25.262570
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:35:35.544155
# Unit test for function main
def test_main():
    from io import StringIO
    from tempfile import TemporaryDirectory

    def create_file(path, text):
        with open(path, 'w') as f:
            f.write(text)

    with TemporaryDirectory() as temp_dir:
        with StringIO() as stream:
            sys.stdout = stream
            create_file(temp_dir + '/test.py', """\
print('Hello!')
""")
            sys.argv = [sys.argv[0], '-i', temp_dir + '/test.py', '-o',
                        temp_dir + '/test.py.bak', '-t', '3.5']
            assert main() == 0
            assert stream.getvalue() == 'Finished!\n'

            stream.seek(0)
            stream.truncate(0)
            create

# Generated at 2022-06-23 22:35:45.327570
# Unit test for function main
def test_main():
    from .conf import settings
    from . import conf
    from . import exceptions
    import unittest

    class TestMain(unittest.TestCase):

        def setUp(self):
            settings.clear()
            conf.init_settings = lambda *args: None

        def test_right_input_output(self):
            main_args = ['py-backwards', '-i', 'example', '-o', 'dst', '-t',
                         'python2.7']
            self.assertEqual(main(), 0)
            self.assertEqual(settings.INPUT, ['example'])
            self.assertEqual(settings.OUTPUT, 'dst')
            self.assertEqual(settings.TARGET, 'python2.7')
            self.assertFalse(settings.DEBUG)


# Generated at 2022-06-23 22:35:48.028285
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', sys.argv[0], '-o', sys.argv[0][:-1], '-t', '2.7', '-d']
    main()

# Generated at 2022-06-23 22:35:50.706959
# Unit test for function main
def test_main():
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1

# Generated at 2022-06-23 22:35:52.624777
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-23 22:35:53.267045
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-23 22:36:00.859357
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('examples/inheritance')
    sys.argv.append('-i')
    sys.argv.append('examples/inheritance')
    sys.argv.append('-o')
    sys.argv.append('examples/inheritance_out')
    sys.argv.append('-t')
    sys.argv.append('2.7')
    main()

if __name__ == '__main__':
    main()
    # test_main()

# Generated at 2022-06-23 22:36:12.109743
# Unit test for function main
def test_main():
    sys.argv.append("-i")
    sys.argv.append("input_file.py")
    sys.argv.append("-o")
    sys.argv.append("output_folder")
    sys.argv.append("-t")
    sys.argv.append("3.5")

    assert main() == 0

    sys.argv[5] = "2.6"
    sys.argv[7] = "2.6"

    assert main() == 0

    sys.argv[3] = "input_folder"
    sys.argv[1] = "-r"
    sys.argv[2] = "root_sources"

    assert main() == 0

test_main()

# Generated at 2022-06-23 22:36:13.827538
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:36:19.646615
# Unit test for function main
def test_main():
    from types import SimpleNamespace
    from io import StringIO
    from contextlib import redirect_stdout

    args = SimpleNamespace(debug=False, output='output', target='3.5',
                           input=['main.py'])
    init_settings(args)

    with StringIO() as buf, redirect_stdout(buf):
        result = main()
    output = buf.getvalue()

    assert result == 0
    assert output == messages.compilation_result(1) + '\n'

# Generated at 2022-06-23 22:36:29.306910
# Unit test for function main
def test_main():
    args = ['-t', '26', '-o', 'out', 'input']
    with patch('sys.argv', args):
        with patch('builtins.print') as mock_print:
            with patch('sys.stderr.write', create=True) as mock_error_print:
                mock_print.return_value = None
                mock_error_print.return_value = None
                with patch('argparse.ArgumentParser.parse_args',
                           return_value=Namespace(input=('input',),
                                                  output='out', target='26')):
                    assert main() == 0
                    assert mock_print.call_count == 1

# Generated at 2022-06-23 22:36:29.828316
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 22:36:30.975890
# Unit test for function main
def test_main():
    import os
    os.system('pytest -k test_main tests')