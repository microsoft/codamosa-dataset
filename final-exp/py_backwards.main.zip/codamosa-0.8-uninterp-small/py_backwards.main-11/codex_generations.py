

# Generated at 2022-06-25 21:56:40.499349
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:56:42.574894
# Unit test for function main
def test_main():
    print('Testing function main')
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:56:47.476079
# Unit test for function main
def test_main():
    from unittest import TestCase
    from py_backwards.execution import main

    class Tests(TestCase):
        def test_case_0(self):
            int_0 = main()
            self.assertEqual(int_0, 0)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:56:50.574855
# Unit test for function main
def test_main():
    # Check behavior for string on boundary
    test_case_0()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:56:51.819290
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 21:56:53.160712
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0

# Generated at 2022-06-25 21:56:54.404149
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# No command line argument

# Generated at 2022-06-25 21:56:56.803085
# Unit test for function main
def test_main():
    print(const.START_TEST_STYLE)
    print('Testing function main')

    print('\nTesting main set 1\n')
    print('test_case_0')
    test_case_0()

# Generated at 2022-06-25 21:56:58.319615
# Unit test for function main
def test_main():
    assert main() == 0, "Expected: 0"

test_main()

# Generated at 2022-06-25 21:57:01.064747
# Unit test for function main
def test_main():
    # Not sure why there is an error in the main. Probably a missing step
    # or something
    assert int_0 == 0, 'Test failed'

if __name__ == '__main__':
    status = main()
    sys.exit(status)

# Generated at 2022-06-25 21:57:10.509158
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:11.794457
# Unit test for function main
def test_main():
    print("test_main")
    test_case_0()

# Generated at 2022-06-25 21:57:14.354286
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('Test failed!')
        sys.exit(1)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:17.039140
# Unit test for function main
def test_main():
    match = re.match(main(), int)
    assert match, 'Function main should return an int'
    assert (main() == 0 or 1), 'Function main must return 0 or 1'

# Test for coverage

# Generated at 2022-06-25 21:57:21.786621
# Unit test for function main
def test_main():
    p = Popen(['python', '-m', 'py_backwards', '-i', '../test/test_data/test1.py', '-o', '/Users/akozlov/test.py',
               '-t', '3.5', '-d', '-r', '../test/test_data/'])
    p.wait()
    return p.returncode


# Generated at 2022-06-25 21:57:25.931329
# Unit test for function main
def test_main():
    sys.argv=['py-backwards', '-i', './Input/Fibonacci.py', '-o',  './Output/Fibonacci.py', '-t', '3.5'] # Insert test argument values
    int_0 = main()
    assert (int_0 == 0)


# Generated at 2022-06-25 21:57:26.463122
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 21:57:29.803474
# Unit test for function main
def test_main():
    main(["-i", "test_cases/test_case_0.py", "-o", "test-output", "-t", "3.7", "-r", "test_cases", "-d", False, False])


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:57:31.926319
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-25 21:57:36.486372
# Unit test for function main
def test_main():
    # Test with no arguments
    try:
        main()
    except SystemExit:
        pass

    # Test with -h
    try:
        main()
    except SystemExit:
        pass

    # Test with invalid input
    try:
        main()
    except SystemExit:
        pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:58.816689
# Unit test for function main
def test_main():
    inp, outp, debug, lib, root = 'test.py', 'temp.py', False, '', ''
    sys.argv = ['py-backwards', '-i', inp, '-o', outp, '-t', '26', '-d']
    assert main() == 0

if __name__ == '__main__':
    res = main()
    sys.exit(res)

# Generated at 2022-06-25 21:58:04.759979
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main(["-i", "/usr/bin/python", "-o", "/home/dima/PycharmProjects/py-backwards",
              "-t", "python2"])
    assert main(["-i", ".", "-o", ".", "-t", "python2"]) == 1
    main(["-i", ".", "-o", ".", "-t", "python2"])


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:58:07.847452
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    try:
        import pytest
        pytest.main([__file__])
    except ModuleNotFoundError as e:
        test_main()

# Generated at 2022-06-25 21:58:09.757330
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False


test_main()

# Generated at 2022-06-25 21:58:17.959972
# Unit test for function main
def test_main():
    with patch('argparse.ArgumentParser.parse_args',
               autospec=True) as mock_args:
        with patch('sys.stderr') as mock_sys:
            with patch('builtins.print') as mock_print:
                with patch('builtins.init_settings') as mock_settings:
                    instance = mock_args.return_value
                    instance.input.__getitem__.return_value = '1'
                    instance.output = '2'
                    instance.target = '3'
                    instance.debug = False
                    instance.root = '4'

                    # First exception case
                    with patch('compiler.compile_files',
                               side_effect=exceptions.CompilationError()) as p_compile:
                        main()
                        p_compile.assert_called_once()
                        mock_sys

# Generated at 2022-06-25 21:58:18.906299
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 21:58:20.017050
# Unit test for function main
def test_main():
    assert main() != 0, 'Something is wrong with main'
    pass



# Generated at 2022-06-25 21:58:22.195178
# Unit test for function main
def test_main():  # TODO
    pass


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-25 21:58:23.165738
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:24.371207
# Unit test for function main
def test_main():
    # Main execution of test
    test_case_0();
    # Test function



# Generated at 2022-06-25 21:59:00.598231
# Unit test for function main
def test_main():
    print("Test 0:")
    test_case_0()
    return True
if __name__ == '__main__':
    print(test_main())

# Generated at 2022-06-25 21:59:10.246058
# Unit test for function main
def test_main():
    from unittest.mock import patch
    with patch('sys.stdout', new=io.StringIO()) as fake_out:
        with patch('sys.stderr', new=io.StringIO()) as fake_err:
            args = ["-i", "input.py", "-o", "output.py", "-t", "python34"]
            try:
                main(args)
            except SystemExit as e:
                print(fake_out.getvalue())
                print(fake_err.getvalue())
                assert e.code==1

# Generated at 2022-06-25 21:59:12.889498
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit:
        pass

# Program entry point
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:59:14.534005
# Unit test for function main
def test_main():
    int_0 = main()
    equals_call_result_0 = equals(int_0, 1)
    return equals_call_result_0

# Generated at 2022-06-25 21:59:16.759608
# Unit test for function main
def test_main():
    if (main() == 0):
        print("Unit test 1 has passed!")
    else:
        print("Unit test 1 has failed!")

# Generated at 2022-06-25 21:59:18.199489
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        assert True
    else:
        assert False

# Generated at 2022-06-25 21:59:26.918866
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 21:59:27.727200
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:28.813413
# Unit test for function main
def test_main():
    test_case_0()
    # More cases if needed


# Generated at 2022-06-25 21:59:35.571148
# Unit test for function main
def test_main():
    from pytconf import register_main, run_main, Config
    class ConfigExample(Config):
        """
        Configuration for the script
        """
        def __init__(self):
            super().__init__()
            self.input = ['./tests/unit/example.py']
            self.output = './tests/unit/example_out.py'
            self.target = 'python36'
            self.root = './tests/unit'

    @register_main(ConfigExample, description="Unit test of function main")
    def main():
        main_result = main()
        print(main_result)

    run_main()

# Generated at 2022-06-25 22:01:00.146517
# Unit test for function main
def test_main():
    # Cases
    test_case_0()

# Generated at 2022-06-25 22:01:03.180372
# Unit test for function main
def test_main():
    assert test_case_0() == 0

test_main()

# Generated at 2022-06-25 22:01:06.107639
# Unit test for function main
def test_main():
    assert 0 == main()

# Generated at 2022-06-25 22:01:06.786090
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:01:14.497382
# Unit test for function main
def test_main():
    # Testing no input
    sys.argv = ['py-backwards']
    try:
        test_case_0()
        assert False
    except SystemExit:
        assert True

    # Testing no input
    sys.argv = ['py-backwards', '-i', 'test/test_src.py -o test/test_src.py',
                '-t', '2.7']
    try:
        test_case_0()
        assert False
    except SystemExit:
        assert True

    # Testing no input
    sys.argv = ['py-backwards', '-o', 'test/test_src.py', '-t', '2.7']
    try:
        test_case_0()
        assert False
    except SystemExit:
        assert True

    # Testing no input

# Generated at 2022-06-25 22:01:15.700938
# Unit test for function main
def test_main():
    print('test case 0')
    test_case_0()

test_main()

# Generated at 2022-06-25 22:01:22.570501
# Unit test for function main
def test_main():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()

if __name__ == '__main__':
    print(main())

# Generated at 2022-06-25 22:01:27.700983
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Exception in user code:")
        print('-' * 60)
        traceback.print_exc(file=sys.stdout)
        print('-' * 60)
        sys.exit(1)

if __name__ == "__main__":
    main()
    #test_main()

# Generated at 2022-06-25 22:01:38.388865
# Unit test for function main
def test_main():
    with mock.patch('builtins.print', return_value=None) as mock_print:
        with mock.patch('argparse.ArgumentParser',
                        spec=argparse.ArgumentParser,
                        return_value=None) as mock_ArgumentParser:
            with mock.patch('loop.compiler.compile_files',
                            return_value=None) as mock_compile_files:
                with mock.patch('loop.conf.init_settings',
                                return_value=None) as mock_arg_settings:
                    test_case_0()
    mock_print.assert_called_once_with(messages.compilation_result(None))

# Generated at 2022-06-25 22:01:41.475046
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_programs/pysrc', '-o', 'test/test_programs/pycompiled', '-t', '2.7']
    test_case_0()

test_main()

# Generated at 2022-06-25 22:05:01.305262
# Unit test for function main
def test_main():
    main()
    main(['-h'])
    main(['-o', 'output.py'])
    main(['-t', '2'])
    assert main(['-o', 'output.py', '-t', '2']) == 1
    assert main(['-i', 'input.py', '-t', '2']) == 1
    assert main(['-i', 'input.py', '-o', 'output.py']) == 1
    assert main(['-i', 'input.py', '-o', 'output.py', '-t', '2']) == 0

# Generated at 2022-06-25 22:05:06.323060
# Unit test for function main
def test_main():
    with patch('builtins.input', side_effect=['py-backwards', '-i', 'py_backwards/tests/test_cases/test_case_1/__init__.py', '-o',
                                              'py_backwards/tests/test_cases/test_case_1/__init__.py', '-t', '3.5']):
        test_case_0()


if __name__ == "__main__":
    main()
    test_main()

# Generated at 2022-06-25 22:05:18.040010
# Unit test for function main
def test_main():
    # Inline tests of the main function
    # Invalid python version
    sys.argv = ['py-backwards', '-i', './input.py', '-o', 'output.py',
                '-t', 'invalid', '-d']
    int_0 = main()
    assert int_0 == 1

    # No input file specified
    sys.argv = ['py-backwards', '-o', 'output.py', '-t', '3.5']
    int_1 = main()
    assert int_1 == 2

    # No output file specified
    sys.argv = ['py-backwards', '-i', './input.py', '-t', '3.5']
    int_2 = main()
    assert int_2 == 2

    # No python version specified
    sys.argv

# Generated at 2022-06-25 22:05:19.793033
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 22:05:29.509188
# Unit test for function main
def test_main():
    # Initialize ArgParse Parser
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 22:05:35.386490
# Unit test for function main
def test_main():
    real_sys_argv = sys.argv
    try:
        sys.argv = ["py-backwards", "-i","_test/test_input/compiler_test.py","-o","_test/compiler_test_output.py","-t","2.7","-r","_test/test_input/"]
        int_0 = main()
        assert int_0 == 0
    finally:
        sys.argv = real_sys_argv

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'test':
        test_main()
    else:
        main()

# Generated at 2022-06-25 22:05:35.811612
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:05:36.752888
# Unit test for function main
def test_main():
    assert main() == 0
    

# Generated at 2022-06-25 22:05:39.242199
# Unit test for function main
def test_main():
    # Test case
    print("Test case 0: ", end="")
    test_case_0()
    sys.exit(0)

# Generated at 2022-06-25 22:05:40.762138
# Unit test for function main
def test_main():
    # Arguments for function main
    int_0: str = ''
    main_0 = main(int_0)


if __name__ == '__main__':
    main()