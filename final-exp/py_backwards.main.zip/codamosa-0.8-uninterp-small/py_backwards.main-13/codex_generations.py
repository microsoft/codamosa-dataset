

# Generated at 2022-06-25 21:56:45.133509
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        if e.code == 0:
            assert True
        else:
            assert False

# Generated at 2022-06-25 21:56:46.038197
# Unit test for function main
def test_main():
    assert test_case_0() is None

# Generated at 2022-06-25 21:56:47.940771
# Unit test for function main
def test_main():
    test_case_0()

# Programme entry point
if __name__ == "__main__":
    # Call function main
    test_main()

# Generated at 2022-06-25 21:56:50.706807
# Unit test for function main
def test_main():
    int_1 = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:56:58.906302
# Unit test for function main
def test_main():
    test_case_0()

run_test(test_main)

# Run the program
main()

# Stop logging exceptions
remove_exception_handler()

 
# Main script
#
# logger = logging.getLogger(__name__)
#
#
# def main() -> int:
#     logger.debug('Starting main...')
#     logger.info('Starting main...')
#     logger.warning('Starting main...')
#     logger.error('Starting main...')
#     logger.critical('Starting main...')
#     logger.fatal('Starting main...')
#     try:
#         x = 5 / 0
#     except Exception as e:
#         logger.exception('Error in main!')
#         raise e
#     logger.info('Exit main.')
#     return 0
#


# Generated at 2022-06-25 21:57:00.627313
# Unit test for function main
def test_main():
    # Call function main and store the result
    result = main()
    # If the result is zero all the tests are successful
    assert result == 0

# Generated at 2022-06-25 21:57:01.876245
# Unit test for function main
def test_main():
    assert callable(main)
    try:
        main()
    except:
        pass

# Generated at 2022-06-25 21:57:02.712121
# Unit test for function main
def test_main():
    assert main() == 0, "Error"

# Generated at 2022-06-25 21:57:05.077233
# Unit test for function main
def test_main():
    test_case_0()
    # Outputs:
    # Compiling 3 files from backend/tests/compiler/fixtures/input to /tmp/...
    # Compiled 1 files successfully, 0 failed


# Generated at 2022-06-25 21:57:07.391580
# Unit test for function main
def test_main():
    assert int_0 == 1

test_case_0()

# Generated at 2022-06-25 21:57:17.655109
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 1


# Generated at 2022-06-25 21:57:18.910007
# Unit test for function main
def test_main():
    main()
    main2()
    main3()


# Generated at 2022-06-25 21:57:20.271238
# Unit test for function main
def test_main():
    test_case_0()

# unit test for entire module

# Generated at 2022-06-25 21:57:21.120732
# Unit test for function main
def test_main():
    assert test_case_0() == 0

main()

# Generated at 2022-06-25 21:57:21.942867
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 21:57:30.982709
# Unit test for function main
def test_main():
    # Wrong args
    sys.argv = ['py-backwards', '-o', 'folder0', '-i', 'folder1']
    int_0 = main()
    assert int_0 == 2

    # Wrong input
    sys.argv = ['py-backwards', '-o', 'folder0', '-i', 'folder1/file.py',\
                '-t', '2.7']
    int_0 = main()
    assert int_0 == 1

    # Wrong output
    sys.argv = ['py-backwards', '-o', 'folder0/file.py', '-i', 'folder1',\
                '-t', '2.7']
    int_0 = main()
    assert int_0 == 1

    # Wrong target

# Generated at 2022-06-25 21:57:34.000189
# Unit test for function main
def test_main():
    assert "main" in globals(), "No main function."
    assert callable(main), "Not a function."
    assert main(main) == "main"

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:57:34.520612
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:57:36.244163
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:37.079676
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:55.872889
# Unit test for function main
def test_main():
    test_case_0()


main()

# Generated at 2022-06-25 21:57:57.481074
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:58:00.283487
# Unit test for function main
def test_main():
    print("Test case 0: python -r", end=' ')
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:58:01.111672
# Unit test for function main
def test_main():
    """test_main"""
    test_case_0()

# Generated at 2022-06-25 21:58:01.605612
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 21:58:02.133113
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:58:05.470747
# Unit test for function main
def test_main():
    with patch.object(sys, 'argv', ['py-backwards', '-i', './py_backwards/tests/test_data/import_from.py', '-o', 'tmp', '-t', '3_6', '--debug']):
        test_case_0()


main()

# Generated at 2022-06-25 21:58:14.608102
# Unit test for function main
def test_main():

    # If input is valid
    if True:
        print("Checking for Valid Input")
    
        # test for input: file or folder and target version 2
        if True:
            print("Checking for input: file or folder and target version 2")
            arg_1 = '-i test_files/test_case_0.py test_files/test_case_1.py'
            arg_2 = '-o test_files/test_case_0.py test_files/test_case_1.py'
            arg_3 = '-t 2'
            arg_4 = '-r test_files/'
            arg_5 = '-d'
            main()
            # expected output is 0
            int_0 = 0
            assert int_0 == 0
            # pass
            print("Arguments match")
    


# Generated at 2022-06-25 21:58:16.025512
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:58:16.666845
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:58:55.595076
# Unit test for function main
def test_main():
    for test_case in [test_case_0]:
        test_case()

# Generated at 2022-06-25 21:58:56.694926
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:57.722602
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point

# Generated at 2022-06-25 21:59:10.429757
# Unit test for function main
def test_main():
    import sys
    import os
    sys.argv = ['py-backwards', '-i', 'test_case', '-o', 'out', '-t', 'py27', '-r', 'test_case']
    test_case_0()
    if not os.path.exists('out/test_case'):
        raise Exception("Failed in test_case 1")
    if not os.path.exists('out/test_case/test_module.py'):
        raise Exception("Failed in test_case 2")
    if os.path.exists('out/test_case/lambda-function.py'):
        raise Exception("Failed in test_case 3")

# Generated at 2022-06-25 21:59:11.757390
# Unit test for function main
def test_main():
    int_0 =  main()
    assert int_0 == 0


# Generated at 2022-06-25 21:59:20.616294
# Unit test for function main
def test_main():
    # Let C0 denote the case where no error is raised
    # Let C1 denote the case where CompilationError is raised
    # Let C2 denote the case where TransformationError is raised
    # Let C3 denote the case where InputDoesntExists is raised
    # Let C4 denote the case where InvalidInputOutput is raised
    # Let C5 denote the case where PermissionError is raised

    # C1 is not testable because it can't be raised without user interaction

    # Test case 1 - C2
    try:
        main()
    except exceptions.TransformationError:
        # Test case C2 passed
        return
    # If C2 is not raised, the test case failed
    assert False

    # Test case 2 - C3

# Generated at 2022-06-25 21:59:21.459825
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:25.110530
# Unit test for function main
def test_main():
    input0 = ["test_test.py", "test2_test.py"]
    output0 = "test"
    assert main_test(input0, output0) == 0, s.format()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:59:30.451711
# Unit test for function main
def test_main():
    # Setup
    sys.argv = sys.argv[:1]
    sys.argv.append("-i")
    sys.argv.append("./tests/transformer_tests/test1.py")
    sys.argv.append("-o")
    sys.argv.append("test1.py")
    sys.argv.append("-t")
    sys.argv.append("3.4")
    sys.argv.append("-r")
    sys.argv.append("/")
    sys.argv.append("-d")
    # Exercise
    main()

# Generated at 2022-06-25 21:59:31.001040
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-25 22:00:57.445920
# Unit test for function main
def test_main():

    # Arrange
    sys.argv = ['py-backwards', '-i', 'project/app.py', '-o', 'project/output', '-t', '3.5', '-r', 'project', '-d']

    # Act
    int_0 = main()

    # Assert

    assert(int_0 == 0)

# Generated at 2022-06-25 22:00:58.816204
# Unit test for function main
def test_main():
    # User input is handled by argparse, so it's not possible to write
    # unit tests.
    pass

# Generated at 2022-06-25 22:01:00.898823
# Unit test for function main
def test_main():
    with patch('__main__.main', return_value=0) as main_function:
        assert main_function.return_value == 0


# Generated at 2022-06-25 22:01:09.761816
# Unit test for function main
def test_main():
    # Arrange
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 22:01:11.217518
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 22:01:13.394344
# Unit test for function main
def test_main():
    assert main() == 1


# Generated at 2022-06-25 22:01:14.569658
# Unit test for function main
def test_main():
    assert True == False


# Generated at 2022-06-25 22:01:17.986652
# Unit test for function main
def test_main():
    try:
        t1 = threading.Thread(target=test_case_0)
        t1.start()
    except:
        print('Exception: unable to start thread')

if __name__ == "__main__":
    # Test
    test_main()

# Generated at 2022-06-25 22:01:23.135400
# Unit test for function main
def test_main():
    test_cases = [0]

    for case in test_cases:
        if case == 0:
            test_case_0()

# Generated at 2022-06-25 22:01:28.232543
# Unit test for function main
def test_main():
    print("Test #1")
    print("Input:")
    print("py-backwards -i tests/data/temp/main.py -o tests/data/temp/out_main.py -t 2.7")
    print("Output:")
    test_case_0()
    print("----------------")

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:04:36.955744
# Unit test for function main
def test_main():
    test_str = 'TEST SUCCESS'
    test_str_1 = 'TEST_ROOT'
    sys.argv = [
        '', '-i', '@tests/goals/', '-o', '@tests_out/goals_out',
        '-t', '2.7', '--root', test_str_1
    ]
    try:
        int_0 = main()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-25 22:04:38.030530
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:04:39.047617
# Unit test for function main
def test_main():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 22:04:45.196324
# Unit test for function main
def test_main():
    import argparse
    from .compiler import Compiler
    from .settings import init_settings, get_settings
    from .debug import debug
    from . import const, messages, exceptions
    import os, sys

    class Args:
        def __init__(self, input, output, target, root, debug):
            self.input = input
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    def sys_exit(code):
        raise SystemExit(code)

    # Save the global variables used in this file
    saved_main = __main__
    saved_sys = sys
    saved_os = os
    saved_argparse = argparse.ArgumentParser
    saved_init_settings = init_settings
    saved_Compiler = Compiler
    saved_get_

# Generated at 2022-06-25 22:04:51.653927
# Unit test for function main
def test_main():
    with tempfile.TemporaryDirectory() as compile_files_tmp_dir:
        with tempfile.TemporaryDirectory() as input_tmp_dir:
            with tempfile.TemporaryDirectory() as output_tmp_dir:
                fd = open(os.path.join(input_tmp_dir, 'test_file.py'), 'w')
                fd.write('def test_func(): return True')
                fd.close()

                assert main([
                    '--input', os.path.join(input_tmp_dir, 'test_file.py'),
                    '--output', os.path.join(output_tmp_dir, 'output.py'),
                    '--root', '/'
                ]) == 0

                fd = open(os.path.join(output_tmp_dir, 'output.py'), 'r')

# Generated at 2022-06-25 22:04:52.073879
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 22:04:52.524205
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 22:04:53.664172
# Unit test for function main

# Generated at 2022-06-25 22:04:54.322804
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:01.459453
# Unit test for function main
def test_main():
    try:
        user_input_1 = ['-i', 'file.py', '-t', 'python2.7', '-o', 'compiled.py']
        with patch.object(sys, 'argv', user_input_1):
            test_case_0()
    except SystemExit:
        pass

if __name__ == '__main__':
    # Run test for function main
    test_main()