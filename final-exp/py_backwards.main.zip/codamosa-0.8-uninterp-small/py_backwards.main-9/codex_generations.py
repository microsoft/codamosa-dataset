

# Generated at 2022-06-25 21:56:41.500566
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/data/compile', '-o', 'tests/data/compile/output', '-t', 'v2']
    test_case_0()

test_main()

# Generated at 2022-06-25 21:56:42.760282
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:45.175885
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:56:55.193867
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        assert(e.code == 0)

    try:
        sys.argv[1:] = ['--input', 'app.py', '-o', 'app.py', '-t', '3.5', '-r', 'root']
        test_case_0()
    except SystemExit as e:
        assert(e.code == 0)

    try:
        sys.argv[1:] = ['--input', 'app.py', '-o', 'app.py', '-t', '3.6', '-r', 'root']
        test_case_0()
        assert False
    except SystemExit as e:
        assert(e.code == 1)


# Generated at 2022-06-25 21:56:57.721839
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:06.976084
# Unit test for function main
def test_main():
    # Setup
    os.chdir(os.path.join(os.path.dirname(__file__), '..'))
    os.environ['PY_BWD_TEST'] = 'true'
    os.environ['PY_BWD_TARGET'] = '2.7'
    os.environ['PY_BWD_ROOT'] = os.getcwd() + '/tests'
    os.environ['PY_BWD_INPUT'] = os.getcwd() + '/tests/pass_test.py'
    os.environ['PY_BWD_OUTPUT'] = os.getcwd() + '/tests/output.py'

# Generated at 2022-06-25 21:57:15.695880
# Unit test for function main
def test_main():
    import os
    import shutil
    sys.argv = ['dummy.py', '-i', 'examples/test_4.py', '-t', '2.7', '-o', './output']
    main()
    assert os.path.isfile('./output/test.py')
    with open('./output/test.py', 'r') as f:
        assert f.readline() == '# -*- coding: latin1 -*-\n'
        assert f.readline() == '\n'
        assert f.readline() == 'from __future__ import division\n'
        assert f.readline() == 'from __future__ import absolute_import\n'
        assert f.readline() == 'from __future__ import print_function\n'
        assert f.readline

# Generated at 2022-06-25 21:57:16.500963
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:25.482643
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-h"]
    assert(main() == 0)

    sys.argv = ["py-backwards", "--help"]
    assert(main() == 0)

    sys.argv = ["py-backwards", "-i", "test/code/source_modules",
                "-o", "test/output", "-t", "2.7", "-d"]
    assert(main() == 0)

    sys.argv = ["py-backwards", "-i", "test/code/source_modules",
                "-o", "test/output/nested_folder", "-t", "2.7", "-d"]
    assert(main() == 0)


# Generated at 2022-06-25 21:57:26.891843
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except NameError:
        assert False

# Generated at 2022-06-25 21:57:46.490394
# Unit test for function main
def test_main():
    test_case_0()

# Provides entry point into program
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:48.378573
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False, 'test failed'


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:57:50.531304
# Unit test for function main
def test_main():
    # Call the function to get the True or False result and save it in int_0
    int_0 = main()
    # Test to ensure that the main function produces 0 as the exit status
    assert int_0 == 0

# Generated at 2022-06-25 21:57:52.407251
# Unit test for function main
def test_main():
    print(currentframe().f_code.co_name)
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:57:53.981002
# Unit test for function main
def test_main():
    # Call function main
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:57.271504
# Unit test for function main
def test_main():
    try:
        temp_argv = sys.argv
        sys.argv = ["py-backwards", "-i", "test/input", "-o", "test/output", "-target", "3.5"]
        test_case_0()
    finally:
        sys.argv = temp_argv

# Generates a function with given name.

# Generated at 2022-06-25 21:58:00.092148
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('Import error in test case')

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:58:03.325900
# Unit test for function main
def test_main():
    import sys
    import io

    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    my_result = main()
    my_expected_result = 0

    print(capturedOutput.getvalue())

    assert my_result == my_expected_result



# Generated at 2022-06-25 21:58:12.293905
# Unit test for function main
def test_main():
    # Test cases
    test_case_0()
    # Test error cases

# Main function. Runs only if file is run as a top-level file
if __name__ == '__main__':
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')

# Generated at 2022-06-25 21:58:13.821737
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:58:50.173928
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 21:58:56.734861
# Unit test for function main
def test_main():
    '''
    Default case
    '''
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:59:08.899872
# Unit test for function main
def test_main():
    import argparse
    target = parser.add_argument.return_value
    target.choices = ['3.5']
    single_file_input_args = ['single_file_input.py', 'single_file_output.py', '3.5']
    multiple_files_input_args = ['multiple_files_input.py', 'multiple_files_output.py', '3.5']
    single_folder_input_args = ['single_folder_input', 'single_folder_output', '3.5']
    multiple_folder_input_args = ['multiple_folder_input', 'multiple_folder_output', '3.5']
    # single_input_args = ['single_input.py', 'single_output.py', '3.5']
    # multiple_input_args = ['multiple_input.py', 'multiple

# Generated at 2022-06-25 21:59:15.589664
# Unit test for function main
def test_main():
    sys.argv = ['prog',
                '--input', './test_data/test_input.txt',
                '--output', './test_data/test_result.txt',
                '--target', '2.7'
                ]
    test_case_0()
    sys.argv = ['prog',
                '--input', './test_data/test_input.txt',
                '--output', './test_data/test_folder/',
                '--target', '3.6'
                ]
    test_case_0()


test_main()

# Generated at 2022-06-25 21:59:19.698032
# Unit test for function main
def test_main():
    # Argument 1: argv
    argv = ['-i', '.', '-o', 'out', '-t', 'py35']
    sys.argv = argv

    # Argument 2: func_main
    func_main = main()

    # Check if equal to 0, which is success
    assert func_main == 0

# Generated at 2022-06-25 21:59:20.227305
# Unit test for function main
def test_main():
  pass
  

# Generated at 2022-06-25 21:59:21.392845
# Unit test for function main
def test_main():
    test = main()
    assert test == 0, "Error"


# Generated at 2022-06-25 21:59:29.608748
# Unit test for function main
def test_main():
    path = os.path.dirname(__file__)
    os.chdir(path)
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')

# Generated at 2022-06-25 21:59:30.425016
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 21:59:31.460602
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:00:11.957395
# Unit test for function main
def test_main():
    try:
        assert callable(main)
        assert isinstance(main(), int)
    except:
        print('Function main does not exist or is not callable.')

test_main()

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-25 22:00:13.522374
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:00:14.882274
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 22:00:15.738770
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:00:17.197334
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0

test_case_0()
test_main()


# Generated at 2022-06-25 22:00:23.537222
# Unit test for function main
def test_main():
    import pytest
    import sys
    import io
    sys.stderr = io.StringIO()
    sys.stdout = io.StringIO()
    sys.argv = ['py-backwards', '-i', 'parser.py', '-o', 'parser2.py', '-t', '2.7']
    with pytest.raises(SystemExit) as e_info:
        main()
    assert e_info.value.code == 0
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__

# Generated at 2022-06-25 22:00:32.141676
# Unit test for function main
def test_main():
    int_0 = 'py-backwards -i test_data/test_import_0.py -o /tmp/py-backwards/ -t py25'
    int_1 = 'py-backwards -i test_data/test_import_0.py -o /tmp/py-backwards/ -t py26'
    int_2 = 'py-backwards -i test_data/test_import_0.py -o /tmp/py-backwards/ -t py27'
    int_3 = 'py-backwards -i test_data/test_import_0.py -o /tmp/py-backwards/ -t py30'
    int_4 = 'py-backwards -i test_data/test_import_0.py -o /tmp/py-backwards/ -t py31'
    int_5

# Generated at 2022-06-25 22:00:33.239276
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()


# Main function

# Generated at 2022-06-25 22:00:40.819053
# Unit test for function main
def test_main():
    try:
        main()

    except SystemExit as e:
        if e.code == 1:
            print('Test case passed.')
        else:
            print('Test case failed. Expected return code 1.')
    except:
        print('Test case failed. Expected SystemExit exception.')

if __name__ == '__main__':
    #test_case_0()
    #test_case_1()
    #test_case_2()
    #test_case_3()
    #test_case_4()
    #test_case_5()
    test_case_6()
    test_case_7()
    test_main()

# Generated at 2022-06-25 22:00:41.576348
# Unit test for function main
def test_main():
    int_0 = main()



# Generated at 2022-06-25 22:02:01.601073
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 22:02:02.611570
# Unit test for function main
def test_main():
    int_0 = main()
    assert(int_0 == 0)


# Generated at 2022-06-25 22:02:03.406027
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:02:04.263773
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:02:05.898799
# Unit test for function main
def test_main():
    test_case_0()
    
# Compute code coverage statistics

# Generated at 2022-06-25 22:02:08.499238
# Unit test for function main
def test_main():
    # Test Cases
    test_case_0()
    pass


# Execute Unit Tests
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 22:02:09.775466
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 22:02:12.541833
# Unit test for function main
def test_main():
    # unit test case 0
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 22:02:19.777169
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '--input', 'tests/basic.py',
        '--output', 'out',
        '--target', '2.7'
    ]
    int_0 = main()
    sys.argv = [
        'py-backwards',
        '--input', 'tests/basic.py',
        '--output', 'out',
        '--target', '3.6'
    ]
    int_1 = main()
    sys.argv = [
        'py-backwards',
        '--input', 'tests/basic.py',
        '--output', 'out',
        '--target', '3.6',
        '--debug'
    ]
    int_2 = main()

    assert int_0 == 0
    assert int_1

# Generated at 2022-06-25 22:02:22.175890
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:05:40.103295
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:40.709738
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 22:05:41.315978
# Unit test for function main
def test_main():
    assert int_0 == 1

# Generated at 2022-06-25 22:05:42.417361
# Unit test for function main
def test_main():
    test_case_0()
    return 0


# Generated at 2022-06-25 22:05:42.815314
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:05:45.645172
# Unit test for function main
def test_main():
    try:
        test_case_0()
        print("Unit test for function main with argv[1] = '' and argv[2] = '' passed")
    except AssertionError:
        print("Test case failed")

# Unit tests for functions compile and compile_files

# Generated at 2022-06-25 22:05:46.314699
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:47.608702
# Unit test for function main
def test_main():
    import pytest
    import py
    test_case_0()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 22:05:48.254705
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 22:05:48.895229
# Unit test for function main
def test_main():
    assert test_case_0() == 0