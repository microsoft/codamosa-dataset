

# Generated at 2022-06-25 21:56:42.184308
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0
    assert True

# Generated at 2022-06-25 21:56:44.956705
# Unit test for function main
def test_main():
    print("Start test_main")
    test_case_0()
    print("End test_main")

# Generated at 2022-06-25 21:56:51.822603
# Unit test for function main
def test_main():

    tmpfile = open("output.txt", "w")
    try:
        sys.stdout = tmpfile
        main()
    finally:
        tmpfile.close()
        sys.stdout = sys.__stdout__
        result = open("output.txt", "r")
        print("Unit test for function main")
        print("Output ")
        print("----------------------")
        print(result.readline())
        result.close()

test_case_0()
test_main()

# Generated at 2022-06-25 21:56:53.160442
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-25 21:56:54.735967
# Unit test for function main
def test_main():
    print("Testing function main")
    test_case_0()


# Run all tests

# Generated at 2022-06-25 21:56:57.603631
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:06.976106
# Unit test for function main
def test_main():
    parser = ArgumentParser()
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="increase output verbosity")
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 21:57:09.438624
# Unit test for function main
def test_main():
    test_case_0()  # 1. -i=tests/test.py -o=tests/test.py -r=tests/ -t=py36


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:57:10.293733
# Unit test for function main
def test_main():
    int_0 = main()

# Generated at 2022-06-25 21:57:10.900465
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:57:30.086478
# Unit test for function main
def test_main():
    for i in range(10):
        test_case_0()

# Generated at 2022-06-25 21:57:30.988596
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:32.414998
# Unit test for function main
def test_main():
    print("test_main")
    # Just run it
    test_case_0()

# Generated at 2022-06-25 21:57:36.644256
# Unit test for function main
def test_main():
    argv = ['./pycompiler.py', '-i', './test/compile_tests/simple.py', '-o', './test/compile_tests/simple3.py', '-t', '3.4']
    sys.argv = argv
    int_0 = main()
    assert int_0 == 0

# Generated at 2022-06-25 21:57:40.513736
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv += ["-i", "__pycache__/py_backwards/const.cpython-36.pyc", "-o", "__pycache__/py_backwards/const.cpython-27.pyc", "-t", "2.7"]
    test_case_0()

# Generated at 2022-06-25 21:57:43.058864
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e)
        assert False
    assert True
    

# Generated at 2022-06-25 21:57:46.414290
# Unit test for function main
def test_main():
    int_0 = main()
    assert type(int_0) == int

    int_0 = main()
    assert int_0 == 1

    int_0 = main()
    assert int_0 == 1


# Generated at 2022-06-25 21:57:47.187388
# Unit test for function main
def test_main():
    assert main() == 0
    assert main() == 1

# Generated at 2022-06-25 21:57:48.513121
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:55.893712
# Unit test for function main
def test_main():
    sys.argv = ["py_backwards",
                "-i", "tests/input/",
                "-o", "tests/output/",
                "-t", "3.5",
                "-r", "tests/input/"]
    main()
    test_0 = open("tests/output/main.py")
    test_1 = open('tests/output/2_0.py')
    test_2 = open('tests/output/2_1.py')
    test_3 = open('tests/output/2_2.py')
    test_4 = open('tests/output/2_3.py')
    ans_0 = open("tests/answers/3.5/main.py")
    ans_1 = open("tests/answers/3.5/2_0.py")

# Generated at 2022-06-25 21:58:33.123891
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-25 21:58:33.731101
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 21:58:34.546481
# Unit test for function main
def test_main():
    main()
    main()
    main()



# Generated at 2022-06-25 21:58:39.516233
# Unit test for function main
def test_main():
    with patch('sys.argv', ['main.py', '-i', 'test_data/test_input/test_case_0.py', '-o', 'test_data/test_output/test_case_0.py', '-t', 'py_2', '-r', 'root']):
        test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:58:41.352674
# Unit test for function main
def test_main():
    print('Test #0')
    test_case_0()
    print('Test #1')
    test_case_1()


# Generated at 2022-06-25 21:58:41.874127
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:58:44.417171
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:58:47.645726
# Unit test for function main
def test_main():
    """
    Unit test for function main
    :return:
    """

    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:58:57.281718
# Unit test for function main

# Generated at 2022-06-25 21:58:57.984763
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:41.260759
# Unit test for function main
def test_main():
    import sys
    import io
    import contextlib
    display, sys.stdout = sys.stdout, io.StringIO()

    main()

    sys.stdout = sys.__stdout__
    assert False, 'test failed'


if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 21:59:45.820098
# Unit test for function main
def test_main():
    argv = ['py-backwards', '--input', 'test_files/test_py36.py', '--output', 'test_files/test_py36_result.py', '--target', 'python36']
    sys.argv = argv
    test_case_0()


# Generated at 2022-06-25 21:59:54.148610
# Unit test for function main
def test_main():
    from .conf import init_settings
    import os
    import random
    import string

    random_string = ' '.join([random.choice(string.ascii_lowercase) for i in range(5)])
    random_string += ' '
    random_string += ' '.join([random.choice(string.ascii_lowercase) for i in range(5)])
    random_string += ' '
    random_string += ' '.join([random.choice(string.ascii_lowercase) for i in range(5)])
    random_string += ' '
    random_string += ' '.join([random.choice(string.ascii_lowercase) for i in range(5)])
    random_string += ' '

# Generated at 2022-06-25 21:59:55.872566
# Unit test for function main
def test_main():
    # If no exception is raised then test passed
    try:
        test_case_0()
        assert True
    except:
        assert False

# Generated at 2022-06-25 21:59:58.219121
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        print('Test main')
        test_case_0()

# Generated at 2022-06-25 21:59:59.792570
# Unit test for function main
def test_main():
    assert main() == 0

# Linting doesn't like unused functions, so we just call it
test_case_0()

# Generated at 2022-06-25 22:00:01.085619
# Unit test for function main
def test_main():
    test_case_0()



# Generated at 2022-06-25 22:00:05.236514
# Unit test for function main
def test_main():
    try:
        _main(['-i', 'sources/sample_file.py', '-o', 'compiled', '-t', '2.7', '-r', 'sources', '-d', 'True'])
    except SystemExit as e:
        assert e.code == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 22:00:08.579262
# Unit test for function main
def test_main():
    # test_case_0
    print('\n=================== test_main ===================')
    test_case_0()
    print('================= End test_main =================')
    sys.exit(0)

# Generated at 2022-06-25 22:00:12.977855
# Unit test for function main
def test_main():
    target_stdout = sys.stdout
    target_stderr = sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()
    test_case_0()
    target_stdout.write(sys.stdout.getvalue())
    target_stderr.write(sys.stderr.getvalue())
    sys.stdout = target_stdout
    sys.stderr = target_stderr


main()

# Generated at 2022-06-25 22:01:37.674396
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:01:38.621492
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-25 22:01:39.588062
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:01:40.094639
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 22:01:50.397254
# Unit test for function main
def test_main():
    # Set up the inputs
    sys.argv = []
    sys.argv.append('-i')
    sys.argv.append('py3features.py')
    sys.argv.append('-o')
    sys.argv.append('py3features_comp.py')
    sys.argv.append('-t')
    sys.argv.append('2')
    sys.argv.append('-r')
    sys.argv.append('~')
    sys.argv.append('-d')

    test_case_0()


if __name__ == '__main__':
    print(test_main())

# Generated at 2022-06-25 22:01:52.407313
# Unit test for function main
def test_main():
    print("Testing function main...", end="")
    assert main() == 0
    print("Passed!")

#################################################
# main
#################################################


# Generated at 2022-06-25 22:01:56.200342
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-25 22:02:07.620399
# Unit test for function main
def test_main():
    parser = ArgumentParser('py-backwards', description='Python to python compiler that allows you to use some '
                                                        'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 22:02:11.877619
# Unit test for function main
def test_main():
    try:
        # Test case 1:
        main()
        main()
        main()
        main()
        main()
        main()
        main()
        main()
        main()
        main()
        main()
    except Exception as e:
        print(e)
        assert False


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:02:13.617859
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:03:55.778749
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        assert e.code == 0

# Compiles py-backwards with python 3.6 if executed with -m
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 22:03:56.270795
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 22:03:57.516264
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 22:03:58.797381
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 22:03:59.723122
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:04:01.407350
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 22:04:03.448824
# Unit test for function main
def test_main():
    # test case 0
    test_case_0()

# program entry point
# if __name__ == "__main__":
#    main()


# Generated at 2022-06-25 22:04:04.514638
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        raise

# Generated at 2022-06-25 22:04:14.835843
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')
    args = parser.parse_args()
    init

# Generated at 2022-06-25 22:04:17.149411
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'main.py', '-o', '/tmp/test.py', '-t', '3.5', '-r', '.']
    assert main() == 0