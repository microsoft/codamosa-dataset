

# Generated at 2022-06-25 21:56:34.249135
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:37.598013
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', new=["PyBackwards.py",
                                     "-i", "Examples/HelloWorld",
                                     "-o", "/tmp/Result",
                                     "-t", "python3.6",
                                     "-r", "/tmp/Result",
                                     "-d", "False"
                                     ]):
        x = main()
    assert x == 0



# Generated at 2022-06-25 21:56:47.183255
# Unit test for function main
def test_main():
    # Test of positive execution:
    sys.argv = ['py-backwards',
                '-i', '../../test_data/inputs/example1',
                '-o', '../../test_data/outputs',
                '-r', '../../test_data',
                '-t', 'py35']
    test_case_0()
#    sys.argv = ['py-backwards',
#                '-i', '../../test_data/inputs/example2',
#                '-o', '../../test_data/outputs',
#                '-r', '../../test_data',
#                '-t', 'py36']
#    test_case_0()
#    sys.argv = ['py-backwards',
#                '-i', '../../test_data/

# Generated at 2022-06-25 21:56:48.107886
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 21:56:57.756396
# Unit test for function main
def test_main():
    # Create test environment
    os.mkdir('test_root')
    os.mkdir('test_root/a')
    os.mkdir('test_root/b')
    os.mkdir('test_root/output')
    with open('test_root/a/input1.py', 'w') as file:
        pass
    with open('test_root/a/input2.py', 'w') as file:
        pass
    with open('test_root/b/input3.py', 'w') as file:
        pass
    with open('test_root/b/input4.py', 'w') as file:
        pass
    with open('test_root/output/input1.py', 'w') as file:
        pass
    # Run function under test
    int_0 = main.__wrapped__

# Generated at 2022-06-25 21:57:00.365897
# Unit test for function main
def test_main():
    int_0 = main()
    assert(int_0 == 0)

# LCOV_EXCL_START
if __name__ == "__main__":
    main()
# LCOV_EXCL_STOP

# Generated at 2022-06-25 21:57:01.335404
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 21:57:02.168805
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 21:57:03.611053
# Unit test for function main
def test_main():
    int_ret_0 = test_case_0()

    assert int_ret_0 == 0

# Generated at 2022-06-25 21:57:05.340952
# Unit test for function main
def test_main():
    print("Testing function main")
    print("#------------------------------------------------------------------#")
    test_case_0()

# Creating a test case function

# Generated at 2022-06-25 21:57:24.391783
# Unit test for function main
def test_main():
    test_case_0()

# Run test
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:25.928844
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Error while testing function main")
        raise

# Generated at 2022-06-25 21:57:27.669746
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:29.807453
# Unit test for function main
def test_main():
    test_case_0()

# Boilerplate code to call main function and other useful functions
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:31.343755
# Unit test for function main
def test_main():
    try:
        main()
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 21:57:35.587084
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', ["py-backwards",
                                 "-i \"py_backwards/tests/Cases/case0.py\"",
                                 "-o \"py_backwards/tests/Outputs/case0.py\"",
                                 "-t 3.5"]):
        test_case_0()

# Generated at 2022-06-25 21:57:37.315629
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:40.279803
# Unit test for function main
def test_main():
    # Test cases
    test_case_0()


if __name__ == "__main__":
    if len(sys.argv) == 1:
        test_main()
    else:
        sys.exit(main())

# Generated at 2022-06-25 21:57:43.548616
# Unit test for function main
def test_main():
    sys.argv = ['--input', 'tests/test_0.py', '--target', '3.6', '--output', '----']
    int_0 = main()
    assert int_0 == 0

# Generated at 2022-06-25 21:57:45.046550
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 21:58:21.601841
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:24.932362
# Unit test for function main
def test_main():
    config = Config(
        args=['', '-i', './test/test_0.py', '-o', './test/test_0_output.py', '-t', '30', '-r', '.'])
    assert main(config) == 0

# Generated at 2022-06-25 21:58:34.099707
# Unit test for function main
def test_main():
    try:
        import sys
        import io
        from contextlib import contextmanager
    except Exception as e:
        print(e)

    # Capture the output
    @contextmanager
    def capture():
        oldout, olderr = sys.stdout, sys.stderr
        try:
            out = [io.StringIO(), io.StringIO()]
            sys.stdout, sys.stderr = out
            yield out
        finally:
            sys.stdout, sys.stderr = oldout, olderr
            out[0] = out[0].getvalue()
            out[1] = out[1].getvalue()

    with capture() as out:
        main()

# Generated at 2022-06-25 21:58:34.493077
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:58:35.107855
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 21:58:38.003547
# Unit test for function main
def test_main():
    # Case 0
    int_0 = test_case_0()
    assert int_0 == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:58:48.487793
# Unit test for function main
def test_main():

# Users arguments are valid
    sys.argv = [
        './test_pybackwards.py',
        '-i', 'test_inputs/test_input.py',
        '-o', 'test_outputs/test_output.py',
        '-t', '3.5']
    test_case_0()

# Users arguments are invalid
    sys.argv = [
        './test_pybackwards.py',
        '-i', 'test_inputs/test_input.py',
        '-o', 'test_outputs/test_output.py',
        '-z', '3.5']
    with pytest.raises(SystemExit):
        test_case_1()

# Users arguments are invalid

# Generated at 2022-06-25 21:58:57.849872
# Unit test for function main
def test_main():
    class MockStdout:
        def __init__(self):
            self.written = []
        def write(self, text):
            self.written.append(text)
        def flush(self):
            pass
    class MockStderr:
        def __init__(self):
            self.written = []
        def write(self, text):
            self.written.append(text)
        def flush(self):
            pass
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr
    sys.stdout = MockStdout()
    sys.stderr = MockStderr()

    test_case_0()
    assert sys.stdout.written == ['TODO\n']
    assert sys.stderr.written == []
    sys.stdout = saved

# Generated at 2022-06-25 21:58:58.302343
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:58:58.869646
# Unit test for function main
def test_main():
    test_case_0()
    pass

# Generated at 2022-06-25 22:00:20.908262
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]]
    sys.argv += ["-i", 'tests/sources/main.py', 'tests/sources/abstract_class.py', 'tests/sources/concrete_class.py']
    sys.argv += ["-o", '/home/sohrab/Desktop/output/py-backwards-output/']
    sys.argv += ["-t", "2.7"]
    try:
        int_0 = main()
    except SystemExit as e:
        int_0 = e.code

# Generated at 2022-06-25 22:00:23.656123
# Unit test for function main
def test_main():
    argv = ('py-backwards', '-i', '../py_backwards/tests/test_input', '-o',
            '../py_backwards/tests/test_output', '-t', '35')
    sys.argv = argv
    test_case_0()

# Generated at 2022-06-25 22:00:26.449949
# Unit test for function main
def test_main():
    global int_0
    test_case_0()
    assert int_0 == 0 or int_0 == 1
    print('All tests were passed!')


# Generated at 2022-06-25 22:00:27.182281
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 22:00:28.000329
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:00:29.111148
# Unit test for function main
def test_main():
    test_case_0()


main()
test_main()

# Generated at 2022-06-25 22:00:38.061245
# Unit test for function main
def test_main():
    # Call main() with correct arguments
    # (args.input = Tuple[str], args.output = str, args.target = str,
    #  args.root = Optional[str], args.debug = bool)
    # Returns: None

    assert main(("/mnt/c/dev/py-backwards/tests/sources/input.py",), "/mnt/c/dev/py-backwards/tests/sources/output.py", "2.7")
    assert main(("/mnt/c/dev/py-backwards/tests/sources/input.py",), "/mnt/c/dev/py-backwards/tests/sources/output.py", "3.5")

# Generated at 2022-06-25 22:00:44.128292
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('../../compiler/tests/test_files/compile/')
    sys.argv.append('-o')
    sys.argv.append('../../compiler/tests/test_files/converted/')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    res = main()
    assert res == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:00:44.917938
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 22:00:49.450326
# Unit test for function main
def test_main():
    print('Running tests for function main')

    try:
        test_case_0()
    except BaseException as e:
        return False

    return True


if __name__ == "__main__":
    print('Testing:', __file__)
    result = test_main()
    print('Result', result)
    print('Done')

# Generated at 2022-06-25 22:03:44.804240
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:03:46.285084
# Unit test for function main
def test_main():
    print("Test case 0: ", end="")
    test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:03:47.502029
# Unit test for function main
def test_main():
    """
    @return: None
    """
    
    # Generating test cases
    test_case_0()

# Generated at 2022-06-25 22:03:51.464192
# Unit test for function main
def test_main():
    # test_case_0
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'out.py', '-t', '2.7',
                '-r', '.']
    test_case_0()

# Generated at 2022-06-25 22:03:52.122049
# Unit test for function main
def test_main():
    assert test_case_0() == 1

# Generated at 2022-06-25 22:03:57.123104
# Unit test for function main
def test_main():
    sys_argv_0 = 'python3 backport.py -i tests/resources/test.py -o tests/resources/test_new.py -t py2.7 -r tests/resources'
    sys_argv_original_0 = sys.argv
    sys.argv = sys_argv_0.split()
    test_case_0()
    sys.argv = sys_argv_original_0

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:04:05.547244
# Unit test for function main
def test_main():
    import subprocess
    from .main import main
    from . import conf
    from pathlib import Path

    out_dir = "test_output"
    Path(out_dir).mkdir(exist_ok=True)

    targets = [('26', '2.6'), ('27', '2.7'), ('33', '3.3')]

# Generated at 2022-06-25 22:04:15.863074
# Unit test for function main
def test_main():
    list_of_arguments_0 = __Pyx_GetApiFunc("helpers", "list_of_arguments")
    if ((((list_of_arguments_0 != 0) or
      ((__Pyx_check_type(list_of_arguments_0, __pyx_t_5std_vector_c__std_string_t, 0, 0, 1, 0) != 0) != 0)) != 0) != 0):
        __Pyx_Raise(PyExc_TypeError, "object of type 'std::vector<std::string>' has no len()", 0, 0);
        __PYX_ERR(0, 1, __pyx_L1_error)

# Generated at 2022-06-25 22:04:18.542258
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'input_files/input_0.py',
        '-o', 'output_files/output_0.py',
        '-t', '2.7',
    ]
    test_case_0()


# Generated at 2022-06-25 22:04:26.810763
# Unit test for function main
def test_main():
    from .compiler import compile_files
    from .conf import init_settings
    from argparse import ArgumentParser
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')