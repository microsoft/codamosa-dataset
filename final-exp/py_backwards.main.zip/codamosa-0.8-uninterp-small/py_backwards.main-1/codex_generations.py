

# Generated at 2022-06-25 21:56:44.420855
# Unit test for function main
def test_main():
    with pytest.raises(exceptions.InvalidInputOutput):
        main("/test/test_main.py", "/")


# Generated at 2022-06-25 21:56:45.350232
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:45.913526
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 21:56:47.142208
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0


# Generated at 2022-06-25 21:56:53.418362
# Unit test for function main
def test_main():
    py_3 = sys.version_info[0] == 3
    if not py_3:
        print('SKIP')
        return

    sys.argv = ['', '-i', 'test.py', '-o', 'test.py', '-t', '2.7']

    try:
        main()
    except Exception as e:
        print('Error', e)


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:56:58.286610
# Unit test for function main
def test_main():
    print('Testing for main: ', end = '')
    # Test 0
    sys.argv = ['py-backwards', '-i', 'file1.py', '-o', 'file2.py', '-t', '2.7', '-r', 'root', '-d']
    test_case_0()
    assert(int_0 == 0)
    print('Pass')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:00.247954
# Unit test for function main
def test_main():
    TESTCASE0 = 0

    if TESTCASE0:
        test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:01.219215
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:02.673393
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:57:03.540987
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 21:57:13.402400
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:14.340286
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 21:57:15.468420
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 21:57:16.578232
# Unit test for function main
def test_main():
    # Here is call of main function
    main()


# Generated at 2022-06-25 21:57:20.352025
# Unit test for function main
def test_main():
    input = ['src/py-backwards/const.py', 'src/py-backwards/compiler.py', 'src/py-backwards/messages.py']
    output = 'test'
    target = '2.7'
    root = 'src/'
    debug = False

    test_case_0()

# Generated at 2022-06-25 21:57:24.759265
# Unit test for function main
def test_main():
    sys.argv = "py-backwards -i /home/max/Studies/Fourth/academic/Semester1/compilers/tests/test_0.py -o /home/max/Studies/Fourth/academic/Semester1/compilers/tests/test_0_out.py -t python37".split(" ")
    test_case_0()

test_main()

# Generated at 2022-06-25 21:57:28.797071
# Unit test for function main
def test_main():
    with patch('sys.argv', ['', '-i', 'test/sample_test_testcase/a.py',
                            '-o', 'test/sample_test_testcase/b.py', '-t',
                            '2.7']):
        int_0 = main()
    assert(int_0 == 0)

# Generated at 2022-06-25 21:57:30.958502
# Unit test for function main
def test_main():
    assert main()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:57:40.118730
# Unit test for function main
def test_main():
    # No arguments
    from . import conf
    from .messages import user_error
    from .exceptions import UserError as e
    import sys
    import io
    import argparse
    argparse.ArgumentParser = lambda *args, **kwargs: e
    save_stderr = sys.stderr
    sys.stderr = io.StringIO()
    try:
        int_0 = main()
        str_0 = sys.stderr.getvalue()
    finally:
        sys.stderr = save_stderr
    # AssertionError:
    assert not str_0
    # AssertionError:
    assert not int_0
    # Missing argument compiles
    from . import conf
    from .messages import user_error
    from .exceptions import UserError as e

# Generated at 2022-06-25 21:57:42.375923
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:58:06.181207
# Unit test for function main
def test_main():
    
    import pytest
    import sys
    import io

    capturedOutput = io.StringIO()          # Create StringIO object
    sys.stdout = capturedOutput                    

    test_case_0()
    
    sys.stdout = sys.__stdout__                   # Reset redirect.
    assert capturedOutput.getvalue() == "Compilation result:\nNumber of processed files: 4\nNumber of errors: 0\n"


# Generated at 2022-06-25 21:58:08.133614
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-25 21:58:09.387486
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:17.602285
# Unit test for function main
def test_main():
    assert callable(main)
    # Test 0 - execution
    if os.getcwd().endswith('pybackwards'):
        os.chdir(os.path.join(os.pardir, os.pardir))
    sys.argv = ['pybackwards', 'test', '-i', 'test/data/inputs', '-o',
                'test/data/outputs', '-t', 'py36', '-r', '.']
    test_case_0()
    # Test 1 - execution
    if os.getcwd().endswith('pybackwards'):
        os.chdir(os.path.join(os.pardir, os.pardir))

# Generated at 2022-06-25 21:58:22.235991
# Unit test for function main
def test_main():
    test_cases = [
        ('', '', '', '', '')
    ]
    for args0, args1, args2, args3, args4 in test_cases:
        assert main(args0, args1, args2, args3, args4) == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:58:23.530184
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0

# Generated at 2022-06-25 21:58:32.856666
# Unit test for function main
def test_main():
    """
    Output of main() is the same as the output of compiled file
    """
    from subprocess import check_output
    from random import randint
    from .conf import settings
    from . import const, messages
    import os
    import sys

    # Generate a random name
    while True:
        rand_name = str(randint(1, 100000))
        rand_path = os.path.join(os.getcwd(), rand_name)
        if not os.path.exists(rand_path):
            break

    # Generate a random string inside the file
    random_string = ''.join(chr(randint(97, 122)) for _ in range(randint(1, 100)))

    # Create and write the test file

# Generated at 2022-06-25 21:58:34.286253
# Unit test for function main
def test_main():
    test_case_0()

Main = main

if __name__ == '__main__':
    Main()

# Generated at 2022-06-25 21:58:34.892179
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:36.232624
# Unit test for function main
def test_main():
    assert test_case_0() == 0


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:59:22.711149
# Unit test for function main
def test_main():
    # Tests that the CLI works correctly

    import subprocess

    proc = subprocess.Popen(['py-backwards', '--help'],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    out = proc.communicate()[0]
    out = out.decode('UTF-8')
    assert 'input file or folder' in out

    proc = subprocess.Popen(['py-backwards', '--input', 'test_cases/test_1.py',
                            '--output', 'test_out', '--target', '3.5',
                            '-d', '--root', 'test_cases'],
                             stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT)

# Generated at 2022-06-25 21:59:24.277429
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:26.843735
# Unit test for function main
def test_main():
    import sys
    import io

    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    test_case_0()
    sys.stdout = sys.__stdout__

    print(capturedOutput.getvalue())

# Generated at 2022-06-25 21:59:27.907723
# Unit test for function main
def test_main():
    int_1 = main()
    assert int_1 == 0


# Generated at 2022-06-25 21:59:32.276622
# Unit test for function main
def test_main():
    init_settings(['-i', 'tests/hello_world.py', '-o', './', '-t', '3.6', '-d'])

    assert compile_files('./tests/hello_world.py', './',
                         const.TARGETS['3.6']) == ('tests/hello_world.py', 1,
                                                   0, 0)

# Generated at 2022-06-25 21:59:34.075965
# Unit test for function main
def test_main():
    # Test #0
    int_0 = test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:59:41.546346
# Unit test for function main
def test_main():
    test_case_main_0()
    test_case_main_1()
    test_case_main_2()
    test_case_main_3()
    test_case_main_4()
    test_case_main_5()
    test_case_main_6()
    test_case_main_7()
    test_case_main_8()
    test_case_main_9()
    test_case_main_10()
    test_case_main_11()
    test_case_main_12()

# Positive test cases for function main

# Generated at 2022-06-25 21:59:46.105126
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], "-i", "test/compiler/compiler_test_0.py", "-o", "tmp/compiler_test_0.py", "-t", "2.7", "-d"]
    test_case_0()
    assert True

test_main()

# Generated at 2022-06-25 21:59:46.933724
# Unit test for function main
def test_main():
    assert main() == 0;

# Generated at 2022-06-25 21:59:52.203175
# Unit test for function main
def test_main():
    input_ = ['/home/travis/build/amozhon/py-backwards/tests/fixtures_test/test_module_file.py',
              '/home/travis/build/amozhon/py-backwards/tests/fixtures_test/test_module_file_2.py']
    output = '/home/travis/build/amozhon/py-backwards/tests/output_test'
    target = 'py27'
    debug = True
    main(input_, output, target, debug)

# Generated at 2022-06-25 22:01:20.892994
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:01:26.294722
# Unit test for function main
def test_main():
    if sys.platform != "win32":
        assert main() == 0
        assert main(['-h']) == 0
    assert main(['-i', './py-backwards', '-o', './py-backwards/tests/test.py', '-t', '3.6']) == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:01:27.396007
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:01:37.595239
# Unit test for function main
def test_main():
    # Set up mock input and capture output
    sys.argv = ['py-backwards', 'tests/fixtures/input0.py', '-o', 'output',
                '-t', '2.7']
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    # Call main
    test_case_0()
    # Check if output is correct
    sys.stdout = sys.__stdout__
    assert capturedOutput.getvalue() == 'Successfully compiled.\n' + messages.compilation_result([[[['tests/fixtures/input0.py'], ['output/tests/fixtures/input0.py']]]])

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 22:01:39.937477
# Unit test for function main
def test_main():
    log = LogCapture()
    with log:
        test_case_0()
    log.check(
        ('root', 'ERROR', 'invalid_output'),
    )

# Generated at 2022-06-25 22:01:51.729068
# Unit test for function main
def test_main():
    import mock
    import argparse
    parser = argparse.ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')


# Generated at 2022-06-25 22:02:01.060973
# Unit test for function main
def test_main():
    main()
    main(['-i', 'file', 'file', '-o', 'file', '-t', 'PY38', '-r', 'file'])
    main(['-i', 'file', 'file', '-o', 'file', '-t', 'PY38', '-r', 'file', '-d', '--debug'])
    # TODO: add test for raised exception

# Generated at 2022-06-25 22:02:09.684910
# Unit test for function main
def test_main():
    import sys, os
    import inspect
    current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parent_dir = os.path.dirname(current_dir)
    sys.path.insert(0, parent_dir)
    from pybackwards.compiler import compile_files, init_settings
    from pybackwards.utils import get_settings
    from pybackwards.exceptions import CompilationError
    from pybackwards.utils import is_local_file, is_remote_file, is_package
    from pybackwards.const import TARGETS

    #
    # SITUATION 1:
    # local folder
    # local folder
    t = 'pybackwards/tests/resources/py3.6_functions'

# Generated at 2022-06-25 22:02:14.293362
# Unit test for function main
def test_main():
    in_argv = sys.argv
    sys.argv = ["py-backwards.py", "-i", "test_data\\test0.py", "-o", "test_data\\output", "-t", "3.5", "-r", "test_data\\src"]
    test_case_0()
    sys.argv = in_argv

# Generated at 2022-06-25 22:02:22.231942
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 22:05:42.111234
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:05:46.195636
# Unit test for function main
def test_main():
    # create user defined exception
    class InputException(Exception): pass
    # set expected value
    expected = 0
    # get actual value
    try:
        main()
    # in case exception happens, return exception value
    except InputException as ex:
        actual = ex
    except:
        actual = 1
    else:
        actual = 0

    assert expected == actual
    

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 22:05:46.617865
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:05:49.442755
# Unit test for function main
def test_main():
    # Test case 0
    # function main
    # test with parameters:
    # "py-backwards.py", "--target", "python2.7", "examples/test.py", "-o", "test.py"
    # Expected result:
    # -
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:05:56.791724
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 22:05:57.399111
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:06:00.560267
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/tests/test_package', '-o', 'tests/output',
                '-t', 'python2.7', '-d']
    main()
    

# Generated at 2022-06-25 22:06:01.578541
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 22:06:03.856220
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:06:05.412537
# Unit test for function main
def test_main():
    stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')
    main()
    sys.stdout = stdout