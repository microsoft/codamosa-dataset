

# Generated at 2022-06-25 21:56:45.437070
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


# Program entry point
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:56:46.335560
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:47.225983
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:48.107360
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:49.455340
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:56:50.662116
# Unit test for function main
def test_main():
    int_0 = main()

# Generated at 2022-06-25 21:56:52.595981
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-25 21:56:59.252195
# Unit test for function main
def test_main():
    try:
        good_0 = sys.argv
        sys.argv = [
            'py-backwards',
            '-i',
            './test/test_files/syntax/multiple_stmts_annotations.py',
            '-o',
            './test/test_files/syntax/',
            '-r',
            './test/test_files/syntax',
            '-t',
            '3.5'
            ]
        test_case_0()
    except Exception:
        print('FAILURE')
    else:
        print('SUCCESS')
    finally:
        sys.argv = good_0



# Generated at 2022-06-25 21:57:01.449157
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Failed during test initialization")
        raise

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:10.807900
# Unit test for function main
def test_main():
    print('Testing function main...', end='')
    from argparse import ArgumentParser
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')

# Generated at 2022-06-25 21:57:29.965796
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as e:
        test_case_0()
    assert e.type == SystemExit

# Generated at 2022-06-25 21:57:33.958198
# Unit test for function main
def test_main():
    main()

# Name: __main__
# Arguments: 3
# Arg names: ['--input', './src/test1/__main__.py', '--output', 'output.py']
# Arg types: ['str', 'str', 'str', 'str']
# Return type: int
# Return value: 0

# Generated at 2022-06-25 21:57:35.112244
# Unit test for function main
def test_main():
    test_case_0()

# Run tests for function main
test_main()

# Generated at 2022-06-25 21:57:37.158262
# Unit test for function main
def test_main():
    # 0
    test_case_0()


if __name__ == '__main__':
    print('test_main')
    test_main()

# Generated at 2022-06-25 21:57:37.662956
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:57:38.954372
# Unit test for function main
def test_main():
    test_case_0()

# Compiles Python code to Python 3.6

# Generated at 2022-06-25 21:57:39.834007
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:49.127587
# Unit test for function main
def test_main():
    # Store the original command-line arguments, then clear them.
    orig_sys_argv = sys.argv  # type: List[str]
    sys.argv = []

    orig_stderr = sys.stderr  # type: TextIO
    sys.stderr = io.StringIO()

    #
    # Test case 0:
    sys.argv.append('py-backwards')
    sys.argv.append('-i')
    sys.argv.append('in/')
    sys.argv.append('-o')
    sys.argv.append('_test/out/')
    sys.argv.append('-t')
    sys.argv.append('python35')
    test_case_0()

    #
    # Report test results
    passed = sys.stder

# Generated at 2022-06-25 21:57:52.744788
# Unit test for function main
def test_main():
    # Create a mock object for sys.argv
    sys.argv = ['py-backwards', '-i', 'test_files/test_files_0/',
                '-o', 'test_files/test_files_out/', '-t', '2.7',
                '-r', 'pbb_test_files']
    test_case_0()

# Generated at 2022-06-25 21:57:57.407715
# Unit test for function main
def test_main():
    print ("\n*** Testing function main() ***\n")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()


# Generated at 2022-06-25 21:58:41.233783
# Unit test for function main
def test_main():
    import pytest
    class Test(object):
        @staticmethod
        def main_helper(input_, output, target, root, debug):
            return main(input_, output, target, root, debug)
    test = Test()
    with pytest.raises(TypeError):
        test.main_helper(['a', 'b'], 'c', 'd', 'e', True)
    with pytest.raises(TypeError):
        test.main_helper(['a', 'b'], 'c', 'd', 'e', False)
    with pytest.raises(TypeError):
        test.main_helper(['a', 'b'], 'c', 'd', 'e', 'f')
    try:
        main()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-25 21:58:43.441631
# Unit test for function main
def test_main():
    int_0 = main()
    assert(int_0 == 0)

# Unit tests for main

# Generated at 2022-06-25 21:58:48.699250
# Unit test for function main
def test_main():
    # Run main in a thread to make sure that it doesn't hang.
    thread = threading.Thread(target=test_case_0)
    thread.start()
    thread.join(timeout=5)

    # Check that the output is valid.
    assert int_0 == 0
if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:58:49.512442
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:53.199160
# Unit test for function main
def test_main():
    assert test_case_0() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:58:54.147662
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:54.993542
# Unit test for function main
def test_main():
    assert main() == 0

test_main()

# Generated at 2022-06-25 21:58:56.106224
# Unit test for function main
def test_main():
    assert(int_0 == 0)

# Generated at 2022-06-25 21:58:57.596705
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('Test case 0 failed')

# Generated at 2022-06-25 21:58:58.303042
# Unit test for function main
def test_main():
    int_0 = main()

# Generated at 2022-06-25 21:59:37.735135
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:47.428829
# Unit test for function main

# Generated at 2022-06-25 21:59:48.531161
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0

# Generated at 2022-06-25 21:59:49.324562
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:50.162435
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:51.228295
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:52.665643
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Test 0 failed")

# Generated at 2022-06-25 21:59:53.173759
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:00:03.188576
# Unit test for function main
def test_main():
    primes_list = []
    primes_list.append((0, 0))
    for i in range(1, len(primes_list)):
        assert main(primes_list[i][0]) == primes_list[i][1]
        print('Test Passed!')

    primes_list.append((2, 2))
    for i in range(1, len(primes_list)):
        assert main(primes_list[i][0]) == primes_list[i][1]
        print('Test Passed!')

    primes_list.append((3, 3))
    for i in range(1, len(primes_list)):
        assert main(primes_list[i][0]) == primes_list[i][1]
        print('Test Passed!')

    primes_list

# Generated at 2022-06-25 22:00:04.255527
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 22:01:38.388861
# Unit test for function main
def test_main():
    # inputs
    input = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
    for key in sys.argv:
        if key == "-t":
            if sys.argv[key+1] == "2.7":
                sys.argv[key+1] = const.TARGETS["2.7"]
            if sys.argv[key+1] == "3.6":
                sys.argv[key+1] = const.TARGETS["3.6"]
            if sys.argv[key+1] == "3.7":
                sys.argv[key+1] = const.TARGETS["3.7"]

# Generated at 2022-06-25 22:01:39.357487
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 22:01:40.169396
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:01:40.661826
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:01:52.488078
# Unit test for function main
def test_main():
    test0_0= 'test0_0'
    parser = mock.MagicMock()
    parser.parse_args = mock.MagicMock(return_value=parser)
    parser.input = test0_0
    parser.output = test0_0
    parser.target = test0_0
    parser.root = test0_0
    parser.debug = test0_0

# Generated at 2022-06-25 22:01:59.913128
# Unit test for function main
def test_main():
    print('Test case #0:')
    test_case_0()
    print('Test case #1:')
    test_case_1()
    print('Test case #2:')
    test_case_2()
    print('Test case #3:')
    test_case_3()


# Generated at 2022-06-25 22:02:01.636823
# Unit test for function main
def test_main():
    try:
        for i in range(1000):
            test_case_0()
    except:
        assert False

# Generated at 2022-06-25 22:02:02.718896
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0

# Generated at 2022-06-25 22:02:03.501296
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:02:04.794486
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:05:22.694543
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:05:24.839756
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:05:26.086330
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:05:27.873322
# Unit test for function main
def test_main():
    # @TODO(alvaro.urbina): add test code
    assert True



# Generated at 2022-06-25 22:05:28.589562
# Unit test for function main
def test_main():
    int_0 = main()

# Generated at 2022-06-25 22:05:29.886352
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:05:30.578348
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:31.701219
# Unit test for function main
def test_main():
    test_case_0()



if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:05:32.828200
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:33.269620
# Unit test for function main
def test_main():
    assert main() == 1