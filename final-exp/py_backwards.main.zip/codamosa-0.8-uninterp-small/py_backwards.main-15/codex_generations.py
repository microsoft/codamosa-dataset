

# Generated at 2022-06-25 21:56:37.087609
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:37.805695
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:39.068507
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:56:44.287579
# Unit test for function main
def test_main():
    const.DEBUG = True
    const.VERBOSE_DEBUG = True
    assert main() == 0
    # assert test_case_0() == 0
    assert main() == 0
    assert main() == 0
    print("Successfully tested main()!")

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:56:51.521212
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i',
        'test_files/functions.py',
        '-o',
        'test_files/output.py',
        '-t',
        '3.4',
        '-r',
        'test_files',
        '-d']

    test_case_0()
    sys.argv = sys.argv[:-1]
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:56:55.569089
# Unit test for function main
def test_main():
    arguments = ['py-backwards', '-i', 'test/basic_test_case/', '-o',
                 'test/basic_test_case_output', '-t', 'python2.7']
    sys.argv = arguments
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:00.988195
# Unit test for function main
def test_main():
    print("test_main")
    print("Function: main")
    import os
    import sys
    try:
      test_case_0()
    except:
        exc_type, exc_value, exc_tb = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_tb)



# Generated at 2022-06-25 21:57:04.612868
# Unit test for function main
def test_main():
    import io
    import sys

    capturedOutput = io.StringIO()                # Create StringIO object
    sys.stdout = capturedOutput                   #  and redirect stdout.
    main()
    sys.stdout = sys.__stdout__                   # Reset redirect.
    assert(capturedOutput.getvalue() == 'Using 3.7.4\n')

# Generated at 2022-06-25 21:57:06.154455
# Unit test for function main
def test_main():
    int_0 = main()

# Generated at 2022-06-25 21:57:11.624199
# Unit test for function main
def test_main():
    # Confirmed target 3.2
    sys.argv[:] = [sys.argv[0], "-i", "./test/input/simple/main.py",
                   "-o", "./test/output/main_3.2.py", "-t", "3.2", "-r", "./test/input"]

    # Expected result == 0
    assert main() == 0

    # We need to manually stop if we want to look at the compilation result
    sys.exit(0)

# Generated at 2022-06-25 21:57:30.964372
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:31.513193
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:57:32.898162
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()


# Unit test section

# Generated at 2022-06-25 21:57:34.000280
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:41.740365
# Unit test for function main
def test_main():
    import unittest
    import StringIO
    import sys

    class TestMain(unittest.TestCase):

        def _my_main(self, arguments):
            sys.stdout = StringIO.StringIO()
            sys.argv = arguments
            int_0 = main()
            sys.stdout.seek(0)

        def test_main(self):
            arguments = ['py-backwards', '-i', 'examples', '-o', 'output', '-t', 'python2', '-d']
            self._my_main(arguments)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:42.612373
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 21:57:45.127855
# Unit test for function main
def test_main():
    # If a file is not in the folder, CompilationError exception
    # is thrown
    assert raises(exceptions.CompilationError, test_case_0)

# Generated at 2022-06-25 21:57:52.488072
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 21:57:54.312929
# Unit test for function main
def test_main():
    # Create a play
    file_play = "play.py"

# Generated at 2022-06-25 21:57:55.705537
# Unit test for function main
def test_main():
    int_0 = main()
    assert type(int_0) is int


# Generated at 2022-06-25 21:58:13.986112
# Unit test for function main
def test_main():
    return main() == 0

# Generated at 2022-06-25 21:58:17.118752
# Unit test for function main
def test_main():
    try:
        # Empty args
        sys.argv[:] = ['']
        # Throws SystemExit(2)
        main()
    except SystemExit as e:
        assert e.code == 2


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:58:21.056408
# Unit test for function main
def test_main():
    # test case 0
    sys.argv = [
        'py-backwards', '-i', 'test', '-o', 'result', '-t', 'python36', '-r', 'test'
    ]
    test_case_0()
    assert True

# Generated at 2022-06-25 21:58:21.600156
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:58:23.547444
# Unit test for function main
def test_main():
    with CaptureOutput() as output:
        main()

    assert output.get_text() == "Successfully compiled 1 files"



# Generated at 2022-06-25 21:58:26.077815
# Unit test for function main
def test_main():
    with patch('sys.stdout', new=StringIO()) as fake_out:
        test_case_0()
        assert fake_out.getvalue() == 'test_case_0\n'

# Generated at 2022-06-25 21:58:30.734920
# Unit test for function main
def test_main():
    # Create a io.StringIO object for captured output
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    # Call the function main
    main()
    sys.stdout = sys.__stdout__
    # Check if output is correct
    assert capturedOutput.getvalue() == test_case_0()

# Generated at 2022-06-25 21:58:38.175470
# Unit test for function main
def test_main():

    import sys
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    # Case 1, input has wrong format
    with captured_output() as (outputs, errors):
        test_case_0()
        test_out = outputs.getvalue().strip()
        test_err = errors.getvalue().strip()

# Generated at 2022-06-25 21:58:39.380320
# Unit test for function main
def test_main():
    print("Test main")
    test_case_0()


# Generated at 2022-06-25 21:58:40.914774
# Unit test for function main
def test_main():
    assert 1 == main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:59:20.962603
# Unit test for function main
def test_main():
    int_arg = sys.argv
    sys.argv = ['']
    result = main()
    assert result == 0
    sys.argv = int_arg



# Generated at 2022-06-25 21:59:27.871804
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    args = parser.parse_args(["-i","dfg","-o","dfg","-t","2.7","-r","dfg","-d"])
    assert args.input == "dfg"
    assert args.output == "dfg"
    assert args.target == "2.7"
    assert args.root == "dfg"
    assert args.debug == True

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:59:28.886229
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:59:29.726670
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 21:59:32.956488
# Unit test for function main
def test_main():
    test_0 = ['..\\py_backwards\\samples\\src', '..\\compile_out\\', '3.5', '..\\py_backwards\\samples\\src']
    sys.argv[1:] = test_0
    main()


test_main()

# Generated at 2022-06-25 21:59:35.082838
# Unit test for function main
def test_main():
    try:
        test_case_0()
        assert False
    except SystemExit:
        assert True


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:59:40.186035
# Unit test for function main
def test_main():
    file_name = __file__
    # Test case 0
    input_0 = main()
    output_0 = main()

    # Test case 1
    input_1 = main()
    output_1 = main()

    # Test case 2
    input_2 = main()
    output_2 = main()


# Run all unit tests

# Generated at 2022-06-25 21:59:49.513195
# Unit test for function main
def test_main():
    print("\nTesting main with sys.argv[1] == ")
    sys.argv.append("-h")
    test_case_0()
    sys.argv.pop()
    sys.argv.append("-i")
    sys.argv.append("test_input.py")
    sys.argv.append("-o")
    sys.argv.append("test_input.out.py")
    sys.argv.append("-t")
    sys.argv.append("3.5")
    sys.argv.append("-d")
    test_case_0()
    sys.argv.pop(2)
    sys.argv.pop(2)
    sys.argv.append("-o")
    sys.argv.append("test_input.out.py")

# Generated at 2022-06-25 21:59:50.045487
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 21:59:51.084562
# Unit test for function main
def test_main():
    int_1 = main()


# Generated at 2022-06-25 22:00:42.783434
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        if e.code != 0:
            print("py-backwards exited with code: {}".format(e.code))
            print("Unit test failed, exiting.")
            sys.exit(1)
        else:
            print("Unit test passed.")
            sys.exit(0)
    print("py-backwards returned without exit, exiting.")
    sys.exit(1)

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:00:44.056240
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:00:47.090258
# Unit test for function main
def test_main():
    from pytest import raises, fail

    with raises(Exception) as excinfo:
        main()

    if str(excinfo.value) != "the following arguments are required: -i/--input, -o/--output, -t/--target":
        fail('Return not 0, as expected')

# Generated at 2022-06-25 22:00:55.680974
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_cases/test_case_0/input_0.py', '-o', 'tests/test_cases/test_case_0/output_0.py', '-t', 'python_3_5', '-r']
    test_case_0()
    sys.argv = ['py-backwards', '-i', 'tests/test_cases/test_case_0/input_1.py', '-o', 'tests/test_cases/test_case_0/output_1.py', '-t', 'python_3_5', '-r']
    test_case_0()

# Generated at 2022-06-25 22:00:56.406923
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 22:00:57.242461
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 22:00:58.086664
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:00:59.627931
# Unit test for function main
def test_main():
    assert main() is not None, "Variable returns None"
    test_case_0()

# Generated at 2022-06-25 22:01:01.002221
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:01:13.811122
# Unit test for function main

# Generated at 2022-06-25 22:02:33.676934
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:02:36.152044
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception:
        print('Exception')
        assert False

# Generated at 2022-06-25 22:02:37.755469
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-25 22:02:38.610005
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 22:02:43.509540
# Unit test for function main
def test_main():
    import time

    with open('log.txt', 'a') as f:
        f.write('\n\n')
        f.write(time.strftime('%H:%M:%S'))
        f.write('\n')
        f.write('test_main')
        f.write('\n')
        f.write('==========')
        f.write('\n')

    def test_case_0():
        try:
            int_0 = main()
        except SystemExit:
            pass

    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:02:49.911511
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 22:02:51.827541
# Unit test for function main
def test_main():
    print("Unit test for main")
    test_case_0()
    print("End of unit test for main")
    print()

# Generated at 2022-06-25 22:02:53.259239
# Unit test for function main
def test_main():
    return int_0


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 22:02:55.288221
# Unit test for function main
def test_main():
    '''
    Basic unit test for main
    '''
    test_case_0()

if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-25 22:02:57.410939
# Unit test for function main
def test_main():
    print('Testing function main ...', end='')
    test_case_0()
    print(' done')


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:06:10.009938
# Unit test for function main
def test_main():
    int_0 = main()

# Generated at 2022-06-25 22:06:10.816423
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 22:06:12.966026
# Unit test for function main
def test_main():
    # Test case 0
    print('Running Test Case 0...')
    test_case_0()
    print('Test Case 0 Passed')


if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-25 22:06:17.473937
# Unit test for function main
def test_main():
    # Test case 0
    # We do not put any arguments on the command line, so that 
    # we expect to get an error message "error: the following
    # arguments are required: -i/--input, -o/--output, -t/--target"
    with pytest.raises(SystemExit) as excinfo:
        main()
        print(excinfo.value)
        int_0 = excinfo.value.code
        assert int_0 == 2

# Generated at 2022-06-25 22:06:17.865528
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 22:06:18.467260
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:06:18.861385
# Unit test for function main
def test_main():
    assert 0 == main()

# Generated at 2022-06-25 22:06:20.091459
# Unit test for function main
def test_main():
    try:
        int = main()
    except SystemExit as e:
        int = e.code
    assert int is 0

# Generated at 2022-06-25 22:06:26.022409
# Unit test for function main
def test_main():
    input = ['test/test0.py']
    output = 'out.py'
    root = 'test'
    target = 'python2.7'

    try:
        result = compile_files(input, output, const.TARGETS[target], root)
        print(result)

    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)

    except exceptions.TransformationError as e:
        print(messages.transformation_error(e), file=sys.stderr)

    except exceptions.InputDoesntExists:
        print(messages.input_doesnt_exists(input), file=sys.stderr)
