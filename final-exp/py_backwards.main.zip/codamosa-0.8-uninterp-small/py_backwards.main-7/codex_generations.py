

# Generated at 2022-06-25 21:56:37.982285
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:38.638382
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:39.744601
# Unit test for function main
def test_main():
    x = main()


# Generated at 2022-06-25 21:56:40.538176
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:41.614698
# Unit test for function main
def test_main():
    int_0 = main()

    assert(int_0 == 0)

# Generated at 2022-06-25 21:56:42.190640
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:56:44.956157
# Unit test for function main
def test_main():
    # test_case_0()
    pass


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:56:45.527261
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 21:56:46.760612
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()


# Generated at 2022-06-25 21:56:47.980674
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0

# Generated at 2022-06-25 21:57:01.697273
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "./examples/source/example.py", "-o", "./examples/compiled/example.py", "-t", "2.7", "-d"]
    test_case = [0]
    for i in test_case:
        try:
            test_case_0()
        except Exception as e:
            print(e)
            return False
    return True

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:03.802550
# Unit test for function main
def test_main():
    test_case_0()
# noinspection PyUnresolvedReferences
import py_backwards

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:09.286611
# Unit test for function main
def test_main():
    # Set up the system state
    sys.argv = ["py-backwards", "-i", "test/fixtures/input/", "-o", "test/fixtures/output/", "-t", "2.7", "-r", "test/fixtures/root"]
    # Test the function
    test_case_0()

# Main program
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:57:10.090115
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:18.832003
# Unit test for function main
def test_main():
    args = ArgumentParser('py-backwards')
    args.add_argument('--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    args.add_argument('--output', type=str, required=True,
                        help='output file or folder')
    args.add_argument('--target', type=str, required=True,
                        help='target python version')
    args.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    args.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')

# Generated at 2022-06-25 21:57:21.865063
# Unit test for function main
def test_main():
    with patch("sys.argv", ["py-backwards", "-i", "tests/", "-o", "tmp/", "-t",
                            "2.7", "-d", "True"]):
        test_case_0()

# Generated at 2022-06-25 21:57:24.351208
# Unit test for function main
def test_main():
    try:
        from . import settings
    except ImportError:
        pass
    settings = None


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:25.886583
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:26.985569
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:28.468858
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:53.040976
# Unit test for function main
def test_main():
    import sys
    from io import StringIO
    from unittest.mock import patch
    sys.argv = ['py-backwards', '-i', '/some/input/somefile.py',
                '-o', '/some/output/somefile.py', '-t', '3.5', '-r',
                '/some/source/root/']
    with patch.object(sys, 'stdout', new=StringIO()) as fake_out:
        main()
        assert fake_out.getvalue() == 'Compilation successful\n'

# Generated at 2022-06-25 21:57:54.312149
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:55.705077
# Unit test for function main
def test_main():
    print("test_main:", end="\n\n")
    test_case_0()
    return True

# Generated at 2022-06-25 21:58:02.057613
# Unit test for function main
def test_main():
    import os

    project_root = os.path.dirname(__file__)
    test_dir = os.path.join(project_root, 'tests')
    tests_dir = os.path.join(test_dir, 'test_files')
    results_dir = os.path.join(test_dir, 'results')
    sys.argv = ['py_backwards.py', '-i', tests_dir, '-o', results_dir, '-t',
                'python2', '-r', test_dir]
    main()

# Generated at 2022-06-25 21:58:03.514860
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:58:05.619915
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except AssertionError:
        raise AssertionError("Expected value: 0. Actual value: 1")

# Generated at 2022-06-25 21:58:09.924382
# Unit test for function main
def test_main():
    args = ['-i', 'test/test_dir', '-o', 'test/test_dir', '-t', '2.7',
            '-r', 'test/']
    sys.argv = ['py-backwards'] + args
    int_0 = main()


# Generated at 2022-06-25 21:58:18.370348
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 21:58:20.045856
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:24.616657
# Unit test for function main
def test_main():
    with patch('sys.argv', ['py-backwards', '-i', 'py_backwards/tests/data/tests_compile/test_0.py',
                            '-o', 'py_backwards/tests/data/tests_compile/test_0', '-t', '2.7']):
        test_case_0()

# Generated at 2022-06-25 21:59:03.658712
# Unit test for function main
def test_main():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False
    except:
        assert False

# Call if executed as standalone
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:59:05.011276
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    exit(main())

# EOF

# Generated at 2022-06-25 21:59:09.578229
# Unit test for function main
def test_main():

    print(chr(27) + "[2J")

    return 0

# Generated at 2022-06-25 21:59:10.856018
# Unit test for function main
def test_main():
    test_case_0()
    # Insert here additional test code

# Generated at 2022-06-25 21:59:15.656855
# Unit test for function main
def test_main():
    test_case_message = "Unit test case for function main"
    print_test_message_separator()
    print_test_message(test_case_message)
    print_test_message_separator()

    print_test_message(test_case_message)
    test_case_0()

# Program entrance
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:59:24.781543
# Unit test for function main
def test_main():
    import sys
    import io
    import contextlib

    args = ['py-backwards', '-i', '/home/kamil/PycharmProjects/py-backwards/tests/resources/arguments_test.py', '-o', '/home/kamil/PycharmProjects/py-backwards/tests/resources/output/test_a.py', '-t', '2.7', '-r', '/home/kamil/PycharmProjects/py-backwards', '-d']
    sys.argv = args

    captured_output = io.StringIO()
    with contextlib.redirect_stdout(captured_output):
        temp_0 = main()

    assert captured_output.getvalue() == 'Compilation result:\nSuccess: 1\nFailed: 0\n\n'

# Generated at 2022-06-25 21:59:31.441425
# Unit test for function main
def test_main():
    opts = {
      "output": "build/output/",
      "input": [
        "../tests/unit/test_cases/test_case_0.py"
      ],
      "target": "python36",
      "root": "../tests/unit/test_cases"
    }

    sys.argv = [sys.argv[0]]
    sys.argv.append("-o")
    sys.argv.append(opts["output"])
    sys.argv.append("-i")
    sys.argv.append(opts["input"][0])
    sys.argv.append("-t")
    sys.argv.append(opts["target"])
    sys.argv.append("-r")
    sys.argv.append(opts["root"])

# Generated at 2022-06-25 21:59:41.177732
# Unit test for function main
def test_main():
    test_case_0()
    # Test case 1
    a = ['-i', 'input.py', '-o', 'output.py', '-t', '2.6', '-r', '/home/path', '-d']
    parser = ArgumentParser(description='Python to python compiler that allows you to use some Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True, help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True, help='output file or folder')
    parser.add_argument('-t', '--target', type=str, required=True, choices=const.TARGETS.keys(), help='target python version')

# Generated at 2022-06-25 21:59:45.750659
# Unit test for function main
def test_main():
    with patch.object(sys, 'argv', ['py-backwards.py', '-t', '2.7', '-i', '/home/karkaros/Downloads/ko-examples', '-o', '/home/karkaros/Downloads/ko-examples']):
        test_case_0()

# Generated at 2022-06-25 21:59:47.809879
# Unit test for function main
def test_main():
    with open('tests/compiler/test_files_compiler_0.py', 'r') as f:
        data = f.read()
    assert data == '\n'

# Generated at 2022-06-25 22:01:15.264793
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:01:16.066265
# Unit test for function main
def test_main():
    int_0 = main()



# Generated at 2022-06-25 22:01:16.881812
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 22:01:23.432887
# Unit test for function main
def test_main():
    # All the tests that we have for function main
    test_cases = [
        test_case_0,
    ]

    for test in test_cases:
        test()

if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-25 22:01:24.267441
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 22:01:25.809286
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:01:29.449074
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', ['py-backwards', '-i', 'input.py', '-o',
                                 'output.py', '-t', '2.7', '-r', 'root']):
        int_0 = main()
        assert int_0 == 0


# Generated at 2022-06-25 22:01:39.359027
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')

# Generated at 2022-06-25 22:01:45.146182
# Unit test for function main
def test_main():
    args = ['--input=compiler/py_backwards/__init__.py', '--output=compiler/stage', '--target=2.7']
    global args
    int_ret_devnull = main()
    assert int_ret_devnull == 0

# Generated at 2022-06-25 22:01:48.814567
# Unit test for function main
def test_main():
    # Test case 0
    try:
        test_case_0()
    except SystemExit as e:
        if e.code == 1:
            # Expected
            pass
        else:
            # Unexpected
            assert False
    except:
        # Unexpected
        assert False
    # Expected

# Generated at 2022-06-25 22:05:03.369036
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-25 22:05:04.257358
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:05.710627
# Unit test for function main
def test_main():
    assert test_case_0() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 22:05:06.486927
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 22:05:08.117243
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 22:05:17.522106
# Unit test for function main
def test_main():
    # assign value to args
    args = get_args()
    
    # assign value to result
    try:
        result = compile_files(args.input, args.output, const.TARGETS[args.target], args.root)
    except exceptions.CompilationError:
        result = -1
    except exceptions.TransformationError:
        result = -1
    except exceptions.InputDoesntExists:
        result = -1
    except exceptions.InvalidInputOutput:
        result = -1
    except PermissionError:
        result = -1

    # Check result
    assert result >= 0


# Generated at 2022-06-25 22:05:18.715902
# Unit test for function main
def test_main():
    print("Testing main")
    test_case_0()
    print("Done.\n")


# Generated at 2022-06-25 22:05:19.909020
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 22:05:29.538492
# Unit test for function main

# Generated at 2022-06-25 22:05:30.697799
# Unit test for function main
def test_main():
    int_0 = main()
    print("test_main: ", int_0)
