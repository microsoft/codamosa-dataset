

# Generated at 2022-06-25 21:56:35.628590
# Unit test for function main
def test_main():
    assert main() == 0, 'Test Failed'

# Generated at 2022-06-25 21:56:37.228560
# Unit test for function main
def test_main():
    # Test with an invalid number of arguments
    int_0 = main()
    assert(int_0 == 1)


# Generated at 2022-06-25 21:56:38.185874
# Unit test for function main
def test_main():
    # Unit test for function main
    from . import main
    main.main()

# Generated at 2022-06-25 21:56:39.197662
# Unit test for function main
def test_main():
    test_case_0()


# Main function entry point

# Generated at 2022-06-25 21:56:44.640371
# Unit test for function main
def test_main():
    args = ["-i", "A.py", "-o", "A.py_bak", "-t", "2.7"]

    if os.path.exists(args[3]):
        os.remove(args[3])

    main()
    assert os.path.exists('A.py_bak')
    os.remove('A.py_bak')

# Generated at 2022-06-25 21:56:45.570174
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:52.425225
# Unit test for function main
def test_main():
    # UNIT TEST FOR FUNCTION main

    # Try to run the code
    try:
        main()
    # If a SystemExit exception is thrown
    except SystemExit:
        # If the code exited with a success code
        if sys.exc_info()[0].code == 0:
            # Unit test passed
            assert True
        # Else
        else:
            # Unit test failed
            assert False
    # If another exception is thrown
    except:
        # Unit test failed
        assert False

# Generated at 2022-06-25 21:57:01.118477
# Unit test for function main
def test_main():
    # Define a list of inputs
    inputs = list()
    inputs.append([[sys.argv[0], '-i', './test_data', '-o', './test_output', '-t', '27', '-r', './test_data']])
    inputs.append([[sys.argv[0], '-i', './test_data', '-o', './test_output', '-t', '27', '-r', './test_data', '-d']])
    inputs.append([[sys.argv[0], '-i', './test_data', '-o', './test_output', '-t', '34', '-r', './test_data']])

# Generated at 2022-06-25 21:57:03.531713
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Exception when calling main()")
        raise
    print("main() passed unit test")

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:05.302839
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == "__main__":
    ret = test_main()
    sys.exit(ret)

# Generated at 2022-06-25 21:57:24.678269
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:57:25.888772
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Run the unit tests
test_main()

# Generated at 2022-06-25 21:57:26.974330
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:27.831874
# Unit test for function main
def test_main():
    py_backwards.main()


# Generated at 2022-06-25 21:57:29.318758
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:32.749560
# Unit test for function main
def test_main():
    with patch('sys.argv', ['py-backwards', '-i', 'test/input.py', '-t', '2.7', '-o', 'test/input.py']):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:34.478937
# Unit test for function main
def test_main():
    print('Unit test for main at python/src/backwards/__main__.py')
    test_case_0()

# Generated at 2022-06-25 21:57:36.202060
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:57:37.660341
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:47.403350
# Unit test for function main

# Generated at 2022-06-25 21:58:30.670792
# Unit test for function main
def test_main():
    # Testing if file exists
    assert os.path.isfile("./../examples/example.py") is True
    # Testing if the file is empty
    assert os.path.getsize("./../examples/example.py") is not 0
    # Testing if file can be opened
    assert open("./../examples/example.py") is not None
    # Testing if the function doesn't return an error
    assert int_0 == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:58:31.520991
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:32.367263
# Unit test for function main
def test_main():
    int_0 = main()

# Generated at 2022-06-25 21:58:33.525423
# Unit test for function main
def test_main():
    try: main()
    except SystemExit: assert True


# Generated at 2022-06-25 21:58:34.921554
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:58:36.267324
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Main execution
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:58:38.235430
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:39.715255
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:58:43.632981
# Unit test for function main
def test_main():
    args = ['py-backwards', '-i', 'src/p33', '-o', 'dist/f1.py', '-t', '3.3', '-r', 'src']
    with patch.object(sys, 'argv', args):
        test_case_0()

# Generated at 2022-06-25 21:58:47.003363
# Unit test for function main
def test_main():
    os.chdir(os.path.dirname(__file__))
    test_case_0()


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 22:00:03.823309
# Unit test for function main
def test_main():
    assert type(main()) is int


# Generated at 2022-06-25 22:00:07.394662
# Unit test for function main
def test_main():
    __main_function = main
    def main(input_0: str, input_1: str, input_2: str, input_3: str, input_4: bool) -> int:
        return __main_function()
    main(None, None, None, None, False)

# Generated at 2022-06-25 22:00:09.089644
# Unit test for function main
def test_main():
    test_case_0()


# Program entry point
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:00:14.249970
# Unit test for function main
def test_main():
    try:
        sys.argv.append('-i')
        sys.argv.append('examples/example_0.py')
        sys.argv.append('-o')
        sys.argv.append('tmp/test.py')
        sys.argv.append('-d')
        sys.argv.append('-t')
        sys.argv.append('2.7')
        main()
    except SystemExit:
        pass

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-25 22:00:17.907617
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 1


# @unittest.skip('Not run')
# class MyTests(unittest.TestCase):
#     def test_case_0(self):
#         int_0 = main()
#
#
# if __name__ == '__main__':
#     # unittest.main()
#     test_main()

# Generated at 2022-06-25 22:00:18.938352
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:00:20.474723
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 22:00:21.899724
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 22:00:23.886036
# Unit test for function main
def test_main():
    # Set up arguments
    args_0 = []
    # Call function
    int_0 = main(args_0)
    # Check result
    #assert int_0 == 0
    assert False



# Generated at 2022-06-25 22:00:28.378482
# Unit test for function main
def test_main():
    if not os.path.exists('tests/test.py'):
        sys.exit(print('test_main() failed'))
    main()
    if not os.path.exists('tests/test_py36.py'):
        sys.exit(print('test_main() failed'))

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 22:03:28.835246
# Unit test for function main
def test_main():
    assert callable(main)



# Generated at 2022-06-25 22:03:30.206513
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 22:03:32.968865
# Unit test for function main
def test_main():
    """
    This function tests if function main return integer, either 0 or 1
    """
    assert isinstance(main(), int) == True

# Generated at 2022-06-25 22:03:34.090570
# Unit test for function main
def test_main():
    test_case_0()

# Run main
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:03:40.178136
# Unit test for function main
def test_main():
    from .test_files import test_files
    import shutil

    argv = ['-i', test_files.INPUT, '-o', test_files.OUTPUT,
            '-t', 'py36', '-r', test_files.ROOT]
    sys.argv = ['py-backwards', *argv]
    main()
    assert (test_files.expected_output ==
            open(test_files.OUTPUT, 'r').read())
    shutil.rmtree(test_files.OUTPUT)

# Generated at 2022-06-25 22:03:41.443964
# Unit test for function main
def test_main():
    t = TestCase.TestCase()
    t.add(test_case_0)
    t.run()

# Generated at 2022-06-25 22:03:42.591172
# Unit test for function main
def test_main():
    unittest.main(module="function_tests")

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 22:03:44.149524
# Unit test for function main
def test_main():
    int_0 = main()
    assert type(int_0) == int


# Generated at 2022-06-25 22:03:46.158073
# Unit test for function main
def test_main():
    import main
    # Declare an instance of the InputData class

    # Check add_edge's behavior
    main.main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:03:46.863606
# Unit test for function main
def test_main():
    int_0 = main()