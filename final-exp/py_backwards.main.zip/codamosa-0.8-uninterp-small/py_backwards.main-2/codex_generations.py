

# Generated at 2022-06-25 21:56:44.148160
# Unit test for function main
def test_main():
    int_0 = main()
    #assert int_0 == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:56:45.789079
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:56:46.674204
# Unit test for function main
def test_main():
    const.TEST_CASE_0()

# Generated at 2022-06-25 21:56:47.894895
# Unit test for function main
def test_main():
    assert test_case_0() == 0, 'test case 0 failed'


# Generated at 2022-06-25 21:56:49.687032
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 21:56:51.532755
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:56:52.080271
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 21:56:54.447357
# Unit test for function main
def test_main():
    """
    Main function calling
    """
    test_case_0()


# Main function calling
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:56:55.309284
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 21:56:57.014846
# Unit test for function main
def test_main():
    int_0: int = main()
    assert int_0 is not None


# Generated at 2022-06-25 21:57:19.343057
# Unit test for function main
def test_main():
    # try:
    #     int_0 = main()
    # except SystemExit:
    #     pass
    # except:
    #     raise AssertionError('unexpected exception')
    # assert int_0 == 0
    test_case_0()

#
# Call
#
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:57:20.191112
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:21.668214
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0

test_case_0()

# Generated at 2022-06-25 21:57:25.522874
# Unit test for function main
def test_main():
    mock_stdout = io.StringIO()
    with contextlib.redirect_stdout(mock_stdout):
        test_case_0()
    assert mock_stdout.getvalue() == 'Compilation of 1 files completed successfully\n'
    mock_stdout.close()

# Generated at 2022-06-25 21:57:29.521038
# Unit test for function main
def test_main():
    # Kill all of the output
    with open(os.devnull, 'w') as fh:
        main(['test/test.py'], 'test/test_backward.py', '2.7')

if __name__ == '__main__':
    # main(sys.argv[1:])
    main()

# Generated at 2022-06-25 21:57:34.478394
# Unit test for function main
def test_main():
    sys.argv.append("--input")
    sys.argv.append("../resources/1.py")
    sys.argv.append("--output")
    sys.argv.append("../resources/output/1.py")
    sys.argv.append("--target")
    sys.argv.append("py3.5")
    test_case_0()

# Unit tests

# Generated at 2022-06-25 21:57:43.893138
# Unit test for function main
def test_main():
    # Source: https://pythontesting.net/framework/pytest/pytest-unittest-results-in-travis-ci/

    # Condition 1: The input is a valid file
    args = ['-i','../version_2.0/tests/resources/resources.py', '-o','../output', '-t','py35', '-r','../version_2.0/tests/']
    sys.argv = sys.argv[:1] + args
    test_case_0()

    # Condition 2: The input is an invalid file
    args = ['-i','../version_2.0/tests/resources/invalid.py', '-o','../output', '-t','py35', '-r','../version_2.0/tests/']

# Generated at 2022-06-25 21:57:48.619206
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'example.py', '-o', 'out.py',
     '-t', 'python2', '-r' ,'root.py']
    main()
    sys.argv = ['py-backwards', '-i', 'example.py', '-o', 'out.py',
     '-t', 'python2']


# Generated at 2022-06-25 21:57:49.366587
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:51.267794
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    # Call function main
    sys.exit(test_main())

# Generated at 2022-06-25 21:58:27.700247
# Unit test for function main
def test_main():
    assert main() == 0  # test case 0

# Generated at 2022-06-25 21:58:32.161989
# Unit test for function main
def test_main():
    args = ["-i", "test_case_0.py", "-o", "test_out_0.py", "-t", "2", "-r", "test_root_0.py"]
    sys.argv[1:] = args
    result = main()
    assert result == 0


# Generated at 2022-06-25 21:58:32.694602
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:58:33.575337
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 21:58:37.818473
# Unit test for function main
def test_main():
    sys.argv = [
        "py-backwards",
        "-i",
        "./tests/files/test.py",
        "-o",
        "./tests/files/test-out.py",
        "-t",
        "3.6",
        "-d",
        "-r",
        "./tests/files/",
    ]
    test_case_0()

# Generated at 2022-06-25 21:58:39.118635
# Unit test for function main
def test_main():
    test_case_0()

# Compiled version of py-backwards

# Generated at 2022-06-25 21:58:39.994672
# Unit test for function main
def test_main():
    main()

test_case_0()

# Generated at 2022-06-25 21:58:40.873347
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 21:58:42.026553
# Unit test for function main
def test_main():
    pass


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:58:54.699949
# Unit test for function main
def test_main():
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()
    assert main()

# Generated at 2022-06-25 21:59:33.754455
# Unit test for function main
def test_main():
    from .conf import settings
    settings.debug = True
    test_case_0()

# Generated at 2022-06-25 21:59:40.795713
# Unit test for function main
def test_main():
    # init
    args = [
        '-i',
        '../tests/data/real_life/project_source',
        '-o',
        '../tests/data/real_life/project_destination',
        '-t',
        '3.5',
        '-r',
        '../tests/data/real_life/project_source',
        '-d'
    ]
    sys.argv = sys.argv[:1] + args
    # run
    int_0 = main()


# Generated at 2022-06-25 21:59:41.668919
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 21:59:45.901649
# Unit test for function main
def test_main():
    # TODO: make a better test
    test_case_0()
    test_input_0()
    test_input_1()
    test_input_2()
    test_input_3()
    test_input_4()
    test_input_5()



# Generated at 2022-06-25 21:59:47.046589
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:59:47.849384
# Unit test for function main
def test_main():
    int_0 = main()

# Generated at 2022-06-25 21:59:48.696191
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:50.419329
# Unit test for function main
def test_main():
    assert test_case_0() == 0, 'Test case 0 for main failed.'


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:59:52.054800
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:59:52.890982
# Unit test for function main
def test_main():
	test_case_0()

# Generated at 2022-06-25 22:01:22.413469
# Unit test for function main
def test_main():
    """
    Test function main
    """
    # Test cases
    test_case_0()
    print('All tests passed')

# Generated at 2022-06-25 22:01:25.653522
# Unit test for function main
def test_main():
    # Fail test case 0
    print(colored('Test case 0, should fail: ', 'yellow'))
    test_case_0()
    print(colored('Result: ', 'yellow'), 'Fail\n')


# Generated at 2022-06-25 22:01:28.433696
# Unit test for function main
def test_main():
    # Test case 0
    # No argument
    # Expected result:
    #   Syntax error
    test_case_0()
    int_0 = main()
    assert int_0 == 1

# Generated at 2022-06-25 22:01:31.746168
# Unit test for function main
def test_main():
    print("Testing main")
    test_case_0()

test_main()
result = test_main()
sys.exit(result)

# Generated at 2022-06-25 22:01:34.443206
# Unit test for function main
def test_main():
    unittest_1 = unittest.TestLoader().loadTestsFromTestCase(test_case_0)
    unittest.TextTestRunner(verbosity=2).run(unittest_1)

# Generated at 2022-06-25 22:01:36.843371
# Unit test for function main
def test_main():

    try:
        test_case_0()
    except:
        assert  False

# Program entrypoint
if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-25 22:01:37.388286
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 22:01:41.255686
# Unit test for function main
def test_main():
    args = ('-i', 'test/test_package', '-o', 'test/output', '-t', '3.6', '-r',
            'test')
    with patch.object(sys, 'argv', args):
        test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:01:45.773186
# Unit test for function main
def test_main():
    print(repr(test_case_0.__name__))
    test_case_0()


test_main()

# Generated at 2022-06-25 22:01:48.024185
# Unit test for function main
def test_main():
    assert callable(main)
    assert isinstance(main(), int)

# A hack to call the unit tests
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:04:52.674832
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 22:04:53.814003
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 22:04:54.502777
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:04:55.135893
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 22:05:06.188838
# Unit test for function main

# Generated at 2022-06-25 22:05:10.873139
# Unit test for function main
def test_main():
    # Example
    assert main() == 0
    # Example
    assert main() == 0
    # Example
    assert main() == 0
    # Example
    assert main() == 0
    # Example
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:05:13.026296
# Unit test for function main
def test_main():
    # Call function main without arguments
    with pytest.raises(SystemExit) as ex:
        main()

    # Check exit code
    assert ex.value.code == 2

# Generated at 2022-06-25 22:05:16.327073
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0
    return int_0


# Generated at 2022-06-25 22:05:21.339959
# Unit test for function main
def test_main():
    assert(main() == 0)

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:05:29.446891
# Unit test for function main
def test_main():
    argv = ['-i', 'test_cases/test_case_0.py', '-o', 'test_output', '-t', '3.4', '-r', 'test_cases']
    save_stdout = sys.stdout
    output = io.StringIO()
    sys.stdout = output
    test_case_0()
    sys.stdout = save_stdout
    output_0 = output.getvalue()
    output.close()

    assert output_0 == '''input: test_input
output: test_output
target: 3.4

1 files processed.
0 files compiled.
'''


if __name__ == '__main__':
    sys.exit(main())