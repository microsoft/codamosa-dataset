

# Generated at 2022-06-25 21:56:39.988914
# Unit test for function main
def test_main():
    print("Unit test for function main")
    test_case_0()
    print("Function main passed all unit tests")

# Execute test driver
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:56:41.090462
# Unit test for function main
def test_main():
    # Test Case 0
    test_case_0()

# Generated at 2022-06-25 21:56:41.888553
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:56:53.253194
# Unit test for function main
def test_main():
    print('Test main')

    import os
    import shutil

    def copy_file(source, target):
        try:
            shutil.copy(source, target)
        except shutil.Error as e:
            print('Directory not copied. Error: %s' % e)
        except IOError as e:
            print('File not copied. Error: %s' % e)

# Generated at 2022-06-25 21:56:55.138469
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    test_main()
    #main()

# Generated at 2022-06-25 21:56:57.418144
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 21:56:58.935562
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit:
        pass


# Generated at 2022-06-25 21:57:00.325821
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:02.238531
# Unit test for function main
def test_main():
    assert callable(main)
    assert int_0 == 0
    
if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:57:03.063012
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 21:57:21.241242
# Unit test for function main
def test_main():

    result = main()
    assert result == 0

# Generated at 2022-06-25 21:57:22.369613
# Unit test for function main
def test_main():
    test_case_0()


# Compiling a python file

# Generated at 2022-06-25 21:57:23.858077
# Unit test for function main
def test_main():
    int_0 = main()


# Unit tests for function main

# Generated at 2022-06-25 21:57:32.739940
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "input.py", "-o", "output.py", "-t", "2.7", "-d", "--root", "__init__.py"]
    assert main() == 0
    sys.argv = ["py-backwards", "-i", "input.py", "-o", "output.py", "-t", "2.7", "-d", "--root", "__init__.py"]
    assert main() == 0
    sys.argv = ["py-backwards", "-i", "input.py", "-o", "output.py", "-t", "2.7", "-d", "--root", "__init__.py"]
    assert main() == 0

# Generated at 2022-06-25 21:57:34.478364
# Unit test for function main
def test_main():
    test_case_0()


# Program entry point
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:57:35.323273
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:37.040782
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:38.302409
# Unit test for function main
def test_main():
    test_case_0()

# Compiles Python 2 code

# Generated at 2022-06-25 21:57:39.833485
# Unit test for function main
def test_main():
    # Prepare
    test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:41.399844
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 21:58:27.156889
# Unit test for function main

# Generated at 2022-06-25 21:58:32.896233
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards.py", "-i", "test/test_cases/test_case_0/test_case_0_transformed.py",
                "-o", "test/test_cases/test_case_0/test_case_0.py", "-t", "py36",
                "-r", "test/test_cases/test_case_0"]
    test_case_0()

test_main()

# Generated at 2022-06-25 21:58:39.260478
# Unit test for function main
def test_main():
    import os
    import sys

    cur_path = os.path.dirname(os.path.abspath(__file__))
    if not os.path.isfile(''.join([cur_path, '/../py_backwards/examples/basic.py'])):
        assert(False)

    sys.argv = ['', '-t', '2.7', '-i', ''.join([cur_path, '/../py_backwards/examples/basic.py']),
                '-o', ''.join([cur_path, '/../py_backwards/examples/out'])]
    assert 0 == main()
    os.remove(''.join([cur_path, '/../py_backwards/examples/out/basic.py']))


# Generated at 2022-06-25 21:58:40.802420
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:58:48.373346
# Unit test for function main
def test_main():
    if sys.argv[2:]:
        sys.argv = sys.argv[2:]
    sys.argv = [sys.argv[0], '-i', './build/test/test_cases/test_case_0/in.py', '-o', './build/test/test_cases/test_case_0/out.py', '-r', './build/test/test_cases/test_case_0', '-t', '3', '-d']
    main()

# Generated at 2022-06-25 21:58:49.475217
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 21:58:49.983356
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 21:58:55.326294
# Unit test for function main
def test_main():
    assert main() == 0
    assert main(['--input', 'x', '--output', 'y', '--target', 'python2']) == 1
    assert main(['--input', 'x', '--output', 'y', '--target', 'python3']) == 1

# Generated at 2022-06-25 21:59:04.667492
# Unit test for function main
def test_main():
    test_cases = [
        ("No args", [], 2),
        ("Arguments", ["-i", "sources", "-o", "output", "-t", "3"], 1)
    ]
    ok = True
    for test_name, arguments, expected_value in test_cases:
        try:
            with capture(main, *arguments) as output:
                pass
        except SystemExit as se:
            if se.code != expected_value:
                ok = False
                print("{} failed.".format(test_name))
                print(" Expected {} but got {}.".format(expected_value, se.code))

    if ok:
        print("All tests passed.")

# Test runner from
# https://stackoverflow.com/questions/16571150/how-to-capture-stdout-output

# Generated at 2022-06-25 21:59:05.406609
# Unit test for function main
def test_main():
    int_0 = main()


# Generated at 2022-06-25 22:00:28.070426
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', ['program', '-i', '../tests/data/test_src.py',
                                 '-o', '/tmp/test_out/', '-t', 'python36',
                                 '-r', '/tmp/sources/']):
        test_case_0()

# Generated at 2022-06-25 22:00:29.462119
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:00:30.235012
# Unit test for function main
def test_main():
    assert main() is None



# Generated at 2022-06-25 22:00:31.258213
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:00:32.067040
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:00:39.173284
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards:", "-i", "../test/test_cases/test_case_0.py", "-o", "test_case_0.py", "-t", "2.7", "-r", "../test/test_cases/"]
    test_case_0()
    with open("test_case_0.py", "r") as f:
        target = f.read()
    with open("../test/test_cases/expected_case_0.py", "r") as f:
        expected = f.read()
    assert target == expected


# Generated at 2022-06-25 22:00:41.506802
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'examples/f1.py', '-o', 'output.py',
                '-t', 'Py36', '-r', 'examples']
    main()

# Generated at 2022-06-25 22:00:44.142545
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-25 22:00:44.912356
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-25 22:00:50.306297
# Unit test for function main
def test_main():
    # Test arguments
    sys.argv = ["py-backwards",
                "-i", "/Users/alforbes/Ongoing/py-backwards/tests/test_files/test.py",
                "-o", "/Users/alforbes/Ongoing/py-backwards/tests/test_files/test_out.py",
                "-t", "3.5"]

    res = main()
    assert res == 0


# Generated at 2022-06-25 22:03:45.293349
# Unit test for function main
def test_main():
    assert main() == 0, "Error on main function!"

# Generated at 2022-06-25 22:03:47.727145
# Unit test for function main
def test_main():
    print('Executing unit test for function main')
    test_case_0()
    print('Unit test for function main completed')

# Run program
if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-25 22:03:56.436841
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 22:04:01.038702
# Unit test for function main
def test_main():
    args = ['-i',
            '../tests/files/input/py-backwards.txt',
            '-o',
            '../tests/files/output/py-backwards.txt',
            '-t',
            '3.5',
            '-r',
            '../tests/files/',
            '-d'
            ]
    sys.argv = args
    test_case_0()

# Generated at 2022-06-25 22:04:02.550694
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-25 22:04:03.657315
# Unit test for function main
def test_main():
    # execute the function and assert on the returned result
    assert main() == 0

# Generated at 2022-06-25 22:04:04.445015
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:04:05.234631
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:04:05.723572
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:04:08.071896
# Unit test for function main
def test_main():
    test_case_0()
    assert True

