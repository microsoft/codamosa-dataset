

# Generated at 2022-06-25 21:56:40.105558
# Unit test for function main
def test_main():
    test_case_0()
    print('Done')

# Generated at 2022-06-25 21:56:51.131982
# Unit test for function main
def test_main():
    input_source = os.getcwd() + '\\Tests\\Main\\example.py'
    output = os.getcwd() + '\\Tests\\Main\\Converted'
    sys.argv = [sys.argv[0], '-i', input_source, '-o', output, '-t', '3.4']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', output, '-o', output, '-t', '3.6']
    assert main() == 0
    try:
        sys.argv = [sys.argv[0], '-i', input_source, '-o', output, '-t', '2.7']
        assert main() == 0
    except exceptions.TransformationError:
        pass

# Generated at 2022-06-25 21:56:53.160812
# Unit test for function main
def test_main():
    # Assert that function returns value
    assert test_case_0() == 0

# Unit tests for function compile_files

# Generated at 2022-06-25 21:56:54.061559
# Unit test for function main
def test_main():
    test_main_0()


# Generated at 2022-06-25 21:57:01.966264
# Unit test for function main
def test_main():
    test_case_0()
    test_case_1()

# >>> main()
# py-backwards: error: the following arguments are required: -t/--target

# >>> main('-i a -o b')
# py-backwards: error: the following arguments are required: -t/--target

# >>> main('-i a -o b -t 2')
# py-backwards: error: argument -t/--target: invalid choice: '2' (choose from '2.5', '2.6', '2.7', '3.6')

# >>> main('-i a -o b -t 2.5')
# py-backwards: error: argument -i/--input: invalid int value: 'a'

# >>> main('-i 1 -o b -t 2.5')
# py-

# Generated at 2022-06-25 21:57:03.102256
# Unit test for function main
def test_main():
    # Starting test 1
    assert main() == 1
    # Ending test 1

# Generated at 2022-06-25 21:57:05.152172
# Unit test for function main
def test_main():
    # First test: Normal case
    result = main()
    # Assert
    assert result == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:57:07.790413
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:15.239234
# Unit test for function main
def test_main():
    print("Output should be an error message about the input doesn't exists")
    args = ["-i", "some_file_with_no_valid_name", "-o", "some_other_invalid_file", "-t", "2", "-r", "some_other_invalid_file_too"]
    with patch.object(sys, 'argv', args):
        with patch('sys.stderr', new=StringIO()) as stderr:
            with patch('sys.stdout', new=StringIO()) as stdout:
                main()
                assert stderr.getvalue() == "Input some_file_with_no_valid_name doesn't exists!\n"


# Generated at 2022-06-25 21:57:16.655495
# Unit test for function main
def test_main():
    test_case_0()

# Entry point for script
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:57:36.284189
# Unit test for function main
def test_main():
    int_0 = 0
    int_1 = main()
    assert (int_0 == int_1)


# Generated at 2022-06-25 21:57:38.046099
# Unit test for function main
def test_main():
    test_case_0()

# Main function
# Test function main
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:40.238748
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        return False
    return True

if __name__ == "__main__":
    print(test_main())

# Generated at 2022-06-25 21:57:41.826170
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 21:57:43.086635
# Unit test for function main
def test_main():
    cases = [test_case_0]
    for case in cases:
        case()

# Generated at 2022-06-25 21:57:51.233221
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-25 21:57:51.997398
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:57:52.802424
# Unit test for function main
def test_main():    
    assert main() == 0


# Generated at 2022-06-25 21:57:53.544821
# Unit test for function main
def test_main():
    pass

# Unit test if main function runs

# Generated at 2022-06-25 21:57:54.932184
# Unit test for function main
def test_main():
    # Put test code here
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:58:15.548333
# Unit test for function main
def test_main():
    argv = ['py-backwards', '-i', 'test', '-o', 'test_output', '-t', 'py36', '-r', 'test']
    sys.argv = argv
    test_case_0()

# Generated at 2022-06-25 21:58:16.743008
# Unit test for function main
def test_main():
    test_case_0()

# Run unit tests
test_main()

# Generated at 2022-06-25 21:58:17.527301
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:23.570438
# Unit test for function main
def test_main():
    # Set up parameters
    import sys
    import os

    test_case_0()
    return 0

if __name__ == '__main__':
    test_main()
else:
    import sphinx
    sphinx.main(['sphinx-build', '-M', 'doctest', os.path.dirname(__file__), os.path.join(os.path.dirname(__file__), '../build')])
#
# init.py ends here

# Generated at 2022-06-25 21:58:24.453572
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:31.095357
# Unit test for function main
def test_main():
    args = "-i /home/pawel/Documents/Zastosowania-komputerow-II/lab2/py-backwards/tests/compilation/ -o /home/pawel/Documents/Zastosowania-komputerow-II/lab2/py-backwards/tests/compilation/ -t 2 -r /home/pawel/Documents/zastosowania_komputerowe/zak".split()
    sys.argv = args
    assert main() == 0


# Generated at 2022-06-25 21:58:38.371335
# Unit test for function main
def test_main():
    print("Test case 1: input_folder_none, output_folder_none, target_python_version_none")
    sys.argv = ['py-backwards',
                '-i', './test_data/test_case0_input_folder',
                '-o', './test_data/test_case0_output_folder',
                '-t', '3.5']
    test_case_0()
    print("Test case 2: input_file_good.py, output_folder_none, target_python_version_none")

# Generated at 2022-06-25 21:58:39.237791
# Unit test for function main
def test_main():
    assert (main() == 0)


# Generated at 2022-06-25 21:58:40.424112
# Unit test for function main
def test_main():
    test_case_0()

# Run tests
test_main()

# Generated at 2022-06-25 21:58:43.187766
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '2.7']
    test_case_0()

# Generated at 2022-06-25 21:59:21.987497
# Unit test for function main
def test_main():

    assert(test_case_0() == 0)

    assert(main() == 0)

# Generated at 2022-06-25 21:59:25.627152
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "test.py", "-o", "test_out.py", "-t", "2.7"]
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:59:26.400989
# Unit test for function main
def test_main():
    # Test case 0
    main()

# Generated at 2022-06-25 21:59:27.173791
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:29.544779
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except SystemExit as e:
        assert e.code == 0
        assert True
    except:
        print("Unexpected error:", sys.exc_info()[0])
        assert False

# Generated at 2022-06-25 21:59:31.039902
# Unit test for function main
def test_main():
    # TODO: Test that main returns the correct result
    assert test_case_0() == 0

# Generated at 2022-06-25 21:59:32.026072
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:37.142661
# Unit test for function main
def test_main():
    with patch('argparse.ArgumentParser.parse_args', return_value=argparse.Namespace(input=['app/app.py'], output='app_output', target='py36', root='app')) as argparse_mock:
        main()
        argparse_mock.assert_called()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:59:40.551452
# Unit test for function main
def test_main():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    try:
        test_main()
    except Exception as e:
        print(str(e))
        exit(1)
    
    exit(0)

# Generated at 2022-06-25 21:59:42.156443
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 22:01:08.085558
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 1



# Generated at 2022-06-25 22:01:08.778868
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:01:15.699225
# Unit test for function main
def test_main():
    input_ = ['tests/test_data/test_source_0.py', 'tests/test_data/test_source_1.py']
    output = 'tests/test_data/output'
    target = 'python2.7'
    root = ''
    debug = False

    sys.argv = sys.argv[:1] + ['-i', 'tests/test_data/test_source_0.py', '-i', 'tests/test_data/test_source_1.py',
                               '-o', 'tests/test_data/output', '-t', 'python2.7', '-r', '', '-d', '']
    int_0 = main()


# Generated at 2022-06-25 22:01:16.296322
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-25 22:01:27.096266
# Unit test for function main

# Generated at 2022-06-25 22:01:28.592279
# Unit test for function main
def test_main():
    test_case_0()

# Runs main function with command-line args and returns exit code

# Generated at 2022-06-25 22:01:32.247817
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except:
        return False

    return True


if __name__ == "__main__":
    print(main())

# Generated at 2022-06-25 22:01:40.851242
# Unit test for function main
def test_main():
    # testing branch branch_1
    class mock_parser:
        args = None

        def __init__(self):
            self.args = None

        def parse_args(self):
            self.args = mock_args()
            return self.args

    class mock_args:
        input = None
        output = None
        target = None
        root = None
        debug = None

        def __init__(self):
            self.input = None
            self.output = None
            self.target = None
            self.root = None
            self.debug = None

    parser = mock_parser()
    args = parser.parse_args()
    args.input = [1, 2, 3]
    args.output = 4
    args.target = 'py36'
    args.root = 5
    args.debug = True


# Generated at 2022-06-25 22:01:52.699140
# Unit test for function main
def test_main():
    import imports.exceptions as exceptions
    import imports.const as const
    import imports.messages as messages
    import imports.compiler as compiler
    import imports.conf as conf

    # check if function calls are valid

# Generated at 2022-06-25 22:01:55.969729
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:05:10.758949
# Unit test for function main
def test_main():
    int_0 = main()
    assert(int_0 == 0)


# Generated at 2022-06-25 22:05:12.687911
# Unit test for function main
def test_main():
    print('Test #', bool(main() == 0))

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:05:20.857271
# Unit test for function main
def test_main():
    print(green + "\nUnit test for main")
    print('Should be successful:')
    test_case_0()
    print('Should fail, invalid args:')
    sys.argv = ['main.py', '--invalid']
    int_0 = main()
    assert int_0 == 2
    sys.argv = ['main.py', '-i', 'invalid', '-t', '3.6', '-o', 'out', '-r', 'root']
    int_0 = main()
    assert int_0 == 1
    sys.argv = ['main.py', '-i', 'invalid', '-t', '3.6', '-o', 'out', '-r', 'root']
    int_0 = main()
    assert int_0 == 1

# Generated at 2022-06-25 22:05:22.253074
# Unit test for function main
def test_main():
    assert(main()), 'Function should return 0'

# Generated at 2022-06-25 22:05:23.006504
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:24.336726
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 22:05:28.402207
# Unit test for function main
def test_main():
    print('test_main')
    print('----------')

    # test case 0
    print('Testing test case 0')
    print('Expected output: 0')
    test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:05:29.222112
# Unit test for function main
def test_main():
    main()

# Author test case

# Generated at 2022-06-25 22:05:36.336717
# Unit test for function main
def test_main():
    import pathlib
    import constants
    import os
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()

    # Test case 0
    try:
        main()
    except SystemExit as e:
        sys.exit(0)
    except:
        sys.exit(1)

    # Test case 1

# Generated at 2022-06-25 22:05:37.374380
# Unit test for function main
def test_main():
    test_case_0()