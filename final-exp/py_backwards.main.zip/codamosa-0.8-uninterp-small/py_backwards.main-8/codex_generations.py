

# Generated at 2022-06-25 21:56:45.745969
# Unit test for function main
def test_main():
    int_0 = main()
    # Error: No input args
    int_1 = main([""])
    # Error: Invalid output
    int_2 = main(["", "-o", ""])
    # Error: Invalid target
    int_3 = main(["", "-t", ""])

# Generated at 2022-06-25 21:56:46.633947
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 21:56:51.777627
# Unit test for function main
def test_main():
    # Execution
    int_0 = main()
    # Verification
    int_1 = 0
    int_2 = 1
    if (int_0 != int_1 and int_0 != int_2):
        print('Unit test failed', file=sys.stderr)
        sys.exit(1)


# Generated at 2022-06-25 21:56:55.464613
# Unit test for function main
def test_main():
    tests = [test_case_0]
    # print(len(tests))
    cnt = 1
    for t in tests:
        print("Test #" + str(cnt))
        t()
        cnt += 1


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:56:57.662543
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 21:57:00.057393
# Unit test for function main
def test_main():
    try:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
    except SystemExit:
        pass

test_main()

# Generated at 2022-06-25 21:57:02.277568
# Unit test for function main
def test_main():
    # No testing required. Everything is tested in test_compiler.py
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:57:04.042565
# Unit test for function main
def test_main():
    test_case_0()
    print('Test case for function main has been executed')


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:57:04.845377
# Unit test for function main
def test_main():
    assert(main() == 0)


# Generated at 2022-06-25 21:57:08.431462
# Unit test for function main
def test_main():
    # Clear command line arguments
    sys.argv = sys.argv[:1]

    # Test case 0
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:18.307328
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 21:57:23.003041
# Unit test for function main
def test_main():
    # Test input
    input = "../test/test.py"
    # Test output
    output = "../test/test2.py"
    # Test target
    target = "3.6"

    # Test root
    root = None
    # Test debug
    debug = True

    # Asserts
    assert main() is not None
    assert main() == 0


# Generated at 2022-06-25 21:57:24.882061
# Unit test for function main
def test_main():
    int_0 = main()
    assert int_0 == 0

# Unit test from test/test_cli.py

# Generated at 2022-06-25 21:57:26.091380
# Unit test for function main
def test_main():
    assert test_case_0() == 0




# Generated at 2022-06-25 21:57:32.333445
# Unit test for function main
def test_main():
    with patch('backwards.__main__.main') as mock_main:
        mock_main.return_value = 0
        mock_main.return_value = 1
        mock_main.return_value = 2
        mock_main.return_value = 3
        mock_main.return_value = 4
        mock_main.return_value = -1
        compteur = 0
        while mock_main.return_value != -1 :
            test_case_0()
            compteur += 1
            print(compteur)

# Generated at 2022-06-25 21:57:41.951844
# Unit test for function main
def test_main():
    import sys
    import io

    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    # test for input files
    main(input=["test/test_data/test_case_0/test_input/test_input_0.py",
                "test/test_data/test_case_0/test_input/test_input_1.py"],
         output="test/test_data/test_case_0/test_output/test_output_0.py",
         target="2.7", debug=True)
    sys.stdout = sys.__stdout__
    assert (capturedOutput.getvalue()=="Compiled 1 file\n")
    print (capturedOutput.getvalue())


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:50.289534
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    # test case 1
    args = ['py-backwards',
            '-i', 'test_case/invalid_input/invalid_target.py',
            '-o', 'test_case/invalid_input/',
            '-t', '2.7'
            ]
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        sys.argv = args
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

    # test case 2

# Generated at 2022-06-25 21:57:51.339037
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:57:59.004749
# Unit test for function main
def test_main():
    parser = ArgumentParser('py-backwards')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str,
                        required=True, help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')
    # Case 0
    args = parser.parse

# Generated at 2022-06-25 21:58:00.489638
# Unit test for function main
def test_main():
   int_0=main()

# Generated at 2022-06-25 21:58:19.497196
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:22.311942
# Unit test for function main
def test_main():
    check_main = True
    try:
        test_case_0()
    except:
        check_main = False
    assert check_main


# Generated at 2022-06-25 21:58:31.711422
# Unit test for function main
def test_main():
    settings_0 = {
        'input': ['./gfui/compiler.py'],
        'output': './gfui/tmp/compiled_file.py',
        'target': '2.7',
        'root': '.',
        'debug': False
    }

    settings_1 = {
        'input': ['./gfui/compiler.py'],
        'output': './gfui/tmp/compiled_file.py',
        'target': '3.6',
        'root': '.',
        'debug': False
    }


# Generated at 2022-06-25 21:58:35.621952
# Unit test for function main
def test_main():
    tmp_callable = sys.argv
    sys.argv = ['',
                '-i', 'test_source.py',
                '-o', 'test_output.py',
                '--target', '2']
    test_case_0()
    sys.argv = tmp_callable

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:58:36.938217
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 21:58:39.200813
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:58:41.673037
# Unit test for function main
def test_main():
    output = StringIO()
    sys.stdout = output
    main()
    assert output.getvalue() == 'Compilation done!\n'
    sys.stdout = sys.__stdout__

# Generated at 2022-06-25 21:58:42.984313
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:58:45.681034
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 21:58:49.070371
# Unit test for function main
def test_main():
    # Test case 0
    print('Test case 0')
    test_case_0()

    print('Successful test cases - ' + str(0))
    print('Failed test cases - ' + str(0))

# Running test suite
test_main()

# Generated at 2022-06-25 21:59:27.915410
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-25 21:59:32.268725
# Unit test for function main
def test_main():
    argv = ['py-backwards', '--input', './tests/input', '--output', './tests/output', '--target', '2.7', '-r', './tests/input']
    sys.argv = argv
    import pytest
    pytest.main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 21:59:42.004936
# Unit test for function main
def test_main():
    import subprocess
    import os
    import tempfile
    import shutil
    p = subprocess.Popen([sys.executable, '-m', 'py_backwards',
                          '-i', 'tests/sources/test_func.py',
                          '-o', 'output_test.py',
                          '-t', '2.7'],
                         cwd=os.getcwd(),
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    assert stdout.decode('utf-8').strip() == 'Successfully compiled test_func.py'
    assert not os.path.exists('output_test.py')

    os.remove('output_test.py')

# Generated at 2022-06-25 21:59:44.927737
# Unit test for function main
def test_main():
    j = 1
    while j < 2:
        test_case_0()
        j += 1

# Start program
test_main()

# Generated at 2022-06-25 21:59:46.740438
# Unit test for function main
def test_main():
    print("---Test for main()---")
    print("Test 0: normal case")
    test_case_0()

# Generated at 2022-06-25 21:59:49.361324
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print(messages.test_failed('test_main'))
        raise
    else:
        print(messages.test_passed('test_main'))
    
test_main()

# Generated at 2022-06-25 21:59:50.194652
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 21:59:50.625768
# Unit test for function main
def test_main():
    assert test_case_0() == 0

# Generated at 2022-06-25 21:59:55.870987
# Unit test for function main
def test_main():
    print("Testing function main...", end="")
    sys.argv = ['test-0', '-i','test/test-files/test-0.py','-o','test_result.py','-t','2.7']
    test_case_0()
    assert os.path.exists('test_result.py')
    os.remove('test_result.py')
    print("Passed")

# Unittest for function test_case_0

# Generated at 2022-06-25 21:59:59.349821
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Cannot run unit tests for `main`")

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:01:29.415812
# Unit test for function main
def test_main():
    try:
        sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'out.py',
                    '-t', '3.6', '-d', 'True']
        test_case_0()
    except SystemExit:
        pass

# Generated at 2022-06-25 22:01:39.358499
# Unit test for function main
def test_main():
    # Create a list of inputs
    arg_list_0 = []
    # Add str type element to list arg_list_0
    arg_list_0.append("")
    # Assign to arg_list_0[0] element a value of -1
    arg_list_0[0] = -1
    # Assign arg_list_0[0] element to arg_0 variable
    arg_0 = arg_list_0[0]

    # Create a list of inputs
    arg_list_1 = []
    # Add str type element to list arg_list_1
    arg_list_1.append("")
    # Assign to arg_list_1[0] element a value of -1
    arg_list_1[0] = -1
    # Assign arg_list_1[0] element to arg_

# Generated at 2022-06-25 22:01:48.675253
# Unit test for function main
def test_main():
    print("Test #0 - function main", flush=True)
    test_case_0()


if __name__ == "__main__":
    test_main()
    if len(sys.argv) == 1:
        print("Usage: python -m py_backwards "
              "[-i <input file or folder>] "
              "[-o <output file or folder>] "
              "[-t <target version>] "
              "[-r <sources root>] "
              "[-d - debug output]", file=sys.stderr)
        sys.exit(1)
    sys.exit(main())

# Generated at 2022-06-25 22:01:50.510238
# Unit test for function main
def test_main():
    assert(test_case_0() == 0)


# Generated at 2022-06-25 22:01:50.989972
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 22:01:51.850041
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:01:53.175699
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:01:55.490749
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:01:56.765907
# Unit test for function main
def test_main():
    print('Test for function main')
    test_case_0()
    print()

test_main()

# Generated at 2022-06-25 22:01:59.912505
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:20.327731
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 22:05:23.938141
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input.txt', '-o', 'output.txt',
                '-t', 'py36']
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 22:05:24.670964
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:28.434803
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        print(e)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(test_main())

# Generated at 2022-06-25 22:05:29.255873
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 22:05:36.366539
# Unit test for function main
def test_main():
    print('Testing main... ', end='')
    sys.argv = ['py-backwards', '-i', 'tests/compile/test_case_0.py', '-o', 'tests/compile/test_case_0_res.py', '-t', '2.7']
    test_case_0()
    test_case_0_res = open('tests/compile/test_case_0_res.py', 'r')
    test_case_0_answer = open('tests/compile/test_case_0_answer.py','r')
    assert(test_case_0_res.read() == test_case_0_answer.read())
    test_case_0_res.close()
    test_case_0_answer.close()

# Generated at 2022-06-25 22:05:38.877925
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        if e.code != 0:
            raise

# Generated at 2022-06-25 22:05:39.988440
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 22:05:40.814021
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()

test_main()

# Generated at 2022-06-25 22:05:42.737410
# Unit test for function main
def test_main():
    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print('Exception: ' + str(e))
        assert False
    else:
        assert True

main()