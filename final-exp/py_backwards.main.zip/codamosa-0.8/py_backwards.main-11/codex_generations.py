

# Generated at 2022-06-22 14:58:46.975190
# Unit test for function main
def test_main():
    import json
    # pylint: disable=no-member
    print(main.args)
    assert main.args.count == 1

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 14:58:50.502603
# Unit test for function main
def test_main():
    input_source = 'test/test_file.py'
    output_source = 'test/py36_test_file.py'
    assert main(input_source, output_source) == 0

# Generated at 2022-06-22 14:58:58.123171
# Unit test for function main
def test_main():
    from tempfile import mkdtemp
    from shutil import rmtree
    from pathlib import Path

    with mkdtemp(prefix='py-backwards') as d:
        p = Path(d)
        input_path = p / 'input.py'
        output_path = p / 'output.py'
        input_path.write_text('print(1)')
        output_path.touch()

        assert main(['-i', str(input_path), '-o', str(output_path),
                     '-t', '3.5', '--root', str(p)]) == 0

        assert input_path.read_text() == output_path.read_

# Generated at 2022-06-22 14:59:05.950145
# Unit test for function main
def test_main():
    try:
        main()
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
    except exceptions.TransformationError as e:
        print(messages.transformation_error(e), file=sys.stderr)
    except exceptions.InputDoesntExists:
        print(messages.input_doesnt_exists(args.input), file=sys.stderr)
    except exceptions.InvalidInputOutput:
        print(messages.invalid_output(args.input, args.output),
              file=sys.stderr)


# Generated at 2022-06-22 14:59:08.620535
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i','test_data/test.py', '-o', 'test_data/test_output.py', '-t', 'python3.5', '--debug']
    assert main() == 0

# Generated at 2022-06-22 14:59:11.032893
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:20.584290
# Unit test for function main
def test_main():
    from .conf import settings
    from .smoketest import test
    settings.set_settings({
        'input': 'tests/test_data/test.py',
        'output': '../../tests/test_data/out.py',
        'target': '2.7',
        'root': '../../tests/test_data'
    })
    compile_files(settings.get_settings()['input'],
                  settings.get_settings()['output'],
                  const.TARGETS[settings.get_settings()['target']],
                  settings.get_settings()['root'])
    test('tests/test_data/out.py', 'tests/test_data/expected/2.7.py')

# Generated at 2022-06-22 14:59:23.101112
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:32.324252
# Unit test for function main
def test_main():
    sys.argv[0] = 'py-backwards'
    sys.argv[1:] = '-i files/test.py -o compiled_files/ -t 3.5'.split()
    main()
    assert sys.argv[1] == '-i', "Invalid input arg"
    assert sys.argv[2] == 'files/test.py', 'Invalid input file or folder'
    assert sys.argv[3] == '-o', "Invalid output arg"
    assert sys.argv[4] == 'compiled_files/', 'Invalid output file or folder'
    assert sys.argv[5] == '-t', "Invalid target arg"
    assert sys.argv[6] == '3.5', "Invalid python version"

# Generated at 2022-06-22 14:59:37.373397
# Unit test for function main
def test_main():
    # choose main function for testing
    sys.modules['__main__'].main = main
    with pytest.raises(SystemExit) as e:
        with patch.object(sys, 'argv', ['py-backwards', '-i', 'example', '-o', 'example_output', '-t', '2.7', '-r', '.']):
            sys.exit(main())

    # checks if the returned error code is 0
    assert e.type == SystemExit
    assert e.value.code == 0


# Generated at 2022-06-22 14:59:59.260719
# Unit test for function main
def test_main():
    module = __import__(__name__)
    assert module.main(["-i", "input.py",
                        "-o", "output.py",
                        "-t", "python2",
                        "-r", "root"]) == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:00.432341
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:04.219954
# Unit test for function main
def test_main():
    # argparse uses sys.argv, so we need to mock it
    with mock.patch('sys.argv', [
        'py-backwards',
        '-i', 'tests/data/simple_function.py',
        '-o', 'output.py',
        '-t', '3.5'
    ]):
        assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:07.490227
# Unit test for function main
def test_main():
    orig_stdout, sys.stdout = sys.stdout, StringIO()
    main()
    assert sys.stdout.getvalue() == 'main'
    sys.stdout = orig_stdout


# Generated at 2022-06-22 15:00:09.456709
# Unit test for function main
def test_main():
    main(['-i', 'test.py', '-o', 'output', '-t', '3.5'])

# Generated at 2022-06-22 15:00:10.017972
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:00:21.643357
# Unit test for function main
def test_main():
    # prepare test
    input = 'input.py'
    output = 'output.py'
    target = '2.7'
    run_test_main(input, output, target)
    # prepare test
    input = 'input'
    output = 'output'
    target = '3.6'
    run_test_main(input, output, target)
    # prepare test
    input = 'input'
    output = 'output'
    target = '3.5'
    run_test_main(input, output, target)
    # prepare test
    input = 'input'
    output = 'output'
    target = '3.4'
    run_test_main(input, output, target)
    # prepare test
    input = 'input'
    output = 'output'
    target = '3.3'

# Generated at 2022-06-22 15:00:22.507268
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:25.074300
# Unit test for function main
def test_main():
    # arrange
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:26.152451
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-22 15:00:49.210972
# Unit test for function main
def test_main():
    args = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    args.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    args.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    args.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    args.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-22 15:00:50.175027
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:51.792242
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:54.395488
# Unit test for function main
def test_main():
    # Create a main
    test_main_ = main()

    # Try to parse the data
    assert test_main_ >= 0

# Generated at 2022-06-22 15:00:56.034236
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:01:00.216078
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test-data/test.py', '-o', 'dummy.py', '-t', '3.5']
    main()
    assert sys.argv[-1] == '3.5'

test_main()

# Generated at 2022-06-22 15:01:01.515249
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:08.259536
# Unit test for function main
def test_main():
    # Given a
    sys.argv = ['py-backwards', '-i', 'Tests/samples/sample_one', '-o', 'output',
                '-t', '3.3', '-r', 'Tests/samples/sample_one', '-d']
    # when main
    output = main()
    # then
    assert output == 0


# Generated at 2022-06-22 15:01:09.282872
# Unit test for function main
def test_main():
    # TODO: finish
    pass

# Generated at 2022-06-22 15:01:20.201302
# Unit test for function main
def test_main():
    from . import utils

    temp = utils.TemporaryDirectory()

    # no args
    main_args = main, ()
    result = utils.run_process(main_args)
    assert result.returncode == 2

    # empty input
    main_args = main, ('-i', '', '-o', 'output.py', '-t', '3.4')
    result = utils.run_process(main_args)
    assert result.returncode == 2
    assert result.stderr
    assert 'the following arguments are required' in result.stderr

    # empty target
    main_args = main, ('-i', 'input.py', '-o', 'output.py', '-t', '')
    result = utils.run_process(main_args)
    assert result.returncode

# Generated at 2022-06-22 15:01:56.531132
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:02:07.052170
# Unit test for function main
def test_main():
    # Test for files with py-backwards
    assert main() == 0

    # Test for files without py-backwards
    sys.argv[1] = '-i'
    sys.argv.append('tests/test_files/test1.py')
    sys.argv[3] = '-o'
    sys.argv.append('tests/test_files/test1_copy.py')
    sys.argv[5] = '-t'
    sys.argv.append('python2')
    sys.argv[7] = '-r'
    sys.argv.append('tests/test_files/')
    assert main() == 0

# Generated at 2022-06-22 15:02:13.894280
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'test/test_data/test_a.py',  # specify input file
        '-o', 'test/test_data/test_output',  # specify output file
        '-t', '3.5', # specify python version
        '-r', 'test/test_data', # specify root of the sources
    ]
    assert not main() # check that function main() return true

test_main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:25.803171
# Unit test for function main
def test_main():
    """
    Test main function
    """
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, 'test_file'), 'w') as file:
            file.write('x = 10')
        args = "--input {} --output {} --target 2.7".format(
            os.path.join(tmpdirname, 'test_file'),
            tmpdirname)
        sys.argv = ['py-backwards'] + args.split()
        assert main() == 0
        assert open(os.path.join(tmpdirname, 'test_file')).read() == (
            'x = 10\n'
            '\n'
            '\n')


# Generated at 2022-06-22 15:02:28.070014
# Unit test for function main
def test_main():
    sys.argv = ['pybw', '-i', 'tests/test_cases/basic/input.py', '-o', './', '-t', 'py27']
    main()

# Generated at 2022-06-22 15:02:40.057566
# Unit test for function main
def test_main():
    import pytest
    from io import StringIO
    from unittest.mock import patch
    from .version import VERSION

    def check_argparse(args: list, success: bool):
        input_stream = StringIO()
        with patch('sys.stdout', input_stream):
            argv = ['py-backwards'] + args
            with pytest.raises((SystemExit, KeyboardInterrupt)):
                result = main()
        assert result == 0 if success else 1
        return input_stream.getvalue().strip()

    parser_output = check_argparse(['-h'], True)
    assert parser_output.startswith('usage:')

    parser_output = check_argparse(['--version'], True)

# Generated at 2022-06-22 15:02:43.410481
# Unit test for function main
def test_main():
    try:
        import pytest
    except ImportError:
        return
    from pytest import raises

    sys.argv = ['py-backwards']
    with raises(SystemExit):
        main()

    sys.argv = ['py-backwards', '-i', 'a_file',
                '-o', 'another_file', '-t', '3.6']
    with raises(exceptions.CompilationError):
        main()

    sys.argv = ['py-backwards', '-i', 'fixtures/no_files.txt',
                '-o', 'another_file', '-t', '3.6']
    with raises(exceptions.InputDoesntExists):
        main()


# Generated at 2022-06-22 15:02:45.619027
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:56.580613
# Unit test for function main
def test_main():
    import subprocess
    from . import settings
    from .utils import add_input_extension
    from .parser import parse_file
    from .transformer import transform
    from .emitter import emit
    from .utils import add_output_extension

    settings.DEBUG = True

    def parse_and_transform(filename: str):
        input_file = add_input_extension(filename)
        output_file = add_output_extension(filename)
        ast = parse_file(input_file)
        transformed_ast = transform(ast)
        emit(transformed_ast, output_file)


# Generated at 2022-06-22 15:02:57.552129
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:04:26.776439
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:27.876796
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:31.971120
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i', 'a.py', '-o', 'a.py', '-t', '3.4']
    with patch('builtins.print', mock_print):
        main()
        assert mock_print.call_args_list[0][0][0] == 'Please enter inputs: '
        assert mock_print.call_args_list[1][0][0] == 'Please enter output: '
        assert mock_print.call_args_list[2][0][0] == 'Please enter target: '
        assert mock_print.call_args_list[3][0][0] == 'Ignoring python 3 features'

# Generated at 2022-06-22 15:04:36.812182
# Unit test for function main
def test_main():
    import argparse
    sys.args = argparse.Namespace(input=['test.py', 'test2.py'], output='test',
                           target='3.5', root='.', debug=True)

# Generated at 2022-06-22 15:04:38.324432
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:44.812933
# Unit test for function main
def test_main():
    input = '/Users/julia/Desktop/py-backwards/py_backwards/tests/input/decorator_to_class.py'
    output = '/Users/julia/Desktop/py-backwards/py_backwards/tests/input'
    conf = init_settings()
    conf.target = '2.7'
    result = main()
    assert result == 0
    compare_files(input, output, 'decorator_to_class.py')


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:48.580669
# Unit test for function main
def test_main():
    args = ['py-backwards', '-i', 'input', '-o', 'output', '-t', 'PY27',
            '-r', 'root']
    sys.argv[1:] = args
    assert main() == 0
    sys.argv[1:] = ['py-backwards', '-i', 'input', '-o', 'output', '-t', 'PY27']
    assert main() == 0

# Generated at 2022-06-22 15:04:49.975244
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:04:50.499438
# Unit test for function main
def test_main():
    assert main() != 0

# Generated at 2022-06-22 15:04:54.628305
# Unit test for function main
def test_main():
    args = ['py-backwards', '-r', '.', '-t', '3.6', '-i', 'pbw_tests/tests/', '-o', 'pbw_tests/outputs/output.py']
    sys.argv = args
    main()

# Generated at 2022-06-22 15:08:30.296814
# Unit test for function main
def test_main():
    class Arg:
        def __init__(self, input_: str, output: str, target: int, root: str):
            self.input = input_
            self.output = output
            self.target = target
            self.root = root
    import os
    if not os.path.exists('output'):
        os.makedirs('output')
    if not os.path.exists('output2'):
        os.makedirs('output2')
    if not os.path.exists('output3'):
        os.makedirs('output3')
    if not os.path.exists('output4'):
        os.makedirs('output4')

    assert main(Arg('test1.py', 'output/test1.py', 2, '.')) == 0

# Generated at 2022-06-22 15:08:35.124413
# Unit test for function main
def test_main():
    st = ""
    with open("test.py", 'r') as f:
        st = f.read()
    input = "test.py"
    with open("out.py", 'w') as f:
        f.write(input)
    output = "out.py"
    target = "3.6"
    from .settings import settings
    prototype = main(input, output, target, None)