

# Generated at 2022-06-22 14:58:40.966053
# Unit test for function main
def test_main():
    # assert <expected>, <actual>
    assert main() == 0

# Generated at 2022-06-22 14:58:41.830687
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:58:53.377606
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'test_sources/untouched_sources',
                '-o', 'test_sources/destination',
                '-t', '2.7']
    print(sys.argv)
    assert main() == 0
    sys.argv = ['', '-i', 'test_sources/untouched_sources',
                '-o', 'test_sources/destination',
                '-t', '3.4']
    assert main() == 0
    sys.argv = ['', '-i', 'test_sources/sources',
                '-o', 'test_sources/destination',
                '-t', '2.7',
                '-r', 'test_sources/']
    assert main() == 0

# Generated at 2022-06-22 14:58:54.330736
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 14:59:02.040165
# Unit test for function main
def test_main():
    from unittest.mock import patch, call
    from io import StringIO

    # Test arguments error
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        return_code = main()
        assert return_code == 2
        assert 'usage: py-backwards [-h]' in fake_stderr.getvalue()

    # Test input doesnt exist
    with patch('sys.stderr', new=StringIO()) as fake_stderr, \
         patch('sys.argv', new=['py-backwards', '-o', 'test_output',
                                '-t', '3.6', '-i', 'test']):
        return_code = main()
        assert return_code == 1
        assert 'test doesnt exist' in fake_stderr.getvalue()



# Generated at 2022-06-22 14:59:02.594388
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:05.796019
# Unit test for function main
def test_main():
    argv = ['-d', '-i', '../tests/cool_tests/', '-o',
            '../tests/cool_tests/output', '-t', '27', '-r', '../tests/']
    assert main(argv) == 0

# Generated at 2022-06-22 14:59:06.145834
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:18.382897
# Unit test for function main
def test_main():
    from .compiler import compile_files
    from . import const
    from .conf import init_settings
    from . import exceptions
    from . import messages
    import sys
    import shutil
    import os
    import filecmp

    def rm_dir(dirname):
        shutil.rmtree(dirname)
        if not os.path.exists(dirname):
            return True
        return False


# Generated at 2022-06-22 14:59:19.002519
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 14:59:29.405356
# Unit test for function main
def test_main():
    main(indent=4)

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:30.789206
# Unit test for function main
def test_main():
    ...

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:37.546690
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards","-i","C:/Users/Ruslan/Desktop/СПбПУ/5 курс/Никита/файлы для тестирования/test3.py","-o","test3.py","-t","CPython 2.7","-r","C:/Users/Ruslan/Desktop/СПбПУ/5 курс/Никита/файлы для тестирования/"]
    assert main() == 0

# Generated at 2022-06-22 14:59:47.248367
# Unit test for function main
def test_main():
    # Check that we terminate with error code 1
    # if an exception is raised
    with patch('argparse.ArgumentParser.parse_args', side_effect=Exception()):
        assert main() == 1

    # Check no exception
    with patch('argparse.ArgumentParser.parse_args',
               return_value=Mock(input=[], output='foo', target='python27')):
        assert main() == 0

    # Check syntax error exception
    with patch('argparse.ArgumentParser.parse_args',
               return_value=Mock(input=[], output='foo', target='python27')), \
            patch('pybackwards.compiler.compile_files',
                  side_effect=exceptions.CompilationError('path', 'message')):
        assert main() == 1

    # Check transformation error exception

# Generated at 2022-06-22 14:59:49.247781
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-22 14:59:50.318806
# Unit test for function main
def test_main():
    assert main() != None

# Generated at 2022-06-22 14:59:58.821607
# Unit test for function main
def test_main():
    from . import conf
    init_settings('-i python -o python -t python3 -r python'.split())
    for _, _, files in os.walk('python'):
        files.sort()
        for file in files:
            conf.settings.input = 'python/' + file
            conf.settings.output = 'python_new/' + file
            main()
    import filecmp
    result = filecmp.dircmp('python', 'python_new')
    result.report_full_closure()
    assert filecmp.cmp('python/test.py', 'python_new/test.py')

# Generated at 2022-06-22 14:59:59.699711
# Unit test for function main
def test_main():
    assert main() == -1

# Generated at 2022-06-22 15:00:11.480654
# Unit test for function main
def test_main():
    init_settings(parser.parse_args([
        '-i',
        'tests/input_files',
        '-o',
        'output',
        '-t',
        'python37',
        '-r',
        'tests/root'
    ]))
    assert main() == 0
    init_settings(parser.parse_args([
        '-i',
        'tests/input_files',
        '-o',
        'output',
        '-t',
        'python35',
        '-r',
        'tests/root'
    ]))
    assert main() == 0

# Generated at 2022-06-22 15:00:13.040200
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 15:00:36.818020
# Unit test for function main
def test_main():
    # pylint: disable=protected-access
    from .conf import _settings
    assert main() == 0
    assert _settings.input == []
    assert _settings.output == ''
    assert _settings.target == ''
    assert _settings.root == ''
    assert _settings.debug == False

# Generated at 2022-06-22 15:00:39.986469
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', './tests/src/test.py', '-o', 'out', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-22 15:00:47.869134
# Unit test for function main
def test_main():
    from .conf import settings
    settings.verbose = False
    settings.debug = False
    settings.root = None
    settings.data_dir = 'tests/data'
    ret = main(['-i', 'tests/data/examples/ex1.py', '-o', 'tests/ex1.py', '-t', '2.7'])
    assert ret == 0
    ret = main(['-i', 'tests/data/examples/ex3/ex3.py', '-o', 'tests/ex3.py', '-t', '2.7', '-r', 'tests/data/examples'])
    assert ret == 0

    # Non-existing input file

# Generated at 2022-06-22 15:00:49.260791
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:50.223383
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:55.351811
# Unit test for function main
def test_main():
    # test with valid arguments
    args = '-i tests/data/input/target_valid.py -o test/data/output/' \
           'target_valid.py -t python36 -r tests/data'
    sys.argv = args.split()
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:05.640023
# Unit test for function main
def test_main():
    assert main(["-i", "tests\\test_data\\compiled_module_only.py",
                 "-o", "tests\\test_data\\compiled_module_only_out.py",
                 "-t", "3.5",
                 "-r", "tests\\test_data\\source_root",
                 "-d"]) == 0
    assert main(["-i", "tests\\test_data\\compiled_module_only.py",
                 "-o", "tests\\test_data\\compiled_module_only_out.py",
                 "-t", "3.5",
                 "-r", "tests\\test_data\\source_root",
                 "-d"]) == 0

# Generated at 2022-06-22 15:01:17.357700
# Unit test for function main
def test_main():
    from .compiler import compile_files
    import os, shutil
    from .conf import init_settings
    from . import const
    init_settings(None)
    # Code taken from https://stackoverflow.com/a/28033360
    current_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(current_dir)
    try:
        # Delete folder if exists
        shutil.rmtree("__pycache__")
    except FileNotFoundError:
        pass
    # Check for import
    # TODO: It's very strange, but without compile_files in main function, it
    # doesn't work

# Generated at 2022-06-22 15:01:20.006274
# Unit test for function main
def test_main():
    with pytest.raises(TypeError) as errinfo:
        main()

if __name__ == '__main__':
    sys.exit(main() or 0)

# Generated at 2022-06-22 15:01:24.232194
# Unit test for function main
def test_main():
    input = "hello_world.py"
    output = "output"
    target = "python37"
    root = None
    debug = False
    
    
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:03.076888
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

# Generated at 2022-06-22 15:02:07.297678
# Unit test for function main
def test_main():
    init_settings(ArgumentParser().parse_args([]))
    # Try to run compilation on non-existing file
    with pytest.raises(SystemExit):
        main()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:08.244646
# Unit test for function main
def test_main():
    os.system("python3 -m pytest tests")

# Generated at 2022-06-22 15:02:19.971141
# Unit test for function main
def test_main():
    # if no data is passed, provide a help message
    buffer = io.StringIO()
    sys.stdout = buffer
    try:
        main()
        assert False
    except SystemExit:
        assert buffer.getvalue().startswith('usage: py-backwards')
    finally:
        sys.stdout = sys.__stdout__

    # if the target is not choosen, the target is invalid
    buffer = io.StringIO()
    sys.stdout = buffer
    try:
        main(['-i', 'input', '-o', 'output', '-t'])
        assert False
    except SystemExit:
        assert buffer.getvalue().startswith('usage: py-backwards')
    finally:
        sys.stdout = sys.__stdout__

    # if the input is not passed, the

# Generated at 2022-06-22 15:02:25.268201
# Unit test for function main
def test_main():
    import argparse
    with open('tests/output.txt', 'w') as result:
        if main() == 0:
            result.write('Compilation was finished successfully')
            sys.exit(0)
        else:
            result.write('there were some errors during compilation')
            sys.exit(1)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:30.842882
# Unit test for function main
def test_main():
    init_settings(args)
    init_settings()
    args.input = 'test.py'
    args.output = 'test_output.py'
    args.target = '2.7'
    args.root = 'root_dir'
    args.debug = False

    try:
        result = compile_files(args.input, args.output,
                               const.TARGETS[args.target],
                               args.root)
    except exceptions.CompilationError as e:
        assert e
    except exceptions.TransformationError as e:
        assert e
    except exceptions.InputDoesntExists:
        assert e
    except exceptions.InvalidInputOutput:
        assert e
    except PermissionError:
        assert e
    assert result

# Generated at 2022-06-22 15:02:43.035857
# Unit test for function main
def test_main():
    sys.argv[1:] = ['--input', 'source', '--output', 'output', '--target', '2.7', '--root', 'source']
    with patch('argparse.ArgumentParser',
               side_effect=lambda *args, **kwargs: mock_argument_parser()) as mocked_argument_parser, \
            patch('py_backwards.compiler.compile_files', side_effect=lambda *args, **kwargs: {}) as mocked_compile_files:
        assert main() == 0
        mocked_argument_parser.assert_called_once_with(
            'py-backwards',
            description='Python to python compiler that allows you to use some '
                        'Python 3.6 features in older versions.')

# Generated at 2022-06-22 15:02:48.515788
# Unit test for function main
def test_main():
    with patch('sys.argv', ['py-backwards', '-i', 'test_data/test.py', '-o', 'test_data/test.py.out','-t', '2.7']):
        assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:58.900755
# Unit test for function main
def test_main():
    import sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def dummy_stdin():
        saved_stdin = sys.stdin
        sys.stdin = StringIO('given string')
        yield
        sys.stdin = saved_stdin

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-22 15:02:59.412625
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:04:26.662009
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:04:28.047590
# Unit test for function main
def test_main():
    msg = main()
    assert msg == 0


# Generated at 2022-06-22 15:04:29.094383
# Unit test for function main
def test_main():
    import pytest
    assert main() == 0

# Generated at 2022-06-22 15:04:31.315715
# Unit test for function main
def test_main():
    assert main() == 0 #need to write correct test

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:36.950395
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['py-backwards.py', '-i', 'infile.py',
                '-o', 'outdir', '-t', '3.6']
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:45.361236
# Unit test for function main
def test_main():
    # Arrange
    argv = [sys.executable, 'pybackwards',
            '-t', '3.5',
            '-i', '/home/test/test.py',
            '-o', '/home/test/output.py']
    settings = init_settings(argparse.Namespace())
    settings.input = ['/home/test/test.py']
    settings.output = '/home/test/output.py'
    settings.source_root = '/home/test/'
    settings.target = const.TARGETS['3.5']
    settings.is_debug = False

    # Act
    main()

    # Assert
    # TODO: How to check if stdout is correct?

# Generated at 2022-06-22 15:04:47.294838
# Unit test for function main
def test_main():
    init_settings(ArgumentParser().parse_args(['--input', 'input/test.py',
                                               '--output', 'output/test.py',
                                               '--target', '3.5']))

# Generated at 2022-06-22 15:04:50.498318
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'some.txt', '-o', 'result.txt', '-t', '2.7' ]
    assert main() == 0

# Generated at 2022-06-22 15:04:57.197737
# Unit test for function main
def test_main():

    args = ['py-backwards',
            '-i', 'examples/test.py',
            '-o', 'examples/test_result.py',
            '-t', '2',
            '-r', 'examples/test.py']

    import pytest
    with pytest.raises(SystemExit) as exec:
        main()

    assert 0 == exec.value.code


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:05:02.410637
# Unit test for function main
def test_main():
    try:
        args = sys.argv
        sys.argv = ['py-backwards', '-i', 'tests/input/', '-o', 'tests/output/', '-t', '2.7', '-d', '-r', 'tests']
        assert main(), 0
        sys.argv = args
    except AssertionError:
        assert False

# Generated at 2022-06-22 15:08:28.824914
# Unit test for function main
def test_main():
    INPUT = 'myfile.py'
    OUTPUT = 'output/myfile.py'
    TARGET = '3.6'
    ROOT = None
    DEBUG = False

    pass


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 15:08:29.314137
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:08:31.808132
# Unit test for function main
def test_main():
    sys.argv = ['py_backwards.py', '-i', '../examples/', '-o', '../examples_out/', '-t', '2.7']
    main()