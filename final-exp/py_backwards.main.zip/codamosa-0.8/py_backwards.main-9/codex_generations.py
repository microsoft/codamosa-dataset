

# Generated at 2022-06-22 14:58:52.681160
# Unit test for function main
def test_main():
    # Argument parsing
    sys.argv[1:] = ["-i", "file1.py", "-o", "file2.py", "-t", "2.7", "-r", "."]
    assert main() == 0

    sys.argv[1:] = ["-i", "file1.py", "-o", "file2.py", "-t", "2.7"]
    assert main() == 0

    sys.argv[1:] = ["-i", "file1.py", "-o", "file2.py", "-t", "2.7", "-r"]
    assert main() == 0

    sys.argv[1:] = ["-i", "file1.py", "-o", "file2.py", "-r"]
    assert main() == 0


# Generated at 2022-06-22 14:58:56.927742
# Unit test for function main
def test_main():
    # When we call main
    sys.argv = ["", "-i", "tests/files/3.6/",
                "-o", "tests/files/3.6/", "-t", "3.6",
                "-r", "tests/files/3.6/"]
    result = main()
    # It should return 0
    assert result == 0


# Generated at 2022-06-22 14:58:57.824818
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 14:59:08.311140
# Unit test for function main
def test_main():
    import os
    from py_backwards.settings import TARGET_VERSION, ROOT
    from . import utils
    os.system('python py-backwards.py -i tests/test_1 -o test1.py -t 3.5')
    assert TARGET_VERSION == '3.5'
    assert ROOT is None
    assert os.path.isfile('test1.py')
    out = utils.run_program('test1.py')
    assert out == 'async def test_1(a, b):\n    return a + b + 1\ntest = test_1(1, 2)\nprint(test)\n'
    os.remove('test1.py')

# Generated at 2022-06-22 14:59:09.152640
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:11.312654
# Unit test for function main
def test_main():
    # Unit test for function should_transform

    # Unit test for function should_transform
    assert main() == 0

# Generated at 2022-06-22 14:59:21.513804
# Unit test for function main
def test_main():
    from pbw import run_main
    from .compiler import compile_files
    from . import const, settings, exceptions
    from .conf import init_settings

    settings.DEBUG = False

    init_settings({"input": ['tests/data'],
                   "output": 'tests/output',
                   "target": '2.7',
                   "root": 'tests',
                   "debug": False})

    try:
        compile_files('tests/data', 'tests/output',
                      const.TARGETS['2.7'], 'tests')
    except exceptions.CompilationError as e:
        print(e)
        assert False
    except exceptions.InputDoesntExists:
        print(e)
        assert False
    except exceptions.InvalidInputOutput:
        print(e)
        assert False

# Generated at 2022-06-22 14:59:22.515640
# Unit test for function main
def test_main():
    assert main([]) == 0

# Generated at 2022-06-22 14:59:24.130953
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:33.766622
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'test_programs/', '-o', 'test_output',
                    '-t', 'python2']
    # testing correct return type
    assert isinstance(main(), int)
    assert main() == 0

    sys.argv[1:] = ['-i', 'test_programs/', '-o', 'test_output',
                    '-t', 'python2']
    # testing correct return type with file instead of folder
    assert isinstance(main(), int)
    assert main() == 0
    
    sys.argv[1:] = ['-i', 'test_programs/', '-o', 'test_output',
                    '-t', 'no-python']
    # testing incorrect target
    assert isinstance(main(), int)
    assert main() == 1



# Generated at 2022-06-22 14:59:56.452285
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '--input', 'foo.py', '--output', 'out.py',
                '--target', '2.7', '--root', '.']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:03.780113
# Unit test for function main
def test_main():
  from unittest.mock import patch
  from .settings import settings
  from . import const, messages

  # Test for successful compilation
  with patch('argparse.ArgumentParser.parse_args',
             return_value=argparse.Namespace(
                input=['tests/test_data/bad_return.py'],
                output='output.py',
                debug=False,
                target='py34',
                root=None)),\
        patch('builtins.print', side_effect=lambda *args, **kwargs:
                                print(args[0], type(args[0]))),\
        patch('sys.stderr.write', side_effect=lambda *args, **kwargs:
                                  print(args[0], type(args[0]))):
    assert main() == 0

    assert settings.input

# Generated at 2022-06-22 15:00:14.029311
# Unit test for function main
def test_main():
    parser = ArgumentParser()
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str, nargs='+',
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')
    args = parser.parse_args()
   

# Generated at 2022-06-22 15:00:22.911220
# Unit test for function main
def test_main():
    from .conf import settings
    from . import main

    # Set up the test
    settings.input = 'test_compiler/input_1'
    settings.output = 'test_compiler/output_1'
    settings.target = '3.5'
    settings.root = None
    settings.debug = False
    main()

    # assert result

    # restore config
    settings.input = None
    settings.output = None
    settings.target = None
    settings.root = None
    settings.debug = False

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:25.981563
# Unit test for function main
def test_main():
    print("Test main function...")
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:26.579245
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:31.692503
# Unit test for function main
def test_main():
    test_argv = ['py-backwards',
                 '-i', 'folder_to_compile',
                 '-o', 'resulting_folder',
                 '-t', '2.7',
                 '-r', 'src',
                 '-d', '1']
    argv = sys.argv
    sys.argv = test_argv

    try:
        assert main() == 0
    finally:
        sys.argv = argv

# Generated at 2022-06-22 15:00:44.219496
# Unit test for function main
def test_main():
    sys.modules['__main__'].main = main
    
    # Using wrong parameter -i
    sys.argv = ['py-backwards', '-i', 'file_input.py', '-o', 'file_output.py', '-t', '2']
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        __main__.main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2
    
    # Using wrong parameter -o
    sys.argv = ['py-backwards', '-i', 'file_input.py', '-t', '2']
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        __main__.main()
    assert py

# Generated at 2022-06-22 15:00:45.089532
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:00:51.075543
# Unit test for function main
def test_main():
    # input:
    # -i: file
    # -o: file
    # -t: l
    # -r: root
    result = main(['-i', 'file', '-o', 'file', '-t', 'l', '-r', 'root'])
    assert result == 0


# Generated at 2022-06-22 15:01:11.263407
# Unit test for function main
def test_main():
    sys.argv = ['py_backwards.py', '-i', '-', '-o', '-', '-t', '2.7', '-r', '/']
    assert main() == 0

# Generated at 2022-06-22 15:01:11.839270
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:12.411998
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:16.588644
# Unit test for function main
def test_main():
    sys.argv = ["py_backwards", "-i", "test_data/formatted.py", "-o", "new.py",
                "-t", "3.5", "-r", "test_data"]
    assert main() == 0

# Generated at 2022-06-22 15:01:17.878008
# Unit test for function main
def test_main():
    return main()

# Generated at 2022-06-22 15:01:19.807315
# Unit test for function main
def test_main():
    assert type(main()) == int
    
if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 15:01:24.728361
# Unit test for function main
def test_main():
    args = main(['-i', 'in_file', 'out_file', '-t', '2.7'])
    assert args.input == 'in_file'
    assert args.output == 'out_file'
    assert args.target == '2.7'
    assert args.debug == False

# Generated at 2022-06-22 15:01:35.193701
# Unit test for function main
def test_main():
    # inputs:
    # 1. Call main function with required argument -t, -i, -o
    # 2. Call main function with missing required argument -t
    # 3. Call main function with missing required argument -i
    # 4. Call main function with missing required argument -o
    # 5. Call main function with wrong argument value -t
    # 6. Call main function with invalid command argument
    assert main() == 0
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(['-i', 'input.py'])
    assert pytest_wrapped_e.type == SystemExit
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(['-t', const.TARGETS.keys()[0], '-o', 'out.py'])


# Generated at 2022-06-22 15:01:45.768609
# Unit test for function main
def test_main():
    input_ = 'tests/test_in_1.py'
    output = 'tests/test_out_1.py'
    parser = ArgumentParser()
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-22 15:01:49.255221
# Unit test for function main
def test_main():
    sys.argv = [
        "py-backwards",
        "...",
        "-t",
        "python36",
        "-i",
        "./tests/example_files/py36_code.py",
        "-o",
        "./tests/example_files/py36_code_out.py"
    ]
    assert main() == 0

# Generated at 2022-06-22 15:02:31.107973
# Unit test for function main
def test_main():
    import os
    # Test with non-existent input file
    result = os.system('python -m py_backwards -i none -o test -t python2.7')
    assert result != 0

    # Test with non-existent target
    result = os.system('python -m py_backwards -i test -o test -t python3.9')
    assert result != 0

    # Test with invalid output
    result = os.system('python -m py_backwards -i test -o test/test/test -t python3.9')
    assert result != 0

    # Test with valid input and output
    result = os.system('python -m py_backwards -i test/test_files/test.py -o test/test_files/test.py -t python2.7')
    assert result == 0


# Generated at 2022-06-22 15:02:32.893653
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:38.123824
# Unit test for function main
def test_main():
    import os
    import pytest
    from py_backwards.compiler import compile_files
    from py_backwards.utils import defaults

    SOURCE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                              '..', 'test', 'fixtures'))
    for fname in os.listdir(SOURCE_DIR):
        if not fname.endswith('.py') or os.path.basename(fname) in {'__init__.py',
                                                                    'partial_bracket_syntax.py',
                                                                    'async_in_comprehensions.py',
                                                                    'async_in_list_comprehension.py'}:
            continue


# Generated at 2022-06-22 15:02:39.488861
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:40.261836
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:02:41.147615
# Unit test for function main
def test_main():
    assert(main() == 1)

# Generated at 2022-06-22 15:02:45.378706
# Unit test for function main
def test_main():
    test_args = ['--input', 'test.py', '--output', 'out.py', '--target', 'python2']
    with patch('sys.argv', test_args):
        assert main() == 1

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 15:02:47.346961
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:49.065304
# Unit test for function main
def test_main():
    assert main() == 0
    assert main('-h') == 1


# Generated at 2022-06-22 15:02:52.715752
# Unit test for function main
def test_main():
    # Test case 1: Invalid input
    sys.argv = [sys.argv[0],
                '-i', 'def',
                '-o', 'def',
                '-t', '3.6']

    with pytest.raises(SystemExit):
        main()

    # Test case 2: Invalid input
    sys.argv = [sys.argv[0],
                '-i', 'def',
                '-o', 'def',
                '-t', '3.6']

    with pytest.raises(SystemExit):
        main()

    # Test case 3: Invalid input
    sys.argv = [sys.argv[0],
                '-i', 'def',
                '-o', 'def',
                '-t', '3.7']


# Generated at 2022-06-22 15:04:21.064745
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'main.py', '-o', 'main_compiled.py', '-t', '2']
    assert main() == 0

# Generated at 2022-06-22 15:04:21.847139
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:04:22.666209
# Unit test for function main
def test_main():
    #nothing to test here
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:25.766183
# Unit test for function main
def test_main():
    argv = sys.argv
    sys.argv = ['py-backwards', '-i', 'test_data/input', '-o',
                'test_data/output', '-t', '3.5', '-r', 'test_data/']
    result = main()
    sys.argv = argv
    assert result == 0

# Generated at 2022-06-22 15:04:37.077536
# Unit test for function main
def test_main():
    import unittest.mock
    from collections import namedtuple
    from . import conf, exceptions
    from . import messages

    class TestError(Exception):
        pass

    class TestClass:
        def __init__(self):
            self.counter = 0

        def error(self, e):
            self.counter += 1
            if self.counter <= 3:
                raise TestError()

    input_ = namedtuple('input', ['input', 'output', 'target'])

# Generated at 2022-06-22 15:04:37.865853
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:04:46.845963
# Unit test for function main
def test_main():
    print('Testing function main')
    try:
        assert main() == 1
    except SystemExit:
        pass

    sys.argv = [sys.argv[0], '-i', 'test/fixtures/test_main/test_i.py', '-o', 'test/fixtures/test_main/test_tmp.py', '-t', '3.4']
    try:
        assert main() == 0
    except SystemExit:
        pass

    sys.argv = [sys.argv[0], '-i', 'test/fixtures/test_main/test_i.py', '-o', 'test/fixtures/test_main/test_tmp.py', '-t', '3.6']
    try:
        assert main() == 0
    except SystemExit:
        pass


# Generated at 2022-06-22 15:04:50.290560
# Unit test for function main
def test_main():
    try:
        main()
    except AssertionError as e:
        print(e, file=sys.stderr)
        return 1

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-22 15:04:52.330084
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:05:02.576471
# Unit test for function main
def test_main():
    # test if '-h' is showing help message
    command = [sys.executable, 'main.py', '-h']
    r = subprocess.check_output(command, stderr=subprocess.STDOUT)
    assert b'usage: py-backwards' in r
    assert b'compile' in r

    # test if 'compile' is calling the compiler
    command = [sys.executable, 'main.py', 'compile']
    r = subprocess.check_output(command, stderr=subprocess.STDOUT)
    assert b'usage: py-backwards' in r

    # test for error with wrong argument type

# Generated at 2022-06-22 15:08:38.268375
# Unit test for function main
def test_main():
    from . import conf
    from . import const
    from .exceptions import CompilationError, TransformationError, InputDoesntExists, InvalidInputOutput, PermissionError
    from .compiler import compile_files

    def mock_compile_files(input, output, target, root):
        return 1

    def mock_init_settings(args):
        pass

    def mock_messages_invalid_output(input, output):
        return "messages.invalid_output"

    def mock_messages_input_doesnt_exists(input):
        return "messages.input_doesnt_exists"

    def mock_messages_permission_error(output):
        return "messages.permission_error"
