

# Generated at 2022-06-22 14:58:56.421699
# Unit test for function main
def test_main():
    class config:
        def __init__(self):
            self.input = ['test_data/test.py', 'test_data/test2.py']
            self.output = 'test_data/output'
            self.target = 'py27'
            self.root = 'test_data'
            self.debug = True

    import sys
    sys.argv = ['', '-i', 'test_data/test.py', 'test_data/test2.py',
                '-o', 'test_data/output', '-t', 'py27', '-r', 'test_data',
                '-d']
    sys.exit(main())

# Generated at 2022-06-22 14:58:57.607618
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 14:59:02.235071
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'other_source.py', '-o', 'test.py', '-t', '3.5',
              '-r', 'source.py']
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 14:59:05.352919
# Unit test for function main
def test_main():
    sys.argv[1:] = [
        '-i', '/dev/null',
        '-o', '/dev/null',
        '-t', '27'
    ]

    assert main() == 1

    sys.argv[1:] = [
        '-i', '/dev/null',
        '-o', '/dev/null',
        '-t', '36'
    ]

    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:09.486856
# Unit test for function main
def test_main():
    # Case with invalid target
    argv = ['-i', 'test.py', '-o', 'test_output.py', '-t', 'python39', '-d']
    if main(argv) != 2:
        raise AssertionError('Invalid target test failed')
    # Case with input doesn't exists
    argv = ['-i', 'test_input.py', '-o', 'test_output.py', '-t', 'python33',
            '-d']
    if main(argv) != 1:
        raise AssertionError('Input doesn\'t exists test failed')
    # Case with invalid input and output
    path = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-22 14:59:20.510269
# Unit test for function main
def test_main():
    # Unit test for function main
    if sys.argv[1:]:
        sys.argv[1:] = []
    else:
        del sys.argv[1:]
    assert main() == 2

    sys.argv.append('-h')
    assert main() == 0

    sys.argv.extend(['-i', 'test/test_data/linear2.py', '-o', 'py-backwards.out',
                     '-t', '3.5', '-r', 'test/test_data/'])
    assert main() == 0

    sys.argv.extend(['-d'])
    assert main() == 0

    sys.argv.extend(['-r', 'test'])
    assert main() == 0


# Generated at 2022-06-22 14:59:23.047615
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 14:59:30.425025
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "test/test_data/test_1/test.py",
    "-o", "test/test_data/test_1/test_output.py", "-t", "27", "-d"]
    assert main() == 0
    sys.argv = ["py-backwards", "-i", "test/test_data/test_2/test.py",
    "-o", "test/test_data/test_2/test_output.py", "-t", "36", "-d"]
    assert main() == 0

# Generated at 2022-06-22 14:59:38.006536
# Unit test for function main
def test_main():

    from .conf import init_settings
    from .exceptions import CompilationError, InputDoesntExists,\
                              InvalidInputOutput, PermissionError,\
                              TransformationError

    def test(input_: str, output: str, root: str = '.',
             target: str = '3.6', debug: bool = False,
             raise_exception: type = None, raise_msg: str = ''):
        init_settings(ArgumentParser('').parse_args())

        argv = [
            'py-backwards',
            '-i', input_,
            '-o', output,
            '-t', target,
            '-r', root,
        ]
        if debug:
            argv.append('-d')


# Generated at 2022-06-22 14:59:39.567826
# Unit test for function main
def test_main():
    # assert main() == 0
    assert 0

# Generated at 2022-06-22 14:59:59.740041
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from . import exceptions
    def mock_parse_args(*args, **kwargs):
        class Args:
            input = ['test/test_data/test.py']
            output = 'out'
            target = 'python2'
            root = 'test'
            debug = False
        return Args()

    with patch('py_backwards.main.main.compile_files') as m, \
         patch('py_backwards.main.main.init_settings'), \
         patch('py_backwards.main.main.parser.parse_args', side_effect=mock_parse_args):
        m.side_effect = exceptions.InputDoesntExists()
        assert main() == 1
        m.side_effect = exceptions.InvalidInputOutput()

# Generated at 2022-06-22 15:00:01.679726
# Unit test for function main
def test_main():
    if not main() == 0:
        raise Exception('Function main failed')

if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-22 15:00:13.045456
# Unit test for function main
def test_main():
    # 1. Test -h option
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        sys.argv = ['main.py', '-h']
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

    # 2. Test -i, -o, -t -d options with invalid input, output, target
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        sys.argv = ['main.py', '-d', '-i', './test/input/invalid/', '-o',
                    './test/input/invalid.py', '-t', '3.5']
        main()
    assert pytest_wrapped_e.type == System

# Generated at 2022-06-22 15:00:14.403293
# Unit test for function main
def test_main():
    result = main()
    assert result != 0, "Main function failed"

# Generated at 2022-06-22 15:00:26.446159
# Unit test for function main
def test_main():
    # Function takes no arguments, but we want an ArgumentParser instance
    # for testing purposes.
    parser = ArgumentParser('py-backwards')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')
    args = parser.parse_args()
    # init_settings(args)
    # The line above has the effect of setting the module const.DEBUG to
    # the value of parser's debug var, i.e., const.DEBUG is True.  This

# Generated at 2022-06-22 15:00:33.165128
# Unit test for function main
def test_main():
    from collections import deque
    from io import StringIO
    from unittest import TestCase
    from tempfile import TemporaryDirectory

    class Test(TestCase):

        def setUp(self):
            self.old_sys_argv = sys.argv
            self.old_sys_stdout = sys.stdout
            self.old_sys_stderr = sys.stderr
            sys.stdout = StringIO()
            sys.stderr = StringIO()
            self.tempdir = TemporaryDirectory()

        def tearDown(self):
            sys.argv = self.old_sys_argv
            sys.stdout = self.old_sys_stdout
            sys.stderr = self.old_sys_stderr
            self.tempdir.cleanup()


# Generated at 2022-06-22 15:00:34.192755
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:42.131566
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('C:\\Users\\ilya\\PycharmProjects\\py-backwards\\tests\\test.py')
    sys.argv.append('-o')
    sys.argv.append('C:\\Users\\ilya\\PycharmProjects\\py-backwards\\tests\\test_compiled.py')
    sys.argv.append('-t')
    sys.argv.append('2.7')
    assert main() == 0

# Generated at 2022-06-22 15:00:45.431608
# Unit test for function main
def test_main():
    argv = sys.argv
    sys.argv = argv + ['test_main.py']
    assert main() == 0
    sys.argv = argv


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:50.644507
# Unit test for function main
def test_main():
    """
    Проверяет доступность главной функции.
    """
    assert main() == 0

# Generated at 2022-06-22 15:01:12.834603
# Unit test for function main
def test_main():
    class Args:
        def __init__(self, input, output, target, root, debug):
            self.input = input
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    args = Args(['test.py'], 'test.out', '3.5', '.', True)
    assert main(args) == 0



# Generated at 2022-06-22 15:01:13.730257
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:01:22.046415
# Unit test for function main
def test_main():
    """
    Test that invalid inputs and outputs are handled, using monkeypatch
    :return:
    """
    import pybackwards
    sys.argv = [__file__, '-i', 'xxx', '-o', __file__, '-t', '3.5']

    pybackwards.messages.invalid_output = lambda x, y: "Invalid input"

    assert main() == 1

    sys.argv = [__file__, '-i', 'xxx', '-o', __file__, '-t', '3.5']

    pybackwards.messages.input_doesnt_exists = lambda x: "Input does not exist"

    assert main() == 1

# Generated at 2022-06-22 15:01:33.271747
# Unit test for function main
def test_main():
    import tempfile
    import os
    from .compiler import compile_files

    assert main() == 1

    # Help message
    assert main(['-h']) == 0

    # Failed compilation
    assert main(['--input', __file__, '--output', 'temp.out', '--target', '2',
                 '--root', 'root']) == 1

    # Successful compilation
    temp_file = tempfile.mktemp()
    compile_files(__file__, temp_file, (2, 7))
    assert os.path.exists(temp_file)
    os.remove(temp_file)

    # Invalid output
    assert main(['--input', __file__, '--output', __file__, '--target', '2',
                 '--root', 'root']) == 1

    # Invalid input

# Generated at 2022-06-22 15:01:39.701803
# Unit test for function main
def test_main():
    sys.argv[1:] = []
    sys.argv[1:] = ['--input', 'test_1', '--output', 'test_1_out', '--target', '3']
    sys.argv[1:] = ['--input', 'test_2', '--output', 'test_2_out', '--target', '2']
    sys.argv[1:] = ['--input', 'test_3', '--output', 'test_3_out', '--target', '2']
    sys.argv[1:] = ['--input', 'test_4', '--output', 'test_4_out', '--target', '3']

# Generated at 2022-06-22 15:01:49.354724
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'sample/spam.py', 'sample/', '-o', 'sample/back/', '-t', 'py26', '-r', '.']
    sys.argv = ['py-backwards', '-i', 'sample/discogs_spam.py', 'sample/', '-o', 'sample/back/', '-t', 'py27', '-r', '.']
    sys.argv = ['py-backwards', '-i', 'sample/discogs.py', 'sample/', '-o', 'sample/back/', '-t', 'py26', '-r', '.']

# Generated at 2022-06-22 15:01:58.136968
# Unit test for function main
def test_main():
    assert main(['-i', 'tests/inputs/grandfather.py',
                 '-o', 'tests/outputs/grandfather.py',
                 '-t', 'py36',
                 '-r', 'tests/inputs/']) == 0
    assert main(['-i', 'tests/inputs/grandfather.py',
                 '-o', 'tests/outputs/grandfather.py',
                 '-t', 'py33',
                 '-r', 'tests/inputs/']) == 0
    assert main(['-i', 'tests/inputs/grandfather.py',
                 '-o', 'tests/outputs/grandfather.py',
                 '-t', 'py36',
                 '-r', 'tests/inputs/'
                 '-d']) == 0

# Generated at 2022-06-22 15:02:04.569865
# Unit test for function main
def test_main():
    exit = main(['py-backwards', '-i', 'test/test.py', '-o', 'test/output.py', '-t', '2'])
    assert exit == 0
    exit = main(['py-backwards', '-i', 'test/test.py', '-o', 'test/output.py', '-t', '3'])
    assert exit == 0

# Generated at 2022-06-22 15:02:15.224227
# Unit test for function main
def test_main():
    from .compiler import get_list_of_files, compile_file
    from .conf import settings
    import os
    import shutil

    def get_args() -> ArgumentParser:
        parser = ArgumentParser(
            'py-backwards',
            description='Python to python compiler that allows you to use some '
                        'Python 3.6 features in older versions.')
        parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                            help='input file or folder')
        parser.add_argument('-o', '--output', type=str, required=True,
                            help='output file or folder')

# Generated at 2022-06-22 15:02:26.800435
# Unit test for function main
def test_main():
    from tempfile import TemporaryDirectory
    from .ast import PythonFile
    from .conf import settings
    from . import const, messages

    with TemporaryDirectory() as tmpdir:
        settings.input = [
            'examples/method_in_class/src/class_with_method/main.py',
        ]
        settings.output = tmpdir
        settings.target = const.TARGETS['python2']
        settings.root = 'examples/method_in_class/src/'
        settings.debug = False

# Generated at 2022-06-22 15:03:07.617353
# Unit test for function main
def test_main():
    output = main()
    assert output == 0

if __name__ == "__main__":
    import os

    folder = os.path.dirname(os.path.abspath(__file__))
    sys.exit(main(sys.argv[1:]))

# Generated at 2022-06-22 15:03:08.254567
# Unit test for function main
def test_main():
    return

# Generated at 2022-06-22 15:03:19.680159
# Unit test for function main
def test_main():
    # This should return 0
    assert main(["-i", "tests/data/tree/a.py", "-o", "out/ok.py",
                 "-t", "python36", "-r", "tests/data/tree"]) == 0

    # This should throw 'Incorrect input' error
    assert main(["-i", "tests/data/tree/a.py", "-o", "out/incorrect-input-error.py",
                 "-t", "python36", "-r", "tests/data/tree", "-d", "True"]) == 1

    # This should throw 'Input doesn't exists' error

# Generated at 2022-06-22 15:03:29.807854
# Unit test for function main
def test_main():
    import io
    import sys
    sys.argv = [sys.argv[0]]
    sys.argv.extend(['-i', './test_file.py'])
    sys.argv.extend(['-o', './output'])
    sys.argv.extend(['-t', '2.7'])

    capturedOutput = io.StringIO()           # Create StringIO object
    sys.stdout = capturedOutput                     # and redirect stdout.
    main()                                           # Call function.
    sys.stdout = sys.__stdout__                      # Reset redirect.
    assert capturedOutput.getvalue() == 'Nothing to compile\n'

    capturedOutput = io.StringIO()           # Create StringIO object
    sys.stdout = capturedOutput                     # and redirect stdout.
    sys.arg

# Generated at 2022-06-22 15:03:30.663588
# Unit test for function main
def test_main():
    init_settings('')
    pass

# Generated at 2022-06-22 15:03:40.994849
# Unit test for function main
def test_main():
    # 1. Test input file that doesn't exists
    args = ['-i', 'non-existent.py', '-o', 'test/test_files/test_main/output',
            '-t', 'py27', '-r', 'test/test_files']
    try:
        with pytest.raises(SystemExit):
            main(args)
    except:
        pass

    # 2. Test invalid output path
    args = ['-i', 'test/test_files/test_main/input.py',
            '-o', 'test/te..st_files/test_main/output', '-t', 'py27',
            '-r', 'test/test_files']
    try:
        with pytest.raises(SystemExit):
            main(args)
    except:
        pass

    #

# Generated at 2022-06-22 15:03:49.402811
# Unit test for function main
def test_main():
    output_file = open('test.py', 'w')
    sys.stdout = output_file

    input_str = 'test.py'
    output_str = 'test.py'
    target_str = '3.3'
    root_str = '.'

    sys.argv[1] = '-i'
    sys.argv[2] = input_str
    sys.argv[3] = '-o'
    sys.argv[4] = output_str
    sys.argv[5] = '-t'
    sys.argv[6] = target_str
    sys.argv[7] = '-r'
    sys.argv[8] = root_str

    main()

    output_file.close()

# Generated at 2022-06-22 15:03:52.110363
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main(['-h'])
        main(['-i', 'foo', '-o', 'bar', '-t', '3.5'])

# Generated at 2022-06-22 15:03:53.478261
# Unit test for function main
def test_main():
    from .tests import test_main
    assert test_main() == 0

# Generated at 2022-06-22 15:03:55.083070
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:05:22.725614
# Unit test for function main
def test_main():
    with patch('builtins.print'):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:05:23.182109
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:05:27.424978
# Unit test for function main
def test_main():
    # test_positive
    main()
    main(['-i','test_main','-o','test_main','-t','test_main','-r','test_main','-d'])
    # test_negative
    main(['-i','test_main'])
    main(['-o','test_main'])
    main(['-t','test_main'])
    main(['-r','test_main'])
    main(['-d'])
    main(['-i','test_main','-o','test_main'])
    main(['-i','test_main','-t','test_main'])
    main(['-i','test_main','-r','test_main'])
    main(['-i','test_main','-d'])

# Generated at 2022-06-22 15:05:28.660614
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print("test passed")

# Generated at 2022-06-22 15:05:29.247936
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:05:40.874339
# Unit test for function main
def test_main():

    # Args Input Output Root Target Debug
    # 1
    args = ['input_1.py', '-i', 'input_1', 'input_2', '-o', 'output_folder', '-r', 'root_folder', '-t', 'py2', '-d']

    with patch('sys.argv', args):
        assert main() == 0

    # 2
    args = ['input_2.py', '-i', 'input_1', 'input_2', '-o', 'output_folder', '-r', 'root_folder', '-t', 'py3', '-d']

    with patch('sys.argv', args):
        assert main() == 0

    # 3

# Generated at 2022-06-22 15:05:43.587855
# Unit test for function main
def test_main():
    init_settings(vars(ArgumentParser().parse_args(['-i', 'tests/files/',
                                                    '-o', 'out/',
                                                    '-t', '2.7',
                                                    '-r', ''])))
    assert main() == 0

# Generated at 2022-06-22 15:05:51.970345
# Unit test for function main
def test_main():
    import io
    import sys
    sys.argv = ['main.py', '-i', 'test', '-o', 'output', '-t', 'python35']
    fout = io.StringIO()
    with redirect_stdout(fout):
        main()
    output = fout.getvalue()
    assert output == (termcolor.colored('Компиляция прошла успешно!\n', 'green'))


# Generated at 2022-06-22 15:06:00.873830
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'C:\\Users\\Илья\\PycharmProjects\\pybackwards\\tests\\test_data\\simple', '-o',
                'C:\\Users\\Илья\\PycharmProjects\\pybackwards\\tests\\test_data\\result',
                '-t', 'py34', '-r', 'C:\\Users\\Илья\\PycharmProjects\\pybackwards\\tests\\test_data\\simple',
                '-d']

    main()
    assert True

# Generated at 2022-06-22 15:06:11.069744
# Unit test for function main
def test_main():
    argv = sys.argv.copy()
    sys.argv = [argv[0],
                '-i', 'test_compiler',
                '-o', 'test_compiler/out',
                '-t', 'py57',
                '-r', 'test_compiler'
                ]

    messages.main_filename = 'test_compiler/out/test_file.py'
    messages.compilation_error_in_line = 'test_file.py'
    messages.test_syntax_error = 'test_compiler/out/test_file.py'
    messages.test_transformation_error = 'test_compiler/out/test_file.py'
    messages.test_input_doesnt_exists = 'test_doentexists/test'
    messages.test_invalid