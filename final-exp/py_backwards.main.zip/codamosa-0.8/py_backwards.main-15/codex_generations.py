

# Generated at 2022-06-22 14:58:45.885650
# Unit test for function main
def test_main():
    # Create a parser to get the arguments
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-22 14:58:56.120287
# Unit test for function main
def test_main():
    import io
    import os
    import sys
    import tempfile
    from contextlib import redirect_stdout, redirect_stderr

    import py_backwards.conf

    fd, dest = tempfile.mkstemp()
    with redirect_stderr(io.StringIO()) as stderr, \
            redirect_stdout(io.StringIO()) as stdout:
        assert main(['-i', os.path.dirname(__file__) + '/test_input',
                     '-o', dest, '-t', '2', '-r',
                     os.path.dirname(__file__) + '/test_input']) == 0
        stdout.seek(0)
        assert stdout.read() == 'Compiling finished successfully\n'
    os.remove(dest)


# Generated at 2022-06-22 14:59:06.732604
# Unit test for function main
def test_main():
    try:
        """
        Testing for wrong input
        """
        # input should not be empty
        sys.argv = ['-i', '', '', '']
        main()
    except SystemExit as e:
        assert e.code == 2
    try:
        # target should exist in const.TARGETS list
        sys.argv = ['-i', '__init__.py', '-t', 'v42', '-o', '__output__.py',
                    '-d']
        main()
    except SystemExit as e:
        assert e.code == 2


# Generated at 2022-06-22 14:59:18.739712
# Unit test for function main
def test_main():
    # Test for invalid options
    output = StringIO()
    sys.stdout = output
    main()
    sys.stdout = sys.__stdout__
    pattern_error_options = r'\[ERROR\]\s+The following arguments are required: -i\/--input, -o\/--output, -t\/--target$'
    assert re.search(pattern_error_options, output.getvalue()) is not None
    output.close()

    # Test for invalid target
    output = StringIO()
    sys.stdout = output
    main(['', '-i', 'main.py', '-o', 'output', '-t', 'Python 7.0'])
    sys.stdout = sys.__stdout__

# Generated at 2022-06-22 14:59:21.181062
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/simple.py', 'tests/folder', '-o', 'test.py',
                    '-t', '3.0']
    main()

# Generated at 2022-06-22 14:59:22.210116
# Unit test for function main
def test_main():
    assert main() == 0, "Should be 0"

# Generated at 2022-06-22 14:59:23.754976
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:28.721751
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.argv = [sys.argv[0], '-i', './test/test_files/test.py', '-o',
                    '../test/test_files_2/test2.py', '-t', '2']
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:30.074784
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:30.652540
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:40.430300
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:41.692285
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 14:59:49.384102
# Unit test for function main
def test_main():
    case1 = main(argv=['-i', 'test/test_input/test.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test/test_input'])
    case2 = main(argv=['-i', 'test/test_input/test.py', '-o', 'test/test_output.py', '-t', '3.6', '-r', 'test/test_input'])
    case3 = main(argv=['-i', 'test/test_input/test.py', '-o', 'test/test_output.py', '-t', '3.7', '-r', 'test/test_input'])

# Generated at 2022-06-22 14:59:58.345342
# Unit test for function main
def test_main():
    import pytest
    sys.argv = ['py-backwards.py', '-i', 'test_files/test_main.py',
                '-o', 'test_files/test_main_out.py', '-t', '3.5', '-r',
                'test_files']
    assert main() == 0
    assert open('test_files/test_main_out.py').read() == \
           open('test_files/test_main_out2.py').read()
    pytest.helpers.remove_file('test_files/test_main_out.py')


# Generated at 2022-06-22 15:00:01.782616
# Unit test for function main
def test_main():
    args = sys.argv[:]
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'test', '-t', 'py27',
                '-r', 'test']
    sys.argv += args[1:]


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:03.496009
# Unit test for function main
def test_main():
    sys.argv = "py-backwards -i test_data/abc.py -t 3.0 -o output.py -d".split()
    assert main() == 0

# Generated at 2022-06-22 15:00:09.839455
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'file_to_convert.py', '-o', 'output.py',
                '-t', '2']
    assert main() == 1
    sys.argv = ['py-backwards', '-i', 'file_to_convert.py', '-o', 'output.py',
                '-t', '3.6']
    assert main() == 1

# Generated at 2022-06-22 15:00:10.833535
# Unit test for function main
def test_main():
    assert main()==0

# Generated at 2022-06-22 15:00:12.597111
# Unit test for function main
def test_main():
    import doctest, py_backwards.main
    return doctest.testmod(py_backwards.main)

# Generated at 2022-06-22 15:00:19.047294
# Unit test for function main
def test_main():
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    args = Namespace(input=['test.py'], output='test.py', target='python32',
                     root=None, debug=False)
    try:
        assert main(args) == 1
    except:
        raise

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:43.183549
# Unit test for function main

# Generated at 2022-06-22 15:00:46.824399
# Unit test for function main
def test_main():
    output = StringIO()
    sys.stdout = output
    main_result = main()
    # input:1:1: SyntaxError: invalid syntax
    assert output.getvalue().strip().split('\n')[-1] == 'input:1:1: SyntaxError: invalid syntax'
    sys.stdout = sys.__stdout__
    return 1

# Generated at 2022-06-22 15:00:54.809135
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as tmp:
        sample_input = os.path.join(tmp, 'sample_input')
        sample_output = os.path.join(tmp, 'sample_output')
        os.mkdir(sample_input)

# Generated at 2022-06-22 15:00:58.805558
# Unit test for function main
def test_main():
    info_compiler = logging.getLogger('py_backwards').info
    info_compiler.__wrapped__ = lambda *_: None

    assert main() == 0, 'Wrong work of main function'

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:59.277078
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:59.904193
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:01:05.017651
# Unit test for function main
def test_main():
    input_ = 'tests/data/basic.py'
    output = 'tests/data/basic.pyc'
    target = '3.6'
    root = 'tests/data/'
    args = ['-i', input_, '-o', output, '-t', target, '-r', root]
    assert main(args) == 0
    return args

# Generated at 2022-06-22 15:01:06.109387
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:07.638243
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:01:11.968932
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', './compiler/tests/input/main.py', '-o',
                './compiler/tests/output/main.py', '-t', '2.7', '-r', './compiler/tests/input', '-d']
    assert main() == 0

# Generated at 2022-06-22 15:01:47.536335
# Unit test for function main
def test_main():
    ...

# Generated at 2022-06-22 15:01:52.186039
# Unit test for function main
def test_main():
    args = ['-i', 'i.py', '-o', 'o.py', '-t', '3.2', '-r', '.', '-d']
    sys.argv[1:] = args
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:01:52.984868
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:59.786124
# Unit test for function main
def test_main():
    
    # Test correct compilation
    sys.argv = ['py_backwards', '-i', 'tests/data/transformation/', '-o', 'tests/data/output/', '-t', '3.5', '-r', 'tests/data/']
    assert main() == 0
    sys.argv = ['py_backwards', '-i', 'tests/data/transformation/', '-o', 'tests/data/output/', '-t', '3.6', '-r', 'tests/data/']
    assert main() == 0
    sys.argv = ['py_backwards', '-i', 'tests/data/transformation/', '-o', 'tests/data/output/', '-t', '3.7', '-r', 'tests/data/']
    assert main() == 0

# Generated at 2022-06-22 15:02:02.118546
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:05.382295
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'tests/tests.py', '-o', 'tests/tests2.py',
                '-t', '2.5']
    assert main() == 0

# Generated at 2022-06-22 15:02:05.924520
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:02:13.330968
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'py_backwards/test/test_compiler.py',
                '-o', 'test_output', '-t', '2.7', '-r', 'test', '-d']
    # test file
    assert main() == 0
    # test folder
    assert main() == 0
    # test input does not exist
    assert main() == 1
    # test invalid input
    assert main() == 1
    # test invalid output
    assert main() == 1

# Generated at 2022-06-22 15:02:18.711884
# Unit test for function main
def test_main():
    test_str = 'py-backwards'
    sys.argv = [test_str, "-i", "test/test.py", "-o", "test/test_output.py",
                "-t", "3.5", "-d"]
    assert main() == 0

# Generated at 2022-06-22 15:02:22.891259
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i', 'examples/test.py', '-o', 'out.py', '-r', '.', '-t', '2.7']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:03:49.564877
# Unit test for function main
def test_main():
    import tempfile
    import os
    import shutil
    import io
    import sys
    import runpy
    import contextlib
    import importlib
    import unittest

    # This is a little hack to disable printing in unit tests.
    # It has to be done in this way because print function in
    # unittest is overridden non-strictly by printing results
    # of test, so it's impossible to disable it.
    @contextlib.contextmanager
    def capture(command, *args, **kwargs):
        out, sys.stdout = sys.stdout, io.StringIO()
        try:
            command(*args, **kwargs)
            sys.stdout.seek(0)
            yield sys.stdout.read()
        finally:
            sys.stdout = out


# Generated at 2022-06-22 15:03:59.258981
# Unit test for function main
def test_main():
    import os
    import tempfile
    init_settings([])

    with tempfile.TemporaryDirectory() as tmpdirname:
        os.chdir(tmpdirname)
        open('test.py', 'w').close()
        open('test2.py', 'w').close()
        open('test3.py', 'w').close()
        os.mkdir('test_dir')
        open(os.path.join('test_dir', 'test.py'), 'w').close()
        open(os.path.join('test_dir', 'test2.py'), 'w').close()

        print(main())
        print(main())
        print(main())
        print(main())
        print(main())
        print(main())
        print(main())
        print(main())
        print(main())


# Generated at 2022-06-22 15:04:06.434620
# Unit test for function main

# Generated at 2022-06-22 15:04:08.921439
# Unit test for function main
def test_main():
    args = ["-i", "test/input/main.py", "-o", "test/output/main.py", "-t", "3.5", "-r", "test/input", "-d"]

    assert main() == 0

# Generated at 2022-06-22 15:04:13.410058
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/fixtures/test_resources/test_folder/test.py', '-o', './test_output.py', '-t', '3']
    result = main()
    assert result == 0

# Generated at 2022-06-22 15:04:23.883049
# Unit test for function main
def test_main():
    #assert main("../tests/test_suite/src/example.py", "../tests/test_suite/output/example.py", "3.5.2", "../tests/test_suite/src") == 0
    assert main("../tests/test_suite/output/example.py", "../tests/test_suite/src/example.py", "3.5.2") == 1
    assert main("../tests/test_suite/src/dummy.py", "../tests/test_suite/output/dummy.py", "3.5.2") == 1
    assert main("../tests/test_suite/src/example.py", "../tests/test_suite/output/example.py", "3.5.2", "../tests/test_suite/src") == 0

# Generated at 2022-06-22 15:04:26.092946
# Unit test for function main
def test_main():
    test_main.__doc__ = "Unit test for function main"
    assert main()==0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:26.969139
# Unit test for function main
def test_main():
    assert main() in [0,1]

# Generated at 2022-06-22 15:04:38.644728
# Unit test for function main
def test_main():
    # add function argument test
    temp = sys.argv

    # test for single file
    sys.argv = ['py_backwards', '-i', '/foo/bar/baz.py', '-o', '/foo/bar/hui.py', '-t', '3.6']
    assert main() == 0

    sys.argv = ['py_backwards', '-i', '/foo/bar/baz.py', '-o', '/foo/bar', '-t', '3.6']
    assert main() == 0


    # test for file and folder
    sys.argv = ['py_backwards', '-i', '/foo/bar', '-o', '/foo/bar/baz.py', '-t', '3.6']
    assert main() == 0


# Generated at 2022-06-22 15:04:45.089925
# Unit test for function main
def test_main():
    test_input = ["testdata/test.py", "testdata/test.py"]
    test_output = "testdata/test1.py"
    test_target = "2"

    #calls the main function
    main()

    assert cmp(test_input, test_output) == 0
    assert cmp(test_target, test_output) == 0
    assert cmp('2', test_output) == 0
    assert cmp(test_input, "testdata/test1.py") == 0



# Generated at 2022-06-22 15:08:18.271430
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards','-i', 'example_input.py', '-o', 'example_output.py', '-t', '3.6']
    init_settings(sys.argv)
    open('example_input.py', 'w').close()
    assert main()==0
    sys.argv = ['py-backwards','-i', 'example_input.py', '-o', 'example_output.py', '-t', '3.6']
    init_settings(sys.argv)
    os.remove('example_input.py')
    assert main()==1
    sys.argv = ['py-backwards','-i', 'example_input.py', '-o', 'example_output.py', '-t', '3.6']

# Generated at 2022-06-22 15:08:20.731867
# Unit test for function main
def test_main():
    argv = ['py-backwards', '-i', 'a', '-o', 'b', '-t', '2.7', '-r', 'f']
    assert main(argv) == 0

# Generated at 2022-06-22 15:08:27.899989
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'test/simple_test_files/test.py',
                '-o', 'test/simple_test_files/output.py',
                '-t', '3.6']

    if main() != 0:
        assert False

    sys.argv = ['-i', 'test/simple_test_files/test.py',
                '-o', 'test/simple_test_files/output.py',
                '-t', '8.4']

    if main() != 1:
        assert False

# Generated at 2022-06-22 15:08:33.340808
# Unit test for function main
def test_main():
    init_settings(args=None)
    #file input
    status = main()
    assert status == 1
    #folder input
    status = main()
    assert status == 1
    #syntax error
    status = main()
    assert status == 1
    # input = folder and output = file
    status = main()
    assert status == 1
    # file input and output = folder
    status = main()
    assert status == 1
    #permission error
    status = main()
    assert status == 1