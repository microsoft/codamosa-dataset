

# Generated at 2022-06-22 14:58:44.977756
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]]
    sys.argv.append('-i')
    sys.argv.append('tests/compiler/input')
    sys.argv.append('-o')
    sys.argv.append('tests/compiler/output')
    sys.argv.append('-t')
    sys.argv.append('2.7')
    sys.argv.append('-r')
    sys.argv.append('tests/compiler')
    sys.argv.append('--debug')
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:58:55.539668
# Unit test for function main
def test_main():
    # Test for happy path
    sys.argv = []
    sys.argv.append('-i')
    sys.argv.append('/standard_path/file.py')
    sys.argv.append('-o')
    sys.argv.append('/output')
    sys.argv.append('-t')
    sys.argv.append('2.7')
    result = main()
    assert result == 0

    # Test for happy path
    sys.argv = []
    sys.argv.append('-i')
    sys.argv.append('/standard_path/file.py')
    sys.argv.append('-o')
    sys.argv.append('/output')
    sys.argv.append('-t')
    sys.argv.append('2.7')

# Generated at 2022-06-22 14:58:59.494034
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-t', 'python2', '-i', 'test/test.py',
                '-o', 'test/output']
    assert main() == 0

# Generated at 2022-06-22 14:59:03.291909
# Unit test for function main
def test_main():
    sys.argv = [
        sys.argv[0], '-i', './main.py', '-o', '/home/user', '-t', '2.7',
        '-d', '--root', '/home/user'
    ]
    assert main() == 0

# Generated at 2022-06-22 14:59:14.741740
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        sys.argv = ['pybackwards']
        main()
    with pytest.raises(SystemExit):
        sys.argv = ['pybackwards', '-i', 'temp.py', '-o', 'out', '-t', '3.4']
        main()
    with pytest.raises(SystemExit):
        sys.argv = ['pybackwards', '-i', 'temp.py', '-t', '3.4']
        main()
    with pytest.raises(SystemExit):
        sys.argv = ['pybackwards', '-i', 'temp.py', '-o', 'out']
        main()
        

# Generated at 2022-06-22 14:59:16.136482
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-22 14:59:16.954987
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:21.803356
# Unit test for function main
def test_main():
    try:
        assert main('pybackwards/test.cc', 'pybackwards/test.py', '3.4') == 1
    except Exception:
        print("Test failed")
    try:
        assert main('pybackwards/test.py', 'pybackwards/test2.py', '3.4') == 0
    except Exception:
        print("Test failed")

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:23.754606
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:25.602366
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:45.103730
# Unit test for function main
def test_main():
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1

# Generated at 2022-06-22 14:59:45.552192
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 14:59:48.853320
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:53.732545
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'test_input/test2.py', '-o', 'test_output/test2.py',
                '-t', 'python34', '-root', '/home/user/py-backwards/']
    sys.exit(main())

# Generated at 2022-06-22 14:59:54.311388
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 14:59:54.895931
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:00:06.815273
# Unit test for function main
def test_main():
    assert main([]) == 0
    assert main(['-i','test_resources','-o','test_resources_output',
                '-t','Python3.7','-r','test_resources']) == 0
    assert main(['-i','test_resources/try_syntax_error.py','-o','test_resources_output',
                '-t','Python3.7','-r','test_resources']) == 1
    assert main(['-i','test_resources/try_failed_transformation.py','-o','test_resources_output',
                '-t','Python3.7','-r','test_resources']) == 1

# Generated at 2022-06-22 15:00:07.402656
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:13.862492
# Unit test for function main
def test_main():
    from . import parser, test
    from .profiler import Profiler

    if __name__ == '__main__':
        sys.argv = ['', '-i', 'tst/tests/test_cases/', '-t', '2.7', '-o',
                    'tst/tests/outputs/', '-d']
        Profiler.start()
        main()
        Profiler.stop()
        test.run_tests()
        Profiler.print_stats()

# Generated at 2022-06-22 15:00:15.874840
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 15:00:43.876650
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import patch

    sys.argv = ['py-backwards', '-i', 'test_input', '-o', 'output', '-t', 'py34', '-r', 'root']
    with patch('sys.stdout', new=StringIO()) as mock_stdout:
        main()
    assert '10000 lines and 10010 bytes of input processed' in mock_stdout.getvalue()
    sys.argv = ['py-backwards']
    with patch('sys.stdout', new=StringIO()) as mock_stdout:
        main()
    assert 'usage: py-backwards' in mock_stdout.getvalue()

# Generated at 2022-06-22 15:00:44.464881
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:00:56.379350
# Unit test for function main
def test_main():
    old_argv = sys.argv
    sys.argv = ["py-backwards", "-i", "file", "-o", "file"]
    assert main() == 1

    sys.argv = ["py-backwards", "-i", "file", "-o", "file", "-t", "3.5"]
    assert main() == 1

    sys.argv = ["py-backwards", "-i", "file/notexists", "-o", "file", "-t", "3.5"]
    assert main() == 1

    sys.argv = ["py-backwards", "-i", "file", "-o", "file/notexists", "-t", "3.5"]
    assert main() == 1
    sys.argv = old_argv

# Generated at 2022-06-22 15:01:07.770855
# Unit test for function main
def test_main():
    import os
    import random
    import shutil
    import tempfile
    import string
    
    def get_random_name():
        """
        Get a random name for a file.
        """
        return ''.join(random.choices(string.ascii_uppercase + string.digits + string.ascii_lowercase, k=10))
    
    def get_random_text():
        """
        Get a random text from a file.
        """
        words = ("Hello", "World")
        return ' '.join(random.sample(words, 2))
    
    # Test 1: Input file does not exist
    with tempfile.TemporaryDirectory() as tmp_dir_name:
        tmp_file = os.path.join(tmp_dir_name, get_random_name())

# Generated at 2022-06-22 15:01:08.352480
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:15.423901
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from io import StringIO
    import argparse
    argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '2.7', '-r', 'root']

    with patch.object(sys, 'argv', argv), patch('sys.stderr', new=StringIO()), patch.object(argparse.ArgumentParser, 'error') as error:
        main()
    error.assert_not_called()

# Generated at 2022-06-22 15:01:23.670239
# Unit test for function main

# Generated at 2022-06-22 15:01:34.426915
# Unit test for function main
def test_main():
    from .settings import debug
    import io

    sys.argv = ['py-backwards', '-i', 'tests', '-o', 'test-output', '-t', '2', '-r', 'tests']
    captured_output = io.StringIO()
    sys.stdout = captured_output
    sys.stderr = captured_output
    main()
    sys.stdout = sys.__stdout__

    assert 'tests/tests/test_abc' in captured_output.getvalue()
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'test-output', '-t', '3', '-r', 'tests']
    captured_output = io.StringIO()
    sys.stdout = captured_output
    sys.stderr = captured_output
   

# Generated at 2022-06-22 15:01:36.660222
# Unit test for function main
def test_main():

    args = ["-i","my_program.py","-o","my_program_36.py","-t","3.6","-r","root"]
    sys.argv = args

    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:42.375958
# Unit test for function main
def test_main():
    sys.argv = ['program', '-i', 'tests/input/', '-o',
                'tests/output/', '-t', '27', '-r', 'tests/input/']
    main()
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:19.699162
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:20.313060
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:02:28.071344
# Unit test for function main
def test_main():
    input_ = 'Tests/test_input/test_input.py'
    output = 'Tests/test_output/test_output.py'
    target = '3.5'
    args = ['--input', input_, '--output', output, '--target', target]
    from . import conf
    import os

    try:
        init_settings(args)
        result = compile_files(input_, output, const.TARGETS[target])
        print(messages.compilation_result(result))
        assert os.path.exists(output)
        os.remove(output)
    finally:
        conf.settings = None

# Generated at 2022-06-22 15:02:38.761018
# Unit test for function main
def test_main():
    from .cli import main
    from . import const

    for target in const.TARGETS:
        for input in ['./tests/samples/test.py', './tests/samples']:
            for output in ['./tests/test_output', './tests/test_output/test.py']:
                for root in ['./tests/samples', './tests/samples/']:
                    for debug in [True, False]:
                        main(['-i', input, '-o', output, '-t', target,
                              '-r', root, '-d', debug])
                        assert True
                    assert True
                assert True
            assert True
        assert True
    assert True

# Generated at 2022-06-22 15:02:49.903427
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'example.py', '-o', 'output.py', '-t',
                'py27', '-r', './', '-d']
    assert main() == 0

    sys.argv = ['py-backwards', '-i', 'example.py', '-o', 'output.py', '-t',
                'py27', '-r', './', '-d']
    assert main() == 0

    sys.argv = ['py-backwards', '-i', 'example.py', '-o', 'output.py', '-t',
                'py35', '-r', './', '-d']
    assert main() == 0


# Generated at 2022-06-22 15:03:00.089506
# Unit test for function main
def test_main():
    assert 1 == main(["-i", "py-backwards/__init__.py", "-o", "./out.py"])
    assert 0 == main(["-i", "py-backwards/__init__.py", "-o", "./out.py", "-t", "python3"])
    assert 0 == main(["-i", "py-backwards/__init__.py", "-o", "./out.py", "-t", "python2"])
    assert 0 == main(["-i", "py-backwards/__init__.py", "-o", "./out.py", "-t", "python2", "-r", "./"])

# Generated at 2022-06-22 15:03:00.590559
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:03:06.990884
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards', '-i', 'test_files/test_file.py', '-o', 'out/', '-t',
        '3.6', '-r', 'test_files/test_file.py'
    ]
    assert main() == 0


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 15:03:07.858513
# Unit test for function main
def test_main():
    assert 1 != main()

# Generated at 2022-06-22 15:03:09.830054
# Unit test for function main
def test_main():
    assert main() == 1    # todo: fix it

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:38.464220
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-22 15:04:46.742967
# Unit test for function main
def test_main():
    # test 1
    input_ = ['test/test_main.py']
    output = 'test/test.py'
    target = '2.7'
    root = None
    debug = False
    args = ['-i', input_[0], '-o', output, '-t', target, '-r', root, '-d', debug]
    assert main(args) == 0
    # test 2
    output = 'test/test/test.py'
    args = ['-i', input_[0], '-o', output, '-t', target, '-r', root, '-d', debug]
    assert main(args) == 1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:49.849484
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'tests/input/', '-o', 'tests/output/', '-t', '2.7']
    main()

# Generated at 2022-06-22 15:05:00.653256
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards.py", "-i", "test_data/valid", "-o", "test_output",
                "-t", "2.7", "-r", "test_data"]
    assert main() == 0
    sys.argv = ["py-backwards.py", "-i", "test_data/valid", "-o", "test_output",
                "-t", "2.7"]
    assert main() == 0
    sys.argv = ["py-backwards.py", "-i", "test_data/invalid", "-o", "test_output",
                "-t", "2.7"]
    assert main() == 1

# Generated at 2022-06-22 15:05:01.202899
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:05:03.530229
# Unit test for function main
def test_main():
    args = ['-i', 'tester.py', '-o', './output', '-t', '3.3', '-r', '.']
    main(args)

# Generated at 2022-06-22 15:05:14.813910
# Unit test for function main
def test_main():
    import os
    import tempfile
    import filecmp
    import multiprocessing
    #write testfiles in temp folder
    tempdir = tempfile.gettempdir()
    write_result_file(tempdir)
    write_result_file(tempdir)
    write_result_file(tempdir)
    write_result_file(tempdir)
    write_result_file(tempdir)
    #run command with only files
    os.system("python -m backwards -i "+tempdir+"/testfile.py " + tempdir+"/testfile1.py -o "+tempdir+"/res_folder -t python3 -r "+tempdir + " > "+tempdir+"/logfile 2>&1")

# Generated at 2022-06-22 15:05:15.457316
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:05:17.834196
# Unit test for function main
def test_main():
    args = ['-i', 'file.py', '-o', 'out.py', '-t', '2.7', '-r', '.']
    assert main(args) == 0

# Generated at 2022-06-22 15:05:21.511365
# Unit test for function main
def test_main():
    helpers.set_argv(["py-backwards", "-i", "sources/main.py",
                      "-o", "output/main.py", "-t", "3.5", "-r", "sources/"])
    assert main() == 0