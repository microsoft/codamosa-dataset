

# Generated at 2022-06-22 14:58:54.333058
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:00.560685
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]] + \
        ['-i', 'tests/resources/basic.py', '-o', 'result.py', '-t', '2.7']
    assert main() == 0
    with open('result.py') as f:
        result = f.read()
    assert result.strip() == 'x=5'

# Generated at 2022-06-22 14:59:04.906853
# Unit test for function main
def test_main():
    assert main(['file.py'],
                ['output.py'],
                ['3.5']) == 1
    assert main(['file.py'],
                ['output.py'],
                ['3.6']) == 0
    assert main(['folder'],
                ['output'],
                ['3.6']) == 0

# Generated at 2022-06-22 14:59:07.897111
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(['-i', 'a', 'b'])
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2


# Generated at 2022-06-22 14:59:11.982294
# Unit test for function main
def test_main():
    assert main(
        ['-i', 'tests/unittests/test_data/parser/valid_input.py',
         '-o', '_test_main_output',
         '-t', '2.7']) == 0

# Generated at 2022-06-22 14:59:20.237688
# Unit test for function main
def test_main():
    init_settings(None)
    def _main(input_, output, target='3.5', root=None, debug=False):
        return compile_files(input_, output, const.TARGETS[target], root)

    with open('test.py', 'w') as file:
        file.write('print(1)')

    assert _main('test.py', 'out.py')

    os.remove('test.py')
    os.remove('out.py')

    assert not _main('test.py', 'out.py')

    shutil.rmtree('dummy/')

# Generated at 2022-06-22 14:59:24.331826
# Unit test for function main
def test_main():
    argv = ['', '-i', 'input/', '-o', 'output/', '-t', '2.7', '-r', 'input/']
    assert main(argv) == 0

# Generated at 2022-06-22 14:59:26.536819
# Unit test for function main
def test_main():
    try:
        main()
    except NotImplementedError:
        pass

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-22 14:59:27.914625
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:31.180732
# Unit test for function main
def test_main():
    sys.argv = ['', '--input', 'test.py', '--output', 'out.py', '--target', 'python2.7']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:51.555119
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:58.262423
# Unit test for function main
def test_main():
    test_input = 'test.py'
    test_output = 'out.py'
    test_root = 'test'
    test_target = '3.5'

    sys.argv = [
        '',
        '-i', test_input,
        '-o', test_output,
        '-r', test_root,
        '-t', test_target,
    ]
    if main():
        raise AssertionError('Bad')

# Generated at 2022-06-22 15:00:03.051029
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1] + ['-i', 'test', '-o', 'out', '-t', 'py27', '-r', 'test']
    assert main() == 1

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:13.649757
# Unit test for function main
def test_main():
    # Paths to test resources,
    # FIXME: The fact that the path is hardcoded is bad
    input_ = "./tests/resources/main_resources/input"
    output = "./tests/resources/main_resources/output"

    # Unit test for function main with normal arguments
    sys.argv = ["py-backwards", "-i", input_, "-o", output, "-t", "35",
                "-r", input_]
    main()

    # Unit test for function main with invalid arguments
    sys.argv = ["py-backwards", "-i", "input", "-o", "output", "-t", "35",
                "-r", "input"]
    main()

    # Unit test for function main with invalid permission for output folder

# Generated at 2022-06-22 15:00:14.217659
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:24.692554
# Unit test for function main
def test_main():
    # Test conversion py36 to py36
    assert (main() == 0)

    # Test conversion py36 to py35
    assert (main() == 0)

    # Test conversion py36 to py37
    assert (main() == 0)

    # Test conversion py36 to py34
    assert (main() == 0)

    # Test conversion py36 to not supported version
    assert (main() == 1)

    # Test with empty args
    assert (main() == 1)

    # Test compilation with compile error
    assert (main() == 1)

    # Test translation with translation error
    assert (main() == 1)


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:25.471303
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False

# Generated at 2022-06-22 15:00:29.248450
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'output.py', '-t',
                'python36', '-r', 'root']
    args = main()
    assert args == 0

# Generated at 2022-06-22 15:00:36.910654
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/project', '-o', 'tests/result',
                '-t', '3.5', '-r', 'tests', '-d']
    try:
        assert main() == 0
    except AssertionError:
        raise AssertionError
    finally:
        sys.argv = sys.argv[:1]


# Generated at 2022-06-22 15:00:37.945239
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:01:15.904737
# Unit test for function main
def test_main():
    from unittest import main
    from .test import test_main
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:19.724580
# Unit test for function main
def test_main():
    with patch('argparse.ArgumentParser.parse_args') as parse_arg:
        with patch('pyback.conf.init_settings') as init_settings:
            main()
            assert parse_arg.called
            assert init_settings.called

# Generated at 2022-06-22 15:01:21.603022
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except Exception:
        return False
    else:
        return True

# Generated at 2022-06-22 15:01:24.826512
# Unit test for function main
def test_main():
    argv = ['py-backwards', 'test', '-o', 'output', '-t', '3.6', '-r']
    assert main() == 0

# Generated at 2022-06-22 15:01:25.376621
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:35.789339
# Unit test for function main
def test_main():
    def mock_exists(path: str) -> bool:
        return path in paths
    def mock_isfile(path: str) -> bool:
        return paths[path] == 'file'
    def mock_isdir(path: str) -> bool:
        return paths[path] == 'dir'
    def mock_isfile_side_effect(path: str) -> bool:
        if paths[path] == 'file':
            return True
        raise exceptions.InputDoesntExists()
    def mock_isdir_side_effect(path: str) -> bool:
        if paths[path] == 'dir':
            return True
        raise exceptions.InputDoesntExists()


# Generated at 2022-06-22 15:01:46.650379
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'file.py', '-o', 'file3.py', '-t', '3']
    x = main()
    assert x == 0
    sys.argv = ['py-backwards', '-i', 'file.py', '-o', 'file3.py', '-t', '27']
    x = main()
    assert x == 0
    sys.argv = ['py-backwards', '-i', 'file.py', '-o', 'file3.py', '-t', '3.6']
    x = main()
    assert x == 0
    sys.argv = ['py-backwards', '-i', 'file.py', '-o', 'file3.py', '-t', '34']
    x = main()

# Generated at 2022-06-22 15:01:56.266940
# Unit test for function main
def test_main():
    # TODO: upgrade to using mock and functions
    input_file = open('Python.py', 'w')
    input_file.write('input_ = open(\'Python.py\', \'w\')')
    input_file.close()
    output_file = open('Python3.py', 'w')
    output_file.close()

    # testing for valid input and output
    arglist = ['-i', 'Python.py', '-o', 'Python3.py', '-t', '3.5', '-d']
    args = main.__code__.co_varnames
    arglist_args = dict(zip(args, arglist))
    main(**arglist_args)

    # testing for invalid input
    invalid_input_file = ['1.py', '2.py']
    args = main