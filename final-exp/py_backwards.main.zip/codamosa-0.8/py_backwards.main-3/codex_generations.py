

# Generated at 2022-06-22 14:58:24.198991
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as e:
        main()
        assert e.value.code == 0

# Generated at 2022-06-22 14:58:24.892150
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-22 14:58:26.542257
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-22 14:58:29.152873
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py']
    try:
        main()
    except SystemExit as e:
        assert bool(e)
        assert e.code == 2


# Generated at 2022-06-22 14:58:29.741502
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:58:36.471577
# Unit test for function main
def test_main():
    target_version = const.TARGETS.items()[0][0]
    for target_version in const.TARGETS:
        #example_file = os.path.join(os.path.dirname(__file__), "..", "examples", "example.py")
        example_file = r"D:\Git\py-backwards\examples\example.py"
        assert main(['-i', example_file, '-o', 'out.py', '-t', target_version]) == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:58:45.387964
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import call
    from unittest import TestCase
    from .testing import MockedArgumentParser, MockedSettings

    class MainTests(TestCase):

        def setUp(self):
            self.stdout = StringIO()
            self.parser = MockedArgumentParser('-i', 'input', '-o', 'output',
                                               '-t', 'target', '-r', 'root',
                                               '-d')
            sys.stdout = self.stdout

        def test_help(self):
            self.parser.arguments.invalid = 'help'
            main()
            self.stdout.seek(0)

# Generated at 2022-06-22 14:58:46.130549
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:58:51.559430
# Unit test for function main
def test_main():
    settings.debug = False
    settings.target = 'py36'
    settings.input = ['./test/sample.py']
    settings.output = './test/temp'
    assert main() == 0

    settings.debug = True
    settings.input = './test/sample.py'
    settings.output = './test/temp/sample.py'
    assert main() == 0

# Generated at 2022-06-22 14:58:56.754049
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('./test_folder/test_input.py')
    sys.argv.append('-o')
    sys.argv.append('./test_folder/test_output.py')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    print(sys.argv)
    main()


# Generated at 2022-06-22 14:59:15.071572
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:23.322748
# Unit test for function main
def test_main():
    input_ = './tests/resources/sources'
    output = './tests/resources/output'
    command = ['-i', input_, '-o', output, '-t', '3.5']
    if __name__ == '__main__':
        main()
    else:
        main(command)
    with open('%s/simple_test.py' % output) as actual:
        with open('%s/simple_test.py' % input_) as expected:
            assert actual.read() == expected.read()
        with open('%s/simple_test.py' % output) as actual:
            with open('%s/simple_test_output.py' % input_) as expected:
                assert actual.read() == expected.read()



# Generated at 2022-06-22 14:59:26.394661
# Unit test for function main
def test_main():
    args = main.__defaults__[0].parse_args('-i sample.py -o sample_out.py -t 2.7'.split())
    assert args.input == 'sample.py'

# Generated at 2022-06-22 14:59:28.149220
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as ex:
        main() == 0



# Generated at 2022-06-22 14:59:33.807117
# Unit test for function main
def test_main():
    try:
        sys.argv.extend(["-i", "test_file", "-o", "test_file", "-t", "3.5"])
        main()
    except NameError:
        assert True
    finally:
        del sys.argv[-1]
        del sys.argv[-1]
        del sys.argv[-1]
        del sys.argv[-1]
        del sys.argv[-1]

# Generated at 2022-06-22 14:59:45.312032
# Unit test for function main
def test_main():
    import os
    import shutil

# Generated at 2022-06-22 14:59:45.736814
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 14:59:57.957012
# Unit test for function main
def test_main():
  import tempfile
  import os.path
  import pytest
  import contextlib
  @contextlib.contextmanager
  def tempdir():
      d = tempfile.mkdtemp()
      try:
          yield d
      finally:
          import shutil
          shutil.rmtree(d)
  
  with tempdir() as d:
      print(d)
      assert main(['--input','test/test_data','--output','test/output','--target','2.7','--root',d]) == 0
      assert main(['--input','test/test_data/examples/compile.py','--output','test/output/examples/compile.py','--target','3.4','--root',d]) == 0

# Generated at 2022-06-22 15:00:02.775922
# Unit test for function main
def test_main():
    # test success
    sys.argv = [sys.argv[0], '-i', './tests/tests', '-o', './tests/result.py',
                '-t', '3.5']
    assert main() == 0

    # test fail
    sys.argv = [sys.argv[0], '-i', './tests/tests', '-o', './tests/result.py',
                '-t', '3.7']
    assert main() == 1

# Generated at 2022-06-22 15:00:06.814698
# Unit test for function main
def test_main():
    from .pytest_compat import mock, patch

    with patch('sys.argv', []):
        with mock.patch('py_backwards.compiler.main.compile_files',
                        return_value=True):
            main()

# Generated at 2022-06-22 15:00:32.557099
# Unit test for function main
def test_main():
    import os
    import shutil
    import subprocess
    import tempfile
    import unittest

    class PyBackwardsTest(unittest.TestCase):
        def setUp(self):
            # Set up fake args
            self.args = ['py-backwards', '-d', '-o', tempfile.mkdtemp()]
            self.samples_folder = os.path.join(os.path.dirname(__file__),
                                               'samples')

        def test_main(self):
            # Test samples
            for sample in os.listdir(self.samples_folder):
                if not sample.endswith('.py'):
                    continue

                if sample == 'f-string.py':
                    continue


# Generated at 2022-06-22 15:00:38.016563
# Unit test for function main
def test_main():
    sys.argv.extend(['-i', 'tests', '-o', 'test_dest', '-t', 'py35', '-d'])
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:45.534649
# Unit test for function main
def test_main():
    input = ['tests/test_files/test_inputs/input_00.py', ]
    output = 'tests/test_files/test_outputs/output_00.py'
    target = '2.7'
    import os
    from shutil import rmtree
    os.remove(output)
    rmtree('tests/test_files/test_outputs/test_folder')
    assert main([input, output, target]) == 0
    os.remove(output)


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))

# Generated at 2022-06-22 15:00:53.920280
# Unit test for function main
def test_main():
    from io import StringIO
    capture = StringIO()
    sys.stdout = capture
    main(['-i', 'tests/simple_tests/simple.py', '-o', 'output.py',
          '-t', '3.6', '-r', 'input'])
    sys.stdout = sys.__stdout__
    assert capture.getvalue() == 'Compiled 1 files\n'

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:56.302035
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        # This is intended behavior
        pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:56.843187
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:00.263450
# Unit test for function main
def test_main():
    sys.argv = ["", "-i", "tests/test_src.py", "-o", "tests/tmp.py", "-t", "3.4", "-d",
        "-r", "tests/"]
    assert main() == 0

# Generated at 2022-06-22 15:01:01.906444
# Unit test for function main
def test_main():
        assert main()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:01:06.057388
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as exc_info:
        main()
    assert exc_info.value.code == 1, "Code for incorrect input"

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:17.528771
# Unit test for function main
def test_main():
    import pytest
    # Input exists and is file
    with pytest.raises(SystemExit):
        main(['-i', 'compiler.py', '-o', 'temp/folder', '-t', '2.7'])
    # Output not exists
    with pytest.raises(SystemExit):
        main(['-i', 'tests/cases/example.py', '-o', 'temp/folder', '-t', '2.7'])
    # Input and Output is dirs and they are the same
    with pytest.raises(SystemExit):
        main(['-i', 'tests/cases/', '-o', 'tests/cases/', '-t', '2.7'])
    # Input is folder, output is file

# Generated at 2022-06-22 15:01:59.687502
# Unit test for function main
def test_main():
    from .utils import temp
    from .compiler import compile_files
    from .conf import init_settings

    _, input_path, output_path = temp.create_temp_dir(3)
    with open(input_path, "w") as f:
        f.write("from typing import Dict\ndef test(t: Dict): pass")

    init_settings(
        ArgumentParser('py-backwards').parse_args(
            ["-i", input_path, "-o", output_path, "-d", "-t", "py27"])
    )

    try:
        compile_files(input_path, output_path, (2, 7))
        with open(output_path) as f:
            content = f.read()
        assert "Dict" not in content
    except Exception as e:
        print

# Generated at 2022-06-22 15:02:01.959902
# Unit test for function main
def test_main():
    assert True


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:08.288254
# Unit test for function main
def test_main():
    sys.argv.append('--help')
    main()
    sys.argv.pop()
    sys.argv.append('-i')
    sys.argv.append('a.py')
    sys.argv.append('-o')
    sys.argv.append('b.py')
    sys.argv.append('-t')
    sys.argv.append('python27')
    main()

test_main()

# Generated at 2022-06-22 15:02:09.936980
# Unit test for function main
def test_main():
    init_settings()
    assert main() == 0
    init_settings()
    assert main() == 0

# Generated at 2022-06-22 15:02:10.798692
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:02:20.358662
# Unit test for function main
def test_main():
    from .test import utils
    from .conf import settings
    from . import const

    args = utils.mock_args('-t', '3.6', '-i', 'test.py', '-o', 'test.py', '-r',
                           '.')
    init_settings(args)
    assert settings.target == const.TARGETS['3.6']
    assert settings.input == ['test.py']
    assert settings.output == 'test.py'
    assert settings.root == '.'
    assert settings.debug == False


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:22.101665
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:29.879680
# Unit test for function main
def test_main():
  import pytest
  from unittest.mock import patch, mock_open

  parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
  parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
  parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
  parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')

# Generated at 2022-06-22 15:02:30.423434
# Unit test for function main
def test_main():
	main()

# Generated at 2022-06-22 15:02:32.606291
# Unit test for function main
def test_main():
    print('\n')
    # Expected result
    res = main()

    # Achieved result
    print('result:', res)
    asse

# Generated at 2022-06-22 15:03:54.383287
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:03:55.170619
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:04:01.592455
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files', '-o',
                'test_output', '-t', '3.5', '-r', 'test/test_files']
    main()
    assert sys.argv == ['py-backwards', '-i', 'test/test_files', '-o',
                        'test_output', '-t', '3.5', '-r', 'test/test_files']


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:02.658818
# Unit test for function main
def test_main():
    res = main()
    assert res == 0
    return res

# Generated at 2022-06-22 15:04:07.501430
# Unit test for function main
def test_main():
    input_list = [
        '-i', 'test/test_input/test_input.py',
        '-o', 'test/test_output/test_output.py',
        '-t', '2.7'
    ]

    main(input_list)


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:08.643236
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:04:18.462039
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from io import StringIO

    def test_with_values(expected, input, output, target, root, debug):
        with patch.object(sys, 'argv', ['py-backwards',
                                        '-i', input, '-o', output,
                                        '-t', target, '-r', root, '-d']):
            with StringIO() as buf, patch('sys.stderr', buf):
                assert main() == expected
                print(buf.getvalue())

    test_with_values(0, 'test_in', 'test_out', '2.7', '.', True)



# Generated at 2022-06-22 15:04:18.967159
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:04:28.361885
# Unit test for function main
def test_main():
  args = ArgumentParser('py-backwards',
                        description='Python to python compiler that allows you to use some '
                        'Python 3.6 features in older versions.')
  args.add_argument('-i', '--input', type=str, nargs='+', required=True,
                    help='input file or folder')
  args.add_argument('-o', '--output', type=str, required=True,
                    help='output file or folder')
  args.add_argument('-t', '--target', type=str,
                    required=True, choices=const.TARGETS.keys(),
                    help='target python version')
  args.add_argument('-r', '--root', type=str, required=False,
                    help='sources root')

# Generated at 2022-06-22 15:04:33.747938
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1] + ['-i', 'tests/fixtures/test_file.py', '-o',
                               'output', '-t', '37']
    assert main() == 0
    assert os.path.exists('output')
    os.remove('output')

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:07:58.946632
# Unit test for function main
def test_main():
    from .conf import settings
    from . import messages
    main()
    #assert len(messages) == 7
    assert settings.input == "test_input"
    assert settings.output == "test_output"
    assert settings.target == "2.7"
    assert settings.debug == True

# Generated at 2022-06-22 15:07:59.414139
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:08:00.192377
# Unit test for function main
def test_main():
  assert main() == 0

# Generated at 2022-06-22 15:08:05.974432
# Unit test for function main
def test_main():
    import io
    from . import messages
    from .conf import settings
    import sys
    import tempfile
    import os
    import shutil

    def test_main_run(args, expected_result, expected_msg, input_code=''):
        settings.init_settings(args)

        with tempfile.TemporaryDirectory() as tmp_dir:
            file_name = os.path.join(tmp_dir, 'test.py')

            with open(file_name, 'w') as f:
                f.write(input_code)

            with io.StringIO() as buf, redirect_stdout(buf):
                result = main()

            assert result == expected_result, 'main() returned unexpected ' \
                                              'result'

# Generated at 2022-06-22 15:08:16.379718
# Unit test for function main
def test_main():
    def run(argv):
        backup = sys.argv
        sys.argv = ['main'] + argv
        try:
            return main()
        finally:
            sys.argv = backup

    assert run(['./test/input_files', './test/output', '-t', 'py35']) == 0
    assert run(['./test/input_files', './test/output', '-t', 'py34']) == 0
    assert run(['./test/input_files', './test/output', '-t', 'py36']) == 0
    assert run(['./test/input_files', './test/output', '-t', 'py36', '-d']) == 0