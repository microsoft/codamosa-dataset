

# Generated at 2022-06-22 14:58:40.966020
# Unit test for function main
def test_main():
    import tempfile
    import os.path
    import pytest

    # Test for successful compilation
    def test_success_compilation(capsys):
        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, 'input.py'), 'w') as file:
                file.write('print(1)')

            assert 0 == main(['-i', os.path.join(tmpdir, 'input.py'),
                              '-t', '3.5', '-o', os.path.join(tmpdir, 'out')])

            captured = capsys.readouterr()
            assert '4 transformations applied on 1 files' in captured.out


# Generated at 2022-06-22 14:58:42.198112
# Unit test for function main
def test_main():
    assert(main() == 0)

# Generated at 2022-06-22 14:58:43.580284
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 14:58:45.261571
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-22 14:58:52.977201
# Unit test for function main
def test_main():
    # Test function
    sys.argv = ['pyback', '-i', 'test/test.py', '-o', 'test/test.py',
                '-t', '2.7', '-r', 'test/']
    assert main() == 0
    # Test exception
    sys.argv = ['pyback', '-i', 'test/test_stub.py', '-o', 'test/test_stub.py',
                '-t', '3.6', '-r', 'test/']
    assert main() == 1

# Generated at 2022-06-22 14:59:01.037676
# Unit test for function main
def test_main():
    f1 = tempfile.NamedTemporaryFile(mode='w', suffix='.py')
    f2 = tempfile.NamedTemporaryFile(mode='w', suffix='.py')
    f1.write('import math\nprint(math.e)\n')
    f1.seek(0)
    f2.write('print(math.e)\n')
    f2.seek(0)
    sys.argv = ['py-backwards', '-i', f1.name, '-o', f2.name, '-t', 'py2.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', f1.name, '-o', f2.name, '-t', 'py3.7']
    assert main() == 1
    sys.argv

# Generated at 2022-06-22 14:59:11.932209
# Unit test for function main
def test_main():
    import argparse
    assert main(['-i', 'input', '-o', 'output', '-t', '3.4', '-r', 'root']) == 0
    assert main(['-i', 'input', '-o', 'output', '-t', '3.4']) == 0
    assert main(['-i', 'input', '-o', 'output', '-t', '3.4', '-d']) == 0
    assert main(['-i', 'input', '-o', 'output', '-t', '2.7']) == 0
    assert main(['-i', 'input', '-o', 'output', '-t', '3.4.5']) == 2

# Generated at 2022-06-22 14:59:21.867455
# Unit test for function main
def test_main():
    # 1. Test -i with one file and -o with file
    sys.argv = ['py-backwards', '-i', 'input.txt', '-o', 'output.txt', '-t', 'python2', '-r', 'src']
    assert main() == 1
    # 2. Test -i with one file and -o with folder
    sys.argv = ['py-backwards', '-i', 'input.txt', '-o', 'output', '-t', 'python2', '-r', 'src']
    assert main() == 1
    # 3. Test -i with one file and -o with folder
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output', '-t', 'python2', '-r', 'src']
    assert main

# Generated at 2022-06-22 14:59:23.352518
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:27.833282
# Unit test for function main
def test_main():
    # Test that program exits with 1 when no arguments are given
    sys.argv = [sys.argv[0]]
    assert main() == 1

    # Test that program exits with 1 when input is given but output is missing
    sys.argv = [sys.argv[0], '-i', 'a']
    assert main() == 1

    # Test that program exits with 1 when input is missing but output is given
    sys.argv = [sys.argv[0], '-o', 'b']
    assert main() == 1

    # Test that program exits with 1 when root is given but input is missing
    sys.argv = [sys.argv[0], '-r', 'b', '-o', 'b']
    assert main() == 1

    # Test that program exits with 1 when input is given but target is missing
   

# Generated at 2022-06-22 14:59:37.158467
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-22 14:59:45.430010
# Unit test for function main
def test_main():
    #Test to check if function raises exception
    with pytest.raises(exceptions.InputDoesntExists):
        args = ['-i', 'bla.py', '-o', 'bla.py', '-t', '3.6']
        main(args)
    #Test to check if function raises exception
    with pytest.raises(exceptions.InputDoesntExists):
        args = ['-i', 'bla.py', '-o', 'bla.py', '-t', '3.6', '-r', 'bla.py']
        main(args)

# Generated at 2022-06-22 14:59:45.883691
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 14:59:47.672735
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    assert callable(main)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:59.502435
# Unit test for function main
def test_main():
    from .test import test_compiler as test_compiler

    # Construct an argument parser
    parser = ArgumentParser()

    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-22 15:00:01.465240
# Unit test for function main
def test_main():
    init_settings(None)
    assert main() == 0
    init_settings(None)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:03.943774
# Unit test for function main
def test_main():
    assert 0 == main(['-i', 'tests/test_version_spec.py',
                      '--output', 'out_test',
                      '--target', '2.7'])


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:12.301854
# Unit test for function main
def test_main():
    with patch('sys.argv', ['py-backwards', '-i', 'test-file.py', '-o', 'output-file.py', '-t', '2.7']):
        assert main() == 0
    with patch('sys.argv', ['py-backwords', '-i', 'input-file.py', '-o', 'output-file.py']):
        assert main() == 1
    with patch('sys.argv', ['py-backwords', '-i', 'input-file.py', '-t', '2.6']):
        assert main() == 1


# Generated at 2022-06-22 15:00:15.591921
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'py_backwards', '-o', 'py_backwards/target_folder', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-22 15:00:19.482795
# Unit test for function main
def test_main():
    assert main(
        ["test/test_cases/test_main/test.py"], "test.py", "2.7", "test/test_cases/test_main", False) == 1


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:40.421306
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', './test/test_compiler.py', '-o', './test/comp_result.py', '-t', '2.7', '-r', './test']
    assert(main()==0)

# Generated at 2022-06-22 15:00:41.458124
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:46.448932
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    if __package__ is None and not hasattr(sys, 'frozen'):
        # direct call of __main__.py
        import os.path
        path = os.path.realpath(os.path.abspath(__file__))
        sys.path.append(os.path.dirname(os.path.dirname(path)))
    exit(main())

# Generated at 2022-06-22 15:00:51.270092
# Unit test for function main
def test_main():
    # import sys
    # sys.argv += ['example.py', '-o', 'out.py', '-t', 'py35']
    # assert main() == 0

    assert main() == 0

# Generated at 2022-06-22 15:01:01.515317
# Unit test for function main
def test_main():
    from .conf import settings
    from .compiler import compile_files
    from . import exceptions
    import os, argparse
    class Args:
        def __init__(self):
            self.input = ['test/__init__.py', 'test/test_target.py']
            self.output = 'test/output'
            self.target = '2.7'
            self.root = 'test'
            self.debug = False
    args = Args()
    init_settings(args)


# Generated at 2022-06-22 15:01:12.783924
# Unit test for function main
def test_main():
    from .mock.builtins import builtin_open
    from .mock.argparse import Namespace
    from .mock.os.path import os_path_exists
    from .mock.os import os_rename

    os_path_exists.return_value = True

    # wrong input
    os_path_exists.side_effect = None
    os_path_exists.return_value = False
    #os_makedirs.side_effect = None
    #os_makedirs.return_value = False
    args = Namespace(input=['file.py'],
                     output='out',
                     target='3.6',
                     root='root')
    assert main() == 1

    # invalid input-output
    os_path_exists.return_value = True
    args = Namespace

# Generated at 2022-06-22 15:01:20.889491
# Unit test for function main
def test_main():
    argv_backup = sys.argv
    sys.argv = [sys.argv[0], '-i', 'tests/input.py', '-o', 'output.py', '-t',
                '3.5', '-d']
    res = main()
    sys.argv = argv_backup
    assert res == 0
    assert open('output.py').read() == open('tests/input.py').read()
    open('output.py', 'w').write('')


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:21.671904
# Unit test for function main
def test_main():
    assert main == 0

# Generated at 2022-06-22 15:01:22.764331
# Unit test for function main
def test_main():
    assert main() is 0
# ----------------------------------------------------------------------------

# Generated at 2022-06-22 15:01:28.876594
# Unit test for function main
def test_main():
    argv_for_test = sys.argv
    sys.argv = ['py-backwards.py', '-h']
    with open(os.devnull, 'w') as f:
        stdout_ = sys.stdout
        sys.stdout = f
        main()
        sys.stdout = stdout_
    sys.argv = argv_for_test

# Generated at 2022-06-22 15:02:14.161290
# Unit test for function main
def test_main():
    from io import StringIO
    import sys
    import os
    import shutil
    from .conf import settings
    from . import template


# Generated at 2022-06-22 15:02:19.138802
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()
    with mock.patch('sys.argv', ['compile', '-i', 'input', '-o', 'output',
                                 '-t', 'python2']):
        main()

# Generated at 2022-06-22 15:02:21.144091
# Unit test for function main
def test_main():
    assert main() == 0
    # TODO: write more tests

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:22.807827
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:25.950329
# Unit test for function main
def test_main():
    assert main() == 0
    assert main(['-h']) == 0
    assert main(['-i', 'input.py', '-o', 'output.py', '-t' '2.7']) == 0

# Generated at 2022-06-22 15:02:30.184801
# Unit test for function main
def test_main():
    root = os.path.abspath(os.path.dirname(__file__))
    output_path = os.path.join(root, 'tests/output')
    input_path = os.path.join(root, 'tests/examples/module_3.py')
    args = ['-i', input_path, '-o', output_path, '-t', '3.5', '-r', root]
    assert main(args) == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 15:02:31.631425
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:43.508411
# Unit test for function main
def test_main():
    class Args:
        def __init__(self, input, output, target, debug):
            self.input = input
            self.output = output
            self.target = target
            self.debug = debug

    # Function successfully completes
    args1 = Args(['tests/sources/input1/s1.py'],
                 'tests/sources/output1', '2.7', False)
    assert main(args1) == 0

    # Return 1 when input file doesn't exist
    args2 = Args(['tests/sources/input1/s5.py'],
                 'tests/sources/output1', '2.7', False)
    assert main(args2) == 1

    # Return 1 when output exists and is invalid

# Generated at 2022-06-22 15:02:44.774852
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:02:46.138945
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:15.548896
# Unit test for function main
def test_main():
    from click.testing import CliRunner
    from .main import main

    runner = CliRunner()
    result = runner.invoke(main,
                           ['-i', './tests/resources/tests.py',
                            '-t', 'python27',
                            '-o', './tests/resources/tests.py.compiled'])
    assert result.exit_code == 0

# Generated at 2022-06-22 15:04:16.919371
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:04:26.350213
# Unit test for function main
def test_main():
    from sys import version_info

    def helper(args, expected_target, expected_output, expected_retval):
        sys.argv[1:] = args
        retval = main()
        assert retval == expected_retval
        assert init_settings(args).target == expected_target
        assert init_settings(args).output == expected_output

    # test args are empty
    helper(['test.py'], '2.7', 'test.py', 1)

    # test args are wrong
    helper(['-i', 'foo', '-o', 'bar'], '2.7', 'bar', 1)

    # test args are ok
    helper(['-i', 'foo.py', '-o', 'bar', '-t', '2.7'], '2.7', 'bar', 0)

    # test

# Generated at 2022-06-22 15:04:29.539114
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'tests/resources/main_test', '-o', 'tests/output/main_test', '-t', '2.6', '-d']
    assert main() == 0
    sys.argv = ['', '-i', 'tests/resources/main_test', '-o', 'tests/output/main_test', '-t', '2.6']
    assert main() == 0



# Generated at 2022-06-22 15:04:32.480438
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'input.py', '-o', 'output.py', '-t', '3.4']
    assert main() == 0

# Generated at 2022-06-22 15:04:34.805887
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:44.973460
# Unit test for function main
def test_main():
    def _main():
        try:
            main()
        except SystemExit as e:
            return (e.code, [])
        except:
            return (1, [])
    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = sys.stderr = StringIO()
    args = ['-i', 'testdata/main/input.py', '-o', 'testdata/main/result.py',
            '-t', '2.7', '-d']
    code, _ = _main(args)
    sys.stdout.seek(0)
    sys.stderr.seek(0)
    assert code == 0

# Generated at 2022-06-22 15:04:50.058104
# Unit test for function main
def test_main():
    from unittest import mock
    from .cli import sys, main
    from . import exceptions
    from . import conf
    args = ["py-backwards", "-i", "folderWithValidPyFileInIt", "-o", "output",
            "-t", "2and7", "-r", "root", "-d"]
    with mock.patch.object(sys, 'argv', args):
        main()
        assert conf.settings.debug is True

# Generated at 2022-06-22 15:04:53.823125
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-d', '--input=test/', '--output=py-backwards.egg-info', '--target=python2.7']
    main()
    assert sys.exit() is not None

# Generated at 2022-06-22 15:05:04.045254
# Unit test for function main
def test_main():
    from py_backwards.__main__ import main
    # Test for main function
    main('-i main.py -o output/output.py -t 3.4'.split())
    main('-i main.py -o output/output.py -t 3.4'.split())

    # Test for syntax error
    args = '-i main.py -o output/output.py -t 3.4'.split()
    args.insert(3, '-d')
    main(args)

    # Test for transformation error
    main('-i main.py -o output/output.py -t 3.4'.split())

    # Test for input error
    main('-i n/a/n/a.py -o output/output.py -t 3.4'.split())

    # Test for output error