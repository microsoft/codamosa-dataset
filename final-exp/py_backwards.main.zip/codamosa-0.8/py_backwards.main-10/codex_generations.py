

# Generated at 2022-06-22 14:58:55.045811
# Unit test for function main
def test_main():
    print(main())
    


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:03.799702
# Unit test for function main
def test_main():
    saved_args = sys.argv
    sys.argv = ['py-backwards', '-i', 'file', '-o', 'file', '-t', '2.7',
                '-r', 'file', '-d']

    assert main() == 1

    sys.argv = ['py-backwards', '-i', 'file', '-o', 'file', '-t', '2.7',
                '-r', 'file']

    assert main() == 1

    sys.argv = saved_args

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 14:59:15.282548
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', '../tests/test_files/test_double_for.py', '-o', 'output.py', '-t', '2.7']
    assert(main() == 0)
    sys.argv = ['', '-i', '../tests/test_files/test_double_for.py', '-o', 'output.py', '-t', '3.5']
    assert(main() == 1)
    sys.argv = ['', '-i', '../tests/test_files/test.py', '-o', 'output.py', '-t', '2.7']
    assert(main() == 1)

# Generated at 2022-06-22 14:59:23.433966
# Unit test for function main
def test_main():
    from subprocess import check_call, run, PIPE, STDOUT
    # Negative test
    # 1) Input file doesn't exists
    try:
        check_call(f'python -m backwards -i nonexistent -o test -t py26',
                   shell=True)
        assert False
    except Exception:
        assert True
    # 2) Input is not a file or folder
    try:
        check_call(f'python -m backwards -i test -o test -t py26',
                   shell=True)
        assert False
    except Exception:
        assert True
    # 3) Output is not a folder

# Generated at 2022-06-22 14:59:24.082077
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:27.056066
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert isinstance(e, SystemExit) and e.code, e
    except Exception as e:
        assert not e, e
    else:
        assert False

# Generated at 2022-06-22 14:59:30.330628
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', [
        'py-backwards', '-i', 'file1.py', '-o', 'out.py', '-t', '3.6'
    ]):
        assert main() == 0

# Generated at 2022-06-22 14:59:31.645569
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:37.877784
# Unit test for function main
def test_main():
    test_args = ['py-backwards', '-i', 'C:\\Users\\dariu\\Documents\\GitHub\\py-backwards\\docs\\source\\index.rst',
                 '-o', 'C:\\Users\\dariu\\Documents\\GitHub\\py-backwards\\index.rst',
                 '-t', '-r', '.']
    test_args_parse = parser.parse_args(test_args)
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())
    print("\n" + "Ran 1 test in 0.000s")
    print("OK")

# Generated at 2022-06-22 14:59:40.782105
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as e:
        main()
    assert e.type is SystemExit
    assert e.value.code == 2

# Generated at 2022-06-22 15:00:00.773416
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', './foo.py', '-o', './bar.py', '-t', '27']
    assert main() == 0

# Generated at 2022-06-22 15:00:05.615302
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test/in', '-o', 'test/out', '-t', '35', '-d']
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:00:07.076791
# Unit test for function main
def test_main():
	# If the main function is as expected, return true
	return True

# Generated at 2022-06-22 15:00:07.665784
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:09.076099
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:10.559674
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-22 15:00:12.173236
# Unit test for function main
def test_main():
    '''
    func(inputFiles, outputFiles, target)
    '''
    assert main() == 0

# Generated at 2022-06-22 15:00:12.716395
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:00:14.405909
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-22 15:00:19.243078
# Unit test for function main
def test_main():
    argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.4', '-r', 'root', '-d']
    assert main(sys.argv[1:]) == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:42.132204
# Unit test for function main
def test_main():
    try:
        import pytest
    except:
        print("Start unit test for function main, you need install pytest")
    else:
        pytest.main(['-v', '-s', '--tb=line', 'tests/test_py36_compilation.py'])


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:52.271608
# Unit test for function main
def test_main():
    from argparse import Namespace
    from . import utils

    # Test normal inputs
    test_inputs = [
        ('tests/sources/test_compile_module.py', 'output/test_compile_module.py', '3.5'),
        ('tests/sources/test_compile_package', 'output/test_compile_package', '2.7'),
        ('tests/sources/test_compile_package', 'output/test_compile_package', '3.5'),
        ('tests/sources/test_compile_package', 'output/test_compile_package', '3.6'),
        ('tests/sources/test_compile_package', 'output/test_compile_package', '3.6')
    ]

# Generated at 2022-06-22 15:00:55.608453
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i', './test.py', '-o', './test.pyc', '-t',
                'python35']
    assert main() == 0

# Generated at 2022-06-22 15:00:56.164186
# Unit test for function main
def test_main():
    assert main() is 0

# Generated at 2022-06-22 15:00:57.739775
# Unit test for function main
def test_main():
    assert main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:58.613208
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-22 15:01:04.258143
# Unit test for function main
def test_main():
    from .settings import settings
    import io
    from contextlib import redirect_stdout

    f = io.StringIO()
    with redirect_stdout(f):
        assert main() == 0
    assert settings.input == ['test']
    assert settings.output == 'test'
    assert settings.target == 'py36'
    assert settings.debug == False
    assert f.getvalue() == 'Successfully compiled 0 files\n'

# Generated at 2022-06-22 15:01:08.582545
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'hello.py', '-o', 'hello_new.py',
                '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-22 15:01:15.277166
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_input/', '-o', 'tests/test_input/output/', '-t', '2.7', '-r', 'tests/test_input/', '-d']
    main()
    assert main.__doc__ == 'Python to python compiler that allows you to use some Python 3.6 features in older versions.'

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:21.768772
# Unit test for function main
def test_main():
    # Create the argparse namespace
    args = type('namespace', (object,), {"input": ["./tests/i.py"],
                                         "output": "./tests/o.py",
                                         "target": "python34",
                                         "root": "",
                                         "debug": False})

    try:
        result = main()
    except Exception as e:
        print(messages.error(e), file=sys.stderr)
        return 1

    assert result == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:57.636311
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:02:08.068166
# Unit test for function main
def test_main():
    # Test if syntax error is handled
    with patch('sys.argv', ['py-backwards', '-i', 'examples/test.py', '-o', 'output', '-t', '27']):
        assert main() == 1

    # Test if transformation error is handled
    with patch('sys.argv', ['py-backwards', '-i', 'examples/test_transform.py', '-o', 'output', '-t', '27']):
        assert main() == 1

    # Test if compile success
    with patch('sys.argv', ['py-backwards', '-i', 'examples', '-o', 'output', '-t', '27']):
        assert main() == 0

# Generated at 2022-06-22 15:02:14.241677
# Unit test for function main
def test_main():
    # Unit test for function main
    from unittest.mock import patch
    from py_backwards.conf import settings

    with patch('sys.argv', ['py-backwards', '-i', 'test.py', '-o', 'out.py',
                            '-t', '3.4']):
        main()
        assert settings.input == 'test.py'
        assert settings.output == 'out.py'
        assert settings.target == '3.4'

# Generated at 2022-06-22 15:02:18.730042
# Unit test for function main
def test_main():
    # target version below 3.6 -> print error and exit
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(['-i', 'test', '-o', 'test', '-t', '3.5', '-r', 'test'])
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # input is folder and doesnt exists -> print error and exit
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(['-i', 'test', '-o', 'test', '-t', '3.6', '-r', 'test'])
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code

# Generated at 2022-06-22 15:02:22.912757
# Unit test for function main
def test_main():
    # given
    sys.argv = [sys.argv[0], '-i', 'test_data/test_file.py', '-o', 'test_file_out.py', '-t', '3.6', '-r', 'test_data']
    result = main()
    # when
    with open('test_file_out.py', 'r') as output_file:
        output_file_content = output_file.read()
    # then
    assert result == 0
    assert output_file_content == 'test_file_content\n'
    # clean
    os.remove('test_file_out.py')

# Generated at 2022-06-22 15:02:30.301023
# Unit test for function main
def test_main():
    # trying to compile file without input
    sys.argv = [sys.argv[0]]
    assert main() == 1

    # trying to compile file without output
    sys.argv = [sys.argv[0], '-i', 'examples/test_1.py']
    assert main() == 1

    # trying to compile file without target
    sys.argv = [sys.argv[0], '-i', 'examples/test_1.py', '-o', 'test_1.py']
    assert main() == 1

    # trying to compile file on non-existing Python version
    sys.argv = [sys.argv[0], '-i', 'examples/test_1.py', '-o', 'test_1.py',
                '-t', 'python0.0']

# Generated at 2022-06-22 15:02:39.102264
# Unit test for function main
def test_main():
    from .conf import init_settings
    
    init_settings({"input": ["py_backwards/tests/test_dummy.py"], "output": "py_backwards/tests/test_dummy_output.py", "target": "python2", "root": "py_backwards/"})
    main()
    assert os.path.isfile("py_backwards/tests/test_dummy_output.py")
    os.remove("py_backwards/tests/test_dummy_output.py")

# Generated at 2022-06-22 15:02:39.830904
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:02:43.473435
# Unit test for function main
def test_main():
    args = ['prog_name.py', '-i', 'test/test_data/test_module/test_module.py', '-o', 'out.py',
            '-t', '3.5', '-r', 'root/']
    sys.argv = args
    main()

# Generated at 2022-06-22 15:02:45.620800
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:21.065425
# Unit test for function main
def test_main():
    from io import StringIO
    from contextlib import redirect_stdout

    # Testing no input
    sys.argv = ['py-backwards', '-i', '-o', 'test.py', '-t', 'py36']
    assert main() == 2

    # Testing no output
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', '-t', 'py36']
    assert main() == 2

    # Testing no target
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'out.py', '-t']
    assert main() == 2

    # Testing not existing input

# Generated at 2022-06-22 15:04:23.883293
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'src', '-o', 'build', '-t', 'Python 2',
                '-d']
    ret = main()
    assert ret == 0

# Generated at 2022-06-22 15:04:29.893626
# Unit test for function main
def test_main():    # pragma: no cover
    print('Testing main')
    import os
    import shutil
    import unittest.mock

    def stub_init_settings(args: ArgumentParser) -> None:
        return None

    def stub_compile_files(input_, output, target, root) -> int:
        return 1

    @unittest.mock.patch('argparse.ArgumentParser.parse_args',
                         return_value=('-i', '-o'))
    @unittest.mock.patch('py_backwards.conf.init_settings',
                         side_effect=stub_init_settings)
    def test_valid_inputs(parser, init_settings):
        assert 0 == main()


# Generated at 2022-06-22 15:04:41.484119
# Unit test for function main
def test_main():
    # testing normal behaviour
    sys.argv = ['py-backwards',
                '-i', 'test_input',
                '-o', 'test_output',
                '-t', 'py35',
                '-r', 'test_root',
                '-d']
    assert main() == 0

    # testing when source doesnt exist
    sys.argv = ['py-backwards',
                '-i', 'doesnt_exist',
                '-o', 'test_output',
                '-t', 'py35',
                '-r', 'test_root',
                '-d']
    assert main() == 1

    # testing input and output

# Generated at 2022-06-22 15:04:45.399581
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/resources/test_ast_rewriter_input.py','-o', 'test_ast_rewriter_output.py', '-t', '2.7']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:48.152873
# Unit test for function main
def test_main():
    # create input file
    file = open("test.py", "w")
    file.write("print(\"test\")")
    file.close()
    # check for error
    assert main() == 0
    # delete input file
    os.remove("test.py")

# Generated at 2022-06-22 15:04:59.170891
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'tests/data/main.py', '-o', 'output', '-t', '3']
    assert main() == 0

    sys.argv = ['py-backwards.py', '-i', 'wrong_input', '-o', 'output', '-t', '3']
    assert main() == 1

    sys.argv = ['py-backwards.py', '-i', 'tests', '-o', 'tests', '-t', '3']
    assert main() == 1

    sys.argv = ['py-backwards.py', '-i', 'tests/data/sources', '-o', 'output', '-t', '3']
    assert main() == 0

# Generated at 2022-06-22 15:05:09.200490
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-22 15:05:20.444059
# Unit test for function main
def test_main():
    from . import mocks
    from .test.utils import MockArgs
    from .test.test_compiler import test_compile_files

    mocks.create_files({
        'file1': ('def test():\n'
                  '    return\n'),
        'file2': ('def test():\n'
                  '    return\n'),
        'file3': ('def test():\n'
                  '    return\n')
    })

# Generated at 2022-06-22 15:05:30.121086
# Unit test for function main
def test_main():
  ######################################################
  # parameters tests
  ######################################################
  def test_parameters(parameters, expected):
    """
    Test function main with different parameters
    """
    with patch('sys.argv', parameters):
      assert main() == expected
    
  test_parameters(['py-backwards', '-i', 'tests/source' , '-o', 'tests/results', '-t', '3.5'], 0) # working parameters
  test_parameters(['py-backwards', '-i', 'tests/source' , '-o', 'tests/results', '-t', '3.10'], 1) # bad target version