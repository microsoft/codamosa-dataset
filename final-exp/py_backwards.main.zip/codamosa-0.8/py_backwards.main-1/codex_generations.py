

# Generated at 2022-06-22 14:58:39.095022
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:58:39.842527
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:58:41.832304
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:58:46.799934
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.extend(['-i', 'backwards/tests/sources', '-o', 'backwards/tests/output',
                     '-t', '2.7', '-r', 'backwards', '-d'])
    main()

# Generated at 2022-06-22 14:58:49.247417
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'input', '-o', 'output', '-t', 'py35',
                    '--debug']

# Generated at 2022-06-22 14:58:52.126342
# Unit test for function main
def test_main():
    a = ['-i', '-', '-o', '-', '-t', 'python2', '-r', '_']
    assert main(a) == 0

# Generated at 2022-06-22 14:58:54.330097
# Unit test for function main
def test_main():
    raise exceptions.InputDoesntExists('test'.encode())

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:02.326988
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('tests/files')
    sys.argv.append('-o')
    sys.argv.append('tests/files')
    sys.argv.append('-t')
    sys.argv.append('2.7')
    sys.argv.append('-r')
    sys.argv.append('tests')
    sys.exit(main())

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:13.631433
# Unit test for function main
def test_main():
    # Empty args
    with patch('sys.argv', ['py-backwards']):
        assert main() == 2

    # Successful compilation
    with patch('sys.argv', ['py-backwards', '-i', 'example.py', '-o',
                            'example_result.py', '-t', '2.7']):
        assert main() == 0

    # Wrong input output
    with patch('sys.argv', ['py-backwards', '-i', 'example.py', '-o',
                            'example_result.py', '-t', '2.7', '-r', '1/2']):
        assert main() == 1

    # Compilation error with folder as input

# Generated at 2022-06-22 14:59:15.075088
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:26.534365
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '--input', 'input_folder', '--output', 'output_folder', '--target', 'python37']
    assert main() == 0

# Generated at 2022-06-22 14:59:27.158588
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:36.017106
# Unit test for function main
def test_main():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path
    import re
    import pytest
    
    # Use a temporary directory to be able to delete it later
    tempdir = mkdtemp()
    

# Generated at 2022-06-22 14:59:46.390093
# Unit test for function main
def test_main():
    import os
    import time
    import shutil
    from .conf import settings
    from . import utils
    test_folder = os.path.join(os.path.dirname(__file__), 'test_folder')
    out_folder = os.path.join(os.path.dirname(__file__), 'test_folder_out')

    def tearDown():
        if os.path.exists(out_folder):
            shutil.rmtree(out_folder)


# Generated at 2022-06-22 14:59:51.196335
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '2.7']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:56.199726
# Unit test for function main
def test_main():
    result = []
    result.append(main())
    #  check for error
    result.append(main())
    result.append(main())
    result.append(main())
    result.append(main())
    result.append(main())
    result.append(main())
    result.append(main())

    return 0

# Generated at 2022-06-22 14:59:56.741076
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:58.049080
# Unit test for function main
def test_main():
    print(main())


# Generated at 2022-06-22 15:00:03.808397
# Unit test for function main
def test_main():
    '''test_main()'''
    from pytest import raises
    from . import exceptions
    from . import settings
    from . import const
    from . import compiler
    from . import utils

    settings.DEBUG = True
    with raises(exceptions.InputDoesntExists):
        main()

    compiler.compile_files = lambda x,y,z,w: True
    utils.read_file = lambda x: True
    const.TARGETS = {}
    main()
    utils.read_file = lambda x: 'import re\nre.match'

    with raises(exceptions.TransformationError):
        main()

# Generated at 2022-06-22 15:00:04.421882
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:22.915041
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:00:30.578149
# Unit test for function main
def test_main():
    sys.argv.append("-i")
    sys.argv.append("tests/data/class_new.py")
    sys.argv.append("-o")
    sys.argv.append("/home/zalex/out_")
    sys.argv.append("-t")
    sys.argv.append("py26")
    sys.argv.append("-r")
    sys.argv.append("tests/data")
    assert(main()) == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:31.158995
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:43.791508
# Unit test for function main
def test_main():
    from io import StringIO
    from sys import stdout
    from .conf import settings

    sys.argv = ['py-backwards', '-i', 'tests/resources/test_1/my_package',
            '-o', 'tests/output', '-t', '3.3',
            '-r', 'tests/resources']
    old_stdout = sys.stdout
    captured_output = StringIO()

# Generated at 2022-06-22 15:00:46.128142
# Unit test for function main
def test_main():
    input = ['tests/test_folder/test1.py']
    output = 'test_output.py'
    target = 'python_36'
    assert main(input, output, target) == 0

# Generated at 2022-06-22 15:00:54.899607
# Unit test for function main
def test_main():
    # A test for file that throws an exception
    test_input_1 = ['./tests/test_files/test_file_1.py']
    test_output_1 = 'test_file_1.py'
    test_target_1 = '2.7'
    sys.argv = ['py-backwards', '-i', test_input_1, '-o', test_output_1,
                '-t', test_target_1, '-r', '.']
    assert main() == 1

# Generated at 2022-06-22 15:01:00.636155
# Unit test for function main
def test_main():
    # Tests for correct arguments
    assert(main(['-i', 'sources/main.py', '-o', 'output.py',
                 '-t', 'py35', '-d']) == 0)
    assert(main(['-i', 'sources/main.py', '-o', 'output/', '-t', 'py35',
                 '-d']) == 0)
    assert(main(['-i', 'sources/', '-o', 'output/', '-t', 'py35', '-d']) == 0)
    assert(main(['-i', 'sources/main.py', '-o', 'output.py', '-t', 'py35',
                 '-r', 'sources/', '-d']) == 0)
    # Tests for incorrect arguments

# Generated at 2022-06-22 15:01:01.601353
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-22 15:01:03.373989
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:01:05.117458
# Unit test for function main
def test_main():
    result = main()
    assert result == 0 or result == 1

# Generated at 2022-06-22 15:01:42.331698
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:44.084866
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:01:44.621602
# Unit test for function main
def test_main():
    assert main == 0

# Generated at 2022-06-22 15:01:47.813209
# Unit test for function main
def test_main():
    # TODO: temp
    from io import StringIO
    from contextlib import redirect_stdout
    out = StringIO()
    with redirect_stdout(out):
        main()
    print(out.getvalue())
    assert False

# Generated at 2022-06-22 15:01:48.555812
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:53.850604
# Unit test for function main
def test_main():
    const.DEBUG = True
    parser = ArgumentParser('py-backwards')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    parser.add_argument('-d', '--debug', action='store_true', required=False,
                        help='enable debug output')
    args = parser

# Generated at 2022-06-22 15:02:03.701393
# Unit test for function main
def test_main():
    import filecmp
    import os
    import shutil
    import pytest
    from .compiler import compile_files
    from .conf import settings
    from . import const, exceptions

    # copy tests from project folder
    test_dir = os.path.join(os.getcwd(), 'tests')
    shutil.rmtree(test_dir, ignore_errors=True)
    shutil.copytree('../tests', test_dir)
    shutil.rmtree(os.path.join(test_dir, '__pycache__'), ignore_errors=True)

    # remove result dirs
    paths = [
        os.path.join(test_dir, name)
        for name in os.listdir(test_dir)
        if 'result' in name
    ]
    for dir_ in paths:
        shut

# Generated at 2022-06-22 15:02:04.696765
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-22 15:02:07.745748
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', '.', '-o', '../output', '-t', 'py27']
    assert main() == 0
    return

# Generated at 2022-06-22 15:02:08.304558
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:03:33.090248
# Unit test for function main
def test_main():
    sys.argv += ['a.py', 'b.py']
    assert main() == 1

    sys.argv += ['-i', 'b.py', 'a.py', '-o', '-t', '2.6', 'c.py']
    assert main() == 1

    sys.argv += ['-i', 'b.py', 'a.py', 'c.py', '-o', '.', '-t', '2.6']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:03:42.753904
# Unit test for function main
def test_main():
    test_data = [
        # test_data: (input, output, target, root, debug)
        ([], [], '', '', False),
        (['1.py'], [], '', '', False),
        ([], ['1.py'], '', '', False),
        (['1.py'], ['1.py'], '', '', False),
        (['1.py'], ['2.py'], '', '', False),
    ]
    for arg in test_data:
        with patch('sys.argv', ['name', '-i', arg[0], '-o', arg[1], '-t',
                                arg[2], '-r', arg[3], '-d', arg[4]]):
            main()

if __name__ == '__main__':
    test

# Generated at 2022-06-22 15:03:50.456053
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'test/input/test.py', '-o',
                'test/output/test.py', '-t', '3.5', '-r', '.']

    assert main() == 0

    sys.argv = ['py-backwards.py', '-i', 'test/input/test.py', '-o',
                'test/output/test.py', '-t', '3.8', '-r', '.']

    assert main() == 1

    sys.argv = ['py-backwards.py', '-i', 'test/input/test.py', '-o',
                'test/output/test.py', '-t', 'wrong', '-r', '.']

    assert main() == 2


# Generated at 2022-06-22 15:03:59.855541
# Unit test for function main
def test_main():
    # Arrange
    import os

    input_ = 'test_input'
    output = 'test_output'
    target = '3.5'
    target_ = '3.6'

    name = '__main__'
    script_ = 'print("Hello, World!")'
    script = 'print("Hello, World!")'
    script__ = 'print("Hello, World!")'

    os.mkdir(input_)
    os.mkdir(output)

    with open(os.path.join(input_, '%s.py' % name), 'w') as file:
        file.write(script)

    with open(os.path.join(input_, '%s.py' % name), 'w') as file:
        file.write(script_)


# Generated at 2022-06-22 15:04:04.181896
# Unit test for function main
def test_main():
    pass
    # args = [(['-i', 'tests/test_input.py', '-o', 'tests/test_output.py', '-t', '3.5', '-r', 'tests/test_input.py'], 1)]
    # for arg, expected_result in args:
    #     assert main(arg) == expected_result


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:14.119849
# Unit test for function main
def test_main():
    # Input doesn't exists
    with pytest.raises(SystemExit):
        main()

    # Valid input and output
    sys.argv = sys.argv[:1] + ['-i', 'setup.py', '-o', 'out.py', '-t', '27']
    assert main() == 0

    sys.argv = sys.argv[:1] + ['-i', 'templates', '-o', 'out', '-t', '35']
    assert main() == 0

    # Invalid input or output
    sys.argv = sys.argv[:1] + ['-i', 'setup.py', '-o', 'setup.py', '-t', '27']
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-22 15:04:24.415337
# Unit test for function main
def test_main():
    # remove python 3.5 support
    # FIXME: mock sys.argv
    sys.argv[1] = 'py-backwards'
    sys.argv[2] = '-i'
    sys.argv[3] = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'tests', 'fixtures', 'test.py')
    sys.argv[4] = '-o'
    sys.argv[5] = '__test_main_output__.py'
    sys.argv[6] = '-t'
    sys.argv[7] = 'py35'
    sys.argv.append('-d')

    # make sure output doesn't exist

# Generated at 2022-06-22 15:04:25.960464
# Unit test for function main
def test_main():
    sys.argv = ['test_file']
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:26.437818
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-22 15:04:37.996489
# Unit test for function main
def test_main():
    # Create tmp folder
    import os
    import shutil
    import tempfile
    tempdir = tempfile.mkdtemp()

    # Create test file
    in_file = os.path.join(tempdir, 'test.py')
    out_file = os.path.join(tempdir, 'test_converted.py')

    with open(in_file, 'w') as f:
        f.write('a, b, c = 5, 3, 2\nprint(a + b + c)\n')

    # Create args
    from argparse import Namespace
    args = Namespace(
        input=[in_file], output=out_file, target='2.7', root=tempdir)

    result = main(args)
    assert result == 0

    # Check output

# Generated at 2022-06-22 15:08:13.420283
# Unit test for function main
def test_main():
    # No errors in command line
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'output.py',
                '-t', '3.5', '-r', 'root']
    assert main() == 0

    # Error: no input
    sys.argv = ['py-backwards', '-o', 'output.py', '-t', '3.5', '-r', 'root']
    assert main() == 2

    # Error: no output
    sys.argv = ['py-backwards', '-i', 'test.py', '-t', '3.5', '-r', 'root']
    assert main() == 2

    # Error: no target

# Generated at 2022-06-22 15:08:13.944390
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:08:21.112106
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/data/target_python.py',
                '-o', 'target_python.py', '-t', 'python2', '-d', '-r',
                'tests/data']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', 'tests/data/target_python.py',
                '-o', 'target_python.py', '-t', 'python2']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', 'tests/data/target_python.py',
                '-o', 'target_python.py', '-t', 'python3']
    assert main() == 0

    #Test of exceptions
    sys.arg

# Generated at 2022-06-22 15:08:21.926833
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:08:24.832620
# Unit test for function main
def test_main():
    assert main(['-i', './src/test/test_data/test1.py', '-o', 'out.py', '-t', '3.6']) == 0

# Generated at 2022-06-22 15:08:31.704061
# Unit test for function main
def test_main():
    # Test invalid file
    argv = ['py-backwards', '-i', 'test/test_data/test_main_data/not_exists',
            '-o', 'test/test_data/test_main_data/not_exists']
    assert main(argv) == 1

    # Test invalid output
    argv = ['py-backwards', '-i', 'test/test_data/test_main_data/input.py',
            '-o', 'test/test_data/test_main_data/input.py']
    assert main(argv) == 1

    # Test syntax error