

# Generated at 2022-06-22 14:58:45.457340
# Unit test for function main
def test_main():
    # no args
    result = main()
    assert result == 2

    sys.argv = ['py-backwards', '-h']
    result = main()
    assert result == 0

    # wrong input
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '2.7']
    result = main()
    assert result == 1

    # wrong target version
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.7']
    result = main()
    assert result == 2

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:58:55.853878
# Unit test for function main
def test_main():
    import sys
    from contextlib import redirect_stdout

    from tempfile import NamedTemporaryFile, TemporaryDirectory
    from . import runtime, utils

    with NamedTemporaryFile(mode='w', suffix='.py') as tmp:
        tmp.write('print("Hello world")')
        tmp.seek(0)

        with TemporaryDirectory() as tmp_dir:
            sys.argv = 'py-backwards -i {} -o {} -t python36'.format(
                tmp.name, tmp_dir).split()
            main()

            assert utils.list_files(tmp_dir)
            assert runtime.run_output(
                utils.find_file(tmp_dir,
                                lambda x: x.endswith('.py'))) == 'Hello world\n'

    # Testing error generation

# Generated at 2022-06-22 14:58:59.022821
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:00.752728
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-22 14:59:03.075144
# Unit test for function main
def test_main():
    assert __name__ == '__main__'


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:09.917086
# Unit test for function main
def test_main():
    # "test" folder doesn't exists, so exception InputDoesntExists should be
    #  raised
    with pytest.raises(SystemExit):
        main(['-i', 'test', '-o', 'output', '-t', '2.7'])

    # File "pybackwards/__init__.py" exists, so compilation should be
    # successful
    main(['-i', 'pybackwards/__init__.py', '-o', 'output', '-t', '2.7'])

    # Input file "pybackwards/__init__.py" exists, but its not a python file,
    # so exception InputDoesntExists should be raised

# Generated at 2022-06-22 14:59:14.136760
# Unit test for function main
def test_main():
    try:
        path = Path(__file__).parent.absolute() 
        subprocess.run(['python', path / 'tests' / '__init__.py'])
        assert True
    except Exception as error:
        assert False, error

# Generated at 2022-06-22 14:59:18.253864
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'tests/files_for_tests', '-o', '../outputs',
                '-t', '2.7', '-r', 'tests']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:24.582459
# Unit test for function main
def test_main():
    # testing the case of successful compilation
    sys.argv = ["py-backwards", "-i", "tests/data/main_case1", "-o", "out", "-t", "2.7", "-r", "tests"]
    assert main() == 0

    # case of unsuccessful compilation
    sys.argv = ["py-backwards", "-i", "tests/data/main_case2", "-o", "out", "-t", "2.7", "-r", "tests"]
    assert main() == 1

    # case of unsuccessful compilation
    sys.argv = ["py-backwards", "-i", "tests/data/main_case3", "-o", "out", "-t", "2.7", "-r", "tests"]
    assert main() == 1

    # case of PermissionError

# Generated at 2022-06-22 14:59:34.121768
# Unit test for function main
def test_main():

    # Test simple case
    from .testing import make_file, remove_files
    from .conf import settings

    make_file(
        'source.py',
        'def foo():\n'
        '    return 1\n'
        'print(foo())'
    )
    sys.argv = ['--input', 'source.py', '--output', 'dest.py', '--target', 'py27']
    main()
    assert settings.input[0].endswith('source.py')
    assert settings.output.endswith('dest.py')
    remove_files(['source.py', 'dest.py'])

    # Test invalid flags
    sys.argv = ['-i', 'source.py', '-o', 'dest.py', '-t', 'py27']
    assert main() == 2

# Generated at 2022-06-22 14:59:54.595931
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new_callable=StringIO):
        with patch('py_backwards.compiler.compile') as compile:
            compile.return_value = {'test': {'test.py': 'test'}}
            sys.argv[1:] = ('-i test -o output -t 3.5 -r /root'.split())
            assert main() == 0
            sys.argv[1:] = ('-i test -o output -t 3.5 -r /root'.split())
            assert main() == 0
            sys.argv[1:] = ('-i test1 test2 -o output -t 3.5 -r /root'.split())
            assert main() == 0

# Generated at 2022-06-22 15:00:05.950074
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '--input', 'tests/files/for_unittest/sources',
        '--output', 'tests/files/for_unittest/py3.6',
        '--target', '3.6',
        '--root', 'tests/files/for_unittest/sources'
    ]
    assert main() == 0
    sys.argv = [
        'py-backwards',
        '--input', 'not_exists.py',
        '--output', 'tests/files/for_unittest/py3.6',
        '--target', '3.6',
        '--root', 'tests/files/for_unittest/sources'
    ]
    assert main() == 1

# Generated at 2022-06-22 15:00:06.814471
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:07.397105
# Unit test for function main
def test_main():
    assert 0 == main()

# Generated at 2022-06-22 15:00:07.990316
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:15.920244
# Unit test for function main
def test_main():
    arguments = ArgumentParser()
    arguments.add_argument('-i', '--input', type=str, nargs='+', required=True, help='input file or folder')
    arguments.add_argument('-o', '--output', type=str, required=True, help='output file or folder')
    arguments.add_argument('-t', '--target', type=str, required=True, choices=const.TARGETS.keys(), help='target python version')
    arguments.add_argument('-r', '--root', type=str, required=False, help='sources root')
    arguments.add_argument('-d', '--debug', action='store_true', required=False, help='enable debug output')
    args = arguments.parse_args()
    init_settings(args)
    assert main() == 0
    #assert

# Generated at 2022-06-22 15:00:27.597283
# Unit test for function main
def test_main():
    import sys
    import pytest
    from io import StringIO

    class Args:
        input = ['test_main.py']
        output = 'out'
        target = 'v35'
        root = 'test_root'
        debug = True

    sys.argv = ['py-backwards', '-i', 'test_main.py', '-o', 'out', '-t', 'v35',
                '-r', 'test_root', '-d']
    with StringIO() as buf, redirect_stderr(buf):
        assert main() == 0
        output = buf.getvalue()
        assert output == """Compiled 1 files
Compilation results:
- test_main.py (skipped)
"""

# Generated at 2022-06-22 15:00:33.571724
# Unit test for function main
def test_main():
    class Parser():
        def parse_args(self):
            class Args:
                def __init__(self, input, output, target, root, debug):
                    self.input = input
                    self.output = output
                    self.target = target
                    self.root = root
                    self.debug = debug
            return Args('input', 'output', '2.7', 'root', True)
    import pkg_resources
    sys.modules.pop('py_backwards.__main__', None)
    sys.modules.pop('py_backwards', None)
    sys.path.append(pkg_resources.resource_filename('py_backwards', '..'))
    sys.modules['py_backwards.__main__'] = reload(sys.modules['py_backwards.__main__'])

# Generated at 2022-06-22 15:00:45.010447
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-22 15:00:57.057751
# Unit test for function main
def test_main():
    args = sys.argv[:]
    sys.argv = ['py-backwards', '-i', 'test/examples/a.py', '-o', 'tmp', '-r', 'src', '-t', 'python2']
    assert(main() == 0)
    sys.argv = args[:]
    sys.argv = ['py-backwards', '-i', 'test/examples/b.py', '-o', 'tmp', '-r', 'src', '-t', 'python2']
    assert(main() == 0)
    sys.argv = args[:]
    sys.argv = ['py-backwards', '-i', 'test/examples/c.py', '-o', 'tmp', '-r', 'src', '-t', 'python2']

# Generated at 2022-06-22 15:01:21.323723
# Unit test for function main
def test_main():
    with open('test_main', 'w') as f:
        f.write('print("Hello world!")\n')
    sys.argv = ['py-backwards', '-i', 'test_main', '-o', 'out.py', '-t', '27']
    try:
        assert main() == 0
        with open('out.py', 'r') as res:
            assert res.read() == 'print "Hello world!"\n'
    finally:
        os.remove('test_main')
        os.remove('out.py')

# Generated at 2022-06-22 15:01:21.983049
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:33.189133
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test_output.py', '-t', '3.5', '-d']
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test_output.py', '-t', '3.5', '-d']
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test_output.py', '-t', '3.5', '-d']
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test_output.py', '-t', '3.5', '-d']

# Generated at 2022-06-22 15:01:36.286346
# Unit test for function main
def test_main():
    class Args:
        debug = True
        input = 'tests/input'
        output = 'tests/output'
        target = 'py26'

    init_settings(Args)
    result = main()
    assert result == 0

# Generated at 2022-06-22 15:01:42.462017
# Unit test for function main
def test_main():
    import sys
    from io import StringIO
    from contextlib import contextmanager

    with stdoutIO() as s:
       main()
       output = s.getvalue()
       assert output == 'No input files\n'

    with stdoutIO() as s:
        main(['-i', 'test.py', '-o', '__test__/test.py', '-t', '3'])
        output = s.getvalue()
        assert output.startswith('Success')

    with stdoutIO() as s:
        main(['-i', 'test.py', '-o', '__test__/test.py', '-t', '3', '-r', '.'])
        output = s.getvalue()
        assert output.startswith('Success')


# Generated at 2022-06-22 15:01:46.764658
# Unit test for function main
def test_main():
    args = sys.argv
    sys.argv = ["py_backwards", "-i", "py_backwards", "-o", "py_backwards/compiled", "-t", "2.7", "-d"]
    assert main() == 0
    sys.argv = args


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:50.409623
# Unit test for function main
def test_main():
    with patch('argparse.ArgumentParser.parse_args',
               return_value=argparse.Namespace(
                   input='path/to/file', output='output/file',
                   target='py35', root='sources/root', debug=False)):
        assert main() == 0

# Generated at 2022-06-22 15:01:52.224568
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:01:53.678332
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:58.557070
# Unit test for function main
def test_main():
    """
    Unit test for main. Tests if a given compilation error is reported by the
    code
    """

    sys.argv = [sys.argv[0], '-i', 'tests/data/syntax_error/',
                '-o', 'test.out',
                '-t', 'python35', '-r', 'tests/data/syntax_error']
    assert main() == 1

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:02:46.017116
# Unit test for function main
def test_main():
    from io import StringIO
    import os
    import tempfile
    from . import const, exceptions

    with tempfile.TemporaryDirectory() as temp_dir:
        # no argument
        with StringIO() as buf, redirect_stdout(buf):
            assert main()
        assert buf.getvalue() == messages.invalid_args()

        # wrong target
        f = open(os.path.join(temp_dir, 'file.py'), 'w')
        f.close()
        args = ['-i', 'file.py', '-o', 'file2.py', '-t', 'blabla']
        with StringIO() as buf, redirect_stdout(buf):
            assert main(args)
        assert buf.getvalue() == messages.invalid_args()

        # valid compilation

# Generated at 2022-06-22 15:02:57.092637
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'unittests/input.py', '-o', 'unittests/output.py',
                    '-t', '2.7', '-d']
    assert main() == 0

    with open('unittests/output.py') as output:
        assert 'from __future__ import __format__\n' in output.read()
        assert 'print(f"{x}", file=sys.stderr)' in output.read()
        assert 'for i in range(10):\n' in output.read()
        assert 'return {key: value for key, value in d.items()}\n' in output.read()
        assert 'def test():\n' in output.read()
        assert 'await asy()' in output.read()

# Generated at 2022-06-22 15:03:01.384863
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/example/input', '-o',
                'tests/example/output', '-t', '2.7', '-r', 'tests/example']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:03:05.695020
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'sample.py', '-o', 'output.py',
                '-t', '3.5']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:03:09.460445
# Unit test for function main
def test_main():
    import pytest
    import os
    os.system("python -m py_backwards -i examples/test1.py -o output.py -t py27")

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:03:16.122350
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('tests/bad_programs/v3.5/comp3.py')
    sys.argv.append('-o')
    sys.argv.append('output.py')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    assert(main() == 0)
    os.remove('output.py')

# Generated at 2022-06-22 15:03:19.041370
# Unit test for function main
def test_main():
    sys.argv = "py3to2.py -i input.py -o out.py -t 2.7".split()
    assert main() == 0
    init_settings(None)

# Generated at 2022-06-22 15:03:27.283661
# Unit test for function main
def test_main():
    class Args:
        def __init__(self):
            self.input = ['test/test_file.py']
            self.output = '.temp'
            self.target = '3.3'
            self.root = 'test'
            self.debug = True
    
    sys.argv = ['']
    args = Args()
    main()
    assert os.path.exists('.temp/output_target.py')
    if os.path.exists('.temp/output_target.py'):
        os.remove('.temp/output_target.py')

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:03:37.389506
# Unit test for function main
def test_main():
    import pytest
    import os
    import shutil
    import tempfile

    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 2

    global __name__
    __name__ = '__main__'

    with tempfile.TemporaryDirectory() as d:
        os.makedirs(os.path.join(d, 'a'))
        os.makedirs(os.path.join(d, 'b'))
        input_ = os.path.join(d, 'a')
        output = os.path.join(d, 'b')
        os.path.join(input_, 'main.py')

# Generated at 2022-06-22 15:03:38.157504
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:05:04.368615
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:05:15.748373
# Unit test for function main
def test_main():
    from . import test_system as TS
    import unittest
    import sys
    import os

    def create_test_file(folder, name):
        with open(os.path.join(folder, name), 'w') as f:
            f.write("def f():\n"
                    "    a = 1\n"
                    "    b = 2\n"
                    "    c = 3\n"
                    "    return a + b + c")

    temp_dir = os.path.join(TS.test_dir, 'compiler')
    try:
        os.mkdir(temp_dir)
    except FileExistsError:
        pass


# Generated at 2022-06-22 15:05:19.212322
# Unit test for function main
def test_main():
    out = StringIO()
    sys.stdout = out
    main()
    sys.stdout = sys.__stdout__
    out.seek(0)
    print(out.readlines())

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:05:20.996350
# Unit test for function main
def test_main():
    #TODO: write unit test
    assert 1 == 1

# Generated at 2022-06-22 15:05:30.502147
# Unit test for function main
def test_main():
    # Happy path test
    sys.argv = ['py-backwards', '-i', 'main.py', '-t', '2.7', '-o', 'output/']
    main()

    # Invalid input
    sys.argv = ['py-backwards', '-i', 'main.py, folder2', '-t', '2.7', '-o', 'output/']
    with pytest.raises(SystemExit):
        main()

    # Invalid output
    sys.argv = ['py-backwards', '-i', 'main.py', '-t', '2.7', '-o', 'folder/']
    with pytest.raises(SystemExit):
        main()

    # Invalid Source root

# Generated at 2022-06-22 15:05:33.935699
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 1 or 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:05:39.852760
# Unit test for function main
def test_main():
    argv = sys.argv
    try:
        sys.argv = sys.argv[:1] + ['arg1', 'arg2', 'arg3', 'arg4', 'arg5']
        assert main() is not None
    finally:
        sys.argv = argv


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:05:40.761442
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:05:45.605398
# Unit test for function main
def test_main():
    with open('input.txt', 'w', encoding='utf-8') as file:
        file.write('a\nb\nc\n')
    with open('output.txt', 'w', encoding='utf-8') as file:
        file.write('a\nd\nc\nb\n')
    
    assert main() == 1
    assert 'input.txt' in messages.input_doesnt_exists(['input.txt'])
    assert 'output.txt' in messages.invalid_output('input.txt', 'output.txt')
    
    assert main() == 1
    assert 'permission' in messages.permission_error('output.txt')
    
    assert main() == 0
    assert 'compiled' in messages.compilation_result([(('input.txt',),)])


# Generated at 2022-06-22 15:05:48.060124
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        sys.exit(main())