

# Generated at 2022-06-22 14:58:43.684305
# Unit test for function main
def test_main():
    sys.argv[1:] = ['main.py', '-i', 'main.py', '-o', 'out.py', '-t', '2']
    print(sys.argv)
    main()

# Main function for the py-backwards compiler
if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:58:46.627432
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/fixtures/input.py', '-o', 'output.py', '-t', '3.3']
    assert(main() == 0)

# Generated at 2022-06-22 14:58:56.754016
# Unit test for function main

# Generated at 2022-06-22 14:58:57.715905
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-22 14:59:04.089586
# Unit test for function main
def test_main():
    path = os.path.dirname(os.path.realpath(__file__))
    input = path + '/tests/inputs/'
    output = path + '/tests/outputs/'
    python = str(sys.version_info.major) + '.' + str(sys.version_info.minor)
    sys.argv = [sys.argv[0], '-i', input, '-o', output, '-t', python]
    assert main() == 0

# Generated at 2022-06-22 14:59:10.515265
# Unit test for function main
def test_main():
    # Test with no args
    sys.argv = ['']
    assert main() == 2

    # Test with -h
    sys.argv = ['', '-h']
    assert main() == 0

    # Test with invalid root path
    sys.argv = ['', '-i', 'tests/data', '-o', '.', '-t', '3.5', '-r', 'asd']
    assert main() == 1

    # Test with invalid input path
    sys.argv = ['', '-i', 'asd', '-o', '.', '-t', '3.5']
    assert main() == 1

    # Test with invalid input path
    sys.argv = ['', '-i', 'asd', '-o', '.', '-t', '3.5']

# Generated at 2022-06-22 14:59:12.193222
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except SystemExit:
        pass

# Generated at 2022-06-22 14:59:22.016333
# Unit test for function main
def test_main():
    # Test for default compile_files
    result = main()
    assert result == 0
    
    result = main("-i", "pybackwards/examples/test_compiler.py", "-o", "pybackwards/examples", "-t", "2.7", "-r", "pybackwards/examples")
    assert result == 0

    result = main("-i", "pybackwards/examples/test_compiler.py", "-o", "pybackwards/examples", "-t", "2.7", "-r", "pybackwards/examples")
    assert result == 0

    result = main("-i", "pybackwards/examples/does_not_exist.py", "-o", "pybackwards/examples", "-t", "2.7", "-r", "pybackwards/examples")
   

# Generated at 2022-06-22 14:59:28.007842
# Unit test for function main
def test_main():
    sys.argv[1] = '-i'
    sys.argv[2] = './py_backwards/tests/data/example.py'
    sys.argv[3] = '-o'
    sys.argv[4] = './py_backwards/tests/data/result.py'
    sys.argv[5] = '-t'
    sys.argv[6] = '3.5'
    main()

# Generated at 2022-06-22 14:59:31.309629
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i',
                'tests/example.py', '-o',
                'output', '-t', '2.7',
                '-d', '-r', 'root']
    main()

# Generated at 2022-06-22 14:59:49.774951
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:00:00.509191
# Unit test for function main
def test_main():
    with patch('argparse.ArgumentParser.parse_args',
               return_value=Namespace(
                   input=['tests'],
                   output='test_package',
                   target='2.7',
                   debug=False,
                   root='/home/user/dev/py-backwards-dev/'
               )):
        with patch('py_backwards.conf.init_settings'):
            with patch('py_backwards.compiler.compile_files',
                       return_value=Namespace(
                           added=2,
                           changed=0,
                           skipped=0,
                           failed=0
                       )):
                assert main() == 0


# Generated at 2022-06-22 15:00:04.639511
# Unit test for function main
def test_main():
    return_code = main("tests/data/basic.py", "tests/data/basic.out.py", "2.7")
    assert return_code == 0
    return_code = main("tests/data/basic.py", "tests/data/basic.out.py", "3.5")
    assert return_code == 0
    return_code = main("tests/data/basic.py", "tests/data/basic.out.py", "3.6")
    assert return_code == 0

# Generated at 2022-06-22 15:00:06.814573
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:07.753039
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-22 15:00:12.215908
# Unit test for function main
def test_main():
    argv = ['py-backwards.py', '-i', 'test/data/a.py',
            '-o', 'out', '-t', '3.5']
    assert main(argv) == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:00:18.004535
# Unit test for function main
def test_main():
    input_ = str(__file__)
    output = "output.py"
    target = 3.2
    #root = "../../backwards"
    try:
        main(input_, output, target, None)
    except:
        print('Test of main failed')

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-22 15:00:18.671466
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:00:30.082912
# Unit test for function main
def test_main():
    from unittest import mock
    from argparse import _SubParsersAction

    def arg_parse(input: str) -> str:
        if '-i' not in input:
            return ""
        if '-o' not in input:
            return ""
        if '-t' not in input:
            return ""
        return "arg_parse"

    def compile_files(input: str, output: str, target: str, root: str) -> None:
        if input != 'input.py':
            return ''
        if output != 'output.py':
            return ''
        if target != '3.6':
            return ''
        if root != 'root':
            return ''
        return 'compile_files'


# Generated at 2022-06-22 15:00:42.899157
# Unit test for function main
def test_main():
    test_file_path = 'test.py'

    # Create test file
    test_file = open(test_file_path, 'w')
    test_file.write('print("Hello World!")')
    test_file.close()

    # Test for correct compilation
    test_args = ArgumentParser()
    test_args.input = [test_file_path]
    test_args.output = 'out.py'
    test_args.target = 'py35'
    test_args.root = './'
    test_args.debug = False
    assert main() == 0

    # Test for incorrect compilation
    test_args = ArgumentParser()
    test_args.input = []
    test_args.output = 'out.py'
    test_args.target = 'py35'

# Generated at 2022-06-22 15:01:05.164747
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'testdata/test_main/input', '-o',
                'testdata/test_main/output', '-t', 'py27' , '-r',
                'testdata/test_main/input']
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:07.667472
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:01:18.410706
# Unit test for function main
def test_main():
    encode = sys.getdefaultencoding()
    sys.argv = ['py-backwards','-i', './tests/py_file_in.py',
                '-o', './tests/py_file_out.py', '-t', '2.7']
    main()
    assert filecmp.cmp('./tests/py_file_out_expected.py',
                       './tests/py_file_out.py', shallow=True)
    sys.argv = ['py-backwards','-i', './tests/py_file_in.py',
                '-o', './tests/py_file_out.py', '-t', '1.5']
    main()

# Generated at 2022-06-22 15:01:24.844518
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-22 15:01:28.278023
# Unit test for function main
def test_main():
    assert main(["-i", "test.py", "-o", "testout.py", "-t", "2.7", "-d", "TRUE"]) == 0

# Generated at 2022-06-22 15:01:29.445813
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:01:30.311279
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:31.876623
# Unit test for function main
def test_main():
    assert main() == 1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:01:32.415431
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:01:40.265543
# Unit test for function main
def test_main():
    from . import testutils
    from . import messages
    from .conf import set_debug

    errors = []

    errors.append(testutils.test_exception(
        main, ['-i', 'test_input', '-o', 'test_output', '-t', '3.4'],
        messages.input_doesnt_exists('test_input')
    ))

    errors.append(testutils.test_exception(
        main, ['-i', 'test_input', '-o', 'test_input', '-t', '3.4'],
        messages.invalid_output('test_input', 'test_input')
    ))


# Generated at 2022-06-22 15:02:27.500274
# Unit test for function main
def test_main():
    from unittest import mock
    from .context import parse_args_mock
    from .compiler import compile_files_mock

    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')

# Generated at 2022-06-22 15:02:31.317287
# Unit test for function main
def test_main():
    args = main.__code__.co_varnames
    assert args[0] == 'self'
    assert args[1] == 'in_file'
    assert args[2] == 'out_file'
    assert args[3] == 'target'
    assert args[4] == 'root'
    assert args[5] == 'debug'

# Generated at 2022-06-22 15:02:33.661249
# Unit test for function main
def test_main():
    input_

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 15:02:38.945842
# Unit test for function main
def test_main():
    for arg in ['-h', '--help']:
        sys.argv = [arg]
        try:
            assert main() == 0
        except AssertionError:
            print('our program should exit gracefully.')
    sys.argv = ['-i', 'input_file.py', '-o', 'output_file.py', '-t', '2']
    try:
        assert main() == 1
    except exceptions.InputDoesntExists:
        print('compilation error should be caught')
    sys.argv = ['-i', 'test_file_null.py', '-o', 'output_file.py', '-t', '2']
    try:
        assert main() == 1
    except exceptions.CompilationError:
        print('compilation error should be caught')

# Generated at 2022-06-22 15:02:50.066120
# Unit test for function main
def test_main():
    # Test: no arguments
    sys.argv = [sys.argv[0],]
    assert main() == 2

    # Test: bad filepath
    sys.argv = [sys.argv[0],
                '-i', 'decorators.py',
                '-o', '.',
                '-t', '2.7',
                '-r', '.',
                '-d']
    assert main() == 1

    # Test: bad target
    sys.argv = [sys.argv[0],
                '-i', './tests/decorators.py',
                '-o', '.',
                '-t', '2.7',
                '-r', '.',
                '-d']
    assert main() == 0

    # Test: bad output
    sys.arg

# Generated at 2022-06-22 15:02:50.593748
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:02:52.823694
# Unit test for function main
def test_main():
    class Arguments:
        target = 'python35'
        input = ['./input/compiler.py']

    assert main(Arguments) == 0

# Generated at 2022-06-22 15:02:53.593821
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:02:56.658480
# Unit test for function main
def test_main():
    # main(input_='tests/data/alice.txt', output_='tests/data/alice2.txt',
    #      target_='3.6', root_='tests')
    pass


# Generated at 2022-06-22 15:03:08.328458
# Unit test for function main
def test_main():
    import tempfile
    import sys
    sys.argv = ['py-backwards', '-i', 'test_files/test.py', '-o', 'output.py',
                '-t', '2']
    assert 0 == main()
    sys.argv = ['py-backwards', '-i', 'test_files/test.py', '-o', 'output.py',
                '-t', '2.7']
    assert 0 == main()
    sys.argv = ['py-backwards', '-i', 'test_files/test.py', '-o', 'output.py',
                '-t', '3']
    assert 0 == main()

# Generated at 2022-06-22 15:04:46.296181
# Unit test for function main
def test_main():
    input_ = "C:\\Users\\Admin\\Downloads\\py-backwards-master\\py-backwards\\test_files\\test_file.py"
    output = "C:\\Users\\Admin\\Downloads\\py-backwards-master\\py-backwards\\test_files\\test_file.py"
    target = "python2"
    root = "C:\\Users\\Admin\\Downloads\\py-backwards-master\\py-backwards\\test_files\\"
    debug = False

    try:
        result = compile_files(input_, output, const.TARGETS[target], root)
    except exceptions.CompilationError as e:
        print(messages.syntax_error(e), file=sys.stderr)
        return 1

# Generated at 2022-06-22 15:04:50.880145
# Unit test for function main
def test_main():
    import os, shutil
    from .conf import settings
    from .utils import is_sub_path, cwd

    cwd_ = cwd()

    test_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    target_dir = os.path.join(test_dir, 'target')
    src_path = os.path.join(test_dir, 'source', 'main.py')
    target_path = os.path.join(target_dir, 'main.py')
    os.makedirs(target_dir, exist_ok=True)


# Generated at 2022-06-22 15:04:52.290139
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:04:53.572961
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        assert main()

# Generated at 2022-06-22 15:04:55.116257
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    # main()
    test_main()

# Generated at 2022-06-22 15:04:55.695548
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-22 15:04:58.572753
# Unit test for function main
def test_main():
    sys.argv += ['src/test/python-test-project/test_project', '-o',
                 'target/output', '-t', 'python3.4']
    main()

# Generated at 2022-06-22 15:04:59.174020
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:04:59.950158
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:05:00.495338
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:08:36.894512
# Unit test for function main
def test_main():
    # Test for invalid input
    with pytest.raises(SystemExit, match=r'1'):
        sys.argv = ['py-backwards']
        main()

    # Test for compilation error
    from .compiler import compile_files
    from .conf import settings
    from . import exceptions
    from .exceptions import TransformationError, CompilationError
    settings.input = ['test/test_compiler.py']
    settings.output = 'test/test_output'
    settings.target = '3.1'
    settings.root = None
    settings.debug = False
    settings.debug_output = None
    with pytest.raises(SystemExit, match=r'1'):
        main()

    # Test for compilation sucessfull
    settings.input = ['test/test_compiler.py']
    settings