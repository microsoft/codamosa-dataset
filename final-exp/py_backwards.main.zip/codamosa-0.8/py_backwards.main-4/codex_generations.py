

# Generated at 2022-06-22 14:58:50.981361
# Unit test for function main
def test_main():
    import io
    import contextlib
    f = io.StringIO()
    with contextlib.redirect_stdout(f):
        main()
    s = f.getvalue()
    print("This is for testing")

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-22 14:58:59.729126
# Unit test for function main
def test_main():
    # Simple input
    sys.argv = ['main', '-i', 'tests/sources/basic.py',
                '-o', 'tests/temp.py', '-t', '2.7']
    assert main() == 0
    sys.argv = ['main', '-i', 'tests/sources/basic.py',
                '-o', 'tests/temp.py', '-t', '3.6']
    assert main() == 0

    # Input not exists
    sys.argv = ['main', '-i', 'tests/sources/not_exists.py',
                '-o', 'tests/temp.py', '-t', '3.6']
    assert main() == 1

    # Invalid input, output

# Generated at 2022-06-22 14:59:00.326762
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:01.502648
# Unit test for function main
def test_main():
    # type: () -> ()
    assert main() == 0

# Generated at 2022-06-22 14:59:02.085415
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:02.856692
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 14:59:04.080078
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:04.503897
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:05.482843
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except SystemExit:
        pass

# Generated at 2022-06-22 14:59:05.944916
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:20.872357
# Unit test for function main
def test_main():
    try:
        sys.argv.extend(['-i', 'test/input/test.py', '-t', '2.7', '-o', 'test/output', '-r', 'test'])
        main()
        assert os.path.isfile('test/output/test.py')
    except Exception:
        assert False
    finally:
        if os.path.isfile('test/output/test.py'):
            os.remove('test/output/test.py')

# Generated at 2022-06-22 14:59:21.835158
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-22 14:59:28.577803
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append('test/test_source.py')
    sys.argv.append('-o')
    sys.argv.append('test/test_output.py')
    sys.argv.append('-t')
    sys.argv.append('python34')
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:30.691687
# Unit test for function main
def test_main():
    sys.argv[1:] = '-i ./tests/basic_tests/stdlib -o ./res -t 2'.split()
    assert main() == 0

# Generated at 2022-06-22 14:59:34.462947
# Unit test for function main
def test_main():
    test_args = ['-i','test_files/', '-o','test_output/', '-t','2.7', '-r','test_files/']
    sys.argv[1:] = test_args
    saved_stdout = sys.stdout
    try:
        out = sys.stdout = StringIO()
        result = main()
        print(out.getvalue())
        assert result == 0
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-22 14:59:45.729763
# Unit test for function main
def test_main():
    # Test input directories
    sys.argv = ['py-backwards',
                '--input', 'tests',
                '--output', 'build',
                '--target', '2.7']
    assert main() == 0
    # Test input files
    sys.argv = ['py-backwards',
                '--input', 'tests/test_files/test_files.py',
                '--output', 'build',
                '--target', '2.7']
    assert main() == 0
    # Test target python version
    sys.argv = ['py-backwards',
                '--input', 'tests/test_files/test_files.py',
                '--output', 'build',
                '--target', '2.7']
    assert main() == 0
    # Test exception if input doesn't exists

# Generated at 2022-06-22 14:59:46.195533
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 14:59:51.196480
# Unit test for function main
def test_main():
    for i in range(0,len(const.TARGETS.keys())):
        #sys.argv.append(argv[i])
        main()
        assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 14:59:56.860445
# Unit test for function main
def test_main():
    """
        Test function main with empty input.
        Must show error message.
        (see: messages.py)
    """
    # Arrange
    sys.argv = sys.argv[:1]

    # Act
    with pytest.raises(SystemExit) as e:
        main()

    # Assert
    assert e.type is SystemExit
    assert e.value.code == 2

# Generated at 2022-06-22 14:59:59.221999
# Unit test for function main
def test_main():
    os.environ["PYTHONPATH"] = os.pathsep.join(sys.path)
    assert main() == 0

# Generated at 2022-06-22 15:00:17.071373
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:00:28.565807
# Unit test for function main
def test_main():
    input_ = 'data/bad.py'
    output = 'data/output/bad.py'
    args = ['py-backwards', '-i', input_, '-o', output, '-t', '3.5']
    assert main(args) == 1

    input_ = 'data/collection_comprehensions.py'
    output = 'data/output/collection_comprehensions.py'
    args = ['py-backwards', '-i', input_, '-o', output, '-t', '2.7']
    assert main(args) == 0

    input_ = 'data/format_strings.py'
    output = 'data/output/format_strings.py'

# Generated at 2022-06-22 15:00:30.609216
# Unit test for function main
def test_main():
    #TODO: main function is passing the test but argparse needs more tests
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-22 15:00:32.150891
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:42.501500
# Unit test for function main
def test_main():
    from sys import version_info
    from pytest import raises
    pytest_args = ['-s',            # Print to console
                   '-vv',           # Show header and python statements
                   '-x',            # Stop after first failure
                   '-l',            # Show local variables
                   __file__]
    if version_info.major >= 3:
        code = raises(SystemExit, main, pytest_args)
        assert code.value.code == 0
    else:
        assert main(pytest_args) == 0

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-22 15:00:48.135237
# Unit test for function main
def test_main():
    input_ = '../test/test_data/test.py'
    output_ = '../test/test_data/test_output.py'
    target_ = 'python27'
    root_ = '../test/test_data/'
    args = ArgumentParser()
    args.input = input_
    args.output = output_
    args.target = target_
    args.root = root_
    init_settings(args)
    main()
    assert open(output_).read() == \
        open('../test/expected/test_output.py').read().replace('\r', '')

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:00:54.760642
# Unit test for function main
def test_main():
    args = sys.argv
    sys.argv = ['-i', 'input_test.py', '-o', 'output_test.py', '-t', 'py36', '-d', '-r', '.']
    try:
        assert main() == 0
    except SystemExit:
        assert main() == 0
    sys.argv = args

# Generated at 2022-06-22 15:00:58.758353
# Unit test for function main
def test_main():
    args = argparse.Namespace(
        input=['/home/piotr/py-backwards/test.py'],
        output='/home/piotr/py-backwards/result.py',
        target='py36', root=None, debug=False
    )
    assert main() == 0

# Generated at 2022-06-22 15:01:00.221963
# Unit test for function main
def test_main():
    args = main()
    assert args == 0


# Generated at 2022-06-22 15:01:05.446666
# Unit test for function main
def test_main():
    # Init:
    argv = ['--input', './tests/dummy/input.txt', '--output', './tests/dummy/output.txt',
            '--target', '3.3', '-d']
    sys.argv = argv
    # Testing:
    assert main() == 0
    

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:01:50.643328
# Unit test for function main
def test_main():
    # Empty args
    assert main() == 2, 'Should return 2 when no args are provided'

    # Invalid args
    assert main(['--invalid-arg']) == 2, 'Should return 2 for invalid args'

    # No input provided
    assert main(['--target', 'py27', '--output', 'output']) == 2, \
        'Should return 2 if no input is provided'

    # Invalid output
    assert main(['--target', 'py27', '--output', ':\\:', 'file']) == 2, \
        'Should return 2 if invalid output is provided'

    # Invalid target
    assert main(['--target', 'invalid', 'file', 'valid_target']) == 2, \
        'Should return 2 if invalid target is provided'

    # Source doesn't exists

# Generated at 2022-06-22 15:01:55.151080
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(['-i','test.py', '-o','test_output.py', '-t','python35'])
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-22 15:01:56.000311
# Unit test for function main
def test_main():
    assert main()
    assert main()

# Generated at 2022-06-22 15:01:56.965386
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-22 15:01:57.848663
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:02:09.373592
# Unit test for function main
def test_main():
    # record /dev/stdout
    arg_list = []
    stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')
    
    # test input file doesnt exist
    try:
        main(['-i', '/tmp/file', '-o', '/tmp/output', '-t', '2.7', '-r', 'test/test_data/test_package'])
        assert False
    except SystemExit as e:
        sys.stdout = stdout
        assert e.code == 1
        out, err = capfd.readouterr()

# Generated at 2022-06-22 15:02:09.939101
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-22 15:02:10.798086
# Unit test for function main
def test_main():
    assert main() != 1

# Generated at 2022-06-22 15:02:22.562020
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import patch
    from . import messages, exceptions

    with patch('sys.stdout', new=StringIO()) as captured_output:
        main()

    assert 'usage: py-backwards' in captured_output.getvalue()

    with patch('sys.stdout', new=StringIO()) as captured_output:
        main(['-i', 'input.py', '-o', 'output.py', '-r', 'root', '-t', '27'])

    assert messages.compilation_result({'output.py': ('input.py', {})}) \
        in captured_output.getvalue()


# Generated at 2022-06-22 15:02:27.598866
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0],
                "--input", "py-backwards/tests/fixtures/fixture_in.py",
                "--output", "py-backwards/tests/fixtures/fixture_out.py",
                "--target", "2.7",
                "--debug",
                "--root", "."]
    assert main() == 0

# Generated at 2022-06-22 15:03:45.012232
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:03:49.765089
# Unit test for function main
def test_main():

    test_dict = {}
    test_dict["-i"] = "compiler/tests/correct/while.py"
    test_dict["-o"] = "compiler/tests/correct/while_py36.py"
    test_dict["-t"] = "py36"
    test_dict["-r"] = "compiler/tests/correct/"
    test_dict["-d"] = True

    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:03:50.292977
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:03:59.818996
# Unit test for function main
def test_main():
    import io
    import unittest
    from unittest.mock import patch

    def test_target(target: str) -> str:
        with patch('sys.argv', ['filename.py', '-i', 'input.py', '-o', 'output.py', '-t',
                             target]):
            return main()

    class TestMain(unittest.TestCase):

        @patch('sys.stderr', new_callable=io.StringIO)
        def test_non_exist_input(self, stderr):
            with self.assertRaises(SystemExit) as cm:
                test_target('python35')

            self.assertEqual(cm.exception.code, 1)

# Generated at 2022-06-22 15:04:06.824692
# Unit test for function main
def test_main():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    # Creating temporary directory
    with TemporaryDirectory() as tmp_dir:
        # Creating temporary file for input
        with tempfile.NamedTemporaryFile(
                mode='w+',
                suffix='.py',
                dir=tmp_dir,
                encoding='utf-8',
                delete=False
        ) as tmp_file:
            tmp_file.write("def hello():\n    print('Hello World!')")
            tmp_file.flush()
            input = tmp_file.name

            # Creating temporary file for output
            output = tempfile.mkstemp(
                suffix='.py',
                dir=tmp_dir,
                text=True
            )[1]

            # Running main

# Generated at 2022-06-22 15:04:08.081119
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:04:08.611166
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:04:19.468787
# Unit test for function main
def test_main():
    test_input = ['test.py', 'test_folder']
    test_output = 'test.py'
    test_target = 'py27'
    test_root = 'root'
    test_args = {
        'input': test_input,
        'output': test_output,
        'target': test_target,
        'root': test_root,
        'debug': True,
    }
    class args:
        def __init__(self):
            self.input = test_input
            self.output = test_output
            self.target = test_target
            self.root = test_root
            self.debug = True

    assert main(args) == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:04:19.985757
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:04:21.027145
# Unit test for function main
def test_main():
    # TODO cover with unit test
    assert True

# Generated at 2022-06-22 15:07:38.736036
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-22 15:07:45.662960
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/input_scripts', '-o',
                'test/output_scripts', '-t', '3.0', '-r', 'test/input_scripts',
                '-d']
    assert main() == 0


if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:07:55.843833
# Unit test for function main
def test_main():
    # no args
    sys.argv = []
    assert (main() == 2)

    # invalid args
    sys.argv = ['-i', 'test/test_data/syntax_error.py']
    assert (main() == 2)

    # Compilation error
    sys.argv = [
        '-i', 'test/test_data/syntax_error.py',
        '-o', 'output.py',
        '-t', 'python35'
    ]
    assert (main() == 1)

    # Transformation error
    sys.argv = [
        '-i', 'test/test_data/transformation_error.py',
        '-o', 'output.py',
        '-t', 'python35'
    ]
    assert (main() == 1)

    # Input doesnt exists

# Generated at 2022-06-22 15:07:56.414093
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:07:57.007835
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-22 15:08:03.682692
# Unit test for function main
def test_main():
    sys.argv[1] = "-t py36"
    sys.argv[2] = "-i"
    sys.argv[3] = "tests/tests_hierarchy/tests_with_errors/00_syntax_error.py"
    sys.argv[4] = "-o"
    sys.argv[5] = "test_output"
    sys.argv[6] = "-d"
    sys.argv[7] = "-r"
    sys.argv[8] = "tests/tests_hierarchy/tests_with_errors/"

    assert(main() == 1)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 15:08:04.208391
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 15:08:12.947478
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]]
    sys.argv.append('-i')
    sys.argv.append('tests/input0.py')
    sys.argv.append('-o')
    sys.argv.append('tests/output0.py')
    sys.argv.append('-t')
    sys.argv.append('3.5')
    sys.argv.append('-r')
    sys.argv.append('tests')
    sys.argv.append('-d')
    assert main() == 0

# Generated at 2022-06-22 15:08:14.730615
# Unit test for function main
def test_main():
    args = []
    result = main(args)
    assert result == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 15:08:17.311708
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    sys.exit(main())