

# Generated at 2022-06-21 17:24:25.831260
# Unit test for function main
def test_main():
    input_ = 'input'
    output = 'output'
    target = const.TARGETS['2.7']

    main_argv = sys.argv
    sys.argv = ['py-backwards', '-i', input_, '-o', output, '-t',
                target, '-r', 'root', '-d']

    def dummy_compile_files(input_, output, target, root):
        assert input_ == 'input', 'Wrong input'
        assert output == 'output', 'Wrong output'
        assert target == const.TARGETS['2.7'], 'Wrong target'
        assert root == 'root', 'Wrong root'
        return {'python files': 1}


# Generated at 2022-06-21 17:24:26.548315
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:30.025452
# Unit test for function main
def test_main():
    assert main(['-i', '/root/test/input', '-o',
                '/root/test/output', '-t', '2.7',
                '-r', '/root/test/src']) == 1

# Generated at 2022-06-21 17:24:33.321486
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'out', '-t', 'python2',
                '-d']
    assert main() != 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:35.150368
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-21 17:24:43.059589
# Unit test for function main
def test_main():
    target = 'py27'
    input_ = '/home/input.py'
    output = '/home/output'

    sys.argv = [
        'py-backwards.py',
        '-i', input_,
        '-o', output,
        '-t', target,
        '--debug'
    ]

    assert main() == 1

    # raise exceptions.InputDoesntExists
    input_ = '/doesnt/exists/path.py'
    output = '/home/output'

    sys.argv = [
        'py-backwards.py',
        '-i', input_,
        '-o', output,
        '-t', target,
        '--debug'
    ]

    assert main() == 1


if __name__ == '__main__':
    sys.exit

# Generated at 2022-06-21 17:24:48.565125
# Unit test for function main
def test_main():
    """
    Test main function, check if correct values are returned
    """
    # Test case 1
    sys.argv = ['py-backwards', '-i', 'src/', '-o', 'output/', '-t',
                'python35', '-d']

    assert main() == 0

    # Test case 2
    sys.argv = ['py-backwards', '-i', 'wrong_input/', '-o', 'output/', '-t',
                'python35', '-d']

    assert main() == 1

    # Test case 3
    sys.argv = ['py-backwards', '-i', 'src/', '-o', 'output/', '-t',
                'python35', '-d', '-r', 'tests/']

    assert main() == 0

# Generated at 2022-06-21 17:24:54.195670
# Unit test for function main
def test_main():
    def run_test(*args):
        with mock.patch('sys.argv', ['py-backwards'] + list(args)):
            main()

    run_test('-i', 'tests/data/test_files/files/test_file2.py',
             '-o', './output/',
             '-t', '3.5',
             '-r', 'tests/data/',
             '-d')

# Generated at 2022-06-21 17:24:56.388904
# Unit test for function main
def test_main():
    import py.test
    assert main() == 0
    assert main() == 1
    assert main() == 1


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:24:57.967411
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:17.014471
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:20.132227
# Unit test for function main
def test_main():
    sys.argv=['py-backwards', '-i', './tests/data/bad.py', '-o', './tests/data/result.py', '-t', 'python2.7']
    main()
    assert open('./tests/data/bad.py').read() != open('./tests/data/result.py').read()

# Generated at 2022-06-21 17:25:22.150193
# Unit test for function main
def test_main():
    pass

if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:25:31.932893
# Unit test for function main
def test_main():
    import os
    import pytest
    from .conf import ROOT_DIR, set_settings
    from .compiler import generate_ast
    import io

    args = {
        'input': ['test/test_data/test.py'],
        'target': '3.6',
        'output': 'test/test_data/target.py',
        'root': os.path.abspath(ROOT_DIR + '/../'),
        'debug': False
    }
    set_settings(args)

    # Test correct compilation
    main()

    # Test unknown input
    sys.stdout = io.StringIO()
    args['input'] = ['invalid.py']
    set_settings(args)
    with pytest.raises(SystemExit) as e:
        main()

# Generated at 2022-06-21 17:25:38.546547
# Unit test for function main
def test_main():
    """Checks that main function runs without errors."""
    parser = ArgumentParser('test')
    parser.add_argument('input', type=str)
    parser.add_argument('output', type=str)
    parser.add_argument('target', type=str, choices=const.TARGETS.keys())
    parser.add_argument('root', type=str)
    args = parser.parse_args(['input.py', 'output.py', 'py35', 'root'])
    init_settings(args)
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:25:44.006105
# Unit test for function main
def test_main():
    assert main(["-i", "./tests/test", "-o", "test_compile", "-t", "3.3", "-d"]) == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:44.686396
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:52.036660
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_output', '-t', '2.7']
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:59.648020
# Unit test for function main
def test_main():
    assert main(['-h']) == 0
    assert main(['-v']) == 0
    assert main(['--bad-arg']) == 2
    try:
        assert main(['-i', 'bad_input', '-o', 'bad_outout', '-t', '3.6', '-r', 'root']) == 1
    except SystemExit:
        pass
    try:
        assert main(['-i', 'bad_input']) == 2
    except SystemExit:
        pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:09.269285
# Unit test for function main
def test_main():
    import os
    import tempfile
    from .utils import remove_directory

    def file_exists(path: str) -> bool:
        return os.path.isfile(path)

    def directory_exists(path: str) -> bool:
        return os.path.isdir(path)

    folder = tempfile.mkdtemp()

# Generated at 2022-06-21 17:26:38.306754
# Unit test for function main
def test_main():
    from . import monkeypatch
    from .conf import settings
    import unittest.mock

    settings.compiler.input = ['test/conf/builtin_modules.py', 'test/conf/all']
    settings.compiler.output = 'output'
    settings.compiler.target = '2.7'
    settings.compiler.root = None
    settings.compiler.debug = False

    mock = unittest.mock.Mock()
    mock.side_effect = const.TARGETS['2.7']
    mock.return_value = const.TARGETS['2.7']
    monkeypatch.setattr(compiler.compiler, 'apply_simple_transformations',
                        mock)

    assert main() == 0

# Generated at 2022-06-21 17:26:44.442903
# Unit test for function main
def test_main():
    from subprocess import run
    from contextlib import redirect_stdout
    from io import StringIO
    from sys import executable
    from os.path import join as join_path
    from os import getcwd

    result = run([executable, join_path(getcwd(), __file__)],
                 input='3\n1\n'.encode("utf-8"),
                 stdout=PIPE, stderr=STDOUT)
    assert result.returncode == 0
    assert result.stdout.decode("utf-8") == '1\n2\n3\n'

# Запуск теста для функции main
test_main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:57.331876
# Unit test for function main
def test_main():
    sys.argv[1:] = ['--input', './tests/test_example.py',
                    '--output', './tests/test_example_output.py',
                    '--target', '2.7']

    assert main() == 0
    assert sys.argv[1:] == ['--input', './tests/test_example.py',
                            '--output', './tests/test_example_output.py',
                            '--target', '2.7']

    sys.argv[1:] = ['--input', './tests/test_example.py',
                    '--output', './tests/test_example_output.py',
                    '--target', '3.5']
    assert main() == 0

# Generated at 2022-06-21 17:26:58.537187
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:00.168192
# Unit test for function main
def test_main():
    assert main(['-i', 'tests/example_tests/',
                 '-o', 'output',
                 '-t', '2.7']) == 0

# Generated at 2022-06-21 17:27:01.338337
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:27:02.261929
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:03.754389
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:11.076769
# Unit test for function main
def test_main():
    with open('py36.py', 'w') as input_:
        input_.write('a={1:2, 2:3}')
    with open('py2.py', 'w') as output:
        output.write('a = {1: 2}')
    main()
    with open('py2.py') as f:
        res = f.read()
    assert res == 'a = {1: 2, 2: 3}'
    for fname in ['py36.py', 'py2.py']:
        os.remove(fname)

if __name__ == '__main__':
    status = main()
    sys.exit(status)

# Generated at 2022-06-21 17:27:13.799224
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:27:54.981393
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:27:57.776188
# Unit test for function main
def test_main():
    sys.argv = ['./py-backwards.py', '-i', './tests/data', '-o', 'output',
                '-t', '3.6', '-r', './tests']
    main()


# Generated at 2022-06-21 17:28:03.199870
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-o', './tests/data/test_output', '-i', './tests/data/test_input', '-t', '3.3.7']
    assert main() == 0

# Generated at 2022-06-21 17:28:07.773528
# Unit test for function main
def test_main():
    main(['/py/py3/return/return_statements.py', '-o', 'out.py', '-r',
          '/py/py3/return/', '-t', 'python37'])

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:28:20.057419
# Unit test for function main
def test_main():
    import pytest
    from io import StringIO
    import sys
    input_file = '/home/marcin/Desktop/University/AAAAA/py-backwards/'\
     'tests/resources/simple/simple1.py'
    output_file = '/home/marcin/Desktop/University/AAAAA/py-backwards'\
     '/tests/resources/simple/simple2.py'
    import shutil
    shutil.copyfile(input_file, output_file)

# Generated at 2022-06-21 17:28:25.468762
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_sources', '-o', 'test_output',
                '-t', '3.5', '-d', '-r', 'test_sources']
    from . import run
    run.main()

# Generated at 2022-06-21 17:28:26.088659
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:28.524360
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except SystemExit as e:
        # Good
        assert e.code == 0
    except AssertionError as e:
        print(e)

# Generated at 2022-06-21 17:28:38.531074
# Unit test for function main
def test_main():
	# Test a module that doesn't exist
	result = main()
	assert result == 102
	# Test a module with syntax errors
	result = main()
	assert result == 101
	# Test a module with transformation errors
	result = main()
	assert result == 103
	# Test a module with input/output errors
	result = main()
	assert result == 104
	# Test a module with permission errors
	result = main()
	assert result == 105
	# Test a module without any errors
	result = main()
	assert result == 0
	# Test a module with a nonvalid target
	result = main()
	assert result == 3

# Generated at 2022-06-21 17:28:44.263268
# Unit test for function main
def test_main():
    input_ = '/home/user/work/py-backwards/tests'
    output = '/home/user/work/py-backwards/tests'
    target = 'python2'

    result = main(input_, output, target)
    assert result == 0

# Generated at 2022-06-21 17:30:18.155818
# Unit test for function main
def test_main():
    with open('py-backwards/test.in.py', 'r') as f:
        input = f.read()
    with open('py-backwards/test.out.py', 'r') as f:
        output = f.read()
        assert main() == 0
        assert output == input

# Generated at 2022-06-21 17:30:19.757741
# Unit test for function main
def test_main():
    # TODO: test coverage
    pass

# Generated at 2022-06-21 17:30:20.904688
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-21 17:30:23.422635
# Unit test for function main
def test_main():
    assert main() == 1

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:24.265488
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:25.120124
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:26.404182
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:31.726530
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards', '-i', '../tests/binder/input', '-o',
        '../tests/binder/output', '-t', '2.7'
    ]
    assert main() == 0

    sys.argv = [
        'py-backwards', '-i', '../tests/binder/input_is_not_a_file', '-o',
        '../tests/binder/output', '-t', '2.7'
    ]
    assert main() == 1

    sys.argv = [
        'py-backwards', '-i', '../tests/binder/input', '-o',
        '../tests/binder/input_doesnt_exists', '-t', '2.7'
    ]
    assert main

# Generated at 2022-06-21 17:30:40.369848
# Unit test for function main
def test_main():
    argv = ['pybackwards', '-i', 'tests/input/examples/example1.py',
            '-o', 'tests/output/examples/example1.py', '-t', '2.7', '-r',
            'tests/input']
    sys.argv = argv
    assert main() == 0
    argv = ['pybackwards', '-i', 'tests/input/examples/example1.py',
            '-o', 'tests/output/examples/example1.py', '-t', '2.7', '-r',
            'tests/input']
    sys.argv = argv
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:45.692056
# Unit test for function main
def test_main():
    sys.argv = ['py_backwards', '-i', 'tests/files/logger.py', '-o',
                'tests/files/logger_output.py', '-t', '27']
    assert main() == 0
    sys.argv = ['py_backwards', '-i', 'tests/files/types.py', '-o',
                'tests/files/types_output.py', '-t', '27']
    assert main() == 0

# Generated at 2022-06-21 17:34:08.000493
# Unit test for function main
def test_main():
    # Test compilation with no files to compile
    try:
        main()
    except SystemExit:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-21 17:34:11.560229
# Unit test for function main
def test_main():
    test_input = '/Users/katieromero/Documents/Resources/py-backwards-master/tests/resources/tests/test_vers_31.py'
    test_output = '/Users/katieromero/Documents/Resources/py-backwards-master/tests/resources/output'
    test_target = '3.6'
    test_root = '/Users/katieromero/Documents/Resources/py-backwards-master/tests/resources'
    test_debug = True
    sys.argv = [sys.argv[0], '-i', test_input, '-o', test_output, '-t', test_target, '-r', test_root, '-d', test_debug]
    assert main() == 0