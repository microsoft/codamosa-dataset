

# Generated at 2022-06-21 17:24:24.073791
# Unit test for function main
def test_main():
    class Input:
        def __init__(self, args):
            self.input = args.split(' ')
    try:
        sys.argv = [sys.argv[0], '-i', 'tests/in', '-o', 'tests/out', '-t', '3', '-r', '.']
        main()
        assert True
    except:
        assert False

# Generated at 2022-06-21 17:24:28.323894
# Unit test for function main
def test_main():
    # If you run py-backwards by __init__.py (from root folder)
    sys.argv = ['main.py', '-i', 'test/test_files', '-o', 'test/output', '-t', '2', '-r', 'test/test_files']
    assert main() == 0

    sys.argv = ['main.py', '-i', 'test/test_files/3.py', '-o', 'test/test_files/2.py', '-t', '2']
    assert main() == 0

    sys.argv = ['main.py', '-i', 'test/test_files', '-o', 'test/output', '-t', '3', '-r', 'test/test_files']
    assert main() == 0


# Generated at 2022-06-21 17:24:34.435482
# Unit test for function main
def test_main():
    with open("test.py", 'w') as f:
        f.write("string = 'a'\n"
                "string.upper();\n")
    sys.argv = ["py-backwards", "-i", "test.py", "-o", "test_out.py",
                                            "-t", '2.7']
    assert main() == 0
    with open("test_out.py") as f:
        assert f.read() == "import string\n" \
                            "string.upper(string)\n"

# Generated at 2022-06-21 17:24:36.881383
# Unit test for function main
def test_main():
    import doctest
    doctest.run_docstring_examples(main, globals())

# Generated at 2022-06-21 17:24:37.361859
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:24:44.746214
# Unit test for function main
def test_main():
    # Fake some common files in current directory
    with open('__init__.py', 'w') as f:
        f.write('')
    with open('main.py', 'w') as f:
        f.write('')

# Generated at 2022-06-21 17:24:49.641150
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        sys.argv = ['pybackwards', '-i', 'file.py', '-o', 'file.py',
                    '-t', '2.7']
        main()

# Generated at 2022-06-21 17:24:50.657660
# Unit test for function main
def test_main():
    assert(main() == 0)


# Generated at 2022-06-21 17:24:56.236273
# Unit test for function main
def test_main():
    args = sys.argv
    sys.argv = ['./py-backwards', '-i', os.path.join(os.getcwd(), 'tests/test.py'),
                '-o', os.path.join(os.getcwd(), 'tests/test.out'),
                '-t', '3.5', '-r', os.path.join(os.getcwd(), 'tests')]
    main()
    sys.argv = args

# Generated at 2022-06-21 17:25:00.752951
# Unit test for function main
def test_main():
    from py_backwards.conf import settings
    from . import const

    main(['tests/data/'], 'tests/output/', const.TARGETS['python2'])

    assert 'tests/output/' in settings.output
    assert 'tests/output/' in settings.output_temp


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:18.326049
# Unit test for function main
def test_main():
    # Case 1: Wrong number of arguments
    sys.argv = ['py_backwards', '-t', 'python2.7']
    assert main() == 2
    sys.argv = ['py_backwards', '-i', '-t', 'python2.7', '-o', '-r']
    assert main() == 2
    # Case 2: Wrong input files name
    sys.argv = ['py_backwards', '-i', 'test_main', '-t', 'python2.7', '-o', '-r']
    assert main() == 1
    # Case 3: Wrong target
    sys.argv = ['py_backwards', '-i', 'test_main/main.py', '-t', 'python2.7', '-o', '-r']
    assert main() == 1
   

# Generated at 2022-06-21 17:25:19.090683
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:24.576057
# Unit test for function main
def test_main():

    with pytest.raises(SystemExit):
        main()

    with pytest.raises(SystemExit):
        sys.argv = ["", '-i', 'test.py', '-o', 'out', '-t', 'py37']
        main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:28.215522
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/support/input', '-o', 'test/test_output', '-t', '3.5']
    main()

# Generated at 2022-06-21 17:25:35.460533
# Unit test for function main
def test_main():
    input_file = 'test/test_compiler.py'
    output_file = 'test/test_compilation.py'

    sys.argv = [sys.argv[0],
        '-i', input_file,
        '-o', output_file,
        '-t', '3.5',
    ]
    assert main() == 0
    with open(output_file) as f:
        assert 'print(1, 2, 3, sep=\' \')' in f.read()
    sys.argv = sys.argv[:1]
    os.remove(output_file)


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:37.455558
# Unit test for function main
def test_main():
    from .test.test_unit.test_main import test_main
    test_main()

# Generated at 2022-06-21 17:25:39.799714
# Unit test for function main
def test_main():
    target_ver = '3.4'
    result = main(target_ver)
    assert result == 0
    target_ver = '2.7'
    result = main(target_ver)
    assert result == 0



# Generated at 2022-06-21 17:25:46.711842
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]] +\
               ["--input", "/sample.py", "--output", "/sample_output.py", "--target", "py35", "--root", "/"]
    assert main() == 0
    sys.argv = [sys.argv[0]] +\
               ["--input", "/sample_error.py", "--output", "/sample_output.py", "--target", "py35", "--root", "/"]
    assert main() == 1
    sys.argv = [sys.argv[0]] +\
               ["--input", "/sample.py", "--output", "/sample.py", "--target", "py35", "--root", "/"]
    assert main() == 1

# Generated at 2022-06-21 17:25:58.990028
# Unit test for function main
def test_main():
    from .compiler import compile_files
    from .settings import target
    from .conf import init_settings
    from . import const, messages, exceptions
    from unittest.mock import patch

    init_settings()

    # Test right compilation
    with patch('builtins.open', lambda p, m: open('tests/input/infinite.py', 'r')) \
            as mock_open:
        with patch('builtins.print') as mock_print:
            main()
            assert mock_print.call_count == 1
            assert mock_print.call_args[0][0] == messages.compilation_result(
                compile_files.__code__.co_argcount)

    # Test wrong compilation

# Generated at 2022-06-21 17:26:03.611235
# Unit test for function main
def test_main():
    with patch.object(sys, 'argv', ['py-backwards', '-o', 'destination', '-i', 'source', '-t', '2.7']) as _:
        main()

# Generated at 2022-06-21 17:26:22.329206
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:27.745023
# Unit test for function main
def test_main():
    from .conf import get_settings, set_settings, reset_settings
    from .conf import Settings
    from . import const

    settings = Settings(
        input=['a'], output='b', target=const.TARGETS['2.6'], debug=False)
    set_settings(settings)
    assert main() != 0
    reset_settings()

    settings = Settings(
        input=['a'], output='b', target='3.6', debug=False)
    set_settings(settings)
    assert main() == 0
    reset_settings()

# Generated at 2022-06-21 17:26:28.554821
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:26:38.737327
# Unit test for function main
def test_main():
    # Test if fail when only input argument
    if __name__ == '__main__':
        sys.argv = [sys.argv[0], '-i', 'input']
        assert main() == 2

    # Test if fail when only input and output arguments
    if __name__ == '__main__':
        sys.argv = [sys.argv[0], '-i', 'input', '-o', 'output']
        assert main() == 2

    # Test if fail when only input, output and target arguments
    if __name__ == '__main__':
        sys.argv = [sys.argv[0], '-i', 'input', '-o', 'output', '-t', '2.7']
        assert main() == 1

    # Test pass when all arguments

# Generated at 2022-06-21 17:26:39.503883
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:26:48.567318
# Unit test for function main
def test_main():
    args = ["-i", "test/test_data/test_backwards_function.py","-o","test/test_data/test_backwards_function_output.py","-t","3.6","-r","./test/test_data/__init__.py"]
    sys.argv = args
    assert main() == 0

    args = ["-i", "test/test_data/test_code.py","-o","test/test_data/test_code_output.py","-t","3.6","-r","./test/test_data/__init__.py"]
    sys.argv = args
    assert main() == 0


# Generated at 2022-06-21 17:26:52.412398
# Unit test for function main
def test_main():
    from . import testing
    from . import messages
    with testing.test_singleton() as t:
        t.write_files = True
        main_input = main()
        assert main_input == 0
        assert t.read_stderr() == messages.compilation_result({'1': 1})

# Generated at 2022-06-21 17:27:05.253575
# Unit test for function main
def test_main():
    import sys
    sys.argv = [
        'main', '-i', 'testdata/compiler/test.py', '-o', 'testdata/compiler/out.py',
        '-t', '2.7', '-r', 'testdata'
    ]
    assert main()
    assert open('testdata/compiler/out.py').read() == open('testdata/compiler/test2.py').read()
    assert main() == 1
    sys.argv = [
        'main', '-i', 'testdata/compiler/test.py', '-o', 'testdata/compiler/test.py',
        '-t', '2.7', '-r', 'testdata'
    ]
    assert main() == 1
    assert main() == 1

# Generated at 2022-06-21 17:27:12.409594
# Unit test for function main
def test_main():
    import pytest
    from subprocess import check_output
    from py_backwards.compiler import main
    assert main() == 0
    assert main(["-i", "tests/test_data/compile/test_input.py",
                 "-o", "compile_out",
                 "-t", "2.7",
                 "-r", "tests/test_data/compile"]) == 0
    assert main(["-i", "tests/test_data/compile/test_input.py",
                 "-o", "compile_out",
                 "-t", "2.7",
                 "-r", "tests/test_data/compile",
                 "-d"]) == 0
    # with pytest.raises(SystemExit) as ex:
    #    main(["-i", "tests/test_data/comp

# Generated at 2022-06-21 17:27:13.801477
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:02.919703
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/data/invalid_syntax.py', '-o', 'out.py', '-t', 'python36','--root','tests']
    assert main() == 1
    sys.argv = [sys.argv[0], '-i', 'tests/data/syntax.py', 'tests/data/functions.py', '-o', 'x', '-t', 'python36','--root','tests']
    assert main() == 1
    sys.argv = [sys.argv[0], '-i', 'tests/data/invalid_syntax.py', '-o', 'out.py', '-t', 'python36','--root','tests']
    assert main() == 1

# Generated at 2022-06-21 17:28:03.477919
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:28:06.172778
# Unit test for function main
def test_main():
    #pass
    assert main() == 10


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:28:06.617034
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:28:19.595891
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-21 17:28:25.186266
# Unit test for function main
def test_main():
    from .conf import settings
    assert main() == 0
    assert settings.target == '3.5'
    assert settings.input == ['./testproject']
    assert settings.output == './output'
    assert settings.root == 'testproject'

# Generated at 2022-06-21 17:28:28.578556
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

# Generated at 2022-06-21 17:28:33.739308
# Unit test for function main
def test_main():
    assert main() == 1
    if __name__ == '__main__':
        status = main()
        sys.exit(status)

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:28:43.738470
# Unit test for function main

# Generated at 2022-06-21 17:28:44.559415
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:15.780765
# Unit test for function main
def test_main():
    # Add tests here
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:22.209653
# Unit test for function main
def test_main():
    saved_argv = sys.argv[:]
    sys.argv = ['py_backwards',
                '-i', 'test_input/test.py',
                '-o', 'output.py',
                '-t', 'py35']
    assert main() == 0
    sys.argv = ['py_backwards',
                '-i', 'test_input/test.py',
                '-o', 'test_input/test.py',
                '-t', 'py35']
    assert main() == 1
    sys.argv = ['py_backwards',
                '-i', 'test_input/test.py',
                '-o', 'output.py',
                '-t', 'py35']
    assert main() == 0

# Generated at 2022-06-21 17:30:28.373760
# Unit test for function main
def test_main():
    args = ['py3to2', '-i', 'setup.py', '-o', 'dist/setup.py',
            '-t', '2.7', '-r', 'py', '-d']
    parser = main(args)
    assert parser.input == ['setup.py']
    assert parser.output == 'dist/setup.py'
    assert parser.root == 'py'
    assert parser.target == '2.7'
    assert parser.debug == True

# Generated at 2022-06-21 17:30:29.158506
# Unit test for function main
def test_main():
    #TODO: add unit tests
    pass

# Generated at 2022-06-21 17:30:31.755561
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:30:32.611599
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:36.337357
# Unit test for function main
def test_main():
    sys.argv[1:] = ('-i', 'test/test.py', '-o', 'test/out.py', '-t', '1')
    assert main() == 0

# Generated at 2022-06-21 17:30:38.123378
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:30:50.337736
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append(os.path.join(os.path.dirname(__file__), '..', 'tests', 'data', 'test_program'))
    sys.argv.append('-o')
    sys.argv.append(os.path.join(os.path.dirname(__file__), '..', 'tests', 'data', 'test_output'))
    sys.argv.append('-t')
    sys.argv.append('2.7')
    sys.argv.append('-r')
    sys.argv.append(os.path.join(os.path.dirname(__file__), '..', 'tests', 'data', 'test_program'))


# Generated at 2022-06-21 17:31:01.356313
# Unit test for function main
def test_main():
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
