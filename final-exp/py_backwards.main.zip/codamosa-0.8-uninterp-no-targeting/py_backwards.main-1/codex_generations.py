

# Generated at 2022-06-21 17:24:16.360794
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:16.963027
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:24:18.050328
# Unit test for function main
def test_main():
    assert main() == -1

# Generated at 2022-06-21 17:24:22.151928
# Unit test for function main
def test_main():
    # Test help
    sys.argv = ['py-backwards', '-h']
    assert main() == 0
    # Test compilation
    sys.argv = ['py-backwards', '-i', './tests/test_files/test.py', '-o',
                './tests/test_files/test_output.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-21 17:24:22.633158
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:34.201846
# Unit test for function main
def test_main():
    import sys
    import tempfile
    from .compiler import compile_files
    from .conf import init_settings

    def run_main(args, code):
        argv = sys.argv
        sys.argv = ['py-backwards', '-i', args[0], '-o', args[1], '-t', args[2], '-r', args[3], '-d', args[4]]
        init_settings(main().parse_args())
        sys.argv = argv
        assert code == 0

    with tempfile.TemporaryDirectory() as tmpdirname:
        compile_files(os.path.join(os.path.dirname(__file__), 'tests', 'sources'), tmpdirname, const.TARGETS['3.0'])


# Generated at 2022-06-21 17:24:38.606079
# Unit test for function main
def test_main():
    result = main(['py_backwards/tests/example_code.py', '-t', '3.5'])
    assert result == 0
    print(result)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:45.613406
# Unit test for function main
def test_main():
    from io import StringIO
    from . import messagestest
    from . import exceptions

    for target in const.TARGETS:
        for input_ in messagestest.INPUTS:
            for output in messagestest.OUTPUTS:
                for root in messagestest.ROOTS:
                    for debug in messagestest.DEBUGS:
                        sys.argv = ['py-backwards',
                                    '-i', input_,
                                    '-o', output,
                                    '-t', target,
                                    '-r', root,
                                    '-d', debug]
                        expected_result = messagestest.COMPILATION_RESULT[
                            input_, output, root, debug, target]

# Generated at 2022-06-21 17:24:56.038934
# Unit test for function main
def test_main():
    from .compiler import compile_files
    from . import const, messages, exceptions

    def compile_files_mock(*args): return True

    compile_files_orig = compile_files
    compile_files = compile_files_mock
    assert main() == 0
    compile_files = compile_files_orig
    sys.argv.append('-i')
    sys.argv.append('-o')
    assert main() == 1
    sys.argv.append('-t')
    assert main() == 1
    sys.argv.append('-r')
    sys.argv.append('-d')
    assert main() == 1

    class CompilationException(exceptions.CompilationError):
        pass

    def compile_files_mock(*args):
        raise CompilationException()


# Generated at 2022-06-21 17:25:04.954936
# Unit test for function main
def test_main():
    # test_InputDoesntExists
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        main()
    print(stderr.getvalue())
    assert 'Input doesnt exists' in stderr.getvalue()
    # test_InvalidInputOutput

# Generated at 2022-06-21 17:25:24.304393
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:34.132420
# Unit test for function main
def test_main():
    assert main()==0
    assert main(['-i', 'py_backwards/test_files/test.py',
                 '-o', 'py_backwards/test_files/test.py',
                 '-t', '2.7',
                 '-r', 'python_backwards',
                 '-d', True]) == 0
    assert main(['-t', '2.7',
                 '-r', 'python_backwards',
                 '-d', True]) != 0
    assert main(['-i', 'py_backwards/test_files/test.py',
                 '-t', '2.7',
                 '-r', 'python_backwards',
                 '-d', True]) != 0

# Generated at 2022-06-21 17:25:37.172496
# Unit test for function main
def test_main():
    result = main()
    assert(result == 1)

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:25:37.654259
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:25:41.580597
# Unit test for function main
def test_main():
    sys.argv = ['test.py',
                '-t', '2.7',
                '-i', './test_files/test_files',
                '-o', './test_files/test_files_out',
                '-r', './test_files',
                '-d']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:47.898550
# Unit test for function main
def test_main():
    from . import target_python_27
    from . import target_python_36

    target_python_27.compile_files.return_value = 0
    target_python_36.compile_files.return_value = 0

    old_argv = sys.argv[:]
    sys.argv = ['py-backwards', '--input', 'lib', '--output', 'build', '--target', '2.7']
    sys.argv += ['--root', 'test']

    main()
    target_python_27.compile_files.assert_called()

    sys.argv = ['py-backwards', '--input', 'lib', '--output', 'build', '--target', '3.6']
    sys.argv += ['--root', 'test']

    main()
    target_python_

# Generated at 2022-06-21 17:25:48.758631
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:25:51.889087
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('C:\\Users\\Domas\\Desktop\\PyBackwards\\tests\\test.py')
    sys.argv.append('-o')
    sys.argv.append('C:\\Users\\Domas\\Desktop\\PyBackwards\\tests\\test.py')
    sys.argv.append('-t')
    sys.argv.append('3.5')

    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:54.634292
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:05.443345
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'tests/test_files/test_file.py', '-o', 'output.py',
                '-t', '3.4', '-r', 'tests/test_files/', '-d']
    assert main() == 0

    sys.argv = ['', '-i', 'tests/test_files/test_file.py', '-o', 'output.py',
                '-t', '3.4', '-r', 'tests/test_files/']
    assert main() == 0

    sys.argv = ['', '-i', 'tests/test_files/test_file_error.py', '-o',
                'output.py', '-t', '3.4', '-r', 'tests/test_files/', '-d']
   

# Generated at 2022-06-21 17:26:26.333611
# Unit test for function main
def test_main():
    test_main_not_compiled()
    test_main_compiled()
    test_main_debug()
    test_main_compile_partial()
    test_input_output_error()
    test_compile_some_error()
    test_compile_invalid()
    test_compile_permission()
    test_compile_target_error()
    test_compile_source_error()


# Generated at 2022-06-21 17:26:27.479815
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:26:38.379353
# Unit test for function main
def test_main():
    # mock args
    class Args:
        input = 'some_input_path'
        output = 'some_output_path'
        target = 'python3.6'
        root = 'some_root'
        debug = False
    args = Args()
    # mock input
    result = {
        'output_path': 'some_output_path',
        'number_of_parsed_files': 2,
        'number_of_modified_files': 1,
        'number_of_py36_features': 3
    }
    compile_files = Mock(return_value=result)
    # mock result
    print = Mock()
    # mock sys
    sys = Mock()

    # swap the globals
    globals()['argparse'] = Mock()
    globals()['sys'] = sys
    glob

# Generated at 2022-06-21 17:26:39.327599
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:26:41.226710
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:26:42.076315
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:26:49.310975
# Unit test for function main
def test_main():
    from unittest import mock
    from . import interface_test

    args_list = [
        ['-i', 'a/b/c', '-o', 'a/b', '-t', '3.5', '-r', 'a', 'd', 'e'],
        ['-i', 'a', 'b', '-o', 'a/b/c', '-t', '3.6', '-r', 'a/b', 'd', 'e'],
        ['-i', 'a', 'b', '-o', 'a/b/c', '-t', '3.6', '-r', 'a/b', 'd', 'e',
         '-d'],
    ]


# Generated at 2022-06-21 17:26:52.875584
# Unit test for function main
def test_main():
    with patch('sys.argv', ['py-backwards-test', '-i', 'path1', '-o', 'path2',
                            '-t', '3.5']):
        assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:27:05.474778
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i',
                 'tests/fixtures/input/', '-o',
                 'tests/fixtures/output/', '-t',
                 '2.7', '-d', '-r',
                 'tests']
    assert main() == 0

    sys.argv = ['py-backwards', '-i',
                 'tests/fixtures/input/', '-o',
                 'tests/fixtures/output/', '-t',
                 '2.7', '-d', '-r',
                 'tests']
    assert main() == 0


# Generated at 2022-06-21 17:27:06.002001
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:48.322229
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:27:53.071359
# Unit test for function main
def test_main():
    """
    >>> main() # doctest: +ELLIPSIS
    usage: ...
    py-backwards: error: the following arguments are required: -i/--input, -o/--output, -t/--target
    1
    """

# Generated at 2022-06-21 17:27:56.675000
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', '../test/hello', '-t', '2.7', '-o', '../test/output']
    assert main() == 0

# Generated at 2022-06-21 17:27:57.495808
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:03.007248
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'tests/test_data/',
                '-o', 'tests/test_output/',
                '-t', 'python2']
    sys.exit(main())

# Generated at 2022-06-21 17:28:03.608406
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:06.553490
# Unit test for function main
def test_main():
    
    if(main() == 0):
        print('unit test passed')
    else:
        print('unit test failed')


# Generated at 2022-06-21 17:28:19.599166
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import filecmp

    test_path = os.path.dirname(os.path.realpath(__file__))
    test_files_path = os.path.join(test_path, '..', 'test_files/compilation')
    # We're not sure in which folder main function will run
    # so we have to use absolute path
    py_path = os.path.join(os.path.abspath(os.path.curdir), 'py-backwards.py')


# Generated at 2022-06-21 17:28:22.293998
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:28:31.244747
# Unit test for function main
def test_main():
    import os.path
    import os
    import shutil
    import tempfile

    output_path = os.path.join(tempfile.gettempdir(), 'output')
    root_path = os.path.join(tempfile.gettempdir(), 'root')


# Generated at 2022-06-21 17:30:01.400627
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-21 17:30:10.405797
# Unit test for function main
def test_main():
    import os
    import tempfile
    import subprocess
    import shutil

    # init
    base_dir = os.path.dirname(__file__)
    target_dir = tempfile.mkdtemp()
    input_dir = tempfile.mkdtemp()
    output_dir = tempfile.mkdtemp()
    test_dir = os.path.join(base_dir, 'test_sources')
    shutil.copytree(test_dir, input_dir)

    # arguments
    input_ = os.path.join(input_dir, 'test.py')
    output = os.path.join(output_dir, 'test.py')
    target = '2.5'
    root = input_dir

    # Execute main with arguments

# Generated at 2022-06-21 17:30:20.349734
# Unit test for function main
def test_main():
    import io
    import sys
    import unittest.mock

    function_with_error = 'def function_with_error(a):\n\treturn a + a\n'
    from .ast_builder import BinaryOperation, Identifier
    from .transform import TransformResult

    class Args:
        def __init__(self, files, output, target, root='.'):
            self.input = files
            self.output = output
            self.target = target
            self.root = root


# Generated at 2022-06-21 17:30:29.932870
# Unit test for function main
def test_main():
    class Args():
        def __init__(self):
            self.input = 'input'
            self.output = 'output'
            self.target = 'python36'
            self.root = None

    def _mock_compile_files(*args):
        return 0, 0, 0

    patch('py_backwards.__main__.compile_files', _mock_compile_files).start()
    with patch('py_backwards.__main__.ArgumentParser') as mock_parser:
        mock_parser.parse_args.return_value = Args()
        main()
    assert mock_parser.parse_args.called_once()

if __name__ == '__main__':
    ret_code = main()
    exit(ret_code)

# Generated at 2022-06-21 17:30:32.047178
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:37.813871
# Unit test for function main
def test_main():
    sys.argv = ['test', '-i', 'test/sources/test_file.py', '-o', 'test/sources/test_file.py',
                '-t', 'python36', '-r', 'test/sources']
    assert main() == 0

# Generated at 2022-06-21 17:30:42.101441
# Unit test for function main
def test_main():
    sys.argv = ['-i', 'src', '-o', 'out', '-t', '2.7', '-r', 'root', '-d']
    main()

# Generated at 2022-06-21 17:30:45.282581
# Unit test for function main
def test_main():
    # argparse doesnt support unit testing
    # Checking if zero or non-zero is returned
    return main() in [0, 1]

# Generated at 2022-06-21 17:30:47.245391
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:48.411230
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()