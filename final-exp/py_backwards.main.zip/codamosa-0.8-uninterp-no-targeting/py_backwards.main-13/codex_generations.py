

# Generated at 2022-06-21 17:24:16.299270
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile


# Generated at 2022-06-21 17:24:24.126473
# Unit test for function main
def test_main():
    import pytest

    sys.argv = ['py-backwards', '-i', 'tests/inputs/main_test.py', '-o', 'tests/inputs/main_test.py', '-t', '2.7']
    with pytest.raises(exceptions.CompilationError):
        main()
    sys.argv = ['py-backwards', '-i', 'tests/inputs/main_test.py', '-o', 'tests/inputs', '-t', '2.7'] # noqa E501
    with pytest.raises(exceptions.CompilationError):
        main()

# Generated at 2022-06-21 17:24:30.724206
# Unit test for function main
def test_main():
    argv = sys.argv
    sys.argv = ['main.py', '-i', 'C:\\Users\\Dizman\\Desktop\\py36-backwards\\tests\\input.py', '-o', 'C:\\Users\\Dizman\\Desktop\\py36-backwards\\tests\\output.py', '-t', '3.5']
    main()
    assert True


# Generated at 2022-06-21 17:24:31.827245
# Unit test for function main
def test_main():
    assert 1

# Generated at 2022-06-21 17:24:32.441515
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:43.150552
# Unit test for function main
def test_main():
    from .utils import get_output
    from .tempdir import TempDir
    from .const import SUPPORTED_PYTHON_VERSIONS
    from .utils import get_target_version
    from shutil import rmtree
    import os

    def validate_result(input_, output, target, root=None):
        input_ = os.path.basename(input_)
        output = os.path.basename(output)
        return '''input: {}
output: {}
target: {}
root: None'''.format(input_, output, target)

    # os.path.relpath doesn't work here

    with TempDir() as temp_input_dir, TempDir() as temp_output_dir:
        temp_input_dir.create_file('test.py', 'print(1)')
        temp_input_dir

# Generated at 2022-06-21 17:24:48.630591
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'tests/data/files_in/lambda.py',
        '-o', 'tests/data/files_out/lambda.py',
        '-t', '2.7',
        '-r', 'tests/data'
    ]

    assert main() == 0

    sys.argv = [
        'py-backwards',
        '-i', 'tests/data/files_in/lambda.py',
        '-o', 'tests/data/files_out/lambda.py',
        '-t', '2.7',
        '-r', 'tests/data'
    ]

    assert main() == 0


# Generated at 2022-06-21 17:24:58.248837
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "test_res/main.py", "-o", "output.py", "-t", "2.7", "-d"]
    assert main() == 0
    sys.argv = ["py-backwards", "-i", "test_res/main.py", "-o", "output.py", "-t", "2.7"]
    assert main() == 0
    sys.argv = ["py-backwards", "-i", "test_res/main.py", "-o", "output.py", "-t", "3.6"]
    assert main() == 0
    sys.argv = ["py-backwards", "-i", "test_res/main.py", "-o", "output.py", "-t", "3.8"]
    assert main() == 0
    sys.arg

# Generated at 2022-06-21 17:25:00.429808
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass
    assert True

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:07.240178
# Unit test for function main
def test_main():
    from .conf import settings
    from .py_backwards_test import StringIO
    import sys

    sys.stdout = StringIO()
    sys.argv = ['py-backwards', '-i', 'file1.py', '-o', 'output.py', '-t',
                '3.6', '-r', 'root']
    main()
    assert settings.root == 'root'
    assert settings.target == '3.6'
    assert settings.input_files == ['file1.py']
    assert settings.output_path == 'output.py'
    assert settings.debug is False

    sys.argv = ['py-backwards', '-i', '/home/file.py', '-o',
                '/output/folder/', '-t', '3.4', '-d']
    main()

# Generated at 2022-06-21 17:25:19.996687
# Unit test for function main
def test_main():
    sys.argv = [''] * 3
    sys.argv.extend(['-i', 'test/test_data/test_program.py', '-o', '/tmp/test_program', '-t', '3.5'])
    assert 0 == main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:25:21.665887
# Unit test for function main
def test_main():
    input = ["main.py"]
    output = "output"
    target = "Python-3.5"
    args = main(input, output, target)
    assert args == 0

# Generated at 2022-06-21 17:25:31.664653
# Unit test for function main
def test_main():
    from .conf import settings
    from . import utils
    from . import compiler

    class MockArgs:
        input = ['input']
        output = 'output'
        target = '2'
        root = None
        debug = False

    mock_compiler = utils.snake_to_camel(compiler.__name__)
    test_cases = [
        (const.Result(0, 0, 1), '1', 'Compilation was successful. 1 file has been compiled'),
        (const.Result(1, 0, 1), '2', 'Compilation was successful. 1 file has been compiled'),
        (const.Result(0, 0, 1), '3', 'Compilation was successful. 1 file has been compiled')
    ]

    for result, target, expected_result in test_cases:
        mock_args = MockArgs()

# Generated at 2022-06-21 17:25:32.351068
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:40.437308
# Unit test for function main
def test_main():
    import os
    import time
    import shutil

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    in_dir = os.path.join(cur_dir, '../', const.TEST_INPUT_DIR)
    out = '/tmp/' + const.TEST_INPUT_DIR
    shutil.rmtree(out, ignore_errors=True)
    os.makedirs(out, exist_ok=True)

    return_code = main(['-d', '-i', in_dir, '-o', out, '-t', '2.7', '-r',
                        cur_dir])

    if return_code != 0:
        raise RuntimeError("Error while running a test.")


# Generated at 2022-06-21 17:25:41.351315
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:49.002905
# Unit test for function main
def test_main():
    import __builtin__
    import unittest, mock
    from .compiler import compile_files
    from . import const, messages, exceptions

    # Test all possible combinations of main() arguments for correctness
    for _ in range(4):
        for arg1 in range(3):
            for arg2 in range(2):
                for arg3 in range(2):
                    for arg4 in range(2):
                        cli_input = [sys.executable, '-m', 'py_backwards']
                        if arg1 == 0:
                            cli_input += ['-i', 'input_file']
                        else:
                            cli_input += ['-i', 'input_file', 'input_dir']
                        if arg2 == 0:
                            cli_input += ['-o', 'output_file']

# Generated at 2022-06-21 17:25:53.462112
# Unit test for function main
def test_main():
    def _test_main(args: list, target_version: str) -> int:
        with mock.patch('sys.argv', args):
            assert main() == 0
            return const.TARGETS[target_version]

    assert _test_main(['-i', 'foo.py', '-o', 'out', '-t', 'Python 2.7'],
                      'Python 2.7') == const.TARGETS['Python 2.7']
    assert _test_main(['-i', 'tests', '-o', 'out', '-t', 'Python 2.7'],
                      'Python 2.7') == const.TARGETS['Python 2.7']

# Generated at 2022-06-21 17:25:54.315197
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-21 17:25:55.951688
# Unit test for function main
def test_main():
    """Test function main.

    Params:
        None
    """
    assert main() == 0

# Generated at 2022-06-21 17:26:20.007388
# Unit test for function main
def test_main():
    class Args:
        input = ['test', 'test']
        output = 'result_test'
        target = 'python2.7'
        root = ''
        debug = False
    with pytest.raises(exceptions.InputDoesntExists):
        main()

# Generated at 2022-06-21 17:26:24.992046
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "tests/test_code/main.py", "-o", "tests/test_code/output/", "-t", "python36", "-r", "tests/test_code/"]
    main()
    assert 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:37.371351
# Unit test for function main
def test_main():
    import sys
    import contextlib
    from io import StringIO

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        sys.argv = ['py-backwards', '-i', 'tests', '-o', 'dst', '-t', 'py26', '-r', 'src']
        main()
        assert "There were no files compiled\n"

# Generated at 2022-06-21 17:26:37.966524
# Unit test for function main
def test_main():
    assert 0 == main()

# Generated at 2022-06-21 17:26:38.823120
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:46.993266
# Unit test for function main
def test_main():
    # ArgsParser class mock
    class MockArgsParser:
        def __init__(self, args, output, targets, target, root, debug):
            self.args = args
            self.output = output
            self.targets = targets
            self.target = target
            self.root = root
            self.debug = debug

        def parse_args(self):
            return self

    # Config class mock
    class MockConfig:
        def __init__(self, debug):
            self._debug = debug

        def debug(self):
            return self._debug

    # Compiler class mock
    class MockCompiler:
        def __init__(self, required_input, output, targets, target, root):
            self.required_input = required_input
            self.output = output
            self.targets = targets
           

# Generated at 2022-06-21 17:26:48.087429
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-21 17:26:56.644907
# Unit test for function main
def test_main():
    sys.argv = ['test',
                '-i', '../test/test_input.py',
                '-o', './test_output.py',
                '-t', 'Python 2.7']
    import unittest.mock
    m = unittest.mock.mock_open()
    with unittest.mock.patch('builtins.open', m):
        assert main() == 0
        m.assert_called()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:27:07.460887
# Unit test for function main
def test_main():
    assert main(['-h']) == 0
    assert main(['-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.6']) == 0
    assert main(['-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '2.7']) == 1
    assert main(['-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.6']) == 0
    assert main(['-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '2.7']) == 1

# Generated at 2022-06-21 17:27:12.122597
# Unit test for function main
def test_main():
    assert main(['./tests/test_simple.py', '-o', './tests/test_simple.pyc',
                 '-t', '2.7', '-r', '/home/']) == 0

# Generated at 2022-06-21 17:27:56.728061
# Unit test for function main
def test_main():
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    import os

    def run_compiler(input_: str, output: str, target: str, root: str = None):
        import py_backwards
        mode_ = py_backwards.settings.debug
        py_backwards.settings.debug = True
        result = compile_files(input_, output, const.TARGETS[target], root)
        py_backwards.settings.debug = mode_
        return result

    with TemporaryDirectory() as tmpdir:
        files = {
            'input.py': 'a = 1',
            'input': '1',
            'output': '1',
            'output.py': '1'
        }


# Generated at 2022-06-21 17:27:57.496540
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:58.993927
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:28:05.721248
# Unit test for function main
def test_main():
    from .fixtures.file_system_fixtures import create_folder, create_file, \
        create_file_content, remove_folder
    from .fixtures.argparse_fixtures import create_command_line_args

    def remove_files(files):
        for file in files:
            file.remove()

    def create_files(files_names, content):
        files = [create_file(name) for name in files_names]
        for file, text in zip(files, content):
            create_file_content(file, text)
        return files

    def run_test(input_files, output_file, expected_output, target_version,
                 input_args=None, root_path=None):
        files = create_files(input_files, const.DEFAULT_INPUT_SOURCE)

# Generated at 2022-06-21 17:28:10.068103
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', '/home/denis/programming/interpreters/pybackwards/pybackwards/__init__.py',
        '-o', '/home/denis/programming/interpreters/pybackwards/pybackwards/__init__.py',
        '-t', 'py34',
        '-r', '/home/denis/programming/interpreters/pybackwards'
    ]
    assert main() == 0

# Generated at 2022-06-21 17:28:10.922855
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-21 17:28:16.563958
# Unit test for function main
def test_main():
    assert main(['py_backwards_compiler/py_backwards.py',
                 '-i', 'py_backwards_compiler/examples/test.py',
                 '-o', 'output/test.py',
                 '-t', '3.6']) == 0

# Generated at 2022-06-21 17:28:24.943840
# Unit test for function main
def test_main():
    str1 = """
    py-backwards -i test input -o output -t 3.6 -r module
    """
    parser = ArgumentParser()
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str, required=True,
                        choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    args = parser.parse_args(str1.split())

# Generated at 2022-06-21 17:28:34.585988
# Unit test for function main
def test_main():
    """
    This function is used to test function main
    """
    from py_backwards.utils import get_valid_path
    # Test case 1.1
    sys.argv = [sys.argv[0], '-i', get_valid_path('py_backwards/test/test_files/test_files.py'),
                '-o', get_valid_path('py_backwards/test/test_files/output_files.py'),
                '-t', '3.5']
    assert main() == 0
    # Test case 1.2

# Generated at 2022-06-21 17:28:36.004672
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:30:07.373720
# Unit test for function main
def test_main():
    assert main() == False

# Generated at 2022-06-21 17:30:19.378491
# Unit test for function main
def test_main():
    file_name = 'foo.py'
    file_name_simple = 'foo'
    file_name_changed = 'bar'
    input_file = 'foo.py'
    output_file = 'bar.py'
    output_folder = 'bar'
    target = 'python36'
    root = 'root'
    debug = True

    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')

# Generated at 2022-06-21 17:30:29.906892
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/data/3.6/FunctionAnnotations.py',
                '-o', 'tests/data/out.py', '-t', 'python2.7', '-d']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', 'tests/data/3.6/FunctionAnnotations.py',
                '-o', 'tests/data/out.py', '-t', 'python3']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', 'tests/data/3.6/FunctionAnnotations.py',
                '-o', 'tests/data/out.py', '-t', 'python2.7']
    assert main() == 0

# Generated at 2022-06-21 17:30:36.609666
# Unit test for function main
def test_main():
    sys.argv = [__file__,
                '-i', 'example/dataclass',
                '-o', 'build',
                '--target', 'py35',
                '-r', 'example',
                '-d']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:37.908248
# Unit test for function main
def test_main():
    return


# Generated at 2022-06-21 17:30:50.191520
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'tests/input/input.py',
        '-o', 'tests/output',
        '-t', '3.5',
        '-r', 'tests/input',
        '-d'
    ]
    assert main() == 0
    sys.argv = [
        'py-backwards',
        '-i', 'tests/input/input_cython.py',
        '-o', 'tests/output',
        '-t', '3.5',
        '-r', 'tests/input',
        '-d'
    ]
    assert main() == 0
    
    os.remove('tests/output/input.py')
    os.remove('tests/output/input_cython.py')
   

# Generated at 2022-06-21 17:31:01.302555
# Unit test for function main
def test_main():
    '''
    Test for main function with normal situation
    '''
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')

# Generated at 2022-06-21 17:31:03.803688
# Unit test for function main
def test_main():
    msg = "Testing get_date_time_string function"
    assert main() == 0, msg

# Generated at 2022-06-21 17:31:05.169588
# Unit test for function main
def test_main():
    assert main([]) == 0

# Generated at 2022-06-21 17:31:06.453158
# Unit test for function main
def test_main():
    assert main() == 0
