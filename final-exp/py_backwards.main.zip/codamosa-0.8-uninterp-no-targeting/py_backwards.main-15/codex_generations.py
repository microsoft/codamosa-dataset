

# Generated at 2022-06-21 17:24:03.875836
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:07.153649
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'input', '-o', 'output', '-t', '35']
    assert main() == 1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:12.712827
# Unit test for function main
def test_main():
    input_ = ['test_files/simple_exp.py']
    output = 'test.py'
    target = '3.3'
    root = ''
    debug = True
    args = []
    sys.argv = ['py-backwards.py', '-i', input_, '-o', output, '-t', target,
                '-r', root, '-d', debug, args]
    assert main() == 0

# Generated at 2022-06-21 17:24:13.217882
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:15.109830
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', './test_files/', './test_output/', '2.7']
    assert main() == 0

# Generated at 2022-06-21 17:24:22.230712
# Unit test for function main
def test_main():
    target = StringIO()
    with redirect_stderr(target):
        # Test for wrong target python version
        if main() == 0:
            raise AssertionError
        target.truncate(0)
        target.seek(0)

        # Test for wrong input folder
        if main(['bad_folder', ], const.TARGETS.keys()[0], 'out_folder', '3') == 0:
            raise AssertionError
        target.truncate(0)
        target.seek(0)

        # Test for wrong output folder
        if main([], 'out_folder', const.TARGETS.keys()[0]) == 0:
            raise AssertionError
        target.truncate(0)
        target.seek(0)

        # Test for wrong input and output folders

# Generated at 2022-06-21 17:24:34.167361
# Unit test for function main
def test_main():
    class CommandLine:
        def __init__(self, args):
            self.input = args['input']
            self.output = args['output']
            self.target = args['target']
            self.root = args['root']
            self.debug = args['debug']

        def __str__(self):
            return '{0} {1} {2} {3}'.format(self.input, self.output,
                                            self.target, self.root)

    @contextmanager
    def patch_argv(argv):
        old_sys_argv = sys.argv
        sys.argv = argv
        yield
        sys.argv = old_sys_argv

    @contextmanager
    def patch_open():
        prev_open = open
        open_files = {}


# Generated at 2022-06-21 17:24:34.830635
# Unit test for function main
def test_main():
    assert main() != 0

# Generated at 2022-06-21 17:24:38.756012
# Unit test for function main
def test_main():
    result = main(['-i', 'tests/data/hello_world.py',
                   '-o', 'hello.py', '-t', '2.7'])
    assert result == 0

# Generated at 2022-06-21 17:24:41.127697
# Unit test for function main
def test_main(): # test py-backwards
    input='in.py'
    output='out'
    target='2'
    debug='t'
    result=0
    main()

# Generated at 2022-06-21 17:24:59.046343
# Unit test for function main
def test_main():
    class Args:
        input = ['test.in']
        output = 'test.out'
        target = '3.5'
        root = 'root'
        debug = False

    try:
        import __main__ as main
    except ImportError:
        import py_backwards as main

    setattr(main, '__file__', './py_backwards/__main__.py')
    sys.path.append('.')

    import py_backwards

    setattr(py_backwards, '__file__', './py_backwards/__init__.py')
    sys.path.append('.')

    import compile
    import conf

    setattr(compile, '__file__', './py_backwards/compile.py')
    sys.path.append('.')


# Generated at 2022-06-21 17:25:06.965781
# Unit test for function main
def test_main():
    from . import exceptions

    class Arg:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    args = Arg(input=['main.py'],
               output='/a/temp',
               target='3.4',
               root='/a/temp/root')
    try:
        init_settings(args)
        assert False, 'Expected InputDoesntExists exception'
    except exceptions.InputDoesntExists:
        pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:08.020120
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:17.404034
# Unit test for function main
def test_main():
    # Case when number of arguments = 1
    try:
        sys.argv = ["py-backwards", "-1"]
        main()
        assert True
    except SystemExit:
        assert False

    # Case when number of arguments = 2
    try:
        sys.argv = ["py-backwards", "-2"]
        main()
        assert True
    except SystemExit:
        assert False
    
    # Case when number of arguments = 3
    try:
        sys.argv = ["py-backwards", "-i", "py-backwards.py", "-o", "py-backwards.py", "-t", "2.7"]
        main()
        assert True
    except SystemExit:
        assert False
    
    # Case when number of arguments = 4

# Generated at 2022-06-21 17:25:18.344082
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:21.016822
# Unit test for function main
def test_main():
    class args:
        input = ['tests/simple_file.py']
        output = '.'
        target = 'py27'
        root = None
        debug = False

    init_settings(args)

    compile_files(*args.input, args.output, const.TARGETS[args.target],
                  args.root)

# Generated at 2022-06-21 17:25:25.512515
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-r', 'root', '-t', 'python2']
    main()
    main()
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:28.089617
# Unit test for function main
def test_main():
    assert(main() == 0)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:28.614499
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:37.270058
# Unit test for function main
def test_main():
    assert main(['-i', 'test/input/', '-o', 'test/output/',
                 '-t', 'py35', '-r', 'test/input']) == 0
    assert main(['-i', 'test/input/', '-o', 'test/output/',
                 '-t', 'py35', '-r', 'test/input', '-d']) == 0
    assert main(['-i', 'test/input/', '-o', 'test/output/',
                 '-t', 'py35', '-r', 'test/input1']) == 1
    assert main(['-i', 'test/input/', '-o', 'test/input1/',
                 '-t', 'py35', '-r', 'test/input']) == 1

# Generated at 2022-06-21 17:25:54.812670
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:57.037371
# Unit test for function main
def test_main():
    assert(main() == 0)

if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:25:58.403865
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-21 17:25:59.151079
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-21 17:26:01.598098
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:05.237006
# Unit test for function main
def test_main():
    class arg(object):
        input = "./tests/utils.py"
        output = "./tests/utils_transformed.py"
        target = "py36"
        root = "./tests/"
        debug = False
    main(arg)

# Generated at 2022-06-21 17:26:09.024328
# Unit test for function main
def test_main():
    time.sleep(1)
    assert 1 == main()
    assert 0 == main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:09.493909
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:15.141701
# Unit test for function main
def test_main():
    args = ['--input', 'not_existing_input/file.py',
            '--output', 'output/file.py',
            '--target', '2.7']
    with pytest.raises(SystemExit) as _:
        main(args)
    assert _.type == SystemExit
    assert _.value.code == 1

# Generated at 2022-06-21 17:26:26.741340
# Unit test for function main
def test_main():
    # Case 1: Successful compilation
    from os import rmdir, unlink, remove
    from os.path import exists
    from shutil import rmtree
    from tempfile import mkdtemp
    from random import sample
    from string import ascii_lowercase
    from sys import argv, exit
    from subprocess import PIPE, run
    from glob import glob

    tmp_dir = mkdtemp()

    # Temporary directory with sources
    src_dir = f'{tmp_dir}/src'
    # Temporary directory with compiled sources
    output_dir = f'{tmp_dir}/output'

    # Files with original sources
    files = []
    # Files with compiled sources
    out_files = []
    # Case 1:
    # Successful compilation

# Generated at 2022-06-21 17:27:05.675123
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'test2', '-t', '3.6']
    target = main()
    assert target == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:27:06.511712
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:08.533933
# Unit test for function main
def test_main():
    assert main() == 0
    assert main() == 1
    assert main() == 3

# Generated at 2022-06-21 17:27:12.050424
# Unit test for function main
def test_main():
    args = main()
    assert args == 0

if __name__ == '__main__':
    args = main()
    sys.exit(args)

# Generated at 2022-06-21 17:27:13.269201
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:13.730831
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:17.198837
# Unit test for function main
def test_main():
    args = ['py-backwards', '-i', './tests/hello.py', '-o', './tests/hello_out.py', '-d', '-t', '2.7']
    assert main(args) == 1

# Generated at 2022-06-21 17:27:17.981530
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:27:19.364559
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:20.234865
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:35.883365
# Unit test for function main
def test_main():
    from .test import TestRunner
    with TestRunner() as runner:
        runner.start_test('test_for_main()', main)

# Generated at 2022-06-21 17:28:48.407095
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from unittest.mock import MagicMock
    sys.argv = ['py-backwards']
    with patch.object(ArgumentParser, 'parse_args', return_value=MagicMock(input = ['a'], output = 'b', target = 'c')):
        with patch.object(compile_files, 'handle_input_output', side_effect=exceptions.InputDoesntExists ):
            assert main() == 1
        with patch.object(compile_files, 'handle_input_output', side_effect=exceptions.InvalidInputOutput ):
            assert main() == 1
        with patch.object(compile_files, 'handle_input_output', side_effect=exceptions.TransformationError('a', 'b', 'c') ):
            assert main() == 1

# Generated at 2022-06-21 17:28:48.910265
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:28:49.758626
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:51.115707
# Unit test for function main
def test_main():
  assert type(main()) == int


# Generated at 2022-06-21 17:28:58.514482
# Unit test for function main
def test_main():
    exit_code = main(['py_backwards/main.py', '-i',
                      'tests/sample/a.py',
                      '-o', 'output.py', '-t', '3.3',
                      '-d'])
    with open('output.py', 'r') as f:
        content = f.read()
    # print(content)
    assert content == 'import collections.abc\n'


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:28:59.015019
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:29:00.267330
# Unit test for function main
def test_main():
    assert(main() == 0)
    return

# Generated at 2022-06-21 17:29:06.289909
# Unit test for function main
def test_main():
    sys.argv = ['pback.py', '-i', 'test.py', '-o', 'test.py', '-t', '2.7', '-r', '.']
    assert main() == 0
    print("test_main: OK")

if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-21 17:29:07.649942
# Unit test for function main
def test_main():
    # main()
    main()



# Generated at 2022-06-21 17:32:07.766533
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py',
                '-t', 'p36',
                '-o', 'out',
                '-i', 'test/data/test_input.py']
    assert main() == 1

# Generated at 2022-06-21 17:32:09.836587
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:32:12.533073
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'test', '-o', 'test', '-t', '2.7', '-r', '.']
    assert main() == 0

# Generated at 2022-06-21 17:32:13.406274
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:32:22.881833
# Unit test for function main
def test_main():
    # Test if all the arguments are working correctly and the result is 0
    assert main() == 0
    # Test if there is an exception
    with pytest.raises(exceptions.CompilationError):
        main()
        # Test if there is another exception
    with pytest.raises(exceptions.TransformationError):
        main()
        # Test if there is another exception
    with pytest.raises(exceptions.InputDoesntExists):
        main()
        # Test if there is another exception
    with pytest.raises(exceptions.InvalidInputOutput):
        main()
        # Test if there is another exception
    with pytest.raises(PermissionError):
        main()

# Generated at 2022-06-21 17:32:28.179011
# Unit test for function main
def test_main():
    argv = ['py-backwards', '-i', 'test_files/python_files/', '-o',
            'test_files/output/', '-t', '2.7', '-r', 'test_files/python_files']

    assert main() == 0

# Generated at 2022-06-21 17:32:35.341751
# Unit test for function main
def test_main():
    from .patch import _reset_settings, _patch_argparse_exit
    from .conf import set_settings_debug, is_settings_debug
    from .compiler import _reset_files_compiled
    from unittest import mock

    # bailing out on unit test failures is a bad style
    # the function that calls sys.exit() should always be mocked
    _patch_argparse_exit()

    with mock.patch('sys.stdout') as stdout, \
            mock.patch('sys.stderr') as stderr:
        # test with debug enabled
        set_settings_debug(True)

        assert main() == 1
        stderr.assert_called_with(messages.input_doesnt_exists([]))
        assert not stdout.called

        assert main(['smth']) == 1


# Generated at 2022-06-21 17:32:37.186424
# Unit test for function main
def test_main():
	assert main()==0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:32:44.762747
# Unit test for function main
def test_main():
    # all p3k args of compilation unit
    def all_args(target, input_, output) -> list:
        return ['-i', input_, '-o', output, '-t', target]

    # all p3k args of transformation unit
    def all_args_tr(target, input_, output) -> list:
        return ['-i', input_, '-o', output, '-t', target, '-r', input_]

    def comp(target, input_, output) -> bool:
        # functions for adding new compilation units (if you need to)
        def FU(target, input_, output) -> bool:
            args = all_args(target, input_, output)
            return main(args) == 0

        # functions for adding new transformation units (if you need to)

# Generated at 2022-06-21 17:32:45.740448
# Unit test for function main
def test_main():
    assert main() == 0
