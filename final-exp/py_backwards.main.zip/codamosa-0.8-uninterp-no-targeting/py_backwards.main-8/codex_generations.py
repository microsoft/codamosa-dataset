

# Generated at 2022-06-21 17:24:24.440760
# Unit test for function main
def test_main():
    # Unit test without any arguments
    sys.argv = ['']
    assert main() == 2

    # Unit test with all arguments
    sys.argv = ['', '-i', './tests/annotations/my_module.py',
                '-o', './tests/annotations/output/',
                '-r', './tests/',
                '-t', '3.4']
    assert main() == 0

# Generated at 2022-06-21 17:24:25.895036
# Unit test for function main
def test_main():
    assert main() == 0
    assert main() == 1

# Generated at 2022-06-21 17:24:28.270902
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:36.876690
# Unit test for function main
def test_main():
    # Function arguments
    input_ = 'tests/data/main_test_file.py'
    output = 'output'
    target = 'py36'
    root = 'tests/data'
    debug = False

    def cleanup():
        from os import remove
        from os.path import isfile
        if isfile(output):
            remove(output)

    # Test for validation of compilation error
    try:
        sys.argv = ['py-backwards', '-i', input_, '-o', output, '-t', target,
                    '-r', root, '-d', str(debug)]
        result = main()
        assert result == 0
    finally:
        cleanup()

    # Test for validation of input doesn't exists error

# Generated at 2022-06-21 17:24:44.312065
# Unit test for function main
def test_main():
    from tempfile import NamedTemporaryFile
    from . import parser, translator, utils

    # Create a fake file-like object
    file = NamedTemporaryFile()
    file.write(b'print("something")')
    file.seek(0)

    # Create a fake command line arguments object
    class Args:
        def __init__(self, input, output, target, debug):
            self.input = input
            self.output = output
            self.target = target
            self.debug = debug
            self.root = ''

    # Create a fake file-like object
    output = NamedTemporaryFile()

    args = Args([file.name], output.name, '2.7', False)

    # Load parser and translator modules
    compiler = sys.modules['py_backwards.compiler']

# Generated at 2022-06-21 17:24:49.439258
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/a.py', '-o', 'b', '-t', 'py34', '-r', 'test']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:52.015162
# Unit test for function main
def test_main():
    init_settings()
    compile_files("tests/test.py", "test.py", "2.7")

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-21 17:24:56.111804
# Unit test for function main
def test_main():
    sys.argv = ['./py-backwards', '-i', 'tests/examples/py36/', '-o', 'tests/examples/py36/', '-t', 'py36']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:01.499145
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'D:\homework\py-backwards\examples\debug_syntax_error.py.py', '-o', 'D:\homework\py-backwards\examples\debug_syntax_error.py.py', '-t', '2.7', '-r', 'D:\homework\py-backwards\examples', '-d']
    main()

# Generated at 2022-06-21 17:25:02.987761
# Unit test for function main
def test_main():
    """
    Example of unit test.
    """
    assert 0 == main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:23.344595
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:24.157644
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-21 17:25:28.801838
# Unit test for function main
def test_main():
    # Because function main prints, we don't want to see it
    import io
    sys.stdout = io.StringIO()

    # When is everything ok, main returns 0
    try:
        assert main() == 0
    except SystemExit:
        pass

    # When is the file input not exists, main returns 1
    try:
        assert main(["file.py"], "file.py", "3.3") == 1
    except SystemExit:
        pass

    # When is the file output is not valid, main returns 1
    try:
        assert main(["file.py"], None, "3.3") == 1
    except SystemExit:
        pass

    # When is the input file is not valid (no .py), main return 1

# Generated at 2022-06-21 17:25:36.450256
# Unit test for function main
def test_main():
    # Code coverage in Travis
    if os.environ.get('TRAVIS') == 'true':
        print('Travis CI detected. Skipping main unit test.')
        return

    # Init directories
    os.mkdir('main_test_temp')
    os.chdir('main_test_temp')
    os.mkdir('input')
    os.mkdir('output_python35')
    os.mkdir('output_python36')
    open('input/file.py', 'w').close()

    # Init args
    sys.argv = ['py_backwards.py',
                '-i', 'input/file.py',
                '-o', 'output_python35/file.py',
                '-t', '3.5']
    assert main() == 0


# Generated at 2022-06-21 17:25:37.236373
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:25:38.561880
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-21 17:25:48.240142
# Unit test for function main
def test_main():
    test_path = os.path.join(os.getcwd(), 'test')
    test_input = os.path.join(test_path, 'input')
    test_output = os.path.join(test_path, 'output')
    test_sources_root = os.path.join(test_path, 'sources_root')
    find_output_files(test_input, test_output)
    find_output_files(test_input, test_output,
                      sources_root=test_sources_root)
    test_input_output_combinations(test_input, test_output)
    test_input_output_combinations(test_input, test_output,
                                   sources_root=test_sources_root)
    return 0

# Find all output files for test function

# Generated at 2022-06-21 17:25:59.653921
# Unit test for function main
def test_main():
    # Case 1, both files exist and they are inputs:
    sys.argv = ['python.py', '-i', 'test\\test_files\\source.py', '-o',
    'test\\test_files\\compile.py', '-t', 'python3.5']
    assert main() == 0
    # Case 2, one of the files cannot be found:
    sys.argv = ['python.py', '-i', 'test\\test_files\\source.py', '-o',
    'test\\test_files\\compile.py', '-t', 'python3.5']
    assert main() == 1
    # Case 3, output file is not a file but a folder:

# Generated at 2022-06-21 17:26:00.684286
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:03.988065
# Unit test for function main
def test_main():
    sys.argv = ['name', '-i', 'in.py', '-o', 'out.py', '-t', '3.3']
    assert main() == 0

# Generated at 2022-06-21 17:26:29.082019
# Unit test for function main
def test_main():
    import os
    import shutil
    import subprocess
    import re
    import py_backwards
    import py_backwards.conf as conf
    import py_backwards.const as const
    conf.init_settings(None)

    executable = sys.executable
    test_folder = os.path.dirname(py_backwards.__file__) + '/tests/'
    sources_root = test_folder + '/sources'
    output_folder = test_folder + '/output'

    def create_args(input, output, target):
        return [executable, '-m', 'py_backwards',
                '-i', input, '-o', output, '-t', target]


# Generated at 2022-06-21 17:26:31.165479
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:36.249224
# Unit test for function main
def test_main():
    try:
        args = ['py-backwards', '-i', __file__, '-o', 'a', '-t', '3.5.3']
        main()
    except SystemExit:
        pass
    else:
        assert False

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:37.455745
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:40.235994
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:43.215104
# Unit test for function main
def test_main():
    from .test_main import test_main
    test_main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:46.233211
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'folder',
                '-o', 'folder', '-t', '2.6']
    assert main() == 1


if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:26:58.284875
# Unit test for function main
def test_main():
    from pytest import raises
    from dirsync import sync
    from os import remove, chmod
    from os.path import dirname, exists, join
    from shutil import copyfileobj
    from textwrap import dedent
    from tempfile import mkdtemp, mkstemp
    from unittest.mock import patch

    old_kargs = ['-i', '-', '-o', '-', '-t', '2.7', '-r', 'src']
    new_kargs = old_kargs + ['-d']


# Generated at 2022-06-21 17:27:01.406100
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test-fixtures/input/syntax_error.py', '-o', 'test-fixtures/output/syntax_error', '-t', 'py27', '-r', 'test-fixtures']
    assert main() == 1


# We are using an entry point for tests to keep python2 compatible

# Generated at 2022-06-21 17:27:02.252311
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:46.616553
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

# Generated at 2022-06-21 17:27:48.123188
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-21 17:27:56.867419
# Unit test for function main
def test_main():
    argv = ['py-backwards', '-t', '3.7', '-i', 'test/test_data/compile/'
                                               'collection_literals.py', '-o',
            'compile/collection_literals_compiled.py']
    sys.argv = argv
    assert main() == 0
    assert open('compile/collection_literals_compiled.py').read() == \
           open('test/test_data/compile/collection_literals_compiled.py').read()


# Generated at 2022-06-21 17:28:09.017307
# Unit test for function main
def test_main():
    # создание выходной директории
    output_dir = 'py-backwards-test'
    os.mkdir(output_dir)
    
    # построение аргументов коммандной строки
    inp_dir = 'test/py-backwards'
    out_dir = output_dir
    target = '3.5.1'
    root_dir = 'test'
    args = ['-i', inp_dir, '-o', out_dir, '-t', target, '-r', root_dir]
    print(args)

# Generated at 2022-06-21 17:28:20.474009
# Unit test for function main
def test_main():
    # testing correct parameters
    sys.argv = ['py-backwards.py', '-i', 'test1', '-o', 'test2', '-t', '2.7',]
    assert main() == 0

    # testing -i parameter
    sys.argv = ['py-backwards.py', '-o', 'test2', '-t', '2.7',]
    assert main() == 1

    # testing -o parameter
    sys.argv = ['py-backwards.py', '-i', 'test1', '-t', '2.7',]
    assert main() == 1

    # testing -t parameter
    sys.argv = ['py-backwards.py', '-i', 'test1', '-o', 'test2',]
    assert main() == 1

    # testing syntax_

# Generated at 2022-06-21 17:28:30.805617
# Unit test for function main
def test_main():
    import pytest
    from contextlib import redirect_stdout
    from io import StringIO
    from collections import namedtuple
    from .conf import settings

    pytest.importorskip("colorama")

    args = namedtuple('args', 'input output target root debug')(
        ['test_input.py'], 'test_output.py', '2.7', 'test_root', False)

    init_settings(args)
    assert settings.debug is False
    assert settings.input == ['test_input.py']
    assert settings.output == 'test_output.py'
    assert settings.target == '2.7'
    assert settings.root == 'test_root'

    f = StringIO()
    with redirect_stdout(f):
        assert main() == 1

# Generated at 2022-06-21 17:28:31.611591
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:28:35.551582
# Unit test for function main
def test_main():
    import argparse
    argparse.ArgumentTypeError = Exception
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:28:37.027840
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:28:43.492280
# Unit test for function main
def test_main():
    test_args = ['-i', 'tests/input/', '-o', 'tests/output/', '-t', '2.7', '-d']
    old_args = sys.argv
    sys.argv = test_args
    main()
    sys.argv = old_args

# Generated at 2022-06-21 17:30:13.542471
# Unit test for function main
def test_main():
    x = main()
    assert x == 0

# Generated at 2022-06-21 17:30:17.769972
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', ['py-backwards', '-i', 'input', '-o',
                                 'output', '-t', 'py26', '-r', 'root']):
        main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:30:29.528078
# Unit test for function main
def test_main():
    output = sys.stdout
    result = main(['-i', 'py-backwards/test.py', '-o', '.', '-t', '2.7', '-r', '.', '-d'])
    assert result == 0
    result = main(['-i', 'py-backwards/test/test2.py', '-o', '.', '-t', '2.7', '-r', '.', '-d'])
    assert result == 0
    result = main(['-i', 'py-backwards/test/test2.py', '-o', '.', '-t', '3.6', '-r', '.', '-d'])
    assert result == 0

# Generated at 2022-06-21 17:30:31.401063
# Unit test for function main
def test_main():
    #TODO: implementation
    return None

# Generated at 2022-06-21 17:30:35.189632
# Unit test for function main
def test_main():
    sys.argv = 'py-backwards.py -i test_data/test.py -o ./ -t py35 -d'.split()
    assert main() == 0

# Generated at 2022-06-21 17:30:41.285146
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards', '-i', 'tests/sources/test_list_comp.py', '-o',
        'tests/sources/out.py', '-t', '2.7', '-r', 'sources/', '-d'
    ]
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:30:47.922845
# Unit test for function main
def test_main():
    args = ["test.py", "-i", "/home/work/repos/py-backwards/py_backwards/tests/fixtures/syntax_error.py",
            "-o", "/home/work/repos/py-backwards/py_backwards/tests/fixtures/error.py",
            "-r", "/home/work/repos/py-backwards/py_backwards/tests/fixtures/project",
            "-t", "2.7"]
    with pytest.raises(SystemExit) as e:
        main() == 1
    #assert e.type == SystemExit
    #assert e.value.code == 1

    #args = ["test.py", "-i", "/home/work/repos/py-backwards/py_backwards/tests/fixtures/syntax_error.py",


# Generated at 2022-06-21 17:30:49.244000
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:54.066678
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards",
                "-t", "python2",
                "-i", "file.py",
                "-o", "file.py"]

    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-21 17:30:57.157931
# Unit test for function main
def test_main():
    init_settings(main())

if __name__ == '__main__':
    test_main()