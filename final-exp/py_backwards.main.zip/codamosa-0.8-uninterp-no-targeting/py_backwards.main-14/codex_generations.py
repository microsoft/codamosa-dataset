

# Generated at 2022-06-21 17:24:20.950650
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:21.691415
# Unit test for function main
def test_main():
    assert(main() == 0)

# Generated at 2022-06-21 17:24:22.180314
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:32.570306
# Unit test for function main
def test_main():
    assert main() == 0
    assert main([__file__, '-h']) == 0
    assert main([__file__, '-i', 'test_main.py']) == 1
    assert main([__file__, '-i', 'test_main.py',
                 '-o', 'test_main.py']) == 1
    assert main([__file__, '-i', 'test_main.py', '-t', '2.7']) == 1
    assert main([__file__, '-i', 'test_main.py', '-t', '2.7',
                 '-o', 'test_main.py']) == 0

# Generated at 2022-06-21 17:24:38.174861
# Unit test for function main
def test_main():
    # Input file or folder
    input = 'test.py'
    # Output file or folder
    output = 'test_compiled.py'
    # Target python version
    target = '2.7'

    # Function main() returns integer code
    main_code = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:44.714109
# Unit test for function main
def test_main():
    # Simple test
    input = ['test.py']
    output = 'out.py'
    target = '2.7'
    root = '/'
    debug = True
    args = Namespace(input=input, output=output, target=target,
                     root=root, debug=debug)

    init_settings(args)

    assert const.input == input
    assert const.output == output
    assert const.target == target
    assert const.root == root
    assert const.debug == debug

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:53.180093
# Unit test for function main
def test_main():
    from argparse import Namespace
    from .conf import SETTINGS
    args = Namespace(
        input=['../tests/src'],
        output='../tests/dst',
        target='3.6',
        root='../tests'
    )

    init_settings(args)
    assert SETTINGS['input'] == args.input
    assert SETTINGS['output'] == args.output
    assert SETTINGS['target'] == const.TARGETS[args.target]
    assert SETTINGS['root'] == args.root

# Generated at 2022-06-21 17:24:58.125689
# Unit test for function main
def test_main():
    input_path = '../test/inputs/targets/tuple_unpacking.py'
    output_path = '../test/outputs/tuple_unpacking.py'
    if main([input_path, output_path]) != 0:
        raise RuntimeError()


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))

# Generated at 2022-06-21 17:24:58.691285
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:25:02.353517
# Unit test for function main
def test_main():
    # mock command line arguments
    sys.argv = [sys.argv[0], '-i', 'lib/tests/examples/example_01.py',
                '-d', '-o', 'output/', '-r', 'lib/tests/examples/', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-21 17:25:23.350227
# Unit test for function main
def test_main():
    args = main.__annotations__['return']
    assert issubclass(args, int)

# Generated at 2022-06-21 17:25:25.873860
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/input', '-o', 'tests/output', '-t', '2.7']
    assert main() == 0
    assert os.path.isfile('tests/output/input/fib-2.7.py')


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:26.683502
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:33.822720
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('test/testinput.py')
    sys.argv.append('-o')
    sys.argv.append('test/testoutput/')
    sys.argv.append('-t')
    sys.argv.append('py36')
    sys.argv.append('-r')
    sys.argv.append('test/')

    assert main() == 0

# Generated at 2022-06-21 17:25:41.132413
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test/fixtures/input.py', '-o', 'test/output_test.py', '-t', '2.7']
    assert main() == 0
    os.remove('test/output_test.py')

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:25:42.154414
# Unit test for function main
def test_main():
    pass


if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:25:48.301779
# Unit test for function main
def test_main():
    from .cli_test import assert_main

# Generated at 2022-06-21 17:25:49.146449
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:51.257396
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:25:52.113040
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:14.844289
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', '../tests/data/test.py', '-o', '../tests/data/test.py', '-t', 'Py36', '-r', '../tests/data/', '-d']
    main()

# Generated at 2022-06-21 17:26:15.391169
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:16.167095
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:26:27.216468
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-21 17:26:38.270828
# Unit test for function main
def test_main():
    import os
    import shutil
    path = os.path.dirname(os.path.realpath(__file__))
    input_ = path + "/unit_tests_data/class/input.py"
    output = path + "/unit_tests_data/class/output.py"
    root = path + "/unit_tests_data/class/"
    assert os.path.isfile(input_)
    shutil.copyfile("unit_tests_data/class/output.py",
                    "unit_tests_data/class/output.old")
    assert os.path.isfile(output)
    input_list = [input_]
    target = "python35"
    args = ['-i', input_, '-o', output, '-t', target, '-r', root]

# Generated at 2022-06-21 17:26:40.790798
# Unit test for function main
def test_main():
    from . import conf, const

    sys.argv = ['', '-i', './examples/invalid_input', '-o', './output',
                '-t', '3.5', '-r', '.']
    conf.init_settings()

    if main() > 0:
        import pytest

        pytest.fail('main error')

# Generated at 2022-06-21 17:26:43.992118
# Unit test for function main
def test_main():
    # if __name__ == '__main__':
    #     main()
    sys.argv = [sys.argv[0], "-i", "test.py", "-o", "test_test.py", "-t", "3.6", "-r", "test.py"]
    main()

# Generated at 2022-06-21 17:26:45.824645
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:55.069454
# Unit test for function main
def test_main():

    # create a instance of the argparse object
    parser = ArgumentParser()

    # build the parser object
    parser.add_argument("--input", type=str, default=None)
    parser.add_argument("--output", type=str, default=None)
    

    # parse the arguments from the standard input
    args = parser.parse_args()

    # run the main function and save the output
    func_out = main()

    # check the output
    assert func_out == 0

# Generated at 2022-06-21 17:26:59.200385
# Unit test for function main
def test_main():
    from . import mock_args
    from . import mock_conf

    old_parser_args = sys.argv
    old_settings = mock_conf.settings
    sys.argv = mock_args.get_args(['src',
                                   'out',
                                   'py27',
                                   'root'])
    try:
        mock_conf.settings = {}
        init_settings(mock_args.get_args(['src',
                                          'out',
                                          'py27',
                                          'root']))
        assert main() == 0
    finally:
        sys.argv = old_parser_args
        mock_conf.settings = old_settings

# Generated at 2022-06-21 17:27:48.696912
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "test.py", "-o", "test_compiled.py", "-t", "3.5", "--debug"]
    main()
    sys.argv = ["py-backwards", "-i", "test.py", "-o", "test_compiled.py", "-t", "3.5", "--debug", "-r", "C:\\Users\\Olesia\\PycharmProjects\\py-backwards\\py-backwards\\test"]
    main()


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:27:58.234383
# Unit test for function main
def test_main():
    # Positive case
    sys.argv = [
        'test.py',
        '-i', 'setup.py', 'test.py',
        '-o', 'build',
        '-t', '2.7',
        '-r', '.',
    ]
    assert main() == 0
    # Negative case
    sys.argv = [
        'test.py',
        '-i', 'setup.py', 'test.py',
        '-o', 'build',
        '-t', '2.7',
        '-r', '.',
    ]
    assert main() != 1


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:28:01.040400
# Unit test for function main
def test_main():
    main()

# Code coverage for main function
if __name__ == 'main':
    main()

# Generated at 2022-06-21 17:28:11.301105
# Unit test for function main
def test_main():
    from .const import TARGETS
    from . import project_version
    from argparse import Namespace
    from io import StringIO
    import sys

    default_stdout = sys.stdout
    sys.stdout = StringIO()

    args = Namespace(
        input='',
        output='',
        target='',
        root='',
        debug=False
    )
    result_dict = dict.fromkeys(TARGETS.keys(), 0)

    def run_test(inp, out, target, root='', debug=False) -> int:
        args.input = inp
        args.output = out
        args.target = target
        args.root = root
        args.debug = debug
        return main()


# Generated at 2022-06-21 17:28:13.325379
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:28:15.953548
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:28:17.030108
# Unit test for function main
def test_main():
    assert main() != -1

# Generated at 2022-06-21 17:28:24.752546
# Unit test for function main
def test_main():
    import sys
    from io import StringIO
    capturedOutput = StringIO()
    sys.stdout = capturedOutput
    main()
    sys.stdout = sys.__stdout__
    out = capturedOutput.getvalue()
    if(out == ''):
        return False

    return True

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:28:26.321100
# Unit test for function main
def test_main():
    assert(main() == 0)

# Generated at 2022-06-21 17:28:27.695103
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:29:56.584827
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:02.979566
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'tests/input/root/a/b',
        '-o', 'tests/output/root/a/b',
        '-t', '3.5',
        '-r', 'tests/input/root'
    ]
    assert main() == 0

# Generated at 2022-06-21 17:30:10.077776
# Unit test for function main
def test_main():
    # test for no arguments
    assert main() == 2

    # test for invalid arguments
    argv0 = sys.argv
    sys.argv = [sys.argv[0], '-i', 'input_file', '-o', 'output_file']
    assert main() == 2
    sys.argv = argv0

    # test for normal input and output
    sys.argv = [sys.argv[0], '-i', 'input_file', '-o', 'output_file', '-t',
                'py2']
    assert main() == 0
    sys.argv = argv0

# Generated at 2022-06-21 17:30:11.839214
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-21 17:30:16.406406
# Unit test for function main
def test_main():
    sys.argv = ['main.py', '-i', '../resources/calc.py', '-o', '..', 
                '-t', '3.6', '-d']
    main()

# Generated at 2022-06-21 17:30:16.933310
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:29.368953
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    import argparse
    from .compiler import compile_files
    from .conf import init_settings
    from . import const, messages, exceptions

    # Input doesn't exist
    with pytest.raises(exceptions.InputDoesntExists):
        sys.argv = ['py-backwards', '-i', 'noexist', '-o', 'output', '-t', '3.5']
        main()

    # Invalid output
    with pytest.raises(exceptions.InvalidInputOutput):
        sys.argv = ['py-backwards', '-i', 'input', '-o', 'input', '-t', '3.5']
        main()

    # Permission error

# Generated at 2022-06-21 17:30:32.545573
# Unit test for function main
def test_main():
    init_settings(None)

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:34.647796
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:45.308064
# Unit test for function main
def test_main():
    from shutil import copytree, rmtree
    from os import chdir, mkdir, remove
    from os.path import dirname, join
    from .compiler import remove_pyc_files
    from . import errors

    dirname_ = dirname(__file__)
    test_dir = join(dirname_, 'Test')
    test_files = [join(test_dir, file) for file in ['test.py', 'test_ast.py',
                                                    'test_file.py',
                                                    'test_errors.py']]
    correct_files = [join(test_dir, file) for file in ['test_correct.py',
                                                       'test_ast_correct.py',
                                                       'test_file_correct.py',
                                                       'test_errors_correct.py']]

# Generated at 2022-06-21 17:34:07.826687
# Unit test for function main
def test_main():
    sys.argv.extend(['-i', os.path.join(os.path.dirname(__file__),
                                        '..', 'tests', 'resources'),
                       '-o', '.', '-t', '2.7', '-d'])
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:34:12.218799
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]]
    sys.argv.append('-i')
    sys.argv.append('/Users/nibea/Documents/py-backwards/tests/')
    sys.argv.append('-o')
    sys.argv.append('/Users/nibea/Documents/py-backwards/pybackwards/copy/')
    sys.argv.append('-t')
    sys.argv.append('3.3')
    assert main() == 0, "unit test for main function failed"