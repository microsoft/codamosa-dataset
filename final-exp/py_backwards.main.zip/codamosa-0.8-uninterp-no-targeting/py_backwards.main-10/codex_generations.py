

# Generated at 2022-06-21 17:24:08.556021
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-21 17:24:09.029880
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:12.819194
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', "test_data/src/", "-o", "test_data/bin/",
                "-t", "3.6", "-r", "test_data/src/", "-d"]
    assert main() == 0

# Generated at 2022-06-21 17:24:20.449749
# Unit test for function main
def test_main():
    from os import getcwd
    from unittest.mock import patch
    from .conf import settings

    def get_target():
        return settings.PYTHON_TARGET

    arguments = ['py-backwards', '-i', 'test/sample', '-o', 'test/sample_py36',
                 '-t', 'py36', '-r', getcwd()]

    with patch.object(sys, 'argv', arguments):
        with patch('py_backwards.__main__.compile_files',
                   side_effect=exceptions.CompilationError('error')):
            assert main() == 1


# Generated at 2022-06-21 17:24:21.263907
# Unit test for function main
def test_main():
    assert(main() == 1)

# Generated at 2022-06-21 17:24:25.319831
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'C:/Users/hp/git/py-backwards/tests/test_data', '-o',
                    'C:/Users/hp/git/py-backwards/tests/test_output', '-t',
                    'python3.3', '-r', 'C:/Users/hp/git/py-backwards']
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:25.869399
# Unit test for function main
def test_main():
    assert __name__ == '__main__'

# Generated at 2022-06-21 17:24:35.229491
# Unit test for function main
def test_main():
    init_settings({'input': ['test_data/main_test.py'],
                   'output': 'out',
                   'target': '2.7',
                   'debug': False})
    compile_files('test_data/main_test.py', 'out',
                  const.TARGETS['2.7'],
                               None)

# Generated at 2022-06-21 17:24:43.060126
# Unit test for function main
def test_main():
    class Args:
        def __init__(self, input, output, target, root, debug):
            self.input = input
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

    # Test with input file and output file
    assert main(Args('tests/files/hello.py', 'tests/output/hello.py',
                     'python2', 'tests', False)) == 0
    # Test with input folder and output folder
    assert main(Args('tests/files', 'tests/output', 'python2',
                     'tests', False)) == 0
    # Test with input folder, output file, and invalid root
    assert main(Args('tests/files', 'tests/output/hello.py',
                     'python2', 'tests/files', False)) == 1
    # Test with

# Generated at 2022-06-21 17:24:46.358635
# Unit test for function main
def test_main():
    main(['-i', 'C:\\Users\\Palina\\PycharmProjects\\PyBackwards\\pybackwards\\__init__.py',
          '-o', 'C:\\Users\\Palina\\PycharmProjects\\PyBackwards\\pybackwards\\__init__.py',
          '-t', '2.7'])

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:58.730261
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/examples/test.py',
                '-o', 'tests/examples/test.out.py',
                '-t', '2.7']
    assert main() == 0



# Generated at 2022-06-21 17:24:59.245834
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:01.463758
# Unit test for function main
def test_main():
    assert main() != 1

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:02.885129
# Unit test for function main
def test_main():
    main()
    main("-i test/py_backwards_test.py -o output.py".split(" "))

# Generated at 2022-06-21 17:25:07.420496
# Unit test for function main
def test_main():
    input_ = 'a/b/c.py'
    output = 'a/b/c.py'
    argv = ['-i', input_, '-o', output, '-t', 'python27']
    with pytest.raises(SystemExit):
        main(argv)

# Generated at 2022-06-21 17:25:17.007599
# Unit test for function main
def test_main():
    from . import test
    import os
    import shutil
    import tempfile
    from unittest.mock import patch
    from unittest import mock
    from . import conf

    tempdir = tempfile.mkdtemp()

    def cleanup():
        shutil.rmtree(tempdir)


# Generated at 2022-06-21 17:25:18.982799
# Unit test for function main
def test_main():
    input_ = ['test/test_code.py']
    output = 'test/o.py'
    target = 'python2'
    root = 'test'
    assert main() == 0

# Generated at 2022-06-21 17:25:19.801304
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:25.486887
# Unit test for function main
def test_main():
    from .conf import settings
    from . import exceptions

    with pytest.raises(SystemExit):
        main()

    with pytest.raises(exceptions.CompilationError):
        main(['-t', '2.7', '-o', 'out', '-i', 'input_file'])


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:26.122905
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:44.287375
# Unit test for function main
def test_main():
    assert main() != 0

# Generated at 2022-06-21 17:25:48.377683
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:56.118402
# Unit test for function main
def test_main():
    '''
    Test for function main
    '''
    from click.testing import CliRunner
    from .cli import main_group

    runner = CliRunner()
    result = runner.invoke(main_group, ["-i", "regular.py",
                                        "-o", "result.py",
                                        "-t", "2",
                                        "-r", "root"])
    assert result.exit_code == 0


# Generated at 2022-06-21 17:25:56.851603
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:59.283166
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:09.231863
# Unit test for function main
def test_main():
    args = sys.argv
    sys.argv = ['py-backwards.py', 'test.py', '--input', 'test.py', '--output',
                'test_2.py', '--target', '2', '--root', '.']
    assert main() == 0
    sys.argv = ['py-backwards.py', 'test.py', '--input', 'test.py', '--output',
                'test_2.py', '--target', '3', '--root', '.']
    assert main() == 0
    sys.argv = ['py-backwards.py', 'test.py', '--input', 'test.py', '--output',
                'test_2.py', '--target', '3.6', '--root', '.']
    assert main() == 0


# Generated at 2022-06-21 17:26:13.095439
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except:
        assert 1 == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:15.475828
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:26:16.326832
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:21.635281
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test_main.py', '-o', 'test_main_output.py', '-t', '2.7']
    assert(main() == 0)

# Generated at 2022-06-21 17:27:07.506956
# Unit test for function main

# Generated at 2022-06-21 17:27:18.771907
# Unit test for function main
def test_main():
    import sys, os
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    test_file = os.path.join(os.path.dirname(__file__), "test_files", "test.py")
    output_file = os.path.join(os.path.dirname(__file__), "test_files", "test_result.py")

   

# Generated at 2022-06-21 17:27:25.924354
# Unit test for function main
def test_main():
    argv = sys.argv
    sys.argv = ['py-backwards', '-i', 'C:\\Users\\Егор\\Downloads\\test.py', '-o', 'C:\\Users\\Егор\\Downloads\\test2.py', '-t', '2.7']
    assert main() == 0
    sys.argv = argv

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:27:27.819323
# Unit test for function main
def test_main():
    if main() == 1:
        raise Exception("test_main failed")

# Generated at 2022-06-21 17:27:38.775873
# Unit test for function main
def test_main():
    """
    Testing if all the status codes are working
    """
    sys.argv = ['py-backwards', '-i', 'tests/test_compiler.py', '-o', 'test.py', '-t', 'py27']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/nonexistent.py', '-o', 'test.py', '-t', 'py27']
    assert main() == 1
    sys.argv = ['py-backwards', '-i', 'tests/test_compiler.py', '-o', 'tests/test_compiler.py', '-t', 'py27']
    assert main() == 1

# Generated at 2022-06-21 17:27:39.655351
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:27:40.557905
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:27:41.102641
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:27:41.776585
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:42.646193
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:28:57.939795
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:28:58.394561
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:28:59.503801
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-21 17:29:00.318306
# Unit test for function main
def test_main():
    assert main() == 0;

# Generated at 2022-06-21 17:29:03.019873
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:29:11.693361
# Unit test for function main
def test_main():
    with tempfile.TemporaryDirectory() as temp_dir:

        # Normal case
        shutil.copy('test/test_project/test_app.py', str(temp_dir))
        try:
            main([f'--input={temp_dir}/test_app.py',
                  f'--output={temp_dir}/out',
                  f'--target=2.7'])
        except SystemExit:
            pass
        output_files = os.listdir(f'{temp_dir}/out')
        assert 'test_app.py' in output_files

        # Case, when input doesn't exist

# Generated at 2022-06-21 17:29:14.216860
# Unit test for function main
def test_main():
    try:
        value = main()
    except SystemExit as e:
        value = e.code
    assert value == 0

# Generated at 2022-06-21 17:29:15.631329
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-21 17:29:27.090244
# Unit test for function main
def test_main():
    import io
    import sys
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    assert main() == 0
    assert sys.stdout.getvalue() == ''
    assert sys.stderr.getvalue() == ''
    sys.stderr = io.StringIO()
    assert main(['py-backwards', '-i', 'tests/primes', '-o', 'tests/primes2', '-t',
                 '3.5.0', '-r', 'tests']) == 0
    print(sys.stderr.getvalue())
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__



# Generated at 2022-06-21 17:29:34.165695
# Unit test for function main
def test_main():
    class Args:
        debug = False
        input = '/home/py_backwards/tests/test_main/input'
        output = '/home/py_backwards/tests/test_main/output'
        root = '/home/py_backwards'
        target = '3.5'
    assert main(Args) == 0
# End of test

# Generated at 2022-06-21 17:32:41.461270
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/sources/text.py', '-o',
                'tests/sources/out.py', '-t', '3.4', '-r', 'tests/sources/',
                'tests/sources/reserved.py',
                '-d']
    init_settings()
    #assert main() == None

# Generated at 2022-06-21 17:32:48.288042
# Unit test for function main
def test_main():
    test_input = ['tests/target_files/test1.py']
    test_output = 'tests/target_files'
    test_target = '3.6'
    assert main(test_input, test_output, test_target) == 0

if __name__ == '__main__':
    print(main())

# Generated at 2022-06-21 17:32:48.818825
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:32:57.409611
# Unit test for function main
def test_main():
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main

# Generated at 2022-06-21 17:33:01.396936
# Unit test for function main
def test_main():
    sys.argv = 'main.py -i test -o test -t 2.7 -r test -d'.split()
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:33:07.058048
# Unit test for function main
def test_main():
    sys.argv = ['py_backwards', '-i', '.tests/fixtures/02_input', '-o', '.tests/fixtures/03_output', '-t', 'python2.7', '-d']
    main()


# Generated at 2022-06-21 17:33:08.644862
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:33:15.257880
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '2.7',
                '-r', 'test/test_data']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:33:18.086831
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:33:25.773034
# Unit test for function main
def test_main():
    from unittest.mock import patch
    import os
    import tempfile
    from . import __version__

    def caught_exception(e):
        with patch('sys.stderr', new=StringIO()):
            return main() == 1 and \
                sys.stderr.getvalue().find(str(e)) != -1

    tf1 = tempfile.NamedTemporaryFile(suffix='.py')
    tf2 = tempfile.NamedTemporaryFile(suffix='.py')
    tf3 = tempfile.NamedTemporaryFile(suffix='.py')
    input = os.path.join(os.path.dirname(__file__), 'tests/input')
    output = os.path.join(os.path.dirname(__file__), 'tests/output')