

# Generated at 2022-06-21 17:24:29.044880
# Unit test for function main
def test_main():
    # This is a simple test for main function
    # The main function of the main module is hard to test
    # because it is a command-line program
    # Currently the only test that is done is that no exceptions are raised
    # when executing main function
    try:
        main()
    except:
        return False
    return True

# Generated at 2022-06-21 17:24:37.468807
# Unit test for function main
def test_main():
    from pprint import pprint
    from .conf import get_settings
    from .settings import Settings

    sys.argv = ['-i', 'input_file', '-o', 'output_file', '-t', 'py36']
    main()
    settings: Settings = get_settings()
    pprint(settings.__dict__)
    assert settings.input == ['input_file']
    assert settings.output == 'output_file'
    assert settings.target == 'py36'
    assert settings.root is None
    assert settings.debug == False

    sys.argv = ['-i', 'input_file', '-o', 'output_file', '-t', 'py36',
                '-r', 'root_folder']
    main()
    settings: Settings = get_settings()

# Generated at 2022-06-21 17:24:41.044464
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/resources/in/', '-o',
                'tests/resources/out/', '-t', '3.6', '-r', 'tests/resources/']
    result = main()
    assert result == 0

# Generated at 2022-06-21 17:24:44.013073
# Unit test for function main
def test_main():
    # raise ValueError
    file = open('tests/hello.py', 'w')
    file.write('print(1)')
    file.close()
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:44.479846
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:45.395506
# Unit test for function main
def test_main():
    import pytest
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-21 17:24:46.332153
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:47.118457
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:47.778138
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:50.517834
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    exit_code = main()
    sys.exit(exit_code)

# Generated at 2022-06-21 17:25:11.360450
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:25:14.590501
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i',
                'C:/Users/Paul/PycharmProjects/py-backwards/tests/single_file',
                '-o',
                'C:/Users/Paul/PycharmProjects/py-backwards/tests/single_file_output',
                '-t',
                '2',
                '-r',
                'C:/Users/Paul/PycharmProjects/py-backwards/tests/root',
                '-d']
    main()

# Generated at 2022-06-21 17:25:15.065957
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:25:18.588444
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards',\
            '-i', 'tests/parsing/files.py',\
            '-o', 'tests/parsing/files_out.py',\
            '-t', '2.7']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:19.037734
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:22.212462
# Unit test for function main
def test_main():
    # assert main() == 1
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:23.053677
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:25:24.003480
# Unit test for function main

# Generated at 2022-06-21 17:25:24.877881
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:25.679073
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:47.947523
# Unit test for function main
def test_main():
    import subprocess
    from os import remove
    from .test import test_dir

    main()
    main()
    main()
    main('ls', '-a')
    subprocess.check_output(
        ["python", "main.py", "-i", test_dir, "-o", test_dir,
         "-t", "3.3"])
    subprocess.check_output(
        ["python", "main.py", "-i", "main.py", "-o", "main.py",
         "-t", "3.3"])
    remove(test_dir + '/*.py')


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:59.522197
# Unit test for function main
def test_main():
    from . import const, messages, exceptions
    import argparse
    import io
    import unittest
    import sys
    import os
    import shutil
    from contextlib import redirect_stdout, redirect_stderr
    from filecmp import dircmp
    from os import path
    from .conf import init_settings
    from .compiler import compile_files
    from colorama import init
    init()

    script_path = os.path.dirname(os.path.realpath(__file__))
    input_path = os.path.join(script_path, 'test', 'test_data', 'input')
    output_path = os.path.join(script_path, 'test', 'test_data', 'output')


# Generated at 2022-06-21 17:26:00.679980
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:01.213426
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:02.887748
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:26:04.436502
# Unit test for function main
def test_main():
    # We can't do full test here, but we check that there is no errors
    main()
    assert True

# Generated at 2022-06-21 17:26:06.363055
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-21 17:26:07.263677
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:26:18.266350
# Unit test for function main
def test_main():
    import sys
    from unittest import TestCase, mock
    from .compiler import compile_files as _compile_files, compile_string
    from .exceptions import CompilationError, TransformatioError

    class MainTestCase(TestCase):
        def setUp(self):
            sys.argv = ['py-backwards']

        @mock.patch.object(_compile_files, '__name__', 'compile_files')
        def test_output_file(self):
            sys.argv += ['-i', 'input-file',
                         '-o', 'output-file',
                         '-t', 'PY34']

# Generated at 2022-06-21 17:26:20.935629
# Unit test for function main
def test_main():
    original_input = sys.argv[1:]
    sys.argv = ['', '-i', 'tests/calc.py', '-o', '/tmp/calc.py', '-r', 'tests',
                '-t', '2.7']

    try:
        assert main() == 0
    finally:
        sys.argv = original_input

# Generated at 2022-06-21 17:26:55.762512
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:56.566090
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:57.416576
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:27:07.812288
# Unit test for function main
def test_main():
    from unittest import mock, TestCase
    from unittest.mock import MagicMock

    class Test(TestCase):
        def test_compilation_result_unittest_message_to_console(self):
            test_args = MagicMock()
            test_args.input = ['some/path']
            test_args.output = 'some/output'
            test_args.target = 'py35'
            test_args.root = None
            test_args.debug = False

            test_path_compile = 'pybackwards.compiler'
            with mock.patch(test_path_compile + '.compile_files',
                            return_value=True):
                assert main() == 0


# Generated at 2022-06-21 17:27:09.248852
# Unit test for function main
def test_main():
    r = main()
    assert r == 0

# Generated at 2022-06-21 17:27:17.474426
# Unit test for function main
def test_main():
    # Setup
    test_input = 'myfolder/myfile.py'
    test_output = 'myfolder'
    test_args = ['py-backwards', '-i', test_input, '-o', test_output, '-t', 'python27']
    sys.argv = test_args
    result = compile_files(test_input, test_output, 'python27')

    # Test
    assert main() == 0

    # Teardown
    sys.argv = []

# Generated at 2022-06-21 17:27:18.236157
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:19.496289
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:27.367388
# Unit test for function main
def test_main():
    main('test_files/test_main_1.py', 'test_files/test_main_2.py',
         'test_files/test_main_3.py',
         'test_files/test_main_dir', 'test_files/test_main_dir_2', '3')
    main('test_files/test_main_1.py', 'test_files/test_main_2.py',
      'test_files/test_main_3.py', 'test_files/test_main_dir',
      'test_files/test_main_dir_2', '2')

# Generated at 2022-06-21 17:27:31.490171
# Unit test for function main
def test_main():
    ret = main()
    assert ret == 1

if __name__ == "__main__":
    ret = main()
    sys.exit(ret)

# Generated at 2022-06-21 17:28:48.908316
# Unit test for function main
def test_main():
    sys.argv[1:] = ["-i",
                    "./test_input/test.py",
                    "-o",
                    "./test_output/",
                    "-t",
                    "2.7",
                    "-r",
                    "../",
                    "-d",
                    "true"]
    assert main() == 0

# Generated at 2022-06-21 17:29:00.114179
# Unit test for function main
def test_main():
    # An exception of type CompilationError should be raised when an input file is not valid Python 3.
    input_file = "tests/invalid_input.py"
    with pytest.raises(exceptions.CompilationError) as excinfo:
        result = compile_files(input_file, None, const.TARGETS['3.6'], None)
    assert "invalid_input.py:1:1: SyntaxError: unexpected EOF while parsing" in str(excinfo.value)
    # An exception of type InputDoesntExists should be raised when an input file doesn't exists.
    input_file = "tests/invalid.py"

# Generated at 2022-06-21 17:29:02.818252
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:29:04.726584
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:29:05.508178
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-21 17:29:10.335377
# Unit test for function main
def test_main():
    init_settings({
        'input': [],
        'output': '',
        'target': '2.7',
        'root': '',
        'debug': False
    })
    try:
        main()
    except SystemExit as e:
        assert e.code == 2

# Generated at 2022-06-21 17:29:18.488593
# Unit test for function main
def test_main():
    from pytest import raises
    from io import StringIO
    from unittest.mock import patch

    with raises(SystemExit) as e:
        with patch('sys.argv', ['py-backwards']):
            with patch('sys.stderr', new_callable=StringIO) as out:
                main()
    assert out.getvalue() == messages.invalid_arguments()
    assert str(e.value) == '2'

    with raises(SystemExit) as e:
        with patch('sys.argv', ['py-backwards', '-i', '/folder']):
            with patch('sys.stderr', new_callable=StringIO) as out:
                main()
    assert out.getvalue() == messages.invalid_arguments()
    assert str(e.value) == '2'

# Generated at 2022-06-21 17:29:28.776191
# Unit test for function main
def test_main():
    # Compile file
    main(['tests/example_source.py',],
         'tests/output_example.py', 
         '2.7',
         'tests/')
    # Compile folder
    main(['tests/sources',],
         'tests/outputs', 
         '2.7',
         'tests')
    # Compile file using root, it should remove the root from the output path
    main(['tests/example_source.py',],
         '/home/user/tests/output_example.py', 
         '2.7',
         'tests/')
    # Compile folder, it should remove the root from the output path
    main(['tests/sources',],
         '/home/user/tests/outputs', 
         '2.7',
         'tests')
    # Comp

# Generated at 2022-06-21 17:29:35.595081
# Unit test for function main
def test_main():
    real_argv = sys.argv
    sys.argv = sys.argv[:1]
    sys.argv += ['-i', 'test.py', '--target', '3.6']
    sys.argv += ['-o', 'test.py']
    assert main() == 0
    sys.argv = real_argv
    return True

# Generated at 2022-06-21 17:29:36.365485
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:32:41.394065
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'test.py', '-o', 'output.py', '-t', '2']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:32:42.100321
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:32:50.606329
# Unit test for function main
def test_main():
    with open(os.devnull, 'w') as f:
        assert main() == 0
        assert main('test_input.py','test_output.py','3.5','test') == 1
        assert main('test_input.py','test_output.py','3.6','test') == 0
        assert main('test_input.py','test_output.py','3.7','test') == 1

# Generated at 2022-06-21 17:32:56.434558
# Unit test for function main
def test_main():
    class Args:
        pass

    args = Args()
    args.input = ['./tests/source/test1.py']
    args.output = './tests/source/test5.py'
    args.target = 'py36'
    init_settings(args)
    compile_files('./tests/source/test1.py', './tests/source/test5.py', 'py36')
    with open('./tests/source/test5.py', 'r') as fin:
        data = fin.read()
        assert "from __future__ import annotations" in data

# Generated at 2022-06-21 17:33:04.639373
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import subprocess

    def run(input_: str, output: str, target: str, root: str, debug=None) -> str:
        out = tempfile.TemporaryFile(mode='w+')
        input_files = []
        for _input in input_:
            with tempfile.NamedTemporaryFile(mode='w+') as f:
                f.write(_input)
                f.seek(0)
                input_files.append(f.name)
        arguments = ['py-backwards', '-o', output, '-i', *input_files,
                     '-t', target]
        if root:
            arguments.extend(['-r', root])
        if debug:
            arguments.append('-d')

# Generated at 2022-06-21 17:33:12.842088
# Unit test for function main
def test_main():
    import os
    import subprocess

    # Implementing more tests with pytest
    # It is much more convinient
    def cleanup() -> None:
        for file in os.listdir('./'):
            if file.startswith('test.py'):
                os.remove(file)

    def run_main(command: str) -> None:
        subprocess.check_call(['python', 'main.py'] + command.split(' '))


    command = '-t 2.7 -i test/1.py -o test.py --root /'
    run_main(command)

    with open('test.py', 'r') as f:
        a = f.read()
        assert a.startswith('import sys\n')

# Generated at 2022-06-21 17:33:19.135782
# Unit test for function main
def test_main():
    sys.argv = ['command', '-i', 'tests/dir', '-o', 'output', '-t', '2.7', '-d', '-r', 'tests']
    status = main()
    assert status == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:33:25.706443
# Unit test for function main
def test_main():
    # output file
    sys.argv[1] = '-i'
    sys.argv[2] = 'tests/examples'
    sys.argv[3] = '-o'
    sys.argv[4] = '/tmp/examples'
    sys.argv[5] = '-t'
    sys.argv[6] = 'python2.7'
    sys.argv[7] = '-r'
    sys.argv[8] = 'tests/examples'
    # check if in debug mode
    if os.environ.get("DEBUG"):
        sys.argv[9] = '-d'


# Use for build docker image
if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:33:32.815006
# Unit test for function main
def test_main():
    import os
    from shutil import rmtree
    from io import StringIO
    from unittest.mock import Mock, patch
    file_path = os.path.join(os.getcwd(), 'tests', 'test_files', 'test.py')
    output_path = os.path.join(os.getcwd(), 'tests', 'test_files', 'test_out')
    result_path = os.path.join(output_path, 'test.py')
    parser_mock = Mock()
    return_val = Mock()
    return_val.input = [file_path]
    return_val.output = output_path
    return_val.target = '2.7'
    return_val.root = None
    return_val.debug = None

# Generated at 2022-06-21 17:33:41.911357
# Unit test for function main
def test_main():
    class mock(object):
        pass

    # class for mock parsing
    class Arguments(object):

        def __init__(self, dict_):
            for k in dict_:
                setattr(self, k, dict_[k])

    sys.argv = [sys.argv[0], '--input', 'tests/data', '--output', 'output', '--target', '2']
    args = parse_args()
    args['input'] = ['tests/data']
    args['root'] = os.path.join(os.path.dirname(__file__), '../tests')
    main()


if __name__ == '__main__':
    main()