

# Generated at 2022-06-21 17:24:23.128790
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:33.031017
# Unit test for function main
def test_main():
    target_test = const.TARGETS['2.7']
    input_test = '.\\test_dirs\\dir_to_be_compiled'
    output_test = '.\\test_dirs\\compiled_dir'
    root_test = '.\\test_dirs\\dir_to_be_compiled'
    argv = ['','','', input_test, output_test, target_test, root_test]
    sys.argv = argv
    try:
        result_test = compile_files(input_test, output_test, target_test, root_test)
    except Exception:
        raise AssertionError
    main()
    return 0

# Generated at 2022-06-21 17:24:39.444037
# Unit test for function main
def test_main():
    try:
        args = sys.argv
        sys.argv = ['py-backwards', '-i', 'i.py', '-o', 'o.py', '-t', '3.5', '-r', 'r']
        assert main() == 0
    finally:
        sys.argv = args


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:42.219035
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test/example.py', '-o', 'out', '-t', '2.7',
                '-r', 'test']
    assert main() == 0

# Generated at 2022-06-21 17:24:45.819114
# Unit test for function main
def test_main():
    class sys():
        argv=['py-backwards','-i','~/folder/source.py','-o','~/folder/output.py','-t','3.5']
        stderr=None
        stdout=None

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:52.992291
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'py_backwards/__main__.py', '-o',
                'py_backwards/__main__.py.out', '-t', '2.7', '-r', 'py_backwards/', '-d']
    status = main()
    open('py_backwards/__main__.py.out').read()
    assert status == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:01.824135
# Unit test for function main
def test_main():
    with open('test_pybackwards_main_compile_file') as file:
        file_text = file.read()
    with open('./main_compile_file.py', 'w') as file:
        file.write(file_text)

    input_file = './main_compile_file.py'
    input_dir = './'
    output_dir = './'
    output_file = 'main_compile_file_copy.py'

    result_file = './main_compile_file_copy.py'
    with open(result_file, 'w') as file:
        file.write(file_text)

    def test_input_file(input_file):
        with open(input_file) as in_file:
            file_text = in_file.read()



# Generated at 2022-06-21 17:25:08.778460
# Unit test for function main
def test_main():
    import pytest
    from .io import Result
    from .settings import SETTINGS

    input_ = 'test_input/test.py'
    target = '3.6'
    output = 'test_output/test.py'
    root = 'test_input'
    debug = False
    SETTINGS.input = [input_]
    SETTINGS.output = output
    SETTINGS.target = target
    SETTINGS.root = root
    SETTINGS.debug = debug
    result = compile_files(input_, output, target, root)
    assert result == pytest.approx(Result(3, 2))

# Generated at 2022-06-21 17:25:11.741678
# Unit test for function main
def test_main():
    assert main([__file__]) == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:19.187044
# Unit test for function main
def test_main():
    import os
    import shutil
    
    if not os.path.exists("__pycache__"):
      os.mkdir("__pycache__")
    os.chdir("__pycache__")
    if os.path.exists("temp"):
      os.chdir("..")
      shutil.rmtree("__pycache__")
      os.chdir("..")
      os.mkdir("__pycache__")
      os.chdir("__pycache__")
    else:
      os.mkdir("temp")
    os.chdir("temp")
    class TestCompiler(Compiler):
      def compile(self, source_code):
        py_file = open("test.py", "w")
        py_file.write(source_code)
        py_file.close()


# Generated at 2022-06-21 17:25:37.129029
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:47.766535
# Unit test for function main
def test_main():
    import tempfile, os, shutil, random
    from random import choices

    temp_dir = tempfile.mkdtemp()

    python_version_dictionary = {'3.6': '3.6', '3.7': '3.7',
                                 '3.8': '3.8', '3.9': '3.9'}

    valid_files = ["test.py", "test.pyi", "test.pyw"]
    invalid_files = ["test", "test.txt", "test.pyx", "test.rst"]
    # Invalid output folder check
    file1 = choices(valid_files)
    file2 = "test"

    # Valid combinations
    file1_valid = choices(valid_files)
    file2_valid = choices(valid_files)


# Generated at 2022-06-21 17:25:52.962447
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], 'input', 'output', '2.7']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:55.241590
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:56.474300
# Unit test for function main
def test_main():
    """test
    """
    pass

# Generated at 2022-06-21 17:26:03.829021
# Unit test for function main
def test_main():
    init_settings(ArgumentParser().parse_args({'input': const.T1_INPUT,
                                               'output': const.T1_OUTPUT,
                                               'target': '2.7'}))
    import os
    import shutil
    main()
    assert os.path.exists(const.T1_OUTPUT)
    shutil.rmtree(const.T1_OUTPUT)

# Generated at 2022-06-21 17:26:06.428267
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:12.576026
# Unit test for function main
def test_main():
    args = ('-i', '../tests/test_files/test_files.py',
            '-o', '../tests/test_files/test_out',
            '-t', '2.7',
            '-r', '../tests/test_files/')

    assert main(args) == 0

# Generated at 2022-06-21 17:26:16.098622
# Unit test for function main
def test_main():
    args = ['--input', 'source.py', '--output', 'output.py',
            '--target', '3.4']
    sys.argv = sys.argv[:1] + args
    sys.modules.pop('py_backwards', None)

test_main()

# Generated at 2022-06-21 17:26:18.452466
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-21 17:27:05.488389
# Unit test for function main
def test_main():
    class Args:
        def __init__(self, input, output, target, root, debug):
            self.input = input
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')

# Generated at 2022-06-21 17:27:06.001749
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:18.215332
# Unit test for function main
def test_main():
    sys.argv[1:] = [
        "-i", "examples/absent-module.py",
        "-o", "output",
        "-t", "python3.4",
        "-r", "examples"
    ]
    assert main() == 1

    sys.argv[1:] = [
        "-i", "examples/backwards",
        "-o", "output",
        "-t", "python3.4",
        "-r", "examples"
    ]
    assert main() == 0

    sys.argv[1:] = [
        "-i", "examples/backwards",
        "-o", "output",
        "-t", "python3.4",
        "-r", "examples",
        "-d"
    ]
    assert main() == 0


# Generated at 2022-06-21 17:27:27.066962
# Unit test for function main
def test_main():
    for input_ in [['input'], ['/input']]:
        for output in [['output'], ['/output']]:
            for target in const.TARGETS.keys():
                for root in [[None], ['root'], ['/root']]:
                    for debug in [True, False]:
                        with patch('argparse.ArgumentParser.parse_args') as mock:
                            mock.return_value = argparse.Namespace(input=input_, output=output, target=target, root=root, debug=debug)
                            main()
                            assert mock.called
                            assert mock.call_count == 1

# Generated at 2022-06-21 17:27:34.401853
# Unit test for function main
def test_main():
    from sys import argv
    argv = [argv[0], '-d', '-i', 'test.py', '-o','test_out/',
            '-t', '3.4', '-r', '.']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:27:41.325810
# Unit test for function main
def test_main():
    import unittest.mock as mock
    import io
    import os
    sys.argv = ["py-backwards", "-i", "dir1", "-o", "dir2", "-t", "3.5",
                "-r", "dir1"]
    orig_stdout = sys.stdout
    sys.stdout = io.StringIO()
    main()
    result = sys.stdout.getvalue()[:-1]
    sys.stdout = orig_stdout
    assert os.path.isfile('dir2/file.py')
    assert os.path.isfile('dir2/subdir/file.py')
    assert "exceptions.py" not in result
    assert result.endswith('4 file(s) compiled successfully')

# Generated at 2022-06-21 17:27:45.567806
# Unit test for function main
def test_main():
    sys.argv = ['./py-backwards.py', '-i', 'tests/fixtures/test.py',
                '-o', 'tests/results/test.py', '-t', '27']

    main()
    file = open('tests/results/test.py', 'r')
    assert file.read() == open('tests/fixtures/test_27.py', 'r').read()

# Generated at 2022-06-21 17:27:46.307010
# Unit test for function main
def test_main():
   assert main() == 0


# Generated at 2022-06-21 17:27:48.423787
# Unit test for function main
def test_main():
    print("Test main()")
    assert main() == 0

test_main()

# Generated at 2022-06-21 17:27:53.866381
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', 'tests/test_files/', '-o', 'tests/test_files/',
                    '-t', '2.7', '-r', 'tests/test_files/']
    assert main() == 0

# Generated at 2022-06-21 17:29:18.011872
# Unit test for function main
def test_main():
    #test1
    assert main(['-i', 'test.py', '-o', '1test.py', '-t', 'python37', '-r', 'py36']) == 1

    #test2
    assert main(['-i', 'test.py', '-o', '1test.py', '-t', 'python37', '-r', 'python36']) == 0

    #test3
    assert main(['-i', 'test.py', '-o', '1test.py', '-t', 'python37', '-r', 'pyt36']) == 1

    #test4
    assert main(['-i', 'test.py', '-o', '1test.py', '-t', 'p36', '-r', 'py36']) == 1

    #test5

# Generated at 2022-06-21 17:29:19.440244
# Unit test for function main
def test_main():
    assert main() == 0

test_main()

# Generated at 2022-06-21 17:29:21.912269
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:29:23.906598
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:29:27.049131
# Unit test for function main
def test_main():
    sys.argv = [
        'program',
        '-i', 'path_to_file',
        '-o', 'path_to_output',
        '-r', 'root',
        '-t', '3.6',
        '-d']
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:29:37.999706
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test.py', '-o', 'output.py', '-t', '2.7', '-r', '.', '--debug']
    assert main() == 0

    sys.argv = [sys.argv[0], '-i', 'test.py', '-o', '', '-t', '2.7', '-r', '.', '--debug']
    assert main() == 1

    sys.argv = [sys.argv[0], '-i', '', '-o', 'output.py', '-t', '2.7', '-r', '.', '--debug']
    assert main() == 1


# Generated at 2022-06-21 17:29:39.836248
# Unit test for function main
def test_main():
    try:
        assert main() == 0
    except SystemExit:
        assert main() == 1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:29:48.667889
# Unit test for function main
def test_main():
    args = ArgumentParser()
    args.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    args.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    args.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    args.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    args.add_argument('-d', '--debug', action='store_true',
                        help='enable debug output')
    # Assert input files
    assert(args.input == 'input_files')


# Generated at 2022-06-21 17:29:50.341016
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:29:51.355498
# Unit test for function main
def test_main():
    print(0)

# Generated at 2022-06-21 17:31:17.053811
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as exc_info:
        main(['prog', '-h'])
    assert exc_info.value.code == 0
    with pytest.raises(SystemExit) as exc_info:
        main(['prog', '-i', 'in', '-o', 'out', '-t', '360'])
    assert exc_info.value.code == 1

# Generated at 2022-06-21 17:31:18.346420
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:31:31.131432
# Unit test for function main
def test_main():
    import io
    sys.argv = ['py-backwards', '-i', 'test_folder/test_file.py', '-o', 'out1.py', '-t', '3.4']
    out = io.StringIO()
    sys.stdout = out
    assert main() == 0
    sys.stdout = sys.__stdout__
    sys.argv = ['py-backwards', '-i', 'test_folder/test_file2.py', '-o', 'out1.py', '-t', '3.4']
    out = io.StringIO()
    sys.stdout = out
    assert main() == 1
    sys.stdout = sys.__stdout__

# Generated at 2022-06-21 17:31:32.503987
# Unit test for function main
def test_main():
    a = main()
    assert a == 0

# Generated at 2022-06-21 17:31:41.262273
# Unit test for function main
def test_main():
    sys.argv.append('-i')
    sys.argv.append('test.py')
    sys.argv.append('-o')
    sys.argv.append('output.py')
    sys.argv.append('-t')
    sys.argv.append('python35')
    sys.argv.append('-r')
    sys.argv.append('/Users/mrfedex6/Desktop/')
    sys.argv.append('-d')
    sys.argv.append('True')
    main()

# Generated at 2022-06-21 17:31:42.461720
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:31:53.352978
# Unit test for function main
def test_main():
    try:
        # run py-backwards 1st time
        main()
    except SystemExit:
        # test that help is being displayed
        assert True
    except:
        # fail if something else happens
        assert False

    # create parser for py-backwards
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    # add arguments
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')

# Generated at 2022-06-21 17:31:55.378948
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:31:56.669915
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
     main()

# Generated at 2022-06-21 17:31:59.646872
# Unit test for function main
def test_main():
    init_settings("/home/kamila/Desktop/pp/venv/bin/python3.5 /home/kamila/Desktop/pp/venv/bin/py-backwards /home/kamila/Desktop/pp/src/ /home/kamila/Desktop/pp/src/out/ 2.7 --debug")
    main()
    assert 1