

# Generated at 2022-06-21 17:24:19.211726
# Unit test for function main
def test_main():
    old_sys_argv = sys.argv
    sys.argv = ['', '-i', 'tests/input/main_input.py', '-o', 'tests/output', '-t', '3.6', '-r', 'tests/input']
    assert main() == 0
    sys.argv = old_sys_argv

# Generated at 2022-06-21 17:24:20.692269
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:21.802293
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:23.703618
# Unit test for function main
def test_main():
    sys.argv[1:] = '-i data/input/test.py -o data/output/test.py -t 2.7 -d'.split(' ')
    main()

# Generated at 2022-06-21 17:24:30.543198
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards','-i', 'test/test_compile/test.py', '-o', 'test/test_compile/test_out.py', '-t', '3.5','--root','.']
    exit_code = main()
    assert(exit_code == 0)
    
    
if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:34.857599
# Unit test for function main
def test_main():
    sys.argv = ['script_name','-i','input.py', '-o', 'output.py', '-t', '3.5', '-r', 'root']
    if main() == 0:
        print('Test success')
    else:
        print('Test FAILED')
        
if __name__ == "__main__":
    main()
    #test_main()

# Generated at 2022-06-21 17:24:39.591453
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/input.py', '-o', 'tests/output', '-t', 'py36']
    assert main() == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:47.389761
# Unit test for function main
def test_main():
    # Create mocks
    class MockStdout(object):
        """Mock sys.stdout"""
        def __init__(self):
            self.data = []

        def write(self, value):
            self.data.append(value)

        def __str__(self):
            return "".join(self.data)

    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument

# Generated at 2022-06-21 17:24:48.361489
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:24:50.282741
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:25:05.030450
# Unit test for function main
def test_main():
    try:
        import pytest
    except ImportError:
        print('Cannot import `pytest` package')
        return
    import os
    import shutil
    curdir = os.path.dirname(os.path.abspath(__file__))
    try:
        shutil.copy(curdir + '/test/test.py', curdir + '/test/test_out.py')
        assert main() == 0
    finally:
        os.remove(curdir + '/test/test_out.py')


if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-21 17:25:08.598645
# Unit test for function main
def test_main():
    sys.argv = ["pybackwards", "-i", "tests/test1.py", "-o", "tests/test1-out.py", "-t", "2.7"]
    sys.exit(main())

# Generated at 2022-06-21 17:25:17.903951
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards', description='Python to python compiler that allows you to use some '
                                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-21 17:25:29.559446
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0]] + ['-i', 'test_data', '-o', 'output',
           '-t', '2.7', '-r', 'test_data']
    assert main() == 0
    sys.argv = [sys.argv[0]] + ['-i', 'test_data2', '-o', 'output',
           '-t', '2.7', '-r', 'test_data2']
    assert main() == 1
    sys.argv = [sys.argv[0]] + ['-i', 'test_data4.txt', '-o', 'output',
           '-t', '2.7', '-r', 'test_data4']
    assert main() == 1

# Generated at 2022-06-21 17:25:34.684320
# Unit test for function main
def test_main():
    sys.argv = ["-i", "C:/Users/Acer/Desktop/py-backwards/tests/test.py",
                "-o", "C:/Users/Acer/Desktop/py-backwards/tests/build",
                "-t", "python",
                "-r", "C:/Users/Acer/Desktop/py-backwards/tests/build"]
    init_settings(sys.argv)
    assert main() == 0

# Generated at 2022-06-21 17:25:35.206231
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:47.075815
# Unit test for function main
def test_main():
    # Test for basic compilation
    with tempfile.NamedTemporaryFile() as temp_output_file:
        with open(temp_output_file.name, 'w') as f:
            f.write('source = \'Hello\'\n')
        assert 0 == main(['-i', temp_output_file.name, '-o', temp_output_file.name, '-t', '2.7'])

        # Test for compilation failure
        with open(temp_output_file.name, 'w') as f:
            f.write('source = f\'Hello\'\n')
        assert 1 == main(['-i', temp_output_file.name, '-o', temp_output_file.name, '-t', '2.7'])

        # Test for file not found

# Generated at 2022-06-21 17:25:52.343499
# Unit test for function main
def test_main():
    with open('main.log', 'w') as f:
        sys.stdout = f
        ret = main()
        sys.stdout = sys.__stdout__
        assert ret == 0, 'main exited with incorrect return code'

# Generated at 2022-06-21 17:25:54.509582
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:26:01.538191
# Unit test for function main
def test_main():
    sys.argv = ["make", "-i", "file_to_process", "-o", "new_file", "-t", "2.7"]
    assert main() == 0
    sys.argv = ["make", "-i", "file_to_process", "-o", "new_file", "-t", "3.6"]
    assert main() == 0
    sys.argv = ["make", "-i", "file_to_process", "-o", "new_file", "-t", "3.7"]
    assert main() == 0
    sys.argv = ["make", "-i", "file_to_process", "-o", "new_file", "-t", "3.8"]
    assert main() == 0

# Generated at 2022-06-21 17:26:22.631167
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', '/home/test/test.py', '-o', '/home/test/test_py2.py', '-t', '2.7']
    #result = main()
    assert result == 0

# Generated at 2022-06-21 17:26:26.291027
# Unit test for function main
def test_main():
    input_folder = Path(__file__).absolute().parent / 'test_files' / 'test_input'
    output_folder = Path(__file__).absolute().parent / 'test_files' / 'test_output'
    assert main([
        str(input_folder),
        '-o', str(output_folder),
        '-t', 'py26',
        '-r', str(input_folder)
    ]) == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:27.408513
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:33.967932
# Unit test for function main
def test_main():
    args = ['-i', 'test_compiler.py', '-o', 'test_compiler_compiled.py', '-t', 'python36', '-r', '.']
    assert main(args) == 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:39.871932
# Unit test for function main
def test_main():
    input = 'py-backwards/tests/resources/main.py'
    output = 'py-backwards/tests/resources/main_out.py'
    main(['-i', input, '-o', output, '-t', '3'])
    with open(input) as infile:
        with open(output) as outfile:
            if infile.read() != outfile.read():
                raise AssertionError("Not same content")
    os.remove(output)

# Generated at 2022-06-21 17:26:40.633646
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:41.469169
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:26:49.166729
# Unit test for function main
def test_main():
    import types
    import unittest
    import sys
    import os
    import shutil
    import tempfile

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.temp_dir = os.path.join(tempfile.gettempdir(), 'py_backwards_unittest')
            self.source_dir = os.path.join(self.temp_dir, 'source')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            self.python3_dir = os.path.join(self.output_dir, 'python3')
            self.python28_dir = os.path.join(self.output_dir, 'python28')
            os.makedirs(self.python28_dir)

# Generated at 2022-06-21 17:26:56.249039
# Unit test for function main
def test_main():
    assert 1 == main('-i', 'tests/examples/input_examples/long_expression',
                        '-o', 'output/tmp',
                        '-t', '3.5',
                        '-r', 'tests/examples')
    assert 0 == main('-i', 'tests/examples/input_examples/long_expression',
                        '-o', 'output/tmp',
                        '-t', '3.5',
                        '-r', 'tests/examples',
                        '-d')
    assert 0 == main('-i', 'tests/examples/input_examples/long_expression',
                        '-o', 'output/tmp',
                        '-t', '3.6',
                        '-r', 'tests/examples',
                        '-d')


# Generated at 2022-06-21 17:26:57.061280
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:27:39.267694
# Unit test for function main
def test_main():
    init_settings('')

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:27:40.071088
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:27:50.464542
# Unit test for function main
def test_main():
    # Empty input
    sys.argv = ['py-backwards']
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 2
    # Existing input, not existing input
    sys.argv = [
        'py-backwards',
        '-i', 'test/test_files/not_existing_file.py',
        '-o', 'test/test_files/output/output.py',
        '-t', '3.5',
    ]
    with pytest.raises(SystemExit) as e:
        main()
    assert e.value.code == 1
    # Existing input and output (conflict)

# Generated at 2022-06-21 17:28:00.741672
# Unit test for function main
def test_main():
    assert 0 == main(['py-backwards', '-i', './tests/resources/sample_3.6.py', '-o', './tests/resources/sample_out.py', '-t', '3.7.0'])
    assert 1 == main(['py-backwards', '-i', 'py-backwards', '-o', './tests/resources/sample_out.py', '-t', '3.7.0'])
    assert 1 == main(['py-backwards', '-i', './tests/resources/exceptions.py', '-o', './tests/resources/sample_out.py', '-t', '3.7.0'])

# Generated at 2022-06-21 17:28:11.137602
# Unit test for function main
def test_main():
    # test for nonexistent sources
    nonexistent_file = 'nonexistent'
    nonexistent_args = ['-i', nonexistent_file,
                         '-t', 'Python35',
                         '-o', '/tmp/test_output/test']
    assert main(nonexistent_args) == 1

    # test with correct arguments
    correct_args = ['-i', 'tests/sources/test.py',
                     '-t', 'Python35',
                     '-o', '/tmp/test_output/test']
    assert main(correct_args) == 0

    # test with incorrect target version
    incorrect_version_args = ['-i', 'tests/sources/test.py',
                              '-t', 'Python20',
                              '-o', '/tmp/test_output/test']

# Generated at 2022-06-21 17:28:13.765768
# Unit test for function main
def test_main():
    assert main() == 0

# if __name__ == '__main__':
#     sys.exit(main())

# Generated at 2022-06-21 17:28:16.842176
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 2


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:28:23.291629
# Unit test for function main
def test_main():
    args = list(map(str,
                    ['-i', 'tests/',
                     '-o', 'tests/_build/',
                     '-t', '3.2',
                     '-d']))
    assert main() == 0
    del args[5]
    assert main(args) == 1

# Generated at 2022-06-21 17:28:31.738834
# Unit test for function main

# Generated at 2022-06-21 17:28:33.881581
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:05.313933
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:08.108507
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print('test_main failed: \n {}'.format(e))

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:19.647592
# Unit test for function main
def test_main():
    #test inpout doesnt exist
    sys.argv[1:] = ['-i', 'fail', 'invalid_path', '-o', 'fail', '-t', '3.5']
    with pytest.raises(exceptions.InputDoesntExists):
        main()

    #test input file and output folder
    sys.argv[1:] = ['-i', 'resources/input/invalid_path.py', '-o', 'resources/output', '-t', '3.5']
    with pytest.raises(exceptions.InvalidInputOutput):
        main()

    #test input folder and output file
    sys.argv[1:] = ['-i', 'resources/input', '-o', 'resources/output/invalid_path.py', '-t', '3.5']

# Generated at 2022-06-21 17:30:21.978179
# Unit test for function main
def test_main():
    result = main([ '--help' ])
    assert result == 0

# Generated at 2022-06-21 17:30:27.976684
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    arg = ['test/test_input', '-o', 'test/test_output', '-t', 'py34', '-d']
    sys.argv.extend(arg)
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:30.261508
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-21 17:30:39.570069
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_project', '-o', 'test_compiled', '-t', '2.7', '-r', '.']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_project', '-o', 'test_compiled', '-t', '2.7', '-r', '.']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_project', '-o', 'test_compiled', '-t', '2.7', '-r', '.']
    assert main() == 0

# Generated at 2022-06-21 17:30:40.396510
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:47.616809
# Unit test for function main
def test_main():
    from unittest import mock

    def run(args, **kwargs):
        with mock.patch('sys.argv', args):
            return main(**kwargs)

    assert run(['-i', 'input', '-o', 'output', '-t', '2.7']) == 0
    assert run(['-i', 'input', '-o', 'output', '-t', '2.7', '-r', 'root']) == 0
    assert run(['-i', 'input', '-o', 'output', '-t', '2.7', '-d']) == 0

    assert run(['-i', 'input']) == 2
    assert run(['-i', 'input', '-o', 'output']) == 2

# Generated at 2022-06-21 17:30:53.030708
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', __file__, '-t', '3.4', '-o', 'test.py', '-r', __file__]
    assert main() == 0