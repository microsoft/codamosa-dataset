

# Generated at 2022-06-21 17:24:22.670040
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:27.559429
# Unit test for function main
def test_main():
    """
    Test for case when there is no argument
    """
    with pytest.raises(SystemExit):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:36.428288
# Unit test for function main
def test_main():
    """Проверка функции main

    Проверка функции main с тремя вариантами входных данных.

    """

# Generated at 2022-06-21 17:24:45.409827
# Unit test for function main

# Generated at 2022-06-21 17:24:56.000590
# Unit test for function main
def test_main():
    """Unit test for main"""
    args = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    args.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    args.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    args.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    args.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')
    args.add_

# Generated at 2022-06-21 17:25:04.907958
# Unit test for function main
def test_main():
    try:
        import os
        root = os.path.dirname(__file__)
        old_stdout = sys.stdout
        old_argv = sys.argv
        sys.argv = ['py-backwards', '-i', os.path.join(root, 'sources'),
                    '-o', os.path.join(root, 'results'),
                    '-t', 'py27', '-r', os.path.join(root, 'sources')]
        sys.stdout = open(os.devnull, 'w')
        result = main()
        sys.stdout = old_stdout
        sys.argv = old_argv
        assert result == 0
    except exceptions.CompilationError:
        sys.stdout = old_stdout
        sys.argv = old_argv

# Generated at 2022-06-21 17:25:11.329751
# Unit test for function main
def test_main():
    dummy_stdout = io.StringIO()
    with redirect_stdout(dummy_stdout):
        main()
        output = dummy_stdout.getvalue()
    assert(output == """usage: py-backwards [-h] -i INPUT [INPUT ...] -o OUTPUT -t TARGET [-r ROOT] [-d]

Python to python compiler that allows you to use some
Python 3.6 features in older versions.

optional arguments:
  -h, --help            show this help message and exit
  -i INPUT [INPUT ...]  input file or folder
  -o OUTPUT             output file or folder
  -t TARGET             target python version
  -r ROOT               sources root
  -d                    enable debug output\n""")

# Generated at 2022-06-21 17:25:18.850110
# Unit test for function main
def test_main():
    import os
    import shutil
    import pytest

    cur_dir = os.path.abspath(os.path.dirname(__file__))
    test_dir = os.path.join(cur_dir, 'tests')
    tests_root_dir = os.path.join(test_dir, 'cases')

    def prepare(source, target):
        source_path = os.path.join(tests_root_dir, source, 'in')
        target_path = os.path.join(tests_root_dir, source, 'out')
        shutil.rmtree(target_path, ignore_errors=True)
        shutil.copytree(source_path, target_path)
        print('-' * 80)
        print('Compiling "{}"'.format(source))
        print('-' * 80)
       

# Generated at 2022-06-21 17:25:30.117355
# Unit test for function main
def test_main():
    init_settings("py-backwards.py -i ../src/file.py -o ../output/file.py -t 3.5")
    init_settings("py-backwards.py -i ../src -o ../output -t 3.5")
    init_settings("py-backwards.py -i ../src -o ../output -t 3.5 -r ../src")
    init_settings("py-backwards.py -i ../src -o ../output -t 3.5 -d")
    init_settings("py-backwards.py -i ../src -o ../output -t 2.7")
    init_settings("py-backwards.py -i ../src -o ../output -t 2.6")

# Generated at 2022-06-21 17:25:38.604368
# Unit test for function main
def test_main():
    # Input does not exists
    sys.argv = [
        sys.argv[0],
        '-i', './non_existing_folder',
        '-o', 'file.out',
        '-t', '27'
    ]
    assert main()

    # Output is not a directory, but input is a directory
    sys.argv = [
        sys.argv[0],
        '-i', './tests/data/folder/',
        '-o', 'file.out',
        '-t', '27'
    ]
    assert main()

    # Input is a file, output is a file

# Generated at 2022-06-21 17:26:05.727970
# Unit test for function main
def test_main():
    # Testing normal compilation with one input and one file output
    sys.argv = [
        'py-backwards',
        '-i', 'test_applications/__init__.py',
        '-t', 'python-2.7',
        '-o', 'test_applications/__init___output.py',
        '-r', 'test_applications'
    ]
    assert main() == 0
    with open('test_applications/__init___output.py', 'r') as f:
        content = f.read()
    assert content == '\n'

    # Testing normal compilation with one input and multiple file output

# Generated at 2022-06-21 17:26:06.248181
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:26:08.787520
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:11.369393
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:13.736104
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:26:14.713090
# Unit test for function main
def test_main():
    # TODO: implement a test for main
    pass

# Generated at 2022-06-21 17:26:18.811461
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test.py', '-o', 'output', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-21 17:26:19.595593
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:20.169017
# Unit test for function main
def test_main():
    assert main() in [0, 1]

# Generated at 2022-06-21 17:26:20.843262
# Unit test for function main
def test_main():
    print("Testing function main")
    assert main() == 0

# Generated at 2022-06-21 17:26:40.762662
# Unit test for function main
def test_main():
    assert main() != 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:26:42.678041
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:48.897755
# Unit test for function main
def test_main():
    def run_test(input, target, output, root, debug, expected):
        with patch('sys.argv', ['py-backwards', '-i', input, '-t', target,
                                '-o', output, '-r', root, '-d']):
            assert main() == expected

    run_test('i.py', '3.5', 'o.py', '.', True, 0)

if __name__ == "__main__":
    if sys.argv[0].endswith('__main__.py') or 'pytest' in sys.argv[0]:
        raise SystemExit('Please use main')
    main()

# Generated at 2022-06-21 17:26:49.949975
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:26:54.921842
# Unit test for function main
def test_main():
    argv = sys.argv
    if const.PY_VERSION_INFO >= (3, 5):
        sys.argv = f'{argv[0]} -i "test/test_main.py" -o "test/test_main.py" -t "2.7"'.split(' ')
    else:
        sys.argv = f'-i test/test_main.py -o test/test_main.py -t 2.7'.split(' ')
    main()


# Generated at 2022-06-21 17:27:07.061935
# Unit test for function main
def test_main():
    from io import StringIO
    import sys
    import os
    import tempfile

    test_1 = (
        'py-backwards -i test/py3.6/example -o testOutput -t 3.5 -d -r test',
        'SyntaxError\n'
    )
    test_2 = (
        'py-backwards -i test/py3.6/example -o testOutput -t 2.7 -d -r test',
        'SyntaxError\n'
    )

# Generated at 2022-06-21 17:27:18.634356
# Unit test for function main
def test_main():
    from contextlib import redirect_stdout
    from io import StringIO
    from .fake_argv import fake_argv
    from .fake_time import fake_time

    def check_compile_files(input_files, output, target, root,
                            result_count, raised, result_message):
        assert not raised

        with StringIO() as buf, redirect_stdout(buf):
            with fake_argv('python', '-i', *input_files, '-o', output,
                           '-t', target, '-r', root):
                main()
                output = buf.getvalue()

        assert output.count(' ') == result_count
        assert result_message in output


# Generated at 2022-06-21 17:27:22.908510
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards.py', '-i', 'py_backwards/tests/input/main', '-o', 'py_backwards/tests/input/main', '-t', '2.7', '-d']
    init_settings(sys.argv)
    main()

# Generated at 2022-06-21 17:27:23.684994
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:27:27.021422
# Unit test for function main
def test_main():
    assert main() == 0
    assert main() == 1
    assert main() == 1
    assert main() == 1
    assert main() == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:28:05.608330
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:28:06.554220
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-21 17:28:07.408617
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:28:08.776272
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:28:20.364592
# Unit test for function main
def test_main():
    # Test empty arguments
    sys.argv = ['py-backwards']
    try:
        main()
        assert False
    except SystemExit:
        pass
    
    # Test invalid input
    sys.argv = ['py-backwards', '-i', 'py-backards.py', '-o', 
                'py-backwards.py', '-t', '3.6']
    try:
        main()
        assert False
    except SystemExit:
        pass
    
    # Test invalid input file
    sys.argv = ['py-backwards', '-i', 'tests/test_files/invalid_file.py', '-o', 
                'py-backwards.py', '-t', '3.6']

# Generated at 2022-06-21 17:28:29.813855
# Unit test for function main
def test_main():
    # Слишком долго выполняется, поэтому тест отключен.
    pass
    # assert main() == 0, "Success to execution"
    # assert main(['-i', 'test']) == 1, "Input doesn't exists"
    # assert main(['-i', 'test', '-o', 'test']) == 1, "Input doesn't exists"
    # assert main(['-i', 'test', '-o', 'test', '-t', 'python2.7']) == 1, "Input doesn't exists"

# Generated at 2022-06-21 17:28:34.559083
# Unit test for function main
def test_main():
    """
    test for main function
    :return:
    """
    try:
        sys.argv = ['py-backwards', '-i', 'tests/fixtures/example.py', '-o', 'tests/fixtures/example-3.4.py', '-t',
                    '3.4']
        main()
    except Exception as e:
        print(e)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:28:36.527066
# Unit test for function main
def test_main():

    assert main()==0

if __name__ == '__main__':
    print(main())

# Generated at 2022-06-21 17:28:37.535014
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:28:47.191297
# Unit test for function main
def test_main():
    import pytest
    from .compiler import compile_files

    input = "test.py"
    output = "test_out.py"
    target = "PY27"

    def mock_compile_files(input, output, target):
        return input, output, target

    compile_files_original = compile_files
    compile_files = mock_compile_files

    input_, output_, target_ = main()

    compile_files = compile_files_original

    assert input_ == input
    assert output_ == output
    assert target_ == target

# Generated at 2022-06-21 17:30:17.212884
# Unit test for function main
def test_main():
    input_file = "test/main_test.py"
    output_file = "test/main_out_test.py"
    assert main(["-i", input_file, "-t", "2.7",  "-o", output_file]) == 0

# Generated at 2022-06-21 17:30:18.845512
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:19.830981
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:23.913230
# Unit test for function main
def test_main():
    print("test_main")
    print(main()) #should return 0, since it is a success

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:32.221069
# Unit test for function main
def test_main():
    sys.argv = [
        '', '-i', 'tests/data/3.6_case', '-o', 'out', '-t', '3.6', '-d'
    ]

    assert (main() == 0)

    sys.argv = [
        '', '-i', '../tests/data/3.6_case', '-o', 'out', '-t', '3.6', '-d',
        '-r', '../'
    ]

    assert (main() == 0)

    sys.argv = [
        '', '-i', 'tests/data/3.6_case', '-o', 'out', '-t', '3.6', '-d', '-r',
        '../'
    ]

    assert (main() == 0)


# Generated at 2022-06-21 17:30:37.034367
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1] + ['-i', 'test/test_module.py', '-o',
                               'test/test_module_3.6.py', '-t', '3.6']
    main()

# Generated at 2022-06-21 17:30:40.630783
# Unit test for function main
def test_main():
    print('Testing main function...')
    test_args = ['-i', 'test.py', '-o', 'output.py', '-t', '2.7', '-r', 'sources', '-d', 'True']
    sys.argv[1:] = test_args
    assert main() == 0

# Generated at 2022-06-21 17:30:47.741959
# Unit test for function main
def test_main():
    # Unit test for file
    # Check that file name printed in a correct way
    from . import messages
    from . import exceptions


    def print_wrapper(string, file, *args, **kwargs):
        if string is not None:
            if messages.permission_error(string) in string:
                return
            elif messages.input_doesnt_exists(string) in string:
                return
            elif messages.transformation_error(exceptions.TransformationError(None, None, None), string) in string:
                return
            elif messages.invalid_output(string, string) in string:
                return
            elif messages.syntax_error(exceptions.CompilationError(None, None, None, None)) in string:
                return

# Generated at 2022-06-21 17:30:48.966530
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:30:50.465910
# Unit test for function main
def test_main():
    args = main()
    assert args == 1

# Generated at 2022-06-21 17:34:07.612069
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:34:09.999700
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards','-i','../py_backwards/__init__.py','-o','../py_backwards/__init__.py','-t','python3.5']
    main()

# Generated at 2022-06-21 17:34:14.335738
# Unit test for function main
def test_main():
    args = ['test.py']
    print(sys.argv)
    sys.argv = args
    with pytest.raises(SystemExit):
        main()