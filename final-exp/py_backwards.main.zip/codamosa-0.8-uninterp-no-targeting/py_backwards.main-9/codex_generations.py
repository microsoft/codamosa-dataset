

# Generated at 2022-06-21 17:24:08.991958
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:16.176103
# Unit test for function main
def test_main():
    print("Testing main function")
    print("Note: the following lines are the outputs of main function directly, the program will be compiled with py-backwards")
    assert main() == 0
    print("PYTHON 3.6 FEATURES USED:")
    print("UCN, binary literals, type hints, f-strings, and variable annotations")
    print("Note: the output files are in ./output and ./output2 directories")
    print("Note: the folder is empty right now but the files will be compiled as soon as you start the program")
    print("TEST PASSED")

if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-21 17:24:17.881837
# Unit test for function main
def test_main():
    assert main() == 0
#pytest -q --tb=line test_compiler.py

# Generated at 2022-06-21 17:24:25.055548
# Unit test for function main
def test_main():
    import pytest
    import unittest
    import os
    import shutil
    import sys
    import io

    # Create tests paths and import folders
    TEST_DIR = 'test_files'
    SOURCE_DIR = 'source'
    TARGET_DIR = 'target'
    OUTPUT_DIR = 'output'

    # Create test folders
    os.mkdir(TEST_DIR)
    os.mkdir(os.path.join(TEST_DIR, SOURCE_DIR))
    os.mkdir(os.path.join(TEST_DIR, TARGET_DIR))
    os.mkdir(os.path.join(TEST_DIR, OUTPUT_DIR))

    # Generate test files and save them.

# Generated at 2022-06-21 17:24:34.887730
# Unit test for function main
def test_main():
    input_ = '/home/input'
    output = '/home/output'
    target = '3.5'
    root = '/home/input'
    root2 = '/'
    root3 = './'
    root4 = 'abc'
    parser = ArgumentParser()
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')

# Generated at 2022-06-21 17:24:41.003227
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/dummy_files/3.6/', '-o', 'output_files/',
                '-t', '3.5', '-r', 'tests/dummy_files/']
    sys.argv.append('-d')
    assert main() == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:42.292351
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:24:42.817917
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:43.503020
# Unit test for function main
def test_main():
    assert(main() == 0)

# Generated at 2022-06-21 17:24:49.630024
# Unit test for function main
def test_main():
    # testing parser 
    import sys
    from io import StringIO
    from contextlib import redirect_stdout
    from .conf import init_settings
    from .compiler import compile_files
    from . import const, messages, exceptions
    from .conf import transformator_classes

    const.TARGETS = {
        '3.5': {'transformators': []},
        '3.4': {'transformators': []},
        '3.3': {'transformators': []},
        '3.2': {'transformators': []},
    }

    init_settings(False)
    transformed_code = []

    def compile_files_mock(input_, output, target, root=None):
        if input_ == 'in.py':
            return ([], 'in.py')

    compile_files = compile_files

# Generated at 2022-06-21 17:24:58.807925
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:59.957940
# Unit test for function main
def test_main():
    messages.debug_log = lambda msg: msg
    assert main() == 0

# Generated at 2022-06-21 17:25:01.087082
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:06.859022
# Unit test for function main
def test_main():
    assert main(['py_backwards', 'py_backwards.py', '-i', '.', '-o', 'out',
                 '-t', '2.7', '-r', '.']) == 0
    assert main(['py_backwards', 'py_backwards.py', '-i', 'not_exists.py',
                 '-o', 'out', '-t', '2.7', '-r', '.']) == 1
    assert main(['py_backwards', 'py_backwards.py', '-i', '.', '-o',
                 'py_backwards', '-t', '2.7', '-r', '.']) == 1

# Generated at 2022-06-21 17:25:16.463042
# Unit test for function main
def test_main():
    class ArgsMock:
        input = 'in.py'
        output = 'out.py'
        target = '2.7'
        root = None
        debug = False

    def mock_init_settings(args):
        return

    def mock_compile_files(args):
        return

    with patch.object(ArgumentParser, 'parse_args', return_value=ArgsMock()), \
         patch.object(sys, 'stderr', new_callable=StringIO) as mock_stderr:
        try:
            main()
        except SystemExit as exit:
            assert exit.code == 0
        else:
            assert False, "Didn't raise SystemExit"

    sys.stderr = sys.__stderr__

# Generated at 2022-06-21 17:25:17.306498
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:25:29.028953
# Unit test for function main
def test_main():
    fd1, path1 = tempfile.mkstemp(text=True)
    fd2, path2 = tempfile.mkstemp(text=True)
    with open(path1, 'w+') as file:
        file.write('import os')
        file.seek(0)
        sys.argv = ['py-backwards', '-i', path1, '-o', path2, '-t', 'python35']
        assert main() == 0
        file.write('import os\ndef f(a=file):')
        file.seek(0)
        sys.argv = ['py-backwards', '-i', path1, '-o', path2, '-t', 'python35']
        assert main() == 1


# Generated at 2022-06-21 17:25:37.656943
# Unit test for function main
def test_main():
    root_path = os.path.dirname(os.path.abspath(__file__))
    test_path = os.path.join(root_path, 'test')
    os.makedirs(test_path, exist_ok=True)

# Generated at 2022-06-21 17:25:47.931575
# Unit test for function main
def test_main():
    from . import __main__
    from . import conf
    from . import messages
    from . import exceptions
    from .compiler import compile_files
    from .conf import init_settings
    from . import const

    # In "args" I save the arguments that would be given by the user
    args = __main__.ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    args.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    args.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')

# Generated at 2022-06-21 17:25:59.487987
# Unit test for function main
def test_main():
    test_parser = ArgumentParser(
            'py-backwards',
            description='Python to python compiler that allows you to use some '
                        'Python 3.6 features in older versions.')
    test_parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                             help='input file or folder')
    test_parser.add_argument('-o', '--output', type=str, required=True,
                             help='output file or folder')
    test_parser.add_argument('-t', '--target', type=str,
                             required=True, choices=const.TARGETS.keys(),
                             help='target python version')

# Generated at 2022-06-21 17:26:19.028036
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:26:24.212108
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', '..\\tests\\code\\example.py', '-o', '..\\out\\example.py', '-t', '2', '-r', '..']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:26:26.669398
# Unit test for function main
def test_main():
    sys.argv = ['-i', './tests/compiler/sources', '-o', '../test_output',
               '-r', './tests/compiler/sources', '-t', '2']
    main()

# Generated at 2022-06-21 17:26:28.890393
# Unit test for function main
def test_main():
    assert main(['-i', 'test']) == 1
    assert main(['-o', 'test']) == 1
    assert main(['-i', 'test', '-o', 'test']) == 1
    assert main(['-t', 'test']) == 1

# Generated at 2022-06-21 17:26:30.401861
# Unit test for function main
def test_main():
    # Just check all exceptions are catched
    main()

# Generated at 2022-06-21 17:26:32.462947
# Unit test for function main
def test_main():
    assert __name__ == '__main__'
    main()

# Generated at 2022-06-21 17:26:37.370899
# Unit test for function main
def test_main():
    class ArgumentParser:
        def __init__(self, prog, description):
            pass
        def add_argument(self, *, type, nargs, required, help):
            pass
        def parse_args(self):
            return args
    args = {'input': [], 'output': '', 'target': '', 'root': None, 'debug': False}
    sys.argv = []
    assert main() == 0

# Generated at 2022-06-21 17:26:45.413250
# Unit test for function main
def test_main():
    # Valid args
    sys.argv = ['py-backwards', '-i', 'unit_test.py', '-o', 'output', '-t', '3.5']
    main()

    # Invalid args for input
    sys.argv = ['py-backwards', '-i', 'doesnt_exist.py', '-o', 'output', '-t', '3.5']
    assert main() == 1

    # Invalid args for output
    sys.argv = ['py-backwards', '-i', 'unit_test.py', '-o', 'output/', '-t', '3.5']
    assert main() == 1

    # Missing arg
    sys.argv = ['py-backwards', '-i', 'unit_test.py', '-t', '3.5']

# Generated at 2022-06-21 17:26:52.038909
# Unit test for function main
def test_main():
    sys.argv[1] = const.TEST_PATH
    sys.argv[2] = const.TEST_PATH
    sys.argv[3] = '3.5'

    try:
        result = main()
    except Exception:
        result = 1

    assert result == 0

# Generated at 2022-06-21 17:26:52.620979
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:27:32.006540
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:27:32.813954
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:41.101439
# Unit test for function main
def test_main():
    def mock_parse_args(args):
        class Namespace:
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)
        return Namespace(**vars(args))

    class MockArgs:
        def __init__(self, input_, output, target, root, debug):
            self.input = input_
            self.output = output
            self.target = target
            self.root = root
            self.debug = debug

        def parse_args(self):
            return mock_parse_args(self)

    args = MockArgs(['pybackwards/scripts.py'], 'pybackwards', '2.7', None, False)
    result = main(args)
    assert result == 0


# Generated at 2022-06-21 17:27:43.573557
# Unit test for function main
def test_main():
    sys.argv = ['py_backwards','-i', 'test/folder', '-o', 'output',
                '-t', '2.7', '-r', 'test/folder']
    assert main() == 0

# Generated at 2022-06-21 17:27:44.526921
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:27:56.779249
# Unit test for function main
def test_main():
    result = []

    class Arg:
        def __init__(self, target=None, output=None, debug=False):
            self.target = target
            self.output = output
            self.debug = debug

    # Don't have assertRaises in Python 2.7
    def assertRaises(self, exception):
        def assert_exception():
            result.append(main(Arg()))
        self.assertRaises(exception, assert_exception)

    # Don't have assertRaises in Python 2.7
    def assertRaises_2(self, exception, args):
        def assert_exception():
            result.append(main(args))
        self.assertRaises(exception, assert_exception)


# Generated at 2022-06-21 17:27:57.561636
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:04.415404
# Unit test for function main
def test_main():
    #with pytest.raises(SystemExit) as pytest_wrapped_e:
    #    main()
    #assert pytest_wrapped_e.type == SystemExit
    #assert pytest_wrapped_e.value.code == 0

    # Unit test for function main
    assert main() == 0

# Generated at 2022-06-21 17:28:07.433245
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests', '-o', 'result', '-t', '3.5', '-r', 'tests']
    assert main() == 0

# Generated at 2022-06-21 17:28:19.993803
# Unit test for function main
def test_main():
    sys.argv = ['main.py', '-i', 'test/data/main.py', '-o', 'out', '-t', '3.5']
    assert main() == 0
    sys.argv = ['main.py', '-i', 'not/exists.py', '-o', 'out', '-t', '2.7']
    assert main() == 1
    sys.argv = ['main.py', '-i', 'test/data/main.py', '-o', 'out', '-t', '3.5']
    input_ = sys.argv[2]
    output = sys.argv[4]
    assert main() == 0
    assert os.path.isfile(output)
    os.remove(output)

# Generated at 2022-06-21 17:29:53.536582
# Unit test for function main
def test_main():
    # Test1: test exception InputDoesntExists
    input = 'test'
    output = './'
    target = '2.7'
    args = ['-i', input, '-o', output, '-t', target]
    with pytest.raises(SystemExit, match='1') as e:
        main()

    # Test2 PermissionError
    input = '/usr'
    output = './'
    target = '2.7'
    args = ['-i', input, '-o', output, '-t', target]
    with pytest.raises(SystemExit, match='1') as e:
        main()

    # Test3: Exception InvalidInputOutput
    input = './test'
    output = './'
    target = '2.7'

# Generated at 2022-06-21 17:29:54.005342
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:29:55.392345
# Unit test for function main
def test_main():
    print(main(), end='\n')

# Generated at 2022-06-21 17:30:07.599061
# Unit test for function main
def test_main():
    import os
    import shutil

    os.chdir('/home')
    os.system('mkdir testing')
    os.chdir('testing')
    os.system('mkdir testing1')

    args = ['py-backwards','-i','testing1','-o','output','-t','3.4']
    assert(main() == 1)

    os.chdir('/home/testing')
    os.system('mkdir output')

    assert(main() == 1)

    os.system('rm -r testing1')
    os.system('mkdir testing1')

    assert(main() == 1)

    os.system('touch testing1/test1.py')
    args = ['py-backwards','-i','testing1','-o','output','-t','3.4']

# Generated at 2022-06-21 17:30:13.941884
# Unit test for function main
def test_main():
    sys.argv = ['', '-i', 'tests/test_files/test1.py', '-o', 'tests/test_files/test1_out.py', '-t', '2.7', '-r', 'tests/test_files/']
    main()

# Generated at 2022-06-21 17:30:16.520780
# Unit test for function main
def test_main():
    assert(main() == 0)

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-21 17:30:17.261588
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:21.139402
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-21 17:30:23.138652
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:26.191875
# Unit test for function main
def test_main():
    out = StringIO()
    sys.stdout = out
    main()
    output = out.getvalue().strip()
    assert output

# Generated at 2022-06-21 17:33:40.899187
# Unit test for function main
def test_main():
    from unittest.mock import patch
    with patch.object(sys, 'argv', ['py_backwards', '-i', 'tests/examples',
                                    '-o', 'out', '-t', '3.5', '-r', 'examples']):
        assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:33:52.831035
# Unit test for function main
def test_main():
    os.environ['TESTING'] = 'True'
    os.environ['TESTING_DIR'] = os.path.join(os.path.dirname(__file__), 'assets')

    assert main(['-i', 'tests/version3.6.py', '-t', '3.6', '-o', 'out.py']) == 0
    assert main(['-i', 'tests/version3.6.py', '-t', '3.6', '-o', 'out.py', '-d']) == 0
    assert main(['-i', 'tests/version3.6.py', '-t', '3.6', '-o', 'out.py', '-d', '-r', 'tests']) == 0

# Generated at 2022-06-21 17:33:56.165245
# Unit test for function main
def test_main():
    init_settings()
    result = main()
    assert result == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:34:08.643627
# Unit test for function main
def test_main():
    from py_backwards.parser import parse_string
    from .compiler import compile_module, compile_module_string
    from .tests.test_compiler import const as test_const
    import json

    out_name = 'test_main.out'
    out_path = os.path.join(test_const.TEMP_DIR, out_name)

    input_name = 'test_main.py'
    input_path = os.path.join(test_const.TEMP_DIR, input_name)

    test_module = parse_string(test_const.SIMPLE_COMPILE_CODE)

    assert compile_module_string(test_module, out_path)
    with open(out_path, 'r') as out:
        assert json.load(out) == compile_module(test_module)

