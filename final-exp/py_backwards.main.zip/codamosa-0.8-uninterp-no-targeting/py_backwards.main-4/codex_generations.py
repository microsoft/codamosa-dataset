

# Generated at 2022-06-21 17:24:30.588509
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', './test/test_input.py',
                '-o', './test/test_output.py', '-t', '3.3']
    try:
        sys.exit(main())
    except SystemExit:
        print("OK")
        return 0
    return -1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:32.188427
# Unit test for function main
def test_main():
    # test
    return 0


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:38.556691
# Unit test for function main
def test_main():
    main()
    main(["-i", "C:/Users/Federico/PycharmProjects/py_backwards/Test/testfile.py",
          "-o", "C:/Users/Federico/PycharmProjects/py_backwards/Test/output",
          "-t", "2.7"])

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-21 17:24:40.264113
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:24:40.830947
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:24:45.032898
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv += ['-i', 'tests/unit_tests/integration/utils', '-o', 'tests/unit_tests/integration/output', '-t', '2']
    sys.exit(main())

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:46.282744
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:24:56.427469
# Unit test for function main
def test_main():
    # for input something like this "(" "(" "(" "(" "(" "("
    # there should be an error
    sys.argv = [
        'py-backwards', '-i', 'tests/data/test_main.py', '-o',
        'tests/data/test_main_output.py', '-t', 'python36'
    ]
    assert main() == 1
    
    # for input something like this "(" "(" "(" "(" "(" "("
    # there should be an error
    sys.argv = [
        'py-backwards', '-i', 'tests/data/test_main.py', '-o',
        'tests/data/test_main_output.py', '-t', 'python37'
    ]
    assert main() == 0

    # for input something

# Generated at 2022-06-21 17:25:01.548824
# Unit test for function main
def test_main():
    import pytest
    import sys
    import os
    import subprocess

    sys.argv[1:] = ['-i', 'tests', '-o', 'tests.new', '-t', '3.5', '-d']
    sys.exit(main())
    output = subprocess.check_output(['python3.5', 'tests.new/tests/test_main.py'])
    assert b'Test succeeded' in output

# Generated at 2022-06-21 17:25:09.633174
# Unit test for function main
def test_main():

    sys.argv = ['py-backwards', '-i', 'tests/py-backwards/test_main.py',
                    '-o', 'tests/py-backwards/test_main_out.py', '-t', 'py35']
    sys.argv.pop(0)
    main()

    sys.argv = ['py-backwards', '-i', 'tests/py-backwards/test_main.py',
                    '-o', 'tests/py-backwards/test_main_out.py', '-t', 'py26']
    sys.argv.pop(0)
    main()

    with open('tests/py-backwards/test_main_out.py', 'r') as f:
        actual = f.read()

# Generated at 2022-06-21 17:25:35.794283
# Unit test for function main
def test_main():
    import os, tempfile
    from os.path import join, exists, sep
    from .utils import temporary_args

    with temporary_args(['--target', 'py36', '--output', tempfile.mkdtemp()]) as args:
        assert main() == 1
        assert not exists(args.output)

        with tempfile.TemporaryDirectory() as temp_dir:
            input_path = join(temp_dir, 'input')
            output_path = join(temp_dir, 'output')
            os.mkdir(input_path)
            with tempfile.NamedTemporaryFile(dir=input_path, suffix='.py') as f:
                f.write(b'print("test")\n')
                f.flush()

# Generated at 2022-06-21 17:25:36.662187
# Unit test for function main
def test_main(): assert main() == 0

# Generated at 2022-06-21 17:25:37.532279
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:25:47.908655
# Unit test for function main
def test_main():
    # Test success usage
    sys.argv = []
    sys.argv.append('-i')
    sys.argv.append('C:\\Users\\Slava\\PycharmProjects\\PYBackwards\\tests\\test_files\\test')
    sys.argv.append('-o')
    sys.argv.append('C:\\Users\\Slava\\PycharmProjects\\PYBackwards\\tests\\test_files\\test1')
    sys.argv.append('-t')
    sys.argv.append('2.7')
    sys.argv.append('-r')
    sys.argv.append('C:\\Users\\Slava\\PycharmProjects\\PYBackwards\\tests\\test_files')
    result = main()
    assert result == 0

    # Test wrong input

# Generated at 2022-06-21 17:25:54.425712
# Unit test for function main
def test_main():
    output = StringIO()
    sys.stdout, sys.stderr = output, output
    main()

    sys.stdout, sys.stderr = sys.__stdout__, sys.__stderr__
    return output.getvalue()

# Unit tests for function main

# Generated at 2022-06-21 17:25:55.324839
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-21 17:26:05.660453
# Unit test for function main
def test_main():
    from .test import assert_file_content

    parser = ArgumentParser('py-backwards',
                            description='Python to python compiler that allows you to use some '
                                        'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+')
    parser.add_argument('-o', '--output', type=str)
    parser.add_argument('-t', '--target', type=str,
                        choices=const.TARGETS.keys())
    parser.add_argument('-r', '--root', type=str, required=False)
    args = parser.parse_args()

# Generated at 2022-06-21 17:26:09.911799
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', 'pikachu.py', '-o', 'pikachu_backwards.py', '-t', 'py35', '-d']
    assert main() == 0

# Generated at 2022-06-21 17:26:17.900241
# Unit test for function main
def test_main():
    argv = ['-i', 'tests/in', '-o', 'tests/out', '-t', '2.7', '-r', 'tests']
    sys.argv = ['py-backwards'] + argv
    assert main() == 0
    assert os.path.isfile('tests/out/hello_world.py') and \
        os.path.isfile('tests/out/__init__.py')
    os.remove('tests/out/hello_world.py')
    os.remove('tests/out/__init__.py')

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:26:23.093748
# Unit test for function main
def test_main():

    with open('../tests/forest/__init__.py', 'w') as f:
        f.write('# This is a placeholder file')

    with open('../tests/forest/mountain.py', 'w') as f:
        f.write('# This is a placeholder file')

    with open('../tests/forest/hill.py', 'w') as f:
        f.write('# This is a placeholder file')

    result = main(['../tests/forest', '../tests/forest/output', '3.3'])
    assert result == 0

    with open('../tests/forest/__init__.py', 'w') as f:
        f.write('import mountain')

    result = main(['../tests/forest', '../tests/forest/output', '3.3'])
    assert result == 0


# Generated at 2022-06-21 17:26:58.898238
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:01.517907
# Unit test for function main
def test_main():
    sys.argv = ['pybackwards', '-i', 'test.py', '-o', 'test_ouput.py', '-t', '2.7', '-r', '.', '-d', 'debug']
    if __name__ == '__main__':
        main()

# Generated at 2022-06-21 17:27:11.368945
# Unit test for function main
def test_main():
    input_ = 'test/test_folder/test.py'
    output = 'test/test_folder/test.result.py'
    target = '2.7'
    root = 'test/test_folder'
    args = '-i {} -o {} -t {} -r {}'.format(input_, output, target, root)
    argv = ['-i', input_, '-o', output, '-t', target, '-r', root]
    assert main() == 0


# Generated at 2022-06-21 17:27:15.839277
# Unit test for function main
def test_main():
    sys.argv = ['pyback', '-i', '/opt/project/src/main.py', '-o',
                '/opt/project/build/main.py', '-t', '3.5', '-r',
                '/opt/project/src']
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:27:25.002964
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', './py-backwards/tests/data',
        '-o', './py-backwards/tests/output',
        '-t', '3.4',
        '-r', './py-backwards/tests/data',
        '-d',
    ]
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:27:31.091102
# Unit test for function main
def test_main():
    sys.argv[1:] = ["-i", "test_data/test.py", "-o", "test_data/testout.py",
                    "-t", "python2", "-d", "-r", "test_data"]
    from mock import patch
    with patch('stdout.write') as mocked_stdout:
        with patch('stderr.write') as mocked_stderr:
            with patch('argparse._sys.argv', new=["-i", "test_data/test.py",
                                         "-o", "test_data/testout.py",
                                         "-t", "python2", "-d", "-r",
                                         "test_data"]):
                main()
                mocked_stdout.assert_called()
                mocked_stderr.assert_not_called()

# Generated at 2022-06-21 17:27:32.553845
# Unit test for function main
def test_main():
    assert 0 == py_backwards.main()

# Generated at 2022-06-21 17:27:40.976592
# Unit test for function main
def test_main():
    InputArgument = '-i'
    OutputArgument = '-o'
    TargetArgument = '-t'
    DebugArgument = '-d'
    InputPathArgument = 'input'
    OutputPathArgument = 'output'
    RootArgument = '-r'
    RootPathArgument = 'root'
    FileArgument = '-f'
    FilePath = 'file'

    with pytest.raises(SystemExit) as error:
        sys.argv = ['py-backwards']
        main()
    assert 'main() missing 1 required positional argument: \'' + InputPathArgument + '\'' in str(error.value)

    with pytest.raises(SystemExit) as error:
        sys.argv = ['py-backwards', InputPathArgument]
        main()

# Generated at 2022-06-21 17:27:48.077775
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test', '-o', 'output', '-t', '3.6', '-r', 'root']
    assert (main() == 1)
    sys.argv = ['py-backwards', '-i', 'test/test.py', '-o', 'output', '-t', '3.6', '-r', 'test']
    assert (main() == 0)

# Generated at 2022-06-21 17:27:56.710122
# Unit test for function main
def test_main():
    sys.argv = ['__main__.py', '-i', 'input', '-o', 'output', '-t', '3.5',
                '-r', 'root']
    with pytest.raises(ValueError):
        main()
    init_settings(vars(parser.parse_args()))
    assert settings.input == ['input']
    assert settings.output == 'output'
    assert settings.root == 'root'
    assert settings.target == const.TARGETS['3.5']

# Generated at 2022-06-21 17:29:28.297366
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from .utils import StringIO

    # If args are invalid
    with patch.object(sys, 'argv', ['py-backwards']), patch.object(sys, 'exit'), patch.object(sys.stderr, 'write') as write:
        main()
        assert write.called is True

    # If input file doesn't exist
    with patch.object(sys, 'argv', ['-i', 'main.py', '-o', 'compiled.py', '-t', '3.4']), patch.object(sys, 'exit'), \
            patch.object(sys.stderr, 'write') as write:
        main()
        assert write.called is True

    # If input and output has a same path

# Generated at 2022-06-21 17:29:37.604551
# Unit test for function main
def test_main():
    try:
        # sys.argv[1] = '-i'
        # sys.argv[2] = './tests/input/'
        # sys.argv[3] = '-o'
        # sys.argv[4] = './tests/output/'
        # sys.argv[5] = '-t'
        # sys.argv[6] = 'python27'
        # sys.argv[7] = '-d'
        main()
    except ValueError:
        print("Test passed")
    else:
        print("Test failed")


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:29:38.214658
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:29:38.735709
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:29:39.578438
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:29:47.095699
# Unit test for function main
def test_main():
    from .conf import settings
    from .mock import mock_settings
    import os
    import shutil
    import random
    import string

    random_dir = ''.join(random.choice(string.ascii_uppercase
                                       + string.digits)
                                       for _ in range(12))
    mock_settings(random_dir)

# Generated at 2022-06-21 17:29:47.869228
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:29:48.950256
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:29:52.710768
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:29:54.061681
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:31:22.652137
# Unit test for function main
def test_main():
    saved_args = list(sys.argv)

    sys.argv = ['py-backwards', '-i', 'input/', '-o', 'output/', '-t', '2.7']

    # Correct run
    assert main() == 0

    # Nonexistent input
    sys.argv = ['py-backwards', '-i', 'nonexistent/', '-o', 'output/', '-t',
                '2.7']
    assert main() == 1

    # Input and output are the same
    sys.argv = ['py-backwards', '-i', 'input/', '-o', 'input/', '-t', '2.7']
    assert main() == 1

    # Input doesn't exists

# Generated at 2022-06-21 17:31:32.188048
# Unit test for function main
def test_main():
    import os, sys
    from pathlib import Path
    from pytest import moves_file, check_output_dir

    sys.argv = ['', 'tests/input/main_test.py', '-o',
                'tests/output/main_test_output', '-t', '3.5',
                '-root', 'tests/input']

    main()
    assert check_output_dir('tests/output/main_test_output')
    assert os.path.exists('tests/output/main_test_output/main_test.py')
    moves_file(Path('tests/output/main_test_output/main_test.py'),
               Path('tests/input/main_test.py'))

# Generated at 2022-06-21 17:31:34.257236
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:31:35.065590
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-21 17:31:44.093663
# Unit test for function main
def test_main():
    def test_compile_files(input, output, target, root):
        if input == 'not_existing_file':
            raise exceptions.InputDoesntExists
        elif input == 'input' and output == 'output':
            raise exceptions.InvalidInputOutput
        elif input == 'input':
            return [(output, 'file1'), (output, 'file2')]
        else:
            raise TypeError

    saved_compile_files = sys.modules['pybackwards'].compiler.compile_files
    sys.modules['pybackwards'].compiler.compile_files = test_compile_files

    def test_sys(code):
        if code == 1:
            raise PermissionError
        elif code == 2:
            raise exceptions.InputDoesntExists
        elif code == 3:
            raise

# Generated at 2022-06-21 17:31:53.813969
# Unit test for function main
def test_main():
    # given
    def mock_parse_args(args):
        return args

    def mock_init_settings(settings):
        pass

    def mock_compile_files(input_ , output, target, root):
        return True

    # when
    parser = ArgumentParser()
    parser.add_argument = Mock()
    parser.parse_args = mock_parse_args
    args = parser.parse_args(['-i', 'input', '-o', 'output',
                              '-t', 'python36', '-r', 'root'])

    init_settings = Mock()
    init_settings.side_effect = mock_init_settings

    compile_files = Mock()
    compile_files.side_effect = mock_compile_files

    sys.stderr = Mock()
    print = Mock()


# Generated at 2022-06-21 17:31:55.518895
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-21 17:31:57.012634
# Unit test for function main
def test_main():
    assert main() == 0


if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-21 17:31:59.522224
# Unit test for function main
def test_main():
    exceptions.MessageException = Exception
    test_args = lambda args: main(['prog'] + args)

    assert test_args([]) == 2
    assert test_args(['-i', 'file1.py', '-o', 'file2.py', '-t', 'py27']) == 0

# Generated at 2022-06-21 17:32:05.294711
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '2.7',
                '-r', 'root', '-d', '']
    assert main() == 0