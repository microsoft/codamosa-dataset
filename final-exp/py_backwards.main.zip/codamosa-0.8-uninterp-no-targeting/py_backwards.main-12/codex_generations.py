

# Generated at 2022-06-21 17:24:24.270928
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:24:28.421438
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py',
                '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-21 17:24:34.235588
# Unit test for function main
def test_main():
    input = ['./tests/integration/source']
    output = './tests/integration/output_dir'
    target = '2.7'
    root = './tests/integration'

    args = ArgumentParser('py-backwards').parse_args()
    args.input = input
    args.output = output
    args.target = target
    args.root = root

    init_settings(args)
    run_test_main(input, output, target)



# Generated at 2022-06-21 17:24:43.980364
# Unit test for function main
def test_main():
    # testing invalid input
    sys.argv[1:] = ['-i', '', '-o', '', '-t', '', '-d', '-r', '']
    assert(main() == 1)
    # testing invalid output
    sys.argv[1:] = ['-i', 'test_files/test.py', '-o', '', '-t', '', '-d', '-r', '']
    assert(main() == 1)
    # testing permission_error
    sys.argv[1:] = ['-i', 'test_files/test.py', '-o', '/', '-t', '', '-d', '-r', '']
    assert(main() == 1)

test_main()

# Generated at 2022-06-21 17:24:49.121112
# Unit test for function main
def test_main():
    globals()['sys'].argv[1:] = ['-i', './tests/test_input',
                                 '-o', './tests/test_folder_output',
                                 '-t', '3.5']
    # globals()['sys'].argv[1:] = ['-i', './tests/test_input/ll1_grammar.yacc',
    #                              '-o', './tests/test_file_output',
    #                              '-t', '3.5']

    # argparse cant handle file/folder output so we need to mock it

# Generated at 2022-06-21 17:24:54.681614
# Unit test for function main
def test_main():
    import pytest
    from sys import argv
    argv = ['py-backwards', '--input', './tests/src', '--output', './tests/out',
            '--target', '3.5', '--root', './tests/src']
    assert main() == 0
    try:
        main()
    except TypeError:
        assert True

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:24:55.223592
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-21 17:25:03.705237
# Unit test for function main
def test_main():
    import os
    import shutil
    from .conf import enable_debug, set_target

    enable_debug()
    set_target('3.5')

    def cleanup() -> int:
        try:
            shutil.rmtree('test_main')
        except FileNotFoundError:
            pass
        return 0

    # Test compilation error
    assert main(['py-backwards/tests/func_err.py', '-o', 'test_main',
                 '-t', '3.5', '-i', '3.5']) == 1
    assert cleanup() == 0

    # Test transformation error
    assert main(['-i', 'py-backwards/tests/func_ok.py', '-o', 'test_main',
                 '-t', '3.5']) == 1

# Generated at 2022-06-21 17:25:04.278087
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:25:05.004754
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:25:17.224117
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-21 17:25:19.243806
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:25:22.981913
# Unit test for function main
def test_main():
    sys.argv = ['test_main', '-i', 'dummy.py', '-o', 'result.py']
    result = main()
    assert result == 1

# Generated at 2022-06-21 17:25:30.193958
# Unit test for function main
def test_main():
    # GIVEN
    class Args:
        input = ["test_resources/test_resources.py"]
        output = "output_dir"
        target = "2.7"
        root = "."

    # WHEN

# Generated at 2022-06-21 17:25:30.694062
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-21 17:25:35.131119
# Unit test for function main
def test_main():
    sys.argv = [
        'path_to_py_backwards',
        '-i',
        'test_input',
        '-o',
        'test_output',
        '-t',
        '3.5',
        '-r',
        '.',
        '-d'
    ]
    assert(main() == 0)

# Generated at 2022-06-21 17:25:39.874744
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i','test.py','-o','out','--input','test2.py','--target','27','--root','.']
    if __name__ == "__main__":
        main()

# Generated at 2022-06-21 17:25:43.764517
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:25:46.027243
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'sample.py', '-o', '../tmp/', '-t', '2.7', '-r', '.\\']
    main()
    assert True


# Generated at 2022-06-21 17:25:58.693019
# Unit test for function main
def test_main():
    import pytest
    from sys import executable
    from os import path
    from py_backwards.const import TARGETS
    from py_backwards import exceptions
    from .conf import settings
    from . import messages

    def run_py_backwards(*args):
        import subprocess
        P = subprocess.run([executable, path.join(path.dirname(__file__), '__main__.py')] + list(args),
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return P.returncode, P.stdout.decode('utf-8'), P.stderr.decode('utf-8')

    def run_tests(target):
        settings.debug = True

# Generated at 2022-06-21 17:26:27.508708
# Unit test for function main
def test_main():
    args = ["-i", "hahaha", "-o", "huhuhu", "-t", "2.7"]
    old_stdout = sys.stdout
    f = open('./log.out','w+')
    sys.stdout = f
    assert main() == 1
    f.seek(0)
    out = f.read()
    sys.stdout = old_stdout
    f.close()
    os.remove('./log.out')
    assert out == "File or folder hahaha doesn't exists!\n"

    args = ["-i", "hahaha", "-o", "huhuhu", "-t", "3.7"]
    old_stdout = sys.stdout
    f = open('./log.out','w+')
    sys.stdout = f


# Generated at 2022-06-21 17:26:28.555492
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-21 17:26:38.737292
# Unit test for function main
def test_main():
    # Happy path
    argv = ['py-backwards','-i','test_data/test_input_1.py','-o','test_output','-t','3.3','-r','test_data', '-d']
    assert main() == 0

    argv = ['py-backwards','-i','test_data/test_input_1.py','-o','test_output','-t','3.3','-r','test_data']
    assert main() == 0

    argv = ['py-backwards','-i','test_data/test_input_1.py','-t','3.3','-r','test_data']
    assert main() == 1

    argv = ['py-backwards','-i','test_data/test_input_1.py','-t','3.3']

# Generated at 2022-06-21 17:26:39.316171
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:40.093671
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:47.578333
# Unit test for function main
def test_main():
    from . import test_data
    from .conf import settings

    sys.argv = ['pyback', '-i', test_data.input_folder, '-o',
                test_data.output_folder, '-t', 'py3', '-r', test_data.sources_root]
    assert main() == 0
    assert settings.input == [test_data.input_folder]
    assert settings.output == test_data.output_folder
    assert settings.target == 'py3'
    assert settings.root == test_data.sources_root
    assert settings.debug == False

# Generated at 2022-06-21 17:26:49.712389
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'src', '-o', 'build', '-t', '3.4', '-r', 'src']
    assert main() == 0

# Generated at 2022-06-21 17:26:56.674398
# Unit test for function main
def test_main():
    args = ["-i", "tests/foo.py", "tests/bar/baz.py",
            "-o", "/tmp/pb-output",
            "-t", "2.7",
            "-r", "tests"]

    sys.argv = sys.argv[:1] + args
    assert main() == 0

    args[1] = "/tmp/nonexisting"
    sys.argv = sys.argv[:1] + args
    assert main() == 1

    args[1] = "tests/foo.py"
    args[4] = "tests/foo.py"
    sys.argv = sys.argv[:1] + args
    assert main() == 1

    args[4] = "/tmp/pb-output"
    sys.argv = sys.argv[:1] + args

# Generated at 2022-06-21 17:27:04.431261
# Unit test for function main
def test_main():
    sys.argv = ["py-backwards", "-i", "tests/data/good.py", "-o", "tests/data/output.py", "-t", "python2.7", "-d"]
    main()
    assert os.path.isfile("tests/data/output.py")

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:27:10.355947
# Unit test for function main
def test_main():
    input = ["test.py"]
    output = "output.py"
    target = '27'
    args = Namespace(input = input, output = output, target = target,
                     debug = True, root = None)
    with patch('py_backwards.main.compile_files') as mock_compile_files:
        main()

    mock_compile_files.assert_called_once_with(input[0], output,
                                               const.TARGETS[target],
                                               args.root)

# Generated at 2022-06-21 17:27:55.064515
# Unit test for function main
def test_main():
    sys.argv += ['-i', 'test_input', '-o', 'test_output', '-t', '3.5', '-r', 'test_input']
    test = main()
    assert test == 0

# Generated at 2022-06-21 17:27:56.538770
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 2, 'main() return None'

# Generated at 2022-06-21 17:28:08.832576
# Unit test for function main
def test_main():
    from .tests.mock_compiler import mock_compile_files
    from .conf import settings
    assert main() == 1
    assert main(['file']) == 1
    assert main(['file'], 'output') == 1
    assert main(['file'], 'output', 'version') == 1
    assert main(['file'], 'output', 'version', True) == 1
    assert main(['file'], 'output', '3.5', True) == 0
    assert main(['file'], 'output', '3.5') == 0
    assert main(['file1', 'file2'], 'output', '3.5') == 0
    assert main(['file1', 'file2'], 'output', '3.5', 'root') == 0

    assert main(['file1']) == 1


# Generated at 2022-06-21 17:28:12.666971
# Unit test for function main
def test_main():
    try:
        main()
        return 0
    except Exception:
        return 1


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:28:18.186714
# Unit test for function main
def test_main():
    class Args():
        def __init__(self):
            self.input = ['test.py', 'test2.py']
            self.output = 'output.py'
            self.target = '2.7'
            self.root = 'C:\\Users\\nikit\\PycharmProjects\\py-backwards'

    assert main() == 0

# Generated at 2022-06-21 17:28:19.653507
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:20.619613
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:21.067250
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:30.843072
# Unit test for function main
def test_main():
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/input.py', '-o', 'test/output.py']
    assert main() == 1
    sys.argv = ['py-backwards', '-i', 'test/input.py', '-o', 'test/output.py', '-t', '2.7']
    assert main() == 0
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/input.py', '-o', 'test/output.py', '-t', '3.7']
    assert main() == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:28:33.592610
# Unit test for function main
def test_main():
    assert main() == 0
#
# if __name__ == '__main__':
#     main()

# Generated at 2022-06-21 17:30:05.518825
# Unit test for function main
def test_main():
    sys.argv = ['--input', 'test.py', '--output', 'output.py', '-t', '2.7']
    main()

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:08.047132
# Unit test for function main
def test_main():
    # Assert that no exception is raised when calling main with good args
    assert main("input_path_main", "output_path_main", "3.7", "root") == 0

# Generated at 2022-06-21 17:30:08.840322
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-21 17:30:17.870831
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('-i')
    sys.argv.append('test_data/test1.py')
    sys.argv.append('-o')
    sys.argv.append('test_data/test1_out.py')
    sys.argv.append('-t')
    sys.argv.append('2.6')
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:21.206849
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:23.207020
# Unit test for function main
def test_main():
    assert main() == 0
    return 0


# Generated at 2022-06-21 17:30:25.115728
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:26.470427
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-21 17:30:31.740804
# Unit test for function main
def test_main():
    # test that main function returns 0 when the compilation is successful,
    # 1 when compilation ended with errors
    argv = sys.argv
    sys.argv = ['py-backwards', '-i', './tests/data/py2_success/',
                '-o', './tests/data/py2_success_out/', '-t', 'python2',
                '-d', '-r', './tests/data/']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', './tests/data/py2_syntax/',
                '-o', './tests/data/py2_syntax_out/', '-t', 'python2',
                '-d', '-r', './tests/data/']
    assert main() == 1
    sys

# Generated at 2022-06-21 17:30:32.543856
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:33:50.009910
# Unit test for function main
def test_main():
    # Positive tests
    # Positive tests - arguments with whitespaces and quotes
    # Positive tests - python 2 and 3 compatibility
    # Negative tests
    pass

# Generated at 2022-06-21 17:34:00.798690
# Unit test for function main
def test_main():
    # test for normal compilation
    sys.argv = ["py-backwards","-i","examples/source.py","-o","examples/target.py","-t","2.7"]
    assert main() == 0
    # test for compilation with wrong input and output
    sys.argv = ["py-backwards","-i","examples/source.py","-o","examples/target.py","-t","2.7","-d"]
    assert main() == 1
    sys.argv = ["py-backwards","-i","examples/source.py","-o","examples/target.py","-t","2.7","-r","examples/source.py"]
    assert main() == 1

# Generated at 2022-06-21 17:34:06.270637
# Unit test for function main
def test_main():
    input_ = './tests/invalid.py'
    output_ = './tests/syntax.py'
    target_ = '3.5'
    root_ = './tests/invalid.py'
    assert main(input_, output_, target_, root_) == 1

# Generated at 2022-06-21 17:34:07.109846
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:34:10.773908
# Unit test for function main
def test_main():
    sys.argv = ['','-i', 'test/test_module.py', '-o', 'test_module_output.py', '-t', 'py36', '-r', 'test/test_module.py']
    assert(main() == 0)
    os.remove('test_module_output.py')


# Generated at 2022-06-21 17:34:22.967126
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_file.py', '-o', 'test_file.py',
                '-d', '-t', 'py38']

    assert main() == 0

    sys.argv = ['py-backwards', '-i', 'test_file.py', '-o', 'dir1/dir2',
                '-d', '-t', 'py38']

    assert main() == 1

    sys.argv = ['py-backwards', '-i', 'test_file.py', '-o', 'dir1/dir2',
                '-d', '-t', 'py38', '-r', 'test_file.py']

    assert main() == 0



if __name__ == '__main__':
    main()