

# Generated at 2022-06-21 17:24:26.009196
# Unit test for function main
def test_main():
    # При создание обьекта ArgumentParser проверяется чтобы в параметре -h было
    # значение help и чтобы в параметре description было значение,
    # реализующее данное условие.
    def input_description(description: str):
        parser = ArgumentParser('py-backwards',
                                description=description)
        return (description == parser.description)

# Generated at 2022-06-21 17:24:32.445248
# Unit test for function main
def test_main():
    # test case: py-backwards -i input.py -o output.py -t 2.7 -r ../
    mock_args = ['-i', 'input.py', '-o', 'output.py', '-t', '2.7', '-r', '../']
    sys.argv[1:] = mock_args
    sys.argv[0] = 'py-backwards'
    print(sys.argv)
    assert main() == 0

# Generated at 2022-06-21 17:24:36.447531
# Unit test for function main
def test_main():
    pass
    #tests_cases = []
    #for test_case in tests_cases:
    #    with patch('') as mock_data:
    #        main()
    #        assert mock_data.called

# Generated at 2022-06-21 17:24:37.095574
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:24:39.685541
# Unit test for function main
def test_main():
    main(['-i', 'tests/programs/syntax_error.py', '-o', '/tmp/out', '-t', '3.5', '-d'])

# Generated at 2022-06-21 17:24:42.725275
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()

    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

# Generated at 2022-06-21 17:24:47.584609
# Unit test for function main
def test_main():
    # Set mock input
    sys.argv = ['py-backwards', '-i', '--input', 'test.py',

                # Set mock output
                '-o', '--output', 'out.py',

                # Set mock target
                '-t', '--target', '3.7',

                # Set mock root
                '-r', '--root', 'test',

                # Set mock debug
                '-d', '--debug']

    # If the program runs
    assert main() == 0
    assert 1 == 1

# Generated at 2022-06-21 17:24:57.719118
# Unit test for function main
def test_main():
    from io import StringIO
    import sys
    import os
    import shutil
    from tempfile import mkdtemp
    from .conf import settings
    from .compiler import generate_output_path, compile_source_code, compile_file

    if os.path.isdir('tests/temp'):
        shutil.rmtree('tests/temp')
    os.makedirs('tests/temp')

    # 1. Test that error appears when running with invalid input file
    sys.stdout = out = StringIO()
    try:
        main()
    except SystemExit as e:
        assert e.code == 1
    else:
        assert False, 'Should raise SystemExit exception with code 1'

# Generated at 2022-06-21 17:25:02.993281
# Unit test for function main
def test_main():
    import sys
    from io import StringIO
    from .conf import settings

    old_argv = sys.argv
    sys.argv = ['py-backwards', '-i', 'tests/data/test.py', '-o',
                'tests/data/test_output', '-t', '2.7', '-r',
                'tests/data']
    main()
    sys.argv = old_argv
    assert '-3.8' in settings.DEBUG_ARGS


# Generated at 2022-06-21 17:25:10.362630
# Unit test for function main
def test_main():
    old_sys_argv = sys.argv

    sys.argv = ['script.py', '-i', 'tests/test_compiler.py', '-o', 'output', '-t', '3.5']
    assert main() == 0

    sys.argv = ['script.py', '-i', 'PY_BACKWARDS_INPUT', '-o', 'PY_BACKWARDS_OUTPUT', '-t', '3.6']
    assert main() == 1

    sys.argv = ['script.py', '-i', 'tests/test_compiler.py', '-o', 'output', '-t', '3.8']
    assert main() == 1

    sys.argv = old_sys_argv

# Generated at 2022-06-21 17:25:21.632821
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-21 17:25:22.982766
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

# Generated at 2022-06-21 17:25:27.801048
# Unit test for function main
def test_main():
    # Test for invalid input file
    def test_main_input_doesnt_exist_exception():
        with pytest.raises(SystemExit):
            sys.argv = ['-i', 'fake.py', '-o', 'output.py', '-t', '2.7']
            main()
        with pytest.raises(SystemExit):
            sys.argv = ['-i', 'fake.py', '-o', 'output.py', '-t', '3.6']
            main()

    # Test for invalid target

# Generated at 2022-06-21 17:25:36.250887
# Unit test for function main
def test_main():
    # Good case
    sys.argv = ['py-backwards', '-i', 'test/input', '-o', 'test/output_altered', '-t', '2.7', '-r', 'test/input']
    assert main() == 0
    # Good case
    sys.argv = ['py-backwards', '-i', 'test/input', '-o', 'test/output/output1/output2', '-t', '3.4', '-r', 'test/input']
    assert main() == 0
    # Good case
    sys.argv = ['py-backwards', '-i', 'test/input', '-o', 'test/output/output1/output2', '-t', '3.5', '-r', 'test/input']
    assert main() == 0
   

# Generated at 2022-06-21 17:25:42.418104
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test_compiler/', '-o', 'output/',
                '-t', '2.7', '-r', 'test_compiler']
    assert 0 == main()
    sys.argv = [sys.argv[0], '-i', 'test_compiler/', '-o', 'output/',
                '-t', '2.7', '-r', 'test_compiler']
    assert 0 == main()
    return

if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-21 17:25:48.456013
# Unit test for function main
def test_main():
    # Test parsing
    sys.argv[:] = ['py-backwards', '-i', 'x', '-o', 'x', '-t', '3.6']
    sys.stdout.write('<args>\n')
    main()
    sys.stdout.write('</args>\n')

    # Test command line errors
    sys.argv[:] = ['py-backwards', '-i', 'x', '-t', '3.6']
    sys.stdout.write('<args>\n')
    main()
    sys.stdout.write('</args>\n')

    sys.argv[:] = ['py-backwards', '-i', 'x', '-o', 'x', '-t', '3.9']

# Generated at 2022-06-21 17:25:59.710202
# Unit test for function main
def test_main():
    from . import util
    import tempfile
    from os.path import sep as path_sep, dirname
    from shutil import rmtree
    from importlib import reload
    import io

    temp_dir = tempfile.TemporaryDirectory()
    orig_stderr = sys.stderr
    sys.stderr = io.StringIO()

# Generated at 2022-06-21 17:26:09.273265
# Unit test for function main
def test_main():
    # test invalid input
    with pytest.raises(SystemExit):
        main()

    # test invalid output
    with pytest.raises(SystemExit):
        main(['-i', '', '-o', '', '-t', '3.5'])

    # test input doesnt exist error
    with pytest.raises(SystemExit):
        main(['-i', '-', '-o', '-', '-t', '3.5'])

    # test invalid input output error
    with pytest.raises(SystemExit):
        main(['-i', '-', '-o', '-', '-t', '3.5'])

    # test success
    assert main(['-i', 'tests', '-o', '-', '-t', '3.5', '-d'])

# Generated at 2022-06-21 17:26:10.130703
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:26:17.323593
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    sys.argv.append('--target')
    sys.argv.append('py37')
    sys.argv.append('--input')
    sys.argv.append('test/test_files')
    sys.argv.append('--output')
    sys.argv.append('test/test_files_output')
    sys.argv.append('--debug')
    sys.argv.append('True')
    assert main() == 0


# Generated at 2022-06-21 17:26:47.461671
# Unit test for function main
def test_main():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    # Case success
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_gen.py', '-o', 'test/test_files/test_gen_out.py', '-t', 'py27']
    m_sys = mock.Mock()
    m_sys.exit = mock.Mock()
    m_init_settings = mock.Mock()
    m_compile_files = mock.Mock()
    m_compile_files.return_value = ([[], [], [], [], 0], 1)

    m_modules = ['sys', 'py_backwards.compiler', 'py_backwards.conf']

# Generated at 2022-06-21 17:26:48.296589
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-21 17:26:52.038753
# Unit test for function main
def test_main():
    #TODO: Check out if we can make a unit test for a main function
    assert True

# Testing the file
if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:26:55.267044
# Unit test for function main
def test_main():
    for target in const.TARGETS.keys():
        assert main(['-i', 'test', '-o', 'out', '-t', target]) == 0

# Generated at 2022-06-21 17:26:58.059145
# Unit test for function main
def test_main():
    sys.argv = [
        '/usr/local/bin/pybackwards',
        '-i',
        'tests/resources/input_file',
        '-o',
        'tests/resources/output_file',
        '-t',
        '2.7',
        '-r',
        '.',
        '-d'
    ]
    main()


# Generated at 2022-06-21 17:26:58.508094
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:26:59.308955
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:01.249366
# Unit test for function main
def test_main():
    assert main() == 1
    assert main() == 0
    assert main() == 3

# Generated at 2022-06-21 17:27:04.607926
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        if e.code == 0:
            pass
        else:
            raise e

# Generated at 2022-06-21 17:27:06.008284
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:27:58.310438
# Unit test for function main
def test_main():
    class Args:
        input = ["python_backwards/test/test_data/test.py"]
        output = "python_backwards/test/test_data/test.py"
        target = "3.5"
        root = None
        debug = False
    main_result = main(Args)
    comp_result = bool(filecmp.cmp('python_backwards/test/test_data/test.py',
                       'python_backwards/test/test_data/test_compiled.py'))
    assert main_result == 0 and comp_result

    class Args:
        input = ["python_backwards/test/test_data/test.py"]
        output = "python_backwards/test/test_data/test1.py"
        target = "3.6"
        root = None
       

# Generated at 2022-06-21 17:28:10.092195
# Unit test for function main
def test_main():
    d = {'input': '-i',
         'output': '-o',
         'target': '-t',
         'root': '-r',
         'debug': '-d',
         'input2': '-i2',
         'output2': '-o2'}
    d['input'] = ['-i', 'input']
    d['output'] = ['-o', 'output']
    d['target'] = ['-t', '3.5']
    d['root'] = ['-r', 'input/']
    args = {
        '-i': ['input',],
        '-o': 'output',
        '-t': '3.5',
        '-r': 'input/',
        '-d': True
    }
    assert(main() == 0)

# Generated at 2022-06-21 17:28:21.065255
# Unit test for function main
def test_main():
    parser = ArgumentParser(
        'py-backwards',
        description='Python to python compiler that allows you to use some '
                    'Python 3.6 features in older versions.')
    parser.add_argument('-i', '--input', type=str, nargs='+', required=True,
                        help='input file or folder')
    parser.add_argument('-o', '--output', type=str, required=True,
                        help='output file or folder')
    parser.add_argument('-t', '--target', type=str,
                        required=True, choices=const.TARGETS.keys(),
                        help='target python version')
    parser.add_argument('-r', '--root', type=str, required=False,
                        help='sources root')

# Generated at 2022-06-21 17:28:29.065288
# Unit test for function main
def test_main():
    # Unit test for correct input
    sys.argv = ['py-backwards', '-i', 'test/test_data/test.py', '-o', 'test/test_data/output.py', '-t', '3.5']
    assert main() == 0

    # Unit test for incorrect input
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_error.py', '-o', 'test/test_data/output_error.py', '-t', '3.5']
    assert main() == 1

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:28:39.328542
# Unit test for function main
def test_main():
    # Test with invalid input file
    sys.argv = ['-i', 'dummy.py', '-o', 'dummy.py', '-t', '2.7', '-r', '']
    assert main() == 1

    # Test with valid input file
    tmp_folder = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_folder, 'dummy.py')
    with open(tmp_file, 'w') as f:
        f.write('class Dummy: pass')

    sys.argv = ['-i', tmp_file, '-o', tmp_file, '-t', '2.7', '-r', '']
    assert main() == 0

# Generated at 2022-06-21 17:28:40.812189
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:28:49.870921
# Unit test for function main
def test_main():
    # test with invalid arguments -o
    test_args = ['-i', '../test_data/test1.py', '-t', '37', '-o', '../test_data/test', '-r']
    with pytest.raises(SystemExit):
        main()

    # test with invalid arguments -t
    test_args = ['-i', '../test_data/test1.py', '-t', 'ver', '-o', '../test_data/test', '-r', '../test_data']
    with pytest.raises(SystemExit):
        main()

    # test with invalid arguments -i

# Generated at 2022-06-21 17:28:54.309093
# Unit test for function main
def test_main():
    sys.argv[1:] = ['-i', './test/source/test.py', '-o', './test/build/test.py', '-t', '2.7']
    main()

# Generated at 2022-06-21 17:29:02.690268
# Unit test for function main
def test_main():
    from . import conf
    from . import compiler, exceptions
    class Args: pass
    args = Args()
    args.input = ['./test/test_file.py']
    args.output = './test'
    args.target = 'py27'
    args.root = './'
    init_settings(args)

    compiler.compile_files = lambda *_: {}
    ret = main()
    assert ret == 0

    compiler.compile_files = lambda *_: {'error': True}
    ret = main()
    assert ret == 1

    args.input = ['./test/test_file.not_exists']
    args.output = './test'
    init_settings(args)

    def raises_exception(*_):
        raise exceptions.InputDoesntExists()
   

# Generated at 2022-06-21 17:29:03.651193
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:34.374832
# Unit test for function main
def test_main():
    sys.argv.extend(['-i', '/home/whale/input', '-o', 'home/whale/result', '-t', '3.5'])
    assert main() == 0

# Generated at 2022-06-21 17:30:37.624983
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:38.845017
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-21 17:30:50.755535
# Unit test for function main
def test_main():
    from .test import utils
    import os
    import subprocess

    # Create test directory
    path = utils.create_tmp_directory()

    # Write input file
    with open(os.path.join(path, 'test.py'), 'wt', encoding='utf-8') as f:
        f.write('#! /usr/bin/env python3\n')
        f.write('def to_str(value) -> str:\n')
        f.write('    return value\n\n')
        f.write('def concat(val1, val2) -> str:\n')
        f.write('    return val1 + val2\n\n')
        f.write('def test(x: int, y: str) -> int:\n')
        f.write('    return x\n\n')
       

# Generated at 2022-06-21 17:30:53.874106
# Unit test for function main
def test_main():
    print('Testing main()... ', end='')
    assert main() == 0
    print('Done.')


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:30:54.762188
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-21 17:30:55.652508
# Unit test for function main
def test_main():
    assert None

# Generated at 2022-06-21 17:30:58.033942
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 17:31:03.937339
# Unit test for function main
def test_main():
    """
    $ py-backwards -i input/test_main.py -o output/test_main.py -t 3.4
    """
    # check file
    with open('input/test_main.py', 'r') as input_file:
        content = input_file.read()
        assert content == 'a = 1 + 2\n'
    # compile
    sys.argv = [
        'py-backwards',
        '-i', 'input/test_main.py',
        '-o', 'output/test_main.py',
        '-t', '3.4'
    ]
    assert main() == 0
    # check
    with open('output/test_main.py', 'r') as output_file:
        content = output_file.read()

# Generated at 2022-06-21 17:31:05.867248
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    sys.exit(main())