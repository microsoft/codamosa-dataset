

# Generated at 2022-06-17 23:46:25.673135
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.089980
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:30.663018
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:31.129555
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:31.580717
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:42.885550
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.6', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:46:43.487862
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:44.004802
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:45.178157
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:50.933601
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:47:09.410628
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:11.273123
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:20.658136
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-d']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data']
    assert main() == 0

# Generated at 2022-06-17 23:47:21.865125
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:26.068447
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test.py', '-o', 'test_data/test_out.py', '-t', '3.5', '-r', 'test_data']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:47:26.611207
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:36.764689
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data']

# Generated at 2022-06-17 23:47:37.298391
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:37.846700
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:41.800625
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:22.614683
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:24.726868
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:25.353764
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:25.932869
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:30.607605
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '2.7', '-r', 'test/test_data/', '-d']
    assert main() == 0

# Generated at 2022-06-17 23:48:42.055984
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o',
                'test/test_files/test_out.py', '-t', '3.5', '-r',
                'test/test_files']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o',
                'test/test_files/test_out.py', '-t', '3.5', '-r',
                'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:42.608259
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:46.636538
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    main()
    assert os.path.isfile('test/test_files/test_file_out.py')
    os.remove('test/test_files/test_file_out.py')

# Generated at 2022-06-17 23:48:47.781372
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:48.357355
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:17.687288
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:50:18.215294
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:18.731929
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:20.696442
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:21.628706
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:22.155236
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:22.650712
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:23.207200
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:32.877728
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-17 23:50:33.376712
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:44.753246
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:53:46.035827
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:46.658629
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:49.530114
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test.py', '-o', 'test_data/test_out.py', '-t', '2.7', '-r', 'test_data']
    assert main() == 0

# Generated at 2022-06-17 23:53:50.212167
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:51.741851
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:52.343868
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:52.835835
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:57.257812
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:53:57.719609
# Unit test for function main
def test_main():
    assert main() == 0