

# Generated at 2022-06-17 23:46:18.111921
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:46:27.444387
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_output.py', '-t', '3.5']
    assert main() == 0

    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_output.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0


# Generated at 2022-06-17 23:46:30.176758
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5', '-r', '.']
    assert main() == 0

# Generated at 2022-06-17 23:46:30.656836
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:31.130247
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:35.031154
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/', '-o', 'test/test_data/', '-t', '3.5', '-r', 'test/test_data/']
    assert main() == 0

# Generated at 2022-06-17 23:46:35.802081
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:36.583782
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:37.708846
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:38.316970
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:57.101042
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:57.701317
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:58.357379
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:05.115487
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'test/test_files/test_file.py',
        '-o', 'test/test_files/test_file_out.py',
        '-t', '3.5',
        '-r', 'test/test_files'
    ]
    assert main() == 0

# Generated at 2022-06-17 23:47:05.411185
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:05.679733
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:07.308270
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:47:07.949921
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:08.445798
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:08.918588
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:46.229604
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:46.721911
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:52.600753
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.6']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'input', '-t', '3.6']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.7']
    assert main() == 1

    # Test for invalid root

# Generated at 2022-06-17 23:47:54.788106
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:55.356116
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:55.898520
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:00.110638
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:48:08.809121
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'tests/input.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'tests/input.py', '-o', 'tests/output.py', '-t', '3.6']
    assert main() == 1

    # Test for invalid target

# Generated at 2022-06-17 23:48:09.256857
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:14.592921
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.5']
    assert main() == 1

# Generated at 2022-06-17 23:49:35.705355
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:36.173917
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:37.561656
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:38.012206
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:39.844423
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:41.626064
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:49:42.049872
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:42.470102
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:42.887770
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:43.293688
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:43.383758
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:43.856536
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:44.205672
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:44.570469
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:45.093655
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:45.706390
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:47.547752
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:48.059749
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:48.373056
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:48.840285
# Unit test for function main
def test_main():
    assert main() == 0