

# Generated at 2022-06-17 23:46:25.833744
# Unit test for function main
def test_main():
    # Test 1:
    #   -i: input file
    #   -o: output file
    #   -t: target version
    #   -r: root
    #   -d: debug
    sys.argv = [
        'py-backwards',
        '-i', 'test/test_files/test_file.py',
        '-o', 'test/test_files/test_file_out.py',
        '-t', '3.5',
        '-r', 'test/test_files/',
        '-d'
    ]
    assert main() == 0

    # Test 2:
    #   -i: input file
    #   -o: output file
    #   -t: target version
    #   -r: root
    #   -d: debug
    sys.arg

# Generated at 2022-06-17 23:46:26.235049
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.649069
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:27.148207
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:27.639264
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:28.132451
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:28.614306
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:29.098095
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:30.155034
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:30.660460
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:50.321776
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:50.891843
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:51.410107
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:51.936228
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:52.435082
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:00.287061
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'invalid_input', '-o', 'out', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_file.py', '-o', 'invalid_output', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_file.py', '-o', 'out', '-t', 'invalid_target']
    assert main() == 1

    # Test for valid input and output

# Generated at 2022-06-17 23:47:00.886846
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:05.796226
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py',
                '-o', 'tests/test_data/test_output.py', '-t', '2.7',
                '-r', 'tests/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:47:06.086981
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:06.660911
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:43.994034
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:47.687135
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0


# Generated at 2022-06-17 23:47:52.256785
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'test/test_data/test_input',
        '-o', 'test/test_data/test_output',
        '-t', '3.5',
        '-r', 'test/test_data'
    ]
    assert main() == 0

# Generated at 2022-06-17 23:47:53.662409
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:55.225131
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:55.778251
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:56.282192
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:56.960892
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:00.371218
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test.py', '-o', 'tests/test_files/test_out.py', '-t', '3.5']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:48:00.855423
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:19.821815
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:20.431287
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:29.548412
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data/']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data/']
    assert main() == 0

# Generated at 2022-06-17 23:49:30.085902
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:30.549400
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:31.046408
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:31.552469
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:35.770844
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:49:36.241763
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:36.931465
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:37.649711
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:38.294610
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:43.008002
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:52:51.591359
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:52:53.827793
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:54.389225
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:54.918627
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:00.363407
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '2.7', '-r', 'tests/test_data/']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:53:05.947433
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input/test.py', '-o', 'test/test_output/test.py', '-t', '2.7', '-r', 'test/test_input']
    assert main() == 0

# Generated at 2022-06-17 23:53:06.489886
# Unit test for function main
def test_main():
    assert main() == 0