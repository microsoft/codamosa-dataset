

# Generated at 2022-06-17 23:46:17.331116
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:17.867235
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:18.364520
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:18.899109
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:19.368394
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:19.899236
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:20.947747
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:21.598935
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:23.125704
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:33.044840
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-17 23:46:55.638477
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data/']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:56.392073
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.547223
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import pytest
    from . import compiler
    from . import conf

    def test_compile_files(input_, output, target, root):
        result = compiler.compile_files(input_, output, target, root)
        assert result.success
        assert result.files == 1
        assert result.lines == 1

    def test_compile_files_error(input_, output, target, root):
        with pytest.raises(exceptions.CompilationError):
            compiler.compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:47:03.088645
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:08.086153
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:47:08.626254
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:09.099672
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:14.599546
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '3.5', '-r', 'tests/test_data/']
    assert main() == 0


# Generated at 2022-06-17 23:47:15.109064
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:16.910860
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:55.439530
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:55.973474
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:56.535141
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:56.873102
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:57.422227
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:58.028549
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:58.530146
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:02.020790
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_files/test.py', '-o', 'test_files/test_out.py', '-t', '3.5', '-r', 'test_files']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:48:02.636135
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-17 23:48:03.115492
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:40.142813
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:40.615705
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:41.976006
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:48.638384
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:49.275857
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:50.023835
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:50.630400
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:51.207087
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:51.997803
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:52.532534
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:18.586213
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:19.962206
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:21.547667
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:22.073450
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:22.581066
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:27.444906
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files/']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:50:28.049149
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:29.692184
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:50:33.530276
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:50:34.785219
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:37.717012
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:38.198219
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:38.656776
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:39.127989
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:41.004210
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:41.517642
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:42.184125
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:42.683263
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:43.169919
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:48.412291
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'test/test_files/test_file.py',
        '-o', 'test/test_files/test_file_out.py',
        '-t', '2.7',
        '-r', 'test/test_files'
    ]
    assert main() == 0