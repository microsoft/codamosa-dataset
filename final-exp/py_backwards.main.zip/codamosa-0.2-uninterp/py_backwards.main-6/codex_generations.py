

# Generated at 2022-06-17 23:46:24.178028
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:25.279488
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.153863
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.745657
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:31.694220
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'tests/test_files/test_file.py',
        '-o', 'tests/test_files/test_file_out.py',
        '-t', 'python2',
        '-r', 'tests/test_files'
    ]
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:32.152129
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:32.616623
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:33.064684
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:39.417414
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py',
                '-o', 'tests/test_files/test_file_out.py', '-t', '3.5',
                '-r', 'tests/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:46:40.754767
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:00.517110
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:04.706388
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:47:06.614578
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:47:06.904091
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:07.300576
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:18.565989
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_input.py', '-o', 'test/test_files/test_output.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_input.py', '-o', 'test/test_files/test_output.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:47:19.315012
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:21.198856
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:47:25.891454
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_files/test_input.py', '-o', 'test_files/test_output.py', '-t', '3.5', '-r', 'test_files']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:47:31.913545
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5', '-r', 'tests/test_files']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:48:14.095918
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:23.144545
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '2.7', '-r', 'test/test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '2.7', '-r', 'test/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:48:24.941026
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:25.547934
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:26.117480
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:26.714379
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:34.496474
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '2.7', '-r', 'tests/test_data/']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '2.7', '-r', 'tests/test_data/']
    assert main() == 0

# Generated at 2022-06-17 23:48:34.959575
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:36.146785
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:37.315326
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:03.449553
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:03.992893
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:05.132905
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:05.674388
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:06.144990
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:06.728961
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:14.470880
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid root

# Generated at 2022-06-17 23:50:16.598598
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:17.206178
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:17.753737
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:27.055017
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py',
                '-o', 'tests/test_files/test_file_out.py', '-t', '2.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py',
                '-o', 'tests/test_files/test_file_out.py', '-t', '2.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py',
                '-o', 'tests/test_files/test_file_out.py', '-t', '2.7']

# Generated at 2022-06-17 23:53:31.229362
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/data/test_input.py', '-o', 'tests/data/test_output.py', '-t', '3.5', '-r', 'tests/data']
    assert main() == 0

# Generated at 2022-06-17 23:53:31.745255
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:32.161522
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:32.527512
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:32.938070
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:33.320216
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:33.695254
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:34.078274
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:35.862640
# Unit test for function main
def test_main():
    assert main() == 0