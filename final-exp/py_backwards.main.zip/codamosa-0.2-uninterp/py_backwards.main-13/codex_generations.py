

# Generated at 2022-06-17 23:46:32.682775
# Unit test for function main
def test_main():
    from . import __main__
    from unittest.mock import patch
    import io
    import sys

    with patch('sys.stdout', new=io.StringIO()) as fake_out:
        with patch('sys.stderr', new=io.StringIO()) as fake_err:
            assert __main__.main() == 1
            assert fake_out.getvalue() == ''
            assert fake_err.getvalue() == 'usage: py-backwards [-h] -i INPUT [INPUT ...] -o OUTPUT -t {2.7,3.4,3.5,3.6} [-r ROOT] [-d]\npy-backwards: error: the following arguments are required: -i/--input, -o/--output, -t/--target\n'


# Generated at 2022-06-17 23:46:33.246767
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:45.390982
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0
    sys.arg

# Generated at 2022-06-17 23:46:46.020425
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:46.582899
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:57.137027
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py',
                '-o', 'test/test_data/test_output.py', '-t', '3.5',
                '-r', 'test/test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py',
                '-o', 'test/test_data/test_output.py', '-t', '3.5',
                '-r', 'test/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:46:57.749354
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:09.075818
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from . import conf
    from . import messages
    from . import exceptions
    from . import compiler

    # Test for invalid input
    with patch('sys.argv', ['py-backwards', '-i', 'input', '-o', 'output',
                            '-t', '3.5']):
        assert main() == 1

    # Test for invalid output
    with patch('sys.argv', ['py-backwards', '-i', 'input', '-o', 'output',
                            '-t', '3.5']):
        assert main() == 1

    # Test for invalid target

# Generated at 2022-06-17 23:47:09.619021
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:11.521630
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:32.830044
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5', '-d']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:47:37.004859
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'test_data/test_input',
        '-o', 'test_data/test_output',
        '-t', '3.5',
        '-r', 'test_data/test_input',
        '-d'
    ]
    assert main() == 0

# Generated at 2022-06-17 23:47:37.603623
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:38.125791
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:38.638254
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:39.085597
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:39.593851
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:40.066014
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:40.727844
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:41.576277
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:22.614480
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:24.728370
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:25.354667
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:25.932772
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:26.531476
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:27.119729
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:27.772832
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:28.808812
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:29.618800
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:31.611971
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:57.272741
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:57.784969
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:59.240920
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:00.554150
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:10.649236
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from io import StringIO
    from . import conf

    with patch('sys.argv', ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5', '-r', 'root']):
        with patch('sys.stdout', new_callable=StringIO) as mock_stdout:
            with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
                main()
                assert mock_stdout.getvalue() == 'Compiled 1 files\n'
                assert mock_stderr.getvalue() == ''
                assert conf.settings.input == ['input.py']
                assert conf.settings.output == 'output.py'

# Generated at 2022-06-17 23:50:11.318778
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:12.253222
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:22.683425
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test_data/invalid_input.py', '-o', 'test_data/output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test_data/input.py', '-o', 'test_data/invalid_output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test_data/input.py', '-o', 'test_data/output.py', '-t', '3.4']
    assert main() == 1

    # Test for invalid input and

# Generated at 2022-06-17 23:50:23.248041
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:27.438257
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input', '-o', 'test/test_data/test_output', '-t', '3.5', '-r', 'test/test_data/test_input']
    assert main() == 0

# Generated at 2022-06-17 23:53:38.551922
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:53:39.058808
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:40.935692
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:41.477533
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:42.146886
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:47.347884
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:53:47.802733
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:53.962722
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test_data/invalid_input', '-o', 'test_data/output', '-t', '2.7']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test_data/input', '-o', 'test_data/invalid_output', '-t', '2.7']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test_data/input', '-o', 'test_data/output', '-t', '2.6']
    assert main() == 1

    # Test for invalid input and output

# Generated at 2022-06-17 23:54:01.983194
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test_files/test_file.py', '-o', 'test_files/test_file.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test_files/test_file.py', '-o', 'test_files/test_file.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test_files/test_file.py', '-o', 'test_files/test_file.py', '-t', '3.5']
    assert main() == 1

   

# Generated at 2022-06-17 23:54:11.487966
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test/test_data/input', '-o', 'output', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test/test_data/input', '-o', 'output', '-t', '3.6']
    assert main() == 1

    # Test for valid input