

# Generated at 2022-06-17 23:46:25.799439
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.472293
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:33.932037
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test_input', '-o', 'test_output', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test_input', '-o', 'test_input', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test_input', '-o', 'test_output', '-t', '3.6']
    assert main() == 1

    # Test for valid input

# Generated at 2022-06-17 23:46:35.289968
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:36.064983
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:36.775465
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:41.951903
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:42.510748
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:43.048592
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:43.658361
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:06.747505
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_compiled.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:47:07.272508
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:07.919777
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:08.411965
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:19.441185
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:47:20.154519
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:20.673299
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:23.786565
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-17 23:47:24.321683
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:29.053195
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test.py', '-o', 'test_data/test_out.py', '-t', '3.5', '-r', 'test_data']
    assert main() == 0

# Generated at 2022-06-17 23:48:08.647831
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:09.099251
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:09.591089
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:10.050761
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:10.661633
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:11.211844
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:22.166383
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5', '-r', 'tests/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:24.444980
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:25.202474
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:25.793250
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:58.415780
# Unit test for function main
def test_main():
    # Test for valid input
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '2.7']
    assert main() == 0

    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '2.7']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '2.7']
    assert main() == 1

    # Test for invalid target

# Generated at 2022-06-17 23:50:00.278680
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:00.979008
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:01.436675
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:01.873063
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:02.422998
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:03.001025
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:03.574909
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:04.118223
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:05.877644
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:53:05.191329
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:05.757968
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:09.263520
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input/test_input.py', '-o', 'test/test_output/test_output.py', '-t', '2.7', '-r', 'test/test_input']
    assert main() == 0

# Generated at 2022-06-17 23:53:09.756496
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:10.239881
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:10.701688
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:11.427895
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:12.146078
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:12.683774
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:13.881267
# Unit test for function main
def test_main():
    assert main() == 0