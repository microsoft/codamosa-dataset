

# Generated at 2022-06-17 23:46:21.394210
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:22.248489
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:23.404104
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:24.977415
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:25.930433
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.559324
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:33.969578
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.6']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.6']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.6']
    assert main() == 1

    # Test for valid input

# Generated at 2022-06-17 23:46:39.709120
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '2.7', '-r', 'tests/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:46:40.753541
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:41.314718
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:00.471216
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:01.015161
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:01.530840
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.102757
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.566297
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:11.376199
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py',
                '-o', 'tests/test_data/test_output.py', '-t', '3.5',
                '-r', 'tests/test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py',
                '-o', 'tests/test_data/test_output.py', '-t', '3.5',
                '-r', 'tests/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:47:12.148814
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:12.781265
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:13.333732
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:13.937302
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:59.923065
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:00.413607
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:00.825425
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:01.311228
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:05.347948
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/input/', '-o', 'test/output/',
                '-t', '2.7', '-r', 'test/input/']
    assert main() == 0

# Generated at 2022-06-17 23:48:15.468791
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_files/test.py', '-o', 'test_files/test_out.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_files/test.py', '-o', 'test_files/test_out.py', '-t', '3.6']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_files/test.py', '-o', 'test_files/test_out.py', '-t', '3.7']
    assert main() == 0

# Generated at 2022-06-17 23:48:20.622088
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/input.py', '-o', 'test_data/output.py', '-t', '2.7', '-r', 'test_data']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:48:23.065656
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_files/test_file.py', '-o', 'test_files/test_file_out.py', '-t', '3.5', '-r', 'test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:24.941366
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:25.547577
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:47.069862
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:47.540450
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:48.018480
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:52.798437
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5', '-r', 'tests/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:49:53.297858
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:54.427013
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:54.933317
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:55.514957
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:01.927820
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '2.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:50:02.413948
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:58.491271
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:58.997625
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:59.428478
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:05.336967
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input', '-o', 'test/test_data/test_output', '-t', '2.7', '-r', 'test/test_data/test_input']
    assert main() == 0

# Generated at 2022-06-17 23:53:08.276609
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-17 23:53:08.763691
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:09.490704
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:09.975894
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:10.492129
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:11.081649
# Unit test for function main
def test_main():
    assert main() == 0