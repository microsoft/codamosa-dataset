

# Generated at 2022-06-17 23:46:23.059869
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:28.317362
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '3.5', '-r', 'test/test_input']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:28.795780
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:29.284149
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:30.350106
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:30.864676
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:31.323638
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:31.776196
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:32.280955
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:32.749808
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:51.596125
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:52.105783
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:52.574989
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:53.029080
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:00.750258
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:47:06.423251
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '2.7', '-r', 'tests/test_data/']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:47:06.695337
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:07.234346
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:07.892562
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:08.378695
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:44.918695
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:51.682305
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile

    def create_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    def create_dir(path):
        os.mkdir(path)

    def create_package(path):
        create_dir(path)
        create_file(os.path.join(path, '__init__.py'), '')

    def create_package_with_file(path, file_name, content):
        create_package(path)
        create_file(os.path.join(path, file_name), content)


# Generated at 2022-06-17 23:47:52.159365
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:52.958143
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:55.135839
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:55.693839
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:56.205177
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:56.870786
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:57.433043
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:58.029186
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:40.250310
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:48:40.726199
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:42.135583
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:45.188459
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:47.545892
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:48.109747
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:48.689850
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:49.318572
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:58.707736
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from io import StringIO
    from . import conf
    from . import exceptions

    with patch('sys.argv', ['py-backwards', '-i', 'input', '-o', 'output',
                            '-t', '3.5']):
        assert main() == 1

    with patch('sys.argv', ['py-backwards', '-i', 'input', '-o', 'output',
                            '-t', '3.5', '-r', 'root']):
        assert main() == 1

    with patch('sys.argv', ['py-backwards', '-i', 'input', '-o', 'output',
                            '-t', '3.5', '-r', 'root', '-d']):
        assert main() == 1

   

# Generated at 2022-06-17 23:48:59.251297
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:23.069528
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:23.644753
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:24.238971
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:24.778420
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:35.039010
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '3.5', '-d']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '3.5', '-r', 'tests/test_data']

# Generated at 2022-06-17 23:50:35.613596
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:36.112699
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:36.632549
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:45.834491
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-d']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data']

# Generated at 2022-06-17 23:50:46.540827
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:49.890590
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:50.418878
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:51.789683
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:52.344070
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:56.593060
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/input', '-o', 'test_data/output', '-t', '2.7', '-r', 'test_data/input']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:53:57.222566
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:00.296285
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:54:02.826085
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:54:03.309060
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:12.049874
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1
    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1
    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

if __name__ == '__main__':
    main()