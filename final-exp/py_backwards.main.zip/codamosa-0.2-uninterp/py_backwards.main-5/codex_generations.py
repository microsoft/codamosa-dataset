

# Generated at 2022-06-17 23:46:20.429664
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:20.926011
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:27.296176
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:46:27.840047
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:31.794629
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/input/test_input.py', '-o', 'tests/output/test_output.py', '-t', '3.5', '-r', 'tests/input']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:32.280518
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:32.749459
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:33.325520
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:39.322552
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data/']
    assert main() == 0

# Generated at 2022-06-17 23:46:40.318125
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:00.418305
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:00.972450
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:01.493896
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.103378
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:07.113250
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files/']
    assert main() == 0

# Generated at 2022-06-17 23:47:07.719015
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:08.125388
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:19.210116
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test.py', '-o', 'test/test_out.py',
                '-t', '3.5', '-r', 'test']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test.py', '-o', 'test/test_out.py',
                '-t', '3.5', '-r', 'test']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test.py', '-o', 'test/test_out.py',
                '-t', '3.5', '-r', 'test']
    assert main() == 0

# Generated at 2022-06-17 23:47:20.038870
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:31.333665
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:21.675767
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

    # Test for valid input

# Generated at 2022-06-17 23:48:22.129652
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:24.445231
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:33.631977
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5', '-r', 'root']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5', '-r', 'root']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5', '-r', 'root']
    assert main() == 1

    # Test for invalid root

# Generated at 2022-06-17 23:48:34.127330
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:34.616356
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:38.867454
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test_out.py', '-t', '2.7', '-r', '.']
    assert main() == 0

# Generated at 2022-06-17 23:48:39.393925
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:43.657518
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files/']
    assert main() == 0

# Generated at 2022-06-17 23:48:49.656753
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '2.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.6']
    assert main() == 0
    sys.arg

# Generated at 2022-06-17 23:50:16.656340
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:17.202882
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:17.754514
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:18.988072
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:50:22.344590
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:50:22.816185
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:23.374107
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:27.545088
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/input', '-o', 'test/output', '-t', '3.5', '-r', 'test/input']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:50:28.121434
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:37.673678
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data']

# Generated at 2022-06-17 23:53:39.364181
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:41.198889
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:41.710744
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:42.365170
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:46.852475
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test.py', '-o', 'tests/test_files/test_out.py', '-t', '2.7', '-r', 'tests/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:53:47.421093
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:47.953560
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:48.414364
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:48.930306
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:49.398351
# Unit test for function main
def test_main():
    assert main() == 0