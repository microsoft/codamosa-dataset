

# Generated at 2022-06-17 23:46:20.148029
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:20.642754
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:21.126126
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:24.605637
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:46:25.413251
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:25.857840
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.515505
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:27.071812
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:27.566767
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:28.058569
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:52.748662
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'tests/test_data/test_input.py',
        '-o', 'tests/test_data/test_output.py',
        '-t', '2.7',
        '-r', 'tests/test_data/'
    ]
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:46:53.237528
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:00.881893
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py',
                '-o', 'test/test_data/test_output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py',
                '-o', 'test/test_data/test_input.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target

# Generated at 2022-06-17 23:47:01.421459
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:01.988110
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.456400
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.962478
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:03.507039
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:05.386687
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:05.992139
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:43.897568
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:44.436667
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:44.996773
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:45.514670
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:48.825652
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '2.7', '-r', 'test/test_data/']
    assert main() == 0

# Generated at 2022-06-17 23:47:49.650130
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:50.093687
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:50.512325
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:51.029924
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:51.621073
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:10.118656
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:10.631865
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:11.093482
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:13.570867
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '3.5', '-r', 'test/test_input']
    assert main() == 0

# Generated at 2022-06-17 23:49:15.289141
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:15.859331
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:16.387841
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:16.890856
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:17.367469
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:20.756777
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:52:20.671055
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:21.224212
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:21.687063
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:22.546298
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:23.030524
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:23.529545
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:24.309535
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:35.190530
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'tests/input/', '-o', 'tests/input/', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'tests/input/', '-o', 'tests/output/', '-t', '3.6']
    assert main() == 1

    # Test for invalid target

# Generated at 2022-06-17 23:52:37.176374
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:37.689098
# Unit test for function main
def test_main():
    assert main() == 0