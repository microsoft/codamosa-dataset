

# Generated at 2022-06-17 23:46:24.652095
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:25.803581
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.206701
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:34.692132
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile

    def create_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    def create_folder(path):
        os.mkdir(path)

    def create_folder_structure(path, structure):
        for name, content in structure.items():
            if isinstance(content, dict):
                create_folder(os.path.join(path, name))
                create_folder_structure(os.path.join(path, name), content)
            else:
                create_file(os.path.join(path, name), content)


# Generated at 2022-06-17 23:46:41.179928
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5', '-r', 'tests/test_files']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:46:41.777353
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:49.818499
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'invalid_input', '-o', 'output', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'invalid_output', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'input', '-o', 'output', '-t', 'invalid_target']
    assert main() == 1

    # Test for invalid input and output

# Generated at 2022-06-17 23:46:53.966536
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_output.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:54.636684
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:57.782948
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input/', '-o', 'test/test_output/', '-t', '2.7', '-r', 'test/test_input/']
    assert main() == 0

# Generated at 2022-06-17 23:47:07.153978
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:07.777344
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:08.183842
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:08.661548
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:19.677390
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '2.7', '-r', 'tests/test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'tests/test_data/test_input.py', '-o', 'tests/test_data/test_output.py', '-t', '2.7', '-r', 'tests/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:47:31.078701
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o',
                'test/test_files/test_file_out.py', '-t', '3.5', '-r',
                'test/test_files']
    assert main() == 0

    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o',
                'test/test_files/test_file_out.py', '-t', '3.5', '-r',
                'test/test_files']
    assert main() == 0


# Generated at 2022-06-17 23:47:31.673865
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:32.190480
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:32.710571
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:40.850081
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'tests/test_data/test_input.py',
        '-o', 'tests/test_data/test_output.py',
        '-t', '2.7'
    ]
    assert main() == 0
    sys.argv = [
        'py-backwards',
        '-i', 'tests/test_data/test_input.py',
        '-o', 'tests/test_data/test_output.py',
        '-t', '3.6'
    ]
    assert main() == 0

# Generated at 2022-06-17 23:48:05.428651
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_output.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:48:06.218496
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:08.966369
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o',
                'test/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-17 23:48:09.462044
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:09.924008
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:10.403048
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:11.038783
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:11.528364
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:12.029638
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:16.888497
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:48:54.290890
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:54.837674
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:55.331214
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:55.866263
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:56.454358
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:56.998445
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:57.621935
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:58.170935
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:58.714220
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:06.452474
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = [sys.argv[0], '-i', 'test_input', '-o', 'test_output', '-t', '2.7']
    assert main() == 1

    # Test for invalid output
    sys.argv = [sys.argv[0], '-i', 'test_input', '-o', 'test_input', '-t', '2.7']
    assert main() == 1

    # Test for invalid target
    sys.argv = [sys.argv[0], '-i', 'test_input', '-o', 'test_output', '-t', '3.7']
    assert main() == 1

    # Test for valid input

# Generated at 2022-06-17 23:50:30.368922
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:31.220164
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:31.790397
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:42.313581
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '2.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '3.6']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '3.7']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '3.8']

# Generated at 2022-06-17 23:50:44.303965
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '2.7']
    assert main() == 0

# Generated at 2022-06-17 23:50:45.997918
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:46.619371
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:47.116224
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:47.844170
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:52.501580
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test.py', '-o', 'test/test_data/test_out.py', '-t', '2.7', '-r', 'test/test_data']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:54:01.904620
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:02.431118
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:05.110756
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/input/', '-o', 'test/output/', '-t', '2.7', '-r', 'test/input/']
    assert main() == 0

# Generated at 2022-06-17 23:54:07.230191
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:07.796037
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:08.294195
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:08.653770
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:09.150491
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:09.632070
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:15.961996
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'tests/input.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'tests/input.py', '-o', 'tests/output.py', '-t', '3.5']
    assert main() == 1

    # Test for syntax error