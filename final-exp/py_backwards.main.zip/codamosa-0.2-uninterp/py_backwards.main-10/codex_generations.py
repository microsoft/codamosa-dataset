

# Generated at 2022-06-17 23:46:23.618853
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:25.205910
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.833426
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:27.373310
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:27.918337
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:34.567163
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:46:35.480355
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:36.257948
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:41.176095
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:46:41.730707
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:00.516976
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:09.936603
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'input.py', '-o', 'output.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid input and output

# Generated at 2022-06-17 23:47:11.725643
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:20.773844
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '2.7']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_input.py', '-t', '2.7']
    assert main() == 1

    # Test for invalid target

# Generated at 2022-06-17 23:47:25.846245
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_output.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:47:26.409745
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:27.701156
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:28.910713
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:37.763588
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '3.5', '-r', 'test/test_input']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '3.5', '-r', 'test/test_input']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '3.5', '-r', 'test/test_input']
    assert main() == 0

# Generated at 2022-06-17 23:47:38.560812
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:18.019257
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:18.499951
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:22.532981
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input.py', '-o', 'test/test_data/test_output.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:48:24.727073
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:25.354505
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:30.065599
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:31.675619
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:42.538394
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_output.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_output.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:43.069782
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:43.556702
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:10.309410
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:10.795709
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:11.595152
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:12.756724
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:13.533791
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:14.866554
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:23.251264
# Unit test for function main
def test_main():
    # Test for invalid input
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid output
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5']
    assert main() == 1

    # Test for invalid target

# Generated at 2022-06-17 23:50:23.822018
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:28.004305
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_input', '-o', 'test/test_data/test_output', '-t', '3.5', '-r', 'test/test_data/test_input']
    assert main() == 0

# Generated at 2022-06-17 23:50:28.680358
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:31.647348
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:32.061062
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:32.432951
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:34.681589
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test/']
    assert main() == 0

# Generated at 2022-06-17 23:53:44.494983
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test.py', '-o', 'test/test_data/test_out.py', '-t', '3.5']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_data/test.py', '-o', 'test/test_data/test_out.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:53:45.871606
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:46.529823
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:47.165040
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:47.635462
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:48.998914
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())