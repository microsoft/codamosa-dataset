

# Generated at 2022-06-17 23:46:27.030572
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/data/test_input.py', '-o', 'tests/data/test_output.py', '-t', '3.5', '-r', 'tests/data']
    assert main() == 0

# Generated at 2022-06-17 23:46:27.530735
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:28.059420
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:28.538699
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:29.024715
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:30.075352
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:31.224668
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:42.426729
# Unit test for function main
def test_main():
    from . import conf
    from . import const
    from . import messages
    from . import exceptions
    from .compiler import compile_files

    conf.settings = None
    conf.init_settings(None)
    assert conf.settings is not None
    assert conf.settings.debug is False
    assert conf.settings.root is None
    assert conf.settings.target is None

    conf.settings = None
    conf.init_settings(None)
    assert conf.settings is not None
    assert conf.settings.debug is False
    assert conf.settings.root is None
    assert conf.settings.target is None

    conf.settings = None
    conf.init_settings(None)
    assert conf.settings is not None
    assert conf.settings.debug is False
    assert conf.settings.root is None
    assert conf.settings.target

# Generated at 2022-06-17 23:46:42.968259
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:43.580876
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.178349
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.681739
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:03.207960
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:03.757482
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:05.748606
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:06.327858
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:12.463849
# Unit test for function main
def test_main():
    # Test 1
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test_out.py', '-t', '3.5']
    assert main() == 0

    # Test 2
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test_out.py', '-t', '3.5', '-r', 'root']
    assert main() == 0

    # Test 3
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test_out.py', '-t', '3.5', '-d']
    assert main() == 0

    # Test 4

# Generated at 2022-06-17 23:47:13.082081
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:13.721337
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:14.234594
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:50.887474
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:51.349162
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:55.523803
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.6']
    assert main() == 0

# Generated at 2022-06-17 23:47:56.052147
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:56.695139
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:57.266378
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:57.802940
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:58.299271
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:58.800929
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:59.299665
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:15.529657
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:26.113544
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o',
                'test/test_files/test_file_out.py', '-t', '2.7', '-r',
                'test/test_files/']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o',
                'test/test_files/test_file_out.py', '-t', '2.7', '-r',
                'test/test_files/']
    assert main() == 0

# Generated at 2022-06-17 23:49:26.610391
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:27.194361
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:27.672364
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:28.147035
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:32.143533
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:49:32.588059
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:49:41.398515
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    main()
    assert open('test/test_files/test_file_out.py').read() == open('test/test_files/test_file_out_expected.py').read()
    os.remove('test/test_files/test_file_out.py')

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:49:41.842684
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:39.834281
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:52:40.263594
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:52:50.382045
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import pytest
    from . import conf

    def _main(input_, output, target, root=None, debug=False):
        sys.argv = ['py-backwards', '-i', input_, '-o', output, '-t', target]
        if root:
            sys.argv.extend(['-r', root])
        if debug:
            sys.argv.append('-d')
        return main()

    def _test_main(input_, output, target, root=None, debug=False):
        conf.init_settings(None)
        return _main(input_, output, target, root, debug)


# Generated at 2022-06-17 23:53:01.101519
# Unit test for function main
def test_main():
    import pytest
    from io import StringIO
    from unittest.mock import patch
    from . import conf
    from . import exceptions

    with patch('sys.stdout', new=StringIO()) as fake_out:
        with pytest.raises(SystemExit) as e:
            main()
        assert e.value.code == 2
        assert 'usage: py-backwards' in fake_out.getvalue()

    with patch('sys.stdout', new=StringIO()) as fake_out:
        with pytest.raises(SystemExit) as e:
            main(['-i', 'a', '-o', 'b', '-t', '3.5'])
        assert e.value.code == 1
        assert 'Input file or folder doesn\'t exists: a' in fake_out.getvalue()



# Generated at 2022-06-17 23:53:06.086347
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '2.7', '-r', 'test/test_input']
    assert main() == 0

# Generated at 2022-06-17 23:53:10.201936
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:53:10.665811
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:13.346660
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '3.5', '-r', '.']
    assert main() == 0

# Generated at 2022-06-17 23:53:14.912480
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:15.534304
# Unit test for function main
def test_main():
    assert main() == 0