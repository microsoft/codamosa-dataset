

# Generated at 2022-06-17 23:46:24.292605
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:24.616134
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:25.799417
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:26.206194
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:33.814098
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = [sys.argv[0], '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '2.7', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:46:35.290701
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:40.467123
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:46:41.036215
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:41.593844
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:42.173541
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.601355
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-17 23:47:08.222879
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test.py', '-o', 'tests/test_files/test_out.py', '-t', '3.5', '-r', 'tests/test_files']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:47:19.276041
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_file.py', '-o', 'test/test_data/test_file_out.py', '-t', '2.7', '-r', 'test/test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_data/test_file.py', '-o', 'test/test_data/test_file_out.py', '-t', '2.7', '-r', 'test/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:47:20.097110
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:31.377234
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test']
    assert main() == 0

# Generated at 2022-06-17 23:47:32.391253
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:32.915139
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:33.434717
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:33.941424
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:34.450905
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:15.228616
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:15.730079
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:16.243133
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:16.731317
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:17.459759
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:22.440700
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5', '-r', 'tests/test_files']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:48:27.452200
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input', '-o', 'test/test_output', '-t', '2.7', '-r', 'test/test_input']
    assert main() == 0

# Generated at 2022-06-17 23:48:28.547253
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:29.110711
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:34.891715
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:50:00.643288
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:10.757622
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test/test_input.py']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test/test_input.py']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test/test_input.py']

# Generated at 2022-06-17 23:50:11.531042
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:12.396205
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:13.411221
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:14.149356
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:16.547659
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:27.612434
# Unit test for function main
def test_main():
    sys.argv = [
        'py-backwards',
        '-i', 'test/test_data/test_input.py',
        '-o', 'test/test_data/test_output.py',
        '-t', '3.5',
        '-r', 'test/test_data'
    ]
    assert main() == 0
    sys.argv = [
        'py-backwards',
        '-i', 'test/test_data/test_input.py',
        '-o', 'test/test_data/test_output.py',
        '-t', '3.5',
        '-r', 'test/test_data'
    ]
    assert main() == 0

# Generated at 2022-06-17 23:50:28.120733
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:28.805737
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:31.472255
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:31.927256
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:32.308075
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:32.673420
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:33.146898
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:33.519705
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:33.898475
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:38.551686
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test.py', '-o', 'test/test_files/test_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:53:39.024370
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:45.699141
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o',
                'test/test_files/test_file_out.py', '-t', '3.5', '-r',
                'test/test_files']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())