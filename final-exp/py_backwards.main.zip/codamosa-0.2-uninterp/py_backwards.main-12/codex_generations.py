

# Generated at 2022-06-17 23:46:17.159076
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:17.634289
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:18.120280
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:18.613744
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:21.452390
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o',
                'test/test_files/test_file_out.py', '-t', '3.5', '-r',
                'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:46:27.182944
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_input.py', '-o', 'test/test_output.py', '-t', '3.5', '-r', 'test']
    assert main() == 0

# Generated at 2022-06-17 23:46:27.726592
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:28.206304
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:28.686672
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:29.173016
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:47.836953
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:48.315717
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:50.280070
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:46:53.928250
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test_file.py', '-o', 'test_data/test_file_out.py', '-t', '2.7', '-r', 'test_data']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:46:54.598268
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:01.579225
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test_data/test_input.py', '-o', 'test_data/test_output.py', '-t', '3.5', '-r', 'test_data', '-d']
    assert main() == 0

# Generated at 2022-06-17 23:47:02.178254
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:02.682205
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:03.207761
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:03.754904
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:49.669304
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import pytest
    from . import utils

    def _test_main(input_, output, target, root, debug, expected_result):
        args = ['-i', input_, '-o', output, '-t', target]
        if root:
            args.extend(['-r', root])
        if debug:
            args.append('-d')
        args = parser.parse_args(args)
        init_settings(args)
        try:
            result = compile_files(input_, output,
                                   const.TARGETS[target],
                                   root)
        except exceptions.CompilationError as e:
            result = messages.syntax_error(e)
        except exceptions.TransformationError as e:
            result = messages.transformation

# Generated at 2022-06-17 23:47:50.090158
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:50.512897
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:51.067831
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:51.654767
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:47:57.561109
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'tests/test_files/test_file.py', '-o', 'tests/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:48:00.598461
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5']
    assert main() == 0

# Generated at 2022-06-17 23:48:01.065842
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:01.557623
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:02.046553
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:39.265997
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:39.815145
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:40.288660
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:40.762041
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:48.406347
# Unit test for function main
def test_main():
    # Test 1
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '2.7']
    assert main() == 0

    # Test 2
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '2.7']
    assert main() == 0

    # Test 3
    sys.argv = ['py-backwards', '-i', 'test.py', '-o', 'test.py', '-t', '2.7']
    assert main() == 0

    # Test 4

# Generated at 2022-06-17 23:48:48.966221
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:53.061389
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file_out.py', '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:48:53.722862
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:54.291171
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:48:55.482136
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 23:50:21.708164
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-17 23:50:22.234134
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:22.716329
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:32.358737
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import subprocess

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = os.path.join(temp_dir, 'test.py')
    with open(temp_file, 'w') as f:
        f.write('print(f"Hello {name}")')

    # Create temporary output directory
    temp_output_dir = os.path.join(temp_dir, 'output')
    os.mkdir(temp_output_dir)

    # Run py-backwards
    subprocess.run(['py-backwards', '-i', temp_file, '-o', temp_output_dir,
                    '-t', '3.5', '-r', temp_dir])

    # Check if

# Generated at 2022-06-17 23:50:32.956681
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:33.455525
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:34.699610
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:35.255470
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:50:44.736054
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py',
                '-o', 'test/test_files/test_file_output.py',
                '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py',
                '-o', 'test/test_files/test_file_output.py',
                '-t', '3.5', '-r', 'test/test_files']
    assert main() == 0

# Generated at 2022-06-17 23:50:54.169660
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_data/test.py', '-o', 'test/test_data/test_out.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0
    sys.argv = ['py-backwards', '-i', 'test/test_data/test.py', '-o', 'test/test_data/test_out.py', '-t', '3.5', '-r', 'test/test_data']
    assert main() == 0

# Generated at 2022-06-17 23:53:58.648649
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:59.135885
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:53:59.638358
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:01.781888
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:02.320597
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:02.826821
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:03.309249
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:03.808359
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:04.248930
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-17 23:54:09.936582
# Unit test for function main
def test_main():
    sys.argv = ['py-backwards', '-i', 'test/test_files/test_file.py', '-o', 'test/test_files/test_file.py', '-t', '2.7', '-r', 'test/test_files/']
    assert main() == 0

if __name__ == '__main__':
    sys.exit(main())