

# Generated at 2022-06-22 22:33:07.843586
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_classes = []
    namespace = 'ansible'
    filter_spec = []

    fact_collector = \
        AnsibleFactCollector(collectors=collector_classes,
                             filter_spec=filter_spec,
                             namespace=namespace)

    assert fact_collector.collector_classes == collector_classes
    assert fact_collector.namespace == namespace
    assert fact_collector.filter_spec == filter_spec

# Generated at 2022-06-22 22:33:13.796317
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = ['network', 'hardware', 'virtual']
    namespace = 'test_namespace'

    def test_obj():
        return CollectorMetaDataCollector(collectors=all_collector_classes,
                                          namespace=namespace,
                                          gather_subset='all',
                                          module_setup=True)

    obj = test_obj()
    assert obj.gather_subset == 'all'
    assert obj.module_setup == True
    assert obj.collectors == all_collector_classes
    assert obj.namespace == namespace

# Generated at 2022-06-22 22:33:24.219786
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_distribution_facts
    from ansible.module_utils.facts import ansible_distribution_version_facts
    from ansible.module_utils.facts import ansible_env_facts
    from ansible.module_utils.facts import ansible_system_facts
    from ansible.module_utils.facts import ansible_date_time_facts
    from ansible.module_utils.facts import ansible_hardware_facts
    from ansible.module_utils.facts import ansible_hostname_facts
    from ansible.module_utils.facts import ansible_interfaces_facts
    from ansible.module_utils.facts import ansible_kernel_facts
    from ansible.module_utils.facts import ansible_machine_id_facts

# Generated at 2022-06-22 22:33:28.383133
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all',
                                                               module_setup=True)

    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': 'all', 'module_setup': True}


# Generated at 2022-06-22 22:33:34.991613
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts
    all_collector_classes = \
        ansible.module_utils.facts.collectors.__dict__.values()

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=[],
                                           gather_timeout=None,
                                           minimal_gather_subset=frozenset())

    assert fact_collector is not None


if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-22 22:33:42.996425
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.text_file
    import ansible.module_utils.facts.namespace

    text_file_collector = ansible.module_utils.facts.collector.text_file.TextFileFactCollector()

    collector = \
        AnsibleFactCollector(collectors=[text_file_collector],
                             filter_spec=['*'],
                             namespace=ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_'))

    facts = collector.collect()

    assert len(facts) > 0

# Generated at 2022-06-22 22:33:52.532869
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import unittest

    class TestCollectorMetaDataCollector(unittest.TestCase):
        '''Unit tests for method collect of class CollectorMetaDataCollector.'''

        def test_concrete_collector_class(self):
            collector_classes = \
                [CollectorMetaDataCollector, CollectorMetaDataCollector]
            from ansible.module_utils.facts import ansible_collector
            fact_collector = \
                ansible_collector.get_ansible_collector(all_collector_classes=collector_classes)
            facts = fact_collector.collect(collected_facts=dict())
            self.assertIn('ansible_facts', facts)
            # self.assertIn('gather_subset', facts['ansible_facts'])
            # self.assertIn('module_setup', facts

# Generated at 2022-06-22 22:33:59.734050
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # GIVEN an AnsibleFactCollector and a module
    from ansible.module_utils.facts import generic_legacy_facts
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts.virtual import virtualbox

    namespace = None
    filter_spec = []

    collectors = (
        generic_legacy_facts.GenericLegacyFactsCollector(namespace=namespace),
        hardware.HardwareCollector(namespace=namespace),
        virtualbox.VirtualboxCollector(namespace=namespace),
    )

    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          filter_spec=filter_spec,
                                          namespace=namespace)

    # WHEN facts are collected
    facts = fact_collector.collect()

    # THEN facts should be

# Generated at 2022-06-22 22:34:10.218657
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    """Test ansible fact collector constructor"""

    fact_collector = AnsibleFactCollector()
    assert(fact_collector.namespace is None)
    assert(fact_collector.collectors == [])
    assert(fact_collector.filter_spec is None)

    fact_collector = AnsibleFactCollector(collectors=['test_collector'],
                                          namespace='test_namespace',
                                          filter_spec=['test_filter'])
    assert(fact_collector.namespace == 'test_namespace')
    assert(fact_collector.collectors == ['test_collector'])
    assert(fact_collector.filter_spec == ['test_filter'])

# Generated at 2022-06-22 22:34:18.913467
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Fact collectors that always return the same value for any namespace
    class DummyFactCollector1(collector.BaseFactCollector):
        name = 'test_fact1'
        _fact_ids = set([])
        def collect(self, module=None, collected_facts=None):
            return {'test_fact1': 'test_fact1'}
    class DummyFactCollector2(collector.BaseFactCollector):
        name = 'test_fact2'
        _fact_ids = set([])
        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_fact2'}
    # Fact collector that returns different values depending on the namespace
    class DummyFactCollector3(collector.BaseFactCollector):
        name = 'test_fact3'


# Generated at 2022-06-22 22:34:30.609794
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    namespace = 'test'
    filter_spec = ['fact_a', 'fact_b']
    gather_subset = ['!all', '!fact_c']  # this will resolve to ['fact_a', 'fact_b']
    gather_timeout = 10

    def fake_collect_with_namespace(module=None, collected_facts=None):
        return {'fact_a': 'fact_a_value',
                'fact_b': 'fact_b_value',
                'fact_c': 'fact_c_value'}

    class FakeCollector(object):
        def __init__(self, namespace=None, gather_subset=None, gather_timeout=None, filter_spec=None):
            self.ns = namespace
            self.gather_subset = gather_subset
            self.gather_timeout

# Generated at 2022-06-22 22:34:36.741061
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemCollector

    system_collector = SystemCollector()
    fact_collector = AnsibleFactCollector(system_collector)
    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'system' in facts['ansible_facts']
    assert 'distribution' in facts['ansible_facts']


# Generated at 2022-06-22 22:34:47.054267
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Test function get_ansible_collector() with minimal set of collectors.'''

    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    class MockFactCollector(collector.BaseFactCollector):
        '''Mock Collectors that always return mock facts.'''

        name = 'test'
        _fact_ids = set([])

        def __init__(self, namespace):
            super(MockFactCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            # Suppress missing argument error.
            if module is None or collected_facts is None:
                return {}
            return {self.name: '%s_value' % self.name}


# Generated at 2022-06-22 22:34:59.234535
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):
        name = 'Test'

        def collect(self, module=None, collected_facts=None):
            return {'key': 'value'}

    test_collector = TestCollector()
    test_fact_collector = AnsibleFactCollector(collectors=[test_collector])

    expected = {u'ansible_facts': {u'key': u'value'}}
    actual = test_fact_collector.collect()

    assert actual == expected
    # now test when you override namespace
    test_fact_collector = AnsibleFactCollector(collectors=[test_collector],
                                               namespace=collector.PrefixFactNamespace(prefix='ansible_'))
    actual = test_fact_collector.collect()

    assert actual == expected




# Generated at 2022-06-22 22:35:09.684842
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_1 = collector.BaseFactCollector(namespace=None)
    collector_2 = collector.BaseFactCollector(namespace='example')
    collectors = [collector_1, collector_2]
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          namespace=None,
                                          filter_spec=None)

    expected_result = 'foo'
    expected_result_with_namespace = 'example.foo'
    def mock_collect(self, module=None, collected_facts=None):
        return {'foo': 'foo'}
    collector_1.collect = mock_collect
    collector_2.collect = mock_collect
    actual_result = fact_collector.collect()
    assert actual_result == {'foo': expected_result}
    actual_result = fact_

# Generated at 2022-06-22 22:35:19.572190
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    all_collector_classes = []

    gather_subset = None
    module_setup = None
    meta_collector = CollectorMetaDataCollector(collectors=None,
                                                namespace=None,
                                                gather_subset=gather_subset,
                                                module_setup=module_setup)
    meta_facts = meta_collector.collect(module=None, collected_facts=None)
    assert meta_facts['gather_subset'] == ['all']
    assert meta_facts['module_setup'] is True

    gather_subset = 'network'
    module_setup = False

# Generated at 2022-06-22 22:35:31.395776
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    ns = PrefixFactNamespace(prefix='ansible_')

    c1 = collector.FacterCollector()
    c1.name = 'c1'
    c2 = collector.FacterCollector()
    c2.name = 'c2'
    c3 = collector.FacterCollector()
    c3.name = 'c3'

    collectors = [c1, c2]
    filters = ['c1', 'c3']
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          namespace=ns,
                                          filter_spec=filters)

    print(fact_collector)

    # We expect the namespace to have not been modified since it is a PrefixFactNamespace

# Generated at 2022-06-22 22:35:38.154739
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['a','b','c'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['a', 'b', 'c'], 'module_setup': True}


# Generated at 2022-06-22 22:35:46.413890
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.collector

    try:
        # This is a function defined in ansible.module_utils.facts.system.distribution which is
        # used in the default gather_subset for FactsCollector.  It should not be called since
        # it does not appear in the minimal_gather_subset used as input to get_ansible_collector.
        ansible.module_utils.facts.system.distribution.collect_distribution_facts()
    except Exception as e:
        pass
    else:
        assert False==True, 'collect_distribution_facts() should not have been called'

    gather_subset = ['all', 'network']
    minimal_gather_subset = ['!all', '!network']

   

# Generated at 2022-06-22 22:35:55.158378
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['network'],
                                   module_setup=True)
    
    assert isinstance(collector_meta_data_collector, NetworkCollector)
    assert collector_meta_data_collector.name == 'gather_subset'
    assert collector_meta_data_collector._fact_ids == set([])
    assert collector_meta_data_collector.namespace is None
    assert collector_meta_data_collector.gather_subset == ['network']
    assert collector_meta_data_collector.module_setup == True



# Generated at 2022-06-22 22:36:05.541366
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Test using no namespace
    fact_collector = \
        AnsibleFactCollector(collectors=[],
                             filter_spec=None,
                             namespace=None)
    assert fact_collector.collect() == {}

    # Test using None namespace
    fact_collector = \
        AnsibleFactCollector(collectors=[],
                             filter_spec=None,
                             namespace=None)
    assert fact_collector.collect() == {}

    # Test using an empty namespace
    fact_collector = \
        AnsibleFactCollector(collectors=[],
                             filter_spec=None,
                             namespace=collector.EmptyFactNamespace())
    assert fact_collector.collect() == {}

    # Test using a prefixing namespace
    ns = collector.PrefixFactNamespace(prefix='ansible_')


# Generated at 2022-06-22 22:36:13.125166
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import internal_dict_facts

    fact_collector = \
        get_ansible_collector(all_collector_classes=internal_dict_facts.__fact_classes__,
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)

    assert len(fact_collector.collectors) == len(internal_dict_facts.__fact_classes__) + 1

    collected_facts = fact_collector.collect()
    assert 'gather_subset' in collected_facts
    assert 'module_setup' in collected_facts
    assert 'module_setup_warnings' in collected_facts

# Generated at 2022-06-22 22:36:22.329128
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gather_subset = ['all','network','hardware']
    module_setup = True

    # Test for all values as expected
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset,
                                                               module_setup=module_setup)

    result = collector_meta_data_collector.collect()
    assert result['gather_subset'] == gather_subset
    assert result['module_setup'] == module_setup
    assert len(result) == 2

    # Test for expected values but missing a dictionary entry
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset,
                                                               module_setup=None)

    result = collector_meta_data_collector.collect()

# Generated at 2022-06-22 22:36:27.841522
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    fact_collector = CollectorMetaDataCollector(gather_subset=['all'])
    module = {}
    collected_facts = {}

    result = fact_collector.collect(module, collected_facts)
    assert result['gather_subset'] == ['all']
    assert result['module_setup'] is True


# Generated at 2022-06-22 22:36:35.085484
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai

    # get_ansible_collector only needs to be tested for the minimal subset
    # as what it does is just ask all the collector classes for their
    # gather_subset, and include with the minimal subset, and form that
    # collection we want to include in our fact gathering.

    # So we do htat here, and the minimal subset is 'all' and we want to
    # include all collectors, and we are testing for that.

# Generated at 2022-06-22 22:36:40.114147
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=["all"], module_setup=True)
    fact_collector.collect(module=None, collected_facts=None) == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:36:47.623155
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.service import ServiceDiscoveryFactCollector

    service_collector = ServiceDiscoveryFactCollector()
    network_collector = NetworkCollector(namespace=PrefixFactNamespace(prefix='ansible_'))

    fact_collector = AnsibleFactCollector(collectors=[service_collector, network_collector])
    facts_dict = fact_collector.collect()
    print(facts_dict)


if __name__ == '__main__':
    sys.path.append('/home/vagrant')
    test_AnsibleFactCollector()

# Generated at 2022-06-22 22:36:56.403486
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    # Test with None
    mmc = CollectorMetaDataCollector()
    assert mmc.gather_subset is None
    assert mmc.module_setup is None

    # Test with empty string
    mmc = CollectorMetaDataCollector(gather_subset='')
    assert mmc.gather_subset == ''
    assert mmc.module_setup is None

    # Test with gather_subset
    mmc = CollectorMetaDataCollector(gather_subset=['network', 'interfaces'])
    assert mmc.gather_subset == ['network', 'interfaces']
    assert mmc.module_setup is None

    # Test with gather_subset and module_setup

# Generated at 2022-06-22 22:37:08.541660
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    namespaces = [namespace.PrefixFactNamespace(prefix='a_'),
                  namespace.PrefixFactNamespace(prefix='b_')]

    fact_collector = AnsibleFactCollector(collectors=[],
                                          namespace=namespaces,
                                          filter_spec='a_*')

    test_facts = {'a_aaa': 'aaa',
                  'a_bbb': 'bbb',
                  'a_ccc': 'ccc',
                  'a_ddd': 'ddd',
                  'a_abc': 'abc',
                  'b_bbb': 'bbb',
                  'b_ccc': 'ccc',
                  'b_ddd': 'ddd',
                  'b_abc': 'abc'}

    filtered_facts

# Generated at 2022-06-22 22:37:18.010139
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = \
        list(collector.get_collector_classes(fact_source_modules=default_collectors.DEFAULT_FACT_SOURCES))
    sas = set(['all'])
    mgs = frozenset()

    # Basic case
    ac1 = get_ansible_collector(all_collector_classes=all_collector_classes,
                                gather_subset=sas,
                                minimal_gather_subset=mgs)

    assert(len(ac1.collectors) == len(all_collector_classes) + 1)

    # Test with a non-default namespace
    from ansible.module_utils.facts import namespace

# Generated at 2022-06-22 22:37:21.968362
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # A gather_subset is empty
    result = CollectorMetaDataCollector(gather_subset=[])
    assert result.gather_subset == []
    # A gather_subset is not empty
    result = CollectorMetaDataCollector(gather_subset=['all'])
    assert result.gather_subset == ['all']


# Generated at 2022-06-22 22:37:31.646031
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Test constructor of class AnsibleFactCollector.'''
    # test invalid argument
    invalid_collectors_stmt = 'invalid_collectors_stmt'
    invalid_namespace_stmt = 'invalid_namespace_stmt'
    invalid_filter_spec_stmt = 'invalid_filter_spec_stmt'

    with pytest.raises(TypeError):
        AnsibleFactCollector(collectors=invalid_collectors_stmt,
                             namespace=invalid_namespace_stmt,
                             filter_spec=invalid_filter_spec_stmt)
    # the test passes if no exception is raised during the above statement

# Generated at 2022-06-22 22:37:37.728154
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector = CollectorMetaDataCollector(
        ['all'],
        None,
        True,
        False
    )

    results = collector.collect()

    assert 'gather_subset' in results
    assert results['gather_subset'] == ['all']
    assert 'module_setup' in results
    assert results['module_setup'] == False

# Generated at 2022-06-22 22:37:41.072876
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    assert collector_meta_data_collector.gather_subset == ['all']


# Generated at 2022-06-22 22:37:46.883029
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector = CollectorMetaDataCollector(gather_subset='foo',
                                           module_setup=True)
    facts = collector.collect()
    assert isinstance(facts, dict)
    assert 'gather_subset' in facts
    assert 'module_setup' in facts
    assert facts['gather_subset'] == 'foo'
    assert facts['module_setup'] is True

# Generated at 2022-06-22 22:37:55.163448
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import cache as fact_cache
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local_facts

    fact_cache.FACT_CACHE = {}

    namespace_obj = namespaces.PrefixFactNamespace(prefix='ansible_', separator='_')

    gather_subset = ['all', 'network']

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=True,
                                   namespace=namespace_obj)



# Generated at 2022-06-22 22:38:02.749284
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = \
        AnsibleFactCollector(collectors=None,
                             filter_spec=None,
                             namespace=None)

    # confirm that this is an instance of AnsibleFactCollector
    assert isinstance(fact_collector, AnsibleFactCollector)

    # confirm that this is an instance of BaseFactCollector
    assert isinstance(fact_collector, collector.BaseFactCollector)

    # confirm that this is an instance of a FactCollector
    assert isinstance(fact_collector, collector.FactCollector)

# Generated at 2022-06-22 22:38:14.281232
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.platform.base import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import UbuntuFactCollector
    from ansible.module_utils.facts.system.distribution import SysVInitFactCollector
    from ansible.module_utils.facts.system.distribution import SystemdFactCollector


# Generated at 2022-06-22 22:38:15.122223
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-22 22:38:18.279047
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Can't instantiate because BaseFactCollector() needs a module parameter
    # ansible_fact_collector = AnsibleFactCollector()
    pass

# Generated at 2022-06-22 22:38:26.845854
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''
    Test the constructor for AnsibleFactCollector
    '''

    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts import network

    collectors = [cache.CacheCollector(namespace=namespace),
                  network.NetworkCollector(namespace=namespace)]
    namespace = namespaces.PrefixFactNamespace(prefix='ansible_')

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=namespace)

    assert fact_collector.namespace == namespace
    assert fact_collector.collectors == collectors

# Generated at 2022-06-22 22:38:29.485309
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    filter_spec = filter_spec or []
    namespace = namespace or 'ansible'

    assert isinstance(filter_spec, list)
    assert is_string(namespace)

# Generated at 2022-06-22 22:38:40.196721
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    test_collector = collector.FacterCollector()
    test_filter_spec = ['ansible_hostname', 'ansible_os', 'facter_os']
    ansible_collector = AnsibleFactCollector(test_collector, filter_spec=test_filter_spec)
    assert 'facter_os' in ansible_collector.filter_spec, 'test_AnsibleFactCollector failed'
    assert 'ansible_os' in ansible_collector.filter_spec, 'test_AnsibleFactCollector failed'
    assert 'ansible_hostname' in ansible_collector.filter_spec, 'test_AnsibleFactCollector failed'
    assert 'facter_os_family' not in ansible_collector.filter_spec, 'test_AnsibleFactCollector failed'
   

# Generated at 2022-06-22 22:38:43.562873
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'])
    assert collector_meta_data_collector.gather_subset == ['all']

# Generated at 2022-06-22 22:38:53.578950
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector, NamespacePrefixFactCollector, NetworkFactCollector, PlatformFactCollector
    from ansible.module_utils.facts.collector import LocalFactsCollector, DistroFactsCollector, HardwareFactsCollector, VirtualFactsCollector, SELinuxFactsCollector, PackageManagerFactsCollector

    collector1 = BaseFactCollector(namespace=NamespacePrefixFactCollector(prefix='ansible_'))
    collector2 = BaseFactCollector(namespace=NamespacePrefixFactCollector(prefix='ansible_'))
    collector3 = BaseFactCollector(namespace=NamespacePrefixFactCollector(prefix='ansible_'))

# Generated at 2022-06-22 22:39:01.243041
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.base

    # Use base class to simulate a setup
    all_collector_classes = ansible.module_utils.facts.collector.base.BaseFactCollector.classes()

    # Test facts
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    facts_dict = fact_collector.collect()
    assert 'ansible_facts' in facts_dict
    assert 'gather_subset' in facts_dict['ansible_facts']
    assert 'module_setup' in facts_dict['ansible_facts']
    assert facts_dict['ansible_facts']['gather_subset'] == ['all']
    assert facts_dict['ansible_facts']['module_setup'] is True

   

# Generated at 2022-06-22 22:39:11.102102
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # mock classes
    class Collector1(object):
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'a': '1', 'b': '2'}

    class Collector2(object):
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'c': '3', 'd': '4'}

    # mock object
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collectors = [Collector1(), Collector2()]
    ansible_fact_collector.namespace = 'ansible'

    # test default

# Generated at 2022-06-22 22:39:23.575406
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # NOTE: This may not be the most efficient way to unit test this function, but it
    # seems to work
    ansible_collector = get_ansible_collector(all_collector_classes=collector.collector_classes(),
                                              gather_subset=['all'])
    local_collectors = ansible_collector.collectors
    assert len(local_collectors) == len(collector.collector_classes())

    ansible_collector = get_ansible_collector(all_collector_classes=collector.collector_classes(),
                                              gather_subset=['network', 'virtual'])
    local_collectors = ansible_collector.collectors
    assert len(local_collectors) == len(collector.collector_classes())

    ansible_collector = get_

# Generated at 2022-06-22 22:39:29.296683
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    expected_gather_subset = ['all']
    expected_module_setup = True
    meta_data_collector = CollectorMetaDataCollector(gather_subset=expected_gather_subset,
                                                     module_setup=expected_module_setup)
    actual_gather_subset = meta_data_collector.collect()['gather_subset']
    actual_module_setup = meta_data_collector.collect()['module_setup']
    assert actual_gather_subset == expected_gather_subset
    assert actual_module_setup == expected_module_setup


# Generated at 2022-06-22 22:39:35.833683
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes = []
    fact_collector = get_ansible_collector(all_collector_classes)
    assert fact_collector is not None
    assert isinstance(fact_collector, AnsibleFactCollector)

    # NOTE: This is not testing full functionality, but it at least tests that we can call
    # the top level get_ansible_collector and collect facts.
    facts_dict = fact_collector.collect()
    assert 'gather_subset' in facts_dict



# Generated at 2022-06-22 22:39:39.358341
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'])
    assert fact_collector.gather_subset == ['all']

# Generated at 2022-06-22 22:39:49.577573
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    namespace = collector.FactNamespace()
    gather_subset = 'all'
    module_setup = True

    fact_collector = CollectorMetaDataCollector(gather_subset=gather_subset,
                                                namespace=namespace,
                                                module_setup=module_setup)

    assert fact_collector.name == 'gather_subset'
    assert fact_collector.gather_subset == 'all'
    assert fact_collector.module_setup == True

    assert fact_collector.namespace.get_prefix() == ''
    assert fact_collector.namespace.get_sep() == '_'


# Generated at 2022-06-22 22:39:58.737273
# Unit test for function get_ansible_collector

# Generated at 2022-06-22 22:40:10.821387
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    AnsibleCollector = get_ansible_collector()

    # test data is a dict of dict
    test_data = {'ansible_facts': {'os': 'Linux', 'facter': {'netmask': ''}}}

    # get_ansible_collector returns AnsibleFactCollector object
    assert isinstance(AnsibleCollector, collector.BaseFactCollector)

    # use this to collect all facts
    collected_facts = AnsibleCollector.collect()

    # use this to collect facts filtered by ansible_
    masked_facts = AnsibleCollector.collect(filter_spec='ansible_*')

    # check to see if os facts included in collected_facts
    assert isinstance(collected_facts, dict)
    assert 'os' in collected_facts['ansible_facts']

# Generated at 2022-06-22 22:40:14.521875
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    module = AnsibleFactCollector()
    result = CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True).collect(module)
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:40:25.673149
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    class dummy_collector(collector.BaseFactCollector):
        name = 'dummy'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return collected_facts

    collector_classes = [dummy_collector]
    collector_meta_data_collector = CollectorMetaDataCollector(collector_classes, namespace="ansible_test", gather_subset='network')
    assert collector_meta_data_collector.collect() == {'gather_subset': 'network'}
    collector_meta_data_collector = CollectorMetaDataCollector(collector_classes, namespace="ansible_test", gather_subset='network', module_setup=False)

# Generated at 2022-06-22 22:40:34.845962
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    class Collectors(object):
        name = 'test_collectors'
        def __init__(self):
            self.namespace = 'test_namespace'
    collector_obj = Collectors()
    fact_collector = \
        AnsibleFactCollector(collectors=[collector_obj],
                             namespace=collector_obj.namespace)

    assert(collector_obj.name == 'test_collectors')
    assert(collector_obj.namespace == 'test_namespace')
    assert(fact_collector.collectors[0] == collector_obj)
    assert(fact_collector.namespace == 'test_namespace')



# Generated at 2022-06-22 22:40:44.119418
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import mock
    from ansible.module_utils.facts import ansible_collector

    collector_mock1 = mock.Mock()
    collector_mock2 = mock.Mock()
    collector_mock1.name = 'collector_mock1'
    collector_mock2.name = 'collector_mock2'

    collector_mock1.collect = mock.Mock()
    collector_mock2.collect = mock.Mock()
    collector_mock1.collect.return_value = {'a': '1'}
    collector_mock2.collect.return_value = {'b': '2', 'c': '3'}


# Generated at 2022-06-22 22:40:49.694618
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # pylint: disable=protected-access
    subset_names = ['all', 'network', 'identity']
    modules_setup = True
    collector = CollectorMetaDataCollector(gather_subset=subset_names,
                                           module_setup=modules_setup)
    assert collector._fact_ids == set(['gather_subset', 'module_setup'])

# Generated at 2022-06-22 22:40:57.995464
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_metadata_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                              module_setup=True)
    facts_dict = collector_metadata_collector.collect(module=None, collected_facts=None)
    expected_facts_dict = {u'gather_subset': [u'all'], u'module_setup': True}
    assert facts_dict == expected_facts_dict



# Generated at 2022-06-22 22:40:59.111865
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    f = AnsibleFactCollector()

# Generated at 2022-06-22 22:41:09.041940
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.plugins.action.network
    import ansible.plugins.action.setup
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible.plugins.action.script
    import ansible.plugins.action.free_form
    import ansible.plugins.action.copy
    import ansible.plugins.action.template
    import ansible.plugins.action.slurp
    import ansible.plugins.action.uri
    import ansible.plugins.action.fetch
    import ansible.plugins.action.setup_term
    import ansible.plugins.action.meta

    import ansible.module_utils.facts.default_collectors
    import ansible.module_utils.facts.network.default
    import ansible.module_utils.facts.hardware.default

# Generated at 2022-06-22 22:41:17.490125
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import default

    minimal_gather_subset = frozenset()
    all_collector_classes = {'default': default.Default,
                             'hardware': hardware.Hardware,
                             'network': None}

    ansible_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                              minimal_gather_subset=minimal_gather_subset,
                                              gather_subset=['all'])
    assert len(ansible_collector.collectors) == 2


# Generated at 2022-06-22 22:41:18.457809
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    pass


# Generated at 2022-06-22 22:41:29.409039
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import processor
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    prefix = 'test_prefix_'
    namespace = PrefixFactNamespace(prefix=prefix)

    # Initialize with an empty cache and whitelist of fact_ids
    f = processor.Facts(cache=cache.FactCache(cache_file=None),
                        whitelist_externals=[],
                        collectors_classes=[])

    all_collector_classes = f.collector_classes
    sample_gather_subset = ["test_test_test"]
    sample_filter_spec = ""
    sample_minimal_gather_subset = frozenset()
    sample_gather_timeout = 0

    # Get the collector


# Generated at 2022-06-22 22:41:35.425126
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gather_subset = ['all']
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset,
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts['gather_subset'] == gather_subset
    assert meta_facts['module_setup'] == True

# Generated at 2022-06-22 22:41:40.321308
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_obj = CollectorMetaDataCollector(gather_subset=['all'])
    result = collector_obj.collect()
    assert len(result.keys()) == 2
    assert 'gather_subset' in result.keys()
    assert 'module_setup' in result.keys()


# Generated at 2022-06-22 22:41:45.740362
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset=['all'],
        module_setup=False
    )
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': False}

# Generated at 2022-06-22 22:41:54.666190
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    class FakeNamespace(object):
        def __init__(self, prefix):
            self.prefix = prefix

        def get_prefix(self):
            return self.prefix

        def get_name(self):
            return self.prefix

    class FakeCollector(object):
        def __init__(self, collectors=None, namespace=None, filter_spec=None):

            super(FakeCollector, self).__init__(collectors=collectors,
                                                namespace=namespace)

            self.filter_spec = filter_spec

        def collect(self, module=None, collected_facts=None):

            return {}

    namespace = FakeNamespace('ansible_')
    collectors = None
    filter_spec = None

# Generated at 2022-06-22 22:42:01.886490
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    m = MockModule()
    namespace = collector.DictFactNamespace(name='some_namespace')
    c0 = MockFactCollector()
    c1 = MockFactCollector(extra_facts={'a': 'A', 'b': 'B'})
    fact_collector = AnsibleFactCollector(collectors=[c0, c1], namespace=namespace)
    assert fact_collector.collect(module=m) == {'a': 'A', 'b': 'B'}



# Generated at 2022-06-22 22:42:04.978587
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector('', '')
    assert collector_meta_data_collector.collect() == {'gather_subset': '',
                                                       'module_setup': True}

    collector_meta_data_collector2 = CollectorMetaDataCollector('test', 'test')
    assert collector_meta_data_collector2.collect() == {'gather_subset': 'test',
                                                        'module_setup': True}

# Generated at 2022-06-22 22:42:14.889155
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    facts_dict = {}

    # Test to make sure params are set according to the constructor
    collector_obj = AnsibleFactCollector(filter_spec=['test_collector'])
    assert collector_obj.collectors == []
    assert collector_obj.filter_spec == ['test_collector']

    # Test to make sure facts are collected under ansible_facts
    collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector()])
    assert collector.collect(module=None, collected_facts=None) == facts_dict



# Generated at 2022-06-22 22:42:27.313450
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # pylint: disable=redefined-outer-name

    class TestFact(object):
        def __init__(self, fact):
            self.name = fact
            self.fact = fact

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {self.fact: self.fact}

    class TestFactCollector(collector.BaseFactCollector):

        def __init__(self, collectors=None, namespace=None, filter_spec=None):
            super(TestFactCollector, self).__init__(collectors=collectors,
                                                    namespace=namespace)

            self._fact_ids = set(['test_fact_a', 'test_fact_b'])


# Generated at 2022-06-22 22:42:36.127894
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_namespace = PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=fact_namespace)

    assert fact_collector.namespace
    assert isinstance(fact_collector.namespace, PrefixFactNamespace)
    assert 'prefix' in fact_collector.namespace.kwargs
    assert fact_collector.namespace.kwargs['prefix'] == 'ansible_'


# Generated at 2022-06-22 22:42:47.337264
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import unittest2 as unittest
    from ansible.module_utils.facts import timeout

    class CollectorMetaDataCollectorTest(unittest.TestCase):
        def test_collect_no_gather_subset(self):
            # when
            collector_obj = CollectorMetaDataCollector()
            # then
            self.assertEqual(collector_obj.collect(), {'gather_subset': ['all']})

        def test_collect_with_gather_subset(self):
            # when
            collector_obj = CollectorMetaDataCollector(gather_subset=['test1', 'test2'])
            # then
            self.assertEqual(collector_obj.collect(), {'gather_subset': ['test1', 'test2']})


# Generated at 2022-06-22 22:42:56.375458
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import ansible.module_utils.facts.hardware.system_profiler

    # FactCollector that provides a fact that is a dict and a fact that is a list
    class SubsetCollector(collector.BaseFactCollector):
        name = 'subset'

        _fact_ids = set(['subset_list_fact', 'subset_dict_fact', 'subset_dict_fact_with_no_subset'])

        def collect(self, module=None, collected_facts=None):
            return dict(subset_dict_fact={'subset_key': 'subset_value'},
                        subset_list_fact=[1, 2, 3],
                        subset_dict_fact_with_no_subset={'subset_key': 'subset_value'})


# Generated at 2022-06-22 22:43:03.131502
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_detector

    collectors = collector_detector.get_collectors()

    # gets a CollectorMetaDataCollector for gather_subset=('!all',), filter_spec=None
    fact_collector = get_ansible_collector(collectors,
                                           gather_subset=('!all',),
                                           filter_spec=None)

    assert {'gather_subset': ('!all',)} == fact_collector.collect()

    # gets a CollectorMetaDataCollector for gather_subset=('all',), filter_spec=None
    fact_collector = get_ansible_collector(collectors,
                                           gather_subset=('all',),
                                           filter_spec=None)
