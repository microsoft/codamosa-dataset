

# Generated at 2022-06-22 22:33:02.675479
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    actual = collector_meta_data_collector.collect()
    expected = {'gather_subset': 'all', 'module_setup': True}
    assert actual == expected

# Generated at 2022-06-22 22:33:06.786410
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''
    Test constructor of class AnsibleFactCollector
    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=namespace)
    '''

    collectors = []

    namespace = 'ansible_'

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=namespace)
    assert fact_collector != None

# Generated at 2022-06-22 22:33:14.670120
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    filter_spec = filter_spec or []
    gather_subset = gather_subset or ['all']
    gather_timeout = gather_timeout or timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = minimal_gather_subset or frozenset()

    collector_classes = \
        collector.collector_classes_from_gather_subset(all_collector_classes=collector,
                                                       minimal_gather_subset=minimal_gather_subset,
                                                       gather_subset=gather_subset,
                                                       gather_timeout=gather_timeout)
    collectors = []
    for collector_class in collector_classes:
        collectors.append(collector_class)


# Generated at 2022-06-22 22:33:24.902988
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace

    empty_namespace = namespace.BaseFactNamespace(name='')

    mycollector1 = AnsibleFactCollector(namespace=empty_namespace, filter_spec='*')
    assert mycollector1

    # test __init__ with all args
    mycollector2 = \
        AnsibleFactCollector(collectors=[],
                             namespace=namespace.BaseFactNamespace(name=''),
                             filter_spec='*')
    assert mycollector2

    mycollector3 = AnsibleFactCollector(filter_spec='*')
    assert mycollector3

    mycollector4 = \
        AnsibleFactCollector(collectors=[],
                             filter_spec='*')
    assert mycollector4

    # test __init__ with no args

# Generated at 2022-06-22 22:33:30.465723
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.common.text.converters import to_text
    collector = CollectorMetaDataCollector(gather_subset=['all'],
                                           module_setup=True)
    module = None
    collected_facts = None
    result = collector.collect(module, collected_facts)
    assert result == {'gather_subset': ['all'], 'module_setup': True}, \
        to_text(result)

# Generated at 2022-06-22 22:33:34.392356
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)

    expected_facts = {'gather_subset': ['all'], 'module_setup': True}
    collect_facts = collector_meta_data_collector.collect()

    assert collect_facts == expected_facts

# Generated at 2022-06-22 22:33:40.978298
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.collector import AptFactCollector

    collector_classes = [AptFactCollector]
    collector = get_ansible_collector(all_collector_classes=collector_classes,
                                      gather_subset=['all'])
    assert(collector.collectors[0].__class__ == AptFactCollector)

# Generated at 2022-06-22 22:33:51.012547
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_functions

    get_ansible_collector(
        all_collector_classes=collector_functions,
        namespace=None,
        filter_spec=None,
        gather_subset=frozenset(['all', '!facter']),
        minimal_gather_subset=frozenset(),
        gather_timeout=5
    )
    get_ansible_collector(
        all_collector_classes=collector_functions,
        namespace=None,
        filter_spec=None,
        gather_subset=frozenset(['all', '!facter']),
        minimal_gather_subset=frozenset(),
        gather_timeout=5
    )

# Generated at 2022-06-22 22:33:58.804791
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import TestFactsCollector

    fact_collector = \
        get_ansible_collector(all_collector_classes=default.all_collector_classes,
                              gather_subset='test')
    facts_dict = fact_collector.collect()
    assert 'gather_subset' in facts_dict
    assert 'module_setup' in facts_dict
    assert 'test' in facts_dict

    test_ns = PrefixFactNamespace(prefix='test_', namespace=facts_dict['test'])
    assert test_ns.namespace == TestFactsCollector.collected_facts()


# Generated at 2022-06-22 22:34:02.447095
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector = CollectorMetaDataCollector()
    facts = collector.collect()
    assert 'gather_subset' in facts
    assert facts['gather_subset'] == ['all']

# Generated at 2022-06-22 22:34:10.460355
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace

    collector_mock = collector.BaseFactCollector
    collector_mock.__init__ = lambda self, namespace: None
    collector_mock.collect_with_namespace = lambda self, module=None, collected_facts=None: {'ansible_facts': 'yes'}

    fact_collector = AnsibleFactCollector(collectors=[collector_mock()], namespace=namespace.BaseFactNamespace())
    facts = fact_collector.collect()

    assert facts == {'ansible_facts': 'yes'}

# Generated at 2022-06-22 22:34:19.136095
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import FactNamespace, PrefixFactNamespace
    from ansible.module_utils.facts.collectors.file_facts import FileFactsCollector

    # Test 1
    test_facts_dict = {
        'a': 'A',
        'b': 'B',
        'c': 'C',
        'd': {
            'e': 'E',
            'f': 'F',
            'ansible_g': 'G',
            'h': {
                'i': 'I',
                'j': 'J',
                'k': 'K',
            }
        },
        'l': {
            'm': 'M',
            'n': 'N',
            'o': 'O',
        }
    }

# Generated at 2022-06-22 22:34:24.554388
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    def foo_collector(module, collected_facts):
        return {"foo": "bar"}

    fact_collector = \
        AnsibleFactCollector(collector=[foo_collector], filter_spec=["foo"])
    result = fact_collector.collect()
    assert result == {"foo": "bar"}

# Generated at 2022-06-22 22:34:27.283237
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = \
        CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    fact_collector.collect()

# Generated at 2022-06-22 22:34:37.993168
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import db
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import virtual

    # must be a dict of dicts
    all_collector_classes = {
        'network.NetworkCollector': network.NetworkCollector,
        'cache.CacheCollector': cache.CacheCollector,
        'namespace.NamespaceCollector': namespace.NamespaceCollector,
        'db.DBFactCollector': db.DBFactCollector,
        'hardware.HardwareCollector': hardware.HardwareCollector,
        'virtual.VirtualCollector': virtual.VirtualCollector,
    }

    #

# Generated at 2022-06-22 22:34:45.033238
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class Collect1(collector.BaseFactCollector):
        name = 'collect1'
        _fact_ids = set(['fact1'])

        def collect(self, module=None, collected_facts=None):
            info_dict = {'fact1': 'a'}
            return info_dict

    class Collect2(collector.BaseFactCollector):
        name = 'collect2'
        _fact_ids = set(['fact2'])

        def collect(self, module=None, collected_facts=None):
            info_dict = {'fact2': 'b'}
            return info_dict

    all_collector_classes = [Collect1, Collect2]

    fact_collector = \
        AnsibleFactCollector(collectors=all_collector_classes)

    facts_dict = fact_collector

# Generated at 2022-06-22 22:34:58.054691
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from . import LinuxFactCollector, darwin
    all_collector_classes = [LinuxFactCollector, darwin.DarwinFactCollector]

    ansible_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert ansible_collector.namespace is None
    assert ansible_collector.collectors[-1].name == 'gather_subset'
    assert ansible_collector.collectors[-1].gather_subset is not None
    assert ansible_collector.collectors[-1].module_setup is True

    ansible_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                              namespace='foo')

# Generated at 2022-06-22 22:35:08.830141
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    class dummy_collector(collector.BaseFactCollector):
        name = 'dummy'

    assert CollectorMetaDataCollector(collectors=[dummy_collector(namespace=None)],
                                      gather_subset=['all', 'network'],
                                      module_setup=True).collect()['gather_subset'] == ['all', 'network']

    assert CollectorMetaDataCollector(collectors=[dummy_collector(namespace=None)],
                                      gather_subset=['all', 'network'],
                                      module_setup=False).collect()['gather_subset'] == ['all', 'network']


# Generated at 2022-06-22 22:35:18.740248
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gather_subset = ["min"]
    fc = CollectorMetaDataCollector(gather_subset=gather_subset)
    assert fc is not None
    assert fc.gather_subset is not None
    assert fc.gather_subset == gather_subset
    assert fc.module_setup is None
    facts_dict = fc.collect(None, {})
    assert facts_dict is not None
    assert "gather_subset" in facts_dict
    assert facts_dict['gather_subset'] == gather_subset
    assert "module_setup" not in facts_dict
    gather_subset = ["all"]
    fc = CollectorMetaDataCollector(gather_subset=gather_subset, module_setup=False)
    assert fc is not None
   

# Generated at 2022-06-22 22:35:21.300293
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all')
    assert collector_meta_data_collector.collect()['gather_subset'] == 'all'


# Generated at 2022-06-22 22:35:33.025612
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'foo': 1}
    class TestNamespace(collector.BaseFactNamespace):
        def get_facts(self, collected_facts=None):
            return {'test_namespace_foo': 2}
    class TestFilterSpec(collector.BaseFactNamespace):
        def get_facts(self, collected_facts=None):
            return {'test_filter_spec_foo': 2}
    class TestNoFilterSpec(collector.BaseFactNamespace):
        def get_facts(self, collected_facts=None):
            return {'test_no_filter_spec_foo': 2}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])


# Generated at 2022-06-22 22:35:43.682788
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test for method collect of class CollectorMetaDataCollector'''
    from ansible.module_utils.facts import namespace

    # test default values
    collector = CollectorMetaDataCollector(namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    facts = collector.collect(collected_facts={})

    assert facts == {'gather_subset': 'all', 'module_setup': True}

    # test with custom values
    collector = CollectorMetaDataCollector(namespace=namespace.PrefixFactNamespace(prefix='ansible_'), gather_subset='min', module_setup=False)

    facts = collector.collect(collected_facts={})

    assert facts == {'gather_subset': 'min', 'module_setup': False}

# Generated at 2022-06-22 22:35:44.681795
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    pass

# Generated at 2022-06-22 22:35:54.691714
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    fact_collector = get_ansible_collector(
        all_collector_classes=[
            ansible.module_utils.facts.system.SystemCollector,
            ansible.module_utils.facts.network.NetworkCollector,
            ansible.module_utils.facts.virtual.VirtualCollector,
        ],
        gather_subset=['network'],
        filter_spec=['ansible_eth*'],
        minimal_gather_subset=['all'])

    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'gather_subset' in facts['ansible_facts']
    assert facts

# Generated at 2022-06-22 22:36:05.142647
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
   mapped_collector_classes = {
        'all': [
            collector.PlatformFactCollector,
            collector.DistributionFactCollector,
        ],
        'network': [
            collector.NetworkFactCollector,
            collector.InterfaceFactCollector,
        ]
    }
   all_collector_classes = collector.all_collector_classes(mapped_collector_classes)
   collector = \
      CollectorMetaDataCollector(all_collector_classes,
                                 namespace=None,
                                 gather_subset=['all', 'network'],
                                 module_setup=True)
   meta_facts = collector.collect(module=None, collected_facts={})
   assert 'gather_subset' in meta_facts
   assert 'network' in meta_facts['gather_subset']

# Generated at 2022-06-22 22:36:16.665108
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace

    class TestCollector1(collector.BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['a'])

        def collect(self, module=None, collected_facts=None):
            return {'a': 'a', 'b': 'b'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['c'])

        def collect(self, module=None, collected_facts=None):
            return {'c': 'c', 'd': 'd'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['e'])


# Generated at 2022-06-22 22:36:24.270347
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    fact_collector = \
        AnsibleFactCollector(collectors=[collector_meta_data_collector],
                             filter_spec=[],
                             namespace=None)
    module = None
    collected_facts = None
    fact_collector.collect()

# Generated at 2022-06-22 22:36:32.860518
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.network
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.virtual


# Generated at 2022-06-22 22:36:45.016538
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.package

    # Test with no namespace
    fact_collector = AnsibleFactCollector(collectors=[])
    assert fact_collector.namespace is None

    # Test with a namespace
    fact_namespace = collector.PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(collectors=[],
                                          namespace=fact_namespace)

    assert fact_collector.namespace == fact_namespace

    # Test with collectors specified

# Generated at 2022-06-22 22:36:47.864154
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    try:
        afc = AnsibleFactCollector()
    except Exception as e:
        assert 'at least one collector or namespace is required' in str(e)

# Generated at 2022-06-22 22:36:56.091176
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FakeCollector(collector.BaseFactCollector):
        name = 'fake'
        _fact_ids = set([])

        def __init__(self, *args, **kwargs):
            super(FakeCollector, self).__init__(*args, **kwargs)

        def collect(self, *args, **kwargs):
            return {'fake1': 'fake1', 'fake2': 'fake2'}

    fact_collector = \
        AnsibleFactCollector(collectors=[FakeCollector(),],
                             filter_spec=['fake1', 'fake2'],
                             namespace=None)

    assert fact_collector.collect() == {'fake1': 'fake1', 'fake2': 'fake2'}

# Generated at 2022-06-22 22:37:08.425930
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # make sure we don't do anything special for the 'setup' fact
    setup_fact_data = 'setup_fact_data'

    class DummyCollector(collector.BaseFactCollector):
        name = 'dummy'
        _fact_ids = set(['fact1', 'fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'fact1': 1, 'fact2': 2, 'setup': setup_fact_data}

    dummy_collector = DummyCollector()
    dummy_collector.collect_with_namespace(module=None)

    fact_collector = \
        AnsibleFactCollector(collectors=[dummy_collector],
                             namespace=None)

    facts_dict = fact_collector.collect(module=None)

    assert isinstance

# Generated at 2022-06-22 22:37:18.574809
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts import namespace

    ns = namespace.PrefixNS({}, prefix='')

    # Test that __init__() creates the expected variables
    collector_meta_data_collector = CollectorMetaDataCollector(namespace=ns, gather_subset='all', module_setup=True)
    assert collector_meta_data_collector.gather_subset == 'all'
    assert collector_meta_data_collector.module_setup == True

    # Test that collect() creates the expected dict
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts.get('gather_subset') == 'all'
    assert meta_facts.get('module_setup') == True

# Generated at 2022-06-22 22:37:29.106441
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import inspect
    import json
    import os

    filename = inspect.getfile(test_AnsibleFactCollector_collect)
    test_dir_path = os.path.dirname(os.path.abspath(filename))
    data_dir_path = os.path.join(test_dir_path, 'data')

    # Ensure we start with a clean state
    all_collector_classes = \
        collector.get_collector_classes()
    collector.clear_collector_instances(all_collector_classes=all_collector_classes)
    collector.clear_collector_classes(all_collector_classes=all_collector_classes)

    all_collector_classes = \
        collector.get_collector_classes()
    fact_collector = \
        get_ansible_collector

# Generated at 2022-06-22 22:37:41.998196
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import collector

    collect_test_facts = {
        'test_facts': {
            'test_1': 'dict',
            'test_2': [1, 2, 3],
            'test_3': True,
        },
        'test_facts_2': {
            'test_4': 'dict',
        }
    }

    test_collector = collector.BaseFactCollector(namespace='')
    test_collector.collect = lambda: collect_test_facts

    test_collectors = [test_collector]

    test_fact_collector = AnsibleFactCollector(collectors=test_collectors)

    test_collector_facts = test_fact_collector.collect()

    assert test_collector_facts == collect_test_facts


# Unit

# Generated at 2022-06-22 22:37:49.401675
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.collectors.base

    collectors = [
        ansible.module_utils.facts.collectors.base.NetworkCollector(),
        ansible.module_utils.facts.collectors.base.HardwareCollector(),
        ansible.module_utils.facts.collectors.base.VirtualCollector(),
    ]

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec='*',
                             namespace='ansible_')

    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-22 22:38:01.744169
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    test_all_collector_classes = [
        ansible.module_utils.facts.system.distribution.DistributionFactCollector
    ]

    test_filter_spec = ['ansible_d*']
    test_gather_subset = 'all'
    test_gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    test_minimal_gather_subset = frozenset()
    test_namespace = PrefixFactNamespace(prefix='ansible_')


# Generated at 2022-06-22 22:38:13.582362
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Mock
    class MockCollector(collector.BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            return dict(foo='bar')

    def test_no_subset_defaults_to_all():

        c = get_ansible_collector(all_collector_classes=[MockCollector],
                                  gather_subset=None)

        assert set(['foo']) == set(c.collect(collected_facts={}).keys())

    def test_subset_includes_metadata():

        c = get_ansible_collector(all_collector_classes=[MockCollector],
                                  gather_subset=['network'])


# Generated at 2022-06-22 22:38:25.585818
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import default

    cache_collector_classes = cache.collector_fact_classes()
    default_collector_classes = default.collector_fact_classes()
    fact_collector_classes = cache_collector_classes + default_collector_classes
    fact_collector_classes.sort(key=lambda x: x.name)

    fact_collector_obj = \
        get_ansible_collector(
            fact_collector_classes,
            gather_subset=['all'],
            gather_timeout=3,
            minimal_gather_subset=['facter'])

    # check if the collector object is indeed from the ansible_facts class

# Generated at 2022-06-22 22:38:36.028104
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import sys

    class FakeCollector1(collector.BaseFactCollector):
        name = 'fake1'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return {'fake1': 1}

    class FakeCollector2(collector.BaseFactCollector):
        name = 'fake2'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return {'fake2': 2}

    class FakeCollector3(collector.BaseFactCollector):
        name = 'fake3'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return {'fake3': 3}


# Generated at 2022-06-22 22:38:39.413262
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # TODO: move this test case to unit test file
    test_obj = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert test_obj.collect() == {'gather_subset': ['all'], 'module_setup': True}


# Generated at 2022-06-22 22:38:50.388478
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import (
        namespace,
        gather_subset,
    )
    subset_namespace = namespace.PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=subset_namespace)
    assert fact_collector.namespace == subset_namespace
    assert fact_collector.collectors == []
    assert fact_collector.filter_spec is None

    subset_namespace = namespace.PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=subset_namespace,
                                          filter_spec='')
    assert fact_collector.namespace == subset_namespace
    assert fact_collector.collectors == []
    assert fact_collector.filter_

# Generated at 2022-06-22 22:38:57.158936
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class TestCollector(collector.BaseFactCollector):
        name = 'test_collector'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_collector': True}

    assert get_ansible_collector(all_collector_classes={'test_collector': TestCollector},
                                 gather_subset=['all'])

    assert get_ansible_collector(all_collector_classes={'test_collector': TestCollector},
                                 gather_subset=['!min_test'])

    assert get_ansible_collector(all_collector_classes={'test_collector': TestCollector},
                                 gather_subset=['!*'])


# Generated at 2022-06-22 22:39:08.779699
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.ruby

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.ruby.RubyCollector,
    ]

    collectoer = \
        get_ansible_collector(all_collector_classes,
                              gather_subset=['!ruby', 'platform'],
                              filter_spec=['all'])

    # Make sure all the collector classes have been instantiated

    assert len(collectoer.collectors) == 3



# Generated at 2022-06-22 22:39:20.948543
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit test for get_ansible_collector'''

    import os
    import unittest
    import ansible.module_utils.facts.collector.network

    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors.DefaultCollector._classes

    class _TestClass(unittest.TestCase):
        def test_get_ansible_collector(self):
            fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
            self.assertIsInstance(fact_collector, AnsibleFactCollector)
            self.assertIsInstance(fact_collector.collectors[-1], CollectorMetaDataCollector)

# Generated at 2022-06-22 22:39:31.165445
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    all_collector_classes = [collector.LogCollector]

    # without namespace
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes)
    try:
        collected_facts = fact_collector.collect_with_namespace()
        assert 'ansible_facts' in collected_facts
    except Exception as e:
        sys.stderr.write(repr(e))
        sys.stderr.write('\n')

    # with namespaces
    namespace = collector.PrefixFactNamespace(prefix='ansible_')
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace)

# Generated at 2022-06-22 22:39:35.733393
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    meta_data = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert meta_data.gather_subset == 'all'
    assert meta_data.module_setup == True
    assert meta_data.name == 'gather_subset'
    assert meta_data._fact_ids == set([])

# Generated at 2022-06-22 22:39:48.281262
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector.network import NetworkCollector

    all_collector_classes = [cache.CacheCollector, NetworkCollector]

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              minimal_gather_subset=['!all', 'network'])

    collected_facts = fact_collector.collect()

    fact_key = 'ansible_facts'
    assert collected_facts
    assert fact_key in collected_facts

    fact_dict = collected_facts[fact_key]
    assert fact_dict
    assert 'ansible_' in fact_dict

# Generated at 2022-06-22 22:39:58.013679
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Create mock collectors and module setup
    class MockCollectorA(collector.BaseFactCollector):
        name = 'A'

    class MockCollectorB(collector.BaseFactCollector):
        name = 'B'

    class MockCollectorC(collector.BaseFactCollector):
        name = 'C'

    class MockCollectorD(collector.BaseFactCollector):
        name = 'D'

    module_setup = {'a': 1, 'b': 2}

    # Test that we get all non-empty mock collecter modules excluding CollectorMetaDataCollector

# Generated at 2022-06-22 22:40:10.001723
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_classes_from_gather_subset
    from ansible.module_utils.facts import namespace

    namespace_obj = namespace.FactsNamespace()

    # Collectors are not the same object
    collectors = \
        collector_classes_from_gather_subset(
            all_collector_classes=collector.collector_classes(),
            minimal_gather_subset=frozenset(),
            gather_subset=['all'],
            gather_timeout=None)

    collector_objs = []
    for collector in collectors:
        collector_obj = collector(namespace=namespace_obj, filter_spec=None)
        collector_objs.append(collector_obj)


# Generated at 2022-06-22 22:40:18.607297
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collectors.all as all_collectors
    import ansible.module_utils.facts.collectors.network as network_collectors
    import ansible.module_utils.facts.namespace as ns

    all_collector_classes = all_collectors.collector_classes
    network_collector_classes = network_collectors.collector_classes


# Generated at 2022-06-22 22:40:27.910207
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.collector.system import DistributionCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import AbsPrefixFactNamespace

    test_collector_classes = [DistributionCollector]
    test_gather_subset = 'min'
    test_gather_timeout = None
    test_minimal_gather_subset = None
    test_namespace = PrefixFactNamespace(prefix='ansible_')
    test_prefix = 'ansible_'
    test_abs_prefix = 'ansible_facts'


# Generated at 2022-06-22 22:40:39.160580
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for method collect of class AnsibleFactCollector

       Collect Facts by using a FactCollector.
       For ex,
       from ansible.module_utils.facts import ansible_collector as ansible_collector
       from ansible.module_utils.facts import timeout as timeout

       fact_collector = ansible_collector.get_ansible_collector()

       facts = fact_collector.collect(module=module)
       '''

    fact_collector = get_ansible_collector(all_collector_classes=collector.FACT_COLLECTOR_CLASSES)
    facts = fact_collector.collect()

    # test fact names starts with ansible_, if namespace is not specified
    for fact in facts:
        assert fact.startswith('ansible_')



# Generated at 2022-06-22 22:40:42.504214
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    """Return a fact collector with no namespaces and no collectors,
       but with a filter_spec of '*'."""
    collector = AnsibleFactCollector()
    assert collector.filter_spec == '*'
    assert collector.namespace is None
    assert collector.collectors == []



# Generated at 2022-06-22 22:40:50.402653
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collectors = [1, 2, 3]
    filter_spec = ['ansible_os_family', 'ansible_all_ipv4_addresses']
    n = collector.PrefixFactNamespace('ansible_')
    fact_collector = AnsibleFactCollector(collectors=collectors, filter_spec=filter_spec, namespace=n)
    assert fact_collector.collectors == collectors
    assert fact_collector.filter_spec == filter_spec
    assert fact_collector.namespace == n


# Generated at 2022-06-22 22:40:56.709541
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_classes

    all_collector_classes = get_collector_classes()
    namespace = PrefixFactNamespace(prefix='ansible_')
    minimal_gather_subset = frozenset(['all'])
    fact_collector = get_ansible_collector(
        all_collector_classes=all_collector_classes,
        namespace=namespace,
        minimal_gather_subset=minimal_gather_subset)

    # Placeholder for how to unit test fact collector.  First we need a way to
    # unit test the collectors themselves.

    # assert collector_obj.name == 'gather_subset'
    # assert collector_

# Generated at 2022-06-22 22:41:07.336318
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''
    Unit test for method collect of class AnsibleFactCollector.
    This test use the class AnsibleFactCollector and method
    collect to check if facts are collected based on namespaces
    and filters.
    '''

    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace

    namespace = PrefixFactNamespace(prefix='ansible_')

    all_collector_classes = [ansible.module_utils.facts.system.distribution.DistributionFactCollector]

    filter_spec = ['*']
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset

# Generated at 2022-06-22 22:41:17.574816
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    def test_collector(namespace=None):
        return 'test_collector_output_%s' % namespace

    TestCollector = collector.make_collector_functor_for_module(test_collector)
    TestCollectorPrefixed = collector.make_collector_functor_for_module(test_collector,
                                                                        namespace=collector.PrefixFactNamespace('prefix_'))

    all_collector_classes = (TestCollector, TestCollectorPrefixed)

    fact_collector = get_ansible_collector(all_collector_classes)
    facts_dict = fact_collector.collect()

    assert 'test_collector_output_None' == facts_dict['test_collector']

# Generated at 2022-06-22 22:41:28.589367
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts import default

    # Test 1: empty list of collectors and specifiers.
    fact_collector = AnsibleFactCollector(
        collectors=[],
        filter_spec=[]
    )
    result = fact_collector.collect()
    assert result == {}

    # Test 2: 1 collector and empty specifier or "*"
    fact_collector = AnsibleFactCollector(
        collectors=[collector.FacterFactCollector(namespace=None)],
        filter_spec=[]
    )
    result = fact_collector.collect()
    assert result is not None


# Generated at 2022-06-22 22:41:29.489303
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector.main()



# Generated at 2022-06-22 22:41:36.347635
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.distribution

    # Import the following so we can iterate over them to make a list of collector class
    # objects, which tests the 'find_by_path' method of BaseFactCollector
    import ansible.module_utils.facts.system.all_ipv4_addresses
    import ansible.module_utils.facts.system.all_ipv6_addresses
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.dns
    import ansible.module_utils.facts.system.fips_enabled
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.system.platform

# Generated at 2022-06-22 22:41:45.485643
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform

    collectors = [
        ansible.module_utils.facts.collector.network.NetworkCollector(),
        ansible.module_utils.facts.collector.platform.PlatformCollector()
    ]
    fact_collector = AnsibleFactCollector(collectors=collectors)
    collector_facts = fact_collector.collect()
    assert 'ansible_all_ipv4_addresses' in collector_facts
    assert 'ansible_os_family' in collector_facts


# Generated at 2022-06-22 22:41:54.521538
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''unit test for function get_ansible_collector'''

    # test with just minimal_gather_subset specified
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           minimal_gather_subset=[],
                                           gather_subset=[],
                                           gather_timeout=0,
                                           namespace=None)
    assert fact_collector

    # test with minimal_gather_subset and gather_subset specified
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           minimal_gather_subset=[],
                                           gather_subset=[],
                                           gather_timeout=0,
                                           namespace=None)
    assert fact_collector

    # test with minimal_gather

# Generated at 2022-06-22 22:42:04.885680
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import unittest

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollectorFoo(collector.BaseFactCollector):
        pass

    class TestCollectorBar(collector.BaseFactCollector):
        pass

    class TestCollectorBaz(collector.BaseFactCollector):
        pass

    class TestFilterCollectorWithoutFilter(collector.BaseFactCollector):

        # This collector is a leaf collector without a filter
        def collect(self, module=None, collected_facts=None):
            return {'a': 1}


# Generated at 2022-06-22 22:42:09.629826
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    module_setup = CollectorMetaDataCollector(gather_subset='all',
                                              module_setup=True).module_setup
    assert module_setup == True

# Generated at 2022-06-22 22:42:14.280921
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    c1 = collector.BaseCollector()
    c2 = collector.BaseCollector()
    c3 = collector.BaseCollector()
    t = AnsibleFactCollector([c1, c2, c3])
    assert t.collectors == [c1, c2, c3]

# Generated at 2022-06-22 22:42:26.290305
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for AnsibleFactCollector._filter()'''

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import cache_manager
    from ansible.module_utils.facts import collection_count
    from ansible.module_utils.facts import collection_execution_time
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import exception_collector

    # test data
    gathered_data = {'a': 'aa', 'b': 'bb', 'c': 'cc'}
    filter_spec = ['a', 'c']
    namespace = PrefixFactNamespace(prefix='my_')

# Generated at 2022-06-22 22:42:29.245405
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    assert {} == ansible_fact_collector.collect()
    return

# Generated at 2022-06-22 22:42:41.834044
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.local import LocalFactCollector

    class MockCollector(BaseFactCollector):
        def __init__(self, k1, v1):
            self.k1 = k1
            self.v1 = v1
            super(MockCollector, self).__init__()

        def collect(self, module=None, collected_facts=None):
            return {self.k1: self.v1}

    collector_obj1

# Generated at 2022-06-22 22:42:46.784926
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    CollectorMetaDataCollector_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                                                module_setup=True)
    collected_facts = CollectorMetaDataCollector_obj.collect()
    assert collected_facts['gather_subset'] == ['all']
    assert collected_facts['module_setup'] == True

# Generated at 2022-06-22 22:42:49.160994
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    meta_fact_collector = CollectorMetaDataCollector(gather_subset='min')
    assert meta_fact_collector.gather_subset == 'min'

# Generated at 2022-06-22 22:42:57.627783
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # pylint: disable=unused-variable
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    my_prefix = 'my_prefix_'

    class TestFactCollector(collector.BaseFactCollector):
        name = 'TestFactCollector'
        _fact_ids = set(['fact1', 'fact2', 'fact3'])

        # pylint: disable=no-self-use
        def collect(self, module=None, collected_facts=None):
            return {'fact1': 'fact1', 'fact2': 'fact2'}

    class TestFactCollector2(collector.BaseFactCollector):
        name = 'TestFactCollector2'
        _fact_ids = set(['fact1', 'fact2', 'fact3'])

        # pyl

# Generated at 2022-06-22 22:43:00.433616
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    gathered_facts = collector_meta_data_collector.collect()
    assert gathered_facts.get('gather_subset') == ['all']
    assert gathered_facts.get('module_setup')
    assert not gathered_facts.get('hid')
