

# Generated at 2022-06-22 22:33:04.280547
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts
    from ansible.module_utils.facts import timeout

    all_collector_classes = \
        ansible.module_utils.facts.collector.all_collectors(
            gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT)

    fact_collector = get_ansible_collector(all_collector_classes)

    assert fact_collector.collectors is not None
    assert len(fact_collector.collectors) > 0
    assert fact_collector.collect is not None
    assert fact_collector.filter_spec is not None
    assert fact_collector.namespace is None

# Generated at 2022-06-22 22:33:10.461064
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collectors = []
    namespace = None
    filter_spec = None
    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec=filter_spec,
                             namespace=namespace)

    assert len(fact_collector._collectors) == 0
    assert fact_collector._namespace is None
    assert fact_collector.filter_spec is None

# Generated at 2022-06-22 22:33:16.409245
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace

    collectors = []
    filter_spec = []

    # Test with a namespace that prefixes each gathered fact name with ansible
    ansible_namespace = namespace.PrefixFactNamespace(prefix='ansible_')

    # Test with no namespace
    no_namespace = None

    # Create the desired AnsibleFactCollector objects and verify that
    # the constructor worked as expected
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          filter_spec=filter_spec,
                                          namespace=ansible_namespace)

    assert fact_collector.collectors == collectors
    assert fact_collector.filter_spec == filter_spec
    assert fact_collector.namespace is ansible_namespace

    fact_collector = AnsibleFactCollector

# Generated at 2022-06-22 22:33:26.640297
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.network.interfaces import InterfacesFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import get_distribution

    class MockModule:
        def __init__(self):
            self.params = {'gather_subset': 'all'}
            self.params['module_setup'] = True

        def get_option(self, opt):
            return self.params.get(opt)

    mock_module = MockModule()

    if_collector = InterfacesFactCollector(namespace=None)
    distro_collector = DistributionFactCollector(namespace='ansible_distribution')

    collectors = [if_collector, distro_collector]

    # ans

# Generated at 2022-06-22 22:33:35.176041
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_facts = {}
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=None,
                                   module_setup=False)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': None, 'module_setup': False}

    meta_facts = {}
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='all',
                                   module_setup=False)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': 'all', 'module_setup': False}

    meta_facts = {}

# Generated at 2022-06-22 22:33:46.980144
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """Unit test for method collect of class AnsibleFactCollector."""

    # Test setup
    mock_module = {'test': True}
    test_collected_facts = {}
    test_filter_spec = ['*', 'a.*', 'a.b.*']

    # Test collector 1
    mock_collector_1_class = collector.BaseFactCollector
    mock_collector_1_obj = mock_collector_1_class({})
    mock_collector_1_info_dict = {'1': 1, '2': 2, '3': 3}
    mock_collector_1_obj.collect_with_namespace = \
        lambda *args, **kwargs: mock_collector_1_info_dict

    # Test collector 2
    mock_collector_2_class = collector.BaseFactCollector

# Generated at 2022-06-22 22:33:55.028349
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts import collectors

    # Test that filter_spec is None or '*' or [] by default
    fact_collector = AnsibleFactCollector(namespace=None)
    assert fact_collector.filter_spec is None

    fact_collector = AnsibleFactCollector(namespace=None, filter_spec=None)
    assert fact_collector.filter_spec is None

    fact_collector = AnsibleFactCollector(namespace=None, filter_spec='*')
    assert fact_collector.filter_spec == '*'

    fact_collector = AnsibleFactCollector(namespace=None, filter_spec=[])
    assert fact_collector.filter_spec == []

    # Test that filter_spec is set correctly when

# Generated at 2022-06-22 22:34:08.844311
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_collector_classes = [collector.FacterCollector,
                              collector.OhaiCollector,
                              collector.SystemdCollector,
                              collector.CommandCollector,
                              collector.LocalFileCollector,
                              collector.PipCollector,
                              collector.YumCollector,
                              collector.HardwareCollector,
                              collector.VirtualCollector]
    test_collectors = [collector.FacterCollector,
                       collector.OhaiCollector,
                       collector.SystemdCollector,
                       collector.CommandCollector,
                       collector.LocalFileCollector,
                       collector.PipCollector,
                       collector.YumCollector,
                       collector.HardwareCollector,
                       collector.VirtualCollector]
    test_namespace = None
    test_gather_subset = None


# Generated at 2022-06-22 22:34:19.055063
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """AnsibleFactCollector collects"""

    class CollectorOne(collector.BaseFactCollector):
        name = 'collector_one'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {'one': 1}

    class CollectorTwo(collector.BaseFactCollector):
        name = 'collector_two'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {'two': 2}

    class CollectorThree(collector.BaseFactCollector):
        name = 'collector_three'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {'three': 3}

    # Base case -

# Generated at 2022-06-22 22:34:28.040754
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    raw_collectors = [collector.NetworkCollector(), collector.HardwareCollector()]
    fact_collector = AnsibleFactCollector(collectors=raw_collectors)

    namespace = collector.Namespace(prefix="this_is_a_test_prefix_")
    fact_collector_with_namespace = AnsibleFactCollector(collectors=raw_collectors, namespace=namespace)

    assert fact_collector.collectors == raw_collectors
    assert fact_collector_with_namespace._collector_namespaces == [namespace]


# Generated at 2022-06-22 22:34:38.756175
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import namespace

    sysinfo = system.SystemInfoCollector(namespace=namespace.DEFAULT_SYSTEM_COLLECTOR_NAMESPACES)
    sysinfo = namespace.PreferredNamespacePrefixFactNamespace(namespace.DEFAULT_SYSTEM_COLLECTOR_NAMESPACES)

    ansible_collecctor = AnsibleFactCollector(collectors=[sysinfo])
    facts = ansible_collecctor.collect()
    assert facts['ansible_facts']['ansible_system'] == 'Linux'
    assert facts['ansible_facts']['ansible_ip'] == '127.0.0.1'

# Generated at 2022-06-22 22:34:41.884131
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    fact_collector = \
        AnsibleFactCollector(collectors=[], filter_spec=None, namespace=None)
    results = fact_collector.collect()
    assert results == {}



# Generated at 2022-06-22 22:34:43.424588
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fc = AnsibleFactCollector()
    assert fc



# Generated at 2022-06-22 22:34:52.213921
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    c = AnsibleFactCollector()
    assert c.filter_spec is None
    c = AnsibleFactCollector(filter_spec='', namespace='ansible')
    assert c.filter_spec == ''
    assert isinstance(c.namespace, collector.PrefixFactNamespace)
    assert c.namespace.prefix == 'ansible'
    c = AnsibleFactCollector(filter_spec=[], namespace='ansible')
    assert c.filter_spec == []

# Generated at 2022-06-22 22:34:58.925175
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    namespace = None
    gather_subset = ['a', 'all']
    module_setup = True

    collector_obj = CollectorMetaDataCollector(namespace=namespace,
                                               gather_subset=gather_subset,
                                               module_setup=module_setup)

    facts_dict = collector_obj.collect(None, None)
    assert facts_dict['gather_subset'] == gather_subset
    assert facts_dict['module_setup'] == module_setup
    assert sorted(facts_dict.keys()) == ['gather_subset', 'module_setup']

# Generated at 2022-06-22 22:35:09.569682
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class CollectCollector1(BaseFactCollector):
        name = 'collector1'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {'fact1': 'value1'}
    collect_collector1 = CollectCollector1()

    class CollectCollector2(BaseFactCollector):
        name = 'collector2'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {'ansible_fact2': 'value2'}
    collect_collector2 = CollectCollector2()


# Generated at 2022-06-22 22:35:15.295902
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    class fake_collector:
        name = 'gather_subset'
        _fact_ids = set([])

        def __init__(self, collectors=None, namespace=None, gather_subset=None, module_setup=None):
            self.gather_subset = gather_subset
            self.module_setup = module_setup

        def collect(self, module=None, collected_facts=None):
            meta_facts = {'gather_subset': self.gather_subset}
            if self.module_setup:
                meta_facts['module_setup'] = self.module_setup
            return meta_facts

    fc = fake_collector(gather_subset=['!all'], module_setup=True)

# Generated at 2022-06-22 22:35:23.604280
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class FakeCollector(collector.BaseFactCollector):
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'fact_a': 'foo', 'fact_b': 'bar'}

    fact_collector = \
        AnsibleFactCollector(collectors=[FakeCollector()])


# Generated at 2022-06-22 22:35:26.290076
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fc = AnsibleFactCollector()


if __name__ == '__main__':
    test_AnsibleFactCollector()

# Generated at 2022-06-22 22:35:35.317535
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit test for function get_ansible_collector.'''

    all_collectors_classes = [collector.FacterCollector, collector.OhaiCollector]
    ansible_collector = get_ansible_collector(
        all_collector_classes=all_collectors_classes,
        gather_subset=['!facter'],
        filter_spec='*')

    assert len(ansible_collector.collectors) == 1
    assert ansible_collector.collectors[0].name == 'ohai'

    ansible_collector = get_ansible_collector(
        all_collector_classes=all_collectors_classes,
        gather_subset=['!ohai'],
        filter_spec='*')

    assert len(ansible_collector.collectors) == 1

# Generated at 2022-06-22 22:35:45.147944
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import mock

    # Test that we can call collect
    fact_collector = \
        AnsibleFactCollector(collectors=[],
                             namespace=None)

    assert fact_collector.collect()

    # Test that we ignore exceptions when a collector raises an exception
    fact_collector = \
        AnsibleFactCollector(collectors=[mock.MagicMock(side_effect=Exception)],
                             namespace=None)

    assert fact_collector.collect()

    # Test that we ignore exceptions when a collector raises an exception

# Generated at 2022-06-22 22:35:54.974600
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestNamespace(object):
        def __init__(self, namespace):
            pass

        def prefix_key(self, key):
            return 'test_%s' % key

        def unprefix_keys(self, facts_dict):
            unprefixed_facts_dict = {}
            for k, v in facts_dict.items():
                unprefixed_facts_dict['unprefixed_%s' % k] = v
            return unprefixed_facts_dict

    class TestCollector(collector.BaseFactCollector):

        def __init__(self, namespace=None):
            super(TestCollector, self).__init__(namespace=namespace)

        def collect(self):
            info = {}
            info['key1'] = 'value1'
            info['key2'] = 'value2'
            return info

# Generated at 2022-06-22 22:35:59.088822
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    data = CollectorMetaDataCollector(gather_subset=['min'], module_setup=False)
    assert data.gather_subset == ['min']
    assert data.module_setup == False


# Generated at 2022-06-22 22:36:01.572516
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset='subset',
                                                module_setup=False)
    assert fact_collector is not None


# Generated at 2022-06-22 22:36:03.566019
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=True)

# Generated at 2022-06-22 22:36:12.396517
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    class TestCollector1(AnsibleFactCollector):
        name = 'test_module'
        _fact_ids = set(['test_fact'])

    class TestCollector2(AnsibleFactCollector):
        name = 'test_module2'
        _fact_ids = set(['test_fact2'])

    import ansible.module_utils.facts as module_facts
    all_collector_classes = module_facts.get_collector_classes()
    all_collector_classes['test_module'] = TestCollector1
    all_collector_classes['test_module2'] = TestCollector2


# Generated at 2022-06-22 22:36:18.895367
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=True)
    try:
        result = fact_collector.collect()
    except Exception as e:
        sys.stderr.write(repr(e))
        sys.stderr.write('\n')

    # print(result)
    assert result["gather_subset"] == ['all']
    assert result["module_setup"] is True

# Generated at 2022-06-22 22:36:28.242846
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class MockClass(collector.BaseFactCollector):

        def __init__(self, namespace=None):
            super(MockClass, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'answer': 42}

    all_collector_classes = {'mock': MockClass}

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['!all', 'mock'])

    assert fact_collector.collect() == {'ansible_facts': {'answer': 42}}


# Generated at 2022-06-22 22:36:34.035842
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import modules
    all_collector_classes = collector.get_collector_classes(modules=modules)

    gather_subset = [ 'all', 'facter', 'ohai', 'network', 'virtual' ]

    # Tests that a collector that specifies a subset is returned.
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=gather_subset)
    assert 'facter' in fact_collector.collect()

# Generated at 2022-06-22 22:36:45.254917
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Test 1: pass param collectors=None and namespace=None
    fact_collector = AnsibleFactCollector()
    assert fact_collector.collectors == []
    assert fact_collector.filter_spec is None
    assert fact_collector.namespace is None

    # Test 2: pass param collectors=collectors and namespace=namespace
    collectors = [collector.BaseFactCollector()]
    namespace = collector.BaseFactNamespace()
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          namespace=namespace)

    assert fact_collector.collectors == collectors
    assert fact_collector.filter_spec is None
    assert fact_collector.namespace is not None

    # Test 3: pass param collectors=None and namespace=namespace
    namespace = collector.BaseFactNamespace()

# Generated at 2022-06-22 22:36:48.804677
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_obj = AnsibleFactCollector(collectors=None,
                                         namespace=None)

    assert collector_obj.filter_spec is None
    assert collector_obj.collectors == []
    assert collector_obj.namespace is None

# Generated at 2022-06-22 22:36:56.971377
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.network

    fact_collector = \
        AnsibleFactCollector(
            collectors=[
                ansible.module_utils.facts.collector.platform.PlatformFactCollector(),
                ansible.module_utils.facts.collector.distribution.DistributionFactCollector(),
                ansible.module_utils.facts.collector.network.NetworkFactCollector()],
            filter_spec=['distribution', 'kernel', 'network_*'])

    facts_dict = fact_collector.collect()

    assert 'distribution' in facts_dict, \
        'Failed to collect distribution fact, got:\n%s' % facts_dict

# Generated at 2022-06-22 22:36:57.632935
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    pass

# Generated at 2022-06-22 22:37:08.976663
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_dict = {
        'ansible_collector_one': {
            'internal_key_1': 'internal_value_1',
            'internal_key_2': 'internal_value_2'
        },
        'ansible_collector_two': {
            'internal_key_1': 'internal_value_3',
            'internal_key_2': 'internal_value_4'
        }
    }


# Generated at 2022-06-22 22:37:15.940891
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fc = AnsibleFactCollector(namespace=None)
    assert fc.namespace is None
    assert fc.parser is None
    assert fc.collectors == []
    assert fc.filter_spec is None

    fc = AnsibleFactCollector(namespace='hello', filter_spec=['world'],
                              collectors=['a', 'b', 'c'])
    assert fc.namespace == 'hello'
    assert fc.collectors == ['a', 'b', 'c']
    assert fc.filter_spec == ['world']

# Generated at 2022-06-22 22:37:19.073627
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector = CollectorMetaDataCollector(gather_subset=['all'],
                                           module_setup=True)
    result = collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:37:20.993407
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert fact_collector.namespace is None

# Generated at 2022-06-22 22:37:27.700306
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    meta_data_collector = CollectorMetaDataCollector(collectors=[BaseFactCollector(), DistributionFactCollector()])
    assert meta_data_collector is not None
    assert meta_data_collector.collectors is not None
    assert len(meta_data_collector.collectors) == 2
    assert meta_data_collector.collectors[0] is not None
    assert meta_data_collector.collectors[1] is not None
    assert str(type(meta_data_collector.collectors[0])) == "<class 'ansible.module_utils.facts.system.base.BaseFactCollector'>"

# Generated at 2022-06-22 22:37:40.248683
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    python_version = '2.7'
    if sys.version_info[0] == 3:
        python_version = '3.6'

    class MockCollector1(collector.BaseFactCollector):
        name = 'mockcollector1'

        def __init__(self, namespace=None):
            super(MockCollector1, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'python_version': python_version}

    class MockCollector2(collector.BaseFactCollector):
        name = 'mockcollector2'

        def __init__(self, namespace=None):
            super(MockCollector2, self).__init__(namespace=namespace)


# Generated at 2022-06-22 22:37:50.129775
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no arguments
    assert None == AnsibleFactCollector().collect()

    # Test with a collectors argument
    # test_collector object has a dictionary for collect()
    test_collector = collector.BaseFactCollector('test_collector')
    test_collectors = [test_collector]
    assert {'test_collector': {'test_collector': {}}} == AnsibleFactCollector(collectors=test_collectors).collect()

    # Test with a namespace argument
    # test_namespace object is a PrefixFactNamespace that has a dictionary for prefix
    test_namespace = collector.namespace.PrefixFactNamespace('test_namespace')
    assert {'test_namespace': {}} == AnsibleFactCollector(namespace=test_namespace).collect()

    # Test with a filter_spec

# Generated at 2022-06-22 22:38:02.429358
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    default_collector_names = \
        [collector.name for collector in default_collectors]

    minimal_gather_subset = frozenset()

    # NOT in minimal_gather_subset
    # Gather only modules setup, kernel, and platform.
    gather_subset = frozenset(['modules', 'kernel', 'platform'])
    collector = get_ansible_collector(
        all_collector_classes=default_collectors,
        minimal_gather_subset=minimal_gather_subset,
        gather_subset=gather_subset)
    collector_names = [collector.name for collector in collector.collectors]

# Generated at 2022-06-22 22:38:06.193772
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    facts = CollectorMetaDataCollector(minimal_gather_subset=['all']).collect()
    assert facts['gather_subset'] == 'all'



# Generated at 2022-06-22 22:38:16.231139
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class Mock_BaseCollector:

        def collect_with_namespace(self, module, collected_facts):
            return {}

    # test default behavior
    fact_collector = AnsibleFactCollector(collectors=[Mock_BaseCollector()])
    assert fact_collector.collect() == {}

    # test with filter_spec='*'
    fact_collector = AnsibleFactCollector(collectors=[Mock_BaseCollector()],
                                          filter_spec='*')
    assert fact_collector.collect() == {}

    # test with filter_spec=''
    fact_collector = AnsibleFactCollector(collectors=[Mock_BaseCollector()],
                                          filter_spec='')
    assert fact_collector.collect() == {}

    # test with filter_spec=[]
    fact_

# Generated at 2022-06-22 22:38:22.652732
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    sys.path.append('/usr/share/ansible')
    import ansible.utils.module_docs as muc

    all_collector_classes = muc.get_docstring_collector_classes()

    ansible_collector = get_ansible_collector(all_collector_classes)

    assert isinstance(ansible_collector, AnsibleFactCollector)
    assert ansible_collector.collector_count() == len(all_collector_classes) + 1

# Generated at 2022-06-22 22:38:34.345325
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=None,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert type(fact_collector) == AnsibleFactCollector
    assert type(fact_collector.collectors) == list
    assert len(fact_collector.collectors) > 0
    for x in fact_collector.collectors:
        assert issubclass(type(x), collector.BaseFactCollector)
    assert type(fact_collector.filter_spec) == list
    assert len(fact_collector.filter_spec) == 0

# Generated at 2022-06-22 22:38:42.819108
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    def _mock_collector_obj_collect(self, module=None, collected_facts=None):
        #
        # Note: a real Collector class might collect facts under its namespace if it wants to
        #
        # Note: this function is mocked in the unit test, so we can use a fake module=None
        #
        return {'fact1': 1, 'fact2': 2}

    mock_collector_obj = \
        collector.BaseFactCollector(namespace=None)
    mock_collector_obj.collect_with_namespace = _mock_collector_obj_collect

    fact_collector = \
        AnsibleFactCollector(collectors=[mock_collector_obj])

    facts = fact_collector.collect(module=None)

# Generated at 2022-06-22 22:38:50.483243
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts import namespace

    # test default constructor

    # test from_gather_subset constructor

    # test constructor with a namespace

    namespace_prefix_obj = namespace.PrefixNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=namespace_prefix_obj)

    # test constructor with a filter_spec

    fact_collector = AnsibleFactCollector(filter_spec='s*')
    fact_collector = AnsibleFactCollector(filter_spec=['s*'])


# Generated at 2022-06-22 22:38:58.928615
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts import namespace

    from ansible.module_utils.facts.system import distribution
    from ansible.module_utils.facts.system import network
    from ansible.module_utils.facts.system import platform
    from ansible.module_utils.facts.system import virtual
    from ansible.module_utils.facts.system import hardware

    all_collector_classes = [
        hardware.Hardware,
        distribution.Distribution,
        network.Network,
        platform.Platform,
        virtual.Virtual,
    ]


# Generated at 2022-06-22 22:39:09.749663
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.collector.plugins.setup import Setup
    import ansible.module_utils.facts.collector
    all_collector_classes = ansible.module_utils.facts.collector.collector_registry.collector_classes
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.filter_spec is None
    assert len(fact_collector.collectors) == len(all_collector_classes) + 1

# Generated at 2022-06-22 22:39:15.149942
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_obj = CollectorMetaDataCollector()

    assert collector_obj.collect() == {'gather_subset': None}

    collector_obj = CollectorMetaDataCollector(gather_subset='!')

    assert collector_obj.collect() == {'gather_subset': '!'}


# Generated at 2022-06-22 22:39:26.600518
# Unit test for constructor of class AnsibleFactCollector

# Generated at 2022-06-22 22:39:28.697658
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert AnsibleFactCollector(collectors=[])
    assert AnsibleFactCollector(collectors=[], namespace=None)

# Generated at 2022-06-22 22:39:38.112701
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ''' Unit test for function get_ansible_collector '''
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector

    # this test is not the same as the one in module_utils/facts/network/__init__.py
    # because we are not testing the functionality of the NetworkCollector
    # but the functionality of get_ansible_collector
    test_dir = os.path.dirname(os.path.realpath(__file__))
    inventory_path = os.path.join(test_dir, 'inventory')
    print('inventory_path', inventory_path, file=sys.stderr)
    # load platforms/os/inventory first
    # this will load required inventory files

# Generated at 2022-06-22 22:39:50.469710
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    import ansible.module_utils.facts.network as network_module_utils

    all_collector_classes = \
        collector.collector_classes_from_module_utils(
            module_utils=[cache, network_module_utils])

    fact_collector = \
        get_ansible_collector(all_collector_classes,
                              namespace='cache',
                              gather_subset='network',
                              filter_spec=[])

    collected_facts = fact_collector.collect()

    # a bit hard to test here.. this is just a simple check that the
    # gather_subset metadata fact is present which is a good sign
    # that CollectorMetaDataCollector is registered and working
    assert collected_facts['gather_subset'] == 'network'

# Generated at 2022-06-22 22:39:59.338360
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # NOTE: This test depends on imports from ansible.module_utils.facts to test
    # the get_ansible_collector() factory function.  This is not ideal but
    # was the best way I (clalancette) could come up with to test the function.

    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import virtual

    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual import OpenVZCollector
    from ansible.module_utils.facts.virtual import LXCCollector
    from ansible.module_utils.facts.virtual import VirtualBoxCollector
    from ansible.module_utils.facts.virtual import VMwareCollector

# Generated at 2022-06-22 22:40:04.484754
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    meta_facts = {'gather_subset': ['all'], 'module_setup': True}


# Generated at 2022-06-22 22:40:11.472265
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.collector_classes_from_gather_subset(gather_subset=['all'],
                                                       gather_timeout=0)
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes, filter_spec=['*'])
    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert facts['ansible_facts']['gather_subset'] == ['all']

# Generated at 2022-06-22 22:40:19.505007
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    def _get_namespace():
        return namespace

    class FakeCollector(collector.BaseFactCollector):
        name = 'FakeCollector'
        _fact_ids = set()

        def __init__(self, namespace=None):
            super(FakeCollector, self).__init__(namespace)
            self.namespace = namespace

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['name'].append(self.name)
            return {'name': self.name}

    fact_collector = AnsibleFactCollector(collectors=[FakeCollector('A'),
                                                       FakeCollector('B')])
    facts = fact_collector.collect()

# Generated at 2022-06-22 22:40:28.157853
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    namespace = collector.Namespace(prefices=['ansible_'], separator='_')
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['*'],
                                                               module_setup=True,
                                                               namespace=namespace)
    #test gather_subset
    assert collector_meta_data_collector.gather_subset == ['*']

    #test module_setup
    assert collector_meta_data_collector.module_setup == True

    #test namespace
    assert collector_meta_data_collector.namespace == namespace

# Generated at 2022-06-22 22:40:39.044385
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    ''' Tests the constructor of the CollectorMetaDataCollector class '''

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)

    expected_result = {'gather_subset': ['all'],
                       'module_setup': True,
                       'namespace': None}

    assert isinstance(collector_meta_data_collector, CollectorMetaDataCollector)
    assert collector_meta_data_collector.gather_subset == expected_result['gather_subset']
    assert collector_meta_data_collector.module_setup == expected_result['module_setup']
    assert collector_meta_data_collector.namespace == expected_result['namespace']



# Generated at 2022-06-22 22:40:42.701248
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(
        module_setup=True, gather_subset='all')

    assert collector_meta_data_collector.collect() == {
        'module_setup': True, 'gather_subset': 'all'}



# Generated at 2022-06-22 22:40:53.148223
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import unittest.mock as mock
    from ansible.module_utils.facts import namespaced_fact_collectors
    from ansible.module_utils.facts import collector

    # can override the DEFAULT_GATHER_SUBSET used by default in the class
    gather_subset = ['all']
    module_setup = True
    test_collector = CollectorMetaDataCollector(gather_subset=gather_subset,
                                                module_setup=module_setup)

    mock_module = mock.MagicMock()
    collected_facts = mock.MagicMock()
    expected_meta_facts = {'gather_subset': ['all'],
                           'module_setup': True}


# Generated at 2022-06-22 22:41:01.829550
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    class FakeCollector(collector.BaseFactCollector):
        def collect(self):
            return {'foo': 'bar'}

    collectors = [FakeCollector()]
    namespace = collector.BaseFactNamespace()
    ansible_fact_collector = AnsibleFactCollector(collectors=collectors,
                                                  namespace=namespace,
                                                  filter_spec='*')
    collected_facts = ansible_fact_collector.collect()

    assert collected_facts == {'_namespace': namespace.namespace,
                               'ansible_facts': {'foo': 'bar'}}

# Generated at 2022-06-22 22:41:11.633611
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_meta_data_collector_1 = CollectorMetaDataCollector(gather_subset='my_subset',
                                                                 module_setup=True)

    collected_facts_1 = collector_meta_data_collector_1.collect(module=None,
                                                                collected_facts=None)

    assert isinstance(collected_facts_1, dict)
    assert collected_facts_1 == {'gather_subset': 'my_subset', 'module_setup': True}


    collector_meta_data_collector_2 = CollectorMetaDataCollector(gather_subset='my_subset',
                                                                 module_setup=False)

    collected_facts_2 = collector_meta_data_collector_2.collect(module=None,
                                                                collected_facts=None)

# Generated at 2022-06-22 22:41:14.591287
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                          module_setup=True)
    assert test_obj.gather_subset == ['all'] and test_obj.module_setup == True

# Generated at 2022-06-22 22:41:20.317446
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ans_fact_obj = AnsibleFactCollector()
    assert isinstance(ans_fact_obj, collector.BaseFactCollector)
    assert ans_fact_obj.collector_all_classes is not None
    assert ans_fact_obj.collectors is not None
    assert ans_fact_obj.namespace is None


# Generated at 2022-06-22 22:41:30.596004
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    class Collector1(collector.BaseFactCollector):
        name = 'Collector1'

        def collect(self, module=None, collected_facts=None):
            return {'a': 'b'}

    class Collector2(collector.BaseFactCollector):
        name = 'Collector2'

        def collect(self, module=None, collected_facts=None):
            return {'c': 'd'}

    # Should not include Collector1
    fact_collector = get_ansible_collector(all_collector_classes=[Collector1, Collector2],
                                           gather_subset=['Collector2'])
    facts_dict = fact_collector.collect()

    assert facts_dict == {'c': 'd'}

    # Should include Collector1 and Collector2
    fact_collector = get

# Generated at 2022-06-22 22:41:42.002683
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
  import pytest
  from ansible.module_utils.facts import namespace
  from ansible.module_utils.facts import timeout
  import ansible.module_utils.facts.collectors.all as all_collectors
  from ansible.module_utils.facts.collector import CollectorMetaDataCollector

  # Test gather_subset
  gather_subset = ['a', 'b']
  # Test module_setup
  module_setup = True
  # Create instance of CollectorMetaDataCollector
  meta_data_collector = CollectorMetaDataCollector(none, none, gather_subset, module_setup)
  # Call collect method and verify results
  meta_facts = meta_data_collector.collect()
  assert meta_facts.get('gather_subset') == gather_subset

# Generated at 2022-06-22 22:41:52.415905
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import unittest
    import json
    import copy

    class CollectorA(collector.BaseFactCollector):
        name = 'collector_a'
        _fact_ids = set(['a'])

        def collect(self, module=None, collected_facts=None):
            return {'a': 1}

    class CollectorB(collector.BaseFactCollector):
        name = 'collector_b'
        _fact_ids = set(['b'])

        def collect(self, module=None, collected_facts=None):
            return {'b': 2}

    class CollectorC(collector.BaseFactCollector):
        name = 'collector_c'
        _fact_ids = set(['c'])


# Generated at 2022-06-22 22:42:03.557588
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    load_fact_classes_from_module = collector.load_fact_classes_from_module
    all_collector_classes = collector.collector_classes_from_directory(load_fact_classes_from_module)

    gather_subset = ['all']
    minimal_gather_subset = frozenset()
    gather_timeout = 20

    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=gather_subset,
                                           gather_timeout=gather_timeout,
                                           minimal_gather_subset=minimal_gather_subset)

    assert fact_collector.collectors[0].name == 'facter'

# Generated at 2022-06-22 22:42:12.385978
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    try:
        AnsibleFactCollector(namespace='ansible.module_utils.facts.namespace.PrefixFactNamespace',
                             filter_spec=['datetime', 'network', 'platform', 'facter'])
    except Exception as e:
        print(e)
        assert False, 'AnsibleFactCollector constructor test failed'



# Generated at 2022-06-22 22:42:19.712015
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a temporary TestCollector
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'fact': 'value'}

    # Create an AnsibleFactCollector with the TestCollector
    fact_collector = \
        AnsibleFactCollector(collectors=[TestCollector()])

    # Test collect
    assert fact_collector.collect() == {'ansible_facts': {'fact': 'value'}}
    assert fact_collector.collect()['ansible_facts'].get('fact') == 'value'


# Generated at 2022-06-22 22:42:30.031071
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts import default_collectors as default_collector_classes
    from ansible.module_utils.facts import namespace

    def get_default_collector_instance(collector_class):
        for collector_obj in default_collector_instances:
            if isinstance(collector_obj, collector_class):
                return collector_obj

    # Module that is passed to the collector
    module = None

    # Instantiate all the default collectors
    default_collector_instances = []
    for default_collector_class in default_collector_classes:
        default_collector_obj = default_collector_class(namespace=namespace.DEFAULT_NAMESPACE)
        default_collector_instances.append(default_collector_obj)

    # Collect all the default facts
   

# Generated at 2022-06-22 22:42:34.654555
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'])
    fact = collector_meta_data_collector.collect()
    assert fact['gather_subset'] == ['all']

# Generated at 2022-06-22 22:42:45.587530
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.namespace

    def test_get_ansible_collector_base():
        fact_collector = get_ansible_collector(
            ansible.module_utils.facts.collectors.__all__,
            namespace=ansible.module_utils.facts.namespace.BaseFactNamespace(prefix='test_'),
            filter_spec=['test_fact'])
        facts = fact_collector.collect()
        assert facts['test_fact'] == 'value'


# Generated at 2022-06-22 22:42:55.281639
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes = collector.get_fact_collector_classes()

    # Note: This is the default subset
    gather_subset = ['all']
    filter_spec = ['ansible_kernel']

    # Note: this is the default namespace
    namespace = collector.FactNamespace()

    # Note: this is the default gather_subset
    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=frozenset(),
            gather_subset=gather_subset,
            gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT)


# Generated at 2022-06-22 22:43:04.616553
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Test: filter_spec=[]
    # filter_spec empty or '*' is equivalent to filter_spec=''
    # which means no filtering.
    # The filter spec translates to filter_spec=''
    filter_spec = []
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           filter_spec=filter_spec)
    assert fact_collector.filter_spec == ''

    # Test: filter_spec=['*']
    filter_spec = ['*']
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           filter_spec=filter_spec)
    assert fact_collector.filter_spec == ''

    # Test: filter_spec=['*', 'os']
    # param filter_spec: filters the gathered