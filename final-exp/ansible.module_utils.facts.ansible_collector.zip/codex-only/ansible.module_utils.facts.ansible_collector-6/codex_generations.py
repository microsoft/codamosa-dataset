

# Generated at 2022-06-22 22:33:06.635922
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)

    module = None
    collected_facts = None
    meta_facts = collector_meta_data_collector.collect(module, collected_facts)

    expected_meta_facts = {'gather_subset': ['all'], 'module_setup': True}
    assert meta_facts == expected_meta_facts, \
        "meta_facts = %s expected = %s" % (meta_facts, expected_meta_facts)

# Generated at 2022-06-22 22:33:13.544973
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import collector_classes
    test_collectors = get_ansible_collector(
        all_collector_classes=collector_classes,
        namespace=PrefixFactNamespace(prefix='ansible_'),
        gather_subset=['network', 'virtual'],
        gather_timeout=10
    )
    collected_facts = test_collectors.collect()
    import re
    assert re.search(r"^'network', 'virtual'$", str(collected_facts['ansible_gather_subset']))

# Generated at 2022-06-22 22:33:17.885289
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespaces

    fake_collectors = [FakeCollector(fact_name='fake_fact1', fact_value='fake_value1'),
                       FakeCollector(fact_name='fake_fact2', fact_value='fake_value2')]

    # Test case: namespace prefix provided, no filter given
    fact_collector = AnsibleFactCollector(collectors=fake_collectors,
                                          namespace=namespaces.PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collector.collect()
    assert facts == {'ansible_fake_fact1': 'fake_value1', 'ansible_fake_fact2': 'fake_value2'}

    # Test case: namespace prefix and filter

# Generated at 2022-06-22 22:33:23.371519
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=['all'])

    facts_dict = fact_collector.collect()
    assert facts_dict
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-22 22:33:26.716681
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    provider = CollectorMetaDataCollector(gather_subset=['all'],
                                          module_setup=True)
    result = provider.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:33:35.245320
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    f1 = {'f1': 'f1_value'}
    f2 = {'f2': 'f2_value'}

    # ansible_f1 will be transformed to ansible_facts['ansible_f1']
    # f2 will be transformed to ansible_facts['f2']
    # f3 will not be transformed because it is not in filter
    facts = {'f1': f1, 'f2': f2, 'f3': {'f3': 'f3_value'}}
    namespace = PrefixFactNamespace(prefix='ansible_')


# Generated at 2022-06-22 22:33:37.870287
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    try:
        assert AnsibleFactCollector()
    except:
        assert False


# Generated at 2022-06-22 22:33:48.757432
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    all_collector_classes = []
    all_collector_classes.append(collector.FacterFactCollector)
    all_collector_classes.append(collector.OhaiFactCollector)
    all_collector_classes.append(collector.PlatformFactCollector)

    fact_collector = \
        get_ansible_collector(all_collector_classes,
                              namespace=None,
                              filter_spec='*',
                              gather_subset=['all'],
                              gather_timeout=None,
                              minimal_gather_subset=None)
    collected_facts = fact_collector.collect()
    assert collected_facts is not None
    assert 'ansible_facts' in collected_facts
    assert collected_facts['ansible_facts'] is not None


# Generated at 2022-06-22 22:33:55.585033
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    namespace = None
    gather_subset = ['network']
    module_setup = True
    collector_ = CollectorMetaDataCollector(namespace=namespace,
                                            gather_subset=gather_subset,
                                            module_setup=module_setup)

    assert collector_.gather_subset == ['network']
    assert collector_.namespace == None
    assert collector_.module_setup == True

    meta_facts = collector_.collect()
    assert meta_facts['gather_subset'] == ['network']
    assert meta_facts['module_setup'] == True


# Generated at 2022-06-22 22:34:08.889476
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ''' Non-pytest unit test for method collect of CollectorMetaDataCollector '''
    import time
    import pdb
    from ansible.module_utils.facts import collector

    collect_timeout = 10

    import platform
    #import ansible.module_utils.facts.hardware as hardware_collector_class
    #import ansible.module_utils.facts.network as network_collector_class
    #import ansible.module_utils.facts.distribution as distribution_collector_class
    #import ansible.module_utils.facts.virtual as virtual_collector_class

    # When running unit test outside pytest (eg running with pdb)
    # the set of collector classes may differ from the ones imported
    # by pytest.
    from ansible.module_utils.facts.collector.base import CollectorMetaDataCollector

# Generated at 2022-06-22 22:34:18.329939
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Example of a test of get_ansible_collector()
    # TODO: add this and other unit tests to global ansible test suite
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.platform
    import ansible.module_utils.facts.system

    all_collector_classes = [
        ansible.module_utils.facts.network.NetworkFactCollector,
        ansible.module_utils.facts.platform.PlatformFactCollector,
        ansible.module_utils.facts.system.SystemFactCollector,
    ]


# Generated at 2022-06-22 22:34:29.921298
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

    all_collector_classes = {
        'test': TestCollector.__module__ + '.' + TestCollector.__name__
    }

    def assert_collector_classes(expected_collector_classes,
                                 minimal_gather_subset,
                                 gather_subset,
                                 gather_timeout=None):

        gather_timeout = gather_timeout or timeout.DEFAULT_GATHER_TIME

# Generated at 2022-06-22 22:34:40.570698
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Test filter_spec='' returns all facts
    all_collector_classes = []
    filter_spec = ''
    fact_collector = get_ansible_collector(
        all_collector_classes=all_collector_classes,
        filter_spec=filter_spec)

    facts_dict = fact_collector.collect()
    assert facts_dict == {}

    # Test filter_spec=[] returns all facts
    all_collector_classes = []
    filter_spec = []
    fact_collector = get_ansible_collector(
        all_collector_classes=all_collector_classes,
        filter_spec=filter_spec)

    facts_dict = fact_collector.collect()
    assert facts_dict == {}

    # Test filter_spec='*' returns all facts
    all_collect

# Generated at 2022-06-22 22:34:44.244876
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.system as system

    fact_namespace = namespace.BaseFactNamespace()
    fact_collector = AnsibleFactCollector(collectors=[fact_namespace],
                                          namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    fact_dict = fact_collector.collect()
    assert 'ansible_facts' in fact_dict

    fact_namespace = namespace.BaseFactNamespace()
    fact_collector = AnsibleFactCollector(collectors=[fact_namespace],
                                          namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    fact_dict = fact_collector.collect()
    assert 'ansible_facts' in fact_dict

    fact

# Generated at 2022-06-22 22:34:52.473843
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.utils
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import cache

    # Create the dummy module_setup function
    def fake_module_setup():
        pass

    # Create the CollectorMetaDataCollector object
    c = CollectorMetaDataCollector(gather_subset=['*'], module_setup=fake_module_setup)

    # Call the method collect
    facts = c.collect()

    # Check the facts
    expected_facts = {'gather_subset': ['*']}
    if hasattr(cache, 'timeout_cache_path'):
        expected_facts['module_setup'] = True


# Generated at 2022-06-22 22:34:58.203212
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.network import NetworkFactCollector

    # Python 2 and 3 compatible
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('ansible.module_utils.facts.collector.network'
               '.NetworkFactCollector.collect',
               return_value={}):

        net_collector = NetworkFactCollector()
        system_collector = SystemFactCollector()

        # Test without namespace

# Generated at 2022-06-22 22:35:03.889274
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    def my_collector(namespace):
        return collector.BaseFactCollector(namespace=namespace)

    fact_collector = get_ansible_collector([my_collector], namespace='foo')
    collected_facts = fact_collector.collect({})
    assert collected_facts == {'ansible_facts': {}}, collected_facts

# Generated at 2022-06-22 22:35:04.493712
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    pass

# Generated at 2022-06-22 22:35:12.400607
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.collector.network as network
    import ansible.module_utils.facts.collector.platform as platform
    import ansible.module_utils.facts.collector.system as system
    import ansible.module_utils.facts.collector.virtual as virtual

    # Test collectors are registered successfully
    collectors = [
        network.NetworkCollector,
        platform.PlatformCollector,
        system.SystemCollector,
        virtual.VirtualCollector
    ]

    collector_obj = AnsibleFactCollector(collectors)
    assert collector_obj

    # Test collectors by collect method
    facts = collector_obj.collect()
    assert facts
    assert 'ansible_system' in facts
    assert 'ansible_network' in facts
    assert 'ansible_virtualization' in facts

# Generated at 2022-06-22 22:35:19.568434
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_collector = CollectorMetaDataCollector()
    assert test_collector
    assert test_collector.name == 'gather_subset'
    assert test_collector.collectors == []
    assert test_collector._fact_ids == set([])
    assert test_collector.gather_subset is None
    assert test_collector.module_setup is None
    assert test_collector.namespace is None
    assert test_collector.collect() == {'gather_subset': None}


# Generated at 2022-06-22 22:35:31.384589
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace


# Generated at 2022-06-22 22:35:41.331150
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit test for function get_ansible_collector.'''

    from ansible.module_utils.facts import all_collectors as fact_collector_classes

    fact_collector = get_ansible_collector(all_collector_classes=fact_collector_classes,
                                           gather_subset=['all'])

    facts = fact_collector.collect_with_namespace(collected_facts={},
                                                  module=None)

    assert 'ansible_all_ipv4_addresses' in facts, \
        'Collector did not fill facts dictionary with expected information.'



# Generated at 2022-06-22 22:35:53.236083
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class TestCollectorA(collector.BaseFactCollector):
        name = 'test_a'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_a': {'a': 'a'}}

    class TestCollectorB(collector.BaseFactCollector):
        name = 'test_b'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_b': {'b': 'b'}}

    class TestCollectorC(collector.BaseFactCollector):
        name = 'test_c'
        _fact_ids = set([])


# Generated at 2022-06-22 22:36:04.008296
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import nose.tools as nt
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import runners
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import ansible_collector

    all_collectors = [
        ansible_collector.AnsibleCollector,
        ansible_collector.FacterCollector,
        ansible_collector.OhaiCollector,
        ansible_collector.FileglobCollector,
        ansible_collector.PkgFactCollector,
        ansible_collector.DMIHardwareCollector,
        ansible_collector.VirtWhatCollector,
        ansible_collector.SystemdCollector,
    ]

   

# Generated at 2022-06-22 22:36:12.459945
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class DummyCollector(collector.BaseFactCollector):
        name = 'dummy'
        _fact_ids = set(['test1', 'test2'])

        def collect(self, module=None, collected_facts=None):
            return {'test1': 1, 'test2': 2}

    class DummyCollector2(collector.BaseFactCollector):
        name = 'dummy2'
        _fact_ids = set(['test3', 'test4'])

        def collect(self, module=None, collected_facts=None):
            return {'test3': 3, 'test4': 4}

    # Test no filter
    fact_collector = AnsibleFactCollector(collectors=[DummyCollector()])
    facts = fact_collector.collect()

# Generated at 2022-06-22 22:36:15.200037
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert fact_collector.__class__.__name__ == 'AnsibleFactCollector'

# Generated at 2022-06-22 22:36:26.728058
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Set up a mock module
    class MyModule(object):
        def __init__(self):
            self.params = {
                'gather_subset': ['all'],
                'filter': '*'
            }

    my_mock_module = MyModule()

    # Set up collectors to be used in the collector
    class MyFactsCollector1(collector.BaseFactCollector):
        name = 'my_facts_collector_1'
        _fact_ids = set(['fact_1', 'fact_2'])

        def collect(self):
            return { 'fact_1': 'fact_1_value', 'fact_2': 'fact_2_value' }

    class MyFactsCollector2(collector.BaseFactCollector):
        name = 'my_facts_collector_2'

# Generated at 2022-06-22 22:36:30.352838
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_collector = CollectorMetaDataCollector(gather_subset=collector.ALL_SUBSETS, module_setup=False)
    assert test_collector.gather_subset == collector.ALL_SUBSETS
    assert test_collector.module_setup == False



# Generated at 2022-06-22 22:36:36.395867
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts.utils as utils
    import ansible.module_utils.facts.namespace as facts_ns
    import ansible.module_utils.facts.system.distribution as ds
    import ansible.module_utils.facts.system.distribution_version as ds_v
    import ansible.module_utils.facts.system.distribution_release as ds_r

    fact_collector = get_ansible_collector([ds.DistributionFactCollector,
                                            ds_v.DistributionVersionFactCollector,
                                            ds_r.DistributionReleaseFactCollector],
                                           [],
                                           ['all'])
    utils.setup_module_loaders()

    fp = fact_collector.collect()


# Generated at 2022-06-22 22:36:46.161645
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class MyCollector(collector.BaseFactCollector):
        name = 'name'

        def __init__(self, namespace=None):
            super(MyCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    my_collector_class = MyCollector
    namespace = collector.Namespace(name='test')
    all_collector_classes = [my_collector_class]

    ansible_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                              namespace=namespace,
                                              gather_subset=['all'],
                                              filter_spec=['*'],
                                              gather_timeout=60)



# Generated at 2022-06-22 22:36:55.606877
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Test that the collect method returns expected results.'''
    # import unittest
    # import mock
    # import ansible.module_utils.facts.facts
    # import ansible.module_utils.facts.namespace

    # class MockFactsCollector:
    #     name = 'fake_facts'
    #     def collect(self, module, collected_facts):
    #         return {'ansible_fake_fact': 'foo'}

    # class TestAnsibleFactCollector(unittest.TestCase):
    #     def test_collect(self):
    #         fact_collector = ansible.module_utils.facts.facts.AnsibleFactCollector(
    #             collectors=[MockFactsCollector()],
    #             filter_spec=[],
    #             namespace=None)
    #

# Generated at 2022-06-22 22:36:59.246454
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collect = CollectorMetaDataCollector(['all']).collect()
    assert collect['gather_subset'] == ['all']
    assert collect['module_setup'] == True


# Generated at 2022-06-22 22:37:04.811107
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import namespaces

    c = CollectorMetaDataCollector(namespace=namespaces.PrefixFactNamespace(prefix='ansible_'))
    facts = c.collect()

    assert facts['gather_subset'] == 'all'

# Generated at 2022-06-22 22:37:08.742822
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='apple', module_setup=True)
    assert collector_meta_data_collector
    assert collector_meta_data_collector.gather_subset == 'apple'
    assert collector_meta_data_collector.module_setup == True


# Generated at 2022-06-22 22:37:12.635383
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    expected = {'gather_subset': ['!all', 'network']}
    actual = CollectorMetaDataCollector(gather_subset=['!all', 'network'])
    assert expected == actual.collect()


# Generated at 2022-06-22 22:37:19.872993
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible_collections.ansible.community.plugins.module_utils.facts.collector
    all_collector_classes = \
        ansible_collections.ansible.community.plugins.module_utils.facts.collector.C.get_collector_classes()
    ansible_collector = get_ansible_collector(all_collector_classes)
    assert ansible_collector

# Generated at 2022-06-22 22:37:23.170640
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    ns = PrefixFactNamespace(prefix='ansible_')

    fact_collector = AnsibleFactCollector(collectors=[NetworkCollector(namespace=ns)],
                                          filter_spec='non-existing-fact',
                                          namespace=ns)



# Generated at 2022-06-22 22:37:29.879970
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """Unit test for method collect of class CollectorMetaDataCollector"""

    # CollectorMetaDataCollector()
    collector_metadata_collector = CollectorMetaDataCollector()

    expected = {'gather_subset': None}
    assert (expected == collector_metadata_collector.collect())

    # CollectorMetaDataCollector(gather_subset=['all'])
    collector_metadata_collector = CollectorMetaDataCollector(gather_subset=['all'])

    expected = {'gather_subset': ['all']}
    assert (expected == collector_metadata_collector.collect())

    # CollectorMetaDataCollector(gather_subset='all')
    collector_metadata_collector = CollectorMetaDataCollector(gather_subset='all')

    expected = {'gather_subset': 'all'}

# Generated at 2022-06-22 22:37:30.831230
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # test `get_ansible_collector()` by calling it in a test module.

    # todo
    pass

# Generated at 2022-06-22 22:37:32.583588
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import all_collector_classes

    fact_collector = get_ansible_collector(all_collector_classes)

    result = fact_collector.collect(module=None, collected_facts=None)

    assert result['gather_subset'] == ['all']

# Generated at 2022-06-22 22:37:38.650118
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FakeCollector1(collector.BaseFactCollector):
        name = 'FakeCollector1'

        def collect(self):
            return {'fake_collector1_fact': True}

    class FakeCollector2(collector.BaseFactCollector):
        name = 'FakeCollector2'

        def collect(self):
            return {'fake_collector2_fact': True}

    fact_collector = \
        AnsibleFactCollector(collectors=[FakeCollector1(), FakeCollector2()])

    try:
        fact_collector.collect()
    except:
        pytest.fail("Collect method of AnsibleFactCollector failed")

# Generated at 2022-06-22 22:37:43.618141
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    module = None
    collected_facts = {}
    collector_metadata_collector = CollectorMetaDataCollector(['all'])
    my_test_facts = collector_metadata_collector.collect(module, collected_facts)
    assert my_test_facts['gather_subset'] == ['all']


# Generated at 2022-06-22 22:37:53.671712
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=['!all'])
    fact_dict = fact_collector.collect()
    assert not fact_dict.get('module_setup')

    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=True)
    fact_dict = fact_collector.collect()
    assert fact_dict.get('module_setup') is True
    assert fact_dict.get('gather_subset') == ['all']

    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=False)
    fact_dict = fact_collector.collect()
    assert fact_dict.get('module_setup') is False
    assert fact_dict.get

# Generated at 2022-06-22 22:38:03.649996
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Notice the prefix='ansible_' can be use in 3 ways.
    #
    # 1. directly using a namespace to create the collector
    #
    # 2. by creating namespace object with the prefix and use the namespace object.
    #
    # 3. by creating a namespace object with the prefix, and pass it to the collectors in the
    #    collector list.
    #
    fact_collector = AnsibleFactCollector(collectors=[collector.FacterCollector()],
                                          namespace=collector.PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collector.collect()
    assert('ansible_os_family' in facts)
    assert('ansible_architecture' in facts)



# Generated at 2022-06-22 22:38:13.404150
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes = [collector.NetworkCollector]
    ansible_collector = \
        get_ansible_collector(all_collector_classes=collector_classes,
                              minimal_gather_subset=frozenset(['network']),
                              gather_subset=['network'],
                              gather_timeout=3,
                              namespace=None)
    facts_dict = ansible_collector.collect()
    for fact_dict in facts_dict.values():
        assert 'default_ipv4' in fact_dict
        assert 'default_ipv6' in fact_dict
        assert 'interfaces' in fact_dict
        return

# Generated at 2022-06-22 22:38:25.511432
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    def mock_mycollect_dict():
        return {
            'mycollect_1': {
                'mycollect_1.1': 'mycollect_1.1',
            },
            'mycollect_2': {
                'mycollect_2.1': 'mycollect_2.1',
            }
        }

    def mock_mycollect_dicts(*args, **kwargs):
        return [
            {'mycollect_1': 'mycollect_1'},
            {'mycollect_2': 'mycollect_2'},
        ]

    def mock_mycollect_dicts_with_filter(mycollect_ids, module, **kwargs):
        return [
            {'mycollect_1': 'mycollect_1'},
            {'mycollect_2': 'mycollect_2'},
        ]

   

# Generated at 2022-06-22 22:38:26.198452
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    pass

# Generated at 2022-06-22 22:38:36.513159
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class Collector1(collector.BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['foo.bar'])

        def collect(self, module=None, collected_facts=None):
            return {'foo.bar': 'baz'}

    class Collector2(collector.BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['a.b'])

        def collect(self, module=None, collected_facts=None):
            return {'a.b': 'c'}


# Generated at 2022-06-22 22:38:46.788048
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import platform

    def FakeCollector(collectors=None, namespace=None):
        facts_dict = {}
        if namespace is not None:
            facts_dict = {'ansible_hostname': platform.node()}
            facts_dict = namespace.add_namespace(facts_dict)
        else:
            facts_dict = {'hostname': platform.node()}
        return facts_dict

    n = collector.PrefixFactNamespace(prefix='ansible_')
    collectors = [FakeCollector(namespace=n)]
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          namespace=n)
    assert fact_collector.collect() == {'ansible_hostname': platform.node()}



# Generated at 2022-06-22 22:38:56.328149
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.setup

    FACT_LIST = ['a', 'b', 'c']

    class TestCollector1(collector.BaseFactCollector):

        name = 'test1'
        _fact_ids = set(FACT_LIST)

        def collect(self, module=None, collected_facts=None):
            return ('test1_fact1', 'test1_fact2', 'test1_fact3')

    class TestCollector2(collector.BaseFactCollector):

        name = 'test2'
        _fact_ids = set(FACT_LIST)


# Generated at 2022-06-22 22:39:07.937356
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    class MyCollector(collector.BaseFactCollector):
        name = "my_collector"

        def collect(self, module=None, collected_facts=None):
            return {'test_collector_fact': 1}

    def assert_from_gather_subset(gather_subset, collector_names_expected):
        collectors = []
        for name in collector_names_expected:
            collectors.append(MyCollector())

        fact_collector = AnsibleFactCollector(collectors=collectors)
        assert fact_collector.collect() == {'test_collector_fact': 1}

    assert_from_gather_subset('all', ['my_collector'])


# Generated at 2022-06-22 22:39:20.006874
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class CollectorA(collector.BaseFactCollector):
        name = 'a'

        def __init__(self, namespace=None):
            super(CollectorA, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'a': 'A'}

    class CollectorB(collector.BaseFactCollector):
        name = 'b'

        def __init__(self, namespace=None):
            super(CollectorB, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'b': 'B'}

    class CollectorC(collector.BaseFactCollector):
        name = 'c'


# Generated at 2022-06-22 22:39:22.133433
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    actual = collector_meta_data_collector.collect()
    assert actual['gather_subset'] == ['all']
    assert actual['module_setup']

# Generated at 2022-06-22 22:39:31.757481
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """
    ansible.module_utils.facts.collector.AnsibleFactCollector.collect(module=None,
                                                                     collected_facts=None)
    """
    filter_spec = ['ansible_*', '*.date', 'facter_uptime_seconds', 'ohai_time']
    namespace = collector.Namespace()
    default_fact_collector = \
        get_ansible_collector(collector.all_collector_classes(),
                              namespace=namespace)
    actual_output = default_fact_collector.collect()
    assert actual_output['ansible_lsb']['code'] == 'Ubuntu'
    assert actual_output['ansible_date_time']['iso8601'] == '2017-03-06T03:12:13Z'
    assert actual_output

# Generated at 2022-06-22 22:39:40.612408
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import filesystem
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual

    # all of these will be added to the fact_collector
    collector_classes = [hardware.Hardware, filesystem.FileSystem, network.Network, virtual.Virtual]

    fact_collector = get_ansible_collector(collector_classes=collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'))

    # all means all collectors
    facts = fact_collector.collect()
    assert facts

# Generated at 2022-06-22 22:39:43.365730
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    collectors = []
    namespace = None
    filter_spec = None

    afc = AnsibleFactCollector(collectors=collectors, namespace=namespace, filter_spec=filter_spec)

    assert afc.collectors == collectors
    assert afc.namespace == namespace
    assert afc.filter_spec == filter_spec

# Generated at 2022-06-22 22:39:54.573649
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.dynamic
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.network
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.collector

    all_collector_classes = \
        ansible.module_utils.facts.collector.get_collector_classes()

    fact_collector = get_ansible_collector(all_collector_classes)

    assert fact_collector.collect(module=None, collected_facts=None)['gather_subset'] == ['all']

# Generated at 2022-06-22 22:39:58.163668
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='magic', module_setup=True)

    assert collector_meta_data_collector.gather_subset == 'magic'
    assert collector_meta_data_collector.module_setup is True
    assert collector_m

# Generated at 2022-06-22 22:40:01.216634
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(None, None, ['all'], True)
    fct = c.collect()
    assert fct == {'gather_subset': ['all'], 'module_setup': True}


# Generated at 2022-06-22 22:40:12.226387
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test no collectors, should return empty dict
    fact_collector = AnsibleFactCollector(collectors=[], namespace=None)
    assert fact_collector.collect() == {}

    # Test two collectors are collected
    # collector 1
    collector_1 = collector.BaseFactCollector(namespace=None)
    collector_1.collect_with_namespace = lambda module, collected_facts: {'key1': 1, 'key2': 2}
    # collector 2
    collector_2 = collector.BaseFactCollector(namespace=None)
    collector_2.collect_with_namespace = lambda module, collected_facts: {'key3': 3, 'key4': 4}
    fact_collector = AnsibleFactCollector(collectors=[collector_1, collector_2], namespace=None)
    assert fact_collector

# Generated at 2022-06-22 22:40:19.988667
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # create a mock namespace object with a prefix
    class MocNamespace:
        @staticmethod
        def get_prefix():
            return 'ansible_'

    mock_namespace = MocNamespace()
    mock_facts_dict = {'mock_fact': 'mock_value'}
    mock_filter_spec = 'mock_filter_spec'

    # create a mock collector object
    class MockCollector:
        def __init__(self):
            pass

        def collect_with_namespace(self, module=None, collected_facts=None):
            return mock_facts_dict

    # create a mock collector list, containing one mock collector
    mock_collector_classes = [MockCollector]
    mock_collector_list = [MockCollector()]

    # create AnsibleFactCollector,

# Generated at 2022-06-22 22:40:28.783518
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Create a custom namespace.
    prefix_fact_namespace = collector.PrefixFactNamespace(prefix='ansible_')
    collector_classes = [collector.NetworkAllInterfacesCollector]
    all_collector_classes = collector.AvailableCollectorClasses()
    fact_collector = get_ansible_collector(all_collector_classes,
                                           gather_subset='network',
                                           namespace=prefix_fact_namespace)
    facts = fact_collector.collect()
    assert facts['ansible_facts']['ansible_all_ipv4_addresses'] == ['127.0.0.1']

# Generated at 2022-06-22 22:40:32.923625
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    t1 = CollectorMetaDataCollector()
    assert t1.gather_subset == None
    assert t1.module_setup == None
    assert t1.collectors == None
    assert t1.namespace == None


# Generated at 2022-06-22 22:40:41.208293
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class MockCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'value1'}

    class MockCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'value2'}

    fact_collector = \
        AnsibleFactCollector(collectors=[MockCollector(), MockCollector2()])

    result = fact_collector.collect()
    assert result['ansible_facts']['test_fact'] == 'value1'
    assert result['ansible_facts']['test_fact2'] == 'value2'

# Generated at 2022-06-22 22:40:46.869531
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                                         module_setup=True)
    assert collector_meta_data_obj.gather_subset == ['all']
    assert collector_meta_data_obj.module_setup


# Generated at 2022-06-22 22:40:52.957191
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system.bsd

    fact_collector = get_ansible_collector(all_collector_classes=[ansible.module_utils.facts.system.bsd.BSDHardware],
                                           filter_spec=['ansible_product_name'])

    my_facts = fact_collector.collect()
    assert my_facts.has_key('ansible_product_name')
    assert len(my_facts['ansible_product_name']) > 0

# Generated at 2022-06-22 22:40:57.637169
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=False)
    assert collector_meta_data_collector.collect() == {'gather_subset': 'all', 'module_setup': False}

# Generated at 2022-06-22 22:41:02.152318
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # pylint: disable=undefined-variable
    fact_collector = get_ansible_collector(all_collector_classes=collector_fact_classes,
                                           namespace=ansible_collected_facts_namespace)
    # pylint: enable=undefined-variable

# Generated at 2022-06-22 22:41:05.425137
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_collector = CollectorMetaDataCollector(['all'], None)
    test_result = test_collector.collect()
    assert test_result == {'gather_subset': ['all']}


# Generated at 2022-06-22 22:41:14.870024
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit test
    '''
    import ansible.module_utils.facts.network.legacy as network_legacy
    import ansible.module_utils.facts.network.base as network_base

    class MyCollectorA(collector.BaseFactCollector):
        '''Mock Collector'''
        name = 'a'
        _fact_ids = set([])  # Note: sets must be hashable

    class MyCollectorB(collector.BaseFactCollector):
        '''Mock Collector'''
        name = 'b'
        _fact_ids = set([])  # Note: sets must be hashable

    class MyCollectorC(collector.BaseFactCollector):
        '''Mock Collector'''
        name = 'c'
        _fact_ids = set([])  # Note: sets must

# Generated at 2022-06-22 22:41:19.673226
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(['all'], True)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True


# Generated at 2022-06-22 22:41:28.806934
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import sys
    sys.path.append('/home/scotts/ansible/ansible/module_utils/facts/collector')
    #sys.path.append('/home/scotts/ansible/ansible/module_utils/facts')
    import ohai_collector
    from ansible.module_utils.facts.collector.bios import bios_collector
    from ansible.module_utils.facts.collector.config_file import config_file_collector
    from ansible.module_utils.facts.collector.cpu import cpu_collector
    from ansible.module_utils.facts.collector.date_time import date_time_collector
    from ansible.module_utils.facts.collector.distribution import distribution_collector

# Generated at 2022-06-22 22:41:40.837149
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''
    This is not a doctest because we cannot import module_utils.facts anywhere but the
    top level setup.py file.  Since we don't want to add the dependency on facts to
    ansible-base just yet, we will test this here.

    get_ansible_collector(all_collector_classes,
                          namespace=None,
                          filter_spec=None,
                          gather_subset=None,
                          gather_timeout=None,
                          minimal_gather_subset=None):

    all_collector_classes = ansible_module_utils.facts.FACT_COLLECTOR_CLASSES
    gather_subset = [all]
    '''

    from ansible.module_utils.facts import FACT_COLLECTOR_CLASSES


# Generated at 2022-06-22 22:41:46.602949
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True},\
        "CollectorMetaDataCollector's collect method returns wrong facts"

# Generated at 2022-06-22 22:41:50.960951
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.namespace as namespace

    # basic case
    ansible_fact_collector = AnsibleFactCollector()
    assert ansible_fact_collector.namespace is None

    # with namespace
    ansible_fact_collector = AnsibleFactCollector(namespace.PrefixFactNamespace(prefix='ansible_'))
    assert ansible_fact_collector.namespace == namespace.PrefixFactNamespace(prefix='ansible_')



# Generated at 2022-06-22 22:41:56.378970
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='all',
                                   module_setup=True)

    assert collector_meta_data_collector is not None
    assert collector_meta_data_collector.name == 'gather_subset'


# Generated at 2022-06-22 22:42:01.472465
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all',
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == 'all'
    assert facts['module_setup'] == True
    return


# Generated at 2022-06-22 22:42:08.634453
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """
    mocker.patch can only replace the methods of a class, not the class itself.
    So we need to patch the imported class "from ansible.module_utils.facts import collector" with a new class.
    After running the target method(AnsibleFactCollector.collect), the mock_collect_with_namespace will be called,
    and it returns a fact.
    """
    # Patch the "from ansible.module_utils.facts import collector" class to make the collector.BaseFactCollector be a mock class
    # The mock_collector_class is what being returned from the collector.BaseFactCollector()
    mock_collector_class = MagicMock(spec=collector.BaseFactCollector)
    mock_collector_class.collect_with_namespace.return_value = {'fact1':'value1'}

# Generated at 2022-06-22 22:42:18.020631
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespaces

    assert isinstance(ansible_collector, AnsibleFactCollector)

    # default namespace should be empty
    assert not ansible_collector.namespace

    # assuming that a namespace object is created, it should have prefix 'ansible_'
    ns = namespaces.PrefixFactNamespace(prefix='ansible_')
    ansible_collector = AnsibleFactCollector(collectors=None,
                                             filter_spec=None,
                                             namespace=ns)
    assert ansible_collector.namespace
    assert ansible_collector.namespace.prefix == 'ansible_'

# Generated at 2022-06-22 22:42:24.874080
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    ns = collector.PrefixFactNamespace(prefix='ansible_')
    fact_collector = \
        AnsibleFactCollector(collectors=[DistributionFactCollector(namespace=ns)],
                             namespace=ns,
                             filter_spec='ansible_distribution')

    assert 'ansible_facts' in fact_collector.collect()

# Generated at 2022-06-22 22:42:32.171789
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collector

    collector = get_ansible_collector(all_collector_classes=[ansible_collector.PlatformFactCollector,
                                                             default_collector.DistributionFactCollector],
                                      gather_subset=['!all', 'platform'],
                                      minimal_gather_subset=['all'])

    assert isinstance(collector, AnsibleFactCollector)
    assert len(collector.collectors) == 3

    # The metadata collector should be last
    assert isinstance(collector.collectors[2], CollectorMetaDataCollector)



# Generated at 2022-06-22 22:42:43.377101
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import unittest

    class CollectorMetaDataCollectorTestCase(unittest.TestCase):
        def test_initialization(self):
            o = CollectorMetaDataCollector()
            self.assertEqual(o.name, 'gather_subset')
            self.assertEqual(o._fact_ids, set())

            o = CollectorMetaDataCollector(gather_subset=['all'])
            self.assertEqual(o.name, 'gather_subset')
            self.assertEqual(o.gather_subset, ['all'])
            self.assertEqual(o._fact_ids, set())

            o = CollectorMetaDataCollector(module_setup=True)
            self.assertEqual(o.name, 'gather_subset')

# Generated at 2022-06-22 22:42:53.817875
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import json

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(TestCollector):
        name = 'test2'

    class TestCollectorWithError(TestCollector):
        name = 'test_with_error'

        def collect(self, module=None, collected_facts=None):
            raise Exception('test exception')

    # One collector
    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    facts_and_warnings = fact_collector.collect()
    assert(facts_and_warnings['ansible_facts'] == {'test_fact': 'test_value'})

   

# Generated at 2022-06-22 22:43:03.876051
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    all_collector_classes = cache.collector_classes()

    fact_collector = get_ansible_collector(all_collector_classes)
    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'gather_subset' in facts['ansible_facts']
    assert 'module_setup' in facts['ansible_facts']
    assert facts['ansible_facts']['gather_subset'] == ['all']
    assert facts['ansible_facts']['module_setup'] is True

    # inject a fake namespace, then collect again
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    namespace = PrefixFactNamespace(prefix='ansible_')
    fact_collector