

# Generated at 2022-06-22 22:33:00.223254
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_facts = CollectorMetaDataCollector().collect()
    assert meta_facts['gather_subset'] == ['all']


# Generated at 2022-06-22 22:33:11.827546
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.fact_cache
    import ansible.module_utils.facts.cmd
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    ansible_facts = {'dummy': 'dummy'}
    collectors = [ansible.module_utils.facts.cmd.CmdCollector(),
                  ansible.module_utils.facts.fact_cache.CacheableFactsCollector()]

    collector_obj = AnsibleFactCollector(collectors=collectors,
                                         namespace=PrefixFactNamespace(prefix='ansible_'))


# Generated at 2022-06-22 22:33:18.152013
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    module = None
    collected_facts = {}
    gather_subset = ['all']
    module_setup = True
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset, module_setup)
    meta_facts = collector_meta_data_collector.collect(module, collected_facts)
    assert 'gather_subset' in meta_facts
    assert 'module_setup' in meta_facts

# Generated at 2022-06-22 22:33:21.148671
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector(namespace='ansible.')
    assert fact_collector.namespace == 'ansible.'
    assert fact_collector.collectors is None

# Generated at 2022-06-22 22:33:29.493488
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''Tests CollectorMetaDataCollector constructor'''
    all_collector_classes = [CollectorSuffixFactNamespace, CollectorPrefixFactNamespace]

    # This should be the default configuration for 'gather_subset' and 'minimal_gather_subset'
    gather_subset = ['all']
    minimal_gather_subset = frozenset()

    # These classes should've been selected for gather_subset = ['all']
    collector_classes = set([collector.CollectorPrefixFactNamespace,
                             collector.CollectorSuffixFactNamespace])

    # This returns a list of Collector classes

# Generated at 2022-06-22 22:33:33.941342
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    obj = CollectorMetaDataCollector(gather_subset=['s1', 's2'],
                                     module_setup=False)
    assert obj.collect() == {'gather_subset': ['s1', 's2'], 'module_setup': False}

# Unit test

# Generated at 2022-06-22 22:33:40.459707
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # This test only works on Python 2.7 or greater (duplicate keyword detection)
    try:
        {}.update(a=1, a=2)
    except TypeError as e:
        if "duplicate keyword argument" in str(e):
            sys.exit(1)

    # The test is in unit/test_facts.py

# Generated at 2022-06-22 22:33:42.095048
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector()
    print(c.collect())

# Generated at 2022-06-22 22:33:52.006441
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ''' Unit test for function get_ansible_collector.

        This attempts to be isolated from other code in this file to
        make it easy to run this test and the results valid, even if
        other code in the file changes.
    '''
    import unittest
    import inspect
    import ansible.module_utils.facts.collectors

    # Inspect ansible.module_utils.facts.collectors to find classes
    collector_classes = inspect.getmembers(ansible.module_utils.facts.collectors,
                                           inspect.isclass)
    # don't use the base collector class
    collector_classes = filter(lambda n: n[0] != 'BaseFactCollector', collector_classes)
    # make a map of classname to class for easy lookup in collector_classes_from_subset

# Generated at 2022-06-22 22:33:58.027103
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_classes = []
    namespace = None
    gather_subset = None
    minimal_gather_subset = None
    module_setup = False
    fact_collector = \
        get_ansible_collector(all_collector_classes=collector_classes,
                              namespace=namespace,
                              gather_subset=gather_subset,
                              minimal_gather_subset=minimal_gather_subset,
                              module_setup=module_setup)
    assert fact_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:34:05.955086
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    module = None
    collected_facts = {}
    fact_collector = CollectorMetaDataCollector(collectors=None,
                                                namespace=None,
                                                gather_subset=['all'],
                                                module_setup=True)

    expected = {'gather_subset': ['all']}
    expected['module_setup'] = True
    result = fact_collector.collect(module, collected_facts)

    assert result == expected


# Generated at 2022-06-22 22:34:17.628531
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fake_collector_1 = object()
    fake_collector_2 = object()
    fake_collected_facts = {'fake_key': 'fake_value'}
    fake_module = object()

    fact_collector = \
        AnsibleFactCollector(collectors=[fake_collector_1, fake_collector_2],
                             namespace=None,
                             filter_spec=[])

    def collector_collect(collector_obj, module, collected_facts):
        assert module is fake_module
        assert collected_facts is fake_collected_facts
        if collector_obj == fake_collector_1:
            return {'collector_1': 'collector_1_results'}

# Generated at 2022-06-22 22:34:24.470843
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collectors = []
    namespace = None
    gather_subset = ['test_subset']
    module_setup = True
    coll_md_coll = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)
    module = None
    collected_facts = None
    result = coll_md_coll.collect(module, collected_facts)
    assert result == {'gather_subset': ['test_subset'], 'module_setup': True}

# Generated at 2022-06-22 22:34:30.621628
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=True)
    ansible_facts = fact_collector.collect()
    assert ansible_facts.get('gather_subset') == ['all']
    assert ansible_facts.get('module_setup') == True


# Generated at 2022-06-22 22:34:35.851882
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # test a simple fact collector
    fact_id = 'test_id'
    # no namespace
    fact1_collector = collector.BaseFactCollector(fact_id)
    # test with namespace
    fact2_collector = collector.BaseFactCollector(fact_id, namespace=fact_id)
    fact3_collector = collector.BaseFactCollector(fact_id, namespace=fact_id)
    fact_collector = AnsibleFactCollector(collectors=[fact1_collector, fact2_collector, fact3_collector])
    assert fact_collector


if __name__ == '__main__':
    test_AnsibleFactCollector()

# Generated at 2022-06-22 22:34:36.987663
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO: Unit test
    pass

# Generated at 2022-06-22 22:34:44.346968
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts import collector_classes

    gather_subset = ['all']
    module_setup = True

    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           gather_subset=gather_subset,
                                           module_setup=module_setup)
    # Note: we don't care about results. This test is mostly just to ensure
    # that the collector and metacollector were constructed properly.
    fact_collector.collect()

# Generated at 2022-06-22 22:34:52.537501
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)

    assert collector_meta_data_collector.gather_subset == 'all'

    assert not collector_meta_data_collector.collectors

    assert collector_meta_data_collector.name == 'gather_subset'

    assert collector_meta_data_collector._fact_ids == set([])

    assert collector_meta_data_collector.namespace == None

    assert collector_meta_data_collector.module_setup == True

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all', 'min'], module_setup=True)

    assert collector_meta_data_collector.gather_subset == ['all', 'min']

# Generated at 2022-06-22 22:34:57.418851
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all', '!network'],
                                                               module_setup=True)
    info_dict = collector_meta_data_collector.collect_with_namespace(collected_facts=dict())
    assert info_dict == {'ansible_gather_subset': ['all', '!network'],
                         'ansible_module_setup': True}

# Generated at 2022-06-22 22:35:04.487803
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all')
    assert collector_meta_data_collector.collect() == {'gather_subset': 'all'}
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='!all')
    assert collector_meta_data_collector.collect() == {'gather_subset': '!all'}

# Generated at 2022-06-22 22:35:15.717487
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    def test_collector_class(collector_id):
        class TestCollector(collector.BaseFactCollector):
            name = collector_id

            def collect(self, module=None, collected_facts=None):
                return {'test_collector_%s_value' % collector_id: collector_id}

        return TestCollector

    test_collector_1 = test_collector_class('collector_1')
    test_collector_2 = test_collector_class('collector_2')

    fact_collector = \
        AnsibleFactCollector(collectors=[test_collector_1(), test_collector_2()],
                             filter_spec=['*', 'test_collector_1*'])

    collected_facts = fact_collector.collect()

# Generated at 2022-06-22 22:35:23.862948
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # A fake set of collector classes for testing
    class Collector1(collector.BaseFactCollector):
        name = 'collector_1'
        def collect(self, module=None, collected_facts=None):
            return {'collected_by': ['collector_1']}

    class Collector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'collected_by': ['collector_2']}

    class Collector3(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'collected_by': ['collector_3']}

    class CollectorError(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            raise IO

# Generated at 2022-06-22 22:35:31.782157
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    # Test with gather_subset == all
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    assert collector_meta_data_collector.gather_subset == ['all']

    # Test with gather_subset == some subset
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['network', 'facter'])
    assert collector_meta_data_collector.gather_subset == ['network', 'facter']


# Generated at 2022-06-22 22:35:43.346215
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ac = AnsibleFactCollector(collectors=['foo', 'bar'])
    assert ac.collectors == ['foo', 'bar']
    assert ac.namespace is None

    # Now with a namespace
    ac = AnsibleFactCollector(collectors=['foo', 'bar'], namespace='ansible_')
    assert ac.collectors == ['foo', 'bar']
    assert ac.namespace == 'ansible_'

    # Now with a filter_spec
    ac = AnsibleFactCollector(collectors=['foo', 'bar'], namespace='ansible_', filter_spec=['facter*'])
    assert ac.collectors == ['foo', 'bar']
    assert ac.namespace == 'ansible_'
    assert ac.filter_spec == ['facter*']


# Generated at 2022-06-22 22:35:47.988270
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    fact_collector = AnsibleFactCollector(
        collectors=[],
        filter_spec=['foo.*'],
        namespace=collector.PrefixFactNamespace(prefix='ansible_')
    )

    assert fact_collector.is_valid()
    assert fact_collector.filter_spec == ['foo.*']
    assert fact_collector.namespace
    assert isinstance(fact_collector.namespace, collector.PrefixFactNamespace)


# Generated at 2022-06-22 22:35:52.314260
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collectors = get_ansible_collector(all_collector_classes=collector.collector_classes(),
                                       gather_subset=['hardware'],
                                       filter_spec='cpu*')
    facts = collectors.collect()

    assert len(facts) != 0
    assert 'cpu0' in facts

# Generated at 2022-06-22 22:36:03.483252
# Unit test for function get_ansible_collector

# Generated at 2022-06-22 22:36:10.555351
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset='all')
    facts = c.collect()
    assert(facts['gather_subset'] == 'all')
    assert('module_setup' in facts)
    assert(facts['module_setup'] is True)

    c = CollectorMetaDataCollector(gather_subset='all',
                                   module_setup=False)
    facts = c.collect()
    assert(facts['gather_subset'] == 'all')
    assert('module_setup' in facts)
    assert(facts['module_setup'] is False)



# Generated at 2022-06-22 22:36:15.251434
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gather_subset = ['all']
    module_setup = True
    assert CollectorMetaDataCollector(gather_subset=gather_subset, module_setup=module_setup).collect() == \
        {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:36:23.126802
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.system

    all_collector_classes = [ansible.module_utils.facts.collector.network.NetworkCollector,
                             ansible.module_utils.facts.collector.platform.PlatformCollector,
                             ansible.module_utils.facts.collector.virtual.VirtualCollector,
                             ansible.module_utils.facts.system.SystemCollector]

    filter_spec = []

    gather_subset = ['all']

    gather_timeout = 30

    minimal_gather_subset = frozenset

# Generated at 2022-06-22 22:36:29.192391
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    all_collector_classes = [('collector_linux', 'Linux', 'linux'),
                             ('collector_windows', 'Windows', 'windows')]

    gather_subset = ['all']

    fact_collector = CollectorMetaDataCollector(
        gather_subset=gather_subset,
        module_setup=True)
    facts = fact_collector.collect()

    assert facts['module_setup'] == True
    assert facts['gather_subset'] == gather_subset


# Generated at 2022-06-22 22:36:33.719898
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collectors import ansible_collector

    # Try to collect all facts
    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.all_collector_classes(),
                                           filter_spec=['*'],
                                           gather_subset=['all'])
    fact_dict = fact_collector.collect()
    assert 'ansible_facts' in fact_dict



# Generated at 2022-06-22 22:36:45.251386
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    gather_subset= 'all'
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
    assert collector_meta_data_collector.gather_subset == 'all'
    assert collector_meta_data_collector.name == 'gather_subset'
    assert collector_meta_data_collector.collectors == None

    collector_classes = []
    all_collector_classes = collector.collector_classes_from_gather_subset(
        all_collector_classes=collector_classes,
        minimal_gather_subset=frozenset(),
        gather_subset=['all'],
        gather_timeout=None
    )

    # Unit test that get_ansible_collector() can be invoked without any parameters.


# Generated at 2022-06-22 22:36:55.010297
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = [collector.DefaultFactCollector]
    namespace = 'ansible_'
    gather_subset = ['min', '!all']
    minimal_gather_subset = frozenset(['network'])
    gather_timeout = 30
    ansible_fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                                   namespace=namespace,
                                                   filter_spec=None,
                                                   gather_subset=gather_subset,
                                                   gather_timeout=None,
                                                   minimal_gather_subset=minimal_gather_subset)
    assert isinstance(ansible_fact_collector.gather_subset, str)
    assert ansible_fact_collector.gather_sub

# Generated at 2022-06-22 22:37:07.806005
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network

    filter_spec = filter_spec or []
    gather_subset = gather_subset or ['network']
    gather_subset = list(set(gather_subset))
    gather_facts_subset_collectors_names = \
        set(collector.collector_class_names_from_gather_subset(gather_subset))

    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=ansible.module_utils.facts.collector.network.__dict__.values(),
            minimal_gather_subset=['network'],
            gather_subset=gather_subset)
    print(collector_classes)
    collectors = []

# Generated at 2022-06-22 22:37:10.773770
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True


# Generated at 2022-06-22 22:37:15.763027
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector(gather_subset='all',
                                      module_setup=True)
    assert CollectorMetaDataCollector(gather_subset='!all',
                                      module_setup=False)
    assert CollectorMetaDataCollector(gather_subset='all,!module_setup',
                                      module_setup=True)

# Generated at 2022-06-22 22:37:23.668943
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no filter
    fact_collector = \
        AnsibleFactCollector(collectors=None,
                             filter_spec=None,
                             namespace=None)

    # Mock fact collector
    class MockFactCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['test1'] = 'test1'
            collected_facts['test2'] = None
            collected_facts['test3'] = "test3"
            collected_facts['test4'] = []
            collected_facts['test5'] = {'test5': 'test5'}
            return collected_facts

    mock_obj = MockFactCollector()
    fact_collector.add_collector(mock_obj)

   

# Generated at 2022-06-22 22:37:36.142691
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace as facnamespace
    import ansible.module_utils.facts.hardware as factcollector

    class TestBaseFactNamespace(facnamespace.BaseFactNamespace):
        def __init__(self, module, collected_facts={}):
            super(TestBaseFactNamespace, self).__init__(module)
            self.collected_facts = collected_facts

        def get_facts(self):
            return {'test_collector_key': {'test_ns': 'test_ns_val'}}

        def get_info(self, name=None):
            return {'test_collector_key': {'test_ns': 'test_ns_val'}}

        def filter_facts(self, facts):
            return facts


# Generated at 2022-06-22 22:37:40.053668
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # pylint: disable=unused-argument
    test_obj = CollectorMetaDataCollector(gather_subset=["test_value"], module_setup=True)
    result = test_obj.collect()
    assert result == {"gather_subset":["test_value"], "module_setup":True}

# Generated at 2022-06-22 22:37:41.642553
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO: Write a unit test for AnsibleFactCollector
    assert True is True

# Generated at 2022-06-22 22:37:47.301316
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_metadata_collector = \
        CollectorMetaDataCollector(
            collectors=None,
            namespace=None,
            gather_subset=['!all', 'test'],
            module_setup=True)

    assert test_metadata_collector.collect() == {'gather_subset': ['!all', 'test'], 'module_setup': True}


# Generated at 2022-06-22 22:37:48.305442
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Example unit test function.'''
    pass

# Generated at 2022-06-22 22:37:52.507589
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Test CollectorMetaDataCollector class.
       This method is called from unit_tests.
       AnsibleFactCollector(self, collectors=None, namespace=None)'''
    ansible_fact_collector = AnsibleFactCollector()
    assert isinstance(ansible_fact_collector, AnsibleFactCollector)



# Generated at 2022-06-22 22:37:53.393534
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-22 22:38:04.061043
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Mock the function get_all_collector_classes to return a list of class objects
    # for the test
    def get_all_collector_classes():
        def class1(collector):
            def collect(self, module=None, collected_facts=None):
                return {'class1': 'a'}
            return collect
        def class2(collector):
            def collect(self, module=None, collected_facts=None):
                return {'class2': 'b'}
            return collect
        return [class1, class2]
    global get_all_collector_classes
    get_all_collector_classes = get_all_collector_classes

    # Mock the function collector_classes_from_gather_subset to return a list of class objects
    # for the test

# Generated at 2022-06-22 22:38:14.749423
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [collector.FacterCollector,
                             collector.OhaiCollector]

    collecter_filters = ['facter_*', 'ohai_*']

    ansible_collector = get_ansible_collector(all_collector_classes,
                                              filter_spec=collecter_filters)

    # assert that it is an instance of AnsibleFactCollector
    assert isinstance(ansible_collector, AnsibleFactCollector)

    # assert that it has two collectors in it
    assert len(ansible_collector.collectors) == 2

    # assert that the collectors are FacterCollector and OhaiCollector
    assert isinstance(ansible_collector.collectors[0], collector.FacterCollector)

# Generated at 2022-06-22 22:38:22.230731
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import json

    class FakeCollector(collector.BaseFactCollector):

        def __init__(self):
            self.name = 'fake'

        def collect(self, module=None, collected_facts=None):
            return {'foo': True}

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='!all',
                                   module_setup=False)

    meta_facts = collector_meta_data_collector.collect()
    expected_meta_facts = \
        {"gather_subset": "!all", "module_setup": False}

    assert meta_facts == expected_meta_facts

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='!all')

    meta_facts = collector_meta_data_

# Generated at 2022-06-22 22:38:27.023214
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [
        cache.CacheFactCollector,
        network.NetworkFactCollector,
        system.SystemFactCollector,
        virtual.VirtualFactCollector
    ]

    namespace = 'ansible'
    filter_spec = ['*']
    gather_subset = ['min', 'hardware']
    gather_timeout = 10
    minimal_gather_subset = frozenset()


# Generated at 2022-06-22 22:38:39.052658
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''We create a CollectorMetaDataCollector object and check, if the object
       has the right property values.'''

    # We expect module_setup to default to None
    col_meta_coll = CollectorMetaDataCollector(collectors=None,
                                               namespace=None,
                                               gather_subset='all')
    assert col_meta_coll.module_setup is None

    # We expect module_setup to default to None
    col_meta_coll = CollectorMetaDataCollector(collectors=None,
                                               namespace=None,
                                               gather_subset='all',
                                               module_setup=True)
    assert col_meta_coll.module_setup is True

    # We expect module_setup to default to None

# Generated at 2022-06-22 22:38:50.144636
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # prepare mocks

    # Mock _filter
    import ansible.module_utils.facts.collector
    filter_spec_mock = []
    facts_dict_mock = {'a': 'A', 'b': 'B', 'ansible_c': 'C'}
    ansible.module_utils.facts.collector.AnsibleFactCollector._filter = lambda self, facts_dict, filter_spec: list(facts_dict.items()) if filter_spec == filter_spec_mock else []

    # Mock collect of BaseFactCollector
    class BaseFactCollectorMock(ansible.module_utils.facts.collector.BaseFactCollector):
        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors
            self.namespace = namespace

# Generated at 2022-06-22 22:38:53.915135
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector(collectors=[])
    module = None
    collected_facts = None
    expected_data = {}
    data = fact_collector.collect(module=module, collected_facts=collected_facts)
    assert data == expected_data


# Generated at 2022-06-22 22:38:58.609992
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors =[
        collector.NetworkCollector()
    ]
    namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')

    c = CollectorMetaDataCollector(collectors=collectors, namespace=namespace, gather_subset=['!all'])

    facts = c.collect()
    assert facts == {'gather_subset': ['!all']}, facts


# Generated at 2022-06-22 22:39:09.593002
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceCollector

    # pylint: disable=protected-access
    collector_ns = NamespaceCollector(namespace_prefix='my')
    collector = NetworkCollector(namespace=collector_ns)
    # pylint: disable=protected-access
    prefix_ns = PrefixFactNamespace(prefix='my_')
    collector = CollectorMetaDataCollector(collectors=[collector],
                                           gather_subset=['all'],
                                           namespace=prefix_ns)
    assert collector.gather_subset == ['all']

# Generated at 2022-06-22 22:39:16.178949
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts

    collector_meta_data_collector = \
        CollectorMetaDataCollector(namespace=ansible.module_utils.facts.namespace.BaseFactNamespace(),
                                   gather_subset=['all'])
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts['gather_subset'] == ['all']

# Generated at 2022-06-22 22:39:27.618333
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_classes = [collector.FacterFactCollector, collector.OhaiFactCollector]
    minimal_gather_subset = ['!all', '!min']
    gather_subset = ['all', '!non_existing_fact']
    gather_timeout = 10.0
    filter_facter = ['*']
    fact_collector = get_ansible_collector(collector_classes,
                                           minimal_gather_subset=minimal_gather_subset,
                                           gather_subset=gather_subset,
                                           gather_timeout=gather_timeout,
                                           filter_spec=filter_facter)

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors[0].__class__ == collector.OhaiFact

# Generated at 2022-06-22 22:39:30.925034
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True

# Generated at 2022-06-22 22:39:37.251094
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Ensure what happens when no namespace provided
    fact_collector = AnsibleFactCollector()
    assert fact_collector.namespace is None

    # Ensure what happens when namespace provided
    ansible_prefix_namespace = \
        fact_collector.namespace_class.PrefixFactNamespace(prefix="ansible_")
    fact_collector = AnsibleFactCollector(namespace=ansible_prefix_namespace)
    assert fact_collector.namespace is ansible_prefix_namespace



# Generated at 2022-06-22 22:39:39.261306
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO: create unit test for method collect of class AnsibleFactCollector
    pass

# Generated at 2022-06-22 22:39:47.155767
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='gather_subset',
                                   module_setup=True)
    assert collector_meta_data_collector.gather_subset == 'gather_subset'
    assert collector_meta_data_collector.module_setup is True
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == 'gather_subset'
    assert facts['module_setup'] is True

# Generated at 2022-06-22 22:39:57.461084
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class MockCollector1(collector.BaseFactCollector):
        _fact_ids = set(['from_MockCollector1'])

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {'from_MockCollector1': 1}

    class MockCollector2(collector.BaseFactCollector):
        _fact_ids = set(['from_MockCollector2'])

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {'from_MockCollector2': 2}

    fact_collector = \
        AnsibleFactCollector(collectors=[MockCollector1(), MockCollector2()])

    ansible_facts = fact_collector.collect

# Generated at 2022-06-22 22:40:09.379929
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.system as system

    collector_classes = [system.SystemCollector,
                         distribution.DistributionCollector]

    # NOTE: This is a functional test, not a unittest.
    # This test is for local testing only and not for submittal to the tests/ directory
    fact_collector = get_ansible_collector(collector_classes)
    facts_dict = fact_collector.collect()
    from pprint import pprint
    pprint(facts_dict)

    # test a subset of known fact keys
    fact_keys = facts_dict.keys()
    assert 'ansible_os_family' in fact_keys
    assert 'ansible_distribution' in fact_keys

# Generated at 2022-06-22 22:40:14.605504
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    # assert isinstance(collector_meta_data_collector, CollectorMetaDataCollector)
    assert collector_meta_data_collector.gather_subset == 'all'
    assert collector_meta_data_collector.module_setup == True


# Generated at 2022-06-22 22:40:19.445483
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collects = ['a', 'b', 'c']

    class TestCollector(collector.BaseFactCollector):
        name = 'TestCollector'


# Generated at 2022-06-22 22:40:22.148489
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    filter_spec = 'do*'

    fc = AnsibleFactCollector(filter_spec=filter_spec)

    assert fc.filter_spec == filter_spec


# Generated at 2022-06-22 22:40:26.446263
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import default_collectors
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.ALL_COLLECTOR_CLASSES)
    facts_dict = fact_collector.collect()
    assert facts_dict.get('ansible_system') is not None
    assert facts_dict.get('ansible_architecture') is not None

# Generated at 2022-06-22 22:40:37.008662
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector

    # Test various gather subset specs
    c1 = get_ansible_collector(all_collector_classes=[NetworkCollector, PlatformCollector],
                               gather_subset='network')
    assert(isinstance(c1.collectors[0], NetworkCollector))


# Generated at 2022-06-22 22:40:43.892838
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    test_collector = AnsibleFactCollector(filter_spec=['*'])
    assert test_collector.filter_spec == ['*']

    test_collector = AnsibleFactCollector(filter_spec='*')
    assert test_collector.filter_spec == '*'

    test_collector = AnsibleFactCollector(filter_spec='f*')
    assert test_collector.filter_spec == 'f*'

    test_collector = AnsibleFactCollector(filter_spec='*facts')
    assert test_collector.filter_spec == '*facts'


# Generated at 2022-06-22 22:40:53.782830
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # __init__(self, collectors=None, namespace=None, filter_spec=None):
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    filter_spec = {'ansible_eth0': 'ansible_eth0'}
    namespace = PrefixFactNamespace(prefix='foo_')
    fact_collector = AnsibleFactCollector(collectors=[NetworkCollector(namespace=namespace)],
                                          filter_spec=filter_spec,
                                          namespace=namespace)
    fc = fact_collector.collectors[0]
    assert isinstance(fc, NetworkCollector) is True
    assert len(fc.namespace) == len(namespace)

# Generated at 2022-06-22 22:41:04.169832
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Create an object of type CollectorMetaDataCollector
    meta_collector_obj = CollectorMetaDataCollector()

    # Create a dict to test if it is returned as a value with
    # key gather_subset in the returned dict
    gather_subset = {'all'}
    meta_collector_obj.gather_subset = gather_subset

    # Create a dict to test if it is returned as a value with
    # key module_setup in the returned dict
    module_setup = {'local'}
    meta_collector_obj.module_setup = module_setup

    # Call the collect method and assign it to a dict
    facts_dict = meta_collector_obj.collect()

    # If the dict returned by the collect method
    # doesn't have key gather_subset, then return error

# Generated at 2022-06-22 22:41:11.372403
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ''' This test validates the combination of arguments that get_ansible_collector() uses
        as inputs is handled as expected.
    '''
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import default

    all_collector_classes = [hardware.Hardware, system.SystemDetection, virtual.Virtual, network.Network, distribution.Distribution, default.Default]

    # Test 1:  all=False, gather_subset=['network'], all_subsets=['minimal', 'hardware', 'network', 'virtual']
    ansible_collector = get_

# Generated at 2022-06-22 22:41:21.979800
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    namespace = 'foo'
    name = 'gather_subset'
    gather_subset = ['network']
    module_setup = False
    meta_facts = {'gather_subset': gather_subset,
                  'module_setup': module_setup}

    # Create CollectorMetaDataCollector object
    collector_meta_data_collector = CollectorMetaDataCollector(namespace=namespace,
                                                               gather_subset=gather_subset,
                                                               module_setup=module_setup)

    # Compare expected metadata facts with actual facts
    assert collector_meta_data_collector.collect() == meta_facts


# Generated at 2022-06-22 22:41:26.419518
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    meta_data_fact_collector = CollectorMetaDataCollector(collectors=None, namespace=None, gather_subset=['all'], module_setup=True)
    meta_data_facts = meta_data_fact_collector.collect()
    assert meta_data_facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:41:33.803397
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestFactsDict1:

        name = 'fact_dict_1'

        @classmethod
        def collect(cls, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            info_dict = {'fact1': 'fact1_val', 'fact2': 'fact2_val', 'fact3': 'fact3_val'}
            collected_facts.update(info_dict.copy())
            return info_dict

    class TestFactsDict2:

        name = 'fact_dict_2'

        @classmethod
        def collect(cls, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            info_dict = {'fact4': 'fact4_val'}


# Generated at 2022-06-22 22:41:45.587963
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # mock 'ansible.module_utils.facts.collector.collector_classes_from_gather_subset()'
    # so that we can bypass the lengthy collector classes importing
    collector.collector_classes_from_gather_subset = \
        lambda *args, **kwargs: \
            [collector.BaseFactCollector, collector.BaseFactCollector]

    # mock 'ansible.module_utils.facts.collector.BaseFactCollector.collect()'
    # not to actually call real collection
    collector.BaseFactCollector.collect = \
        lambda *args, **kwargs: \
            {'fake_fact': 'fake value'}

    # None 'namespace' is expected by default
    fact_collector = AnsibleFactCollector()
    fact_collector.collect()
    assert fact_

# Generated at 2022-06-22 22:41:54.555053
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collect_meta_data_object = CollectorMetaDataCollector(gather_subset=[])
    # test with gather_subset option
    facts = collect_meta_data_object.collect()
    assert facts == {'gather_subset': []}

    collect_meta_data_object = CollectorMetaDataCollector(gather_subset=['all'])
    facts = collect_meta_data_object.collect()
    assert facts == {'gather_subset': ['all']}

    collect_meta_data_object = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = collect_meta_data_object.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

    collect_meta_data_object = Collector

# Generated at 2022-06-22 22:42:04.259544
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''A new collector is created with some facts that can be collected'''
    fact_namespace = collector.PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=fact_namespace)
    fact_collector.collectors = [
        collector.BaseFactCollector(namespace=fact_namespace),
        collector.BaseFactCollector(namespace=fact_namespace)
    ]
    facts = fact_collector.collect()
    assert facts
    assert len(facts) == 2
    assert facts['ansible_facts']['ansible_f1'] == 'v1'
    assert facts['ansible_facts']['ansible_f2'] == 'v2'


# Generated at 2022-06-22 22:42:17.563335
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Test for class AnsibleFactCollector.'''

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.aix.collectors import \
        AnsibleAIXDmidecode_Collector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.aix.collectors import \
        AnsibleAIXLscfg_Collector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.aix.collectors import \
        AnsibleAIXLsvpd_Collector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.aix.collectors import \
        AnsibleAIXPrdiag_Collector

# Generated at 2022-06-22 22:42:29.140173
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import DefaultFactCollector

    # test all collectors
    fact_collector = \
        AnsibleFactCollector(collectors=[DefaultFactCollector()],
                             namespace=None,
                             filter_spec=None)

    facts_dict = fact_collector.collect()

    assert 'ansible_all_ipv4_addresses' in facts_dict, \
        "Test with collectors=[DefaultFactCollector()] failed."

    # test empty facts collection
    fact_collector = \
        AnsibleFactCollector(collectors=[],
                             namespace=None,
                             filter_spec=None)

    facts_dict = fact_collector.collect()

    assert len(facts_dict) == 0, "Test with collectors=[] failed."

    # test with filter
    fact_collect

# Generated at 2022-06-22 22:42:41.834367
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector = CollectorMetaDataCollector()
    collector.collector_classes = []
    collector.collectors = []

    # None
    result = collector.collect()
    assert result == {'gather_subset': None}

    # gather_subset=None
    collector.gather_subset = None
    result = collector.collect()
    assert result == {'gather_subset': None}

    # gather_subset=''
    collector.gather_subset = ''
    result = collector.collect()
    assert result == {'gather_subset': ''}

    # gather_subset='all'
    collector.gather_subset = 'all'
    result = collector.collect()
    assert result == {'gather_subset': 'all'}

    # module_setup=False
    collector

# Generated at 2022-06-22 22:42:52.650078
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Testing the constructor, it should create a collector
    # with a namespace
    test_namespace = 'ansible'
    test_collector_name = 'test'
    test_filter_spec = []
    fact_collector = AnsibleFactCollector(namespace=test_namespace,
                                          filter_spec=test_filter_spec)
    # Test the collector
    # Test the namespace
    assert fact_collector.namespace == test_namespace
    assert test_namespace in fact_collector.namespace

    # Add a collector
    test_collector = CollectorMetaDataCollector(gather_subset=test_collector_name,
                                                module_setup=True)
    fact_collector.collectors.append(test_collector)
    # Test the data from the collector
    test_module

# Generated at 2022-06-22 22:43:03.325440
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.virtual.virtualbox
    import ansible.module_utils.facts.virtual.vmware
    import ansible.module_utils.facts.virtual.xen
    import ansible.module_utils.facts.virtual.zone

    klasses = []
    klasses += ansible.module_utils.facts.system.distribution.collector_classes
    klasses += ansible.module_utils.facts.system.pkg_mgr.collector_classes
    klasses += ansible.module_utils.facts.system.platform.collector_classes