

# Generated at 2022-06-22 22:33:06.831099
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               namespace=None,
                                                               module_setup=True)
    collector_meta_data_collector.collect()
    assert all([collector_meta_data_collector, collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}])


# Generated at 2022-06-22 22:33:09.696854
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    fact_collector = AnsibleFactCollector(collectors=[MockCollector()])
    facts = fact_collector.collect()
    assert facts == {'foo': 'bar'}



# Generated at 2022-06-22 22:33:22.328459
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector(collectors=[])

    # Case when there is no fact 'test1'
    filter_spec = ['test*']
    result = fact_collector._filter({'test2': 'value2'}, filter_spec)
    assert result == []

    # Case when there is a single fact 'test1'
    filter_spec = ['test*']
    result = fact_collector._filter({'test1': 'value1'}, filter_spec)
    assert result == [('test1', 'value1')]

    # Case when there are 2 facts 'test1' and 'test2'
    filter_spec = ['test*']
    result = fact_collector._filter({'test1': 'value1', 'test2': 'value2'}, filter_spec)

# Generated at 2022-06-22 22:33:27.758377
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    sys.modules['ansible'] = type('AnsibleModule', (object,), {})

    ge_fact_collector = collector.GenericExtrasFactCollector()

    # Test the constructor of AnsibleFactCollector
    assert AnsibleFactCollector() is not None
    assert AnsibleFactCollector([ge_fact_collector]) is not None
    assert AnsibleFactCollector(namespace=collector.GenericExtrasFactNamespace()) is not None


# Generated at 2022-06-22 22:33:35.831804
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    class SingleFactCollector(collector.BaseFactCollector):
        '''A trivial collector that provides one fact.'''
        name = 'single_fact'
        _fact_ids = ['a.b']

        def collect(self, module=None, collected_facts=None):
            return {'a': {'b': 1}}

    class SingleFactCollectorWithoutName(collector.BaseFactCollector):
        '''A trivial collector that provides one fact.'''
        _fact_ids = ['a.b']

        def collect(self, module=None, collected_facts=None):
            return {'a': {'b': 1}}

    class SingleFactCollectorAdditional(collector.BaseFactCollector):
        '''A trivial collector that provides one additional fact.'''
        name = 'single_fact_additional'
        _fact

# Generated at 2022-06-22 22:33:39.378489
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_facts = CollectorMetaDataCollector(gather_subset='all', module_setup=True).collect()
    assert meta_facts == {'gather_subset': 'all', 'module_setup': True}



# Generated at 2022-06-22 22:33:48.299155
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector.network import InterfacesFactCollector
    from ansible.module_utils.facts.collector.system import DistributionFactCollector
    from ansible.module_utils.facts.collector.system import PlatformFactCollector

    fact_collector = AnsibleFactCollector(collectors=[InterfacesFactCollector(), DistributionFactCollector(), PlatformFactCollector()], filter_spec=['interfaces', 'distribution', 'platform'])

    import json

    #print (json.dumps(fact_collector.collect(module=None, collected_facts=None), sort_keys=True, indent=4))


# Generated at 2022-06-22 22:33:53.027617
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    collector_meta_data_collector_facts = collector_meta_data_collector.collect()
    assert collector_meta_data_collector_facts['gather_subset'] == ['all']
    assert collector_meta_data_collector_facts['module_setup']

# Generated at 2022-06-22 22:33:59.966394
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts import ansible_collector
    fact_collector = ansible_collector.get_ansible_collector(
        all_collector_classes=None,
        namespace=None,
        filter_spec=None,
        gather_subset=['all'],
        gather_timeout=None,
        minimal_gather_subset=None)
    # print(dir(fact_collector))
    # print(fact_collector)
    # print(fact_collector.collectors)
    # print(fact_collector.collect())

# Generated at 2022-06-22 22:34:04.956295
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test = CollectorMetaDataCollector()
    assert test.name == 'gather_subset'
    assert not test._fact_ids
    assert not test.collectors
    assert not test.gather_subset
    assert not test.module_setup



# Generated at 2022-06-22 22:34:17.005500
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import system

    namespace_obj = ansible_collector.FactsNamespace()
    system_obj = system.SystemCollector(namespace=namespace_obj)
    fact_collector = \
        AnsibleFactCollector(collectors=[system_obj],
                             namespace=namespace_obj)
    facts_dict = fact_collector.collect()
    assert isinstance(facts_dict, dict)
    assert 'ansible_facts' in facts_dict
    assert isinstance(facts_dict['ansible_facts']['system'], dict)

    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')
    system_obj = system

# Generated at 2022-06-22 22:34:21.734481
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Grab all possible collectors
    all_collector_classes = collector.get_collector_classes()

    # Specify a filter_spec for facts
    filter_spec = ['*_interface*', 'dmi*']

    # Filter out some collectors - the remaining are dependent on the minimal_gather_subset
    gathered_collector_names = ['default', 'virtual', 'network']

    # Create a fact collector with a namespace, filter_spec and gather_subset
    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=filter_spec,
                                           gather_subset=gathered_collector_names)

# Generated at 2022-06-22 22:34:32.519034
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Test to get a collector with all defaults.
    fact_collector = get_ansible_collector(all_collector_classes=[])
    assert fact_collector.collectors
    assert len(fact_collector.collectors) == 1

    # Test to get a collector with a gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           gather_subset=['foo'])
    assert fact_collector.collectors
    assert len(fact_collector.collectors) == 2

    # Test to get a collector with a filter
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           filter_spec=['foo'])
    assert fact_collector.collectors

# Generated at 2022-06-22 22:34:40.104225
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                               module_setup=True)
    metadata = collector_obj.collect(module=None, collected_facts=None)
    assert metadata == {'gather_subset': ['all'], 'module_setup': True}


if __name__ == '__main__':
    test_CollectorMetaDataCollector_collect()

# Generated at 2022-06-22 22:34:46.579073
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    collectors = [ collector.BaseFactCollector(namespace=None),
                   collector.BaseFactCollector(namespace=PrefixFactNamespace('ansible_')) ]

    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=None)

    assert fact_collector.collectors == collectors
    assert fact_collector.filter_spec == None



# Generated at 2022-06-22 22:34:51.783284
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector

    assert isinstance(get_ansible_collector(all_collector_classes=ansible.module_utils.facts.collector.FACT_COLLECTORS),
                      AnsibleFactCollector)

    # Test that the CollectorMetaDataCollector is present
    assert 'gather_subset' in get_ansible_collector(all_collector_classes=ansible.module_utils.facts.collector.FACT_COLLECTORS).collect()

# Generated at 2022-06-22 22:35:02.130939
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(gather_subset='all')
    assert c.gather_subset == ['all']
    assert c.module_setup is None

    c = CollectorMetaDataCollector(gather_subset=None, module_setup=True)
    assert c.gather_subset == ['all']
    assert c.module_setup == True

    c = CollectorMetaDataCollector(gather_subset=['network'], module_setup=False)
    assert c.gather_subset == ['network']
    assert c.module_setup == False

    c = CollectorMetaDataCollector(gather_subset=['ansible_network'], module_setup=False)
    assert c.gather_subset == ['ansible_network']
    assert c.module_setup == False

# Generated at 2022-06-22 22:35:05.709461
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all']}



# Generated at 2022-06-22 22:35:10.076579
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=["a", "b"], module_setup=True)
    c.collect()
    assert c.name == 'gather_subset'
    assert c.gather_subset == ["a", "b"]
    assert c.module_setup == True

# Generated at 2022-06-22 22:35:14.491717
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import collector

    meta_data_collector = collector.CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert meta_data_collector.collect() == {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-22 22:35:21.377092
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    all_collector_classes = [collector.NetworkInterfaceFactCollector,
                             collector.LocalNamespaceCollector]

    filters = ['ansible_eth*']

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              filter_spec=filters)

    collected_facts = fact_collector.collect(module=None,
                                             collected_facts={})

    assert(collected_facts is not None)
    assert('ansible_eth0' in collected_facts)
    assert('ansible_eth1' in collected_facts)

# Generated at 2022-06-22 22:35:26.029809
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network

    # Create a list of collectors that will be passed to AnsibleFactCollector
    collectors = [
        ansible.module_utils.facts.collector.network.NetworkCollector()
    ]

    # Create an instance of AnsibleFactCollector
    ansible_fact_collector = AnsibleFactCollector(collectors)

    # Run the collect method
    result = ansible_fact_collector.collect()

    # The key 'default_ipv4' should exist in the resulting dict
    assert 'default_ipv4' in result


# Generated at 2022-06-22 22:35:35.216019
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.test_collector import TestFactCollector
    from ansible.module_utils.facts.test_collector2 import TestFactCollector2
    from ansible.module_utils.facts.test_collector3 import TestFactCollector3

    fact_collector = AnsibleFactCollector(
        collectors=[TestFactCollector(namespace=PrefixFactNamespace(prefix='test_')),
                    TestFactCollector2(namespace=PrefixFactNamespace(prefix='test_')),
                    TestFactCollector3(namespace=PrefixFactNamespace(prefix='test_'))]
    )

    collected_facts = {'test_foo_fact': 'bar'}

    facts = fact_collector

# Generated at 2022-06-22 22:35:45.095567
# Unit test for function get_ansible_collector

# Generated at 2022-06-22 22:35:54.943305
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['test'] = 42
            collected_facts[self.namespace.fqdn + 'test'] = 42
            return collected_facts

    test_collector = TestCollector()
    ansible_fact_collector = AnsibleFactCollector(collectors=[test_collector], namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    facts = ansible_fact_collector.collect()
    assert(facts['test'] == 42)

# Generated at 2022-06-22 22:36:02.807041
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    minimal_gather_subset = ['ansible_local', 'ansible_mountpoints']

    # default parameter values
    c1 = CollectorMetaDataCollector()

    # some values
    c2 = CollectorMetaDataCollector(gather_subset=minimal_gather_subset,
                                    module_setup=True)

    result1 = c1.collect()
    result2 = c2.collect()
    
    assert result1 == ['all']
    assert result2 == minimal_gather_subset
    assert result1 != result2

# Generated at 2022-06-22 22:36:09.280339
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import namespace, collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):

        name = 'test_collector'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    # Create a CollectorNamespace
    ns = namespace.PrefixFactNamespace(prefix='namespace_')

    # Create a AnsibleFactCollector with a list of collectors
    test_collector = TestCollector(namespace=ns)
    fact_collector = ansible_collector.AnsibleFactCollector(collectors=[test_collector],
                                                             filter_spec=[],
                                                             namespace=ns)

   

# Generated at 2022-06-22 22:36:20.501678
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FakeCollector1(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'f1': 'v1'}

    class FakeCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'f2': 'v2'}

    class FakeCollector3(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'ansible_f3': 'v3'}

    class FakeCollector4(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'f4': 'v4'}


# Generated at 2022-06-22 22:36:24.197785
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector()
    expected_dict = {'gather_subset': 'all'}
    response = fact_collector.collect()
    assert response == expected_dict


# Generated at 2022-06-22 22:36:32.800533
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import LegacyCollector, FallbackCollector
    from ansible.module_utils.facts.default import BaseFactNamespace
    prefix = 'ansible_'
    namespace = PrefixFactNamespace(prefix=prefix)

    # Create a collecter with no namespaces
    collector_1 = BaseFactCollector()

    # Create a collector with namespace
    collector_2 = BaseFactCollector(namespace=namespace)

    # Create a collector with a namespace
    collector_3 = BaseFactCollector(namespace=BaseFactNamespace())

    collectors = [collector_1, collector_2, collector_3]

    fact_

# Generated at 2022-06-22 22:36:44.070790
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.platform.linux

    x = get_ansible_collector(all_collector_classes=[ansible.module_utils.facts.platform.linux.LinuxHardware],
                              filter_spec=['ansible_processor'],
                              gather_subset=['all'],
                              gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                              minimal_gather_subset=frozenset())

    facts = x.collect()

    assert len(facts.keys()) == 2
    assert 'ansible_processor' in facts
    assert 'gather_subset' in facts
    assert facts['gather_subset'] == ['all']



# Generated at 2022-06-22 22:36:53.498061
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_metadata_collector = CollectorMetaDataCollector(gather_subset=['all', 'network'])
    results = collector_metadata_collector.collect()
    assert results == {'gather_subset': ['all', 'network']}

    # Test without gather_subset
    collector_metadata_collector = CollectorMetaDataCollector()
    results = collector_metadata_collector.collect()
    assert results == {'module_setup': True}

    # Test without module_setup
    collector_metadata_collector = CollectorMetaDataCollector(gather_subset=['all', 'network'])
    results = collector_metadata_collector.collect()
    assert results == {'gather_subset': ['all', 'network']}

# Generated at 2022-06-22 22:37:07.022730
# Unit test for constructor of class AnsibleFactCollector

# Generated at 2022-06-22 22:37:18.517614
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    def collect_function():
        return {'fact1': 'key1', 'fact2': 'key2', 'fact3': 'key3'}

    def collect_function_returning_dict(module=None, collected_facts=None):
        return collect_function()

    # Only fact1 is filtered out
    fact_collector = \
        AnsibleFactCollector(collectors=[collector.BaseFactCollector('fact_name',
                                                                     collect_function=collect_function_returning_dict)],
                             filter_spec=['fact1'])
    facts = fact_collector.collect()
    assert facts == {'fact2': 'key2', 'fact3': 'key3'}

    # This is a test case for covering the '*' case where filter spec is
    # ['*'], i.e.,

# Generated at 2022-06-22 22:37:29.065373
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Test constructor
    collector_obj = AnsibleFactCollector()
    assert collector_obj.collectors is None
    assert collector_obj.namespace is None

    # Test constructor with a namespace
    collector_obj = AnsibleFactCollector(namespace=collector.PrefixFactNamespace(prefix='ansible_'))
    assert collector_obj.collectors is None
    assert collector_obj.namespace.prefix == 'ansible_'

    # Test constructor with collectors and namespace
    collector_obj = AnsibleFactCollector(collectors=[collector.FacterFactCollector()],
                                         namespace=collector.PrefixFactNamespace(prefix='ansible_'))
    assert collector_obj.collectors[0].name == 'facter'
    assert collector_obj.namespace.prefix == 'ansible_'


# Unit

# Generated at 2022-06-22 22:37:37.174507
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['minimal', 'hardware', 'network', 'virtual'],
                                   module_setup=True)
    assert collector_meta_data_collector.collect(collected_facts=None) == \
        {'gather_subset': ['minimal', 'hardware', 'network', 'virtual'], 'module_setup': True}



# Generated at 2022-06-22 22:37:48.174830
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.collector import collector_name_list, get_collector_classes
    namespace = None
    filter_spec = None

    # filter_spec is None
    fact_collector = \
        AnsibleFactCollector(collectors=collector_name_list,
                             namespace=namespace)
    assert fact_collector.filter_spec == '*'

    # filter_spec is a string
    fact_collector = \
        AnsibleFactCollector(collectors=collector_name_list,
                             namespace=namespace,
                             filter_spec='ansible_*')
    assert fact_collector.filter_spec == 'ansible_*'

    # filter_spec is a list

# Generated at 2022-06-22 22:37:53.480022
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    collectors = None
    namespace = None
    gather_subset = ['all', 'network']
    module_setup = True

    fact_collector = \
        CollectorMetaDataCollector(collectors=collectors, namespace=namespace,
                                   gather_subset=gather_subset, module_setup=module_setup)

    assert fact_collector.gather_subset == gather_subset
    assert fact_collector.module_setup == module_setup


# Generated at 2022-06-22 22:38:01.363621
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gather_subset = ['all']
    module_setup = True
    meta_facts = {
        'gather_subset': gather_subset,
        'module_setup': module_setup
    }
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=module_setup)
    result_facts = collector_meta_data_collector.collect()
    assert result_facts == meta_facts

# Generated at 2022-06-22 22:38:05.851863
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    obj = CollectorMetaDataCollector(gather_subset=['!all'], module_setup=True)
    assert obj.gather_subset == ['!all']
    assert obj.module_setup is True

# Generated at 2022-06-22 22:38:14.252035
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Test class constructor'''

    # Simple: no collectors
    fact_collector = AnsibleFactCollector()
    assert fact_collector.collectors == []

    # One collector
    dummy_collector = collector.BaseFactCollector()
    fact_collector = AnsibleFactCollector(collectors=[dummy_collector])
    assert fact_collector.collectors == [dummy_collector]

    # two collectors
    fact_collector = AnsibleFactCollector(collectors=[dummy_collector,
                                                      dummy_collector])
    assert fact_collector.collectors == [dummy_collector, dummy_collector]

# Generated at 2022-06-22 22:38:21.701361
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           minimal_gather_subset=['facter'],
                                           gather_subset=['all'])

    fact_dict = fact_collector.collect()

    assert set(fact_dict.keys()) == {'facter', 'gather_subset', 'module_setup'}
    ns_prefix = PrefixFactNamespace.get_prefix()
    assert set(fact_dict[ns_prefix + 'facter'].keys()) == {'facter', 'gather_subset', 'module_setup'}

# Generated at 2022-06-22 22:38:33.028974
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import unittest

    class TestCollectorMetaDataCollector(unittest.TestCase):
        def test_collect(self):
            c = CollectorMetaDataCollector(gather_subset='all', module_setup=False)
            self.assertEqual(c.name, 'gather_subset')
            self.assertEqual(c.gather_subset, 'all')
            self.assertEqual(c.module_setup, False)
            self.assertEqual(c.collect(), {'gather_subset': 'all'})
            c = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
            self.assertEqual(c.name, 'gather_subset')
            self.assertEqual(c.gather_subset, 'all')
            self

# Generated at 2022-06-22 22:38:42.240845
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    namespace = PrefixFactNamespace(prefix='ansible_')

    # Basic Unit test
    fact_collector = get_ansible_collector(all_collector_classes=[BaseFactCollector],
                                           gather_subset=[])
    assert len(fact_collector.collectors) == 1

    fact_collector = get_ansible_collector(all_collector_classes=[BaseFactCollector],
                                           minimal_gather_subset=['all'],
                                           gather_subset=[])
    assert len(fact_collector.collectors)

# Generated at 2022-06-22 22:38:51.788638
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_default_facts
    from ansible.module_utils.facts import default_collectors

    filter_spec = ['ansible_processor', 'ansible_architecture']
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.AnsibleDefaultFactNamespace(),
                                           filter_spec=filter_spec)
    facts = fact_collector.collect()

    assert(facts['ansible_processor'] != '')
    assert(facts['ansible_architecture'] != '')

    assert(facts['ansible_distribution'] == '')

# Generated at 2022-06-22 22:38:57.940323
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # setup test
    class CollectTest(collector.BaseFactCollector):
        name = 'TestCollector'
        _fact_ids = set(['test_fact'])

        def __init__(self, module=None):
            super(CollectTest, self).__init__(module=module)

        def collect(self):
            return {'test_fact': 'test_value'}

    test_collector = CollectTest()
    test_collectors = [test_collector]

    test_collected_facts = {}
    # test with no filter
    test_collector = AnsibleFactCollector(collectors=test_collectors)
    test_result = test_collector.collect(collected_facts=test_collected_facts)
    assert test_result.keys() == set(['test_fact'])


# Generated at 2022-06-22 22:39:08.900717
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.utils
    ansible_collector = get_ansible_collector(
        all_collector_classes=ansible.module_utils.facts.utils.all_collector_classes,
        gather_subset=['!all', 'min'],
        minimal_gather_subset=['facter'],
        filter_spec=['ansible_*', 'facter*'],
        gather_timeout=15)

    assert isinstance(ansible_collector, AnsibleFactCollector)

    # All collectors are not default namespaced
    for c in ansible_collector.collectors:
        assert isinstance(c, collector.BaseFactCollector)
        assert c.namespace is None

# Generated at 2022-06-22 22:39:21.234908
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Unit test for constructor of class AnsibleFactCollector'''
    # test name attribute inherited from BaseFactCollector initialized properly
    collector_obj = AnsibleFactCollector()
    assert collector_obj.name == 'ansible'
    assert collector_obj.collectors == []
    assert collector_obj.namespace is None
    assert collector_obj.filter_spec is None

    # test no namespace
    collector_obj = AnsibleFactCollector(namespace=namespace.NoNamespace())
    assert collector_obj.name == 'ansible'
    assert collector_obj.collectors == []
    assert collector_obj.namespace is namespace.NoNamespace()
    assert collector_obj.filter_spec is None

    # test prefix namespace

# Generated at 2022-06-22 22:39:25.496795
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(collectors=None, namespace=None, gather_subset=None, module_setup=None)
    res = c.collect(module=None, collected_facts=None)
    assert res == {'gather_subset': None}

# Generated at 2022-06-22 22:39:27.380502
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """
    Unit test for method collect of class AnsibleFactCollector.
    """
    pass


# Generated at 2022-06-22 22:39:35.004912
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_fqdn_fact
    from ansible.module_utils.facts import ansible_all_ipv4_addresses as ansible_ipv4
    from ansible.module_utils.facts import ansible_all_ipv6_addresses as ansible_ipv6
    all_collector_classes = \
        [ansible_fqdn_fact.FqdnFactCollector,
         ansible_ipv4.IPv4FactCollector,
         ansible_ipv6.IPv6FactCollector]
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])

# Generated at 2022-06-22 22:39:43.119174
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=collector.ALL_COLLECTOR_CLASSES,
            minimal_gather_subset=timeout.MINIMAL_GATHER_SUBSET,
            gather_subset=['all'],
            gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT)

    collector_obj = \
        get_ansible_collector(all_collector_classes=all_collector_classes)

    assert isinstance(collector_obj, AnsibleFactCollector)
    assert collector_obj.namespace is None
    assert collector_obj.filter_spec is None

    # Test filter_spec

# Generated at 2022-06-22 22:39:47.265599
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector = CollectorMetaDataCollector(gather_subset=['all'])

    gathered_facts = collector.collect()

    assert gathered_facts['gather_subset'] == ['all']
    assert 'module_setup' in gathered_facts



# Generated at 2022-06-22 22:39:48.289112
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    pass

# Generated at 2022-06-22 22:39:58.006994
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import LocalFactsCollector, NetworkFactsCollector

    class MockFactCollector1(collector.BaseFactCollector):
        def __init__(self, namespace=None):
            super(MockFactCollector1, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'a': 1}

    class MockFactCollector2(collector.BaseFactCollector):
        def __init__(self, namespace=None):
            super(MockFactCollector2, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'b': 2}


# Generated at 2022-06-22 22:40:10.001666
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import amd
    from ansible.module_utils.facts import blockdevices
    from ansible.module_utils.facts import docker
    from ansible.module_utils.facts import ohai
    from ansible.module_utils.facts import system

    mock_module = None
    mock_collected_facts = None

    amd_collector = amd.AmdFactCollector(namespace=None)
    blockdevices_collector = blockdevices.BlockDevicesFactCollector(namespace=None)
    docker_collector = docker.DockerFactCollector(namespace=None)
    ohai_collector = ohai.OhaiFactCollector(namespace=None)
    system_collector = system.SystemFactCollector(namespace=None)


# Generated at 2022-06-22 22:40:15.748772
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gather_subset = 'facter'
    module_setup = True
    c = CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=module_setup)

    assert module_setup == c.module_setup

    gathered_facts = c.collect()

    assert gather_subset == gathered_facts['gather_subset']
    assert module_setup == gathered_facts['module_setup']





# Generated at 2022-06-22 22:40:22.602876
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    facts = c.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

    c = CollectorMetaDataCollector(gather_subset=['all'])
    facts = c.collect()
    assert facts == {'gather_subset': ['all']}

# Generated at 2022-06-22 22:40:34.402605
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Test 1: minimal_gather_subset specified, only minimal gather subset created as collectors,
    #         even though all gather_subset requested.
    all_collector_classes = collector.get_collector_classes()
    f = get_ansible_collector(namespace=object(),
                              all_collector_classes=all_collector_classes,
                              gather_subset=['all'],
                              minimal_gather_subset=['ohai'])

    assert isinstance(f, AnsibleFactCollector)
    assert len(f.collectors) == 1  # does not include metadata collector

    # Test 2: no minimal_gather_subset specified, all classes for all gather_subset requested
    # created as collectors
    all_collector_classes = collector.get_collector_classes()
   

# Generated at 2022-06-22 22:40:40.060577
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Test 1. Check if CollectorMetaDataCollector produces correct output.
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'])
    output_dict = \
        collector_meta_data_collector.collect(module=None,
                                              collected_facts=None)
    expected_output_dict = {'gather_subset': ['all']}
    assert output_dict == expected_output_dict


# Generated at 2022-06-22 22:40:47.667808
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    fact_collector = get_ansible_collector(all_collector_classes=['ansible.module_utils.facts.collector.DummyFactCollector'],
                                           namespace='ansible_test')
    assert fact_collector.__class__.__name__ == 'AnsibleFactCollector'
    assert fact_collector.namespace == 'ansible_test'

    facts = fact_collector.collect()
    assert 'ansible_test_dummy_1' in facts
    assert 'ansible_test_dummy_2' in facts
    assert 'ansible_test_dummy_3' in facts


# Generated at 2022-06-22 22:40:54.308394
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default

    # Test a normal set of inputs with a default namespace
    fact_collector = \
        get_ansible_collector(all_collector_classes=default.collector_classes,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None,
                              namespace=None)

    assert(isinstance(fact_collector, AnsibleFactCollector))
    assert(fact_collector.filter_spec is None)
    assert(fact_collector.collectors)

# Generated at 2022-06-22 22:41:04.462249
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import network, virtual
    import ansible.module_utils.facts.collector.ansible_local

    # Get default collector
    collector = get_ansible_collector({'network': network.NetworkCollector,
                                       'virtual': virtual.VirtualCollector,
                                       'ansible_local': ansible.module_utils.facts.collector.ansible_local.AnsibleLocalCollector,
                                       'collector_metadata': CollectorMetaDataCollector},
                                      namespace=None,
                                      gather_timeout=1000)

    results = collector.collect()

    assert 'ansible_all_ipv4_addresses' in results
    assert results['ansible_all_ipv4_addresses'] is not None

# Generated at 2022-06-22 22:41:14.050303
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    test_collector1 = collector.BaseFactCollector(namespace='test1_')
    test_collector2 = collector.BaseFactCollector(namespace='test2_')
    test_collectors = [test_collector1, test_collector2]
    test_facts = {'facts1': 'facts1', 'facts2': 'facts2'}

    def fake_collect(self, module, collected_facts):
        return {'facts1': 'facts1', 'facts2': 'facts2'}

    test_collector1.collect_with_namespace = fake_collect
    test_collector2.collect_with_namespace = fake_collect

    test_instance = AnsibleFactCollector(collectors=test_collectors, namespace='test_')

    result = test_instance.collect()


# Generated at 2022-06-22 22:41:19.586983
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = [CollectorMetaDataCollector(gather_subset='all')]
    assert collectors[0].gather_subset == 'all'
    for collector in collectors:
        assert collector.gather_subset == 'all'
        assert collector.module_setup == True


# Generated at 2022-06-22 22:41:23.781368
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(collectors='',
                                                               namespace='',
                                                               gather_subset=[],
                                                               module_setup=None)
    assert collector_meta_data_collector.name == 'gather_subset'

# Generated at 2022-06-22 22:41:32.636760
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.base
    import ansible.module_utils.facts.utils
    gc = get_ansible_collector(all_collector_classes=[ansible.module_utils.facts.system.base.BaseFactCollector],
                               namespace=ansible.module_utils.facts.utils.PrefixFactNamespace(prefix='ansible_'),
                               filter_spec=['ansible_*'],
                               gather_subset=['all'],
                               gather_timeout=10,
                               minimal_gather_subset=['all'])
    gc_facts = gc.collect(module=None, collected_facts=None)
    assert 'ansible_facts' in gc_facts

# Generated at 2022-06-22 22:41:39.216638
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],module_setup=True)
    assert collector_meta_data_collector is not None
    assert collector_meta_data_collector.name == 'gather_subset'
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True

# Generated at 2022-06-22 22:41:41.048168
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    fact_collector = AnsibleFactCollector()
    assert fact_collector.filter_spec is None

# Generated at 2022-06-22 22:41:42.458034
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert AnsibleFactCollector

# Generated at 2022-06-22 22:41:48.204225
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts import namespace

    fact_collector = AnsibleFactCollector(collectors=[],
                                          namespace=namespace.AnsiblePrefixFactNamespace())
    assert fact_collector is not None
    assert not fact_collector.collectors
    assert fact_collector.namespace is not None
    assert not fact_collector.filter_spec



# Generated at 2022-06-22 22:41:55.987442
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    gather_subset = ['all']
    filter_spec = []

    class TestCollector1(BaseFactCollector):
        '''A class to test get_ansible_collector().'''

        name = 'test1'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test1_fact': True}

    class TestCollector2(BaseFactCollector):
        '''A class to test get_ansible_collector().'''

        name = 'test2'
        _fact_ids = set([])


# Generated at 2022-06-22 22:42:05.582394
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace

    collectors = [
        collector.fact_collector_cls(namespace=namespace.PrefixNamespace(prefix='a_')),
        collector.fact_collector_cls(namespace=namespace.PrefixNamespace(prefix='b_')),
        collector.fact_collector_cls(namespace=namespace.PrefixNamespace(prefix='c_'))
    ]

    fact_collector = AnsibleFactCollector(collectors=collectors)

    module = None
    collected_facts = fact_collector.collect(module=module)

    assert 'a_facts' in collected_facts
    assert 'b_facts' in collected_facts
    assert 'c_facts' in collected_facts

# Generated at 2022-06-22 22:42:17.638726
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector
    from ansible.module_utils.facts.system.platform import PlatformCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.virtual.virt_what import VirtWhatCollector

    # specify an order of collectors that would be found by module loader
    all_collector_classes = [
        PlatformCollector,
        PkgMgrCollector,
        DistributionCollector,
        VirtWhatCollector,
        NetworkCollector,
    ]

    gather_subset = ['all', '!facter', '!ohai', 'network', 'virtual']
    gather_timeout = 10

# Generated at 2022-06-22 22:42:21.897180
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # TODO: Add some test here
    # NOTE: We need to find a way to pass a test module to the constructors, which
    # is required by the BaseFactCollector.
    pass



# Generated at 2022-06-22 22:42:31.295181
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.darwin import DarwinHardwareInfo
    from ansible.module_utils.facts.linux import DistributionInfo, DistributionFilesystemInfo, LinuxHardwareInfo

    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    all_collector_classes = set([DarwinHardwareInfo.__name__,
                                 DistributionInfo.__name__,
                                 DistributionFilesystemInfo.__name__,
                                 LinuxHardwareInfo.__name__])
    minimal_gather_subset = frozenset()
    filter_spec = []


# Generated at 2022-06-22 22:42:43.044932
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector

    fact_namespace = namespaces.PrefixFactNamespace(prefix='ansible_',
                                                    fact_namespace=namespaces.FactNamespace())

    ansible_collector = CollectorMetaDataCollector(namespace=fact_namespace,
                                                   gather_subset=['all', 'network'],
                                                   module_setup=True)

    ansible_facts = ansible_collector.collect()
    assert ansible_facts['ansible_gather_subset'] == ['all', 'network']
    assert ansible_facts['ansible_module_setup'] is True


# Generated at 2022-06-22 22:42:45.532748
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ''' Ensure we can construct an AnsibleFactCollector() '''
    x = AnsibleFactCollector()
    assert x is not None


# Generated at 2022-06-22 22:42:55.263835
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors as def_coll
    import ansible.module_utils.facts.namespace as ns

    coll = get_ansible_collector(def_coll.get_collector_classes())
    assert coll.__class__ == AnsibleFactCollector
    assert coll.namespace == None
    assert len(coll.collectors) == len(def_coll.get_collector_classes()) + 1
    assert isinstance(coll.collectors[0], def_coll.NetworkFactCollector)

    coll = get_ansible_collector(def_coll.get_collector_classes(),
                                 namespace=ns.DefaultFactNamespace())
    assert coll.__class__ == AnsibleFactCollector
    assert coll.namespace.__class__ == ns.DefaultFactNamespace

# Generated at 2022-06-22 22:42:57.177745
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    f = AnsibleFactCollector()
    assert f

# Generated at 2022-06-22 22:42:57.921636
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass



# Generated at 2022-06-22 22:42:59.952959
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_obj = CollectorMetaDataCollector(["test_collector","test_collector2"], "test_namespace", "test_gather_subset", "test_module_setup")
    test_obj.collect()