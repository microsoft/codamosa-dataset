

# Generated at 2022-06-22 22:33:03.497074
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import collector
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts_dict = collector_meta_data_collector.collect(module=None, collected_facts=None)
    assert facts_dict == {'gather_subset': ['all'], 'module_setup': True}


# Generated at 2022-06-22 22:33:13.485445
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    ansible_ns = PrefixFactNamespace(prefix='ansible_')

    all_collectors = [IPv4NetworkInterfaceFactCollector]

    fact_collector = AnsibleFactCollector(collectors=all_collectors, namespace=ansible_ns)

    assert fact_collector.filter_spec is None

    # filter spec provided now
    fact_collector = AnsibleFactCollector(collectors=all_collectors, namespace=ansible_ns, filter_spec='ansible_eth*')
    assert fact_collector.filter_spec is 'ansible_eth*'

    # filter spec provided now as a list

# Generated at 2022-06-22 22:33:18.950933
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_gather_subset = ['all']
    test_module_setup = True
    c = CollectorMetaDataCollector(gather_subset=test_gather_subset,
                                   module_setup=test_module_setup)
    f = c.collect()
    assert f['gather_subset'] == ['all']
    assert f['module_setup'] == True

# Generated at 2022-06-22 22:33:26.678657
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import json
    import sys

    # Instantiate a CollectorMetaDataCollector with an arbitrary subset
    arbitrary_subset = [ "!all", "network", "facter" ]
    metric_collector = CollectorMetaDataCollector(gather_subset=arbitrary_subset)

    # Check that it is properly initialized
    assert(metric_collector.gather_subset == arbitrary_subset)

    # Check that it returns the right value
    result = metric_collector.collect()
    expected = {'gather_subset': arbitrary_subset}
    assert(result == expected)



# Generated at 2022-06-22 22:33:30.605242
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_obj = AnsibleFactCollector()
    expected = {}
    if sys.version_info.major == 2 and sys.version_info.minor < 7:
        actual = collector_obj.collect()
    else:
        actual = collector_obj.collect(module=None)
        assert (actual == expected)

# Generated at 2022-06-22 22:33:37.570163
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    namespace = 'ansible'
    filter_spec = '*'
    test_Collectors = ['a','b']
    test_collector = AnsibleFactCollector(collectors=test_Collectors,
                                          namespace=namespace,
                                          filter_spec=filter_spec)

    assert test_collector.collectors == test_Collectors
    assert test_collector.namespace == namespace
    assert test_collector.filter_spec == filter_spec


# Generated at 2022-06-22 22:33:48.481546
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    myCollector = AnsibleFactCollector(collectors=[], filter_spec=None)
    assert myCollector.collectors == [], "Should be an empty list of collectors"
    assert myCollector.filter_spec == None, "Should be None"
    assert myCollector.namespace == None, "Should be None"
    assert myCollector._filter([('os', 'Darwin')], None) == [('os', 'Darwin')], "Should match 'os', 'Darwin'"
    assert myCollector._filter([('os', 'Darwin')], '*') == [('os', 'Darwin')], "Should match 'os', 'Darwin'"
    assert myCollector._filter([('os', 'Darwin')], ['*']) == [('os', 'Darwin')], "Should match 'os', 'Darwin'"
   

# Generated at 2022-06-22 22:33:55.985558
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import Hardware
    from ansible.module_utils.facts.collector.network import Network
    from ansible.module_utils.facts.collector.virtual import Virtual
    from ansible.module_utils.facts.collector.pip import Pip
    from ansible.module_utils.facts.collector.python import Python
    from ansible.module_utils.facts.collector.system import System

    subset = ['all']

    collectors = [Hardware(), Network(), Virtual(), Pip(), Python(), System()]

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=subset)


# Generated at 2022-06-22 22:34:08.933411
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    class fake_collector(object):
        def __init__(self, namespace=None):
            assert namespace == 'ansible'

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {}

    ns_obj = collector.PrefixFactNamespace(prefix='ansible_')
    cls = CollectorMetaDataCollector(collectors=[fake_collector(namespace=ns_obj)],
                                     namespace=ns_obj,
                                     gather_subset=['all'])

    # test that the metadata collector is providing a fact
    facts = cls.collect()
    assert 'ansible_facts' in facts
    # test that it's providing the gather_subset fact
    assert 'gather_subset' in facts['ansible_facts']
    # test that it's providing the gather

# Generated at 2022-06-22 22:34:16.381600
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit test of function get_ansible_collector'''

    fact_collector = get_ansible_collector(
        all_collector_classes=collector.get_collector_classes(),
        namespace=None,
        filter_spec=None,
        gather_subset='all',
        gather_timeout=0,
        minimal_gather_subset=None)

    assert fact_collector


# Generated at 2022-06-22 22:34:22.591378
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.collector.hardware as hardware_collector
    import ansible.module_utils.facts.collector.identity as identity_collector
    import ansible.module_utils.facts.collector.processor as processor_collector
    import ansible.module_utils.facts.collector.virtual as virtual_collector

    all_collector_classes = frozenset([hardware_collector, identity_collector, processor_collector, virtual_collector])

    collector = get_ansible_collector(all_collector_classes,
                                      gather_subset=['all'])

    assert collector.name == 'ansible_facts'
    assert len(collector.collectors) == len(all_collector_classes) + 1

# Generated at 2022-06-22 22:34:33.433873
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''In order to test this constructor, we will use a mock class.
       We will test that it has the right properties, and that these properties
       are class attributes initialized properly.'''
    mock_class = CollectorMetaDataCollector
    mock_namespace_class = collector.PrefixFactNamespace
    mock_namespace = mock_namespace_class('some_prefix')
    mock_gather_subset = 'mock_gather_subset'
    mock_module_setup = True
    mock_instance = CollectorMetaDataCollector(collectors=None,
                                               namespace=mock_namespace,
                                               gather_subset=mock_gather_subset,
                                               module_setup=mock_module_setup)
    assert mock_instance.__class__.__name__ == mock_class.__name

# Generated at 2022-06-22 22:34:43.842672
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Namespace is a prefix namespace
    namespace = collector.PrefixFactNamespace(
        prefix='ansible_')  # namespace=None is the default case

    # A list of collectors to use
    collectors = [ collector.FacterCollector(namespace=namespace),
                  collector.OhaiCollector(namespace=namespace),
                  collector.CustomCollector(namespace=namespace)
                  ]

    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=namespace)
    #print("fact_collector.collectors: %s" % fact_collector.collectors)

    #assert fact_collector.collectors == [collector.FacterCollector(namespace=namespace),
    #     collector.OhaiCollector(namespace=namespace),
    #     collector.CustomCollector(

# Generated at 2022-06-22 22:34:52.243209
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    import ansible.module_utils.facts.network.default as default
    import ansible.module_utils.facts.network.interfaces as interfaces
    import ansible.module_utils.facts.network.route as route

    module_setup = True
    all_collector_classes = [default.DefaultNetworkCollector,
                             interfaces.InterfacesNetworkCollector,
                             route.RouteNetworkCollector]
    gather_subset = ['all', 'min']
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=module_setup)

    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts['gather_subset'] == gather_subset

# Generated at 2022-06-22 22:35:01.810346
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    def fake_collector_class(*args, **kwargs):
        class FakeCollector(object):
            def __init__(self, *args, **kwargs):
                self.fake_name = 'I am a fake'
        return FakeCollector

    fake_collector_classes = [fake_collector_class]
    ansible_collector = get_ansible_collector(fake_collector_classes)

    # assert that the collector class is a AnsibleFactCollector instance
    assert isinstance(ansible_collector, AnsibleFactCollector)

    # assert that the AnsibleFactCollector instance returned has a CollectorMetaDataCollector
    assert isinstance(ansible_collector.collectors[1], CollectorMetaDataCollector)

# Generated at 2022-06-22 22:35:10.950110
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts import base_fact_collector

    def raise_exception(*args, **kwargs):
        raise Exception("my exception")

    # make sure that exception is not thrown even if no namespace
    # and make sure collectors is optional
    x = AnsibleFactCollector(collectors=None, namespace=None)
    assert isinstance(x, AnsibleFactCollector)

    x = AnsibleFactCollector(collectors=[], namespace=None)
    assert isinstance(x, AnsibleFactCollector)

    with pytest.raises(Exception) as e:
        x = AnsibleFactCollector(collectors=None, namespace=None)
        x.collectors.append(base_fact_collector.BaseFactCollector(namespace=None))
        x.collectors[0].collect = raise_

# Generated at 2022-06-22 22:35:14.169370
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = \
        AnsibleFactCollector(filter_spec=['*'])

    assert fact_collector.collectors == []
    assert fact_collector.filter_spec == ['*']

# Generated at 2022-06-22 22:35:19.529808
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    module = {}
    collected_facts = {}
    meta_facts = collector_meta_data_collector.collect(module, collected_facts)
    assert meta_facts.get('gather_subset') == ['all']
    assert meta_facts.get('module_setup')

# Generated at 2022-06-22 22:35:30.978933
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    try:
        AnsibleFactCollector()
    except:
        assert False
    try:
        AnsibleFactCollector(namespace='test')
    except:
        assert False
    try:
        AnsibleFactCollector(filter_spec='test')
    except:
        assert False
    try:
        AnsibleFactCollector(filter_spec=[])
    except:
        assert False
    try:
        AnsibleFactCollector(filter_spec=['test'])
    except:
        assert False
    try:
        collector_obj = CollectorMetaDataCollector()
        AnsibleFactCollector(collectors=[collector_obj])
    except:
        assert False
    try:
        AnsibleFactCollector(collectors=[])
    except:
        assert False

# Generated at 2022-06-22 22:35:39.278785
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils.facts.collector as c
    import ansible.module_utils.facts.namespace as n

    myns = n.PrefixFactNamespace(prefix='ansible_', subcollector=c.FacterFactCollector())
    collector = CollectorMetaDataCollector(namespace=myns, gather_subset=['all'])

    assert collector.collect().has_key('ansible_gather_subset')


# Generated at 2022-06-22 22:35:44.524678
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    class TestFactCollector(collector.BaseFactCollector):
        pass

    tfc = TestFactCollector()

    fact_collector = AnsibleFactCollector(collectors=[tfc])

    # Test that setting 'collectors' and 'namespace' on AnsibleFactCollector
    # results in setting them on BaseFactCollector.
    assert fact_collector.collectors == [tfc]
    assert fact_collector.namespace is None

# Generated at 2022-06-22 22:35:51.821014
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    try:
        from ansible.module_utils import facts
        from ansible.module_utils.facts.collector import BaseFactCollector
        import ansible.module_utils.facts.namespace
    except ImportError:
        return
    c = facts.get_ansible_collector([ansible.module_utils.facts.namespace.NamespaceCollector], gather_subset=['all'])
    assert c.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:36:00.938347
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['min'], module_setup=False)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['min'], 'module_setup': False}


# Generated at 2022-06-22 22:36:05.752981
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # load the common fact collectors, so that we can collect all
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)

    # Note: This should match the filter_spec=None in get_ansible_collector above
    all_facts = fact_collector.collect()

    assert 'ansible_facts' in all_facts



# Generated at 2022-06-22 22:36:09.244187
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           filter_spec=[],
                                           gather_subset=['all'],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT)

    fact_collector.collect()



# Generated at 2022-06-22 22:36:16.417017
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''Verify constructor correctly sets all_collector_classes.'''
    all_collector_classes = [
        collector.SystemCollector,
        collector.PlatformCollector,
        collector.SystemdCollector
    ]
    gather_subset = ['all']
    gather_timeout = None
    minimal_gather_subset = None

    CollectorMetaDataCollector(gather_subset=gather_subset, module_setup=True)

# Generated at 2022-06-22 22:36:23.586138
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    a0 = collector.BaseFactCollector()
    a1 = collector.BaseFactCollector()
    a2 = collector.BaseFactCollector()
    a3 = collector.BaseFactCollector()

    b0 = namespace.BaseFactNamespace()
    b1 = namespace.BaseFactNamespace()
    b2 = namespace.BaseFactNamespace()
    b3 = namespace.BaseFactNamespace()

    afc1 = AnsibleFactCollector([a0, a1], [b0, b1])
    afc2 = AnsibleFactCollector([a0, a1], [b0, b1])
    afc3 = AnsibleFactCollector([a0, a1], [b0, b1])


# Generated at 2022-06-22 22:36:32.355833
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """Unit test for method collect of class AnsibleFactCollector"""

    # pylint: disable=unused-variable
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Note: We have to use relative imports since if we have a global import of this module,
    # and then we mock this module in a test, the global import is still the original
    # and any changes we make to it in the test will not be seen by the global import.
    # This is an issue because the real Ansible modules use a global import of this module
   

# Generated at 2022-06-22 22:36:35.207529
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector()
    assert c.name == 'gather_subset'

# Generated at 2022-06-22 22:36:43.853290
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gather_subset = ['all']
    module_setup = True
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset, module_setup=module_setup)
    assert(collector_meta_data_collector.gather_subset == gather_subset)
    assert(collector_meta_data_collector.module_setup == module_setup)
    assert(collector_meta_data_collector.collect() == {'gather_subset':['all'], 'module_setup': True})


# Generated at 2022-06-22 22:36:48.314110
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    assert(collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True})

# Generated at 2022-06-22 22:36:56.760432
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ast
    import os
    import tempfile

    # TODO: test with --script-dir
    # TODO: coerce `-c local` to `local`
    # TODO: test remaining collection errors
    # TODO: test ansible_* and facter_* namespaces

    # These tests will not work on non-Linux because they depend on the system
    # facts being present.
    if os.name != 'posix':
        return

    facts_d = dict()
    for fact in ['facter_uptime_days', 'facter_uptime_seconds',
                 'ansible_env', 'ansible_distribution_version']:
        assert fact in facts_d
    facts_d['ansible_env'] = dict()
    facts_d['ansible_env']['PWD'] = ''
   

# Generated at 2022-06-22 22:37:08.572701
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.network

    filter_spec = ['*']
    ansible_collector = get_ansible_collector(
        [ansible.module_utils.facts.collectors.base.BaseFactCollector],
        filter_spec=filter_spec
    )
    assert ansible_collector

    namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')
    ansible_collector = get_ansible_collector(
        [ansible.module_utils.facts.collectors.network.NetworkFactCollector],
        filter_spec=filter_spec,
        namespace=namespace
    )
    assert ansible_collector

# Generated at 2022-06-22 22:37:18.051051
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import datetime
    from ansible.module_utils.facts.collectors.dmi import DmiFactCollector
    from ansible.module_utils.facts.collectors.disk import DiskFactCollector

    collectors = [
        DmiFactCollector(namespace='ansible_dmi'),
        DiskFactCollector(namespace='ansible_disk'),
    ]

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=None)

    res = fact_collector.collect()
    #print(res)
    assert res['ansible_dmi']['system_vendor'] == 'LENOVO'
    assert res['ansible_disk']['sda']['size'] > 0

# Generated at 2022-06-22 22:37:20.886239
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = meta.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}


# Generated at 2022-06-22 22:37:27.616517
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    collector = get_ansible_collector(all_collector_classes,
                                      namespace=PrefixFactNamespace(prefix='ansible_'),
                                      gather_subset=['*'],
                                      gather_timeout=2,
                                      filter_spec=['ansible_*'])

    collected_facts = collector.collect()

    assert 'ansible_architecture' in collected_facts
    assert 'ansible_interfaces' in collected_facts
    assert 'ansible_distribution' in collected_facts
    assert 'ansible_distribution_version' in collected_facts
    assert 'ansible_kernel' in collected_facts

# Generated at 2022-06-22 22:37:33.921991
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """Test the method collect of class CollectorMetaDataCollector"""
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collectors.base import BaseFactCollector

    # Create a fictitious collector class
    class FictitiousCollector(BaseFactCollector):
        name = 'fictitious'

    # Create a CollectorMetaDataCollector object
    namespace = PrefixFactNamespace('ansible_')
    meta_collector = CollectorMetaDataCollector(namespace=namespace,
                                                gather_subset=['foo', 'bar'])
    # Test invoke collect method
    expected_value = {
            'ansible_gather_subset': ['foo', 'bar'],
            'ansible_module_setup': True
    }

# Generated at 2022-06-22 22:37:36.474708
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
  from ansible.module_utils.facts import collectors

  fact_collector = AnsibleFactCollector(collectors=[collectors.CommandLineArgsCollector()])

# Generated at 2022-06-22 22:37:38.034120
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert fact_collector

# Generated at 2022-06-22 22:37:48.872925
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """Test CollectorMetaDataCollector.collect
    """

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixMetaDataNamespace
    from ansible.module_utils.facts.namespace import DeprecationNamespace

    gather_subset = ['all', 'network', 'virtual']
    gather_timeout = 5
    minimal_gather_subset = frozenset(['all'])
    all_collectors = [
        collector.DarwinNetworkCollector,
        collector.LinuxDistributionFactCollector,
        collector.NetworkCollector,
        collector.VirtualenvFactCollector,
    ]

# Generated at 2022-06-22 22:37:52.698148
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    assert c.gather_subset == ['all']
    assert c.module_setup == True


# Generated at 2022-06-22 22:38:03.753542
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    mock_info_dict = {'ansible_eth1': {'macaddress': '00:0c:29:8c:11:b1'}, 'ansible_lsb': {'codename': 'trusty', 'release': '14.04', 'major_release': '14.04', 'description': 'Ubuntu 14.04.6 LTS', 'id': 'Ubuntu', 'distributor_id': 'Ubuntu'}}
    mock_info_dict2 = {'ansible_lsb': {'codename': 'trusty', 'release': '14.04', 'major_release': '14.04', 'description': 'Ubuntu 14.04.6 LTS', 'id': 'Ubuntu', 'distributor_id': 'Ubuntu'}}

# Generated at 2022-06-22 22:38:11.557293
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    def mock_collect(self, module=None, collected_facts=None):
        return {'test_fact': 'test_fact_value'}

    def mock_namespace_collect(self, module=None, collected_facts=None):
        return {'test_fact': 'test_fact_namespace_value'}

    class MockFactCollector(collector.BaseFactCollector):
        name = 'test_fact_collector'

        def __init__(self, namespace=None):
            super(MockFactCollector, self).__init__()
            self.namespace = namespace

        def collect(self, module=None, collected_facts=None):
            if self.namespace:
                return mock_namespace_collect(self, module=module, collected_facts=collected_facts)
            else:
                return

# Generated at 2022-06-22 22:38:24.649184
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    c1 = collector.BaseFactCollector(namespace=None)
    assert c1.namespace is None
    c2 = collector.BaseFactCollector(namespace='ns1')
    assert c2.namespace == 'ns1'

    c3 = AnsibleFactCollector()
    assert c3.namespace is None
    c1.namespace = 'ns1'
    c4 = AnsibleFactCollector(collectors=[c1])
    assert c4.namespace is None
    c5 = AnsibleFactCollector(collectors=[c2])
    assert c5.namespace == 'ns1'

    c6 = AnsibleFactCollector(namespace='ns2')
    assert c6.namespace == 'ns2'
    c7 = AnsibleFactCollector(collectors=[c1], namespace='ns3')

# Generated at 2022-06-22 22:38:27.645755
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert fact_collector is not None


if __name__ == '__main__':

    test_AnsibleFactCollector()

# Generated at 2022-06-22 22:38:32.571392
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset='all')
    results = fact_collector.collect()
    assert 'gather_subset' in results
    assert results['gather_subset'] == 'all'


# Generated at 2022-06-22 22:38:41.925147
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # create two separate collectors with two facts each
    fact_dictA = dict(a=1, b=2)
    fact_dictB = dict(c=3, d=4)

    collector1 = collector.MockFactCollector()
    collector1.facts = dict(fact_dictA)
    collector1.name = 'collector1'

    collector2 = collector.MockFactCollector()
    collector2.facts = dict(fact_dictB)
    collector2.name = 'collector2'

    # Create the ansible fact collector
    fact_collector = \
        AnsibleFactCollector(collectors=[collector1, collector2])
    # This will get all facts,
    facts = fact_collector.collect()

    # All facts will be under ansible_facts

# Generated at 2022-06-22 22:38:45.713999
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=[],
                                   module_setup=True)
    result = fact_collector.collect(None, None)
    assert result['gather_subset'] == []
    assert result['module_setup'] == True

# Generated at 2022-06-22 22:38:50.243625
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gather_subset = ['all']
    fact_metadata_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
    assert fact_metadata_collector.name == 'gather_subset'
    assert fact_metadata_collector.gather_subset == ['all']

# Generated at 2022-06-22 22:38:57.036133
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_obj1 = collector.BaseFactCollector(namespace=None)
    collector_obj2 = collector.BaseFactCollector(namespace=None)
    collectors_list = [collector_obj1, collector_obj2]

    fact_collector = AnsibleFactCollector(collectors=collectors_list, namespace=None)
    assert fact_collector.collectors == collectors_list
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None

    fact_collector = AnsibleFactCollector(collectors=collectors_list, filter_spec='*', namespace=None)
    assert fact_collector.collectors == collectors_list
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec == ['*', 'ansible_*']

   

# Generated at 2022-06-22 22:39:01.097789
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    result = c.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:39:10.997504
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-22 22:39:23.461688
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network_all
    from ansible.module_utils.facts import network_interfaces
    from ansible.module_utils.facts import network_lom

    if not ansible_collector.__dict__.get('TestCollector'):
        class TestCollector(collector.BaseFactCollector):
            name = 'test'
            _fact_ids = ['test1']

            def collect(self, module=None, collected_facts=None):
                return {'test1': 'test1'}


# Generated at 2022-06-22 22:39:28.481256
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    actual_facts = collector_meta_data_collector.collect()
    assert actual_facts['gather_subset'] == ['all']
    assert actual_facts['module_setup'] is True


# Generated at 2022-06-22 22:39:37.925768
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    import ansible.module_utils.facts.core

    class FooCollector(BaseFactCollector):
        name = 'foo'

    class BarCollector(BaseFactCollector):
        name = 'bar'

    class OtherCollector(BaseFactCollector):
        name = 'other'

    foo = FooCollector()
    bar = BarCollector()
    other = OtherCollector()

    # start unit test
    all_collector_classes = frozenset([foo.__class__, bar.__class__, other.__class__])
    # normally, this would come from ansible.module_utils.facts.FACT_CACHE
    namespace = None

# Generated at 2022-06-22 22:39:44.997301
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector().gather_subset == 'base'
    assert CollectorMetaDataCollector(gather_subset='a').gather_subset == 'a'
    assert CollectorMetaDataCollector(gather_subset='b', module_setup=True).gather_subset == 'b'
    assert CollectorMetaDataCollector(gather_subset='b', module_setup=True).module_setup is True


# Generated at 2022-06-22 22:39:51.969649
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Test a case with one collector and a filter that matches no facts
    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            fact1_name = '%sfact1' % self.namespace.prefix
            fact2_name = '%sfact2' % self.namespace.prefix
            return {fact1_name: 'f1value',
                    fact2_name: 'f2value'}

    fact_collector = \
        AnsibleFactCollector(collectors=[TestCollector(namespace='')],
                             filter_spec=[])
    filtered_facts = fact_collector.collect()
    assert len(filtered_facts.keys()) == 0

    # Test a case with one collector and a filter that matches

# Generated at 2022-06-22 22:39:57.261065
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    class TestCollector(CollectorMetaDataCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {}

    c = TestCollector()
    assert c.collect() == {'gather_subset': None}

    c = TestCollector(gather_subset=['all'])
    assert c.collect() == {'gather_subset': ['all']}


# Generated at 2022-06-22 22:40:03.794811
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    namespace = 'ansible_'
    filter_spec = 'ansible_os*'

    fact_collector = AnsibleFactCollector(filter_spec=filter_spec,
                                          namespace=namespace)
    assert fact_collector.filter_spec == filter_spec
    assert fact_collector.namespace == namespace


# Generated at 2022-06-22 22:40:13.269356
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''
        Unit test for method collect of class AnsibleFactCollector
    '''

    class FakeCollector():
        '''Fake class'''
        def __init__(self):
            self.name = 'fake_collector'
            self.FACT_ID = 'fake_fact'

        def collect(self, module=None, collected_facts=None):
            dict = {}
            dict['fake_key'] = 'fake_value'
            return dict

    class FakeNamespace():
        '''Fake class'''
        def __init__(self):
            self.name = 'fake'

    class FakeNamespaceWithPrefix():
        '''Fake class'''
        def __init__(self):
            self.name = 'fake'


# Generated at 2022-06-22 22:40:17.533778
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.namespace as namespace
    fact_namespace = namespace.PrefixFactNamespace(prefix='ansible_')
    collector = CollectorMetaDataCollector(namespace=fact_namespace,
                                           gather_subset=['all'])
    facts = collector.collect()
    assert facts['ansible_gather_subset'] == ['all']



# Generated at 2022-06-22 22:40:26.927308
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit test for get_ansible_collector'''

    # import here to keep unit tests from failing if not all deps are installed
    import ansible.module_utils.facts.system.platform

    try:
        import ansible.module_utils.facts.system.distribution
    except ImportError:
        pass

    all_collector_classes = \
        collector.get_all_collector_classes()

    ansible_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=None,
                              filter_spec=['*'])

    gathered_facts = ansible_collector.collect()

    assert('ansible_facts' in gathered_facts)


# Generated at 2022-06-22 22:40:33.701749
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['!all'])
    assert collector_meta_data_collector.collect() == {'gather_subset': ['!all'], 'module_setup': True}

    collector_meta_data_collector = CollectorMetaDataCollector()
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:40:38.569415
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = get_ansible_collector(
        all_collector_classes=collector.CORE_COLLECTORS)
    assert fact_collector.collectors[-1].name == 'gather_subset'
    assert fact_collector.collectors[-1].gather_subset == ['all']

# Generated at 2022-06-22 22:40:46.797731
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts
    namespace = ansible.module_utils.facts.namespace

    EmptyNamespace = namespace.EmptyFactNamespace()
    ansible_prefix_namespace = namespace.PrefixFactNamespace(prefix='ansible_')
    ec2_prefix_namespace = namespace.PrefixFactNamespace(prefix='ec2_')


# Generated at 2022-06-22 22:40:47.449496
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-22 22:40:51.796728
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collectors = []
    filter_spec = []
    namespace = None

    fact_collector = AnsibleFactCollector(collectors, filter_spec, namespace)

    assert fact_collector.collectors == collectors
    assert fact_collector.filter_spec == filter_spec
    assert fact_collector.namespace == namespace


# Generated at 2022-06-22 22:41:03.146466
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # pylint: disable=too-few-public-methods
    class TestCollector():

        def __init__(self, namespace=None):
            self.collect_called = False
            self.namespace = namespace
            self.collect_args = {}
            self.collect_kwargs = {}

        def collect(self, module=None, collected_facts=None):
            self.collect_called = True
            self.collect_args = {}
            self.collect_kwargs = {}
            self.collect_args['module'] = module
            self.collect_args['collected_facts'] = collected_facts
            return {'test_fact': 'test_value'}

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}



# Generated at 2022-06-22 22:41:10.202486
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    class MockModule(object):
        def __init__(self, timeout=10):
            self.params = {'gather_subset': ['all', 'network'], 'gather_timeout': timeout}

    fake_module = MockModule()
    fake_collected_facts = None

    # Test with gather_subset=[all, network] and gather_timeout=10
    fact_collector = get_ansible_collector([],
                                           gather_subset=fake_module.params['gather_subset'],
                                           gather_timeout=fake_module.params['gather_timeout'],
                                           minimal_gather_subset=['all'])
    fake_collected_facts = fact_collector.collect(fake_module, fake_collected_facts)

# Generated at 2022-06-22 22:41:16.037582
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Create a CollectorMetaDataCollector object with gather_subset and module_setup
    collector_meta_data = CollectorMetaDataCollector(gather_subset='all',
                                                     module_setup=True)

    # Verify the two parameters
    assert collector_meta_data.gather_subset == 'all'
    assert collector_meta_data.module_setup is True

    # Verify that the collector_meta_data.name contains the correct fact name
    assert collector_meta_data.name == 'gather_subset'



# Generated at 2022-06-22 22:41:28.027794
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Setup
    collected_facts = {'ansible_os_family': 'Debian'}

    class TestCollector:
        name = 'test'
        _fact_ids = set(['test_fact'])

        def __init__(self, namespace=None):
            pass

        def collect_with_namespace(self, module=None, collected_facts=None):
            # This assumes that self.name is assigned and that
            # the same name is used for the key and fact_id.
            return {self.name: self.name}

    test_collector = TestCollector()
    ansible_fact_collector = \
        AnsibleFactCollector(collectors=[test_collector])

    # Execute

# Generated at 2022-06-22 22:41:34.320813
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    subset = ['!all', '!min', 'network']
    module_setup = False

    c = CollectorMetaDataCollector(gather_subset=subset,
                                   module_setup=module_setup)
    meta_facts = c.collect()

    assert meta_facts['gather_subset'] == subset
    assert meta_facts['module_setup'] == module_setup

# Generated at 2022-06-22 22:41:46.052288
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    def collect_mock(module=None, collected_facts=None):
        return {'test_ansible_dict': 'test_ansible_val'}

    def collect_mock_test(module=None, collected_facts=None):
        return {'test': 'test_val'}

    class TestCollector(object):
        def collect_with_namespace(self, module=None, collected_facts=None):
            if self.collect == collect_mock:
                return {'test_ansible_dict': 'test_ansible_val'}
            elif self.collect == collect_mock_test:
                return {'test': 'test_val'}

# Generated at 2022-06-22 22:41:50.589013
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=True, module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': True, 'module_setup': True}, "Test for CollectorMetaDataCollector failed!"

# Generated at 2022-06-22 22:42:01.933706
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.hardware.dmi
    import ansible.module_utils.facts.network.linux
    import ansible.module_utils.facts.network.windows

    all_collector_classes = [
        ansible.module_utils.facts.hardware.dmi.DmiFactCollector,
        ansible.module_utils.facts.network.linux.LinuxNetworkCollector,
        ansible.module_utils.facts.network.windows.WindowsNetworkCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes)
    fact_collector.collect()


if __name__ == '__main__':
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-22 22:42:06.792601
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    ac = get_ansible_collector(all_collector_classes=all_collector_classes,
                               namespace=PrefixFactNamespace(prefix='ansible_'),
                               filter_spec='ansible_os_family',
                               gather_subset='all',
                               gather_timeout=10,
                               minimal_gather_subset=frozenset(['network']))

    facts = ac.collect()
    assert 'ansible_facts' in facts
    assert 'ansible_os_family' in facts['ansible_facts']
    assert 'ansible_hostname' not in facts['ansible_facts']

# Generated at 2022-06-22 22:42:17.930737
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [CollectorMetaDataCollector]
    filter_spec = []
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset([])

    ansible_collector = get_ansible_collector(all_collector_classes,
                                              filter_spec=filter_spec,
                                              gather_subset=gather_subset,
                                              gather_timeout=gather_timeout,
                                              minimal_gather_subset=minimal_gather_subset)

    class DummyConnection():
        def get_module_implementation_path(self):
            return 'foo/bar/init.py'


# Generated at 2022-06-22 22:42:20.712182
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Tests constructor of class AnsibleFactCollector'''

    assert(isinstance(AnsibleFactCollector(), AnsibleFactCollector))
    assert(isinstance(AnsibleFactCollector(collectors=[]), AnsibleFactCollector))
    assert(isinstance(AnsibleFactCollector(namespace=collector.BaseFactNamespace),
                       AnsibleFactCollector))



# Generated at 2022-06-22 22:42:30.605375
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import tempfile
    import os
    import shutil
    import platform

    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    kwargs = {'system': 'Linux',
              'kernel': '3.10.0-514.10.2.el7.x86_64',
              'distribution': 'CentOS',
              'distribution_release': '7.3.1611',
              'distribution_major_version': '7'}

    # make a tempdir for the temp files for this test
    test_dir = tempfile.mkdtemp()

    # create a fake sysfs path so the tests will work on any system

# Generated at 2022-06-22 22:42:40.912352
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    """
    Test the CollectorMetaDataCollector() constructor.
    """
    collector_meta_data_collector = CollectorMetaDataCollector()
    assert 'gather_subset' in collector_meta_data_collector.fact_ids
    assert 'module_setup' not in collector_meta_data_collector.fact_ids
    # It should not be possible to instantiate a subclass of AbstractFactCollector
    # without providing the names of the facts it collects.
    try:
        collector.AbstractFactCollector()
        # If we get no exception, the test must fail.
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-22 22:42:50.862703
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # gather_subset is not None
    collector_meta_data_collector_1 = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    assert collector_meta_data_collector_1.gather_subset == ['all']
    assert collector_meta_data_collector_1.module_setup == True

    # gather_subset is None
    collector_meta_data_collector_2 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_2.gather_subset == []
    assert collector_meta_data_collector_2.module_setup == None



# Generated at 2022-06-22 22:43:02.657126
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Note: for general unit test coverage, we should probably make sure the
    # various collectors are actually exercised.
    #
    # Note2: This is a hackish way to get a sample of collector classes. It would
    # be nice if we could get a list of all the collector classes without instantiating
    # them, but that would require changes to all the factories.
    from ansible.module_utils.facts import distribution
    collector_classes = [distribution.DistributionCollector, distribution.DistributionAliases]

    ansible_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                              filter_spec='distribution*',
                                              gather_subset='all')
    ansible_facts = ansible_collector.collect()

    # make sure the distribution* filter worked