

# Generated at 2022-06-22 22:33:03.912370
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    def dummy_get_collector_classes():
        return ['a', 'b']

    collector_meta_data_collector = get_ansible_collector(all_collector_classes=dummy_get_collector_classes)
    collected_facts = collector_meta_data_collector.collect()

    assert len(collected_facts['gather_subset']) == 2


# Generated at 2022-06-22 22:33:11.183728
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    namespace = None
    filter_spec = None
    collectors = []

    ansible_fact_collector = AnsibleFactCollector(collectors=collectors,
                                                  filter_spec=filter_spec,
                                                  namespace=namespace)

    assert ansible_fact_collector is not None
    assert ansible_fact_collector.collectors == collectors
    assert ansible_fact_collector.filter_spec == filter_spec
    assert ansible_fact_collector.namespace == namespace

# Generated at 2022-06-22 22:33:22.494031
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network

    fact_collector = \
        AnsibleFactCollector(namespace.fact_namespace(),
                             namespace.PrefixFactNamespace(prefix='ansible_'),
                             network.LegacyNetworkCollector(),
                             network.NetworkCollector(),
                             filter_spec=['ansible_f*'])

    expected = [namespace.fact_namespace(),
                namespace.PrefixFactNamespace(prefix='ansible_'),
                CollectorMetaDataCollector(),
                network.LegacyNetworkCollector(),
                network.NetworkCollector()]

    facts = fact_collector.collect()

# Generated at 2022-06-22 22:33:31.478184
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''pass in 2 collectors, one of which is a CollectorMetaDataCollector and make sure the
    metadata collector is included in the returned list of all collectors'''
    all_collector_classes = [BaseFactCollector, CollectorMetaDataCollector]
    minimal_gather_subset = ['all']
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=gather_subset,
                                           gather_timeout=gather_timeout,
                                           minimal_gather_subset=minimal_gather_subset)

    fact_collector_classes = fact_collector.collectors
    fact_collector_classes

# Generated at 2022-06-22 22:33:42.095048
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Simulate a module setup fact
    some_fact = {}
    some_fact['ansible_module_setup'] = {}
    some_fact['ansible_module_setup']['some_fact'] = 'some value'
    # Simulate a fact
    some_fact['some_fact'] = 'some value'

    # Simulate a module setup fact
    another_fact = {}
    another_fact['ansible_module_setup'] = {}
    another_fact['ansible_module_setup']['another_fact'] = 'another value'
    # Simulate a fact
    another_fact['another_fact'] = 'another value'

    expected_results = {'ansible_module_setup': {},
                        'some_fact': 'some value',
                        'another_fact': 'another value'}


# Generated at 2022-06-22 22:33:50.467818
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'testfact': 'testvalue'}

    all_collector_classes = [TestCollector]
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    ansible_facts = fact_collector.collect()
    assert 'ansible_facts' in ansible_facts
    assert 'testfact' in ansible_facts['ansible_facts']

# Generated at 2022-06-22 22:33:58.430235
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Arrange
    import ansible.module_utils.facts.network.base
    import ansible.module_utils.facts.network.ios
    import ansible.module_utils.facts.network.iosxr
    import ansible.module_utils.facts.network.nxos

    import ansible.module_utils.facts.virtual.base
    import ansible.module_utils.facts.virtual.hyperv
    import ansible.module_utils.facts.virtual.kvm
    import ansible.module_utils.facts.virtual.openstack
    import ansible.module_utils.facts.virtual.openvz
    import ansible.module_utils.facts.virtual.rhev
    import ansible.module_utils.facts.virtual.vmware
    import ansible.module_utils.facts.virtual.virtuozzo


# Generated at 2022-06-22 22:34:10.428459
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import pytest

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.namespace import PrefixFactNamespace, SeparatorFactNamespace

    # canary1_ns2_ns is a fake fact that is present on a collector that is namedpaced
    # with both PrefixFactNamespace('canary1_') and SeparatorFactNamespace(separator='__')
    canary1_ns2_ns = {'canary1_ns2_ns': 'value'}

    def collector_foo():
        return {'canary1': 'value'}

    def collector_bar():
        return {'canary1': 'value2'}


# Generated at 2022-06-22 22:34:19.114020
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class FakeCollector(object):

        def __init__(self, name, facts=None):
            self.name = name
            self.facts = facts or {}

        def collect(self, module=None, collected_facts=None):
            return self.facts

    fake_collector1 = FakeCollector('fake_collector1',
                                    facts={'foo': 'foo', 'bar': 'bar'})

    fake_collector2 = FakeCollector('fake_collector2',
                                    facts={'fiz': 'fiz', 'baz': 'baz'})

    fact_collector = AnsibleFactCollector(namespace=None,
                                          collectors=[fake_collector1, fake_collector2])
    collected_facts = fact_collector.collect()

# Generated at 2022-06-22 22:34:23.392400
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_data_collector = CollectorMetaDataCollector()
    facts = meta_data_collector.collect()

    assert facts['gather_subset'] == []
    assert facts['module_setup'] == True

# Generated at 2022-06-22 22:34:34.371767
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # Test with default collector_meta_data_collector
    collector_meta_data_collector = CollectorMetaDataCollector()
    assert collector_meta_data_collector is not None

    # Test with collector_meta_data_collector with gather subset
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='default')
    assert collector_meta_data_collector.gather_subset == 'default'

    # Test with collector_meta_data_collector with all arguments
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all',
                                                               module_setup=True)
    assert collector_meta_data_collector.gather_subset == 'all'
    assert collector_meta_data_collector.module_setup == True

    #

# Generated at 2022-06-22 22:34:41.834951
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # no args
    fact_collector = AnsibleFactCollector()
    assert fact_collector._collectors == []

    # collectors
    my_collector = collector.BaseFactCollector()
    fact_collector = AnsibleFactCollector(collectors=[my_collector])
    assert fact_collector._collectors == [my_collector]

    # namespace
    fact_collector = AnsibleFactCollector(namespace='foo')
    assert fact_collector.namespace.prefix == 'foo'


# Generated at 2022-06-22 22:34:51.018603
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Demonstrate how to use function get_ansible_collector()'''

    import os
    sys.path.append(os.path.dirname(__file__))
    import ansible.module_utils.facts.test_test_test as test_test_test

    test_all_collector_classes = [test_test_test.TestTestTestCollector]
    test_namespace = test_test_test.TestTestTestNamespace()
    test_filter_spec = ['all', 'test_test']
    test_gather_subset = ['all', 'test_test']
    test_gather_timeout = 5
    test_minimal_gather_subset = frozenset(['asdf', 'asdf'])


# Generated at 2022-06-22 22:34:53.508831
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''A test for the constructor of CollectorMetaDataCollector class.'''

    fact_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert fact_collector != None, 'Expected fact_collector to be not None'

# Generated at 2022-06-22 22:35:00.176363
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Run gather_subset meta data collector with default parameters
    meta_facts = CollectorMetaDataCollector().collect()
    assert 'gather_subset' in meta_facts
    assert 'module_setup' in meta_facts

    # Run gather_subset meta data collector with all non-default parameters
    meta_facts = CollectorMetaDataCollector(gather_subset=['hardware'], module_setup=False).collect()
    assert meta_facts['gather_subset'] == ['hardware']
    assert meta_facts['module_setup'] is False


# Generated at 2022-06-22 22:35:10.688263
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.linux.distribution

    all_collector_classes = \
        ansible.module_utils.facts.collector.get_collectors_for_platform('linux')
    namespace = \
        ansible.module_utils.facts.linux.distribution.LinuxDistributionNamespace(prefix='ansible_')

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespace)

    filter_spec = ['ansible_distribution*']

    fact_dict = fact_collector.collect(filter_spec=filter_spec)


# Generated at 2022-06-22 22:35:20.519077
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # setup a BaseFactCollector mock
    class MockBaseFactCollector(collector.BaseFactCollector):

        def __init__(self, collectors=None, namespace=None):
            super(MockBaseFactCollector, self).__init__(collectors=collectors, namespace=namespace)
            self.collector_fact_dict = {'expected_fact_1': 'fact_1_value',
                                        'expected_fact_2': 'fact_2_value'}

        def collect(self, module=None, collected_facts=None):
            return self.collector_fact_dict

    collector_namespace = collector.Namespace('mock_collector_namespace.')

# Generated at 2022-06-22 22:35:32.397936
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.namespace as facts_namespace

    all_collector_classes = [
        AnsibleFactCollector,
        CollectorMetaDataCollector
    ]

    my_namespace = facts_namespace.PrefixFactNamespace(prefix='ansible_')

    my_filter_spec = ['ansible_system']

    my_gather_subset = ['all']

    # Empty gather_timeout will use default_timeout from facts.timeout
    my_gather_timeout = ''

    # None minimal_gather_subset is an empty set
    my_minimal_gather_subset = None


# Generated at 2022-06-22 22:35:43.562962
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Test 1: ensure meta data collector is added at end of collectors
    collectors = []
    collector_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                               module_setup=False)
    collectors.append(collector_obj)

    collector_obj = CollectorMetaDataCollector(gather_subset=['network'],
                                               module_setup=True)
    collectors.append(collector_obj)

    fact_collector = AnsibleFactCollector(collectors=collectors)

    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup == False

    # Test 2: confirm that data can be collected

# Generated at 2022-06-22 22:35:49.181245
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=False)

    collected_facts = collector_meta_data_collector.collect(collected_facts={})
    assert collected_facts == {'gather_subset': ['all']}


# Generated at 2022-06-22 22:35:56.801670
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ''' Test collect method of AnsibleFactCollector class '''
    import os
    import tempfile
    import shutil

    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import systems
    from ansible.module_utils.facts import virtual

    # This is the content of a test file which will be used by a fact collector
    # and could have any content.
    file_content = 'This is some content for a fact_file'

    test_dir = tempfile.mkdtemp()

    # Creating a test file which will be used by a fact collector

# Generated at 2022-06-22 22:36:03.274671
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # NOTE: Not much to test, we're mostly just testing the framework

    # pylint: disable=unused-argument
    collector_meta_data_collector = CollectorMetaDataCollector(collectors=None,
                                                               namespace=None,
                                                               gather_subset='should_be_a_fact_in_result',
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['module_setup'] is True
    assert facts['gather_subset'] == 'should_be_a_fact_in_result'


# Generated at 2022-06-22 22:36:12.176078
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollectorClass1(collector.BaseFactCollector):
        name = 'test_collector_1'

        def __init__(self, *args, **kwargs):
            super(TestCollectorClass1, self).__init__(*args, **kwargs)

        def collect(self, module=None, collected_facts=None):
            return {}

    class TestCollectorClass2(collector.BaseFactCollector):
        name = 'test_collector_2'

        def __init__(self, *args, **kwargs):
            super(TestCollectorClass2, self).__init__(*args, **kwargs)

        def collect(self, module=None, collected_facts=None):
            return {'fact_1': 'fact_val_1'}


# Generated at 2022-06-22 22:36:21.898903
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.virtual.ohai import OpenStack
    from ansible.module_utils.facts.os.openbsd import OpenBSD
    from ansible.module_utils.facts.os.smartos import SmartOS
    from ansible.module_utils.facts.os.hardware import Hardware
    from ansible.module_utils.facts.system.distribution import Distribution

    # all_collector_classes:
    # * ansible.module_utils.facts.virtual.ohai.OpenStack
    # * ansible.module_utils.facts.os.openbsd.OpenBSD
    # * ansible.module_utils.facts.os.smartos.SmartOS
    # * ansible.module_utils.facts.os.hardware.Hardware
    # * ansible.module_utils.facts.system.dist

# Generated at 2022-06-22 22:36:26.908192
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    """Test to make sure that AnsibleFactCollector returns expected values"""
    namespace_str = collector.make_namespace_str("test")
    collector_obj = collector.BaseFactCollector(namespace=namespace_str)
    all_collectors = [collector_obj]
    fact_collector = get_ansible_collector(all_collectors)
    assert fact_collector

# Generated at 2022-06-22 22:36:27.890658
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    pass



# Generated at 2022-06-22 22:36:35.109903
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.system.base import System
    from ansible.module_utils.facts.virtual.base import Virtual

    class MockHardware(Hardware):
        name = 'hardware'

    class MockSystem(System):
        name = 'system'

    class MockVirtual(Virtual):
        name = 'virtual'

    class CollectorClasses:
        def __init__(self, classes):
            self.classes = classes

        def get_collector_classes(self, subset, gather_timeout=None):
            if subset == 'all':
                return self.classes
            else:
                return []


# Generated at 2022-06-22 22:36:44.723961
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    collectors = []
    namespace = None
    filter_spec = '*'

    fact_collector = AnsibleFactCollector(collectors, namespace, filter_spec)

    assert fact_collector

    # The following attributes should exist
    assert fact_collector is not None
    assert fact_collector.namespace is not None
    assert fact_collector.collectors is not None
    assert fact_collector.filter_spec is not None

    # The following attributes should hold the expected values
    assert fact_collector.namespace is None
    assert fact_collector.collectors == []
    assert fact_collector.filter_spec == '*'


# Generated at 2022-06-22 22:36:54.706648
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.fqdn
    import ansible.module_utils.facts.system.domain
    import ansible.module_utils.facts.system.hostname
    import ansible.module_utils.facts.system.kernel
    import ansible.module_utils.facts.system.os

    test_module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # Simple test of constructor of AnsibleFactCollector
    fact_namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')

# Generated at 2022-06-22 22:37:00.698521
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:37:10.572502
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import ansible_distribution_facts
    from ansible.module_utils.facts import ansible_distribution_version_facts
    from ansible.module_utils.facts import ansible_os_family_facts
    from ansible.module_utils.facts import ansible_system_facts
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import filesystem
    from ansible.module_utils.facts import networking
    from ansible.module_utils.facts import default

    # If a namespace is provided, facts will be collected under that namespace.
    namespace_prefix = namespace.PrefixFactNamespace(prefix='my_')

    # Check if facts are collected under namespace
    fact_collector = AnsibleFactCollect

# Generated at 2022-06-22 22:37:21.756136
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import pprint

    # Patch this since we're running outside a real module
    def get_all_collector_classes():
        from ansible.module_utils.facts import systems
        return systems.all_collector_classes

    all_collector_classes = get_all_collector_classes()

    # Test that we can get the standard collectors
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])
    facts = fact_collector.collect()
    assert 'ansible_os_family' in facts
    assert 'ansible_kernel' in facts

    # Test that we can get just the software collectors

# Generated at 2022-06-22 22:37:28.490711
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert 'all' in get_ansible_collector(all_collector_classes=None,
                                          gather_subset=['all']).gather_subset
    assert 'all' in get_ansible_collector(all_collector_classes=None,
                                          gather_subset=[]).gather_subset
    assert 'all' in get_ansible_collector(all_collector_classes=None,
                                          gather_subset='*').gather_subset
    assert 'all' in get_ansible_collector(all_collector_classes=None,
                                          gather_subset='all').gather_subset
    assert 'all' in get_ansible_collector(all_collector_classes=None,
                                          gather_subset='al*').gather

# Generated at 2022-06-22 22:37:33.061098
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    all_collector_classes = [ansible_collector.NetworkCollector,
                             ansible_collector.PlatformCollector,
                             ansible_collector.HardwareCollector]

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=ansible_collector.ANSIBLE_COLLECTOR_NS,
                              gather_subset='!all,!network')
    print(fact_collector)

# Generated at 2022-06-22 22:37:42.357502
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    namespace = 'test_namespace'
    gather_subset = ['all']
    module_setup = True

    collector_metadata_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=module_setup)
    assert collector_metadata_collector.name == 'gather_subset'
    assert collector_metadata_collector.gather_subset == gather_subset
    assert collector_metadata_collector.module_setup == module_setup
    assert collector_metadata_collector.collectors is None
    assert collector_metadata_collector.namespace is None


# Generated at 2022-06-22 22:37:50.101451
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    cmc = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert cmc.gather_subset == ['all'], 'Expected gather_subset=["all"]'
    assert cmc.module_setup is True, 'Expected module_setup=True'

    cmc = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    assert cmc.gather_subset == ['all'], 'Expected gather_subset=["all"]'
    assert cmc.module_setup is False, 'Expected module_setup=False'

# Generated at 2022-06-22 22:38:01.733308
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Create Fake collectors
    class FakeCollector1(collector.BaseFactCollector):
        pass

    class FakeCollector2(collector.BaseFactCollector):
        pass

    # Create collectors using the above fake collectors
    collectors = [FakeCollector1(), FakeCollector2()]

    class FakeNamespace(object):
        pass

    namespace = FakeNamespace()

    # Create a fact collector using the above collectors
    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=namespace)

    # Validate that fact_collector is created
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors == collectors
    assert fact_collector.namespace == namespace

# Generated at 2022-06-22 22:38:13.582621
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    fact_namespace = 'ansible'

    # This is a very simple fake collector that returns the testfact key value pair
    # and the fact_namespace key value pair.
    class TestFactCollector(collector.BaseFactCollector):
        def __init__(self, namespace=None):
            super(TestFactCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts.update({
                'testfact': 'testvalue',
                self.namespace: {'testfact': 'testvalue'}
            })
            return collected_facts

    # Create a TestFactCollector instance
    collector_obj = TestFactCollector(namespace=fact_namespace)

    # Create an Ansible

# Generated at 2022-06-22 22:38:23.256690
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert (fact_collector.namespace is None)
    assert (fact_collector.filter_spec is None)

    class A():
        pass

    objA = A()

    fact_collector = AnsibleFactCollector(collectors=[objA],
                                          namespace='',
                                          filter_spec=True)
    assert (fact_collector.namespace == '')
    assert (fact_collector.filter_spec is True)
    assert (fact_collector.collectors[0] is objA)



# Generated at 2022-06-22 22:38:31.796103
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Test default (gather_subset) parameter
    my_collector = CollectorMetaDataCollector()
    facts = my_collector.collect()
    assert(facts['gather_subset'] == ['all'])

    # Test with gather_subset
    my_collector = CollectorMetaDataCollector(
        gather_subset='!all,!local', module_setup=False)
    facts = my_collector.collect()
    assert(facts['gather_subset'] == ['!all', '!local'])
    assert(facts['module_setup'] == False)

# Generated at 2022-06-22 22:38:40.085329
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class DummyCollector(collector.BaseFactCollector):
        name = 'dummy'

        def collect(self, module=None, collected_facts=None):
            return {'a': 0, 'b': 1}

    fact_collector = \
        AnsibleFactCollector(collectors=[DummyCollector(namespace=namespace.BaseFactNamespace())])

    facts = fact_collector.collect()
    assert 'a' in facts
    assert 'b' in facts

    assert 'a' in facts
    assert 'b' in facts


# Generated at 2022-06-22 22:38:46.245994
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    mock_gather_subset = ["mock_gather_subset"]
    fact_collector = CollectorMetaDataCollector(gather_subset=mock_gather_subset)
    mock_collected_facts = fact_collector.collect()
    assert mock_collected_facts == {'gather_subset': mock_gather_subset,
                                    'module_setup': True}


# Generated at 2022-06-22 22:38:55.933171
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector

    # Create a test collector
    class TestCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    # Create a fake Collector class and load it dynamically
    ansible.module_utils.facts.collector.FACT_COLLECTORS['test'] = TestCollector

    # Create a test namespace
    class TestAnsibleNamespace(ansible.module_utils.facts.namespace.BaseFactNamespace):
        name = 'ansible'

    # Create a namespace for our collector
    test

# Generated at 2022-06-22 22:39:00.335999
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    subset_list = ['network', 'hardware', 'facter']
    c = CollectorMetaDataCollector(gather_subset=subset_list, module_setup=True)
    result = c.collect()
    assert (result['module_setup'] == True)



# Generated at 2022-06-22 22:39:10.565390
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.networking
    import ansible.module_utils.facts.system

    test_gather_subset = '!all,!min'
    test_filter_spec = 'net.*'

    test_fact_collector = get_ansible_collector(
        all_collector_classes=set([ansible.module_utils.facts.networking.NetworkCollector,
                                   ansible.module_utils.facts.system.SystemCollector]),
        gather_subset=test_gather_subset,
        filter_spec=test_filter_spec)
    assert test_fact_collector
    assert isinstance(test_fact_collector, AnsibleFactCollector), \
        'Gather subset collector should be an instance of AnsibleFactCollector'

# Generated at 2022-06-22 22:39:23.007908
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           gather_subset='all',
                                           filter_spec='*linux*')
    assert fact_collector is not None
    assert len(fact_collector.collectors) == 1
    assert fact_collector.collectors[0].name == 'gather_subset'
    assert 'gather_subset' in fact_collector.collect(collected_facts={}).keys()

    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           gather_subset=['all'],
                                           filter_spec=['*linux*'])
    assert fact_collector is not None
    assert len(fact_collector.collectors) == 1
    assert fact_

# Generated at 2022-06-22 22:39:29.556488
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collectors = [
        MockFactsCollector(),
        MockFactsCollector(),
        MockFactsCollector()
    ]
    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=MockFactNamespace('facter'))

    collected_facts = {}
    facts = fact_collector.collect(collected_facts=collected_facts)
    assert facts == {'ansible_facter.fact1': 1,
                     'ansible_facter.fact2': True,
                     'ansible_facter.fact3': ['v1', 'v2']}

# Test for from_gather_subset method of class AnsibleFactCollector

# Generated at 2022-06-22 22:39:39.554499
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    namespace = None
    gather_subset = None
    module_setup = None

    meta_collector = \
        CollectorMetaDataCollector(collectors=None,
                                   namespace=namespace,
                                   gather_subset=gather_subset,
                                   module_setup=module_setup)

    if gather_subset != meta_collector.gather_subset:
        raise("gather_subset does not match")

    if module_setup != meta_collector.module_setup:
        raise("module_setup does not match")

    if meta_collector.collectors != None:
        raise("collectors does not match")

    if meta_collector.namespace != None:
        raise("namespace does not match")

    gather_subset = 'all'
    module_setup = True

    meta_

# Generated at 2022-06-22 22:39:47.315365
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_classes = [CollectorMetaDataCollector]
    collectors = collector.collector_classes_from_gather_subset(
        all_collector_classes=collector_classes,
        minimal_gather_subset=frozenset(),
        gather_subset=['all'],
        gather_timeout=60)
    assert len(collectors) == 1
    assert collectors[0].name == 'gather_subset'
    assert collectors[0].gather_subset == ['all']
    assert collectors[0].module_setup == True

# Generated at 2022-06-22 22:39:50.603932
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    a = AnsibleFactCollector(collectors=['c1', 'c2'],
                             namespace='ns',
                             filter_spec='foo')
    assert a.collectors == ['c1', 'c2']
    assert a.namespace == 'ns'
    assert a.filter_spec == 'foo'


# Generated at 2022-06-22 22:39:52.931814
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    try:
        CollectorMetaDataCollector()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 22:40:02.053451
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class CollectorFoo(collector.BaseFactCollector):
        name = 'foo'

        def collect(self, module=None, collected_facts=None):
            # pylint: disable=unused-argument
            return {'foo': 'bar'}

    class CollectorFoo2(collector.BaseFactCollector):
        name = 'foo2'

        def collect(self, module=None, collected_facts=None):
            # pylint: disable=unused-argument
            return {'foo2': 'bar2'}

    class CollectorFoo3(collector.BaseFactCollector):
        name = 'foo3'

        def collect(self, module=None, collected_facts=None):
            # pylint: disable=unused-argument
            raise NotImplementedError('Test exception')


# Generated at 2022-06-22 22:40:02.688842
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # FIXME: write test
    pass

# Generated at 2022-06-22 22:40:12.182780
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.distribution as dist
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionCollector

    # Having this test for the DistributionCollector's namespace
    # in the ansible_facts.system namespace helps make
    # sure we are returning the correct namespace for the distribution class
    # so that the distribution fact can be collected in the ansible_facts.system
    # namespace.
    module = None
    namespace_obj = dist.namespace
    assert isinstance(namespace_obj, PrefixFactNamespace)
    assert namespace_obj.prefix == 'ansible_facts.system.'

# Generated at 2022-06-22 22:40:16.776796
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import sys
    setattr(sys.modules[__name__],
            'test_CollectorMetaDataCollector',
            CollectorMetaDataCollector)
    from collector import CollectorMetaDataCollector

    collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset=['all'])

    assert collector_meta_data_collector.gather_subset == ['all']

# Generated at 2022-06-22 22:40:23.227231
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_col = CollectorMetaDataCollector()
    fact = fact_col.collect()
    assert fact['gather_subset'] == []
    assert fact['module_setup'] == True
    fact_col = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    fact = fact_col.collect()
    assert fact['gather_subset'] == ['all']
    assert fact['module_setup'] == False

# Generated at 2022-06-22 22:40:34.813147
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_defaults
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockCollector(BaseFactCollector):
        name = 'mockcollector'
        _fact_ids = set(['mockfact'])

        def collect(self, module=None, collected_facts=None):
            return {self.namespace_prefix + 'mockfact': 'mockvalue'}


# Generated at 2022-06-22 22:40:42.296464
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import collectors as c
    from ansible.module_utils.facts import namespaces

    all_collector_classes = [
        c.FacterBaseFactCollector,
        c.OhaiBaseFactCollector,
        c.RedHatSubscriptionFactCollector,
        c.VirtualboxFactCollector,
        c.VMwareFactCollector,
        c.NetworkFactCollector,
        c.DockerFactCollector,
        c.WindowsRegistryFactCollector,
        c.NetworkInterfaceFactCollector,
        c.LinuxSysctlFactCollector,
        c.DpkgFactCollector,
    ]

    fact_collector = \
        get_ansible_collector

# Generated at 2022-06-22 22:40:49.160898
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import os
    from ansible.module_utils.facts import platform
    from ansible.module_utils.facts import virtual

    all_collector_classes = set([])
    all_collector_classes.update(default.collector_classes)
    all_collector_classes.update(hardware.collector_classes)
    all_collector_classes.update(os.collector_classes)
    all_collector_classes.update(platform.collector_classes)
    all_collector_classes.update(virtual.collector_classes)


# Generated at 2022-06-22 22:41:00.064200
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import namespace

    fact_namespace = namespace.PrefixFactNamespace(prefix='ansible_')
    fact_collector = \
        AnsibleFactCollector(namespace=fact_namespace)

    collected_facts = {}
    collected_facts.update(fact_collector.collect())

    assert 'ansible_all_ipv4_addresses' in collected_facts['ansible_facts']
    assert collected_facts['ansible_facts']['ansible_all_ipv4_addresses']


if __name__ == '__main__':
    # Make this module as executable
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-22 22:41:10.062381
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class FakeCollector1(collector.BaseFactCollector):
        name = 'fake_collector1'

        def collect(self, module=None, collected_facts=None):
            return {'fact1': 1, 'fact2': 2}

    class FakeCollector2(collector.BaseFactCollector):
        name = 'fake_collector2'

        def collect(self, module=None, collected_facts=None):
            return {'fact3': 3}

    all_collector_classes = [FakeCollector1, FakeCollector2]


# Generated at 2022-06-22 22:41:13.431328
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import processor

    # Create a ad-hoc fact collector with a ad-hoc fact processor
    fact_collector = AnsibleFactCollector(collectors=[processor.ProcessorCollector()])
    fact_collector.collect()

# Generated at 2022-06-22 22:41:14.949340
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    AnsibleFactCollector(collectors=None,
                         namespace=None,
                         filter_spec=None)

# Generated at 2022-06-22 22:41:26.713952
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.setup
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.system


# Generated at 2022-06-22 22:41:30.705819
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    collected_facts = collector_meta_data_collector.collect()
    assert collected_facts['gather_subset'] is 'all'
    assert collected_facts['module_setup'] is True


# Generated at 2022-06-22 22:41:42.458383
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import ntc_platform
    from ansible.module_utils.facts import systemd

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    ntc_platform_ns = PrefixFactNamespace(prefix='ansible_ntc_platform_',
                                          namespace=ntc_platform)

    systemd_ns = PrefixFactNamespace(prefix='ansible_systemd_',
                                     namespace=systemd)

    all_collector_classes = [ntc_platform_ns, systemd_ns]

    # Make sure we get the two collectors we expect

# Generated at 2022-06-22 22:41:43.173951
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass


# Generated at 2022-06-22 22:41:50.442093
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Test constructor of class AnsibleFactCollector.
       This is a unit test for testing constructor of AnsibleFactCollector.

       Expected result: return instance of AnsibleFactCollector.

       The code snippet for this unit test is as following.
       ....
        all_collector_classes = [collector.BaseFactCollector,
                                 ohai_collector.OhaiFactCollector,
                                 facter_collector.FacterFactCollector]

        fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                               filter_spec=filter_spec,
                                               gather_subset=['all', 'network'],
                                               gather_timeout=10)
       ....

       Result of this unit test case: instance of AnsibleFactCollector
    '''

# Generated at 2022-06-22 22:41:58.447942
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_collector = \
        CollectorMetaDataCollector(gather_subset='network',
                                   module_setup=True)
    test_collected_facts = {}
    test_metadata_facts = test_collector.collect(module=None,
                                                 collected_facts=test_collected_facts)
    assert test_metadata_facts['gather_subset'] == 'network'
    assert test_metadata_facts['module_setup'] == True


# Generated at 2022-06-22 22:42:07.185155
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.network.bsd import BsdInterfaceCollector
    from ansible.module_utils.facts.collector.network.linux import LinuxInterfaceCollector

    namespace = PrefixFactNamespace(prefix='ansible_')
    linux_collector = LinuxInterfaceCollector(namespace=namespace)
    bsd_collector = BsdInterfaceCollector(namespace=namespace)
    collectors = [linux_collector, bsd_collector]
    gather_subset = ['all']
    module_setup = True
    meta_collector = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)

# Generated at 2022-06-22 22:42:15.733436
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ''' Unit test for constructor of class AnsibleFactCollector.
         '''
    collectors = []
    namespace = collector.namespace.EmptyNamespace()
    filter_spec = ['filter_spec']
    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec=filter_spec,
                             namespace=namespace)

    assert len(fact_collector.collectors) == 0
    assert fact_collector.namespace == namespace
    assert fact_collector.filter_spec == filter_spec



# Generated at 2022-06-22 22:42:23.354825
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system.memory

    fact_collector = get_ansible_collector(all_collector_classes=[ansible.module_utils.facts.system.memory])

    result = fact_collector.collect()

    assert result['ansible_facts']['ansible_system_vendor'] == '', \
        "Failed to collect ansible_system_vendor"

# Generated at 2022-06-22 22:42:32.039970
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    namespace = None
    gather_subset = ['all']
    module_setup = None
    collector_meta_data_collector = CollectorMetaDataCollector(collectors=None,
                                                               namespace=namespace,
                                                               gather_subset=gather_subset,
                                                               module_setup=module_setup)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all']}

    # test with module_setup
    module_setup = {'layout': {'path': '/layout.py', 'extra': [1, 2, 3]}}

# Generated at 2022-06-22 22:42:40.831403
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    mock_collectors = [
        MockCollector(name='test_1', facts={'a': 'b', 'c': 'd'}),
        MockCollector(name='test_2', facts={'e': 'f', 'g': 'h'})
    ]

    fact_collector = AnsibleFactCollector(collectors=mock_collectors)
    collected_facts = fact_collector.collect()

    assert collected_facts == {'a': 'b', 'e': 'f', 'c': 'd', 'g': 'h'}



# Generated at 2022-06-22 22:42:52.507616
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = \
        collector.all_collector_classes()
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=['all'])

    import json
    # This usually dumps out a lot of stuff
    # print(json.dumps(fact_collector.collect(), sort_keys=True, indent=4))
    # print('-'*80)
    # print(json.dumps(fact_collector.collect(module=True), sort_keys=True, indent=4))
    # print('-'*80)
    # print(json.dumps(fact_collector.collect(module=True, collected_facts={'a': 1}), sort_keys=True, indent=4))
    #

# Generated at 2022-06-22 22:43:03.178856
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts import default
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    ns = PrefixFactNamespace(prefix='ns_')

    fact_collector = AnsibleFactCollector(collectors=[default.FactsCollector()],
                                          namespace=ns)

    facts = fact_collector.collect()

    assert ns.real_name('ns_fact1') in facts
    assert ns.real_name('ns_fact2') in facts
    assert 'fact2' not in facts
