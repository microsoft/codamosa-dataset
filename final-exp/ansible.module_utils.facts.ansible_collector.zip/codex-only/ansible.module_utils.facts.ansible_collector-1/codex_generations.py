

# Generated at 2022-06-22 22:33:04.279990
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import mock

    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            facts_dict['foo'] = None
            facts_dict['bar'] = None
            facts_dict['fie'] = None
            return facts_dict

    mock_collector = TestCollector()

    collector_obj = AnsibleFactCollector(collectors=[mock_collector], namespace=None)
    actual_facts_dict = collector_obj.collect()
    expected_facts_dict = {'foo': None, 'bar': None, 'fie': None}

    assert actual_facts_dict == expected_facts_dict, 'Ansible Fact Collector collect method failed to collect'



# Generated at 2022-06-22 22:33:10.392654
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # test construction with empty collectors
    ansible_fact_collector = AnsibleFactCollector(collectors=[])
    assert ansible_fact_collector.collectors == []
    assert ansible_fact_collector.namespace is None
    assert ansible_fact_collector.filter_spec is None

    # test construction with non empty collectors and namespace
    collectors = [1, 2]
    namespace = PrefixFactNamespace(prefix='ansible_')
    ansible_fact_collector = AnsibleFactCollector(collectors=collectors,
                                                  namespace=namespace)
    assert ansible_fact_collector.collectors == collectors
    assert ansible_fact_collector.namespace == namespace
    assert ansible_fact_collect

# Generated at 2022-06-22 22:33:22.369393
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Test method collect of class AnsibleFactCollector.'''
    try:
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
    except ImportError:
        PrefixFactNamespace = None
    try:
        from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict
    except ImportError:
        PrefixFactNamespaceDict = None
    try:
        from ansible.module_utils.facts.namespace import MergePrefixFactNamespaceDict
    except ImportError:
        MergePrefixFactNamespaceDict = None
    try:
        from ansible.module_utils.facts.namespace import MergePrefixFactNamespace
    except ImportError:
        MergePrefixFactNamespace = None


# Generated at 2022-06-22 22:33:30.591509
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [MockCollector, MockCollectorWithNamespace]
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              filter_spec=['*'],
                              gather_subset=['all'],
                              gather_timeout=None,
                              minimal_gather_subset=None)

    facts = fact_collector.collect()

    assert not facts.get('ansible_facts')

    # Get ansible facts
    ansible_facts = facts.get('ansible_facts', {})
    assert ansible_facts.get('fact_key') == 'fact_value'

    # Get namespace facts
    namespace_facts = ansible_facts.get('namespace', {})
    assert namespace_facts.get

# Generated at 2022-06-22 22:33:36.656475
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c1 = CollectorMetaDataCollector(gather_subset=['all'])
    assert c1.gather_subset == ['all']
    assert c1.module_setup
    c2 = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    assert c2.gather_subset == ['all']
    assert not c2.module_setup

# Generated at 2022-06-22 22:33:42.933691
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''ansible_facts can be set to anything. Ansible will not attempt to use this as a fact.'''
    ansible_facts = 'not a fact'
    fact_collector = CollectorMetaDataCollector(gather_subset=ansible_facts)
    fact_dict = fact_collector.collect()
    ansible_facts = 'not a fact'
    assert fact_dict['gather_subset'] == ansible_facts
    return True

# Generated at 2022-06-22 22:33:47.435073
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    result = get_ansible_collector(all_collector_classes=[],
                                   namespace=None,
                                   filter_spec=None,
                                   gather_subset=None,
                                   gather_timeout=None,
                                   minimal_gather_subset=None)

    assert result.collectors is not []

# Generated at 2022-06-22 22:33:50.505406
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector()
    if c.gather_subset is None:
        raise Exception('gather_subset is None')
    if c.module_setup is None:
        raise Exception('module_setup is None')

# Generated at 2022-06-22 22:33:58.457811
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    """unit test for AnsibleFactCollector"""

    class mock_collector(object):
        def __init__(self, b):
            self.b = b

        def collect_with_namespace(self, module, collected_facts):
            ret = {'a':'1','b':'2','c':'3'}
            ret[self.b] = '5'
            return ret

    mock_collectors = [
        mock_collector('b'),
        mock_collector('c')
    ]
    mock_collectors_copy = [
        mock_collector('b'),
        mock_collector('c')
    ]

    fc = AnsibleFactCollector(collectors=mock_collectors,
                              filter_spec=['a', 'c'])

    facts = fc.collect()



# Generated at 2022-06-22 22:34:08.289552
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with a single collector collecting a single fact

    # Arrange
    TestCollector = collector.Collector
    collector_class = TestCollector
    collector_obj = collector_class()
    expected_info_dict = {'a': 1}
    collector_obj.collect_with_namespace = \
        lambda collected_facts: expected_info_dict

    # Act
    test_collector = AnsibleFactCollector(collectors=[collector_obj])
    collected_facts = test_collector.collect()

    # Assert
    assert collected_facts == expected_info_dict



# Generated at 2022-06-22 22:34:12.159806
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # arrange
    collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    # act
    result = collector.collect()
    # assert
    assert result == {'gather_subset': ['all']}

# Generated at 2022-06-22 22:34:20.401858
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils
    for _name in dir(ansible.module_utils):
        if _name.startswith('facts'):
            x = getattr(ansible.module_utils, _name)
            if hasattr(x, 'collector_classes'):
                if x.collector_classes:
                    metadata_collector = CollectorMetaDataCollector(collectors=x.collector_classes,
                                                                    namespace='ansible_',
                                                                    gather_subset=['all'])
                    assert metadata_collector.name == 'gather_subset'
                    assert metadata_collector.collectors == x.collector_classes
                    assert metadata_collector.namespace == 'ansible_'
                    assert metadata_collector.gather_subset == ['all']
                    assert metadata_collect

# Generated at 2022-06-22 22:34:31.083898
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # filter_spec == '*'
    afc = AnsibleFactCollector(filter_spec='*')
    assert afc.filter_spec == '*'

    # filter_spec == ''
    afc = AnsibleFactCollector(filter_spec='')
    assert afc.filter_spec == '*'

    # filter_spec == ['']
    afc = AnsibleFactCollector(filter_spec=[''])
    assert afc.filter_spec == '*'

    # filter_spec == []
    afc = AnsibleFactCollector(filter_spec=[])
    assert afc.filter_spec == '*'

    # filter_spec == 'gather_subset'
    afc = AnsibleFactCollector(filter_spec='gather_subset')

# Generated at 2022-06-22 22:34:34.060719
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    coll = CollectorMetaDataCollector([], None, ['foo', 'bar'], True)
    assert 'gather_subset' in coll.collect()
    assert 'module_setup' in coll.collect()



# Generated at 2022-06-22 22:34:44.948569
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()

    assert fact_collector.collectors == []
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert fact_collector.name == 'AnsibleFactCollector'

    namespace = 'test_AnsibleFactCollector'
    fact_collector = AnsibleFactCollector(namespace=namespace)

    assert fact_collector.collectors == []
    assert fact_collector.namespace == namespace
    assert fact_collector.filter_spec is None
    assert fact_collector.name == 'AnsibleFactCollector'

    collectors = [1, 2, 3]
    namespace = 'test_AnsibleFactCollector'

# Generated at 2022-06-22 22:34:55.048672
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    facts_dict = {'foo': {'a': 1, 'b': 2},
                  'bar': {'a': 2, 'b': 3}}

    def fake_collector_obj_collect(module=None, collected_facts=None):
        return facts_dict

    for collector_obj in fact_collector.collectors:
        collector_obj.collect = fake_collector_obj_collect

    result = fact_collector.collect()
    assert result == facts_dict

# Generated at 2022-06-22 22:34:58.205738
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    expected_meta_facts = {'gather_subset': 'all'}
    collector = CollectorMetaDataCollector(gather_subset='all')
    meta_facts = collector.collect()

    assert meta_facts == expected_meta_facts

# Generated at 2022-06-22 22:35:06.623520
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.test import ALL_COLLECTORS, TestFactCollector, Test2FactCollector
    fact_collector = get_ansible_collector(
        all_collector_classes=ALL_COLLECTORS,
        gather_subset='_test',
        gather_timeout=10,
        minimal_gather_subset=frozenset(['_test']))

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.collectors[0], TestFactCollector)

# Generated at 2022-06-22 22:35:09.265593
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset='all')
    facts = fact_collector.collect()
    assert facts['gather_subset'] == 'all'

# Generated at 2022-06-22 22:35:19.172598
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # We need to mock the all_collector_classes and namespace
    class MockNamespace:
        def __init__(self, name):
            self.name = name

    class MockCollectorClass:
        def __init__(self, namespace=None):
            self.namespace = namespace

    mock_collector1 = MockCollectorClass(namespace=MockNamespace('mock_collector1'))
    mock_collector2 = MockCollectorClass(namespace=MockNamespace('mock_collector2'))
    mock_collector_classes = [mock_collector1, mock_collector2]

    mock_namespace = MockNamespace('mock_namespace')

    # Invoke get_ansible_collector

# Generated at 2022-06-22 22:35:31.283410
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from mock import patch, Mock

    # Test: module_setup is True by default
    all_collector_classes = {}
    gather_subset = ['all']
    gather_timeout = None
    minimal_gather_subset = None
    MODULE_NAME = 'ansible.module_utils.facts.collectors.setup'

    with patch(MODULE_NAME) as mock_setup:
        mock_setup.return_value = {'facts': {'ansible_facts': {'gather_subset': gather_subset}}}
        fact_collector = CollectorMetaDataCollector(gather_subset=gather_subset)

# Generated at 2022-06-22 22:35:39.916937
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network

    all_collector_classes = [
        ansible.module_utils.facts.collector.all.AllCollector,
        ansible.module_utils.facts.collector.network.NetworkCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])
    assert fact_collector.collect()

# Generated at 2022-06-22 22:35:47.775064
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    def assertDictEqual(expected, actual, msg=None):
        '''Asserts that expected and actual are equal as dicts.
        '''
        if expected != actual:
            if sys.version_info >= (2, 7):
                import difflib
                missing = dict(set(expected.items()).difference(set(actual.items())))
                unexpected = dict(set(actual.items()).difference(set(expected.items())))
                err_msg = 'Dicts not equal:\n'
                if missing:
                    err_msg += '  Missing items:\n'
                    err_msg += '\n'.join('    {}: {}'.format(k, repr(v)) for k, v in missing.items())
                if unexpected:
                    err_msg += '  Unexpected items:\n'
                    err_msg

# Generated at 2022-06-22 22:35:51.524103
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collect = CollectorMetaDataCollector(gather_subset = ['all'], module_setup = True)
    result = collect.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:36:03.189166
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.collectors.base as base
    import ansible.module_utils.facts.collectors.facter as facter
    import ansible.module_utils.facts.collectors.ohai as ohai
    import ansible.module_utils.facts.collectors.pkg_mgr as pkg_mgr

    # Setup a namespace for test
    ns_name = 'ns_name'
    ns = namespace.BaseFactNamespace(name=ns_name)

    # Setup a collector with a name and a namespace
    facter_collector_name = 'facter_collector'
    facter_collector = facter.FacterCollector(namespace=ns)

    # Setup a collector with a name and do not setup a namespace

# Generated at 2022-06-22 22:36:09.050808
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    #test case 1
    all_collector_classes = [collector.Facter]
    subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec=filter_spec,
                             namespace=namespace)
    fact_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-22 22:36:11.531751
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    try:
        AnsibleFactCollector()
        assert False
    except:
        assert True
    pass

# Generated at 2022-06-22 22:36:20.248516
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Create a new collector that will collect ansible_facts
    fact_collector = AnsibleFactCollector(namespace=PrefixFactNamespace(prefix='ansible_'))

    # Collect facts
    ansible_facts = fact_collector.collect()

    # Validate that the key of the collected facts is 'ansible_facts'
    assert ansible_facts.keys() == ['ansible_facts']

    # Validate that the value of collected facts is a list
    assert isinstance(ansible_facts['ansible_facts'], dict)



# Generated at 2022-06-22 22:36:29.360566
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Note: We don't test actual values of the meta_facts since their values will vary
    # depending on environment specifics
    c = CollectorMetaDataCollector(namespace=None,
                                   gather_subset=['min', '!all'],
                                   module_setup=False)
    foo = c.collect()
    assert foo
    assert 'gather_subset' in foo
    assert 'module_setup' not in foo

    c = CollectorMetaDataCollector(namespace=None,
                                   gather_subset=['all'],
                                   module_setup=True)
    foo = c.collect()
    assert foo
    assert 'gather_subset' in foo
    assert 'module_setup' in foo

# Generated at 2022-06-22 22:36:32.276283
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert isinstance(collector_meta_data_collector, CollectorMetaDataCollector)


# Generated at 2022-06-22 22:36:44.531616
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.system as system

    fact_namespace = namespace.PrefixFactNamespace(prefix='ansible_')
    hostname_namespace = namespace.PrefixFactNamespace(prefix='hostname')
    system_collector = system.SystemCollector()

    fact_collector = \
        AnsibleFactCollector(collectors=[system_collector],
                             namespace=fact_namespace,
                             filter_spec=['ansible_', '/^hostname/'])

    # get facts for the node
    facts = fact_collector.collect()

    # assert we are getting the 'localhost' back for our fact

# Generated at 2022-06-22 22:36:45.307594
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert 1

# Generated at 2022-06-22 22:36:55.046483
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Simple class that collects a dict of {'a': 'A', 'b': 'B'}
    class CollectorOne(collector.BaseFactCollector):
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'a': 'A', 'b': 'B'}

    # Constructor of AnsibleFactCollector
    ansible_fact_collector = AnsibleFactCollector(collectors=[CollectorOne()])
    ansible_fact_collector._filter = lambda x, y: x

    # Get the collected facts from ansible fact collector
    fact_dict = ansible_fact_collector.collect()

    # Fact dict should have the following values
    assert 'a' in fact_dict
    assert 'b' in fact_dict
    assert not 'c' in fact_dict


# Generated at 2022-06-22 22:37:07.833036
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # module test for AnsibleFactCollector() constructor
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.processor as processor

    # constructor should always work
    kernel_collector = \
        ansible.module_utils.facts.collector.DefaultSysctlFactCollector(namespace.KernelNamespace())
    ansible_collector = \
        AnsibleFactCollector(collectors=kernel_collector)

    # create a class with a useless method just to ensure it is not called

# Generated at 2022-06-22 22:37:09.364111
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''test collect() method of class AnsibleFactCollector'''

    # TODO: need to add unittests here
    pass

# Generated at 2022-06-22 22:37:19.873298
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    class TestFactCollector(collector.BaseFactCollector):
        name = 'facts'
        _fact_ids = set(['facts'])

        def collect(self, module=None, collected_facts=None):
            return {'facts': 1}

    test_collectors = [
        TestFactCollector()
    ]

    # with no filter, return all facts
    fact_collector = AnsibleFactCollector(collectors=test_collectors)
    facts = fact_collector.collect()
    assert facts == {'facts': 1}

    # with filter, return facts matching filter
    fact_collector = AnsibleFactCollector(collectors=test_collectors, filter_spec='*')
    facts = fact_collector.collect()
    assert facts == {'facts': 1}

    fact_collector = Ans

# Generated at 2022-06-22 22:37:30.975873
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Case when gather_subset is not None and module_setup is None.
    collector_obj = CollectorMetaDataCollector(gather_subset=['no_data'],
                                               module_setup=None)
    assert collector_obj.collect()['gather_subset'] == ['no_data']
    assert collector_obj.collect()['module_setup'] is None

    # Case when gather_subset is None and module_setup is not None.
    collector_obj = CollectorMetaDataCollector(gather_subset=None,
                                               module_setup=True)
    assert collector_obj.collect()['gather_subset'] is None
    assert collector_obj.collect()['module_setup'] is True

    # Case when gather_subset and module_setup are both not None.
    collector_obj = CollectorMeta

# Generated at 2022-06-22 22:37:36.241539
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all')
    meta_facts = collector_meta_data_collector.collect()
    expected_meta_facts = {'gather_subset': 'all'}
    assert meta_facts == expected_meta_facts

# Generated at 2022-06-22 22:37:45.415799
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test for method collect() of class CollectorMetaDataCollector.'''

    # Setup
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all', 'min'], module_setup=True)

    # Test
    meta_facts = collector_meta_data_collector.collect()
    actual_result = meta_facts['gather_subset']
    actual_result_2 = meta_facts['module_setup']

    # Verify
    assert actual_result == ['all', 'min']
    assert actual_result_2 is True


# Generated at 2022-06-22 22:37:49.302817
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector('', '', ['minimal', 'other subscribers'])
    # test the collection of facts
    meta_facts = fact_collector.collect()
    assert meta_facts['gather_subset'] == ['minimal', 'other subscribers']
    assert meta_facts['module_setup'] is True



# Generated at 2022-06-22 22:37:57.998083
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    fact_collector = AnsibleFactCollector()
    collected_facts = fact_collector.collect()

    assert collected_facts
    assert 'gather_subset' in collected_facts
    assert 'module_setup' in collected_facts
    assert 'default' in collected_facts['gather_subset']
    assert len(collected_facts['gather_subset']['default']) > 0
    assert 'ansible_distribution' in collected_facts
    assert 'ansible_os_family' in collected_facts



# Generated at 2022-06-22 22:37:59.023416
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-22 22:38:11.000445
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    fc = AnsibleFactCollector()
    assert fc.namespace is None
    assert len(fc.collectors) == 0
    assert fc.filter_spec is None

    fc = AnsibleFactCollector(namespace='foo')
    assert fc.namespace == 'foo'
    assert len(fc.collectors) == 0
    assert fc.filter_spec is None

    fc = AnsibleFactCollector(namespace='foo', filter_spec='*')
    assert fc.namespace == 'foo'
    assert len(fc.collectors) == 0
    assert fc.filter_spec == '*'

    fc = AnsibleFactCollector(namespace='foo', filter_spec=['bar', 'baz'])
    assert fc.namespace == 'foo'

# Generated at 2022-06-22 22:38:17.682996
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = []
    gather_subset = ['all', 'min']
    module_setup = False
    collector_meta_data_collector = CollectorMetaDataCollector(collectors,
                                                               gather_subset=gather_subset,
                                                               module_setup=module_setup)
    info_dict = collector_meta_data_collector.collect()

    assert len(info_dict) == 2
    assert info_dict['gather_subset'] == gather_subset
    assert info_dict['module_setup'] == module_setup


# Generated at 2022-06-22 22:38:24.140914
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collectors = [
        collector.BaseFactCollector('collector1', namespace=None),
        collector.BaseFactCollector('collector2', namespace=None)
    ]

    # Assert that all collectors are called when no filter_spec is given.
    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=None,
                             filter_spec=None)
    for collector_obj in collectors:
        collector_obj.collect_with_namespace = \
            lambda x, y: {collector_obj.name: True}

    result = fact_collector.collect()
    assert len(result) == len(collectors)
    for collector_obj in collectors:
        assert result[collector_obj.name]

    # Assert that filtered collectors are called and non filtered ones are not.

# Generated at 2022-06-22 22:38:30.732120
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collectors = []
    namespace = collector.namespace.PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          namespace=namespace)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors == collectors
    assert fact_collector.namespace == namespace
    assert fact_collector.filter_spec is None

# Generated at 2022-06-22 22:38:36.191458
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # test with no args
    collector_meta_data_collector = CollectorMetaDataCollector()
    assert collector_meta_data_collector.gather_subset is None

    # test with given args
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['network'])
    assert collector_meta_data_collector.gather_subset == ['network']



# Generated at 2022-06-22 22:38:43.215264
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Test that CollectorMetaDataCollector returns a dictionary
       with 'gather_subset' and 'module_setup' keys.  The 'gather_subset'
       is equal to the value of the 'gather_subset' argument passed to the
       constructor and 'module_setup' is always True.'''

    # Number of tests
    NUM_TEST = 2

    # Create a CollectorMetaDataCollector with 'gather_subset' argument set
    # to 'all'.
    collector_metadata_collector = CollectorMetaDataCollector(gather_subset='all')

    # Call the collect method and confirm 'gather_subset' equals 'all'
    # and 'module_setup' equals True
    facts_dict = collector_metadata_collector.collect()

# Generated at 2022-06-22 22:38:46.881530
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(gather_subset='base')
    assert 'base' == c.gather_subset

# Generated at 2022-06-22 22:38:54.375012
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # memory is a test class
    from ansible.module_utils.facts import memory

    # setup some test data
    test_mem_data = {'MemTotal': '12345 bytes',
                     'MemFree': '1234 bytes',
                     'SwapTotal': '3456 bytes',
                     'SwapFree': '3456 bytes'}
    memory._fact_ids.update(test_mem_data)

    # test a dummy namespace

    collectors = [memory.MemoryCollector(namespace=namespace)
                  for namespace in [None, 'test', 'test1.test2']]

    # create AnsibleFactCollector with the test collector
    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace='test')

    # 'init' the test collector
    collected_facts = {}


# Generated at 2022-06-22 22:38:59.512289
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    collectors = [collector.BaseFactCollector()]
    namespace = None
    filter_spec = []

    ansible_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=namespace,
                             filter_spec=filter_spec)

    assert ansible_collector.collectors == collectors
    assert ansible_collector.namespace is None
    assert ansible_collector.filter_spec == filter_spec

# Generated at 2022-06-22 22:39:07.992126
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collectors = None
    namespace = None
    gather_subset = [ 'network', 'protocols', 'facter' ]
    module_setup = False
    fact_collector = CollectorMetaDataCollector(collectors,
                                                namespace,
                                                gather_subset,
                                                module_setup)

    meta_facts = fact_collector.collect(None, None)
    assert meta_facts['gather_subset'] == [ 'network', 'protocols', 'facter' ]
    assert meta_facts['module_setup'] == False


# Generated at 2022-06-22 22:39:15.972202
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    CollectorMetaDataCollector(gather_subset=['all'])
    CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)

    try:
        CollectorMetaDataCollector(gather_subset=None)
        assert False
    except AssertionError as e:
        pass

    try:
        CollectorMetaDataCollector(gather_subset=['all'], module_setup='True')
        assert False
    except AssertionError as e:
        pass

# Generated at 2022-06-22 22:39:27.429928
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # test no filters
    a = AnsibleFactCollector(filter_spec=None)
    a.collectors = [
        collector.SimpleFactCollector({'a': 1, 'b': 2}),
        collector.SimpleFactCollector({'b': 3, 'c': 4}),
    ]
    assert a.collect() == {'ansible_facts': {'a': 1, 'b': 3, 'c': 4}}

    # test with filters
    a = AnsibleFactCollector(filter_spec=None)
    a.collectors = [
        collector.SimpleFactCollector({'a': 1, 'b': 2}),
        collector.SimpleFactCollector({'b': 3, 'c': 4}),
    ]

# Generated at 2022-06-22 22:39:35.033831
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollectorOne(collector.BaseFactCollector):

        name = 'mockcollectorone'

        def collect(self, module=None, collected_facts=None):
            return {'one': '1'}

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'one': '1'}

    class MockCollectorTwo(collector.BaseFactCollector):

        name = 'mockcollectortwo'

        def collect(self, module=None, collected_facts=None):
            return {'two': '2'}

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'two': '2'}

    mockcollectorone = MockCollectorOne()
    mockcollectortwo = MockCollectorTwo()

# Generated at 2022-06-22 22:39:42.959379
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = []
    fact_collector = \
        CollectorMetaDataCollector(collectors=collectors, gather_subset=['min'], module_setup=True)
    assert fact_collector.collect() == {'gather_subset': ['min'], 'module_setup':True}

    fact_collector = \
        CollectorMetaDataCollector(collectors=collectors, gather_subset=['min'], module_setup=False)
    assert fact_collector.collect() == {'gather_subset': ['min']}

    fact_collector = \
        CollectorMetaDataCollector(collectors=collectors, gather_subset=['min'])
    assert fact_collector.collect() == {'gather_subset': ['min']}


# Generated at 2022-06-22 22:39:50.210024
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts
    all_collector_classes = ansible.module_utils.facts.collectors.all_collector_classes
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)

    facts_dict = fact_collector.collect()

    #print(facts_dict)

    assert(set(facts_dict.keys()) == set(['gather_subset']))

# Generated at 2022-06-22 22:39:59.193284
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import NamespacePrefixFactNamespace
    from ansible.module_utils.facts.netdev_base import NetDevBase
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.system import System
    from ansible.module_utils.facts.distribution import Distribution
    from ansible.module_utils.facts.network import Network

    ns = NamespacePrefixFactNamespace(prefix='ansible_')
    collectors = [NetDevBase(namespace=ns), Hardware(namespace=ns),
                  Virtual(namespace=ns), System(namespace=ns),
                  Distribution(namespace=ns), Network(namespace=ns)]

    fact_collector = AnsibleFact

# Generated at 2022-06-22 22:40:11.045045
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    filter_spec = filter_spec or []
    gather_subset = gather_subset or ['all']
    gather_timeout = gather_timeout or timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = minimal_gather_subset or frozenset()
    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=minimal_gather_subset,
            gather_subset=gather_subset,
            gather_timeout=gather_timeout)
    collectors = []
    for collector_class in collector_classes:
        collector_obj = collector_class(namespace=namespace)
        collectors.append(collector_obj)

    # Add a collector

# Generated at 2022-06-22 22:40:15.379161
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    fact_collector = get_ansible_collector(all_collector_classes=ansible.module_utils.facts.collector.collectors)

    collected_facts = fact_collector.collect()

    # Test that we have an ansible_facts top level key
    assert 'ansible_facts' in collected_facts

    ansible_facts = collected_facts['ansible_facts']

    # test that we have a 'gather_subset' at the top level
    assert 'gather_subset' in ansible_facts

    # test that we have 'ansible_distribution' which should be in all sets
    assert 'ansible_distribution' in ansible_facts

# Generated at 2022-06-22 22:40:24.161747
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    namespace = 'ansible'
    gather_subset = ['!all', 'network']
    collector_meta_data_collector = CollectorMetaDataCollector(namespace=namespace,
                                                               gather_subset=gather_subset)
    assert collector_meta_data_collector.collect(collected_facts={},
                                                 module=None) == {'gather_subset': ['!all', 'network']}
    assert collector_meta_data_collector.collect(collected_facts={},
                                                 module=None) == {'gather_subset': ['!all', 'network']}

# Generated at 2022-06-22 22:40:30.190836
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector is not None
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup is True


# Generated at 2022-06-22 22:40:40.374824
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class CollectorDummy(collector.BaseFactCollector):
        name = 'collector_dummy'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'nothing'}

    dummycollector1 = CollectorDummy()
    dummycollector2 = CollectorDummy()
    ansiblecollector = AnsibleFactCollector(collectors=[dummycollector1, dummycollector2])

    mock_module = None
    mock_collected_facts = None

    actualresult = ansiblecollector.collect(module=mock_module, collected_facts=mock_collected_facts)

    expectedresult = {
        'test': 'nothing'
    }
    assert actualresult == expectedresult



# Generated at 2022-06-22 22:40:47.856344
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Test get_ansible_collector()'''
    import ansible.module_utils.facts.namespace

    assert get_ansible_collector({})

    # Test with a collector that uses a namespace
    fact_collector = get_ansible_collector({
        'ansible.module_utils.facts.system.distribution':
            ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')})
    assert fact_collector
    collected_facts = fact_collector.collect()
    assert isinstance(collector, AnsibleFactCollector)
    assert collected_facts.get('ansible_distribution') is not None

    # Test with a collector that uses a namespace and also with a filter

# Generated at 2022-06-22 22:40:54.663191
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    try:
        collector_meta_data_collector = CollectorMetaDataCollector(None, 'test_namespace',
                                                                   'test_gather_subset',
                                                                   'test_module_setup')
        assert collector_meta_data_collector.gather_subset == 'test_gather_subset'
        assert collector_meta_data_collector.module_setup == 'test_module_setup'
    except Exception as e:
        print("Got exception : {}".format(repr(e)))
        assert False


if __name__ == "__main__":
    test_CollectorMetaDataCollector()

# Generated at 2022-06-22 22:40:59.019418
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test = CollectorMetaDataCollector("all")
    assert test.gather_subset == "all"
    assert test.module_setup == None
    test = CollectorMetaDataCollector("network", module_setup=True)
    assert test.module_setup == True

# Generated at 2022-06-22 22:41:05.821702
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    namespace.PrefixFactNamespace = namespace.PrefixFactNamespace
    a = namespace.PrefixFactNamespace
    filter_spec = "*"
    collectors = ["a", "b", "c"]
    fact_collector = AnsibleFactCollector(collectors=collectors, filter_spec=filter_spec, namespace=a)
    rc = fact_collector.collect(module=None, collected_facts=None)
    assert isinstance(rc, dict)

# Generated at 2022-06-22 22:41:08.094994
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(gather_subset='all')
    assert c.gather_subset == 'all'

# Generated at 2022-06-22 22:41:12.709704
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import tempfile
    import shutil
    import os
    import datetime
    import textwrap
    import subprocess
    import json

    # Create a temp dir for our fake fact collection module(s)
    class_dir = tempfile.mkdtemp()

    # Create a fake fact collection module.
    fake_module_path = os.path.join(class_dir, 'test_example.py')

# Generated at 2022-06-22 22:41:14.907315
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector('all',
                                   'ansible')
    assert collector_meta_data_collector is not None

# Generated at 2022-06-22 22:41:26.304203
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import copy
    # collector.BaseFactCollector.__init__ init also initializes
    # namespace and collectors 
    collectors = [collector.BaseFactCollector(), collector.BaseFactCollector()]
    namespace = collector.BaseFactNamespace()
    afc = AnsibleFactCollector(collectors=collectors, namespace=namespace,
                               filter_spec=['a','b','c','',None,'*'])
    # verify collectors and namespace were properly set
    assert(afc.collectors == collectors)
    assert(afc.namespace == namespace)
    # verify filter spec was properly set and normalized
    expected_filter_spec = ['a','b','c','*']
    assert(afc.filter_spec == expected_filter_spec)


# Generated at 2022-06-22 22:41:34.563416
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Fact collectors that have a gather_subset override to be in minimal_gather_subset
    # are not part of the minimal_gather_subset when setting gather_subset='!all'
    assert collector.collector_classes_from_gather_subset(
        all_collector_classes=collector.all_collector_classes,
        minimal_gather_subset=frozenset(['facter']),
        gather_subset=['!all'],
        gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT) == [collector.FacterCollector]
    # Collectors that have a gather_subset override to be in minimal_gather_subset
    # are part of the minimal_gather_subset even when setting gather_subset='!all'
    assert collector.collector_

# Generated at 2022-06-22 22:41:44.495428
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    kwargs = {
        'module': None,
        'collected_facts': None
    }

    collectors = []

    fact_subset_collector = \
        collector.FactSubsetCollector(namespace=None,
                                      fact_subset=['ansible_distribution_major_version'])
    collectors.append(fact_subset_collector)

    fact_subset_collector = \
        collector.FactSubsetCollector(namespace=None,
                                      fact_subset=['ansible_distribution_release'])
    collectors.append(fact_subset_collector)

    fact_subset_collector = \
        collector.FactSubsetCollector(namespace=None,
                                      fact_subset=['ansible_os_family'])

# Generated at 2022-06-22 22:41:51.421341
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = (collector.GenericFactCollector, collector.NetworkFactCollector)

    gather_subset = None
    expected_collector_classes = all_collector_classes
    collector = get_ansible_collector(all_collector_classes,
                                      gather_subset=gather_subset)
    assert collector is not None
    assert len(collector.collectors) == len(expected_collector_classes)

    gather_subset = ['all']
    expected_collector_classes = all_collector_classes
    collector = get_ansible_collector(all_collector_classes,
                                      gather_subset=gather_subset)
    assert collector is not None
    assert len(collector.collectors) == len(expected_collector_classes)

    gather_sub

# Generated at 2022-06-22 22:41:58.125024
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = \
        AnsibleFactCollector(filter_spec=['ansible_python_version'])

    fact_collector.collect(collected_facts={'foo': 'bar'})
    # [TODO] assert fact_collector.collect(collected_facts={'foo': 'bar'}) == {'ansible_python_version': u'2.7.5'}

# Generated at 2022-06-22 22:42:04.254061
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    exp_collectors = [
        {'gather_subset': ['all'], 'module_setup': True},
        {'gather_subset': ['all'], 'ansible_facts': {'facts1': 1, 'facts2': 2}},
    ]

    fact_collector = AnsibleFactCollector()

    assert fact_collector.collectors == exp_collectors
    assert fact_collector.filter_spec == None



# Generated at 2022-06-22 22:42:17.240575
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.base as base_fact_collector
    class FakeFactCollector(base_fact_collector.BaseFactCollector):
        def __init__(self, namespace=None):
            self.name = 'fake'
            self._fact_ids = set(['fact1'])
        def collect(self, module=None, collected_facts=None):
            return {'fact1': 'a'}

    fact_collector = AnsibleFactCollector(collectors=[FakeFactCollector()],
                                          namespace=None,
                                          filter_spec=None)
    fact_collector_result = fact_collector.collect()
    assert fact_collector_result == {'fact1': 'a'}

# Generated at 2022-06-22 22:42:25.808297
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    #Arrange
    collector_classes = []
    gather_subset = ["all"]
    module_setup = True
    expected_result = {
        'gather_subset': ['all'],
        'module_setup': True
    }
    test_collector = CollectorMetaDataCollector(collector_classes, None, gather_subset, module_setup)

    #Act
    actual_result = test_collector.collect()

    #Assert
    assert expected_result == actual_result


test_CollectorMetaDataCollector_collect()

# Generated at 2022-06-22 22:42:30.604865
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils.facts.collectors.distro
    distro = ansible.module_utils.facts.collectors.distro.DistroFactCollector()
    meta_collector = CollectorMetaDataCollector(distro)
    meta_facts = meta_collector.collect()
    assert 'gather_subset' in meta_facts
    assert 'module_setup' in meta_facts

# Generated at 2022-06-22 22:42:42.743277
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.omit
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.default
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.platform

    # test_AnsibleFactCollector_collect
    # test_AnsibleFactCollector_collect_default_collectors
    # test_AnsibleFactCollector_collect_fact_filtering
    # test_AnsibleFactCollector_collect_invalid_filter_spec
    # test_AnsibleFactCollector_collect_namespace_with_ansible_prefix
    # test_AnsibleFactCollector_collect_names

# Generated at 2022-06-22 22:42:53.539736
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-22 22:42:58.078158
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    try:
        fact_collector = get_ansible_collector([])
    except Exception as e:
        sys.stderr.write(repr(e))
        sys.stderr.write('\n')
        raise