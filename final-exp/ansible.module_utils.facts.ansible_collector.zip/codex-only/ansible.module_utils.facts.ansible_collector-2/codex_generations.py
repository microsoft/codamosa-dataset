

# Generated at 2022-06-22 22:32:59.470831
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector(namespace='ansible_test').name == 'gather_subset'


# Generated at 2022-06-22 22:33:02.762940
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collect_obj = CollectorMetaDataCollector(collected_facts=None)
    collect_obj.collect()
    if collect_obj.collect() != collect_obj.meta_facts:
        print("collect() method of CollectorMetaDataCollector isn't working")


# Generated at 2022-06-22 22:33:03.308254
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-22 22:33:13.366930
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Case 1:
    #     collector_class_list = ['collector_sytem', 'collector_hardware', 'collector_network']
    #     gather_subset = ['all']
    #     gather_timeout = 10
    #     expected = {'gather_subset': gather_subset, 'gather_timeout': gather_timeout}
    #     actual = collector_meta_data_collector.collect()
    #     assert actual == expected

    collector_classes = ['collector_sytem', 'collector_hardware', 'collector_network']
    gather_subset = ['all']
    gather_timeout = 10
    expected = {'gather_subset': gather_subset, 'gather_timeout': gather_timeout}
    actual = collector_meta_data_collector.collect()
    assert actual

# Generated at 2022-06-22 22:33:17.184521
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=['network'], module_setup=True)
    assert fact_collector._fact_ids == set(['gather_subset', 'module_setup'])



# Generated at 2022-06-22 22:33:22.104466
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector = CollectorMetaDataCollector(gather_subset = ['all'], module_setup=True)
    facts = collector.collect()
    assert 'gather_subset' in facts
    assert facts['gather_subset'] == ['all']
    assert 'module_setup' in facts
    assert facts['module_setup'] is True


# Generated at 2022-06-22 22:33:30.414023
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collectors

    gather_subset = ['all', 'network']

    # sanity check that the set of collector found by collector_classes_from_gather_subset
    # matches the set of collectors that would be found by get_ansible_collector()
    all_collector_classes = \
        collector.collector_classes_from_gather_subset(ansible.module_utils.facts.collectors.all_collectors,
                                                       set(),
                                                       gather_subset,
                                                       timeout.DEFAULT_GATHER_TIMEOUT)


# Generated at 2022-06-22 22:33:34.403253
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=["all"])
    facts = collector_meta_data_collector.collect(module=None)
    assert facts['gather_subset'] == ["all"]



# Generated at 2022-06-22 22:33:46.934724
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FactCollector1(collector.BaseFactCollector):
        name = 'fact_collector_1'
        _fact_ids = set(['fact_coll_1_1', 'fact_coll_1_2'])

        def collect(self, module=None, collected_facts=None):
            return {'fact_coll_1_1': 'fact_coll_1_1_value',
                    'fact_coll_1_2': 'fact_coll_1_2_value'}

    class FactCollector2(collector.BaseFactCollector):
        name = 'fact_collector_2'
        _fact_ids = set(['fact_coll_2_1', 'fact_coll_2_2'])


# Generated at 2022-06-22 22:33:47.885505
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass


# Generated at 2022-06-22 22:33:55.621544
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import unittest
    import ansible
    import sys
    import os

    # Test the following:
    # 1. Test that the metadata collector includes the gather subset in the
    #    facts output.
    # 2. Test that the metadata collector includes the module_setup fact in the
    #    facts output.
    # 3. Test that the metadata collector doesn't include module_setup if it
    #    is False.

    class TestCollectorMetaDataCollector(unittest.TestCase):

        def test_gather_subset(self):

            # Test that the metadata collector includes the gather subset in the
            # facts output.

            fact_collector = \
                CollectorMetaDataCollector(gather_subset=['all'])

            facts = fact_collector.collect()

# Generated at 2022-06-22 22:33:59.370657
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    collector_meta_data_collector.collect()

# Generated at 2022-06-22 22:34:06.514419
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Note: This constructor iws used by the setup module, so don't change the signature

    filter_list = ['base', '*']
    filter_list = filter_list or []

    fact_collector = AnsibleFactCollector(filter_spec=filter_list)
    assert fact_collector
    assert filter_list == fact_collector.filter_spec
    assert not fact_collector.collectors


# Generated at 2022-06-22 22:34:14.621428
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_ = collector.BaseFactCollector()
    gather_subset = ['all']

    fact_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=True)
    facts = fact_collector.collect(module='', collected_facts=collector_)
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] == True

# Unit tests for method collect of class AnsibleFactCollector

# Generated at 2022-06-22 22:34:17.639263
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():  # noqa
    collectors = []
    namespace = 'ansible'
    gather_subset = ['min']
    module_setup = True
    CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)

# Generated at 2022-06-22 22:34:20.743913
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector = get_ansible_collector(all_collector_classes=[]).collect()
    expected = {'ansible_facts': {'gather_subset': ['all'], 'module_setup': True}}
    assert collector == expected

# Generated at 2022-06-22 22:34:31.515705
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.system

    # Create a mock class to use as a collector. This collector will be named 'foo' and will
    # have a single fact named 'a' with value '1'
    class FakeCollector(collector.BaseFactCollector):
        name = 'foo'
        _fact_ids = set(['a'])

        def collect(self, module=None, collected_facts=None):
            info_dict = {'a': '1'}
            return info_dict

    # Create a mock class to use as a collector. This collector will be named 'foo' and will
    # have a single fact named 'a' with value '1'
    class EmptyCollector(collector.BaseFactCollector):
        name = 'empty'

# Generated at 2022-06-22 22:34:36.418434
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    # Call the constructor
    fact_collector = \
        CollectorMetaDataCollector(gather_subset='all',
                                   module_setup='True')

    # Check the result
    assert fact_collector is not None
    assert fact_collector.gather_subset == 'all'
    assert fact_collector.module_setup is True

# Generated at 2022-06-22 22:34:45.791439
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # test_create_AnsibleFactCollector_without_collectors
    fact_collector = AnsibleFactCollector()

    if fact_collector.namespace is not None:
        raise AssertionError('Test for test_create_AnsibleFactCollector_without_namespace failed')

    # test_create_AnsibleFactCollector_with_collectors
    collectors = collector.BaseFactCollector.get_collector_classes()
    fact_collector = AnsibleFactCollector(collectors=collectors)

    if fact_collector.namespace is not None:
        raise AssertionError('Test for test_create_AnsibleFactCollector_with_collectors failed')

# Generated at 2022-06-22 22:34:56.045681
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    Gather_Subset = ['network', 'all']
    Minimal_Gather_Subset = ['network', 'all']
    Gather_Timeout = 10
    Module_Setup = True

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=Gather_Subset,
                                   module_setup=Module_Setup)
    collector_obj = collector_meta_data_collector.collect()

    assert collector_obj['gather_subset'] == Gather_Subset
    assert collector_obj['module_setup'] == Module_Setup


# Generated at 2022-06-22 22:34:59.968143
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default
    assert get_ansible_collector(all_collector_classes=default.ALL_COLLECTORS)

# pylint: disable=redefined-outer-name

# Generated at 2022-06-22 22:35:00.868369
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    pass

# Generated at 2022-06-22 22:35:10.336648
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    gather_subset = ['!all', 'network', 'ohai', 'hardware', 'virtual', 'facter']
    gather_subset = ':'.join(gather_subset)
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=gather_subset.split(':'))

    collected_facts = fact_collector.collect()
    assert(collected_facts['gather_subset'] == ['network', 'ohai', 'hardware', 'virtual', 'facter'])
    assert(collected_facts['module_setup'] == True)

    # the 'gather_subset' fact should not be collected otherwise

# Generated at 2022-06-22 22:35:15.789903
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    expected = {'gather_subset': ['all'], 'module_setup': True}
    test_collector = CollectorMetaDataCollector('all', 'test_namespace', True)
    assert test_collector.collect() == expected


if __name__ == '__main__':
    # Unit tests for collect and from_gather_subset methods of class AnsibleFactCollector
    test_collectors = [collector.BaseFactCollector(), collector.FacterFactCollector()]
    test_collector = AnsibleFactCollector(test_collectors, 'test_namespace')
    test_filter_spec = ['test_fact']


# Generated at 2022-06-22 22:35:27.660421
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    def _test(exp_filter_spec, exp_collectors):
        collector = AnsibleFactCollector(filter_spec=filter_spec, collectors=collectors)
        assert collector.filter_spec == exp_filter_spec
        assert collector.collectors == exp_collectors

    exp_collectors = []
    exp_filter_spec = []
    filter_spec = []
    collectors = None
    _test(exp_filter_spec, exp_collectors)

    exp_collectors = []
    exp_filter_spec = ['*']
    filter_spec = ''
    collectors = None
    _test(exp_filter_spec, exp_collectors)

    exp_collectors = [1, 2]
    exp_filter_spec = []
    filter_spec = None
    collectors = [1, 2]

# Generated at 2022-06-22 22:35:31.782313
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['min', '!foo'])
    facts = fact_collector.collect()

    assert facts["gather_subset"] == ['min', '!foo']
    assert facts["module_setup"] is True

# Generated at 2022-06-22 22:35:35.348993
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector('test_collectors', 'test_namespace')
    assert c.__class__.__name__ == 'CollectorMetaDataCollector'


# Generated at 2022-06-22 22:35:38.867057
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    try:
        fact_collector = AnsibleFactCollector()
        assert fact_collector.fact_ids == ()
    except:
        print("test_AnsibleFactCollector failed")
        raise

# Generated at 2022-06-22 22:35:47.175594
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import NumFactsCollector, DummyCollector

    test_collector_classes = [NumFactsCollector, DummyCollector]
    test_collectors = [test_collector_classes[0](), test_collector_classes[1]()]

    fact_collector = AnsibleFactCollector(collectors=test_collectors, namespace=PrefixFactNamespace(prefix='test_'))

    facts = fact_collector.collect()
    assert len(facts) == 5

    assert facts['test_num_facts_dict'] == {'a': 1, 'b': 2, 'c': 3}

    assert facts['test_test_fact'] == 'test_fact'

# Generated at 2022-06-22 22:35:55.922534
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # CollectorMetaDataCollector requires two arguments: gather_subset, module_setup
    # Here module_setup is set to True
    assertion_msg = 'Collector module_setup is not True'
    test_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                          module_setup=True)
    assert test_obj.module_setup == True, assertion_msg

    # Here module_setup is set to False
    assertion_msg = 'Collector module_setup is not False'
    test_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                          module_setup=False)
    assert test_obj.module_setup == False, assertion_msg

    # Here module_setup is set to None
    assertion_msg = 'Collector module_setup is not None'
    test

# Generated at 2022-06-22 22:36:00.442709
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_class = CollectorMetaDataCollector
    collector_meta_data_collector = collector_class(gather_subset='test')
    assert collector_meta_data_collector.gather_subset == 'test'



# Generated at 2022-06-22 22:36:06.890525
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # setup
    import ansible.module_utils.facts.ansible_collector as ans_coll
    import ansible.module_utils.facts.collectors.base as base_coll
    import ansible.module_utils.facts.collectors.network as net_coll

    test_obj = ans_coll.AnsibleFactCollector()
    test_obj.collectors = [base_coll.BaseFactCollector(),
                           ans_coll.CollectorMetaDataCollector(),
                           net_coll.NetworkCollector()]
    test_obj.namespace = None

    # test
    test_obj.collect()

    # teardown
    pass

# Generated at 2022-06-22 22:36:12.357181
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=True, module_setup=True)
    assert collector_meta_data_collector.gather_subset
    assert collector_meta_data_collector.module_setup

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=False, module_setup=False)
    assert not collector_meta_data_collector.gather_subset
    assert not collector_meta_data_collector.module_setup

# Generated at 2022-06-22 22:36:16.763931
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=['!all', 'min'],
                                   module_setup=None)
    meta_facts = c.collect()
    assert meta_facts['gather_subset'] == ['!all', 'min']

# Generated at 2022-06-22 22:36:22.708523
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.collector_classes_from_gather_subset(gather_subset=None)
    ansible_collector = get_ansible_collector(all_collector_classes)
    # TODO assert something about ansible_fact_collector

# Generated at 2022-06-22 22:36:30.951089
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ''' Test collect metafacts. '''
    # Facts
    facts = {}
    meta_facts = {'gather_subset': ['all'], 'module_setup': True}

    # Instanciate a metadata collector
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])

    # Test collect metafacts
    result = collector_meta_data_collector.collect(collected_facts=facts)

    # Test the result
    assert result == meta_facts


# Generated at 2022-06-22 22:36:43.310751
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import platform
    # Create a collector with a fake method collect
    class MapFactCollector(collector.BaseFactCollector):
        name = 'map'

        def __init__(self, *args, **kwargs):
            super(MapFactCollector, self).__init__(*args, **kwargs)

        def collect(self, module=None, collected_facts=None):
            return {'map': 'rocks'}

    # Create a collector with a fake method collect that depends on the MapFactCollector
    class MapFactDependentCollector(collector.BaseFactCollector):
        name = 'dependent'

        def __init__(self, *args, **kwargs):
            super(MapFactDependentCollector, self).__init__(*args, **kwargs)


# Generated at 2022-06-22 22:36:49.493912
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == False
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all']}

# Generated at 2022-06-22 22:36:54.185643
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Unit test for constructor of class AnsibleFactCollector.'''
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    hardware_collector = HardwareCollector(namespace=PrefixFactNamespace(prefix='ansible_'))
    ansible_fact_collector = AnsibleFactCollector(collectors=[hardware_collector],
                                                  filter_spec=[],
                                                  namespace=PrefixFactNamespace(prefix='ansible_'))
    assert ansible_fact_collector.filter_spec is not None
    assert ansible_fact_collector.collectors[0] == hardware_collector
    assert ansible_fact_collector.namespace.prefix == 'ansible_'

# Generated at 2022-06-22 22:37:07.479621
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector

    def assert_collect_result(collector_obj, expected):
        actual = collector_obj.collect(module=None, collected_facts=None)
        assert actual == expected

    # test gather_subset=None
    assert_collect_result(get_ansible_collector(all_collector_classes=ansible.module_utils.facts.collector.FACT_COLLECTORS),
                          {'gather_subset': ['all'], 'module_setup': True})

    # test gather_subset=[]

# Generated at 2022-06-22 22:37:19.031318
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO: better sample set of facts
    import ansible.module_utils.facts.system.base as base

    # TODO: Get rid of the local function that partially mimics module_utils.facts functions,
    # so that it can be exported.
    def get_all_collector_classes():
        return dict(base.collector_classes)

    # TODO: get rid of this sort of hardcoded test, or formalize a way for facts to specify
    # a list of dependencies.
    def get_filter_spec():
        return ['ansible_*']

    fact_collector = get_ansible_collector(all_collector_classes=get_all_collector_classes(),
                                           filter_spec=get_filter_spec())
    # We'd really prefer to not use the _collect() function.
    result

# Generated at 2022-06-22 22:37:23.894894
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=[])
    assert collector_meta_data_collector.gather_subset == []
    assert collector_meta_data_collector.module_setup is None
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=[], module_setup=True)
    assert collector_meta_data_collector.gather_subset == []
    assert collector_meta_data_collector.module_setup is True


# Generated at 2022-06-22 22:37:36.423267
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collectors.base
    # This is a set of all possible collectors
    all_collector_classes = set(ansible.module_utils.facts.collectors.base.collector_classes())

    from ansible.module_utils.facts import namespace
    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert fact_collector is not None
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(all_collector_classes)


# Generated at 2022-06-22 22:37:38.450134
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO: write unit test for AnsibleFactCollector.collect()
    return None


# Generated at 2022-06-22 22:37:49.166985
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.local
    import ansible.module_utils.facts.collector.virt
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr


# Generated at 2022-06-22 22:38:01.416041
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts.namespace import BaseFactNamespace

    class FactCollector1(collector.BaseFactCollector):
        name = 'test_facter1'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_facter1': '1'}

    class FactCollector2(collector.BaseFactCollector):
        name = 'test_facter2'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_facter2': '2'}

    class TestNamespace(BaseFactNamespace):
        name = 'test_namespace'
        prefix = 'test_'

    # Single namespace provided to constructor
    test_names

# Generated at 2022-06-22 22:38:06.297601
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # generate collector and assert it has the right values set
    collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)

    assert collector.gather_subset == 'all'
    assert collector.module_setup == True

# Generated at 2022-06-22 22:38:13.003864
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import generic
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import collector_utils

    all_collector_classes = [
        system.SystemCollector,
        generic.LinuxGenericCollector,
        distribution.LinuxDistributionCollector,
        hardware.HardwareCollector,
        network.NetworkCollector,
        virtual.VirtualCollector
    ]

    fact_collector = get_ansible_collector(all_collector_classes = all_collector_classes)
    assert fact_collector

# Generated at 2022-06-22 22:38:25.358749
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Need to import this for unit test
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.all import AllCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    all_collector_classes = [AllCollector, NetworkCollector, HardwareCollector, VirtualCollector]

    # Test full gather subset with minimal subset
    gather_subset = ['network', 'all', 'hardware', 'virtual', 'min']
    minimal_gather_subset = frozenset(['network'])


# Generated at 2022-06-22 22:38:31.260820
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fc1 = collector.BaseFactCollector(collectors=['foo'])
    fc2 = collector.BaseFactCollector(collectors=['bar'])
    afc = AnsibleFactCollector(collectors=[fc1, fc2], filter_spec='f*')
    assert afc.collectors == [fc1, fc2]
    assert afc.filter_spec == ['f*']


# Generated at 2022-06-22 22:38:41.041388
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Example of all_collector_classes
    all_collector_classes = [collector.NetworkInterfacesCollector,
                             collector.SomeOtherCollector]

    namespace = collector.Namespace()
    filter_spec = '*'
    gather_subset = ['all']
    gather_timeout = 60
    minimal_gather_subset = frozenset()
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)

    # Example of FactCollector
    #   namespace=

# Generated at 2022-06-22 22:38:44.000738
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = get_ansible_collector(collector.FACT_COLLECTOR_CLASSES)
    assert(isinstance(fact_collector, AnsibleFactCollector))

# Generated at 2022-06-22 22:38:52.854984
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_obj = CollectorMetaDataCollector(gather_subset=['!all'], module_setup=True)

    result = test_obj.collect()
    assert result['gather_subset'] == ['!all']
    assert result['module_setup'] == True
    assert len(result) == 2

    result = test_obj.collect(module_setup=False)
    assert result['module_setup'] == False
    assert len(result) == 1

    result = test_obj.collect(gather_subset=['all'])
    assert result['gather_subset'] == ['all']
    assert len(result) == 1



# Generated at 2022-06-22 22:39:00.764298
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts.salt import SaltFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils.facts.puppet import PuppetFactCollector
    from ansible.module_utils.facts.zabbix import ZabbixFactCollector

    facts_collector_classes = (ansible_collector.AnsibleFactCollector,
                               SystemFactCollector,
                               SaltFactCollector,
                               OhaiFactCollector,
                               ZabbixFactCollector,
                               PuppetFactCollector)

    # create collector objects

# Generated at 2022-06-22 22:39:10.814123
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    collection = CollectorMetaDataCollector(namespace=PrefixFactNamespace())
    result = collection.collect()
    assert result == {}

    collection = CollectorMetaDataCollector(gather_subset=['all'], namespace=PrefixFactNamespace())
    result = collection.collect()
    assert result == {'ansible_gather_subset': ['all']}

    collection = CollectorMetaDataCollector(gather_subset=['!all'], namespace=PrefixFactNamespace())
    result = collection.collect()
    assert result == {'ansible_gather_subset': ['!all']}


# Generated at 2022-06-22 22:39:16.641532
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # if this test does not fail, this is enough for now
    get_ansible_collector(all_collector_classes=collector.FACT_COLLECTORS,
                          namespace=None,
                          filter_spec=None,
                          gather_subset=None,
                          gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT)

# Generated at 2022-06-22 22:39:25.091230
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # When no gather_subset is provided
    collector_meta_data_collector = CollectorMetaDataCollector()
    assert not collector_meta_data_collector.gather_subset
    assert collector_meta_data_collector.name == 'gather_subset'

    # When gather_subset is provided
    gather_subset = ['all']
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
    assert collector_meta_data_collector.gather_subset == gather_subset

# Generated at 2022-06-22 22:39:32.598482
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import time

    class BaseTestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'TRUE_FACT': True}

    class TimeTestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'TIME_FACT': time.time()}

    a = AnsibleFactCollector(collectors=[BaseTestCollector(), TimeTestCollector()])
    results = a.collect()

    assert len(results) == 2
    assert results['TRUE_FACT']
    assert 'TIME_FACT' in results

# Generated at 2022-06-22 22:39:37.459609
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_data_collector_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                                         module_setup=True)
    meta_data_collector_obj.collect()
    assert meta_data_collector_obj.gather_subset == ['all']
    assert meta_data_collector_obj.module_setup == True

# Generated at 2022-06-22 22:39:49.856030
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts.ns_prefix import PrefixFactNamespace

    class FakeCollector:

        # fake collector that returns a subset of the facts with
        # ids of the form "fake[0-9]_<name>"
        def __init__(self, namespace=None):
            self.namespace = namespace
            self._fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            f = {}
            for i in range(10):
                f['fake%d_a' % i] = '%d' % i
                f['fake%d_c' % i] = '%d' % i
            return f

    class FakeFacts:
        def __init__(self):
            self.namespace

# Generated at 2022-06-22 22:39:56.500974
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    result = get_ansible_collector(all_collector_classes=[],
                                   namespace=None,
                                   filter_spec=None,
                                   gather_subset=[],
                                   gather_timeout=None,
                                   minimal_gather_subset=None)
    assert result.__class__.__name__ == 'AnsibleFactCollector'

# Generated at 2022-06-22 22:40:00.279435
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Test AnsibleFactCollector constructor.'''

    fact_collector = \
        AnsibleFactCollector(collectors=[],
                             filter_spec=None,
                             namespace=None)

    if not isinstance(fact_collector, AnsibleFactCollector):
        print(type(fact_collector))
        print('is not instance of AnsibleFactCollector')
        raise Exception()

# Generated at 2022-06-22 22:40:06.463510
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup is True
    assert collector_meta_data_collector.collectors is None

# Generated at 2022-06-22 22:40:11.248701
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ansible_fact_collector = \
        AnsibleFactCollector(collectors=[],
                             filter_spec=None,
                             namespace=None)
    assert ansible_fact_collector
    assert ansible_fact_collector.namespace is None
    assert ansible_fact_collector.collectors == []
    assert ansible_fact_collector.filter_spec == []

# Generated at 2022-06-22 22:40:19.349056
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Build a mock for a real Ansible module
    class MockBase:
        class AnsibleModule(object):
            def __init__(self, arg_spec, **kwargs):
                self.params = kwargs
                self.argument_spec = arg_spec
                self.exit_json = exit_json

        def __init__(self, arg_spec, **kwargs):
            pass

    class MockFactsModule(MockBase):
        def __init__(self, arg_spec, **kwargs):
            super(MockFactsModule, self).__init__(arg_spec, **kwargs)
            self.module = self.AnsibleModule(arg_spec, **kwargs)

    def exit_json(self, **kwargs):
        self.exit_json_called = True
        self.json_kw

# Generated at 2022-06-22 22:40:28.301918
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # This is a list of Collector classes that are to be used to gather facts.
    # This is filtered by the gather_subset specifier and passed to the AnsibleFactCollector.
    # It is filled by the various fact plugins by calling collector_classes_from_gather_subset()
    # with the list of Collector classes they provide.
    # The Collector classes are listed in order of priority. That is, what they
    # provide will be in the facts first.
    all_collector_classes = []

    # This is a list of collector names that will be filtered by get_ansible_collector()
    # and used to construct the Collector classes that are intialized and used to gather facts.
    # This corresponds to the -f

# Generated at 2022-06-22 22:40:29.871351
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert(AnsibleFactCollector())


# Generated at 2022-06-22 22:40:40.398073
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()

    mock_collectors = [
        {'c1': {'f1': 'val1', 'f2': 'val2'}},
        {'c2': {'f3': 'val3', 'f4': 'val4'}},
        {'c3': {'f5': 'val5', 'f6': 'val6'}},
    ]
    results = \
        fact_collector.collect(collectors=mock_collectors,
                               collected_facts={'i': 'inherited'})

# Generated at 2022-06-22 22:40:47.667263
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts.collector.system import SysInfoCollector
    collect_subset = ['all']
    filterspec = []
    module_setup = True
    fact_collectors = get_ansible_collector([SysInfoCollector],
                                            gather_subset=collect_subset,
                                            filter_spec=filterspec,
                                            namespace=namespaces.PrefixFactNamespace(prefix='ansible_'))
    facts_dict = fact_collectors.collect()
    assert facts_dict['ansible_facts']['gather_subset'] == collect_subset
    assert facts_dict['ansible_facts']['module_setup'] == module_setup

# Generated at 2022-06-22 22:40:52.350774
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for AnsibleFactCollector.collect()'''
    from ansible.module_utils.facts import namespaced_facts

    class FakeCollectorA(collector.BaseFactCollector):
        name = 'fake_a'
        _fact_ids = set(['a', 'b'])

        def collect(self, module=None, collected_facts=None):
            return {'a': 'a', 'b': 'b'}

    class FakeCollectorB(collector.BaseFactCollector):
        name = 'fake_b'
        _fact_ids = set(['c', 'd'])

        def collect(self, module=None, collected_facts=None):
            return {'c': 'c', 'd': 'd'}


# Generated at 2022-06-22 22:40:58.555718
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'x': 'y'}

    collector = AnsibleFactCollector([TestCollector()])
    facts = collector.collect()
    assert facts == {'ansible_facts': {'x': 'y'}}


# Generated at 2022-06-22 22:41:08.485293
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import processors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(collector.BaseFactCollector):

        name = 'testcollector1'
        _fact_ids = set([])

        def __init__(self, namespace=None):
            super(TestCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            # This 'facts' dict will be saved as a value of the outer dict
            # under key 'testcollector1'
            return {
                'some_fact': 'some_value',
                'some_other_fact': 'some_other_value'
            }

    class TestProcessor(processors.BaseFactProcessor):

        name

# Generated at 2022-06-22 22:41:16.990982
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit test for function get_ansible_collector'''
    fact_collector = get_ansible_collector(namespace=None,
                                           filter_spec=[],
                                           gather_subset=['all'],
                                           gather_timeout=None,
                                           minimal_gather_subset=frozenset())

    facts = fact_collector.collect()

    # NOTE: this test is a good sanity check, but we should really be using the
    # fact_collector in a unit test to get facts, not just the fact_collector
    # itself.
    #
    # We need to test that the fact_collector is calling the right collectors
    # for the given gather_subset.
    #
    # We should also test that the fact_collector is calling the collectors in
    #

# Generated at 2022-06-22 22:41:20.805193
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    cmc = CollectorMetaDataCollector(gather_subset = ['all'])
    facts = cmc.collect()

    assert facts['gather_subset'] == ['all']
    assert facts.get('module_setup')

# Generated at 2022-06-22 22:41:31.157170
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    valid_supported_subsets = [
        {'all'}, {'ansible_local'}, {'network', 'cache'},
        {'network', 'all'}, {'all', 'network', 'cache'},
        {'ansible_local', 'network', 'cache'},
        {'ansible_local', 'network', 'cache', 'all'}
    ]

    # Test all combinations of valid gather_subset and module_setup
    for valid_gather_subset in valid_supported_subsets:
        for module_setup in [True, False]:
            CollectorMetaDataCollector(gather_subset=valid_gather_subset,
                                       module_setup=module_setup)

        # Test an invalid gather_subset
        invalid_gather_subset = {'invalid_value'}


# Generated at 2022-06-22 22:41:43.088643
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import timeout

    def mock_collect(self, *args, **kwargs):
        # mock method collect() of class BaseFactCollector to return the local variables
        # in the function
        fact_names = [k for k, v in locals().items() if v not in
                      ['self', 'args', 'kwargs', 'fact_names', 'facts_dict']]
        fact_names.sort()
        facts_dict = {k: None for k in fact_names}
        return facts_dict

    collector.BaseFactCollector.collect = mock_collect

    assert(sys.version_info[0] >= 3)  # assert Python 3.x
    assert(sys.version_info[1] >= 5)  # assert Python 3.5+


# Generated at 2022-06-22 22:41:50.372972
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_classes = []
    all_collector_classes = collector.collector_classes_from_gather_subset(collector_classes)

    #(gather_subset, gather_timeout, expected_meta_facts)

# Generated at 2022-06-22 22:41:55.303974
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collect_obj = CollectorMetaDataCollector(collectors=None, namespace=None, gather_subset='all', module_setup=True)
    assert collect_obj.collect() == {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-22 22:41:57.797294
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_obj = \
        AnsibleFactCollector(collectors=[],
                             filter_spec=[])
    assert collector_obj is not None

# Generated at 2022-06-22 22:42:06.817486
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''
    Tests the collect method of class AnsibleFactCollector.
    '''

    # Mock the class `ModuleUtil` so we can use its objects
    # in the test
    class MockClass(object):
        def __init__(self):
            self.NAME = 'MockClass'

    mock_class_obj = MockClass()

    fact_collector_ns = AnsibleFactCollector(collectors=mock_class_obj)
    fact_collector = AnsibleFactCollector()
    ansible_facts = fact_collector.collect(mock_class_obj)
    ansible_facts_with_namespace = fact_collector_ns.collect(mock_class_obj)

    assert ansible_facts == ansible_facts_with_namespace



# Generated at 2022-06-22 22:42:11.195103
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    class TestFacts(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test'}

    all_fact_classes = [TestFacts]

    fact_collector = get_ansible_collector(all_fact_classes)

    module = None
    collected_facts = None

    facts = fact_collector.collect(module=module,
                                   collected_facts=collected_facts)

    assert facts == {'ansible_facts': {'test_fact': 'test',
                                       'gather_subset': ['all'],
                                       'module_setup': True}}



# Generated at 2022-06-22 22:42:14.740588
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    fc = get_ansible_collector([ansible_collector.AnsibleCollector])

    # TODO: more tests

# Generated at 2022-06-22 22:42:27.110636
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    class TestCollector(collector.BaseFactCollector):
        name = "test"

        def collect(self, module=None, collected_facts=None):
            return {self._namespace('test_fact'): True}

    fact_collector = \
        AnsibleFactCollector(collectors=[TestCollector()],
                             filter_spec="*")

    assert fact_collector._filter({'ansible_test_fact': True}, "*") == [('ansible_test_fact', True)]
    assert fact_collector._filter({'ansible_test_fact': True}, "ansible_*") == [('ansible_test_fact', True)]
    assert fact_collector._filter({'ansible_test_fact': True}, "test_fact") == [('ansible_test_fact', True)]
   

# Generated at 2022-06-22 22:42:30.912625
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)

    actual = collector_meta_data_collector.collect()
    expected = {'gather_subset': ['all'], 'module_setup': True}

    assert actual == expected

# Generated at 2022-06-22 22:42:42.818551
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import get_local_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import utils

    fact_collector = \
        AnsibleFactCollector(collectors=(get_local_facts,),
                             filter_spec=['ansible_eth*', 'facter_ipaddress_*'],
                             namespace=PrefixFactNamespace(prefix='ansible_'))

    # test fact namespaces
    facts_dict = fact_collector.collect()

    assert 'ansible_eth0' in facts_dict
    assert 'ansible_eth1' in facts_dict
    assert 'ansible_ipaddress_eth0' in facts_dict

# Generated at 2022-06-22 22:42:47.683998
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['!all'],
                                                               module_setup=False)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['!all'],
                                                       'module_setup': False}

# Generated at 2022-06-22 22:42:58.164961
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts.system import System
    from ansible.module_utils.facts.network import Network
    from ansible.module_utils.facts.module_setup import ModuleSetup
    from ansible.module_utils.facts.gather_subset import GatherSubset
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.facter import Facter

    hardware = Hardware()
    system = System()
    network = Network()
    module_setup = ModuleSetup()
    gather_subset = GatherSubset()
    virtual = Virtual()
    facter = Facter()
