

# Generated at 2022-06-22 22:33:11.859660
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = []
    facts_collector = CollectorMetaDataCollector(
        gather_subset=['all'], module_setup=True)
    collectors.append(facts_collector)
    assert collectors[0].gather_subset == ['all']
    assert collectors[0].module_setup == True
    assert collectors[0].ns_prefix == 'gather_subset'
    assert collectors[0]._fact_ids == None
    assert collectors[0].name == 'gather_subset'
    assert collectors[0].ns_list == ['gather_subset']
    assert collectors[0].ns_prefix == 'gather_subset'
    assert collectors[0].namespace == None
    assert collectors[0].options == None
    assert collectors[0].timeout == None
    assert collectors[0].collectors == None


# Generated at 2022-06-22 22:33:15.233085
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collectors = ['fake-collector']
    fact_collector = \
        AnsibleFactCollector(collectors=collectors)
    assert fact_collector.collectors == collectors, (fact_collector.collectors,
                                                     collectors)



# Generated at 2022-06-22 22:33:24.407746
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # pylint: disable=unused-argument

    # Note: module is not used here.

    fact_collector_meta_data_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                                              module_setup=True)

    # When:
    meta_facts = fact_collector_meta_data_obj.collect(module=None,
                                                      collected_facts=None)

    # Then:
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}


if __name__ == '__main__':
    # pylint: disable=no-value-for-parameter
    test_CollectorMetaDataCollector_collect()

# Generated at 2022-06-22 22:33:29.464866
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    class Collector(object):
        def collect_with_namespace(self, module, collected_facts):
            return {'domain': 'localhost'}

    collector = CollectorMetaDataCollector(collectors=[Collector()],
                                           gather_subset=['network'])
    result = collector.collect()
    assert result.keys() == ['domain', 'gather_subset']
    assert result['gather_subset'] == ['network']
    assert result['domain'] == 'localhost'

# Generated at 2022-06-22 22:33:39.874215
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    ns = collector.BaseFactNamespace()
    cmc = CollectorMetaDataCollector(namespace=ns)

    # verify that the class/function name is returned
    meta_facts = cmc.collect()
    assert meta_facts['gather_subset'] == ['all']

    # verify that we use the supplied gather_subset
    subset = set(['one', 'two'])
    cmc = CollectorMetaDataCollector(namespace=ns, gather_subset=subset)
    meta_facts = cmc.collect()
    assert meta_facts['gather_subset'] == ['one', 'two']

    # verify that we use the supplied module_setup
    cmc = CollectorMetaDataCollector(namespace=ns, module_setup=False)
    meta_facts = cmc.collect()

# Generated at 2022-06-22 22:33:50.426316
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    mock_info_dict = {
        'hello': 'world',
    }

    class MockCollector(collector.BaseFactCollector):
        def collect_with_namespace(self, module):
            return mock_info_dict.copy()

    # Test as if all facts are collected
    fact_collector = \
        AnsibleFactCollector(collectors=[MockCollector()])
    collected_facts = \
        fact_collector.collect()
    assert collected_facts == mock_info_dict

    # Test as if all facts are collected, with namespace
    namespace = collector.namespace.PrefixFactNamespace('ansible_')
    fact_collector = \
        AnsibleFactCollector(collectors=[MockCollector(namespace=namespace)])

# Generated at 2022-06-22 22:33:56.499250
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import CommandLineCollector

    namespace = PrefixFactNamespace(prefix='ansible_')
    collector = CommandLineCollector(namespace=namespace)
    fact_collector = \
        AnsibleFactCollector(collectors=[collector],
                             namespace=namespace)

    facts_dict = fact_collector.collect()
    assert facts_dict.get('ansible_python_version') == sys.version_info


# Generated at 2022-06-22 22:34:06.691248
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''Unit test for constructor of class CollectorMetaDataCollector'''
    fact_collector = CollectorMetaDataCollector(gather_subset='all',
                                                module_setup=True)
    assert fact_collector is not None
    assert fact_collector.name == 'gather_subset'
    assert fact_collector._fact_ids == set([])
    assert fact_collector.gather_subset == 'all'
    assert fact_collector.module_setup

    try:
        fact_collector.collect()
    except NotImplementedError:
        print('Invalid operation!')



# Generated at 2022-06-22 22:34:17.950997
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    all_collector_classes = collector.get_collector_class_list()
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespace,
                                           filter_spec=filter_spec,
                                           gather_subset=gather_subset,
                                           gather_timeout=gather_timeout,
                                           minimal_gather_subset=minimal_gather_subset)
    # Check if facts are present
    if not fact_collector:
        raise AssertionError("fact_collector is empty.")

    # Check if only permitted collector classes are present

# Generated at 2022-06-22 22:34:23.405418
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True



# Generated at 2022-06-22 22:34:34.419792
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # no gather_subset, no module setup
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=None,
                                                               module_setup=None)
    fact_dict = collector_meta_data_collector.collect()
    assert fact_dict == {}

    # no gather_subset, module setup
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=None,
                                                               module_setup=True)
    fact_dict = collector_meta_data_collector.collect()
    assert fact_dict == {'module_setup': True}

    # gather_subset, no module setup
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all',
                                                               module_setup=None)


# Generated at 2022-06-22 22:34:45.347836
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.user
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector


# Generated at 2022-06-22 22:34:51.755924
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    CollectorMetaDataCollector(gather_subset="all", module_setup=True).collect()
    CollectorMetaDataCollector(gather_subset="min", module_setup=False).collect()
    CollectorMetaDataCollector(gather_subset="!min", module_setup=True).collect()



# Generated at 2022-06-22 22:34:57.877478
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    fact_collector = \
        CollectorMetaDataCollector(collectors=[],
                                   namespace=None,
                                   gather_subset=['all'],
                                   module_setup=True)

    collected_facts = fact_collector.collect(module=None,
                                             collected_facts={})
    assert collected_facts['module_setup'] is True
    assert collected_facts['gather_subset'] == ['all']

# Generated at 2022-06-22 22:35:07.948837
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    all_collector_classes = collector.BaseFactCollector.collector_classes()
    collector_class = list(all_collector_classes[0].values())[0]
    collector_obj = collector_class()
    collector_instances = [collector_obj]
    namespace_obj = collector.FactNamespace()
    filter_spec = []

    test_fact_collector = AnsibleFactCollector(collector_instances,
                                               namespace_obj,
                                               filter_spec)

    assert test_fact_collector.collectors == collector_instances
    assert test_fact_collector.namespace == namespace_obj
    assert test_fact_collector.filter_spec == filter_spec



# Generated at 2022-06-22 22:35:11.590716
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_fact = CollectorMetaDataCollector(gather_subset=['a', 'b'],
                                        module_setup=True)

    assert test_fact.collect() == {'gather_subset': ['a', 'b'], 'module_setup': True}


# Generated at 2022-06-22 22:35:14.391058
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    my_collector = CollectorMetaDataCollector()
    assert my_collector.__class__.__name__ == 'CollectorMetaDataCollector'


# Generated at 2022-06-22 22:35:23.027762
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_obj = collector.FacterCollector()
    fact_collector = AnsibleFactCollector(collectors=[collector_obj])
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert len(facts.keys()) == 1
    assert 'facter' in facts
    assert facts['facter']['os'] not in ['Darwin', 'Linux', 'FreeBSD']

    # Test with a filter
    fact_collector = AnsibleFactCollector(collectors=[collector_obj],
                                          filter_spec='facter.os')
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert len(facts.keys()) == 1
    assert 'ansible_os' in facts

# Generated at 2022-06-22 22:35:33.773586
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import sys
    import re

    # Mock out the module and collected_facts
    class FakeModule(object):
        def __init__(self):
            self.params = dict()

    module = FakeModule()

    # We need to mock out get_file_content() otherwise the collect() function will
    # attempt to read a file of the same name as the dummy collector class, resulting
    # in an error.

    class FakeCollector1(collector.BaseFactCollector):
        name = 'dummy1'
        _fact_ids = set(['dummy1_fact1', 'dummy1_fact2', 'dummy1_fact3'])

        def get_file_content(self, filename):
            return 'dummy1_fact1'


# Generated at 2022-06-22 22:35:42.578965
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import sys
    from ansible.module_utils.facts import namespace

    filter_spec = filter_spec or []
    gather_subset = gather_subset or ['all']

    collectors = sys.modules[__name__].COLLECTORS
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec=filter_spec,
                             namespace=namespace_obj)

    print(fact_collector.collect())

# Unit tests for get_ansible_collector()

# Generated at 2022-06-22 22:35:53.858183
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    try:
        from ansible.module_utils.facts import cache
    except ImportError:
        sys.path.append('../../module_utils')
        from facts import cache

    class TestCollector(object):
        def __init__(self, namespace):
            self.namespace = namespace

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'test_namespace_%s' % self.namespace: 'foo'}

    fact_collector = get_ansible_collector(all_collector_classes=[cache.CacheCollector,
                                                                  TestCollector],
                                           namespace='foo',
                                           gather_subset=['all'])

    results = fact_collector.collect()

    assert isinstance(results, dict)

# Generated at 2022-06-22 22:36:04.474054
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.fact_classes_from_module_spec(
        module_spec='ansible.module_utils.facts.Hardware',
        reload_module=True,
        fail_on_missing=False)
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=None,
                                           filter_spec=[],
                                           gather_subset=['all'],
                                           gather_timeout=None,
                                           minimal_gather_subset=frozenset())
    facts_dict = fact_collector.collect(module=None, collected_facts=None)
    assert 'ansible_all_ipv4_addresses' in facts_dict

# Generated at 2022-06-22 22:36:09.514773
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = get_ansible_collector(['test_test_test'],
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    # This test should not throw an error
    assert fact_collector.name == 'ansible_fact_collector'

# Generated at 2022-06-22 22:36:20.684253
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Collectors
    class CollectorA(collector.BaseFactCollector):
        def collect_with_namespace(self, collected_facts=None, module=None):
            return {'a': 'A'}

    class CollectorAA(collector.BaseFactCollector):
        def collect_with_namespace(self, collected_facts=None, module=None):
            return {'aa': 'AA'}

    class CollectorB(collector.BaseFactCollector):
        def collect_with_namespace(self, collected_facts=None, module=None):
            return {'b': 'B'}

    # Methods to test
    def collect_without_namespace():
        fact_collector = \
            AnsibleFactCollector(collectors=[CollectorA(), CollectorB()])
        return fact_collector.collect()



# Generated at 2022-06-22 22:36:27.980608
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """ Unit Test: test_CollectorMetaDataCollector_collect
    """
    # GIVEN: Test object, gather_subset and module_setup attributes
    test_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                          module_setup=True)

    # WHEN: collect is called
    result = test_obj.collect()

    # THEN: assert that returned dictionary is correct
    assert result == {'gather_subset': ['all'], 'module_setup': True}



# Generated at 2022-06-22 22:36:32.646967
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['hardware'],
                                   module_setup=True)
    collected_facts = collector.collect_from_collector(collector_meta_data_collector,
                                                       module=None)
    assert collected_facts['gather_subset'] == ['hardware']
    assert collected_facts['module_setup'] == True


# Generated at 2022-06-22 22:36:44.872750
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts import network

    # dummy fact collection that returns a dict of { fact: 'value'}.
    class DummyFactCollector(collector.BaseFactCollector):
        name = 'dummy'

        def collect(self, module=None, collected_facts=None):
            return {'fact': 'value'}

    dummy_fact_collector = DummyFactCollector()

    fact_collector = \
        AnsibleFactCollector(collectors=[dummy_fact_collector],
                             namespace=namespaces.PrefixFactNamespace(
                                 prefix='ansible_'))

    facts = fact_collector.collect()


# Generated at 2022-06-22 22:36:54.822585
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # To validate the output of the method collect(), first we need to get an instance of
    # a Collector class.
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.distribution import DistributionFactCollector
    distributor = DistributionFactCollector()
    # Another instance of a Collector class.
    facts_collector = CollectorMetaDataCollector()

    # Create a AnsibleFactCollector object with two collectors, the two instances created
    # previously.
    ansible_fact_collector = AnsibleFactCollector(collectors=[distributor, facts_collector])

    # Get the results generated by the method collect()
    results = ansible_fact_collector.collect()

    # Compare the results with the expected output
    assert isinstance(results, dict)
    assert 'ansible_facts' in results


# Generated at 2022-06-22 22:37:07.691343
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import os
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import system

    all_collector_classes = collector.collector_classes_from_gather_subset()

    _filter_spec = None
    _namespace = None

    # make a fact collector
    fact_collector = \
        AnsibleFactCollector(collectors=all_collector_classes,
                             namespace=_namespace,
                             filter_spec=_filter_spec)

    # verify that get_collector_class is same as same class in all_collector_classes

# Generated at 2022-06-22 22:37:11.949790
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    _ = AnsibleFactCollector()
    _ = CollectorMetaDataCollector()

    result = CollectorMetaDataCollector(gather_subset=['all']).collect()
    assert result == {'gather_subset': ['all']}

    result = CollectorMetaDataCollector(gather_subset=['all'],
                                        module_setup=False).collect()
    assert result == {'gather_subset': ['all'], 'module_setup': False}



# Generated at 2022-06-22 22:37:23.323994
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # No Namespace
    fact_collector = AnsibleFactCollector()
    assert fact_collector.namespace is None
    assert fact_collector.collectors == []
    assert fact_collector.filter_spec is None

    # With Namespace
    fact_collector = AnsibleFactCollector(namespace='my_namespace')
    assert fact_collector.namespace == 'my_namespace'
    assert fact_collector.collectors == []
    assert fact_collector.filter_spec is None

    # With Namespace and filter_spec
    fact_collector = AnsibleFactCollector(filter_spec='all', namespace='my_namespace')
    assert fact_collector.namespace == 'my_namespace'
    assert fact_collector.collectors == []
    assert fact_collector.filter_

# Generated at 2022-06-22 22:37:29.240513
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    all_collector_classes = [BaseFactCollector]
    collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                      gather_subset=['all'])
    assert len(collector.collectors) == 5
    assert isinstance(collector, AnsibleFactCollector)


# Generated at 2022-06-22 22:37:42.153034
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ns = 'ansible_'
    fc_list = [('ansible_one', 1), ('ansible_two', 2), ('ansible_three', 3), ('ansible_four', 4),
               ('facter_one', 11), ('facter_two', 12), ('facter_three', 13), ('facter_four', 14),
               ('ohai_one', 21), ('ohai_two', 22), ('ohai_three', 23), ('ohai_four', 24),
               ('one', 1), ('two', 2), ('three', 3), ('four', 4)]

    collectors = [collector.BaseFactCollector(namespace=ns), collector.BaseFactCollector(namespace=ns),
                  collector.BaseFactCollector(namespace=ns), collector.BaseFactCollector(namespace=ns)]
    ns_collect

# Generated at 2022-06-22 22:37:50.214619
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    class TestCollector(collector.BaseFactCollector):
        '''A TestCollector that returns a facts dictionary'''

        name = 'test'
        _elements_to_collect = ['one', 'two']

        def __init__(self, namespace=None):
            self._namespace = namespace

        def collect(self, module=None, collected_facts=None):
            return {'test': 1}

    fact_collector = \
        AnsibleFactCollector(collectors=[TestCollector(namespace=None)],
                             filter_spec=None)

    facts = fact_collector.collect()

    assert facts['test'] == 1


# Generated at 2022-06-22 22:38:02.535628
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    ansible_fact_collector = ansible_collector.get_ansible_collector()

    result_facts = ansible_fact_collector.collect()

    # unit test assertions
    # too many facts to assert, just check that the result is valid structure
    assert isinstance(result_facts, dict)
    assert isinstance(result_facts.keys(), list)
    assert isinstance(result_facts.values(), list)

    subset_facts = ansible_fact_collector.collect(gather_subset=['!all', 'network'])

    assert isinstance(subset_facts, dict)
    assert isinstance(subset_facts.keys(), list)
    assert isinstance(subset_facts.values(), list)


# Generated at 2022-06-22 22:38:14.123016
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test case 1: collect facts with all subsets
    gather_subset = ['all']
    minimal_gather_subset = frozenset()
    collector_classes = get_ansible_collector(all_collector_classes=all_collector_classes,
                                              minimal_gather_subset=minimal_gather_subset)
    collected_facts = collector_classes.collect_with_namespace()
    assert collected_facts
    for fact_id, fact_val in collected_facts.items():
        assert fact_val == FACT_COLLECTED_VALUES[fact_id]
    assert len(collected_facts) == len(FACT_COLLECTED_VALUES)

    # Test case 2: collect facts with subset_1
    gather_subset = ['subset_1']
    collector_

# Generated at 2022-06-22 22:38:21.817611
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import network_igd
    from ansible.module_utils.facts import network_gce
    from ansible.module_utils.facts import virtual

    # test that we can get a collector we need
    fact_collector = \
        get_ansible_collector(all_collector_classes=collector.collector_classes,
                              gather_subset=['all'],
                              namespace=None,
                              filter_spec=None)

    assert isinstance(fact_collector, AnsibleFactCollector)
    # sanity check collector contents
    assert isinstance(fact_collector.collectors[0], network.NetworkCollector)
    assert isinstance(fact_collector.collectors[1], virtual.VirtualCollector)


# Generated at 2022-06-22 22:38:33.150492
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gs = ['all', 'network', 'hardware']
    namespace = 'ansible'
    module_setup = True

    # Collectors metadata collector with minimal arguments
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gs)
    assert collector_meta_data_collector.gather_subset == gs
    assert collector_meta_data_collector.namespace is None
    assert collector_meta_data_collector.module_setup is False

    # Collectors metadata collector with all arguments
    collector_meta_data_collector = \
        CollectorMetaDataCollector(collectors=None,
                                   namespace=namespace,
                                   gather_subset=gs,
                                   module_setup=module_setup)

# Generated at 2022-06-22 22:38:42.359779
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestAnsibleFactCollector(AnsibleFactCollector):
        name = 'test_ansible_fact'
        _fact_ids = set(['test_ansible_fact'])

        def collect(self, module=None, collected_facts=None):
            return {self.namespace: {'test_fact': 'value'}}

    class TestAnsibleFactCollectorBad(AnsibleFactCollector):
        name = 'test_ansible_fact_bad'
        _fact_ids = set(['test_ansible_fact_bad'])

        def collect(self, module=None, collected_facts=None):
            raise Exception('cannot collect')

    fact_collector = \
        TestAnsibleFactCollector(filter_spec='*')
    fact_collector_bad = \
        Test

# Generated at 2022-06-22 22:38:52.566996
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import sys

    # Don't import the test_utils into this module as it's already available in the ansible namespace.
    # If you import it again it will throw an exception with a message that says:
    # "sys.meta_path is None, module import has been blocked by sitecustomize"
    from ansible.module_utils.facts.utils.test_utils import get_all_collector_classes

    all_collector_classes = get_all_collector_classes()

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset='all',
                              namespace='ansible_')


# Generated at 2022-06-22 22:38:58.406433
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import collector

    def simple_fact_for_test(collected_facts):
        return collected_facts.get('ansible_fact_for_test', None)

    def simple_fact_for_test_2(collected_facts):
        return collected_facts.get('ansible_fact_for_test_2', None)

    class SimpleFacterBase(collector.BaseFactCollector):
        name = 'simple_facter_for_test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'ansible_fact_for_test': 'simple_facter_for_test'}


# Generated at 2022-06-22 22:39:09.593078
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no collectors
    factCollector = AnsibleFactCollector()
    assert factCollector.collect() == {}

    # Test with a non-collector class
    factCollector = AnsibleFactCollector(collectors=[object()])
    assert factCollector.collect() == {}

    # Test with a non-collector class
    factCollector = AnsibleFactCollector(collectors=[collector.BaseFactCollector()])
    assert factCollector.collect() == {}

    # Test with a collector class
    mock_collector = collector.BaseFactCollector()
    mock_collector.collect_with_namespace = lambda module, collected_facts: {'foo': 'bar'}
    factCollector = AnsibleFactCollector(collectors=[mock_collector])

# Generated at 2022-06-22 22:39:17.134145
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None):
            return {'test':'testval'}

    test_collector = TestCollector(namespace='')
    ansible_fact_collector = AnsibleFactCollector(collectors=[test_collector], namespace=None)

    facts = ansible_fact_collector.collect()
    assert facts == {'test': 'testval'}


# Generated at 2022-06-22 22:39:20.873627
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    print('Testing CollectorMetaDataCollector with gather_subset=all, module_setup=True')
    collection = CollectorMetaDataCollector(['all'], True)
    assert collection.gather_subset is not None
    assert collection.module_setup is True

# Generated at 2022-06-22 22:39:28.482056
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all')
    # Test case 1
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': 'all'}

    # Test case 2
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='!all')
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': '!all'}


# Generated at 2022-06-22 22:39:37.293015
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    collectors = []
    collector1 = collector.BaseFactCollector(namespace='foo.bar')
    collector2 = collector.BaseFactCollector(namespace='foo.baz')
    collectors.append(collector1)
    collectors.append(collector2)

    collector1.collect = \
        lambda module, collected_facts: {'foo1': 'bar1'}
    collector2.collect = \
        lambda module, collected_facts: {'foo2': 'bar2'}

    fact_collector = AnsibleFactCollector(collectors=collectors)

    facts = fact_collector.collect()

    assert isinstance(facts, dict)
    assert facts == {'foo1': 'bar1', 'foo2': 'bar2'}

# Generated at 2022-06-22 22:39:49.724807
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    facts = {'fact_a': 0, 'fact_b': 1, 'fact_c': 2}

    class TestCollector(collector.BaseFactCollector):
        def __init__(self, namespace=None):
            super(TestCollector, self).__init__([], namespace)

        def collect(self, module=None, collected_facts=None):
            return facts

    test_namespace = collector.PrefixFactNamespace(prefix='test_')
    test_collector = TestCollector(test_namespace)
    ansible_fact_collector = AnsibleFactCollector([test_collector],
                                                  namespace=test_namespace)

    assert facts == ansible_fact_collector.collect()

# Generated at 2022-06-22 22:39:58.843062
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.hardware import Hardware
    from ansible.module_utils.facts.settings import DEFAULT_GATHER_SUBSET

    # ensure we can get a fact collector with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)

    # ensure we can get a fact collector with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'))

    # ensure we can get a fact collector with a filter_

# Generated at 2022-06-22 22:40:10.832299
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import unittest

    class TestCollectorMetaDataCollector(unittest.TestCase):

        def test_all_gather_subset(self):
            collector_meta_data_collector = \
                CollectorMetaDataCollector(gather_subset=['all'],
                                           module_setup=True)

            self.assertEqual(collector_meta_data_collector.collect(collected_facts={}), {'gather_subset': ['all'], 'module_setup': True})

        def test_some_gather_subset(self):
            collector_meta_data_collector = \
                CollectorMetaDataCollector(gather_subset=['network'],
                                           module_setup=None)


# Generated at 2022-06-22 22:40:19.179623
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.other

    ansible_collector = get_ansible_collector(all_collector_classes=[ansible.module_utils.facts.collector.other.OtherFactCollector],
                                              gather_subset=['all', 'network'],
                                              gather_timeout=10,
                                              filter_spec='ansible_os*')

    # Using the private attr _collectors since we don't want to trigger collection
    # via the __iter__ method which actually calls the collect() method
    assert len(ansible_collector._collectors) == 2

    # ensure one of the collectors is the metadata collector
    assert any([True for collector in ansible_collector._collectors if collector.name == 'gather_subset'])

    # ensure one of the collectors is

# Generated at 2022-06-22 22:40:25.025120
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    namespace = collector.NamespaceFactNamespace(prefix='ansible_from_module_utils_')

    d = {}

    d['ansible_from_module_utils_test_fact'] = {
        "first": "test_data"
    }

    facts_dict = AnsibleFactCollector(collectors=[TestAnsibleFactCollector(namespace=namespace)],
                                      namespace=namespace).collect()

    assert facts_dict == d


# Generated at 2022-06-22 22:40:35.714593
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeCollector(BaseFactCollector):

        name = 'fake'

        def __init__(self, namespace=None):
            super(FakeCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {self.namespace: {'fake': True}}

    fake_collector_class = FakeCollector

    all_collector_classes = [fake_collector_class]

    filter_spec = 'f*'
    gather_subset = ['fake']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    # Note that collector_classes_from_gather_subset will throw

# Generated at 2022-06-22 22:40:44.960165
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils import facts
    import ansible.module_utils.facts.collector

    gather_subset = ['all']
    minimal_gather_subset = frozenset()
    namespace = None
    filter_spec = []

    fact_collector = \
        get_ansible_collector(all_collector_classes=facts.collector.all_fact_collectors,
                              gather_subset=gather_subset,
                              gather_timeout=None,
                              minimal_gather_subset=minimal_gather_subset,
                              namespace=namespace,
                              filter_spec=filter_spec)

    # check that a collector for each fact was added

# Generated at 2022-06-22 22:40:54.339542
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = \
        collector.load_collectors_from_path(path_list=['./unit_tests/facts/test_facts_modules'],
                                            warn_only=True)
    gather_subset = ['min']
    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            gather_subset=gather_subset)

    collectors = []
    for collector_class in collector_classes:
        collector_obj = collector_class()
        collectors.append(collector_obj)

    # Add dummy collector
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=True)


# Generated at 2022-06-22 22:40:57.681623
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_collector = CollectorMetaDataCollector(gather_subset=['all'])
    assert meta_collector.collect() == {'gather_subset': ['all']}

# Generated at 2022-06-22 22:41:08.100435
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_obj = CollectorMetaDataCollector(gather_subset=[])
    assert collector_obj.collect()['gather_subset'] == []

    collector_obj = CollectorMetaDataCollector(gather_subset=['a', 'b'])
    assert collector_obj.collect()['gather_subset'] == ['a', 'b']

    v = collector.GatherFacts()
    assert v.collect_with_namespace() == v.collect_with_namespace()  # correct? idempotent?

    # check that 'module_setup' is present if enabled
    collector_obj = CollectorMetaDataCollector(module_setup=True)
    assert collector_obj.collect()['module_setup']

    # check that 'module_setup' is not present if disabled

# Generated at 2022-06-22 22:41:18.724982
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    collector = AnsibleFactCollector(collectors=[TestCollector()], namespace=namespace.PrefixFactNamespace(prefix='ansible_', separator='_'))

    assert collector.collect().get('test') == 'test'
    assert collector.collect().get('ansible_test') == 'test'
    assert collector.collect().get('ansible_test_test') is None

    collector = AnsibleFactCollector(collectors=[TestCollector()])

    assert collector.collect().get('test') == 'test'
    assert collector.collect().get('ansible_test') is None

# Generated at 2022-06-22 22:41:29.647635
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """Test collect method of class AnsibleFactCollector"""
    import ansible.module_utils.facts.test.test_ansible_collector as test_ansible_collector
    import ansible.module_utils.facts.test.test_ansible_collector_namespace as test_ansible_collector_namespace
    import ansible.module_utils.facts.test.test_filter_spec as test_filter_spec

    module = test_ansible_collector.FakeModule()

    # Case 1: Filter does not specify any facts, all facts are returned
    collector = CollectorMetaDataCollector()
    collector.collect()
    collector = CollectorMetaDataCollector()
    collector.collect(module=module)

    collector = test_ansible_collector.Collector1()
    collector.collect()
    collector = test_ans

# Generated at 2022-06-22 22:41:35.141551
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import copy

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=[],
                                   module_setup=True)
    collected_facts = copy.copy(collector_meta_data_collector.collect())
    assert collected_facts['gather_subset'] == []
    assert collected_facts['module_setup'] == True

# Generated at 2022-06-22 22:41:46.803118
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ns1 = collector.PrefixFactNamespace(prefix='ansible_ns1_')
    ns2 = collector.PrefixFactNamespace(prefix='ansible_ns2_')

    # dummyinfo is a DictFactCollector that has 3 keys in it
    # 1 of which is 'ansible_facts' (but we don't do anything special with 'ansible_facts')
    dummyinfo = collector.DictFactCollector()
    dummyinfo.add_fact('foo', 'bar')
    dummyinfo.add_fact('foo2', 'baz')
    dummyinfo.add_fact('ansible_facts', 'blah')

    foo_collector = collector.DictFactCollector()
    foo_collector.add_fact('foo', 'bar')
    foo_collector.add_fact('foo2', 'baz')

# Generated at 2022-06-22 22:41:52.788133
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collectors.distribution as distro_collector
    import ansible.module_utils.facts.collectors.network as network_collector
    import ansible.module_utils.facts.collectors.hardware as hardware_collector
    import ansible.module_utils.facts.collectors.virtual as virtual_collector
    import ansible.module_utils.facts.collectors.kernel as kernel_collector
    import ansible.module_utils.facts.collectors.facter as facter_collector
    import ansible.module_utils.facts.collectors.ohai as ohai_collector
    import ansible.module_utils.facts.collectors.system as system_collector
    import ansible.module_utils.facts.collectors.pkg_mgr as pkg_mgr

# Generated at 2022-06-22 22:41:57.301037
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''collect method of CollectorMetaDataCollector class'''

    collector_meta_data_collector = CollectorMetaDataCollector()
    result = collector_meta_data_collector.collect()
    assert 'gather_subset' in result


# Generated at 2022-06-22 22:42:06.548629
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual

    f1 = ansible.module_utils.facts.hardware.Hardware()
    f2 = ansible.module_utils.facts.network.Network()
    f3 = ansible.module_utils.facts.system.System()
    f4 = ansible.module_utils.facts.virtual.Virtual()

    fc = AnsibleFactCollector(collectors=[f1, f2, f3, f4], filter_spec=['*'])

    assert fc.collectors == [f1, f2, f3, f4]
    assert fc.filter_spec == ['*']
    assert fc

# Generated at 2022-06-22 22:42:17.895382
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    #
    # Smoke test
    #

    # Smoke test (all facts except net facts)
    all_collector_classes = list(collector.ALL_COLLECTOR_CLASSES)
    all_collector_classes.remove(collector.NetworkCollector)

    smoke_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    facts_dict = smoke_collector.collect()
    assert 'ansible_facts' in facts_dict

    #
    # filter_spec test
    #

    # Just collect a subset of facts.  Only an empty filter_spec or

# Generated at 2022-06-22 22:42:29.140385
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FactCollectorMock:
        def __init__(self, namespace):
            self.namespace = namespace

        def collect(self, collected_facts=None, module=None):
            return '{}_data'.format(self.namespace)

    class FactCollectorExceptionMock:
        def collect(self, collected_facts=None, module=None):
            raise Exception('test exception')

        def __str__(self):
            return 'test exception'

    # when not filter-spec is provided, all the available facts should be returned
    fact_collector = AnsibleFactCollector(collectors=[FactCollectorMock('ns1'), FactCollectorMock('ns2')])
    assert fact_collector.collect() == {'ns1': 'ns1_data', 'ns2': 'ns2_data'}

   

# Generated at 2022-06-22 22:42:36.596250
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # testing __init__()
    collectors = []
    namespace = None
    filter_spec = None
    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=namespace, filter_spec=filter_spec)
    assert fact_collector.collectors == collectors
    assert fact_collector.namespace == namespace
    assert fact_collector.filter_spec == filter_spec


# Generated at 2022-06-22 22:42:47.518445
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import json
    import ansible.module_utils.facts.collector

    facts = {}

    class TestFactsCollector:
        def __init__(self, module=None, collected_facts=None):
            # collected_facts is a dict sent as an argument to collect_with_namespace,
            # and it is later passed to collect as an argument.
            # This class just adds one entry to collected facts.
            collected_facts['test_entry'] = 'Test Entry'

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'test_entry': 'Test Entry'}

    # Test fact collector which collects test_entry and returns it.
    fact_collector = AnsibleFactCollector(collectors=[TestFactsCollector()])

# Generated at 2022-06-22 22:42:56.495885
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.cache


# Generated at 2022-06-22 22:43:00.669095
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert c.collect() == {'gather_subset': ['all'], 'module_setup': True}



# Generated at 2022-06-22 22:43:01.758245
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_inst = AnsibleFactCollector()
    return collector_inst