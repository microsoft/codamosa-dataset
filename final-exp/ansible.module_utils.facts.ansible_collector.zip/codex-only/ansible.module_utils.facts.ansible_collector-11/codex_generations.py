

# Generated at 2022-06-22 22:33:04.635358
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # build a instance of CollectorMetaDataCollector
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='!all', module_setup=True)
    # run the collect method
    result = collector_meta_data_collector.collect(collected_facts={'facts': {'facts': 'facts'}})

    expected_result = {'gather_subset': '!all', 'module_setup': True}
    assert result == expected_result

# Generated at 2022-06-22 22:33:06.626725
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass



# Generated at 2022-06-22 22:33:10.546572
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset=['network'],
        module_setup=True
    )
    assert collector_meta_data_collector.collect() == {'gather_subset': ['network'], 'module_setup': True}



# Generated at 2022-06-22 22:33:19.554123
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=None, module_setup=False)
    assert collector_meta_data_collector.gather_subset is None
    assert collector_meta_data_collector.module_setup is False
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert collector_meta_data_collector.gather_subset == 'all'
    assert collector_meta_data_collector.module_setup is True



# Generated at 2022-06-22 22:33:23.219986
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class CollectorA(collector.BaseFactCollector):
        def __init__(self, namespace=None):
            super(CollectorA, self).__init__()

            if namespace:
                self.namespace = namespace

        def collect_with_namespace(self, collected_facts=None, module=None):
            return {'fact_a': 'fact_a_val'}

    class CollectorB(collector.BaseFactCollector):
        def __init__(self, namespace=None):
            super(CollectorB, self).__init__()

            if namespace:
                self.namespace = namespace

        def collect_with_namespace(self, collected_facts=None, module=None):
            return {'fact_b': 'fact_b_val'}

    fact_collector = \
        AnsibleFactCollect

# Generated at 2022-06-22 22:33:27.934633
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ''' Test for method collect of class CollectorMetaDataCollector '''

    fact_collector = CollectorMetaDataCollector(gather_subset='test_gather_subset',
                                                module_setup='test_module_setup')

    assert {'gather_subset': 'test_gather_subset',
            'module_setup': 'test_module_setup'} == fact_collector.collect()

# Generated at 2022-06-22 22:33:35.925629
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_default_gather
    from ansible.module_utils.facts import default_collector_classes
    from ansible.module_utils.facts.collector.default import DefaultFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector

    minimal_gather_subset = 'hardware'
    gather_subset = ['!all', 'network']
    timeout = 1

    # return only facts named 'ansible_all_ipv4_addresses'
    filter_spec = 'ansible_all*'


# Generated at 2022-06-22 22:33:40.742002
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    facts = fact_collector.collect()
    assert 'gather_subset' in facts
    assert facts['gather_subset'] == 'all'
    assert 'module_setup' in facts
    assert facts['module_setup'] is True

# Generated at 2022-06-22 22:33:51.129141
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import AllFactCollector, \
        TestFactsCollector

    TestFactsCollector.name = 'test_facts'
    all_collectors = [AllFactCollector, TestFactsCollector]
    fact_collector = get_ansible_collector(all_collector_classes=all_collectors)
    module = None
    if hasattr(fact_collector, 'collectors'):
        facts = fact_collector.collect(module=module)
    else:
        facts = fact_collector.collect_with_namespace(module=module)

    assert facts
    assert facts['test_facts']
    assert facts['ansible_facts']['test_facts']

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
   

# Generated at 2022-06-22 22:33:56.575156
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts import namespace

    fact_collector = AnsibleFactCollector(collectors=[],
                                          filter_spec=['ansible_*', 'facter_*'],
                                          namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    assert fact_collector.collectors == []
    assert fact_collector.filter_spec == ['ansible_*', 'facter_*']
    assert fact_collector.namespace.prefix == 'ansible_'

# Generated at 2022-06-22 22:34:09.195160
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.system.distribution

    # Can create Ansible fact collector with no arguments
    ansible_collector = \
        get_ansible_collector(
            all_collector_classes=[
                ansible.module_utils.facts.system.distribution.Distribution,
            ],
            namespace=None,
        )
    assert ansible_collector

    # Can create Ansible fact collector with no arguments and run it
    ansible_collector = \
        get_ansible_collector(
            all_collector_classes=[
                ansible.module_utils.facts.system.distribution.Distribution,
            ],
            namespace=None,
        )
    facts

# Generated at 2022-06-22 22:34:17.980232
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_collectors = [1, 2, 3]
    test_namespace = collector.FactNamespace('test')
    test_gather_subset = ['all', '!minimal', '!networking']
    test_module_setup = True
    test_collector = CollectorMetaDataCollector(test_collectors, test_namespace, test_gather_subset, test_module_setup)

    test_facts = test_collector.collect()
    assert test_facts == {'gather_subset': ['all', '!minimal', '!networking'], 'module_setup': True}

# Generated at 2022-06-22 22:34:22.290332
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['!all'], module_setup=None)
    actual = collector_meta_data_collector.collect()
    assert actual == {'gather_subset': ['!all']}
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    actual = collector_meta_data_collector.collect()
    assert actual == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:34:33.075841
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts import namespaces

    ns1 = namespaces.PrefixFactNamespace(prefix='a_')
    ns2 = namespaces.PrefixFactNamespace(prefix='b_')

    collectors_list = []
    c1 = collectors.DistributionCollector()
    c1.set_namespace(ns1)
    collectors_list.append(c1)

    c2 = collectors.PlatformCollector(namespace=ns2)
    collectors_list.append(c2)

    afc = AnsibleFactCollector(collectors=collectors_list)

    facts = afc.collect()

    # For this test, there are no additional filters.
    # So Gather facts should be suffixed with _namespace

# Generated at 2022-06-22 22:34:38.481565
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    collector = CollectorMetaDataCollector(gather_subset=['all'],
                                           module_setup=True)
    assert collector.gather_subset == ['all']
    assert collector.module_setup

    collected_facts = collector.collect()
    assert collected_facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:34:41.108895
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    c = AnsibleFactCollector()
    assert isinstance(c, AnsibleFactCollector) and isinstance(c, collector.BaseFactCollector)

# Generated at 2022-06-22 22:34:50.552006
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts.namespace import Namespace

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.hardware.cpu import CPUFactCollector

    # Get a fact collector instance
    fact_collector = get_ansible_collector(
        gather_subset=['all'],
        all_collector_classes=[DistributionFactCollector,
                               PkgMgrFactCollector,
                               CPUFactCollector])

    # Test get_fact_names()

# Generated at 2022-06-22 22:35:01.545551
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.hardware as hardware_collectors
    import ansible.module_utils.facts.collector.virtual as virtual_collectors

    all_collector_classes = \
        hardware_collectors.all_collector_classes + \
        virtual_collectors.all_collector_classes

    gather_subset = ['all']
    gather_timeout = 30
    minimal_gather_subset = frozenset()

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)

    # Returned fact collector should be an

# Generated at 2022-06-22 22:35:10.786091
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_collector_classes()

    # get all the fact names available
    all_fact_names = set([])
    for c_name in all_collector_classes.keys():
        all_fact_names.update(all_collector_classes[c_name]._fact_ids)

    def check_all_facts_present(facts_dict, all_fact_names):
        '''validate that all the known fact names are present in the facts_dict'''
        for name in all_fact_names:
            if name not in facts_dict:
                return(False)

        return(True)

    # test all facts with facts filter set to '*'

# Generated at 2022-06-22 22:35:20.596955
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    c1 = collector.BaseFactCollector()
    c2 = collector.BaseFactCollector()
    c3 = collector.BaseFactCollector()
    c4 = collector.BaseFactCollector()
    c5 = collector.BaseFactCollector()
    c6 = collector.BaseFactCollector()

    collectors1 = [c1, c2]
    collectors2 = [c3, c4]
    collectors3 = [c5, c6]

    # simple creation with no arguments
    fc1 = AnsibleFactCollector()

    # set collectors and filter spec
    fc2 = AnsibleFactCollector(collectors=collectors1, filter_spec='a')
    assert fc2.collectors == collectors1
    assert fc2.filter_spec == 'a'

    # set collectors and filter spec
    fc3

# Generated at 2022-06-22 22:35:24.494921
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector().collect() == {'gather_subset': 'all'}
    assert CollectorMetaDataCollector(gather_subset=['min']).collect() == {'gather_subset': 'min'}
    assert CollectorMetaDataCollector(gather_subset=['all'], module_setup=True).collect() == {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-22 22:35:29.229975
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='network', module_setup=False)
    assert collector_meta_data_collector.gather_subset == ['network']
    assert collector_meta_data_collector.module_setup is False


# Generated at 2022-06-22 22:35:37.999171
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collectors.generic
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.platform
    import ansible.module_utils.facts.collectors.virtual
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.timeout


# Generated at 2022-06-22 22:35:41.623669
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import collector_spec

    collector_spec_list = collector_spec.get_spec_list()

    fact_collector = get_ansible_collector(
        all_collector_classes=collector_spec_list)

    assert fact_collector.collectors

# Generated at 2022-06-22 22:35:43.445049
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    namespace = None
    filter_spec = None
    collectors = None
    AnsibleFactCollector(collectors, namespace, filter_spec)


# Generated at 2022-06-22 22:35:49.129547
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector(gather_subset=['all'],
                                      module_setup=True).collect() == {'gather_subset': ['all'], 'module_setup': True}
    assert CollectorMetaDataCollector(gather_subset=['all']).collect() == {'gather_subset': ['all']}

# Generated at 2022-06-22 22:35:56.778907
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # pylint: disable=unused-variable
    # prep a fake collector that collects info about the dict
    class DictCollector(collector.BaseFactCollector):
        name = 'dict'

        def collect(self, module=None, collected_facts=None):
            return {
                '__info__': {
                    'version': None,
                    'date': None,
                    'fact_type': 'dict'
                }
            }

    # prep a fake collector that collects info about the list
    class ListCollector(collector.BaseFactCollector):
        name = 'list'


# Generated at 2022-06-22 22:36:05.981969
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Minimal gathering
    collector_obj = get_ansible_collector(all_collector_classes=fact_modules,
                                          gather_subset='!all,!network,!hardware,!virtual',
                                          gather_timeout=0.1,
                                          minimal_gather_subset=frozenset(['!network',
                                                                          '!hardware',
                                                                          '!virtual']))
    assert(len(collector_obj._collectors) == 1)
    assert(collector_obj._collectors[0].name == 'facter')

    # Non minimal gathering, no collectors filtered

# Generated at 2022-06-22 22:36:06.949083
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO:
    pass

# Generated at 2022-06-22 22:36:09.000811
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = fact_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}


# Generated at 2022-06-22 22:36:20.316509
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import (
        BaseFactCollector,
        PrefixFactNamespace,
        HostnameFactCollector,
        NetworkCollector,
        CommandCollector
    )

    c = get_ansible_collector(
        all_collector_classes=[HostnameFactCollector, NetworkCollector, CommandCollector],
        namespace=None,
        filter_spec=['ansible_facts', '*'],
        gather_subset=frozenset(['all']),
        gather_timeout=10,
        minimal_gather_subset=frozenset()
    )
    assert c.__class__ == AnsibleFactCollector
    assert c.filter_spec == ['ansible_facts', '*']
   

# Generated at 2022-06-22 22:36:25.105673
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = []
    namespace = 'test'
    gather_subset = ['all']
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset)
    collector_meta_data_collector.collect(collected_facts={})

# Generated at 2022-06-22 22:36:28.591426
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:36:29.168913
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    pass

# Generated at 2022-06-22 22:36:35.823324
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a dummy fact collector
    class F(collector.BaseFactCollector):
        name = 'ansible_dummy'

        def collect(self, module=None, collected_facts=None):
            return dict(ansible_dummy='ansible_dummy')

    # Create one fact collector with no namespaces
    fact_collector = AnsibleFactCollector(collectors=[F()])

    # Create a dict of collectors with no namespaces
    # Note: This is what AnsibleModule._load_params() actually calls
    fact_collectors = collector.BaseFactCollector.get_fact_collectors(collectors=[F()])

    # Collect facts from the dict of collectors
    # Note: This is what AnsibleModule._load_params() actually does
    # Also note: This is what AnsibleFactCollector.collect_from()

# Generated at 2022-06-22 22:36:45.916317
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.system.distribution as distribution_module
    import ansible.module_utils.facts.system.platform as platform_module
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr_module

    distribution_obj = \
        distribution_module.DistributionFactCollector(namespace=None)
    platform_obj = \
        platform_module.PlatformFactCollector(namespace=None)
    pkg_mgr_obj = \
        pkg_mgr_module.PkgMgrFactCollector(namespace=None)

    all_collector_classes = [distribution_module.DistributionFactCollector,
                             platform_module.PlatformFactCollector,
                             pkg_mgr_module.PkgMgrFactCollector]

   

# Generated at 2022-06-22 22:36:55.491470
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import collector_defaults
    from ansible.module_utils.facts import injectors
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts import parsers
    from ansible.module_utils.facts import version

    # Note: in order to run unit tests with nose, we must use a global.
    # The nose test runner is not aware that this was created in another module.
    # A better solution is to refactor the facts module to not use globals.
    global _DEFAULT_COLLECTORS

    _DEFAULT_COLLECTORS = collector_defaults.DEFAULT_COLLECTORS

    # Create the collector_classes by patching the _DEFAULT_COLLECTORS global
    # to include a NamespaceFactsCollectionTest to make sure the namespace
    # functionality

# Generated at 2022-06-22 22:37:02.667839
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """
    Test the return value of collect method when asked to gather module_setup
    """
    collect_meta_data = CollectorMetaDataCollector(
        gather_subset=['all'], module_setup=True)

    collected_facts = collect_meta_data.collect()
    assert collected_facts == {'gather_subset': ['all'], 'module_setup': True}


# Generated at 2022-06-22 22:37:11.749886
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-branches

    # NOTE: this is not as thorough a test suite as I would like.  More should be added.

    from ansible.module_utils.facts import namespaced_fact_collectors

    # pylint: disable=unused-variable
    from ansible.module_utils.facts import hardware as hardware
    from ansible.module_utils.facts import virtual as virtual
    from ansible.module_utils.facts import system as system
    from ansible.module_utils.facts import distro as distro
    from ansible.module_utils.facts import network as network
    from ansible.module_utils.facts import appliance as appliance

# Generated at 2022-06-22 22:37:18.875614
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.collectors_from_entry_points()
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace,
                                           filter_spec,
                                           gather_subset,
                                           gather_timeout,
                                           minimal_gather_subset)
    assert(fact_collector is not None)

# Generated at 2022-06-22 22:37:22.280959
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    fact_collector = \
        AnsibleFactCollector(collectors=[collector_meta_data_collector])

    collected_facts = fact_collector.collect()
    assert collected_facts['gather_subset'] == ['all']

# Generated at 2022-06-22 22:37:26.508934
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_obj = CollectorMetaDataCollector(gather_subset='all',
                                               module_setup=True)
    result = collector_obj.collect()
    assert result['gather_subset'] == 'all'
    assert result['module_setup']


# Generated at 2022-06-22 22:37:31.482453
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:37:43.609367
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollector(collector.BaseFactCollector):
        '''Fake collector class used for unit tests.'''
        name = 'mock_collector'
        _fact_ids = set([])
        def collect(self, module=None, collected_facts=None):
            return {'fake_collector_key': 'fake collector value'}

    mock_collector_class = MockCollector
    mock_collector_obj = mock_collector_class()
    mock_collector_obj.name = 'mock_collector'
    mock_collector_obj._fact_ids = set([])

    # assert that the mock collector is working
    assert mock_collector_obj.collect() == {'fake_collector_key': 'fake collector value'}

    # assert that the collector is returned under the 'ansible_facts

# Generated at 2022-06-22 22:37:51.515461
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # NOTE: this is a whitebox test, so we reference internal details of the namespaces.
    # Worthwhile to keep this up to date as it asserts what happens under the hood
    from ansible.module_utils.facts.namespace import _is_namespace_class

    # List of all the existing default collector class names.
    # Use the same class names as in get_collector_classes to verify the test cases

# Generated at 2022-06-22 22:38:03.062152
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import unittest
    import sys

    # mock Python modules that are imported by module under test
    import collections
    import ansible.module_utils.facts.collector

    mocked_modules = {
       'collections': collections,
       'ansible.module_utils.facts.collector': ansible.module_utils.facts.collector,
       'sys': sys,
    }

    # mock object classes that are imported by module under test
    # mock_classes = {
    # }

    # mock the objects that are imported by module under test
    mocked_objects = {}

    # mock functions and names in __builtin__
    # mock_builtin_funcs_names = {
    # }

    # mock all objects and names in module under test
    mock_objs_names = {}

    mock_all = {}
    mock

# Generated at 2022-06-22 22:38:07.538891
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import pytest
    # no test implementation
    with pytest.raises(NotImplementedError):
        test_CollectorMetaDataCollector = CollectorMetaDataCollector()
        test_CollectorMetaDataCollector.collect()

# Generated at 2022-06-22 22:38:17.152181
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    memory_dict = {'MemTotal': 4152820, 'MemFree': 3136568}

    class MemoryFactCollector(collector.BaseFactCollector):

        name = 'memory'
        _fact_ids = set(['MemTotal', 'MemFree'])

        def collect(self, module=None, collected_facts=None):
            return memory_dict

    class FactCollector1(collector.BaseFactCollector):

        name = 'factcollector1'
        _fact_ids = set(['a', 'b', 'c'])

        def collect(self, module=None, collected_facts=None):
            return {'a': '1', 'b': '2', 'c': '3'}

    class FactCollector2(collector.BaseFactCollector):

        name = 'factcollector2'
       

# Generated at 2022-06-22 22:38:27.153288
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fetched_facts = AnsibleFactCollector(collectors=None).collect()
    assert fetched_facts == {}

    # Passing collectors=[]
    fetched_facts = AnsibleFactCollector(collectors=[]).collect()
    assert fetched_facts == {}

    # Passing non-empty collectors
    from ansible.module_utils.facts.collector import FacterCollector, OhaiCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    fetched_facts = AnsibleFactCollector(namespace=PrefixFactNamespace(prefix='abc_'),
                                         collectors=[FacterCollector(), OhaiCollector()]).collect()
    assert fetched_facts == {'abc_system': 'Linux', 'abc_product_name': 'Red Hat Enterprise Linux Server'}

    # Using from_

# Generated at 2022-06-22 22:38:28.413523
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector = AnsibleFactCollector()

# Generated at 2022-06-22 22:38:33.440403
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    filter_spec = ['ansible_lsb*', 'ansible_distribution*']
    ansible_fact_collector = AnsibleFactCollector(collectors=[], filter_spec=filter_spec)
    assert ansible_fact_collector.filter_spec == filter_spec


# Generated at 2022-06-22 22:38:40.047385
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector()
    assert c.collect()['gather_subset'] == []
    c = CollectorMetaDataCollector(gather_subset=['val1', 'val2'])
    assert c.collect()['gather_subset'] == ['val1', 'val2']
    c = CollectorMetaDataCollector(gather_subset=['val1', 'val2'], module_setup=False)
    assert c.collect()['module_setup'] is False

# Generated at 2022-06-22 22:38:50.911771
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Just prove that it returns a dictionary with the expected keys
    # and values.

    # Create an instance.
    c1_collector = CollectorMetaDataCollector(None, None, 'all', None)

    # Invoke the test method.
    result = c1_collector.collect(None, None)

    # Prove the results are what we expect.
    assert 'gather_subset' in result
    assert result['gather_subset'] == 'all'
    # If the module_setup attribute is False, it shouldn't be present.
    assert 'module_setup' not in result

    # Create a second instance.
    c2_collector = CollectorMetaDataCollector(None, None, gather_subset='local', module_setup=True)

    # Invoke the test method.
    result = c2_collector

# Generated at 2022-06-22 22:38:54.935101
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}



# Generated at 2022-06-22 22:38:57.595492
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()

    assert not fact_collector.collectors
    assert not fact_collector.collector_classes
    assert not fact_collector.filter_spec
    assert not fact_collector.namespace

# Generated at 2022-06-22 22:39:09.215177
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = None
    gather_subset = ['all']
    gather_timeout = '30'
    minimal_gather_subset = []
    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=minimal_gather_subset,
            gather_subset=gather_subset,
            gather_timeout=gather_timeout)
    collectors = []
    namespace = None
    for collector_class in collector_classes:
        collector_obj = collector_class(namespace=namespace)
        collectors.append(collector_obj)
    # Add a collector that knows what gather_subset we used so it it can provide a fact
    collector_meta_data

# Generated at 2022-06-22 22:39:15.818483
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_collector_classes = ['test_class']
    test_namespace = 'test_namespace'
    test_gather_subset = ['test_gather_subset']
    test_module_setup = True
    CollectorMetaDataCollector(test_collector_classes,
                                   test_namespace,
                                   test_gather_subset,
                                   test_module_setup)


# Generated at 2022-06-22 22:39:25.597561
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collectors = collector.get_collector_classes(all_collectors=True)

    ansible_collector = get_ansible_collector(all_collectors)

    # collect module_setup fact
    all_facts = ansible_collector.collect()

    # verify module_setup fact is present
    assert ('module_setup' in all_facts)

    ansible_collector = get_ansible_collector(all_collectors, gather_subset=['!all'])

    # collect module_setup fact
    all_facts = ansible_collector.collect()

    # verify module_setup fact is not present
    assert ('module_setup' not in all_facts)

# Generated at 2022-06-22 22:39:33.958274
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import \
        get_all_collector_classes, get_gather_subset_categories

    # The collector classes that we expect each minimal_gather_subset to include

# Generated at 2022-06-22 22:39:42.638683
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    c1 = collector.CollectorBase()
    c2 = collector.CollectorBase()

    ns1 = collector.NoNamespace()
    ns2 = collector.NoNamespace()

    with pytest.raises(ValueError):
        # should raise exception since collectors list is None
        AnsibleFactCollector(collectors=None)

    with pytest.raises(ValueError):
        # should raise exception since collectors list is empty
        AnsibleFactCollector(collectors=[])

    with pytest.raises(ValueError):
        # should raise exception since collectors list is not empty, but namespace is None
        AnsibleFactCollector(collectors=[c1], namespace=None)

    with pytest.raises(ValueError):
        # should raise exception since collectors list is not empty, but namespace is not a FactNamespace
        AnsibleFact

# Generated at 2022-06-22 22:39:54.040383
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.base
    import ansible.module_utils.facts.collector.dmi
    import ansible.module_utils.facts.collector.external_procs
    import ansible.module_utils.facts.collector.disk
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr

    import ansible.module_utils.facts.namespace.PrefixFactNamespace

    import ansible.module_utils.facts.collector.network as network

    from ansible.module_utils.facts.collector.network import NetworkFactCollector

# Generated at 2022-06-22 22:40:02.388549
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Create a AnsibleFactCollector object with given members
    fact_collector = AnsibleFactCollector(collectors=['collect1', 'collect2'],
                                          filter_spec=['filterspec1', 'filterspec2'],
                                          namespace=['namespace1', 'namespace2'])
    # Create a dict with given facts
    test_dict = \
        {'testkey1': 'testvalue1',
         'testkey2': 'testvalue2'}

    # Set the method return value for _filter
    fact_collector._filter = \
        lambda x, y: \
            {'_filterkey1': '_filtervalue1',
             '_filterkey2': '_filtervalue2'}

    # Create a test module object
    test_module = 'testmodule'

    # Create

# Generated at 2022-06-22 22:40:08.037652
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gather_subset = ['all']
    minimal_gather_subset = frozenset()
    module_setup = True
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=module_setup)
    assert collector_meta_data_collector.collect() == {'module_setup':module_setup, 'gather_subset': gather_subset}

# Generated at 2022-06-22 22:40:11.759564
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors=None
    namespace=None
    gather_subset=None
    module_setup=None
    assert CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup).collect()['module_setup'] == True


# Generated at 2022-06-22 22:40:19.694597
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    cmc = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    ansible_facts = cmc.collect()

    if ansible_facts['gather_subset'] == ['all']:
        print('test successful')
        return True
    else:
        print('test unsuccessful')
        return False

if __name__ == '__main__':
    test_CollectorMetaDataCollector_collect()

"""
This module is for use on the target system in place of Ansiballz, see
https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/system/__init__.py
for the original source file.
"""

import os
import sys

from ansible.module_utils.facts import timeout

# Generated at 2022-06-22 22:40:21.707190
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=['devices'],
                                   module_setup=True)
    result = c.collect()
    assert result['gather_subset'] == ['devices']
    assert result['module_setup'] == True


# Generated at 2022-06-22 22:40:26.658713
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class FakeCollector:
        pass

    all_collector_classes = {
        'all': FakeCollector,
        'network': FakeCollector
    }
    gather_subset = ['all', 'network']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT

    get_ansible_collector(all_collector_classes,
                          gather_subset=gather_subset,
                          gather_timeout=gather_timeout)

# Generated at 2022-06-22 22:40:32.427075
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test for method collect of class CollectorMetaDataCollector'''
    g_s = "some gather subset"
    c_d = {}
    c = CollectorMetaDataCollector(gather_subset=g_s)
    assert c.collect(module=None, collected_facts=c_d) == {
        'gather_subset': g_s
    }

# Generated at 2022-06-22 22:40:41.340560
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test filter_spec='*'
    filter_spec = '*'
    fact_collector = AnsibleFactCollector(filter_spec=filter_spec)
    expected = {'A': 'foo', 'B': 'bar'}
    actual = fact_collector.collect(fact_collector, [{'A': 'foo'}, {'B': 'bar'}])
    assert actual == expected

    # Test filter_spec=['A', 'B']
    # NOTE: It's ok if filter_spec matches more than one fact
    filter_spec = ['A', 'B', 'C']
    fact_collector = AnsibleFactCollector(filter_spec=filter_spec)
    expected = {'A': 'foo', 'B': 'bar'}

# Generated at 2022-06-22 22:40:46.329856
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = c.collect()
    assert facts['module_setup'] is True
    assert facts['gather_subset'] == ['all']


# Generated at 2022-06-22 22:40:48.810321
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_collector = get_ansible_collector()
    assert isinstance(ansible_collector, AnsibleFactCollector)

# Generated at 2022-06-22 22:40:50.531550
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert AnsibleFactCollector()
    assert AnsibleFactCollector(collectors=[])


# Generated at 2022-06-22 22:41:02.608171
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils.facts.collector.hardware
    collector_classes = [ansible.module_utils.facts.collector.hardware.Hardware,
                         ansible.module_utils.facts.collector.os.OS,
                         ansible.module_utils.facts.collector.network.Network,
                         CollectorMetaDataCollector]

    collectors = []
    for collector_class in collector_classes:
        collector_obj = collector_class()
        collectors.append(collector_obj)

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=None)
    facts = fact_collector.collect(module=None,
                                   collected_facts=None)
    assert facts['gather_subset'] == ['all']

# Generated at 2022-06-22 22:41:04.727763
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert isinstance(fact_collector, AnsibleFactCollector)



# Generated at 2022-06-22 22:41:12.610632
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # pylint: disable=redefined-outer-name
    from . import filter
    # pylint: enable=redefined-outer-name

    all_collector_classes = filter.get_filter_classes()
    meta_data_collector = CollectorMetaDataCollector(all_collector_classes, 'meta_data', '*')
    assert meta_data_collector.gather_subset == '*'
    meta_data_collector = CollectorMetaDataCollector(all_collector_classes, 'meta_data', 'all')
    assert meta_data_collector.gather_subset == 'all'


# Generated at 2022-06-22 22:41:13.847704
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert(isinstance(AnsibleFactCollector(), collector.BaseFactCollector))

# Generated at 2022-06-22 22:41:20.572813
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    assert {} == CollectorMetaDataCollector(gather_subset='').collect()
    assert {'gather_subset': ['one']} == CollectorMetaDataCollector(gather_subset=['one']).collect()
    assert {'gather_subset': ['one'], 'module_setup': True} == CollectorMetaDataCollector(gather_subset=['one'], module_setup=True).collect()

# Generated at 2022-06-22 22:41:29.919712
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ''' Unit test for method collect of class AnsibleFactCollector '''
    class FakeCollector:
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'a': '1', 'b': '2'}
    from ansible.module_utils.facts import namespace
    collector_obj = FakeCollector()
    fact_collector = AnsibleFactCollector(collectors=[collector_obj],
                                          namespace=namespace.PrefixFactNamespace('ansible_'))
    expanded_facts = fact_collector.collect()
    assert expanded_facts == {'ansible_a': '1', 'ansible_b': '2'}

# Generated at 2022-06-22 22:41:41.333128
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class FakeCollector(object):
        def __init__(self, name, namespace):
            self.name = name
            self.namespace = namespace

        def __str__(self):
            return self.name

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {'%s_%s' % (self.namespace, self.name): "val"}

    fake_collector1 = FakeCollector(name='collector1', namespace='ns1')
    fake_collector2 = FakeCollector(name='collector2', namespace='ns2')

    # filter_spec='*', no namespaces, no collected_facts

# Generated at 2022-06-22 22:41:51.991372
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # Test for a specific gather_subset
    gather_subset = ['network']
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts['gather_subset'] == gather_subset

    # Test for all gather_subsets
    gather_subset = ['all']
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts['gather_subset'] == gather_subset

    # Test for an empty gather_subset
    gather_subset = None
    collector_meta_data_collector = Collector

# Generated at 2022-06-22 22:42:03.296339
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collectors import cpu
    from ansible.module_utils.facts.collectors import memory

    filter_spec = filter_spec = ['ansible_mem*']
    fact_collector = \
        AnsibleFactCollector(collectors=[cpu, memory],
                             filter_spec=filter_spec)

    facts_dict = fact_collector.collect()

    assert 'ansible_all_ipv4_addresses' in facts_dict
    assert 'ansible_processor_vcpus' in facts_dict
    assert 'ansible_processor_threads_per_core' in facts_dict

    assert 'ansible_memtotal_mb' in facts_dict
    assert 'ansible_swaptotal_mb' in facts_dict
    assert 'ansible_memfree_mb' in facts

# Generated at 2022-06-22 22:42:07.153082
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespaces
    fact_collector = \
        CollectorMetaDataCollector(gather_subset='all',
                                   namespace=namespaces.PrefixFactNamespace(prefix='ansible_'))
    assert fact_collector.name == 'gather_subset'
    assert fact_collector.collectors is None
    assert fact_collector.namespace == 'ansible_'
    assert fact_collector.gather_subset == 'all'
    assert fact_collector.module_setup is True


# Generated at 2022-06-22 22:42:12.653960
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(
        gather_subset=['all'],
        module_setup=True)
    fact_dict = fact_collector.collect()
    assert fact_dict == {
        'gather_subset': ['all'],
        'module_setup': True
    }


# Generated at 2022-06-22 22:42:18.570718
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes = [collector.AIXDmiCollector, collector.LinuxDmiCollector]
    collectors = get_ansible_collector(collector_classes)
    assert len(collectors.collectors) == 2
    assert isinstance(collectors.collectors[0], collector.AIXDmiCollector)
    assert isinstance(collectors.collectors[1], collector.LinuxDmiCollector)
    assert isinstance(collectors.collectors[2], CollectorMetaDataCollector)

# Generated at 2022-06-22 22:42:29.641143
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.collector import Collectors

    def list_collectors():
        '''Return a list of collector tuples (subset, name, class).'''
        results = []
        for subset, collectors in Collectors.items():
            for collector_name in collectors:
                results.append((subset, collector_name))

        return results

    def show_collectors(collector_list, sep='\n'):
        '''Return collector list as string.'''
        return sep.join(['(%s, %s)' % (a, b) for a, b in collector_list])


# Generated at 2022-06-22 22:42:38.695730
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import get_all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    namespace = PrefixFactNamespace(prefix='ansible_')

    all_fact_collectors = get_all_collector_classes()

    fact_collector = get_ansible_collector(all_fact_collectors, namespace=namespace)

    collected_facts = fact_collector.collect()
    assert collected_facts

# Generated at 2022-06-22 22:42:49.453809
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    minimal_gather_subset = frozenset(['network', 'virtual'])
    gather_subset = ['all']

    # Unit tests should use a short gather_timeout
    gather_timeout = 1

    filter_spec = []


# Generated at 2022-06-22 22:42:57.904381
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ''' Testing AnsibleFactCollector.collect() '''

    class TestFacts():
        def collect(self, module=None, collected_facts=None):
            return {'ansible_1': 1, 'ansible_2': 2}

    class TestCollector(collector.BaseFactCollector):
        name = 'TestCollector'
        _fact_ids = set(['ansible_1', 'ansible_2'])

        def __init__(self, collectors=None, namespace=None):
            super(TestCollector, self).__init__(collectors=None,
                                                namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return TestFacts().collect(module=module, collected_facts=collected_facts)

    fact_collector = \
        Ans

# Generated at 2022-06-22 22:43:00.978604
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector()

    facts = fact_collector.collect(module=None, collected_facts=None)
    assert facts['gather_subset'] == dict()

