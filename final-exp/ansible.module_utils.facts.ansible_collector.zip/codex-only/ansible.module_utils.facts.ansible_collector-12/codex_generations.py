

# Generated at 2022-06-22 22:32:59.685745
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta = CollectorMetaDataCollector(namespace=None, gather_subset=['all'], module_setup=True)
    assert meta.collect()['gather_subset'] == ['all']



# Generated at 2022-06-22 22:33:03.664076
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all', 'min'], module_setup=True)
    facts_dict = fact_collector.collect()

    expected_facts_dict = {'gather_subset': ['all', 'min'], 'module_setup': True}
    assert facts_dict == expected_facts_dict

# Generated at 2022-06-22 22:33:10.031717
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class CollectedFacts(object):
        def __init__(self):
            self.collected_facts = None

    class TestCollector(object):
        def __init__(self):
            self.collected_facts = None

        def collect(self, module=None, collected_facts=None):
            c = CollectedFacts()
            c.collected_facts = collected_facts
            return {'test_fact': True}

    test_collector = TestCollector()
    to_collect = [test_collector]
    fact_collector = AnsibleFactCollector(collectors=to_collect,
                                          namespace=None)

    result = fact_collector.collect()

    assert result['test_fact'] == True
    assert isinstance(result['test_fact'], bool)
    assert test_collect

# Generated at 2022-06-22 22:33:16.226546
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=True)
    assert fact_collector.name == 'gather_subset'
    assert fact_collector.gather_subset == ['all']
    assert fact_collector.module_setup is True


# Generated at 2022-06-22 22:33:24.600908
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import namespace

    result_facts = {}
    result_collectors = []
    result_collectors.append(ansible.module_utils.facts.collector.BaseFactCollector())
    result_collectors.append(ansible.module_utils.facts.collector.BaseFactCollector())
    result_collectors.append(ansible.module_utils.facts.collector.BaseFactCollector())
    result_collector = ansible.module_utils.facts.collector.AnsibleFactCollector(result_collectors)
    result_collector.collect(None, result_facts)

# Generated at 2022-06-22 22:33:33.835268
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    assert CollectorMetaDataCollector().name == 'gather_subset'
    assert CollectorMetaDataCollector()._fact_ids == set()

    assert CollectorMetaDataCollector(gather_subset=['gather_subset']).gather_subset == ['gather_subset']
    assert CollectorMetaDataCollector(gather_subset=['gather_subset']).module_setup == None
    assert CollectorMetaDataCollector(gather_subset=['gather_subset']).namespace == None

    assert CollectorMetaDataCollector(module_setup=['module_setup']).gather_subset == None
    assert CollectorMetaDataCollector(module_setup=['module_setup']).module_setup == ['module_setup']
    assert CollectorMetaDataCollector(module_setup=['module_setup']).namespace

# Generated at 2022-06-22 22:33:37.511465
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    return AnsibleFactCollector(collectors=None, namespace=None, filter_spec=None)



# Generated at 2022-06-22 22:33:48.073453
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.hardware import hardware_collector

    namespace = collector.SimpleNamespace(base_name='test_ns')
    hardware_collector_obj = hardware_collector.HardwareCollector(namespace=namespace)

    collector_meta_data = CollectorMetaDataCollector(collectors=[hardware_collector_obj],
                                                     namespace=namespace,
                                                     gather_subset='all')
    assert collector_meta_data.collectors == [hardware_collector_obj]
    assert collector_meta_data.namespace.base_name == 'test_ns'
    assert collector_meta_data.gather_subset == 'all'


# Generated at 2022-06-22 22:33:55.735814
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.common.collections import ImmutableDict

    # Set up the environment for the namespace.
    expected_prefix = 'foo'
    namespace = PrefixFactNamespace(expected_prefix)

    # Create an instance of the class we want to test.
    expected_gather_subset = 'all'
    expected_module_setup = True
    instance = CollectorMetaDataCollector(namespace=namespace,
                                          gather_subset=expected_gather_subset,
                                          module_setup=expected_module_setup)

    # Build what we expect to get back.

# Generated at 2022-06-22 22:34:04.799774
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    all_collector_classes = [TestCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           filter_spec=['*'],
                                           gather_subset=['all'])

    collected_facts = fact_collector.collect()
    assert collected_facts['ansible_test_fact'] == 'test_fact'
    assert collected_facts['gather_subset'] == ['all']



# Generated at 2022-06-22 22:34:07.492150
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    if not isinstance(fact_collector, AnsibleFactCollector):
        raise AssertionError()

# Generated at 2022-06-22 22:34:18.318788
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespace

    filter_spec = filter_spec or []
    gather_subset = gather_subset or ['all']
    gather_timeout = gather_timeout or timeout.DEFAULT_GATHER_TIMEOUT

    from ansible.module_utils.facts import collectors

    collector_classes = \
        collector.collector_classes_from_gather_subset(all_collector_classes=collectors.all_collector_classes,
                                                       gather_subset=gather_subset,
                                                       gather_timeout=gather_timeout)

    collectors = []
    for collector_class in collector_classes:
        collector_obj = collector_class(namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
        collectors.append(collector_obj)

    fact

# Generated at 2022-06-22 22:34:29.920770
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    def test_empty_filter_spec():
        collector = AnsibleFactCollector(filter_spec='')
        assert collector.filter_spec == '*'
        collector = AnsibleFactCollector(filter_spec=[])
        assert collector.filter_spec == '*'

    def test_simple_filter_spec():
        collector = AnsibleFactCollector(filter_spec='ansible_*')
        assert collector.filter_spec == 'ansible_*'

    def test_filter_spec_with_list_of_items():
        collector = AnsibleFactCollector(filter_spec=['ansible_*', '*uptime*', '*version*'])
        assert collector.filter_spec == ['ansible_*', '*uptime*', '*version*']

    test_empty_filter_spec()
    test_

# Generated at 2022-06-22 22:34:33.994012
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    meta_facts = CollectorMetaDataCollector(
        gather_subset=['all', 'network', 'hardware'],
        module_setup=True)

    facts = meta_facts.collect()

    assert 'gather_subset' in facts
    assert facts['gather_subset'] == ['all', 'network', 'hardware']
    assert 'module_setup' in facts
    assert facts['module_setup'] is True


# Generated at 2022-06-22 22:34:44.911396
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import json
    import mock

    class FakeBaseCollector( collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'a_fact':'value','another_fact':'another_value'}

    class FakeCollector(FakeBaseCollector ):
        pass

    class NamespacedCollector(FakeBaseCollector ):

        def __init__(self, namespace=None):
            self.namespace = namespace

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'%s.a_fact' % self.namespace: 'namespaced_fact', '%s.other_fact': 'other_fact'}


# Generated at 2022-06-22 22:34:52.892392
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # test gather_subset=['all'] when minimal_gather_subset = ['ansible_distribution','ansible_os_family']
    minimal_gather_subset = ['ansible_distribution','ansible_os_family']
    gather_subset = ['all']
    all_collector_classes = collector.get_collector_classes()
    ansible_fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                                   gather_subset=gather_subset,
                                                   minimal_gather_subset=minimal_gather_subset)
    # this is the minimal set of facts that should be collected
    assert len(ansible_fact_collector.collectors) == 5
    # we should also check the subset used in the collector

# Generated at 2022-06-22 22:35:00.073508
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class MockCollector1(AnsibleFactCollector):
        def collect(self):
            return {'fact1': 'fact1'}

    class MockCollector2(AnsibleFactCollector):
        def collect(self):
            return {'ansible_fact2': 'fact2'}

    fact_collector = AnsibleFactCollector(collectors=[MockCollector1(), MockCollector2()])
    facts = fact_collector.collect()
    assert facts is not None
    assert facts['fact1'] == 'fact1'
    assert facts['ansible_fact2'] == 'fact2'



# Generated at 2022-06-22 22:35:02.210480
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_class = collector.get_collector_class('ping')
    collector_obj = collector_class()
    assert AnsibleFactCollector(collectors=[collector_obj]).collect()['ping'] == 'pong'

if __name__ == '__main__':
    test_AnsibleFactCollector()

# Generated at 2022-06-22 22:35:06.487388
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = \
        CollectorMetaDataCollector(gather_subset=['main', 'others'],
                                   module_setup=True)

    assert fact_collector.gather_subset == ['main', 'others']
    assert fact_collector.module_setup is True


# Generated at 2022-06-22 22:35:14.441995
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import math

    class MathCollector(collector.BaseFactCollector):
        name = 'math'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'pi': math.pi}

    fact_collector = \
        AnsibleFactCollector(collectors=[MathCollector()],
                             filter_spec=['pi'],
                             namespace=None)

    facts_dict = fact_collector.collect()

    assert facts_dict == {'ansible_facts': {'pi': math.pi}}

# Generated at 2022-06-22 22:35:15.052140
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    pass

# Generated at 2022-06-22 22:35:18.572604
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:35:20.794510
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    result = CollectorMetaDataCollector(['all'], True).collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}, result

# Generated at 2022-06-22 22:35:26.360102
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import ansible.module_utils.facts.network.interfaces as netifaces
    import ansible.module_utils.facts.system.distribution as dist

    namespace = collector.FactNamespace('network_')

    if_collector = netifaces.InterfacesCollector(namespace=namespace)
    dist_collector = dist.DistributionCollector(namespace=namespace)

    fact_collector = \
        AnsibleFactCollector(collectors=[if_collector, dist_collector],
                             namespace=namespace)

    new_facts = fact_collector.collect(module=None, collected_facts=None)

    assert 'network_interfaces' in new_facts
    assert 'network_distribution' in new_facts

# Generated at 2022-06-22 22:35:35.366902
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    namespace = collector.Namespace(prefix='ansible_')

    all_collector_classes = [collector.FacterFactCollector,
                             collector.OhaiFactCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespace,
                                           gather_timeout=1,
                                           gather_subset=['network', 'ohai', 'hardware'],
                                           minimal_gather_subset=frozenset(['hardware']))

    assert len(fact_collector.collectors) == 4

    # If a namespace is provided, we should have a PrefixFactNamespace for all collectors

# Generated at 2022-06-22 22:35:44.430566
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Mock a base collector that returns a fact
    class MockFactCollector(collector.BaseFactCollector):
        name = 'mock_fact'

        def __init__(self, namespace=None):
            super(MockFactCollector, self).__init__(namespace=namespace)
            self.facts = {self.name: 'MockFactCollector'}

        def collect(self, module=None, collected_facts=None):
            return self.facts

    # define mock collector classes
    mock_fact_collector_class = MockFactCollector
    ansible_collector_class = ansible_collector.AnsibleCollector

    # Mock the fact

# Generated at 2022-06-22 22:35:48.819526
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                               module_setup=True)
    facts_dict = collector_obj.collect()

    assert facts_dict == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-22 22:35:56.656922
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import copy
    class TestFactCollector(collector.BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['foo'] = 'A'
            collected_facts['bar'] = 'B'
            collected_facts['git'] = 'C'
            return collected_facts

    class TestFactCollector2(collector.BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['bar'] = 'B2'
            collected_facts['git'] = 'C2'
            return collected_facts

    class HashableDict(dict):
        def __hash__(self):
            return 1


# Generated at 2022-06-22 22:36:06.312901
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # test gather_subset is defined in CollectorMetaDataCollector
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['network'], module_setup=False)
    result_dict = collector_meta_data_collector.collect()
    gather_subset_dict = result_dict['gather_subset']
    assert(gather_subset_dict == ['network'])

    # test module_setup is defined in CollectorMetaDataCollector
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['network'], module_setup=True)
    result_dict = collector_meta_data_collector.collect()
    module_setup_dict = result_dict['module_setup']
    assert(module_setup_dict == True)



# Generated at 2022-06-22 22:36:13.778930
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector()
    assert collector_meta_data_collector.collect() == {
        'gather_subset': None
    }
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    assert collector_meta_data_collector.collect() == {
        'gather_subset': ['all']
    }
    collector_meta_data_collector = CollectorMetaDataCollector(module_setup=True)
    assert collector_meta_data_collector.collect() == {
        'module_setup': True
    }


if __name__ == '__main__':
    # ansible facts modules that can be called via command line for debugging
    import ansible.module_utils.facts.virtual as virtual

# Generated at 2022-06-22 22:36:22.633964
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    # gather_subset is non-empty
    gather_subset = ['all']
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
    assert collector_meta_data_collector.gather_subset == gather_subset

    # gather_subset is empty
    gather_subset = []
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
    assert collector_meta_data_collector.gather_subset == gather_subset

    # gather_subset is None
    gather_subset = None
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
    # gather_subset is set to empty

# Generated at 2022-06-22 22:36:26.677191
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    all_collector_classes = collector.get_fact_collector_classes()
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    collected_facts = fact_collector.collect()
    assert 'ansible_facts' in collected_facts

# Generated at 2022-06-22 22:36:34.384943
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollector(collector.BaseFactCollector):
        name = 'mockcollector'
        _fact_ids = ['mockcollector_key']

        def collect(self, module=None, collected_facts=None):
            return {'mockcollector_key': 'mockcollector_value'}

    class MockCollector2(collector.BaseFactCollector):
        name = 'mockcollector2'
        _fact_ids = ['mockcollector2_key']

        def collect(self, module=None, collected_facts=None):
            return {'mockcollector2_key': 'mockcollector2_value'}

    class MockCollector3(collector.BaseFactCollector):
        name = 'mockcollector3'

# Generated at 2022-06-22 22:36:40.015152
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    meta_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=True)

    ret = meta_collector.collect()
    assert ret['gather_subset'] == ['all']
    assert ret.get('module_setup') is True

# Generated at 2022-06-22 22:36:45.577570
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils import facts

    fact_collector = \
        get_ansible_collector(all_collector_classes=facts.CORE_PLUGINS,
                              namespace=None,
                              filter_spec=None,
                              gather_subset='all',
                              gather_timeout=None,
                              minimal_gather_subset=None)

    facts = fact_collector.collect()
    assert facts['gather_subset'] == ['all']

# Generated at 2022-06-22 22:36:47.949634
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # This is an example test to demonstrate functionality.
    # If this module changes to become actual code, this test should be updated.
    assert True

# Generated at 2022-06-22 22:36:48.956996
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO
    pass

# Generated at 2022-06-22 22:36:56.241317
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import namespace

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='all',
                                   module_setup=True)
    ns = namespace.PrefixFactNamespace(prefix='ansible_')
    fact_collector = \
        AnsibleFactCollector(collectors=[collector_meta_data_collector],
                             namespace=ns)

    meta_facts = fact_collector.collect()
    assert meta_facts['ansible_facts']['gather_subset'] == 'all'
    assert meta_facts['ansible_facts']['module_setup']



# Generated at 2022-06-22 22:37:01.516780
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector([], namespace='ansible_')

    assert fact_collector.collectors == []
    assert fact_collector.namespace == 'ansible_'
    # Check that filter_spec defaults to 'None'
    assert fact_collector.filter_spec is None

# Generated at 2022-06-22 22:37:11.404372
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    my_meta_data_obj = CollectorMetaDataCollector()
    assert my_meta_data_obj.name == 'gather_subset'
    assert my_meta_data_obj._fact_ids == set()
    assert my_meta_data_obj.gather_subset is None
    assert my_meta_data_obj.collectors is None
    assert my_meta_data_obj.namespace is None
    assert my_meta_data_obj.module_setup is None

    my_meta_data_obj = CollectorMetaDataCollector(
        collectors=None,
        namespace=None,
        gather_subset=['all'],
        module_setup=False)

    assert my_meta_data_obj.name == 'gather_subset'
    assert my_meta_data_obj._fact_ids == set

# Generated at 2022-06-22 22:37:21.099375
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace

    my_collector = ansible_collector.AnsibleFactCollector(namespace=namespace.PrefixFactNamespace('ansible_'))


# Generated at 2022-06-22 22:37:24.554503
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # pylint: disable=too-many-arguments
    CollectorMetaDataCollector(collectors=None,
                               namespace=None,
                               gather_subset=None,
                               module_setup=None)

# Generated at 2022-06-22 22:37:31.278556
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import NamespacedCollectorMetaDataCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector

    class MockCollector(Collector):
        name = 'x'
        _fact_ids = set(['a','b','c'])

        def collect(self, module=None, collected_facts=None):
            return {'a': 'b', 'c': 'd'}

    class Mock2Collector(Collector):
        name = 'y'
        _fact_ids = set(['a','b','c'])



# Generated at 2022-06-22 22:37:33.765291
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit: test for get_ansible_collector.'''
    # Should not fail on arguments.
    get_ansible_collector(all_collector_classes={},
                          minimal_gather_subset={'all'},
                          gather_subset={'all'})



# Generated at 2022-06-22 22:37:45.313892
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all', '!min'],
                                   module_setup=True)

    result = collector_meta_data_collector.collect()
    assert 'gather_subset' in result
    assert 'module_setup' in result
    assert result['gather_subset'] == ['all', '!min']
    assert result['module_setup'] is True

    # Now with no gather_subset and no module_setup
    collector_meta_data_collector = \
        CollectorMetaDataCollector()

    result = collector_meta_data_collector.collect()
    assert 'gather_subset' not in result
    assert 'module_setup' not in result



# Generated at 2022-06-22 22:37:49.200395
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = \
            CollectorMetaDataCollector(gather_subset=['all'],
                                       module_setup=True)
    fact_collector.collect()

# Generated at 2022-06-22 22:37:56.849262
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    pass_filter = ['ansible_date', 'ansible_hostname']
    fail_filter = ['ansible_hostname', 'ansible_date']
    actual = CollectorMetaDataCollector(gather_subset=pass_filter).collect()['gather_subset']
    assert actual == pass_filter
    actual = CollectorMetaDataCollector(gather_subset=fail_filter).collect()['gather_subset']
    assert actual == fail_filter


# Generated at 2022-06-22 22:38:01.265244
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector(): # pylint: disable=missing-docstring
    obj = CollectorMetaDataCollector()
    assert obj.gather_subset == None

    obj = CollectorMetaDataCollector(gather_subset='all')
    assert obj.gather_subset == 'all'


# Generated at 2022-06-22 22:38:09.457318
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=['all'])
    assert c.collect() == {'gather_subset': ['all']}
    c = CollectorMetaDataCollector(module_setup=True)
    assert c.collect() == {'module_setup': True}
    c = CollectorMetaDataCollector(module_setup=True, gather_subset=['all'])
    assert c.collect() == {'module_setup': True, 'gather_subset': ['all']}

# Generated at 2022-06-22 22:38:21.218290
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector = AnsibleFactCollector(collectors=[], namespace=None)
    assert collector.collectors == []
    assert collector.namespace is None
    assert collector.filter_spec == []

    collector = AnsibleFactCollector(collectors=[], namespace=None, filter_spec='systemd')
    assert collector.collectors == []
    assert collector.namespace is None
    assert collector.filter_spec == ['systemd']

    collector = AnsibleFactCollector(collectors=[], namespace=None, filter_spec='')
    assert collector.collectors == []
    assert collector.namespace is None
    assert collector.filter_spec == '*'

    collector = AnsibleFactCollector(collectors=[], namespace=None, filter_spec=['systemd'])
    assert collector.collectors == []

# Generated at 2022-06-22 22:38:24.544339
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # Create a CollectorMetaDataCollector object
    test_collector = CollectorMetaDataCollector('collectors', 'namespace', 'gather_subset', True)

    # Call method collect and test the results
    test_results = test_collector.collect(module='module', collected_facts='collected_facts')
    assert test_results['gather_subset'] == 'gather_subset'
    assert test_results['module_setup']


# Generated at 2022-06-22 22:38:30.060154
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    class testCollector(CollectorMetaDataCollector):
        name = 'test'
        _fact_ids = frozenset(['test'])

    collector = testCollector(gather_subset=['all'], module_setup=True)
    facts = collector.collect()
    assert (facts.get('test', {}).get('gather_subset') == ['all'])

# Generated at 2022-06-22 22:38:40.369938
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Empty fact set
    fact_collector = AnsibleFactCollector()
    collected_facts = fact_collector.collect()
    assert {} == collected_facts

    # Single fact
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector(fact_ids=['a'])])
    collected_facts = fact_collector.collect()
    assert {'a': {}} == collected_facts

    # Two facts, one with a namespace
    fact_collector = AnsibleFactCollector(collectors=[
        collector.BaseFactCollector(fact_ids=['a']),
        collector.BaseFactCollector(facts={'some.name': {'b': 1}}, namespace='some')])
    collected_facts = fact_collector.collect()

# Generated at 2022-06-22 22:38:46.098359
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=False)
    result_dict = \
        meta_data_collector.collect(module=None,
                                    collected_facts=None)
    assert result_dict == {'gather_subset': ['all'],
                           'module_setup': False}



# Generated at 2022-06-22 22:38:55.769521
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    collectors = all_collector_classes()
    assert collectors

    collect = get_ansible_collector(collector_classes=collectors,
                                    gather_subset=['all'])
    assert collect
    assert isinstance(collect, AnsibleFactCollector)

    facts = collect.collect(module=None, collected_facts={'test': 'foo'})
    assert facts
    assert facts.get('test') == 'foo'
    assert facts.get('ansible_facts')
    assert facts.get('ansible_facts').get('gather_subset')

    #
    # test namespace
    #

    namespace_prefix = 'vendor_'
    namespace

# Generated at 2022-06-22 22:39:02.924389
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collectors = None
    filter_spec = None
    namespace = None

    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          filter_spec=filter_spec,
                                          namespace=namespace)

    assert fact_collector.collectors == collectors
    assert fact_collector.filter_spec == filter_spec
    assert fact_collector.namespace == namespace


# Generated at 2022-06-22 22:39:07.994413
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Initialize the arguments
    meta_collector_obj = CollectorMetaDataCollector(collectors=None, namespace=None,
                                                    gather_subset=[],
                                                    module_setup=None)
    # Call the method
    meta_facts = meta_collector_obj.collect()
    # Assert the result
    assert meta_facts.get('gather_subset') == []


# Unit tests for method get_ansible_collector

# Generated at 2022-06-22 22:39:11.228081
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collect = CollectorMetaDataCollector(module_setup=True, gather_subset=['all', 'network'])
    assert collect.module_setup
    assert collect.gather_subset == ['all', 'network']

# Generated at 2022-06-22 22:39:11.884468
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-22 22:39:17.760937
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(['all'], module_setup='ansible_facts.setup')
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == 'ansible_facts.setup'



# Generated at 2022-06-22 22:39:22.408146
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_collector = CollectorMetaDataCollector(gather_subset='all', module_setup='True')

    # Check that facts are collected
    assert test_collector.collect() == {'gather_subset': 'all', 'module_setup': 'True'}



# Generated at 2022-06-22 22:39:31.017294
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_collector_name = 'test_collector_name'
    test_collector_gather_subset = 'test_collector_gather_subset'
    test_collector_module_setup = True
    test_collector = CollectorMetaDataCollector(gather_subset=[test_collector_gather_subset],
                                                module_setup=test_collector_module_setup)
    test_fact_dict = test_collector.collect()

    assert test_fact_dict['gather_subset'] == [test_collector_gather_subset]
    assert test_fact_dict['module_setup'] == test_collector_module_setup

# Generated at 2022-06-22 22:39:40.016451
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unitest for method collect of class CollectorMetaDataCollector'''

    # Test: gather_subset is set
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'])
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'],
                                                       'module_setup': True}

    # Test: module_setup is set
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=None, module_setup=None)
    assert collector_meta_data_collector.collect() == {'gather_subset': None,
                                                       'module_setup': None}

# Generated at 2022-06-22 22:39:43.737192
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta = CollectorMetaDataCollector(gather_subset=['all'])
    facts = meta.collect()
    assert 'all' == facts['gather_subset']
    assert 'module_setup' in facts


# Generated at 2022-06-22 22:39:49.767713
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gsubset = ['foo', 'bar']
    module_setup = True
    collector_meta_data_collector = CollectorMetaDataCollector(gsubset, module_setup)
    collected_facts = collector_meta_data_collector.collect()
    assert(collected_facts == {'gather_subset': gsubset, 'module_setup': module_setup})

# Generated at 2022-06-22 22:39:58.876551
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ansible_collector=get_ansible_collector()

    assert isinstance(ansible_collector, AnsibleFactCollector)

    # Test collector registry
    ansible_collector.register_collector(collector.DistributionCollector)
    ansible_collector.register_collector(collector.PlatformCollector)

    # Test collector instantiation
    assert len(ansible_collector.collectors) == 3
    assert len([collector_obj for collector_obj in ansible_collector.collectors
                if isinstance(collector_obj, collector.DistributionCollector)]) == 1
    assert len([collector_obj for collector_obj in ansible_collector.collectors
                if isinstance(collector_obj, collector.PlatformCollector)]) == 1

    # Test collect
    ansible_collect

# Generated at 2022-06-22 22:40:06.576911
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''
    Test for CollectorMetaDataCollector
    '''

    collector = CollectorMetaDataCollector(namespace='ansible',
                                           gather_subset=['all'],
                                           module_setup=True)
    module = None
    collected_facts = {}
    facts = collector.collect(module, collected_facts)
    assert facts['ansible_gather_subset'] == ['all']



# Generated at 2022-06-22 22:40:08.117545
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert fact_collector



# Generated at 2022-06-22 22:40:17.469350
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import ohai
    from ansible.module_utils.facts import script
    from ansible.module_utils.facts import systemd
    from ansible.module_utils.facts import systemd_hostname
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import cloud
    from ansible.module_utils.facts import zpool

    all_collector_classes = dict()
    all_collector_classes.update(default.AllCollectorClasses())
    all_collector_classes.update(network.AllCollectorClasses())

# Generated at 2022-06-22 22:40:26.889551
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # any import statements needed to load your module(s)
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.network.distribution import NetworkCollector
    from ansible.module_utils.facts.namespace.prefix import PrefixFactNamespace

    # collect facts without any namespace
    namespace = None
    fact_collector = AnsibleFactCollector(
        collectors=[DistributionFactCollector(namespace=namespace)],
        namespace=namespace
    )
    facts = fact_collector.collect()
    assert 'distribution' in facts
    assert facts['distribution']['distribution'] in collector.DISTRIBUTION_REPO_MAP.keys()

    # collect facts with namespace
    namespace

# Generated at 2022-06-22 22:40:37.359877
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''
    Ensure CollectorMetaDataCollector.collect() produces correct output for different input values
    '''
    collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert collector.collect() == {'gather_subset': 'all', 'module_setup': True}

    collector = CollectorMetaDataCollector(gather_subset='all', module_setup=None)
    assert collector.collect() == {'gather_subset': 'all'}

    collector = CollectorMetaDataCollector(gather_subset=None, module_setup=True)
    assert collector.collect() == {'module_setup': True}

    collector = CollectorMetaDataCollector(gather_subset=None, module_setup=None)
    assert collector.collect() == {}

# Generated at 2022-06-22 22:40:46.036008
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils._text import to_native
    import pprint
    pp = pprint.PrettyPrinter(indent=4)
    module = {}
    all_collector_classes = collector.all_collector_classes(module=module)
    C = get_ansible_collector(all_collector_classes,
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)
    try:
        C.collect(module=None, collected_facts=None)
    except Exception as e:
        sys.stderr.write(to_native(e))
        sys.stderr.write('\n')

# Generated at 2022-06-22 22:40:54.892292
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    my_collector = AnsibleFactCollector(collectors=[], namespace=None, filter_spec=None)
    my_collector._filter({'a': 'b'}, ['*'])
    my_collector._filter({'a': 'b'}, ['*', 'c'])
    my_collector._filter({'a': 'b'}, '*')
    my_collector._filter({'a': 'b'}, '')
    my_collector._filter({'a': 'b'}, [])
    my_collector._filter({'a': 'b'}, ['c'])
    my_collector._filter({'a': 'b'}, ['a'])
    my_collector.collectors = [{}, {}]
    my_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-22 22:41:04.762999
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.all import AllFactCollector

    collected_facts = {}
    s = frozenset()
    assert (get_ansible_collector(all_collector_classes=collector.collectors,
                                  namespace=None,
                                  filter_spec=None,
                                  gather_subset=None,
                                  gather_timeout=None,
                                  minimal_gather_subset=s))

    assert (get_ansible_collector(all_collector_classes=collector.collectors,
            namespace='',
            filter_spec=[],
            gather_subset=['all'],
            gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
            minimal_gather_subset=s))


# Generated at 2022-06-22 22:41:14.329294
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.collector.parsers.facter import FacterCollector
    from ansible.module_utils.facts.collector.parsers.ohai import OhaiCollector

    facter_collector = FacterCollector()
    ohai_collector = OhaiCollector()

    fact_collector = AnsibleFactCollector(collectors=[facter_collector, ohai_collector])

    facts = fact_collector.collect()
    assert 'facter' in facts
    assert 'ohai' in facts
    assert 'ansible_facts' in facts
    assert 'facter' in facts['ansible_facts']
    assert 'ohai' in facts['ansible_facts']

    prefix_fact_collector = Ansible

# Generated at 2022-06-22 22:41:19.347668
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # create AnsibleFactCollector
    c = CollectorMetaDataCollector()

    # test the name property
    assert c.name == 'gather_subset'

    # test the _fact_ids property
    assert len(c._fact_ids) == 0

    # test the _collectors property
    assert c._collectors == []

    # test the _namespace property
    assert c._namespace == None

    # test the collect() method
    assert c.collect() == {'gather_subset': None}

# Generated at 2022-06-22 22:41:23.554553
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_data = CollectorMetaDataCollector(gather_subset=['hardware'],
                                           module_setup=False)
    fact_dict = meta_data.collect()
    assert fact_dict['gather_subset'] == ['hardware']
    assert fact_dict['module_setup'] == False

# Generated at 2022-06-22 22:41:32.968744
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    try:
       import unittest2 as unittest  # python < 2.7
    except ImportError:
        import unittest

    class Test_get_ansible_collector(unittest.TestCase):
        """Tests for function ``get_ansible_collector``."""

        def test_gather_facts_with_facts_filter_spec(self):
            """Test function with some facts filter spec."""
            from ansible.module_utils.facts import namespace

            # test with all supported facts

# Generated at 2022-06-22 22:41:39.049306
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    all_collector_classes = []

    fact_collector = \
        CollectorMetaDataCollector(all_collector_classes,
                                   gather_subset=['all'],
                                   module_setup=True)
    fact_dict = fact_collector.collect()

    assert fact_dict == {'gather_subset': ['all'], 'module_setup': True}



# Generated at 2022-06-22 22:41:50.177857
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace as facts_namespace
    import ansible.module_utils.facts.system.distribution as facts_distribution
    import ansible.module_utils.facts.system.distribution.redhat as facts_distribution_redhat
    import ansible.module_utils.facts.system.distribution.rpm as facts_distribution_rpm

    filter_spec = ['system.*', 'facter.fact']

    namespace_redhat = facts_namespace.PrefixFactNamespace(prefix='ansible_')
    namespace_rpm = facts_namespace.PrefixFactNamespace(prefix='rpm_')


# Generated at 2022-06-22 22:41:55.142223
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts['gather_subset'] == ['all']

# Generated at 2022-06-22 22:42:01.886621
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.collector_classes_from_gather_subset(gather_subset=['all'])
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)

    facts = fact_collector.collect()
    assert 'gather_subset' in facts
    assert 'all' in facts['gather_subset']

    print('get_ansible_collector passed all tests')

# Generated at 2022-06-22 22:42:05.185379
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    CollectorMetaDataCollector(None, None, ['all'], True)
    CollectorMetaDataCollector(None, None, ['all']).collect(None, None)
    CollectorMetaDataCollector(None, None, ['all'], False).collect(None, None)

# Generated at 2022-06-22 22:42:17.600979
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # test a Collector that returns just a simple fact

    try:
        from ansible.module_utils.facts import test_collectors
    except ImportError:
        # unit test not setup correctly?
        return

    import time

    class test_collector1(collector.BaseFactCollector):
        name = 'test1'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {'test1_fact': 't1_fact'}

    class test_collector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            time.sleep(1)

# Generated at 2022-06-22 22:42:28.460114
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    collectors = []
    namespace = 'ansible'
    gather_subset = ['hardware']
    module_setup = [True]

    for collector_class in collectors:
        collector_obj = collector_class(namespace=namespace)
        collectors.append(collector_obj)

    # Add a collector that knows what gather_subset we used so it it can provide a fact
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=True)
    collectors.append(collector_meta_data_collector)
    print(collectors)
    print(collector_meta_data_collector)
    


# Generated at 2022-06-22 22:42:41.148375
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class FakeFactsCollector(collector.BaseFactCollector):

        name = 'fake_facts1'
        _fact_ids = set(['foo', 'bar'])

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            facts_dict = {}
            facts_dict['foo'] = 'foo_value'
            facts_dict['bar'] = 'bar_value'
            return facts_dict

    class FakeFactsCollector2(collector.BaseFactCollector):

        name = 'fake_facts2'
        _fact_ids = set(['foo2', 'bar2'])


# Generated at 2022-06-22 22:42:50.476680
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Situation 1:
    # Input: gather_subset = ['all', 'network'], module_setup=true
    # Expected output:
    # {
    #   'gather_subset': ['all', 'network'],
    #   'module_setup': true
    # }
    # Situation 2:
    # Input: gather_subset = ['minimal'], module_setup=false
    # Expected output:
    # {
    #   'gather_subset': ['minimal'],
    #   'module_setup': false
    # }
    collector_meta_data_collector_1 = CollectorMetaDataCollector(gather_subset=['all', 'network'],
                                                                 module_setup=True)


# Generated at 2022-06-22 22:42:58.130969
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import hardware

    all_collector_classes = \
        default.default_collectors + network.network_collectors + hardware.hardware_collectors

    namespace = None
    filter_spec = None
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()
