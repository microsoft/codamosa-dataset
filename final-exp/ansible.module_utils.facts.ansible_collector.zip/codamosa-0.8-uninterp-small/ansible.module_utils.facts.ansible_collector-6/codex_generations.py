

# Generated at 2022-06-24 21:27:41.899755
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    cd = CollectorMetaDataCollector(gather_subset='all',
                                    module_setup=True)

    actual = cd.collect()
    expected = {'gather_subset': 'all', 'module_setup': True}

    assert actual == expected

# Generated at 2022-06-24 21:27:50.976447
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.distribution.darwin as distribution_darwin
    all_collector_classes = [collector.Collector,
                             distribution.Distribution,
                             distribution_darwin.DistributionDarwin]

    fact_collector_0 = get_ansible_collector(all_collector_classes=all_collector_classes,
                                             gather_subset=['all'],
                                             gather_timeout=None,
                                             minimal_gather_subset=['all'])

    #import pdb; pdb.set_trace()

#import os
#import sys

#sys.path.append(os.path.join(os.path.dirname(__file__), "..

# Generated at 2022-06-24 21:28:02.226016
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.collector_classes_from_gather_subset(gather_subset=['all'])
    ansible_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes)
    collected_facts = ansible_collector.collect(module=None)
    assert collected_facts is not None
    assert 'ansible_facts' in collected_facts
    assert 'gather_subset' in collected_facts['ansible_facts']


if __name__ == '__main__':

    # test_case_0()

    test_get_ansible_collector()

    # import doctest
    # doctest.testmod()

# Generated at 2022-06-24 21:28:06.654682
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_collector = get_ansible_collector(all_collector_classes=[],
                                              namespace=None,
                                              filter_spec=None,
                                              gather_subset=None,
                                              gather_timeout=None,
                                              minimal_gather_subset=None)

    assert isinstance(ansible_collector, AnsibleFactCollector)



# Generated at 2022-06-24 21:28:11.863325
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    CollectorMetaDataCollector(gather_subset = 'gather_subset', module_setup = 'module_setup')
    result = CollectorMetaDataCollector.collect()
    assert result == {'gather_subset': 'gather_subset', 'module_setup': 'module_setup'}


# Generated at 2022-06-24 21:28:17.882747
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ansible_fact_collector_1 = CollectorMetaDataCollector(gather_subset=['!all'])
    ansible_fact_inst = ansible_fact_collector_1.collect()
    assert ansible_fact_inst['gather_subset'] == ['!all']
    assert 'module_setup' not in ansible_fact_inst


# Generated at 2022-06-24 21:28:21.568523
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gather_subset = ['all']
    fact_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
    facts = fact_collector.collect()
    assert facts['gather_subset'] == gather_subset

# Generated at 2022-06-24 21:28:30.482868
# Unit test for method collect of class CollectorMetaDataCollector

# Generated at 2022-06-24 21:28:35.367310
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    avc_0 = AnsibleFactCollector()
    test_dict_0 = {}
    avc_0.collect(collected_facts=test_dict_0)
    assert test_dict_0.keys() == ['facter', 'ansible_facts', 'ohai']


# Generated at 2022-06-24 21:28:41.028449
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_facts = CollectorMetaDataCollector(['all'], True).collect()

    assert meta_facts['gather_subset'] == ['all']
    assert meta_facts['module_setup'] is True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:28:48.350336
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ansible_fact_collector_0 = \
        CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    result = ansible_fact_collector_0.collect()
    assert result == {'gather_subset': 'all', 'module_setup': True}


# Generated at 2022-06-24 21:28:50.047367
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_obj = CollectorMetaDataCollector(gather_subset=["all"], namespace="test_namespace")
    test_obj.collect()



# Generated at 2022-06-24 21:28:59.728910
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import inspect
    if not 'unittest' in sys.modules:
        import unittest
    class_under_test = get_module_class(module_name='ansible.module_utils.facts.core', class_name='CollectorMetaDataCollector')
    method_under_test = inspect.getargspec(class_under_test.collect)
    if 'module' not in method_under_test.args:
        raise RuntimeError('method collect() does not have "module" as first argument')
    if 'collected_facts' not in method_under_test.args:
        raise RuntimeError('method collect() does not have "collected_facts" as second argument')
    if len(method_under_test.args) > 2:
        raise RuntimeError('method collect() does have additional arguments')


# Generated at 2022-06-24 21:29:05.721478
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class AnsibleFactCollectorTest(AnsibleFactCollector):
        def dummy_collect(self):
            return {'a': 1}

    fact_collector = AnsibleFactCollector(
        collectors=[AnsibleFactCollectorTest()]
    )

    assert fact_collector.collect() == {'a': 1}

# Generated at 2022-06-24 21:29:09.290560
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = collector.CollectorRegistry(namespace=collector.BaseFactNamespace())

    ansible_fact_collector = AnsibleFactCollector(collectors=[fact_collector])

    assert isinstance(ansible_fact_collector.collect(), dict)

# Generated at 2022-06-24 21:29:13.992532
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    instance = CollectorMetaDataCollector(all)
    collected_facts = {}
    ansible_fact_collector = instance.collect(collected_facts)
    assert ansible_fact_collector == {'all'}

# Generated at 2022-06-24 21:29:16.855539
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # Run the method with different parameters
    result = CollectorMetaDataCollector().collect()

    assert result['gather_subset'] == ['all']


# Generated at 2022-06-24 21:29:19.413349
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}


# Generated at 2022-06-24 21:29:25.443736
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    coll1 = CollectorMetaDataCollector(gather_subset='default')
    coll2 = CollectorMetaDataCollector(gather_subset='default', module_setup=False)
    assert coll1.collect() == {'gather_subset': 'default'}
    assert coll2.collect() == {'gather_subset': 'default', 'module_setup': False}


# Generated at 2022-06-24 21:29:28.058094
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    metadata_collector = CollectorMetaDataCollector()
    metadata = metadata_collector.collect()
    assert isinstance(metadata,dict)
    assert 'gather_subset' in metadata


# Generated at 2022-06-24 21:29:37.164049
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-24 21:29:39.990641
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}


# Generated at 2022-06-24 21:29:44.511206
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # test an empty collector.
    result = get_ansible_collector(all_collector_classes={})
    assert isinstance(result, AnsibleFactCollector)



# Generated at 2022-06-24 21:29:55.939046
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    def ns(s):
        return s + '_namespace'

    global_namespace = ''

    all_collector_classes = [1, 2, 3]
    namespace = [ns(i) for i in all_collector_classes]
    filter_spec = '*'
    gather_subset = ['all', 'pinky']
    gather_timeout = 1337
    minimal_gather_subset = ['toad']


# Generated at 2022-06-24 21:30:02.050122
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()

if __name__ == '__main__':

    # This is a simple test to check if the class & methods are defined.
    test_case_0()
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:30:14.230000
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Module import
    from ansible.module_utils.facts import collectors

    # Initialising "gather_subset" to None
    gather_subset = None
    # Initialising "filter_spec" to None
    filter_spec = None
    # Initialising "minimal_gather_subset" to None
    minimal_gather_subset = None
    # Call method to get the ansible collector
    ansible_fact_collector = get_ansible_collector(all_collector_classes=collectors,
                                                   gather_subset=gather_subset,
                                                   filter_spec=filter_spec,
                                                   minimal_gather_subset=minimal_gather_subset)
    # Check if ansible_fact_collector is not None

# Generated at 2022-06-24 21:30:19.044109
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_case_0()

if __name__ == '__main__':
    print('Starting facts_module tests')
    test_AnsibleFactCollector_collect()
    print('facts_module tests finished')

# Generated at 2022-06-24 21:30:23.560296
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.all_collector_classes()
    ansible_fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert isinstance(ansible_fact_collector, collector.BaseFactCollector)

# Generated at 2022-06-24 21:30:31.248743
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # test case 1:
    # query_module_args = {'gather_subset': '!all'}
    all_collector_classes = \
        collector.get_collector_classes(path_list=sys.path)
    fact_collector_1 = get_ansible_collector(all_collector_classes,
                                             gather_subset=['!all'])

    # test case 2:
    # query_module_args = {'gather_subset': 'all'}
    all_collector_classes = \
        collector.get_collector_classes(path_list=sys.path)
    fact_collector_2 = get_ansible_collector(all_collector_classes,
                                             gather_subset=['all'])


# test for function collector_classes_

# Generated at 2022-06-24 21:30:42.894747
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.platform

    from ansible.module_utils.facts.collector import network
    from ansible.module_utils.facts.collector import hardware
    from ansible.module_utils.facts.collector import virtual
    from ansible.module_utils.facts.collector import system
    from ansible.module_utils.facts.collector import pkg_mgr
    from ansible.module_utils.facts.collector import platform

# Generated at 2022-06-24 21:30:51.220930
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=None,
                                           gather_subset=['all'],
                                           gather_timeout=None,
                                           namespace=None,
                                           filter_spec=None,
                                           minimal_gather_subset=None)


# Generated at 2022-06-24 21:30:54.835362
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Tests basic functionality with empty dicts of all collectors.
    ansible_fact_collector_0 = AnsibleFactCollector()
    results_0 = ansible_fact_collector_0.collect()

    assert results_0 == {}


# Generated at 2022-06-24 21:30:59.116568
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # obj initialization
    ansible_fact_collector_1 = AnsibleFactCollector(collectors=None, filter_spec=None, namespace=None)
    
    # method collect call
    ansible_fact_collector_1.collect(module=None)
    
    # check the attributes of obj
    assert ansible_fact_collector_1.filter_spec == None

# Generated at 2022-06-24 21:31:06.964854
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=[collector.FacterCollector,
                                                     collector.OhaiCollector,
                                                     collector.NetworkCollector,
                                                     collector.HardwareCollector,
                                                     collector.PlatformCollector],
                              filter_spec=['ansible_*'],
                              gather_subset=['all'],
                              gather_timeout=10,
                              minimal_gather_subset=[])

# Generated at 2022-06-24 21:31:13.321175
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    fact_collector = get_ansible_collector(all_collector_classes=get_collector_classes(), namespace=PrefixFactNamespace(prefix='ansible_'))
    print(fact_collector)
    assert fact_collector is not None
    assert fact_collector.collectors
    assert fact_collector.filter_spec is None
    assert fact_collector.namespace is not None

# Generated at 2022-06-24 21:31:15.278228
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:31:20.015072
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=collector.ALL_COLLECTOR_CLASSES)

    # Get the list of collectors that would be used
    collectors_list = ansible_fact_collector.collectors

    # Check that the CollectorMetaDataCollector is the last one
    assert isinstance(collectors_list[-1], CollectorMetaDataCollector)


# Generated at 2022-06-24 21:31:29.458378
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # test no collectors
    afc = AnsibleFactCollector()
    try:
        collected_facts = afc.collect()
    except SystemExit as e:
        assert e.code == 0
    except Exception as e:
        pytest.fail("Failed to call afc.collect() with no collectors, Exception: %s" % e)
    else:
        assert collected_facts == {}, "Failed to call afc.collect() with no collectors"

    # test with mock collectors using MockCollector
    afc = AnsibleFactCollector([MockCollector(), MockCollector()])
    try:
        collected_facts = afc.collect()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-24 21:31:36.840804
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = \
        get_ansible_collector(all_collector_classes=collector.collector_classes(),
                              namespace=collector.ad_hoc_namespace(),
                              filter_spec=None,
                              gather_subset=['all'],
                              gather_timeout=10,
                              minimal_gather_subset=collector.MINIMAL_FACT_SUBSET)

    assert(fact_collector)
    facts = fact_collector.collect()
    assert(facts)

# Generated at 2022-06-24 21:31:48.561658
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import disk
    from ansible.module_utils.facts import memory
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import collector

    disable_collector_names = frozenset(['hardware'])
    all_collector_classes = frozenset(collector.collector_class_map(disable_collector_names=disable_collector_names))

    gather_timeout = 1
    gather_subset = ['all']
    minimal_gather_subset = frozenset()
    filter_spec = ['']


# Generated at 2022-06-24 21:31:54.027514
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:31:55.516918
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()

# Generated at 2022-06-24 21:31:59.428119
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector(all_collector_classes=set(),
                                                   filter_spec=[],
                                                   gather_subset=[],
                                                   gather_timeout=0,
                                                   minimal_gather_subset=set())
    assert ansible_fact_collector

# Generated at 2022-06-24 21:32:02.466722
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector._filter = MagicMock(return_value=['test'])
    assert ansible_fact_collector.collect() == ['test']


# Generated at 2022-06-24 21:32:04.441317
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    print(ansible_fact_collector_0.collect())

# Generated at 2022-06-24 21:32:05.983669
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    AnsibleFactCollector().collect()



# Generated at 2022-06-24 21:32:17.063959
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_1 = AnsibleFactCollector()
    ansible_fact_collector_2 = AnsibleFactCollector()
    ansible_fact_collector_3 = AnsibleFactCollector()
    ansible_fact_collector_4 = AnsibleFactCollector()
    ansible_fact_collector_5 = AnsibleFactCollector()
    ansible_fact_collector_6 = AnsibleFactCollector()
    ansible_fact_collector_7 = AnsibleFactCollector()
    ansible_fact_collector_8 = AnsibleFactCollector()
    ansible_fact_collector_9 = AnsibleFactCollector()
    ansible_fact_collector_10 = AnsibleFactCollector()
   

# Generated at 2022-06-24 21:32:29.847414
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.system import SystemFactCollector

    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collectors = [
        NetworkFactCollector(namespace=PrefixFactNamespace(prefix='ansible_')),
        SystemFactCollector(namespace=PrefixFactNamespace(prefix='ansible_'))
    ]
    ansible_fact_collector_0.namespace = PrefixFactNamespace(prefix='ansible_')
    result_0 = ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:32:32.910351
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector(_collectors=[])

    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:32:35.965022
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    # AssertionError: expected {} == {'ansible_avalue': 4}
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:32:51.448229
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=[])
    assert fact_collector
    assert fact_collector.collectors
    assert len(fact_collector.collectors) == 1
    assert fact_collector.collectors[0].name == 'gather_subset'
    assert fact_collector.filter_spec == []

    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           gather_subset=['all', 'network'])
    assert fact_collector
    assert fact_collector.collectors
    assert len(fact_collector.collectors) == 1
    assert fact_collector.collectors[0].name == 'gather_subset'
    assert fact_collector.filter_spec == []

    fact_

# Generated at 2022-06-24 21:32:53.103909
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()

    # call method collect on object ansible_fact_collector_0
    ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:32:58.169538
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    fact_collector = \
        get_ansible_collector(
            all_collector_classes=collector.collector_classes(),
            gather_subset=['all'])

    assert isinstance(fact_collector, AnsibleFactCollector)

if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-24 21:33:01.787937
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_collector_classes()
    fact_collector = get_ansible_collector(all_collector_classes)
    assert(fact_collector != None)


# Generated at 2022-06-24 21:33:08.949108
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import AllFactCollector
    from ansible.module_utils.facts import namespaces

    ansible_fact_collector = get_ansible_collector(
        all_collector_classes=AllFactCollector,
        namespace=namespaces.PrefixFactNamespace(prefix='ansible_')
    )

    ansible_facts = ansible_fact_collector.collect()

    assert 'ansible_facts' in ansible_facts
    assert 'gather_subset' in ansible_facts
    assert 'module_setup' in ansible_facts



# Generated at 2022-06-24 21:33:14.661169
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_collector_classes()
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes)
    assert isinstance(ansible_fact_collector_0.collectors, list)
    assert len(ansible_fact_collector_0.collectors) == len(all_collector_classes) + 1

# Generated at 2022-06-24 21:33:24.737372
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes

    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    ansible_collector = \
        get_ansible_collector(all_collector_classes,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)

    # DEBUG
    print(ansible_collector)

    # TODO: add assert?



# Generated at 2022-06-24 21:33:28.926270
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_obj_0 = AnsibleFactCollector()
    ansible_fact_collector_obj_0.collect()


# Generated at 2022-06-24 21:33:32.309384
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    expected = {}
    actual = ansible_fact_collector_0.collect()
    assert actual == expected


# Generated at 2022-06-24 21:33:36.406809
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector(filter_spec=['*'])
    # ansible_fact_collector2 = get_ansible_collector(filter_spec=['*'], gather_subset=['all'])


# Generated at 2022-06-24 21:33:56.087863
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    ansible_fact_collector = get_ansible_collector(all_collector_classes=collector.ALL_COLLECTOR_CLASSES,
                                                   namespace=None,
                                                   filter_spec=None,
                                                   gather_subset=collector.ALL_GATHER_SUBSET,
                                                   gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                                   minimal_gather_subset=frozenset())
    ansible_facts = ansible_fact_collector.collect()
    assert ansible_facts

# Generated at 2022-06-24 21:34:01.191287
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    c = AnsibleFactCollector()
    import StringIO
    out = StringIO.StringIO()
    modules.support.AnsibleFakeModuleStdout(out)
    c.collect()
    output = out.getvalue().strip()
    assert (output == '{"ansible_facts": {}}')


# Generated at 2022-06-24 21:34:08.061938
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    assert ansible_fact_collector.collect() == {}, 'failed to collect when there are no collectors'

    ansible_fact_collector = AnsibleFactCollector(collectors=[])
    assert ansible_fact_collector.collect() == {}, 'failed to collect when there are no collectors'

    ansible_fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    assert ansible_fact_collector.collect()['test'] == 'test', \
        'failed to find "test" collector fact when ' \
        'collector is added with AnsibleFactCollector.__init__'

    ansible_fact_collector.add_collector(TestCollector())
    assert ansible_fact_collector.collect()['test']

# Generated at 2022-06-24 21:34:13.993006
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_collector = get_ansible_collector(all_collector_classes=['foo', 'bar'],
                                              namespace='ansible_',
                                              filter_spec=['ansible_*'],
                                              gather_subset=['all'],
                                              gather_timeout=10,
                                              minimal_gather_subset=['foo', 'bar'])
    assert isinstance(ansible_collector.name, str)
    assert isinstance(ansible_collector.collectors, list)
    assert isinstance(ansible_collector.namespace, str)
    assert ansible_collector.filter_spec == ['ansible_*']

# Generated at 2022-06-24 21:34:17.029151
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    get_ansible_collector({}, namespace=None, filter_spec=None, gather_subset=None, gather_timeout=None,
                          minimal_gather_subset=None)

# Generated at 2022-06-24 21:34:19.450278
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:34:21.861520
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_collect_obj = AnsibleFactCollector()
    assert ansible_collect_obj is not None
    ansible_collect_obj_collect = ansible_collect_obj.collect()
    assert ansible_collect_obj_collect is not None



# Generated at 2022-06-24 21:34:29.034772
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_class_0 = []
    minimal_gather_subset_0 = 'all'
    gather_subset_0 = 'all'
    gather_timeout_0 = timeout.DEFAULT_GATHER_TIMEOUT
    ansible_fact_collector_0 = get_ansible_collector(collector_class_0, minimal_gather_subset_0, gather_subset_0, gather_timeout_0)
    print(ansible_fact_collector_0)

# Generated at 2022-06-24 21:34:33.060647
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.collector_classes_from_entry_points()
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

# Generated at 2022-06-24 21:34:42.365116
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.linux import LinuxNetworkCollector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.linux import LinuxHostnameCollector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.linux import LinuxPlatformCollector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.linux import LinuxDistributionCollector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.linux import LinuxVirtualCollector

# Generated at 2022-06-24 21:34:59.001095
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_instance = AnsibleFactCollector()
    assert collector_instance.collect() == {}

    collector_instance = AnsibleFactCollector()
    assert collector_instance.collect(collected_facts={'test': 'facts'}) == {}


# Generated at 2022-06-24 21:35:01.679154
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert 'test' == ansible_fact_collector_0.collect()['test']['test']

# Run all tests

# Generated at 2022-06-24 21:35:06.122416
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test for method collect for class AnsibleFactCollector
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:35:08.815437
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()

    module_0 = {}
    collected_facts_0 = AnsibleFactCollector(collector.collector_classes_from_module_name('setup'))
    ansible_fact_collector_0.collect(module_0, collected_facts_0)


# Generated at 2022-06-24 21:35:12.164908
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    c0 = AnsibleFactCollector()
    c0.collect()


# Generated at 2022-06-24 21:35:17.814014
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    collected_facts_1 = dict()
    module_2 = None
    ansible_fact_collector_0.collect(module_2, collected_facts_1)
    fact_collector_3 = AnsibleFactCollector()
    collected_facts_4 = dict()
    module_5 = None
    fact_collector_3.collect(module_5, collected_facts_4)


# Generated at 2022-06-24 21:35:25.524671
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # We create our own module object for testing purposes
    # This tests the case where no namespace is specified, and the fact
    # collector does not add any namespace
    module = {}

    # We create our own FactCollector
    ansible_fact_collector = \
        AnsibleFactCollector(collectors=[TestFactCollector()],
                             namespace=None)

    # We check that the collector we created returns what we expect
    # In this case, gather_subset is empty, so the result should be empty
    assert ansible_fact_collector.collect() == {}


if __name__ == '__main__':
    test_case_0()
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:35:29.155478
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    result = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:35:35.943242
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collectors = [None]
    with mock.patch.object(ansible_fact_collector_0, '_filter' , return_value='facts_dict'):
        ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:35:38.915495
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:35:56.613254
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cpu

    all_fact_classes = [cpu.CpuFactCollector]
    fact_collector = get_ansible_collector(all_fact_classes)

    module_args = {'gather_subset': 'all'}
    facts_dict = fact_collector.collect(module=module_args)

    assert isinstance(facts_dict, dict)
    assert 'gather_subset' in facts_dict
    assert 'module_setup' in facts_dict
    assert facts_dict['gather_subset'] == [u'all']
    assert 'ansible_facts' in facts_dict

# Generated at 2022-06-24 21:35:58.643680
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:36:01.464023
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()


# Generated at 2022-06-24 21:36:11.030462
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    module = AnsibleModule(argument_spec=dict())
    ansible_fact_collector = get_ansible_collector(
        all_collector_classes=collector.all_collector_classes(),
        namespace=None,
        filter_spec=None,
        gather_subset=['all'],
        gather_timeout=10,
        minimal_gather_subset=frozenset())

    facts_dict = ansible_fact_collector.collect(module=module)
    assert isinstance(facts_dict, dict)
    assert len(facts_dict) == 1
    assert len(facts_dict['gather_subset']) == 1


if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:36:20.853459
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_collector = get_ansible_collector(all_collector_classes=[],
                                              namespace=collector.BaseFactNamespace(),
                                              filter_spec=[],
                                              gather_subset=['all'],
                                              gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                              minimal_gather_subset=frozenset())

    assert ansible_collector.filter_spec == []
    assert ansible_collector.collectors[0].name == 'gather_subset'
    assert len(ansible_collector.collectors) == 1

    assert len(ansible_collector.collectors[0].namespaces) > 0


if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collect

# Generated at 2022-06-24 21:36:29.445856
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.collector.distribution import DistributionFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.command import CommandFactCollector
    from ansible.module_utils.facts.collector.file import FileFactCollector

    # Setup
    system_collector = SystemFactCollector(namespace='ansible')
    distribution_collector = DistributionFactCollector(namespace='ansible')
    network_collector = NetworkFactCollector(namespace='ansible')
    command_collector = CommandFactCollector(namespace='ansible')
    file_collector = FileFactCollector(namespace='ansible')

# Generated at 2022-06-24 21:36:32.221492
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}



# Generated at 2022-06-24 21:36:37.780048
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    facts_dict_1 = ansible_fact_collector_1.collect(module=None, collected_facts=None)
    assert isinstance(facts_dict_1, dict)


# Generated at 2022-06-24 21:36:43.797399
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = get_ansible_collector(\
        all_collector_classes=collector.get_collector_classes(), \
        namespace=None, \
        filter_spec=None, \
        gather_subset='all', \
        gather_timeout=10, \
        minimal_gather_subset=frozenset())

if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:36:53.512544
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.all_platforms_collector_classes()
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes)
    ansible_facts_0 = ansible_fact_collector_0.collect()
    for k, v in ansible_facts_0.items():
        keys = k.split('.')

# Generated at 2022-06-24 21:37:21.077793
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO: get a list of collectors to pass in
    all_collector_classes = []

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes)
    # todo: validate the fact_collector populated with collectors was created as expected

if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:37:24.065294
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_collector_classes()
    fact_collector = get_ansible_collector(all_collector_classes)
    assert(isinstance(fact_collector, AnsibleFactCollector))

# Generated at 2022-06-24 21:37:28.517186
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test case 1: No collectors
    ansible_fact_collector_1 = AnsibleFactCollector()
    fact_dict_1 = ansible_fact_collector_1.collect()
    assert not fact_dict_1

    # Test case 2: One dictionary of collectors
    ansible_fact_collector_2 = \
        AnsibleFactCollector(collectors=[{'a': 1, 'b': 2}])
    fact_dict_2 = ansible_fact_collector_2.collect()
    assert fact_dict_2 == {'a': 1, 'b': 2}

    # Test case 3: Two dictionary of collectors
    ansible_fact_collector_3 = \
        AnsibleFactCollector(collectors=[{'a': 1, 'b': 2}, {'c': 3}])
    fact_