

# Generated at 2022-06-24 21:27:39.882614
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''
    Unit test for method collect of class CollectorMetaDataCollector
    '''
    obj = CollectorMetaDataCollector()
    result = obj.collect()

    assert result == {'gather_subset': None}, \
           "Ansible facts are not correct"


# Generated at 2022-06-24 21:27:41.843280
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test = CollectorMetaDataCollector()
    collect = test.collect()
    assert isinstance(collect, dict)


# Generated at 2022-06-24 21:27:44.084797
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    instance = CollectorMetaDataCollector()
    expected = {'gather_subset': None}
    actual = instance.collect()
    assert actual == expected



# Generated at 2022-06-24 21:27:48.918042
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    global collector_meta_data_collector_0
    collector_meta_data_collector_0.collect()



if __name__ == '__main__':
    # Unit test for method collect of class CollectorMetaDataCollector
    test_case_0()
    test_CollectorMetaDataCollector_collect()

# Generated at 2022-06-24 21:27:55.977560
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    module_0 = None
    collected_facts_0 = None
    expected_return_value_0 = {'gather_subset': None}
    actual_return_value_0 = collector_meta_data_collector_0.collect(module_0, collected_facts_0)
    assert expected_return_value_0 == actual_return_value_0


# Generated at 2022-06-24 21:28:07.748334
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.collectors.all
    all_collector_classes = ansible.module_utils.facts.collectors.all.__dict__
    c = CollectorMetaDataCollector(collectors=[], namespace=None, gather_subset=None, module_setup=None)
    f = c.collect()
    assert({'gather_subset': None} == f)
    c = CollectorMetaDataCollector(collectors=[], namespace=None, gather_subset=['network', 'min'], module_setup=None)
    f = c.collect()
    assert({'gather_subset': ['network', 'min']} == f)
    c = CollectorMetaDataCollector(collectors=[], namespace=None, gather_subset=['network', 'min'], module_setup=True)
   

# Generated at 2022-06-24 21:28:19.326060
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # test with collectors, namespace, filter_spec
    collector_obj_0 = collector.BaseFactCollector()
    collector_obj_1 = collector.BaseFactCollector()
    collectors = [collector_obj_0, collector_obj_1]

    fact_collector = AnsibleFactCollector(collectors=collectors, namespace='ns_1', filter_spec='*')

    s = {'ansible_facts': {'ansible_module_setup': True, 'gather_subset': None}}
    assert fact_collector.collect() == s

    # test with collectors, namespace
    fact_collector = AnsibleFactCollector(collectors=collectors, namespace='ns_2')

    s = {'ansible_facts': {'ansible_module_setup': True, 'gather_subset': None}}
   

# Generated at 2022-06-24 21:28:25.550340
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
  collector_meta_data_collector_1 = CollectorMetaDataCollector(collectors=None, gather_subset=None)
  # fmt: off
  collector_meta_data_collector_1._fact_ids = set([])
  # fmt: on
  meta_facts = {'gather_subset': None}
  assert collector_meta_data_collector_1.collect(collected_facts=None) == meta_facts


# Generated at 2022-06-24 21:28:32.346385
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    expected_output = {'gather_subset': 'all'}
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    actual_output = collector_meta_data_collector_0.collect()
    assert actual_output == expected_output


# Generated at 2022-06-24 21:28:36.898225
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}, 'Method "collect" of "CollectorMetaDataCollector" class returned wrong result.'


# Generated at 2022-06-24 21:28:46.369502
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import collectors as all_collector_classes

    ansible_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                              gather_subset=['min'],
                                              gather_timeout=0.3,
                                              minimal_gather_subset=frozenset(['facter', 'min']))

    assert(isinstance(ansible_collector, AnsibleFactCollector))
    assert(ansible_collector.filter_spec is None)
    assert(ansible_collector.namespace is None)
    assert(ansible_collector.fail_on_any_collect_error is True)

# Generated at 2022-06-24 21:28:50.921289
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    class module_mock:
        pass
    module_mock_0 = module_mock()
    assert collector_meta_data_collector_0.collect(module=module_mock_0) == {'gather_subset': None, 'module_setup': None}


# Generated at 2022-06-24 21:29:00.194699
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    expected = {'gather_subset': None}
    actual = collector_meta_data_collector_0.collect()
    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)
    collector_meta_data_collector_1 = CollectorMetaDataCollector(gather_subset=['!all'])
    expected = {'gather_subset': ['!all']}
    actual = collector_meta_data_collector_1.collect()
    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)
    collector_meta_data_collector_2 = CollectorMetaDataCollector()

# Generated at 2022-06-24 21:29:09.488227
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector()
    collector_meta_data_collector.gather_subset = ['!all', '!facter', '!ohai']
    collector_meta_data_collector.module_setup = True
    result = collector_meta_data_collector.collect()
    # Result: {'gather_subset': ['!all', '!facter', '!ohai'], 'module_setup': True}
    # TODO: replace with improved assert logic
    assert result == {'gather_subset': ['!all', '!facter', '!ohai'], 'module_setup': True}

# Generated at 2022-06-24 21:29:10.644087
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_case_0()


# Generated at 2022-06-24 21:29:18.939519
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector()
    assert collector_meta_data_collector.collect() == {'gather_subset': None}
    assert collector_meta_data_collector.collect() == {'gather_subset': None}
    assert collector_meta_data_collector.collect() == {'gather_subset': None}
    assert collector_meta_data_collector.collect() == {'gather_subset': None}
    assert collector_meta_data_collector.collect() == {'gather_subset': None}
    assert collector_meta_data_collector.collect() == {'gather_subset': None}
    assert collector_meta_data_collector.collect() == {'gather_subset': None}
    assert collector_meta_data

# Generated at 2022-06-24 21:29:19.930791
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    pass



# Generated at 2022-06-24 21:29:23.622889
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test for method collect of class CollectorMetaDataCollector'''
    collect_object = CollectorMetaDataCollector()
    result = collect_object.collect(module=None, collected_facts=None)
    assert result == {'gather_subset': None}


# Generated at 2022-06-24 21:29:27.938588
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    facts = collector_meta_data_collector_0.collect(module=None, collected_facts=None)
    assert facts == {'gather_subset': None}


# Generated at 2022-06-24 21:29:32.261982
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}



# Generated at 2022-06-24 21:29:42.355161
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.timeout
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts
    import sys

    if sys.version_info[0] < 3:
        import mock
    else:
        from unittest import mock
    m = mock.mock_open()

    with mock.patch("ansible.module_utils.facts.collector.open", m, create=True):
        ansible.module_utils.facts.timeout.DEFAULT_GATHER_TIMEOUT = 0
        ansible.module_utils.facts.collector.CollectorMetaDataCollector.time = None
        test_collector_meta_data_collector_collect_0 = \
            ansible.module_utils.facts

# Generated at 2022-06-24 21:29:47.290705
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    collector_meta_data_collector_0.collect()


# Generated at 2022-06-24 21:29:51.517757
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Test setup
    collector_meta_data_collector_1 = CollectorMetaDataCollector()

    # Test execution
    result = collector_meta_data_collector_1.collect()

    # Verify
    assert result == {'gather_subset': []}

# Generated at 2022-06-24 21:29:55.035343
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:29:58.679975
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert isinstance(collector_meta_data_collector_0.collect(), dict)


# Generated at 2022-06-24 21:30:01.656241
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}


# Generated at 2022-06-24 21:30:07.470015
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_meta_data_collector_0 = CollectorMetaDataCollector()

    # Test 0 - no exception expected. no return value expected.
    try:
        collector_meta_data_collector_0.collect(module=None, collected_facts=None)
    except Exception as e:
        if type(e) != type(None):
            raise Exception(e.message)




# Generated at 2022-06-24 21:30:15.792385
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    facts = collector_meta_data_collector_0.collect()
    assert set(facts.keys()) == {'gather_subset'}
    assert facts['gather_subset'] == 'all'

# [ansible-test-collection-namespace: localhost] ------------------------------------ test_CollectorMetaDataCollector_collect: PASSED
# [ansible-test-collection-namespace: localhost] ------------------------------------ test_case_0: PASSED
# [ansible-test-collection-namespace: localhost] ------------------------------------ test_get_ansible_collector: PASSED


# Generated at 2022-06-24 21:30:19.663622
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}


# Generated at 2022-06-24 21:30:22.406990
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}


# Generated at 2022-06-24 21:30:29.626873
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    result = collector_meta_data_collector_0.collect()
    assert result is not None


# Generated at 2022-06-24 21:30:35.395586
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    os_collector_0 = collector.GenericFactCollector(namespace='os')
    d = {
        'alpha': {
            'beta': 'gamma'
        }
    }
    namespace = collector.PrefixFactNamespace(prefix='huey_')
    fact_collector_0 = AnsibleFactCollector(collectors=[os_collector_0], namespace=namespace, filter_spec='*')
    d1 = fact_collector_0.collect(collected_facts=d)
    assert d1['os']['name'] is not None
    assert d1['huey_os']['name'] is not None



# Generated at 2022-06-24 21:30:37.092154
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}


# Generated at 2022-06-24 21:30:43.043911
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # test_collector_meta_data_collector_0 = CollectorMetaDataCollector()
    test_module = {}
    test_collector_meta_data_collector_0 = CollectorMetaDataCollector()
    result = test_collector_meta_data_collector_0.collect(test_module)
    assert result == {}

test_case_0()

# Generated at 2022-06-24 21:30:48.986084
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    collectors = [collector_meta_data_collector_0]
    filter_spec = ['*']
    fact_collector_0 = AnsibleFactCollector(collectors=collectors, filter_spec=filter_spec)
    print(fact_collector_0.collect())

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:30:52.257295
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    meta_facts = collector_meta_data_collector_0.collect()
    assert meta_facts['module_setup']
    assert 'gather_subset' in meta_facts


# Generated at 2022-06-24 21:30:54.437748
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_obj = CollectorMetaDataCollector()

    # noinspection PyCallingNonCallable
    collector_obj.collect()

# Generated at 2022-06-24 21:31:00.951847
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.all_collector_classes()
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = 10
    minimal_gather_subset = None
    get_ansible_collector(all_collector_classes=all_collector_classes,
                          namespace=namespace,
                          filter_spec=filter_spec,
                          gather_subset=gather_subset,
                          gather_timeout=gather_timeout,
                          minimal_gather_subset=minimal_gather_subset)

if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-24 21:31:04.777984
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    all_collector_classes = {}
    fact_collector = get_ansible_collector(all_collector_classes)
    collected_facts = fact_collector.collect()
    assert collected_facts['gather_subset'] == ['all']

# Generated at 2022-06-24 21:31:07.831972
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}


# Generated at 2022-06-24 21:31:31.054027
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector as fact_collector
    all_collector_classes = fact_collector.BaseFactCollector.all_collector_names()

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                              gather_subset=['all'],
                              gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                              minimal_gather_subset=frozenset())

    if fact_collector.namespace:
        fact_collector.namespace.post_process_collected_facts('ansible_', {})


# Generated at 2022-06-24 21:31:35.297892
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    try:
        fact_collector.collect()
    except Exception as e:
        er = e

    # TODO: check that it throws the right exception



# Generated at 2022-06-24 21:31:45.987941
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test cases gathered from:
    #   https://docs.python.org/2/library/fnmatch.html#fnmatch-examples
    #   https://docs.python.org/2/library/fnmatch.html#module-fnmatch
    #   https://docs.python.org/2/howto/regex.html#greedy-vs-non-greedy

    # Test case 0
    # Test case setup code
    collector_meta_data_collector_0 = CollectorMetaDataCollector()

    # Test case operation code
    result_0 = collector_meta_data_collector_0.collect()

    # Test case validation code
    assert result_0 == {'gather_subset': ['all']}

    # Test case 1
    # Test case setup code

# Generated at 2022-06-24 21:31:57.688393
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    filter_spec_value_0 = ''
    filter_spec_value_1 = []
    filter_spec_value_2 = '*'
    filter_spec_value_3 = ['ansible_*', 'facter_*', 'ohai_*']
    filter_spec_value_4 = ['ansible_facter_*', 'ansible_distribution', 'facter_ohai_*']
    filter_spec_value_5 = ['ansible_facter_*', 'ansible_distribution', 'facter_ohai_*', 'distribution_version']
    filter_spec_value_6 = ['ansible_facter_*', 'ansible_distribution', 'facter_ohai_*', 'distribution_version', 'ansible_*']

# Generated at 2022-06-24 21:32:02.585172
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    collector_base_0 = collector_meta_data_collector_0
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=[collector_base_0])
    ansible_fact_collector_0.collect(collected_facts=None)


# Generated at 2022-06-24 21:32:08.566431
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Unit test: AnsibleFactCollector.collect
    collector_namespace_0 = collector.PrefixFactNamespace(prefix='os_')
    collector_meta_data_collector_0 = CollectorMetaDataCollector(namespace=collector_namespace_0)
    fact_collector_0 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0])
    fact_collector_0.collect(collected_facts={'os_gather_subset': 'gather_subset',
                                              'os_module_setup': 'module_setup'})

# Generated at 2022-06-24 21:32:15.573301
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    test_fact_collector = get_ansible_collector(collector.all_collectors_classes(), filter_spec=[], gather_subset=[], gather_timeout=None, minimal_gather_subset=None)
    assert isinstance(test_fact_collector, AnsibleFactCollector)

    test_collector = test_fact_collector.collectors[0]
    assert isinstance(test_collector, collector.Collector)


if __name__ == '__main__':
    ''' Run with nosetests -v -s '''
    test_case_0()

    test_get_ansible_collector()

    print('Done testing')

# Generated at 2022-06-24 21:32:22.189147
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    collectors = []
    collectors.append("fake_collector_a")
    collectors.append("fake_collector_b")
    namespace = None
    filter_spec = None

    ansible_fact_collector = AnsibleFactCollector(collectors=collectors,
                                                  namespace=namespace,
                                                  filter_spec=filter_spec)

    collected_facts = {}

    try:
        ansible_fact_collector.collect()
    except Exception as e:
        assert False

# Generated at 2022-06-24 21:32:31.732782
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    all_collector_classes_0 = [collector_meta_data_collector_0]
    filter_spec_0 = ['all']
    gather_subset_0 = ['all']
    gather_timeout_0 = 30
    minimal_gather_subset_0 = []
    namespace_0 = None
    ansible_collector_0 = get_ansible_collector(all_collector_classes_0, namespace_0, filter_spec_0, gather_subset_0, gather_timeout_0, minimal_gather_subset_0)
    assert len(ansible_collector_0.collectors) == 1
    assert ansible_collector_0.collectors[0]._fact_ids == set([])

# Generated at 2022-06-24 21:32:40.102923
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collectors.hardware
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.virtual

    all_collector_classes = collector.collector_classes_from_fact_modules(
        fact_modules=[ansible.module_utils.facts.collectors.hardware,
                      ansible.module_utils.facts.collectors.network,
                      ansible.module_utils.facts.collectors.system,
                      ansible.module_utils.facts.collectors.virtual])

    gather_subset = ['all', 'network', 'hardware', 'virtual', 'facter', 'ohai', 'debian_setup']
    gather_timeout = 10
    minimal_

# Generated at 2022-06-24 21:33:01.087417
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    namespace_0 = None
    filter_spec_0 = None
    collectors_0 = [ collector_meta_data_collector_0 ]
    fact_collector_0 = AnsibleFactCollector(collectors=collectors_0, namespace=namespace_0, filter_spec=filter_spec_0)
    collected_facts_0 = { }
    module_0 = None
    test_case_0_0 = fact_collector_0.collect(collected_facts=collected_facts_0, module=module_0)
    ansible_facts_0 = test_case_0_0


# Generated at 2022-06-24 21:33:11.453966
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes = set()
    filter_spec = ['', '*', 'ansible_*', 'facter_*']

    gather_subset = ['all', 'network', 'facter', 'ohai']

    fact_collector = get_ansible_collector(
        all_collector_classes=all_collector_classes,
        filter_spec=filter_spec,
        gather_subset=gather_subset)

    facts_dict = fact_collector.collect()
    assert facts_dict
    assert isinstance(facts_dict, dict)

    # test for module_setup fact
    assert facts_dict.get('module_setup') == True
    assert facts_dict.get('gather_subset') == gather_subset



# Generated at 2022-06-24 21:33:23.149296
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Instantiate mock FactCollector objects that return some hardcoded dummy data
    fact_collector1 = collector.MockFactCollector()
    fact_collector1.collect_fn = lambda: {u'foo': u'bar', u'baz': 100}
    fact_collector2 = collector.MockFactCollector()
    fact_collector2.collect_fn = lambda: {u'bar': u'baz', u'quz': u'qux'}
    fact_collector3 = collector.MockFactCollector()
    fact_collector3.collect_fn = lambda: {u'tac': u'toe', u'hat': u'bat'}

    # Using a FactNamespace to make sure that namespace works in the collect()
    fact_collector_ns = collector.MockFactCollector()
    fact

# Generated at 2022-06-24 21:33:28.726857
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_fact_collector_classes()
    ansible_collector = get_ansible_collector(all_collector_classes)
    collected_facts = ansible_collector.collect()
    assert 'gather_subset' in collected_facts
    assert 'module_setup' in collected_facts
    assert len(collected_facts) > 0



# Generated at 2022-06-24 21:33:36.404735
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector = AnsibleFactCollector()
    # by default, the filterspec is '*' and the fact_collector will collect all facts that
    # it can get

    # Test that the empty case is handled correctly.
    assert ansible_fact_collector._filter({}, None) == {}
    assert ansible_fact_collector._filter({}, '') == {}
    assert ansible_fact_collector._filter({}, []) == {}
    assert ansible_fact_collector._filter({'a': 1}, '') == []
    assert ansible_fact_collector._filter({'a': 1}, []) == []

    # Test that the global case is handled correctly.

# Generated at 2022-06-24 21:33:39.219452
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()


# Generated at 2022-06-24 21:33:44.663781
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_obj = get_ansible_collector()

    assert isinstance(collector_obj, CollectorMetaDataCollector)
    assert isinstance(collector_obj.collectors[0], AnsibleFactCollector)
#     assert False, 'No unit test for function get_ansible_collector()'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:33:45.994449
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_obj = AnsibleFactCollector()
    collector_obj.collect()

# Generated at 2022-06-24 21:33:53.274921
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector_0 = \
        get_ansible_collector(all_collector_classes=[], namespace=None,
                              filter_spec=None, gather_subset=['all'],
                              gather_timeout=None, minimal_gather_subset=frozenset([]))
    assert fact_collector_0
    print(fact_collector_0)


if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:33:58.953665
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    get_ansible_collector()

# Generated at 2022-06-24 21:34:57.501160
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:34:59.217784
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()


# Generated at 2022-06-24 21:35:06.317598
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import os
    import stat
    import shutil
    import uuid
    import tempfile

    ansible_facts_tmp_dir_path = tempfile.mkdtemp()

    # create a temporary collector to test
    # that uses a filesystem-based namespace for test purposes

    tmp_namespace_name_0 = 'tmp_namespace_%s' % uuid.uuid4()
    tmp_namespace_path_0 = os.path.join(ansible_facts_tmp_dir_path, tmp_namespace_name_0)
    tmp_namespace_dict_0 = {'path': tmp_namespace_path_0}
    tmp_namespace_0 = AnsibleFactCollector.get_namespace('filesystem', tmp_namespace_dict_0)


# Generated at 2022-06-24 21:35:06.929986
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 21:35:11.633599
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector_1 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0])
    ansible_fact_collector_1.collect()
    ansible_fact_collector_1.collect(collected_facts={'asdf': 'asdf'})
    ansible_fact_collector_2 = AnsibleFactCollector(collectors=[])
    ansible_fact_collector_2.collect()
    ansible_fact_collector_3 = AnsibleFactCollector()
    ansible_fact_collector_3.collect()


# Generated at 2022-06-24 21:35:18.946528
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network_collector
    from ansible.module_utils.facts import system_collector

    all_collectors = [
        ansible_collector,
        network_collector,
        system_collector,
    ]
    collector_meta_data_collector_0 = \
        CollectorMetaDataCollector(gather_subset='network')

    ansible_collector_0 = \
        get_ansible_collector(
            all_collector_classes=all_collectors,
            gather_subset=['network'],
            minimal_gather_subset=['network'],
        )


# Generated at 2022-06-24 21:35:25.974504
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0_collect = ansible_fact_collector_0.collect()
    print(ansible_fact_collector_0_collect)

    ansible_fact_collector_1 = AnsibleFactCollector(collectors=[])
    ansible_fact_collector_1_collect = ansible_fact_collector_1.collect()
    print(ansible_fact_collector_1_collect)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:35:27.576722
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass


# Generated at 2022-06-24 21:35:39.378533
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-24 21:35:46.968553
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    try:
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
        from ansible.module_utils.facts import default_collectors
    except ImportError:
        print('Skipped tests due to missing import ansible.module_utils.facts')
        return

    all_collector_classes = [c for c in default_collectors.__dict__.values()
                             if isinstance(c, type) and issubclass(c, collector.BaseFactCollector)
                             and c.name != collector.BaseFactCollector.name]

    filter_spec = ['ansible_eth*']


# Generated at 2022-06-24 21:36:53.511675
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.namespace

    collector_meta_data_collector = CollectorMetaDataCollector()
    ansible_fact_collector = AnsibleFactCollector(collectors = [collector_meta_data_collector])

    collected_facts = {'ansible_facts': {'gather_subset': ['all']}}
    ansible_fact_collector.collect(collected_facts=collected_facts)
    #AnsibleCollector._collector_classes[0]


# Generated at 2022-06-24 21:37:00.051670
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = get_ansible_collector(
                        all_collector_classes=collector.all_collector_classes(),
                        gather_subset=['all'])
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert len(facts) > 0
    assert 'gather_subset' in facts
    assert 'module_setup' in facts



# Generated at 2022-06-24 21:37:04.319608
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    module_ = MockModule()
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0])
    ansible_fact_collector_0.collect(module_)


# Generated at 2022-06-24 21:37:08.721705
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector_0 = AnsibleFactCollector([collector_meta_data_collector_0])
    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:37:14.362286
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_1 = CollectorMetaDataCollector()
    collector_2 = CollectorMetaDataCollector()
    collectors = [collector_1, collector_2]
    collect = AnsibleFactCollector(collectors=collectors)
    result = collect.collect()
    if result == {'gather_subset': ['all'], 'module_setup': True}:
        return True
    else:
        return False


# Generated at 2022-06-24 21:37:22.070473
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    collected_facts = {'platform_system': 'Linux'}
    collector_meta_data_collector_1 = CollectorMetaDataCollector(gather_subset=None, module_setup=None)
    my_collector = AnsibleFactCollector(collectors=[collector_meta_data_collector_1], filter_spec=None)
    assert my_collector.collect(module=None, collected_facts=collected_facts) == {'gather_subset': None, 'module_setup': None, 'ansible_facts': {'gather_subset': None, 'module_setup': None}}

# Generated at 2022-06-24 21:37:26.799486
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collect_obj = AnsibleFactCollector()
    assert collect_obj.collect() == {}
