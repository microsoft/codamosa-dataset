

# Generated at 2022-06-24 21:27:36.201367
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Test failure
    pass


# Generated at 2022-06-24 21:27:48.219727
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    CollectorMetaDataCollector.name = 'gather_subset_name'
    CollectorMetaDataCollector._fact_ids = set(['collector_ids'])
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=None, namespace=None, filter_spec=None)
    ansible_fact_collector_1 = AnsibleFactCollector(collectors=None, namespace=None, filter_spec=None)
    ansible_fact_collector_2 = AnsibleFactCollector(collectors=None, namespace=None, filter_spec=None)
    ansible_fact_collector_3 = AnsibleFactCollector(collectors=None, namespace=None, filter_spec=None)

# Generated at 2022-06-24 21:27:49.955872
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)


# Generated at 2022-06-24 21:27:57.205997
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    float_0 = 100.0
    collector_meta_data_collector_0 = CollectorMetaDataCollector(float_0)
    module_1 = AnsibleModule(argument_spec=dict())
    float_2 = 100.0
    ansible_fact_collector_1 = AnsibleFactCollector(float_2)
    ansible_fact_collector_1.collect()


if __name__ == '__main__':
    test_CollectorMetaDataCollector_collect()

# Generated at 2022-06-24 21:28:06.364515
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    module_0 = MagicMock()
    module_0._ansible_module = module_0
    module_0._ansible_module.params = dict()
    module_0._ansible_module.params['gather_subset'] = list()
    module_0._ansible_module.params['gather_subset'].extend(['!all'])
    module_0._ansible_module.params['gather_subset'].extend(['!mandatory'])
    module_0._ansible_module.params['gather_subset'].extend(['!min'])
    module_0._ansible_module.params['gather_subset'].extend(['!network'])

# Generated at 2022-06-24 21:28:11.303141
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    float_0 = 100.0
    CollectorMetaDataCollector_0 = CollectorMetaDataCollector(float_0)
    answer_1 = CollectorMetaDataCollector_0.collect()
    assert answer_1 == dict({'gather_subset': float_0})


# Generated at 2022-06-24 21:28:14.074675
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Check if _filter returns list when input is a dict.
    assert issubclass(AnsibleFactCollector.collect, list)



# Generated at 2022-06-24 21:28:17.214517
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    coll = AnsibleFactCollector()
    coll.collect()

if __name__ == '__main__':
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:28:27.532960
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    float_0 = 100.0
    CollectorMetaDataCollector_0 = CollectorMetaDataCollector(float_0)
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    float_1 = 100.0
    float_2 = 100.0
    float_3 = 100.0
    list_0 = ['str', float_2, float_3]
    tuple_0 = ('str', float_2, float_3)
    tuple_1 = (float_3, 'str', float_3)
    tuple_2 = ('str', float_3, float_3)
    set_0 = {'str', float_2, float_3}
    set_1 = {float_3, 'str', float_3}

# Generated at 2022-06-24 21:28:38.719250
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    namespace = 'ansible_'
    gather_subset = 'all'
    module_setup = None
    collector_meta_data_collector_0 = \
        CollectorMetaDataCollector(set([]), namespace, gather_subset, module_setup)

    def mock_collect_0(*args, **kwargs):
        # mock_collect_0 is a function callable
        x = \
            {(('ansible_', 'ansible_processor_vcpus'), ): 'ansible_processor_vcpus'}
        return x

    setattr(collector_meta_data_collector_0, 'collect', mock_collect_0)


# Generated at 2022-06-24 21:28:43.313079
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = CollectorMetaDataCollector(float_0)


# Generated at 2022-06-24 21:28:53.739328
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ansible_fact_collector_0 = CollectorMetaDataCollector(float_0, namespace=None)
    ansible_fact_collector_1 = CollectorMetaDataCollector(float_0, namespace=None)
    ansible_fact_collector_2 = CollectorMetaDataCollector(float_0, namespace=None)
    ansible_fact_collector_3 = CollectorMetaDataCollector(float_0, namespace=None)
    ansible_fact_collector_4 = CollectorMetaDataCollector(float_0, namespace=None)
    module_0 = float_0
    ansible_fact_collector_4.collect(module_0)
    ansible_fact_collector_3.collect(module_0)
    ansible_fact_collector_2.collect(module_0)
    ansible_fact_

# Generated at 2022-06-24 21:28:59.752211
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = set([])
    filter_spec = set([])
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()
    ret = get_ansible_collector(all_collector_classes,
                                filter_spec,
                                gather_subset,
                                gather_timeout,
                                minimal_gather_subset)
    assert ret is not None


# Generated at 2022-06-24 21:29:10.747320
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    all_collector_classes_0 = set([])
    namespace_0 = None
    filter_spec_0 = []
    gather_subset_0 = None
    gather_timeout_0 = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset_0 = frozenset()
    ansible_fact_collector_0 = \
        get_ansible_collector(all_collector_classes=all_collector_classes_0,
                              namespace=namespace_0,
                              filter_spec=filter_spec_0,
                              gather_subset=gather_subset_0,
                              gather_timeout=gather_timeout_0,
                              minimal_gather_subset=minimal_gather_subset_0)
    
    # Verify
    assert ansible_

# Generated at 2022-06-24 21:29:18.984793
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    print('''**** Unit test for AnsibleFactCollector.collect''')

    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)

    # Test 1:
    # Try to collect some facts.
    # Ensure the returned facts are not empty.
    # TODO: Fix error when invoking ansible_fact_collector_0.collect()
    # AssertionError: Expected value: not empty.
    # Actual value: {}

    # ************************
    # ansible_fact_collector_0.collect()
    # Expected: not empty
    # Actual: {}
    # ************************

    # Test 2:
    # Try to collect some facts.
    # Ensure the returned facts are a dictionary.
    # TODO: Fix error when invoking type(ans

# Generated at 2022-06-24 21:29:22.657229
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)


if __name__ == '__main__':
    test_case_0()
    test_CollectorMetaDataCollector_collect()

# Generated at 2022-06-24 21:29:28.820316
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # The name of the fact to reference instead of the value.
    ansible_fact_collector_0 = CollectorMetaDataCollector()
    # The name of the fact to reference instead of the value.
    ansible_fact_collector_1 = CollectorMetaDataCollector()
    # The name of the fact to reference instead of the value.
    ansible_fact_collector_2 = CollectorMetaDataCollector()
    # The name of the fact to reference instead of the value.
    ansible_fact_collector_3 = CollectorMetaDataCollector()
    ansible_fact_collector_4 = CollectorMetaDataCollector('ansible_all_ipv4_addresses')
    # The name of the fact to reference instead of the value.
    ansible_fact_collector_5 = CollectorMetaDataCollector()
    # The name

# Generated at 2022-06-24 21:29:31.325506
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 21:29:33.654428
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:29:37.032148
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert isinstance(get_ansible_collector(), AnsibleFactCollector)


# Generated at 2022-06-24 21:30:03.381075
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
  float_0 = 100.0
  ansible_fact_collector_0 = AnsibleFactCollector(float_0)
  ansible_fact_collector_1 = AnsibleFactCollector(float_0)
  ansible_fact_collector_2 = AnsibleFactCollector(float_0)
  ansible_fact_collector_0.collect()
  ansible_fact_collector_1.collect()
  ansible_fact_collector_2.collect()


# Generated at 2022-06-24 21:30:15.292210
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes_0 = [
        ['ansible.module_utils.facts.dispatcher'],
        ['ansible.module_utils.facts.dispatcher.FactCollector'],
        ['ansible.module_utils.facts.dispatcher.FacterFactCollector'],
        ['ansible.module_utils.facts.dispatcher.OhaiFactCollector'],
        ['ansible.module_utils.facts.dispatcher.FactCacheFactCollector'],
        ['ansible.module_utils.facts.dispatcher.CommandLineFactCollector']
    ]


# Generated at 2022-06-24 21:30:20.282237
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)

    module = None
    collected_facts = None

    ansible_fact_collector_0.collect(module=module, collected_facts=collected_facts)


# Generated at 2022-06-24 21:30:22.764047
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Note: no assertions, just make sure the method runs without error
    ansible_fact_collector_0 = AnsibleFactCollector(None)
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:30:27.330953
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    # Call function collect
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:30:39.467852
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_1 = AnsibleFactCollector()
    ansible_fact_collector_1._AnsibleFactCollector__collectors = {}
    ansible_fact_collector_2 = AnsibleFactCollector()
    ansible_fact_collector_2._AnsibleFactCollector__collectors = {}
    ansible_fact_collector_2._AnsibleFactCollector__collectors = {}
    ansible_fact_collector_1.collect()
    ansible_fact_collector_2.collect(module=ansible_fact_collector_1)
    ansible_fact_collector_1.collect()

# Generated at 2022-06-24 21:30:42.941131
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:30:54.633886
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    namespace_0 = 'ansible_'
    filter_spec_0 = 'ansible_*'
    all_collector_classes_0 = [collector.NetworkCollector,
                               collector.HardwareCollector,
                               collector.FacterCollector,
                               collector.OhaiCollector]
    gather_subset_0 = None
    gather_timeout_0 = 0.00392156862745
    minimal_gather_subset_0 = {collector.NetworkCollector,
                               collector.FacterCollector,
                               collector.HardwareCollector}


# Generated at 2022-06-24 21:31:00.042891
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    assert not hasattr(ansible_fact_collector_0, 'collect'), "Attribute 'collect' of AnsibleFactCollector instance should not be read-only"
    try:
        ansible_fact_collector_0.collect()
    except AttributeError as e:
        raise AssertionError("Attribute 'collect' of AnsibleFactCollector instance should not raise AttributeError") from e


# Generated at 2022-06-24 21:31:01.750128
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass


# Generated at 2022-06-24 21:31:21.624059
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.fact_ids = set([])
    ansible_fact_collector_0.collectors = []
    ansible_fact_collector_0.namespace = None
    ansible_fact_collector_0.filter_spec = None
    # Test Parameter: module=None
    # Test Parameter: collected_facts=None
    test_result_0_0 = ansible_fact_collector_0.collect(None, None)
    assert test_result_0_0 == {} or test_result_0_0 == None


# Generated at 2022-06-24 21:31:30.591822
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 1.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    ansible_module_0 = 'module'
    dict_0 = dict()
    dict_0['dict'] = dict_0
    dict_0['dict'] = dict_0
    dict_0['dict'] = dict_0
    dict_1 = dict()
    dict_1['dict'] = dict_1
    dict_1['dict'] = dict_1
    dict_1['dict'] = dict_1
    dict_1['dict'] = dict_0
    dict_1['dict'] = dict_0
    dict_1['dict'] = dict_1
    dict_1['dict'] = dict_0
    dict_1['dict'] = dict_0

# Generated at 2022-06-24 21:31:39.020272
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_1 = get_ansible_collector(namespace=None, gather_subset=None, filter_spec=['*'], minimal_gather_subset=None, gather_timeout=None)
    pass

# all_collector_classes = [
#     collector.PlatformFactCollector,
#     collector.DistributionFactCollector,
#     collector.HardwareFactCollector,
#     collector.VirtualFactCollector,
#     collector.NetworkFactCollector,
#     collector.LocalFactCollector,
#     collector.FacterFactCollector,
#     collector.OhaiFactCollector,
#     collector.AllSubsetCollector,
#     collector.MinimalFactCollector,
#     collector.CommandLineCollector,
#     collector.FileGlobCollector,
#     collector

# Generated at 2022-06-24 21:31:43.135023
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:31:53.751466
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    bool_0 = not False
    bool_1 = not True
    bool_2 = bool_0 and bool_1
    dict_0 = dict()
    str_0 = str(dict_0)
    ansible_fact_collector_0.collect(str_0)
    bool_0 = False
    bool_1 = False
    bool_2 = bool_0 and bool_1
    dict_0 = dict()
    str_0 = str(dict_0)
    ansible_fact_collector_0.collect(str_0)


# Generated at 2022-06-24 21:31:58.837254
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collectors = [AnsibleFactCollector(0.0)]
    ansible_fact_collector_0 = AnsibleFactCollector(collectors)
    module_0 = AnsibleFactCollector(0.0)
    # No module.params['gather_subset'] provided
    facts = ansible_fact_collector_0.collect(module=module_0)
    assert (facts == {})

# Generated at 2022-06-24 21:32:00.993048
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_1 = 100.0
    ansible_fact_collector_1 = AnsibleFactCollector(float_1)


# Generated at 2022-06-24 21:32:08.984624
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes_0 = __file__
    namespace_0 = __file__
    filter_spec_0 = __file__
    gather_subset_0 = __file__
    gather_timeout_0 = __file__
    minimal_gather_subset_0 = __file__
    get_ansible_collector_function_0 = get_ansible_collector(collector_classes_0,
                                                             namespace_0,
                                                             filter_spec_0,
                                                             gather_subset_0,
                                                             gather_timeout_0,
                                                             minimal_gather_subset_0)


if __name__ == "__main__":

    # Unit test for function get_ansible_collector
    test_get_ansible_collector()

    # Unit test for

# Generated at 2022-06-24 21:32:11.627868
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector(0)
    module_0 = ModuleStub()
    ansible_fact_collector_0.collect(module_0)


# Generated at 2022-06-24 21:32:15.281888
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''
    Unit test for function get_ansible_collector
    '''

    ansible_fact_collector_0 = get_ansible_collector()

if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:32:51.514167
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Set up test environment
    test_AnsibleFactCollector_collect.test_env_0()

    # Test with no optional args
    test_AnsibleFactCollector_collect.test_with_no_optional_args()

    # Test with no optional args and normal float return
    test_AnsibleFactCollector_collect.test_with_no_optional_args_and_normal_float_return()

    # Test with no optional args and abnormal float return
    test_AnsibleFactCollector_collect.test_with_no_optional_args_and_abnormal_float_return()

    # Test with no optional args and normal str return
    test_AnsibleFactCollector_collect.test_with_no_optional_args_and_normal_str_return()

    # Test with no optional args and abnormal str return


# Generated at 2022-06-24 21:32:54.435834
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    
    # Call method collect of var with argument module=None and collected_facts=None
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:33:02.480249
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = None
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    ansible_fact_collector = get_ansible_collector(all_collector_classes,
                                                   namespace,
                                                   filter_spec,
                                                   gather_subset,
                                                   gather_timeout,
                                                   minimal_gather_subset)
    assert ansible_fact_collector is not None


# Generated at 2022-06-24 21:33:06.781814
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)

# Generated at 2022-06-24 21:33:13.412384
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    native_python = 1

    def function_0():
        class_0 = type(CollectorMetaDataCollector)
        float_0 = 100.0
        ansible_fact_collector_0 = AnsibleFactCollector(float_0)

        module_0 = 1

        collected_facts_0 = 1
        return ansible_fact_collector_0.collect(module_0, collected_facts_0)
    ansible_fact_collector_0.collectors = iter([class_0(ansible_fact_collector_0)])


# Generated at 2022-06-24 21:33:20.023288
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    float_1 = 100.0
    collected_facts_0 = {float_0: float_1}
    assert ansible_fact_collector_0.collect(collected_facts=collected_facts_0) == {}


# Generated at 2022-06-24 21:33:27.975517
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """
    collect(self, module=None, collected_facts=None)
    :param module:
    :param collected_facts:
    :return:
    """
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)

    ansible_fact_collector_0_collected_facts_1 = {'ansible_eth0': '114.114.114.114'}
    ansible_fact_collector_0_collected_facts_1['ansible_em1.1'] = '192.168.0.3'
    ansible_fact_collector_0_collected_facts_1['ansible_em1.3'] = '192.168.0.2'
    ansible_fact_collector_0_collected_facts_

# Generated at 2022-06-24 21:33:30.322738
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)



# Generated at 2022-06-24 21:33:33.517476
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    #todo: implement test for collect

#

# Generated at 2022-06-24 21:33:36.475102
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    collected_facts = {}
    ansible_fact_collector_0.collect(collected_facts=collected_facts)


# Generated at 2022-06-24 21:34:41.023334
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO: BOGUS
    all_collector_classes = None
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes, namespace, filter_spec,
                                                     gather_subset, gather_timeout,
                                                     minimal_gather_subset)
    pass

# Generated at 2022-06-24 21:34:46.568373
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    default_0 = None
    default_1 = None
    default_2 = None
    default_3 = None
    default_4 = None
    ansible_fact_collector_0 = get_ansible_collector(default_0, default_1, default_2, default_3,
                                                     default_4)
    ansible_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:34:50.336243
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector_0 = test_case_0()
    ansible_fact_collector_0 = AnsibleFactCollector(fact_collector_0)
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:34:54.969844
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = []
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    get_ansible_collector(all_collector_classes,
                          namespace,
                          filter_spec,
                          gather_subset,
                          gather_timeout,
                          minimal_gather_subset)

# Generated at 2022-06-24 21:34:56.927744
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    float_0 = 100.0
    ansible_fact_collector_0 = get_ansible_collector(float_0)



# Generated at 2022-06-24 21:34:59.395961
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """
    AnsibleFactCollector.collect(module=None, collected_facts=None)
    """
    # TODO
    pass


# Generated at 2022-06-24 21:35:02.205135
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    float_0 = 100.0
    try:
        ansible_fact_collector_0 = get_ansible_collector(float_0)
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-24 21:35:03.775073
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    yield (None, False)


# Generated at 2022-06-24 21:35:06.098931
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)


# Generated at 2022-06-24 21:35:09.512542
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    float_0 = 100.0
    ansible_fact_collector_0 = AnsibleFactCollector(float_0)
    ansible_fact_collector_0.collect()
