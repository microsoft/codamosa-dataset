

# Generated at 2022-06-24 21:27:38.241820
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Define a few values
    int_0 = -672
    list_0 = ['e', 'wy', 'k', 'f']

# Generated at 2022-06-24 21:27:44.395854
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -669
    int_1 = -669
    int_2 = -669
    int_3 = -669
    var_0 = CollectorMetaDataCollector(int_0, int_0, int_0)
    var_1 = AnsibleFactCollector(int_1, int_1, int_1)
    var_2 = var_1._filter({'a': 'b'}, int_3)
    var_3 = var_1.collect(int_2, {})


# Generated at 2022-06-24 21:27:46.708483
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -672
    var_0 = get_ansible_collector(int_0, int_0)
    var_1 = var_0.collect()
    print(var_1)


# Generated at 2022-06-24 21:27:52.316442
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -672
    var_0 = get_ansible_collector(int_0, int_0)


# Generated at 2022-06-24 21:27:55.150406
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = -672
    var_0 = get_ansible_collector(int_0, int_0)


# Generated at 2022-06-24 21:27:59.314630
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    try:
        # Test for expected exceptions (from ansible.module_utils.facts)
        test_case_0()
    except Exception as e:
        assert isinstance(e,MissingArgument)


from ansible.module_utils.facts import test_0


# Generated at 2022-06-24 21:28:00.070129
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass  # NOP

# Generated at 2022-06-24 21:28:02.199873
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -672
    var_1 = get_ansible_collector(int_0, int_0)

    var_1.collect()

# Generated at 2022-06-24 21:28:05.178810
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    try:
        # Unit: Call function under test
        test_case_0()
    except:
        print("Exception encountered in test_get_ansible_collector")
        # Unit: Assert if an exception was raised
        raise AssertionError()

# Generated at 2022-06-24 21:28:13.330986
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    print('In test_AnsibleFactCollector_collect')
    int_0 = -672
    var_0 = get_ansible_collector(int_0, int_0)

    # Test 1
    # Verify that AnsibleFactCollector.collect returns a dict with expected keys.
    print('Test 1')
    facts = var_0.collect()
    if not isinstance(facts, dict):
        print('Expected return value of type dict, got', type(facts))
        print('FAILED')
        print()
        return
    expected_keys = ['gather_subset', 'module_setup']

# Generated at 2022-06-24 21:28:20.684394
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:28:23.242392
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:28:27.113289
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = 'module'
    collected_facts_0 = {}
    var_0 = ansible_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0)


# Generated at 2022-06-24 21:28:38.683900
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = set()
    namespace = object()
    filter_spec = object()
    gather_subset = object()
    gather_timeout = object()
    minimal_gather_subset = object()

    # Instantiation of the AnsibleFactCollector, this is the class
    # that produces the top level 'ansible_facts' variable. We don't
    # have to pass called params since they are optional
    get_ansible_collector()

    # Calling the function

# Generated at 2022-06-24 21:28:41.440066
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_1.collect()
    if True:
        assert var_0 is not None


# Generated at 2022-06-24 21:28:44.823796
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    assert type(var_0) == dict



# Generated at 2022-06-24 21:28:47.454401
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collectors = ['ansible', 'facter', 'network', 'ohai', 'os', 'pkg_mgr', 'platform', 'virtual']
    collector = get_ansible_collector(collectors)
    assert collector

# Generated at 2022-06-24 21:28:49.341515
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:28:56.044654
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.all_collector_classes()

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              minimal_gather_subset=['all'])

    # Dummy module to collect facts
    module = {}
    facts = fact_collector.collect(module=module)

    assert facts and 'facter' in facts

# Generated at 2022-06-24 21:28:57.309325
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert False


# Generated at 2022-06-24 21:29:11.485800
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    all_collector_classes = None
    ansible_fact_collector_0 = \
        get_ansible_collector(all_collector_classes,
                              namespace,
                              filter_spec,
                              gather_subset,
                              gather_timeout,
                              minimal_gather_subset)
    var_0 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:29:22.538171
# Unit test for function get_ansible_collector

# Generated at 2022-06-24 21:29:30.794699
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    all_collector_classes = [
        {
            'collector': AnsibleFactCollector
        },
        {
            'collector': collector.BaseFactCollector
        }
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    ansible_facts = fact_collector.collect()

    print(ansible_facts)



# Generated at 2022-06-24 21:29:33.953056
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    var_1 = ansible_fact_collector_1.collect()
    assert True or False , "Cannot currently test"
    return var_1


# Generated at 2022-06-24 21:29:37.921641
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:29:41.880506
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    print(var_0)


# Generated at 2022-06-24 21:29:45.975501
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    assert True

# Generated at 2022-06-24 21:29:49.320241
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:29:51.480343
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_1 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:30:00.475377
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=[])

    # Call method collect with argument module=module_0 and argument collected_facts=var_1
    module_0 = mock.MagicMock(return_value=None)
    var_1 = mock.Mock(return_value=None)
    ansible_fact_collector_0.collect(module=module_0, collected_facts=var_1)

    # Call method collect with argument module=module_0 and argument collected_facts=None
    module_0 = mock.MagicMock(return_value=None)
    ansible_fact_collector_0.collect(module=module_0, collected_facts=None)

    # Call method collect with argument module=None

# Generated at 2022-06-24 21:30:21.805996
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:30:26.549230
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create instances for testing
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collectors = []
    ansible_fact_collector_0.namespace = None

    var_0 = ansible_fact_collector_0.collect()

    assert var_0 == {}


# Generated at 2022-06-24 21:30:29.450115
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:30:32.994922
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_obj = AnsibleFactCollector()
    ansible_fact_collector_ret = ansible_fact_collector_obj.collect()

# Generated at 2022-06-24 21:30:35.779285
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:30:37.268015
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    pytest.main(['-s', __file__])


# Generated at 2022-06-24 21:30:41.233231
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:30:47.336281
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0._filter({'a': 'b'}, ['a']) == [('a', 'b')]
    assert ansible_fact_collector_0.collect() == {}


# Generated at 2022-06-24 21:30:50.286921
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:30:53.641528
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
  ##
  # Testing for the case where a failed fact is collected.
  ##
  ansible_fact_collector_0 = AnsibleFactCollector()
  var_0 = ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:31:15.154811
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:31:18.726098
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=[],
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)

# Generated at 2022-06-24 21:31:26.010464
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    #Collect the facts using the default subset and namespace
    '''
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    return var_0
    '''
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    return var_0


# Generated at 2022-06-24 21:31:31.896040
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = []
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    get_ansible_collector(all_collector_classes,
                          namespace,
                          filter_spec,
                          gather_subset,
                          gather_timeout,
                          minimal_gather_subset)

# Generated at 2022-06-24 21:31:39.352288
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_fact_classes = []
    namespace = AnsibleFactCollector()
    filter_spec = ''
    gather_subset = ['all']
    gather_timeout = 15
    minimal_gather_subset = frozenset()
    get_ansible_collector(all_fact_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset)


if __name__ == "__main__":
    test_get_ansible_collector()

# Generated at 2022-06-24 21:31:43.680142
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_1 = ansible_fact_collector_0.filter_spec.append('test_0')
    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:31:49.284530
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.get_collector_classes(minimal_subset=frozenset())
    collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                      namespace=None,
                                      filter_spec=None,
                                      gather_subset=None,
                                      gather_timeout=None,
                                      minimal_gather_subset=None)
    assert isinstance(collector, AnsibleFactCollector)


# Generated at 2022-06-24 21:31:58.777742
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # we're going to test a bunch of methods, so initialize
    # some dummy classes that we'll use:

    class DummyCollector(object):
        def __init__(self, module=None):
            self.module = module
            self.called = 0

        def collect(self, module=None, collected_facts=None):
            self.called += 1
            return {'dummy': True, '_ansible_': True}

    class ErrorCollector(object):
        def __init__(self, module=None):
            self.module = module
            self.called = 0

        def collect(self, module=None, collected_facts=None):
            raise Exception("I'm catching this.")

    class DependsCollector(object):
        def __init__(self, module=None):
            self.module = module
           

# Generated at 2022-06-24 21:32:07.047003
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class EmptyCollector():

        def __init__(self, namespace):
            pass

        def collect(self):
            return

        def collect_with_namespace(self, collected_facts=None):
            return

    all_collectors = {
        'one': EmptyCollector,
        'two': EmptyCollector,
        'three': EmptyCollector
    }

    # precondition
    assert all_collectors
    assert 'one' in all_collectors
    assert 'two' in all_collectors
    assert 'three' in all_collectors
    assert 'four' not in all_collectors

    # no gather_subset specified
    ansible_fact_collector = get_ansible_collector(all_collectors)
    assert ansible_fact_collector

# Generated at 2022-06-24 21:32:08.662379
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    var_1 = ansible_fact_collector_1.collect()
    assert var_1 is not None


# Generated at 2022-06-24 21:32:59.269229
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert True

if __name__ == '__main__':
    """Calls the test methods of this class"""
    import sys
    import inspect
    import pytest
    from functools import partial

    # Create a list of functions with name beginning with "test"
    item_list = [obj for name, obj in inspect.getmembers(sys.modules[__name__]) if
                 (inspect.isfunction(obj) and name.startswith('test_'))]

    # Replace the test methods in this module with "partial" versions of the same method
    # which adds a call a pytest.raises(AssertionError) to the test method to capture
    # failures.  This allows the failure information to be captured and used by py.test
    # to report the failure.

# Generated at 2022-06-24 21:33:01.834545
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    var_1 = ansible_fact_collector_1.collect()


# Generated at 2022-06-24 21:33:06.893077
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    assert(var_0 == {})

# Generated at 2022-06-24 21:33:14.093008
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = None
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    ansible_fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                                   namespace=namespace, filter_spec=filter_spec,
                                                   gather_subset=gather_subset,
                                                   gather_timeout=gather_timeout,
                                                   minimal_gather_subset=minimal_gather_subset)


# Generated at 2022-06-24 21:33:16.500364
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    for i in range(10):
        test_case_0()

# Generated at 2022-06-24 21:33:25.308357
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes = collector.FACT_COLLECTORS

    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None

    ansible_collector = get_ansible_collector(all_collector_classes,
                                              namespace,
                                              filter_spec,
                                              gather_subset,
                                              gather_timeout,
                                              minimal_gather_subset)

    collected_facts = ansible_collector.collect()

    # ansible_facts contains the module_setup fact
    assert collected_facts['ansible_facts']['module_setup']

# Generated at 2022-06-24 21:33:35.254645
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:33:41.548584
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector(namespace=None)
    module = None
    collected_facts = None
    var_0 = ansible_fact_collector_0.collect(module=module,
                                             collected_facts=collected_facts)
    assert(var_0 == {})


# Generated at 2022-06-24 21:33:43.976964
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:33:46.841479
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    assert 'ansible_facts' in var_0
    collection = dict(ansible_facts=var_0)
    assert collection == {}


# Generated at 2022-06-24 21:36:48.408510
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None

    assert get_ansible_collector(namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset)


if __name__ == "__main__":
    # Unit test for function test_case_0
    test_case_0()

    # Unit test for function test_get_ansible_collector
    test_get_ansible_collector()

# Generated at 2022-06-24 21:36:50.951858
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:36:54.389420
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    ansible_fact_collector_1.collect()
    var_1 = ansible_fact_collector_1.collect()


# Generated at 2022-06-24 21:36:58.248996
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    assert not var_0


# Generated at 2022-06-24 21:37:03.919583
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = \
        get_ansible_collector(all_collector_classes=collector.ALL_COLLECTOR_CLASSES,
                              gather_subset='all',
                              filter_spec=['fact_id'],
                              minimal_gather_subset=[])

if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:37:07.278008
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    assert var_0 == dict()


# Generated at 2022-06-24 21:37:17.297485
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes_value_0 = '*'
    filter_spec_value_0 = None
    gather_subset_value_0 = 'all'
    gather_timeout_value_0 = 0
    minimal_gather_subset_value_0 = []
    get_ansible_collector(all_collector_classes=all_collector_classes_value_0,
                          filter_spec=filter_spec_value_0,
                          gather_subset=gather_subset_value_0,
                          gather_timeout=gather_timeout_value_0,
                          minimal_gather_subset=minimal_gather_subset_value_0)

if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:37:24.293097
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = None
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    expected = get_ansible_collector(all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset)
    ansible_fact_collector = get_ansible_collector(all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset)
    assert ansible_fact_collector == expected
