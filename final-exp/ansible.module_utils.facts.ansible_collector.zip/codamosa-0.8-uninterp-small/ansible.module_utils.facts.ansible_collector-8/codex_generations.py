

# Generated at 2022-06-24 21:27:44.153002
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [collector.FacterFactCollector,
                             collector.OhaiFactCollector]

    for subset in ['all',
                   'kernel',
                   'ohai',
                   'ansible_local',
                   '!ansible_local'
                   ]:

        ansible_fact_collector = get_ansible_collector(all_collector_classes,
                                                       gather_subset=subset,
                                                       filter_spec='*')

        facts = ansible_fact_collector.collect()

        print('Facts:')
        print(facts)


# Unit test if we run standalone
if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:27:48.791489
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''
    Test collect method for AnsibleFactCollector.
    '''
    
    ansible_fact_collector = AnsibleFactCollector()

    assert ansible_fact_collector.collect() == {}


# Generated at 2022-06-24 21:27:57.638358
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Setup
    collector.get_gather_subset_info = lambda all_collector_classes, minimal_gather_subset, gather_subset: []


    # Exercise
    actual_result = get_ansible_collector(all_collector_classes=[])

    # Verify
    assert isinstance(actual_result, AnsibleFactCollector)
    assert actual_result.collectors == [CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)]
    assert actual_result.filter_spec == None


# Generated at 2022-06-24 21:28:00.070460
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:28:10.621212
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts import ansible_all_collectors
    ansible_fact_collector = get_ansible_collector(ansible_all_collectors, gather_subset=['all'])
    assert ansible_fact_collector.collectors is not None
    assert ansible_fact_collector.collectors.__len__() != 0
    assert ansible_fact_collector.namespace is None

    ansible_fact_collector = get_ansible_collector(ansible_all_collectors, gather_subset=['all'], filter_spec=['*'])
    assert ansible_fact_collector.collectors is not None
    assert ansible_fact_collector.collectors.__len__() != 0


# Generated at 2022-06-24 21:28:20.663244
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.virtual import VirtualFactCollector
    import ansible.module_utils.facts.network.interfaces as network_interfaces
    import ansible.module_utils.facts.network.ipv4 as network_ipv4


# Generated at 2022-06-24 21:28:23.384859
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:28:30.483225
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    def test_collector_class(namespace=None):
        class TestCollector(collector.BaseFactCollector):
            name = 'testcollector'
            _fact_ids = set(['test_fact'])
            def collect(self, module=None, collected_facts=None):
                return {'test_fact': 'test_value'}

        return TestCollector(namespace=namespace)

    ansible_fact_collector = AnsibleFactCollector(collectors=[test_collector_class()])
    facts_dict = ansible_fact_collector.collect()
    assert facts_dict['test_fact'] == 'test_value'



# Generated at 2022-06-24 21:28:40.418239
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_1 = AnsibleFactCollector()
    ansible_fact_collector_1_collect = ansible_fact_collector_1.collect()
    ansible_fact_collector_1_collect_keys = ansible_fact_collector_1_collect.keys()

    ansible_fact_collector_2 = AnsibleFactCollector(collectors=None, filter_spec='*')
    ansible_fact_collector_2_collect = ansible_fact_collector_2.collect()
    ansible_fact_collector_2_collect_keys = ansible_fact_collector_2_collect.keys()

    ansible_fact_collector_3 = AnsibleFactCollector(collectors=None, filter_spec='')
    ansible_fact_collector_3_

# Generated at 2022-06-24 21:28:50.718354
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [MockCollectingClass]
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    ansible_fact_collector = get_ansible_collector(all_collector_classes,
                                                   namespace,
                                                   filter_spec,
                                                   gather_subset,
                                                   gather_timeout,
                                                   minimal_gather_subset)
    assert type(ansible_fact_collector) == AnsibleFactCollector
    assert ansible_fact_collector.collectors[0] == MockCollectingClass()
    assert ansible_fact_collector.fact_ids == {'mock_collecting_class_fact_id'}


# Generated at 2022-06-24 21:29:01.777297
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    fact_collector = \
        get_ansible_collector(all_collector_classes=collector.collector_classes(),
                              filter_spec=['*'],
                              gather_subset=['!all'],
                              gather_timeout=None,
                              minimal_gather_subset=None)

    collected_facts = \
        fact_collector.collect(module=None,
                               collected_facts={})

    print(collected_facts)

if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-24 21:29:11.358364
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # test_case_0 : gather_subset=all, filter_spec=['*'], namespace=None, expected facts:
    #            num_facts = 41, len(fact_keys) = 41
    ansible_fact_collector_0 = AnsibleFactCollector()
    test_case_0_facts = ansible_fact_collector_0.collect()
    assert len(test_case_0_facts) == 41, \
        'test_case_0_facts = %s, len(test_case_0_facts) = %d, expected len = %d' % (
            test_case_0_facts, len(test_case_0_facts), 41)

    # test_case_1 : gather_subset=all, filter_spec=['ansible_*'], namespace=None, expected facts:
   

# Generated at 2022-06-24 21:29:15.904949
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    ansible_collectors = ansible.module_utils.facts.collector

    ansible_fact_collector_0 = get_ansible_collector(ansible_collectors)


# Generated at 2022-06-24 21:29:20.119573
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    facts_dict = ansible_fact_collector_0.collect()
    test_case_0()
    test_case_0_0()
    test_case_0_0_0()
    test_case_1()



# Generated at 2022-06-24 21:29:23.530851
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collectors = []
    ansible_fact_collector_0.collect(module=None)


# Generated at 2022-06-24 21:29:34.185185
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    fact_0_dict = {'ansible_os_family': "Debian", }
    fact_1_dict = {'ansible_all_ipv4_addresses': ["10.10.10.10", ], }
    fact_2_dict = {'ansible_bios_date': "04/01/2014", }
    fact_3_dict = {'ansible_architecture': "", }
    fact_4_dict = {'ansible_distribution': "Ubuntu", }

# Generated at 2022-06-24 21:29:37.349025
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_facts = ansible_fact_collector_0.collect()
    assert ansible_facts is not None



# Generated at 2022-06-24 21:29:39.814690
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector(collector.FACT_COLLECTOR_OBJECTS)


# Generated at 2022-06-24 21:29:45.348468
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    ansible_fact_collector_2 = AnsibleFactCollector()
    ansible_fact_collector_1.collect()
    ansible_fact_collector_2.collect()


# Generated at 2022-06-24 21:29:50.005359
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    expected_dict = {}
    actual_dict = ansible_fact_collector_0.collect()
    assert actual_dict == expected_dict


# Generated at 2022-06-24 21:30:06.390487
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()


# Generated at 2022-06-24 21:30:09.081469
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:30:17.874421
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    module_setup = True
    all_collector_classes = {}
    namespace = None
    filter_spec = ['*']
    gather_subset = ['all']
    gather_timeout = None
    minimal_gather_subset = ['all']

    ansible_fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                                   namespace=namespace,
                                                   filter_spec=filter_spec,
                                                   gather_subset=gather_subset,
                                                   gather_timeout=gather_timeout,
                                                   minimal_gather_subset=minimal_gather_subset)

    facts_dict = ansible_fact_collector.collect(module=None, collected_facts=None)


# Generated at 2022-06-24 21:30:21.932923
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    dictionary1 = {}
    dictionary2 = {}
    ansible_fact_collector_0.namespace = dictionary1
    ansible_fact_collector_0.collectors = [dictionary2]
    with pytest.raises(NotImplementedError): ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:30:25.593628
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Setup test case data
    ansible_fact_collector_0 = AnsibleFactCollector()

    # Execute the AnsibleFactCollector.collect(module, collected_facts) method
    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:30:31.615872
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """AnsibleFactCollector - Test collect method

       Test that the collect method returns a dictionary when no ansible_facts
       are returned by the collect_with_namespace method"""

    test_output = {}

    # test AnsibleFactCollector.collect returns a dictionary when no ansible_facts returned
    ansible_fact_collector_0 = AnsibleFactCollector()
    mock_collectors = [MockCollector('test_collector1'), MockCollector('test_collector2')]
    ansible_fact_collector_0.collectors = mock_collectors
    result_x = ansible_fact_collector_0.collect()
    assert isinstance(result_x, dict), "Expected <class 'dict'>, got %s" % type(result_x)

# Generated at 2022-06-24 21:30:43.209638
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = \
        get_ansible_collector(all_collector_classes=[],
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)
    assert ansible_fact_collector_0.filter_spec is None
    assert ansible_fact_collector_0.collectors == [
        CollectorMetaDataCollector(gather_subset=[], module_setup=True)]
    assert ansible_fact_collector_0.namespace is None


# Generated at 2022-06-24 21:30:48.465751
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCaseAnsibleFactCollectorCollect(object):
        def __init__(self):
            self.input = None

        def run_test(self):
            ansible_fact_collector_0 = AnsibleFactCollector()
            ansible_fact_collector_0.collect(self.input)

    # Define input and expected output
    test_case_0 = TestCaseAnsibleFactCollectorCollect()
    test_case_0.input = module_0 = None
    test_case_0.run_test()

    # Define input and expected output
    test_case_1 = TestCaseAnsibleFactCollectorCollect()
    test_case_1.input = module_1 = None
    test_case_1.run_test()

# Generated at 2022-06-24 21:30:52.219195
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = get_ansible_collector(None, None)
    assert(isinstance(ansible_fact_collector_0, AnsibleFactCollector))


# Generated at 2022-06-24 21:31:00.443471
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector

    ansible_fact_collector = get_ansible_collector(all_collector_classes=[
        ansible.module_utils.facts.collector.FacterCollector,
        ansible.module_utils.facts.collector.OhaiCollector])
    collected_facts = ansible_fact_collector.collect()

    # make sure the subset fact exists
    assert collected_facts['gather_subset'] == ['all'], \
        'gather_subset should be [all] not %s' % collected_facts['gather_subset']
    assert collected_facts['module_setup'] == True, \
        'module_setup should be True'



# Generated at 2022-06-24 21:31:12.529277
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}, 'Failed to test_AnsibleFactCollector_collect'



# Generated at 2022-06-24 21:31:15.500391
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    fact_collector = AnsibleFactCollector()

    collected_facts = {}
    collected_facts = fact_collector.collect(module=None, collected_facts=collected_facts)

    assert collected_facts is not None


# Generated at 2022-06-24 21:31:22.164013
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_facts = ansible_fact_collector.collect()
    assert isinstance(ansible_facts, dict)


# Generated at 2022-06-24 21:31:25.390247
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:31:27.994718
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()




# Generated at 2022-06-24 21:31:35.651912
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    print("TESTING: get_ansible_collector")
    ansible_fact_collector = get_ansible_collector(all_collector_classes=collector.C.__subclasses__())
    facts = ansible_fact_collector.collect()
    assert isinstance(facts, dict)
    print(facts)
    # execute some assertions against facts
    assert isinstance(facts['ansible_all_ipv4_addresses'], list)

# Generated at 2022-06-24 21:31:39.420999
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_facts = ansible_fact_collector_0.collect()
    assert isinstance(ansible_facts, dict)



# Generated at 2022-06-24 21:31:49.545350
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes = collector.get_collector_classes()

    # caller passes gather_subset, minimal_gather_subset.
    # gather_subset adds 'all' to the subset.
    fact_collector_1 = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=['!min'],
                              minimal_gather_subset=['min'])

    # gather_subset is None. minimal_gather_subset is None.
    # gather_subset is set to 'all'.
    fact_collector_2 = \
        get_ansible_collector(all_collector_classes=all_collector_classes)

    # gather_subset is 'all'. minimal_gather_subset is None

# Generated at 2022-06-24 21:31:58.974626
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_1 = get_ansible_collector(None)
    ansible_fact_collector_2 = get_ansible_collector(None, gather_subset='all')
    ansible_fact_collector_3 = get_ansible_collector(
        all_collector_classes=[collector.BaseFactCollector],
        filter_spec=['ansible_*', 'facter_*'],
        namespace='ansible_')
    ansible_fact_collector_4 = get_ansible_collector(
        all_collector_classes=[collector.BaseFactCollector],
        filter_spec=['ansible_*', 'facter_*'],
        namespace='ansible_',
        gather_subset='all')

# Generated at 2022-06-24 21:32:02.297355
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    collected_facts = {}
    result = ansible_fact_collector.collect(collected_facts=collected_facts)
    assert result is None


# Generated at 2022-06-24 21:32:28.197604
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    module_setup = True
    gather_subset = ['all']
    gather_timeout = 10
    minimal_gather_subset = frozenset()
    collector_classes = ['all']
    namespace = None
    filter_spec = 'all'

    result = get_ansible_collector(module_setup, gather_subset, gather_timeout, minimal_gather_subset, collector_classes, namespace, filter_spec)

    assert result

# Generated at 2022-06-24 21:32:30.272852
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
        ansible_fact_collector = AnsibleFactCollector()

        assert ansible_fact_collector.collect() == {}



# Generated at 2022-06-24 21:32:34.093861
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector(filter_spec=['ansible_stress'])
    ansible_fact_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 21:32:39.859241
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # 1. Create a new instance of AnsibleFactCollector
    ansible_fact_collector_0 = AnsibleFactCollector()

    # 2. Execute an existing fact collector
    fact_dict = ansible_fact_collector_0.collect()

    # 3. Validate that fact collection was successful
    assert fact_dict is not None


# Generated at 2022-06-24 21:32:43.065583
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    print(ansible_fact_collector_0.collect())

if __name__ == "__main__":
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:32:48.569153
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Just make sure get_ansible_collector does not blow up.'''
    import ansible.module_utils.facts.collector
    ansible_fact_collector_0 = \
        get_ansible_collector(
            all_collector_classes=ansible.module_utils.facts.collector.all_collectors)

# Generated at 2022-06-24 21:32:53.401808
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector()
    assert isinstance(ansible_fact_collector.collectors, list)
    assert len(ansible_fact_collector.collectors) > 0
    for collector in ansible_fact_collector.collectors:
        assert isinstance(collector, collector.BaseFactCollector)


if __name__ == "__main__":

    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:33:00.189816
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    expected_ansible_facts = {
        'ansible_eth0': {
            'module': 'ansible.module_utils.basic.AnsibleModule',
            'state': 'up',
            'type': 'ether',
            'macaddress': '00:50:56:a5:92:45'
            }
        }

    facts_dict = ansible_fact_collector_0.collect()
    assert facts_dict == expected_ansible_facts


# Generated at 2022-06-24 21:33:10.177261
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [
        collector.NetworkCollector,
        collector.HardwareCollector,
        collector.PlatformCollector,
        collector.VirtualCollector,
        collector.FacterCollector,
        collector.OhaiCollector,
        collector.ConfigContextCollector,
        collector.LocalCollector
    ]
    fact_collector = get_ansible_collector(all_collector_classes)
    #print(fact_collector.facts)

if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:33:13.954470
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:33:52.885134
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.get_collector_classes(
            path_prefix=collector.COLLECTOR_PATH_PREFIX,
            base_class=collector.BaseFactCollector,
            namespace_class=None)
    fact_collector = \
        get_ansible_collector(all_collector_classes,
                              gather_subset=['all'])
    # TODO: add a proper test case

# Generated at 2022-06-24 21:33:56.395115
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}


# Generated at 2022-06-24 21:34:05.465665
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Test where we only have a subset of collectors.
    collector_classes = [collector.GenericFactCollector]
    ansible_fact_collector = get_ansible_collector(all_collector_classes=collector.FACT_COLLECTOR_CLASSES,
                                                   gather_subset=['network', 'virtual', 'min'],
                                                   gather_timeout=15,
                                                   filter_spec=['*'],
                                                   minimal_gather_subset=collector.MINIMAL_GATHER_SUBSET)
    facts = ansible_fact_collector.collect()
    assert len(facts) > 0

    # Test using all collectors

# Generated at 2022-06-24 21:34:08.229991
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:34:09.270313
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = test_case_0()
    assert fact_collector.collect() == {}

# Generated at 2022-06-24 21:34:14.505626
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector(['all'])
    print(ansible_fact_collector)

if __name__ == '__main__':
    # Standard module execution.
    test_get_ansible_collector()

# Generated at 2022-06-24 21:34:17.029836
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:34:20.914969
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    get_ansible_collector(all_collector_classes)

# pylint: disable=W0621

# Generated at 2022-06-24 21:34:24.938073
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    res = ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:34:25.515223
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-24 21:35:38.751383
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    result = ansible_fact_collector_0.collect()

    assert(isinstance(result, dict))
    assert(len(result) == 0)


# Generated at 2022-06-24 21:35:41.511658
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    target_0 = ansible_fact_collector_0.collect()
    print(target_0)
    assert target_0 == {}


# Generated at 2022-06-24 21:35:48.332472
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # tests with gather_subset=['all'], namespace=None, filter_spec=None
    ansible_fact_collector_1 = get_ansible_collector(all_collector_classes=None,
                                                     namespace=None,
                                                     filter_spec=None,
                                                     gather_subset=None,
                                                     gather_timeout=None,
                                                     minimal_gather_subset=None)

    # tests with gather_subset=['all'], namespace=None, filter_spec=None, gather_timeout=None

# Generated at 2022-06-24 21:35:53.801458
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector(all_collector_classes=[],
                                                   namespace=[],
                                                   filter_spec=[],
                                                   gather_subset=[],
                                                   gather_timeout=0,
                                                   minimal_gather_subset=[])
    assert ansible_fact_collector is not None

if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:35:55.713753
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    result = ansible_fact_collector.collect()
    assert isinstance(result, dict)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:36:03.263005
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # fixture for AnsibleFactCollector.collect
    class CollectCollectorMockCollector(object):
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    class CollectCollectorMock(AnsibleFactCollector):
        def __init__(self, collectors=None, namespace=None):
            ansible_fact_collector_0 = AnsibleFactCollector(collectors=collectors, namespace=namespace)

        @classmethod
        def _filter(cls, facts_dict, filter_spec):
            return {'foo': 'bar'}

    # pass

    import ansible.module_utils.facts.collector

    m1 = CollectCollectorMockCollector()

    # pass


# Generated at 2022-06-24 21:36:10.175991
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = set([])
    gather_timeout = None
    gather_subset = None
    filter_spec = None
    minimal_gather_subset = None

    # Normal execution with no options
    collector_0 = get_ansible_collector(all_collector_classes,
                                        filter_spec=filter_spec,
                                        gather_subset=gather_subset,
                                        gather_timeout=gather_timeout,
                                        minimal_gather_subset=minimal_gather_subset)



# Generated at 2022-06-24 21:36:16.351896
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector = AnsibleFactCollector()
    collected_facts = ansible_fact_collector.collect(module=None, collected_facts={})

    assert(type(collected_facts) is dict)


# Generated at 2022-06-24 21:36:18.562265
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    test_string = 'abc'
    ansible_fact_collector_0.collect(test_string)



# Generated at 2022-06-24 21:36:22.844244
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}
