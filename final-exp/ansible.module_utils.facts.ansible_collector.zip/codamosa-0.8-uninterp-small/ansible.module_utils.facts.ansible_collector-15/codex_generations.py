

# Generated at 2022-06-24 21:27:39.316076
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    sys.modules['__main__'].gather_timeout = 13
    class MockModule:
        pass
    class MockCollectorMetaDataCollector:
        def __init__(self, gather_subset):
            self.gather_subset = gather_subset

    mock_module = MockModule()
    mock_collector_meta_data_collector = MockCollectorMetaDataCollector('all')
    assert {'gather_timeout': 13, 'gather_subset': 'all', 'module_setup': True} == \
        mock_collector_meta_data_collector.collect(mock_module)


# Generated at 2022-06-24 21:27:40.548820
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    try:
        pass
    except:
        pass


# Generated at 2022-06-24 21:27:48.563875
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    int_0 = 954
    collector_meta_data_collector_0 = CollectorMetaDataCollector()

    # Call method on object
    result = collector_meta_data_collector_0.collect()

    assert isinstance(result, dict)
    # Check that the fact 'gather_subset' is set to []
    assert result['gather_subset'] == [], "result['gather_subset'] != []"
    # Check that the fact 'module_setup' is set to True
    assert result['module_setup'] is True, "result['module_setup'] == True"


# Generated at 2022-06-24 21:27:50.631713
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # TODO: Add test code
    assert True


# Generated at 2022-06-24 21:27:51.790233
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 21:27:57.269777
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # NOTE: needs a real test
    collector_metadata_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0.collect(module='setup')


# Generated at 2022-06-24 21:27:58.201294
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_case_0()



# Generated at 2022-06-24 21:28:05.460250
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    module_setup = False
    gather_subset = ['a', 'b', 'c']
    namespace = ansible.module_utils.facts.ansible_collector.AnsibleDefaultFactNamespace()
    collector_meta_data_collector_0 = CollectorMetaDataCollector(gather_subset=gather_subset, module_setup=module_setup)
    module = None
    collected_facts = None
    collector_meta_data_collector_0.collect(module=module, collected_facts=collected_facts)


# Generated at 2022-06-24 21:28:13.361827
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    int_0 = 31
    int_1 = -36
    collectors_0 = []
    gather_subset_0 = ['margin']
    module_setup_0 = True
    collector_metadata_collector_0 = \
        CollectorMetaDataCollector(collectors=collectors_0,
                                   gather_subset=gather_subset_0,
                                   module_setup=module_setup_0)
    module_0 = None

# Generated at 2022-06-24 21:28:25.395774
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = -2555
    collectors_0 = [int_0]
    Namespace_0 = AnsibleFactCollector(collectors = collectors_0 )
    all_collector_classes_0 = ['network']
    filter_spec_0 = Namespace_0
    gather_subset_0 = ['!all']
    gather_timeout_0 = int_0
    minimal_gather_subset_0 = frozenset(['distribution', 'virtual'])
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes_0,
                                                     Namespace_0,
                                                     filter_spec_0,
                                                     gather_subset_0,
                                                     gather_timeout_0,
                                                     minimal_gather_subset_0)



# Generated at 2022-06-24 21:28:34.656073
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # arrange
    ansible_fact_collector = AnsibleFactCollector()
    module = None
    collected_facts = None

    # act
    retval = ansible_fact_collector.collect(module, collected_facts)

    # assert
    assert retval['gather_subset'] == ['all']
    assert retval['module_setup'] == True


# Generated at 2022-06-24 21:28:40.554557
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    module = FakeModule()
    collected_facts = ['__ansible_module__']
    collector_meta_data_collector_0 = CollectorMetaDataCollector(collectors=None,
                                                                 namespace=None,
                                                                 gather_subset='__ansible_module__',
                                                                 module_setup=None)
    ansible_facts = collector_meta_data_collector_0.collect(module=module,
                                                            collected_facts=collected_facts)
    assert not ansible_facts


# Generated at 2022-06-24 21:28:50.829948
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_arg_spec = dict()
    test_arg_spec['collectors'] = None
    test_arg_spec['namespace'] = None
    test_arg_spec['gather_subset'] = None
    test_arg_spec['module_setup'] = None
    test_arg_spec['module'] = None
    test_arg_spec['collected_facts'] = None
    test_arg_spec['module'] = 'ansible.module_utils.facts.ansible_collector.GatherSubsetCollector'

# Generated at 2022-06-24 21:28:53.946259
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_case_0()



# Generated at 2022-06-24 21:28:56.200965
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:28:58.966494
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    n = 1
    result = CollectorMetaDataCollector().collect()
    assert result is not None



# Generated at 2022-06-24 21:29:03.946599
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()



# Generated at 2022-06-24 21:29:06.296630
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = CollectorMetaDataCollector()

# Generated at 2022-06-24 21:29:12.663269
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    module_0 = None
    collected_facts_0 = None
    assert isinstance(collector_meta_data_collector_0.collect(module_0, collected_facts_0),
                      dict)


# Generated at 2022-06-24 21:29:15.354089
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 11173
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:29:26.994524
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -18179
    ansible_fact_collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:29:33.142881
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -5
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = None
    collected_facts_0 = {}
    facts_dict_0 = ansible_fact_collector_0.collect(module_0, collected_facts_0)
    assert facts_dict_0 is not None



# Generated at 2022-06-24 21:29:38.200573
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes_0 = {'test_case_0': test_case_0}

    # Testing for exception (TypeError) 'collectors' is not iterable
    try:
        get_ansible_collector(all_collector_classes=all_collector_classes_0)
    except TypeError:
        pass
    else:
        assert False, "Expected exception"


# Generated at 2022-06-24 21:29:45.836046
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()

    module_0 = mock.Mock()
    collected_facts_0 = mock.Mock()

    # Invoke method
    return_value = ansible_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0)
    assert return_value is None


# Generated at 2022-06-24 21:29:50.960703
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = None
    namespace = 'namespace'
    filter_spec = ['filter_spec']
    gather_subset = ['all']
    gather_timeout = 'gather_timeout'
    minimal_gather_subset = 'minimal_gather_subset'



# Generated at 2022-06-24 21:29:58.123722
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_collector_0 = get_ansible_collector(ansible_fact_collector_0)
    print('ansible_collector_0:\n%s' % ansible_collector_0)


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-24 21:30:03.238371
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Check if there is a collector
    # Case in which there is a collector
    if ansible_fact_collector_0.collectors == [] :
        ansible_fact_collector_0.collectors.append(ansible_fact_collector_0)

    # Case in which there is no collector
    if ansible_fact_collector_0.collectors == [] :
        pass


# Generated at 2022-06-24 21:30:14.737014
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_1 = 844
    ansible_fact_collector_1 = AnsibleFactCollector()
    # collector_class = 'AnsibleFactCollector'
    # filter_spec = '*'
    # module = None
    # namespace = AnsibleFactCollector
    # collectors = collector_class.split(',')
    # collectors[0] = collector_class
    # ansible_fact_collector_0 = AnsibleFactCollector(collectors=collectors, filter_spec=filter_spec)
    # ansible_fact_collector_0.collect(module=module, namespace=namespace)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:30:18.431191
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:30:26.330778
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    all_collector_classes_0 = []
    namespace_0 = None
    filter_spec_0 = []
    gather_subset_0 = ['all']
    gather_timeout_0 = -3442
    minimal_gather_subset_0 = frozenset()
    ansible_fact_collector_1 = get_ansible_collector(all_collector_classes_0, namespace_0, filter_spec_0, gather_subset_0, gather_timeout_0, minimal_gather_subset_0)
    test_value_1 = ansible_fact_collector_1.name
    assert test_value_1 == 'ansible'


# Generated at 2022-06-24 21:31:07.953658
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    print('\n#### Unit test for method collect of class AnsibleFactCollector')

# Generated at 2022-06-24 21:31:14.191886
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_module_utils_facts_collector__0 = AnsibleFactCollector.collect(ansible_fact_collector_0)
    return


# Generated at 2022-06-24 21:31:17.718594
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # First, create the class instance
    # This is currently a no-op
    fact_collector = get_ansible_collector()


if __name__ == '__main__':
    # Run the unit test
    test_get_ansible_collector()

# Generated at 2022-06-24 21:31:22.695373
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_module_0 = AnsibleModule()
    ansible_fact_collector_0.collect(ansible_module_0)




# Generated at 2022-06-24 21:31:35.163479
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    all_collector_classes_0 = ({}, str, )
    namespace_0 = 7459
    filter_spec_0 = 6074
    gather_timeout_0 = ({}, -962.2628, )
    gather_subset_0 = str
    minimal_gather_subset_0 = frozenset()
    get_ansible_collector(all_collector_classes_0,
                          namespace_0,
                          filter_spec_0,
                          gather_subset_0,
                          gather_timeout_0,
                          minimal_gather_subset_0)

# Generated at 2022-06-24 21:31:37.046993
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 6
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:31:48.695142
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    pytest.skip("This test is failing. Needs to be fixed by Ad hoc team.")

    dummy_collector_class_0 = collector.BaseCollector()
    class_name_0 = "BaseCollector"
    assert class_name_0 == dummy_collector_class_0.__name__

    all_collector_classes_0 = [dummy_collector_class_0]
    namespace_0 = "test_namespace"
    filter_spec_0 = ""
    gather_subset_0 = ["all"]
    gather_timeout_0 = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset_0 = frozenset()

# Generated at 2022-06-24 21:31:53.435709
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    module_0 = {}
    collected_facts_0 = {}
    # Test case for method collect of class AnsibleFactCollector
    ansible_fact_collector_0 = AnsibleFactCollector()
    test_case_AnsibleFactCollector_collect_0(module_0, collected_facts_0, ansible_fact_collector_0)


# Generated at 2022-06-24 21:31:59.308312
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = None
    collected_facts_0 = {}
    dict_0 = ansible_fact_collector_0.collect(module_0, collected_facts_0)
    print(dict_0)
    # assert isinstance(dict_0, dict)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:32:01.744329
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:32:28.901981
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:32:37.618561
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = None
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None


    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)
    #assert ansible_fact_collector.name == 'gather_subset'
    #assert ansible_fact_collector._fact_ids == set([])

# Generated at 2022-06-24 21:32:48.486275
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = all_collector_classes=collector.list_collector_classes()
    namespace='ansible_'
    filter_spec='*'
    gather_subset='network, virtual'
    gather_timeout=30
    minimal_gather_subset='network, virtual'

    # Invoke method
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes,
                               namespace,
                               filter_spec,
                               gather_subset,
                               gather_timeout,
                               minimal_gather_subset)

    # get ansible_facts
    facts_dict = ansible_fact_collector_0.collect()

    assert 'os_version' in facts_dict
    assert 'network' in facts_dict

# Generated at 2022-06-24 21:32:50.300156
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:32:58.452518
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes = CollectorMetaDataCollector()
    namespace = AnsibleFactCollector()
    filter_spec = CollectorMetaDataCollector()
    gather_subset = AnsibleFactCollector()
    gather_timeout = CollectorMetaDataCollector()
    minimal_gather_subset = CollectorMetaDataCollector()
    try:
        get_ansible_collector(collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset)
    except (TypeError, ValueError, NameError, AttributeError) as e:
        pass

# Generated at 2022-06-24 21:33:09.557220
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    # test for normal case
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert fact_collector.collect(module=None, collected_facts=None) == ansible_fact_collector_0.collect(module=None, collected_facts=None)
    # test for exceptions case
    ansible_fact_collector_1 = AnsibleFactCollector()
    assert fact_collector.collect(module=None, collected_facts=None) == ansible_fact_collector_1.collect(module=None, collected_facts=None)
    # test for exceptions case
    ansible_fact_collector_2 = AnsibleFactCollector()
    assert fact_collector.collect(module=None, collected_facts=None) == ansible_fact_

# Generated at 2022-06-24 21:33:14.231095
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:33:17.955722
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:33:26.958266
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = -2555
    int_1 = -768
    int_2 = -4
    fact_collector_0 = collector.FactCollector()
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect(all_collectors())
    fact_collector_0.collect(all_collectors())
    int_3 = -1337
    ansible_fact_collector_2 = get_ansible_collector(all_collectors())
    ansible_fact_collector_2.collect(all_collectors())

if __name__ == '__main__':
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    print(ansible_fact_collector_0)


# Generated at 2022-06-24 21:33:29.314032
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()



# Generated at 2022-06-24 21:34:50.611176
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    global int_0
    global ansible_fact_collector_0
    ansible_fact_collector_0 = get_ansible_collector(int_0)


if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:34:54.563021
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    filter_spec = ['*']
    gather_subset = 'all'
    gather_timeout = 60
    minimal_gather_subset = 'all'

    ansible_fact_collector_1 = get_ansible_collector(filter_spec, gather_subset, gather_timeout, minimal_gather_subset)


# Generated at 2022-06-24 21:34:56.531613
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:34:57.590146
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    assert True == True


# Generated at 2022-06-24 21:34:59.748611
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -81
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = None
    collected_facts_0 = {}
    ansible_fact_collector_0.collect(module_0, collected_facts_0)


# Generated at 2022-06-24 21:35:06.560021
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()

    assert ansible_fact_collector_0.collect() == {}, \
        'Test 0 of 1 failed. Test collect of AnsibleFactCollector failed.'


# Generated at 2022-06-24 21:35:14.527564
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # import the module that we are going to test
    from ansible.module_utils.facts import ansible_collector
    # set up our test data
    all_collector_classes = list()
    namespace = dict()
    filter_spec = list()
    gather_subset = list()
    gather_timeout = None
    minimal_gather_subset = frozenset()
    # call our function with the test data and test that the expected result is returned
    result = ansible_collector.get_ansible_collector(all_collector_classes,
                                                     namespace,
                                                     filter_spec,
                                                     gather_subset,
                                                     gather_timeout,
                                                     minimal_gather_subset)



# Generated at 2022-06-24 21:35:17.085216
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:35:19.545207
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collectors = ["all", "network", "hardware"]
    for collector in collectors:
        obj = get_ansible_collector(collector, ["all"], ["all"], [None], None)
        assert obj is not None

# Generated at 2022-06-24 21:35:21.917279
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-24 21:36:28.485517
# Unit test for function get_ansible_collector

# Generated at 2022-06-24 21:36:30.416016
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert True # TODO: implement your test here


# Generated at 2022-06-24 21:36:37.930623
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # test case 0
    print("\ntest case 0")
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = "module_0"
    collected_facts_0 = {}
    # call method collect of AnsibleFactCollector object
    ansible_fact_collector_0.collect(module_0, collected_facts_0)


# Generated at 2022-06-24 21:36:42.204375
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2585
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = None
    collected_facts_0 = {}
    ansible_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0)



# Generated at 2022-06-24 21:36:45.490320
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}


# Generated at 2022-06-24 21:36:46.298727
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()

# Generated at 2022-06-24 21:36:51.174503
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_facts_0 = {}
    ansible_fact_collector_0.collect(module=None, collected_facts=ansible_facts_0)
    assert ansible_facts_0 == {}



# Generated at 2022-06-24 21:36:58.148208
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 5
    ansible_fact_collector_0 = AnsibleFactCollector()
    __tracebackhide__ = True
    try:
        module_0 = None
        collected_facts_0 = None
        ansible_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0)
    except:
        __tracebackhide__ = False
        raise


# Generated at 2022-06-24 21:37:07.898019
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from pprint import pprint
    import json
    import inspect
    import os
    import sys
    import types
    import unittest
    import platform

    module_name = 'ansible_fact_collector'
    if module_name not in sys.modules:
        __import__(module_name)
    module_instance = sys.modules[module_name]
    path_to_me = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    if path_to_me not in sys.path:
        sys.path.insert(0, path_to_me)

    class_name = 'AnsibleFactCollector'

# Generated at 2022-06-24 21:37:12.529100
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = -2555
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = None
    collected_facts_0 = {}
    facts_dict = ansible_fact_collector_0.collect(module_0,collected_facts_0)
    assert facts_dict == {}

