

# Generated at 2022-06-24 21:27:33.725740
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}


# Generated at 2022-06-24 21:27:38.260211
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_0 = CollectorMetaDataCollector()

    from ansible.module_utils.facts.collectors import NetworkInterfaceCollector
    test_1 = NetworkInterfaceCollector()

    test_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 21:27:45.073642
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    fact_collector = \
        get_ansible_collector(all_collector_classes=collector.CollectorRegistry().collector_names(),
                              filter_spec=None,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)



if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:27:52.551373
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Test case data
    class TestData():
        def __init__(self):
            self.name = 'Test case 0'
            self.gather_subset = None
            self.module_setup = None
            self.expected_result = None

    # Test data
    test_data_list = []
    test_data_list.append(TestData())
    test_data_list[-1].gather_subset = ['all']
    test_data_list[-1].module_setup = True
    test_data_list[-1].expected_result = {'gather_subset': ['all'], 'module_setup': True}

    test_data_list.append(TestData())
    test_data_list[-1].gather_subset = ['!all']

# Generated at 2022-06-24 21:27:56.791984
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_1 = CollectorMetaDataCollector()
    result = collector_meta_data_collector_1.collect(module=None,collected_facts=None)
    assert result == {'gather_subset': None}


# Generated at 2022-06-24 21:28:01.102189
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    for i in range(10000):
        collector_metadata_collector = CollectorMetaDataCollector()
        module = None
        collected_facts = None
        meta_facts = {'gather_subset': None}
        assert collector_metadata_collector.collect(module, collected_facts) == meta_facts


# Generated at 2022-06-24 21:28:05.942236
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}


# Generated at 2022-06-24 21:28:08.921295
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    assert collector_meta_data_collector_0.collect() == {'gather_subset': None}



# Generated at 2022-06-24 21:28:15.740309
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    try:
        collected_facts = {}
        collected_facts = collector_meta_data_collector_0.collect(collected_facts=collected_facts)

    except Exception as e:
        sys.stderr.write(repr(e))
        sys.stderr.write('\n')


# Generated at 2022-06-24 21:28:21.202421
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    param_module = None
    param_collected_facts = None
    assert collector_meta_data_collector_0.collect(param_module, param_collected_facts) == None


# Generated at 2022-06-24 21:28:33.419607
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    module_mock = MagicMock(name='module')
    collected_facts_mock = MagicMock(name='collected_facts')
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    expected_result = {'gather_subset': None}
    def _side_effect_collect(module=None, collected_facts=None):
        if (module is module_mock and collected_facts is collected_facts_mock):
            return expected_result

    with patch.object(CollectorMetaDataCollector, 'collect',
            side_effect=_side_effect_collect) as obj_collect:
        obj_CollectorMetaDataCollector_collect = collector_meta_data_collector_0.collect(module=module_mock,
            collected_facts=collected_facts_mock)

# Generated at 2022-06-24 21:28:38.165864
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_facts_0 = collector_meta_data_collector_0.collect()
    assert ansible_facts_0['gather_subset'] == ['all']
    assert ansible_facts_0['module_setup'] == True


# Generated at 2022-06-24 21:28:42.221458
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    assert len(CollectorMetaDataCollector.collect()) == 2



# Generated at 2022-06-24 21:28:52.888681
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # NOTE: minimal_gather_subset not needed in the test case since we are adding everything
    #       to the collectors already.  Would need to include minimal_gather_subset when
    #       testing an actual gather_subset.
    try:
        fact_collector = get_ansible_collector(all_collector_classes=set([test_case_0]),
                                               namespace=None,
                                               gather_subset=['all'],
                                               gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                               minimal_gather_subset=frozenset())
    except Exception:
        assert False, "get_ansible_collector() raises exception on valid parameters"

# Generated at 2022-06-24 21:29:01.230320
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector()

    collected_facts = {}
    module = None

    # Test .collect() with module=None, collected_facts={}
    result = collector_meta_data_collector.collect(module, collected_facts)
    assert result == {'gather_subset': None}, "test_CollectorMetaDataCollector_collect 0 failed"

    # Test .collect() with module=None, collected_facts=None
    result = collector_meta_data_collector.collect(module)
    assert result == {'gather_subset': None}, "test_CollectorMetaDataCollector_collect 1 failed"

    # Test .collect() with module=None, collected_facts={}, gather_subset=['all']
    collector_meta_data_collector = CollectorMetaDataCollector

# Generated at 2022-06-24 21:29:05.256945
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector(collectors=(),
                                                                 namespace=None)

    assert collector_meta_data_collector_0.collect() == \
        {'gather_subset': None}


# Generated at 2022-06-24 21:29:13.199958
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    fact_collector_0 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0], namespace=None)
    with collector.faked_ansible_module(collector_meta_data_collector_0) as fake_module:
        f_0 = fact_collector_0.collect(fake_module)
        assert f_0 == {'gather_subset': 'all'}


# Generated at 2022-06-24 21:29:19.269483
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_meta_data_collector_0 = CollectorMetaDataCollector()

    # Call method collect of collector_meta_data_collector_0
    # Execution of this code path does not complete.  The reason for this is that
    # the method collect of CollectorMetaDataCollector is not implemented and it is
    # expected that this is a defect.
    #assert collector_meta_data_collector_0.collect() == '*TBD*'

# Generated at 2022-06-24 21:29:27.914882
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # put some test code here
    ansible_collector_0 = get_ansible_collector(all_collector_classes=[],
                                                namespace=None,
                                                filter_spec=None,
                                                gather_subset=None,
                                                gather_timeout=None,
                                                minimal_gather_subset=None)
    ansible_collector_1 = get_ansible_collector(all_collector_classes=[],
                                                namespace=None,
                                                filter_spec=None,
                                                gather_subset=None,
                                                gather_timeout=None,
                                                minimal_gather_subset=None)

    assert ansible_collector_0 is not ansible_collector_1

# Generated at 2022-06-24 21:29:33.106974
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector= CollectorMetaDataCollector()
    module=None
    collected_facts=None
    info_dict = collector_meta_data_collector.collect(module, collected_facts)
    assert info_dict['gather_subset'] == 'all'


# Generated at 2022-06-24 21:29:50.588013
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_meta_data_collector_0 = CollectorMetaDataCollector()

    # Testing collect() with those inputs:
    #     module=None
    #     collected_facts=None

    #     The expected values are:
    # {'gather_subset': ['all']}

    try:

        # Step 1
        expected_1 = {'gather_subset': ['all']}
        actual_1 = collector_meta_data_collector_0.collect(module=None, collected_facts=None)

        if actual_1 != expected_1:
            print(actual_1, expected_1)
            assert False, '\nExpected: {}\nActual: {}'.format(expected_1, actual_1)

    except Exception as e:
        print(e)

# Generated at 2022-06-24 21:29:54.105767
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0])
    try:
        ansible_fact_collector_0.collect()
    except Exception as e:
        sys.stderr.write(repr(e))
        sys.stderr.write('\n')


# Generated at 2022-06-24 21:29:59.028163
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    dict = collector_meta_data_collector_0.collect()
    assert dict == {'gather_subset': None}


# Generated at 2022-06-24 21:30:02.050641
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    x = collector_meta_data_collector_0.collect()
    assert x == {'gather_subset': None}


# Generated at 2022-06-24 21:30:07.530006
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_case = test_case_0()
    result = test_case.collect_with_namespace(module=None, collected_facts=None)
    assert result == {'gather_subset': None}
    assert test_case._fact_ids

# Generated at 2022-06-24 21:30:10.744105
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector()
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': None}


# Generated at 2022-06-24 21:30:15.266415
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    print('test_CollectorMetaDataCollector_collect')
    print('module_setup=None')
    collector_meta_data_collector0 = CollectorMetaDataCollector(module_setup=None)
    result0 = collector_meta_data_collector0.collect()
    print(result0)
    print('gather_subset=["non_existent"]')
    collector_meta_data_collector1 = CollectorMetaDataCollector(gather_subset=["non_existent"])
    result1 = collector_meta_data_collector1.collect()
    print(result1)
    print('gather_subset=["all"]')
    collector_meta_data_collector2 = CollectorMetaDataCollector(gather_subset=["all"])

# Generated at 2022-06-24 21:30:22.592918
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    collector_meta_data_collector_1 = CollectorMetaDataCollector()
    ansible_collector_0 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0, collector_meta_data_collector_1])
    ansible_collector_0.collect()
    ansible_collector_1 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0, collector_meta_data_collector_1])
    ansible_collector_1.collect()


# Generated at 2022-06-24 21:30:26.461891
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ''' Test case for function get_ansible_collector. '''
    try:
        test_case_0()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-24 21:30:29.816245
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    result = collector_meta_data_collector_0.collect()
    assert result['gather_subset'] == ['all']

# Generated at 2022-06-24 21:30:45.924757
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_all_collector_classes()
    assert ('ansible.module_utils.facts.hardware.filtered_dmi_facts' in
            [c.__name__ for c in all_collector_classes])
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes)
    ansible_facts = fact_collector.collect()
    assert 'ansible_facts' in ansible_facts
    assert 'gather_subset' in ansible_facts['ansible_facts']
    assert ansible_facts['ansible_facts']['gather_subset'] == ['all']



# Generated at 2022-06-24 21:30:56.673193
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_collector_0 = AnsibleFactCollector()
    test_module_0 = None
    test_collected_facts_0 = {}

    # from ansible.module_utils.facts import timeout
    test_gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    test_minimal_gather_subset = frozenset()
    test_gather_subset = ['all']
    test_all_collector_classes = []

    test_fact_collector_0 = get_ansible_collector(test_all_collector_classes,
                                                  gather_subset=test_gather_subset,
                                                  gather_timeout=test_gather_timeout,
                                                  minimal_gather_subset=test_minimal_gather_subset)

    test_fact_

# Generated at 2022-06-24 21:30:58.501230
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    a = AnsibleFactCollector()
    a_collect = a.collect()


# Generated at 2022-06-24 21:31:07.126643
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_collector_0 = AnsibleFactCollector()
    ansible_collector_0.initialize()

    # Define collector objects
    fact_collector = ansible_collector_0

    # Get the content of the fact_collector
    fact_collector_content = fact_collector.collect()
    import pprint
    pprint.pprint(fact_collector_content)

    # Check if the content of fact_collector is empty
    assert(fact_collector_content is not None)

    ansible_collector_0.finalize()

# Generated at 2022-06-24 21:31:10.304754
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()

    fact_collector_0 = \
      AnsibleFactCollector(collectors=[collector_meta_data_collector_0])

    fact_collector_0.collect()

# Generated at 2022-06-24 21:31:17.116295
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    filter_spec = []
    gather_subset = []
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = []
    ansible_fact_collector = get_ansible_collector(
        all_collector_classes=[],
        namespace=None,
        filter_spec=filter_spec,
        gather_subset=gather_subset,
        gather_timeout=gather_timeout,
        minimal_gather_subset=minimal_gather_subset)
    assert(isinstance(ansible_fact_collector, AnsibleFactCollector))

# Generated at 2022-06-24 21:31:22.529996
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class fake_collector(object):

        def collect_with_namespace(self):
            return {'fake_fact': 'fake_value'}

    class fake_collector_2(object):
        def collect_with_namespace(self):
            return {'fake_fact_2': 'fake_value_2'}

    fact_collector = AnsibleFactCollector([fake_collector(), fake_collector_2()])
    facts = fact_collector.collect()
    assert facts['fake_fact'] == 'fake_value'
    assert facts['fake_fact_2'] == 'fake_value_2'


# Generated at 2022-06-24 21:31:35.564321
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [CollectorMetaDataCollector, ]
    namespace_0 = None
    filter_spec_0 = []
    gather_subset_0 = ['all', ]
    gather_timeout_0 = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset_0 = frozenset()
    ansible_collector_0 = get_ansible_collector(all_collector_classes=all_collector_classes,
                                                namespace=namespace_0,
                                                filter_spec=filter_spec_0,
                                                gather_subset=gather_subset_0,
                                                gather_timeout=gather_timeout_0,
                                                minimal_gather_subset=minimal_gather_subset_0)
    # Note that the first

# Generated at 2022-06-24 21:31:47.956287
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    class TestCollector0(collector.BaseFactCollector):
        '''A TestCollector0 class for testing get_ansible_collector.'''
        name = 'test_collector_0'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact_0_0': 'test_fact_0_0_value'}

    class TestCollector1(collector.BaseFactCollector):
        '''A TestCollector1 class for testing get_ansible_collector.'''
        name = 'test_collector_1'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact_1_0': 'test_fact_1_0_value'}


# Generated at 2022-06-24 21:31:48.537948
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-24 21:31:54.615580
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    if not ansible_fact_collector_0.collect():
        raise AssertionError('')


# Generated at 2022-06-24 21:31:57.515555
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0 is not None

    assert ansible_fact_collector_0.collect() == {}


# Generated at 2022-06-24 21:32:02.809009
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes)
    ansible_facts = fact_collector.collect()
    assert 'ansible_facts' in ansible_facts
    assert 'gather_subset' in ansible_facts['ansible_facts']
    assert 'all' in ansible_facts['ansible_facts']['gather_subset']



# Generated at 2022-06-24 21:32:06.053893
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    test_case_0()
    # TODO: Complete this with more tests
    raise NotImplementedError('test_get_ansible_collector: Please add more test cases')


if __name__ == "__main__":
    test_get_ansible_collector()

# Generated at 2022-06-24 21:32:13.607266
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    all_collector_classes = \
        ansible_collector.AnsibleFactCollector.get_collector_classes()
    ansible_collector = get_ansible_collector(all_collector_classes,
                                              gather_subset=None,
                                              gather_timeout=None,
                                              minimal_gather_subset=None)
    ansible_collector = get_ansible_collector(all_collector_classes,
                                              gather_subset=[],
                                              gather_timeout=None,
                                              minimal_gather_subset=None)

# Generated at 2022-06-24 21:32:17.951174
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    namespace = collector.BaseFactNamespace()
    ansible_fact_collector = get_ansible_collector(default_collectors, namespace)


# Generated at 2022-06-24 21:32:25.566912
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(collector.ALL_COLLECTORS)
    assert fact_collector.collectors is not None
    assert len(fact_collector.collectors) > 0
    for collector in fact_collector.collectors:
        assert collector is not None
        assert collector.collect is not None
        assert collector.collect_with_namespace is not None
        assert isinstance(collector, collector.BaseFactCollector)

# Generated at 2022-06-24 21:32:29.083236
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()

# Generated at 2022-06-24 21:32:37.349228
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = \
        get_ansible_collector(
            all_collector_classes=[collector.FacterFactCollector],
            gather_subset=[],
            filter_spec=[],
            gather_timeout=2,
            minimal_gather_subset=frozenset())

    collected_facts_0 = ansible_fact_collector_0.collect()
    # verify collected_facts_0['ansible_facts']['gather_subset'] exists
    if 'ansible_facts' not in collected_facts_0 or 'gather_subset' not in collected_facts_0['ansible_facts']:
        raise AssertionError
    # verify collected_facts_0['ansible_facts']['module_setup'] exists

# Generated at 2022-06-24 21:32:48.236195
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes=None,
                                                     namespace=None,
                                                     filter_spec=None,
                                                     gather_subset=None,
                                                     gather_timeout=None,
                                                     minimal_gather_subset=None)

    ansible_fact_collector_0_fact_ids = ansible_fact_collector_0._fact_ids

    assert('ansible_os_family' in ansible_fact_collector_0_fact_ids)
    assert('ansible_selinux' in ansible_fact_collector_0_fact_ids)
    assert('ansible_distribution' in ansible_fact_collector_0_fact_ids)

# Generated at 2022-06-24 21:33:00.615482
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO: Fix module_utils/facts/test/test_ansible_facts.py to work with
    #       new ansible_fact_collector.
    pass

# Generated at 2022-06-24 21:33:06.588908
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_collector_classes()

    ansible_fact_collector = get_ansible_collector(all_collector_classes,
                                                   gather_subset='all',
                                                   gather_timeout=None,
                                                   filter_spec=None,
                                                   namespace=None)

    ansible_facts = ansible_fact_collector.collect()
    assert ansible_facts['gather_subset'] == 'all'

# Generated at 2022-06-24 21:33:12.855697
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()

    to_collect = {'ansible_system': 'Darwin', 'ansible_python_version': 2.7}
    info_dict = {'ansible_system': 'Darwin', 'ansible_python_version': 2.7}

    mock_collector = MockCollector(name='mock',
                                   info_dict=to_collect,
                                   all_collector_classes=['mock'])
    fact_collector.collectors = [mock_collector]
    ans_facts = fact_collector.collect()

    assert ans_facts == info_dict


# Generated at 2022-06-24 21:33:17.766146
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Most basic call produces empty list
    ansible_fact_collector = get_ansible_collector([])
    fact_dict = ansible_fact_collector.collect()
    assert not fact_dict, 'empty fact_dict'



# Generated at 2022-06-24 21:33:23.996305
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    sys_facter_dict = ansible_fact_collector_0.collect(module=None, collected_facts=None)
    assert is_string(sys_facter_dict["ansible_os_family"])
    assert sys_facter_dict["ansible_os_family"] == "RedHat"
# end unit test for method collect of class AnsibleFactCollector



# Generated at 2022-06-24 21:33:33.944831
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-24 21:33:38.130930
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()

    with pytest.raises(NotImplementedError) as excinfo:
        ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:33:43.544325
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    # Collect facts with no collectors attached
    assert ansible_fact_collector_1.collect() == {}



# Generated at 2022-06-24 21:33:50.594670
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    ansible_fact_collector = get_ansible_collector(all_collector_classes=collector.FACT_COLLECTOR_SUBSET)
    assert(ansible_fact_collector)

    ansible_fact_collector = get_ansible_collector(all_collector_classes=collector.FACT_COLLECTOR_SUBSET,
                                                   gather_subset=['!all'])
    assert(ansible_fact_collector)

    ansible_fact_collector = get_ansible_collector(all_collector_classes=collector.FACT_COLLECTOR_SUBSET,
                                                   gather_subset=['!all', '!min'])
    assert(ansible_fact_collector)

    ansible_fact_collector = get_ansible_

# Generated at 2022-06-24 21:34:01.546076
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # NOTE(mhayden): The 'mock' here is to avoid having to mock out the
    # 'collector_classes_from_gather_subset' function since 'AnsibleFactCollector'
    # is already well-tested above.
    ansible_fact_collector = get_ansible_collector(mock, gather_subset=['all'])
    assert ansible_fact_collector

    # NOTE(mhayden): The 'mock' here is to avoid having to mock out the
    # 'collector_classes_from_gather_subset' function since 'AnsibleFactCollector'
    # is already well-tested above.
    ansible_fact_collector = get_ansible_collector(mock, gather_subset=['min'])
    assert ansible_fact_

# Generated at 2022-06-24 21:34:11.511103
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:34:14.450349
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = \
        get_ansible_collector(all_collector_classes=collector.default_fact_collector_classes,
                              filter_spec=['*'])

# Generated at 2022-06-24 21:34:17.030232
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:34:25.112818
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.network
    #import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.legacy
    all_collector_classes = list(set(
        [CollectorMetaDataCollector] +
        ansible.module_utils.facts.network.collector_classes() +
        #ansible.module_utils.facts.virtual.collector_classes() +
        ansible.module_utils.facts.system.collector_classes() +
        ansible.module_utils.facts.distribution.collector_classes() +
        ansible.module_utils.facts.legacy.collector_classes()
    ))
    ansible_fact_collect

# Generated at 2022-06-24 21:34:27.511020
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # We only have time to test to see if this function runs without error.
    AnsibleFactCollector = get_ansible_collector(all_collector_classes=[])

# Generated at 2022-06-24 21:34:35.034059
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import os

    import ansible.module_utils.facts.collector.platform.linux
    import ansible.module_utils.facts.collector.network.linux
    import ansible.module_utils.facts.collector.parsers.linux
    import ansible.module_utils.facts.collector.sys_info.linux
    import ansible.module_utils.facts.collector.datasource.facter
    import ansible.module_utils.facts.collector.datasource.ohai
    import ansible.module_utils.facts.collector.files.linux
    import ansible.module_utils.facts.collector.virt.linux


# Generated at 2022-06-24 21:34:38.205839
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:34:40.905478
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}


# Generated at 2022-06-24 21:34:50.398905
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    base_collector_class = collector.BaseFactCollector
    fake_collector_classes = [base_collector_class]

    # Test gather_subset=['all']
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=fake_collector_classes,
                              gather_subset=['all'])
    assert(len(ansible_fact_collector.collectors)==3)

    # Test gather_subset=['all', 'network']
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=fake_collector_classes,
                              gather_subset=['all', 'network'])
    assert(len(ansible_fact_collector.collectors)==3)

    # Test

# Generated at 2022-06-24 21:34:58.514038
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    facts_collector = get_ansible_collector(all_collector_classes=None,  # as are all arguments
                                            namespace=None,
                                            filter_spec=None,
                                            gather_subset=None,
                                            gather_timeout=None,
                                            minimal_gather_subset=None
                                            )
    assert isinstance(facts_collector, AnsibleFactCollector)

# Generated at 2022-06-24 21:35:07.413654
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_obj = AnsibleFactCollector()
    ansible_fact_collector_obj.collect()


# Generated at 2022-06-24 21:35:09.406375
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()

if __name__ == "__main__":
    # unit test
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:35:19.443630
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Collect the minimum set of facts, but with a bogus namespace
    ansible_fact_collector_1 = \
        get_ansible_collector(gather_subset=['min'],
                              namespace='')

    # Collect the default set of facts, with a namespace
    ansible_fact_collector_2 = \
        get_ansible_collector(namespace='')

    # Collect the minimum set of facts, but with a bogus namespace
    ansible_fact_collector_3 = \
        get_ansible_collector(minimal_gather_subset=['min'],
                              namespace='')

    # Collect the default set of facts, with a namespace

# Generated at 2022-06-24 21:35:21.515605
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_facts_collector_0 = AnsibleFactCollector()
    ansible_facts_collector_0.collect()


# Generated at 2022-06-24 21:35:23.746189
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    results = ansible_fact_collector_0.collect()
    assert results == {}



# Generated at 2022-06-24 21:35:29.987494
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # test fixture setup
    ansible_fact_collector = AnsibleFactCollector()

    # pre-call checks before calling the tested method
    assert True is True

    # call the method being tested
    ansible_fact_collector.collect(collected_facts=None, module=None)

    # post-call checks
    assert True is True



# Generated at 2022-06-24 21:35:35.786045
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a test AnsibleFactCollector
    ansible_fact_collector = AnsibleFactCollector()

    # The underlying method returns a dict
    result = ansible_fact_collector.collect()

    # Expected False since the underlying method returns {}
    assert result is not False


# Generated at 2022-06-24 21:35:39.568631
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_collector_classes()
    gather_subset = ['all']
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=gather_subset)



# Generated at 2022-06-24 21:35:43.088984
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create an instance of class AnsibleFactCollector
    ansible_fact_collector_0 = AnsibleFactCollector()

    # Collect facts from ansible_fact_collector_0
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:35:44.291226
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert get_ansible_collector()



# Generated at 2022-06-24 21:36:08.054810
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    collected_facts = {}
    collected_facts['test_key'] = {}
    ansible_fact_collector_0.collect(None, collected_facts)

# Generated at 2022-06-24 21:36:13.456284
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()

    ansible_fact_collector_collect = ansible_fact_collector.collect()
    assert type(ansible_fact_collector_collect) == dict



# Generated at 2022-06-24 21:36:14.631176
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_case_0()

if __name__ == '__main__':
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:36:16.466736
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:36:23.046954
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Test the case where all_collector_classes is None, gather_subset is None, gather_timeout is 0,
    # minimal_gather_subset is None, filter_spec is None, namespace is None
    ansible_fact_collector_0 = get_ansible_collector(None,
                                                     None,
                                                     None,
                                                     None,
                                                     0,
                                                     None)

    # Test the case where all_collector_classes is not None, gather_subset is not None,
    # gather_timeout is 0, minimal_gather_subset is not None, filter_spec is not None,
    # namespace is not None

# Generated at 2022-06-24 21:36:24.731032
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:36:29.905829
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    assert(get_ansible_collector is not None)
    fact_collector = get_ansible_collector(all_collector_classes=[])

    assert(fact_collector is not None)
    assert(isinstance(fact_collector, AnsibleFactCollector))



# Generated at 2022-06-24 21:36:42.244661
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.pkg_mgr

    collector_classes = ansible.module_utils.facts.collector.network.collector_classes() + \
        ansible.module_utils.facts.collector.platform.collector_classes() + \
        ansible.module_utils.facts.collector.pkg_mgr.collector_classes()

    ansible_fact_collector = \
        get_ansible_collector(collector_classes,
                              gather_subset='!all',
                              filter_spec=['*'])
    ansible_facts = ansible_fact_collector.collect()

    print(ansible_facts)


# Generated at 2022-06-24 21:36:52.725933
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import hardware

    all_collector_classes = [default.DefaultCollector,
                             hardware.HardwareCollector]
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes)

    ansible_facts = fact_collector.collect()

    def check(facts):
        assert isinstance(facts, dict)
        assert 'gather_subset' in facts
        assert 'module_setup' in facts
        assert 'all' in facts['gather_subset']
        assert isinstance(facts['all'], dict)
        assert 'distribution' in facts['all']
        assert 'distribution_version' in facts['all']
        assert 'os_family' in facts

# Generated at 2022-06-24 21:36:59.096077
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import default_collector_classes
    ansible_fact_collector = \
        get_ansible_collector(
            all_collector_classes=default_collector_classes)
    print("TEST PASSED: get_ansible_collector()")
