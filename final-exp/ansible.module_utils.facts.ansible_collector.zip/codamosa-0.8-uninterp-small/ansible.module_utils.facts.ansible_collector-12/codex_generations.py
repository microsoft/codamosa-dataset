

# Generated at 2022-06-24 21:27:40.642269
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect(collected_facts={})


# Generated at 2022-06-24 21:27:50.225491
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    all_collector_classes = [collector.TestCollector1, collector.TestCollector2, collector.TestCollector3]

    # test all

    gather_subset = ['!all', 'all']

    for gather_subseti in gather_subset:
        fact_collectori = get_ansible_collector(all_collector_classes=all_collector_classes,
                                                gather_subset=gather_subseti)
        fact_dicti = fact_collectori.collect()

        assert fact_dicti['ansible_test_fact1'] == 'test_fact1_value_all'
        assert fact_dicti['test_fact2'] == 'test_fact2_value_all'
        assert fact_dicti['test_fact3'] == 'test_fact3_value_all'


# Generated at 2022-06-24 21:28:01.952570
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Create an empty ansible_fact_collector
    get_ansible_collector([])

    # Create an ansible fact collector that uses an empty namespace
    get_ansible_collector(namespace=collector.BaseFactNamespace())

    # Create an ansible fact collector that uses a PrefixFactNamespace
    get_ansible_collector(namespace=collector.PrefixFactNamespace(prefix='ansible_'))

    # Create an ansible fact collector that uses a PrefixFactNamespace and a filter
    get_ansible_collector(namespace=collector.PrefixFactNamespace(prefix='ansible_'),
                          filter_spec='*')


test_case_0()
test_get_ansible_collector()

# Generated at 2022-06-24 21:28:05.999374
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    pass
# vim: set expandtab tabstop=4 shiftwidth=4 autoindent smartindent:
# vim: foldmethod=marker foldlevel=0 fileencoding=utf-8:

# Generated at 2022-06-24 21:28:07.663007
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # test case 0
    test_case_0()
    pass



# Generated at 2022-06-24 21:28:19.241564
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import \
        ansible_collector as ansible_collector_1
    ansible_fact_collector_0 = test_case_0()
    ansible_collector_0 = ansible_collector_1.get_ansible_collector(all_collector_classes=set([]))
    ansible_collector_0.collect()
    ansible_collector_0 = ansible_collector_1.get_ansible_collector(all_collector_classes=set([]))
    ansible_collector_0.collect(collected_facts={'ansible_facts': {'all': {}, 'min': {}}})

# Generated at 2022-06-24 21:28:29.136631
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import platform
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.runner
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collection
    import ansible.module_utils.facts.other

    # Create collecter instances
    ansible_fact_collector_0 = collector.DefaultFactCollector()
    ansible_fact_collector_1 = collector.DefaultFactCollector()
    ansible_fact_collector_2 = collector.DefaultFactCollector()
    ansible_fact_collector_3 = collector.DefaultFactCollector()
    ansible_fact_

# Generated at 2022-06-24 21:28:36.788939
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache, hardware, network, virtual, systemd
    from ansible.module_utils.facts import default, platforms, software
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.overwrite

    ansible_fact_collector = get_ansible_collector([
        cache.CacheFactCollector,
        hardware.HardwareCollector,
        network.NetworkCollector,
        virtual.VirtualCollector,
        systemd.SystemdCollector,
        default.DefaultCollector,
        platforms.PlatformsCollector,
        software.SoftwareCollector
    ])

    ansible_facts = ansible_fact_collector.collect()
    return ansible_facts

# Generated at 2022-06-24 21:28:46.216350
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.collector.default
    import ansible.module_utils.facts.collector.ohai

    all_collector_classes = [
        ansible.module_utils.facts.collector.default.DefaultFactCollector,
        ansible.module_utils.facts.collector.ohai.OhaiFactCollector
    ]

    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=['all'])

    collected_facts = ansible_fact_collector.collect()

    assert 'ansible_facts' in collected_facts
    assert 'gather_subset' in collected_facts['ansible_facts']

# Generated at 2022-06-24 21:28:48.892945
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector(all_collector_classes=collector.collectors.values())
    assert isinstance(ansible_fact_collector, AnsibleFactCollector)



# Generated at 2022-06-24 21:28:57.823610
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_facts = ansible_fact_collector_0.collect()
    assert ansible_facts == {'gather_subset': ['all']}
    assert 'gather_subset' in ansible_facts.keys()


# Generated at 2022-06-24 21:29:08.706055
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    # stubbed methods
    ansible_fact_collector.collectors = [{'collect_with_namespace': 'collect_with_namespace'}]

    collect_with_namespace_result = {'collect_with_namespace_result': 'collect_with_namespace_result_value'}
    ansible_fact_collector.collectors[0]['collect_with_namespace'].return_value = collect_with_namespace_result
    # test execution
    result = ansible_fact_collector.collect()
    # assertions
    assert result == collect_with_namespace_result
    # method calls tracking

# Generated at 2022-06-24 21:29:13.697728
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=collector.FACT_COLLECTORS)

    assert hasattr(ansible_fact_collector, 'collectors')
    assert len(ansible_fact_collector.collectors) > 1


# Generated at 2022-06-24 21:29:18.780171
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:29:23.119505
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector(all_collector_classes=None,
                                                   namespace=None)
    assert isinstance(ansible_fact_collector, AnsibleFactCollector)


if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:29:27.949970
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=collector.ALL_COLLECTOR_CLASSES)

    assert len(collector.ALL_COLLECTOR_CLASSES) == len(ansible_fact_collector.collectors)



# Generated at 2022-06-24 21:29:37.990250
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.collector import collect_all_subset

    # test gathering all facts
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes=facts.collectors)

    sys.stdout.write('Display names of facts to be gathered by default:\n')
    sys.stdout.write('ansible_fact_collector_0.collectors: %s\n' % repr(ansible_fact_collector_0.collectors))

    collected_facts = ansible_fact_collector_0.collect()

    sys.stdout.write('Display names of facts collected by default:\n')
    sys.stdout.write('collected_facts: %s\n' % repr(collected_facts))



# Generated at 2022-06-24 21:29:43.151701
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_facts = ansible_fact_collector.collect()
    assert type(ansible_facts) is dict
    # assert ansible_facts == '{"changed": false, "ansible_facts": {}}'


# Generated at 2022-06-24 21:29:50.522355
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import ansible_collector
    collector_0 = \
        get_ansible_collector(
            all_collector_classes=ansible_collector.__all__,
            namespace=None,
            filter_spec=None,
            gather_subset=[],
            minimal_gather_subset=None,
            gather_timeout=None)

if __name__ == '__main__':
    print('Run Unit Tests')
    print('---------------')
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:29:54.587847
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # AnsibleFactCollector Object created with empty list
    ansible_fact_collector_0 = AnsibleFactCollector([])

    # Call method collect of AnsibleFactCollector object
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:30:03.782877
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    gather_subset = None
    namespace = None
    filter_spec = None
    all_collector_classes = None
    minimal_gather_subset = None
    result = get_ansible_collector(all_collector_classes,
                                   namespace,
                                   filter_spec,
                                   gather_subset,
                                   minimal_gather_subset)
    assert isinstance(result, AnsibleFactCollector)

# Generated at 2022-06-24 21:30:15.231830
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect(): # pylint: disable=too-many-locals
    '''test: AnsibleFactCollector class method collect'''
    ansible_collector = AnsibleFactCollector()

    module = dict({'type': 'dict'})

    # There are no collectors in this empty collector
    facts = ansible_collector.collect(module=module)
    assert facts == {}

    # Add a collector
    fact_namespace = collector.Namespace()
    fact_collector_0 = \
        collector.FactsFileCollector(namespace=fact_namespace,
                                     search_paths=('/etc/ansible/facts.d',))

    ansible_collector = AnsibleFactCollector(collectors=[fact_collector_0])

    # Get some facts

# Generated at 2022-06-24 21:30:18.481980
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # FIXME: Add your unit test here
    ansible_fact_collector = get_ansible_collector()


# Generated at 2022-06-24 21:30:25.129413
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_collector = get_ansible_collector(all_collector_classes=[], namespace=None, filter_spec=None, gather_subset=None, gather_timeout=None, minimal_gather_subset=None)
    assert ansible_collector is not None
    assert ansible_collector.namespace == None
    assert isinstance(ansible_collector.collectors, list)
    print("Tests passed.")


# Generated at 2022-06-24 21:30:29.265454
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    result = ansible_fact_collector_0.collect()
    assert result is not None


# Generated at 2022-06-24 21:30:38.716643
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default

    all_collector_classes = default.__collector_classes__()

    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes,
                              gather_subset=['all'],
                              filter_spec=['ansible_all_ipv6_addresses'])

    collected_facts = ansible_fact_collector.collect()
    ipv6_addresses = collected_facts['ansible_all_ipv6_addresses']
    assert isinstance(ipv6_addresses, list)

# Generated at 2022-06-24 21:30:43.032567
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = {}
    collected_facts_0 = {}
    result = ansible_fact_collector_0.collect(module_0, collected_facts_0)
    assert result == {}



# Generated at 2022-06-24 21:30:46.915954
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    namespace = 'ansible.module_utils.facts.namespace.PrefixFactNamespace'
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()



# Generated at 2022-06-24 21:30:51.880127
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    ansible_fact_collector_0 = get_ansible_collector(
        all_collector_classes=collector.FACT_COLLECTORS,
        gather_subset=['all'],
        gather_timeout=10,
        namespace=None)

if __name__ == '__main__':

    test_get_ansible_collector()

# Generated at 2022-06-24 21:30:56.236647
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    collected_facts = {}
    assert ansible_fact_collector_0.collect(collected_facts=collected_facts) == {}


# Generated at 2022-06-24 21:31:07.340946
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_obj = AnsibleFactCollector()
    ansible_fact_collector_obj.collect()



# Generated at 2022-06-24 21:31:13.925127
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    # Test with a no collectors
    ansible_fact_collector_0.collect()
    assert ansible_fact_collector_0 is not None


# Generated at 2022-06-24 21:31:15.878897
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:31:20.582700
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()

    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:31:25.441752
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()
    fact_dict = ansible_fact_collector_0.collect()

    # Assert the collector collects some facts
    assert fact_dict



# Generated at 2022-06-24 21:31:26.964767
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    get_ansible_collector(None,None,None,None,None)

# Generated at 2022-06-24 21:31:34.867483
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    type(ansible_fact_collector)._fact_ids = set(['ansible_local'])
    ansible_fact_collector._collect = lambda: {'ansible_local': 'foo'}
    results = ansible_fact_collector.collect()
    assert results['ansible_facts'] == {'ansible_local': 'foo'}



# Generated at 2022-06-24 21:31:41.405583
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # verify base case, with no collectors
    ansible_fact_collector = get_ansible_collector([])
    assert ansible_fact_collector.collectors == []

    # verify that require_collectors() fails
    try:
        ansible_fact_collector.require_collectors()
        assert False, "Expected an exception"
    except ValueError:
        pass

    # verify that require_collectors() succeeds
    ansible_fact_collector = get_ansible_collector(['ansible.module_utils.facts.master.AnsibleMasterFactCollector'])
    ansible_fact_collector.require_collectors()



# Generated at 2022-06-24 21:31:49.682528
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    no_gather_subset = []
    all_gather_subset = ['all']
    min_gather_subset = ['min']
    empty_namespace = None
    prefix_namespace = collector.PrefixFactNamespace(prefix='ansible_')
    filter_spec = ['*']

    ansible_fact_collector = get_ansible_collector(
        all_collector_classes=collector.ALWAYS_COLLECTOR_CLASSES,
        gather_subset=no_gather_subset,
        minimal_gather_subset=set(),
        filter_spec=filter_spec,
        namespace=empty_namespace)

    assert len(ansible_fact_collector.collectors) == 1


# Generated at 2022-06-24 21:31:56.183375
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    filter_spec = []

    gather_subset = ['all']
    gather_timeout = None
    minimal_gather_subset = None
    all_collector_classes = collector.get_collector_classes()

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=None,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)

    facts = fact_collector.collect()

    assert(isinstance(facts, dict))

# Generated at 2022-06-24 21:32:05.990725
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-24 21:32:08.617490
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:32:19.880968
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.setCollectors([
        MockCollector(['fact_1', 'fact_2']),
        MockCollector(['fact_3', 'fact_4'])
    ])
    collected_results = ansible_fact_collector.collect()
    assert collected_results is not None and \
        sorted(collected_results) == sorted(['fact_1', 'fact_2', 'fact_3', 'fact_4'])

    ansible_fact_collector.setFilterSpec(['fact*'])
    collected_results = ansible_fact_collector.collect()

# Generated at 2022-06-24 21:32:24.861613
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector_collect_result = ansible_fact_collector.collect()

    expected_result = {}

    assert ansible_fact_collector_collect_result == expected_result


# Generated at 2022-06-24 21:32:30.138550
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = None
    collected_facts_0 = {}
    ansible_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0)


# Generated at 2022-06-24 21:32:33.062929
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:32:35.428185
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_facts = ansible_fact_collector.collect()
    assert ansible_facts is not None



# Generated at 2022-06-24 21:32:36.505612
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    a = get_ansible_collector()



# Generated at 2022-06-24 21:32:40.857776
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_facts_dict = \
        get_ansible_collector(all_collector_classes=collector.all_collector_classes()).collect()
    assert collector_facts_dict['gather_subset'] == ['all']
    assert 'module_setup' in collector_facts_dict


# Generated at 2022-06-24 21:32:51.435630
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()

    # Test no collectors passed in
    ansible_fact_collector._filter = lambda x, y: x
    assert ansible_fact_collector.collect() == {}

    # Test single collector
    class TestCollector1(collector.BaseFactCollector):

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'a': 1, 'b': 2}

    test_collector1 = TestCollector1()
    ansible_fact_collector = AnsibleFactCollector([test_collector1])
    ansible_fact_collector._filter = lambda x, y: x
    assert ansible_fact_collector.collect() == {'a': 1, 'b': 2}

    # Test single collector,

# Generated at 2022-06-24 21:33:16.369293
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Test function get_ansible_collector'''

    from ansible.module_utils.facts.collector import BaseFactCollector

    fake_collector_classes = [BaseFactCollector]
    actual_result = get_ansible_collector(fake_collector_classes)
    assert isinstance(actual_result, AnsibleFactCollector)

    fake_filter_spec = ['*']
    actual_result = get_ansible_collector(fake_collector_classes, filter_spec=fake_filter_spec)
    assert isinstance(actual_result, AnsibleFactCollector)

    fake_gather_subset = ['all']
    actual_result = get_ansible_collector(fake_collector_classes, gather_subset=fake_gather_subset)

# Generated at 2022-06-24 21:33:23.762276
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    namespace = None
    filter_spec = None
    all_collector_classes = {}
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace,
                              filter_spec=filter_spec)

    collected = ansible_fact_collector.collect()

    gathered_facts = collected.get('')

    return gathered_facts



# Generated at 2022-06-24 21:33:31.332142
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_collector_0 = get_ansible_collector(all_collector_classes=None,
                                                namespace=None,
                                                filter_spec=None,
                                                gather_subset=None)
    collected_facts = ansible_collector_0.collect()
    ansible_fact_collector_0.collect(collected_facts=collected_facts, module=None)

# Generated at 2022-06-24 21:33:34.311682
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Just get a collector with everything
    fact_collector = get_ansible_collector()
    assert fact_collector is not None
    assert len(fact_collector.collectors) == 1

# Generated at 2022-06-24 21:33:39.122768
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}

if __name__ == '__main__':
    test_case_0()
    # test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:33:44.359038
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    get_ansible_collector(all_collector_classes=[CollectorMetaDataCollector], 
                          namespace=CollectorMetaDataCollector, 
                          filter_spec=['foo'], 
                          gather_subset=['foo'], 
                          gather_timeout=60, 
                          minimal_gather_subset=['foo'])


# Generated at 2022-06-24 21:33:46.234947
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # ansible_collector = get_ansible_collector(facts, 'example')
    pass

# Generated at 2022-06-24 21:33:51.958094
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect(module='some module', collected_facts='some collected_facts')


# Generated at 2022-06-24 21:33:56.039859
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Collect with no collectors defined
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}



# Generated at 2022-06-24 21:34:03.859591
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    ansible_fact_collector = get_ansible_collector(
        all_collector_classes=collector.FactCollector.__subclasses__(),
        filter_spec=['*'],
        gather_subset=['all'],
        gather_timeout=10,
        minimal_gather_subset=['!all'])

    ansible_facts = ansible_fact_collector.collect()
    assert ansible_facts
    assert ansible_facts.get('gather_subset') == ['all']
    assert ansible_facts.get('module_setup') == True

# Generated at 2022-06-24 21:34:47.488292
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()

    mock_module_1 = Mock(return_value=None)
    mock_collected_facts_1 = {}

    # Call method collect with args module=mock_module_1 and collected_facts=mock_collected_facts_1
    ansible_fact_collector_1.collect(module=mock_module_1, collected_facts=mock_collected_facts_1)



# Generated at 2022-06-24 21:34:59.396261
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import ReservedPrefixFactNamespace
    from ansible.module_utils.facts.namespace import merge_dicts
    from ansible.module_utils.facts.namespace import reserved_prefixes

    ansible_fact_collector = get_ansible_collector(all_collector_classes=[NetworkCollector, ],
                                                   namespace=ReservedPrefixFactNamespace(reserved_prefixes=reserved_prefixes))


# Generated at 2022-06-24 21:35:02.389773
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()
    collected_facts = {}
    collected_facts = ansible_fact_collector_0.collect(collected_facts=collected_facts)
    test_AnsibleFactCollector_collect_0(collected_facts)

# Test for method collect of class AnsibleFactCollector with no collectors provided

# Generated at 2022-06-24 21:35:08.827534
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_collector_obj = \
        get_ansible_collector(all_collector_classes=collector.base_fact_collector_classes,
                              namespace=None,
                              filter_spec=None,
                              gather_subset=['!all'],
                              gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                              minimal_gather_subset={})

# Generated at 2022-06-24 21:35:12.789004
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:35:15.076900
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    result_0 = ansible_fact_collector_0.collect(  )
    assert result_0 == {}


# Generated at 2022-06-24 21:35:16.645588
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # ansible_fact_collector.collect()
    pass

# Generated at 2022-06-24 21:35:26.740117
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = \
        get_ansible_collector(
            all_collector_classes=collector.base.ALL_COLLECTOR_CLASSES,
            namespace=None,
            filter_spec=None,
            gather_subset=['all'],
            gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
            minimal_gather_subset=['!version'])
    assert ansible_fact_collector is not None
    assert len(ansible_fact_collector.collectors) >= 5
    assert ansible_fact_collector.filter_spec is None
    assert ansible_fact_collector.namespace is None


# Generated at 2022-06-24 21:35:29.441255
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:35:36.186501
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    empty_list = []
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=empty_list)
    try:
        ansible_fact_collector_0.collect()
    except Exception as e:
        sys.stderr.write(repr(e))
        sys.stderr.write('\n')
