

# Generated at 2022-06-24 21:27:33.531961
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    bool_1 = True
    fact_collector = get_ansible_collector(bool_1)
    assert fact_collector is not None


# Generated at 2022-06-24 21:27:35.398520
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    bool_0 = True
    var_0 = get_ansible_collector(bool_0)

# Generated at 2022-06-24 21:27:38.968287
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    try:
        var_1 = get_ansible_collector(True, None)
        var_1.collect()
    except Exception as e:
        print('Exception message: ' + str(e))
        assert False



# Generated at 2022-06-24 21:27:42.348701
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    bool_0 = True
    var_0 = get_ansible_collector(bool_0)
    var_1 = var_0.collect()
    var_2 = get_ansible_collector(bool_0)
    var_3 = var_2.collect()

# Generated at 2022-06-24 21:27:48.904285
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    filtered_facts = {'name_0': 'value_0'}
    namespace = 'namespace'
    obj = AnsibleFactCollector(collectors=(), filter_spec=filtered_facts, namespace=namespace)
    ansible_facts = {'name_0': 'value_0', 'name_1': 'value_1'}
    module = None
    x = obj.collect(module=module, collected_facts=ansible_facts)


# Generated at 2022-06-24 21:27:53.749191
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    bool_0 = True
    var_0 = get_ansible_collector(bool_0)
    # Assigning var_0 = get_ansible_collector(bool_0)
    var_1 = var_0.collect()
    return var_1


# Generated at 2022-06-24 21:27:55.983227
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    bool_0 = True
    # module = None
    # collected_facts = None
    var_0 = AnsibleFactCollector(True)
    var_0.collect()

# Generated at 2022-06-24 21:28:02.114960
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    bool_0 = True
    AnsibleFactCollector_obj_0 = AnsibleFactCollector(collectors=None,
                                                      namespace=None,
                                                      filter_spec=None)
    AnsibleFactCollector_collect_ret_0 = \
        AnsibleFactCollector_obj_0.collect(collected_facts=None, module=None)
    assert isinstance(AnsibleFactCollector_collect_ret_0, dict)


# Generated at 2022-06-24 21:28:03.755592
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    bool_0 = True
    assert callable(get_ansible_collector(bool_0))

# Generated at 2022-06-24 21:28:12.203910
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    print("GET FACTS")
    print("\n")

    # test with bool_0 as bool type
    bool_0 = True
    try:
        var_0 = get_ansible_collector(bool_0)
    except Exception as e:
        print(e)
        assert False

    # test with bool_1 as bool type
    bool_1 = False
    try:
        var_1 = get_ansible_collector(bool_1)
    except Exception as e:
        print(e)
        assert False

    # test with list_0 as list type
    list_0 = []
    try:
        var_2 = get_ansible_collector(list_0)
    except Exception as e:
        print(e)
        assert False

    # test with list_1 as list type
    list

# Generated at 2022-06-24 21:28:22.140425
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert True == True
# unit test for function get_ansible_collector

# Generated at 2022-06-24 21:28:24.109443
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    bool_0 = True
    # No error in collecting facts
    if bool_0:
        test_case_0()


# Generated at 2022-06-24 21:28:29.066551
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    bool_0 = True
    var_0 = get_ansible_collector(bool_0)
    var_1 = var_0.collect()
    print(var_1)


# Generated at 2022-06-24 21:28:36.504304
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    #from ansible.module_utils.facts import collector
    #from ansible.module_utils.facts import ansible_collector
    #from ansible.module_utils.facts import timeout
    #
    collect_obj = collector.BaseFactCollector()
    #create a new obj
    #
    obj = ansible_collector.AnsibleFactCollector(collectors=None, namespace=None, filter_spec=None)
    #
    ret = obj.collect(module=None, collected_facts=None)
    assert isinstance(ret, dict), 'Incorrect return type for ansible_collector.AnsibleFactCollector.collect; expected type dict but got type {}'.format(type(ret))


# Generated at 2022-06-24 21:28:46.185232
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes = []
    assert get_ansible_collector(all_collector_classes) is not None
    all_collector_classes = [CollectorMetaDataCollector]
    assert get_ansible_collector(all_collector_classes) is not None

    namespace = None
    assert get_ansible_collector(all_collector_classes, namespace) is not None

    filter_spec = None
    assert get_ansible_collector(all_collector_classes, namespace, filter_spec) is not None

    gather_subset = None
    assert get_ansible_collector(all_collector_classes, namespace, filter_spec, gather_subset) is not None

    gather_timeout = None

# Generated at 2022-06-24 21:28:56.560431
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Input params sample:

    # all_collector_classes = 'True'
    # namespace = 'default'
    # filter_spec = 'default'
    # gather_subset = 'default'
    # gather_timeout = 'default'
    # minimal_gather_subset = 'default'

    # Execute the tested function:
    result = get_ansible_collector()
    assert result == 'somevalue'
    # Test function wrapper with the mock:
    # with patch('ansible.module_utils.facts.ansible_collector.get_ansible_collector', autospec=True) as _mock_ansible_collector:
    #     _mock_ansible_collector.return_value = 'ansible_collector'
    #     result = _ansible_collector_wrapper(all_

# Generated at 2022-06-24 21:28:59.422703
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    bool_0 = True
    var_0 = get_ansible_collector(bool_0)

# Generated at 2022-06-24 21:29:03.654551
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    bool_0 = True
    var_0 = get_ansible_collector(bool_0)
    assert isinstance(var_0, AnsibleFactCollector)



# Generated at 2022-06-24 21:29:10.695836
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    bool_0 = True
    bool_1 = True
    bool_2 = False
    ansible_fact_collector_0 = AnsibleFactCollector(bool_0)
    collected_facts_0 = {}
    ansible_fact_collector_0.collect(bool_1, collected_facts_0)
    ansible_fact_collector_0.collect(bool_2, collected_facts_0)


# Generated at 2022-06-24 21:29:17.508492
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Set up mock
    #
    # Note: While this class is mocked, it is used as an iterator.
    class MockCollector:
        def __init__(self):
            self._namespace = 'self._namespace'

        def __iter__(self):
            return self

        def __next__(self):
            return self

        @property
        def namespace(self):
            return self._namespace

    mock_collector = MockCollector()

    # First call to mock
    #
    # This will return an object if callable.
    # The returned object will be used to configure the next call to the mock.
    #
    # This first call creates the 'mock_collector' object used in the second call.
    # We also configure the filterspec used in the call to the mock.
    # The expectation is that

# Generated at 2022-06-24 21:29:23.629629
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO: Implement this unit test
    #assert ansible_fact_collector_0.collect() == ''
    return


# Generated at 2022-06-24 21:29:25.654047
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert True


# Generated at 2022-06-24 21:29:29.632798
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    module_0 = None
    collected_facts_0 = None
    facts_dict_0 = ansible_fact_collector_0.collect()




# Generated at 2022-06-24 21:29:38.611959
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = 350

    list_0 = dir(__builtins__)
    list_1 = [type, int, list, filter, map, str, len, chr]
    list_2 = [id, abs, all, any, ascii, bin, bool, bytearray, bytes, callable, dict, enumerate, format,
              frozenset, getattr, hasattr, hash, help, hex, input, int, isinstance, issubclass, iter,
              len, list, locals, max, min, next, oct, ord, open, pow, print, range, repr, reversed,
              round, set, setattr, slice, sorted, sum, tuple, type, vars, zip]

    # Return a new set object, optionally with elements taken from iterable.
    # @note: frozenset() is equivalent to set

# Generated at 2022-06-24 21:29:45.309815
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)

    module_0 = [354, int_0]
    collected_facts_0 = ansible_fact_collector_0.collect(module_0)
    assert len(collected_facts_0) == 2



# Generated at 2022-06-24 21:29:57.632637
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = 350
    list_0 = [int_0]
    ansible_fact_collector_0 = AnsibleFactCollector(list_0)
    collector_classes_0 = [ansible_fact_collector_0]
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    collectors_0 = [collector_meta_data_collector_0]
    ansible_fact_collector_1 = AnsibleFactCollector(collectors_0)
    list_1 = [ansible_fact_collector_1]
    int_1 = 350
    ansible_fact_collector_2 = AnsibleFactCollector(int_1)
    collector_classes_1 = [ansible_fact_collector_2]
    fact_collector_0 = \
        get_ans

# Generated at 2022-06-24 21:30:08.531537
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    int_1 = 350
    ansible_fact_collector_1 = AnsibleFactCollector(collectors=int_1)
    int_2 = 350
    ansible_fact_collector_2 = AnsibleFactCollector(collectors=int_2, filter_spec=350)
    int_3 = 350
    ansible_fact_collector_3 = AnsibleFactCollector(collectors=int_3, filter_spec=350, namespace=350)
    class_4 = CollectorMetaDataCollector
    ansible_fact_collector_4 = AnsibleFactCollector(class_4)
    class_5 = CollectorMetaDataCollector
    ansible_fact_collector_5 = AnsibleFact

# Generated at 2022-06-24 21:30:16.396764
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    int_1 = 550
    # Creating an instance of class AnsibleFactCollector with the following arguments:
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    str_0 = 'Failed to collect fact: ansible_facts'
    # Call method collect of ansible_fact_collector_0
    try:
        ansible_fact_collector_0.collect(int_1)
    except Exception as str_1:
        # Verify the message of the raised exception
        assert str_1 == str_0



# Generated at 2022-06-24 21:30:27.104962
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    collected_facts_0 = {'var_0': 'value_0', 'var_1': 'value_1'}
    facts_dict_0 = {'var_0': 'value_0', 'var_1': 'value_1'}
    ansible_fact_collector_0._filter = (lambda ansible_fact_collector_0, facts_dict_0, var_0: var_0)
    assert facts_dict_0 == ansible_fact_collector_0.collect(module=None, collected_facts=collected_facts_0)


# Generated at 2022-06-24 21:30:33.274372
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    ansible_module_0 = None
    ansible_facts_0 = {}
    collected_facts_0 = ansible_fact_collector_0.collect(ansible_module_0, ansible_facts_0)


# Generated at 2022-06-24 21:30:43.616648
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Create an instance of class AnsibleFactCollector
    # Set instance ansible_fact_collector_1 of class AnsibleFactCollector
    ansible_fact_collector_1 = AnsibleFactCollector()

    # Call method collect of class AnsibleFactCollector with arg
    # Set instance ansible_fact_collector_collect_1 of class
    ansible_fact_collector_collect_1 = ansible_fact_collector_1.collect()



# Generated at 2022-06-24 21:30:45.831848
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # test 0
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)



# Generated at 2022-06-24 21:30:56.635563
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    module_0 = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(), supports_check_mode=True)
    collected_facts_0 = None
    facts_dict_0 = ansible_fact_collector_0.collect(module_0,
                                                    collected_facts_0)
    assert facts_dict_0 is not None
    ansible_fact_collector_1 = AnsibleFactCollector()
    module_1 = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(), supports_check_mode=True)
    collected_facts_1 = None

# Generated at 2022-06-24 21:31:07.287969
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # declare variables
    arg_0 = None
    arg_1 = None
    ansible_fact_collector_0 = AnsibleFactCollector(arg_0, arg_1)
    ansible_fact_collector_1 = AnsibleFactCollector(arg_0, arg_1)
    ansible_fact_collector_2 = AnsibleFactCollector(arg_0, arg_1)

    ansible_fact_collector_1.get_collectors().append(ansible_fact_collector_2)
    # declare variables
    arg_0 = None
    arg_1 = {}
    # test method collect
    ansible_fact_collector_0.collect(arg_0, arg_1)
    pass



# Generated at 2022-06-24 21:31:13.924159
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    str_0 = ansible_fact_collector_0.collect()
    assert type(str_0) == str


# Generated at 2022-06-24 21:31:18.455898
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO: Not yet implemented
    pass

# Import testcases from module into testsuite
from ansible.module_utils.facts.collectors import acpi, aix, altlinux, ansible, bsd, debian, f5, freebsd, gentoo, hpux, junos, linux, macos, netbsd, openbsd, others, pfsense, turbolinux, vmware, windows
from ansible.module_utils.facts.collectors.virtual import base, bhyve, bsd, docker, linux, lxc, openbsd, solaris, test as collector_test, virtualbox, vmware, windows
from ansible.module_utils.facts.collectors.network import base, bsd, darwin, linux, openbsd, test as collector_test, windows

# Generated at 2022-06-24 21:31:27.527408
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    str_0 = 'gather_subset'
    ansible_fact_collector_1 = AnsibleFactCollector(int_0)
    str_1 = '*'
    # Call function get_ansible_collector.
    get_ansible_collector(ansible_fact_collector_0,
                          ansible_fact_collector_1,
                          str_0,
                          str_1)



# Generated at 2022-06-24 21:31:29.888231
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:31:31.051403
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

  # test for case 0
  test_case_0()

# Generated at 2022-06-24 21:31:39.345028
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector_0 = get_ansible_collector(['all'], 'ansible_')
    assert ('gather_subset' in fact_collector_0) is True
    assert ('module_setup' in fact_collector_0) is True
    assert ('ansible_test_fact' in fact_collector_0['ansible_all']) is True
    assert ('type' in fact_collector_0) is True

    # Verify that with an empty gather_subset, we get an empty dict
    fact_collector_1 = get_ansible_collector([], 'ansible_')
    assert (len(fact_collector_1) == 0)

    # Verify that unknown subsets are passed through.

# Generated at 2022-06-24 21:31:50.842862
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = \
        get_ansible_collector(None, None, None, None, None)


# Module is importable
# ansible_fact_collector_0 = get_ansible_collector(None, None, None, None)

# ansible_fact_collector_0 = AnsibleFactCollector(None)

# Generated at 2022-06-24 21:32:00.161668
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.facter import FacterCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.fact import CustomFact
    from ansible.module_utils.facts.fact import Fact


# Generated at 2022-06-24 21:32:06.361149
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = 1208104640
    fact_collector_0 = AnsibleFactCollector(int_0)

    # On OSX 10.13 and later, the system facts collection logic is broken on
    # macOS when running python with -s flag.  The test suite runs with the -s
    # flag, and on these OS versions this causes the system facts collection to
    # fail.  As a workaround, skip system fact collection on these OS versions.
    ansible_collector_0 = get_ansible_collector(int_0)

# Generated at 2022-06-24 21:32:12.300563
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)

    module_0 = mock.Mock()
    collected_facts_0 = mock.MagicMock(return_value=dict())
    dict_0 = ansible_fact_collector_0.collect(module_0, collected_facts_0)



# Generated at 2022-06-24 21:32:16.649815
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    module_collectors = [10]
    collected_facts = {}
    collector_facts = {}
    ansible_fact_collector_0 = AnsibleFactCollector(module_collectors)
    ansible_fact_collector_0.collect(collected_facts=collected_facts)
    collector_facts.update(ansible_fact_collector_0.collect(collected_facts=collected_facts))


# Generated at 2022-06-24 21:32:28.529618
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = list()
    namespace = collector.BaseFactNamespace(prefix='ansible_')
    filter_spec = list()
    gather_subset = list(['all'])

    # test case 0
    try:
        get_ansible_collector(all_collector_classes,
                              namespace,
                              filter_spec,
                              gather_subset)
    except TypeError:
        assert True


if __name__ == '__main__':

    # test cases
    #test_case_0()
    test_get_ansible_collector()


# vim: se sw=4 ts=4 ft=python et:

# Generated at 2022-06-24 21:32:31.646505
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Setup fixture
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)

    # Test the code
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:32:40.039620
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # collect_only is used to collect the facts and not include it in
    # the ansible_facts dict returned
    class CollectOnlyCollector(collector.BaseFactCollector):
        name = 'collect_only'

    fqcl_0 = ['foo']
    namespace_0 = 'x'
    filter_spec_0 = ['y']
    gather_subset_0 = ['foo']
    gather_timeout_0 = 'bar'
    minimal_gather_subset_0 = 'baz'
    ansible_fact_collector_x = get_ansible_collector(fqcl_0, namespace_0, filter_spec_0, gather_subset_0, gather_timeout_0, minimal_gather_subset_0)
    assert ansible_fact_collector_x is not None

# Unit

# Generated at 2022-06-24 21:32:50.300614
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Gather facts required for tests
    ansible_fact_collector_0 = get_ansible_collector(
        all_collector_classes=collector.ALL_COLLECTOR_CLASSES,
        minimal_gather_subset=frozenset([]),
        gather_subset=['all']
    )
    ansible_fact_collector_1 = get_ansible_collector(
        all_collector_classes=collector.ALL_COLLECTOR_CLASSES,
        gather_subset=['min']
    )

    # Set up test variables
    names = ['ansible_local']

# Generated at 2022-06-24 21:32:57.804014
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    ansible_module_0 = None
    collected_facts_0 = None
    returned_0 = ansible_fact_collector_0.collect(ansible_module_0, collected_facts_0)


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    #unittest.main()
    pass

# Generated at 2022-06-24 21:33:12.755437
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO: explore creating test cases for this method
    pass

# Generated at 2022-06-24 21:33:15.624110
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:33:23.333616
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 426
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    ansible_module_0 = None
    dict_0 = dict()
    dict_1 = ansible_fact_collector_0.collect(ansible_module_0, dict_0)
    int_1 = len(dict_1)
    assert int_1 == len(dict_0) == 0


# Generated at 2022-06-24 21:33:29.382671
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector()

# Generated at 2022-06-24 21:33:34.347423
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    parameters = [{'filter_spec': 'a'}]
    for count in range(0, len(parameters)):
        ansible_fact_collector_0.filter_spec = parameters[count]['filter_spec']
        ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:33:35.871020
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert get_ansible_collector is not None

# Generated at 2022-06-24 21:33:41.735496
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    dict_1 = dict()
    dict_0 = ansible_fact_collector_0.collect(dict_1)
    print(dict_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:33:48.289899
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = None
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None

    result = get_ansible_collector(all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset)

    assert(result is not None)
    assert('gather_subset' in result)
    assert(len(result['gather_subset']) == 1)
    assert('all' in result['gather_subset'])


# Generated at 2022-06-24 21:33:52.340473
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    module_0 = 0
    collected_facts_0 = 350
    return_value_0 = ansible_fact_collector_0.collect(module_0, collected_facts_0)
    return_value_0 = ansible_fact_collector_0.collect(module_0, collected_facts_0)
    assert return_value_0 == 350


# Generated at 2022-06-24 21:34:03.282822
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    dictionary_0 = {'hypervisor': 'xen0'}
    module_0 = AnsibleModule({'name': 'hypervisor'}, [dictionary_0, 'hypervisor'])
    ansible_fact_collector_0.collect(module_0)
    dictionary_1 = {'ansible_disk_devices': ['xvda', 'xvdb', 'xvdc']}
    dictionary_2 = {'ansible_devices': ['xvda', 'xvdb', 'xvdc']}
    module_1 = AnsibleModule({'name': 'ansible_disk_devices'}, [dictionary_1, 'ansible_devices'])

# Generated at 2022-06-24 21:34:33.339604
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO: Add tests
    print("Not implemented")


# Generated at 2022-06-24 21:34:42.521311
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    module_0 = AnsibleModule(
        argument_spec={}, supports_check_mode=False)
    str_0 = 'ansible_0'
    dict_0 = dict()
    int_0 = 350
    dict_0[str_0] = int_0
    dict_1 = dict_0
    dict_4 = dict()
    dict_4['ansible_facts'] = dict_1
    dict_5 = dict()
    dict_5['warnings'] = list()
    dict_5['contacted'] = dict()
    dict_5['ansible_facts'] = dict_4
    dict_6 = dict()
    dict_6['warnings'] = list()
    dict_6['contacted'] = dict()
    dict_6['ansible_facts'] = dict()
    dict_7 = dict()


# Generated at 2022-06-24 21:34:46.181709
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)

    dict_0 = ansible_fact_collector_0.collect(dict_0)
    assert len(dict_0) == 0



# Generated at 2022-06-24 21:34:58.306214
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_collector_classes()
    namespace = 'namespace'
    filter_spec = ['*']
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)

    assert(fact_collector.filter_spec == ['*'])

# Generated at 2022-06-24 21:35:00.284879
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)



# Generated at 2022-06-24 21:35:05.800323
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = 350
    ansible_fact_collector_0 = get_ansible_collector(int_0)


# Generated at 2022-06-24 21:35:12.728780
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    assert(ansible_fact_collector_0.collect() == {});

if __name__ == '__main__':
    import pytest
    # --collect-only to see what would be run
    # -s for verbose output
    # -x to stop running tests on first failure
    # --tb=short trims traceback
    pytest.main(['-s', '-x', '--tb=short', 'test_facts.py'])

# Generated at 2022-06-24 21:35:14.994811
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:35:20.190704
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)

    str_0 = 'all'
    frozenset_0 = frozenset()
    str_1 = 'all'
    ansible_fact_collector_1 = get_ansible_collector(ansible_fact_collector_0, None, None, str_0, None, frozenset_0)

# Generated at 2022-06-24 21:35:25.170707
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = 350
    collector.BaseFactCollector.TestBaseFactCollector(int_0)
    collector.BaseFactCollector.TestBaseFactCollector(int_0)

    ansible_fact_collector_0 = AnsibleFactCollector(int_0)

    get_ansible_collector(ansible_fact_collector_0, None, {'*'}, {'network'}, None, None)


# Generated at 2022-06-24 21:36:32.470755
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_get_ansible_collector_0 = get_ansible_collector('gather_subset', 350, namespace)
    int_get_ansible_collector_1 = get_ansible_collector(350, True)

# Generated at 2022-06-24 21:36:40.083732
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    int_1 = 350
    int_2 = 350
    int_3 = 350
    ansible_fact_collector_1 = get_ansible_collector(ansible_fact_collector_0, int_1, int_2, int_3)
    assert ansible_fact_collector_1 is not None

# Generated at 2022-06-24 21:36:44.931863
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()
        assert False

if __name__ == '__main__':
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:36:50.369978
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    all_collector_classes = []
    val_0 = get_ansible_collector(all_collector_classes)
    assert(val_0 == ansible_collector._ansible_collector)

# End test suite for function get_ansible_collector

# Generated at 2022-06-24 21:36:55.467948
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    module_0 = None
    collected_facts_0 = dict()
    ansible_fact_collector_0.collect(module_0, collected_facts_0)

if __name__ == '__main__':
    pass

# Generated at 2022-06-24 21:37:01.789319
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    module_0 = None
    collected_facts_0 = None
    # AssertionError: <class 'ansible.module_utils.facts.collector.AnsibleFactCollector'> != <type
    # 'dict'>
    assert type(ansible_fact_collector_0.collect(module_0, collected_facts_0)) is not type({})


# Generated at 2022-06-24 21:37:12.275352
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 742
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    module_0 = None
    collected_facts_0 = {}
    ansible_fact_collector_0.collect(module_0, collected_facts_0)
    collected_facts_1 = {'ansible_facts': {'example_fact': 'example_value'}}
    ansible_fact_collector_0.collect(module_0, collected_facts_1)
    collected_facts_2 = {'example_fact': 'example_value'}
    ansible_fact_collector_0.collect(module_0, collected_facts_2)
    collected_facts_3 = None
    ansible_fact_collector_0.collect(module_0, collected_facts_3)
   

# Generated at 2022-06-24 21:37:15.324247
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:37:17.946861
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    print(test_case_0.__name__)
    test_case_0()

if __name__ == '__main__':
    test_AnsibleFactCollector_collect()
    sys.exit(0)

# Generated at 2022-06-24 21:37:20.113143
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    int_0 = 350
    ansible_fact_collector_0 = AnsibleFactCollector(int_0)

