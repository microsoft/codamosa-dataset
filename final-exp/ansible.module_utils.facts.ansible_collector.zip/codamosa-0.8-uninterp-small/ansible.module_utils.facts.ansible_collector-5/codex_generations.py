

# Generated at 2022-06-24 21:27:42.716813
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # run test
    collector_meta_data_collector_1 = CollectorMetaDataCollector()

    fact_collector_0 = \
        AnsibleFactCollector(collectors=[collector_meta_data_collector_1])
    facts_dict_0 = fact_collector_0.collect()

    assert facts_dict_0 == {'gather_subset': 'all'}



# Generated at 2022-06-24 21:27:44.553718
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()

    result = fact_collector.collect()
    assert result is not None


# Generated at 2022-06-24 21:27:48.866586
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()

#
# Main program
#
if __name__ == '__main__':
    test_case_0()
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:27:54.619235
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    collectors = []
    fact_collector = \
        AnsibleFactCollector(collectors=collectors)
    module = None
    collected_facts = None

    facts_dict = fact_collector.collect(module=module,
                                        collected_facts=collected_facts)

    assert len(facts_dict) == 0


# Generated at 2022-06-24 21:28:01.952595
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # used by unit tests
    from ansible.module_utils.facts.collectors import all_collector_classes

    collector_meta_data_collector = CollectorMetaDataCollector()
    collector_classes = [collector_meta_data_collector]

    fact_collector = AnsibleFactCollector(collectors=collector_classes)
    collected_facts = fact_collector.collect()

    assert collected_facts['gather_subset'] == 'all'



# Generated at 2022-06-24 21:28:03.926311
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    res = fact_collector.collect()
    # TODO: write assert statement


# Generated at 2022-06-24 21:28:11.082523
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """
    AnsibleFactCollector: test collect method
    """
    # Create instance of class AnsibleFactCollector with
    # filter_spec = ['ansible_os_family']
    collector_data = AnsibleFactCollector(filter_spec=['ansible_os_family'])

    # Get values for vars
    module_value = 'module'
    # Call method collect of class AnsibleFactCollector with
    # the arguments module_value
    collector_data.collect(module=module_value)

if __name__ == "__main__":
    test_case_0()
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:28:22.070415
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-24 21:28:27.837042
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Ensure that a collector for just the platform fact is created on a linux
    # host.
    all_collector_classes = [collector.LinuxPlatformFactCollector,
                             collector.LinuxDistributionFactCollector]
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              minimal_gather_subset=['all'],
                              gather_subset='platform').collect()

    assert fact_collector['ansible_facts'] == {'ansible_platform': 'linux'}


# Generated at 2022-06-24 21:28:34.221389
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = []
    gather_subset = 'all'
    gather_timeout = 10
    minimal_gather_subset = None
    filter_spec = []

    get_ansible_collector(all_collector_classes,
                          gather_subset,
                          gather_timeout,
                          minimal_gather_subset,
                          filter_spec)



# Generated at 2022-06-24 21:28:43.565021
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_0 = CollectorMetaDataCollector()
    collector_1 = CollectorMetaDataCollector()
    fact_collector_0 = AnsibleFactCollector(collectors=[collector_0, collector_1],
                                            namespace=None)
    ansible_facts = fact_collector_0.collect(module=None,
                                             collected_facts=None)
    assert ansible_facts.keys() == ['gather_subset']



# Generated at 2022-06-24 21:28:53.932214
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    test_gather_subset = ['network', 'virtual']
    test_gather_timeout = 120
    test_minimal_gather_subset = frozenset()

    result_collector = get_ansible_collector(all_collector_classes=collector.FACT_SUBSETS,
                                             filter_spec='*',
                                             gather_subset=test_gather_subset,
                                             gather_timeout=test_gather_timeout,
                                             minimal_gather_subset=test_minimal_gather_subset)

    assert result_collector.gather_subset == test_gather_subset
    assert result_collector.gather_timeout == test_gather_timeout
    assert result_collector.minimal_gather_subset == test_min

# Generated at 2022-06-24 21:28:56.199357
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    afc = AnsibleFactCollector(None, None, None)
    assert(afc.collect() == {})


# Generated at 2022-06-24 21:29:05.704407
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_list = [collector.QemuFactCollector(namespace=collector.NamespacedFactNamespace(name='ansible', prefix='ansible_')),
                      collector.CollectorMetaDataCollector(namespace=collector.NamespacedFactNamespace(name='ansible', prefix='ansible_'))]
    fact_collector = AnsibleFactCollector(collectors=[collector.QemuFactCollector(namespace=collector.NamespacedFactNamespace(name='ansible', prefix='ansible_')),
                      collector.CollectorMetaDataCollector(namespace=collector.NamespacedFactNamespace(name='ansible', prefix='ansible_'))])

    fact_dict = fact_collector.collect()

    assert len(fact_dict) > 0

# Generated at 2022-06-24 21:29:13.479144
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansibleFactCollector = AnsibleFactCollector()
    ansibleFactCollector._filter = mock_filter

    ansibleFactCollector.collectors = [
        CreateMockCollector(info_dict={'test1': 'test1_val'}),
        CreateMockCollector(info_dict={'test2': 'test2_val'}),
        CreateMockCollector(info_dict={'test3': 'test3_val'})
    ]

    ansibleFactCollector.collect()


# Generated at 2022-06-24 21:29:18.686685
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    collector_meta_data_collector_0 = CollectorMetaDataCollector()

    ansible_fact_collector_0 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0],
                                                    filter_spec=[])
    module_0 = None
    collected_facts_0 = None
    ansible_fact_collector_0._filter(collected_facts_0, ansible_fact_collector_0.filter_spec)
    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:29:21.086935
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    test_case_0()


if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-24 21:29:32.627526
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # NOTE: This unit test is incomplete.
    # collector_meta_data_collector_0 is CollectorMetaDataCollector object
    # ansible_filter_spec_0 is str object
    # ansible_fact_collector_0 is AnsibleFactCollector object
    # ansible_gather_subset_0 is str object
    # ansible_minimal_gather_subset_0 is frozenset object
    # ansible_module_0 is str object
    ansible_module_0 = 'EmptyModuleClass'
    ansible_minimal_gather_subset_0 = frozenset()
    ansible_gather_subset_0 = 'all'

# Generated at 2022-06-24 21:29:41.405656
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes_0 = \
        [collector.NetworkCollector, collector.DistributionCollector,
         collector.PlatformCollector, collector.HardwareCollector]
    test_get_ansible_collector_0 = \
        AnsibleFactCollector(collectors=[
        CollectorMetaDataCollector(gather_subset=['all'], module_setup=True),
        collector.NetworkCollector(namespace=None),
        collector.PlatformCollector(namespace=None),
        collector.DistributionCollector(namespace=None),
        collector.HardwareCollector(namespace=None)], namespace=None)

# Generated at 2022-06-24 21:29:50.245226
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes_dict = collector.load_collector_classes()
    all_collector_classes = all_collector_classes_dict.values()

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=['all'])
    collected_facts = fact_collector.collect()
    assert 'gather_subset' in collected_facts
    assert 'module_setup' in collected_facts



# Generated at 2022-06-24 21:30:01.482678
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector_0 = AnsibleFactCollector()
    result = fact_collector_0.collect()
    assert isinstance(result, dict), "Should be a dictionary"
    assert len(result) == 0, "Should be of length 0"


# Generated at 2022-06-24 21:30:02.951572
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO: Implement this.
    assert True, "TODO: Implement this."

# Generated at 2022-06-24 21:30:07.637090
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Arrange
    fact_collector = AnsibleFactCollector()

    # Act
    facts_dict = fact_collector.collect()

    # Assert
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-24 21:30:17.309625
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''
    This is to test if the collectors are working
    '''


# Generated at 2022-06-24 21:30:23.114551
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector(collectors=[collector.FilesystemFactCollector(),
                                                      collector.LinuxDistributionFactCollector(),
                                                      collector.NetworkFactCollector()])
    facts = fact_collector.collect()

    assert facts['ansible_facts']['ansible_all_ipv4_addresses'] == \
        ['192.168.50.2', '127.0.0.1', '192.168.50.5']

    assert facts['ansible_facts']['ansible_distribution'] == 'CentOS'


# Generated at 2022-06-24 21:30:31.151532
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector.generic import GenericFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import AnsibleFilteredFactNamespace

    # get all collectors and
    # test a basic collector
    collector_class = GenericFactCollector
    all_collectors = [collector_class]
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collectors,
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-24 21:30:35.285480
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_collector_classes()

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)

    fact_dict = fact_collector.collect()

    assert len(fact_dict) > 0

# Generated at 2022-06-24 21:30:45.886652
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import mock
    import json


# Generated at 2022-06-24 21:30:56.643950
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # create a mock module to pass to AnsibleFactCollector
    class MockModule(object):

        def __init__(self):
            self.params = {'gather_subset': '!all'}

        def fail_json(self, **kwargs):
            pass
    mock_module = MockModule()

    # create a mock collector to pass to AnsibleFactCollector
    class MockCollector(collector.BaseFactCollector):

        def __init__(self):
            pass

        def collect_with_namespace(self, module=None, collected_facts=None):
            fact_dict = {'foo': 'bar'}
            return fact_dict

    mock_collector = MockCollector()

    ansible_fact_collector = AnsibleFactCollector([mock_collector], filter_spec='*')


# Generated at 2022-06-24 21:31:02.655793
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Remove filter_spec to remove deprecation warning
    ansible_collector = get_ansible_collector(
        all_collector_classes=[test_case_0],
        filter_spec=None
    )

    collected_facts = ansible_collector.collect()
    assert collected_facts['gather_subset'] == ['all']
    assert collected_facts['module_setup'] == True

# Generated at 2022-06-24 21:31:13.043939
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:31:17.965741
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''
    This test case demonstrates the usage of the get_ansible_collector function.
    '''
    ansible_fact_collector = get_ansible_collector(all_collector_classes=None,
                                            namespace=None,
                                            filter_spec=None,
                                            gather_subset=None,
                                            gather_timeout=None,
                                            minimal_gather_subset=None)


# Generated at 2022-06-24 21:31:20.848297
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    test_get_ansible_collector.collector_classes = collector.get_collector_classes()

    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=test_get_ansible_collector.collector_classes)

# Generated at 2022-06-24 21:31:22.615408
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()


# Generated at 2022-06-24 21:31:30.554889
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector(all_collector_classes)
    assert isinstance(ansible_fact_collector, AnsibleFactCollector)

ansible_collector_classes = collector.get_collector_classes(
    all_collector_classes,
    minimal_gather_subset=minimal_gather_subset,
    collect_only=collect_only,
    exclude=exclude,
    gather_timeout=gather_timeout)



# Generated at 2022-06-24 21:31:33.610077
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector()
    # The function must return a AnsibleFactCollector object
    assert isinstance(ansible_fact_collector, AnsibleFactCollector)

# Generated at 2022-06-24 21:31:42.837155
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = \
        get_ansible_collector(all_collector_classes=[],
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)
    ansible_fact_collector_1 = \
        get_ansible_collector(all_collector_classes=[],
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)


# Generated at 2022-06-24 21:31:43.814034
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    test_case_0()

# Generated at 2022-06-24 21:31:52.124513
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collectors = collector.load_collectors_from_path(collector.collector_dir)

    # Try with a subset and filter
    ansible_fact_collector = \
        get_ansible_collector(collector_classes=collectors,
                              gather_subset="all",
                              filter_spec=None)

    fact_dict = ansible_fact_collector.collect()

    # Try with only ohai
    ansible_fact_collector = \
        get_ansible_collector(collector_classes=collectors,
                              gather_subset="ohai",
                              filter_spec=None)

    fact_dict = ansible_fact_collector.collect()

if __name__ == '__main__':

    test_case_0()
    test_get_ansible_collector

# Generated at 2022-06-24 21:31:55.237212
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    dict_obj = dict()
    dict_obj['ansible_facts'] = ansible_fact_collector_0.collect()
    

# Generated at 2022-06-24 21:32:08.889186
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Arrange
    ansible_fact_collector_0 = AnsibleFactCollector()

    # Act
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:32:14.189138
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Get the ansible collector object'''
    ansible_fact_collector_0 = get_ansible_collector(
        all_collector_classes=[],
        namespace=None,
        filter_spec=None,
        gather_subset=None,
        gather_timeout=None,
        minimal_gather_subset=None)

# Generated at 2022-06-24 21:32:17.621936
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_1 = False
    ansible_fact_collector_0.collect(module=module_1)


# Generated at 2022-06-24 21:32:20.303718
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:32:25.216925
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0.collect({})
    ansible_fact_collector_0.collect({}, {})


# Generated at 2022-06-24 21:32:30.137547
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_collector_object = AnsibleFactCollector()
    collected_facts_dict = {}
    result = ansible_collector_object.collect(collected_facts=collected_facts_dict)
    assert result == {}

# Generated at 2022-06-24 21:32:35.922957
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts

    all_collector_classes = ansible.module_utils.facts.collector.collector_fact_classes()
    ansible_fact_collector = get_ansible_collector(all_collector_classes)


if __name__ == '__main__':
    test_case_0()
    test_get_ansible_collector()

# Generated at 2022-06-24 21:32:46.249076
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    module_0 = is_string
    ansible_fact_collector_1 = AnsibleFactCollector()
    module_1 = is_string
    ansible_fact_collector_2 = AnsibleFactCollector()
    module_2 = is_string
    ansible_fact_collector_3 = AnsibleFactCollector()
    module_3 = is_string
    ansible_fact_collector_4 = AnsibleFactCollector()
    module_4 = is_string
    ansible_fact_collector_5 = AnsibleFactCollector()
    module_5 = is_string
    ansible_fact_collector_6 = AnsibleFactCollector()
    module_6 = is_string
    ansible_fact_collector_7

# Generated at 2022-06-24 21:32:55.159348
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    class AnsibleFacts(object):
        def __init__(self, all_collector_classes):
            self.all_collector_classes = all_collector_classes
            self.default_collector_classes = self.get_collector_classes(
                subset='!all')

        def get_collector_classes(self, subset='all'):
            for cls in self.all_collector_classes:
                yield(cls)

    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()
    ansible_facts = AnsibleFacts([])

# Generated at 2022-06-24 21:32:58.649581
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes=None, namespace=None, filter_spec=None, gather_subset=None, gather_timeout=None, minimal_gather_subset=None)



# Generated at 2022-06-24 21:33:35.739888
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()


# Generated at 2022-06-24 21:33:41.647976
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:33:45.842142
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=None,
                              filter_spec=None,
                              namespace=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)

# Generated at 2022-06-24 21:33:55.440047
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual

    all_collector_classes = \
        network.collector_classes + \
        virtual.collector_classes

    gather_subset = ['all']

    # Create AnsibleFactCollector object.
    fact_collector = \
        get_ansible_collector(all_collector_classes,
                              gather_subset=gather_subset)

    collected_facts = {}

    # Collect facts.
    collected_facts = fact_collector.collect(collected_facts=collected_facts)

    print(collected_facts)


if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-24 21:34:05.071368
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collectors = []
    collector_meta = CollectorMetaDataCollector(collectors=collectors, namespace='ansible')
    collector_obj = get_ansible_collector(all_collector_classes=collectors,
                                          gather_subset=['all'],
                                          gather_timeout=None,
                                          minimal_gather_subset=set(['all']),
                                          namespace='ansible')
    # TODO: More assertions
    assert collector_obj.collectors == collectors
    assert collector_meta.name == 'gather_subset'
    assert collector_meta.gather_subset == ['all']
    assert collector_meta.module_setup == True
    assert collector_obj.namespace == 'ansible'

# Generated at 2022-06-24 21:34:06.592488
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    ansible_fact_collector_1.collect()

# Generated at 2022-06-24 21:34:08.581782
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()


# Generated at 2022-06-24 21:34:11.720343
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    ansible_fact_collector_1.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 21:34:19.921242
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    sys.path.append('/Users/vcoder/Documents/Platform_Dev/Ansible/ansible/module_utils/facts/')
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.autogen_fact_collector
    import ansible.module_utils.facts.cache

    all_collector_classes = ansible.module_utils.facts.collector.all_collector_classes
    ansible_fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes)
    assert ansible

# Generated at 2022-06-24 21:34:21.856586
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}



# Generated at 2022-06-24 21:35:50.863139
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # setup
    ansible_fact_collector_0 = AnsibleFactCollector()

    # test
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:35:56.602411
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_1 = AnsibleFactCollector(
    )
    ansible_fact_collector_2 = AnsibleFactCollector(
    )
    ansible_fact_collector_3 = AnsibleFactCollector(
    )
    ansible_fact_collector_4 = AnsibleFactCollector(
    )
    ansible_fact_collector_5 = AnsibleFactCollector(
    )
    ansible_fact_collector_6 = AnsibleFactCollector(
    )
    ansible_fact_collector_7 = AnsibleFactCollector(
    )
    ansible_fact_collector_8 = AnsibleFactCollector(
    )
    ansible_fact_collector_9 = Ansible

# Generated at 2022-06-24 21:36:01.571954
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_1 = AnsibleFactCollector()
    ansible_fact_collector_1._filter = lambda x, y: {'ansible_facts': 'some facts'}
    assert ansible_fact_collector_1.collect() == {'ansible_facts': 'some facts'}


# Generated at 2022-06-24 21:36:02.667662
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass


# Generated at 2022-06-24 21:36:08.259425
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() is not None

if __name__ == '__main__':
    test_case_0()

    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:36:10.911983
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_facts = ansible_fact_collector_0.collect()
    assert type(ansible_facts) is dict


# Generated at 2022-06-24 21:36:15.423364
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect(module=None)

# Generated at 2022-06-24 21:36:21.993947
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    ansible_fact_collector = get_ansible_collector(
        all_collector_classes=collector.get_collector_classes(),
        gather_subset=['!foo'],
        filter_spec=['f*'],
        gather_timeout=15,
        minimal_gather_subset=['network'])

    # Print the info available
    print('%r' % ansible_fact_collector)
    print('%r' % ansible_fact_collector.collector_metadata)
    collected_facts = ansible_fact_collector.collect()
    print('%s' % collected_facts)

if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-24 21:36:24.789973
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    with pytest.raises(collector.AnsibleFactCollectorError):
        ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:36:27.294449
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_dict = ansible_fact_collector.collect()
    assert type(ansible_fact_dict) == dict


# Generated at 2022-06-24 21:37:18.503114
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    x = AnsibleFactCollector()
    x.collect()


# Run tests
test_case_0()
test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:37:21.348980
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    collected_facts = dict()
    assert ansible_fact_collector_0.collect(collected_facts=collected_facts) == {}

# Generated at 2022-06-24 21:37:31.764084
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_1 = get_ansible_collector(
        all_collector_classes=collector.all_collector_classes(),
        filter_spec=['a*', 'b*'],
        gather_subset='!all'
    )
    ansible_fact_collector_2 = get_ansible_collector(
        all_collector_classes=collector.all_collector_classes(),
        filter_spec=['a*', 'b*'],
        gather_subset='all'
    )