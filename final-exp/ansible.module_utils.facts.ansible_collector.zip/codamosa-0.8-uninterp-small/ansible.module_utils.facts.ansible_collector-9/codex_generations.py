

# Generated at 2022-06-24 21:27:34.849868
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ansible_fact_collector_0 = CollectorMetaDataCollector()
    var_0 = ansible_fact_collector_0.collect()
    print(var_0)



# Generated at 2022-06-24 21:27:37.782008
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    CollectorMetaDataCollector_obj_0 = CollectorMetaDataCollector()
    dict_0 = CollectorMetaDataCollector_obj_0.collect()
    assert not dict_0 == dict_0


# Generated at 2022-06-24 21:27:40.800056
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    expect_var_0 = None
    assert var_0 == expect_var_0


# Generated at 2022-06-24 21:27:42.757399
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:27:49.260539
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # test object creation
    my_collector = CollectorMetaDataCollector(collectors=None,
                                              namespace=None,
                                              gather_subset=['a', 'b', 'c'],
                                              module_setup=True)

    # noinspection PyCallingNonCallable
    assert my_collector.collect() == \
        {'gather_subset': ['a', 'b', 'c'],
         'module_setup': True}

# Generated at 2022-06-24 21:27:52.896102
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    Collector_Meta_Data_Collector_obj = CollectorMetaDataCollector()
    var_0 = Collector_Meta_Data_Collector_obj.collect(module=None,collected_facts=None)

# Generated at 2022-06-24 21:27:56.714202
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    var_0 = ansible_fact_collector_0.collect()
    # Test the truth value of the object
    assert var_0



# Generated at 2022-06-24 21:27:58.735467
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    var = ansible_fact_collector.collect()

# Generated at 2022-06-24 21:28:02.091250
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    var_0 = collector_meta_data_collector_0.collect()


# Generated at 2022-06-24 21:28:04.389607
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ansible_fact_collector_0 = CollectorMetaDataCollector()
    var_0 = ansible_fact_collector_0.collect()
    return var_0



# Generated at 2022-06-24 21:28:13.554030
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:28:14.879747
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_AnsibleFactCollector_collector_0 = AnsibleFactCollector()
    collector_AnsibleFactCollector_collector_0.collect()



# Generated at 2022-06-24 21:28:17.529377
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.collector_classes_from_gather_subset(['!all'])

    ansible_fact_collector = get_ansible_collector(all_collector_classes)
    assert ansible_fact_collector._validate_collector_objs()


# Unit tests for the class AnsibleFactCollector

# Generated at 2022-06-24 21:28:21.964463
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector_0 = AnsibleFactCollector(collectors={collector_meta_data_collector_0})
    ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:28:27.112957
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector_obj = AnsibleFactCollector([collector_meta_data_collector_0])
    collected_facts = {}
    result = fact_collector_obj.collect(module=None, collected_facts=collected_facts)
    assert(result == {"ansible_facts": {"gather_subset": None}})

# Generated at 2022-06-24 21:28:30.356335
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector = AnsibleFactCollector()


# Generated at 2022-06-24 21:28:40.339840
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.all_collector_classes()
    assert all_collector_classes
    assert len(all_collector_classes) > 0
    assert set(all_collector_classes.keys()) == \
        collector.FACT_NAMESPACES.union(collector.FACT_COLLECTOR_PLUGINS.keys())

    minimal_gather_subset = ['hardware']
    gather_subset = 'all'
    gather_timeout = 30
    filter_spec = 'fact_collector_namespaces'

# Generated at 2022-06-24 21:28:42.189554
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_facts_collector_object = AnsibleFactCollector()
    ansible_facts_collector_object.collect()

# Generated at 2022-06-24 21:28:46.953126
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''test for AnsibleFactCollector::collect'''
    collector_obj = AnsibleFactCollector()
    collected_facts = {}
    fact_collector = AnsibleFactCollector(collectors=[collector_obj])
    # TODO: How do we validate this type?
    print(fact_collector.collect())


# Generated at 2022-06-24 21:28:48.082278
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(['all'])
    assert fact_collector



# Generated at 2022-06-24 21:29:00.937159
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # create mock object for all_collector_classes
    all_collector_classes = [
        # can't use collector.BaseFactCollector here, because
        # BaseFactCollector is abstract
        AnsibleFactCollector,
        CollectorMetaDataCollector,
    ]

    # create mock object for namespace
    namespace = None

    # create mock object for filter_spec
    filter_spec = []

    # create mock object for gather_subset
    gather_subset = ['all']

    # create mock object for gather_timeout
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT

    # create mock object for minimal_gather_subset
    minimal_gather_subset = frozenset()

    # create mock object for collectors

# Generated at 2022-06-24 21:29:03.518099
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Mock objecs
    module = {}
    collected_facts = {}

    # Instantiate class
    obj = AnsibleFactCollector()

    # Call method
    obj.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-24 21:29:15.230087
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import network

    all_collector_classes = frozenset([ansible_local.AnsibleLocalCollector,
                                       network.NetworkCollector])

    fact_collector = get_ansible_collector(all_collector_classes)

    facts = fact_collector.collect()

    expected_keys = ['ipv4', 'python']

    assert frozenset(facts.keys()) >= frozenset(expected_keys), \
        'Failed to find some of the expected facts with keys: %s, found keys: %s' % \
        (str(expected_keys), str(facts.keys()))


# Generated at 2022-06-24 21:29:17.552914
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert len(facts) == 0


# Generated at 2022-06-24 21:29:23.604848
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    collector_classes = [collector_meta_data_collector_0]
    filter_spec = []
    fact_collector = AnsibleFactCollector(collectors=collector_classes, filter_spec=filter_spec)
    assert type(fact_collector) is AnsibleFactCollector

    facts_dict = fact_collector.collect()
    assert facts_dict == {'gather_subset': 'all'}
    assert facts_dict == {'gather_subset': ['all']}


# Generated at 2022-06-24 21:29:25.345561
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()



# Generated at 2022-06-24 21:29:31.286111
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    fact_collector_0 = AnsibleFactCollector(namespace=None)
    fact_collector_0.collect()
    fact_collector_1 = AnsibleFactCollector(namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    fact_collector_1.collect()


# Generated at 2022-06-24 21:29:37.762460
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    col_obj = get_ansible_collector(all_collector_classes=[],
                                    gather_subset=[],
                                    minimal_gather_subset=[])
    assert isinstance(col_obj, AnsibleFactCollector)

    col_obj = get_ansible_collector(all_collector_classes=[],
                                    gather_subset=[],
                                    minimal_gather_subset=['platform', 'network'])
    assert isinstance(col_obj, AnsibleFactCollector)

# Generated at 2022-06-24 21:29:46.500047
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    filter_spec = filter_spec or []
    gather_subset = gather_subset or ['all']
    gather_timeout = gather_timeout or timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = minimal_gather_subset or frozenset()

    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=minimal_gather_subset,
            gather_subset=gather_subset,
            gather_timeout=gather_timeout)

    collectors = []
    for collector_class in collector_classes:
        collector_obj = collector_class(namespace=namespace)
        collectors.append(collector_obj)

    # Add a collector

# Generated at 2022-06-24 21:29:58.290967
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Testing with a filter spec of ['ansible_eth*']
    filter_spec=['ansible_eth*']
    fact_collector_0 = AnsibleFactCollector(filter_spec=filter_spec)
    results_0 = fact_collector_0.collect(collected_facts={})
    if results_0['gather_subset'] != ['all']:
        raise AssertionError()
    if results_0['module_setup'] != True:
        raise AssertionError()
    if results_0['ansible_eth0']['ipv4']['address'] != '10.0.2.15':
        raise AssertionError()
    if results_0['ansible_eth0']['ipv4']['broadcast'] != '10.0.2.255':
        raise Ass

# Generated at 2022-06-24 21:30:07.508132
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=None,
                                                    filter_spec=None,
                                                    namespace=None)

    collected_facts = None
    ansible_fact_collector_0.collect(collected_facts=collected_facts)
    collected_facts = {}
    ansible_fact_collector_0.collect(collected_facts=collected_facts)


# Generated at 2022-06-24 21:30:17.253108
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Create a CollectorMetaDataCollector object
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    # Create a list of CollectorMetaDataCollector objects
    collector_meta_data_collectors = [collector_meta_data_collector_0]
    # Create a AnsibleFactCollector object
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=collector_meta_data_collectors)
    # Create a list of AnsibleFactCollector objects
    ansible_fact_collectors = [ansible_fact_collector_0]
    # Execute function
    ansible_fact_collector = get_ansible_collector(all_collector_classes=ansible_fact_collectors)
    # Verify the results

# Generated at 2022-06-24 21:30:25.643578
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network.default as network_facts

    ansible_fact_collector = get_ansible_collector(all_collector_classes=[network_facts.NetworkCollector],
                                                   gather_subset='!all')

    facts_dict = ansible_fact_collector.collect()
    assert facts_dict
    assert 'gather_subset' in facts_dict
    assert 'module_setup' in facts_dict
    assert facts_dict['gather_subset'] == ['!all']

# Generated at 2022-06-24 21:30:27.288076
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector()
    assert fact_collector
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-24 21:30:31.247728
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # This smoke test doesn't really test functionality, but at least shows that
    # running the class doesn't fail.
    fact_collector = AnsibleFactCollector()
    fact_collector.collect()



# Generated at 2022-06-24 21:30:37.394109
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    def mock_collect(self, module=None, collected_facts=None):
        facts_dict = {}
        facts_dict.update({'ansible_test_1': 'value_1'})
        facts_dict.update({'ansible_test_2': 'value_2'})
        facts_dict.update({'ansible_test_3': 'value_3'})
        facts_dict.update({'ansible_test_4': 'value_4'})
        return facts_dict

    collector_class = type('Collector', (collector.BaseFactCollector,),
                           dict(name='test_collector',
                                collect=mock_collect))

    collector_0 = collector_class()
    collector_1 = collector_class()


# Generated at 2022-06-24 21:30:39.612668
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert facts == {}


# Generated at 2022-06-24 21:30:48.378192
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    fact_collector._filter = lambda a, b: a
    fact_collector.collectors = [
        collector.FacterFactCollector(),
        CollectorMetaDataCollector(), ]

    facts_dict = fact_collector.collect()
    assert isinstance(facts_dict, dict)

    keys = facts_dict.keys()
    assert 'ansible_facter' in keys
    assert 'gather_subset' in keys
    assert 'module_setup' in keys

    assert isinstance(facts_dict['ansible_facter'], dict)
    assert isinstance(facts_dict['gather_subset'], list)
    assert isinstance(facts_dict['module_setup'], bool)


if __name__ == '__main__':
    test_Ans

# Generated at 2022-06-24 21:30:52.110492
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    fact_collector = AnsibleFactCollector(collectors=[collector_meta_data_collector_0,])
    assert fact_collector.collect() == {'gather_subset': ['all']}

# Generated at 2022-06-24 21:30:55.021317
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_obj = AnsibleFactCollector()

    assert ansible_fact_collector_obj.collect() == {}


# Generated at 2022-06-24 21:31:03.690272
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.collector.custom import CustomFactCollector

    all_collector_classes = [CustomFactCollector]

    # call constructor
    fact_collector = \
        get_ansible_collector(all_collector_classes)

    assert isinstance(fact_collector, AnsibleFactCollector)

test_case_0()
test_get_ansible_collector()

# Generated at 2022-06-24 21:31:13.891034
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_obj_0 = AnsibleFactCollector(namespace=None)
    # Standard FactCollector collect() method
    collected_facts_0 = \
        collector_obj_0.collect(module=None, collected_facts=None)
    assert collected_facts_0 == {'ansible_facts': {'gather_subset': ['all']}}


# This test is only useful with an instance created with 'filter_spec'
# parameter set.
# def test_AnsibleFactCollector_collect_filter():
    # collector_obj_0 = AnsibleFactCollector(namespace=None,
                                           # filter_spec=['mcollector_0*', 'fcollector_1*'])
    # collected_facts_0 = \
        # collector_obj_0.collect(module=None, collected_facts=

# Generated at 2022-06-24 21:31:15.500202
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    print(fact_collector.collect())


# Generated at 2022-06-24 21:31:22.394965
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    fact_collector = AnsibleFactCollector(collectors=[collector_meta_data_collector_0])
    fact_collector.collect()



# Generated at 2022-06-24 21:31:35.476905
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    filter_spec = '*'
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = None

    fact_collector = get_ansible_collector(all_collector_classes=collector.get_collector_classes(),
                                           filter_spec=filter_spec,
                                           gather_subset=gather_subset,
                                           gather_timeout=gather_timeout,
                                           minimal_gather_subset=minimal_gather_subset)
    data = fact_collector.collect_with_namespace()
    assert type(data) == dict
    assert 'ansible_facts' in data
    assert 'all' in data
    assert 'module_setup' in data


# Generated at 2022-06-24 21:31:44.609737
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=['all'],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=[])
    assert fact_collector
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector._filter == AnsibleFactCollector._filter
    assert fact_collector.collect == AnsibleFactCollector.collect



# Generated at 2022-06-24 21:31:49.684153
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=None,
                                                    namespace=None,
                                                    filter_spec=None)
    ansible_fact_collector_0._filter = None
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:31:52.410023
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-24 21:32:00.037000
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # this is the test case for normal code flow
    collector_0 = AnsibleFactCollector(collectors=[],
                                       filter_spec=[],
                                       namespace=None)

    #(collector_0, None, None) actual results
    #assert collector_0.collect() == {}, 'Test case 0 failed'

    # this is the test case for abnormal code flow
    collector_1 = AnsibleFactCollector(collectors=[],
                                       filter_spec=[],
                                       namespace=None)

    #(collector_1, None, None) actual results
    #assert collector_1.collect() == {}, 'Test case 1 failed'

# Generated at 2022-06-24 21:32:05.017566
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    test_AnsibleFactCollector_collect_0 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0])
    assert test_AnsibleFactCollector_collect_0.collect() == {'ansible_facts': {'gather_subset': ''}}


# Generated at 2022-06-24 21:32:24.841913
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Test gather_subset all
    fact_collector_0 = get_ansible_collector(all_collector_classes=collector.CORE_COLLECTOR_CLASSES,
                                             gather_subset='all')
    # Test gather_subset default
    fact_collector_1 = get_ansible_collector(all_collector_classes=collector.CORE_COLLECTOR_CLASSES,
                                             gather_subset='default')
    # Test gather_subset network
    fact_collector_2 = get_ansible_collector(all_collector_classes=collector.CORE_COLLECTOR_CLASSES,
                                             gather_subset=['network'])
    # Test gather_subset network and ansible_facts
    fact_collector_3 = get_ansible

# Generated at 2022-06-24 21:32:35.999937
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Test case #0

    filter_spec0 = []
    module0 = 'ansible.module_utils.facts.test_utils'

    fact_collector0 = AnsibleFactCollector()
    collected_facts0 = {'facter': {'test_facter_fact': 'test_value_facter_fact'}, 'ohai': {'test_ohai_fact': 'test_value_ohai_fact'}}

    result0 = fact_collector0.collect(module=module0, collected_facts=collected_facts0)
    assert result0 == {'facter': {'test_facter_fact': 'test_value_facter_fact'}, 'ohai': {'test_ohai_fact': 'test_value_ohai_fact'}}

    # Test case #1

    filter_spec1

# Generated at 2022-06-24 21:32:40.192178
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect(collector_meta_data_collector_0, None)


# Generated at 2022-06-24 21:32:48.448560
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # create a minimal test case for collecting facts
    fact_collector_0 = AnsibleFactCollector()
    module_0 = None
    collected_facts_0 = {}
    facts_dict_0 = fact_collector_0.collect(module_0, collected_facts_0)

    assert isinstance(facts_dict_0, dict)



# Generated at 2022-06-24 21:32:52.074129
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    pass



# Generated at 2022-06-24 21:32:58.533582
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_obj_0 = AnsibleFactCollector()

    # Assign param 'module' a new value
    module_1 = None

    # Assign param 'collected_facts' a new value
    collected_facts_1 = {}

    # Call method collect on object collector_obj_0
    return_value_1 = collector_obj_0.collect(module=module_1, collected_facts=collected_facts_1)
    assert return_value_1 == {}



# Generated at 2022-06-24 21:33:02.564078
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # instantiate the object
    fact_collector = AnsibleFactCollector()
    # call collect
    actual_return = fact_collector.collect()
    # check return value
    expected_return = {}
    assert actual_return == expected_return


# Generated at 2022-06-24 21:33:11.634962
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.utils.loader
    import ansible.module_utils.facts.namespace

    # create a test AnsibleFactCollector
    test_collector_0 = AnsibleFactCollector(filter_spec=['m1', 'm2'],
                                            namespace=ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='test_prefix_'))

    # create a test dict and test value for fact to be collected
    test_facts_dict_0 = {'test_key_0': 'test_value_0'}

    # insert test value into test dict
    test_collector_0._filter(test_facts_dict_0, ['m1', 'm2'])

    # create test dict and test value for collected_facts to be collected

# Generated at 2022-06-24 21:33:15.625033
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=[collector_meta_data_collector_0])
    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:33:24.205817
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_meta_data_collector_0 = CollectorMetaDataCollector()
    collectors_0 = set([collector_meta_data_collector_0])
    ansible_fact_collector_0 = AnsibleFactCollector(collectors=collectors_0)
    ansible_fact_collector_0._filter = Mock(return_value=None)
    ansible_fact_collector_0.collect()
    ansible_fact_collector_0._filter.assert_called_with('', None)


# Generated at 2022-06-24 21:33:33.803730
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:33:37.246459
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    dict_0 = ansible_fact_collector_0.collect()
    assert dict_0 == {}



# Generated at 2022-06-24 21:33:40.524871
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect(module=None)



# Generated at 2022-06-24 21:33:41.794616
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    result = fact_collector.collect()
    assert result is None

# Generated at 2022-06-24 21:33:49.657359
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    namespace = None
    filter_spec = []
    gather_subset = ['all']
    gather_timeout = 210
    minimal_gather_subset = frozenset()
    ansible_fact_collector = get_ansible_collector(all_collector_classes,
                                                   namespace,
                                                   filter_spec,
                                                   gather_subset,
                                                   gather_timeout,
                                                   minimal_gather_subset)

    ansible_facts = ansible_fact_collector.collect()

    assert (type(ansible_facts) == dict)
    assert ('all' in ansible_facts)
    assert ('ansible_facts' in ansible_facts['all'])

# Generated at 2022-06-24 21:33:52.649678
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes=[])
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:33:57.308741
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_obj = AnsibleFactCollector()
    ansible_fact_collector_collect_method_output = ansible_fact_collector_obj.collect()
    assert ansible_fact_collector_collect_method_output == {}


# Generated at 2022-06-24 21:33:59.667304
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collect()


# Generated at 2022-06-24 21:34:02.340761
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()



# Generated at 2022-06-24 21:34:07.172700
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_case_0()
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect(module=module_0)



# Generated at 2022-06-24 21:34:25.231422
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # class instance
    ansible_fact_collector_instance = AnsibleFactCollector()
    ansible_fact_collector_instance._filter = mock.MagicMock(spec_set=True)
    collected_facts = dict()

    # invoke method
    return_value = ansible_fact_collector_instance.collect(collected_facts=collected_facts)

    # check return value
    assert return_value['ansible_facts']['ansible_all_ipv4_addresses'] == 'test string'
    assert return_value['ansible_facts']['ansible_all_ipv6_addresses'] == 'test string'
    assert return_value['ansible_facts']['ansible_architecture'] == 'test string'

# Generated at 2022-06-24 21:34:33.981459
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    """Test the basic functionality of AnsibleFactCollector.collect()"""
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.kernel import KernelFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils.facts.virtual import VirtualFactCollector

    all_collector_classes = [KernelFactCollector,
                             SystemFactCollector,
                             VirtualFactCollector]

    gather_subset = ['min', '!vmware']

    fact_collector_obj = get_ansible_collector(all_collector_classes=all_collector_classes,
                                               gather_subset=gather_subset)

    fact_dict = fact_collector_obj.collect()


# Generated at 2022-06-24 21:34:41.997091
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(collector.all_collector_classes(),
                                           gather_subset='all')
    assert fact_collector
    fact_collector_collectors = fact_collector.collectors

    # Ensure CollectorMetaDataCollector is in the collector's collector list
    metadata_collector = None
    for obj in fact_collector_collectors:
        if isinstance(obj, CollectorMetaDataCollector):
            metadata_collector = obj
            break

    assert metadata_collector
    assert metadata_collector._fact_ids == set(['gather_subset', 'module_setup'])


# Generated at 2022-06-24 21:34:47.826067
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.collector_classes_from_gather_subset(
        all_collector_classes=collector.BaseFactCollector.__subclasses__(),
        minimal_gather_subset=frozenset(),
        gather_subset=['all'],
    )
    fact_collector = get_ansible_collector(
        all_collector_classes=all_collector_classes,
    )


# Generated at 2022-06-24 21:34:50.721484
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    obj = AnsibleFactCollector()
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}



# Generated at 2022-06-24 21:34:53.356883
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert ansible_fact_collector_0.collect() == {}, "Returned facts are not empty"


# Generated at 2022-06-24 21:34:56.480770
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:35:03.905313
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aosw import AoswNetworkCollector
    from ansible.module_utils.facts.network.aio import AioNetworkCollector

    network_collector_class_list = [
        AoswNetworkCollector,
        AioNetworkCollector,
    ]

    try:
        # Call function
        ansible_fact_collector = get_ansible_collector(network_collector_class_list)
        assert ansible_fact_collector.collect()
    finally:
        # Reset cached facts
        collector._COLLECTOR_FACT_CACHE = {}
        collector._FILTER_SPEC = None


# Generated at 2022-06-24 21:35:07.430611
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes(),
                                           gather_subset='all')


# Generated at 2022-06-24 21:35:12.746405
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts import network_linux
    from ansible.module_utils.facts import network_bsd
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import timeout


# Generated at 2022-06-24 21:35:35.628907
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
        ansible_fact_collector_0 = AnsibleFactCollector()
        module_0 = AnsibleModule(argument_spec={})
        module_0.params['gather_subset'] = ''
        module_0.params['filter'] = ''
        ansible_fact_collector_0.collect(module=module_0, collected_facts=None)


from ansible.module_utils.basic import *

main()

# Generated at 2022-06-24 21:35:38.953650
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    collected_facts_dict_0 = None
    ansible_fact_collector_0.collect(module=None, collected_facts=collected_facts_dict_0)

# Generated at 2022-06-24 21:35:40.588346
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    m = AnsibleFactCollector()
    assert m.collect() == {}, "AnsibleFactCollector.collect()"


# Generated at 2022-06-24 21:35:42.833504
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()


# Generated at 2022-06-24 21:35:53.117539
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_1 = AnsibleFactCollector()
    ansible_fact_collector_0._collectors = [ansible_fact_collector_1]
    ansible_fact_collector_1.collect = MagicMock(return_value={'facter_memoryfree': '17245484'})
    ansible_fact_collector_0.module = MagicMock()
    ansible_fact_collector_0.collect()
    ansible_fact_collector_1.collect.assert_called_with(module=ansible_fact_collector_0.module, collected_facts={})


# Generated at 2022-06-24 21:36:03.140937
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create instance of class AnsibleFactCollector
    ansible_fact_collector = AnsibleFactCollector()
    # Try to collect facts from ansible_fact_collector
    actual_ansible_facts = ansible_fact_collector.collect()
    actual_ansible_facts_keys = actual_ansible_facts.keys()


# Generated at 2022-06-24 21:36:07.537195
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()

    ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:36:13.558127
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0_collected_facts = {}

    ansible_fact_collector_0_collect_result = \
        ansible_fact_collector_0.collect(collected_facts=ansible_fact_collector_0_collected_facts)
    assert ansible_fact_collector_0_collect_result == {}, "Did not collect facts properly"

if __name__ == '__main__':
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-24 21:36:14.184288
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    test_case_0()


# Generated at 2022-06-24 21:36:16.118346
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=[])

# Test with just a gather_subset

# Generated at 2022-06-24 21:36:59.881801
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    print('Unit test for function get_ansible_collector')
    print('Test case 0: collect with minimal_gather_subset')
    # minimal_gather_subset = ['!all', 'min']
    ansible_fact_collector_0 = get_ansible_collector(
        all_collector_classes = [TestCollector1, TestCollector2, TestCollector3],
        minimal_gather_subset = ['!all', 'min'])

    # make sure ansible_fact_collector_0 collects with 2 collectors
    assert(len(ansible_fact_collector_0.collectors) == 2)

    # make sure we are collecting with TestCollector1 (uid) and TestCollector3 (group)
    # we don't collect with TestCollector2 because minimal_gather_subset =

# Generated at 2022-06-24 21:37:02.186050
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    module = {}
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect(module=module)


# Generated at 2022-06-24 21:37:03.966549
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fc = AnsibleFactCollector()
    assert fc.collect() == {}


# Generated at 2022-06-24 21:37:14.778618
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # create an instance of the class to be tested
    ansible_fact_collector_0 = AnsibleFactCollector()
    
    # create another instance of the class to be tested
    ansible_fact_collector_1 = AnsibleFactCollector()

    # create an instance of the class which is being tested
    # by the class being tested
    collector_set_0 = collector.CollectorSet()

    # call the collect method on the object to be tested
    # collect method is expected to return a dictionary:
    # {'gather_subset': 'all', 'module_setup': True}
    ansible_facts = ansible_fact_collector_0.collect(collector_set_0)
    
    # create an instance of the class which is being tested
    # by the class being tested

# Generated at 2022-06-24 21:37:20.730837
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector_0 = get_ansible_collector(all_collector_classes=collector.fact_collector_classes(),
                                                     gather_subset=[],
                                                     gather_timeout='',
                                                     minimal_gather_subset=frozenset([]),
                                                     namespace=None)


# Generated at 2022-06-24 21:37:23.006205
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector_0 = AnsibleFactCollector()
    ansible_fact_collector_0.collect()

# Generated at 2022-06-24 21:37:26.204570
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Test collect method of AnsibleFactCollector'''

    # No collectors, no facts
    ansible_fact_collector_0 = AnsibleFactCollector()
    assert not ansible_fact_collector_0.collect()

    # One collector, should return facts
    collector = collector.FacterFactCollector()
    ansible_fact_collector_1 = AnsibleFactCollector(collectors=[collector])
    assert ansible_fact_collector_1.collect()
