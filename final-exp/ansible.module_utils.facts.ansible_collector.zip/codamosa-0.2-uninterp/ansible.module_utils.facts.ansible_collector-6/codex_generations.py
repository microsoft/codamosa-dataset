

# Generated at 2022-06-16 23:30:22.759368
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    namespace = PrefixFactNamespace(prefix='ansible_')
    network_collector = NetworkCollector(namespace=namespace)
    platform_collector = PlatformCollector(namespace=namespace)
    system_collector = SystemCollector(namespace=namespace)

    fact_collector = \
        AnsibleFactCollector(collectors=[network_collector,
                                         platform_collector,
                                         system_collector],
                             namespace=namespace)

    facts = fact

# Generated at 2022-06-16 23:30:31.631749
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_collector_namespace
    from ansible.module_utils.facts import ansible_minimal_gather_subset
    from ansible.module_utils.facts import ansible_gather_subset

    # Test with no gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector,
                                           namespace=ansible_collector_namespace,
                                           gather_subset=None,
                                           minimal_gather_subset=ansible_minimal_gather_subset)
    assert fact_collector.collectors[-1].gather_subset == ansible_gather_subset

    # Test

# Generated at 2022-06-16 23:30:37.855596
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.platform


# Generated at 2022-06-16 23:30:47.183779
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, namespace.PrefixFactNamespace)

    # Test with a

# Generated at 2022-06-16 23:30:57.722335
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDictList
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDictListDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDictListDictList
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDictListDictListDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDictListDictListDictList
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDictListDictListD

# Generated at 2022-06-16 23:31:09.699212
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'ansible_all_ipv4_addresses' in facts['ansible_facts']

# Generated at 2022-06-16 23:31:18.743382
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no collectors
    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert facts == {}

    # Test with one collector
    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    facts = fact_collector.collect()
    assert facts == {'test': 'test'}

    # Test with two collectors
    class TestCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}


# Generated at 2022-06-16 23:31:25.654212
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.virtual


# Generated at 2022-06-16 23:31:37.749677
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes(),
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace == namespace.PrefixFactNamespace(prefix='ansible_')
    assert fact_collector.filter_spec == ['*']

# Generated at 2022-06-16 23:31:47.493045
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=0,
                                           minimal_gather_subset=frozenset())
    assert fact_collector.namespace is None
    assert fact_collector.collectors[0].namespace is None
    assert fact_collector.collectors[1].namespace is None

    # Test with a namespace

# Generated at 2022-06-16 23:32:01.252924
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    # Test with all defaults
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes,
                                           namespace=namespace.AnsiblePrefixFactNamespace(),
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert len(fact_collector.collectors) == len

# Generated at 2022-06-16 23:32:12.063758
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

    all_collector_classes = [TestCollector]
    namespace_classes = [TestNamespace]


# Generated at 2022-06-16 23:32:13.057460
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO: implement
    pass

# Generated at 2022-06-16 23:32:21.546922
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class MockCollector(collector.BaseFactCollector):
        name = 'mock'

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': 'mock_value'}

    class MockCollector2(collector.BaseFactCollector):
        name = 'mock2'

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact2': 'mock_value2'}

    class MockCollector3(collector.BaseFactCollector):
        name = 'mock3'


# Generated at 2022-06-16 23:32:32.939298
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collectors.all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset(['all']))
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors[0].namespace is None
    assert fact_collector.collectors[1].namespace is None
    assert fact_collector.collectors[2].namespace is None

    # Test with a namespace

# Generated at 2022-06-16 23:32:44.078292
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

# Generated at 2022-06-16 23:32:55.119823
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import collector

    all_collector_classes = [
        ansible_collector.AnsibleCollector,
        network.NetworkCollector,
        hardware.HardwareCollector,
        system.SystemCollector,
        virtual.VirtualCollector,
        default.DefaultCollector
    ]


# Generated at 2022-06-16 23:33:07.076553
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [cache.CacheFactCollector,
                             network.NetworkFactCollector,
                             system.SystemFactCollector,
                             virtual.VirtualFactCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10)

    assert fact_collector.collectors[0].name == 'cache'
    assert fact_collector.collectors[1].name == 'network'

# Generated at 2022-06-16 23:33:18.576987
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact': 'test2_value'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'


# Generated at 2022-06-16 23:33:26.275877
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.platform as platform
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr
    import ansible.module_utils.facts.system.user as user
    import ansible.module_utils.facts.system.selinux as selinux
    import ansible.module_utils.facts.system.service_mgr as service_mgr
    import ansible.module_utils.facts.system.fips as fips
    import ansible.module_utils.facts.system.selinux as selinux
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr

# Generated at 2022-06-16 23:33:39.798201
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FacterFactCollector
    from ansible.module_utils.facts.collector import OhaiFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector
    from ansible.module_utils.facts.collector import VirtualizationFactCollector
    from ansible.module_utils.facts.collector import PipFactCollector
    from ansible.module_utils.facts.collector import PkgMgrFactCollector

# Generated at 2022-06-16 23:33:49.971751
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts import timeout

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collectors.all_collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert fact_collector.collectors[0].namespace is None
    assert fact_collector.collectors

# Generated at 2022-06-16 23:34:01.833920
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.system


# Generated at 2022-06-16 23:34:06.639733
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for method collect of class AnsibleFactCollector'''

    # Test with no collectors
    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert facts == {}

    # Test with one collector
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector()])
    facts = fact_collector.collect()
    assert facts == {}

    # Test with two collectors
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector(),
                                                      collector.BaseFactCollector()])
    facts = fact_collector.collect()
    assert facts == {}

    # Test with one collector that returns a fact

# Generated at 2022-06-16 23:34:19.193766
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import DictCollector
    from ansible.module_utils.facts.collector import FunctionCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'


# Generated at 2022-06-16 23:34:25.735636
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr


# Generated at 2022-06-16 23:34:37.060962
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector

    # Create a mock collector that returns a dict with a single key
    class MockCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'mock_key': 'mock_value'}

    # Create a mock namespace that returns a dict with a single key
    class MockNamespace(namespace.BaseFactNamespace):
        def get_facts(self, collected_facts=None):
            return {'mock_namespace_key': 'mock_namespace_value'}

    # Create a mock namespace that returns a dict with a single key

# Generated at 2022-06-16 23:34:43.519663
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    fact_collector = get_ansible_collector(all_collector_classes)
    assert fact_collector is not None
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(all_collector_classes) + 1
    assert isinstance(fact_collector.collectors[-1], CollectorMetaDataCollector)


# Generated at 2022-06-16 23:34:55.422349
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a mock module
    module = MockModule()

    # Create a mock collector
    mock_collector = MockCollector()

    # Create a mock namespace
    mock_namespace = MockNamespace()

    # Create a mock filter spec
    mock_filter_spec = MockFilterSpec()

    # Create a AnsibleFactCollector object
    fact_collector = AnsibleFactCollector(collectors=mock_collector,
                                          namespace=mock_namespace,
                                          filter_spec=mock_filter_spec)

    # Call method collect
    fact_collector.collect(module=module)

    # Check if method collect of class AnsibleFactCollector was called
    assert fact_collector.collect.called

    # Check if method collect_with_namespace of class MockCollector was called
    assert mock_

# Generated at 2022-06-16 23:35:05.436559
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes)
    assert fact_collector.__class__ == ansible_collector.AnsibleFactCollector
    assert fact_collector.collectors[-1].__class__ == ansible_collector.CollectorMetaDataCollector
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True

# Generated at 2022-06-16 23:35:42.967731
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no namespace
    fact_collector = AnsibleFactCollector(collectors=[])
    facts = fact_collector.collect()
    assert facts == {}

    # Test with a namespace
    fact_collector = AnsibleFactCollector(collectors=[], namespace='ansible_')
    facts = fact_collector.collect()
    assert facts == {'ansible_': {}}

    # Test with a namespace and a filter spec
    fact_collector = AnsibleFactCollector(collectors=[], namespace='ansible_', filter_spec='*')
    facts = fact_collector.collect()
    assert facts == {'ansible_': {}}

    # Test with a namespace and a filter spec

# Generated at 2022-06-16 23:35:54.545803
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test_namespace'

    test_collector = TestCollector()
    test_namespace = TestNamespace()
    fact_collector = AnsibleFactCollector(collectors=[test_collector],
                                          namespace=test_namespace)
    facts = fact_collector.collect()
    assert facts == {'test_namespace': {'test_fact': 'test_value'}}

# Generated at 2022-06-16 23:36:06.435570
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    # Test that we get the default collectors
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes)
    assert fact_collector.collectors == ansible_collector.collectors

    # Test that we get the default collectors with a subset
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes,
                                           gather_subset=['network'])
    assert fact_collector.collectors == ansible_collector.collectors

    # Test that we get the default collectors with a subset and a filter
    fact_collector = get_ansible_collect

# Generated at 2022-06-16 23:36:16.940245
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes(),
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None

    # Test with a namespace

# Generated at 2022-06-16 23:36:26.285854
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_collector_classes = collector.get_collector_classes()
    namespace = PrefixFactNamespace(prefix='ansible_')
    filter_spec = ['ansible_*']
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()


# Generated at 2022-06-16 23:36:34.400314
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with a simple collector that returns a dict with a single key
    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    # Test with a simple collector that returns a dict with a single key
    class TestCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector(), TestCollector2()])
    facts = fact_collector.collect()
    assert facts == {'test_fact': 'test_value', 'test_fact2': 'test_value2'}

    # Test with

# Generated at 2022-06-16 23:36:44.428748
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert len(fact_collector.collectors) == len(collector.collector_classes) + 1

    # test with a namespace
    fact_collector = get_

# Generated at 2022-06-16 23:36:48.230968
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert fact_collector is not None
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors is not None
    assert len(fact_collector.collectors) > 0
    assert isinstance(fact_collector.collectors[0], collector.BaseFactCollector)
    assert fact_collector.collectors[0].name == 'all'

# Generated at 2022-06-16 23:36:55.624024
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    # Test with no gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert fact_collector.collectors[-1].gather_subset == ['all']

    # Test with gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=['network'])
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert fact_collector.collectors

# Generated at 2022-06-16 23:37:05.316268
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.solaris

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
        ansible.module_utils.facts.collector.solaris.SolarisCollector
    ]

# Generated at 2022-06-16 23:37:37.397506
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'gather_subset' in facts['ansible_facts']

    # Test with a namespace
    fact_collector = get_ans

# Generated at 2022-06-16 23:37:44.278198
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector

    # Test the default case
    collector = get_ansible_collector(all_collector_classes=collector_classes)
    assert isinstance(collector, ansible_collector.AnsibleFactCollector)
    assert len(collector.collectors) == len(collector_classes)
    assert collector.namespace is None

    # Test with a namespace
    collector = get_ansible_collector(all_collector_classes=collector_classes,
                                      namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(collector, ansible_collector.AnsibleFactCollector)

# Generated at 2022-06-16 23:37:55.660480
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2'])

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(BaseFactCollector):
        name

# Generated at 2022-06-16 23:38:03.108019
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.file_system
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.cmd_line
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module

# Generated at 2022-06-16 23:38:10.628532
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FacterFactCollector
    from ansible.module_utils.facts.collector import OhaiFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector
    from ansible.module_utils.facts.collector import DMIHardwareInfoFactCollector
    from ansible.module_utils.facts.collector import DMISystemInfoFactCollector
    from ansible.module_utils.facts.collector import DMISoftwareInfoFactCollector

# Generated at 2022-06-16 23:38:18.784572
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    # Create a namespace
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a list of collectors

# Generated at 2022-06-16 23:38:28.775662
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_functions
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors + collector_functions

    fact_collector = get_ansible_collector(all_collector_classes)
    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'gather_subset' in facts['ansible_facts']
    assert 'module_setup' in facts['ansible_facts']
    assert 'all' in facts['ansible_facts']['gather_subset']
    assert facts['ansible_facts']['module_setup'] is True


# Generated at 2022-06-16 23:38:40.266041
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network

    # Create a fact collector that collects facts under 'ansible_facts' namespace
    fact_collector = \
        ansible_collector.AnsibleFactCollector(namespace=namespace.AnsiblePrefixFactNamespace())

    # Create a fact collector that collects facts under 'network' namespace
    network_fact_collector = \
        network.NetworkCollector(namespace=namespace.AnsiblePrefixFactNamespace())

    # Create a fact collector that collects facts under 'ansible_facts' namespace

# Generated at 2022-06-16 23:38:53.252215
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import collector

    # Create a namespace
    ns = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a cache

# Generated at 2022-06-16 23:39:03.114137
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pip


# Generated at 2022-06-16 23:40:01.880364
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_collector_classes = get_collector_classes()
    namespace = PrefixFactNamespace(prefix='ansible_')
    filter_spec = []
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace,
                                           filter_spec,
                                           gather_subset,
                                           gather_timeout,
                                           minimal_gather_subset)


# Generated at 2022-06-16 23:40:08.677123
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}
