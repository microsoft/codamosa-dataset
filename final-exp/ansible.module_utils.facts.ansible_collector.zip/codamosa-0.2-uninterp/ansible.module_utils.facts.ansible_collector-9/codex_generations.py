

# Generated at 2022-06-16 23:30:22.887817
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)

    assert fact_collector.collectors
    assert fact_collector.filter_spec == []
    assert fact_collector.namespace is None

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           filter_spec=['ansible_*'])

    assert fact_collector.collectors
    assert fact_collector.filter_spec == ['ansible_*']
    assert fact_collector.namespace is None


# Generated at 2022-06-16 23:30:31.735601
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    fact_collector = \
        get_ansible_collector(all_collector_classes=default_collectors,
                              namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                              filter_spec=['ansible_*'],
                              gather_subset=['all'],
                              gather_timeout=10,
                              minimal_gather_subset=frozenset())

    assert fact_collector.filter_spec == ['ansible_*']
    assert fact_collector.namespace.prefix == 'ansible_'
    assert len(fact_collector.collectors) == len(default_collectors) + 1

# Generated at 2022-06-16 23:30:37.466255
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts import namespace

    all_collector_classes = collector_registry.get_collector_classes()
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    # test with all collectors
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespace_obj)
    assert fact_collector.collectors
    assert fact_collector.namespace

    # test with subset of collectors
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespace_obj,
                                           gather_subset=['network'])
   

# Generated at 2022-06-16 23:30:46.996762
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert fact_collector is not None
    assert isinstance(fact_collector, AnsibleFactCollector)

    # Test that the collector_meta_data_collector was added
    assert len(fact_collector.collectors) == len(default_collectors) + 1
    assert isinstance

# Generated at 2022-06-16 23:30:57.592896
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

# Generated at 2022-06-16 23:31:06.447251
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    fact_collector = get_ansible_collector(all_collector_classes)
    assert fact_collector.collectors[-1].name == 'gather_subset'
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup == True

# Generated at 2022-06-16 23:31:18.048992
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_registry.all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_registry.all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-16 23:31:23.914083
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           gather_subset=['all'],
                                           gather_timeout=10)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace == PrefixFactNamespace(prefix='ansible_')

    # Test without a namespace

# Generated at 2022-06-16 23:31:35.788859
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # test with no namespace
    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert facts == {}

    # test with namespace
    fact_collector = AnsibleFactCollector(namespace=collector.PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collector.collect()
    assert facts == {}

    # test with namespace and filter_spec
    fact_collector = AnsibleFactCollector(namespace=collector.PrefixFactNamespace(prefix='ansible_'),
                                          filter_spec='ansible_*')
    facts = fact_collector.collect()
    assert facts == {}

    # test with namespace and filter_spec

# Generated at 2022-06-16 23:31:41.507725
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    fact_collector = get_ansible_collector(all_collector_classes)
    assert fact_collector is not None
    assert fact_collector.collectors is not None
    assert len(fact_collector.collectors) > 0
    assert fact_collector.collectors[0].name == 'hardware'
    assert fact_collector.collectors[-1].name == 'gather_subset'

# Generated at 2022-06-16 23:31:55.897978
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.file_system
    import ansible.module_utils.facts.collector.service_mgr


# Generated at 2022-06-16 23:32:03.566486
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pip


# Generated at 2022-06-16 23:32:12.484621
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test that we get the right collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector.FACT_COLLECTOR_CLASSES,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset(['hardware']),
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    # Test that we get the right collectors
    assert len(fact_collector.collectors) == len(collector.FACT_COLLECTOR_CLASSES) + 1

    # Test that we get the right collectors

# Generated at 2022-06-16 23:32:20.976837
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts import namespace

    all_collector_classes = collector_registry.get_collector_classes()
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespace_obj,
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=['all'])

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.filter_spec == ['ansible_*']


# Generated at 2022-06-16 23:32:30.924981
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual


# Generated at 2022-06-16 23:32:41.716177
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector

    all_collector_classes = ansible_collector.get_collector_classes()
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])
    assert fact_collector is not None
    assert fact_collector.collectors is not None
    assert len(fact_collector.collectors) > 0

    # Test that we can collect facts
    facts = fact_collector.collect()
    assert facts is not None
    assert len(facts) > 0
    assert 'ansible_facts' in facts
    assert 'gather_subset' in facts['ansible_facts']
    assert 'module_setup' in facts['ansible_facts']

# Generated at 2022-06-16 23:32:50.977156
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True

    # Test with a namespace
    fact_collector = get

# Generated at 2022-06-16 23:33:04.385125
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    # Test that we get the default collectors
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes)
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(default_collectors.collector_classes)

    # Test that we get the default collectors with a namespace

# Generated at 2022-06-16 23:33:13.250922
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    # Test with no namespace
    fact_collector = AnsibleFactCollector(collectors=[NetworkCollector(), PlatformCollector(), SystemCollector()])
    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'ansible_all_ipv4_addresses' in facts['ansible_facts']
    assert 'ansible_all_ipv6_addresses' in facts['ansible_facts']

# Generated at 2022-06-16 23:33:18.664102
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.collectors[-1], CollectorMetaDataCollector)

# Generated at 2022-06-16 23:33:39.348071
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import PlatformCollector
    from ansible.module_utils.facts.collector import DistributionCollector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.collector import CommandCollector
    from ansible.module_utils.facts.collector import FileCollector
    from ansible.module_utils.facts.collector import PipCollector

# Generated at 2022-06-16 23:33:49.672978
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import default_collectors

    # test with no namespace
    fact_collector = \
        AnsibleFactCollector(collectors=default_collectors.collector_classes,
                             namespace=None)
    facts = fact_collector.collect()
    assert facts['ansible_facts']['ansible_all_ipv4_addresses'] == ['10.0.2.15']

    # test with namespace
    fact_collector = \
        AnsibleFactCollector(collectors=default_collectors.collector_classes,
                             namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collector.collect

# Generated at 2022-06-16 23:34:01.574769
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True



# Generated at 2022-06-16 23:34:13.275705
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact': 'test2_value'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3_fact': 'test3_value'}

    fact_collector = AnsibleFact

# Generated at 2022-06-16 23:34:23.045607
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import test_collector

    # Create a collector that returns a dict with a single key: 'test_fact'
    test_fact_collector = test_collector.TestFactCollector(namespace=namespace.BaseFactNamespace())

    # Create a collector that returns a dict with a single key: 'test_fact2'
    test_fact2_collector = test_collector.TestFactCollector(namespace=namespace.BaseFactNamespace())

    # Create a collector that returns a dict with a single key: 'test_fact3'
    test_fact3_collector = test_collector.TestFactCollector(namespace=namespace.BaseFactNamespace())

    # Create

# Generated at 2022-06-16 23:34:33.557277
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceDictCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'


# Generated at 2022-06-16 23:34:37.186743
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    # Test with default args
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert fact_collector.collectors
    assert fact_collector.namespace is None

    # Test with custom namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert fact_collector.collectors
    assert isinstance(fact_collector.namespace, namespace.PrefixFactNamespace)

    # Test with custom filter_spec

# Generated at 2022-06-16 23:34:46.826915
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    class FakeCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        name = 'fake'

        def collect(self, module=None, collected_facts=None):
            return {'fake_fact': 'fake_value'}

    class FakeNamespace(ansible.module_utils.facts.namespace.BaseFactNamespace):
        name = 'fake'

    fake_collector = FakeCollector(namespace=FakeNamespace())
    fact_collector = AnsibleFactCollector(collectors=[fake_collector])
    facts = fact_collector.collect()
    assert facts == {'ansible_facts': {'fake': {'fake_fact': 'fake_value'}}}

# Generated at 2022-06-16 23:34:54.670487
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    test_collector = TestCollector(namespace=PrefixFactNamespace(prefix='test_'))
    fact_collector = AnsibleFactCollector(collectors=[test_collector])

    facts = fact_collector.collect()
    assert facts == {'test_fact': 'test_value'}



# Generated at 2022-06-16 23:35:06.249721
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}


# Generated at 2022-06-16 23:35:28.386909
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=default.ALL_COLLECTOR_CLASSES)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=default.ALL_COLLECTOR_CLASSES,
                                           namespace=PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, PrefixFactNamespace)
   

# Generated at 2022-06-16 23:35:40.002193
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert fact_collector.filter_spec == ['ansible_*']
    assert len(fact_collector.collectors) == len(default_collectors) + 1

# Generated at 2022-06-16 23:35:44.561821
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    assert fact_collector.collect() == {'ansible_facts': {'test': 'test'}}



# Generated at 2022-06-16 23:35:54.686478
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    # Create a namespace
    fact_namespace = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a collector

# Generated at 2022-06-16 23:36:06.463448
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # test with no namespace and no filter_spec
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes(),
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert len(fact_collector.collectors) == len(collector.collector_classes())

    # test with a namespace and no filter_spec


# Generated at 2022-06-16 23:36:17.057363
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        _

# Generated at 2022-06-16 23:36:26.426437
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors.all_collector_classes

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           filter_spec=['*'],
                                           gather_timeout=10)

    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'gather_subset' in facts['ansible_facts']
    assert 'module_setup' in facts['ansible_facts']
    assert 'all' in facts['ansible_facts']['gather_subset']

# Generated at 2022-06-16 23:36:38.285379
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.hardware.HardwareCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]

   

# Generated at 2022-06-16 23:36:50.653561
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = ansible_collector.AnsibleFactCollector(collectors=[],
                                                            namespace=PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collector.collect()
    assert facts == {}

    fact_collector = ansible_collector.AnsibleFactCollector(collectors=[],
                                                            namespace=PrefixFactNamespace(prefix='ansible_'),
                                                            filter_spec='*')
    facts = fact_collector.collect()
    assert facts == {}


# Generated at 2022-06-16 23:37:00.184247
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.hardware.HardwareCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]

   

# Generated at 2022-06-16 23:37:27.019674
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout

    # Test that a collector can be added to the list of collectors
    # and that the collect method returns a dictionary with the
    # facts collected by the collector.
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    # Test that a collector can be added to the list of collectors
    # and that the collect method returns a dictionary with the
    # facts collected by the collector.

# Generated at 2022-06-16 23:37:36.485484
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no collectors
    fact_collector = AnsibleFactCollector()
    assert fact_collector.collect() == {}

    # Test with collectors
    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    assert fact_collector.collect() == {'test': 'test'}

    # Test with namespace
    class TestNamespace(collector.BaseFactNamespace):
        name = 'test'

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()],
                                          namespace=TestNamespace())

# Generated at 2022-06-16 23:37:47.887463
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert fact_collector is not None
    assert fact_collector.collectors is not None
    assert len(fact_collector.collectors) == 2
    assert fact_collector.collectors[0].name == 'all'
    assert fact_collector.collectors[1].name == 'gather_subset'
    assert fact_collector.collectors[1].gather_subset == ['all']

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=['network'])
    assert fact_collector is not None
    assert fact_collector

# Generated at 2022-06-16 23:37:56.093117
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv4Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv6Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceMACCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMTUCollector

# Generated at 2022-06-16 23:38:03.448172
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace

    # Test with all collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes.all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert len(fact_collector.collectors) == len(collector_classes.all_collector_classes)

    # Test with subset of collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes.all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           gather_subset=['network', 'virtual'])
   

# Generated at 2022-06-16 23:38:11.233009
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    all_collector_classes = collector.get_collector_classes()
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=0,
                                           minimal_gather_subset=frozenset(),
                                           filter_spec=['ansible_*'])

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, namespace.PrefixFactNamespace)
    assert fact_collector.namespace.prefix == 'ansible_'
   

# Generated at 2022-06-16 23:38:19.294507
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None

# Generated at 2022-06-16 23:38:28.824906
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import default_collectors

    # Create a collector that collects a fact named 'test_fact'
    class TestFactCollector(collector.BaseFactCollector):
        name = 'test_fact'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    # Create a collector that collects a fact named 'test_fact_2'
    class TestFactCollector2(collector.BaseFactCollector):
        name = 'test_fact_2'
        _fact_ids = set(['test_fact_2'])



# Generated at 2022-06-16 23:38:40.265386
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import cache

    # Create a collector that returns a dict with a single fact
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    # Create a collector that returns a dict with a single fact
    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])


# Generated at 2022-06-16 23:38:53.251739
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    all_collector_classes = default_collectors.get_collector_classes()

    # Test with gather_subset=['all']
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    facts = fact_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] is True

    # Test with gather_subset=['network']
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['network'])
    facts = fact_collector.collect()

# Generated at 2022-06-16 23:39:23.004040
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import systemd
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import package
    from ansible.module_utils.facts import collector


# Generated at 2022-06-16 23:39:31.057713
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import collector

    all_collector_classes = [
        default.Default,
        hardware.Hardware,
        network.Network,
        virtual.Virtual,
        system.System,
    ]

    gather_subset = ['all']
    gather_timeout = 10
    minimal_gather_subset = frozenset()


# Generated at 2022-06-16 23:39:42.203019
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

        def __init__(self, prefix=None):
            super(TestNamespace, self).__init__(prefix=prefix)

    test_collector = TestCollector()
    test_namespace = TestNamespace()
    test_fact_collector = AnsibleFactCollector(collectors=[test_collector], namespace=test_namespace)

# Generated at 2022-06-16 23:39:52.560185
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           gather_subset=['all'],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())

    assert fact_collector.collectors[0].name == 'all'
    assert fact_collector.collectors[1].name == 'gather_subset'
    assert fact_collector.collectors[1].g

# Generated at 2022-06-16 23:39:53.364459
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO: write unit test
    pass

# Generated at 2022-06-16 23:40:05.183285
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]
