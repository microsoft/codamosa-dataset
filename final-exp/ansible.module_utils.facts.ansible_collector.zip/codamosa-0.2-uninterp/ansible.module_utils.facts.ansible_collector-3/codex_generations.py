

# Generated at 2022-06-16 23:30:19.773401
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:24.400322
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'],
                                                       'module_setup': True}

# Generated at 2022-06-16 23:30:28.407063
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:31.735874
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:33.762652
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:40.313798
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:44.423824
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'],
                                                       'module_setup': True}

# Generated at 2022-06-16 23:30:56.682364
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FacterFactCollector
    from ansible.module_utils.facts.collector import OhaiFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector
    from ansible.module_utils.facts.collector import PlatformFactCollector
    from ansible.module_utils.facts.collector import VirtualFactCollector
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector


# Generated at 2022-06-16 23:31:08.954467
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

    all_collector_classes = [TestCollector]
    namespace_classes = [TestNamespace]


# Generated at 2022-06-16 23:31:11.876502
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:31:18.769710
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-16 23:31:31.145045
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True

# Generated at 2022-06-16 23:31:34.642215
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:31:38.662802
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:31:47.561380
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=collector.all_collector_classes(),
            minimal_gather_subset=frozenset(),
            gather_subset=['all'],
            gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT)


# Generated at 2022-06-16 23:31:54.056849
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] is True

# Generated at 2022-06-16 23:31:57.900899
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] == True


# Generated at 2022-06-16 23:32:03.936096
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:32:08.336963
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:32:12.790169
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'],
                                                       'module_setup': True}

# Generated at 2022-06-16 23:32:25.011636
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout

    # Create a mock namespace
    mock_namespace = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a mock collector
    mock_collector = collector.BaseFactCollector(namespace=mock_namespace)

    # Create a mock cache
    mock_cache = cache.FactCache()

    # Create a mock timeout
    mock_timeout = timeout.Timeout(10)

    # Create a mock gather_subset
    mock_gather_subset = ['all']

    # Create a mock minimal_gather_subset
    mock_minimal_gather_subset = frozenset()

# Generated at 2022-06-16 23:32:36.451548
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace

    all_collector_classes = collector_classes()
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace_obj,
                              filter_spec=['ansible_*'],
                              gather_subset=['all'],
                              gather_timeout=10,
                              minimal_gather_subset=frozenset())

    assert fact_collector.collectors
    assert fact_collector.namespace == namespace_obj
    assert fact_collector.filter_spec == ['ansible_*']

# Generated at 2022-06-16 23:32:47.813228
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import ansible_network
    from ansible.module_utils.facts import ansible_virtual
    from ansible.module_utils.facts import ansible_distribution
    from ansible.module_utils.facts import ansible_pkg_mgr
    from ansible.module_utils.facts import ansible_service_mgr
    from ansible.module_utils.facts import ansible_user_id
    from ansible.module_utils.facts import ansible_env
    from ansible.module_utils.facts import ansible_date_time
    from ansible.module_utils.facts import ansible_system

# Generated at 2022-06-16 23:33:00.400163
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import package
    from ansible.module_utils.facts import collector

    all_collector_classes = [
        ansible_collector.AnsibleCollector,
        network.NetworkCollector,
        system.SystemCollector,
        virtual.VirtualCollector,
        hardware.HardwareCollector,
        distribution.DistributionCollector,
        package.PackageCollector,
    ]

    # Test with no namespace
    fact_collector = get_

# Generated at 2022-06-16 23:33:10.488277
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Make sure we can get a collector with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_registry.collector_classes)
    assert fact_collector.namespace is None

    # Make sure we can get a collector with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_registry.collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'))
    assert fact_collector.namespace is not None
    assert fact_collector.namespace.prefix == 'ansible_'

# Generated at 2022-06-16 23:33:22.597412
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test with all collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes)
    assert fact_collector.collectors
    assert fact_collector.namespace is None

    # Test with a subset of collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           gather_subset=['all', 'network'])
    assert fact_collector.collectors
    assert fact_collector.namespace is None

    # Test with a namespace

# Generated at 2022-06-16 23:33:28.984864
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace

    # Test with all collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert len(fact_collector.collectors) == len(collector_classes)

    # Test with subset of collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           gather_subset=['network'])
    assert len(fact_collector.collectors) == 1

    # Test with subset of collectors
    fact

# Generated at 2022-06-16 23:33:42.086228
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = \
        ansible.module_utils.facts.collector.network.collector_classes + \
        ansible.module_utils.facts.collector.platform.collector_classes + \
        ansible.module_utils.facts.collector.pkg_mgr.collector_classes + \
        ansible.module_utils.facts.collector.virtual.collector_classes


# Generated at 2022-06-16 23:33:52.423403
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector
    ]

    fact_collector = get_ansible_collector(all_collector_classes,
                                           filter_spec=['ansible_eth*', 'ansible_os_family'])

    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'ansible_eth0' in facts

# Generated at 2022-06-16 23:34:03.811363
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr


# Generated at 2022-06-16 23:34:19.403848
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]


# Generated at 2022-06-16 23:34:31.864769
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])


# Generated at 2022-06-16 23:34:39.914460
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test_collector2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}


# Generated at 2022-06-16 23:34:48.596188
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.collectors.base as base
    import ansible.module_utils.facts.collectors.network as network

    # Create a fake collector that returns a dict with a single key/value pair
    class FakeCollector(base.BaseFactCollector):
        name = 'fake'
        _fact_ids = set(['fake_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'fake_fact': 'fake_value'}

    # Create a fake collector that returns a dict with a single key/value pair
    class FakeCollector2(base.BaseFactCollector):
        name = 'fake2'
        _fact_ids = set(['fake_fact2'])


# Generated at 2022-06-16 23:34:58.063278
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    assert fact_collector is not None
    assert fact_collector.collectors is not None
    assert len(fact_collector.collectors) > 0

    assert fact_collector.collectors[-1].name == 'gather_subset'
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True

# Generated at 2022-06-16 23:35:08.057168
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import test_collector

    # Create a test collector that returns a dict with a single key
    test_collector_obj = test_collector.TestFactCollector(namespace=namespace.BaseFactNamespace())
    test_collector_obj.FACT_NAME = 'test_fact'
    test_collector_obj.FACT_DATA = 'test_data'

    # Create a collector that returns a dict with a single key
    ansible_collector_obj = ansible_collector.AnsibleFactCollector(collectors=[test_collector_obj])

    # Collect the facts
    facts_dict = ansible_collector_obj.collect()

   

# Generated at 2022-06-16 23:35:19.780878
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with a namespace

# Generated at 2022-06-16 23:35:26.908472
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    # Test with namespace
    namespace = PrefixFactNamespace(prefix='ansible_')
    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=namespace)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace == namespace

    # Test without namespace
    fact_collector = get_ansible_collector(all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace == FactNamespace

# Generated at 2022-06-16 23:35:37.133378
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}


# Generated at 2022-06-16 23:35:44.935068
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test with no namespace
    fact_collector = AnsibleFactCollector(collectors=[NetworkCollector(), SystemCollector()])
    facts = fact_collector.collect()
    assert 'ansible_all_ipv4_addresses' in facts
    assert 'ansible_all_ipv6_addresses' in facts
    assert 'ansible_architecture' in facts
    assert 'ansible_distribution' in facts

    # Test with namespace

# Generated at 2022-06-16 23:36:00.211906
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors.all_collector_classes()

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10)

    assert fact_collector.collectors[-1].name == 'gather_subset'
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup == True


# Generated at 2022-06-16 23:36:11.680885
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test_fact3'])


# Generated at 2022-06-16 23:36:23.766442
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = \
        ansible.module_utils.facts.collector.network.collector_classes + \
        ansible.module_utils.facts.collector.platform.collector_classes + \
        ansible.module_utils.facts.collector.system.collector_classes

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=['all'],
                              filter_spec=['*'])

    facts = fact_collector.collect()

    assert 'ansible_facts' in facts


# Generated at 2022-06-16 23:36:33.648544
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)

    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'ansible_all_ipv4_addresses' in facts['ansible_facts']

# Generated at 2022-06-16 23:36:41.299942
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}

    fact_collector = AnsibleFactCollector

# Generated at 2022-06-16 23:36:53.611547
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    collectors = [ansible.module_utils.facts.collector.network.NetworkCollector,
                  ansible.module_utils.facts.collector.platform.PlatformCollector,
                  ansible.module_utils.facts.collector.distribution.DistributionCollector,
                  ansible.module_utils.facts.collector.virtual.VirtualCollector]

    fact_collector = AnsibleFactCollector(collectors=collectors)
    facts = fact_collector.collect()

# Generated at 2022-06-16 23:37:02.478522
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset(['all']))

    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)

# Generated at 2022-06-16 23:37:09.410627
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec='ansible_*',
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, PrefixFactNamespace)
    assert fact_collector.namespace.prefix == 'ansible_'
    assert fact_collector.filter_spec

# Generated at 2022-06-16 23:37:19.505570
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceList
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceSet

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}


# Generated at 2022-06-16 23:37:26.541117
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a mock collector that returns a dict with a single key
    class MockCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'mock_key': 'mock_value'}

    # Create a mock collector that returns a dict with a single key
    class MockCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'mock_key2': 'mock_value2'}

    # Create a mock collector that returns a dict with a single key
    class MockCollector3(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'mock_key3': 'mock_value3'}

   

# Generated at 2022-06-16 23:37:50.717353
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]


# Generated at 2022-06-16 23:38:01.006301
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import ansible_network
    from ansible.module_utils.facts import ansible_virtual
    from ansible.module_utils.facts import ansible_distribution
    from ansible.module_utils.facts import ansible_pkg_mgr
    from ansible.module_utils.facts import ansible_user
    from ansible.module_utils.facts import ansible_date_time
    from ansible.module_utils.facts import ansible_system
    from ansible.module_utils.facts import ansible_service_mgr
    from ansible.module_utils.facts import ansible_mount
    from ansible.module_utils.facts import ansible

# Generated at 2022-06-16 23:38:08.476741
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for method collect of class AnsibleFactCollector'''

    class TestCollector(collector.BaseFactCollector):
        '''Test class for AnsibleFactCollector unit test'''

        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    # Test case 1: no filter_spec
    test_collector = TestCollector()
    ansible_fact_collector = AnsibleFactCollector(collectors=[test_collector])
    facts = ansible_fact_collector.collect()
    assert facts == {'test_fact': 'test_value'}

    # Test case 2: filter_spec = 'test_fact'
    ansible_fact_collector

# Generated at 2022-06-16 23:38:17.955248
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactResolver

    class MockDistributionFactCollector(DistributionFactCollector):
        def __init__(self, namespace=None):
            super(MockDistributionFactCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'distribution': 'mock_distribution'}


# Generated at 2022-06-16 23:38:28.726701
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    # Create a namespace
    prefix_namespace = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a collector
    fact_collector = AnsibleFactCollector(namespace=prefix_namespace)

    # Create a mock module
    module = MockModule()

    # Create a mock collected_facts
    collected_facts = {'ansible_test_fact': 'test_value'}

    # Call collect method
    facts_dict = fact_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that the facts_dict is not empty
    assert facts_dict

    # Assert that the facts_dict contains the key 'ansible_test_fact'
    assert 'ansible_test_fact' in facts_dict

   

# Generated at 2022-06-16 23:38:40.212835
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import collector

    # Create a list of all collector classes

# Generated at 2022-06-16 23:38:53.200809
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    # Create a collector that collects facts from the default collectors
    fact_collector = \
        get_ansible_collector(all_collector_classes=default_collectors.collector_classes,
                              gather_subset=['all'],
                              gather_timeout=10,
                              minimal_gather_subset=frozenset())

    # Collect facts
    facts_dict = fact_collector.collect()

    # Check that the facts are collected under the 'ansible_facts' key
    assert 'ansible_facts' in facts_dict
    assert 'ansible_facts' in facts_dict['ansible_facts']



# Generated at 2022-06-16 23:39:03.038350
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

        def __init__(self, prefix=None):
            super(TestNamespace, self).__init__(prefix=prefix)

    test_collector = TestCollector(namespace=TestNamespace())
    fact_collector = AnsibleFactCollector(collectors=[test_collector])
    facts = fact_collector.collect()
   

# Generated at 2022-06-16 23:39:13.424082
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FacterFactCollector
    from ansible.module_utils.facts.collector import OhaiFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector
    from ansible.module_utils.facts.collector import PipFactCollector
    from ansible.module_utils.facts.collector import PlatformFactCollector
    from ansible.module_utils.facts.collector import VirtualBoxFactCollector
    from ansible.module_utils.facts.collector import VMwareFactCollector

# Generated at 2022-06-16 23:39:23.005981
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FacterFactCollector
    from ansible.module_utils.facts.collector import OhaiFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector
    from ansible.module_utils.facts.collector import PlatformFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector
    from ansible.module_utils.facts.collector import FileGlobFactCollector

    # test with no namespace
    fact_collector = AnsibleFactCollector()
    facts = fact_collect

# Generated at 2022-06-16 23:39:52.011569
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [ansible_collector.AnsibleCollector,
                             cache.CacheCollector,
                             network.NetworkCollector,
                             system.SystemCollector,
                             virtual.VirtualCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10)

    assert fact_collector.collectors[0].name == 'ansible'
   

# Generated at 2022-06-16 23:40:03.862670
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv4Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv6Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceDNSCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMACCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMTUCollector
   