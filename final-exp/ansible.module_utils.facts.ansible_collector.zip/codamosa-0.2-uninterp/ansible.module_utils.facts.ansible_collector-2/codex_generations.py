

# Generated at 2022-06-16 23:30:15.285797
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-16 23:30:19.549126
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] is True

# Generated at 2022-06-16 23:30:24.399107
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:28.406885
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'],
                                                       'module_setup': True}

# Generated at 2022-06-16 23:30:29.997314
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'],
                                                       'module_setup': True}

# Generated at 2022-06-16 23:30:33.163056
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] is True

# Generated at 2022-06-16 23:30:35.731021
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:46.601274
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import ansible_virtual
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import network_resources
    from ansible.module_utils.facts import ohai
    from ansible.module_utils.facts import systemd
    from ansible.module_utils.facts import systemd_hostname


# Generated at 2022-06-16 23:30:57.247406
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact': 'test2_value'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'


# Generated at 2022-06-16 23:31:09.465630
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceList

    # Test that we get the correct collectors
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=['all'])
    assert len(fact_collector.collectors) == len(default_collectors)

    # Test that we get the correct collectors

# Generated at 2022-06-16 23:31:18.808391
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:31:31.237118
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import default_collector_classes

    fact_collector = get_ansible_collector(all_collector_classes=default_collector_classes)
    assert fact_collector.collectors == default_collectors
    assert fact_collector.filter_spec == []
    assert fact_collector.namespace is None

    fact_collector = get_ansible_collector(all_collector_classes=default_collector_classes,
                                           filter_spec=['*'])
    assert fact_collector.collectors == default_collectors
    assert fact_collector.filter_spec == ['*']
    assert fact_collector.namespace is None

    fact_collector = get_ansible_collector

# Generated at 2022-06-16 23:31:41.922225
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert len(fact_collector.collectors) == len(ansible_collector.collector_classes)

    # Test with a namespace


# Generated at 2022-06-16 23:31:53.268617
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user

    all_collector_classes = [
        ansible.module_utils.facts.system.distribution.Distribution,
        ansible.module_utils.facts.system.platform.Platform,
        ansible.module_utils.facts.system.pkg_mgr.PkgMgr,
        ansible.module_utils.facts.system.user.User
    ]

    fact_collector = get_ansible_collector(all_collector_classes)

    facts = fact_collector.collect()

    assert 'ansible_facts' in facts

# Generated at 2022-06-16 23:31:55.928842
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:32:03.598614
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [ansible_collector.AnsibleCollector,
                             cache.CacheCollector,
                             network.NetworkCollector,
                             system.SystemCollector,
                             virtual.VirtualCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)

    assert fact_collector.collectors[0].name == 'ansible'
    assert fact_collector.collectors[1].name == 'cache'
    assert fact_collector

# Generated at 2022-06-16 23:32:07.562073
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:32:18.653127
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import ansible_network
    from ansible.module_utils.facts import ansible_virtualization
    from ansible.module_utils.facts import ansible_distribution
    from ansible.module_utils.facts import ansible_pkg_mgr
    from ansible.module_utils.facts import ansible_service_mgr
    from ansible.module_utils.facts import ansible_user
    from ansible.module_utils.facts import ansible_date_time
    from ansible.module_utils.facts import ansible_system
    from ansible.module_utils.facts import ansible_mounts

# Generated at 2022-06-16 23:32:27.286997
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import namespace

    # Make sure we can get a collector
    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=30,
                                           minimal_gather_subset=frozenset(['all']))

    # Make sure we can collect facts
    facts = fact_collector.collect(module=None, collected_facts=None)

    # Make

# Generated at 2022-06-16 23:32:34.192459
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] == True

# Generated at 2022-06-16 23:32:43.268668
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] == True

# Generated at 2022-06-16 23:32:47.370288
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:32:59.725053
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert isinstance(fact_collector, AnsibleFactCollector)

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=['all'])
    assert isinstance(fact_collector, AnsibleFactCollector)

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=['all', 'network'])
    assert isinstance(fact_collector, AnsibleFactCollector)


# Generated at 2022-06-16 23:33:05.327044
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts['gather_subset'] == ['all']
    assert meta_facts['module_setup'] == True

# Generated at 2022-06-16 23:33:09.194321
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:33:16.060983
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import package
    from ansible.module_utils.facts import service
    from ansible.module_utils.facts import user
    from ansible.module_utils.facts import selinux
    from ansible.module_utils.facts import zypper
    from ansible.module_utils.facts import dnf
    from ansible.module_utils.facts import pip
    from ansible.module_utils.facts import gem
    from ansible.module_utils.facts import oh

# Generated at 2022-06-16 23:33:20.393434
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] == True

# Generated at 2022-06-16 23:33:23.256526
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:33:30.013302
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'],
                                                       'module_setup': True}

# Generated at 2022-06-16 23:33:36.023673
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:33:55.593343
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import default

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test_namespace'

    test_collector = TestCollector(namespace=TestNamespace())
    fact_collector = AnsibleFactCollector(collectors=[test_collector])

    facts = fact_collector.collect()


# Generated at 2022-06-16 23:34:05.738473
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact': 'test2_value'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3_fact': 'test3_value'}

# Generated at 2022-06-16 23:34:18.345372
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.collector import DictFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a DictFactCollector that returns a dictionary with two keys
    # 'a' and 'b'
    class TestDictFactCollector(DictFactCollector):
        name = 'test'

        def __init__(self, namespace=None):
            super(TestDictFactCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'a': 1, 'b': 2}

    # Create a BaseFactCollector that returns a dictionary with two keys
    # 'c' and 'd'

# Generated at 2022-06-16 23:34:27.083682
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.file
    import ansible.module_utils.facts.collector.service
    import ansible.module_utils.facts.collector.command


# Generated at 2022-06-16 23:34:37.018786
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)

    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'ansible_local' in facts['ansible_facts']
    assert 'ansible_network_resources'

# Generated at 2022-06-16 23:34:46.708634
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_defaults
    from ansible.module_utils.facts import namespace

    all_collector_classes = collector_defaults.ALL_COLLECTOR_CLASSES
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()
    filter_spec = []


# Generated at 2022-06-16 23:34:56.184745
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.collectors[0], collector.NetworkFactCollector)
    assert isinstance(fact_collector.collectors[1], collector.PlatformFactCollector)
    assert isinstance(fact_collector.collectors[2], collector.FacterFactCollector)
    assert isinstance(fact_collector.collectors[3], collector.OhaiFactCollector)
    assert isinstance(fact_collector.collectors[4], collector.PkgMgrFactCollector)

# Generated at 2022-06-16 23:35:06.320767
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import ansible_network
    from ansible.module_utils.facts import ansible_virtual
    from ansible.module_utils.facts import ansible_distribution
    from ansible.module_utils.facts import ansible_pkg_mgr
    from ansible.module_utils.facts import ansible_service_mgr
    from ansible.module_utils.facts import ansible_user
    from ansible.module_utils.facts import ansible_date_time
    from ansible.module_utils.facts import ansible_system
    from ansible.module_utils.facts import ansible_selinux

# Generated at 2022-06-16 23:35:17.067445
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=['all'],
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors[0].namespace is None
    assert fact_collector.collectors[1].namespace is None
    assert fact_collector.collectors[2].namespace is None
    assert fact_collector.collectors[3].names

# Generated at 2022-06-16 23:35:26.808589
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactNamespace

    namespace = PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=namespace)

    # Add a collector that knows what gather_subset we used so it it can provide a fact
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    fact_collector.collectors.append(collector_meta_data_collector)

    # Add a collector that provides a fact

# Generated at 2022-06-16 23:35:44.130035
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

   

# Generated at 2022-06-16 23:35:54.640549
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}


# Generated at 2022-06-16 23:36:06.463147
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import distribution

    # Create a fact collector with a namespace
    fact_collector = \
        AnsibleFactCollector(collectors=[network.NetworkCollector(),
                                         system.SystemCollector(),
                                         distribution.DistributionCollector()],
                             namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    # Collect facts
    facts = fact_collector.collect()

    # Check facts
    assert 'ansible_all_ipv4_addresses' in facts
    assert 'ansible_all_ipv6_addresses'

# Generated at 2022-06-16 23:36:17.057046
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pip
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.file_system
    import ansible.module_utils.facts

# Generated at 2022-06-16 23:36:26.383768
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    collector_obj = get_ansible_collector(all_collector_classes=default_collectors)
    assert collector_obj.collectors
    assert collector_obj.collectors[-1].name == 'gather_subset'
    assert collector_obj.collectors[-1].gather_subset == ['all']
    assert collector_obj.collectors[-1].module_setup is True

    collector_obj = get_ansible_collector(all_collector_classes=default_collectors,
                                          gather_subset=['network'])
    assert collector_obj.collectors
    assert collector_obj.collectors[-1].name == 'gather_subset'
    assert collector_obj.collectors[-1].gather_sub

# Generated at 2022-06-16 23:36:38.256466
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no collectors
    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert facts == {}

    # Test with one collector
    fact_collector = AnsibleFactCollector(collectors=[collector.FacterFactCollector()])
    facts = fact_collector.collect()
    assert facts == {}

    # Test with two collectors
    fact_collector = AnsibleFactCollector(collectors=[collector.FacterFactCollector(),
                                                      collector.OhaiFactCollector()])
    facts = fact_collector.collect()
    assert facts == {}

    # Test with two collectors and a namespace

# Generated at 2022-06-16 23:36:44.709731
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    # Note: this test is not complete, but it is a start.
    # We need to test the various cases of the filter_spec.
    # We need to test the various cases of the namespace.

    # Test with no namespace and no filter_spec
    fact_collector = \
        AnsibleFactCollector(collectors=[
            ansible.module_utils.facts.collector.network.NetworkCollector(),
            ansible.module_utils.facts.collector.platform.PlatformCollector(),
            ansible.module_utils.facts.collector.system.SystemCollector()])

    facts = fact_collector.collect()
   

# Generated at 2022-06-16 23:36:54.172835
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.distribution

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
        ansible.module_utils.facts.collector.hardware.HardwareCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
    ]

   

# Generated at 2022-06-16 23:37:04.414099
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           filter_spec=['ansible_*'])

    facts = fact_collector.collect()

    assert 'ansible_facts' in facts

# Generated at 2022-06-16 23:37:15.348881
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv4Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv6Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceMACCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMTUCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceNetmaskCollector
   

# Generated at 2022-06-16 23:37:36.519595
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with a single collector
    class TestCollector(collector.BaseFactCollector):
        name = 'test_collector'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    test_collector = TestCollector()
    fact_collector = AnsibleFactCollector(collectors=[test_collector])

    facts = fact_collector.collect()
    assert facts == {'test_fact': 'test_value'}

    # Test with multiple collectors
    class TestCollector2(collector.BaseFactCollector):
        name = 'test_collector2'
        _fact_ids = set([])


# Generated at 2022-06-16 23:37:47.922318
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

# Generated at 2022-06-16 23:37:56.518793
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}


# Generated at 2022-06-16 23:38:07.781328
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import PlatformCollector
    from ansible.module_utils.facts.collector import DistributionCollector
    from ansible.module_utils.facts.collector import LocalCollector
    from ansible.module_utils.facts.collector import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

       

# Generated at 2022-06-16 23:38:16.031830
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    fact_collector = get_ansible_collector(all_collector_classes)
    assert fact_collector is not None
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors is not None
    assert len(fact_collector.collectors) > 0
    assert isinstance(fact_collector.collectors[0], collector.BaseFactCollector)

# Generated at 2022-06-16 23:38:27.551766
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}


# Generated at 2022-06-16 23:38:36.846510
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pip


# Generated at 2022-06-16 23:38:46.241358
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    fact_collector = get_ansible_collector(all_collector_classes)
    assert fact_collector
    assert fact_collector.collectors
    assert fact_collector.collectors[0].namespace
    assert fact_collector.collectors[0].namespace.prefix == 'ansible_'
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup == True

# Generated at 2022-06-16 23:38:58.301116
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}


# Generated at 2022-06-16 23:39:09.757490
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    # Test with no namespace
    collectors = [NetworkCollector(), PlatformCollector(), SystemCollector()]
    fact_collector = AnsibleFactCollector(collectors=collectors)
    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'network' in facts['ansible_facts']
    assert 'system' in facts['ansible_facts']
    assert 'platform' in facts['ansible_facts']

    # Test with namespace
    namespace = Prefix

# Generated at 2022-06-16 23:39:43.676263
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'


# Generated at 2022-06-16 23:39:53.547838
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    # Test that we can get a collector with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert fact_collector is not None

    # Test that we can get a collector with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert fact_collector is not None

    # Test that we can get a collector with a filter_spec

# Generated at 2022-06-16 23:40:05.213035
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    # Test with default gather_subset and filter_spec
    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           gather_subset=None,
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())

    assert fact_collector.collectors[0].name == 'all'
    assert fact_collector.collectors[1].name == 'gather_subset'
   