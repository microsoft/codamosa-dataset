

# Generated at 2022-06-16 23:30:26.064579
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    all_collector_classes = collector.get_collector_classes()

    # Test that the default collector is returned
    fact_collector = get_ansible_collector(all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(all_collector_classes)

    # Test that a collector with a namespace is returned
    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-16 23:30:34.684281
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    # Test with default gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert fact_collector.collectors[-1].name == 'gather_subset'
    assert fact_collector.collectors[-1].gather_subset == ['all']

    # Test with gather_subset=['all']

# Generated at 2022-06-16 23:30:43.036855
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    facts = fact_collector.collect()
    assert facts['test_fact'] == 'test_value'



# Generated at 2022-06-16 23:30:56.554060
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import DictCollector
    from ansible.module_utils.facts.collector import FileGlobCollector
    from ansible.module_utils.facts.collector import FileDictCollector
    from ansible.module_utils.facts.collector import FileLinesCollector
    from ansible.module_utils.facts.collector import FileJsonLinesCollector
    from ansible.module_utils.facts.collector import FileJsonCollector
    from ansible.module_utils.facts.collector import FileIniCollector

# Generated at 2022-06-16 23:31:08.806962
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.hardware

    # Create a list of collectors

# Generated at 2022-06-16 23:31:17.974055
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]


# Generated at 2022-06-16 23:31:24.983221
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts import namespace

    all_collector_classes = collector_registry.all_collector_classes()

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-16 23:31:36.465050
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import package
    from ansible.module_utils.facts import collector

    all_collector_classes = [ansible_collector.AnsibleCollector,
                             network.NetworkCollector,
                             system.SystemCollector,
                             virtual.VirtualCollector,
                             hardware.HardwareCollector,
                             distribution.DistributionCollector,
                             package.PackageCollector]


# Generated at 2022-06-16 23:31:46.489868
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert fact_collector.collectors[0].name == 'facter'
    assert fact_collector.collectors[1].name == 'ohai'
    assert fact_collector.collectors[2].name == 'gather_subset'

# Generated at 2022-06-16 23:31:58.122385
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network_collector
    from ansible.module_utils.facts import system_collector
    from ansible.module_utils.facts import virtual_collector

    # create a namespace
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    # create a collector
    collector_obj = ansible_collector.AnsibleCollector(namespace=namespace_obj)

    # create a collector
    network_collector_obj = network_collector.NetworkCollector(namespace=namespace_obj)

    # create a collector
    system_collector_obj = system_collector.SystemCollector(namespace=namespace_obj)

# Generated at 2022-06-16 23:32:12.000673
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'


# Generated at 2022-06-16 23:32:20.638843
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no collectors
    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert facts == {}

    # Test with one collector
    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    facts = fact_collector.collect()
    assert facts == {'test_fact': 'test_value'}

    # Test with two collectors
    class TestCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    fact

# Generated at 2022-06-16 23:32:30.473638
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

# Generated at 2022-06-16 23:32:41.115986
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset(['all']))

    assert fact_collector.collectors[0].name == 'all'
    assert fact_collector.collectors[1].name == 'gather_subset'
    assert fact_collector.collectors[1].gather_subset == ['all']
   

# Generated at 2022-06-16 23:32:50.310919
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no collectors
    fact_collector = AnsibleFactCollector()
    assert fact_collector.collect() == {}

    # Test with one collector
    fact_collector = AnsibleFactCollector(collectors=[collector.FacterFactCollector()])
    assert fact_collector.collect() == {'facter': {}}

    # Test with two collectors
    fact_collector = AnsibleFactCollector(collectors=[collector.FacterFactCollector(),
                                                      collector.OhaiFactCollector()])
    assert fact_collector.collect() == {'facter': {}, 'ohai': {}}

    # Test with two collectors, one of which returns no facts

# Generated at 2022-06-16 23:33:03.740465
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv4Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv6Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceMACCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMTUCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceNetmaskCollector
   

# Generated at 2022-06-16 23:33:12.878835
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    all_collector_classes = collector.get_collector_classes()
    fact_collector = ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes)
    assert fact_collector
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert fact_collector.collectors
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec == []

    fact_collector = ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                             filter_spec=['ansible_*'])

# Generated at 2022-06-16 23:33:23.799437
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector
    ]

    fact_collector = get_ansible_collector(all_collector_classes,
                                           gather_subset=['all'],
                                           filter_spec=['*'])

    facts = fact_collector.collect()


# Generated at 2022-06-16 23:33:37.751104
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_defaults
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_defaults.ALL_COLLECTOR_CLASSES,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.filter_spec is None
    assert fact_collector.namespace is None

# Generated at 2022-06-16 23:33:42.938164
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [cache.CacheFactCollector,
                             hardware.HardwareFactCollector,
                             network.NetworkFactCollector,
                             system.SystemFactCollector,
                             virtual.VirtualFactCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])

    assert fact_collector.collectors[0].name == 'cache'

# Generated at 2022-06-16 23:33:58.529919
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test that we get the right collectors for gather_subset=all
    fact_collector = get_ansible_collector(all_collector_classes=collector.ALL_COLLECTOR_CLASSES,
                                           gather_subset=['all'])
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(collector.ALL_COLLECTOR_CLASSES)

    # Test that we get the right collectors for gather_subset=!all

# Generated at 2022-06-16 23:34:09.983904
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2'])

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3'])


# Generated at 2022-06-16 23:34:21.352411
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.collectors[0], collector.BaseFactCollector)

# Generated at 2022-06-16 23:34:32.430036
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}

    class TestCollector4(collector.BaseFactCollector):
        name = 'test4'


# Generated at 2022-06-16 23:34:39.923436
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=['all'])

    assert fact_collector.namespace.prefix == 'ansible_'
    assert fact_collector.filter_spec == ['ansible_*']
    assert len(fact_collector.collectors) == len(default_collectors) + 1
    assert fact_collector.collectors

# Generated at 2022-06-16 23:34:51.469091
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

        def __init__(self):
            super(TestNamespace, self).__init__()
            self.add_prefix('test_')

    test_namespace = TestNamespace()

    test_collector = TestCollector(namespace=test_namespace)
    test_collector_list = [test_collector]

   

# Generated at 2022-06-16 23:35:02.361820
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a mock module
    module = MockModule()

    # Create a mock collector
    mock_collector = MockCollector()
    mock_collector.collect_with_namespace = Mock(return_value={'ansible_os_family': 'RedHat'})

    # Create a mock namespace
    mock_namespace = MockNamespace()

    # Create an AnsibleFactCollector
    fact_collector = AnsibleFactCollector(collectors=[mock_collector], namespace=mock_namespace)

    # Call collect
    facts = fact_collector.collect(module=module)

    # Assert that the facts are returned
    assert facts == {'ansible_os_family': 'RedHat'}

    # Assert that the namespace is called
    mock_namespace.add_prefix.assert_called_once_with

# Generated at 2022-06-16 23:35:10.328956
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.solaris
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.system

# Generated at 2022-06-16 23:35:17.504500
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    # Test with default args
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes)
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, namespace.PrefixFactNamespace)
    assert fact_collector.namespace.prefix == 'ansible_'
    assert fact_collector.filter_spec == []
    assert len(fact_collector.collectors) == len(default_collectors.collector_classes)

    # Test with custom args
    fact_collect

# Generated at 2022-06-16 23:35:27.253685
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes)

    facts = fact_collector.collect()

# Generated at 2022-06-16 23:35:44.380954
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.solaris
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.file

# Generated at 2022-06-16 23:35:48.477042
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceList
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceSet
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceTuple
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceFrozenset
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceOrderedDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDefaultDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceCounter
   

# Generated at 2022-06-16 23:35:56.356852
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [ansible_collector.AnsibleCollector,
                             cache.CacheCollector,
                             network.NetworkCollector,
                             system.SystemCollector,
                             virtual.VirtualCollector]

    fact_collector = get_ansible_collector(all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10)

    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-16 23:36:06.555179
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           gather_subset=['all'])

    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'ansible_gather_subset' in facts['ansible_facts']
    assert 'ansible_module_setup' in facts['ansible_facts']
    assert 'ansible_all_ipv4_addresses' in facts['ansible_facts']
   

# Generated at 2022-06-16 23:36:17.206782
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, namespace.PrefixFactNamespace)

# Generated at 2022-06-16 23:36:26.435780
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import DictFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'


# Generated at 2022-06-16 23:36:38.322875
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    # Test with default gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert fact_collector.collectors[-1].gather_subset == ['all']

    # Test with gather_subset=['all']
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=['all'])
    assert fact_collector.collectors[-1].gather_subset == ['all']

    # Test with gather_subset=['network']

# Generated at 2022-06-16 23:36:46.094844
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert fact_collector.collectors[-1].name == 'gather_subset'
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True

# Generated at 2022-06-16 23:36:54.677116
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace

    # Test with default args
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec == []

    # Test with namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors

# Generated at 2022-06-16 23:37:03.799992
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=['all'],
                                           gather_timeout=10)

    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(default_collectors) + 1
    assert isinstance(fact_collector.collectors[-1], ansible_collector.CollectorMetaDataCollector)

# Generated at 2022-06-16 23:37:51.783050
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': 'mock_value'}

    mock_collector = MockCollector()
    fact_collector = AnsibleFactCollector(collectors=[mock_collector])

    facts = fact_collector.collect()
    assert facts == {'mock_fact': 'mock_value'}

# Generated at 2022-06-16 23:38:01.105594
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    # Create a list of collectors
    collectors = [ansible_collector.AnsibleCollector(),
                  network.NetworkCollector(),
                  system.SystemCollector(),
                  virtual.VirtualCollector()]

    # Create a namespace
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a filter spec
    filter_spec = ['ansible_*']

    # Create an AnsibleFactCollector object

# Generated at 2022-06-16 23:38:08.530994
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])

    facts = fact_collector.collect()

    assert 'ansible_facts' in facts

# Generated at 2022-06-16 23:38:16.963130
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact': 'test2_value'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        _fact_ids = set([])


# Generated at 2022-06-16 23:38:25.780983
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    # Test with all collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           gather_subset=['all'],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())
    assert len(fact_collector.collectors) == len(collector.all_collector_classes)

    # Test with minimal subset

# Generated at 2022-06-16 23:38:36.289425
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network

    fact_collector = \
        AnsibleFactCollector(collectors=[ansible.module_utils.facts.collector.network.NetworkCollector()])

    facts_dict = fact_collector.collect()

    assert 'ansible_all_ipv4_addresses' in facts_dict
    assert 'ansible_all_ipv6_addresses' in facts_dict
    assert 'ansible_default_ipv4' in facts_dict
    assert 'ansible_default_ipv6' in facts_dict
    assert 'ansible_default_ipv4' in facts_dict
    assert 'ansible_default_ipv6' in facts_dict
    assert 'ansible_eth0' in facts_dict

# Generated at 2022-06-16 23:38:43.786178
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace

    # Test with minimal_gather_subset=None
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['*'],
                                           gather_subset=['all'],
                                           gather_timeout=0,
                                           minimal_gather_subset=None)

    # Test with minimal_gather_subset=frozenset()

# Generated at 2022-06-16 23:38:56.280212
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # test with namespace
    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, PrefixFactNamespace)

# Generated at 2022-06-16 23:39:04.920321
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-16 23:39:16.256273
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=['all'],
                                           namespace=PrefixFactNamespace(prefix='ansible_'))

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, PrefixFactNamespace)
    assert fact_collector.namespace.prefix == 'ansible_'
    assert len(fact_collector.collectors) == len(default_collectors) + 1

    # Test that the last