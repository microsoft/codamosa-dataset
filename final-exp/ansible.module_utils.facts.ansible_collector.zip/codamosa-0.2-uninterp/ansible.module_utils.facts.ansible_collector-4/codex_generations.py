

# Generated at 2022-06-16 23:30:18.845069
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    test_collector = TestCollector()
    test_collector2 = TestCollector2()

# Generated at 2022-06-16 23:30:21.210385
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO: write unit test
    pass

# Generated at 2022-06-16 23:30:29.452299
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}

    class TestCollector4(collector.BaseFactCollector):
        name = 'test4'


# Generated at 2022-06-16 23:30:36.223823
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no filter_spec
    fact_collector = AnsibleFactCollector(filter_spec=None)
    facts = fact_collector.collect()
    assert facts == {'ansible_facts': {'gather_subset': ['all'], 'module_setup': True}}

    # Test with filter_spec
    fact_collector = AnsibleFactCollector(filter_spec='*')
    facts = fact_collector.collect()
    assert facts == {'ansible_facts': {'gather_subset': ['all'], 'module_setup': True}}

    # Test with filter_spec
    fact_collector = AnsibleFactCollector(filter_spec=['*'])
    facts = fact_collector.collect()

# Generated at 2022-06-16 23:30:46.698236
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import package
    from ansible.module_utils.facts import service

    all_collector_classes = [
        ansible_collector.AnsibleCollector,
        network.NetworkCollector,
        hardware.HardwareCollector,
        virtual.VirtualCollector,
        system.SystemCollector,
        distribution.DistributionCollector,
        package.PackageCollector,
        service.ServiceCollector,
    ]

    fact_collector = get

# Generated at 2022-06-16 23:30:57.321680
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(collector.collector_classes) + 1

# Generated at 2022-06-16 23:31:09.526415
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test the default case
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.filter_spec == []
    assert len(fact_collector.collectors) == len(collector.collector_classes) + 1
    assert isinstance(fact_collector.collectors[-1], CollectorMetaDataCollector)

    # Test the case where we filter out some facts

# Generated at 2022-06-16 23:31:18.635615
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.distribution

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector
    ]

    fact_collect

# Generated at 2022-06-16 23:31:30.948534
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact3': 'test_value3'}

# Generated at 2022-06-16 23:31:40.395550
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [ansible_collector.AnsibleCollector,
                             network.NetworkCollector,
                             system.SystemCollector,
                             virtual.VirtualCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

# Generated at 2022-06-16 23:31:54.772850
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test that get_ansible_collector() returns a collector with the expected
    # collectors in the expected order.
    #
    # This test is a bit fragile, in that it assumes that the order of the
    # collectors in the returned collector is the same as the order of the
    # collectors in the list of collector classes.
    #
    # This test is also fragile in that it assumes that the order of the
    # collectors in the list of collector classes is the same as the order of
    # the collectors in the list of collector classes returned by
    # collector_classes_from_gather_subset().
    #
    # This test is also fragile in that it assumes that the order of the
    # collectors in the list of collector classes returned by

# Generated at 2022-06-16 23:32:05.566237
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import timeout

    # Test with all collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())

    assert len(fact_collector.collectors) == len(collector.all_collector_classes)

    # Test with only one collector

# Generated at 2022-06-16 23:32:17.707826
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FacterFactCollector
    from ansible.module_utils.facts.collector import OhaiFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector
    from ansible.module_utils.facts.collector import PipeFactCollector
    from ansible.module_utils.facts.collector import PlatformFactCollector
    from ansible.module_utils.facts.collector import FileGlobFactCollector

# Generated at 2022-06-16 23:32:30.272521
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.hardware

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.hardware.HardwareCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)

# Generated at 2022-06-16 23:32:42.758913
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-16 23:32:52.893481
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import distribution

    all_collector_classes = [
        default.Default,
        hardware.Hardware,
        network.Network,
        virtual.Virtual,
        system.System,
        distribution.Distribution,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=['!all'])


# Generated at 2022-06-16 23:33:05.648281
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    fact_collector = get_ansible_collector(all_collector_classes)
    assert fact_collector.collectors
    assert fact_collector.filter_spec == []
    assert fact_collector.namespace is None
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True
    assert fact_collector.collectors[-1].namespace is None


# Generated at 2022-06-16 23:33:14.019669
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    all_collector_classes = default_collectors + [TestCollector]
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           filter_spec=['test'],
                                           namespace=PrefixFactNamespace(prefix='ansible_'))


# Generated at 2022-06-16 23:33:24.840009
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import cache_manager
    from ansible.module_utils.facts import namespace

    all_collector_classes = collector.get_collector_classes()

    # Test with no gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert fact_collector.collectors
    assert fact_collector.filter_spec is None
    assert fact_collector.namespace is None

    # Test with gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])
    assert fact_collector.collectors
    assert fact_collect

# Generated at 2022-06-16 23:33:38.367667
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import collectors

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test_namespace'

    test_collector = TestCollector()
    test_namespace = TestNamespace()

    fact_collector = AnsibleFactCollector(collectors=[test_collector],
                                          namespace=test_namespace)

    collected_facts = fact_collector.collect()

# Generated at 2022-06-16 23:33:50.631770
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    # Test with a namespace

# Generated at 2022-06-16 23:34:02.387659
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'


# Generated at 2022-06-16 23:34:07.086875
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.collectors.base as base
    import ansible.module_utils.facts.collectors.network as network
    import ansible.module_utils.facts.collectors.hardware as hardware
    import ansible.module_utils.facts.collectors.virtual as virtual
    import ansible.module_utils.facts.collectors.system as system
    import ansible.module_utils.facts.collectors.distribution as distribution

    class MockCollector(base.BaseFactCollector):
        name = 'mock'

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': 'mock_value'}

    class MockCollector2(base.BaseFactCollector):
        name

# Generated at 2022-06-16 23:34:11.116804
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [ansible_collector.AnsibleCollector,
                             cache.CacheCollector,
                             network.NetworkCollector,
                             system.SystemCollector,
                             virtual.VirtualCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])

    assert fact_collector.collectors[0].name == 'ansible'

# Generated at 2022-06-16 23:34:21.905422
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespaces

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert len(fact_collector.collectors) == len(collector_classes)

    # Test with a namespace
    fact_collector = get_ansible_collector

# Generated at 2022-06-16 23:34:32.468709
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts import namespaces

    # Test with all collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_registry.all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(collector_registry.all_collector_classes)

    # Test with subset of collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_registry.all_collector_classes,
                                           gather_subset=['network', 'virtual'])
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-16 23:34:43.661498
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout

    # Create a fact collector that collects facts from the 'all' gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())

    # Create a fact cache that will be used to store facts
    fact_cache = cache.FactCache()

    # Collect facts

# Generated at 2022-06-16 23:34:55.462866
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import default

    all_collector_classes = [
        ansible_collector.AnsibleCollector,
        hardware.Hardware,
        system.System,
        network.Network,
        virtual.Virtual,
        default.Default,
    ]

    fact_collector = get_ansible_collector(all_collector_classes)
    assert fact_collector.collectors[0].name == 'ansible'
    assert fact_collector.collectors[1].name == 'hardware'


# Generated at 2022-06-16 23:35:05.965677
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import collector

    # Create a namespace
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a cache
    cache_obj = cache.FactCache()

    # Create a timeout

# Generated at 2022-06-16 23:35:14.731925
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert fact_collector.namespace.prefix == 'ansible_'
    assert fact_collector.filter_spec == ['*']
    assert fact_collector.collectors[-1].gather_subset == ['all']

# Generated at 2022-06-16 23:35:28.725135
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network

    all_collector_classes = [ansible_collector.AnsibleCollector,
                             network.NetworkCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset(['all']))

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == 2

    # test that the CollectorMetaDataCollector is the last collector

# Generated at 2022-06-16 23:35:40.606138
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceList
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceSet
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceTuple
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceFrozenset
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceOrderedDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDefaultDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceCounter
   

# Generated at 2022-06-16 23:35:48.288473
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_functions
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_functions.all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=0,
                                           minimal_gather_subset=frozenset())
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with a namespace

# Generated at 2022-06-16 23:35:59.781060
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network

    all_collector_classes = collector.get_collector_classes()

    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                gather_subset=['all'],
                                                gather_timeout=10,
                                                minimal_gather_subset=frozenset(['all']))

    # Make sure the network collector is in the list of collectors
    assert network.NetworkCollector in fact_collector.collectors

    # Make sure the CollectorMetaDataCollector is in the list of collectors
    assert CollectorMetaDataCollector in fact

# Generated at 2022-06-16 23:36:11.155937
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class FakeCollector(collector.BaseFactCollector):
        name = 'fake'

        def collect(self, module=None, collected_facts=None):
            return {'fake_fact': 'fake_value'}

    class FakeNamespace(namespace.BaseFactNamespace):
        name = 'fake'

    fake_collector = FakeCollector()
    fake_namespace = FakeNamespace()

    fact_collector = AnsibleFactCollector(collectors=[fake_collector],
                                          namespace=fake_namespace)

    collected_facts = fact_collector.collect()

    assert collected_facts == {'fake': {'fake_fact': 'fake_value'}}

# Generated at 2022-06-16 23:36:15.516247
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    facts = fact_collector.collect()
    assert facts == {'ansible_facts': {'test': 'test'}}

# Generated at 2022-06-16 23:36:22.397083
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}


# Generated at 2022-06-16 23:36:33.563774
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with all collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, namespace.BaseFactNamespace)
    assert fact_collector.namespace.name == 'ansible'
    assert len(fact_collector.collectors) == len(collector.all_collector_classes)

    # Test with a subset of collectors

# Generated at 2022-06-16 23:36:41.250169
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with a namespace
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, namespace.PrefixFactNamespace)

# Generated at 2022-06-16 23:36:53.535444
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import DictFactCollector
    from ansible.module_utils.facts.collector import FileGlobFactCollector
    from ansible.module_utils.facts.collector import FileExtensionFactCollector
    from ansible.module_utils.facts.collector import FileContainsFactCollector
    from ansible.module_utils.facts.collector import FileExistsFactCollector
    from ansible.module_utils.facts.collector import FileModeFactCollector
    from ansible.module_utils.facts.collector import FileOwnerFactCollector
    from ansible.module_utils.facts.collector import FileSize

# Generated at 2022-06-16 23:37:14.838620
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    # Test with gather_subset=['all']
    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())

    # Test with gather_subset=['network']

# Generated at 2022-06-16 23:37:25.358295
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())
    assert fact_collector.namespace.prefix == 'ansible_'
    assert fact_collector.filter_spec == ['ansible_*']
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors

# Generated at 2022-06-16 23:37:31.621178
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # TODO:
    # - test with namespace
    # - test with filter_spec
    # - test with collectors that raise exceptions
    # - test with collectors that return empty dicts
    # - test with collectors that return non-empty dicts
    # - test with collectors that return non-empty dicts with namespaces
    # - test with collectors that return non-empty dicts with namespaces and filter_spec
    pass

# Generated at 2022-06-16 23:37:42.791076
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes(),
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert len(fact_collector.collectors) == len(collector.collector_classes()) + 1

    # Test with a namespace
    fact_collector = get_

# Generated at 2022-06-16 23:37:52.041793
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(
        all_collector_classes=collector.collector_classes(),
        namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
        filter_spec=['ansible_*'],
        gather_subset=['all'],
        gather_timeout=10,
        minimal_gather_subset=frozenset(['all']))

    assert fact_collector is not None
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.collectors is not None
    assert len(fact_collector.collectors) > 0

# Generated at 2022-06-16 23:37:59.115298
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact': 'test2_value'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3_fact': 'test3_value'}


# Generated at 2022-06-16 23:38:07.706877
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           gather_subset=['all'],
                                           gather_timeout=10)

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(default_collectors) + 1

    # Check that the CollectorMetaDataCollector is last
    assert isinstance(fact_collector.collectors[-1], CollectorMetaDataCollector)

# Generated at 2022-06-16 23:38:16.030227
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    facts = fact_collector.collect()
    assert facts == {'test_fact': 'test_value'}



# Generated at 2022-06-16 23:38:25.227226
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    facts = fact_collector.collect()


# Generated at 2022-06-16 23:38:36.260372
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    # Test with default gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes,
                                           gather_subset=None,
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())

    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert fact_collector.collectors[0].name == 'all'
    assert fact_collector.collectors

# Generated at 2022-06-16 23:39:00.480654
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

    test_collector = TestCollector(namespace=TestNamespace())
    fact_collector = AnsibleFactCollector(collectors=[test_collector])

    facts = fact_collector.collect()
    assert facts == {'test_fact': 'test_value'}

# Generated at 2022-06-16 23:39:10.956506
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network

    all_collector_classes = [ansible_collector.AnsibleCollector,
                             network.NetworkCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset(['all']))

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == 2
    assert isinstance(fact_collector.collectors[0], ansible_collector.AnsibleCollector)

# Generated at 2022-06-16 23:39:19.990463
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'


# Generated at 2022-06-16 23:39:29.824694
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pip


# Generated at 2022-06-16 23:39:30.853401
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-16 23:39:41.926957
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no namespace
    fact_collector = AnsibleFactCollector()
    fact_collector.collectors = [collector.FacterFactCollector(),
                                 collector.OhaiFactCollector()]
    fact_collector.filter_spec = ['*']
    facts = fact_collector.collect()
    assert 'facter' in facts
    assert 'ohai' in facts
    assert 'ansible_facts' not in facts

    # Test with a namespace
    fact_collector = AnsibleFactCollector(namespace=collector.PrefixFactNamespace(prefix='ansible_'))
    fact_collector.collectors = [collector.FacterFactCollector(),
                                 collector.OhaiFactCollector()]
    fact_collector.filter_spec = ['*']
    facts = fact_collector

# Generated at 2022-06-16 23:39:52.433393
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

        def __init__(self):
            super(TestNamespace, self).__init__(prefix='test_')

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()],
                                          namespace=TestNamespace())

    collected_facts = fact_collector.collect()

    assert collected_facts == {'test_test_fact': 'test_value'}

# Generated at 2022-06-16 23:40:04.315239
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace

    fact_collector = \
        get_ansible_collector(all_collector_classes=ansible_collector.FACT_COLLECTORS,
                              namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    facts = fact_collector.collect()
    assert facts['ansible_facts']['ansible_all_ipv4_addresses'] == ['127.0.0.1']
    assert facts['ansible_facts']['ansible_all_ipv6_addresses'] == ['::1']
    assert facts['ansible_facts']['ansible_default_ipv4']['address'] == '127.0.0.1'
   