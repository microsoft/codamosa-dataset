

# Generated at 2022-06-16 23:30:29.685436
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import collector

    all_collector_classes = ansible_collector.get_collector_classes()
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()


# Generated at 2022-06-16 23:30:34.812326
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace

    # Create a fact collector with a namespace
    fact_collector = \
        AnsibleFactCollector(namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    # Create a fact collector with a namespace and a filter
    fact_collector_with_filter = \
        AnsibleFactCollector(namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                             filter_spec='ansible_*')

    # Create a fact collector with a namespace and a filter

# Generated at 2022-06-16 23:30:46.376765
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    # Test with no gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           gather_subset=[],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())
    assert fact_collector.collectors == []

    # Test with gather_subset=['all']

# Generated at 2022-06-16 23:30:57.052278
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact': 'test2_value'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'


# Generated at 2022-06-16 23:31:09.310268
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector(), TestCollector2()])
    facts = fact_collector.collect()
    assert facts == {'test': 'test', 'test2': 'test2'}

    fact_collect

# Generated at 2022-06-16 23:31:18.493635
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import DictCollector
    from ansible.module_utils.facts.collector import FileCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import PlatformCollector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.collector import SystemCollector
    from ansible.module_utils.facts.collector import CommandCollector
    from ansible.module_utils.facts.collector import PipCollector

# Generated at 2022-06-16 23:31:24.196238
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}


# Generated at 2022-06-16 23:31:34.337962
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for method collect of class AnsibleFactCollector'''

    class FakeCollector(collector.BaseFactCollector):
        '''Fake collector for testing'''

        def __init__(self, namespace=None):
            super(FakeCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    fact_collector = \
        AnsibleFactCollector(collectors=[FakeCollector()])

    facts = fact_collector.collect()
    assert facts == {'test_fact': 'test_value'}

# Generated at 2022-06-16 23:31:45.239894
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with a namespace

# Generated at 2022-06-16 23:31:56.102605
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Test with no collectors
    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert facts == {}

    # Test with a single collector
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector()])
    facts = fact_collector.collect()
    assert facts == {}

    # Test with multiple collectors
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector(),
                                                      collector.BaseFactCollector()])
    facts = fact_collector.collect()
    assert facts == {}

    # Test with a single collector that returns facts
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector(facts={'foo': 'bar'})])
    facts = fact_collector

# Generated at 2022-06-16 23:32:12.000559
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

        def get_facts(self, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollectorWithNamespace(collector.BaseFactCollector):
        name = 'test_with_namespace'
        _fact_ids = set(['test_fact'])


# Generated at 2022-06-16 23:32:20.639067
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactResolver

    class MockDistributionFactCollector(DistributionFactCollector):
        def __init__(self, namespace=None):
            super(MockDistributionFactCollector, self).__init__(namespace=namespace)


# Generated at 2022-06-16 23:32:30.476261
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with PrefixFactNamespace
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)


# Generated at 2022-06-16 23:32:41.071283
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test with a single collector
    fact_collector = \
        get_ansible_collector(all_collector_classes=[collector.FacterCollector],
                              gather_subset=['facter'],
                              filter_spec=['ansible_*'])
    assert fact_collector.collectors[0].name == 'facter'
    assert fact_collector.collectors[1].name == 'gather_subset'
    assert fact_collector.filter_spec == ['ansible_*']

    # Test with a namespace

# Generated at 2022-06-16 23:32:50.264256
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_collector_classes = [NetworkCollector, SystemCollector]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])

    assert fact_collector.collectors[0].name == 'network'
    assert fact_collector.collectors[1].name == 'system'
    assert fact_collector.collectors[2].name == 'gather_subset'

    assert fact_collector.collectors[2].gather_subset == ['all']
    assert fact_collector.collectors[2].module_setup is True

   

# Generated at 2022-06-16 23:33:03.696061
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceList

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector.FACT_COLLECTORS)
    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'gather_subset' in facts['ansible_facts']
    assert 'module_setup' in facts['ansible_facts']

    # Test with a namespace

# Generated at 2022-06-16 23:33:12.844100
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'])

    # Test that the collector is a AnsibleFactCollector
    assert isinstance(fact_collector, AnsibleFactCollector)

    # Test that the collector has a namespace
    assert fact_collector.namespace is not None

    # Test that the collector has a filter_spec
    assert fact_collector.filter_spec is not None

    # Test that the collector has collectors
    assert fact_collector.collectors is not None

    # Test that the

# Generated at 2022-06-16 23:33:23.801156
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.collectors[0], collector.BaseFactCollector)
    assert isinstance(fact_collector.collectors[1], CollectorMetaDataCollector)
   

# Generated at 2022-06-16 23:33:37.748181
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout

    # Test with no gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=collector.collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())
    assert fact_collector.collectors[0].name == 'all'

# Generated at 2022-06-16 23:33:48.534549
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    # Test that we get the expected collectors
    collector_classes = [collector.FacterFactCollector,
                         collector.OhaiFactCollector,
                         collector.NetworkFactCollector,
                         collector.PlatformFactCollector,
                         collector.HardwareFactCollector,
                         collector.VirtualFactCollector,
                         collector.CommandFactCollector]

    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())

    assert len

# Generated at 2022-06-16 23:34:17.427990
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes

    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10)

    # Test that the fact_collector has the right collectors
    assert len(fact_collector.collectors) == len(collector_classes) + 1

    # Test that the fact_collector has the right metadata collector
    assert isinstance(fact_collector.collectors[-1], CollectorMetaDataCollector)
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True

# Generated at 2022-06-16 23:34:26.461237
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    # create a list of collectors
    collector_classes = [ansible.module_utils.facts.collector.network.NetworkCollector,
                         ansible.module_utils.facts.collector.platform.PlatformCollector,
                         ansible.module_utils.facts.collector.distribution.DistributionCollector,
                         ansible.module_utils.facts.collector.virtual.VirtualCollector]

    # create a list of collectors
    collectors = []
    for collector_class in collector_classes:
        collector_obj = collector_class()

# Generated at 2022-06-16 23:34:30.782549
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.puppet
    import ansible.module_utils.facts.collector.salt
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.pkg_mgr


# Generated at 2022-06-16 23:34:42.139293
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    all_collector_classes = default_collectors.all_collector_classes()
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)

    fact_collector = get_ansible_collector

# Generated at 2022-06-16 23:34:49.910509
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user

    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.default_ipv4

    import ansible.module_utils.facts.virtual.virtualbox
    import ansible.module_utils.facts.virtual.lxc
    import ansible.module_utils.facts.virtual.kvm
    import ansible.module_utils.facts.virtual.xen
    import ansible.module_utils.facts.virtual.vmware

    import ansible.module_utils.facts.hardware.cpu
    import ansible

# Generated at 2022-06-16 23:35:00.871131
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import collector

    all_collector_classes = [
        ansible_collector.AnsibleCollector,
        network.NetworkCollector,
        system.SystemCollector,
        virtual.VirtualCollector,
        hardware.HardwareCollector,
    ]

    # Test with no gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-16 23:35:09.400691
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import collector

    all_collector_classes = [
        cache.Cache,
        hardware.Hardware,
        network.Network,
        virtual.Virtual,
        system.System,
        distribution.Distribution,
    ]

    # Test with gather_subset=['all']
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'])

# Generated at 2022-06-16 23:35:17.006926
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [
        ansible_collector.AnsibleCollector,
        network.NetworkCollector,
        system.SystemCollector,
        virtual.VirtualCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           filter_spec=['*'],
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))


# Generated at 2022-06-16 23:35:26.720344
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    # Test with default args
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes)
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)
    assert fact_collector.collectors[-1].gather_subset == ['all']

    # Test with gather_subset=['network']
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.collector_classes,
                                           gather_subset=['network'])

# Generated at 2022-06-16 23:35:36.838107
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai


# Generated at 2022-06-16 23:36:00.363036
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector(), TestCollector2()])
    facts = fact_collector.collect()
    assert facts == {'test': 'test', 'test2': 'test2'}



# Generated at 2022-06-16 23:36:11.190348
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors.all_collector_classes()
    fact_collector = get_ansible_collector(all_collector_classes)

    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)

    assert len(fact_collector.collectors) == len(all_collector_classes) + 1

    assert isinstance(fact_collector.collectors[-1],
                      ansible_collector.CollectorMetaDataCollector)

    assert fact_collector.collectors[-1].gather_subset == ['all']



# Generated at 2022-06-16 23:36:23.716639
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_collector_namespace

    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=ansible_collector_namespace.AnsibleCollectorNamespace())

    assert fact_collector.namespace == ansible_collector_namespace.AnsibleCollectorNamespace()
    assert fact_collector.filter_spec == []
    assert len(fact_collector.collectors) == len(ansible_collector.collector_classes) + 1

    # Test that the CollectorMetaDataCollector is the last collector

# Generated at 2022-06-16 23:36:29.419379
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors()

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)

    assert len(fact_collector.collectors) == len(all_collector_classes) + 1

    assert isinstance(fact_collector.collectors[-1],
                      ansible_collector.CollectorMetaDataCollector)

# Generated at 2022-06-16 23:36:40.005203
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network_collector
    from ansible.module_utils.facts import hardware_collector
    from ansible.module_utils.facts import system_collector
    from ansible.module_utils.facts import distribution_collector
    from ansible.module_utils.facts import virtual_collector

    all_collector_classes = [
        ansible_collector.AnsibleCollector,
        network_collector.NetworkCollector,
        hardware_collector.HardwareCollector,
        system_collector.SystemCollector,
        distribution_collector.DistributionCollector,
        virtual_collector.VirtualCollector
    ]

    fact_collector = get

# Generated at 2022-06-16 23:36:52.576452
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pip
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.file_system


# Generated at 2022-06-16 23:37:00.324186
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FacterFactCollector
    from ansible.module_utils.facts.collector import OhaiFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector
    from ansible.module_utils.facts.collector import PipFactCollector
    from ansible.module_utils.facts.collector import VirtualBoxFactCollector
    from ansible.module_utils.facts.collector import VMwareFactCollector
    from ansible.module_utils.facts.collector import SystemProfilerFactCollector

# Generated at 2022-06-16 23:37:09.285173
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=['all'])

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.collectors[0], ansible_collector.NetworkCollector)

# Generated at 2022-06-16 23:37:19.398630
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_collector_classes = [
        ansible_collector.AnsibleCollector,
        network.NetworkCollector,
        system.SystemCollector,
        virtual.VirtualCollector,
    ]

    # Test with no namespace

# Generated at 2022-06-16 23:37:26.434103
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for method collect of class AnsibleFactCollector'''

    class Collector1(collector.BaseFactCollector):
        '''A test collector that returns a dict with a single key'''

        name = 'collector1'
        _fact_ids = set(['collector1_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'collector1_fact': 'collector1_fact_value'}

    class Collector2(collector.BaseFactCollector):
        '''A test collector that returns a dict with a single key'''

        name = 'collector2'
        _fact_ids = set(['collector2_fact'])


# Generated at 2022-06-16 23:38:30.480620
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Test that the function returns a AnsibleFactCollector
    assert isinstance(get_ansible_collector(all_collector_classes=[]), AnsibleFactCollector)


# Generated at 2022-06-16 23:38:40.964878
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}


# Generated at 2022-06-16 23:38:53.895206
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.hardware.HardwareCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]

   

# Generated at 2022-06-16 23:39:03.560908
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]


# Generated at 2022-06-16 23:39:11.126132
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    facts = fact_collector.collect()
    assert facts == {'test_fact': 'test_value'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()],
                                          namespace=PrefixFactNamespace(prefix='ansible_'))
    facts = fact_

# Generated at 2022-06-16 23:39:20.107833
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.collectors.hardware as hardware
    import ansible.module_utils.facts.collectors.network as network
    import ansible.module_utils.facts.collectors.virtual as virtual

    # Create a namespace object
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a list of collectors
    collectors = [hardware.Hardware(namespace=namespace_obj),
                  network.Network(namespace=namespace_obj),
                  virtual.Virtual(namespace=namespace_obj)]

    # Create a filter spec
    filter_spec = ['ansible_*', 'facter*', 'ohai*']

    # Create an AnsibleFactCollector object
    fact_collector = Ans

# Generated at 2022-06-16 23:39:29.895512
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.cache

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
        ansible.module_utils.facts.collector.cache.CacheCollector,
    ]

    fact_

# Generated at 2022-06-16 23:39:39.562726
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FakeCollector(collector.BaseFactCollector):
        name = 'fake'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'fake_fact': 'fake_value'}

    fake_collector = FakeCollector()
    fact_collector = AnsibleFactCollector(collectors=[fake_collector])
    facts = fact_collector.collect()
    assert facts == {'fake_fact': 'fake_value'}


# Generated at 2022-06-16 23:39:46.613651
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]


# Generated at 2022-06-16 23:39:59.102692
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    facts = fact_collector.collect()
