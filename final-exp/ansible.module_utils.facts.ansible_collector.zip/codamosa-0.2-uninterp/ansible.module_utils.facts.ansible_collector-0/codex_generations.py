

# Generated at 2022-06-16 23:30:23.980785
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:32.628028
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import package

    all_collector_classes = [
        ansible_collector.AnsibleCollector,
        network.NetworkCollector,
        system.SystemCollector,
        virtual.VirtualCollector,
        hardware.HardwareCollector,
        distribution.DistributionCollector,
        package.PackageCollector,
    ]


# Generated at 2022-06-16 23:30:35.070874
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:40.986744
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:30:45.036138
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'],
                                                       'module_setup': True}

# Generated at 2022-06-16 23:30:56.723304
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert fact_collector.collectors[-1].name == 'gather_subset'
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           gather_subset=['network'])
    assert fact_collector.collectors[-1].name == 'gather_subset'
    assert fact_collector.collectors[-1].gather_subset == ['network']
    assert fact_collect

# Generated at 2022-06-16 23:31:04.136119
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] is True


# Generated at 2022-06-16 23:31:07.327238
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=True)
    assert fact_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:31:13.000604
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}



# Generated at 2022-06-16 23:31:18.049776
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:31:26.845168
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] == True

# Generated at 2022-06-16 23:31:32.880792
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}



# Generated at 2022-06-16 23:31:42.060971
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.file
    import ansible.module_utils.facts.collector.cmd


# Generated at 2022-06-16 23:31:53.482830
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceDict
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestCollectorWithNamespace(collector.BaseFactCollector):
        name = 'test'


# Generated at 2022-06-16 23:31:56.664843
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'],
                                                       'module_setup': True}


# Generated at 2022-06-16 23:32:00.344985
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}


# Generated at 2022-06-16 23:32:08.257800
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    all_collector_classes = collector.get_collector_classes()
    fact_collector = ansible_collector.get_ansible_collector(all_collector_classes)
    assert fact_collector is not None
    assert isinstance(fact_collector, ansible_collector.AnsibleFactCollector)

# Generated at 2022-06-16 23:32:13.059822
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:32:21.280287
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _

# Generated at 2022-06-16 23:32:26.378546
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-16 23:32:40.622544
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert fact_collector.filter_spec == ['ansible_*']
    assert fact_collector.namespace.prefix == 'ansible_'
    assert len(fact_collector.collectors) == len(default_collectors) + 1
    assert fact_collector.collect

# Generated at 2022-06-16 23:32:49.195051
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}


# Generated at 2022-06-16 23:33:01.987100
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-16 23:33:08.962950
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network_collector
    from ansible.module_utils.facts import hardware_collector

    # Create a namespace
    ansible_namespace = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a collector
    ansible_collector_obj = ansible_collector.AnsibleCollector(namespace=ansible_namespace)

    # Create a collector
    network_collector_obj = network_collector.NetworkCollector(namespace=ansible_namespace)

    # Create a collector
    hardware_collector_obj = hardware_collector.HardwareCollector(namespace=ansible_namespace)

    # Create a list of

# Generated at 2022-06-16 23:33:15.921448
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.puppet
    import ansible.module_utils.facts.collector.salt
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.pkg_mgr

# Generated at 2022-06-16 23:33:25.263869
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_collector_classes = collector_registry.get_collector_classes()
    namespace = PrefixFactNamespace(prefix='ansible_')
    filter_spec = ['ansible_*']
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()


# Generated at 2022-06-16 23:33:38.728902
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution

    # Test with no namespace
    fact_collector = AnsibleFactCollector(collectors=[
        ansible.module_utils.facts.collector.network.NetworkCollector(),
        ansible.module_utils.facts.collector.platform.PlatformCollector(),
        ansible.module_utils.facts.collector.distribution.DistributionCollector()
    ])

    facts = fact_collector.collect()
    assert 'ansible_all_ipv4_addresses' in facts
    assert 'ansible_all_ipv6_addresses' in facts
    assert 'ansible_architecture' in facts

# Generated at 2022-06-16 23:33:49.301026
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_collector_registry
    from ansible.module_utils.facts import ansible_minimal_gather_subset
    from ansible.module_utils.facts import ansible_gather_subset
    from ansible.module_utils.facts import ansible_gather_timeout

    # Test that we can get an AnsibleFactCollector

# Generated at 2022-06-16 23:34:01.106348
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['a', 'b'])

        def collect(self, module=None, collected_facts=None):
            return {'a': 'A', 'b': 'B'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

        def __init__(self, prefix=None):
            super(TestNamespace, self).__init__(prefix=prefix)

        def facts(self, collected_facts=None):
            return {'c': 'C'}

    test_collector = TestCollector()
    test_namespace = TestNamespace()


# Generated at 2022-06-16 23:34:12.818335
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts import namespace

    # Test with all collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_registry.all_collector_classes)
    assert fact_collector.collectors
    assert fact_collector.collectors[-1].gather_subset == ['all']

    # Test with subset of collectors
    fact_collector = get_ansible_collector(all_collector_classes=collector_registry.all_collector_classes,
                                           gather_subset=['network'])
    assert fact_collector.collectors
    assert fact_collector.collectors[-1].gather_subset == ['network']

    # Test with namespace


# Generated at 2022-06-16 23:34:24.386145
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict

    namespace = PrefixFactNamespace(prefix='ansible_')
    filter_spec = ['ansible_*']
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()


# Generated at 2022-06-16 23:34:32.803804
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import default_collector_classes

    fact_collector = get_ansible_collector(all_collector_classes=default_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10)

    facts = fact_collector.collect(module=None)

    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] is True
    assert facts['ansible_facts'] == default_collectors.collect(module=None)

# Generated at 2022-06-16 23:34:44.150999
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system

    # Create a namespace
    namespace_obj = namespace.BaseFactNamespace(name='test')

    # Create a collector
    collector_obj = ansible_collector.AnsibleFactCollector(namespace=namespace_obj)

    # Create a network collector
    network_collector_obj = network.NetworkCollector(namespace=namespace_obj)

    # Create a system collector
    system_collector_obj = system.SystemCollector(namespace=namespace_obj)

    # Create a fact collector

# Generated at 2022-06-16 23:34:51.280892
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert fact_collector.collectors[-1].name == 'gather_subset'
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup == True


# Generated at 2022-06-16 23:35:02.191929
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network_collector
    from ansible.module_utils.facts import hardware_collector

    # Create a collector that collects facts from ansible_collector, network_collector and hardware_collector
    collectors = [ansible_collector.FactsCollector(),
                  network_collector.NetworkCollector(),
                  hardware_collector.HardwareCollector()]

    # Create a namespace that prefixes all facts with 'ansible_'
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a fact collector that collects facts from collectors and namespaces them

# Generated at 2022-06-16 23:35:10.231590
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import default_collector

    # Test with no namespace
    fact_collector = ansible_collector.AnsibleFactCollector(
        collectors=[default_collector.DefaultCollector()])
    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'ansible_all_ipv4_addresses' in facts['ansible_facts']

    # Test with namespace
    fact_collector = ansible_collector.AnsibleFactCollector(
        collectors=[default_collector.DefaultCollector()],
        namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collect

# Generated at 2022-06-16 23:35:19.982571
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_registry
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceList

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=collector_registry.collector_classes)
    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'gather_subset' in facts['ansible_facts']
    assert 'module_setup' in facts['ansible_facts']

    # Test with a namespace

# Generated at 2022-06-16 23:35:31.008062
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes

    # Test with no gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes)
    assert fact_collector.collectors[-1].gather_subset == ['all']

    # Test with gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           gather_subset=['network'])
    assert fact_collector.collectors[-1].gather_subset == ['network']

    # Test with minimal_gather_subset

# Generated at 2022-06-16 23:35:41.157733
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact3': 'test_value3'}

# Generated at 2022-06-16 23:35:48.308598
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes)

    facts = fact_collector.collect()


# Generated at 2022-06-16 23:36:06.405016
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes)
    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'ansible_network_resources' in facts['ansible_facts']
    assert 'ansible_all_ipv4_addresses'

# Generated at 2022-06-16 23:36:17.138515
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    assert fact_collector.namespace.prefix == 'ansible_'
    assert fact_collector.filter_spec == ['ansible_*']

    assert len(fact_collector.collectors) == len(all_collector_classes) + 1


# Generated at 2022-06-16 23:36:26.444496
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceList

    # Test with a namespace
    namespace = PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=namespace)
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert isinstance(facts['ansible_facts'], dict)

    # Test with a namespace that returns a list
    namespace = PrefixFactNamespaceList(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=namespace)
    facts = fact_collector.collect()

# Generated at 2022-06-16 23:36:38.322778
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_fact_value2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact3': 'test_fact_value3'}


# Generated at 2022-06-16 23:36:50.353168
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector(), TestCollector2()])
    facts = fact_collector.collect()
    assert facts == {'test': 'test', 'test2': 'test2'}



# Generated at 2022-06-16 23:37:00.184269
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import BSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SolarisDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DarwinDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import WindowsDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import NetworkDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import AIX

# Generated at 2022-06-16 23:37:09.446149
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network_collector
    from ansible.module_utils.facts import hardware_collector
    from ansible.module_utils.facts import virtual_collector
    from ansible.module_utils.facts import default_collector

    # Create a namespace
    prefix_namespace = namespace.PrefixFactNamespace(prefix='ansible_')

    # Create a collector

# Generated at 2022-06-16 23:37:16.345931
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai

    # Create a list of all the collectors

# Generated at 2022-06-16 23:37:25.427621
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test case 1:
    #   - collector_1 returns {'a': 1, 'b': 2}
    #   - collector_2 returns {'c': 3, 'd': 4}
    #   - filter_spec is ['a', 'c']
    #   - expected result is {'a': 1, 'c': 3}

    class Collector1(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'a': 1, 'b': 2}

    class Collector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'c': 3, 'd': 4}

    collector_1 = Collector1()
    collector_2 = Collector2()
    fact_collector = AnsibleFactCollect

# Generated at 2022-06-16 23:37:35.528192
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import collector

    all_collector_classes = [
        default.Default,
        hardware.Hardware,
        network.Network,
        virtual.Virtual,
        system.System,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=['all'])


# Generated at 2022-06-16 23:38:01.106413
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}


# Generated at 2022-06-16 23:38:06.935358
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

# Generated at 2022-06-16 23:38:15.376423
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}

    class TestCollector4(collector.BaseFactCollector):
        name = 'test4'


# Generated at 2022-06-16 23:38:22.466736
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import cache

    # Create a mock collector that returns a fact
    class MockCollector(collector.BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': 'mock_value'}

    # Create a mock cache that returns a fact
    class MockCache(cache.BaseFactCache):
        name = 'mock'

        def get(self, module=None, collected_facts=None):
            return {'mock_fact': 'mock_value'}

    # Create a mock namespace that returns a fact


# Generated at 2022-06-16 23:38:33.029184
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    all_collector_classes = [TestCollector, TestCollector2]
    namespace = PrefixFactNamespace(prefix='ansible_')
    filter_spec = ['test']
    gather_subset = ['all']
    gather_timeout = timeout.DE

# Generated at 2022-06-16 23:38:42.952149
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    all_collector_classes = default_collectors.get_collector_classes()

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.namespace is None

    # Test with namespace
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-16 23:38:55.346089
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class MockCollector(collector.BaseFactCollector):
        name = 'mock'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'mock': 'mock'}

    mock_collector = MockCollector()
    fact_collector = AnsibleFactCollector(collectors=[mock_collector])
    facts = fact_collector.collect()
    assert facts == {'mock': 'mock'}

    fact_collector = AnsibleFactCollector(collectors=[mock_collector],
                                          namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collector.collect()

# Generated at 2022-06-16 23:39:04.449331
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    network_collector = NetworkCollector(namespace=PrefixFactNamespace(prefix='network_'))
    platform_collector = PlatformCollector(namespace=PrefixFactNamespace(prefix='platform_'))
    system_collector = SystemCollector(namespace=PrefixFactNamespace(prefix='system_'))

    fact_collector = AnsibleFactCollector(collectors=[network_collector, platform_collector, system_collector])

    facts = fact_collector.collect()

# Generated at 2022-06-16 23:39:15.656156
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # test with no collectors
    fact_collector = AnsibleFactCollector()
    assert fact_collector.collect() == {}

    # test with one collector
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector()])
    assert fact_collector.collect() == {}

    # test with two collectors
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector(),
                                                      collector.BaseFactCollector()])
    assert fact_collector.collect() == {}

    # test with two collectors, one of which returns a fact
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector(),
                                                      collector.BaseFactCollector(facts={'foo': 'bar'})])
    assert fact_collector.collect()

# Generated at 2022-06-16 23:39:23.535438
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.hardware.HardwareCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]

   

# Generated at 2022-06-16 23:39:59.103114
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.cmdline
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pip
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.file
    import ansible.module_utils.facts.collect

# Generated at 2022-06-16 23:40:10.153625
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv4Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv6Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceMACCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMTUCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceNetmaskCollector
   