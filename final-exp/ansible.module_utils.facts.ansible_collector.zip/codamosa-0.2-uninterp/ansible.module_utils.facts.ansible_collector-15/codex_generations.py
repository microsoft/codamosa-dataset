

# Generated at 2022-06-16 23:30:24.708684
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import cache

    # Create a fact collector that collects facts from the default fact collectors
    fact_collector = get_ansible_collector(all_collector_classes=default.collector_classes)

    # Create a fact cache
    fact_cache = cache.FactCache()

    # Collect facts
    facts_dict = fact_collector.collect(module=None, collected_facts=fact_cache.facts)

    # Assert that the facts are collected under the 'ansible_facts' key
    assert 'ansible_facts' in facts_dict

    # Assert that the facts are collected under the 'ansible_facts' key
    assert 'ansible_facts' in facts_dict

    #

# Generated at 2022-06-16 23:30:33.265753
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a mock module
    class MockModule:
        def __init__(self):
            self.params = {}

    # Create a mock collector
    class MockCollector:
        def __init__(self, namespace=None):
            self.namespace = namespace

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    # Create a mock namespace
    class MockNamespace:
        def __init__(self, prefix=None):
            self.prefix = prefix

        def get_prefix(self):
            return self.prefix

    # Create a mock fact collector
    mock_collector = MockCollector(namespace=MockNamespace(prefix='ansible_'))

# Generated at 2022-06-16 23:30:38.329006
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.virtual


# Generated at 2022-06-16 23:30:47.424565
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceDictCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv4Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv6Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceMACCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMTUCollector
   

# Generated at 2022-06-16 23:30:57.883953
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network

    # Test with no namespace
    fact_collector = ansible_collector.AnsibleFactCollector()
    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'ansible_all_ipv4_addresses' in facts['ansible_facts']

    # Test with a namespace
    fact_collector = ansible_collector.AnsibleFactCollector(namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collector.collect()
    assert 'ansible_facts' in facts
    assert 'ansible_all_ipv4_addresses'

# Generated at 2022-06-16 23:31:09.749538
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = \
        ansible.module_utils.facts.collector.network.collector_classes + \
        ansible.module_utils.facts.collector.platform.collector_classes + \
        ansible.module_utils.facts.collector.distribution.collector_classes + \
        ansible.module_utils.facts.collector.virtual.collector_classes


# Generated at 2022-06-16 23:31:19.694082
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    # Test that we can get the ansible_collector with the default args
    fact_collector = get_ansible_collector(collector.FACT_COLLECTOR_CLASSES)
    assert isinstance(fact_collector, AnsibleFactCollector)

    # Test that we can get the ansible_collector with a namespace
    fact_collector = get_ansible_collector(collector.FACT_COLLECTOR_CLASSES,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, AnsibleFactCollector)

    # Test that we can get the ansible_collector with a filter_spec
    fact_collector = get

# Generated at 2022-06-16 23:31:32.287257
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    # Test that we can get a collector with the default gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())

    # Test that we can get a collector with a custom gather_subset

# Generated at 2022-06-16 23:31:41.998590
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.file_system
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.cmd_line
    import ansible.module_utils.facts.collector.local


# Generated at 2022-06-16 23:31:53.380525
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           filter_spec=['ansible_eth*', 'ansible_default_ipv4'])

    facts = fact_collector.collect()


# Generated at 2022-06-16 23:32:07.872788
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual

    # Create a namespace
    fact_namespace = namespace.BaseFactNamespace(name='test_namespace')

    # Create a collector
    fact_collector = collector.BaseFactCollector(namespace=fact_namespace)

    # Create a fact
    fact_obj = default.DefaultFactCollector(namespace=fact_namespace)

    # Create a fact collector
    fact_collector = AnsibleFactCollector(collectors=[fact_collector, fact_obj])

    # Collect facts
    facts

# Generated at 2022-06-16 23:32:18.828883
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [
        cache.Cache,
        network.Network,
        system.System,
        virtual.Virtual,
    ]

    fact_collector = get_ansible_collector(all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=1)

    collected_facts = fact_collector.collect()

    assert 'ansible_facts' in collected_facts
    assert 'gather_subset' in collected_facts['ansible_facts']
    assert 'module_setup' in collected_facts['ansible_facts']
   

# Generated at 2022-06-16 23:32:30.362350
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a mock class for testing
    class MockCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    # Create a mock class for testing
    class MockCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    # Create a mock class for testing
    class MockCollector3(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact3': 'test_value3'}

    # Create a mock class for testing

# Generated at 2022-06-16 23:32:40.503156
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

# Generated at 2022-06-16 23:32:49.163480
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector

# Generated at 2022-06-16 23:33:01.987122
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv4Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv6Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceMACCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMTUCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceNetmaskCollector
   

# Generated at 2022-06-16 23:33:08.964031
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no collectors
    fact_collector = AnsibleFactCollector()
    assert fact_collector.collect() == {}

    # Test with one collector
    class FakeCollector(object):
        def collect(self):
            return {'a': 1}

    fact_collector = AnsibleFactCollector(collectors=[FakeCollector()])
    assert fact_collector.collect() == {'a': 1}

    # Test with two collectors
    class FakeCollector2(object):
        def collect(self):
            return {'b': 2}

    fact_collector = AnsibleFactCollector(collectors=[FakeCollector(), FakeCollector2()])
    assert fact_collector.collect() == {'a': 1, 'b': 2}

    # Test with two collectors, one of which returns None

# Generated at 2022-06-16 23:33:20.694871
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.fips
    import ansible.module_utils.facts.system.capabilities
    import ansible.module_utils.facts.system.selinux


# Generated at 2022-06-16 23:33:24.185697
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

        def execute(self, fact_name, fact_data):
            return 'test'

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()],
                                          namespace=TestNamespace())
    facts = fact_collector.collect()
    assert facts['test'] == 'test'

# Generated at 2022-06-16 23:33:37.807208
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_collector_classes = [NetworkCollector, PlatformCollector, SystemCollector]

    # Test with no namespace
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.collectors[0], NetworkCollector)

# Generated at 2022-06-16 23:33:57.496904
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import DictFactCollector
    from ansible.module_utils.facts.collector import FileGlobFactCollector
    from ansible.module_utils.facts.collector import FileSearchFactCollector
    from ansible.module_utils.facts.collector import PathSearchFactCollector
    from ansible.module_utils.facts.collector import ShellCommandFactCollector
    from ansible.module_utils.facts.collector import ShellScriptFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'


# Generated at 2022-06-16 23:34:01.840192
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import cache_manager
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [
        cache.CacheFactCollector,
        cache_manager.CacheManagerFactCollector,
        network.NetworkFactCollector,
        system.SystemFactCollector,
        virtual.VirtualFactCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['all'],
                                           gather_timeout=10)


# Generated at 2022-06-16 23:34:06.688953
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test_fact3'])


# Generated at 2022-06-16 23:34:19.236710
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no namespace
    fact_collector = AnsibleFactCollector(collectors=[], namespace=None)
    facts = fact_collector.collect()
    assert facts == {}

    # Test with namespace
    fact_collector = AnsibleFactCollector(collectors=[], namespace='test')
    facts = fact_collector.collect()
    assert facts == {'test': {}}

    # Test with namespace and filter_spec
    fact_collector = AnsibleFactCollector(collectors=[], namespace='test', filter_spec=['*'])
    facts = fact_collector.collect()
    assert facts == {'test': {}}

    # Test with namespace and filter_spec
    fact_collector = AnsibleFactCollector(collectors=[], namespace='test', filter_spec=['test_*'])

# Generated at 2022-06-16 23:34:31.864988
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import ansible_network
    from ansible.module_utils.facts import ansible_virtual
    from ansible.module_utils.facts import ansible_distribution
    from ansible.module_utils.facts import ansible_pkg_mgr
    from ansible.module_utils.facts import ansible_service_mgr
    from ansible.module_utils.facts import ansible_user
    from ansible.module_utils.facts import ansible_date_time
    from ansible.module_utils.facts import ansible_system
    from ansible.module_utils.facts import ansible_selinux

# Generated at 2022-06-16 23:34:43.330687
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector
    ]

    fact_collector = get_ansible_collector(all_collector_classes)
    facts = fact_collector.collect()
    assert facts['ansible_facts']['ansible_all_ipv4_addresses'] == ['192.168.1.1']

# Generated at 2022-06-16 23:34:55.423371
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    facts = fact_collector.collect()

# Generated at 2022-06-16 23:35:06.298169
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv4Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv6Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceMACCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMTUCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceNetmaskCollector
   

# Generated at 2022-06-16 23:35:12.102885
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    class Collector1(collector.BaseFactCollector):
        name = 'collector1'

        def collect(self, module=None, collected_facts=None):
            return {'a': 1, 'b': 2}

    class Collector2(collector.BaseFactCollector):
        name = 'collector2'

        def collect(self, module=None, collected_facts=None):
            return {'c': 3, 'd': 4}

    class Collector3(collector.BaseFactCollector):
        name = 'collector3'

        def collect(self, module=None, collected_facts=None):
            return {'e': 5, 'f': 6}

    class Collector4(collector.BaseFactCollector):
        name = 'collector4'

       

# Generated at 2022-06-16 23:35:20.274611
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors.get_collector_classes()

    # Test with default args
    fact_collector = get_ansible_collector(all_collector_classes)
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True

    # Test with gather_subset=['!all']

# Generated at 2022-06-16 23:35:42.178900
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import default_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = get_ansible_collector(all_collector_classes=default_collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                           minimal_gather_subset=frozenset())


# Generated at 2022-06-16 23:35:54.482831
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.virtual


# Generated at 2022-06-16 23:36:06.435967
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import cache

    # Test with default parameters
    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.namespace, namespace.PrefixFactNamespace)
    assert fact_collector.namespace.prefix == 'ansible_'
    assert fact_collector.filter_spec == []
    assert fact_collector.collectors[-1].gather_subset == ['all']
    assert fact_collector.collectors[-1].module_setup is True

    # Test with custom namespace
    fact_collect

# Generated at 2022-06-16 23:36:12.846242
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestNamespace(namespace.BaseFactNamespace):
        name = 'test'

    test_collector = TestCollector(namespace=TestNamespace())
    ansible_fact_collector = AnsibleFactCollector(collectors=[test_collector])

    assert ansible_fact_collector.collect() == {'test_fact': 'test_value'}

# Generated at 2022-06-16 23:36:24.260685
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.distribution.DistributionCollector,
        ansible.module_utils.facts.collector.virtual.VirtualCollector
    ]

    fact_collector = get_ansible_collector(all_collector_classes)
    facts = fact_collector.collect()


# Generated at 2022-06-16 23:36:33.740793
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()])
    facts = fact_collector.collect()
    assert facts == {'test_fact': 'test_value'}

    fact_collector = AnsibleFactCollector(collectors=[TestCollector()],
                                          namespace=PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collector.collect()

# Generated at 2022-06-16 23:36:41.344430
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace

    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=['ansible_*'],
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())
    assert fact_collector.collectors[0].name == 'all'
    assert fact_collector.collectors[1].name == 'gather_subset'
    assert fact_collector.collectors[1].gather_subset == ['all']
    assert fact_collector

# Generated at 2022-06-16 23:36:53.611576
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test case 1:
    #   - collectors = [{'ansible_os_family': 'RedHat'}, {'ansible_distribution': 'CentOS'}]
    #   - filter_spec = ['ansible_os_family', 'ansible_distribution']
    #   - expected_result = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}
    collectors = [{'ansible_os_family': 'RedHat'}, {'ansible_distribution': 'CentOS'}]
    filter_spec = ['ansible_os_family', 'ansible_distribution']
    expected_result = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}

# Generated at 2022-06-16 23:37:02.243331
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector

    # Create a dummy fact collector
    class DummyFactCollector(collector.BaseFactCollector):
        name = 'dummy'

        def collect(self, module=None, collected_facts=None):
            return {'dummy_fact': 'dummy_value'}

    # Create a dummy fact namespace
    class DummyFactNamespace(namespace.BaseFactNamespace):
        name = 'dummy'

        def __init__(self):
            super(DummyFactNamespace, self).__init__()

        def execute(self, fact_name, fact_data):
            return 'dummy_' + fact_data

    # Create a dummy fact namespace

# Generated at 2022-06-16 23:37:12.518625
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    fact_collector = \
        AnsibleFactCollector(collectors=[TestCollector(), TestCollector2()])
    facts = fact_collector.collect()

# Generated at 2022-06-16 23:37:44.241344
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test with no namespace
    fact_collector = AnsibleFactCollector()
    fact_collector.collectors = [collector.BaseFactCollector()]
    fact_collector.collectors[0].collect = lambda: {'a': 1, 'b': 2, 'c': 3}
    assert fact_collector.collect() == {'a': 1, 'b': 2, 'c': 3}

    # Test with namespace
    fact_collector = AnsibleFactCollector(namespace=collector.PrefixFactNamespace(prefix='ansible_'))
    fact_collector.collectors = [collector.BaseFactCollector()]
    fact_collector.collectors[0].collect = lambda: {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 23:37:55.660185
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}

    # Create a mock collector
    class MockCollector(collector.BaseFactCollector):
        def __init__(self, namespace=None):
            super(MockCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    # Create a mock namespace
    class MockNamespace(object):
        def __init__(self, prefix):
            self.prefix = prefix

        def apply(self, fact_dict):
            return {self.prefix + k: v for k, v in fact_dict.items()}

    # Create a mock fact collector
    fact_collect

# Generated at 2022-06-16 23:38:06.546108
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactMetaDataNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'


# Generated at 2022-06-16 23:38:14.969400
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import PlatformCollector
    from ansible.module_utils.facts.collector import VirtualCollector

    class TestCollector(Collector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(Collector):
        name = 'test2'
        _fact_ids = set

# Generated at 2022-06-16 23:38:22.162580
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}


# Generated at 2022-06-16 23:38:29.065664
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactNamespace

    namespace = PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=namespace)

    fact_collector.collectors = [DistributionFactCollector(namespace=DistributionFactNamespace())]

    facts = fact_collector.collect()

    assert 'ansible_distribution' in facts
    assert 'ansible_distribution_version' in facts
    assert 'ansible_distribution_major_version' in facts
    assert 'ansible_distribution_release' in facts

# Generated at 2022-06-16 23:38:40.265434
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = \
        collector.get_collector_classes(collector_classes=[ansible_collector.AnsibleCollector,
                                                           network.NetworkCollector,
                                                           system.SystemCollector,
                                                           virtual.VirtualCollector])


# Generated at 2022-06-16 23:38:53.250646
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import PlatformCollector
    from ansible.module_utils.facts.collector import DistributionCollector
    from ansible.module_utils.facts.collector import VirtualCollector

    class MockCollector(BaseFactCollector):
        name = 'mock'

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': 'mock_value'}

# Generated at 2022-06-16 23:39:03.075693
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.facter
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.pkg_mgr


# Generated at 2022-06-16 23:39:13.539512
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    all_collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.platform.PlatformCollector,
        ansible.module_utils.facts.collector.system.SystemCollector,
    ]

    fact_collector = get_ansible_collector(all_collector_classes)
    facts = fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'gather_subset' in facts['ansible_facts']
    assert 'module_setup' in facts['ansible_facts']

