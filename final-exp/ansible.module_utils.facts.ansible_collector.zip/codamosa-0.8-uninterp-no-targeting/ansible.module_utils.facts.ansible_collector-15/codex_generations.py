

# Generated at 2022-06-20 16:46:40.187899
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    class FakeCollector(object):
        '''a fake collector'''
        name = 'fake'

    # CollectorMetaDataCollector takes keep_timestamp, gather_subset and module_setup as optional
    collector_meta_data_collector = CollectorMetaDataCollector(CollectorMetaDataCollector.name,
                                                               [FakeCollector()],
                                                               'fake', False, True)
    collected_facts = collector_meta_data_collector.collect()

    assert len(collected_facts) > 0, "Expected to get a non-empty dict for collect"
    assert "gather_subset" in collected_facts, "Expected to get the gather_subset in the results"
    assert "module_setup" in collected_facts, "Expected to get the module_setup in the results"
    assert collector

# Generated at 2022-06-20 16:46:44.122508
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector(gather_subset='only_me',
                                      module_setup=True)

# Generated at 2022-06-20 16:46:54.754110
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    # test defaults
    #
    #   gather_subset is 'all', which is the default
    #   filter_spec is '', which is the default
    #
    fc = get_ansible_collector(all_collector_classes=default_collectors.all)
    output = fc.collect()
    assert 'ansible_distribution' in output
    assert 'gather_subset' in output
    assert all(x in output['gather_subset'] for x in ['all', 'network', 'ohai', 'facter'])
    assert output['gather_subset']['module_setup'] is True

    # verify we have some collectors
    assert len(fc.collectors) > 0

    # test with subset
    #
   

# Generated at 2022-06-20 16:47:03.991902
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    gather_subset = {'gather_subset': ['a', 'b']}
    module_setup = {'module_setup': True}

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=module_setup)

    result = collector_meta_data_collector.collect(module=None,
                                                   collected_facts=None)

    assert result['gather_subset'] == gather_subset
    assert result['module_setup'] == module_setup

# Generated at 2022-06-20 16:47:09.428664
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    expected = {'gather_subset': '!all', 'module_setup': True}
    fact_collector = CollectorMetaDataCollector(gather_subset='!all', module_setup=True)
    assert expected == fact_collector.collect()

# Generated at 2022-06-20 16:47:19.423031
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # given
    class FakeCollector():
        def collect_with_namespace(self, module, collected_facts):
            return {
                'dummy_key': 'dummy_value',
            }

    class FakeNamespace():
        def get_name(self):
            return 'dummy_namespace'

        def wrap(self, fact_dict):
            return fact_dict

    dummy_module = object
    fake_collector = FakeCollector()
    collector_list = [fake_collector]
    filter_spec = []
    namespace = FakeNamespace()

    expected_facts = {
        'dummy_namespace': {
            'dummy_key': 'dummy_value',
        }
    }

    # when

# Generated at 2022-06-20 16:47:23.761543
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import collector

    collector = CollectorMetaDataCollector(gather_subset=['all'],
                                           module_setup=True)
    fact = collector.collect(module=None)
    assert fact == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-20 16:47:30.086642
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # no collector
    a = AnsibleFactCollector()
    assert not a.collectors

    # collector provided
    b = AnsibleFactCollector(collectors=[object()])
    assert len(b.collectors) == 1

# Generated at 2022-06-20 16:47:41.023736
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Mock a class of a collector we can instantiate
    class MockCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'mock_collector': True}

    # get_ansible_collector() with minimal parms returns an AnsibleFactCollector,
    # with no collectors
    fact_collector = get_ansible_collector([MockCollector])
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == 0
    assert fact_collector.collect() == {}

    # Give gather_subset=[] to get_ansible_collector() returns an AnsibleFactCollector,
    # with no collectors

# Generated at 2022-06-20 16:47:49.728996
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """Unit tests for collect method of class AnsibleFactCollector.

    """
    class Collector1(object):
        def __init__(self, namespace=None):
            self.namespace = namespace

        def collect_with_namespace(self, collected_facts=None, module=None):
            return {'facts1': 'facts1'}

    class Collector2(object):
        def __init__(self, namespace=None):
            self.namespace = namespace

        def collect_with_namespace(self, collected_facts=None, module=None):
            return {'facts2': 'facts2'}

    test_collector = AnsibleFactCollector(collectors=[Collector1(), Collector2()])
    test_collector.collect()

# Generated at 2022-06-20 16:48:00.153768
# Unit test for constructor of class AnsibleFactCollector

# Generated at 2022-06-20 16:48:11.252207
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collectors import network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.local import LocalNetworkCollector
    from ansible.module_utils.facts.network.hpilo import HPILONetworkCollector
    from ansible.module_utils.facts.network.nxapi import NXAPINetworkCollector
    from ansible.module_utils.facts.network.ios import IOSNetworkCollector
    from ansible.module_utils.facts.network.iosxr import IOSXRNetworkCollector

    # Gather subset of all is the default
    fact_collector = get_ansible_collector(all_collector_classes=[network.NetworkCollector])
    assert fact_collector.filter_spec

# Generated at 2022-06-20 16:48:18.701591
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Testing collect method of class AnsibleFactCollector'''
    from ansible.module_utils.facts import collector

    class CollectMock(collector.BaseFactCollector):
        '''Mock for testing class AnsibleFactCollector'''

        name = 'mock_collector'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            '''Mock collect method'''
            return {'value': 'test'}

    fact_collector = AnsibleFactCollector(collectors=CollectMock())
    fact_dict = fact_collector.collect()
    assert fact_dict == {'value': 'test'}


# Generated at 2022-06-20 16:48:30.032377
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import network

    gs = '!all,!min'

    # There is no params here, but we want them, so pass in None
    all_collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=None,
            minimal_gather_subset=None,
            gather_subset=[gs],
            gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT)

    fact_collector = AnsibleFactCollector(collectors=all_collector_classes)

    facts = fact_

# Generated at 2022-06-20 16:48:36.782289
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True


# Generated at 2022-06-20 16:48:48.438262
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = ['ohai', 'facter', 'default']
    namespace = 'ansible'

# Generated at 2022-06-20 16:48:49.990093
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    tmp = AnsibleFactCollector()
    print(tmp.__class__.__name__)
    assert tmp.__class__.__name__ is "AnsibleFactCollector"


# Generated at 2022-06-20 16:48:57.864826
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # arrange
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['!all', 'min'],
                                                               module_setup=False)
    # act
    meta_facts = collector_meta_data_collector.collect()

    # assert
    assert meta_facts['gather_subset'] == ['!all', 'min']
    assert 'module_setup' in meta_facts
    assert meta_facts['module_setup'] == False


# Generated at 2022-06-20 16:49:09.698451
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import types
    fact_collector = get_ansible_collector(['ansible.module_utils.facts.system.distribution',
                                            'ansible.module_utils.facts.system.network',
                                            'ansible.module_utils.facts.system.platform',
                                            'ansible.module_utils.facts.system.pkg_mgr'],
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=['all'],
                                           gather_timeout=None,
                                           minimal_gather_subset=set())
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == 5
    assert type(fact_collector.collectors[0]) == types.ModuleType


# Generated at 2022-06-20 16:49:17.217715
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    #import ansible.module_utils.facts.collector.network_resources

    from ansible.module_utils.facts.collector.network_resources import NetworkResourcesFactCollector

    #ns = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')

    ansible_collector = AnsibleFactCollector(collectors=None)

    nw_collector = NetworkResourcesFactCollector()

    ansible_collector = AnsibleFactCollector(collectors=[nw_collector])

    #ansible_collector = AnsibleFactCollector(collectors=[nw_collector], namespace=ns)

    #ansible_collector.collect()



# Generated at 2022-06-20 16:49:34.226740
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.network.systemprofiler
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.version

    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.network
    import ansible.module_utils.facts.network.neighbors

    # set up
    # call function to test

# Generated at 2022-06-20 16:49:39.848921
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    collector_obj = get_ansible_collector(default_collectors)
    assert isinstance(collector_obj, AnsibleFactCollector)
    assert len(collector_obj.collectors) > 0
    for c in collector_obj.collectors:
        assert isinstance(c, collector.BaseFactCollector)



# Generated at 2022-06-20 16:49:53.012595
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import systemd
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import hardware

    # Need to use namespace to test module as it requires it.
    ansible_namespace = PrefixFactNamespace(prefix='ansible_')
    ansible_fact_collector = AnsibleFactCollector(namespace=ansible_namespace)
    ansible_fact_collector.add_collector(collector=systemd.SystemdFactCollector())
    ansible_fact_collector.add_collector(collector=system.PySystemInformation())
    ansible

# Generated at 2022-06-20 16:50:02.941027
# Unit test for function get_ansible_collector

# Generated at 2022-06-20 16:50:10.398216
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset={'network', 'hardware'},
                                                               module_setup=False)

    collected_facts = collector_meta_data_collector.collect()
    assert collected_facts == {'gather_subset': {'network', 'hardware'},
                               'module_setup': False}


# Generated at 2022-06-20 16:50:18.392359
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import gather_subset
    from ansible.module_utils.facts import gather_timeout
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.plugins.software.linux import LinuxSoftwareCollector

    test_collector = AnsibleFactCollector(filter_spec='foo')

    assert isinstance(test_collector, collector.BaseFactCollector)
    assert callable(test_collector._filter)

    test_collector = AnsibleFactCollector(filter_spec=')(*&%^&*')

    assert isinstance(test_collector, collector.BaseFactCollector)
    assert callable(test_collector._filter)


# Generated at 2022-06-20 16:50:30.983965
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Mock Collectors
    collector1 = collector.BaseFactCollector()
    collector2 = collector.BaseFactCollector()

    collected_facts = {}

    # Mock results from collectors
    info_dict1 = {'a': 1, 'b': 2}
    info_dict2 = {'c': 3, 'd': 4}

    # Set side_effect for collector1.collect_with_namespace()
    # which is called by fact_collector.collect()
    collector1.collect_with_namespace = lambda module, collected_facts: info_dict1
    # Set side_effect for collector2.collect_with_namespace()
    # which is called by fact_collector.collect()
    collector2.collect_with_namespace = lambda module, collected_facts: info_dict2

    # Create fact_collector and call

# Generated at 2022-06-20 16:50:36.698629
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(gather_subset=['a', 'b', 'c'], module_setup=True)
    assert c.name == 'gather_subset'
    assert c._fact_ids == set(['gather_subset', 'module_setup'])
    assert c.gather_subset == ['a', 'b', 'c']
    assert c.module_setup is True
    facts = c.collect()
    assert facts['gather_subset'] == ['a', 'b', 'c']
    assert facts['module_setup'] is True

# Generated at 2022-06-20 16:50:45.374691
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ''' Unit test for function get_ansible_collector '''

    import ansible.module_utils.facts.collector.base
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.namespace

    # Recreate the default set of facts
    all_fact_collectors = ansible.module_utils.facts.collector.base.get_collectors_for_type(
        'ansible',
        ansible.module_utils.facts.namespace.PrefixFactNamespace)
    # Add the network facts
    all_fact_collectors.update(
        ansible.module_utils.facts.collector.network.get_network_collectors(
            ansible.module_utils.facts.namespace.PrefixFactNamespace))

    fact_collector_obj

# Generated at 2022-06-20 16:50:45.911238
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector()


# Generated at 2022-06-20 16:51:01.936393
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.collectors

    # Note: add_gather_subset() only adds collector classes that have the same gather_subset
    # value.  This is why we add it multiple times below.
    all_collector_classes = set()
    ansible.module_utils.facts.collectors.add_gather_subset(all_collector_classes, 'test_collector')
    ansible.module_utils.facts.collectors.add_gather_subset(all_collector_classes, 'test_collector')
    ansible.module_utils.facts.collectors.add_gather_subset(all_collector_classes, 'test_collector3')

# Generated at 2022-06-20 16:51:04.722524
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector(collectors=[])
    assert len(fact_collector.collectors) == 0
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None


# Generated at 2022-06-20 16:51:10.419623
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollector():

        def collect(self, module=None, collected_facts={}):
            return {'foo': 'File1'}

    class MockCollector2(MockCollector):

        def collect(self, module=None, collected_facts={}):
            return {'bar': 'File2'}


    fact_collector = AnsibleFactCollector(collectors=[MockCollector(), MockCollector2()])
    facts = fact_collector.collect()

    assert facts['foo'] == 'File1'
    assert facts['bar'] == 'File2'

# Generated at 2022-06-20 16:51:17.075765
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=True)
    facts = fact_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert facts['module_setup'] == True

# Generated at 2022-06-20 16:51:24.792307
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.network
    class MockNetworkCollector(ansible.module_utils.facts.collector.network.NetworkCollector):
        def __init__(self, namespace=None):
            ansible.module_utils.facts.collector.network.NetworkCollector.__init__(self, namespace=namespace)
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'ansible_interfaces': ['eth0']}
    class TestAnsibleFactCollector(AnsibleFactCollector):
        def __init__(self, collectors=None, namespace=None, filter_spec=None):
            super(TestAnsibleFactCollector, self).__init__(collectors=collectors, namespace=namespace)
            self.filter_

# Generated at 2022-06-20 16:51:30.588409
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'])
    facts = fact_collector.collect()
    assert facts['gather_subset'] == ['all']
    assert 'module_setup' in facts



# Generated at 2022-06-20 16:51:36.106286
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    CMC = CollectorMetaDataCollector(gather_subset=['all'], namespace=None)
    assert {'gather_subset': ['all'], 'module_setup': True} == CMC.collect()


# Generated at 2022-06-20 16:51:39.019517
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert collector_meta_data_collector.gather_subset == gather_subset
    assert collector_meta_data_collector.module_setup == module_setup


# Generated at 2022-06-20 16:51:47.341726
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import random
    import string

    class FakeCollector(collector.BaseFactCollector):
        def __init__(self, namespace=None, filter_spec=None):
            super(FakeCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            fact_dict = {}
            for i in range(5):
                fact_name = ''.join(random.sample(string.ascii_lowercase, 8))
                fact_dict[fact_name] = ''.join(random.sample(string.ascii_lowercase, 8))
            return fact_dict

    collectors = [FakeCollector(), FakeCollector()]

    filter_spec = ['ansible_*', 'facter_*', 'ohai_*']

    # Assert case

# Generated at 2022-06-20 16:51:57.998537
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_mock1 = AnsibleFactCollector()
    collector_mock2 = AnsibleFactCollector()

    fact_collector = AnsibleFactCollector(collectors=[collector_mock1, collector_mock2],
                                          filter_spec=['foo', 'bar'])

    # test when filter_spec is empty
    fact_collector.filter_spec = []
    res = fact_collector.collect()
    assert res == {}, res

    # test when filter_spec is '*'
    fact_collector.filter_spec = '*'
    res = fact_collector.collect()
    assert res == {}, res

    # test when filter_spec is a list
    fact_collector.filter_spec = ['foo', 'bar']
    res = fact_collector.collect()

# Generated at 2022-06-20 16:52:15.782924
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gather_subset = 'all'
    module_setup = False
    collector_meta_data_collector = CollectorMetaDataCollector(collectors=[],
                                                               namespace=[],
                                                               gather_subset=gather_subset,
                                                               module_setup=module_setup)
    assert collector_meta_data_collector.gather_subset  == gather_subset
    assert collector_meta_data_collector.module_setup == module_setup


# Generated at 2022-06-20 16:52:20.945028
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    collectors = []
    namespace = 'test'
    filter_spec = []

    collector = AnsibleFactCollector(collectors, namespace, filter_spec)

    assert collector.collectors == collectors
    assert collector.collector_namespace == namespace
    assert collector.filter_spec == filter_spec

# Generated at 2022-06-20 16:52:23.325660
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts import collectors

    ns = namespaces.PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(namespace=ns, collectors=[collectors.NetworkCollector()])

    collected_facts = fact_collector.collect()
    assert collected_facts.get('ansible_network') is not None

# Generated at 2022-06-20 16:52:35.938646
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import hardware

    all_collector_classes = [hardware.Hardware, hardware.Networking]

    collectors = []
    for collector_class in all_collector_classes:
        collectors.append(collector_class())

    fact_collector = AnsibleFactCollector(collectors=collectors)

    facts = fact_collector.collect()

    assert hardware.Networking.name in facts, \
        "'%s' not in %s" % (hardware.Networking.name, facts.keys())

    assert hardware.Hardware.name in facts, \
        "'%s' not in %s" % (hardware.Hardware.name, facts.keys())


# Generated at 2022-06-20 16:52:46.933915
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''Unit test for constructor of class CollectorMetaDataCollector.

       Tests if the class can be instantiated with no exception.
    '''

    if sys.version_info >= (3, 0):
        # Take a snapshot of the original object
        x = sys.modules[CollectorMetaDataCollector.__module__]
        x = [(k, v) for (k, v) in x.items()]

    # Create an instance
    inst = CollectorMetaDataCollector()

    if sys.version_info >= (3, 0):
        # Ensure that no new module-level attributes were added
        y = [(k, v) for (k, v) in sys.modules[CollectorMetaDataCollector.__module__].items()]
        # The extra two attributes correspond to the object itself

# Generated at 2022-06-20 16:52:52.260130
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['min', 'all', '!forest'],
                                   module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['min', 'all', '!forest'], 'module_setup': True}

# Generated at 2022-06-20 16:53:01.825942
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class DummyFactsCollector(collector.BaseFactCollector):
        '''A dummy facts collector that returns a facts dict with a key of 'foo' and value 'bar'.
           Used for testing AnsibleFactCollector.collect().'''

        name = 'dummy'

        def collect(self, module=None, collected_facts=None):
            facts = {'foo': 'bar'}
            return facts

    class DummyNamespaceCollector(collector.BaseFactCollector):
        '''A dummy namespace collector that returns a facts dict with a key of 'foo' and value 'bar'.
           Used for testing AnsibleFactCollector.collect().'''

        name = 'dummy'

        def collect_with_namespace(self, module=None, collected_facts=None):
            facts = {'foo': 'bar'}


# Generated at 2022-06-20 16:53:08.535604
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Arrange
    # The CollectorMetaDataCollector is used as a stand in for a regular
    # collector so we can test the collect method of AnsibleFactCollector
    collector_metadata_collector = CollectorMetaDataCollector()
    fact_collector = AnsibleFactCollector(collectors=[collector_metadata_collector])

    # Act
    collected_facts = fact_collector.collect()

    # Assert
    assert 'ansible_facts' in collected_facts

# Generated at 2022-06-20 16:53:20.330363
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    collectors = [HardwareCollector(namespace=None)]
    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=None)
    fact_info = fact_collector.collect()

    assert fact_info['hardware']['kernel']
    assert fact_info['hardware']['memfree']

    collectors = [HardwareCollector(namespace='ansible_')]
    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=None)
    fact_info = fact_collector.collect()

    assert fact_info['ansible_hardware']['kernel']
    assert fact_info['ansible_hardware']['memfree']


# Generated at 2022-06-20 16:53:26.560354
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = [
        collector.FacterCollector,
        collector.OhaiCollector,
        collector.UnixCollector,
        collector.NetworkCollector,
        collector.HardwareCollector,
        collector.VirtualCollector,
        collector.PkgMgrFactCollector,
        collector.ServiceMgrFactCollector,
        collector.ZypperCollector,
        collector.AptFactCollector,
        collector.YumFactCollector,
        collector.DNFFactCollector
    ]
    gather_subset = ['all']
    gather_timeout = 30
    minimal_gather_subset = frozenset()
    namespace = None
    filter_spec = []

# Generated at 2022-06-20 16:53:57.453985
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector1 = collector.BaseFactCollector()
    collector1.name = 'collector1'
    collector2 = collector.BaseFactCollector()
    collector2.name = 'collector2'
    collector3 = collector.BaseFactCollector()
    collector3.name = 'collector3'
    collector3.m_facts = {'foo': 'bar_from_collector3', 'ansible_foo': 'bar_from_collector3'}
    fact_collector = AnsibleFactCollector([collector1, collector2, collector3],
                                          filter_spec=['foo', 'ansible_foo'],
                                          namespace=None)
    # Check that facts in different collectors which names appear in filter_spec are collected

# Generated at 2022-06-20 16:54:02.056115
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_facts = CollectorMetaDataCollector(gather_subset="TestGatherSubset").collect()
    assert meta_facts['gather_subset'] == "TestGatherSubset"


# Generated at 2022-06-20 16:54:10.995153
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''
    When an instance of CollectorMetaDataCollector is initialized, it is initialized with
    gather_subset equal to set(['min', 'network', 'hardware', 'virtual']).

    If a request is made to collect the gather_subset then the result will be
    {'ansible_facts': {'gather_subset': set(['min', 'network', 'hardware', 'virtual'])}}.
    '''
    all_collector_classes = {}
    ansible_collector = get_ansible_collector(all_collector_classes,
                                              gather_subset=['min', 'network', 'hardware', 'virtual'])
    ansible_facts = ansible_collector.collect()

# Generated at 2022-06-20 16:54:16.140961
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import unittest
    from ansible.module_utils.facts import ansible_collector

    # test for valid case
    collector = CollectorMetaDataCollector()
    result = collector.collect(gather_subset="all")
    assert result['gather_subset'] == 'all'

    # test for invalid case
    collector = CollectorMetaDataCollector()
    result = collector.collect(gather_subset="not all")
    assert result['gather_subset'] == 'not all'

    # test for valid case
    collector = CollectorMetaDataCollector()
    result = collector.collect(module_setup="True")
    assert result['module_setup'] == 'True'

    # test for invalid case
    collector = CollectorMetaDataCollector()
    result = collector.collect(module_setup="False")
    assert result

# Generated at 2022-06-20 16:54:25.959946
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import mock
    import pytest

    class AnsibleFactCollectorChild(AnsibleFactCollector):
        def __init__(self, mock_collectors, mock_namespace):
            self.mock_collectors = mock_collectors
            self.mock_namespace = mock_namespace
            self.collectors = mock_collectors
            self.namespace = mock_namespace

    class MockCollector(object):
        def __init__(self, collect_with_namespace):
            self.collect_with_namespace = collect_with_namespace

    class MockNamespace(object):
        def __init__(self, prefix):
            self.prefix = prefix

        def get_namespace(self):
            return self.prefix


# Generated at 2022-06-20 16:54:36.476075
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Test the collect method of class AnsibleFactCollector.'''

    class Collector1(collector.BaseFactCollector):
        '''Mock class to test AnsibleFactCollector collect method.'''

        name = 'collector1'
        _fact_ids = set([])
        def collect(self, module=None, collected_facts=None):
            facts_dict = {'k1': 'v1', 'k2': 'v2'}
            return facts_dict

    class Collector2(collector.BaseFactCollector):
        '''Mock class to test AnsibleFactCollector collect method.'''

        name = 'collector2'
        _fact_ids = set([])

# Generated at 2022-06-20 16:54:41.791163
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(
        gather_subset=['all'], module_setup=True)
    assert fact_collector.collect() == {'gather_subset': ['all'],
                                        'module_setup': True}


# Generated at 2022-06-20 16:54:45.232517
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert fact_collector.collectors == []

# Generated at 2022-06-20 16:54:52.126862
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes

    filter_spec = []
    gather_subset = ['all']
    gather_timeout = 20

    collector = get_ansible_collector(all_collector_classes,
                                      filter_spec=filter_spec,
                                      gather_subset=gather_subset,
                                      gather_timeout=gather_timeout)
    assert collector



# Generated at 2022-06-20 16:55:04.235267
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collectors = []
    namespace = None
    gather_subset = ['!all', 'facter', 'min', 'ohai']
    module_setup = None
    GatherFactsCollector_obj = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)
    # Constructing a module object and calling collect of CollectorMetaDataCollector class
    module_obj = MockModule()
    GatherFactsCollector_obj.collect(module_obj)
    # Asserting the value of the facts dictionary
    assert module_obj.ansible_facts['gather_subset'] == gather_subset
    assert module_obj.ansible_facts['module_setup'] is True


# Generated at 2022-06-20 16:55:59.168617
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import internals
    from ansible.module_utils.facts import namespace

    internal_collector_classes = [internals.NetworkingFactCollector, internals.VirtualizationFactCollector, internals.DistributionFactCollector, internals.PlatformFactCollector, internals.LocalFactsCollector]

    fact_collector = AnsibleFactCollector(collectors=[],
                                          namespace=namespace.FactNamespace())
    outer_facts = {}
    for internal_collector in internal_collector_classes:
        collector = internal_collector(namespace=namespace.FactNamespace())
        fact_collector.collectors.append(collector)
        fact = fact_collector.collect(module=None, collected_facts=outer_facts)
        outer_facts = fact.copy()

# Generated at 2022-06-20 16:56:10.060029
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # It is tested that:
    # -an error during collection of a fact is properly handled
    # -if no filter_spec is passed, all facts are collected
    # -if a string or list of strings if passed as filter_spec, only facts matching the strings are collected
    # -if a string or list of strings if passed as filter_spec, only facts with matching key
    #  or with a prefix are collected
    # -facts already collected in collected_facts are passed to each collector at each collection
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespace

    class DummyCollector(collector.BaseFactCollector):
        name = 'dummy'
        _fact_ids = set(['dummy1', 'dummy2'])


# Generated at 2022-06-20 16:56:15.247685
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector(gather_subset=['network'],
                                      module_setup=True).collect() == {'module_setup': True, 'gather_subset': ['network']}


if __name__ == '__main__':
    test_CollectorMetaDataCollector()

# Generated at 2022-06-20 16:56:28.155450
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import network

    gather_subset = ['min']
    minimal_gather_subset = frozenset(['all'])
    namespace = None

    fact_collector = get_ansible_collector(all_collector_classes=[system.SystemCollector,
                                                                  hardware.HardwareCollector,
                                                                  virtual.VirtualCollector,
                                                                  network.NetworkCollector],
                                           gather_subset=gather_subset,
                                           minimal_gather_subset=minimal_gather_subset)

    facts = fact_collector.collect(collected_facts={})

