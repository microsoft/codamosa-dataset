

# Generated at 2022-06-20 16:46:35.345122
# Unit test for function get_ansible_collector
def test_get_ansible_collector(): # pylint: disable=no-self-use
    from ansible.module_utils.facts import namespace
    filter_spec = filter_spec_test = '*'
    gather_subset = gather_subset_test = ['all']
    gather_timeout = gather_timeout_test = 0
    minimal_gather_subset = minimal_gather_subset_test = frozenset()
    namespace = namespace_test = namespace.NullAnsibleFactNamespace()

    all_collector_class = [collector.FacterCollector]


# Generated at 2022-06-20 16:46:37.454601
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO: Add a unit test here
    pass

# Generated at 2022-06-20 16:46:42.688131
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    all_collector_classes = collector._load_collectors()
    fact_collector = get_ansible_collector(all_collector_classes)
    facts = fact_collector.collect()
    assert 'gather_subset' in facts
    assert facts['gather_subset'] == ['all']
    assert 'module_setup' in facts
    assert facts['module_setup']

# Generated at 2022-06-20 16:46:54.481615
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import deb_facts
    from ansible.module_utils.facts import default

    collector_class_name_to_obj = {}
    collector_class_name_to_obj['default'] = default
    collector_class_name_to_obj['network'] = network
    collector_class_name_to_obj['deb_facts'] = deb_facts
    all_collector_classes = collector_class_name_to_obj.values()

    namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')

    minimal_gather_subset = frozenset()

    # test all collectors

# Generated at 2022-06-20 16:47:06.157632
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import unittest
    from ansible.module_utils.facts.network.base import BaseNetworkCollector
    from ansible.module_utils.facts.virtual.base import BaseVirtualCollector
    from ansible.module_utils.facts.system.base import BaseSysCollector
    from ansible.module_utils.facts.processor.base import BaseProcessorCollector

    class SysCollector(BaseSysCollector):
        '''for test, will never be called'''
        pass

    class ProcCollector(BaseProcessorCollector):
        '''for test, will never be called'''
        pass

    class VirtCollector(BaseVirtualCollector):
        '''for test, will never be called'''
        pass

    class NetworkCollector(BaseNetworkCollector):
        '''for test, will never be called'''
       

# Generated at 2022-06-20 16:47:16.805204
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Use the same test as for AnsibleFactCollector
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts.system import System
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector

    hard = Hardware()
    sys = System()
    vir = Virtual()

    all_collector_classes = [hard.__class__, sys.__class__, vir.__class__]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    facts_dict = fact_collector.collect(module=None)

# Generated at 2022-06-20 16:47:27.012526
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Tests for collect method of class CollectorMetaDataCollector.'''
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    returned_value = collector_meta_data_collector.collect()
    assert returned_value == {'gather_subset': ['all'], 'module_setup': True}

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=[],
                                   module_setup=False)
    returned_value = collector_meta_data_collector.collect()
    assert returned_value == {'gather_subset': [], 'module_setup': False}


# Generated at 2022-06-20 16:47:36.315516
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    fact_collector = get_ansible_collector(all_collector_classes=ansible.module_utils.facts.collector.C.all)
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'ansible_system' in facts

if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-20 16:47:46.328171
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from .. import get_collectors_from_namespace

    test_collector_class_set = get_collectors_from_namespace('ansible.module_utils.facts.test_collectors')
    collector_class_set = get_collectors_from_namespace('ansible.module_utils.facts.collectors')
    all_collector_class_set = set(list(test_collector_class_set) + list(collector_class_set))

    fact_collector = get_ansible_collector(all_collector_class_set,
                                           gather_subset='all',
                                           filter_spec=[])

    assert len(fact_collector.collectors) > 0
    assert fact_collector.collectors[0].__class__.__name__ == 'NetworkCollector'

# Generated at 2022-06-20 16:47:52.888133
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset=['all'],
        module_setup=True)

    assert collector_meta_data_collector
    assert len(collector_meta_data_collector._fact_ids) == 1

# Generated at 2022-06-20 16:48:09.732279
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    d = {}
    # setup
    import ansible.module_utils.facts.collector
    ansible_collector = ansible.module_utils.facts.collector

    # perform
    _fact_collector = get_ansible_collector(all_collector_classes=ansible_collector,
                                            namespace=None,
                                            filter_spec=None,
                                            gather_subset=None,
                                            gather_timeout=None,
                                            minimal_gather_subset=None)

    # verify
    facts = _fact_collector.collect(module=d,
                                    collected_facts={'ansible_facts': {}})
    assert isinstance(facts, dict)
    assert 'ansible_facts' in facts



# Generated at 2022-06-20 16:48:21.247562
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector1(collector.BaseFactCollector):
        name = 'test_collector1'

        def collect(self, module=None, collected_facts=None):
            return {'test1a': 'value1a', 'test1b': 'value1b'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test_collector2'

        def collect(self, module=None, collected_facts=None):
            return {'test2a': 'value2a', 'test2b': 'value2b', 'test2c': 'value2c'}

    fact_collector = \
        AnsibleFactCollector(collectors=[TestCollector1(), TestCollector2()])


# Generated at 2022-06-20 16:48:27.118372
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_data_collector = CollectorMetaDataCollector(
        gather_subset=['min'],
        module_setup=None
    )

    # Test that gather_subset key is present
    assert meta_data_collector.collect() == {'gather_subset': ['min']}

    meta_data_collector = CollectorMetaDataCollector(
        gather_subset=None,
        module_setup=True
    )

    # Test that module_setup key is present
    assert meta_data_collector.collect() == {'module_setup': True}

    meta_data_collector = CollectorMetaDataCollector(
        gather_subset=['min'],
        module_setup=True
    )

    # Test that gather_subset and module_setup keys are present
    assert meta_data_collector

# Generated at 2022-06-20 16:48:30.264947
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(collected_facts=set())
    fact_collector.collect()

# Generated at 2022-06-20 16:48:41.738430
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Unit test for constructor of class AnsibleFactCollector.'''

    class C1(collector.BaseFactCollector):
        name = 'c1'

    class C2(collector.BaseFactCollector):
        name = 'c2'

    class C3(collector.BaseFactCollector):
        name = 'c3'

    def test_collector_objects(collector_objs):
        assert len(collector_objs) == 3
        for collector_obj in collector_objs:
            assert isinstance(collector_obj, collector.BaseFactCollector)
        assert isinstance(collector_objs[0], C1) and \
               isinstance(collector_objs[1], C2) and \
               isinstance(collector_objs[2], C3)


# Generated at 2022-06-20 16:48:45.583888
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset=None,
        module_setup=None)

    assert collector_meta_data_collector is not None
    assert collector_meta_data_collector.collect() == {'gather_subset': None}

# Generated at 2022-06-20 16:48:55.231847
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fake_gather_subset = 'test_gather_subset'
    fake_collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=fake_gather_subset,
                                   module_setup=False)
    result = fake_collector_meta_data_collector.collect()
    assert result == {'gather_subset': fake_gather_subset, 'module_setup': False}



# Generated at 2022-06-20 16:48:59.471548
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gather_subset = ['all']
    module_setup = True

    # Instantiate a CollectorMetaDataCollector object
    collector = CollectorMetaDataCollector(gather_subset=gather_subset, module_setup=module_setup)
    # Call method collect and test the result
    expected_result = {
        u'gather_subset': [u'all'],
        u'module_setup': True
    }
    assert(expected_result == collector.collect())

# Generated at 2022-06-20 16:49:00.430905
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectorClass = CollectorMetaDataCollector
    collectorClass().collect()
    collectorClass()


# Generated at 2022-06-20 16:49:09.297154
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class MockFactCollector(collector.BaseFactCollector):
        name = 'MockFactCollector'
        _fact_ids = set(['mock_fact_1'])

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact_1': {'value': 'mock_fact_1_value'}}

    fact_collector = \
        AnsibleFactCollector(collectors=[MockFactCollector()],
                             namespace=None)

    collected_facts = fact_collector.collect()

    assert collected_facts['mock_fact_1']['value'] == 'mock_fact_1_value'

# Generated at 2022-06-20 16:49:14.865197
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # The goal here is to get the class instantiated.
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)

# Generated at 2022-06-20 16:49:20.604878
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Normal use case
    fact_collector = get_ansible_collector(module=None,
                                           collected_facts=None,
                                           gather_subset="",
                                           minimal_gather_subset=None)

    # Test the _filter() method of AnsibleFactCollector
    #
    # generate a test_facts_dict for testing _filter() method in AnsibleFactCollector
    #
    # assert that there are at least 10 keys in test_facts_dict
    test_facts_dict = {k: v for k, v in enumerate(range(1, 15))}
    assert len(list(test_facts_dict.keys())) >= 10

    # assert no filtering is done if wild card * is used as filter

# Generated at 2022-06-20 16:49:28.099611
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=[],
                                   module_setup=True)
    collected_facts = collector_meta_data_collector.collect()
    assert type(collected_facts) is dict
    assert type(collected_facts['gather_subset']) is list
    assert type(collected_facts['module_setup']) is bool


# Generated at 2022-06-20 16:49:34.178119
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(gather_subset=['network'])
    assert c.name == 'gather_subset'

    f = c.collect()
    assert f == {'gather_subset': ['network']}


# Generated at 2022-06-20 16:49:42.272916
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector

    import ansible.module_utils.facts.namespace

    from ansible.module_utils.facts.cache import AnsibleCacheFactCollector
    from ansible.module_utils.facts.distribution import AnsibleDistributionFactCollector
    from ansible.module_utils.facts.network import AnsibleNetworkFactCollector
    from ansible.module_utils.facts.system import AnsibleSystemFactCollector
    from ansible.module_utils.facts.virtual import AnsibleVirtualFactCollector

    minimal_

# Generated at 2022-06-20 16:49:43.923227
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    a = CollectorMetaDataCollector()
    assert a.collect() == {'gather_subset': None}

# Generated at 2022-06-20 16:49:53.275996
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test a collector obj that returns ansible_os_family
    class Collector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test'}

    test_collectors = [Collector()]
    test_filter_spec = ['test_fact']
    test_fact_collector = AnsibleFactCollector(collectors=test_collectors,
                                               filter_spec=test_filter_spec)

    # returned facts should contain ansible_os_family
    facts = test_fact_collector.collect()
    assert 'test_fact' in facts
    assert facts['test_fact'] == 'test'

# Generated at 2022-06-20 16:50:04.946402
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class TestCollector1(collector.BaseFactCollector):
        _fact_ids = set(['test1'])
        name = 'test_collector_1'
        def collect(self, module=None, collected_facts=None):
            return {'test1': 'x'}

    class TestCollector2(collector.BaseFactCollector):
        _fact_ids = set(['test2', 'test3'])
        name = 'test_collector_2'
        def collect(self, module=None, collected_facts=None):
            return {'test2': 'y', 'test3': 'z'}

    test_collector_classes = [TestCollector1, TestCollector2]


# Generated at 2022-06-20 16:50:07.558776
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    test_obj = AnsibleFactCollector()

    assert test_obj is not None


# Generated at 2022-06-20 16:50:16.951001
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts.hardware.virtual
    import ansible.module_utils.facts.platform
    import ansible.module_utils.facts.system

    # This should not include collectors whose classes do not appear in the list of all_collector_classes
    # But it will include collectors whose parent class is part of all_collector_classes
    all_collector_classes = [ansible.module_utils.facts.hardware.virtual.VirtualCollector,
                             ansible.module_utils.facts.system.SystemCollector,
                             ansible.module_utils.facts.platform.PlatformCollector]

    # This will have SystemCollector and PlatformCollector, but not VirtualCollector
    filter_spec = ['*', '!ansible_virtual', 'ansible_system']


# Generated at 2022-06-20 16:50:25.811777
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    namespace = collector.BaseFactNamespace()
    gather_subset = 'all'
    module_setup = True
    collector_obj = CollectorMetaDataCollector(gather_subset=gather_subset,
                                               module_setup=module_setup)
    fact_dict = collector_obj.collect_with_namespace(namespace=namespace)
    assert fact_dict['gather_subset'] == gather_subset

# Generated at 2022-06-20 16:50:35.226826
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector
    from ansible.module_utils.facts.system.platform import LinuxPlatformCollector
    from ansible.module_utils.facts.system.pkg_mgr import LinuxPkgMgrCollector

    collectors = [LinuxNetworkCollector, LinuxPlatformCollector, DistributionCollector, LinuxPkgMgrCollector]
    fact_collector = get_ansible_collector(all_collector_classes=collectors)
    collectors = fact_collector.collectors
    assert(len(collectors)) == 5
    assert(collectors[0].__class__.__name__ == 'LinuxNetworkCollector')

# Generated at 2022-06-20 16:50:39.710024
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    meta_facts = CollectorMetaDataCollector(gather_subset=['all','network','!min']).collect()

    expected_meta_facts = {'gather_subset': ['all','network','!min']}
    assert meta_facts == expected_meta_facts


# Generated at 2022-06-20 16:50:47.145059
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Test the collect method of the CollectorMetaDataCollector class
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=["network", "hostname"], module_setup=True)
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': ["network", "hostname"], 'module_setup': True}

# Generated at 2022-06-20 16:51:00.438378
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts import timeout

    # AnsibleFactCollector accepts a list of collectors
    # and wraps it with namespaces.
    collector_1 = \
        ansible.module_utils.facts.collector.BaseFactCollector(
            namespace=ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_'))

    collector_2 = \
        ansible.module_utils.facts.collector.BaseFactCollector(
            namespace=ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_'))

    # actually pull the collectors.

# Generated at 2022-06-20 16:51:04.218204
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}



# Generated at 2022-06-20 16:51:13.005149
# Unit test for function get_ansible_collector
def test_get_ansible_collector(): # noqa

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import OhaiCollector

    namespace = PrefixFactNamespace(prefix='ansible_')

    # test no facts
    fact_collector = get_ansible_collector(all_collector_classes=[])
    ansible_facts = fact_collector.collect()
    assert ansible_facts == {'gather_subset': ['all'], 'module_setup': True}

    # test single fact
    fact_collector = get_ansible_collector(all_collector_classes=[OhaiCollector],
                                           filter_spec='foobar',
                                           namespace=namespace)


# Generated at 2022-06-20 16:51:22.279465
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # minimal_gather_subset=['all']
    # gather_subset=['!facter', 'facter', '!facter', '!foo', 'foo']
    # should remove dup gather subsets and add minimal subset
    # and return ['all', '!facter', 'foo']
    fact_collector = \
        get_ansible_collector(all_collector_classes=[],
                              minimal_gather_subset=['all'],
                              gather_subset=['!facter', 'facter', '!facter', '!foo', 'foo'])

    assert fact_collector.collectors[-1].gather_subset == ['all', '!facter', 'foo']

# Generated at 2022-06-20 16:51:24.428865
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    result            = fact_collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-20 16:51:33.931575
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # Basic test, check that the 'gather_subset' fact is present
    metadata_collector = CollectorMetaDataCollector(gather_subset=[],
                                                    module_setup=True)
    facts = metadata_collector.collect()
    assert 'gather_subset' in facts
    assert facts['gather_subset'] == []
    assert 'module_setup' in facts

    # Test that 'module_setup' is not present if not required
    metadata_collector = CollectorMetaDataCollector(gather_subset=[],
                                                    module_setup=False)
    facts = metadata_collector.collect()
    assert 'gather_subset' in facts
    assert facts['gather_subset'] == []
    assert 'module_setup' not in facts

# Generated at 2022-06-20 16:51:57.226432
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class MockCollector(collector.BaseFactCollector):

        name = "mock_collector"

    mock_collectors = [MockCollector]

    fact_collector = \
        AnsibleFactCollector(collectors=mock_collectors,
                             namespace=None,
                             filter_spec=None)
    collected_facts = fact_collector.collect(module=None,
                                             collected_facts=None)
    expected_collected_facts = {'mock_collector': {}}
    assert collected_facts == expected_collected_facts


# Generated at 2022-06-20 16:52:06.223476
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collectors import network

    all_collector_classes = [network.NetworkCollector]
    filter_spec = ['ansible_*']
    namespace = PrefixFactNamespace(prefix='ansible_')
    gather_subset = ['all']
    gather_timeout = 60
    minimal_gather_subset = frozenset()


# Generated at 2022-06-20 16:52:16.536273
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.hardware import hardware
    from ansible.module_utils.facts.network import network
    from ansible.module_utils.facts.virtual import virtual

    all_collector_classes = [hardware, network, virtual]

    ansible_collector = \
        get_ansible_collector(all_collector_classes,
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)

    # Assert that the ansible_collector contains a single metadata collector
    assert len(ansible_collector.collectors) == 4
    assert isinstance(ansible_collector.collectors[0], hardware.HardwareCollector)

# Generated at 2022-06-20 16:52:24.893454
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.namespace  # avoid circular import

    # make sure we got a fact collector
    ac = get_ansible_collector(all_collector_classes=None,
                               namespace=None)
    assert isinstance(ac, AnsibleFactCollector)

    # make sure we got a facts namespace
    assert ac.namespace is None
    ac = get_ansible_collector(all_collector_classes=None,
                               namespace=ansible.module_utils.facts.namespace.PrefixFactNamespace('ansible_'))

    assert isinstance(ac.namespace, ansible.module_utils.facts.namespace.PrefixFactNamespace)

# Generated at 2022-06-20 16:52:32.365924
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    module = None
    collected_facts = {}

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all')
    meta_facts = collector_meta_data_collector.collect(module=module, collected_facts=collected_facts)
    assert meta_facts == {'gather_subset': 'all'}

# Generated at 2022-06-20 16:52:33.320565
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # TODO
    pass

# Generated at 2022-06-20 16:52:38.578081
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(namespace=None,
                                   gather_subset=['all'],
                                   module_setup=False)
    assert c.name == 'gather_subset'
    assert c._fact_ids == set([])



# Generated at 2022-06-20 16:52:46.722712
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    class_ = CollectorMetaDataCollector('', '', 'all')
    ans = class_.collect()
    assert 'gather_subset' in ans, \
        'test_CollectorMetaDataCollector_collect() failed'
    assert ans['gather_subset'] == 'all', \
        'test_CollectorMetaDataCollector_collect() failed'

    class_ = CollectorMetaDataCollector('', '', 'all', 'test')
    ans = class_.collect()
    assert 'module_setup' in ans, \
        'test_CollectorMetaDataCollector_collect() failed'
    assert ans['module_setup'] == 'test', \
        'test_CollectorMetaDataCollector_collect() failed'

# Generated at 2022-06-20 16:52:55.699676
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from . import namespaces
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FilterFactNamespace
    from ansible.module_utils.facts.namespace import IncludeFilteredFactNamespace
    from ansible.module_utils.facts.namespace import ExcludeFilteredFactNamespace

    # Test that get_ansible_collector() creates a NamespaceFactCollector with the specified namespace

# Generated at 2022-06-20 16:53:05.587665
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all', 'network', 'virtual'],
                                   module_setup=True)
    
    meta_facts = collector_meta_data_collector.collect(collected_facts=None)
    assert meta_facts['gather_subset'] == ['all', 'network', 'virtual']
    assert meta_facts['module_setup'] == True

test_CollectorMetaDataCollector_collect()


# Generated at 2022-06-20 16:53:24.216955
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.get_collector_classes(collector_classes_from_module_names=['ansible_facts.collectors'])
    fact_collector = \
        get_ansible_collector(all_collector_classes,
                              gather_subset=['network', 'fact_gathering'])


# Generated at 2022-06-20 16:53:31.602341
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=False)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == False


# Generated at 2022-06-20 16:53:34.858019
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace

    test = AnsibleFactCollector(namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    assert test

# Generated at 2022-06-20 16:53:41.207193
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    class CollectorMetaDataCollectorTest(CollectorMetaDataCollector):
        pass

    test_object = CollectorMetaDataCollectorTest(gather_subset=['all', 'network'],
                                                 module_setup=True)

    assert {'gather_subset': ['all', 'network'],
            'module_setup': True} == test_object.collect()

# Generated at 2022-06-20 16:53:41.775488
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    pass

# Generated at 2022-06-20 16:53:45.640106
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    missing_gather_subset = None
    expected_default_gather_subset = frozenset()

    c_meta_data_obj = CollectorMetaDataCollector(gather_subset=missing_gather_subset)
    assert c_meta_data_obj.gather_subset == expected_default_gather_subset



# Generated at 2022-06-20 16:53:51.572255
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-20 16:53:58.245192
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution

    # Setup a list of collectors
    fact_collectors = []
    fact_collectors.append(DistributionFactCollector(namespace=Distribution))

    # Setup a fact collector
    fact_collector = AnsibleFactCollector(collectors=fact_collectors,
                                          namespace=Distribution)

    # Get collected facts
    try:
        collected_facts = fact_collector.collect_with_namespace()
    except Exception as e:
        sys.stderr.write(repr(e))
        sys.stderr.write('\n')

    # Unit test to fail if collected facts is not a dict

# Generated at 2022-06-20 16:54:07.181178
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import mock
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace

    all_collector_classes = set([collector.NetworkCollector,
                                 collector.HardwareCollector,
                                 collector.VirtualCollector,
                                 collector.SystemCollector,
                                 collector.SystemDCollector,
                                 collector.DistributionCollector,
                                 collector.FileSystemCollector,
                                 collector.LocalJsonCollector,
                                 collector.InterfacesCollector])

    filter_spec = []
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    # List of collector classes returned by the

# Generated at 2022-06-20 16:54:18.058393
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    ''' Unit test function get_ansible_collector '''

    def test_collector_class(collector_class, fact_ids=None):
        fact_ids = fact_ids or []
        return collector_class(namespace=None)

    test_collector_classes = [
        ('test_collector_0', test_collector_class),
        ('test_collector_1', test_collector_class),
        ('test_collector_2', test_collector_class),
    ]

    ''' Initialize FactCollector with a list of test FactCollectors '''

# Generated at 2022-06-20 16:55:02.904668
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    a = CollectorMetaDataCollector(gather_subset='all', module_setup=False)
    assert a.name == 'gather_subset'
    assert a.gather_subset == 'all'
    assert a.module_setup is False
    assert 'gather_subset' in a.collect()
    assert not a.collect()['module_setup']

    b = CollectorMetaDataCollector(gather_subset='all')
    assert b.module_setup is True

# Generated at 2022-06-20 16:55:10.834808
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''
    Ensure that CollectorMetaDataCollector has the correct constructor.
    '''
    facts = get_ansible_collector((CollectorMetaDataCollector,), gather_subset=('all',))
    assert facts.collectors[0].gather_subset == ('all',)
    # assert that module_setup is true
    assert facts.collectors[0].module_setup == True

# Generated at 2022-06-20 16:55:13.717892
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector(gather_subset='all').gather_subset == 'all'
    assert CollectorMetaDataCollector(gather_subset=None).gather_subset == None

# Generated at 2022-06-20 16:55:20.251800
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    result = meta_data_collector.collect()
    assert result == {'gather_subset': ['all']}



# Generated at 2022-06-20 16:55:23.556034
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import unittest

    class TestClass(unittest.TestCase):
        def test_collect(self):
            """returns correct meta_facts"""
            c = CollectorMetaDataCollector(['all'], "", "", True)
            self.assertEqual(c.collect(), {'module_setup': True, 'gather_subset': ['all']})

    unittest.main()

# Generated at 2022-06-20 16:55:35.999778
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    g_subset = 'all'
    module_setup = False
    f_fact_collector = CollectorMetaDataCollector(gather_subset=g_subset,
                                                  module_setup=module_setup)

    expected_f_meta_facts = {'gather_subset': g_subset,
                             'module_setup': module_setup}

    f_meta_facts = f_fact_collector.collect()

    if f_meta_facts != expected_f_meta_facts:
        raise AssertionError('expected: %s, actual: %s' %
                             (expected_f_meta_facts, f_meta_facts))



# Generated at 2022-06-20 16:55:46.428947
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import unittest

    from ansible.module_utils.facts import network
    from ansible.module_utils.facts.network import FactNamespace

    # Introduce a mock NetworkCollector for unit testing purposes
    class MockNetworkCollector(network.NetworkCollector):
        def __init__(self, namespace=None):
            self.namespace = namespace if namespace else FactNamespace()


# Generated at 2022-06-20 16:55:53.574901
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()

    if fact_collector.namespace:
        raise AssertionError('namespace is not None')

    if not fact_collector.collectors:
        raise AssertionError('collectors is None')

    if fact_collector.filter_spec:
        raise AssertionError('filter_spec is not None')

# Generated at 2022-06-20 16:56:05.556776
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    ns = collector.namespace.PrefixFactNamespace(prefix='ansible_')
    collector = CollectorMetaDataCollector(namespace=ns, gather_subset='all', module_setup=True)
    collected = collector.collect_with_namespace()
    # There is only one fact from this collector
    assert len(collected) == 1
    # The fact name should be prefixed with 'ansible_'
    assert collector.namespace.prefix_with_namespace('gather_subset') in collected
    # The fact value should be 'all' and module_setup=True
    assert collected[collector.namespace.prefix_with_namespace('gather_subset')] == 'all'

# Generated at 2022-06-20 16:56:09.822348
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}
