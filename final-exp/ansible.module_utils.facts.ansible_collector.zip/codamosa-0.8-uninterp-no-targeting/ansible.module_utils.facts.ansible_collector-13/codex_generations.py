

# Generated at 2022-06-20 16:46:25.403619
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    assert 1 == 1

# Generated at 2022-06-20 16:46:28.374923
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    test_filter_spec = 'ansible_*'
    collector1 = collector.BaseFactCollector()
    collectors = [collector1]
    fact_collector = AnsibleFactCollector(collectors, filter_spec=test_filter_spec)
    assert fact_collector.collectors is collectors
    assert fact_collector.filter_spec == test_filter_spec

# Generated at 2022-06-20 16:46:33.334461
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import collector
    all_collector_classes = collector.all_collector_classes()

    with namespace:
        fact_collector = get_ansible_collector(all_collector_classes)

    assert type(fact_collector) is AnsibleFactCollector


# Generated at 2022-06-20 16:46:44.992853
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    sys.modules['ansible.module_utils.facts.collector.facter_collector'] = None
    sys.modules['ansible.module_utils.facts.collector.facter_subset_collector'] = None

    # This is a minimal set of collectors used by Ansible modules to gather facts

# Generated at 2022-06-20 16:46:50.967593
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert collector_meta_data_collector.gather_subset == 'all'
    assert collector_meta_data_collector.module_setup == True


# Generated at 2022-06-20 16:46:53.528251
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=False)
    assert 'gather_subset' in collector_meta_data_collector.collect()

# Generated at 2022-06-20 16:47:05.254136
# Unit test for function get_ansible_collector

# Generated at 2022-06-20 16:47:12.648120
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_obj = CollectorMetaDataCollector()
    assert collector_obj.collect() == {'gather_subset': None, 'module_setup': True}, "CollectorMetaDataCollector collect returns unexpected result, expected: {'gather_subset': None, 'module_setup': True}, actual: '%s'"%collector_obj.collect()

# Generated at 2022-06-20 16:47:19.190557
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Unit test with gather_subset and module_setup
    c_test = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    fact_test = c_test.collect()
    assert fact_test['gather_subset'] == ['all']
    assert fact_test['module_setup'] is True

    # Unit test with gather_subset
    c_test = CollectorMetaDataCollector(gather_subset=['all'])
    fact_test = c_test.collect()
    assert fact_test['gather_subset'] == ['all']

    # Unit test without gather_subset
    c_test = CollectorMetaDataCollector()
    fact_test = c_test.collect()
    assert fact_test['gather_subset'] == ['all']

# Generated at 2022-06-20 16:47:28.215473
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):
        name = 'test_collector'

        def __init__(self, namespace=None):
            super(TestCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'xyz'}

    class TestNamespace(collector.BaseFactNamespace):

        def get_facts(self, collected_facts=None):
            collected_facts = collected_facts or {}

            test_fact = collected_facts.get('test_fact')
            return {'test_fact_ns': test_fact}

    test_namespace = TestNamespace(prefix='test_')
    test_collector = TestCollector(namespace=test_namespace)
    ansible

# Generated at 2022-06-20 16:47:41.667897
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    class CollectorMock:
        def __init__(self, name='', facts=None):
            self.name = name
            self.facts = facts or {}

        def collect(self, module=None, collected_facts=None):
            return self.facts

    all_collectors = [CollectorMock('fact_1', {'foo': 'bar', 'aaa': 'bbb'}),
                      CollectorMock('fact_2', {'ccc': 'ddd', 'eee': 'fff'}),
                      CollectorMock('fact_3', {'ggg': 'hhh', 'iii': 'jjj'})]

    fact_collector = \
        AnsibleFactCollector(collectors=all_collectors,
                             filter_spec=['*', 'ccc'])

    # Note: this is testing implementation of collect

# Generated at 2022-06-20 16:47:45.528010
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test for method collect of class CollectorMetaDataCollector.'''
    CollectorMetaDataCollector_obj = CollectorMetaDataCollector()
    assert(CollectorMetaDataCollector_obj.collect() == {'gather_subset': None, 'module_setup': None})

# Generated at 2022-06-20 16:47:58.426868
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.composite import DictFacts
    from ansible.module_utils.facts.system.distribution import DistributionFactsCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector
    from ansible.module_utils.facts.network.network import NetworkCollector
    from ansible.module_utils.facts.network.system.system_interfaces import SystemInterfaces
    import time

    # Disable NetworkCollector to avoid dependency on NetworkManager
    NetworkCollector.DISABLED = True

    # Subset of facts collectors.
    fact_collector_classes = [
        DistributionFactsCollector,
        DistributionCollector,
        SystemInterfaces,
    ]

    collectors = []

# Generated at 2022-06-20 16:48:10.528777
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # No args to the constructor
    md_collector = CollectorMetaDataCollector()
    assert md_collector.gather_subset is None
    assert md_collector.module_setup is None
    assert md_collector.name == 'gather_subset'
    assert md_collector.collectors is None
    assert md_collector.namespace is None
    # Four args to the constructor, but specify only two of them
    md_collector = CollectorMetaDataCollector(collectors=[],
                                              namespace='ansible',
                                              gather_subset=['network'],
                                              module_setup=True)
    assert md_collector.gather_subset == ['network']
    assert md_collector.module_setup
    assert md_collector.name == 'gather_subset'


# Generated at 2022-06-20 16:48:13.381118
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ''' Check collect for AnsibleFactCollector.
    :return:
    '''
    pass

# Generated at 2022-06-20 16:48:22.809780
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    assertion_expected_values = \
        [
            {'gather_subset': ['all']},
            {'gather_subset': ['all'], 'module_setup': True},
            {'gather_subset': ['min']},
            {'gather_subset': ['min'], 'module_setup': True},
            {'gather_subset': ['!all']},
            {'gather_subset': ['!all'], 'module_setup': True},
            {'gather_subset': ['!min']},
            {'gather_subset': ['!min'], 'module_setup': True},
        ]

# Generated at 2022-06-20 16:48:28.789866
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes())
    assert hasattr(fact_collector, 'namespace')
    # Collect facts
    fact_dict = fact_collector.collect(module=None, collected_facts=None)
    assert fact_dict
    assert 'ansible_facts' in fact_dict
    assert fact_dict['ansible_facts']

# Generated at 2022-06-20 16:48:41.197003
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import copy
    import types

    import ansible.module_utils.facts

    module = object()

    try:
        get_ansible_collector([], gather_subset=['all'])().collect(module=module)
    except Exception:
        pass

    collector_instance = get_ansible_collector([ansible.module_utils.facts.system.SystemCollector], gather_subset=['all'])

    collected_facts = collector_instance().collect(module=module)

# Generated at 2022-06-20 16:48:45.332583
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset='test_gather_subset')

    module = None
    collected_facts = None

    assert collector_meta_data_collector.collect(module, collected_facts) == {
        'gather_subset': 'test_gather_subset'}

# Generated at 2022-06-20 16:48:48.379489
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    global collected_facts
    fact_collector = AnsibleFactCollector()
    collected_facts = fact_collector.collect()



# Generated at 2022-06-20 16:48:55.549826
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_classes = []

    collect_data = {}
    collector_classes.append(CollectorMetaDataCollector())

    for collector_class in collector_classes:
        collector_obj = collector_class(gather_subset=['foo', 'bar', 'baz'])

        try:
            fact_data = collector_obj.collect()
        except Exception as e:
            sys.stderr.write(repr(e))
            sys.stderr.write('\n')
        collect_data.update(fact_data)

    assert collect_data['gather_subset'] == ['foo', 'bar', 'baz']
    assert collect_data['module_setup'] == True

# Generated at 2022-06-20 16:49:07.850208
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Test with a namespace and a filter
    namespace = collector.PrefixFactNamespace(prefix='ansible_')
    filter_spec = ['*', '!ansible_env']

    fact_collector = AnsibleFactCollector(namespace=namespace,
                                          filter_spec=filter_spec)

    assert fact_collector.namespace == namespace
    assert fact_collector.filter_spec == filter_spec
    assert fact_collector.collectors == []

    # Test with no values
    fact_collector = AnsibleFactCollector()

    assert fact_collector.namespace is None
    assert fact_collector.filter_spec is None
    assert fact_collector.collectors == []

# Generated at 2022-06-20 16:49:14.555888
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test for method collect of class CollectorMetaDataCollector'''

    # Init method
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['network', 'virtual'],
                                   module_setup=False)
    # Call method
    meta_facts = collector_meta_data_collector.collect()
    # Verify result
    assert meta_facts == {'gather_subset': ['network', 'virtual'], 'module_setup': False}

# Generated at 2022-06-20 16:49:16.024000
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)

# Generated at 2022-06-20 16:49:22.463358
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import AnyFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    any_collector = AnyFactCollector(namespace=PrefixFactNamespace(prefix='any_'))
    ans_collector = get_ansible_collector([AnyFactCollector],
                                          namespace=PrefixFactNamespace(prefix='ans_'),
                                          filter_spec=['any_*'])
    ans_collector_facts = ans_collector.collect(collected_facts={})

    # Verify that the AnyFactCollector is in the collectors list in the AnsibleFactCollector
    assert ans_collector.collectors.count(any_collector)
    # Verify that the AnyFactCollector was collected but with prefix change
    assert ans_

# Generated at 2022-06-20 16:49:28.715331
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    idk_fact_collector = \
        collector.IdkFactCollector(namespace=None)

    filter_spec = []

    fact_collector = \
        AnsibleFactCollector(collector=[idk_fact_collector],
                             filter_spec=filter_spec)

    facts_dict = fact_collector.collect()

    assert facts_dict == collector.IDK_FACT_DICT

# Generated at 2022-06-20 16:49:40.371451
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.test_utils import MockFact

    # Setup the following structure:
    #
    #                            FakeFact
    #                             /     \
    #                            /       \
    #                        MockFact     MockFact
    #
    # FakeFact returns 2 facts
    #   - fake1
    #   - fake2
    # MockFact returns a list facts
    #   - mock1
    #   - mock2
    #
    class FakeFact(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'fake1': 'value1',
                    'fake2': 'value2'}


# Generated at 2022-06-20 16:49:52.265102
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # This is a unit test for a private class so only test the 'gather_subset'
    # fact that is returned by the 'collect' method.  Other functionality is
    # tested by the 'get_ansible_collector' function and its usages in the
    # various tests of the facts modules.
    #
    # Note that the 'CollectorMetaDataCollector' depends on 'gather_subset'
    # being a list.  So make sure that is the case.
    gathered_subset = ['all']
    module_setup = True

    fact_collector = CollectorMetaDataCollector(gather_subset=gathered_subset,
                                                module_setup=module_setup)

    # Since the 'collect' method does not take any arguments we do not need
    # to worry about the values of the arguments here.

# Generated at 2022-06-20 16:50:04.610723
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    test_collector_classes = [collector.NetworkInterfaceFactCollector,
                              collector.MemoryFactCollector,
                              collector.MountFactCollector]

    only_gather_subset = ['network']

    fact_collector = \
        get_ansible_collector(all_collector_classes=test_collector_classes,
                              gather_subset=only_gather_subset,
                              gather_timeout=1,
                              minimal_gather_subset=only_gather_subset)

    expected_collector_classes = [collector.NetworkInterfaceFactCollector,
                                  collector.CollectorMetaDataCollector]
    # Expect collector classes to have only NetworkInterface and CollectorMetaData collectors
    assert fact_collector.collectors is not None

# Generated at 2022-06-20 16:50:09.565685
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
        meta_data = CollectorMetaDataCollector(gather_subset=['all'],
                                               module_setup=True)

        assert meta_data.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-20 16:50:19.534299
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    meta_data = CollectorMetaDataCollector(gather_subset=['all'],
                                           module_setup=False)

    assert meta_data.gather_subset == ['all']
    assert meta_data.module_setup == False

# Generated at 2022-06-20 16:50:27.889754
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    namespace = PrefixFactNamespace(prefix='ansible_')
    fact_collector = \
        AnsibleFactCollector(namespace=namespace,
                             filter_spec="my_test_fact")

    assert fact_collector.namespace is namespace
    assert fact_collector.filter_spec == "my_test_fact"

# Generated at 2022-06-20 16:50:38.057081
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c1 = CollectorMetaDataCollector(namespace=None,
                                    gather_subset=['all'],
                                    module_setup=True)
    assert c1.collect() == {'gather_subset': ['all'],
                            'module_setup': True}
    c2 = CollectorMetaDataCollector(namespace=None,
                                    gather_subset=['min'],
                                    module_setup=None)
    assert c2.collect() == {'gather_subset': ['min']}


# Generated at 2022-06-20 16:50:47.642973
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_c = CollectorMetaDataCollector()
    assert fact_c.name=='gather_subset'
    fact_c = CollectorMetaDataCollector(gather_subset='all')
    assert fact_c.gather_subset=='all'
    fact_c = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert fact_c.gather_subset=='all'
    assert fact_c.module_setup==True


# Generated at 2022-06-20 16:50:57.193429
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    obj = CollectorMetaDataCollector()
    assert obj.collect(module=None, collected_facts=None) == {'gather_subset': None, 'module_setup' : None}
    obj = CollectorMetaDataCollector(gather_subset="!foo,!bar", module_setup=True)
    assert obj.collect(module=None, collected_facts=None) == {'gather_subset': '!foo,!bar', 'module_setup' : True}

# Generated at 2022-06-20 16:51:05.995614
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils.facts.collector.hardware
    from ansible.module_utils.facts import namespace

    module_setup=False
    nmspc = namespace.PrefixFactNamespace(prefix='ansible_')
    collectors = [ansible.module_utils.facts.collector.hardware.Hardware("hardware",namespace=nmspc)]
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=module_setup,
                                   collectors=collectors,
                                   namespace=nmspc)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == module_setup
    assert collector_meta_data_collector.collect

# Generated at 2022-06-20 16:51:13.169268
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collect_setup = CollectorMetaDataCollector(namespace=None, gather_subset=['all'], module_setup=True)
    collect_default = CollectorMetaDataCollector(namespace=None, gather_subset=['all'], module_setup=None)
    collect_setup_default = CollectorMetaDataCollector(namespace=None, gather_subset=['all'])

    assert collect_setup.collect() == {'gather_subset': ['all'], 'module_setup': True}
    assert collect_default.collect() == {'gather_subset': ['all'], 'module_setup': None}
    assert collect_setup_default.collect() == {'gather_subset': ['all'], 'module_setup': None}

# Generated at 2022-06-20 16:51:21.604998
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_collected_facts = {}
    test_gather_subset = 'all'
    test_module_setup = True
    test_collector_obj = CollectorMetaDataCollector(gather_subset=test_gather_subset,
                                                    module_setup=test_module_setup)
    test_facts_dict = test_collector_obj.collect(module=None, collected_facts=test_collected_facts)
    assert test_facts_dict['gather_subset'] == test_gather_subset
    assert test_facts_dict['module_setup'] == test_module_setup

# Generated at 2022-06-20 16:51:33.922140
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector = CollectorMetaDataCollector(gather_subset = ['all'])

    fact = collector.collect(None, None)
    assert (type(fact) is dict), "Unittest must return a dictionary"
    assert ('gather_subset' in fact), "Unittest must return a dictionary include key ['gather_subset']"
    assert (type(fact['gather_subset']) is list), "gather_subset must be a list"
    assert (fact['gather_subset'] == ['all']), "gather_subset must be equal to ['all']"
    assert ('module_setup' in fact), "Unittest must return a dictionary include key ['module_setup']"
    assert (type(fact['module_setup']) is bool), "module_setup must be a bool"

# Generated at 2022-06-20 16:51:39.334880
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=None,
                                   module_setup=True)
    ansible_facts = collector_meta_data_collector.collect()
    assert ansible_facts['gather_subset'] == 'base'
    assert ansible_facts['module_setup'] == True


# Generated at 2022-06-20 16:51:59.923407
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    test_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert isinstance(test_collector, AnsibleFactCollector)

# Generated at 2022-06-20 16:52:04.531976
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Test case where no filters are passed
    fc = AnsibleFactCollector()
    fd = fc.collect()
    assert fd == {}

    # Test case where filter list has a value
    fc = AnsibleFactCollector(filter_spec=['ansible_foo'])
    fd = fc.collect()
    assert fd == {}

    # Test case where filter list has no value
    fc = AnsibleFactCollector(filter_spec=[])
    fd = fc.collect()
    assert fd == {}

# Generated at 2022-06-20 16:52:16.161249
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    from ansible.module_utils.facts import default_collectors

    collectors = get_ansible_collector(all_collector_classes=default_collectors())

    # there is one CollectorMetaDataCollector in the end
    assert 2 == len(collectors.collectors)

    # and the first one should be the default network
    assert isinstance(collectors.collectors[0], ansible.module_utils.facts.collector.network.NetworkCollector)

    # and the second one should be the metadata collector
    assert isinstance(collectors.collectors[1], CollectorMetaDataCollector)

    # and the metadata collector should have data
    metadata_collector = collectors.collectors[1]

    assert ['*'] == metadata_collector.gather_subset

# Generated at 2022-06-20 16:52:24.969489
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = [
        collector.BaseCollector,
        collector.FacterFactCollector,
        collector.OhaiFactCollector,
        collector.NetworkCollector,
        collector.PlatformCollector
    ]
    test_gather_subset = 'all'
    test_module_setup = True

    test_collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset=test_gather_subset, module_setup=test_module_setup)

    assert test_collector_meta_data_collector.gather_subset == test_gather_subset
    assert test_collector_meta_data_collector.module_setup == test_module_setup


# Generated at 2022-06-20 16:52:34.370469
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector()
    assert(collector_meta_data_collector.collectors is None)
    assert(collector_meta_data_collector.namespace is None)
    assert(collector_meta_data_collector.gather_subset is None)
    assert(collector_meta_data_collector.module_setup is None)

# Unit test that CollectorMetaDataCollector collects the gather_subset correctly.

# Generated at 2022-06-20 16:52:46.326016
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Use module_utils.facts.collector.COLLECTOR_LIST of collectors as
    # the list of all collectors to choose from.

    fact_collector = \
        get_ansible_collector(all_collector_classes=collector.COLLECTOR_LIST)

    # This gather_subset has no collectors
    fact_collector = \
        get_ansible_collector(all_collector_classes=collector.COLLECTOR_LIST,
                              gather_subset=['none'])

    # This gather_subset has only the as configured subset of collectors
    # and the metadata collector (as configured).
    minimal_gather_subset = frozenset('min')

# Generated at 2022-06-20 16:52:57.574589
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes = []
    """
    # Not needed
    collector_classes.append(collector.GenericFactCollector)
    collector_classes.append(collector.PlatformFactCollector)
    """
    collector_classes.append(collector.OhaiFactCollector)
    collector_classes.append(collector.FacterFactCollector)

    ansible_fact_collector = get_ansible_collector(collector_classes=collector_classes)
    assert(ansible_fact_collector)

    collected_facts = ansible_fact_collector.collect_with_namespace()
    assert(collected_facts)
    assert(collected_facts['ansible_architecture'])

# Generated at 2022-06-20 16:53:05.958450
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Test constructor
    collector_meta_data_collector = CollectorMetaDataCollector('', '', '', '')
    assert collector_meta_data_collector.name == 'gather_subset'
    assert collector_meta_data_collector._fact_ids == set([])

    # Test `collect` method
    assert 'gather_subset' in collector_meta_data_collector.collect()



# Generated at 2022-06-20 16:53:10.327476
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # construct with collectors, namespace, filter_spec, gather_subset
    # gather_subset is no longer an argument to AnsibleFactCollector
    my_collector = AnsibleFactCollector(
        collectors=[],  # empty collectors
        namespace=None,  # no namespace
        filter_spec=None)  # no filter_spec
    assert my_collector and isinstance(my_collector, AnsibleFactCollector)



# Generated at 2022-06-20 16:53:21.428661
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual

    fact_collector = AnsibleFactCollector()
    fact_collector.collectors.extend(
        [
            distribution.Distribution(),
            hardware.Hardware(),
            network.Network(),
            virtual.Virtual()
        ]
    )

    fact_dict = fact_collector.collect()
    assert(fact_dict['distribution'] == 'Debian')
    assert(fact_dict['distribution_major_version'] == '8')
    assert(fact_dict['distribution_release'] == 'jessie')
    assert(fact_dict['distribution_version'] == '8.9')
   

# Generated at 2022-06-20 16:53:42.994189
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # we need _fact_ids here to get past hasattr() inside AnsibleFactCollector
    collector.BaseFactCollector._fact_ids = set([])

    fact_collector = AnsibleFactCollector()
    assert fact_collector.namespace.prefix == 'ansible_'

    fact_collector = AnsibleFactCollector(namespace='ohai')
    assert fact_collector.namespace.prefix == 'ohai'

# Generated at 2022-06-20 16:53:53.886935
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    assert CollectorMetaDataCollector(
        gather_subset='all',
        module_setup=True).collect() == {
            'gather_subset': 'all',
            'module_setup': True,
    }
    assert CollectorMetaDataCollector(
        gather_subset='min',
        module_setup=False).collect() == {
            'gather_subset': 'min',
            'module_setup': False,
    }
    assert CollectorMetaDataCollector(
        gather_subset='none',
        module_setup=True).collect() == {
            'gather_subset': 'none',
            'module_setup': True,
    }

# Generated at 2022-06-20 16:54:01.146818
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    namespace = collector.namespace.PrefixFactNamespace(prefix='ansible_')

    fact_collector = AnsibleFactCollector(collectors=None,
                                          namespace=namespace)

    assert fact_collector.__class__.__name__ == 'AnsibleFactCollector'


# Generated at 2022-06-20 16:54:02.752111
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-20 16:54:08.809858
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Args
    gather_subset = ['all']
    module_setup = True

    # Constructor
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset,
                                                               module_setup=module_setup)

    # Asserts
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True



# Generated at 2022-06-20 16:54:14.306907
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = []
    gather_subset = ['all']
    module_setup = True
    collector = CollectorMetaDataCollector(collectors, None, gather_subset, module_setup)
    assert collector.gather_subset == ['all']
    assert collector.module_setup == True



# Generated at 2022-06-20 16:54:25.355530
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts.collector.network as network
    import ansible.module_utils.facts.collector.platform as platform
    import ansible.module_utils.facts.collector.system as system

    all_collectors = [
        network.NetworkCollector,
        network.DefaultNetworkCollector,
        platform.PlatformCollector,
        system.SystemCollector,
        ]

    '''
    Confirm that a valid specs for collector classes are returned from
    get_ansible_collector()
    '''

    # Test 1: all specified for gather_subset=, filter_spec=None
    collector = get_ansible_collector(all_collector_classes=all_collectors,
                                      gather_subset=['all'],
                                      filter_spec=None)

# Generated at 2022-06-20 16:54:34.684756
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Non-namespaced  collector
    c1 = collector.BaseFactCollector()
    c1.name = 'c1'
    # Namespaced collector
    n_ns = 'ns1.ns2'
    c2 = collector.BaseFactCollector(namespace=n_ns)
    c2.name = 'c2'

    # Test constructor
    f1 = AnsibleFactCollector(collectors=[c1, c2], namespace=None)
    # Test for accessing collector object
    assert f1.collectors[0] == c1
    # Test for namespace
    assert f1.collectors[1].namespace == n_ns

# Generated at 2022-06-20 16:54:41.192678
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual

    all_collector_classes = \
        [distribution.Distribution,
         hardware.Hardware,
         network.Network,
         virtual.Virtual]

    collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                      gather_subset=['all'])

    new_facts = collector.collect()
    assert len(new_facts) > 0

    for fact_name, fact_value in new_facts.items():
        assert 'ansible_' in fact_name

# Generated at 2022-06-20 16:54:46.709954
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.collector import \
        NetworkFactCollector, FilesystemFactCollector, \
        HardwareFactCollector, VirtualizationFactCollector, \
        OperatingSystemFactCollector, PlatformFactCollector, \
        AllSubsetFactCollector

    mock_collector_classes = [
        NetworkFactCollector,
        OperatingSystemFactCollector,
        PlatformFactCollector,
        VirtualizationFactCollector,
        HardwareFactCollector,
        FilesystemFactCollector,
        AllSubsetFactCollector,
    ]

    mock_filter_spec = ['ansible_network*']
    mock_gather_timeout = 10
    mock_gather_subset = ['all', 'network']
    mock_minimal_gather_subset = frozenset(['all'])

    fact_collect

# Generated at 2022-06-20 16:55:25.820430
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespaces
    nspc = namespaces.PrefixFactNamespace(prefix='test_')
    from ansible.module_utils.facts.collectors import network
    collectors = [network.NetworkCollector(namespace=nspc)]
    filter_spec = ['test_fqdn', 'test_nics']
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          filter_spec=filter_spec,
                                          namespace=nspc)
    return fact_collector

# Generated at 2022-06-20 16:55:37.910751
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    try:
        import ansible.module_utils.facts.collector.platform.linux
    except ImportError:
        raise ImportError("Unable to import ansible.module_utils.facts.collector.platform.linux. "
                          "This is required to run the unittests for get_ansible_collector. "
                          "Please install python-dev and make sure python-devel is available. "
                          "Once this package has been installed and this module can be imported "
                          "re-run the unittest.")


# Generated at 2022-06-20 16:55:40.990209
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector(filter_spec='*')
    assert fact_collector.filter_spec == '*'
    fact_collector = AnsibleFactCollector()
    assert fact_collector.filter_spec is None


# Generated at 2022-06-20 16:55:42.164676
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ansible_fact_collector = AnsibleFactCollector()
    assert ansible_fact_collector


# Generated at 2022-06-20 16:55:45.018537
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    result = collector_meta_data_collector.collect()

    assert result['gather_subset'] == ['all']
    assert result['module_setup'] == True

# Generated at 2022-06-20 16:55:56.448407
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''
    Test get_ansible_collector with no args
    '''

    all_collector_classes = CollectorMetaDataCollector.__subclasses__()

    fact_collector = get_ansible_collector(all_collector_classes)
    # to trigger facts gathering
    collected_facts = fact_collector.collect()

    feature_flag = 'ansible_fact_gather_subset'

    # feature flag should be added to the collected facts
    assert feature_flag in collected_facts

    # check that the feature flag is True
    assert collected_facts[feature_flag] == ['all']

    # Therefore fact_collector collects facts for all collectors
    for fact_collector_class in all_collector_classes:
        assert fact_collector_class is not None

# Generated at 2022-06-20 16:56:04.324409
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_gather_subset = ['one', 'two']
    test_module_setup = True
    test_collector_object = CollectorMetaDataCollector(gather_subset=test_gather_subset,
                                                       module_setup=test_module_setup)
    assert test_collector_object.collect() == {'gather_subset' : test_gather_subset, 'module_setup' : test_module_setup}

# Generated at 2022-06-20 16:56:14.018940
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    c = CollectorMetaDataCollector(gather_subset=['all', 'foo'])
    assert c.gather_subset == ['all', 'foo']

    c = CollectorMetaDataCollector(gather_subset=['all'])
    assert c.gather_subset == ['all']

    c = CollectorMetaDataCollector()
    assert c.gather_subset == ['all']

#  vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 16:56:17.459066
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_obj = CollectorMetaDataCollector('all')
    assert collector_obj.collect() == {'gather_subset': 'all'}
    collector_obj = CollectorMetaDataCollector('network', 'ansible_')
    assert collector_obj.collect() == {'gather_subset': 'network'}