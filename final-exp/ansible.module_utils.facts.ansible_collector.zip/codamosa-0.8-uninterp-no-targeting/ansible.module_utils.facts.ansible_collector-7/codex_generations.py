

# Generated at 2022-06-20 16:46:35.096973
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['min'],
                                   module_setup=True)

    meta_facts = \
        collector_meta_data_collector.collect(module=None,
                                              collected_facts=None)
    assert meta_facts == {'gather_subset': ['min'],
                          'module_setup': True}



# Generated at 2022-06-20 16:46:46.084421
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import pytest

    fake_collector_fact = {'ansible_fake_collector_fact': 'ansible_fake_collector_fact'}
    fake_collector_fact_namespace = {'ansible_facts_fake_collector': fake_collector_fact}

    fake_collector = collector.BaseFactCollector(None, 'fake_collector')
    fake_collector.collect = lambda module, collected_facts: fake_collector_fact_namespace
    fake_collector.fact_ids = lambda: {'ansible_fake_collector_fact'}

    fact_collector = AnsibleFactCollector(collectors=[fake_collector])

    ansible_facts = fact_collector.collect()
    assert ansible_facts == fake_collector_fact

    # Use with namespace
    fake

# Generated at 2022-06-20 16:46:55.508756
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    metafacts = {'gather_subset': ['all']}
    test_collector = CollectorMetaDataCollector(None, None, None, True)
    assert test_collector.collect(None, None) == metafacts
    test_collector = CollectorMetaDataCollector(None, None, ['network'], False)
    assert test_collector.collect(None, None) == {'gather_subset': ['network']}
    test_collector = CollectorMetaDataCollector(None, None, ['all'], False)
    assert test_collector.collect(None, None) == {'gather_subset': ['all']}
    test_collector = CollectorMetaDataCollector(None, None, '*', True)
    assert test_collector.collect(None, None) == metafacts
    test

# Generated at 2022-06-20 16:46:58.391068
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector(collectors=[], namespace=None)
    assert fact_collector is not None

# Generated at 2022-06-20 16:47:08.140424
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    namespace = PrefixFactNamespace(prefix='test_')
    namespace_no_prefix = FactNamespace()

    gather_subset = {'all'}
    module_setup = True
    metadata_collector = CollectorMetaDataCollector(namespace=namespace,
                                                    gather_subset=gather_subset,
                                                    module_setup=module_setup)
    assert metadata_collector.gather_subset == gather_subset
    assert metadata_collector.module_setup == module_setup
    metadata_collector_no_namespace = CollectorMetaDataCollector(module_setup=module_setup)

# Generated at 2022-06-20 16:47:14.348748
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import BaseFactCollector, AnsibleCollector

    class FakeCollector(BaseFactCollector):

        name = 'fake'
        _fact_ids = set(['fake_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'fake': 'fake'}

    def test_ansible_collector_obj():
        fact_collector = get_ansible_collector(all_collector_classes=[FakeCollector])
        isinstance(fact_collector, AnsibleFactCollector)

    def test_filter():
        fact_collector = get_ansible_collector(all_collector_classes=[FakeCollector],
                                               filter_spec='f*')
        ansible_facts = fact_collector.collect()


# Generated at 2022-06-20 16:47:25.298756
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes = \
        collector.collector_classes_from_gather_subset(['all'],
                                                       frozenset(['all']),
                                                       timeout.DEFAULT_GATHER_TIMEOUT,
                                                       timeout.DEFAULT_GATHER_TIMEOUT)
    fact_collector = get_ansible_collector(all_collector_classes)

    collected_facts = fact_collector.collect(collected_facts={})

    assert 'ansible_facts' in collected_facts
    assert 'gather_subset' in collected_facts['ansible_facts']

# Generated at 2022-06-20 16:47:39.218543
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace

    # test basic creation
    afc = AnsibleFactCollector(namespace=namespace.EmptyNamespace())
    assert (afc.namespace.__class__.__name__ == 'EmptyNamespace')
    assert (afc.collectors == [])
    assert (afc.filter_spec == [])

    # test creation with collectors and filter_spec
    afc = AnsibleFactCollector(collectors=[1, 2, 3],
                               filter_spec=['a', 'b'],
                               namespace=namespace.EmptyNamespace())
    assert (afc.collectors == [1, 2, 3])
    assert (afc.filter_spec == ['a', 'b'])

    # test creation with namespace

# Generated at 2022-06-20 16:47:43.192357
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    f = get_ansible_collector([ansible.module_utils.facts.collector.network.NetworkCollector])
    print(f.collect())

# Generated at 2022-06-20 16:47:47.832603
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    info_dict_expected = {'gather_subset' : 'all', 'module_setup' : True}
    metadata_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    info_dict = metadata_collector.collect()
    assert info_dict == info_dict_expected


# Generated at 2022-06-20 16:47:58.823308
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    mdc = CollectorMetaDataCollector(gather_subset='facter',
                                     module_setup=True)
    expected = {'gather_subset': 'facter', 'module_setup': True}
    assert expected == mdc.collect()
    # as above but with gather_subset = True and module_setup = False
    mdc = CollectorMetaDataCollector(gather_subset=True,
                                     module_setup=False)
    expected = {'gather_subset': True, 'module_setup': False}
    assert expected == mdc.collect()

# Generated at 2022-06-20 16:48:02.372441
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset='all',
                                                module_setup=True)
    expected_meta_facts = {'gather_subset': 'all',
                           'module_setup': True}
    meta_facts_dict = fact_collector.collect()
    assert meta_facts_dict == expected_meta_facts



# Generated at 2022-06-20 16:48:12.381900
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    all_collector_classes = ansible.module_utils.facts.collector.all_collector_classes
    class Ubuntu(object):
        name = 'ubuntu'

    class Debian(object):
        name = 'debian'

    class RedHat(object):
        name = 'redhat'

    class OpenSUSE(object):
        name = 'opensuse'

    class Alpine(object):
        name = 'alpine'

    class DebianCollector(object):
        # does not subclass BaseFactCollector, but it's close enough
        name = 'debian'

    all_collector_classes = {}
    for cls in [Ubuntu, Debian, RedHat, OpenSUSE, Alpine, DebianCollector]:
        all_collector_classes[cls.name] = cl

# Generated at 2022-06-20 16:48:22.460068
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import system

    fact_collector = get_ansible_collector(all_collector_classes=[system.SystemCollector])
    assert fact_collector
    assert fact_collector.gather_subset
    assert fact_collector.gather_subset == ['all']

    fact_collector = get_ansible_collector(all_collector_classes=[system.SystemCollector],
                                           gather_subset=['all'])
    assert fact_collector
    assert fact_collector.gather_subset
    assert fact_collector.gather_subset == ['all']

    fact_collector = get_ansible_collector(all_collector_classes=[system.SystemCollector],
                                           gather_subset=['network'])

# Generated at 2022-06-20 16:48:31.903346
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace

    # In this test case, we will create two collector_obj: ns1 and ns2
    # ns1 has two collectors: c1 and c2
    # ns2 has two collectors: c2 and c3
    # So we expect to get a c1, c2 and c3 object in the fact_collector

    ns1 = namespace.PrefixFactNamespace(prefix='ns1_')
    c1 = collector.FactCollectorData('c1', 'c1', 'c1')
    c2 = collector.FactCollectorData('c2', 'c2', 'c2')
    ns1_collectors = [c1, c2]

    ns2 = namespace.PrefixFactNamespace(prefix='ns2_')

# Generated at 2022-06-20 16:48:35.144685
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_obj = CollectorMetaDataCollector(gather_subset='all')
    assert collector_obj.gather_subset == ['all']



# Generated at 2022-06-20 16:48:44.744339
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    gather_subset = ['all']
    module_setup = True

    ansible_collector = CollectorMetaDataCollector(module_setup=module_setup,
                                                   gather_subset=gather_subset)
    assert isinstance(ansible_collector, BaseFactCollector)


# Generated at 2022-06-20 16:48:49.707030
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    class_obj = CollectorMetaDataCollector(gather_subset=['!all'], module_setup=True)
    assert class_obj.collect() == {'gather_subset': ['!all'], 'module_setup': True}



# Generated at 2022-06-20 16:48:59.432670
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collectors.base

    class DummyCollector(ansible.module_utils.facts.collectors.base.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'dummy_key': 'dummy_value'}

    fact_collector = \
        AnsibleFactCollector(collectors=[
            DummyCollector(),
            DummyCollector(),
        ])

    facts = fact_collector.collect()
    assert facts == {'dummy_key': 'dummy_value'}

# Unit test that when a fact is added with a namespace, it is placed under the namespace key in
# the facts dictionary.

# Generated at 2022-06-20 16:49:06.037884
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes = [collector.FacterFactCollector,
                             collector.OhaiFactCollector]

    collector_classes = get_ansible_collector(all_collector_classes).collectors
    assert len(collector_classes) == 1
    assert collector_classes[0].__class__ == collector.FacterFactCollector

# Generated at 2022-06-20 16:49:13.422771
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert(True)

# Generated at 2022-06-20 16:49:18.385038
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_metadata_collector = CollectorMetaDataCollector()
    assert test_metadata_collector.gather_subset == None
    assert test_metadata_collector.module_setup == None
    assert test_metadata_collector.name == 'gather_subset'

# Generated at 2022-06-20 16:49:30.139246
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ''' Execute test for method collect of class CollectorMetaDataCollector '''
    collectors = []
    namespace = None
    gather_subset = 'all'
    module_setup = True
    collector_meta_data_collector = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)
    result = collector_meta_data_collector.collect()
    actual_keys = result.keys()
    expected_keys = ['gather_subset', 'module_setup']
    assert sorted(actual_keys) == sorted(expected_keys)
    assert result['gather_subset'] == gather_subset
    assert result['module_setup'] == module_setup



# Generated at 2022-06-20 16:49:39.021419
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ansible_fact_collector = get_ansible_collector(
        all_collector_classes=collector.collector_classes(),
        gather_subset=['all'],
        filter_spec=[],
        gather_timeout='10.0',
        minimal_gather_subset=['all'],
    )
    assert type(ansible_fact_collector) == AnsibleFactCollector
    assert len(ansible_fact_collector.collectors) > 1


# Generated at 2022-06-20 16:49:46.347633
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(['all'], None)
    collected_facts = collector_meta_data_collector.collect()

    # assert that we got the right collected facts
    assert collected_facts['gather_subset'] == ['all']
    assert collected_facts['module_setup'] == True


# Generated at 2022-06-20 16:49:52.672990
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_facts = CollectorMetaDataCollector(namespace='options').collect()
    assert meta_facts == {'gather_subset': 'options'}

    meta_facts = CollectorMetaDataCollector(namespace='options',
                                            gather_subset=['all']).collect()
    assert meta_facts == {'gather_subset': ['all']}

    meta_facts = CollectorMetaDataCollector(gather_subset=['races']).collect()
    assert meta_facts == {'gather_subset': ['races']}

    meta_facts = CollectorMetaDataCollector(gather_subset=['races']).collect()
    assert meta_facts == {'gather_subset': ['races']}


# Generated at 2022-06-20 16:50:02.593898
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    mock_collector_class = collector.BaseFactCollector
    mock_collector_class_name = "ansible.module_utils.facts.collector.BaseFactCollector"
    mock_collector_obj = mock_collector_class(namespace=None,
                                              collectors=[])
    mock_fact_collector = AnsibleFactCollector(collectors=[mock_collector_obj],
                                               filter_spec=None,
                                               namespace=None)
    mock_fact_collector.collect(collected_facts=None)


# Generated at 2022-06-20 16:50:14.742984
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit test for function get_ansible_collector.'''

    try:
        from ansible.module_utils.facts.collector import all_collector_classes
    except ImportError:
        # Ansible platform is not compatible
        return

    # Get all the collector classes
    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=frozenset(),
            gather_subset=['all'],
            gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT)

    # Make sure we got some
    assert collector_classes

    # Make sure we got the ones that are supposed to be in minimal
    minimal_collector_classes = \
        collector.collector_classes_

# Generated at 2022-06-20 16:50:22.654223
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # create mock module
    class MockModule:
        def __init__(self):
            self.params = {}
    module = MockModule()
    
    # create test object
    collector = CollectorMetaDataCollector([], namespace=None, 
                                           gather_subset=['all'], module_setup=True)
    
    # test method
    result = collector.collect(module=module)
    
    assert result == {'module_setup': True, 'gather_subset': ['all']}

# Generated at 2022-06-20 16:50:32.560761
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    #Setup some mock collectors
    class MockCollector1(collector.BaseFactCollector):
        name = 'mock1'
        _fact_ids = set(['mock1_fact1', 'mock1_fact2'])
        def collect(self, module=None, collected_facts=None):
            mock_facts = {'mock1_fact1': 'mock1_fact1_value', 'mock1_fact2': 'mock1_fact2_value'}
            return mock_facts

    class MockCollector2(collector.BaseFactCollector):
        name = 'mock2'
        _fact_ids = set(['mock2_fact1', 'mock2_fact2'])

# Generated at 2022-06-20 16:50:45.984112
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector = get_ansible_collector(all_collector_classes={}, gather_subset='network')
    assert collector.collectors
    assert collector.namespace
    assert collector.filter_spec

# Generated at 2022-06-20 16:50:50.954286
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespaces

    fact_collector = get_ansible_collector(all_collector_classes=collector_classes.ALL,
                                           gather_subset=[],
                                           gather_timeout=1,
                                           minimal_gather_subset=[])

    fact_collector.collect()
    assert fact_collector.collectors

    namespace = namespaces.PrefixFactNamespace('ansible_')
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes.ALL,
                                           namespace=namespace,
                                           gather_subset=[],
                                           gather_timeout=1,
                                           minimal_gather_subset=[])
   

# Generated at 2022-06-20 16:50:59.534645
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'])
    facts = fact_collector.collect()
    assert facts['module_setup'] is True
    assert facts['gather_subset'] == ['all']

    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=False)
    facts = fact_collector.collect()

    assert 'module_setup' not in facts
    assert facts['gather_subset'] == ['all']

# Generated at 2022-06-20 16:51:11.726642
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.legacy
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.user


# Generated at 2022-06-20 16:51:23.046366
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # mock the class
    class MockFactsCollector(collector.BaseFactCollector):
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {"name1": "value1", "name2": "value2"}

    # assume that a "mock_module" with a "fail_json" method is provided
    mock_module = None
    mock_module = Mock()
    mock_module.fail_json = Mock()

    # create a collector and provide some values for it
    mock_collector = MockFactsCollector(namespace='mock')
    collected_facts = {}

    # assert that a dictionary is returned by the method "collect" of AnsibleFactCollector

# Generated at 2022-06-20 16:51:32.844709
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collectors.base import BaseFactCollector

    all_collector_classes = [BaseFactCollector]

    fact_collector = AnsibleFactCollector(collectors=[],
                                          namespace=PrefixFactNamespace(prefix='ansible_'))
    assert fact_collector.collect() == {}

    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=PrefixFactNamespace(prefix='ansible_'))
    assert 'ansible_facts' in fact_collector.collect()

# Generated at 2022-06-20 16:51:45.267767
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import network

    # This is essentially a copy of the all_collector_classes from __init__.py
    all_collector_classes = [
        namespace.PrefixFactNamespace,
        network.NetworkFactCollector,
        network.HardwareFactCollector,
        network.VirtualizationFactCollector,
        network.DefaultInterfacesFactCollector,
    ]

    filter_spec = ['ansible_default_ipv4', 'ansible_default_interface']

    gather_subset = ['network', 'default']
    gather_timeout = 10
    minimal_gather_subset = frozenset(['network'])


# Generated at 2022-06-20 16:51:55.652604
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import unittest
    from ansible.module_utils.facts import ansible_virtual, ansible_default, ansible_network

    class FakeNetwork(ansible_network.NetworkFactCollector):
        """A fake NetworkFactCollector
        That just return 'ok' for network facts to not have to mock facts
        when testing the Collector itself. """

        def collect(self, module=None, collected_facts=None):
            return {'all_ipv4_addresses': ['ok'],
                    'all_ipv6_addresses': ['ok'],
                    'default_ipv4': 'ok',
                    'default_ipv6': 'ok'}


# Generated at 2022-06-20 16:52:01.948571
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollector(object):
        def collect_with_namespace(self, *args, **kwargs):
            return {'foo': {'bar': 'baz'}}
    collector = AnsibleFactCollector(collectors=[MockCollector()])
    result = collector.collect()
    assert result == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-20 16:52:15.072108
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_module = None
    test_collected_facts = {}

    key = 'test_collector'
    test_value = 'test_value'
    test_dict = {key: test_value}

    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return test_dict

    test_collector_list = [TestCollector()]
    test_AnsibleFactCollector = AnsibleFactCollector(collectors=test_collector_list)

    expected_result = test_dict
    test_result = test_AnsibleFactCollector.collect(module=test_module,
                                                    collected_facts=test_collected_facts)
    assert expected_result == test_result

    test_AnsibleFactCollector_2

# Generated at 2022-06-20 16:52:56.225440
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Make sure we can use get_ansible_collector() to gather ALL facts
    from ansible.module_utils.facts import all_collector_classes
    fact_collector = get_ansible_collector(all_collector_classes)
    facts = fact_collector.collect()

if __name__ == "__main__":
    test_get_ansible_collector()

# Generated at 2022-06-20 16:53:07.452908
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # This is the method we are testing
    from ansible.module_utils.facts import ansible_collector as ansible_collector
    collector = ansible_collector.CollectorMetaDataCollector(gather_subset='all',
                                                             module_setup=True)
    facts = collector.collect()

    # We expect to receive a dictionary whose keys are 'gather_subset' and 'module_setup'
    assert 'gather_subset' in facts
    assert 'module_setup' in facts

    assert facts['gather_subset'] == 'all'
    assert facts['module_setup'] is True



# Generated at 2022-06-20 16:53:19.818317
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    namespace = PrefixFactNamespace(prefix='ansible_')
    filter_spec = ['*']
    gather_subset = ['all']
    gather_timeout = 10

    fact_collector = \
        get_ansible_collector(
            all_collector_classes=[DistributionFactCollector],
            namespace=namespace,
            filter_spec=filter_spec,
            gather_subset=gather_subset,
            gather_timeout=gather_timeout)

   

# Generated at 2022-06-20 16:53:24.593975
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_data_collector = collector.CollectorMetaDataCollector(gather_subset=['!all', 'network'])
    meta_data_facts = meta_data_collector.collect()
    assert meta_data_facts['gather_subset'] == ['!all', 'network']


# Generated at 2022-06-20 16:53:33.747563
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespaced_fact_collector
    collectors = []
    filter_spec = []
    namespace = namespaced_fact_collector.PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(collectors=collectors, filter_spec=filter_spec, namespace=namespace)
    assert isinstance(fact_collector, AnsibleFactCollector)


# Generated at 2022-06-20 16:53:39.670216
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    fact_collector = \
        AnsibleFactCollector(collectors=[DistributionFactCollector(namespace=None)])

    # Collect facts
    facts = fact_collector.collect()
    assert facts['distribution'] == 'unknown'

# Generated at 2022-06-20 16:53:43.298868
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    class TestNamespace(object):
        def get_prefix(self):
            return 'test_'

    test_collector_metadata_collector = \
        CollectorMetaDataCollector(namespace=TestNamespace())
    assert test_collector_metadata_collector.namespace.get_prefix() == 'test_'

# Generated at 2022-06-20 16:53:54.944522
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.network.interfaces

    # Basic test of constructor, like what is done in the module in the module for most
    # gather_subsets.
    all_collector_classes = \
        ansible.module_utils.facts.collector.get_collectors_for_platform('all')
    fact_collector = \
        get_ansible_collector(all_collector_classes,
                              gather_subset=['all'],
                              filter_spec=['*'])

    # fact_collector should have a few known attributes/methods
    assert fact_collector.namespace == None
    assert fact_collector.collectors != []
    assert fact_collector.filter_spec == ['*']
    assert fact_collector.filter != None

    # This is a function

# Generated at 2022-06-20 16:54:01.374209
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    mdc = CollectorMetaDataCollector(gather_subset=None,
                                     module_setup=None)
    result = mdc.collect(module=None,
                         collected_facts=None)

    assert result == {'gather_subset': None}

# Generated at 2022-06-20 16:54:10.936210
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''
    A unit test that exercises the collect() method of class AnsibleFactCollector.
    '''
    # Arrange:
    # Create two mocks to simulate facts gathered by two collectors
    # facts_1 = {'fact_1': 'value_1'}
    # facts_2 = {'fact_2': 'value_2'}
    #
    # Create a Mock that simulates the method collect_with_namespace() invoked on each collector
    from mock import Mock
    collect_with_namespace_method_mock = Mock(return_value={})
    #
    # Create two mock instances to represent the two collectors
    collectors = []
    collector_mock_1 = Mock(spec=collector.BaseFactCollector)
    collector_mock_2 = Mock(spec=collector.BaseFactCollector)


# Generated at 2022-06-20 16:54:36.999406
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import timeout

    class CollectorA(collector.BaseFactCollector):

        name = 'a'

        def collect(self, module=None, collected_facts=None):
            info_dict = {}
            info_dict['a0'] = 'a0'
            info_dict['a1'] = 'a1'
            return info_dict

    class CollectorB(collector.BaseFactCollector):

        name = 'b'

        def collect(self, module=None, collected_facts=None):
            info_dict = {}
            info_dict['b0'] = 'b0'
            info_dict['b1'] = 'b1'
            return info_dict

    collectors = []
    collectors.append(CollectorA(namespace=None))

# Generated at 2022-06-20 16:54:42.064678
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.namespace
    meta_collector = CollectorMetaDataCollector(namespace=ansible.module_utils.facts.namespace.BaseFactNamespace())
    assert meta_collector.collect() == {'gather_subset': None}

# Generated at 2022-06-20 16:54:54.062805
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import platform
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.os

    all_collector_classes = collector.get_collector_classes()

    namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')
    collector_class = ansible.module_utils.facts.system.platform.PlatformFactCollector
    collector_obj = collector.BaseFactCollector(namespace=namespace)
    collectors = [collector_obj, ]

    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=namespace)
    assert fact_collector is not None
    facts

# Generated at 2022-06-20 16:55:05.795639
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import platform
    import json

    from ansible.module_utils.facts.collector import SetupFactsCollector, FacterCollector, OhaiCollector

    from ansible.module_utils.facts import default_collectors
    default_collectors_set = set(default_collectors)

    class TestCollector(collector.BaseFactCollector):
        name = 'mock_collector'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return module.params

    fact_collector = \
        AnsibleFactCollector(collectors=[TestCollector()])

    params = {'a': 'b', 'c': {'d': 'e'}, 'data': {'f': 1}, 'g': platform.platform()}
    # Note: 'filter_

# Generated at 2022-06-20 16:55:09.194228
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': ['all']}


# Generated at 2022-06-20 16:55:13.534176
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.collector
    collector_1 = CollectorMetaDataCollector(gather_subset='!all')
    ansible.module_utils.facts.collector = collector_1
    assert ansible.module_utils.facts.collector.collect() == {'module_setup': True, 'gather_subset': '!all'}

# Generated at 2022-06-20 16:55:25.916071
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Valid gather_subset
    gather_subset1 = ['all', 'network']
    # Invalid gather_subset
    gather_subset2 = ['all', 'network', 'foobar']
    # Invalid gather_subset
    gather_subset3 = None

    collector_meta_data_collector1 = CollectorMetaDataCollector(gather_subset=gather_subset1)
    result1 = collector_meta_data_collector1.collect()
    assert result1['gather_subset'] == gather_subset1

    try:
        collector_meta_data_collector2 = CollectorMetaDataCollector(gather_subset=gather_subset2)
    except:
        pass
    else:
        raise Exception("gather_subset2 should not be valid")


# Generated at 2022-06-20 16:55:34.126717
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """This test checks method collect of class CollectorMetaDataCollector"""
    # arrange
    collector_obj = CollectorMetaDataCollector(gather_subset=['all', 'network'])

    # act
    result = collector_obj.collect()

    # assert
    assert len(result) == 2
    assert 'gather_subset' in result
    assert result['gather_subset'] == ['all', 'network']

# Generated at 2022-06-20 16:55:45.817306
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''Test CollectorMetaDataCollector constructor'''

    from facts import all_collectors

    fact_collector = get_ansible_collector(all_collector_classes=all_collectors)
    info_dict = fact_collector.collect()
    assert 'gather_subset' in info_dict
    assert 'module_setup' in info_dict
    assert info_dict['gather_subset'] == ['all']
    assert info_dict['module_setup'] is True

    fact_collector = get_ansible_collector(all_collector_classes=all_collectors,
                                           gather_subset=['network'])

    info_dict = fact_collector.collect()
    assert 'gather_subset' in info_dict
    assert 'module_setup' in info_dict

# Generated at 2022-06-20 16:55:46.660652
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    pass

# Generated at 2022-06-20 16:56:24.901307
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local

    # ansible_local is a FactCollector that provides 'local_facts' under the 'ansible' namespace
    # which is the default prefix for AnsibleFactsCollector
    local_facts_collector = ansible_local.AnsibleLocalFactNamespace(module=None)

    # ansible_collector is a FactCollector that provides 'collector_facts' under the 'ansible' namespace
    collector_facts_collector = ansible_collector.AnsibleCollectorFactNamespace(module=None)

    fact_collector = AnsibleFactCollector(collectors=[local_facts_collector, collector_facts_collector])
