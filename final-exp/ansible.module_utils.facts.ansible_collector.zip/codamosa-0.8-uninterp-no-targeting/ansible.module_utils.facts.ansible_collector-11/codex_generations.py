

# Generated at 2022-06-20 16:46:36.818308
# Unit test for method collect of class AnsibleFactCollector

# Generated at 2022-06-20 16:46:40.376632
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    coll = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert coll.collect() == {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-20 16:46:46.918436
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector
    import ansible.module_utils.facts.namespace as namespace

    expected_results = {'gather_subset': ['some_subset'], 'module_setup': True}
    fact_collector = CollectorMetaDataCollector(gather_subset=['some_subset'],
                                                module_setup=True)
    results = fact_collector.collect()
    results.pop('_timestamp')

    assert expected_results == results


# Generated at 2022-06-20 16:46:56.009628
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class FakeCollector(collector.BaseFactCollector):
        name = 'fake'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'answer': 42}

    class FakeCollector2(collector.BaseFactCollector):
        name = 'fake2'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'answer': 43}

    fake_collector = FakeCollector()
    fake_collector2 = FakeCollector2()
    fact_collector = AnsibleFactCollector(collectors=[fake_collector,
                                                      fake_collector2])
    ansible_facts = fact_collector.collect()

# Generated at 2022-06-20 16:47:02.267953
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    __tracebackhide__ = True

    import sys
    sys.path.insert(0, "..")

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactProxy
    from ansible.module_utils.facts.namespace import FactProxy

    class TestNamespace(BaseFactNamespace):

        def __init__(self, namespace=None):
            self.namespace = 'test'

        def get_facts(self):
            return {self.namespace: {'name': self.namespace, 'full_name': self.get_full_name()}}

        def get_full_name(self):
            return self.namespace


# Generated at 2022-06-20 16:47:15.521328
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # test a normal collection
    base_facts = {
        'fact1': 'hello',
        'fact3': 'world',
        'fact4': 'ansible'
    }

    class MockFactCollector(collector.BaseFactCollector):
        def collect(self):
            return base_facts

    mock_fact_collector = MockFactCollector()

    fact_collector = AnsibleFactCollector(mock_fact_collector)

    expected_facts = {
        'ansible_facts': {
            'fact1': 'hello',
            'fact3': 'world',
            'fact4': 'ansible'
        }
    }

    collected_facts = fact_collector.collect()

    assert collected_facts == expected_facts

    # test filtering of the collected facts
    fact_collector = Ansible

# Generated at 2022-06-20 16:47:26.869235
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # we need a module to be passed to the collectors
    fake_module = type('FakeModule', (object, ), {})

    # a simple fact collector class that we use for testing
    class AnsibleFactCollectorTest(collector.BaseFactCollector):
        name = 'test_fact'

        def collect(self, module=None, collected_facts=None):
            facts_dict = dict()
            facts_dict.update({self.name: 'test_value'})
            return facts_dict

    # a simple fact collector class that we use for testing
    class AnsibleFactCollectorTest1(collector.BaseFactCollector):
        name = 'test_fact1'

        def collect(self, module=None, collected_facts=None):
            facts_dict = dict()

# Generated at 2022-06-20 16:47:30.875398
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    def _collect():
        return {'test_key': 'test_value'}
    collector = {'collect': _collect}
    fact_collector = AnsibleFactCollector(collectors=[collector])
    facts = fact_collector.collect()
    assert facts == {'test_key': 'test_value'}


# Generated at 2022-06-20 16:47:36.493021
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import unittest

    class TestCollectorMetaDataCollector(unittest.TestCase):
        def test_collect(self):
            collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                                       module_setup=True)
            self.assertEqual(collector_meta_data_collector.collect(), {'gather_subset': ['all'],
                                                                       'module_setup': True})
            collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
            self.assertEqual(collector_meta_data_collector.collect(), {'gather_subset': ['all']})

    # Initialize a unittest object and run test
    test_CollectorMetaDataCollector = TestCollect

# Generated at 2022-06-20 16:47:42.598891
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    minimal_gather_subset = frozenset(['network'])
    # Should include all collectors that are in minimal_gather_subset
    c = get_ansible_collector(collector.FACT_COLLECTOR_FUNCTIONS,
                              minimal_gather_subset=minimal_gather_subset)
    assert c.collectors[0].name == 'network'
    # Should also include the meta data collector
    assert c.collectors[-1].name == 'gather_subset'

    # If gather_subset is specified then minimal_gather_subset is ignored

# Generated at 2022-06-20 16:47:58.459158
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class mock_BaseFactCollector():
        def __init__(self, namespace=None):
            pass

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class mock_AnsibleFactCollector():
        def __init__(self, collectors=None, namespace=None, filter_spec=None):
            pass

        def _filter(self, facts_dict, filter_spec):
            return facts_dict

    class mock_BaseCollector():
        def __init__(self, namespace=None):
            pass

        def collect(self):
            return {'test':['test', 'test', 'test']}


# Generated at 2022-06-20 16:48:10.564936
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.minimal

    # filter_spec=None, gather_timeout=None, minimal_gather_subset=None

# Generated at 2022-06-20 16:48:18.847400
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    obj = CollectorMetaDataCollector(gather_subset=['all'])
    assert obj.gather_subset == ['all']
    assert obj.module_setup is None

    obj = CollectorMetaDataCollector(gather_subset=['network'], module_setup=True)
    assert obj.gather_subset == ['network']
    assert obj.module_setup is True

    obj = CollectorMetaDataCollector(gather_subset=['network'], module_setup=False)
    assert obj.gather_subset == ['network']
    assert obj.module_setup is False

    obj = CollectorMetaDataCollector(gather_subset=['network'], module_setup='foo')
    assert obj.gather_subset == ['network']
    assert obj.module_setup == 'foo'

# Generated at 2022-06-20 16:48:25.747321
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts['gather_subset'] == ['all']
    assert 'module_setup' in meta_facts


# Generated at 2022-06-20 16:48:28.928871
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    expected = {
        'gather_subset': ['network'],
        'module_setup': True
    }
    collector = CollectorMetaDataCollector(gather_subset=['network'],
                                           module_setup=True)
    actual = collector.collect()
    assert expected == actual


# Generated at 2022-06-20 16:48:41.229863
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes as ansible_collectors
    ansible_collector = get_ansible_collector(
        all_collector_classes=ansible_collectors,
        filter_spec=['*'],
        gather_subset=['all', 'network'],
        gather_timeout=10,
        minimal_gather_subset=frozenset(['all']),
    )
    collected_facts = ansible_collector.collect(module=None)
    assert collected_facts['gather_subset'] == ['all', 'network']
    assert collected_facts['module_setup'] == True
    assert 'ansible_distribution' in collected_facts
    assert 'ansible_all_ipv4_addresses' in collected_facts
    return True

# Generated at 2022-06-20 16:48:44.879295
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=["all"],
                                                module_setup=False)
    assert fact_collector.gather_subset == ["all"]
    assert not fact_collector.module_setup

# Generated at 2022-06-20 16:48:57.755196
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.namespace

    namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')
    collect_classes = [i for i in dir(ansible.module_utils.facts.collectors)
                       if not i.startswith('__')]
    fact_collector = get_ansible_collector(collect_classes,
                                           minimal_gather_subset=('fact1', 'fact2'),
                                           gather_timeout=2,
                                           gather_subset=('all', 'fact1'),
                                           filter_spec=('fact1', '*fact2'))
    assert fact_collector.filter_spec == ('fact1', '*fact2')
   

# Generated at 2022-06-20 16:49:08.695982
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # create a mock collector
    class MockCollector:

        def __init__(self, foo):
            pass

        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    foo_collector = MockCollector('foo')
    foo_collector.name = 'foo'

    # create a new AnsibleFactCollector and append the mock collector
    fact_collector = AnsibleFactCollector()
    fact_collector.collectors.append(foo_collector)

    # test
    result = fact_collector.collect()

    # assert
    assert 'foo' in result
    assert result['foo'] == 'bar'

# Generated at 2022-06-20 16:49:11.839574
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Tests constructor of class AnsibleFactCollector.'''

    namespace = None
    collector_obj = AnsibleFactCollector(namespace=namespace)
    assert collector_obj.namespace is None

# Generated at 2022-06-20 16:49:15.919413
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    pass



# Generated at 2022-06-20 16:49:22.009585
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import synchronous
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    fact_collector = get_ansible_collector(synchronous.FACT_SUBSETS,
                                           namespace=PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec='ansible_*',
                                           gather_subset=['all'],
                                           gather_timeout=5,
                                           minimal_gather_subset=['hardware'])
    collected_facts = fact_collector.collect()
    assert len(collected_facts) >= 1

# Generated at 2022-06-20 16:49:25.980276
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_collector = CollectorMetaDataCollector()
    facts = collector_collector.collect()
    assert facts == {'gather_subset': [], 'module_setup': True}

# Generated at 2022-06-20 16:49:28.278772
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Verify instance can be created
    CollectorMetaDataCollector(gather_subset={'all', 'network'})


# Generated at 2022-06-20 16:49:34.810748
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_facts = {'gather_subset': ['all']}
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=None)
    result = collector_meta_data_collector.collect()
    assert result == meta_facts

# Generated at 2022-06-20 16:49:43.068318
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Start with an empty collector
    fact_collector = AnsibleFactCollector()

    # Add a fact that can be filtered with a name that starts with 'b'
    class DummyFactCollector1(collector.BaseFactCollector):
        name = 'dummy_fact_collector_1'

        def collect(self, module=None, collected_facts=None):
            return {'banana': 'fruit', 'apple': 'fruit'}

    fact_collector.add_collector(DummyFactCollector1())

    # Add a second fact that can be filtered with a name that starts with 'a'
    class DummyFactCollector2(collector.BaseFactCollector):
        name = 'dummy_fact_collector_2'

        def collect(self, module=None, collected_facts=None):
            return

# Generated at 2022-06-20 16:49:50.550222
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    collectors = \
        [collector.BaseFactCollector(),
         collector.BaseFactCollector()]

    # namespace = collector.FactNamespace()

    filter_spec = ['*']

    ansible_fact_collector = AnsibleFactCollector(collectors,
                                                  filter_spec=filter_spec)

    assert ansible_fact_collector.collectors == collectors
    assert ansible_fact_collector.filter_spec == filter_spec



# Generated at 2022-06-20 16:50:03.734625
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.virtual


# Generated at 2022-06-20 16:50:12.204480
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collectA = collector.BaseFactCollector(None, 'foo.')
    collectors = [collectA]
    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=None)

    assert fact_collector._collectors == collectors
    assert fact_collector.namespace == None

    fact_collector = AnsibleFactCollector(collectors=collectors, namespace='bar.')

    assert fact_collector._collectors == collectors
    assert fact_collector.namespace == 'bar.'

# Generated at 2022-06-20 16:50:16.919830
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.default.system import DefaultSystemFactCollector

    namespace = PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(collectors=[DefaultSystemFactCollector()],
                                          namespace=namespace)

    assert 'ansible_facts' in fact_collector.collect()



# Generated at 2022-06-20 16:50:24.616122
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ''' Test the collect method of the class CollectorMetaDataCollector.
    '''
    # create a CollectorMetaDataCollector object
    cmc = CollectorMetaDataCollector(gather_subset={}, module_setup=True)
    # obtain the result of calling collect
    result = cmc.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-20 16:50:30.723231
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_classes = [
        {'name': 'ansible_connection'},
        {'name': 'ansible_distribution'},
    ]

    fact_collector = \
        AnsibleFactCollector(collectors=collector_classes,
                             namespace=None,
                             filter_spec=None)

    assert fact_collector.collectors == collector_classes
    assert fact_collector.filter_spec is None
    assert fact_collector.namespace is None

# Generated at 2022-06-20 16:50:34.988301
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gsubset = ['all']
    c = CollectorMetaDataCollector(gather_subset=gsubset)
    assert c is not None
    assert c.gather_subset == gsubset
    assert c.module_setup == None
    facts = c.collect()
    assert facts == {'gather_subset': gsubset}

# Generated at 2022-06-20 16:50:44.620159
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.network


# Generated at 2022-06-20 16:50:49.656869
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    ansible_fact_collector = get_ansible_collector({'all': collector.BaseFactCollector}, gather_subset=['all'],
                                                   gather_timeout=None, filter_spec=None, minimal_gather_subset=None)
    # tests that all collectors in _collector_classes are returned when gather_subset='all'
    assert(hasattr(ansible_fact_collector, '_collectors'))
    assert(len(ansible_fact_collector._collectors) > 0)
    # tests that CollectorMetaDataCollector object is present as the last collector
    assert(type(ansible_fact_collector._collectors[-1])) is CollectorMetaDataCollector

# Generated at 2022-06-20 16:50:56.750273
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset='foo',
        module_setup=True)

    assert collector_meta_data_collector.collect()['gather_subset'] == 'foo'
    assert collector_meta_data_collector.collect()['module_setup'] == True


# Generated at 2022-06-20 16:51:05.652674
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    global a
    a = 1
    class Collect1():
        def collect_with_namespace(self, module=None, collected_facts=None):
            global a
            a = 2
            return {'f1': {'a': 1}}

    class Collect2():
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'f2': {'a': 1}}

    class Collect3():
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'f3': {'a': 1}}

    FactCollector1 = Collector1()
    FactCollector2 = Collector2()
    FactCollector3 = Collector3()
    collector_list = [Collect1, Collect2, Collect3]
    # test with empty filters
    fact

# Generated at 2022-06-20 16:51:10.155341
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    expected_filter_spec = ['*', 'ansible*', 'asdf*']
    fact_collector = AnsibleFactCollector(collectors=[],
                                          namespace='',
                                          filter_spec=expected_filter_spec)
    assert fact_collector.filter_spec == expected_filter_spec

# Generated at 2022-06-20 16:51:15.353278
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_facts = CollectorMetaDataCollector(gather_subset='all').collect()
    assert meta_facts == {'gather_subset': 'all'}



# Generated at 2022-06-20 16:51:24.458592
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts import namespace

    # Collector that returns info_dict = {'a':1}, with prefix namespace
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['a'])

        def collect(self, module=None, collected_facts=None):
            return {'a': 1}

    collector_obj = TestCollector(namespace=namespace.PrefixFactNamespace(prefix='test_'))
    assert collector_obj.namespace.prefix == 'test_'
    assert collector_obj.namespace.info_dict == {'a': 1}

    collector_obj = TestCollector()
    assert collector_obj.namespace is None
    assert collector_obj.info_dict == {'a': 1}


# Generated at 2022-06-20 16:51:44.522937
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    a = get_ansible_collector(
        all_collector_classes=collector.BaseFactCollector.__subclasses__(),
        gather_subset='all',
        gather_timeout=20,
        namespace=None,
        filter_spec=['ansible_os_family', 'ansible_distribution'],
        minimal_gather_subset=frozenset())

    result = a.collect()
    dist = result['ansible_distribution'].lower()
    os_family = result['ansible_os_family'].lower()

    assert isinstance(a, AnsibleFactCollector)
    assert isinstance(result, dict)
    assert isinstance(result['ansible_distribution'], str)
    assert isinstance(result['ansible_os_family'], str)

# Generated at 2022-06-20 16:51:48.774080
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    fact_collector = get_ansible_collector(
        all_collector_classes=[],
        filter_spec=['ansible_hostname', 'ansible_os_family'],
        gather_subset=['all'],
        gather_timeout=None,
        minimal_gather_subset=None)

    collected_facts = fact_collector.collect()
    assert collected_facts == {}



# Generated at 2022-06-20 16:51:57.448732
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    all_collector_classes = collector.CollectorRegistry.collector_classes()

    ansible_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                              gather_subset=['all'])

    assert(isinstance(ansible_collector, collector.BaseFactCollector))

    assert(ansible_collector.name == 'ansible')
    assert(len(ansible_collector.collectors) > 0)

    names = set([x.name for x in ansible_collector.collectors])
    assert('ansible_sysctl' in names)

# Generated at 2022-06-20 16:52:06.085238
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class CollectorFoo(collector.BaseFactCollector):
        name = 'foo'

    class CollectorBar(collector.BaseFactCollector):
        name = 'bar'

    all_collector_classes = [CollectorFoo, CollectorBar]

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           filter_spec=['bar'],
                                           gather_subset=['foo'],
                                           gather_timeout=666)

    assert fact_collector.collectors == [CollectorFoo(namespace=None)]
    assert fact_collector.filter_spec == ['bar']


if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-20 16:52:15.504694
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_test = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    assert collector_test.collect() == {'gather_subset': ['all'], 'module_setup': False}

    collector_test = CollectorMetaDataCollector(gather_subset=[], module_setup=False)
    assert collector_test.collect() == {'gather_subset': [], 'module_setup': False}

    collector_test = CollectorMetaDataCollector(gather_subset=[], module_setup=True)
    assert collector_test.collect() == {'gather_subset': [], 'module_setup': True}


# Generated at 2022-06-20 16:52:22.104618
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert(meta_facts['gather_subset'] == ['all'])
    assert(meta_facts['module_setup'] == True)

# Generated at 2022-06-20 16:52:30.256310
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Unit test for constructor of class AnsibleFactCollector.'''


# Generated at 2022-06-20 16:52:39.530720
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    assert c.gather_subset == ['all']
    assert c.module_setup == False
    assert c.name == 'gather_subset'
    assert c._fact_ids == set([])
    c = CollectorMetaDataCollector(gather_subset=['min'], module_setup=False)
    assert c.gather_subset == ['min']
    assert c.module_setup == False
    assert c.name == 'gather_subset'
    assert c._fact_ids == set([])
    c = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert c.gather_subset == ['all']
    assert c.module_setup

# Generated at 2022-06-20 16:52:47.863230
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.ansible_collector as ansible_collector

    collector_classes = ansible_collector.CollectorRegistry.collector_classes()
    c = get_ansible_collector(all_collector_classes=collector_classes,
                              gather_subset=['network'],
                              filter_spec='ansible_eth*')
    assert len(c.collectors)

    c = get_ansible_collector(all_collector_classes=collector_classes,
                              gather_subset=['all'],
                              filter_spec='ansible_eth*')
    assert len(c.collectors)

# Unit test function for function CollectorMetaDataCollector.collect

# Generated at 2022-06-20 16:52:54.911527
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    meta_facts = meta_data_collector.collect()
    assert meta_facts.get('gather_subset') == ['all']
    assert meta_facts.get('module_setup') == True



# Generated at 2022-06-20 16:53:12.834254
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_collector = CollectorMetaDataCollector()
    assert test_collector.name == 'gather_subset'
    assert test_collector._fact_ids == set()

# Generated at 2022-06-20 16:53:20.500013
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Execute method and test result
    expected = {'gather_subset': ['all']}
    assert CollectorMetaDataCollector(gather_subset=['all']).collect() == expected
    assert CollectorMetaDataCollector(gather_subset=['all'], module_setup=True).collect() == expected
    expected = {'gather_subset': ['network'], 'module_setup': True}
    assert CollectorMetaDataCollector(gather_subset=['network'], module_setup=True).collect() == expected



# Generated at 2022-06-20 16:53:27.591382
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector

    all_collector_classes = [NetworkCollector, SystemCollector]
    collector_classes = collector.collector_classes_from_gather_subset(all_collector_classes,
                                                                      gather_subset={'network', 'system'})
    collect_obj = CollectorMetaDataCollector(collector_classes)
    assert collect_obj is not None
    assert collect_obj.gather_subset == {'network', 'system'}

# Generated at 2022-06-20 16:53:38.320102
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.network import NetworkInterfacesFactCollector

    filter_spec = ['eth*']
    gather_subset = 'network'
    gather_timeout = None
    minimal_gather_subset = frozenset()
    namespace = PrefixFactNamespace(prefix='test_')
    fact_collector = \
        get_ansible_collector(all_collector_classes=[NetworkFactCollector],
                              namespace=namespace,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset)

    facts_dict = fact_collector.collect()
    eth_

# Generated at 2022-06-20 16:53:38.821256
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    pass

# Generated at 2022-06-20 16:53:41.162120
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector('foo', 'bar', ['baz']).gather_subset == ['baz']

# Generated at 2022-06-20 16:53:48.213587
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    facts_dict = {}
    ansible_collector = AnsibleFactCollector()

    # Test case when the ansible_collector._collector is None
    collected_dict = ansible_collector.collect(module=None, collected_facts=facts_dict)
    assert not collected_dict

    # Test case when the ansible_collector._collectors is empty
    ansible_collector.collectors = []
    collected_dict = ansible_collector.collect(module=None, collected_facts=facts_dict)
    assert not collected_dict

    # Test case when the ansible_collector._collectors has a non empty collector
    fact_collector = collector.BaseFactCollector()
    ansible_collector.collectors = [fact_collector]

# Generated at 2022-06-20 16:53:56.488493
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    answer = []
    class fakeCollector:
        def __init__(self, namespace=None):
            self.namespace = namespace
            self.namespace_list = [namespace]

        def collect_with_namespace(self, module=None, collected_facts=None):
            answer.append((self.namespace, collected_facts))
            return {self.namespace + 'key': self.namespace + 'value'}

    namespace1 = ''
    namespace2 = 'ansible_'
    namespace3 = 'facter_'
    namespace4 = 'ohai_'
    collector1 = fakeCollector(namespace=namespace1)
    collector2 = fakeCollector(namespace=namespace2)
    collector3 = fakeCollector(namespace=namespace3)

# Generated at 2022-06-20 16:54:02.671184
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    coll = CollectorMetaDataCollector()
    assert coll.collect() == {'gather_subset': None}
    coll = CollectorMetaDataCollector(gather_subset=['all'])
    assert coll.collect() == {'gather_subset': ['all']}
    coll = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    assert coll.collect() == {'gather_subset': ['all'], 'module_setup': False}

# Generated at 2022-06-20 16:54:06.835689
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['_all'], module_setup=True)
    meta_facts = fact_collector.collect(collected_facts={})
    assert meta_facts == {'gather_subset': ['_all'], 'module_setup': True}


# Generated at 2022-06-20 16:54:24.037370
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(collectors=None, namespace=None, gather_subset=['all'])
    assert c.collect() == {'gather_subset': ['all']}



# Generated at 2022-06-20 16:54:35.410192
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    def get_fact_collector_class(name):
        class FakeFactCollector():
            '''Fake collector class.'''
            name = name

            def __init__(self, namespace=None):
                self.namespace = namespace

            def collect(self, module=None, collected_facts=None):
                return {'%s_%s' % (self.namespace, self.name): 'fake'}

        return FakeFactCollector

    def get_collector_class(name):
        return get_fact_collector_class(name)

    all_collectors = collector.get_collector_classes(get_collector_class,
                                                     [get_collector_class, get_collector_class])


# Generated at 2022-06-20 16:54:43.902762
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(
        collectors=[],
        namespace=None,
        gather_subset=['all_test'],
        module_setup=True)

    assert collector_meta_data_collector.name == 'gather_subset'
    assert collector_meta_data_collector.namespace == None

    all_facts = collector_meta_data_collector.collect()
    gather_subset = all_facts['gather_subset']
    assert 'all_test' in gather_subset


# Generated at 2022-06-20 16:54:49.201528
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_collectors = \
        [BaseFactCollector(namespace=namespace.BaseFactNamespace())]

    fact_collector_obj = \
        CollectorMetaDataCollector('all',
                                   fact_collectors,
                                   namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    collected_facts = fact_collector_obj.collect()

    assert isinstance(collected_facts, dict)
    assert 'gather_subset' in collected_facts
    assert 'module_setup' in collected_facts

# Generated at 2022-06-20 16:54:56.269773
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_classes
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.os import Linux

    fact_collector = \
        get_ansible_collector(all_collector_classes=collector_classes,
                              namespace=namespace.PrefixFactNamespace(prefix='ansible_'),
                              filter_spec=['ansible_*'],
                              gather_subset='all',
                              gather_timeout=0,
                              minimal_gather_subset=frozenset(['all']))

    # gather all facts across all collectors
    facts = fact_collector.collect()

    # using the fact namespace (ansible_) we should get back a fact

# Generated at 2022-06-20 16:55:01.835427
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # sanity check this class exists
    assert (CollectorMetaDataCollector)
    # test that constructor works with no parameters
    assert (CollectorMetaDataCollector())
    # test that constructor works with just collectors parameter
    assert (CollectorMetaDataCollector(collectors='test'))
    # test that constructor works with just namespace parameter
    assert (CollectorMetaDataCollector(namespace='test'))
    # test that constructor works with just gather_subset parameter
    assert (CollectorMetaDataCollector(gather_subset='test'))
    # test that constructor works with just module_setup parameter
    assert (CollectorMetaDataCollector(module_setup='test'))
    # test that constructor works with all parameters

# Generated at 2022-06-20 16:55:05.183752
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    instance = collector.CollectorMetaDataCollector()
    assert isinstance(instance, collector.CollectorMetaDataCollector)


# Generated at 2022-06-20 16:55:13.717674
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    class CollectorWithNamespace(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = set(['foo'])

        def collect(self, module=None, collected_facts=None):
            return {self._prefix_key('foo'): 'bar'}

    collectors = [CollectorWithNamespace(namespace=collector.Namespace('test'))]
    gs = ['all']
    c = CollectorMetaDataCollector(collectors=collectors, gather_subset=gs)
    assert c.gather_subset == gs
    c.collect()

# Generated at 2022-06-20 16:55:26.006169
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # Case 1:
    #     Setting gather_subset=['a', 'b', 'c'], module_setup=None
    #     Expecting: {'gather_subset': ['a', 'b', 'c']}
    subset = ['a', 'b', 'c']
    module_setup = None
    meta_data = CollectorMetaDataCollector(gather_subset=subset, module_setup=module_setup)
    res = meta_data.collect()
    assert 'gather_subset' in res and res['gather_subset'] == subset

    # Case 2:
    #     Setting gather_subset=['a','b','c'], module_setup=True
    #     Expecting: {'gather_subset': ['a', 'b', 'c'], 'module_setup': True}


# Generated at 2022-06-20 16:55:27.362840
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert fact_collector
    assert fact_collector.collectors == []


# Generated at 2022-06-20 16:56:07.492637
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_collector_classes = [cache.CacheCollector, cache.NetworkCollector, network.NetworkCollector]
    namespace = PrefixFactNamespace(prefix='ansible_')

    collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                      namespace=namespace,
                                      filter_spec='*cache')
    assert collector.collectors[0] == cache.CacheCollector(namespace=namespace)
    assert collector.collectors[1] == CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)



# Generated at 2022-06-20 16:56:16.897340
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    def collect_1():
        return {'a': 1}
    def collect_2():
        return {'b': 2, 'c': 3}

    class MockCollector1(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return collect_1()

    class MockCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return collect_2()

    collectors = [MockCollector1(), MockCollector2()]
    fact_collector = AnsibleFactCollector(collectors=collectors)

    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert facts == {'a': 1, 'b': 2, 'c': 3}


# unit test