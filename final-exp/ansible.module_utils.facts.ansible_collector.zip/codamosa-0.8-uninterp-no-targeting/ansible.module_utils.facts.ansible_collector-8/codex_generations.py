

# Generated at 2022-06-20 16:46:29.966725
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector.name == 'gather_subset'

# Generated at 2022-06-20 16:46:39.561069
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import cache
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.platform as platform
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr

    class MockSimpleCollector(collector.BaseFactCollector):
        name = 'mock_collector'
        _fact_ids = {'mock_fact'}

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': 'mock_value'}

    mock_collectors = [MockSimpleCollector()]

    ansible

# Generated at 2022-06-20 16:46:43.521373
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c_meta_data_col = CollectorMetaDataCollector(gather_subset=['!all'],
                                                 module_setup=False)
    assert c_meta_data_col.gather_subset == ['!all']
    assert c_meta_data_col.module_setup == False

# Generated at 2022-06-20 16:46:51.788927
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class TestCollector(collector.BaseFactCollector):
        name = 'Test'

    class TestCollector2(collector.BaseFactCollector):
        name = 'Test2'

    all_collector_classes = [TestCollector, TestCollector2]

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes)

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == 2

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=['!Test'])

    assert isinstance(fact_collector, AnsibleFactCollector)

# Generated at 2022-06-20 16:46:58.973735
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Test that we can create an AnsibleFactCollector that has wrapped collectors and metadata collector.'''

    class TestCollector1(collector.BaseFactCollector):
        name = 'test1'

        def collect(self, module=None, collected_facts=None):
            return {'test1': True}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': True}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

        def collect(self, module=None, collected_facts=None):
            return {'test3': True}


# Generated at 2022-06-20 16:47:03.331078
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all', '*'],
                                   module_setup=True)
    facts_dict = collector_meta_data_collector.collect()
    assert facts_dict['gather_subset'] == ['all', '*']
    assert facts_dict['module_setup'] is True


# Generated at 2022-06-20 16:47:11.122217
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector_metadata_collector = CollectorMetaDataCollector(gather_subset='all')
    fact_collector_metadata_collector.set_namespace('facter')
    result = fact_collector_metadata_collector.collect()
    assert result == {'facter_gather_subset': 'all'}


# Generated at 2022-06-20 16:47:16.161083
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collect_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                             module_setup=True)
    result = collect_obj.collect()
    assert result['gather_subset'] == ['all']
    assert result['module_setup'] == True

# Generated at 2022-06-20 16:47:23.006640
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network

    def test_results(all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):

        f = get_ansible_collector(all_collector_classes,
                                  namespace=namespace,
                                  filter_spec=filter_spec,
                                  gather_subset=gather_subset,
                                  gather_timeout=gather_timeout,
                                  minimal_gather_subset=minimal_gather_subset)

        result = f.collect()

        # Test that we get the expected number of facts
        assert len(result) == 3
        assert result['ansible_facts']['test_fact'] == 'test_fact_value'

# Generated at 2022-06-20 16:47:31.089228
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    gather_subset = ['!all', 'network']
    gather_subset_no_min = ['!all', 'network']
    minimal_gather_subset = ['!all', 'network']
    gather_subset_no_min_no_collector = ['!all', 'software']

    # get a list of all collectors that would be considered for any gather_subset
    all_collector_classes = collector.collector_classes_from_gather_subset(
        all_collector_classes=collector.all_collector_classes(),
        minimal_gather_subset=minimal_gather_subset,
        gather_subset=gather_subset)

    # same result with or without minimal_gather_subset
    all_collector_classes_no_min = collector.collector_classes

# Generated at 2022-06-20 16:47:39.909877
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Arrange
    collector_meta_data_collector = CollectorMetaDataCollector(
        collectors=None,
        namespace=None,
        gather_subset=['this is the gather_subset'],
        module_setup=True)

    expected_result = {'gather_subset': ['this is the gather_subset'], 'module_setup': True}
    result = collector_meta_data_collector.collect()

    assert result == expected_result

# Generated at 2022-06-20 16:47:46.802951
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import ansible.module_utils.facts.namespace as namespace
    from ansible.module_utils.facts.collector.hardware import GenericHardwareCollector
    from ansible.module_utils.facts.collector.system import GenericSystemCollector

    collectors = [GenericHardwareCollector(), GenericSystemCollector()]

    fact_collector = AnsibleFactCollector(collectors=collectors)

    found_facts = fact_collector.collect()

    assert found_facts
    assert 'ansible_fqdn' in found_facts



# Generated at 2022-06-20 16:47:56.048155
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector

    all_collector_classes = [ansible_collector.AnsibleCollector]

    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    ansible_collector_1 = get_ansible_collector(all_collector_classes=all_collector_classes,
                                                minimal_gather_subset=frozenset(['!all']),
                                                gather_subset=['all'],
                                                filter_spec='',
                                                namespace=namespace_obj)

# Generated at 2022-06-20 16:48:04.504621
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FakeCollector(object):
        def collect(self, module=None, collected_facts=None):
            return {'ansible_facts': {'foo': 'bar'}}

    fact_collector = \
        AnsibleFactCollector(collectors=[FakeCollector()])
    facts = fact_collector.collect()
    assert facts == {'ansible_facts': {'foo': 'bar'}}

# Generated at 2022-06-20 16:48:13.807885
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = collector.get_fact_classes()
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None

    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=minimal_gather_subset,
            gather_subset=gather_subset,
            gather_timeout=gather_timeout)

    collectors = []
    for collector_class in collector_classes:
        collector_obj = collector_class(namespace=namespace)
        collectors.append(collector_obj)

    # Add a collector that knows what gather_subset we used so it it can

# Generated at 2022-06-20 16:48:22.996117
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    with open('test_meta_data_collector.txt', 'w') as f:
        f.write('test case: CollectorMetaDataCollector\n')
        f.write('\n')

        c = CollectorMetaDataCollector([], [],'all',True)
        ans = {'gather_subset': 'all', 'module_setup': True}
        f.write('\n')
        f.write('test 1: \n')
        f.write('Expected result: \n')
        f.write(str(ans))
        f.write('\n')
        f.write('Actual result: \n')
        f.write(str(c.collect()))
        f.write('\n')
        f.write('Conclusion:\n')

# Generated at 2022-06-20 16:48:28.034825
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True



# Generated at 2022-06-20 16:48:35.700779
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta = CollectorMetaDataCollector(gather_subset=['all','network','virtual','min'],
                                                module_setup=True)
    fact_dict = collector_meta.collect()
    assert fact_dict['gather_subset'] == ['all','network','virtual','min']
    assert fact_dict['module_setup'] == True

# Generated at 2022-06-20 16:48:45.009694
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.network as ansible_network
    import ansible.module_utils.facts.system as ansible_system

    # Set up the collectors and gather_subset
    collectors = [ansible_network.NetworkCollector, ansible_system.SystemCollector]
    minimal_gather_subset = []
    gather_subset = ['all']

    # Create the fact collector and gather facts
    fact_collector = get_ansible_collector(all_collector_classes=collectors,
                                           minimal_gather_subset=minimal_gather_subset,
                                           gather_subset=gather_subset)
    facts_dict = fact_collector.collect()

    # Assert that the list of gathered facts includes facts from each of our collectors

# Generated at 2022-06-20 16:48:55.381742
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector(): # noqa
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts.network import Network
    from ansible.module_utils.facts.virtual import Virtual

    collector1 = Hardware(namespace='hardware')
    collector2 = Network(namespace='network')
    collector3 = Virtual(namespace='virtual')

    fact_collector = AnsibleFactCollector([collector1, collector2, collector3])
    assert fact_collector.collectors == [collector1, collector2, collector3]

# Generated at 2022-06-20 16:49:15.468618
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = \
        AnsibleFactCollector(collectors=CollectorMetaDataCollector(),
                             filter_spec=[])

    # Call to method collect() of AnsibleFactCollector,
    # in order to set the namespace attribute.
    fact_collector.collect()

    # Assert the name space and filter_spec attributes of AnsibleFactCollector
    assert fact_collector.namespace is None
    assert fact_collector.filter_spec == []



# Generated at 2022-06-20 16:49:20.998852
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespace

    # Test all the collectors
    fact_collector = get_ansible_collector(all_collector_classes=True)
    assert fact_collector is not None
    facts = fact_collector.collect()
    # TODO: make sure the subset of facts returned is expected
    assert facts is not None
    assert isinstance(facts, dict)

    # Test a minimal subset of collectors
    fact_collector = get_ansible_collector(minimal_gather_subset=['hardware'])
    assert fact_collector is not None
    facts = fact_collector.collect()
    assert facts is not None
    assert isinstance(facts, dict)

    # Test a minimal subset of collectors with a namespace

# Generated at 2022-06-20 16:49:30.391423
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # mock_collectors is a dict that maps a namespace to a dict that maps fact names (that would
    # be collected) to the value of the fact
    mock_collectors = {'ansible_facts': {'ansible_distribution_release': '9.9'}}
    fact_collector = \
        AnsibleFactCollector(collectors=mock_collectors,
                             namespace=None,
                             filter_spec='ansible_distrib*')

    collected_facts = fact_collector.collect()
    assert collected_facts == {'ansible_distribution_release': '9.9'}


# Generated at 2022-06-20 16:49:40.688654
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
   # Test for None arguments
    test_obj = CollectorMetaDataCollector(collectors=None, namespace=None, gather_subset=None, module_setup=None)
    assert test_obj is not None
    # Test for all arguments
    test_obj = CollectorMetaDataCollector(collectors=['test_collectors'], namespace='test_namespace',
                                          gather_subset='test_gather_subset', module_setup='test_module_setup')
    assert test_obj is not None
    # Test for non-none arguments
    test_obj = CollectorMetaDataCollector(collectors=['test_collectors'], namespace='test_namespace',
                                          gather_subset='test_gather_subset')
    assert test_obj is not None


# Generated at 2022-06-20 16:49:44.840506
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Test that a default constructed collector doesn't collect anything
    f = AnsibleFactCollector()
    f.collect()
    assert (f.collect_with_namespace() == {})

# Generated at 2022-06-20 16:49:53.357218
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts.hardware

    # Test filtering of facts.
    fact_collector = AnsibleFactCollector(filter_spec=['*_mem*', '*_total'])

    # Test collection of specified collectors.
    fact_collector = AnsibleFactCollector(collectors=[
        ansible.module_utils.facts.hardware.HardwareFactCollector(namespace='test')])

    # Test collection of collectors with a namespace.
    fact_collector = AnsibleFactCollector(collectors=[
        ansible.module_utils.facts.hardware.HardwareFactCollector(namespace='test')],
        namespace=collector.PrefixFactNamespace(prefix='ansible_'))



# Generated at 2022-06-20 16:49:59.537512
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='all', module_setup=False)
    result = collector_meta_data_collector.collect()
    assert result == {'gather_subset': 'all'}

# Generated at 2022-06-20 16:50:09.149498
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Test arg filter_spec that is not a list or tuple
    filter_spec = '*'
    collectors = []
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          filter_spec=filter_spec)
    assert fact_collector is not None
    assert fact_collector.filter_spec == ['*']

    # Test arg filter_spec that is a list or tuple
    filter_spec = ['prefix*', '*suffix']
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          filter_spec=filter_spec)
    assert fact_collector is not None
    assert fact_collector.filter_spec == ['prefix*', '*suffix']

# Generated at 2022-06-20 16:50:17.796449
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test to test method collect of class AnsibleFactCollector'''

    class CollectorMock(object):
        def __init__(self, name, facts):
            self.name = name
            self.facts = facts

        def collect_with_namespace(self, *args, **kwargs):
            return self.facts

    # Create the mock Objects to test method collect of class AnsibleFactCollector

# Generated at 2022-06-20 16:50:24.827503
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    # constructor test
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)

    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup

    collect_facts = collector_meta_data_collector.collect(module=None,
                                                          collected_facts=None)

    assert collect_facts['gather_subset'] == ['all']
    assert collect_facts['module_setup']

# Generated at 2022-06-20 16:51:01.360868
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    """Test constructor for class CollectorMetaDataCollector"""
    collector_classes = []
    collector_classes.append(collector.FacterInfoCollector)

    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           gather_subset=['all'],
                                           namespace=None,
                                           filter_spec=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    collected_facts = fact_collector.collect()

    assert type(collected_facts) is dict, "fact_collecter.collect() is a dict"

    assert "facter" in collected_facts, "collected_facts has 'facter' as a key"

# Generated at 2022-06-20 16:51:06.212650
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import facts

    all_collector_classes = facts.collector_classes(ext_fact_classes=facts.ext_fact_classes)
    fact_collector = get_ansible_collector(all_collector_classes,
                                           gather_timeout=0,
                                           gather_subset=['all'],
                                           minimal_gather_subset=['all'])
    facts = fact_collector.collect()
    assert facts

# Generated at 2022-06-20 16:51:13.503189
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import device

    minimal_gather_subset = ['!all', '!min']
    gather_subset = ['!all', 'network']
    gather_timeout = 5

    collector_classes = [system.SystemCollector, device.DeviceCollector]

    all_collector_classes = system.all + device.all

    # get_ansible_collector(all_collector_classes,
    #                        namespace='test',
    #                        filter_spec=['*'],
    #                        gather_subset=['!all', 'network'],
    #                        gather_timeout=5,
    #                        minimal_gather_subset=['!all', '!min'])
    fact_collector = get_ansible_collector

# Generated at 2022-06-20 16:51:23.225823
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import mock
    import ansible.module_utils.facts.collectors
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import namespace

    import mock
    import ansible.module_utils.facts.collectors
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import namespace

    timeout.DEFAULT_GATHER_TIMEOUT = 10

    class MockSystemCollector(ansible.module_utils.facts.collectors.SystemCollector):
        name = 'system'
        _fact_ids = set(['a', 'b'])


# Generated at 2022-06-20 16:51:29.687700
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # load the ansible fact collector
    fact_collector = AnsibleFactCollector()

    # Check the fact collector has got the name 'ansible_facts'
    assert fact_collector.name == 'ansible_facts'

    # Check the fact collector has got a namespace of type PrefixFactNamespace
    assert isinstance(fact_collector.namespace, collector.PrefixFactNamespace)

# Generated at 2022-06-20 16:51:39.340815
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collect_func = AnsibleFactCollector(collectors=[], namespace=None).collect
    assert collect_func() == {}, \
        "Failed to collect with no collectors"

    class CollectorA(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'a': 1, 'b': 2}

    class CollectorB(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'c': 3}

    class CollectorC(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'d': 4}


# Generated at 2022-06-20 16:51:51.376944
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import unittest

    class TestCollectorMetaDataCollector(unittest.TestCase):
        def test_collect_with_gather_subset_set(self):
            # setup
            collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all')
            # collect
            meta_facts = collector_meta_data_collector.collect()
            # verify
            self.assertEqual(meta_facts, {'gather_subset': 'all'})

        def test_collect_with_gather_subset_none(self):
            # setup
            collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=None)
            # collect
            meta_facts = collector_meta_data_collector.collect()
            # verify
            self.assertE

# Generated at 2022-06-20 16:52:04.126136
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collect_obj = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    assert collect_obj.gather_subset == ['all']
    assert collect_obj.module_setup == False
    assert collect_obj.name == 'gather_subset'
    assert collect_obj._fact_ids == set([])
    facts = collect_obj.collect()
    assert facts['gather_subset'] == ['all']
    assert 'module_setup' not in facts
    assert isinstance(facts, dict)

    collect_obj = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collect_obj.gather_subset == ['all']
    assert collect_obj.module_setup == True

# Generated at 2022-06-20 16:52:16.008737
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # 1. Assemble facts.TestCollector, facts.TestNamespaceCollector, and facts.TestBadCollector instances
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = {'test1', 'test2'}

        def collect(self):
            return {'test1': 'test1', 'test2': 'test2'}

    namespace_cls = PrefixFactNamespace(prefix='test_')

    class TestNamespaceCollector(TestCollector):
        namespace = namespace_cls

    class TestBadCollector(TestCollector):
        _fact_ids = {'test3', 'test4'}

# Generated at 2022-06-20 16:52:23.093612
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # mock module object
    module = type('module', (object,), {'params': {'gather_subset': ['all']}})

    # create object
    fact_collector = CollectorMetaDataCollector(gather_subset=module.params['gather_subset'])

    # call collect
    facts = fact_collector.collect(module, collected_facts=None)

    # test result
    assert facts['gather_subset'] == ['all']

# Generated at 2022-06-20 16:52:59.816760
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            return {'one': 1}

    class TestCollector2(collector.BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            return {'two': 2}

    class TestCollector3(collector.BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            return {'two': 4}

    with_filter = AnsibleFactCollector(collectors=[TestCollector(),
                                                   TestCollector2(),
                                                   TestCollector3()],
                                       filter_spec=['two'])

    with_filter.collect()  # noqa


# Generated at 2022-06-20 16:53:10.301091
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.platform.linux as linux_collector
    import ansible.module_utils.facts.network.linux as net_collector

    all_collector_classes = [linux_collector.LinuxFactCollector, net_collector.LinuxNetworkCollector]

    # default case
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    assert isinstance(fact_collector, AnsibleFactCollector)

    # with namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    n = PrefixFactNamespace(prefix='ansible_')
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=n)


# Generated at 2022-06-20 16:53:21.389785
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import ALL_COLLECTOR_CLASSES
    import ansible.module_utils.facts.namespace
    namespace_type = ansible.module_utils.facts.namespace.NamespaceType

    # Test on all collectors
    fact_collector = get_ansible_collector(all_collector_classes=ALL_COLLECTOR_CLASSES)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert len(fact_collector.collectors) == len(ALL_COLLECTOR_CLASSES) + 1
    assert fact_collector.filter_spec is None
    assert isinstance(fact_collector.namespace, namespace_type)
    assert fact_collector.namespace.prefix == ''
    assert fact_collector.namespace.postfix == ''

# Generated at 2022-06-20 16:53:29.574339
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes_dict = {
        'foo': collector.BaseFactCollector,
        'bar': collector.BaseFactCollector,
        'baz': collector.BaseFactCollector,
        'fake': collector.BaseFactCollector,
    }


# Generated at 2022-06-20 16:53:41.086666
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector(): #pylint: disable=unused-argument
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.default_ipv4

    import ansible.module_utils.facts.namespace
    ansible_namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')

    class DummyCollector(collector.BaseFactCollector):
        name = 'dummy'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'dummy_fact': 'abc'}

    ansible_collector = get_ansible

# Generated at 2022-06-20 16:53:43.261337
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert fact_collector.collect().get('module_setup') is True

# Generated at 2022-06-20 16:53:50.700081
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'],
                          'module_setup': True}

# Generated at 2022-06-20 16:53:57.453612
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import doctest
    import inspect
    import copy

    all_collector_classes = []
    for name, cls in inspect.getmembers(sys.modules[__name__], inspect.isclass):
        if issubclass(cls, collector.BaseFactCollector) and cls is not collector.BaseFactCollector:
            all_collector_classes.append(cls)

    # we don't want the AnsibleFactCollector in the test
    all_collector_classes.remove(AnsibleFactCollector)
    all_collector_classes.remove(CollectorMetaDataCollector)

    # we need to make sure that each collector only collects once to keep
    # the test deterministic

# Generated at 2022-06-20 16:54:01.516303
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['all'], 'module_setup': True}, "Incorrect meta data"

# Generated at 2022-06-20 16:54:10.967661
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import tempfile
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import cache_file
    from ansible.module_utils.facts import namespace as facts_namespace
    import ansible.module_utils.facts.sources.system as ansible_sources_system

    temp_dir = tempfile.mkdtemp()
    ansible_c = ansible_collector.get_ansible_collector(filter_spec=['ansible_*'],
                                                        gather_subset=['!all', '!min'],
                                                        gather_timeout=1,
                                                        minimal_gather_subset=None)
    filt_fact_dict = ansible_c.collect()
    fact_dict

# Generated at 2022-06-20 16:55:13.800043
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class Collector1(collector.BaseFactCollector):
        name = 'collector1'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            fact_dict = {'c1_fact1': 'c1_fact1_value'}
            return fact_dict

    class Collector2(collector.BaseFactCollector):
        name = 'collector2'
        _fact_ids = set([])

        def __init__(self):
            self.collect_calls = 0

        def collect(self, module=None, collected_facts=None):
            fact_dict = {'c2_fact1': 'c2_fact1_value', 'c2_fact2': 'c2_fact2_value'}
            self.collect_calls += 1


# Generated at 2022-06-20 16:55:23.392252
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Test empty constructor
    fact_collector = AnsibleFactCollector()
    if fact_collector == None:
        raise Exception("AnsibleFactCollector() did not return as expected")

    # Test constructor with collector
    collector_classes = [collector.BaseFactCollector]
    fact_collector = AnsibleFactCollector(collector_classes)
    if fact_collector == None:
        raise Exception("AnsibleFactCollector() did not return as expected")

# Generated at 2022-06-20 16:55:32.822784
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible import module_utils
    # Gather facts with all collectors
    ansible_collector = get_ansible_collector(all_collector_classes=module_utils.facts.collectors.__all__)
    ansible_facts = ansible_collector.collect()

    assert ansible_facts['module_setup']
    assert ansible_facts['gather_subset'] == ['all']


# Generated at 2022-06-20 16:55:41.286180
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    collector_obj = CollectorMetaDataCollector(gather_subset=['all'])
    expected = {u'gather_subset': [u'all']}
    actual = collector_obj.collect()
    assert(expected == actual)

    collector_obj = CollectorMetaDataCollector(gather_subset=[])
    expected = {u'gather_subset': []}
    actual = collector_obj.collect()
    assert(expected == actual)

    collector_obj = CollectorMetaDataCollector(gather_subset=['all'],
                                               module_setup=True)

# Generated at 2022-06-20 16:55:46.301114
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_list = ['facter', 'other', 'ohai']
    gather_subset = ['facter', 'ohai']
    collect_module_setup = True
    c = CollectorMetaDataCollector(collector_list, gather_subset, collect_module_setup)
    assert c.module_setup == collect_module_setup
    assert c.gather_subset == gather_subset
    assert c.namespace is None
    assert c.collectors is collector_list



# Generated at 2022-06-20 16:55:52.344450
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-20 16:55:55.500507
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    expected = dict(gather_subset=['all'], module_setup=True)
    actual = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True).collect()
    assert expected == actual



# Generated at 2022-06-20 16:56:07.383037
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Test creation of CollectorMetaDataCollector with minimal parameters
    cg = CollectorMetaDataCollector()
    assert cg is not None
    assert cg._fact_ids == set([])

    # Test creation of CollectorMetaDataCollector with gather_subset
    cg = CollectorMetaDataCollector(gather_subset=['all', 'mini'])
    assert cg is not None
    assert cg._fact_ids == set([])

    # Test creation of CollectorMetaDataCollector with module_setup
    cg = CollectorMetaDataCollector(module_setup=True)
    assert cg is not None
    assert cg._fact_ids == set([])

    # Test creation of CollectorMetaDataCollector with minimal parameters
    cg = CollectorMetaDataCollector(collectors=[], namespaces={})

# Generated at 2022-06-20 16:56:13.581488
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gather_subset = '!fake_facts'
    namespace = None
    collector = CollectorMetaDataCollector(gather_subset=gather_subset, namespace=namespace)
    assert(collector.gather_subset == gather_subset)
    assert(collector.namespace == namespace)
    assert (collector.fact_ids == set([]))


# Generated at 2022-06-20 16:56:14.088996
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass