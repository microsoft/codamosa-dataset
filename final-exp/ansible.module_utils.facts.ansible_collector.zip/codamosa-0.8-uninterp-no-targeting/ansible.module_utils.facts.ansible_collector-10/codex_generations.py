

# Generated at 2022-06-20 16:46:36.515073
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # empty
    collector = get_ansible_collector(all_collector_classes=[],
                                      gather_subset=[],
                                      filter_spec=[])
    assert collector.collectors == []

    # just meta_data_collector
    collector = get_ansible_collector(all_collector_classes=[],
                                      gather_subset=[],
                                      filter_spec=[])
    assert collector.collectors == []

    # net and meta_data_collector
    collector = get_ansible_collector(all_collector_classes=[collector.FactsByNamespace],
                                      gather_subset=['network'],
                                      filter_spec=[])
    assert len(collector.collectors) == 2

    assert isinstance(collector.collectors[0], collector.FactsByNamespace)

# Generated at 2022-06-20 16:46:41.757056
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=frozenset(['hardware', 'network']),
                                   module_setup=True)
    f = c.collect()
    assert f['gather_subset'] == frozenset(['hardware', 'network'])
    assert f['module_setup']


# Generated at 2022-06-20 16:46:54.058588
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test case:
    # some_data_dict is given as the collected facts
    # and the collect() method will filter on the
    # data with filter_spec.
    # collector_A_obj and collector_B_obj are added
    # to the collectors list.

    some_data_dict = dict(a=1, b=2, c=dict(e=3, f=4), d=5, g=6)

    class collector_A_obj(object):
        def __init__(self):
            self.name = 'A'

        def collect_with_namespace(self, **kwargs):
            return dict(a=1, b=2, c=dict(e=3, f=4))


# Generated at 2022-06-20 16:47:02.388666
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_obj = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    facts = collector_obj.collect()
    assert facts['gather_subset'] == 'all'
    assert facts['module_setup'] == True

if __name__ == '__main__':
    test_CollectorMetaDataCollector_collect()

# vim: ai et ts=4 sts=4 sw=4 nu ft=python

# Generated at 2022-06-20 16:47:15.582061
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test constructor with collectors and namespace.
    collectors = ['list of collectors']
    namespace = PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          namespace=namespace)
    assert fact_collector.collectors == collectors
    assert fact_collector.namespace == namespace
    assert fact_collector.filter_spec is None

    # Test constructor with collectors and no namespace.
    fact_collector = AnsibleFactCollector(collectors=collectors)
    assert fact_collector.collectors == collectors
    assert fact_collector.namespace is None

# Generated at 2022-06-20 16:47:23.006608
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {self.name: self.name}
    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {self.name: {'a': 'a1'}}

    collectors = [TestCollector(), TestCollector2()]
    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=None)
    facts_dict = fact_collector.collect()

    assert facts_dict == {'test': 'test', 'test2': {'a': 'a1'}}


# Generated at 2022-06-20 16:47:25.218698
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test of method collect of class CollectorMetaDataCollector'''
    test_metadata_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                         module_setup=True)
    test_meta_facts = test_metadata_collector.collect()

    assert 'module_setup' in test_meta_facts

# Generated at 2022-06-20 16:47:35.809178
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''unit test for method collect'''

    my_test_subset = 'test'

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=my_test_subset)

    my_facts = collector_meta_data_collector.collect()

    assert my_facts is not None
    assert my_facts['gather_subset'] == my_test_subset
    assert 'module_setup' not in my_facts

# Generated at 2022-06-20 16:47:45.219113
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.cache

    factnamespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')
    cache = ansible.module_utils.facts.cache.FactCache()
    fact_collector = AnsibleFactCollector(namespace=factnamespace)
    assert(fact_collector.namespace == factnamespace)

    fact_collector = AnsibleFactCollector()
    assert(fact_collector.namespace is None)


# Generated at 2022-06-20 16:47:55.405403
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """
       Verify if collect method returns the correct values
    """
    gather_subset = ['all']
    module_setup = True
    collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset=gather_subset,
        module_setup=module_setup
    )
    result = collector_meta_data_collector.collect()
    assert result['gather_subset'] == gather_subset
    assert result['module_setup'] == module_setup

# Generated at 2022-06-20 16:48:13.807743
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector import CollectorBase
    from ansible.module_utils.facts import default

    class CollectorA(CollectorBase):
        name = 'collector_a'

    class CollectorB(CollectorBase):
        name = 'collector_b'
        _fact_ids = {'fact_c'}

        def collect(self, module=None, collected_facts=None):
            return {'fact_c': 'collector_b'}

    class CollectorC(CollectorBase):
        name = 'collector_c'
        _fact_ids = {'fact_d'}


# Generated at 2022-06-20 16:48:21.127371
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # TODO: This is a unit test for the class ansible.module_utils.facts.AnsibleFactCollector
    #       The class needs to be refactored (moved to a testable location)
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.collector import BaseFactCollector

    collector_1 = BaseFactCollector(namespace=None)
    collector_2 = BaseFactCollector(namespace=None)
    collector_3 = BaseFactCollector(namespace=None)

    collector_1.collect = lambda: {'name': 'collector_1'}
    collector_2.collect = lambda: {'name': 'collector_2'}
    collector_3.collect = lambda: {'name': 'collector_3'}

# Generated at 2022-06-20 16:48:23.553463
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    CollectorMetaDataCollector(gather_subset=['all'])


# Generated at 2022-06-20 16:48:28.557800
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    class CollectorMetaDataCollectorTest(CollectorMetaDataCollector):
        def __init__(self):
            super(CollectorMetaDataCollectorTest, self).__init__(gather_subset=['all'],
                                                                 module_setup=True)

    fact_collector = CollectorMetaDataCollectorTest()
    fact_collector.collect()


# Generated at 2022-06-20 16:48:36.914290
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    assert CollectorMetaDataCollector(gather_subset=['asdf'],
                                      module_setup=False).collect() == \
                                      {'gather_subset': ['asdf']}

    assert CollectorMetaDataCollector(gather_subset=['asdf']).collect() == \
                                      {'gather_subset': ['asdf'],
                                       'module_setup': True}

# Generated at 2022-06-20 16:48:42.919783
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['some gather_subset'])
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': ['some gather_subset']}



# Generated at 2022-06-20 16:48:49.261572
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import unittest.mock as mock

    class DummyCollector(collector.BaseFactCollector):
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'foo': 'bar',
                    'bogus_fact': 'that_should_not_be_returned'}

    class Test_AnsibleFactCollector(unittest.TestCase):
        '''Test class for AnsibleFactCollector class: Unit test for method collect of class AnsibleFactCollector'''

        @mock.patch.object(timeout, 'time')
        def test_collect_with_collector_that_returns_dictionary_and_filter_spec_that_matches_all_facts(self, time_mock):
            time_mock.return_value = 1.0


# Generated at 2022-06-20 16:48:50.898696
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert (get_ansible_collector is not None)

# Generated at 2022-06-20 16:48:56.408627
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    expected = {
        'gather_subset': ['all']
    }
    collected_facts = {'test': 'test'}
    actual = CollectorMetaDataCollector(gather_subset=['all']).collect(collected_facts=collected_facts)
    assert expected == actual


# Generated at 2022-06-20 16:49:03.129946
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Arrange
    test_collector = CollectorMetaDataCollector()
    result_not_expected = {'gather_subset': None}

    # Act
    result = test_collector.collect()

    # Assert
    assert result != result_not_expected



# Generated at 2022-06-20 16:49:21.519409
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Note: this is a functional unit test, meaning it uses real
    # code to test get_ansible_collector.  It is not a unit test in
    # the traditional sense of testing a class or function in isolation.

    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.system.kernel
    import ansible.module_utils.facts.processor


# Generated at 2022-06-20 16:49:31.976309
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_defaultdict

    # Get all the collector classes
    all_collector_classes = \
        collector_defaultdict.GenericFactCollectorDefaultDict.values()

    # get a collector for gather_subset=['all'] for fact names matching test*
    ac = get_ansible_collector(all_collector_classes=all_collector_classes,
                               gather_subset=['all'],
                               minimal_gather_subset=frozenset(['all']),
                               filter_spec=['test*'])

    # It should have collectors for all facts
    assert len(ac.collectors) == len(all_collector_classes) + 1


# Generated at 2022-06-20 16:49:35.208822
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='!all,!min',
                                   module_setup=True)

    assert isinstance(collector_meta_data_collector, AnsibleFactCollector)



# Generated at 2022-06-20 16:49:39.343239
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset=['foo', 'bar'],
                                                module_setup=True)
    facts = fact_collector.collect()
    assert facts == {'gather_subset': ['foo', 'bar'], 'module_setup': True}

# Generated at 2022-06-20 16:49:42.212884
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector = AnsibleFactCollector()
    assert isinstance(collector, AnsibleFactCollector)



# Generated at 2022-06-20 16:49:50.449411
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    base_fact_collector_obj = BaseFactCollector(namespace=PrefixFactNamespace(prefix='ansible_'))
    ansible_fact_collector_obj = AnsibleFactCollector(collectors=[base_fact_collector_obj], namespace=PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(ansible_fact_collector_obj.collectors[0], BaseFactCollector)
    assert ansible_fact_collector_obj.namespace and isinstance(ansible_fact_collector_obj.namespace, PrefixFactNamespace)
    assert ansible_fact_collector_obj.filter_spec == None


# Generated at 2022-06-20 16:50:03.695097
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Test with gather_subset=None
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=None)
    facts = collector_meta_data_collector.collect()
    assert facts == {}

    # Test with gather_subset=[]
    gather_subset = []
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset)
    facts = collector_meta_data_collector.collect()
    assert facts == {'gather_subset': gather_subset}

    # Test with gather_subset=['all']
    gather_subset = ['all']
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=gather_subset)


# Generated at 2022-06-20 16:50:12.501320
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.system import DistroCollector

    namespace = PrefixFactNamespace('ansible_')
    distro_collector = DistroCollector(namespace)
    fact_collector = AnsibleFactCollector(collectors=[distro_collector],
                                          namespace=namespace)
    ansible_facts = fact_collector.collect()
    assert 'ansible_distribution' in ansible_facts

# Generated at 2022-06-20 16:50:13.884599
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Test successful creation of object
    AnsibleFactCollector()

# Generated at 2022-06-20 16:50:19.402436
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector(collectors=['devicename', 'uptime'])
    assert type(fact_collector.collectors) is list
    assert fact_collector.collectors[0] == 'devicename'
    assert fact_collector.collectors[1] == 'uptime'

# Generated at 2022-06-20 16:50:55.633027
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''AnsibleFactCollector init'''
    namespace = 'ansible_'
    filter_spec = 'ansible*'
    collectors = []
    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          filter_spec=filter_spec,
                                          namespace=namespace)

    assert fact_collector.filter_spec == filter_spec

# Generated at 2022-06-20 16:51:04.723107
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from test.unit.module_utils.facts.test_collector import SimpleTestFactsCollector
    from test.unit.module_utils.facts.test_collector import ComplexNamespaceFactsCollector


    # test collection with a single collector
    fact_collector = get_ansible_collector(all_collector_classes=[SimpleTestFactsCollector])
    facts = fact_collector.collect()

    assert 'simple' in facts
    assert facts['simple']['fact1'] == 'fact1'
    assert facts['simple']['fact2'] == 'fact2'

    # test collection with two collectors with same namespace
    fact_collector = get_ansible_collector(all_collector_classes=[SimpleTestFactsCollector,
                                                                   SimpleTestFactsCollector])
    facts = fact_collect

# Generated at 2022-06-20 16:51:12.500096
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespaced_fact
    from ansible.module_utils.facts import cache

    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'testf': 'testf'}

    class TestCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'testf2': 'testf2'}

    class TestCollector3(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'testf3': 'testf3'}


# Generated at 2022-06-20 16:51:20.519890
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    cmc = CollectorMetaDataCollector(gather_subset=['a', 'b'])
    assert cmc.collect() == {'gather_subset': ['a', 'b']}

    cmc2 = CollectorMetaDataCollector(gather_subset=['a', 'b'], module_setup=False)
    assert cmc2.collect() == {'gather_subset': ['a', 'b'], 'module_setup': False}

# Generated at 2022-06-20 16:51:33.308842
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    my_module_setup = True
    my_gather_subset = ['all', '!network', 'network:dns']
    my_collector = CollectorMetaDataCollector(gather_subset=my_gather_subset,
                                              module_setup=my_module_setup)
    my_collected_facts = {}
    my_facts = my_collector.collect(module=None, collected_facts=my_collected_facts)
    assert 'module_setup' in my_facts
    assert my_facts['module_setup'] == my_module_setup
    assert 'gather_subset' in my_facts
    assert len(my_facts['gather_subset']) == len(my_gather_subset)
    for s in my_gather_subset:
        assert s in my

# Generated at 2022-06-20 16:51:45.460064
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import fact.collector.linux as linux_facts
    import fact.collector.network as network_facts

    all_collector_classes = \
        frozenset(collector.get_all_collector_classes())

    # Add network_fact.NetworkFactCollector to filter_spec
    # (so we get only that fact, as well as the gather_subset meta-data)
    filter_spec = ['*', 'network_fact*']

    # Nothing from gather_subset should be in the result
    gather_subset = ['non-existant-subset']

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset)

    facts = fact

# Generated at 2022-06-20 16:51:51.315895
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector(collectors=None)
    assert(len(fact_collector.collectors) == 0)

    empty_filter_spec = []
    fact_collector = AnsibleFactCollector(filter_spec=empty_filter_spec)
    assert(len(fact_collector.filter_spec) == 0)

# Generated at 2022-06-20 16:52:04.049927
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts.collector.all as all
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.networking as networking

    all_collector_classes = [all.AllFactCollector,
                             all.FacterFactCollector,
                             all.OhaiFactCollector,
                             all.LinuxHardwareInfoFactCollector,
                             all.LinuxNetworkInterfacesFactCollector,
                             all.LinuxNetworkInterfaceFactCollector,
                             all.NetworkingFactCollector,
                             all.NetworkFactCollector]

    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')
    filter_spec = ["ansible_*", "facter_*", "ohai_*"]

# Generated at 2022-06-20 16:52:11.777458
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    expected = {'gather_subset': ['min', 'network'],
                'module_setup': True}
    meta = CollectorMetaDataCollector(gather_subset=expected['gather_subset'],
                                      module_setup=expected['module_setup'])
    actual = meta.collect()
    assert expected == actual

# Generated at 2022-06-20 16:52:18.120327
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Valid parameters
    assert CollectorMetaDataCollector(gather_subset=['!foo', '*'], module_setup=True) is not None
    assert CollectorMetaDataCollector(gather_subset=['!foo', '*'], module_setup=False) is not None

    # Invalid parameters
    assert CollectorMetaDataCollector(gather_subset=[], module_setup=True) is not None
    assert CollectorMetaDataCollector(gather_subset=[], module_setup=False) is not None
    assert CollectorMetaDataCollector(gather_subset=['!foo', '*']) is not None
    assert CollectorMetaDataCollector(gather_subset=['!foo', '*'], module_setup=None) is not None

# Generated at 2022-06-20 16:53:00.901142
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.solaris
    import ansible.module_utils.facts.collector.linux

    def _names(objs):
        return [x.name for x in objs]

    # test minimal_gather_subset=None
    a = get_ansible_collector(all_collector_classes=[
        ansible.module_utils.facts.collector.network.NetworkCollector,
        ansible.module_utils.facts.collector.solaris.SolarisDictFactCollector,
        ansible.module_utils.facts.collector.linux.LinuxDictFactCollector,
    ])

# Generated at 2022-06-20 16:53:08.688804
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors.values(),
                                           gather_subset=['all'],
                                           filter_spec=['a*'],
                                           )

    facts_d = fact_collector.collect()

    for f in ['ansible_all_ipv4_addresses', 'ansible_architecture']:
        assert f in facts_d


# Generated at 2022-06-20 16:53:20.415214
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import packaging
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    all_collector_classes = [collector.BaseFactCollector,
                             hardware.Hardware,
                             network.Network,
                             packaging.Packaging,
                             system.System,
                             virtual.Virtual,
                             ]

    gather_subset = ['all']
    minimal_gather_subset = ['all']
    gather_timeout = 10

# Generated at 2022-06-20 16:53:28.974046
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.hardware import memory

    module = cache.Cache(timeout=None)

    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes,
                                           namespace=ansible_collector.DEFAULT_COLLECTOR_NAMESPACE,
                                           filter_spec=[],
                                           gather_subset=['all'],
                                           gather_timeout=None,
                                           minimal_gather_subset=frozenset())

    # should collect all
    facts_dict = fact_collector.collect(module=module)

# Generated at 2022-06-20 16:53:38.806242
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import \
        ALL_COLLECTOR_CLASSES, \
        BaseFactCollector, \
        collector_classes_from_gather_subset

    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set([])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set([])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set([])

    all_collector_classes = ALL_COLLECTOR_CLASSES
    all_collector_classes.update({
        Collector1.name: Collector1,
        Collector2.name: Collector2,
        Collector3.name: Collector3,
    })

# Generated at 2022-06-20 16:53:47.226875
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # following test case is created to test the constructor of the class CollectorMetaDataCollector
    class SampleCollector(collector.BaseFactCollector):
        ''' Add docs '''
        name = 'sample_collector'

    class SampleCollector1(collector.BaseFactCollector):
        ''' Add docs '''
        name = 'sample_collector1'

    collector_classes = [SampleCollector, SampleCollector1]
    gather_subset = ['all', 'network']
    gather_subset.append('sample_collector1')
    factory = collector.CollectorFactory(gather_subset)
    for collector_class in collector_classes:
        factory.register_collector(collector_class)
    collectors = factory.create_collectors()


# Generated at 2022-06-20 16:53:56.148344
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test if the collect function works
    # Create an AnsibleFactCollector object
    test_AnsibleFactCollector = AnsibleFactCollector()
    # Create a dictionary with random keys and values
    test_dict = { 'test_key_1': 'test_val_1', 'test_key_2': 'test_val_2' }

    # Create a module object to use in the collect method of the AnsibleFactCollector object
    test_module = type('module', (object,), {})
    test_module.params = {'filter': 'test_key_1'}

    # Call the collect method with the test module and the test dictionary
    # Should return the test dictionary
    collector_output = test_AnsibleFactCollector.collect(test_module, test_dict)
    assert collector_output == test_dict


# Generated at 2022-06-20 16:53:59.571208
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_classes = []
    namespace = None
    filter_spec = None
    fact_collector = \
        AnsibleFactCollector(collectors=collector_classes,
                             filter_spec=filter_spec,
                             namespace=namespace)

    assert fact_collector.collectors == collector_classes
    assert fact_collector.namespace == namespace
    assert fact_collector.filter_spec == filter_spec

# Generated at 2022-06-20 16:54:08.209487
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # mock module and collected_facts
    module = None 
    collected_facts = {}
    # mock gather_subset and module_setup
    gather_subset = None
    module_setup = None
    
    # create CollectorMetaDataCollector object
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset, module_setup)
    # collect module_setup
    result = collector_meta_data_collector.collect(module, collected_facts)
    assert result == {'module_setup': True}

# Generated at 2022-06-20 16:54:18.549196
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class Collector1(collector.BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1'])

        def collect(self, module=None, collected_facts=None):
            fact = 'collector1'
            return {self.namespace.join('fact1'): fact}

    class Collector2(collector.BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact2'])

        def collect(self, module=None, collected_facts=None):
            fact = 'collector2'
            return {self.namespace.join('fact2'): fact}

    class Collector3(collector.BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact3'])


# Generated at 2022-06-20 16:55:25.235908
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    expected_gather_subset = ['all']
    expected_module_setup = True

    collect_obj = \
        CollectorMetaDataCollector(gather_subset=expected_gather_subset,
                                   module_setup=expected_module_setup)

    actual_gather_subset = collect_obj.gather_subset
    actual_module_setup = collect_obj.module_setup

    assert actual_gather_subset == expected_gather_subset
    assert actual_module_setup == expected_module_setup

# Generated at 2022-06-20 16:55:37.759478
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Tests get_ansible_collector() and uses the ansible_local facts'''
    from ansible.module_utils.facts.local import AnsibleLocalFactCollector

    all_collector_classes = {
        'ansible_local': AnsibleLocalFactCollector,
        'gather_subset': CollectorMetaDataCollector,
    }

    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                      gather_subset=gather_subset,
                                      gather_timeout=gather_timeout,
                                      minimal_gather_subset=minimal_gather_subset)



# Generated at 2022-06-20 16:55:40.465662
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collectors import default_collectors

    fact_collector = get_ansible_collector(all_collector_classes=default_collectors)
    assert fact_collector



# Generated at 2022-06-20 16:55:46.783870
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.fact_cache import FactsCache
    from ansible.module_utils.facts import namespaces

    def collector_classes(gather_subset):
        return {'all': [FakeCollector1, FakeCollector3, FakeCollector2]}

    cache = FactsCache()
    namespace = namespaces.Namespace('ansible_')
    fact_collector = get_ansible_collector(collector_classes,
                                           namespace=namespace,
                                           filter_spec=[],
                                           gather_subset='all',
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    facts_dict = fact_collector.collect(module=None,
                                        collected_facts=cache.get_facts())
    assert facts_

# Generated at 2022-06-20 16:55:53.399469
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.collect(module=None,
                                                 collected_facts=None) == {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-20 16:55:57.023121
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ns = 'ansible'
    gather_subset = 'min'
    module_setup = True
    collector = CollectorMetaDataCollector(namespace=ns, gather_subset=gather_subset, module_setup=module_setup)
    facts = collector.collect()

    assert 'gather_subset' in facts
    assert facts.get('gather_subset') == gather_subset

    assert 'module_setup' in facts
    assert facts.get('module_setup') == module_setup


# Generated at 2022-06-20 16:56:04.620101
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Create CollectorMetaDataCollector object
    collector_obj = CollectorMetaDataCollector(gather_subset=['facter', 'ohai'])
    # Call collect function
    fact = collector_obj.collect()
    # Verify if the fact is correct
    assert fact['gather_subset'] == ['facter', 'ohai']
    # TODO: run collect() to other values of gather_subset and module_setup


# Generated at 2022-06-20 16:56:16.369656
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MyCollector(collector.BaseFactCollector):
        name = 'my_fancy_collector'

        def collect_with_namespace(self, module, collected_facts):
            return {'fact_a': 'A',
                    'ansible_fact_b': 'B'}

    my_collector = MyCollector()

    fact_collector = \
        AnsibleFactCollector(collectors=[my_collector],
                             filter_spec=['*', 'ansible_*'],
                             namespace=None)

    fact_dict = fact_collector.collect()
    assert len(fact_dict.keys()) == 2
    assert fact_dict['ansible_fact_a'] == 'A'
    assert fact_dict['ansible_fact_b'] == 'B'


# Generated at 2022-06-20 16:56:28.336523
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collectors

    filter_spec = filter_spec or 'ansible_eth*'
    gather_subset = gather_subset or ['all']
    gather_timeout = gather_timeout or timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = minimal_gather_subset or frozenset()

    fact_collector = \
        get_ansible_collector(all_collector_classes=default_collectors,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)
    fact_collector = fact_collector.collect()
