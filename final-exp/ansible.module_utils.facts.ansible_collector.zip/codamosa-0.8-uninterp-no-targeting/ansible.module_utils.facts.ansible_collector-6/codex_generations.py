

# Generated at 2022-06-20 16:46:42.077593
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # We can't use the regular importer because it isn't setup yet
    class_name = 'ansible.module_utils.facts.cache.file.FileCache'
    module_path = 'ansible.module_utils.facts.cache.file'
    m = __import__(module_path, globals(), locals(), [class_name])
    cls = getattr(m, class_name)
    cache_obj = cls()
    meta_collector = CollectorMetaDataCollector(collectors=[cache_obj],
                                                namespace=cache_obj.get_namespace(),
                                                gather_subset=['hardware', 'network'],
                                                module_setup=True)
    facts_dict = meta_collector.collect()
    assert facts_dict['module_setup']

    # Check for the expected keys in

# Generated at 2022-06-20 16:46:50.885736
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts.collector.base
    from ansible.module_utils.facts import namespace

    # using a "real" collector class here, but any would do
    collector_class = ansible.module_utils.facts.collector.base.BaseFactCollector
    collector_classes = [collector_class]

    # using a "real" namespace class here, but any would do
    namespace_class = namespace.PrefixFactNamespace

    # create a collector to obtain the collectors that were filtered
    fact_collector = \
        get_ansible_collector(all_collector_classes=collector_classes,
                              gather_subset=['all'])

    # get the collectors that were filtered
    collectors = fact_collector.collectors

    # this is what we are testing here
    collector = Ans

# Generated at 2022-06-20 16:46:54.967457
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_collector_classes = ['*']
    test_gather_subset = ['all']
    test_module_setup = True

    meta_data_collector = CollectorMetaDataCollector(
            gather_subset=test_gather_subset,
            module_setup=test_module_setup
    )

    assert meta_data_collector.gather_subset == 'all'
    assert meta_data_collector.module_setup == True

# Generated at 2022-06-20 16:47:06.602743
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector(filter_spec='ansible*')
    assert fact_collector
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert not fact_collector.collectors
    assert fact_collector.filter_spec == 'ansible*'

    fact_collector = AnsibleFactCollector(filter_spec=['ansible*', 'ansible*'])
    assert fact_collector
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert not fact_collector.collectors
    assert fact_collector.filter_spec == ['ansible*', 'ansible*']

    # test filter_spec='' or filter_spec=[] is equivalent to filter_spec='*'
    fact_collector = AnsibleFactCollector()
    assert fact_

# Generated at 2022-06-20 16:47:07.925356
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils import facts

    assert get_ansible_collector(facts.collector_classes)

# Generated at 2022-06-20 16:47:13.149386
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    all_collector_classes = {'all': collector.BaseFactCollector}
    filter_spec = []
    gather_subset = ['all']
    gather_timeout = None
    minimal_gather_subset = frozenset()

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=None,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)

# Generated at 2022-06-20 16:47:26.172125
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Init
    class MockCollector1(collector.BaseFactCollector):
        name = 'MockCollector1'
        _fact_ids = set(['fact1', 'fact2'])
        def collect(self, module=None, collected_facts=None):
            return {'fact1': 'fact1', 'fact2': 'fact2'}

    class MockCollector2(collector.BaseFactCollector):
        name = 'MockCollector2'
        _fact_ids = set(['fact3', 'fact4'])
        def collect(self, module=None, collected_facts=None):
            return {'fact3': 'fact3', 'fact4': 'fact4'}

    class MockCollector3(collector.BaseFactCollector):
        name = 'MockCollector3'
        _

# Generated at 2022-06-20 16:47:39.499987
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.network

    all_collector_classes = [
        ansible.module_utils.facts.collector.system.SystemFactCollector,
        ansible.module_utils.facts.collector.hardware.HardwareFactCollector,
        ansible.module_utils.facts.collector.network.NetworkFactCollector,
    ]
    # test implicit gathering of all collectors
    collector = get_ansible_collector(all_collector_classes,
                                      gather_subset=None)
    assert len(collector.collectors) == 4

# Generated at 2022-06-20 16:47:47.300704
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Verify that the constructor accepts two named arguments,
    # and that they are both optional.
    collector_meta_data_collector = CollectorMetaDataCollector()
    assert not hasattr(collector_meta_data_collector, 'collectors')
    assert not hasattr(collector_meta_data_collector, 'namespace')
    assert hasattr(collector_meta_data_collector, 'gather_subset') and collector_meta_data_collector.gather_subset is None
    assert hasattr(collector_meta_data_collector, 'module_setup') and collector_meta_data_collector.module_setup is None

    # Verify that the constructor accepts two named arguments,
    # and that they are both optional.

# Generated at 2022-06-20 16:47:56.350826
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_classes = [collector.FacterFactCollector, collector.OhaiFactCollector]
    namespace = collector.PrefixFactNamespace(prefix='ansible_')
    gather_subset = ['all']

    collector_meta_data_test = CollectorMetaDataCollector(collector_classes, namespace, gather_subset)

    assert collector_meta_data_test.gather_subset == ['all']
    assert collector_meta_data_test.module_setup == True



# Generated at 2022-06-20 16:48:11.325357
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class Collector(object):
        def __init__(self, data=None):
            self.data = data

        def collect(self, module=None, collected_facts=None):
            return self.data

    class CollectorWithNamespace(object):
        def __init__(self, data=None, namespace=None):
            self.data = data
            self.namespace = namespace

        def collect_with_namespace(self, module=None, collected_facts=None):
            return self.data

    namespace = collector.Namespace(name='namespace_one', prefix='prefix_one')

    collectors = [Collector(data={'fact_one': 'value_one'}),
                  CollectorWithNamespace(data={'fact_two': 'value_two'}, namespace=namespace)]

    fact_collector = AnsibleFactCollect

# Generated at 2022-06-20 16:48:23.422875
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.core import OS_Facts
    from ansible.module_utils.facts.core import Hardware

    gather_subset = ['all', 'min']
    all_collector_classes = [OS_Facts, Hardware]
    minimal_gather_subset = ['min']
    ns = collector.PrefixFactNamespace(prefix='foo_')

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           minimal_gather_subset=minimal_gather_subset,
                                           gather_subset=gather_subset,
                                           namespace=ns)

    # ensure that we have the right collector classes but only once

# Generated at 2022-06-20 16:48:32.335324
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespaces

    try:
        from unittest import mock
    except ImportError:
        import mock

    import ansible.module_utils.facts.collector

    _fake_collector_1 = mock.MagicMock()
    _fake_collector_1.name = 'fake_collector_1'
    _fake_collector_2 = mock.MagicMock()
    _fake_collector_2.name = 'fake_collector_2'
    _fake_collector_3 = mock.MagicMock()
    _fake_collector_3.name = 'fake_collector_3'

    all_collector_classes = [_fake_collector_1, _fake_collector_2, _fake_collector_3]


# Generated at 2022-06-20 16:48:45.386720
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    class simple_mock_collector(collector.BaseFactCollector):
        name = 'test_collector'
        def collect(self, module=None, collected_facts=None):
            return {'first_fact': 'first_fact_value',
                    'second_fact': 'second_fact_value'}

    mock_collector = simple_mock_collector()

    namespace = collector.FactNamespace('test_namespace')

    fact_collector = \
        AnsibleFactCollector(collectors=[mock_collector],
                             namespace=namespace)

    collected_facts = fact_collector.collect()
    assert collected_facts['test_namespace'] == \
        {'first_fact': 'first_fact_value',
         'second_fact': 'second_fact_value'}


#

# Generated at 2022-06-20 16:48:54.716109
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # create test CollectorMetaDataCollector object
    test_collector = CollectorMetaDataCollector(collectors=None, namespace=None, gather_subset=['all'], module_setup=False)

    # Dict with the result of the method collect
    result = test_collector.collect()

    # Create the expected result
    expected = {'gather_subset': ['all']}
    assert result == expected

# Generated at 2022-06-20 16:49:03.023194
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import utils
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.system

    namespace_obj = namespace.PrefixFactNamespace(prefix='ross_')
    fact_collector_obj = \
        get_ansible_collector(all_collector_classes=ansible.module_utils.facts.collector.collectors,
                              namespace=namespace_obj,
                              gather_subset='network',
                              gather_timeout=5,
                              minimal_gather_subset=frozenset())

    module_obj = utils.get_dummy_module()
    fact_collector_obj.collect

# Generated at 2022-06-20 16:49:08.348848
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_obj = \
        CollectorMetaDataCollector(gather_subset=['all','network', 'logname'],
                                   module_setup=True)
    collected_facts = collector_meta_data_collector_obj.collect()

    assert collected_facts == {'gather_subset': ['all','network', 'logname'],
                               'module_setup': True}

# Generated at 2022-06-20 16:49:11.184182
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector(collectors=None,
                                      namespace=None,
                                      gather_subset=['all'],
                                      module_setup=True)


# Generated at 2022-06-20 16:49:21.626252
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.get_fact_collector_classes()

    # This is the minimal set of collectors that should be returned
    minimal_classes = frozenset([
        collector.GenericFactCollector,
        collector.FileGlobFactCollector,
        collector.CommandExistenceFactCollector,
        collector.PythonFactCollector,
        collector.FacterFactCollector,
        collector.OhaiFactCollector,
        collector.InventoryFactCollector,
        collector.CloudFactCollector,
    ])

    fact_collector = \
        get_ansible_collector(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=minimal_classes)

    fact_collector.collect(),


# Generated at 2022-06-20 16:49:32.540798
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # Constructor tests
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.network import NetworkLegacyFactCollector
    from ansible.module_utils.facts.collector.system import SystemLegacyFactCollector

    fact_collector = AnsibleFactCollector()
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.filter_spec is None
    assert fact_collector.namespace is None
    assert fact_collector.collectors == []

    network_collector = NetworkLegacyFactCollector(namespace=PrefixFactNamespace(prefix='ansible_'))
    system_collector = SystemLegacyFactCollector(namespace=PrefixFactNamespace(prefix='ansible_'))


# Generated at 2022-06-20 16:49:51.812626
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # TODO: better test

    import ansible.module_utils.facts.system.base
    from ansible.module_utils.facts import namespace

    all_collector_classes = \
        [ansible.module_utils.facts.system.base.BaseSystemCollector]
    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace_obj,
                              filter_spec=[''],
                              gather_subset=['all'],
                              gather_timeout=10,
                              minimal_gather_subset=frozenset())

    facts_dict = fact_collector.collect()


# Generated at 2022-06-20 16:49:56.698069
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    m1 = AnsibleFactCollector()
    m2 = CollectorMetaDataCollector()
    m3 = AnsibleFactCollector(collectors=[m1, m2])
    assert m3.collect(module=None, collected_facts=None) == {
        'ansible_facts': {
            'gather_subset': None
        }
    }

# Generated at 2022-06-20 16:50:06.138203
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        name = 'test_collector'
        _fact_ids = set(['test_fact', 'test_fact_with_namespace'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value', 'test_fact_with_namespace': 'test_value'}

    class TestNamespace(collector.BaseFactNamespace):
        name = 'test_namespace'

    test_namespace = TestNamespace()

    test_collector = TestCollector(namespace=test_namespace)
    fact_collector = AnsibleFactCollector(collectors=[test_collector])

    result = fact_collector.collect()

    assert 'test_fact' in result

# Generated at 2022-06-20 16:50:16.290955
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    def dummy_collector(namespace=None, filter_spec=None):
        class dummy_collector_obj(object):
            def __init__(self, namespace=None):
                self.namespace = namespace
                self.facts = {'a': 1, 'b': 2, 'ansible_c': 3}

            def collect(self, module=None, collected_facts=None):
                return self.facts

        c = dummy_collector_obj(namespace=namespace)
        return c

    collectors = []
    for i in range(2):
        c = dummy_collector(namespace='foo_%d' % i, filter_spec=['*'])
        collectors.append(c)

    fc = AnsibleFactCollector(collectors=collectors, namespace='ansible')


# Generated at 2022-06-20 16:50:20.051063
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''
    meta_facts = {'gather_subset': 'all'}
    assert(meta_facts == CollectorMetaDataCollector(namespace=None, gather_subset='all', module_setup=True).collect())
    '''
    assert (1 == 1)

# Generated at 2022-06-20 16:50:25.494582
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.namespace

    ns = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')
    assert(isinstance(ns, ansible.module_utils.facts.namespace.PrefixFactNamespace))

    fc = AnsibleFactCollector(namespace=ns)



# Generated at 2022-06-20 16:50:34.184467
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = {
        'all': [collectors.NetworkCollector,
                collectors.PlatformCollector,
                collectors.LocalCollector,
                collectors.HardwareCollector,
                collectors.VirtualCollector],

        'hardware': [collectors.PlatformCollector,
                     collectors.HardwareCollector,
                     collectors.VirtualCollector],

        'network': [collectors.NetworkCollector,
                    collectors.PlatformCollector],

        'facts': [],
        'min': []
    }

    # by default, we gather the 'all' subset

# Generated at 2022-06-20 16:50:40.394831
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class DummyCollector(collector.BaseFactCollector):
        name = 'dummy'

        def collect(self, module=None, gathered_facts=None):
            return {'dummy': 'dummy fact'}

    fact_collector = AnsibleFactCollector([DummyCollector()])

    facts = fact_collector.collect()

    assert facts['ansible_facts']['dummy'] == 'dummy fact'

# Generated at 2022-06-20 16:50:50.297000
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes = [collector.Facter, collector.Ohai]
    gather_subset = ['!facter']
    namespaces = ['facter', 'ohai']
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           gather_subset=gather_subset,
                                           gather_timeout=5,
                                           minimal_gather_subset=[],
                                           namespace=namespaces)
    assert isinstance(fact_collector, AnsibleFactCollector)
    assert isinstance(fact_collector.collectors[0], collector.Ohai)
    for collector_obj in fact_collector.collectors:
        assert isinstance(collector_obj, collector.BaseFactCollector)

# Generated at 2022-06-20 16:50:58.706882
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test that checks the collect method.'''
    gather_subset = ['!all', 'network']
    module_setup = False
    meta_facts = CollectorMetaDataCollector(namespace=None,
                                            gather_subset=gather_subset,
                                            module_setup=module_setup).collect()
    assert (meta_facts['gather_subset'] == gather_subset)
    assert (meta_facts['module_setup'] == module_setup)

# Generated at 2022-06-20 16:51:04.683006
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    CollectorMetaDataCollector(gather_subset='network,all',
                               module_setup=False)
    CollectorMetaDataCollector(gather_subset='all',
                               module_setup=True)

# Generated at 2022-06-20 16:51:13.149507
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    facts_dict = {
        'first': {
            'first_elem': 11
        },
        'ansible_second': {
            'second_elem': 22
        },
        'ansible_third': {
            'third_elem': 33
        }
    }

    def collect():
        return facts_dict

    class MockCollector(object):
        def collect(self):
            return {'a': 1, 'b': 2}

    class MockCollectorWithNamespace(object):
        def collect(self):
            return {'a': 1, 'b': 2}

        def collect_with_namespace(self):
            return {'namespace_test': {'a': 1, 'b': 2}}


# Generated at 2022-06-20 16:51:23.040561
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import time
    from copy import deepcopy
    fact_collector = AnsibleFactCollector()

    class TestCollector1(collector.BaseFactCollector):
        def collect_with_namespace(self, *args, **kwargs):
            return {'foo': 'bar'}

    class TestCollector2(collector.BaseFactCollector):
        def collect_with_namespace(self, *args, **kwargs):
            return {'baz': 'qux'}

    fact_collector.collectors = [TestCollector1(), TestCollector2()]

    result = fact_collector.collect()

    assert result == {'foo': 'bar', 'baz': 'qux'}

    # verify that collected_facts was passed to all collectors
    # and included results of previous collectors


# Generated at 2022-06-20 16:51:32.505485
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.local import LocalFactCollector
    import ansible.module_utils.facts.collector.local

    fact_collector = AnsibleFactCollector(collectors=[LocalFactCollector()],
                                          namespace=PrefixFactNamespace('ansible_'))
    collected_facts = {}
    facts_dict = fact_collector.collect(collected_facts=collected_facts)
    assert len(facts_dict) > 0



# Generated at 2022-06-20 16:51:40.665658
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collectors = [collector.FacterCollector()]
    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec=['fact1', 'fact2'])
    assert fact_collector
    assert fact_collector.collectors == collectors
    assert fact_collector.filter_spec == ['fact1', 'fact2']



# Generated at 2022-06-20 16:51:48.614835
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for method collect of class AnsibleFactCollector'''
    class TestCollector1(collector.BaseFactCollector):
        '''Simple test collector that returns a constant fact'''
        def collect(self, module=None, collected_facts=None):
            '''always return a constant fact'''
            return {'test_collector1': 'foo'}

    class TestCollector2(collector.BaseFactCollector):
        '''Simple test collector that returns a constant fact'''
        def collect(self, module=None, collected_facts=None):
            '''always return a constant fact'''
            return {'test_collector2': 'bar'}

    test_collector1 = TestCollector1()
    test_collector2 = TestCollector2()
    fact_collector = AnsibleFact

# Generated at 2022-06-20 16:51:54.163796
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    c = AnsibleFactCollector(collectors=[])
    if c:
        sys.stdout.write('test_AnsibleFactCollector() success\n')
    else:
        sys.stdout.write('test_AnsibleFactCollector() failed\n')



# Generated at 2022-06-20 16:52:05.508302
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Test the AnsibleFactCollector.collect() method.'''
    from ansible.module_utils.facts import ansible_collector

    # This fact collector should have no collectors in it. It's for testing only.
    test_collector = AnsibleFactCollector()

    # If you need an AnsibleFactCollector that does useful things, then just insist on it, as below:
    basic_collector = ansible_collector.get_collector('basic')

    # Setup for the test
    module_directory = {}
    collected_facts = {}

    # This is the test, calling collect with an empty collector should produce an empty dict
    result = test_collector.collect(module=module_directory, collected_facts=collected_facts)
    assert isinstance(result, dict)
    assert len(result) == 0

    #

# Generated at 2022-06-20 16:52:08.010142
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gather_subset = 'test'
    module_setup = True

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset,
                                                               module_setup=module_setup)

    meta_facts = collector_meta_data_collector.collect(module=None, collected_facts=None)

    assert meta_facts['gather_subset'] == gather_subset
    assert meta_facts['module_setup'] == module_setup

# Generated at 2022-06-20 16:52:20.269272
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    """
    This constructs an AnsibleFactCollector that filters facts.
    :return: Resulting fact collector
    """

    # list of namespaces - note that these are actual Ansible modules that may not be loaded
    # when this snippet is used
    ansible_namespaces = [
        'ansible_lsb',
        'ansible_local',
        'ansible_machine',
        'ansible_net_all_ipv4_addresses',
        'ansible_os_family',
        'ansible_processor_count',
        'ansible_processor_cores',
        'ansible_processor_threads_per_core',
        'ansible_processor_vcpus',
    ]

    # empty namespace
    collector_fact_namespaces = [
        collector.EmptyFactNamespace(),
    ]

    #

# Generated at 2022-06-20 16:52:37.459614
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    
    from ansible.module_utils.facts import get_all_collector_classes
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    all_collector_classes = get_all_collector_classes()
    fact_collector_1 = get_ansible_collector(all_collector_classes=all_collector_classes,
                                             gather_subset=['all'],
                                             namespace=None,
                                             filter_spec=None)

# Generated at 2022-06-20 16:52:43.627698
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import os
    import sys
    import unittest
    from ansible.module_utils.facts import default

    import ansible.module_utils.facts.namespace as namespace

    class MockCollector(collector.BaseFactCollector):
        '''Mock to represent a fact collector'''
        name = 'mock_collector'
        _fact_ids = set(['mock_id'])

        def collect(self, module=None, collected_facts=None):
            facts_dict = {
                'mock_id': 'foo',
                'mock_id_2': 'bar',
                'mock_id_3': 'baz',
            }
            return facts_dict


# Generated at 2022-06-20 16:52:47.990317
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               module_setup=True)
    assert collector_meta_data_collector.name == 'gather_subset'
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup is True


# Generated at 2022-06-20 16:52:59.580485
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.timeout import TimeoutFactCollector

    class DummyBase(BaseFactCollector):
        name = 'dummy1'

    class DummyBase2(BaseFactCollector):
        name = 'dummy2'

    collector_classes = [DummyBase, DummyBase2]

    collector = get_ansible_collector(all_collector_classes=collector_classes,
                                      gather_subset=['dummy1', 'dummy2', 'all'],
                                      gather_timeout=30,
                                      minimal_gather_subset=['all'])
    assert len(collector.collectors) == 3
    assert isinstance(collector.collectors[0], DummyBase)
   

# Generated at 2022-06-20 16:53:10.218352
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # override/mock the objects used by AnsibleFactCollector.collect()
    class CollectorTestMetaDataCollector(CollectorMetaDataCollector):
        def collect(self, module=None, collected_facts=None):
            return {'module_setup': False}

    class CollectorTest1:
        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    class CollectorTest2:
        def collect(self, module=None, collected_facts=None):
            return {'ansible_bar': 'baz'}

    collectors = [CollectorTest1(), CollectorTest2()]

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=None,
                             filter_spec='*')


# Generated at 2022-06-20 16:53:21.304154
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    from ansible.module_utils.facts import namespace as fact_namespaces
    collector_classes = \
        ansible.module_utils.facts.collector.network.collector_classes()

    filter_spec = []
    gather_subset = ['all']
    gather_timeout = 10
    minimal_gather_subset = frozenset()

    fact_collector = get_ansible_collector(collector_classes,
                                           filter_spec=filter_spec,
                                           gather_subset=gather_subset,
                                           gather_timeout=gather_timeout,
                                           minimal_gather_subset=minimal_gather_subset)

    prefix_fact_namespace = fact_namespaces.PrefixFactNamespace

# Generated at 2022-06-20 16:53:22.610939
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gatherer = CollectorMetaDataCollector(collectors=None,
                                          namespace=None,
                                          gather_subset=None,
                                          module_setup=True)
    assert gatherer is not None

# Generated at 2022-06-20 16:53:29.057766
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_gather_subset = 'all'
    test_gather_timeout = 10
    test_module_setup = True
    test_collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=test_gather_subset,
                                   gather_timeout=test_gather_timeout,
                                   module_setup=test_module_setup)
    # Test when module == None and collected_facts == None
    test_result = test_collector_meta_data_collector.collect()
    assert test_result == {'gather_subset': test_gather_subset, 'module_setup': test_module_setup}

# Generated at 2022-06-20 16:53:30.666194
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert AnsibleFactCollector()

# Generated at 2022-06-20 16:53:32.699347
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert CollectorMetaDataCollector(gather_subset=['all']) is not None

# Generated at 2022-06-20 16:53:45.971879
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = None
    namespace = None

    gather_subset = ['!all', 'network']
    module_setup = True

    c = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)
    assert isinstance(c, CollectorMetaDataCollector)

    f = c.collect()
    assert f == {'gather_subset': ['!all', 'network'], 'module_setup': True}

    # Test init with 'all'
    collectors = None
    namespace = None

    gather_subset = ['all']
    module_setup = None

    c = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)
    assert isinstance(c, CollectorMetaDataCollector)

    f = c.collect()

# Generated at 2022-06-20 16:53:51.378008
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    result = meta_collector.collect()
    assert result == {'gather_subset': ['all'], 'module_setup': True}



# Generated at 2022-06-20 16:53:58.098655
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class MyFactCollector(collector.BaseFactCollector):
        name = 'mycollector'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'myfact': 'myvalue'}

    class MyFactCollector2(collector.BaseFactCollector):
        name = 'mycollector2'
        _fact_ids = set([])

        def __init__(self, namespace=None, filter_spec=None):
            super(MyFactCollector2, self).__init__(namespace=namespace)
            self.filter_spec = filter_spec

        def collect(self, module=None, collected_facts=None):
            return {'myfact2': 'myvalue2'}


# Generated at 2022-06-20 16:54:08.646992
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.system.os as os_collector
    import ansible.module_utils.facts.system.distribution as distribution_collector

    all_collector_classes = (os_collector.Collector, distribution_collector.Collector)

    def _test_get_ansible_collector(gather_subset=None,
                                    gather_timeout=None,
                                    minimal_gather_subset=None,
                                    expected_collectors=None):
        if not expected_collectors:
            expected_collectors = [os_collector.Collector,
                                   distribution_collector.Collector]

# Generated at 2022-06-20 16:54:11.110391
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector = CollectorMetaDataCollector(module_setup=True)
    assert collector.module_setup is True


# Generated at 2022-06-20 16:54:16.649000
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    meta_facts = meta_data_collector.collect()
    assert 'gather_subset' in meta_facts
    assert 'all' in meta_facts['gather_subset']
    assert 'module_setup' in meta_facts
    assert meta_facts['module_setup'] is True

# Generated at 2022-06-20 16:54:20.014755
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True


# Generated at 2022-06-20 16:54:29.474003
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collection import any_file_not_found

    from ansible.module_utils.facts.collectors.all import AllFactCollector
    from ansible.module_utils.facts.collectors.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.collectors.dpkg import DpkgFactCollector
    from ansible.module_utils.facts.collectors.pkg_mgr import RpmFactCollector
    from ansible.module_utils.facts.collectors.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collectors.distribution import DistributionCollector

    all_classes = [AllFactCollector, PkgMgrFactCollector, DistributionCollector]

    ansible_collector = \
        get

# Generated at 2022-06-20 16:54:36.751242
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):
        # maintain a set of fact ids
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    test_collector_obj = TestCollector()

    ansible_fact_collector = AnsibleFactCollector(collectors=[test_collector_obj], filter_spec='test*')

    facts = ansible_fact_collector.collect()

    assert len(facts) == 1
    assert facts['test_fact'] == 'test_fact_value'

# Generated at 2022-06-20 16:54:46.030785
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    def mock_collect_with_namespace(module=None,
                                    collected_facts=None):
        return {'fact1': 'one', 'fact2': 'two'}

    # Mock class of a FactCollector
    class MockClass(object):

        # a class attribute that is a string
        name = 'foo'

        # A class method, to simulate collect_with_namespace method
        def collect_with_namespace(self, module=None,
                                   collected_facts=None):
            # return a dict
            return mock_collect_with_namespace(module, collected_facts)

    # mock an instance of a FactCollector
    mock_obj = MockClass()

    # construct the AnsibleFactCollector instance
    # NOTE: Passing any namespace to this object is optional. The example we use here
    # is not a

# Generated at 2022-06-20 16:54:56.445531
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import system

    all_collector_classes = set([collector.NetworkCollector,
                                 collector.HardwareCollector,
                                 collector.VirtualCollector,
                                 collector.PlatformCollector,
                                 system.SystemCollector])

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace='ansible',
                                           gather_subset=['all'])

    assert isinstance(fact_collector, AnsibleFactCollector), "FactCollector not created"

    facts = fact_collector.collect()

    # We should get a gather_subset key if we ask for all facts
    assert 'ansible_facts' in facts

# Generated at 2022-06-20 16:55:04.727175
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    class TestFactCollector(collector.BaseFactCollector):
        name = 'test'

    all_collectors_classes = [TestFactCollector]
    ansible_fact_collector = get_ansible_collector(all_collector_classes=all_collectors_classes)
    assert len(ansible_fact_collector.collectors) == 2
    assert isinstance(ansible_fact_collector.collectors[0], TestFactCollector)
    assert isinstance(ansible_fact_collector.collectors[1], CollectorMetaDataCollector)

# Generated at 2022-06-20 16:55:14.627600
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # no namespace
    fact_collector = AnsibleFactCollector()
    assert fact_collector
    assert fact_collector.filter_spec is None
    assert not fact_collector.namespace

    # namespace but no filter_spec
    fact_collector = AnsibleFactCollector(namespace='ansible.')
    assert fact_collector
    assert fact_collector.filter_spec is None
    assert fact_collector.namespace
    assert fact_collector.namespace.prefix == 'ansible.'
    assert fact_collector.namespace.sep == '_'

    # namespace and filter_spec
    fact_collector = AnsibleFactCollector(namespace='ansible.', filter_spec=['*', '!network'])
    assert fact_collector
    assert fact_collector.filter_spec

# Generated at 2022-06-20 16:55:26.120648
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """Unit testing for method collect of class AnsibleFactCollector"""

    import unittest
    import mock
    mock.patch = mock.patch('mock.patch')
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts import timeout

    class Collector():
        def __init__(self):
            pass
        def collect(self):
            return {
                'test1': 'test1',
                'test2': 'test2',
                'test3': 'test3',
                'test4': 'test4',
                'test5': 'test5',
                'test6': 'test6',
                'test7': 'test7',
                'test8': 'test8',
            }


# Generated at 2022-06-20 16:55:38.064194
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import BaseFactCollector, \
        NetworkFactCollector, DummyNetworkFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.fact_cache
    from ansible.module_utils.facts.utils import get_collector_as_list

    # if gather_subset is empty we should have _all_ collectors
    collector = get_ansible_collector(get_collector_as_list(),
                                      gather_subset=[])
    assert len(collector.collectors) == len(collector_classes)

    # if gather_subset is ['all'] we should have _all_ collectors

# Generated at 2022-06-20 16:55:44.130993
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespace

    fake_namespace = namespace.AnsibleNamespace()

    collectors = ['test1', 'test2']
    filter_spec = ['test_filter']
    ansible_fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec=filter_spec,
                             namespace=fake_namespace)

    assert ansible_fact_collector.collectors == collectors
    assert ansible_fact_collector.filter_spec == filter_spec
    assert ansible_fact_collector.namespace == fake_namespace


# Generated at 2022-06-20 16:55:56.541763
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class MockFactCollectorA(collector.BaseFactCollector):
        name = 'mock_fact_collector_a'
        def collect(self, module=None, collected_facts=None):
            return {'a': 1}

    class MockFactCollectorB(collector.BaseFactCollector):
        name = 'mock_fact_collector_b'
        def collect(self, module=None, collected_facts=None):
            return {'b': 2}

    class MockFactCollectorC(collector.BaseFactCollector):
        name = 'mock_fact_collector_c'
        def collect(self, module=None, collected_facts=None):
            return {'c': 3}


# Generated at 2022-06-20 16:56:08.245307
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # data input
    test_all_collector_classes = None
    test_ns = None
    test_gather_subset = ['all']
    test_module_setup = None

    # construct object
    collector_meta_data_collector = CollectorMetaDataCollector(test_all_collector_classes, test_ns, test_gather_subset, test_module_setup)

    # test results
    assert collector_meta_data_collector.__getattribute__("_fact_ids") == set([])
    assert collector_meta_data_collector.__getattribute__("name") == 'gather_subset'
    assert collector_meta_data_collector.__getattribute__("gather_subset") == test_gather_subset
    assert collector_meta_data_collector.__getattribute__

# Generated at 2022-06-20 16:56:17.118421
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollector(object):
        pass

    class MockTestCollector(MockCollector):
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'test': {'one': 1}}

    class MockTest2Collector(MockCollector):
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'test2': {'two': 2}}

    # Test that a single collector just returns the facts it collects
    c = AnsibleFactCollector([MockTestCollector()])
    assert c.collect() == {'test': {'one': 1}}

    # Test that a 2 collectors return both facts they collect
    c = AnsibleFactCollector([MockTestCollector(), MockTest2Collector()])

# Generated at 2022-06-20 16:56:26.263369
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_collector = CollectorMetaDataCollector(gather_subset='all')
    meta_facts = meta_collector.collect()
    assert meta_facts == {'gather_subset': 'all'}

    meta_collector = CollectorMetaDataCollector(gather_subset='all',
                                                module_setup=True)
    meta_facts = meta_collector.collect()
    assert meta_facts == {'gather_subset': 'all', 'module_setup': True}