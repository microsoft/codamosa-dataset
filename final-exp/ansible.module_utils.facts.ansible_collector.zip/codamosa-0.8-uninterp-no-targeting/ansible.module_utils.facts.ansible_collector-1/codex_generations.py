

# Generated at 2022-06-20 16:46:28.556263
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    ansible_fact_collector = AnsibleFactCollector(collectors=[get_collector(None, None)])
    filter_spec = []
    assert ansible_fact_collector.collect(collected_facts={}) == dictionary_to_collect(filter_spec)



# Generated at 2022-06-20 16:46:35.890412
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform

    fc = AnsibleFactCollector(collectors=[
        ansible.module_utils.facts.system.distribution.DistributionFactCollector(),
        ansible.module_utils.facts.system.platform.PlatformFactCollector()])

    facts = fc.collect()
    assert 'ansible_system' in facts
    assert 'ansible_distribution' in facts
    assert 'ansible_distribution_version' in facts
    assert 'ansible_distribution_release' in facts
    assert 'ansible_distribution_major_version' in facts
    assert 'ansible_distribution_release' in facts

# Generated at 2022-06-20 16:46:40.629995
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_classes = []
    collector_classes.append(collector.FileDataCollector)
    collector_classes.append(collector.FileDataCollector)

    ansible_fact_collector = \
        AnsibleFactCollector(collector_classes, namespace=None, filter_spec=None)

    assert len(ansible_fact_collector.collectors) == 2

    ansible_fact_collector = \
        AnsibleFactCollector(collector_classes, namespace=None, filter_spec='')
    assert len(ansible_fact_collector.collectors) == 2

    ansible_fact_collector = \
        AnsibleFactCollector(collector_classes, namespace=None, filter_spec=[])
    assert len(ansible_fact_collector.collectors) == 2

    ansible_fact

# Generated at 2022-06-20 16:46:50.023315
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collectors = get_ansible_collector(all_collector_classes=None,
                                       gather_subset=None,
                                       gather_timeout=None,
                                       minimal_gather_subset=None)

    assert collectors
    assert collectors.collectors
    assert collectors.collectors[-1].name == 'gather_subset'

    results = collectors.collect()
    assert results
    assert results['gather_subset'] == ['all']

# Generated at 2022-06-20 16:46:56.138987
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''Test that CollectorMetaDataCollector.collect returns json
       with 'gather_subset' and 'module_setup'.'''

    # Test gather_subset='all'
    collector = CollectorMetaDataCollector(gather_subset=['all'],
                                           module_setup=True)
    assert collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

    # Test gather_subset=[]
    collector = CollectorMetaDataCollector(gather_subset=[],
                                           module_setup=True)
    assert collector.collect() == {'gather_subset': [], 'module_setup': True}

    # Test gather_subset='' (empty string)

# Generated at 2022-06-20 16:47:02.780721
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fc1 = AnsibleFactCollector()
    fc2 = AnsibleFactCollector(filter_spec=['foo', 'bar'])
    fc3 = AnsibleFactCollector(filter_spec='')
    fc4 = AnsibleFactCollector(filter_spec=[])

    assert fc1.filter_spec == '*'
    assert fc2.filter_spec == ['foo', 'bar']
    assert fc3.filter_spec == '*'
    assert fc4.filter_spec == '*'

# Generated at 2022-06-20 16:47:14.436136
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # class CollectorMetaDataCollector(collector.BaseFactCollector):
    collectors=[]
    namespace = None
    gather_subset = ['all']
    module_setup=['s']
    # def __init__(self, collectors=None, namespace=None, gather_subset=None, module_setup=None):
    c = CollectorMetaDataCollector(collectors=collectors, namespace=namespace, gather_subset=gather_subset, module_setup=module_setup)
    assert c.gather_subset == gather_subset
    assert c.module_setup == module_setup
    return c


# Generated at 2022-06-20 16:47:23.269205
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collection_obj = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    # Check the values of collector instance variables
    assert fact_collection_obj.name == 'gather_subset'
    assert fact_collection_obj.gather_subset == ['all']
    assert fact_collection_obj.module_setup is True

# Generated at 2022-06-20 16:47:29.776389
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils.facts.collector.network

    collector_classes = [
        ansible.module_utils.facts.collector.network.NetworkCollector,
        CollectorMetaDataCollector
    ]
    collectors = [collector_class(namespace=None) for collector_class in collector_classes]
    collector_meta_data_collector = collectors[1]

    assert collector_meta_data_collector.name == 'gather_subset'
    assert collector_meta_data_collector.gather_subset == []
    assert collector_meta_data_collector.module_setup is False


# Generated at 2022-06-20 16:47:30.599360
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-20 16:47:41.157884
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    class DummyCollector(collector.BaseFactCollector):
        name = 'dummy'
        _fact_ids = set(['one'])

        def collect(self, module=None, collected_facts=None):
            return {'one': 1}

    fake_collector_classes = [DummyCollector]
    fact_collector = get_ansible_collector(all_collector_classes=fake_collector_classes,
                                           gather_subset=['all'])
    facts = fact_collector.collect()
    assert type(facts) == dict
    assert facts == {'gather_subset': ['all'], 'one': 1}

# Generated at 2022-06-20 16:47:49.759875
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.namespace.prefix import PrefixFactNamespace

    from_gather_subset_collectors = [NetworkCollector, SystemCollector]
    namespace = PrefixFactNamespace(prefix='ansible_')
    gather_subset = ['network', 'all']
    module_setup = True
    c = CollectorMetaDataCollector(collectors=from_gather_subset_collectors,
                                   namespace=namespace,
                                   gather_subset=gather_subset,
                                   module_setup=module_setup)

    # expected

# Generated at 2022-06-20 16:47:55.847534
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default
    for gather_subset in [['all'], ['!all'], ['network'], ['!network']]:
        fact_collector = get_ansible_collector([default],
                                               gather_subset=gather_subset)
        assert fact_collector is not None

# Generated at 2022-06-20 16:48:09.023466
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    # Tests no module_setup
    meta_collector = CollectorMetaDataCollector(gather_subset='all')
    assert meta_collector.collect() == {'gather_subset': 'all'}

    meta_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=False)
    assert meta_collector.collect() == {'gather_subset': 'all'}

    # Tests when module_setup module
    meta_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert meta_collector.collect() == {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-20 16:48:20.899757
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=1,
                                           minimal_gather_subset=None)
    assert fact_collector is not None
    assert len(fact_collector.collectors) > 0

    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=['all'],
                                           gather_timeout=1,
                                           minimal_gather_subset=None)
    assert fact_collector is not None
    assert len(fact_collector.collectors)

# Generated at 2022-06-20 16:48:22.995473
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_class = AnsibleFactCollector()
    assert collector_class.collectors == []
    assert collector_class.namespace is None
    assert collector_class.filter_spec is None


# Generated at 2022-06-20 16:48:31.170618
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    empty_all_collector_classes = []
    namespace = None
    filter_spec = None
    gather_subset = []
    gather_timeout = None
    minimal_gather_subset = None
    module_setup = False
    obj = CollectorMetaDataCollector(all_collector_classes=empty_all_collector_classes,
                                     namespace=namespace,
                                     filter_spec=filter_spec,
                                     gather_subset=gather_subset,
                                     gather_timeout=gather_timeout,
                                     minimal_gather_subset=minimal_gather_subset,
                                     module_setup=module_setup)

    module = None
    collected_facts = None

    # Test function call
    meta_facts = obj.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-20 16:48:42.084952
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class MockCollectorA(collector.BaseFactCollector):
        name = 'a'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            info_dict = {
                self.get_fact_id('collected_facts'): collected_facts,
            }
            return info_dict

    class MockCollectorB(collector.BaseFactCollector):
        name = 'b'

        def collect(self, module=None, collected_facts=None):
            info_dict = {'b': {'b1': 'b1', 'b2': 'b2'}}
            return info_dict

    mock_collector_a = MockCollectorA()
    mock_collector_b = MockCollectorB()

    fact_collector = \
        Ans

# Generated at 2022-06-20 16:48:49.079274
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector

    class DummyCollector1(ansible.module_utils.facts.collector.BaseFactCollector):

        name = 'dummy1'

        _fact_ids = set([])

        def __init__(self):
            pass

        def collect(self, module=None, collected_facts=None):
            return {'dummy1': 42}

    class DummyCollector2(ansible.module_utils.facts.collector.BaseFactCollector):

        name = 'dummy2'

        _fact_ids = set([])

        def __init__(self):
            pass

        def collect(self, module=None, collected_facts=None):
            return {'dummy2': 43}


# Generated at 2022-06-20 16:48:59.158888
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.namespace.prefix import PrefixFactNamespace
    from ansible.module_utils.facts.namespace.network import NetworkNamespaceModuleSetup

    collectors = [NetworkCollector(namespace=NetworkNamespaceModuleSetup())]

    namespace_obj = PrefixFactNamespace(prefix='ansible_')

    ansible_fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=namespace_obj)

    assert ansible_fact_collector.collectors == collectors
    assert ansible_fact_collector.namespace == namespace_obj



# Generated at 2022-06-20 16:49:07.814224
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    os_collector_class = collector.get_collector_class('os')
    collectors = \
        get_ansible_collector(all_collector_classes=[os_collector_class],
                              gather_subset=['os']).collectors

    assert os_collector_class in [type(x) for x in collectors]
    assert CollectorMetaDataCollector in [type(x) for x in collectors]

# Generated at 2022-06-20 16:49:19.778922
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # pylint: disable=unused-variable
    from ansible.module_utils.facts.collector import CommandLineValuesCollector
    from ansible.module_utils.facts.collector import NetworkCollector

    fact_collector = get_ansible_collector([CommandLineValuesCollector, NetworkCollector],
                                           gather_subset=['all'],
                                           filter_spec=['facter*', 'ec2*'])
    # pylint: enable=unused-variable

    assert len(fact_collector.collectors) == 3

    # make sure that the metadata collector is last
    assert isinstance(fact_collector.collectors[-1], CollectorMetaDataCollector)

# Generated at 2022-06-20 16:49:25.115237
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset='some_subset', module_setup=True)
    assert c.collect() == {'gather_subset': 'some_subset', 'module_setup': True}

# Generated at 2022-06-20 16:49:33.500525
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.collector as collector_obj
    assert collector_obj.CollectorMetaDataCollector.collect() == {'gather_subset': None}
    assert collector_obj.CollectorMetaDataCollector.collect(gather_subset=['all']) == {'gather_subset': ['all']}
    assert collector_obj.CollectorMetaDataCollector.collect(gather_subset=['all'], module_setup=False) == {'gather_subset': ['all']}
    assert collector_obj.CollectorMetaDataCollector.collect(gather_subset=['all'], module_setup=True) == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-20 16:49:42.038305
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(gather_subset=['network', 'all'])

    # collect 'network', 'all'
    expected = {'gather_subset': ['network', 'all']}
    actual = c.collect()
    assert actual == expected

    # collect 'all'
    c.set_gather_subset(gather_subset=['all'])
    expected = {'gather_subset': ['all']}
    actual = c.collect()
    assert actual == expected

    # collect 'default'
    c.set_gather_subset(gather_subset=['default'])
    expected = {'gather_subset': ['default']}
    actual = c.collect()
    assert actual == expected

    # collect 'min'
    c.set_gather_

# Generated at 2022-06-20 16:49:50.332534
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils import facts
    import os

    def default_collector(facts_module):
        try:
            return os.path.dirname(facts_module.__file__)
        except AttributeError:
            return

    fact_collector = get_ansible_collector(all_collector_classes=facts.collector_classes(),
                                           gather_subset='min',
                                           filter_spec=['*'])

    facts_d = fact_collector.collect()
    del facts_d['ansible_version']   # we don't want to test this


# Generated at 2022-06-20 16:50:03.614147
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import ansible_distribution
    from ansible.module_utils.facts import ansible_distribution_version
    from ansible.module_utils.facts import ansible_pkg_mgr
    from ansible.module_utils.facts import ansible_os_family
    from ansible.module_utils.facts import ansible_all_ipv4_addresses

    class MockCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}


# Generated at 2022-06-20 16:50:15.402853
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # For unit test, we will use the following mock collectors
    # each collector will return a set of facts
    class MockCollector1(collector.BaseFactCollector):
        name = 'MockCollector1'
        _fact_ids = set([('MockFacts1', 'MockFact1'),
                       ('MockFacts1', 'MockFact2')])

        def collect(self, module=None, collected_facts=None):
            return {'MockFact1': 'MockFact1Value',
                    'MockFact2': 'MockFact2Value'}

    class MockCollector2(collector.BaseFactCollector):
        name = 'MockCollector2'

# Generated at 2022-06-20 16:50:25.702066
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector, NamespaceFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = AnsibleFactCollector()
    assert isinstance(fact_collector, BaseFactCollector)
    assert fact_collector.fact_ids == set()
    assert fact_collector.collectors == list()
    assert fact_collector.namespace is None

    fact_collector = AnsibleFactCollector(namespace=PrefixFactNamespace(prefix='ansible_'))
    assert isinstance(fact_collector, BaseFactCollector)
    assert fact_collector.fact_ids == set()
    assert fact_collector.collectors == list()

# Generated at 2022-06-20 16:50:32.937010
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.FACT_COLLECTOR_CLASSES,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=['network'],
                                           gather_timeout=None,
                                           minimal_gather_subset=frozenset())
    # TODO: implement test_AnsibleFactCollector_collect()

# Generated at 2022-06-20 16:50:59.308940
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_meta_data_collector = \
        CollectorMetaDataCollector(collectors=None,
                                   namespace=None,
                                   gather_subset=[],
                                   module_setup=False)

    module_param = {'ANSIBLE_MODULE_ARGS': {}}
    collected_facts = {}

    result = collector_meta_data_collector.collect(module=module_param, collected_facts=collected_facts)

    assert result == {'gather_subset': [], 'module_setup': False}



# Generated at 2022-06-20 16:51:11.726421
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # 1) Test when there are no collectors and no namespace

    collectors = []
    namespace = None

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=namespace)

    facts = fact_collector.collect()
    assert facts == {}

    # 2) Test when there are no collectors and a namespace

    collectors = []
    n = collector.PrefixFactNamespace(prefix='ansible_')
    namespace = n

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             namespace=namespace)

    facts = fact_collector.collect()
    assert facts == {'ansible_facts': {}}

    # 3) Test when there is one collector and no namespace

    class TestCollector(collector.BaseFactCollector):
        name

# Generated at 2022-06-20 16:51:22.221756
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts import namespaced_fact_collector
    import ansible.module_utils.facts.collector.network

    '''Test the AnsibleFactCollector class.'''

    class LocalLinuxFactCollector(ansible.module_utils.facts.collector.network.LinuxIfconfigNetFactCollector):
        '''A class to test that the collect method of AnsibleFactCollector handles exceptions and runs child collectors.'''
        def __init__(self, *args, **kwargs):
            super(LocalLinuxFactCollector, self).__init__(*args, **kwargs)
            self._something = 'something'

        def collect_with_namespace(self, module=False, collected_facts=None):
            collected_facts = collected_facts or {}


# Generated at 2022-06-20 16:51:33.954802
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    collector_meta_data_collector.collect()

    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['network'],
                                   module_setup=False)
    collector_meta_data_collector.collect()

    assert collector_meta_data_collector.gather_subset == ['network']
    assert collector_meta_data_collector.module_setup == False


# Generated at 2022-06-20 16:51:43.702839
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    all_collector_classes = ansible_collector.collector_classes

    namespace_obj = namespace.PrefixFactNamespace(prefix='ansible_')

    subset_filter_spec = ['!ansible_cmdline']

    c = get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace_obj,
                              filter_spec=subset_filter_spec,
                              gather_subset='min')

    # make sure we have a CollectorMetaDataCollector as the last collector
    # in the list

# Generated at 2022-06-20 16:51:50.381736
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_collector = CollectorMetaDataCollector(gather_subset=['all'])
    assert meta_collector.collect()['gather_subset'] == ['all']
    meta_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=False)
    assert meta_collector.collect()['gather_subset'] == ['all']
    assert 'module_setup' not in meta_collector.collect()
    meta_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert meta_collector.collect()['gather_subset'] == ['all']
    assert meta_collector.collect()['module_setup'] == True

# Generated at 2022-06-20 16:51:59.086955
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    namespace = None
    filter_spec = ['ansible_all', 'ansible_*']
    gather_subset = ['all', '*']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    fact_collector = \
        get_ansible_collector(namespace=namespace,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)

    assert(fact_collector is not None)

    assert(fact_collector.namespace == None)
    assert(fact_collector.filter_spec == filter_spec)


# Generated at 2022-06-20 16:52:05.513152
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Test for function get_ansible_collector.'''
    import ansible.module_utils.facts.collector

    all_collector_classes = ansible.module_utils.facts.collector.BaseFactCollector.get_fact_collector_classes()
    collect = get_ansible_collector(all_collector_classes=all_collector_classes,
                                    gather_subset=['all'],
                                    gather_timeout=5)

    facts = collect.collect()

    assert 'ansible_facts' in facts, facts
    assert 'ansible_all_ipv4_addresses' in facts['ansible_facts']

# Generated at 2022-06-20 16:52:10.484438
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collectors

    fact_collector = \
        get_ansible_collector(collectors=collectors.all_collector_classes,
                              namespace='test_namespace.',
                              filter_spec='ansible_*',
                              gather_subset=['min'],
                              gather_timeout=10,
                              minimal_gather_subset=['min'])

    assert 'gather_subset' in fact_collector.collectors[0].name
    assert 'gather_subset' in fact_collector.collectors[0]._fact_ids
    assert 'module_setup' in fact_collector.collectors[0].name
    assert 'module_setup' in fact_collector.collectors[0]._fact_ids

# Generated at 2022-06-20 16:52:17.765999
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts import collector_base
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    False_prefix = PrefixFactNamespace('FALSE')
    True_prefix = PrefixFactNamespace('TRUE')
    False_collector_obj = \
        AnsibleFactCollector(collectors=[],
                             namespace=False_prefix,
                             filter_spec='FALSE')
    True_collector_obj = \
        AnsibleFactCollector(collectors=[],
                             namespace=True_prefix,
                             filter_spec='TRUE')

    # Create a collector for collect the facts
    def MockCollectorClass(namespace):
        class CollectMock(collector_base.BaseFactCollector):
            name = 'mock_collector'
            _fact

# Generated at 2022-06-20 16:52:39.672800
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector(filter_spec='*')
    assert fact_collector.filter_spec == '*'

    fact_collector = AnsibleFactCollector(filter_spec=['*'])
    assert fact_collector.filter_spec == ['*']

    fact_collector = AnsibleFactCollector(filter_spec=['a', 'b', 'c'])
    assert fact_collector.filter_spec == ['a', 'b', 'c']



# Generated at 2022-06-20 16:52:48.649513
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.network.bond as bond
    import ansible.module_utils.facts.network.interfaces as interfaces
    import ansible.module_utils.facts.network.ipv4 as ipv4
    import ansible.module_utils.facts.network.ipv6 as ipv6
    import ansible.module_utils.facts.cache as cache
    import ansible.module_utils.facts.virtual as virtual

    all_collector_classes = [bond.BondFactCollector,
                             interfaces.InterfaceFactCollector,
                             ipv4.IPv4FactCollector,
                             ipv6.IPv6FactCollector,
                             cache.CacheFactCollector,
                             virtual.VirtualFactCollector]


# Generated at 2022-06-20 16:52:53.625653
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts = collector.collect()

    assert facts['gather_subset'] == ['all']
    assert facts['module_setup']

# Generated at 2022-06-20 16:53:02.256211
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ''' Unit Test for AnsibleFactCollector class'''

    # test constructor
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    class MyCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        name = 'myfact'

        def collect(self):
            return {'myfact': 'myvalue'}

    class MyNamespace(ansible.module_utils.facts.namespace.BaseFactNamespace):
        name = 'myfact'

        def get_facts(self, facts_dict):
            return {'myfact': {'myfact': facts_dict['myfact']}}

    collector = MyCollector(namespace=MyNamespace())

# Generated at 2022-06-20 16:53:08.189759
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            return {'test': 'ok'}

    c1 = TestCollector()
    fact_collector = AnsibleFactCollector(collectors=[c1])
    result = fact_collector.collect()
    assert result == {'test': 'ok'}


# Generated at 2022-06-20 16:53:18.292472
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # TODO: Move this to a unit test module
    class TestCollector1():

        name = 'test_collector_1'

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'ansible_test_collector_1': 'test fact 1'}

    class TestCollector2():

        name = 'test_collector_2'

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'ansible_test_collector_2': 'test fact 2'}

    class TestCollector3():

        name = 'test_collector_3'


# Generated at 2022-06-20 16:53:27.504951
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_collector_result_1': True}

    class TestCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_collector_result_2': False}

    test_collector_obj = TestCollector()
    test_collector_obj2 = TestCollector2()

    fact_collector = AnsibleFactCollector(collectors=[test_collector_obj, test_collector_obj2])

    assert fact_collector.collect() == \
        {'test_collector_result_1': True, 'test_collector_result_2': False}


# Unit test

# Generated at 2022-06-20 16:53:38.263055
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import os
    import shutil

    from ansible.module_utils.facts.namespace import FactNamespace

    from ansible.module_utils.facts.platform.dist import DistFactCollector

    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.virtual.base import VirtualFactCollector
    from ansible.module_utils.facts.virtual.lxc import LXCFactCollector
    from ansible.module_utils.facts.virtual.openvz import OpenVZFactCollector
    from ansible.module_utils.facts.virtual.vbox import VirtualBoxFact

# Generated at 2022-06-20 16:53:46.876970
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collectors
    import unittest
    from ansible.module_utils.facts import utils as module_utils

    class MockModule(object):
        def __init__(self):
            self.params = {
                'minimal_gather_subset': ['hardware'],
                'gather_subset': ['hardware', 'network']
            }

    class TestGetAnsibleCollector(unittest.TestCase):

        def setUp(self):
            self.mock_module = MockModule()

        @staticmethod
        def _get_gather_subset(subset):
            gather_subset = module_utils.normalize_subset(subset)
            return tuple((sub, name) for sub, name in gather_subset)


# Generated at 2022-06-20 16:53:55.144774
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.system.distribution import DistributionCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactNamespace

    all_collector_classes = get_collector_classes()
    collector_class = DistributionCollector
    collector_obj = collector_class(namespace=DistributionFactNamespace)

    collect_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset=all_collector_classes
    gather_subset=['all']


# Generated at 2022-06-20 16:54:26.915548
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    class FakeCollector(collector.BaseFactCollector):
        name = 'foo'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {self.name: {'bar': 'baz'}, 'foo': 'bar'}

    class FakeCollector2(collector.BaseFactCollector):
        name = 'monkey'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return {self.name: 'man', 'monkey': 'man'}

    class FakeCollector3(collector.BaseFactCollector):
        name = 'pants'

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}

# Generated at 2022-06-20 16:54:36.922085
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = [
        collector.SolarisFactCollector
    ]
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=minimal_gather_subset,
            gather_subset=gather_subset,
            gather_timeout=gather_timeout)

    collectors = []
    for collector_class in collector_classes:
        collectors.append(collector_class)


# Generated at 2022-06-20 16:54:43.763844
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    TEST_GATHER_SUBSET = '!all'
    TEST_METADATA_FACTS = {'gather_subset': TEST_GATHER_SUBSET, 'module_setup': True}
    metadata_collector = CollectorMetaDataCollector(gather_subset=TEST_GATHER_SUBSET, module_setup=True)
    metadata_facts = metadata_collector.collect()
    assert metadata_facts == TEST_METADATA_FACTS

# Generated at 2022-06-20 16:54:53.711362
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''
    Testing AnsibleFactCollector constructor using filter_spec=['*'] and filter_spec=['ansible_*']
    '''
    filter_spec = ['*']
    fact_collector = AnsibleFactCollector(filter_spec=filter_spec)
    fact_dict = fact_collector.collect()
    assert len(fact_dict) != 0  # should return all facts
    
    filter_spec = ['ansible_*']
    fact_collector = AnsibleFactCollector(filter_spec=filter_spec)
    fact_dict = fact_collector.collect()
    assert len(fact_dict) != 0  # should return all facts

# Generated at 2022-06-20 16:55:05.668906
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = [
        GatherSubset,
        AllSubset,
        NetworkSubset,
        HardwareSubset,
    ]
    c = get_ansible_collector(all_collector_classes)
    assert c.namespace is None
    assert isinstance(c.collectors, list)
    assert isinstance(c.filter_spec, list)
    assert c.filter_spec == []

    c = get_ansible_collector(all_collector_classes, namespace=list())
    assert c.namespace == []
    assert isinstance(c.collectors, list)
    assert isinstance(c.filter_spec, list)
    assert c.filter_spec == []

    c = get_ansible_collector(all_collector_classes, gather_subset='all')
   

# Generated at 2022-06-20 16:55:14.962302
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # test gather_subset and module_setup are in the fact
    assert CollectorMetaDataCollector(gather_subset=['all'], module_setup=True).collect() == {'gather_subset': ['all'], 'module_setup': True}
    # test gather_subset is in the fact
    assert CollectorMetaDataCollector(gather_subset=['all']).collect() == {'gather_subset': ['all']}
    # test module_setup is not in the fact
    assert CollectorMetaDataCollector(module_setup=False).collect() == {'gather_subset': [], 'module_setup': False}
    # test no collect_disable/collect_only/gather_timeout modifiers

# Generated at 2022-06-20 16:55:21.914799
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert get_ansible_collector(all_collector_classes=None,
                                 namespace=None,
                                 filter_spec=None,
                                 gather_subset=None,
                                 gather_timeout=None,
                                 minimal_gather_subset=None)



# Generated at 2022-06-20 16:55:24.560320
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='test_gather_subset')
    assert collector_meta_data_collector.gather_subset == 'test_gather_subset'
    assert collector_meta_data_collector.name == 'gather_subset'

# Generated at 2022-06-20 16:55:34.785177
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import default_collector_classes
    fact_collector = get_ansible_collector(all_collector_classes=default_collector_classes,
                                           gather_subset=['all'])
    facts = fact_collector.collect()
    assert 'ansible_architecture' in facts.keys()
    assert 'gather_subset' in facts.keys()

# Deprecated method name, kept to avoid breaking modules
ansible_fact_collector = get_ansible_collector

# Generated at 2022-06-20 16:55:40.144272
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fixture = collector.CollectorMetaDataCollector()
    result = fixture.collect()
    assert isinstance(result, dict)
    assert result.get('gather_subset') == '!all'
    assert result.get('module_setup', False) is True