

# Generated at 2022-06-20 16:46:28.948179
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collect_meta_data = CollectorMetaDataCollector(gather_subset=['all'],
                                                   module_setup=True)
    facts = collect_meta_data.collect(module=None,
                                      collected_facts=None)

    assert facts == {'gather_subset': ['all'], 'module_setup': True}


# Generated at 2022-06-20 16:46:35.911948
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = get_ansible_collector(all_collector_classes=[],
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=None,
                                           gather_timeout=None,
                                           minimal_gather_subset=None)

    fact_dict = fact_collector.collect()
    assert fact_dict == {'gather_subset': 'all', 'module_setup': True}, \
        "test_CollectorMetaDataCollector_collect. expected: {'gather_subset': 'all', 'module_setup': True}; " \
        "actual %s" % fact_dict

# Generated at 2022-06-20 16:46:46.414073
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # test gather_subset is set in collected facts
    fact_collector = CollectorMetaDataCollector(gather_subset=frozenset())
    collected_facts = fact_collector.collect()
    assert collected_facts == {'gather_subset': frozenset()}

    # test module_setup is set in collected facts
    fact_collector = CollectorMetaDataCollector(module_setup=True)
    collected_facts = fact_collector.collect()
    assert collected_facts == {'module_setup': True}

    # test gather_subset and module_setup are set in collected facts
    fact_collector = CollectorMetaDataCollector(gather_subset=frozenset(), module_setup=True)
    collected_facts = fact_collector.collect()

# Generated at 2022-06-20 16:46:55.838491
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import prefix_fact_ns

    import ansible.module_utils.facts.platform.linux

    # Gather all linux and all facts
    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.ALL_COLLECTOR_CLASSES,
                                           namespace='ansible_',
                                           gather_subset=['all', 'ansible'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset(['ansible_all']))

    # Make sure all facts are collected
    facts = fact_collector.collect()

# Generated at 2022-06-20 16:47:01.894243
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)

    assert collector_meta_data_collector.name == 'gather_subset'
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup

test_CollectorMetaDataCollector()

# Generated at 2022-06-20 16:47:06.506672
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    obj_collector = CollectorMetaDataCollector(gather_subset="all",
                                               module_setup=True)
    facts = obj_collector.collect()
    assert facts["gather_subset"] == ["all"]
    assert facts["module_setup"] == True

if __name__ == '__main__':
    test_CollectorMetaDataCollector_collect()

# Generated at 2022-06-20 16:47:09.590534
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['foo', 'bar'],
                                   module_setup = True)
    assert collector_meta_data_collector.collect() == {'gather_subset': ['foo', 'bar'], 'module_setup': True}

# Generated at 2022-06-20 16:47:12.458099
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    ans = collector_meta_data_collector.collect()
    assert ans['gather_subset'] == ['all']
    assert ans['module_setup'] == True


# Generated at 2022-06-20 16:47:18.953762
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.network.interfaces import InterfacesFactCollector
    from ansible.module_utils.facts.collector.network.default import DefaultFactCollector

    collector1 = InterfacesFactCollector(PrefixFactNamespace('ansible_'))
    collector2 = DefaultFactCollector(PrefixFactNamespace('ansible_'))

    collectors = [collector1, collector2, InterfacesFactCollector(PrefixFactNamespace('facter_'))]

    c = AnsibleFactCollector(collectors=collectors, namespace=PrefixFactNamespace('ansible_'))

# Generated at 2022-06-20 16:47:23.547545
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    a = AnsibleFactCollector()
    facts = {'bar': [{'baz': 'boo'}, {'baz': 'zoo'}]}
    results = a.collect(facts)
    assert results == a.collectors[0].collect(facts)
    print('test_AnsibleFactCollector_collect passed')


# Generated at 2022-06-20 16:47:34.333952
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(gather_subset='all')
    assert fact_collector.gather_subset == 'all'
    assert fact_collector.module_setup is None
    assert fact_collector.collect() == {'gather_subset': 'all'}

    fact_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert fact_collector.collect() == {'gather_subset': 'all', 'module_setup': True}

    fact_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=False)
    assert fact_collector.collect() == {'gather_subset': 'all', 'module_setup': False}



# Generated at 2022-06-20 16:47:36.761546
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    mock_collector = collector.BaseFactCollector()
    fact_collector = AnsibleFactCollector(collectors=[mock_collector],
                                          namespace='ansible')
    assert fact_collector.namespace == 'ansible'
    assert fact_collector.filter_spec is None
    assert len(fact_collector.collectors) == 1
    assert fact_collector.collectors[0] == mock_collector


# Generated at 2022-06-20 16:47:46.563035
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.namespace as an
    import ansible.module_utils.facts.network as anet
    import ansible.module_utils.facts.facts as af

    namespace = an.PrefixFactNamespace(prefix='ansible_')
    collectors = [
        anet.NetworkCollector(namespace=namespace),
        af.PlatformCollector(namespace=namespace),
        ]

    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          namespace=namespace)

    # Facts should be collected under the 'ansible_' namespace
    facts = fact_collector.collect()
    assert 'ansible_' in facts

    # Facts should be collected under the 'ansible_network_' namespace

# Generated at 2022-06-20 16:47:58.763206
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import sys

    class CollectorA(collector.BaseFactCollector):
        '''a test collector that returns a fact that was given to it'''

        name = 'A'
        _fact_ids = set([])

        def __init__(self, collectors=None, namespace=None, fact=None):
            super(CollectorA, self).__init__(collectors, namespace)
            self.fact = fact

        def collect(self, module=None, collected_facts=None):
            return self.fact or {}

    # Verify that nested namespaces are added
    class CollectorB(collector.BaseFactCollector):
        '''a test collector that returns a fact that was given to it'''

        name = 'B'
        _fact_ids = set([])


# Generated at 2022-06-20 16:48:06.306663
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollector(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    fact_collector = AnsibleFactCollector(collectors=[MockCollector()], namespace=None)
    assert fact_collector.collect() == {'foo': 'bar'}


# Generated at 2022-06-20 16:48:09.660134
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    data = CollectorMetaDataCollector()
    output = data.collect()
    assert 'gather_subset' in output

# Generated at 2022-06-20 16:48:21.211762
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.collectors
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.namespace

    # The collector Class for a specific platform fact
    my_collector_class = collector.BaseFactCollector

    # The namespace class to use on a specific platform fact
    my_namespace_class = ansible_collections.ansible.builtin.plugins.module_utils.facts.namespace.AnsiblePrefixFactNamespace

    # All Fact Collectors that can be used by the platform
    # (including those that may be available but not used)
    all_collector_classes = [my_collector_class]

    # The minimal set of Fact Collectors - those that must be used
    # when running with gather_subset

# Generated at 2022-06-20 16:48:31.593356
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils.facts.collector.system

    # test no gather_subset
    fact_collector = get_ansible_collector(all_collector_classes=[], gather_subset=None)
    facts = fact_collector.collect()
    assert facts['gather_subset'] == ['all']

    # test minimal_gather_subset specified
    fact_collector = get_ansible_collector(all_collector_classes=[], gather_subset=None, minimal_gather_subset='all')
    facts = fact_collector.collect()
    assert facts['gather_subset'] == ['all']

    # test FilterSpec

# Generated at 2022-06-20 16:48:37.307918
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(
                                   gather_subset='default',
                                   module_setup=True)
    assert isinstance(fact_collector, CollectorMetaDataCollector)
    assert fact_collector.gather_subset == 'default'
    assert fact_collector.module_setup == True

# Generated at 2022-06-20 16:48:42.184338
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # when
    obj = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)

    # then
    assert obj.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-20 16:48:58.735956
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test for method collect of class CollectorMetaDataCollector'''

    # pylint: disable=unused-argument
    class CollectorMetaDataCollectorTest(CollectorMetaDataCollector):
        '''class used for testing CollectorMetaDataCollector'''

        def __init__(self, collectors=None, namespace=None, gather_subset=None, module_setup=None):
            super(CollectorMetaDataCollectorTest, self).__init__(collectors,
                                                                 namespace,
                                                                 gather_subset,
                                                                 module_setup)

        def collect(self, module=None, collected_facts=None):
            '''collect method used for testing CollectorsMetaDataCollector'''

            return super(CollectorMetaDataCollectorTest, self).collect(module, collected_facts)

    #

# Generated at 2022-06-20 16:49:09.805799
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):

        def __init__(self, *args, **kwargs):
            self.name = 'test'
            self.facts = {}
            self.facts['test1'] = 'test1'
            self.facts['test2'] = 'test2'

        def collect(self, module=None, collected_facts=None):
            return self.facts

    class NamespaceTestCollector(collector.BaseFactCollector):

        def __init__(self, *args, **kwargs):
            self.name = 'test'
            self.facts = {}
            self.facts['test1'] = 'test1'
            self.facts['test2'] = 'test2'

# Generated at 2022-06-20 16:49:17.975137
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespaced_facts
    an_ns = namespaced_facts.PrefixFactNamespace(prefix='ansible_')
    fact_collector = \
        AnsibleFactCollector(namespace=an_ns,
                             filter_spec=['ansible_*', 'ohai_*', 'facter_*'])

    assert fact_collector.filter_spec == ['ansible_*', 'ohai_*', 'facter_*']
    assert fact_collector.namespace == an_ns

    fact_collector = \
        AnsibleFactCollector(namespace=an_ns)
    assert fact_collector.filter_spec == ['*']
    assert fact_collector.namespace == an_ns


# Generated at 2022-06-20 16:49:21.033550
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert isinstance(AnsibleFactCollector(), AnsibleFactCollector)

# Generated at 2022-06-20 16:49:32.360358
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import kernel
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import lsb
    from ansible.module_utils.facts import local
    from ansible.module_utils.facts import collector_cache
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts.collector import BaseFactCollector


# Generated at 2022-06-20 16:49:41.108295
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import mock
    klass = AnsibleFactCollector
    instance = klass()
    assert instance.collectors == []
    assert isinstance(instance.namespace, collector.NullFactNamespace)
    assert isinstance(instance.filter_spec, list) and instance.filter_spec == []

    instance = klass(collectors=[mock.Mock()])
    assert instance.collectors == [mock.Mock()]
    # filter_spec is not set
    assert isinstance(instance.filter_spec, list) and instance.filter_spec == []

    instance = klass(filter_spec='*')
    assert instance.collectors == []
    assert isinstance(instance.filter_spec, list) and instance.filter_spec == ['*']


# Generated at 2022-06-20 16:49:47.113198
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    namespace = None
    fact_collector = get_ansible_collector(None, namespace)

    assert fact_collector.collectors == [], "collectors is not empty"
    assert fact_collector.namespace is None, "namespace is not empty"

# Generated at 2022-06-20 16:49:54.548757
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.base
    import ansible.module_utils.facts.namespace

    all_collector_classes = set(vars(ansible.module_utils.facts.collector.base).values())
    #all_namespace_classes = set(vars(ansible.module_utils.facts.namespace).values())

    class NestedFactCollector(ansible.module_utils.facts.collector.base.BaseFactCollector):
        name = 'nested'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'a': 'b'}

    collector_classes = [NestedFactCollector, ]

    filter_spec = []
    gather_subset = ['nested', ]
    gather_

# Generated at 2022-06-20 16:49:58.527981
# Unit test for function get_ansible_collector

# Generated at 2022-06-20 16:50:05.805010
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(gather_subset=['facter', 'os'])

    assert c.gather_subset == ['facter', 'os'], \
        'Failed to set gather_subset'
    assert c.module_setup == None, \
        'Failed to set module_setup'

    c = CollectorMetaDataCollector(gather_subset=['facter', 'os'],
                                   module_setup=True)

    assert c.gather_subset == ['facter', 'os'], \
        'Failed to set gather_subset'
    assert c.module_setup == True, \
        'Failed to set module_setup'

# Generated at 2022-06-20 16:50:19.861185
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Example: Colect the 'facter' and 'virtual' collectors (which are not used in
    # real life, this is just a demo)

    class FacterCollector(collector.BaseFactCollector):
        name = 'facter'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'facter': 'my_facter_fact'}

    class VirtualCollector(collector.BaseFactCollector):
        name = 'virtual'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'virtual': 'my_virtual_fact'}

    all_collector_classes = [FacterCollector, VirtualCollector]

    # ---
    # case: no minimal gather subset,

# Generated at 2022-06-20 16:50:27.454737
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collect_test = CollectorMetaDataCollector(gather_subset=['network', 'virtual'],
                                              module_setup=True)
    meta_facts = collect_test.collect()
    assert meta_facts.get('gather_subset') == ['network', 'virtual']
    assert meta_facts.get('module_setup') is True



# Generated at 2022-06-20 16:50:35.539057
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import SimpleFactsNamespace

    namespace = PrefixFactNamespace(prefix='ansible_', namespace_class=SimpleFactsNamespace())
    fact_collector = AnsibleFactCollector(collectors=None, filter_spec=None, namespace=namespace)

    assert isinstance(fact_collector.namespace, BaseFactNamespace)
    assert isinstance(fact_collector.collectors, list)

# Generated at 2022-06-20 16:50:44.879290
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Test that get_ansible_collector returns an AnsibleFactCollector with the correct
    # Collectors in place.

    all_collector_classes = frozenset([collector.FacterCollector,
                                       collector.OhaiCollector,
                                       collector.PlatformCollector])
    namespace = collector.Namespace('')

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace,
                              gather_subset='all')

    collectors = fact_collector.collectors

    assert len(collectors) == 3
    assert collectors[0].__class__ == collector.FacterCollector
    assert collectors[1].__class__ == collector.OhaiCollector
    assert collectors[2].__class__ == collector.Platform

# Generated at 2022-06-20 16:50:48.384436
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    assert collector_meta_data_collector.collect() == { 'gather_subset': ['all'] }

# Generated at 2022-06-20 16:50:57.267567
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['all'], \
        'gather_subset should be `all`'
    assert collector_meta_data_collector.module_setup == True, \
        'module_setup should be `True`'


# Generated at 2022-06-20 16:51:00.084837
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    assert collector_meta_data_collector('test_all', ['test_namespace'], 'test_gather_subset', 'test_module_setup')


# Generated at 2022-06-20 16:51:11.801363
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.hardware as hardware
    import ansible.module_utils.facts.network as network
    import ansible.module_utils.facts.system as system

    all_collector_classes = \
        hardware.collector_classes + \
        network.collector_classes + \
        system.collector_classes

    fact_collector = get_ansible_collector(all_collector_classes,
                                           filter_spec=None,
                                           gather_subset=['hardware', 'network'],
                                           gather_timeout=0)

    facts = fact_collector.collect()

    assert 'ansible_all_ipv4_addresses' in facts
    assert 'ansible_all_ipv6_addresses' in facts

# Generated at 2022-06-20 16:51:18.646540
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fake_module = lambda: None
    fake_module.ansible_version = lambda: None
    fake_module.ansible_facts = {}
    meta_data = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    meta_data.collect(fake_module)
    assert fake_module.ansible_facts == {"gather_subset": ['all'], "module_setup": True}

# Generated at 2022-06-20 16:51:27.705820
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.service
    import ansible.module_utils.facts.collector.platform

    all_collector_classes = \
        collector.get_all_collector_classes(directories=[ansible.module_utils.facts.collector.network.__path__[0],
                                                         ansible.module_utils.facts.collector.service.__path__[0],
                                                         ansible.module_utils.facts.collector.platform.__path__[0]])

    # Note that this is not a realistic gather_subset but is this is a unit test, so keeping
    # it simple for clarity.

# Generated at 2022-06-20 16:51:45.888053
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    assert CollectorMetaDataCollector(gather_subset=['all']).collect(collected_facts={}) == {'gather_subset': ['all']}
    assert CollectorMetaDataCollector(gather_subset=['all'],
                                      module_setup=True).collect(collected_facts={}) == {
                                          'gather_subset': ['all'],
                                          'module_setup': True}
    assert CollectorMetaDataCollector(gather_subset=['all'],
                                      module_setup=False).collect(collected_facts={}) == {
                                          'gather_subset': ['all'],
                                          'module_setup': False}

# Generated at 2022-06-20 16:51:56.435623
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # arrange
    collectors = None
    namespace = None
    gather_subset = None
    module_setup = None

    # act
    collector_meta_data_collector = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)
    facts_meta_data = collector_meta_data_collector.collect()

    # assert
    assert facts_meta_data == {
        'gather_subset': frozenset([]),
        'module_setup': True}

    # arrange
    collectors = None
    namespace = None
    gather_subset = frozenset(['all'])
    module_setup = None

    # act
    collector_meta_data_collector = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)

# Generated at 2022-06-20 16:52:05.926682
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for method collect of class AnsibleFactCollector'''

    # Mock up some collector objects
    class MockCollector1(collector.BaseFactCollector):
        name = 'mockcollector1'
        def collect(self, module=None, collected_facts=None):
            return {self.name: {} }

    class MockCollector2(collector.BaseFactCollector):
        name = 'mockcollector2'
        def collect(self, module=None, collected_facts=None):
            # should be excluded
            return {self.name: {'exclude': {'data1', 'data2'}} }

    class MockCollector3(collector.BaseFactCollector):
        name = 'mockcollector3'

# Generated at 2022-06-20 16:52:15.144768
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.collectors.network as network

    # Make sure that the constructor of CollectorMetaDataCollector works even if
    # the module_setup parameter is not provided.
    CollectorMetaDataCollector(collectors=None, namespace=namespace.FactNamespace(), gather_subset=None)

    try:
        CollectorMetaDataCollector(collectors=[network.NetworkCollector()],
                                   namespace=namespace.FactNamespace(),
                                   gather_subset=None,
                                   module_setup=None)
        assert False
    except:
        assert True

# Generated at 2022-06-20 16:52:24.994994
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # No collectors
    fact_collector = AnsibleFactCollector(collectors=None,
                                          namespace=None)
    facts = fact_collector.collect()
    assert facts == {}

    # No facts collected
    fact_collector = AnsibleFactCollector(collectors=[],
                                          namespace=None)
    facts = fact_collector.collect()
    assert facts == {}

    # One fact collected
    fact_collector = AnsibleFactCollector(collectors=[collector.BaseFactCollector()],
                                          namespace=None)
    facts = fact_collector.collect()
    assert facts == {'facter': {}}

    # Add namespace to one fact

# Generated at 2022-06-20 16:52:37.659678
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # import this in the function so test_ansible_collector can be run without collecting
    # all the facts
    from ansible.module_utils.facts import fact_collector
    all_collector_classes = fact_collector.all_collectors()
    ansible_collector = get_ansible_collector(all_collector_classes,
                                              filter_spec=['all', 'logging*'],
                                              gather_subset=['all'],
                                              gather_timeout=10,
                                              minimal_gather_subset=frozenset(['network']))
    assert isinstance(ansible_collector, collector.BaseFactCollector)
    assert isinstance(ansible_collector, AnsibleFactCollector)

# Generated at 2022-06-20 16:52:45.386233
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    module = None
    collected_facts = {'ansible_eth0': {'macaddress': '00:00:00:00:00:00'}}
    object_to_test = CollectorMetaDataCollector(['all'], None)
    assert object_to_test.collect(module, collected_facts) == {'gather_subset': ['all']}
    assert object_to_test.collect(module, collected_facts) == {'gather_subset': ['all']}


# Generated at 2022-06-20 16:52:56.997557
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # Arrange
    module = None
    collected_facts = None
    gather_subset = ['all']
    module_setup = True
    meta_data_collector = CollectorMetaDataCollector(collectors=None,
                                                     namespace=None,
                                                     gather_subset=gather_subset,
                                                     module_setup=module_setup)
    expected_facts = {'gather_subset': gather_subset,
                      'module_setup': module_setup}

    # Act
    actual_facts = meta_data_collector.collect(module=module, collected_facts=collected_facts)

    # Assert
    assert actual_facts == expected_facts


# Generated at 2022-06-20 16:53:05.377344
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_obj = CollectorMetaDataCollector(gather_subset='all', module_setup=False)
    fact_collector = \
        AnsibleFactCollector(collectors=[collector_obj],
                             filter_spec='*')
    assert fact_collector.collect() == {'gather_subset': 'all'}


# Unit test fot method _filter of class AnsibleFactCollector

# Generated at 2022-06-20 16:53:16.313758
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.machine

    collector_class_list = [ansible.module_utils.facts.system.distribution.DistributionFactCollector,
                            ansible.module_utils.facts.system.platform.PlatformFactCollector,
                            ansible.module_utils.facts.system.machine.MachineFactCollector]
    fact_collector = get_ansible_collector(all_collector_classes=collector_class_list,
                                           gather_subset='all',
                                           filter_spec='*')
    assert fact_collector is not None

# Generated at 2022-06-20 16:53:38.522010
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # This function is more tested as part of unit tests for facts.
    pass

# Generated at 2022-06-20 16:53:43.420535
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['all']
    assert collector_meta_data_collector.module_setup == True

if __name__ == '__main__':
    test_CollectorMetaDataCollector()

# Generated at 2022-06-20 16:53:52.804704
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Note: filter_spec doesn't do anything in 2.x, can't test it
    fact_collector = get_ansible_collector(all_collector_classes=['anything'],
                                           namespace='whatever',
                                           gather_subset=[],
                                           gather_timeout=10,
                                           minimal_gather_subset=['minimal'])
    if fact_collector is None:
        raise AssertionError("get_ansible_collector() returned None")

# Generated at 2022-06-20 16:54:02.237084
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import array_of_collector_classes
    from ansible.module_utils.facts import default_collectors

    collection_obj = CollectorMetaDataCollector(collectors=default_collectors, gather_subset=['all'])
    ansible_facts = collection_obj.collect()
    assert ansible_facts['gather_subset'] == ['all']



# Generated at 2022-06-20 16:54:05.738852
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    test_collector = AnsibleFactCollector(collectors=None, namespace=None)
    test_collector_collect = test_collector.collect(module=None, collected_facts=None)
    assert isinstance(test_collector_collect, dict)
    assert isinstance(test_collector.filter_spec, list)

# Generated at 2022-06-20 16:54:09.062007
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    fact_collector = AnsibleFactCollector()

    assert None is fact_collector.namespace
    assert [] == fact_collector.filter_spec

# Generated at 2022-06-20 16:54:12.584778
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    fact_collector = \
        AnsibleFactCollector(collectors=[collector.FacterFactCollector()])

    assert fact_collector



# Generated at 2022-06-20 16:54:22.808942
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.osx
    import ansible.module_utils.facts.system.distribution.freebsd
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr

    all_collectors = ansible.module_utils.facts.system.distribution.collectors
    all_collectors += ansible.module_utils.facts.system.distribution.osx.collectors
    all_collectors += ansible.module_utils.facts.system.distribution.freebsd.collectors
    all_collectors += ansible.module_utils.facts.network.ip

# Generated at 2022-06-20 16:54:33.013645
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    namespace = 'test'
    gather_subset = ['all']
    module_setup = True

    collector_meta_data_collector = \
        CollectorMetaDataCollector(None,
                                   namespace,
                                   gather_subset,
                                   module_setup)

    assert(collector_meta_data_collector.namespace == namespace)
    assert(collector_meta_data_collector.gather_subset == gather_subset)
    assert(collector_meta_data_collector.module_setup == module_setup)
    assert(collector_meta_data_collector.name == 'gather_subset')

# Generated at 2022-06-20 16:54:36.727701
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector(collectors=None,
                                          namespace=None)
    assert(isinstance(fact_collector, AnsibleFactCollector))

# Generated at 2022-06-20 16:55:12.919838
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # empty constructor
    a = AnsibleFactCollector()

    # test from_gather_subset()
    from ansible.module_utils.facts.platform.base import BaseFactCollector
    all_collector_classes = [BaseFactCollector]  # used just to make call to from_gather_subset()
    b = AnsibleFactCollector.from_gather_subset(all_collector_classes, gather_subset=['all', 'foo'])
    assert set([type(x) for x in b.collectors]) == set([BaseFactCollector])



# Generated at 2022-06-20 16:55:25.629628
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.collector.disk as disk
    import ansible.module_utils.facts.collector.file_system as file_system
    import ansible.module_utils.facts.collector.platform as platform

    disk_collector = disk.DiskCollector(namespace=PrefixFactNamespace(prefix='disk_'))
    platform_collector = platform.PlatformCollector(namespace=PrefixFactNamespace(prefix='platform_'))
    file_system_collector = file_system.FileSystemCollector(namespace=PrefixFactNamespace(prefix='file_system_'))


# Generated at 2022-06-20 16:55:37.883472
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.network.base import BaseNetworkCollector

    class DummyCollector(BaseNetworkCollector):
        name = 'dummy'

        def collect(self, module=None, collected_facts=None):
            return {'ansible_dummy_fact': 'dummy'}

    # create a dummy collector with no namespace and a namespace
    dummy_collector_no_namespace = DummyCollector()
    dummy_collector_with_namespace = DummyCollector(namespace=collector.FactNamespace('ansible'))

    # create an AnsibleFactCollector with no filter and a filter
    ansible_fact_collector_no_filter = AnsibleFactCollector(collectors=[dummy_collector_no_namespace])
    ansible_fact_collector_with_filter

# Generated at 2022-06-20 16:55:45.104056
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # test normal case
    subset = ['all']
    module_setup = True
    fact_collector = collector.CollectorMetaDataCollector(gather_subset=subset, module_setup=module_setup)
    expected_facts = {'gather_subset': subset, 'module_setup': module_setup}
    facts = fact_collector.collect()
    assert facts == expected_facts

    # test with None for module_setup
    module_setup = None
    fact_collector = collector.CollectorMetaDataCollector(gather_subset=subset, module_setup=module_setup)
    expected_facts = {'gather_subset': subset}
    facts = fact_collector.collect()
    assert facts == expected_facts

    # test with no arguments
    fact_collector = collector.Collector

# Generated at 2022-06-20 16:55:47.730636
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(collectors=[],
                                                               namespace=None,
                                                               gather_subset=['network'],
                                                               module_setup=True)
    facts = collector_meta_data_collector.collect()
    assert facts['gather_subset'] == ['network']
    assert facts['module_setup'] is True

# Generated at 2022-06-20 16:55:57.660129
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    test_collector_classes = []
    test_namespace = None
    test_gather_subset = ['all']
    test_module_setup = True
    result = CollectorMetaDataCollector(test_collector_classes, test_namespace, test_gather_subset, test_module_setup)
    assert result is not None, "Unable to create a CollectorMetaDataCollector"
    assert result.gather_subset is not None, "gather_subset is None"
    assert result.collectors == test_collector_classes, "collectors has a value other than the passed in value"
    assert result.namespace == test_namespace, "namespace has a value other than the passed in value"

# Generated at 2022-06-20 16:56:09.183392
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Collect all facts
    ansible_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes())
    assert ansible_collector is not None
    assert ansible_collector.collectors is not None
    assert len(ansible_collector.collectors) > 0

    # Collect all facts
    ansible_collector = get_ansible_collector(all_collector_classes=collector.all_collector_classes())
    assert ansible_collector is not None
    assert ansible_collector.collectors is not None
    assert len(ansible_collector.collectors) > 0

    # Collect all facts, with fact filtering
    fact_filter = 'ansible_machines'

# Generated at 2022-06-20 16:56:13.641450
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    cc = CollectorMetaDataCollector(gather_subset=['this', 'that'], module_setup='yes')
    assert (cc.gather_subset == ['this', 'that'])
    assert (cc.module_setup == 'yes')

# Generated at 2022-06-20 16:56:18.131341
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    gather_subset = ['hardware', 'network']
    module_setup = True
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=gather_subset,
                                                               module_setup=module_setup)
    assert gather_subset == collector_meta_data_collector.gather_subset
    assert module_setup == collector_meta_data_collector.module_setup