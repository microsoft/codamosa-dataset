

# Generated at 2022-06-20 16:46:38.110360
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    namespace = collector.PrefixFactNamespace(prefix='ansible_')
    collector = AnsibleFactCollector(name='test_collector',
                                     namespace=namespace,
                                     filter_spec='foo*')
    assert collector.name == 'test_collector'
    assert repr(collector.namespace) == '"ansible_"'
    assert collector.filter_spec == 'foo*'


# Generated at 2022-06-20 16:46:42.524743
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = \
        AnsibleFactCollector(collectors=[], filter_spec='all')
    assert (isinstance(fact_collector, AnsibleFactCollector))
    assert (fact_collector.filter_spec == 'all')
    fact_collector = \
        AnsibleFactCollector(collectors=[])
    assert (isinstance(fact_collector, AnsibleFactCollector))
    assert (fact_collector.filter_spec == '*')

# Generated at 2022-06-20 16:46:53.392997
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector('all', 'namespace')

    info_dict = collector_meta_data_collector.collect(module=None, collected_facts=None)
    assert info_dict == {'gather_subset': 'all'}

    collector_meta_data_collector.module_setup = False
    info_dict = collector_meta_data_collector.collect(module=None, collected_facts=None)
    assert info_dict == {'gather_subset': 'all', 'module_setup': False}


# Generated at 2022-06-20 16:46:58.979775
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert collector_meta_data_collector.collect() == {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-20 16:47:08.701300
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class C1(collector.BaseFactCollector):
        name = 'c1'
    class C2(collector.BaseFactCollector):
        name = 'c2'
    class C3(collector.BaseFactCollector):
        name = 'c3'

    all_collector_classes = [C1, C2, C3]
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    collector_classes = collector.collector_classes_from_gather_subset(all_collector_classes, minimal_gather_subset, gather_subset, gather_timeout)

# Generated at 2022-06-20 16:47:19.111562
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # mock namespaces
    class mock_namespace(object):
        def apply(self, facts_dict):
            return facts_dict

    mock_collectors = []

    # test first when collectors is not empty
    fact_collector_when_collectors_is_not_empty = AnsibleFactCollector(collectors=mock_collectors,
                                                                       namespace=mock_namespace())
    assert fact_collector_when_collectors_is_not_empty.collectors == mock_collectors
    assert fact_collector_when_collectors_is_not_empty.namespace == mock_namespace()

    # test when collectors is empty
    fact_collector_when_collectors_is_empty = AnsibleFactCollector(namespace=mock_namespace())
    assert fact_collector_when_collect

# Generated at 2022-06-20 16:47:22.879128
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=[],
                                                               module_setup=False)
    assert collector_meta_data_collector.gather_subset == []
    assert collector_meta_data_collector.module_setup == False



# Generated at 2022-06-20 16:47:25.943082
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_collector = CollectorMetaDataCollector(gather_subset=['all'])
    meta_data = meta_collector.collect(collected_facts={})
    assert meta_data == {'gather_subset': ['all']}


# Generated at 2022-06-20 16:47:34.249283
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    subset = ['subset1', 'subset2']
    collector_meta_data_collector = CollectorMetaDataCollector(subset, module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    assert subset == meta_facts['gather_subset']
    assert True == meta_facts['module_setup']


# Generated at 2022-06-20 16:47:42.008719
# Unit test for function get_ansible_collector
def test_get_ansible_collector():  # pylint: disable=unused-variable,unused-argument
    from ansible.module_utils.facts import test_collector as test_collector_module
    all_collector_classes = test_collector_module.TestCollector.collector_classes()

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=['!all', 'min'],
                                           filter_spec=['*'])
    collected_facts = fact_collector.collect()


# Generated at 2022-06-20 16:47:58.459279
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    class collector_meta_data_collector(collector.BaseFactCollector):

        name = 'gather_subset'
        _fact_ids = set([])

        def __init__(self, collectors=None, namespace=None, gather_subset=None):
            super(CollectorMetaDataCollector, self).__init__(collectors, namespace)
            self.gather_subset = gather_subset

        def collect(self, module=None, collected_facts=None):
            meta_facts = {'gather_subset': self.gather_subset}
            return meta_facts

    # 1. check the result of get_ansible_collector function with a 'all' gather_subset
    # on all_collector_classes and without namespace.

# Generated at 2022-06-20 16:48:07.409003
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test collect method with a namespace and a filter.
    # A fact matching the filter should be retuned under the namespace
    # while the other facts will be returned under the default 'ansible_' namespace.
    # For ex:
    # {'ansible_os_family': 'RedHat', 'ansible_architecture': 'x86_64', 'myfact': 'myvalue'}
    # with namespace='my' and filter_spec='*'
    # will be returned as
    # {'ansible_os_family': 'RedHat', 'ansible_architecture': 'x86_64', 'my': {'fact': 'myvalue'}}

    namespace = 'my'

# Generated at 2022-06-20 16:48:20.443801
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_classes = [
        collector.FacterCollector,
        collector.OhaiCollector,
        collector.NetworkCollector,
        collector.PkgMgrCollector,
        collector.VirtualCollector,
        collector.HardwareCollector,
        collector.DMIHardwareCollector,
        collector.FileglobCollector,
        collector.DefaultCollector,
        collector.PlatformCollector,
        collector.ProcessorCollector]
    namespace = collector.namespace.PrefixFactNamespace(prefix='ansible_')
    filter_spec = '*'

    fact_collector = \
        AnsibleFactCollector(collectors=collector_classes,
                             namespace=namespace,
                             filter_spec=filter_spec)

    assert fact_collector.namespace.prefix == 'ansible_'
    assert fact

# Generated at 2022-06-20 16:48:26.990848
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['min'],
                                                module_setup=False)
    all_facts = fact_collector.collect(None, None)
    assert all_facts['gather_subset'] == ['min']
    assert 'module_setup' not in all_facts

# Generated at 2022-06-20 16:48:39.688846
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    all_collector_classes = ansible.module_utils.facts.collector.all_collector_classes(module=None)
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes)
    collected_facts = None
    module = None
    ansible_facts = fact_collector.collect(module=module, collected_facts=collected_facts)
    # assert we have ansible_facts and the gather_subet fact
    assert type(ansible_facts) is dict
    assert 'gather_subset' in ansible_facts
    assert 'module_setup' in ansible_facts
    assert 'ansible_facts' in ansible_facts

# Generated at 2022-06-20 16:48:50.777600
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.system.distribution

    class MockupSystemDistribution(ansible.module_utils.facts.system.distribution.DistributionFactCollector):
        name = 'system/distribution'
        _fact_ids = set(['distribution', 'distribution_version', 'distribution_major_version'])

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            ansible_facts = {}
            ansible_facts['ansible_distribution_version'] = '1.0'
            ansible_facts['ansible_distribution_major_version'] = '1'

# Generated at 2022-06-20 16:49:00.349025
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.system.distribution as DistributionFactCollector
    import ansible.module_utils.facts.system.dns as DnsFactCollector
    import ansible.module_utils.facts.system.fips as FipsFactCollector
    import ansible.module_utils.facts.system.pkg_mgr as PkgMgrFactCollector

    known_collectors = [DistributionFactCollector,
                        DnsFactCollector,
                        FipsFactCollector,
                        PkgMgrFactCollector]


# Generated at 2022-06-20 16:49:10.075547
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """Test the collect method of class CollectorMetaDataCollector"""
    # Setup
    all_collector_classes = {'aix': 'aix', 'darwin': 'darwin', 'default': 'default',
                             'debian': 'debian', 'freebsd': 'freebsd', 'hpux': 'hpux',
                             'linux': 'linux', 'openbsd': 'openbsd', 'osx': 'darwin',
                             'python': 'python', 'sunos': 'sunos', 'windows': 'windows'}
    namespace = collector.PrefixFactNamespace(prefix='ansible_')
    gather_subset = ['all']
    gather_timeout = 10
    minimal_gather_subset = ['all']
    # Exercise

# Generated at 2022-06-20 16:49:21.189729
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'])
    assert meta_data_collector.gather_subset == ['all']
    assert meta_data_collector.module_setup is None

    # Test module_setup option
    meta_data_collector = CollectorMetaDataCollector(module_setup=True)
    assert meta_data_collector.module_setup == True
    assert meta_data_collector.gather_subset is None

    # Test both gather_subset and module_setup
    meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert meta_data_collector.gather_subset == ['all']
    assert meta_data_collector.module_setup == True

# Generated at 2022-06-20 16:49:32.422225
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """ Methods that only use the collector under test and its dependencies,
        without touching any real hardware. Should only need to mock the
        modules that are imported. """

    # create mock modules imported by class under test
    mock_module = MagicMock()
    mock_modules = {'ansible.module_utils.facts.collector': collector}

    # construct class under test using mocked dependencies
    test_subset = ['min', '!nominal']
    test_module_setup = False
    test_collector = CollectorMetaDataCollector(namespace=None,
                                                gather_subset=test_subset,
                                                module_setup=test_module_setup)

    # execute code to be tested
    test_results = test_collector.collect(module=mock_module)

    # assert / verify expectations
    assert test_

# Generated at 2022-06-20 16:49:47.093774
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=None,
            minimal_gather_subset=None,
            gather_subset=None,
            gather_timeout=None)

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=None,
                              filter_spec=None)

    collected_facts = fact_collector.collect()

    assert 'gather_subset' in collected_facts
    assert 'module_setup' in collected_facts

# Generated at 2022-06-20 16:49:54.419404
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = ['collector_1', 'collector_2']
    namespace = 'ansible'
    gather_subset = ['min', '!hardware', 'network']
    module_setup = False

    cmDC1 = CollectorMetaDataCollector(collectors=collectors,
                                       namespace=namespace,
                                       gather_subset=gather_subset,
                                       module_setup=module_setup)
    meta_facts = cmDC1.collect()
    assert meta_facts['gather_subset'] == gather_subset
    assert meta_facts['module_setup'] == module_setup

    # When module_setup is None it should not be included in meta_facts.

# Generated at 2022-06-20 16:50:03.265088
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    collector_class = collector.BaseFactCollector
    collectors = [
        collector_class(namespace=collector.FacterFactNamespace()),
        collector_class(namespace=collector.OhaiFactNamespace()),
    ]

    # namespace=None
    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec=None,
                             namespace=None)

    assert fact_collector.collectors == collectors
    assert fact_collector.filter_spec is None
    assert fact_collector.namespace is None

    # namespace=collector.FacterFactNamespace()
    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec=None,
                             namespace=collector.FacterFactNamespace())

   

# Generated at 2022-06-20 16:50:10.124080
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # function should return a FactCollector object
    assert isinstance(get_ansible_collector(all_collector_classes=None,
                                            namespace=None,
                                            filter_spec=None,
                                            gather_subset=None,
                                            gather_timeout=None,
                                            minimal_gather_subset=None), collector.BaseFactCollector)

# Generated at 2022-06-20 16:50:20.175131
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import json

    import pytest
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.timeout import TimedCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'foo'}

        def __init__(self, namespace=None):
            super(TestCollector, self).__init__(namespace)

    collector_classes = get_collector_classes()
    collector_

# Generated at 2022-06-20 16:50:30.516832
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=True,
                                   module_setup=True)
    assert collector_meta_data_collector.collect() == \
        {'gather_subset': True, 'module_setup': True}
    assert collector_meta_data_collector.collectors == []
    assert collector_meta_data_collector.name == 'gather_subset'
    assert collector_meta_data_collector.gather_subset is True
    assert collector_meta_data_collector.module_setup is True
    assert collector_meta_data_collector.namespace is None

# Generated at 2022-06-20 16:50:37.596488
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    assert CollectorMetaDataCollector(gather_subset=['all'],
                                      module_setup=True).collect() == {
                                          'gather_subset': ['all'],
                                          'module_setup': True}
    assert CollectorMetaDataCollector(gather_subset=None,
                                      module_setup=False).collect() == {
                                          'module_setup': False}



# Generated at 2022-06-20 16:50:45.831183
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.redhat

    collectors = [ansible.module_utils.facts.system.distribution.DistributionFactCollector(),
                  ansible.module_utils.facts.system.distribution.debian.DebianFactCollector(),
                  ansible.module_utils.facts.system.distribution.redhat.RedHatFactCollector()]

    collector = AnsibleFactCollector(collectors=collectors,
                                     filter_spec=['*'], # ansible_distribution
                                     namespace=None)

    result = collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-20 16:50:57.852175
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # 1st Test case: gather_subset=None, module_setup=None
    meta_facts = CollectorMetaDataCollector().collect()
    assert meta_facts == {
        'gather_subset': None,
        'module_setup': None,
    }

    # 2nd Test case: gather_subset='all', module_setup=True
    meta_facts = CollectorMetaDataCollector(gather_subset='all', module_setup=True).collect()
    assert meta_facts == {
        'gather_subset': 'all',
        'module_setup': True,
    }

    return True


# Generated at 2022-06-20 16:51:11.260894
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.hardware.cpu import HardwareCPUFactCollector
    from ansible.module_utils.facts.system.sysctl import SysctlFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.namespace.PrefixFactNamespace import PrefixFactNamespace

    namespace = PrefixFactNamespace(prefix='ansible_')
    collectors = [HardwareCPUFactCollector(namespace=namespace),
                  SysctlFactCollector(namespace=namespace),
                  DistributionFactCollector(namespace=namespace)]


# Generated at 2022-06-20 16:51:15.502543
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    fact_collector = AnsibleFactCollector()
    assert isinstance(fact_collector, collector.BaseFactCollector)

# Generated at 2022-06-20 16:51:20.822495
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    class FakeCollector(collector.BaseFactCollector):
        pass

    fact_collector = AnsibleFactCollector(collectors=[FakeCollector()])

    assert(len(fact_collector.collectors) == 1)
    assert(isinstance(fact_collector.collectors[0], FakeCollector))



# Generated at 2022-06-20 16:51:29.666791
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector = CollectorMetaDataCollector(collectors=None, namespace=None, gather_subset=['hardware'], module_setup=True)
    facts_dict = collector.collect(collected_facts=None, module=None)
    assert isinstance(facts_dict, dict)
    assert facts_dict['gather_subset'] == ['hardware']
    assert facts_dict['module_setup'] is True



# Generated at 2022-06-20 16:51:33.805109
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_collector = CollectorMetaDataCollector(namespace=None,
                                                gather_subset=['network'],
                                                module_setup=True)

    # we don't need any 'module' or 'collected_facts' input to collect_with_namespace()
    facts = fact_collector.collect_with_namespace(module=None, collected_facts=None)

    assert facts == {'module_setup': True, 'gather_subset': ['network']}

# Generated at 2022-06-20 16:51:45.519260
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class Collector1(collector.BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['a1', 'a2', 'a3'])
        def collect(self, module=None, collected_facts=None):
            return {'a1': 'A1', 'a2': 'A2', 'a3': 'A3', 'a4': 'A4'}

    class Collector2(collector.BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['b1', 'b2'])
        def collect(self, module=None, collected_facts=None):
            return {'b1': 'B1', 'b2': 'B2', 'b3': 'B3', 'b4': 'B4'}


# Generated at 2022-06-20 16:51:53.065665
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts as facts
    fact_collector = get_ansible_collector(
        all_collector_classes=facts.FACT_SUBSETS,
        gather_subset=['all'],
        gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
        minimal_gather_subset=timeout.MINIMAL_GATHER_SUBSET,
        namespace=None)

    assert(isinstance(fact_collector, AnsibleFactCollector))



# Generated at 2022-06-20 16:52:05.065636
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    import json
    import tempfile

    from ansible.module_utils.facts.namespace import NamespaceCollector

    class FakeCollector1(collector.BaseFactCollector):
        name = "name1"

        def collect(self, module=None, collected_facts=None):
            if collected_facts is None:
                collected_facts = {}
            collected_facts["c1fake1"] = "c1fake1"
            return collected_facts

    class FakeCollector2(collector.BaseFactCollector):
        name = "name2"

        def collect(self, module=None, collected_facts=None):
            if collected_facts is None:
                collected_facts = {}
            collected_facts["c2fake1"] = "c2fake1"
            return collected_facts

    _fd, tmp_path = temp

# Generated at 2022-06-20 16:52:12.249939
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''Tests constructor. An empty constructor should return
    an instance of AnsibleFactCollector with default values.'''

    # Default constructor
    obj = AnsibleFactCollector()

    assert obj.collectors == []
    assert obj.namespace is None
    assert obj.filter_spec == []

# An AnsibleFactCollector with a namespace

# Generated at 2022-06-20 16:52:19.642185
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Make a fake ansible_facts_collector and fake collectors
    class AnsibleFactsCollector(object):
        def __init__(self, collectors, filter_spec):
            self.collectors = collectors
            self.filter_spec = filter_spec

    class FakeCollector(object):
        def __init__(self, collected_facts):
            self.collected_facts = collected_facts

        def collect(self):
            return self.collected_facts

    facts = {'fact1': 'value1',
             'fact2': 'value2',
             'ansible_fact2': 'value2',
             'fact3': 'value3'}

    fake_collector = FakeCollector(facts)

# Generated at 2022-06-20 16:52:29.574108
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Collect all facts
    ansible_collector = \
        get_ansible_collector(all_collector_classes=collector.ALL_COLLECTOR_CLASSES,
                              gather_subset=['all'])

    facts = ansible_collector.collect()

    for fact_name in facts['ansible_facts']:
        assert is_string(facts['ansible_facts'][fact_name])

    assert 'gather_subset' in facts['ansible_facts']['gather_subset']

    # Collect fact 'ansible_all_ipv4_addresses'

# Generated at 2022-06-20 16:52:47.039159
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # mock all_collector_classes
    all_collector_classes = [
        'ansible.module_utils.facts.collector.NetworkCollector',
        'ansible.module_utils.facts.collector.DistributionCollector',
    ]
    # mock namespace
    namespace = 'ansible_'
    # mock filter_spec
    filter_spec = None
    # mock gather_subset
    gather_subset = ['all']
    # mock gather_timeout
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    # mock minimal_gather_subset
    minimal_gather_subset = frozenset()
    # And call

# Generated at 2022-06-20 16:52:53.816114
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.collector_classes()
    module_setup = ansible.module_utils.facts.module_setup
    facts_dict = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=None,
                              filter_spec=None,
                              gather_subset=['all'],
                              gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                              minimal_gather_subset=module_setup.MINIMAL_GATHER_SUBSET).\
        collect(module=module_setup)
    return facts_dict

# Generated at 2022-06-20 16:53:02.325772
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    # use same collector classes as in ansible.module_utils.facts.__main__
    all_collector_classes = [
        collector.NetworkInterfacesCollector,
        collector.DefaultNetworkCollector,
        collector.HardwareCollector,
        collector.VirtualCollector,
        collector.FacterCollector,
        collector.OhaiCollector,
        collector.AnsibleCollector,
        collector.PlatformCollector
    ]

    # ask for only ansible facts and default network facts
    gather_subset = ['!all', '!min', 'ansible', 'default']
    # create a fact collector with all relevant Collector classes
    # since AnsibleFactCollector is forwarding the namespace to the collector objects,
    # the namespace doesn't have to be set at the AnsibleFactCollector level
    fact_collector = get_ansible_

# Generated at 2022-06-20 16:53:11.081776
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class DummyCollector():
        def collect(self, module=None, collected_facts=None):
            return -2

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'ansible_facts': self.collect(module=module, collected_facts=collected_facts)}

    def test_filter(facts_dict, filter_spec):
        return facts_dict

    fact_collector = AnsibleFactCollector(collectors=[DummyCollector()], filter_spec=[])

    # test with empty filterspec
    assert fact_collector.collect(collected_facts={}) == {'ansible_facts': -2}

    # test with non empty filterspec
    fact_collector = AnsibleFactCollector(collectors=[DummyCollector()], filter_spec=[])

   

# Generated at 2022-06-20 16:53:14.380920
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    expect = {'gather_subset': 'subset1'}
    actual = CollectorMetaDataCollector(gather_subset='subset1').collect()
    assert expect == actual

# Generated at 2022-06-20 16:53:16.706709
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    CollectorMetaDataCollector(['all_collectors'], namespace='namespace', gather_subset=['all'])

# Generated at 2022-06-20 16:53:26.551500
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='!all')
    data = collector_meta_data_collector.collect()
    assert data['gather_subset'] == '!all'
    assert 'module_setup' not in data

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='!all', module_setup=True)
    data = collector_meta_data_collector.collect()
    assert data['gather_subset'] == '!all'
    assert data['module_setup'] is True

    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='!all', module_setup=False)
    data = collector_meta_data_collector.collect()
    assert data['gather_subset']

# Generated at 2022-06-20 16:53:30.821053
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    fact_collector = \
        AnsibleFactCollector(collectors=[])

    assert isinstance(fact_collector, AnsibleFactCollector) is True


# Generated at 2022-06-20 16:53:36.556582
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert(isinstance(collector_meta_data_collector.collect(), dict))
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all'], 'module_setup': True}

# Test for function get_ansible_collector

# Generated at 2022-06-20 16:53:38.590006
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    assert AnsibleFactCollector(collectors=[collector.FacterCollector(), collector.OhaiCollector()])

# Generated at 2022-06-20 16:53:49.595332
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_metadata_collector = CollectorMetaDataCollector(
        gather_subset='all'
    )

    facts = collector_metadata_collector.collect()

    assert facts == {'gather_subset': 'all'}


# Generated at 2022-06-20 16:53:56.931509
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils.facts.collectors.all
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import RawFactNamespace

    collector_name_1 = 'gather_subset'
    collector_name_2 = 'facter'
    fact_name_1 = 'gather_subset'
    fact_name_2 = 'os'
    fact_name_3 = 'architecture'

    collect_subset = ['all']
    minimal_subset = ['gather_subset']
    gather_timeout = 2
    filter_spec = ['*']

    all_collector_classes = \
        ansible.module_utils.facts.collectors.all.FACT_COLLECTOR_PLUGINS

    data

# Generated at 2022-06-20 16:54:00.071053
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import json
    expected_result = {'ansible_facts': {'gather_subset': 'all'}}

    # ad-hoc testing
    result = \
        CollectorMetaDataCollector(gather_subset='all', module_setup=True).collect()
    assert json.loads(json.dumps(result)) == expected_result



# Generated at 2022-06-20 16:54:07.699100
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ''' This function will check if the class works'''
    class TestClass(object):
        pass
    test_obj = TestClass()
    # Instantiate the class
    test_obj = AnsibleFactCollector(collectors=None, namespace=None)
    assert test_obj._filter({}, None) == {}
    assert test_obj._filter({'a':'b'}, None) == {'a':'b'}
    assert test_obj._filter({'ab':'b'}, '*') == {'ab':'b'}
    assert test_obj._filter({'ab':'b'}, 'ab') == [('ab', 'b')]
    assert test_obj._filter({'ab':'b', 'ac':'d'}, 'ab') == [('ab', 'b')]
    assert test_obj._

# Generated at 2022-06-20 16:54:12.468815
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    """returns a dictionary with the keys 'gather_subset' and 'module_setup' and their respective values"""
    metadata = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert metadata.collect() == {'gather_subset': ['all'], 'module_setup': True}

    metadata = CollectorMetaDataCollector(gather_subset=['facts'], module_setup=False)
    assert metadata.collect() == {'gather_subset': ['facts'], 'module_setup': False}

# Generated at 2022-06-20 16:54:15.191796
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    # Constructor with no args
    CollectorMetaDataCollector()

    # Constructor with args
    CollectorMetaDataCollector(['a', 'b'], 'c', 'd', 'e')

# Generated at 2022-06-20 16:54:23.525773
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import logging

    import ansible.module_utils.facts.system.base

    logging.basicConfig()
    logging.getLogger().setLevel(logging.DEBUG)

    all_collector_classes = ansible.module_utils.facts.system.base.CACHE

    minimal_gather_subset = frozenset(['!all', '!any'])

    gather_subset = ['!all', '!any']

    gather_timeout = i

# Generated at 2022-06-20 16:54:35.105353
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.distribution

    # Note: AnsibleFactCollector needs no filter_spec
    ansible_fact_collector = \
        AnsibleFactCollector(collectors=[ansible.module_utils.facts.system.distribution.DistributionFactCollector()])

    # Collect facts

    facts_dict = ansible_fact_collector.collect()

    # Note: the fact below is filtered out because of filter_spec
    assert 'kernel' not in facts_dict

    # Get root collector
    root_collector_obj = ansible_fact_collector.root_collector
    assert root_collector_obj.namespace == ''

    # Get list of collectors
    assert len(ansible_fact_collector.collectors) == 1



# Generated at 2022-06-20 16:54:45.405701
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # TODO: Make this a more realistic test.
    import ansible.module_utils.facts.system.distribution

    d1 = ansible.module_utils.facts.system.distribution.Distribution()
    d2 = ansible.module_utils.facts.system.distribution.Distribution()
    c1 = ansible.module_utils.facts.system.distribution.Collector(namespace=None)
    c1.collectors = [d1]
    c2 = ansible.module_utils.facts.system.distribution.Collector(namespace=None)
    c2.collectors = [d2]

    mock_module = {'ANSIBLE_SYSTEM_PACKAGES_LIST': 'a b c'}

    fc = AnsibleFactCollector(collectors=[c1, c2])
    facts

# Generated at 2022-06-20 16:54:51.903932
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    from ansible.module_utils.facts.collector.os import DefaultCollector
    c = CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=None,
                                   collectors=[DefaultCollector()])
    f = c.collect()
    assert(f['gather_subset'] == ['all'])
    assert('module_setup' not in f)


# Generated at 2022-06-20 16:55:14.316476
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import namespaced_fact_collectors

    namespace = namespaced_fact_collectors.PrefixFactNamespace(prefix='ansible_')
    fact_collector = get_ansible_collector(all_collector_classes=False,
                                           namespace=namespace,
                                           gather_subset=['all'],
                                           gather_timeout=10)

    module = {}
    facts = fact_collector.collect(module=module)

    assert isinstance(facts, dict)
    assert 'gather_subset' in facts
    assert 'module_setup' in facts
    assert 'ansible_all_ipv4_addresses' in facts

# Generated at 2022-06-20 16:55:26.093239
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    sys.path.append('./lib/ansible/module_utils/facts')
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import local
    from ansible.module_utils.facts import command
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import system
    all_collector_classes = [cache.CacheFactCollector,
                             local.LocalFactCollector,
                             command.CommandFactCollector,
                             network.NetworkFactCollector,
                             hardware.HardwareFactCollector,
                             system.SystemFactCollector]
    namespace = None
    filter_spec = None
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_G

# Generated at 2022-06-20 16:55:38.032309
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    collector_meta_data_collector_1 = \
        CollectorMetaDataCollector(gather_subset='all',
                                   module_setup=True)

    collector_meta_data_collector_2 = \
        CollectorMetaDataCollector(gather_subset='all')

    collector_meta_data_collector_3 = \
        CollectorMetaDataCollector(gather_subset='network',
                                   module_setup=True)

    assert collector_meta_data_collector_1.collect() == \
           {'gather_subset': 'all', 'module_setup': True}

    assert collector_meta_data_collector_2.collect() == \
           {'gather_subset': 'all'}


# Generated at 2022-06-20 16:55:45.233505
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    # Mock the FactCollector
    class MockCollector(collector.BaseFactCollector):
        def __init__(self, collectors=None, namespace=None):
            super(MockCollector, self).__init__(collectors, namespace)

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            return collected_facts

    # Mock the fact collector classes
    # Since system facts are collected by get_ansible_collector, mocking those facts
    class MockCollectorClasses:
        def __init__(self):
            self.collector_classes = [MockCollector]

    # Mocking the fact collector namespaces
    class MockCollectorNamespace:
        def __init__(self):
            self.namespaces = ["mock1", "mock2"]

# Generated at 2022-06-20 16:55:56.711321
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Test the get_ansible_collector function.'''

    all_collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=collector.get_collector_classes(),
            minimal_gather_subset=frozenset(),
            gather_subset=['all'],
            gather_timeout=10)


# Generated at 2022-06-20 16:56:08.325286
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform

    distro_collector = ansible.module_utils.facts.system.distribution.Distribution()
    platform_collector = ansible.module_utils.facts.system.platform.Platform()
    collectors = [distro_collector, platform_collector]
    collector_namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')
    fact_collector = AnsibleFactCollector(collectors=collectors, namespace=collector_namespace)

    assert fact_collector.namespace == collector_namespace

# Generated at 2022-06-20 16:56:18.131676
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # We need to have local facts registered to run this test
    if 'local' not in collector.CollectorRegistry:
        collector.register(collector.LocalFactsCollector)

    # Test with local gather_subset (minus local), local fact in filter
    ansible_collector = get_ansible_collector(filter_spec='facter.*',
                                              minimal_gather_subset=['local'],
                                              gather_subset={'all', 'local'})

    # Set a local fact for our filter
    ansible_collector.collectors[0].facts.update({'facter': 'foobar'})

    facts = ansible_collector.collect()


# Generated at 2022-06-20 16:56:26.228180
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ''' Test function collect of class CollectorMetaDataCollector. '''
    fact_collector = CollectorMetaDataCollector()
    result = fact_collector.collect()
    assert result == {'gather_subset': 'all'}

    fact_collector = CollectorMetaDataCollector(gather_subset='network')
    result = fact_collector.collect()
    assert result == {'gather_subset': 'network'}