

# Generated at 2022-06-20 16:46:34.224516
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.collector import CollectorMetaDataCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    import copy

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='!all,min')

    ansible_collectors = [collector_meta_data_collector]
    ansible_collector = AnsibleFactCollector(collectors=ansible_collectors,
                                             namespace=PrefixFactNamespace(prefix='ansible_'))

    ansible_facts = {}
    ansible_facts = ansible_collector.collect()


# Generated at 2022-06-20 16:46:46.001434
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    from ansible.module_utils.facts import network

    fact_collector = \
        AnsibleFactCollector(collectors=[collector.BaseFactCollector, network.NetworkCollector],
                             namespace=None)

    # filter_spec=[] is equivalent to filter_spec='*'
    filter_spec = []
    module = None
    collected_facts = {}
    result = \
        fact_collector.collect(module=module,
                               collected_facts=collected_facts)


# Generated at 2022-06-20 16:46:51.760032
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts.collector import namespaced_facts

    fact_collector = AnsibleFactCollector(namespace=namespaced_facts.PrefixFactNamespace(prefix='ansible_'))
    assert fact_collector.namespace.prefix == 'ansible_'

    fact_collector = AnsibleFactCollector(namespace=None)
    assert fact_collector.namespace == None

# Generated at 2022-06-20 16:47:04.809248
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    '''Unit test for method collect of class CollectorMetaDataCollector'''

    # No gather_subset
    meta_facts = CollectorMetaDataCollector().collect()
    assert meta_facts == {'gather_subset': ['all']}

    # gather_subset
    meta_facts = CollectorMetaDataCollector(gather_subset=['all', 'network']).collect()
    assert meta_facts == {'gather_subset': ['all', 'network']}

    # No module_setup
    meta_facts = CollectorMetaDataCollector(gather_subset=['all']).collect()
    assert meta_facts == {'gather_subset': ['all']}

    # module_setup

# Generated at 2022-06-20 16:47:05.668752
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-20 16:47:10.772296
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    m = CollectorMetaDataCollector(["test1", "test2"])
    assert m.collect() == {'gather_subset': ["test1", "test2"]}



# Generated at 2022-06-20 16:47:17.385987
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts import ansible_collector
    collector_obj = ansible_collector.CollectorMetaDataCollector(gather_subset=['all'],
                                                                 module_setup=True)
    result = collector_obj.collect()
    assert 'gather_subset' in result
    assert 'module_setup' in result
    assert result['module_setup'] is True


# Generated at 2022-06-20 16:47:23.460219
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    filter_spec = filter_spec or []
    gather_subset = gather_subset or ['all']
    gather_timeout = gather_timeout or timeout.DEFAULT_GATHER_TIMEOUT

    minimal_gather_subset = frozenset()

    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=minimal_gather_subset,
            gather_subset=gather_subset,
            gather_timeout=gather_timeout)

    collectors = []
    for collector_class in collector_classes:
        collector_obj = collector_class(namespace=namespace)
        collectors.append(collector_obj)

    # Add a collector that knows what gather_subset we

# Generated at 2022-06-20 16:47:32.254138
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    metadata_collector = ansible_collector.CollectorMetaDataCollector(gather_subset=['all'],
                                                                      module_setup=True)
    metadata = metadata_collector.collect()
    assert metadata == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-20 16:47:36.802651
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    '''
    ansible_fact = AnsibleFactCollector()
    '''
    ansible_fact = AnsibleFactCollector()
    return ansible_fact.__init__

# Generated at 2022-06-20 16:47:47.317279
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=('all',))
    assert collector_meta_data_collector.name == 'gather_subset'
    assert len(collector_meta_data_collector._fact_ids) == 0
    assert collector_meta_data_collector.gather_subset == ('all',)
    assert collector_meta_data_collector.module_setup is None

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=('all',),
                                   module_setup=True)
    assert collector_meta_data_collector.name == 'gather_subset'
    assert len(collector_meta_data_collector._fact_ids) == 0
    assert collector_meta_data

# Generated at 2022-06-20 16:47:56.652455
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    collector_a = collector.BaseFactCollector(namespace='ns_a')
    collector_b = collector.BaseFactCollector(namespace='ns_b')
    ansible_fact_collector = AnsibleFactCollector(collectors=[collector_a, collector_b])
    assert ansible_fact_collector.collectors == [collector_a, collector_b]
    assert ansible_fact_collector.namespace is None
    assert ansible_fact_collector.filter_spec is None


# Generated at 2022-06-20 16:48:09.811688
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible_collections.ansible.netcommon.plugins.module_utils.facts import decomposer_classes

    # This code tests the AnsibleFactCollector class by mocking the collector classes.
    collector_class_mocks = []
    # 3 collector classes, each with a unique name
    for x in range(3):
        collector_class_mock = \
            collector.mock_collector_class(name='collector_%s' % x)
        collector_class_mocks.append(collector_class_mock)

    # Get a collector instance for the mock collector classes
    fact_collector = \
        AnsibleFactCollector(collectors=collector_class_mocks,
                             filter_spec='*')

    # Test collect method
    facts_dict = fact_collector.collect()

    #

# Generated at 2022-06-20 16:48:15.698124
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    assert collector_meta_data_collector.collect() == { 'gather_subset': ['all'], 'module_setup': True }

# Generated at 2022-06-20 16:48:28.822749
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Test method collect of class AnsibleFactCollector.'''
    class FirstCollector(collector.BaseFactCollector):
        '''A fake collector.'''
        def collect(self, module=None, collected_facts=None):
            return {'first': 'first'}

    class SecondCollector(collector.BaseFactCollector):
        '''A fake collector.'''
        def collect(self, module=None, collected_facts=None):
            return {'second': 'second'}

    fact_collector = AnsibleFactCollector(collectors=[FirstCollector(),
                                                      SecondCollector()])
    collected_facts = fact_collector.collect(collected_facts={})
    assert collected_facts == {'first': 'first',
                               'second': 'second'}

    fact_collector = Ans

# Generated at 2022-06-20 16:48:41.195517
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class A(collector.BaseFactCollector):
        name = 'a'

        def __init__(self, namespace=None):
            super(A, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {self.namespace_prefix('x'): 'a'}

    class B(collector.BaseFactCollector):
        name = 'b'

        def __init__(self, namespace=None):
            super(B, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {self.namespace_prefix('y'): 'b'}


# Generated at 2022-06-20 16:48:51.419293
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FakeCollector:

        def __init__(self, name=None, prefix=None):
            self._name = name
            self._prefix = prefix
            self._facts = {}

        def collect_with_namespace(self, module=None, collected_facts=None):

            return {self._prefix + self._name: self._facts.copy()}

    fact1 = FakeCollector(name='a', prefix='ansible_')
    fact2 = FakeCollector(name='b', prefix='ansible_')
    fact3 = FakeCollector(name='c', prefix='facter')
    fact1._facts = {'name1': 'value1'}
    fact2._facts = {'name2': 'value2'}
    fact3._facts = {'name3': 'value3'}


# Generated at 2022-06-20 16:48:54.205412
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_collector = CollectorMetaDataCollector(gather_subset=['all', 'network'],
                                                module_setup=True)
    meta_facts_dict = meta_collector.collect()
    assert meta_facts_dict['gather_subset'] == ['all', 'network']
    assert meta_facts_dict['module_setup'] is True, \
        "module_setup should be True"


# Generated at 2022-06-20 16:49:02.717236
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_obj = CollectorMetaDataCollector()
    assert isinstance(collector_obj, CollectorMetaDataCollector)
    assert collector_obj.collect() == {
        'gather_subset': None
    }
    del collector_obj

    # should default to minimal subset
    collector_obj = CollectorMetaDataCollector(gather_subset=None)
    assert isinstance(collector_obj, CollectorMetaDataCollector)
    assert collector_obj.collect() == {
        'gather_subset': 'min'
    }
    del collector_obj

    collector_obj = CollectorMetaDataCollector(gather_subset=['all'])
    assert isinstance(collector_obj, CollectorMetaDataCollector)

# Generated at 2022-06-20 16:49:11.020896
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class DummyFactsCollector(collector.BaseFactCollector):
        '''A Dummy FactsCollector that returns a dictionary.'''

        name = 'dummy_facts'

        def collect(self, module=None, collected_facts=None):
            return {'ansible_dummy': 'this'}

    fact_collector = AnsibleFactCollector(collectors=[DummyFactsCollector()])
    facts = fact_collector.collect()
    assert facts == {'ansible_dummy': 'this'}, \
        'failed to collect facts under ansible_facts top level key'



# Generated at 2022-06-20 16:49:16.749470
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import collector

    collector_obj = AnsibleFactCollector()
    assert collector_obj is not None


# Generated at 2022-06-20 16:49:22.876017
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                module_setup=True)
    facts_dict = fact_collector.collect()
    assert not facts_dict.keys() - ['gather_subset', 'module_setup']
    assert 'gather_subset' in facts_dict.keys()
    assert 'all' in facts_dict['gather_subset']
    assert 'module_setup' in facts_dict.keys()
    assert facts_dict['module_setup'] is True
    fact_collector = CollectorMetaDataCollector(gather_subset=['network', 'ohai'])
    facts_dict = fact_collector.collect()
    assert not facts_dict.keys() - ['gather_subset']

# Generated at 2022-06-20 16:49:29.937037
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    import ansible.module_utils.facts.system.all as fact_class
    ns = collector.namespace.PrefixFactNamespace(prefix='a')
    collected_facts = dict()
    f = CollectorMetaDataCollector(namespace=ns, gather_subset=['all'], module_setup=True)
    assert len(f.gather_subset) == 1
    assert f.gather_subset == ['all']
    assert f.module_setup is True


# Generated at 2022-06-20 16:49:40.802999
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # test calling with no params
    meta = CollectorMetaDataCollector()
    fact = meta.collect()
    assert fact['gather_subset'] == None
    assert fact['module_setup'] == None

    # test calling with gather subset
    meta = CollectorMetaDataCollector(gather_subset=['foo', 'bar'])
    fact = meta.collect()
    assert fact['gather_subset'] == ['foo', 'bar']
    assert fact['module_setup'] == None

    # test calling with module setup True
    meta = CollectorMetaDataCollector(module_setup=True)
    fact = meta.collect()
    assert fact['gather_subset'] == None
    assert fact['module_setup'] == True

    # test calling with gather subset and module setup True

# Generated at 2022-06-20 16:49:49.136196
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collectors = [MockCollector(namespace='fact1', facts={'a': 1, 'b': 2}),
                  MockCollector(namespace='fact2', facts={'c': 3, 'd': 4})]
    fact_collector = AnsibleFactCollector(collectors=collectors)
    ansible_facts = fact_collector.collect()
    assert ansible_facts == {'a': 1, 'b': 2}


# Generated at 2022-06-20 16:49:54.548378
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    ansible_fact_collector = AnsibleFactCollector()
    assert ansible_fact_collector.namespace is None
    assert ansible_fact_collector.collectors == []
    assert ansible_fact_collector.filter_spec is None

# Generated at 2022-06-20 16:49:58.836872
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.platform.linux import LinuxCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.linux import LinuxFileSystemCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_collector_classes = ansible_collector.get_all_collector_classes()

    linux_collector_obj = LinuxCollector(namespace=None)
    linux_file_system_collector_obj = LinuxFileSystemCollector(namespace=None)
    linux_collectors = [linux_collector_obj, linux_file_system_collector_obj]


# Generated at 2022-06-20 16:50:03.572611
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collectors = None
    namespace = None
    gather_subset = 'all'
    module_setup = True

    collector_meta_data_collector = CollectorMetaDataCollector(
        collectors, namespace, gather_subset, module_setup)

    assert collector_meta_data_collector.collect() == \
        {'gather_subset': 'all', 'module_setup': True}

# Generated at 2022-06-20 16:50:15.328793
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.collector.system
    system_collector_class = ansible.module_utils.facts.collector.system.SystemCollector
    # 'gather_subset': None, 'minimal_gather_subset': None, 'gather_timeout': None
    ansible_collector = get_ansible_collector(all_collector_classes=[system_collector_class])
    facts = ansible_collector.collect()
    assert isinstance(facts['gather_subset'], list)
    assert not facts['module_setup']  # default is False
    # 'gather_subset': None, 'minimal_gather_subset': None, 'gather_timeout': None, 'module_setup': True
    ansible_collector = get_ansible_collector

# Generated at 2022-06-20 16:50:25.702418
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''
    NOTE: This is a module_utils and not a module, and it is only possible to have one
    unittest per module.  So this test is at the bottom of the file
    '''
    import pytest
    from . import namespace

    class FakeCollector1(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {
                'a': 1,
                'b': 2,
                'c': 3
            }

    class FakeCollector2(collector.BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {
                'd': 4,
                'e': 5,
                'f': 6
            }


# Generated at 2022-06-20 16:50:40.101641
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # test with no gather_subset
    collector_meta_data_collector = \
        CollectorMetaDataCollector()
    meta_facts = collector_meta_data_collector.collect()
    if meta_facts['gather_subset'] != 'all' or \
       meta_facts['module_setup'] != True:
        raise AssertionError("test 1 of test_CollectorMetaDataCollector_collect() failed")

    # test with gather_subset
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset='some_subset',
                                   module_setup=False)
    meta_facts = collector_meta_data_collector.collect()

# Generated at 2022-06-20 16:50:49.189764
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['min'], module_setup=True)
    assert collector_meta_data_collector.gather_subset == ['min']
    assert collector_meta_data_collector.module_setup == True

    # test fact dict returned
    collected_facts = {}
    fact_dict = collector_meta_data_collector.collect(module=None,
                                                      collected_facts=collected_facts)
    assert fact_dict == {'gather_subset': ['min'], 'module_setup': True}

# Generated at 2022-06-20 16:50:58.229251
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = get_ansible_collector(all_collector_classes=None,
                                           namespace=None,
                                           filter_spec=None,
                                           gather_subset=['!all'],
                                           gather_timeout=None,
                                           minimal_gather_subset=frozenset())
    print(fact_collector.collectors)


# This can be run standalone to perform a test of all of the core facts modules

# Generated at 2022-06-20 16:51:11.468377
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Test the collect method of AnsibleFactCollector'''

    def mock_collect(module=None, collected_facts=None):
        '''A mock collect method for the fact collectors'''
        collected_facts = collected_facts or {}
        collected_facts["_unit_test"] = "Hello World"
        return collected_facts

    class MockCollector(object):
        '''A mock fact collector'''
        def __init__(self, namespace=None):
            self.namespace = namespace

        def collect_with_namespace(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts["_unit_test2"] = "Hello World2"
            return collected_facts

    # Create an AnsibleFactCollector object with 1 mock collector
    mock_collector = Mock

# Generated at 2022-06-20 16:51:23.118167
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    mock_collectors = [
        collector.FacterFactCollector,
        collector.OhaiFactCollector,
        collector.SystemProfilerFactCollector,
        collector.VirtualBoxFactCollector
    ]

    ansible_collector = get_ansible_collector(all_collector_classes=mock_collectors,
                                              gather_subset=['all'],
                                              gather_timeout=10,
                                              minimal_gather_subset=frozenset(('all',)))

    collected_facts = ansible_collector.collect(module=None)

    assert collected_facts is not None
    assert len(collected_facts) > 0

    assert 'all' in collected_facts
    assert 'facter' in collected_facts
    assert 'ansible' in collected_facts

# Generated at 2022-06-20 16:51:31.944293
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    expected_gather_subset = ['all']
    expected_module_setup  = True

    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=expected_gather_subset, module_setup=expected_module_setup)
    fact_dict = collector_meta_data_collector.collect()

    assert fact_dict['gather_subset'] == expected_gather_subset
    assert fact_dict['module_setup'] == expected_module_setup

# Generated at 2022-06-20 16:51:41.514892
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    all_collector_classes = []
    namespace_obj = None
    gather_subset = ['kernel', 'virtual']
    module_setup = True
    obj = CollectorMetaDataCollector(None,
                                    namespace=namespace_obj,
                                    gather_subset=gather_subset,
                                    module_setup=module_setup)
    assert obj.collect() == {'gather_subset': ['kernel', 'virtual'], 'module_setup': True}

# Generated at 2022-06-20 16:51:46.780214
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    c = CollectorMetaDataCollector(gather_subset='all', module_setup=True)
    assert c.module_setup == True
    assert c.gather_subset == 'all'

# Generated at 2022-06-20 16:51:53.698622
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():

    fact_collector = AnsibleFactCollector()
    assert fact_collector.collectors is None
    assert fact_collector.namespace is None

    collectors = ['one', 'two', 'three']
    namespace = 'ge_prefix'

    fact_collector = AnsibleFactCollector(collectors, namespace)
    assert fact_collector.collectors is collectors
    assert fact_collector.namespace is namespace


# Generated at 2022-06-20 16:52:05.380673
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import get_collector_classes

    class MockCollector:
        def __init__(self, namespace):
            pass
        def collect(self, module=None, collected_facts=None):
            return {}

    all_collector_classes = {
        'mock': MockCollector,
    }

    # Call the function we are testing
    fact_collector = \
        get_ansible_collector(all_collector_classes,
                              namespace=None,
                              filter_spec=['foo'],
                              gather_subset=['all'],
                              gather_timeout=30,
                              minimal_gather_subset=['mock'])

    # Verify that we created the right thing

# Generated at 2022-06-20 16:52:29.248586
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import namespace
    import ansible.module_utils.facts.collector.shared.base

    class BaseMock(BaseFactCollector):
        name = 'base'

    BaseMock.register_collector_class(BaseMock)

    class TestMock(BaseFactCollector):
        name = 'test'

    TestMock.register_collector_class(TestMock)

    class Test2Mock(BaseFactCollector):
        name = 'test2'
        _fact_ids = frozenset(['facts_key1', 'facts_key2'])


# Generated at 2022-06-20 16:52:38.311181
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    collectors = [None]
    namespace = None
    gather_subset = ['all', 'foo']
    module_setup = True
    cm = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)
    assert (cm.gather_subset == gather_subset)
    assert (cm.module_setup == module_setup)
    assert (cm.name == 'gather_subset')
    assert (cm._fact_ids == set([]))
    assert (cm.namespace == namespace)
    assert (cm._collectors == collectors)
    assert (cm.collect() == {'gather_subset': gather_subset, 'module_setup': module_setup})


# Generated at 2022-06-20 16:52:47.452639
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import tempfile
    from ansible.module_utils.facts.hardware.aix import AixHardware as aix_hw
    aix_hw_obj = aix_hw(namespace='platform')
    aix_hw_collector = collector.BaseFactCollector(namespace='platform')
    aix_hw_collector.collectors.append(aix_hw_obj)
    aix_hw_collector._fact_ids = aix_hw_obj.FACT_NAMES
    aix_hw_collector.FACT_NAMES = aix_hw_obj.FACT_NAMES

    with tempfile.NamedTemporaryFile(delete=False) as fd:
        fd.write(b'vg00:open/syncd\nrootvg:open/syncd/syncd')

# Generated at 2022-06-20 16:52:59.105955
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    gather_subset = ['all']
    minimal_gather_subset = frozenset()
    gather_timeout = 10
    filter_spec = None
    namespace = None

    from ansible.module_utils.facts.collector.all import AllFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareFactCollector

    all_collector_classes = \
        [AllFactCollector, NetworkFactCollector, HardwareFactCollector]


# Generated at 2022-06-20 16:53:05.755251
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    fact_meta_data_collector = CollectorMetaDataCollector(gather_subset=['network'],
                                                          module_setup=True)
    meta_facts = fact_meta_data_collector.collect()
    assert meta_facts == {'gather_subset': ['network'], 'module_setup': True}

# Generated at 2022-06-20 16:53:16.649126
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = collector.collector_classes()
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    namespace = PrefixFactNamespace(prefix='ansible_')

    truth_data = {'ansible_python_version': 2,
                  'ansible_local': {'test': 1}}

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              namespace=namespace,
                              filter_spec=['local'])

    collected_facts = fact_collector.collect(module=None,
                                             collected_facts={})

    collected_facts = collected_facts[namespace.prefix]
    assert collected_facts == truth_data

# Generated at 2022-06-20 16:53:26.515086
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''
    Make sure the function get_ansible_collector returns AnsibleFactCollector and
    CollectorMetaDataCollector instances.
    '''
    import ansible.module_utils.facts.system.all as sys_all_mock
    import ansible.module_utils.facts.network.all as net_all_mock

    all_collector_classes = [sys_all_mock.AllCollector, net_all_mock.AllCollector]
    gather_subset = ['all', 'min']
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           filter_spec='*',
                                           gather_subset=gather_subset,
                                           namespace=None)

# Generated at 2022-06-20 16:53:27.737566
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    pass

# Generated at 2022-06-20 16:53:32.254722
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    assert(CollectorMetaDataCollector(gather_subset=['foo', 'bar'], module_setup=True).collect() == {'gather_subset': ['foo', 'bar'], 'module_setup': True})

# Generated at 2022-06-20 16:53:37.508049
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset=['all'],
                                                               namespace='ansible_test',
                                                               module_setup=False)
    ansible_facts = collector_meta_data_collector.collect()

    expected_meta_facts = {'ansible_test': {'gather_subset': ['all']}}
    assert ansible_facts == expected_meta_facts

# Generated at 2022-06-20 16:54:13.163422
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class FakeCollector(object):

        def collect(self, module=None, collected_facts=None):
            return dict(foo='baz')

    # Test no filter_spec
    fact_collector = AnsibleFactCollector(collectors=[FakeCollector()])
    fact_dict = fact_collector.collect()
    assert fact_dict == dict(foo='baz')

    # Test filter_spec with wildcard
    fact_collector = AnsibleFactCollector(collectors=[FakeCollector()],
                                          filter_spec='*')
    fact_dict = fact_collector.collect()
    assert fact_dict == dict(foo='baz')

    # Test filter_spec with exact match

# Generated at 2022-06-20 16:54:24.892066
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    from ansible.module_utils.facts import namespaced_fact
    from ansible.module_utils.facts import collector

    # from_gather_subset()
    all_collector_classes = collector.collector_classes(namespaced_fact.PrefixFactNamespace(prefix='all_'))
    minimal_collector_classes = collector.collector_classes(namespaced_fact.PrefixFactNamespace(prefix='min_'))

    # namespaces are ignored
    fact_collector = AnsibleFactCollector.from_gather_subset(
                                                all_collector_classes=all_collector_classes,
                                                minimal_gather_subset=minimal_collector_classes,
                                                gather_subset=['!all', 'minimal'],
                                                gather_timeout=10)

# Generated at 2022-06-20 16:54:35.937529
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    collector.FactNamespace = None

    class MockFacts(object):

        def __init__(self, data):
            self.data = data
            self.changed = False
            self.failed = False
            self.warnings = []

        def collect_with_namespace(self, module, collected_facts):
            return self.data

    def assert_fact_collector(fact_collector, expected):
        fact_collector.collect()
        assert fact_collector.fact_list == expected

    # Test no namespace
    fact_collector = AnsibleFactCollector([MockFacts({'foo': 'bar'})])
    assert_fact_collector(fact_collector, [{'name': 'foo', 'value': 'bar'}])

    # Test namespace
    fact_namespace = collector.FactNamespace

# Generated at 2022-06-20 16:54:45.776863
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # The fact collector which we want to test
    fact_collector = AnsibleFactCollector()

    # Some fact collectors to be used by the test fact collector
    fact1_collector = AnsibleFactCollector()
    fact2_collector = AnsibleFactCollector()
    fact3_collector = AnsibleFactCollector()

    # Set the return dict for the collected facts
    fact1_collector.collect = lambda x, y: {'fact1': 'fact1'}
    fact2_collector.collect = lambda x, y: {'fact2': 'fact2'}
    fact3_collector.collect = lambda x, y: {'fact3': 'fact3'}

    # Create and set the collectors to be used the test fact collector

# Generated at 2022-06-20 16:54:48.218598
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector = CollectorMetaDataCollector(
        gather_subset=['all'],
        module_setup=False
    )
    assert collector_meta_data_collector.collect() == {'gather_subset': ['all']}

# Generated at 2022-06-20 16:54:55.014559
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():
    '''Expects that the initialized object has 4 parameters'''
    collectors = None
    namespace = None
    gather_subset = None
    module_setup = None
    collector_meta_data_collector = CollectorMetaDataCollector(collectors,
                                                               namespace,
                                                               gather_subset,
                                                               module_setup)
    assert collector_meta_data_collector.collectors == None
    assert collector_meta_data_collector.namespace == None
    assert collector_meta_data_collector.gather_subset == None
    assert collector_meta_data_collector.module_setup == None


# Generated at 2022-06-20 16:55:00.423476
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    namespace = collector.BaseFactNamespace(name='test1')
    a = AnsibleFactCollector(namespace=namespace)
    # Will fail if 'test1' namespace does not exist
    assert a.namespace == 'test1'

# Generated at 2022-06-20 16:55:05.846028
# Unit test for constructor of class AnsibleFactCollector
def test_AnsibleFactCollector():
    import ansible.module_utils.facts.namespace as facts_namespace
    namespace = facts_namespace.PrefixFactNamespace(prefix='ansible_')
    filter_spec = ['ansible_os*']
    fact_collector = AnsibleFactCollector(namespace=namespace, filter_spec=filter_spec)
    assert fact_collector._namespace.prefix == 'ansible_'
    assert fact_collector.filter_spec == ['ansible_os*']


# Generated at 2022-06-20 16:55:14.770419
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Unit test for function get_ansible_collector.'''

    import ansible.module_utils.facts.collector.default
    import ansible.module_utils.facts.collector.network
    all_collector_classes = [ansible.module_utils.facts.collector.default.Default,
                             ansible.module_utils.facts.collector.network.Network]
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset='!foo',
                                           gather_timeout=10)
    # Unit test can't really validate collectors.
    # Just check that we have some collectors
    assert len(fact_collector.collectors) > 0

# Generated at 2022-06-20 16:55:23.214724
# Unit test for constructor of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector():

    # Should return all the collectors
    collector_meta_data_collector = \
        CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)

    # All the collectors are present in the CollectorMetaDataCollector object
    set(collector_meta_data_collector.collectors) == set([
        'all', 'network', 'virtual', 'hardware', 'system'])

