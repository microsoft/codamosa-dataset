

# Generated at 2022-06-11 02:01:20.895404
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_facts = {'gather_subset': '!all', 'module_setup': True}
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='!all')
    assert meta_facts == collector_meta_data_collector.collect()

# Generated at 2022-06-11 02:01:29.199028
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # DO NOT REMOVE THIS UNIT TEST: It is used to test unit test code in the main module
    all_collector_classes = None
    namespace = None
    filter_spec = None
    gather_subset = None
    gather_timeout = None
    minimal_gather_subset = None
    fact_collector = \
        get_ansible_collector(all_collector_classes,
                              namespace,
                              filter_spec,
                              gather_subset,
                              gather_timeout,
                              minimal_gather_subset)
    assert fact_collector

# Generated at 2022-06-11 02:01:32.909438
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_obj = \
        CollectorMetaDataCollector(gather_subset=['a'],
                                   module_setup=False)
    assert collector_meta_data_collector_obj.collect() == {'gather_subset': ['a']}

# Generated at 2022-06-11 02:01:36.668186
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    gather_subset = 'all'
    module_setup = True
    c = CollectorMetaDataCollector(gather_subset=gather_subset,
                                   module_setup=module_setup)

    expected_dict = {'gather_subset': gather_subset, 'module_setup': True}

    assert c.collect() == expected_dict


# Generated at 2022-06-11 02:01:39.640651
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    expected = {'gather_subset': ['all'], 'module_setup': True}

    collector_meta_data_collector = CollectorMetaDataCollector(
        namespace=None,
        gather_subset=['all'],
        module_setup=True
    )

    result = collector_meta_data_collector.collect()

    assert result == expected

# Generated at 2022-06-11 02:01:45.595930
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    # Test method collect of class CollectorMetaDataCollector
    collector_meta_data_collector = CollectorMetaDataCollector(gather_subset='all',
                                                               module_setup=True)
    meta_facts = collector_meta_data_collector.collect()
    # Check that the module_setup is correct
    assert meta_facts['module_setup']
    # Check that the gather_subset is correct
    assert meta_facts['gather_subset'] == 'all'


# Generated at 2022-06-11 02:01:50.944361
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_obj = CollectorMetaDataCollector(gather_subset=[],
                                          module_setup=True)
    results = test_obj.collect()
    assert('gather_subset' in results)
    assert('module_setup' in results)
    assert results['module_setup'] is True


# Generated at 2022-06-11 02:01:54.508197
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import all_collector_classes
    from ansible.module_utils.facts import ansible_collector
    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                namespace=None,
                                                gather_subset=None,
                                                gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT,
                                                minimal_gather_subset=frozenset())


if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-11 02:01:58.748831
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = CollectorMetaDataCollector(
        ['fake_collector1', 'fake_collector2'], namespace='Fake_namespace')
    facts = fact_collector.collect()
    assert facts['gather_subset'] == ['fake_collector1', 'fake_collector2']

# Generated at 2022-06-11 02:02:03.791335
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collector_meta_data_collector_obj = \
        CollectorMetaDataCollector(gather_subset=['all'], module_setup=True)
    facts_collected = collector_meta_data_collector_obj.collect(module=None, collected_facts=None)
    assert 'gather_subset' in facts_collected
    assert 'module_setup' in facts_collected

test_CollectorMetaDataCollector_collect()

# Generated at 2022-06-11 02:02:17.678548
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import basicauth
    from ansible.module_utils.facts import defaultdict
    from ansible.module_utils.facts import disk
    from ansible.module_utils.facts import ec2
    from ansible.module_utils.facts import dmidecode
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import lldp
    from ansible.module_utils.facts import networking
    from ansible.module_utils.facts import osinfo
    from ansible.module_utils.facts import package
    from ansible.module_utils.facts import selinux
    from ansible.module_utils.facts import systemd
    from ansible.module_utils.facts import virtual

# Generated at 2022-06-11 02:02:27.434582
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes = [
        collector.Collector1(),
        collector.Collector2()]
    gather_subset = ['all']
    gather_timeout = 0
    minimal_gather_subset = frozenset([])
    fact_collector = \
        get_ansible_collector(all_collector_classes=collector_classes,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)
    assert len(fact_collector.collectors) == 3
    assert fact_collector.collectors[0].__class__ == collector.Collector1
    assert fact_collector.collectors[1].__class__ == collector.Collector2
    assert fact_collector.collect

# Generated at 2022-06-11 02:02:32.876173
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collectors = None
    namespace = None
    gather_subset = None
    module_setup = None

    test_collector = CollectorMetaDataCollector(collectors, namespace, gather_subset, module_setup)
    assert test_collector.collect() == {'gather_subset': None, 'module_setup': None}


# Generated at 2022-06-11 02:02:37.522741
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector()
    f = c.collect()
    assert isinstance(f, dict)
    assert 'gather_subset' in f
    assert 'module_setup' in f
    assert len(f) == 2

# Generated at 2022-06-11 02:02:48.000541
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    import ansible.module_utils.facts.collector as collector
    from ansible.module_utils.facts import ansible_collector

    import ansible.module_utils.facts.hardware as hardware
    from ansible.module_utils.facts import namespaces
    from ansible.module_utils.facts import namespace_manager

    import ansible.module_utils.facts.system as system

    # We need to import all collector classes, so that they are registered in the
    # namespace_manager
    hardware
    system
    # import logging; logging.basicConfig(level=logging.DEBUG)

    hardware_collector_class = collector.CollectorClassRegistry().get_collector_class(
        'ansible.module_utils.facts.hardware.Hardware')

# Generated at 2022-06-11 02:02:55.966492
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ''' Unit tests for module_utils/facts/collector.py class CollectorMetaDataCollector method collect()'''
    my_test_class = CollectorMetaDataCollector(gather_subset="test_gather_subset", module_setup=True)
    my_test_class.collectors = []
    my_test_class.namespace = None
    my_test_collect = my_test_class.collect()
    my_test_dict = {'gather_subset': 'test_gather_subset', 'module_setup': True}
    assert my_test_dict == my_test_collect

# Generated at 2022-06-11 02:03:06.949225
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    def check_collect_facts(gather_subset, expect_gather_subset):

        fact_collector = CollectorMetaDataCollector(gather_subset=gather_subset)
        facts_dict = fact_collector.collect_with_namespace()

        assert facts_dict == {'gather_subset': expect_gather_subset, 'module_setup': True}

    check_collect_facts('all', 'all')
    check_collect_facts(['all'], 'all')
    check_collect_facts(['min'], 'min')
    check_collect_facts(['!all'], '!all')
    check_collect_facts(['!min'], '!min')
    check_collect_facts('network', 'network')

# Generated at 2022-06-11 02:03:16.411316
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    # Empty collectors list
    collector_obj = CollectorMetaDataCollector(collectors=None, namespace=None)
    meta_facts = collector_obj.collect()
    assert meta_facts == {'gather_subset': None}

    # Empty subset list
    collector_obj = CollectorMetaDataCollector(collectors=None, namespace=None, gather_subset=None)
    meta_facts = collector_obj.collect()
    assert meta_facts == {'gather_subset': None}

    # subset list with a single item
    collector_obj = CollectorMetaDataCollector(collectors=None, namespace=None, gather_subset=['all'])
    meta_facts = collector_obj.collect()
    assert meta_facts == {'gather_subset': ['all']}


# Generated at 2022-06-11 02:03:22.957740
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    collectors = None
    namespace = None
    gather_subset=['all']
    module_setup=True
    CollectorMetaDataCollector_collect = CollectorMetaDataCollector(collectors=collectors,
                                               namespace=namespace,
                                               gather_subset=gather_subset,
                                               module_setup=module_setup)
    actual = CollectorMetaDataCollector_collect.collect()
    expected = {'gather_subset': ['all'], 'module_setup': True}
    assert expected == actual



# Generated at 2022-06-11 02:03:35.075051
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    test_gather_subset = ['l2', 'l3']
    test_module_setup = False
    test_object = CollectorMetaDataCollector(gather_subset=test_gather_subset,
                                             module_setup=test_module_setup)
    result = test_object.collect()
    expected = {'gather_subset': test_gather_subset}
    assert result == expected
    test_module_setup = True
    test_object = CollectorMetaDataCollector(gather_subset=test_gather_subset,
                                             module_setup=test_module_setup)
    result = test_object.collect()
    expected = {'gather_subset': test_gather_subset, 'module_setup': test_module_setup}
    assert result == expected

# Generated at 2022-06-11 02:03:48.846122
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Import here instead of the top of the file to prevent the module from
    # loading all the FactsCollector classes when it is imported, and delay that
    # until we need it.
    from ansible.module_utils.facts import collector

    collector_classes = \
        sorted(collector.ALL_COLLECTOR_CLASSES, key=lambda c: c.name)
    collectors = collector.Collector.get_collectors(collector_classes)
    assert len(collectors) == len(collector_classes)

    collector_classes = \
        sorted(collector.ALL_COLLECTOR_CLASSES, key=lambda c: c.name)
    collectors = \
        collector.Collector.get_collectors(collector_classes,
                                           filter_spec=['*'])

# Generated at 2022-06-11 02:04:01.250852
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import virtual

    all_collector_classes = [
        cache.CacheFactCollector,
        hardware.HardwareFactCollector,
        network.NetworkCollector,
        virtual.VirtualCollector,
    ]

    collector_obj = get_ansible_collector(all_collector_classes,
                                          minimal_gather_subset=['!all'],
                                          filter_spec='*')

    collected_facts = collector_obj.collect()

    assert 'ansible_facts' in collected_facts
    assert 'ansible_gather_subset' in collected_facts['ansible_facts']

# Generated at 2022-06-11 02:04:06.717370
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import ansible_collector

    # mock up versions of the collect() methods from the various collectors
    class MockCollector():
        def __init__(self, name):
            self.name = name
        def collect(self, module=None, collected_facts=None):
            return {self.name: self.name}

    # make a few collectors with names of the form "collector_<n>"
    collectors = \
        [MockCollector('collector_%d' % i) for i in range(0, 5)]

    fact_collector = \
        AnsibleFactCollector(collectors=collectors,
                             filter_spec=None)

    # run the collect() method
    res = fact_collector.collect()

    # check that collectors were run as we expect

# Generated at 2022-06-11 02:04:16.609359
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()
    assert facts == {}, 'collector without collectors should return empty facts'

    test_facts = {'a': 'b', 'c': {'d': 'e'}}

    class FakeCollector(collector.BaseFactCollector):
        # fake collector that returns fixed facts
        def collect(self, module=None, collected_facts=None):
            return test_facts

    # fake collector that returns fixed facts
    fact_collector = AnsibleFactCollector(collectors=[FakeCollector()])
    facts = fact_collector.collect()
    assert facts == test_facts, 'collector should return test facts'

    # add a namespace
    fact_

# Generated at 2022-06-11 02:04:27.047980
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """Test the AnsibleFactCollector.collect method."""
    def test_collector_class(fact_namespace):
        """Create a test instance of a fact collector."""
        class Collector(collector.BaseFactCollector):
            """Minimal test fact collector class."""
            def __init__(self, **kwargs):
                """Create a new instance."""
                super(Collector, self).__init__(**kwargs)

            def collect(self, collected_facts=None, **kwargs):
                """Get collected facts."""
                return {"foo": "bar"}

        return Collector(namespace=fact_namespace)

    # The fact namespace is not provided
    fact_collector = \
        AnsibleFactCollector(collectors=[test_collector_class(None)])

# Generated at 2022-06-11 02:04:39.422572
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # the following works on Ubuntu 14.04
    all_collector_classes = \
        collector.collector_fact_classes_from_module('ansible.module_utils.facts')

    result = get_ansible_collector(all_collector_classes=all_collector_classes)

    result_set = set(result.collectors)

    # all_collector_classes has a bunch of collectors, be nice to others
    # and not assert on all of them.

# Generated at 2022-06-11 02:04:50.260427
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class TestCollector(collector.BaseFactCollector):
        ''' Test Collector class. Returns a dict of facts'''
        def collect(self, module=None, collected_facts=None):
            test_facts = {'test1': 'test1_value', 'test2': 'test2_value'}
            return test_facts

    test_collector = TestCollector()
    fact_collector = AnsibleFactCollector(collectors=[test_collector])
    ansible_facts = fact_collector.collect()
    assert ansible_facts['test1'] == 'test1_value'
    assert ansible_facts['test2'] == 'test2_value'


# Generated at 2022-06-11 02:04:56.580252
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    fact_collector = \
        get_ansible_collector(all_collector_classes=None,
                              minimal_gather_subset=frozenset(['all']),
                              gather_subset=['!custom'])
    # Not implemented in AnsibleFactsCollector
    # collect_with_namespace()
    facts = fact_collector.collect(collected_facts={})

    assert facts == {'ansible_facts':{'gather_subset': ['!custom'],'module_setup': True}}

# Generated at 2022-06-11 02:05:05.438816
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.hardware import HardwareCollector

    with_ansible_namespace = AnsibleFactCollector([
        HardwareCollector(namespace=namespace.PrefixFactNamespace(prefix='ansible_'))
    ], namespace=namespace.PrefixFactNamespace(prefix='ansible_'))

    with_ansible_namespace.populate()
    assert with_ansible_namespace.collect() == {'ansible_machine': 'x86_64'}


# Generated at 2022-06-11 02:05:16.563830
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.plugins.ansible.all import (AllFactCollector,
                                                                ModuleSetupFactCollector)
    from ansible.module_utils.facts.plugins.ansible.setup import SetupFactCollector
    from ansible.module_utils.facts.plugins.system.distribution import DistributionFactCollector

    # The following constructor is equivalent to the one in setup_collection_base.py

# Generated at 2022-06-11 02:05:27.881577
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts
    import ansible.module_utils.facts.composite_facts

    # CompositeCollector sets ansible_facts.composite_facts as a subset of
    # ansible facts, so if we cut off collecting all facts, then we won't have composite_facts as
    # well. By default, we collect all facts
    all_collector_classes = ansible.module_utils.facts.composite_facts.ALL_COLLECTOR_CLASSES
    namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace()

    fact_collector = \
        AnsibleFactCollector(collectors=None,
                             namespace=namespace,
                             filter_spec=None)


# Generated at 2022-06-11 02:05:40.486610
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # This is a basic smoke test to ensure we can run get_ansible_collector and
    # we get back expected results
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import namespace


# Generated at 2022-06-11 02:05:50.226120
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.core
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.system.linux


# Generated at 2022-06-11 02:06:01.192391
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.fact_cache import get_fact_cache_style_collector
    from ansible.module_utils.facts.network import get_network_collector
    from ansible.module_utils.facts.system import get_system_collector
    from ansible.module_utils.facts.virtual import get_virtual_collector
    from ansible.module_utils.facts.processor import get_processor_collector
    from ansible.module_utils.facts.pkg_mgr import get_pkg_mgr_collector
    from ansible.module_utils.facts.user import get_user_collector
    from ansible.module_utils.facts.service import get_service_collector
    from ansible.module_utils.facts.mount import get_mount_collector

# Generated at 2022-06-11 02:06:12.142696
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    def my_collector(module=None, collected_facts=None):
        return {"a":1, "b":"2", "c":True, "d":False, "e":[0,1,2], "f":(0,1,2), "g":{0:0, 1:1, 2:2}, "h":None}

    from ansible.module_utils.facts import ansible_collector

    fact_collector = AnsibleFactCollector(collectors=[my_collector], namespace=ansible_collector)
    result_dict = fact_collector.collect()

    assert result_dict['a'] == 1
    assert result_dict['b'] == "2"
    assert result_dict['c'] == True
    assert result_dict['d'] == False

# Generated at 2022-06-11 02:06:23.848036
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class Collector_1(collector.BaseFactCollector):
        name = 'collector_1'
        _fact_ids = ['a', 'b']

        def collect(self, module=None, collected_facts=None):
            return {'a': 1, 'b': 2}

    class Collector_2(collector.BaseFactCollector):
        name = 'collector_2'
        _fact_ids = ['d', 'c']

        def collect(self, module=None, collected_facts=None):
            return {'d': 3, 'c': 4}

    class Collector_3(collector.BaseFactCollector):
        name = 'collector_3'
        _fact_ids = ['a', 'e']


# Generated at 2022-06-11 02:06:31.617642
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class CollectingFactCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': True}

    class CollectingFactCollector2(collector.BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact': True}

    # test glob
    fact_collector = \
        AnsibleFactCollector(collectors=[CollectingFactCollector(),
                                         CollectingFactCollector2()],
                             filter_spec=['test*'])

    facts = fact_collector.collect()
    # facts = {'test_fact': True, 'test2_fact': True}

# Generated at 2022-06-11 02:06:43.243700
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import virtualization
    from ansible.module_utils.facts import networking

    all_collector_classes = [cache.CacheFactCollector,
                             hardware.HardwareCollector,
                             virtualization.VirtualizationCollector,
                             networking.NetworkingCollector]

    # test with empty params
    filer_spec = []
    gather_subset = []
    gather_timeout = None
    minimal_gather_subset = frozenset()

# Generated at 2022-06-11 02:06:54.123320
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Test FactCollector with a list of collectors.'''
    import ansible.module_utils.facts.system
    from ansible.module_utils.facts.system import Distribution
    from ansible.module_utils.facts.system import Hardware
    from ansible.module_utils.facts.system import Platform

    # Trivial usage of get_ansible_collector()
    fact_collector = get_ansible_collector(all_collector_classes=[Distribution, Hardware, Platform],
                                           gather_subset=['all'])
    assert isinstance(fact_collector, AnsibleFactCollector)
    collected_facts = fact_collector.collect()
    assert 'ansible_facts' in collected_facts
    assert 'module_setup' in collected_facts['ansible_facts']

    # When 'gather_

# Generated at 2022-06-11 02:06:59.991632
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes = [
        collector.AllSubsetCollector,
        collector.HardwareSubsetCollector,
        collector.NetworkSubsetCollector,
        collector.LocalSubsetCollector,
        collector.VirtualSubsetCollector,
        collector.InterfacesCollector
    ]

    result = get_ansible_collector(all_collector_classes=collector_classes,
                                   gather_subset=['virtual', 'network'],
                                   filter_spec='*bsd')

    assert result
    assert result.collectors
    assert len(result.collectors)

# Generated at 2022-06-11 02:07:21.101014
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''If we use the collector to gather facts,
    it should provide a dictionary of facts with the keys being the fact names.'''
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    network_facts = NetworkCollector()
    system_facts = SystemCollector()
    virtual_facts = VirtualCollector()
    collectors = [network_facts, system_facts, virtual_facts]
    fact_collector = AnsibleFactCollector(collectors=collectors)
    facts = fact_collector.collect()
    assert is_string(facts['ansible_all_ipv4_addresses'])

# Generated at 2022-06-11 02:07:30.541993
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # create 3 collectors
    foo_collector = TestCollector(name='foo', get_all_facts=dict(fact1='a', fact2='b'))
    bar_collector = TestCollector(name='bar', get_all_facts=dict(fact3='c', fact4='d'))
    baz_collector = TestCollector(name='baz', get_all_facts=dict(fact5='e', fact6='f'))
    # create an AnsibleFactCollector
    fact_collector =  AnsibleFactCollector(collectors=[foo_collector, bar_collector, baz_collector])
    # collect facts
    facts = fact_collector.collect()
    # check facts

# Generated at 2022-06-11 02:07:41.166529
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class MyFactsCollector1(collector.BaseFactCollector):

        name = 'fact_collector1'
        _fact_ids = set(['a', 'b'])

        def collect(self, module=None, collected_facts=None):
            return {'a': 1, 'b': 2}

    class MyFactsCollector2(collector.BaseFactCollector):

        name = 'fact_collector2'
        _fact_ids = set(['c', 'd'])

        def collect(self, module=None, collected_facts=None):
            return {'c': 3, 'd': 4}

    class MyFactsCollector3(collector.BaseFactCollector):

        name = 'fact_collector3'
        _fact_ids = set(['e', 'f'])


# Generated at 2022-06-11 02:07:51.731869
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    collector_a = collector.BaseFactCollector(namespace='a')
    collector_b = collector.BaseFactCollector(namespace='b')
    collector_c = collector.BaseFactCollector(namespace='c')
    collector_d = collector.BaseFactCollector(namespace='d')
    collector_e = collector.BaseFactCollector(namespace='e')

    # collector_a.collect() => {'a': True}
    # collector_b.collect() => {'b': True}
    # collector_c.collect() => {'c': True}
    # collector_d.collect() => {'d': True}
    # collector_e.collect() => {'e': True}

    fact_collector_a = AnsibleFactCollector(collectors=[collector_a])
    fact_collector_

# Generated at 2022-06-11 02:07:58.476616
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.processor
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network

    all_collector_classes = [
        ansible.module_utils.facts.processor.ProcessorFactCollector,
        ansible.module_utils.facts.system.SystemFactCollector,
        ansible.module_utils.facts.network.NetworkFactCollector
    ]

    fact_collector = get_ansible_collector(all_collector_classes)
    collected_facts = fact_collector.collect()

    assert collected_facts is not None
    for k, v in collected_facts.items():
        # print(str(k) + " : " + str(v))
        pass

    assert collected_facts['ansible_facts']['all']

# Generated at 2022-06-11 02:08:10.371690
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [
        'test_collector_classes.CollectorA',
        'test_collector_classes.CollectorB',
        'test_collector_classes.CollectorC',
    ]
    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace='ansible.facts',
                                           gather_subset=['all'],
                                           gather_timeout=60,
                                           minimal_gather_subset=frozenset(['all']),
                                           )

    received_facts_dict = fact_collector.collect()


# Generated at 2022-06-11 02:08:19.035280
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.virtual import VirtualFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector

    all_collector_classes = [VirtualFactCollector, SystemFactCollector]
    fact_collector = get_ansible_collector(all_collector_classes,
                                           gather_subset='!all',
                                           minimal_gather_subset='!all')

    # function get_ansible_collector should have added the '!all' gather_subset
    # to the all_collector classes.
    assert(fact_collector.collectors[0].name == '!all')
    assert(fact_collector.collectors[1].name == 'system')

# Generated at 2022-06-11 02:08:28.415371
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_facts

    namespace_colon = namespace.NamespacePrefixFactNamespace()
    namespace_dot = namespace.DotDictFactNamespace()
    namespace_colon.add_prefix('test_prefix_')
    namespace_dot.add_prefix('test_prefix_')

    collectors = []
    collectors.append(ansible_facts.DistributionFactCollector(namespace=namespace_colon))
    collectors.append(ansible_facts.OSFactCollector(namespace=namespace_dot))
    ans_fc = AnsibleFactCollector(collectors)
    ans_fc.collect()

# Generated at 2022-06-11 02:08:29.034207
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-11 02:08:40.435488
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    assert get_ansible_collector(all_collector_classes=[collector.BaseFactCollector],
                                 namespace=None,
                                 filter_spec=None,
                                 gather_subset=None,
                                 gather_timeout=None,
                                 minimal_gather_subset=None) is not None
    assert get_ansible_collector(all_collector_classes=[collector.BaseFactCollector],
                                 namespace=namespace,
                                 filter_spec=None,
                                 gather_subset='all',
                                 gather_timeout=10,
                                 minimal_gather_subset=None) is not None

# Generated at 2022-06-11 02:08:56.723138
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    """Test correct type and contents of a cached fact dictionary.

    :return:
    """

    # Collection of testdata
    test_collector_data = [{'facter': {'system_uptime': {'seconds': 1064874}},
                            'ohai': {'network': {'interfaces': {'eth0': {'ipaddress': '10.20.30.40'}}}}},
                           {'ansible_test_test1': 'test_test1',
                            'ansible_test_test2': 'test_test2'},
                           {'ansible_test_test1': 'test_test1_collector_3',
                            'ansible_test_test2': 'test_test2_collector_3'}]


# Generated at 2022-06-11 02:09:05.996464
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # collect all facts
    filter_spec = [name for name in _FactsCollectorMeta._fact_id_to_collector_class]
    # gather_timeout of 600 seconds and timeout of 1 second for each fact
    gather_timeout = 600
    timeout = 1
    # gather all facts
    gather_subset = ['all']
    minimal_gather_subset = []
    # create the collector
    collector = get_ansible_collector(timeout=timeout,
                                      filter_spec=filter_spec,
                                      namespace=True,
                                      gather_timeout=gather_timeout,
                                      gather_subset=gather_subset,
                                      minimal_gather_subset=minimal_gather_subset)
    # test facts collection
    facts = collector.collect()

# Generated at 2022-06-11 02:09:16.609876
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector

    all_collector_classes = ansible.module_utils.facts.collector.get_collector_classes()
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              filter_spec=['ansible_*'],
                              gather_subset=['all']
                              )
    results = fact_collector.collect()

    # check for ansible specific metadata
    assert results.get('gather_subset') == ['all']
    assert results.get('module_setup') is True
    # check for collected facts
    assert results.get('ansible_facts')

    # Check that the gather_subset=['all'] implies minimal_gather_subset=['all']
   

# Generated at 2022-06-11 02:09:27.281629
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.base
    class fake_base_collector:
        """fake class to test base_collector.collect method"""
        def __init__(self, namespace=None):
            self.namespace = namespace

        def collect(self, module=None, collected_facts=None):
            return {'fakekey': 'fakevalue'}

    fact_collector1 = fake_base_collector()
    expected_result = {'ansible_facts': {'fakekey': 'fakevalue'}}

    # Testing without namespace
    fact_collector_obj = AnsibleFactCollector(collectors=[fact_collector1])
    assert fact_collector_obj.collect() == expected_result

    # Testing with namespace
    ns = ansible.module_utils.facts.namespace.Prefix

# Generated at 2022-06-11 02:09:34.109847
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace

    class MockCollector(collector.BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            info_dict = {}
            info_dict['mock_fact1'] = 'mock_value1'

            return info_dict

    class MockCollector2(collector.BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            info_dict = {}
            info_dict['mock_fact2'] = 'mock_value2'

            return info_dict

    mock_collector = MockCollector()

# Generated at 2022-06-11 02:09:45.695799
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create mock collectors
    mock_collector_one = collector.BaseFactCollector()
    mock_collector_one.name = "mock_collector_one"
    mock_collector_one.collect_with_namespace = \
        lambda module=None, collected_facts=None: {'mock_key_one': 'mock_value_one'}

    mock_collector_two = collector.BaseFactCollector()
    mock_collector_two.name = "mock_collector_two"
    mock_collector_two.collect_with_namespace = \
        lambda module=None, collected_facts=None: {'mock_key_two': 'mock_value_two'}

    # Test no filter spec
    fact_collector_no_filter_spec \
        = AnsibleFact

# Generated at 2022-06-11 02:09:49.084822
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    facts_dict = fact_collector.collect()
    assert facts_dict == {}

    # FIXME: test me better

# Generated at 2022-06-11 02:09:57.817600
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import namespaced_fact
    from ansible.module_utils.facts import namespace

    all_collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=collector.all_collectors,
            gather_subset=[],
            gather_timeout=timeout.DEFAULT_GATHER_TIMEOUT)

    # simulate a module run with the minimal gather subset
    minimal_gather_subset = frozenset(['!all', '!any'])


# Generated at 2022-06-11 02:10:07.534780
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    class A(collector.BaseFactCollector):
        _fact_ids = set(['a'])

    class B(collector.BaseFactCollector):
        _fact_ids = set(['b'])

    class C(collector.BaseFactCollector):
        _fact_ids = set(['c'])

    fact_collector = get_ansible_collector(all_collector_classes=[B, C, A],
                                           gather_subset=['all'],
                                           filter_spec='a')

    facts = fact_collector.collect(collected_facts={'f': 'facts'})

    assert 'gather_subset' in facts
    assert facts['gather_subset'] == ['all']
    assert len(facts) == 2



# Generated at 2022-06-11 02:10:13.179502
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.base as base
    BaseFactCollector = base.BaseFactCollector
    from ansible.module_utils.facts import namespace

    class DummyCollector(BaseFactCollector):
        name = 'dummy'

        def collect(self):
            return {'dummy': 123}

    assert DummyCollector.name in base.all_collector_classes
    assert DummyCollector.name in base.minimal_collector_classes


# Generated at 2022-06-11 02:10:35.058325
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts import namespaces
    filter_spec = ['fact1', '!fact2', 'ansible_fact3']
    gather_subset = ['all']
    gather_timeout = 10
    minimal_gather_subset = []

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           namespace=namespaces.PrefixFactNamespace(prefix='ansible_'),
                                           filter_spec=filter_spec,
                                           gather_subset=gather_subset,
                                           gather_timeout=gather_timeout,
                                           minimal_gather_subset=minimal_gather_subset)

    assert fact

# Generated at 2022-06-11 02:10:44.278291
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class FakeCollector(collector.BaseFactCollector):
        name = 'fake_fact_collector'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return dict(fact_one='foo', fact_two='bar')

    class FakeCollectorWithNamespace(collector.BaseFactCollector):
        name = 'fake_fact_collector_with_namespace'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return dict(fact_one='foo', fact_two='bar')

    c = AnsibleFactCollector()

    result = c.collect()
    assert len(result) == 0

    c = AnsibleFactCollector(collectors=[FakeCollector()])

    # test collect

# Generated at 2022-06-11 02:10:48.995209
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ansible_collector

    fact_collector = get_ansible_collector(all_collector_classes=ansible_collector.collector_classes)
    print (fact_collector.collect())


if __name__ == '__main__':
    test_get_ansible_collector()

# Generated at 2022-06-11 02:10:52.505617
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    all_collector_classes = ansible.module_utils.facts.collector.__all__
    fact_collector = get_ansible_collector(all_collector_classes)
    return fact_collector.get_fact_list()

# Generated at 2022-06-11 02:11:00.116731
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [
        collector.BaseFactCollector,
        collector.FacterFactCollector,
        collector.OhaiFactCollector]

    namespace = collector.PrefixFactNamespace(prefix='ansible_')

    fact_collector = get_ansible_collector(all_collector_classes,
                                           namespace=namespace,
                                           filter_spec=None,
                                           gather_subset=['all'],
                                           gather_timeout=10,
                                           minimal_gather_subset=frozenset())

    print(fact_collector)

# Generated at 2022-06-11 02:11:09.191987
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import namespaced_fact_collectors

    namespace = 'namespace'
    filter_spec = ['filter_spec']
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    ansible_collector = \
        get_ansible_collector(namespaced_fact_collectors,
                              namespace=namespace,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)

    assert isinstance(ansible_collector, AnsibleFactCollector)

# Generated at 2022-06-11 02:11:17.914533
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # Make sure filter_spec is optional
    fact_collector = get_ansible_collector(all_collector_classes=[collector.FacterCollector],
                                           filter_spec=None)

    # Make sure gather_subset is optional
    fact_collector = get_ansible_collector(all_collector_classes=[collector.FacterCollector],
                                           gather_subset=None)

    # Make sure gather_subset can be a list
    fact_collector = get_ansible_collector(all_collector_classes=[collector.FacterCollector],
                                           gather_subset=[collector.FacterCollector.name])

    # Make sure gather_subset can be a string