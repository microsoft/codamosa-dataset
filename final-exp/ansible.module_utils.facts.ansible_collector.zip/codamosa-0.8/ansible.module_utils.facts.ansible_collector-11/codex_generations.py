

# Generated at 2022-06-11 02:01:28.483067
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockCollector(collector.BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['foo', 'bar', 'baz'])

        def collect(self, module=None, collected_facts=None):
            return {'foo': 'foo_value',
                    'bar': 'bar_value',
                    'baz': 'baz_value'}

    class MockCollector2(collector.BaseFactCollector):
        name = 'mock2'
        _fact_ids = set(['qux', 'quux'])

        def collect(self, module=None, collected_facts=None):
            return {'qux': 'qux_value',
                    'quux': 'quux_value'}


# Generated at 2022-06-11 02:01:37.102445
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Mock all_collector_classes to get some results
    import ansible.module_utils.facts.collector.memory
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.all
    all_collector_classes_mock = [ansible.module_utils.facts.collector.memory.Memory,
                                  ansible.module_utils.facts.collector.network.Network,
                                  ansible.module_utils.facts.collector.hardware.Hardware,
                                  ansible.module_utils.facts.collector.all.All]


    # Test default case

# Generated at 2022-06-11 02:01:43.158419
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class Fake_Namespace():
        def with_prefix(self, fact):
            return fact

    class Fake_Collector():
        def collect(self, module=None, collected_facts=None):
            return {'first_fact': 1}

    fact_collector = AnsibleFactCollector(collectors=[Fake_Collector()], namespace=Fake_Namespace())
    result = fact_collector.collect()
    assert result['first_fact'] == 1



# Generated at 2022-06-11 02:01:55.185398
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # setting up a mock ansible_facts result
    ansible_facts_result_dict = {'ansible_os_family': 'OpenBSD', 'ansible_distribution': 'Archlinux'}
    ansible_facts_result_dict['_ansible_no_log'] = False

# Generated at 2022-06-11 02:01:57.878135
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''
    Unit test for method collect of class AnsibleFactCollector
    '''
    collect_obj = AnsibleFactCollector()
    assert collect_obj.collect() == {}

# Generated at 2022-06-11 02:02:05.129958
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Setup a mock module
    collect_mock = lambda *a, **kw: {'mock': 'dict'}
    module_mock = lambda *a, **kw: None
    module_mock.exit_json = lambda *a, **kw: None
    module_mock.fail_json = lambda *a, **kw: None

    test_case = AnsibleFactCollector(
        collectors=[collector.BaseFactCollector(collect=collect_mock)])

    facts = test_case.collect(module=module_mock)

    assert 'ansible_facts' in facts
    assert facts['ansible_facts'] == {'mock': 'dict'}

# Generated at 2022-06-11 02:02:15.191105
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    FAKE_FACTS = {'fact1': 'value1',
                  'fact2': 'value2',
                  'fact3': 'value3',
                  'fact4': 'value4'}

    class FakeFactCollector(collector.BaseFactCollector):
        name = 'fake'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return FAKE_FACTS

    collectors = [FakeFactCollector(), FakeFactCollector()]
    fact_collector = \
        AnsibleFactCollector(collectors=collectors)

    # no filter-spec
    facts_dict = fact_collector.collect()
    assert (facts_dict == FAKE_FACTS)

    # filter-spec: '*'
    facts_dict = fact_collect

# Generated at 2022-06-11 02:02:26.137721
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.ansible_collector
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.ohai

    all_collector_classes = \
        [ansible.module_utils.facts.ansible_collector.AnsibleFactCollector,
         ansible.module_utils.facts.collectors.facter.FacterCollector,
         ansible.module_utils.facts.collectors.network.NetworkCollector,
         ansible.module_utils.facts.collectors.ohai.OhaiCollector,
         ]


# Generated at 2022-06-11 02:02:38.486506
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import time
    import copy
    from ansible.module_utils.facts import ansible_collector

    class FakeCollector(collector.BaseFactCollector):

        name = 'fake_collector'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            t = time.time()
            collected_facts['fake_fact_%s' % t] = 'fake_fact_value_%s' % t
            return collected_facts

    import ansible.module_utils.facts.namespace as fact_namespace

    with_namespace = fact_namespace.PrefixFactNamespace(prefix='fake_')
    no_namespace = fact_namespace.FactNamespace()

# Generated at 2022-06-11 02:02:39.943212
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for method _AnsibleFactCollector_collect'''
    pass

# Generated at 2022-06-11 02:02:57.153034
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Setup
    class FactCollectorA(collector.BaseFactCollector):
        name = 'a'

        def collect(self, module=None, collected_facts=None):
            return {self.name: 'test_a'}

    class FactCollectorB(collector.BaseFactCollector):
        name = 'b'

        def collect(self, module=None, collected_facts=None):
            return {self.name: 'test_b'}

    fact_collector_a = FactCollectorA()
    fact_collector_b = FactCollectorB()
    fact_collector = AnsibleFactCollector(collectors=[fact_collector_a, fact_collector_b])

    # Test
    collected_facts = fact_collector.collect()

    # Verify

# Generated at 2022-06-11 02:03:07.650827
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Init params for AnsibleFactCollector
    namespace = None
    filter_spec = None

    # Init params for BaseFactCollector
    collectors = []
    namespace = None

    # Init params for BaseCollector
    self = None
    namespace = None

    # Init params for CollectorMetaDataCollector
    namespace = None
    collectors = []
    gather_subset = ['all']
    module_setup = None

    # Init params for CollectMetaDataCollector
    self = None
    namespace = None
    gather_subset = ['all']
    module_setup = None

    fact_collector = AnsibleFactCollector(collectors=collectors,
                                          namespace=namespace)


# Generated at 2022-06-11 02:03:16.600858
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Test collect() method.'''

    class FakeCollector(object):
        '''Fake class to fake collect() method of AnsibleBaseFactCollector.'''

        _fact_id = 'a'

        def collect(self, module=None, collected_facts=None):
            return {'a': '1'}

    fake_collector = None
    try:
        fake_collector = FakeCollector()

        fact_collector = AnsibleFactCollector(collectors=[fake_collector])

        actual_facts = fact_collector.collect()

        expected_facts = {
            'a': '1',
        }
        assert actual_facts == expected_facts
    finally:
        if fake_collector:
            del fake_collector


# Generated at 2022-06-11 02:03:23.741402
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FakeCollector(object):

        def __init__(self, namespace=None):
            self.namespace = namespace

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'fake_fact': 'fake_value'}

    fake_collector = FakeCollector()
    fact_collector = AnsibleFactCollector(collectors=[fake_collector],
                                          filter_spec=['fake*'],
                                          namespace=None)
    facts = fact_collector.collect()
    assert facts == {'fake_fact': 'fake_value'}

# Generated at 2022-06-11 02:03:35.484259
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # If a namespace if provided, facts will be collected under that namespace.
    # For example, a ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')

    # Two collectors, both return some facts
    collector1 = FakeCollector(fact_list=['a', 'b'])
    collector2 = FakeCollector(fact_list=['c', 'd'])
    fact_collector = AnsibleFactCollector(collectors=[collector1, collector2],
                                          filter_spec=['*'])

    facts_dict = fact_collector.collect()
    assert facts_dict == {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}

    # Two collectors, the second is empty

# Generated at 2022-06-11 02:03:46.631435
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''this tests the basics for getting a full ansible_facts dict.  testing of the collectors that
    go into it and the namespace are tested elsewhere.  If you have a new collector, and have fully
    tested it, you can create a minimal test for it here.'''

    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    x_collector = collector.BaseFactCollector(namespace=PrefixFactNamespace(prefix='x_'))
    y_collector = collector.BaseFactCollector(namespace=PrefixFactNamespace(prefix='y_'))

    x_collector.collect = lambda module=None, collected_facts=None: {'x_foo': 'x_bar'}

# Generated at 2022-06-11 02:03:58.905545
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    filter_spec = ['!ansible_architecture', 'ansible_fqdn']

    # Need to be in a test collector
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = {'test_fact'}

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'hi'}

    # Need to be in a test collector
    class Test2Collector(collector.BaseFactCollector):
        name = 'test2'
        _fact_ids = {'test2_fact'}

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact': 'hi2'}

    collector_classes = [TestCollector, Test2Collector]

    # Test

# Generated at 2022-06-11 02:04:08.438213
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespacePrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Tests a single collector that returns all facts
    # with no namespace, and no filter_spec
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _fact_ids = set([])

        def __init__(self, namespace=None):
            super(TestCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'fact1': 'foo', 'fact2': 'bar'}

    test_collector = TestCollector()
    fact_

# Generated at 2022-06-11 02:04:17.508268
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform

    collector_classes = [ansible.module_utils.facts.system.distribution.DistributionFactCollector,
                         ansible.module_utils.facts.system.platform.PlatformFactCollector]

    # Create fact collectors
    fact_collector = \
        AnsibleFactCollector(collectors=collector_classes,
                             filter_spec=['*_fact'])


    # Generate some facts
    facts = fact_collector.collect(collected_facts={})

    print(facts)


# Generated at 2022-06-11 02:04:27.436564
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''Test get_ansible_collector().'''

    # pylint: disable=import-error
    from ansible.module_utils.facts import test_collector

    collector_classes = [
        test_collector.TestCollector,
        test_collector.TestCollectorWithNamespace,
        test_collector.TestCollectorWithTimeout,
    ]
    fact_collector = get_ansible_collector(all_collector_classes=collector_classes,
                                           gather_subset=['!all', 'network'],
                                           minimal_gather_subset=('!all',),
                                           namespace=test_collector.TestNamespace())

    facts = fact_collector.collect()

# Generated at 2022-06-11 02:04:44.833747
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        collector.all_collector_classes()
    namespace = collector.Namespace()
    filter_spec = frozenset()
    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    fact_collector = \
        get_ansible_collector(all_collector_classes,
                              namespace=namespace,
                              filter_spec=filter_spec,
                              gather_subset=gather_subset,
                              gather_timeout=gather_timeout,
                              minimal_gather_subset=minimal_gather_subset)

    assert(isinstance(fact_collector,
                      AnsibleFactCollector))


# Generated at 2022-06-11 02:04:55.726444
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Note: this unit test tests directly by mocking rather than testing indirectly
    # through test_runner
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import fact
    from ansible.module_utils.facts import network

    class CustomCollector(collector.BaseFactCollector):
        _fact_ids = set([
            'fact1',
            'fact2'
        ])
        _platform = 'all'

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'fact1': 'value1',
                    'fact2': 'value2'}

    my_collector = AnsibleFactCollector(
        collectors=[CustomCollector()],
        namespace=namespace.PrefixFactNamespace(prefix='ansible_')
    )
   

# Generated at 2022-06-11 02:05:05.284399
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # test that the collector_class we get back is the one passed in
    # based on the gather_subset spec
    # Also test that the filter_spec is passed through to the collector
    import ansible.module_utils.facts.collector.network

    ftr = get_ansible_collector(all_collector_classes=[ansible.module_utils.facts.collector.network.NetworkCollector],
                                gather_subset=['network'],
                                filter_spec=['*interfaces'])
    assert ftr._collectors[0].__class__ == ansible.module_utils.facts.collector.network.NetworkCollector



# Generated at 2022-06-11 02:05:14.709583
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Create a mock module that returns a dictionary that is the same as a real fact dictionary
    fact_dict = {'a': 'example'}
    module = MockModule(fact_dict)

    # Create a mock collector object that will return the fact dictionary created.
    collector_mock = MockCollector(fact_dict)

    # Create a fact collector object with mock collector and mock module.
    fact_collector = AnsibleFactCollector([collector_mock])

    # Execute the method to test.
    result = fact_collector.collect(module)

    # Assert that the method returns the same as the mock collector returns.
    assert result == fact_dict


# Generated at 2022-06-11 02:05:24.449532
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.facts.collector import all_collector_classes
    from ansible.module_utils.facts import ansible_collector

    expected_collectors = \
        ['test_test',
         'minimal_test',
         'minimal_test',
         'minimal_test',
         'minimal_test',
         'minimal_test',
         'minimal_test',
         'minimal_test',
         'minimal_test',
         'minimal_test',
         'gather_subset']


# Generated at 2022-06-11 02:05:36.467716
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import datetime
    import time
    import unittest

    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector.test_collectors import FailingTestCollector
    from ansible.module_utils.facts.collector.test_collectors import PassThruCollector
    from ansible.module_utils.facts.namespace import add_namespace, PrefixFactNamespace
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    class FailingTestCollectorCollectError(FailingTestCollector):
        def collect(self, module=None, collected_facts=None):
            raise Exception("Collect error")


# Generated at 2022-06-11 02:05:47.904942
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import json
    import tempfile

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.network.interfaces as network_interfaces
    import ansible.module_utils.facts.system.distribution as system_distribution
    import ansible.module_utils.facts.system.mount as system_mount
    import ansible.module_utils.facts.system.platform as system_platform
    import ansible.module_utils.facts.system.pkg_mgr as system_pkg_mgr
    import ansible.module_utils.facts.system.users as system_users

    network_interfaces_obj = network_interfaces.NetworkInterfaces()
    system_distribution_obj = system_distribution.DistributionFactCollector()
    system_mount_obj = system

# Generated at 2022-06-11 02:05:58.924568
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    _all_collector_classes = ['a']
    _namespace = 'b'
    _filter_spec = 'c'
    _gather_subset = 'd'
    _gather_timeout = 'e'
    _minimal_gather_subset = 'f'
    _ns = 'g'

    def mock_collector_classes_from_gather_subset(all_collector_classes,
                                                  minimal_gather_subset,
                                                  gather_subset,
                                                  gather_timeout):
        _all_collector_classes[0] = all_collector_classes
        minimal_gather_subset[0] = minimal_gather_subset
        gather_subset[0] = gather_subset
        gather_timeout[0] = gather_timeout
        return

# Generated at 2022-06-11 02:06:08.547551
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Fixture
    fact_collector = \
        AnsibleFactCollector(
            collectors=[
                collector.BaseFactCollector(namespace='ns1.'),
                collector.BaseFactCollector(namespace='ns2.'),
            ],
            namespace='main.'
        )

    import json
    # Act
    result = fact_collector.collect()
    # Assert
    expected_result = {
        'ns1.foo': 42,
        'ns2.bar': 7
    }

    assert result == expected_result, 'expected %s, got %s' % (json.dumps(expected_result), json.dumps(result))


# Generated at 2022-06-11 02:06:12.838046
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    fact_collector = AnsibleFactCollector()
    facts = fact_collector.collect()

    # By now, only meta_data has been collected
    assert set(facts.keys()) == set(['meta_data'])


if __name__ == '__main__':
    test_AnsibleFactCollector_collect()

# Generated at 2022-06-11 02:06:25.401911
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class FakeCollector(collector.BaseFactCollector):
        def collect(self, module, collected_facts):
            return {'fact': 'value'}

    fact_collector = \
        AnsibleFactCollector(collectors=[FakeCollector()],
                             namespace=None)

    facts = fact_collector.collect()
    assert 'fact' in facts
    assert facts['fact'] == 'value'



# Generated at 2022-06-11 02:06:34.556059
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace.network import NetworkNamespace
    from ansible.module_utils.facts.namespace.network.interface import InterfaceFactCollector
    from ansible.module_utils.facts.network.interface import InterfaceFactCollector as IfaceFactCollector
    iface_namespace = NetworkNamespace(name='ansible_',
                                       path='ansible.module_utils.facts.namespace.network.interface')

    all_collectors = [IfaceFactCollector(namespace=None),
                      InterfaceFactCollector(namespace=iface_namespace)]

    ans_fact_collector = AnsibleFactCollector(collectors=all_collectors,
                                              namespace=None)

# Generated at 2022-06-11 02:06:35.184738
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    pass

# Generated at 2022-06-11 02:06:45.306399
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.system import LinuxFactCollector
    from ansible.module_utils.facts.network import NetworkFactCollector

    all_collector_classes = frozenset([NetworkFactCollector, LinuxFactCollector])
    gather_subset = ['all']
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           gather_subset=gather_subset)
    results = fact_collector.collect()
    assert 'ansible_all_ipv4_addresses' in results
    assert 'ansible_facts' in results
    assert 'module_setup' in results

# Generated at 2022-06-11 02:06:55.342243
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''
    test the collect with filter method of AnsibleFactCollector
    '''

    def local():
        """
        Local fact collection
        """
        return {
            'local_fact': 'local_fact_value'
        }

    def remote():
        """
        remote fact collection
        """
        return {
            'remote_fact': 'remote_fact_value'
        }

    all_collectors = {
        'local': local,
        'remote': remote
    }

    filter_specs = ['local_fact', 'remote_fact', 'not_exist_fact']

    # Test the handling of the case when filter_spec is a list of string
    # with one of the string not matching any available fact.

# Generated at 2022-06-11 02:07:05.226660
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes = [
        collector.GenericFactCollector,
        collector.FacterFactCollector,
        collector.OhaiFactCollector
    ]
    all_collector_classes = collector_classes
    minimal_gather_subset = frozenset(['all'])
    gather_subset = 'all,!facter'
    gather_timeout = 10
    filter_spec = ['facter*']

    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           minimal_gather_subset=minimal_gather_subset,
                                           gather_subset=gather_subset,
                                           gather_timeout=gather_timeout,
                                           filter_spec=filter_spec)

    assert fact_collector.collectors

# Generated at 2022-06-11 02:07:16.106775
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = [
        collector.NetworkCollector,
        collector.FacterCollector,
        collector.OhaiCollector,
        collector.LocalCollector
    ]

    gather_subset = ['network', 'facter', 'ohai', 'local']
    gather_timeout = 10
    minimal_gather_subset = frozenset()


    fact_collector = get_ansible_collector(all_collector_classes,
                                           filter_spec=['ansible_all_ipv4_addresses'],
                                           gather_subset=gather_subset,
                                           gather_timeout=gather_timeout,
                                           minimal_gather_subset=minimal_gather_subset)
    ansible_facts = fact_collector.collect()

    # Test

# Generated at 2022-06-11 02:07:26.903394
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    def test_collect(module=None, collected_facts=None):
        """Test collector test that returns {'test_collector': True}"""
        facts_dict = {}
        info_dict = {'test_collector': True}
        facts_dict.update(info_dict)
        return facts_dict

    class TestCollector(collector.BaseFactCollector):
        name = 'test_collector'

        def collect(self, module=None, collected_facts=None):
            return test_collect(module=module, collected_facts=collected_facts)

    test_collector_class = TestCollector

    # all_collector_classes
    all_collector_classes = [test_collector_class]

    # collectors

# Generated at 2022-06-11 02:07:33.647367
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespace

    # Create a mock namespace object. This object will be used to
    # prefix the collector name.
    namespace_obj = namespace.PrefixFactNamespace(prefix='ns1_')

    # Get a fake previous fact called 'ns1_fake_previous_fact'
    previous_fact_dict = {'ns1_fake_previous_fact': 'fake previous fact'}

    # Create a fake collector whose name is 'fake_name'
    fake_collector_name = 'fake_name'
    fake_collector = FakeCollector(fake_collector_name, namespace_obj)

    # Create a AnsibleFactCollector instance using fake_collector.
    # namespace_obj is passed so that it namespaces the output
    # of fake_collector.

# Generated at 2022-06-11 02:07:40.109438
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeCollector(BaseFactCollector):
        pass

    fake_collector = FakeCollector()

    fact_collector = get_ansible_collector(
        all_collector_classes=[FakeCollector],
        gather_subset=['all'])

    assert fact_collector._fact_ids == set()

    assert fact_collector.collectors == [fake_collector, ]

# Generated at 2022-06-11 02:07:56.232449
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    # Use mockcollector so we don't depend on an actual class
    class MockCollector(object):
        def __init__(self, *args, **kwargs):
            pass

    # To test get_ansible_collector we need to provide the 'all_collector_classes'
    # value which would normally come from 'module_utils/facts' namespace modules
    all_collector_classes = {'mock1': MockCollector, 'mock2': MockCollector}
    gather_subset = ['mock1']
    # should return two collectors (gather_subset and mock1)

# Generated at 2022-06-11 02:08:08.071575
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import default

    from ansible.module_utils.facts.namespace import PrefixFactNamespace


# Generated at 2022-06-11 02:08:18.089869
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.cacheable

    # Create a minimal set of collectors
    class A(ansible.module_utils.facts.collector.BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a'])

        def collect(self, module=None, collected_facts=None):
            return {'a': 1}

    class B(ansible.module_utils.facts.collector.BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b'])

        def collect(self, module=None, collected_facts=None):
            return {'b': 2}

    class Collectors(object):
        is_setup

# Generated at 2022-06-11 02:08:28.373705
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    # Test inputs
    module = {}
    collected_facts = {}
    filter_spec = ['*']

    # Test definition of collector objects
    def dummy_collect_with_namespace(self, module, collected_facts):
        self.info_dict = {'info_dict1': 1, 'info_dict2': 2}
        return self.info_dict
    collector_obj1 = collector.BaseFactCollector()
    setattr(collector.BaseFactCollector, 'collect_with_namespace', dummy_collect_with_namespace)
    collector_obj1.name = 'collector_obj1'
    collector_obj2 = collector.BaseFactCollector()
    setattr(collector.BaseFactCollector, 'collect_with_namespace', dummy_collect_with_namespace)

# Generated at 2022-06-11 02:08:39.834548
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import collector_module
    from ansible.module_utils.facts import namespace
    collectors = collector_module.all_collector_classes()

    # Test: minimal_gather_subset
    minimal_gather_subset = frozenset(['minimal'])
    fact_collector = get_ansible_collector(collectors,
                                           gather_subset='all',
                                           minimal_gather_subset=minimal_gather_subset)
    facts = fact_collector.collect()
    assert 'default_ipv4' in facts['ansible_facts']
    assert 'minimal' in facts['ansible_facts']['gather_subset']

    # Test: gather_subset

# Generated at 2022-06-11 02:08:46.666724
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test case with invalid collector_obj
    class FakeCollector(object):
        def collect_with_namespace(self, module=None, collected_facts=None):
            return {}
    collector1 = FakeCollector()
    collector2 = FakeCollector()
    ansible_fact_collector = AnsibleFactCollector([collector1, collector1, collector2])
    assert ansible_fact_collector.collect(collected_facts={}) == {}

    # Test case with an empty collector_obj
    ansible_fact_collector = AnsibleFactCollector([collector1])
    assert ansible_fact_collector.collect(collected_facts={}) == {}

    # Test case with a single collector_obj

# Generated at 2022-06-11 02:08:55.234201
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class CollectorMock(collector.BaseFactCollector):
        name = ''
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'test_facts': 'test_facts'}

    collectors = []
    for c in range(0, 10):
        collectors.append(CollectorMock())

    fact_collector = AnsibleFactCollector(collectors=collectors)

    expected_facts = {}
    for c in collectors:
        expected_facts.update(c.collect())

    assert fact_collector.collect() == expected_facts


# Unit tests for function get_ansible_collector

# Generated at 2022-06-11 02:09:05.027114
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import collector_defaults

    # empty list of collector classes, empty gather_subset, empty filter_spec,
    ansible_collector = \
        get_ansible_collector(all_collector_classes=[],
                              namespace=None,
                              filter_spec=None,
                              gather_subset=None,
                              gather_timeout=None,
                              minimal_gather_subset=None)

    assert isinstance(ansible_collector, AnsibleFactCollector)
    assert len(ansible_collector.collectors) == 1
    assert isinstance(ansible_collector.collectors[0],
                      CollectorMetaDataCollector)

    # empty list of collector classes, gather_subset=all, filter

# Generated at 2022-06-11 02:09:16.013935
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    def collect_mock(*args, **kwargs):
        return {'fact_a': 'a',
                'fact_b': 'b',
                'fact_c': 'c'}

    collector_mock = collector.BaseFactCollector()
    collector_mock.collect = collect_mock

    fact_collector = \
        AnsibleFactCollector(collectors=[collector_mock,],
                             filter_spec='*')

    # Testing the use case when the filter_spec is ''
    assert fact_collector.collect() == {'fact_a': 'a',
                                        'fact_b': 'b',
                                        'fact_c': 'c'}

    # Testing the use case when the filter_spec is '*'
    fact_collector.set_filter_spec('*')

# Generated at 2022-06-11 02:09:26.599361
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class CollectorOne(collector.BaseFactCollector):
        name = 'CollectorOne'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'fact_one': 'one'}

    class CollectorTwo(collector.BaseFactCollector):
        name = 'CollectorTwo'
        _fact_ids = set([])

        def collect(self, module=None, collected_facts=None):
            return {'fact_two': 'two'}

    collectors = [
        CollectorOne(),
        CollectorTwo()
    ]

    fact_collector = AnsibleFactCollector(collectors=collectors)

    collected_facts = fact_collector.collect(module=None,
                                             collected_facts=None)


# Generated at 2022-06-11 02:09:50.691850
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''Unit test for method collect of class AnsibleFactCollector'''
    from ansible.module_utils.facts import ansible_collector as ac

    fact_collector = ac.AnsibleFactCollector()
    assert fact_collector.collect() == dict()

    # Now add a fact collector and verify the result
    fact_collector.collectors.append(ac.NetworkCollector(namespace=ac.CoreFactNamespace()))
    facts = fact_collector.collect()

    # Result should have a key namespace.KEY and value should be a dict
    assert ('ansible_local' in facts) and (isinstance(facts['ansible_local'], dict))

    # Assert that the same network fact exists in facts
    network_facts = facts['ansible_local']['network']
    assert 'ipv4'

# Generated at 2022-06-11 02:09:58.718614
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class CollectorOne(collector.BaseFactCollector):
        name = 'one'

        def collect(self, module=None, collected_facts=None):
            return {'one': 1}

    class CollectorTwo(collector.BaseFactCollector):
        name = 'two'

        def collect(self, module=None, collected_facts=None):
            return {'two': 2}

    fact_collector_one = CollectorOne()
    fact_collector_two = CollectorTwo()

    fact_collector = \
        AnsibleFactCollector(collectors=[fact_collector_one, fact_collector_two],
                             namespace=collector.BaseFactNamespace())

    result = fact_collector.collect()

    assert result == {'one': 1, 'two': 2}



# Generated at 2022-06-11 02:10:05.084732
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.platform.sunos
    collector_class = ansible.module_utils.facts.platform.sunos.SunOSFactCollector
    collector_obj = collector_class()

    fact_collector = \
        AnsibleFactCollector(collectors=[collector_obj])

    module = object()
    facts = fact_collector.collect(module=module)
    assert len(facts) > 0

# Generated at 2022-06-11 02:10:14.704211
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    collector_classes = [collector.FacterFactCollector]
    fact_collector = get_ansible_collector(collector_classes, gather_subset=['all'])
    facts = fact_collector.collect()
    # make sure that the results returned include the ansible_facts key
    assert 'ansible_facts' in facts
    # make sure that the results returned include the ansible_facts/gather_subset key
    assert 'gather_subset' in facts['ansible_facts']


# Generated at 2022-06-11 02:10:20.608100
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collectors as collectors
    from ansible.module_utils.facts import namespace

    # Try to get facts when no filter speficied
    fact_collector = get_ansible_collector(all_collector_classes=collectors.collectors,
                                           namespace=None,
                                           minimal_gather_subset=frozenset(),
                                           gather_subset=None)
    assert isinstance(fact_collector, AnsibleFactCollector)

    facts = fact_collector.collect(module=None)
    assert facts, facts
    assert 'ansible_facts' in facts, facts
    #assert isinstance(facts['ansible_facts'], namespace.PrefixFactNamespace), facts

    # Try to get facts when filter specfied
    fact_collector

# Generated at 2022-06-11 02:10:31.889598
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts import dict_merge
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    c1 = collector.BaseFactCollector(namespace=None)
    c1.collect = lambda module=None, collected_facts=None: dict(c1dict=dict(c1=1, c2=2, c3=3))
    c2 = collector.BaseFactCollector(namespace=PrefixFactNamespace(prefix='ansible_'))
    c2.collect = lambda module=None, collected_facts=None: dict(c2dict=dict(c1=1, c2=2, c3=3))

    fact_collector = AnsibleFactCollector([c1, c2])

    collected_facts = fact_collector.collect()
    assert collected_

# Generated at 2022-06-11 02:10:38.663234
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # pylint: disable=import-error
    # pylint: disable=no-name-in-module
    from ansible.module_utils.facts.fact_cache import FactCache
    from ansible.module_utils.facts.hardware.cpu import CPUCollector
    from ansible.module_utils.facts.hardware.system import SystemCollector
    from ansible.module_utils.facts.os.freebsd import FreeBSDFactsCollector
    from ansible.module_utils.facts.os.osx import OSXCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.interfaces import InterfacesCollector
    from ansible.module_utils.facts.network.installation import InstallationCollector

# Generated at 2022-06-11 02:10:48.261277
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    # Test case with namespace, filter_spec provided
    collectors = [collector.BaseFactCollector()]
    collector = get_ansible_collector(collectors=collectors,
                                      gather_subset=['all'],
                                      gather_timeout=1,
                                      filter_spec=['is*'],
                                      namespace=collector.PrefixFactNamespace('ansible_'))
    assert collector.collect() == {'is_collector': True}

    # Test case with namespace, filter_spec provided
    collectors = [collector.BaseFactCollector(), collector.BaseFactCollector()]

# Generated at 2022-06-11 02:10:57.590385
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class MockNamespace(object):
        def __init__(self):
            pass
        def set_fact(self, name, value):
            return name, value

    class MockCollector(object):
        def __init__(self, namespace=None):
            self.namespace = namespace
        def collect_with_namespace(self, module, collected_facts):
            return {'mock_fact': 'mock_value'}

    # collect facts without a namespace
    mock_collector = MockCollector()
    fact_collector = AnsibleFactCollector(collectors=[mock_collector])
    assert fact_collector.collect() == {'mock_fact': 'mock_value'}

    # collect facts with a namespace
    mock_namespace = MockNamespace()
    mock_collector = MockCollector

# Generated at 2022-06-11 02:11:06.654521
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''unit test for class AnsibleFactCollector method collect()'''
    import unittest

    # test class for collector objects
    class CollectableObject(object):
        name = ''
        collected_from = ''

        def collect(self):
            return {self.collected_from: self.name}

    # test class for a collector
    class TestCollector(object):
        name = 'test_collector'

        def __init__(self, namespace=None, filter_spec=None):
            pass

        def collect_with_namespace(self, module=None, collected_facts=None):
            '''collect_with_namespace() mock'''
            return {'namespace': 'namespace_data'}

    # test class for a collector that raises an exception
    class TestExceptionCollector(object):
        name