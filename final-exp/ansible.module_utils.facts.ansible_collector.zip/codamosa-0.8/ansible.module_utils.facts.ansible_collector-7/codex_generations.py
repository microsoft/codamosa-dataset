

# Generated at 2022-06-11 02:01:20.977298
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    fact_collector = \
        CollectorMetaDataCollector(gather_subset=['all'],
                                   module_setup=True)
    collected_facts = {}
    results = fact_collector.collect(module=None, collected_facts=collected_facts)
    assert results == {'gather_subset': ['all'], 'module_setup': True}

# Generated at 2022-06-11 02:01:29.705627
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    from ansible.module_utils.facts.test_utils import test_setup
    test_setup()

    # Specify the collector to be tested
    collector_ = CollectorMetaDataCollector('all')

    # Get the result of calling the collector
    result = collector_.collect()

    # Make sure the result is what we expect
    assert result == {'gather_subset': 'all'}

    # Make sure the namespaces are what we expect
    assert collector_.namespace == None
    assert collector_.name == 'gather_subset'
    assert type(collector_._fact_ids) == set

# Generated at 2022-06-11 02:01:36.802648
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    g_subset_value = ['all']
    module_setup_value = True
    meta_data_facts = CollectorMetaDataCollector(gather_subset=g_subset_value,
                                                 module_setup=module_setup_value).collect()

    assert 'gather_subset' in meta_data_facts and meta_data_facts.get('gather_subset') == g_subset_value, \
        "gather_subset fact is not correct!"
    assert 'module_setup' in meta_data_facts and meta_data_facts.get('module_setup') == module_setup_value, \
        "module_setup fact is not correct!"

# Generated at 2022-06-11 02:01:45.709369
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    collector_meta_data_collector = CollectorMetaDataCollector(collectors=None,
                                                               namespace=None,
                                                               gather_subset={'all'},
                                                               module_setup=True)
    result = collector_meta_data_collector.collect(module=None, collected_facts=None)
    assert result == {'gather_subset': {'all'}, 'module_setup': True}

    collector_meta_data_collector = CollectorMetaDataCollector(collectors=None,
                                                               namespace=None,
                                                               gather_subset={'all'},
                                                               module_setup=False)
    result = collector_meta_data_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-11 02:01:57.969621
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():

    c = CollectorMetaDataCollector(gather_subset=['test_collector'])
    f = c.collect()
    assert f == {'gather_subset': ['test_collector']}

    c = CollectorMetaDataCollector(gather_subset=['test_collector'],
                                   module_setup=True)
    f = c.collect()
    assert f == {'gather_subset': ['test_collector'],
                 'module_setup': True}

    c = CollectorMetaDataCollector(gather_subset=['test_collector'],
                                   module_setup=False)
    f = c.collect()
    assert f == {'gather_subset': ['test_collector'],
                 'module_setup': False}


# Generated at 2022-06-11 02:02:06.210119
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import timeout

    gather_subset = ['all']
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    # all_collector_classes is the global map of all collector classes available
    all_collector_classes = fact_collector.get_collector_classes()

    # Create a namespace
    namespace = PrefixFactNamespace(prefix='ansible_')

    # Create a list of filters
    filter_spec = []

    # Get an AnsibleFactCollector

# Generated at 2022-06-11 02:02:09.640431
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    ret = CollectorMetaDataCollector(gather_subset=['all'], module_setup=True).collect()

    assert ret == {'gather_subset': ['all'], 'module_setup': True}



# Generated at 2022-06-11 02:02:12.703674
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_collector = CollectorMetaDataCollector()
    results = meta_collector.collect()
    assert isinstance(results, dict)
    assert 'gather_subset' in results


# Generated at 2022-06-11 02:02:14.084867
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    c = CollectorMetaDataCollector(_collector_classes=[])
    c.collect()

# Generated at 2022-06-11 02:02:19.296900
# Unit test for method collect of class CollectorMetaDataCollector
def test_CollectorMetaDataCollector_collect():
    meta_data_collector = CollectorMetaDataCollector(namespace=None, gather_subset='all', module_setup=True)
    meta_data = meta_data_collector.collect()
    assert meta_data['gather_subset'] == 'all'
    assert meta_data['module_setup'] == True


# Generated at 2022-06-11 02:02:23.672474
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-11 02:02:34.642030
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = {'generic': None,
                             'hardware': None,
                             'facter': None,
                             'ohai': None,
                             'virtual': None}

    filter_spec = ['hardware', 'virtual']

    gather_subset = ['all', 'min', 'hardware']
    fact_collector = get_ansible_collector(all_collector_classes=all_collector_classes,
                                           filter_spec=filter_spec,
                                           gather_subset=gather_subset)

    # We should have a collector that provides the gather_subset metadata.
    assert len(fact_collector.collectors) == 3


# Generated at 2022-06-11 02:02:45.962046
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}

    class FakeCollector1(collector.BaseFactCollector):
        # This collector provides facts in the local namespace
        def collect(self, module=None, collected_facts=None):
            return {'f1': 'F1',
                    'f2': 'F2',
                    'ansible_local_f1': 'AF1'}

    class FakeCollector2(collector.BaseFactCollector):
        # This collector provides facts in the network namespace
        namespace = PrefixFactNamespace(prefix='ansible_network_')

# Generated at 2022-06-11 02:02:51.934513
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts import namespaces

    class PrintCollector(collector.BaseFactCollector):
        def collect(self):
            return {'test_key': 'test_value'}

    fact_collector = AnsibleFactCollector(collectors=PrintCollector(),
                                          namespace=namespaces.PrefixFactNamespace(prefix='ansible_'))
    facts = fact_collector.collect()
    assert facts == {'ansible_test_key': 'test_value'}

# Generated at 2022-06-11 02:03:03.267977
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class TestCollector(object):
        def __init__(self, module, collected_facts):
            self.module = module
            self.collected_facts = collected_facts
            self.collect_called = False

        def collect(self):
            self.collect_called = True
            return (False, 'Something bad happened')

    module = {}
    collected_facts = {'a': 'x', 'b': 'y'}

    # Test if collect returns with expected keys and values
    # when filterspec is 'ansible_*' , even though we have no facts starting with 'ansible_'
    # we should have ansible_facts['ansible_']['filter_result']: [('a', 'x'), ('b', 'y')]

# Generated at 2022-06-11 02:03:14.044667
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    class TestFactCollector(BaseFactCollector):

        name = "some_fact"

        def collect(self, module=None, collected_facts=None):
            return {self.name: self.name}

    collector.FACT_COLLECTORS.insert(0, TestFactCollector)

# Generated at 2022-06-11 02:03:22.459185
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    '''
    The get_ansible_collector function should return a collector
    that contains collectors for all the names in gather_subset
    '''
    from ansible.module_utils.facts.hardware.aix import AixHardware
    from ansible.module_utils.facts.hardware.bsd import BsdHardware
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.solaris import SolarisHardware
    from ansible.module_utils.facts.hardware.windows import WindowsHardware
    from ansible.module_utils.facts.network.aix import AixNetwork
    from ansible.module_utils.facts.network.bsd import BsdNetwork


# Generated at 2022-06-11 02:03:34.531917
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collectors.all as all_collectors

    fact_collector = \
        get_ansible_collector(
            all_collector_classes=all_collectors.all_collector_classes,
            gather_subset=['!hardware'],
            gather_timeout=0)
    assert fact_collector.filter_spec == []
    assert len(fact_collector.collectors) == 7
    assert type(fact_collector.collectors[0]).__name__ == 'PlatformFactCollector'
    assert type(fact_collector.collectors[-1]).__name__ == 'CollectorMetaDataCollector'
    assert fact_collector.collectors[-1].gather_subset == ['!hardware']

    fact_collector = \
        get_ans

# Generated at 2022-06-11 02:03:41.024614
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    fact_collector = \
        get_ansible_collector(all_collector_classes=ansible.module_utils.facts.collector.collector_classes)

    assert isinstance(fact_collector, AnsibleFactCollector)
    assert fact_collector.filter_spec == ['*']
    assert len(fact_collector.collectors) > 2

# Generated at 2022-06-11 02:03:50.001070
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''test_AnsibleFactCollector_collect should return a facts dictionary'''

    # Mock class MockCollector0
    class MockCollector0(object):
        def __init__(self):
            pass

        def collect_with_namespace(self, **kwargs):
            return {'MockCollector0': {'fact1': 'value1', 'fact2': 'value2'}}

    # Mock class MockCollector1
    class MockCollector1(object):
        def __init__(self):
            pass

        def collect_with_namespace(self, **kwargs):
            return {'MockCollector1': {'fact3': 'value3', 'fact4': 'value4'}}

    # Mock class MockCollector2

# Generated at 2022-06-11 02:04:04.463298
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import get_collector_classes
    from ansible.module_utils.facts import default_collector_classes
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import get_collector_class
    from ansible.module_utils.facts import get_all_collector_classes

    import unittest

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'

    class TestCollector4(collector.BaseFactCollector):
        name = 'test4'


# Generated at 2022-06-11 02:04:11.841361
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import mock
    import datetime
    import time

    class TestCollector1(collector.BaseFactCollector):
        name = 'test_collector_1'

        def collect(self, module=None, collected_facts=None):
            return {'fact1': '1'}

    class TestCollector2(collector.BaseFactCollector):
        name = 'test_collector_2'

        def collect(self, module=None, collected_facts=None):
            return {'fact2': '1'}

    class TestCollector3(collector.BaseFactCollector):
        name = 'test_collector_3'

        def collect(self, module=None, collected_facts=None):
            return {'fact3': '1'}


# Generated at 2022-06-11 02:04:21.962697
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts import ns
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import cache_dir

    # simple gather_subsets to use for testing
    gather_subset = ['!all']
    minimal_gather_subset = frozenset(['!all'])
    gather_timeout = 1

    namespace = ns.SimpleNamespace(prefix='ansible_', separator='_')
    fact_collector = get_ansible_collector(
        all_collector_classes=[cache.FactCache],
        namespace=namespace,
        gather_subset=gather_subset,
        minimal_gather_subset=minimal_gather_subset,
        gather_timeout=gather_timeout
    )

    facts_dict = fact_

# Generated at 2022-06-11 02:04:32.154348
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import setup_collectors

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    module_utils_fact_collectors = setup_collectors(collectors_classes=[TestCollector],
                                                    namespace=PrefixFactNamespace())

    fact_collector = AnsibleFactCollector(collectors=module_utils_fact_collectors,
                                          namespace=PrefixFactNamespace())

    collected_facts = fact_collector.collect()


# Generated at 2022-06-11 02:04:43.576991
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import inspect
    import ansible.module_utils.facts.namespace

    all_collector_classes = \
        inspect.getmembers(
            sys.modules[ansible.module_utils.facts.namespace.__name__],
            inspect.isclass)

    gather_subset = ['all', 'network']

    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset=gather_subset)

    collected_facts = fact_collector.collect()

    # verify these facts are present
    assert 'ansible_distribution' in collected_facts
    assert 'ansible_os_family' in collected_facts
    assert 'ansible_all_ipv4_addresses' in collected_facts

    # verify these facts are

# Generated at 2022-06-11 02:04:54.820087
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.distribution
    all_collector_classes = ansible.module_utils.facts.collector
    filter_spec = []
    gather_subset = 'all'
    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = frozenset()

    collector_classes = \
        collector.collector_classes_from_gather_subset(
            all_collector_classes=all_collector_classes,
            minimal_gather_subset=minimal_gather_subset,
            gather_subset=gather_subset,
            gather_timeout=gather_timeout)

    print(collector_classes)

# Generated at 2022-06-11 02:05:06.149718
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collector.platform.linux
    import ansible.module_utils.facts.collector.network.hardware
    import ansible.module_utils.facts.collector.network.interfaces
    all_collector_classes = [
            ansible.module_utils.facts.collector.platform.linux.Distribution,
            ansible.module_utils.facts.collector.network.hardware.NetworkHardware,
            ansible.module_utils.facts.collector.network.interfaces.NetworkInterfaces
        ]

    class MockNetworkHardwareCollector(ansible.module_utils.facts.collector.network.hardware.NetworkHardware):

        name = 'network_hardware'
        _fact_ids = frozenset(['network_hardware'])


# Generated at 2022-06-11 02:05:17.670419
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    collector_namespace = 'collector_namespace'
    fact_collector = AnsibleFactCollector(namespace=collector_namespace)

    expected_fact_dict = {'test_fact': {'test_sub_fact': 'sub_fact_value'}}

    class MockCollector(object):
        def __init__(self, *args, **kwargs):
            self.name = 'mock'

        def collect_with_namespace(self, module=None, collected_facts=None):
            return expected_fact_dict

    class MockCollectorNoNamespace(MockCollector):
        def __init__(self, *args, **kwargs):
            self.name = 'mock2'


# Generated at 2022-06-11 02:05:18.945583
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass


# Generated at 2022-06-11 02:05:29.403213
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual

    all_fact_collector_classes = \
        ansible.module_utils.facts.collector.collector_classes_from_gather_subset(
            all_collector_classes=ansible.module_utils.facts.collector.all_collector_classes,
            gather_subset=['all'],
            gather_timeout=collector.DEFAULT_GATHER_TIMEOUT)

    fact_collector = get_ansible_collector(all_collector_classes=all_fact_collector_classes)

    ansible_facts

# Generated at 2022-06-11 02:05:36.999152
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    pass

# Generated at 2022-06-11 02:05:48.353406
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.hardware.dmi
    collector_classes = [ansible.module_utils.facts.hardware.dmi.DmiHardware, ]
    namespaces = [('ansible.module_utils.facts.hardware', 'ansible_'), ]
    namespace = collector.PrefixFactNamespace(prefix='ansible_')
    collector_obj = get_ansible_collector(collector_classes, namespace=namespace)
    collected_facts = collector_obj.collect()
    assert 'ansible_facts' in collected_facts
    assert 'ansible_device_id' in collected_facts['ansible_facts']
    cpu_collector_obj = ansible.module_utils.facts.hardware.dmi.DmiCpu(namespace=namespace)
    cpu_collected_facts

# Generated at 2022-06-11 02:05:59.432043
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class FakeCollector(collector.BaseFactCollector):

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'a': 1, 'b': 2}

    class FakeCollector2(collector.BaseFactCollector):

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {'c': 3, 'd': 4}

    class FakeCollector3(collector.BaseFactCollector):

        # Don't return a dict, should still work.
        def collect_with_namespace(self, module=None, collected_facts=None):
            return None


# Generated at 2022-06-11 02:06:10.559160
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''collect()'''
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceCollector

    class MockCollector1(BaseFactCollector):
        name = 'mock1'
        _fact_ids = set([])
        def collect(self):
            return {'mock1': 1}

    class MockCollector2(BaseFactCollector):
        name = 'mock2'
        _fact_ids = set([])
        def collect(self):
            return {'mock2': 2}

    class MockNamespaceCollector1(NamespaceCollector):
        name = 'mockns1'
        _fact_ids = set([])


# Generated at 2022-06-11 02:06:22.178168
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    from ansible.module_utils.facts.collector import get_fact_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_collector_classes = collector.fact_collector_classes()
    fact_collector = \
        get_ansible_collector(all_collector_classes=all_collector_classes,
                              gather_subset='all')

    # Tests
    # 1. get_ansible_collector can be run with non empty gather_subset
    # 2. get_ansible_collector can be run with empty gather_subset
    # 3. get_ansible_collector does not raise exception if collector_class has no namespace
    # 4. get_ansible_collector can be run with a valid namespace
    # 5. get_ansible_

# Generated at 2022-06-11 02:06:30.749926
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.system

    gather_subset = ['all']
    timeout = 10
    minimal_subset = ['ohai']
    filter_spec = '*ipv4'

    collector_classes = ansible.module_utils.facts.collector.network.collector_classes
    collector_classes.extend(ansible.module_utils.facts.collector.platform.collector_classes)
    collector_classes.extend(ansible.module_utils.facts.collector.system.collector_classes)


# Generated at 2022-06-11 02:06:42.434498
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class MockCollector(collector.BaseFactCollector):
        name = 'ansible_test'

        def collect(self, module=None, collected_facts=None):
            return {'test_key': 'test_value'}

    mock_collectors = [MockCollector()]

    # with no filter_spec, same dict should be returned.
    fact_collector = AnsibleFactCollector(collectors=mock_collectors)
    facts = fact_collector.collect()
    assert facts == {'test_key': 'test_value'}

    # with filter_spec should return dict with only matched keys
    fact_collector = AnsibleFactCollector(collectors=mock_collectors, filter_spec='test_key')
    facts = fact_collector.collect()

# Generated at 2022-06-11 02:06:53.434447
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    '''
    Unit test for method collect of class AnsibleFactCollector
    '''
    import tempfile

    class FakeCollector:
        name = 'fake'

        def collect_with_namespace(self, module=None, collected_facts=None):
            return {
                'fake_1': 'fake1',
                'fake_2': 'fake2',
            }

    class FakeFact:
        def __init__(self, name, value):
            self.name = name
            self.value = value

    def test_collector_class(base_class, namespace, filter_spec=None):
        collector_obj = FakeCollector()
        fact_collector = \
            AnsibleFactCollector(collectors=[collector_obj],
                                 namespace=namespace,
                                 filter_spec=filter_spec)

# Generated at 2022-06-11 02:06:56.921995
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class Collector(object):
        name = 'collector'

        def collect(self):
            return {'test': 'test'}

    fact_collector = AnsibleFactCollector([Collector()])
    facts = fact_collector.collect()
    assert facts['test'] == 'test'

# Generated at 2022-06-11 02:07:05.680246
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import tempfile
    import shutil
    import os
    from ansible.module_utils.facts.collectors.base import BaseFactCollector

    class Collector(BaseFactCollector):
        name = 'test_collector'

        def collect(self, module=None, collected_facts=None):
            return {'fact': 'fact'}

    tmp_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 02:09:18.632631
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.timeout import BaseFactTimeout
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionNamespace
    from ansible.module_utils.facts.system.machine import MachineFactCollector
    from ansible.module_utils.facts.system.machine import MachineNamespace
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.platform import PlatformNamespace

    sys_machine = MachineFactCollector(namespace=MachineNamespace())


# Generated at 2022-06-11 02:09:29.426138
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    # NOTE: This is a very minimal unit test to verify get_ansible_collector works

    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.virtual

    minimal_gather_subset = frozenset(['!all', '!any'])

    fact_collector = get_ansible_collector(
        all_collector_classes=collector.ALL_COLLECTOR_CLASSES,
        minimal_gather_subset=minimal_gather_subset,
        gather_subset=['!all', 'network', 'virtual'],
        filter_spec=['ansible_eth*'],
        gather_timeout=1,
    )

    assert fact_collector.filter

# Generated at 2022-06-11 02:09:29.914390
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    pass

# Generated at 2022-06-11 02:09:34.427981
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    global_ansible_collector = get_ansible_collector()
    assert(global_ansible_collector['ansible_dns'] == {})
    assert(global_ansible_collector['ansible_python'] == {})
    assert(global_ansible_collector['gather_subset'] == frozenset(['all']))

# Generated at 2022-06-11 02:09:45.947504
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    class a_collector(collector.BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a'])

        def collect(self, module=None, collected_facts=None):
            return {'a': 1}

    class b_collector(collector.BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b'])

        def collect(self, module=None, collected_facts=None):
            return {'b': 2}

    c1 = a_collector()
    c2 = b_collector()

    fc = AnsibleFactCollector(collectors=[c1, c2],
                              filter_spec=['*'])

    assert fc.collect() == {'a': 1, 'b': 2}
    assert fc

# Generated at 2022-06-11 02:09:55.066541
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    class CollectorOne():
        def collect_with_namespace(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['one'] = 1
            return collected_facts
    class CollectorTwo():
        def collect_with_namespace(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['one'] = 2
            return collected_facts

    one = CollectorOne()
    two = CollectorTwo()
    c = AnsibleFactCollector(collectors=[one, two], filter_spec='*')
    f = c.collect()
    assert f['one'] == 2

# Generated at 2022-06-11 02:10:04.647935
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():
    import ansible.module_utils.facts.collectors.platform
    import ansible.module_utils.facts.collectors.network

    platform_collector = ansible.module_utils.facts.collectors.platform.PlatformFactCollector()
    network_collector = ansible.module_utils.facts.collectors.network.NetworkFactCollector()

    ansible_fact_collector = \
        AnsibleFactCollector(collectors=[platform_collector, network_collector])

    facts = ansible_fact_collector.collect()

    assert 'ansible_facts' in facts
    assert 'network' in facts['ansible_facts']
    assert 'ipv4' in facts['ansible_facts']['network']

# Generated at 2022-06-11 02:10:16.900233
# Unit test for function get_ansible_collector
def test_get_ansible_collector():
    all_collector_classes = \
        [collector.FacterCollector,
         collector.OhaiCollector,
         collector.FileGlobCollector,
         collector.CmdCollector,
         collector.PkgCollector,
         collector.VirtualBoxCollector,
         collector.VirtWhatCollector,
         collector.DnfSubscriptionManagerCollector,
         collector.RhelSubscriptionManagerCollector,
         collector.RedHatReleaseCollector,
         collector.ScratchFactCollector]

    # Test the default collector
    fact_collector = get_ansible_collector(all_collector_classes)
    assert len(fact_collector.collectors) == 14

    # Test a collector with a filter list
    filter_list = ['ansible_distribution*', 'ansible_os_family']
    fact

# Generated at 2022-06-11 02:10:28.221602
# Unit test for method collect of class AnsibleFactCollector
def test_AnsibleFactCollector_collect():

    from ansible.module_utils.facts.network.base import BaseNetworkCollector
    from ansible.module_utils.facts.network.bond import BondCollector
    from ansible.module_utils.facts.network.interfaces import InterfaceCollector
    from ansible.module_utils.facts.network.ipv4 import IPv4Collector
    from ansible.module_utils.facts.network.ipv6 import IPv6Collector

    assert interface_collector.__doc__
    assert bond_collector.__doc__

    # Create an ansible namespace
    ##  # For ex: an ansible.module_utils.facts.namespace.PrefixFactNamespace(prefix='ansible_')
    ##  from ansible.module_utils.facts.namespace import PrefixFactNamespace
    ##  ansible_ns = Prefix

# Generated at 2022-06-11 02:10:35.322615
# Unit test for function get_ansible_collector
def test_get_ansible_collector():

    from ansible.module_utils.facts import default

    filter_spec = filter_spec or []
    gather_subset = gather_subset or ['all']
    gather_timeout = gather_timeout or timeout.DEFAULT_GATHER_TIMEOUT
    minimal_gather_subset = minimal_gather_subset or frozenset()

    fact_collector = get_ansible_collector(all_collector_classes=default.collector_classes,
                                           gather_subset=['all'],
                                           filter_spec=filter_spec,
                                           gather_timeout=10,
                                           minimal_gather_subset=minimal_gather_subset)

    assert fact_collector is not None


if __name__ == '__main__':

    test_get_ansible_collector()