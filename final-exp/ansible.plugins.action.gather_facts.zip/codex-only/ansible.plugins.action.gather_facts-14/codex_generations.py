

# Generated at 2022-06-23 07:58:01.791705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    vt = ActionModule()
    # (15, 7)

    # Create an instance of class ActionModule
    vt = ActionModule()
    # (15, 7)

    # Create an instance of class ActionModule
    vt = ActionModule()
    # (15, 7)

    # Create an instance of class ActionModule
    vt = ActionModule()
    # (15, 7)

    # Create an instance of class ActionModule
    vt = ActionModule()
    # (15, 7)

    # Create an instance of class ActionModule
    vt = ActionModule()
    # (15, 7)

    # Create an instance of class ActionModule
    vt = ActionModule()
    # (15, 7)

    # Create an instance of class ActionModule
    vt = ActionModule()

# Generated at 2022-06-23 07:58:12.230535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mname = "mymodule"
    module = "ansible.legacy.setup"
    path = "/path/lib/"
    mod_args = {"arg1": 1, "arg2": 2}
    task_vars = {}
    module_defaults = {}
    action_groups = {}
    connection_loader_mock = mock.MagicMock()
    connection_loader_mock.find_plugin_with_context.return_value.resolved_fqcn = 'resolved_fqcn'
    shared_loader_obj_mock = mock.MagicMock()
    shared_loader_obj_mock.module_loader.find_plugin_with_context.return_value.resolved_fqcn = 'resolved_fqcn'
    templar_obj_mock = mock.MagicMock()


# Generated at 2022-06-23 07:58:22.125839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    shell = AnsibleShellModule()
    print(shell.__class__.__bases__)
    module_name = 'shell'
    module_args = 'ls'
    cwd = '/root/'
    tmp = '.'
    task_vars = dict(foo='bar')
    task_performance_fields = dict()
    wrap_async = True
    task_uuid = None
    shell_option = 'powershell'
    new_stdin = None
    private_data = dict()


# Generated at 2022-06-23 07:58:23.860220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule('test_path', 'test_name', 'test_task', 'test_shared_loader_obj')



# Generated at 2022-06-23 07:58:35.355785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_connection = MagicMock()
    class_mock = MagicMock()
    task_vars = dict(ansible_facts={})

    # setup constructor
    mod = ActionModule(class_mock, task_vars=task_vars, connection=mock_connection)

    # setup instance object
    mod.task_vars = task_vars
    mod.connection = mock_connection

    # test run method
    mod.run()
    assert mod.task_vars['ansible_facts']['_ansible_facts_gathered'] == True
    assert mod.task_vars['_ansible_verbose_override'] == True

    mock_connection.run.assert_not_called()

    # test run method with failed modules
    failed = dict()

# Generated at 2022-06-23 07:58:38.956603
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of ActionModule
    action_module = ActionModule()

    # Check result of ActionModule.run()
    assert action_module.run() == {}

# Generated at 2022-06-23 07:58:53.705940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import ExecutionContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    from ansible_collections.sensu.sensu_go.plugins.modules.sensu_mutator import Exec

    # Constants
    playbooks_dir = 'test_playbooks'
    playbook_path = playbooks_dir + '/test_playbook_from_ActionModule_run.yml'

# Generated at 2022-06-23 07:59:04.989386
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test object
    action_module_obj = ActionModule()

    # Test variables
    tmp = None
    task_vars = {
        'ansible_facts': {
            'network_os': 'junos',
            'ansible_facts_parallel': True
        },
        'ansible_facts_parallel': True
    }

    # Expected result
    expected_result = {
        'ansible_facts': {
            '_ansible_facts_gathered': True,
            'ansible_facts': {
                'ansible_facts_parallel': True,
                'network_os': 'junos'
            }
        },
        '_ansible_verbose_override': True
    }

    # Mock input variables
    action_module_obj._connection = object()
    action_module_

# Generated at 2022-06-23 07:59:10.083740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_dict = dict(
        _supports_check_mode=True,
    )
    result = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    for key, value in test_dict.items():
        assert result.__dict__[key] == value

# Generated at 2022-06-23 07:59:10.625701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 07:59:19.511402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    assert issubclass(ansible.plugins.action.setup.ActionModule, ActionModule)

    import ansible.plugins.action.setup as test_object
    action_module = test_object.ActionModule(
        task=dict(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    action_module._get_module_args = lambda a, b: None
    action_module._execute_module = lambda a, b, c, d: {'ansible_facts': {'network_os': 'junos'}}
    action_module._shared_loader_obj = object()
    action_module.C = object()
    action_module.C.config = object()


# Generated at 2022-06-23 07:59:26.397064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test handle_action_module:action_module#run"""

    action_module = ActionModule()
    assert action_module is not None

    # Test with valid parameters
    action_module.run()

    # Test with tmp=None
    action_module.run(tmp=None)

    # Test with task_vars=None
    action_module.run(task_vars=None)

    # Test with tmp=None, task_vars=None
    action_module.run(tmp=None, task_vars=None)


# Generated at 2022-06-23 07:59:28.066687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_object = ActionModule()
    is_error, has_changed, result = ActionModule_object.run()
    assert is_error
    assert not has_changed
    assert result['ansible_facts'] == {}

# Generated at 2022-06-23 07:59:32.093391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None), ActionModule)

# Generated at 2022-06-23 07:59:35.273978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class AnsibleModule:
        def __init__(self, args):
            self.args = args

    action_module = ActionModule(AnsibleModule({}), {})
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 07:59:36.243998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 07:59:41.770275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method run of class ActionModule
    """

    # controller object
    controller = DummyController()

    # create an empty task object
    task = DummyTask()

    # create the action module object
    action_module = ActionModule(task, controller)

    # call the method to test
    output = action_module.run()

    # ensure that the result is as expected
    assert output == 'PASS'



# Generated at 2022-06-23 07:59:45.251131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture = dict(
        action=dict(
            module_name='setup',
            module_args=dict()
        ),
        task_vars=dict()
    )

    action = ActionModule(fixture, 'fakesocket')
    assert action._supports_check_mode is True



# Generated at 2022-06-23 07:59:48.761353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(id='12345', args=dict(), action='setup'),
        connection='local',
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    # TODO: write unit test
    pass

# Generated at 2022-06-23 07:59:54.792525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.vault import VaultSecret

    loader = DataLoader()
    itree = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-23 08:00:04.310230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Find a fact module to test with
    valid_modules = C.config.get_config_value('FACTS_MODULES')
    for fact_module in valid_modules:
        # Instantiate an action module for testing
        action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

        # Get module args
        module_args = action_module_obj._get_module_args(fact_module, task_vars={})

        # Execute the module
        result = action_module_obj._execute_module(module_name=fact_module, module_args=module_args, task_vars={}, wrap_async=False)

        # Test if the result contains ansible_facts data and returned no errors


# Generated at 2022-06-23 08:00:06.594901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:00:20.594496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Collect module arguments and variables
    module_args = {"gather_subset": "", "filter": ""}
    module_vars = {"ansible_system": "windows"}

    # Construct ActionModule

# Generated at 2022-06-23 08:00:30.550545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import action_loader

    action_class = action_loader.get('setup', class_only=True)
    action_obj = action_class(None)

    action_obj.task_vars = {'ansible_os_family': 'RedHat'}
    action_obj.task_vars['ansible_facts'] = {}
    result = TaskResult()
    result_handler = action_obj._combine_task_result(result, {'ansible_facts': {}})
    assert result_handler['ansible_facts'] == {}

    # Test of method _get_module_args
    # We don't do any asserts here as the original test doesn't either
    # and it is likely that this method is tested in other tests.
   

# Generated at 2022-06-23 08:00:31.427251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-23 08:00:34.168907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(connection='connection', task='task').connection == 'connection'
    assert ActionModule(connection='connection', task='task').task == 'task'

# Generated at 2022-06-23 08:00:43.519850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup dummy test variables
    task_vars = dict()
    task_vars['ansible_facts_parallel'] = None
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['network_os'] = 'nxos'

    # Setup ActionModule class to run module
    am = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    
    # Test module with no fact modules
    am.run(tmp=None, task_vars=task_vars)
    # Test module with one fact module
    am.run(tmp=None, task_vars=task_vars, modules=['test'])

# Generated at 2022-06-23 08:00:46.666897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None,None,None)

    assert action_module.run(None, None) == {'ansible_facts': {},
     'ansible_facts_gathered': True,
     '_ansible_verbose_override': True}

# Generated at 2022-06-23 08:00:47.148592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:00:54.875192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test whether an instance of `ActionModule` could be created.
    """

# Generated at 2022-06-23 08:00:56.205484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod

# Generated at 2022-06-23 08:00:57.570034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None, "ActionModule() class not found"

# Generated at 2022-06-23 08:01:08.300048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import json
    import unittest

    # prepend the workding directory to the path
    sys.path.insert(0, os.path.join(os.getcwd(), '../examples'))

    from _test_action_module_setup import FakeModule, fake_params_args, fake_vars
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import binary_type

    sys.modules['ansible.modules.setup'] = FakeModule()

    action_module = ActionModule()

    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module._supports_async_status = True
    action_module._shared_loader_obj = False
    action_module._config_tmpdir

# Generated at 2022-06-23 08:01:11.874824
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print("Testing ActionModule.run()")

    print("TODO: write actual unit tests for this.")

    return True


if __name__ == '__main__':
    action = ActionModule()
    test_ActionModule_run()

# Generated at 2022-06-23 08:01:12.484506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:01:15.087590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement the unit test with scenario:
    #       - assert one of the return values is result of run method
    pass

# Generated at 2022-06-23 08:01:17.743690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task = dict(args = dict()), connection = None, play_context = "", loader = None, templar = None, shared_loader_obj = None)
    print(am)

# Generated at 2022-06-23 08:01:24.786996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule class requires 3 args:
    # task, connection, play_context
    # Task is an instance of a task, hostvars are taken from this instance.
    # Connection is an instance of a connection to a remote host.
    # play_context is an instance of a play context which defines the behavior of a task.
    assert ActionModule(task=None, connection=None, play_context=None)

# Generated at 2022-06-23 08:01:26.091037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:01:26.865797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:01:38.503108
# Unit test for constructor of class ActionModule
def test_ActionModule():

    pass_vars = {'test_var1': 'test_val', 'test_var2': 'test_val2'}
    fail_vars = {'test_var1': 'test_val', 'test_var2': 'test_val2'}


# Generated at 2022-06-23 08:01:41.333250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # testing that when mod_args is None, that the defaults are used.
    mod = ActionModule(None, dict(a=1))
    assert mod._task.args['a'] == 1


# Generated at 2022-06-23 08:01:43.446066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    am = ActionModule(None, None, None, None, None, None)
    assert am is not None

# Generated at 2022-06-23 08:01:49.980101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit tests for the method ActionModule.run
    #
    # This unit test should be run under module directory
    #

    class Task(object):
        def __init__(self):
            self.args = {}
            self._parent = None

        class _Parent(object):
            def __init__(self):
                self._play = None

            class _Play(object):
                def __init__(self):
                    self._action_groups = None

        def __set_action_groups(self, action_groups):
            self._parent._play._action_groups = action_groups

        def __set_task_args(self, task_args):
            self.args = task_args

        def __set_parent(self, parent):
            self._parent = parent


# Generated at 2022-06-23 08:01:52.055728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod.run("module_name", "module_args", "task_vars")

# Generated at 2022-06-23 08:02:01.798788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {'parallel': None}

    task_vars = {
        'ansible_facts_parallel': None,
    }

    config_module = {'FACTS_MODULES': ['setup']}

    module_loader = {
        'setup': {
            'resolved_fqcn': 'ansible.legacy.setup'
        }
    }

    mock_execute_module = {
        'results_file': '/private/tmp/ansible-local-39319rT9/ansible_local_152967144/tmp_task_pw8m8j',
        'ansible_job_id': '393193224619.6438'
    }


# Generated at 2022-06-23 08:02:13.392085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult

    # setup the test
    result = TaskResult(host=None, task=None)
    result._result = {'ansible_facts': {}}
    test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_action_module._supports_check_mode = True
    test_action_module._display = None
    test_action_module._templar = None
    test_action_module._shared_loader_obj = None

    # run the test

# Generated at 2022-06-23 08:02:14.434224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-23 08:02:25.020517
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    import ansible.template
    import ansible.constants
    import ansible.errors
    import ansible.utils.vars

    def setUpModule():
        ansible.constants.SHOW_CUSTOM_STATS = True

    def tearDownModule():
        ansible.constants.SHOW_CUSTOM_STATS = False

    class ActionModuleWrapper(ActionModule):

        _connection = None
        _shell = None

        @property
        def connection(self):
            return self._connection


# Generated at 2022-06-23 08:02:34.523988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MyTask(object):
        def __init__(self):
            pass
        def get_sub_tasks(self):
            return [1,2,3,4]
        def get_name(self):
            return 'func'

    class MyPlay(object):
        def __init__(self):
            self.hosts = "hosts"
            self.name = 'play_name'
            self.vars = {}
            self.tasks = MyTask()

    class MyInventory(object):
        def __init__(self):
            self.hosts = 'inventory_hosts'
            self.vars = {}

    class MyExecuter(object):
        def __init__(self):
            self.inventory = MyInventory()


# Generated at 2022-06-23 08:02:45.173360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = "/tmp"
    task_vars = {}
    action = ActionModule(tmp, task_vars)
    action._supports_check_mode = True
    result = action.run(tmp, task_vars)
    assert result['ansible_facts'] == {}
    modules = ['smart']
    parallel = task_vars.pop('ansible_facts_parallel', action._task.args.pop('parallel', None))
    assert parallel is None
    assert len(modules) == 1
    parallel = boolean(parallel)
    assert not parallel

# Generated at 2022-06-23 08:02:48.210474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict()),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action

# Generated at 2022-06-23 08:02:59.347269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    # Create a mock task object
    task = {
        'vars': {}, 'version': (2, 4, 3, 'final', 0),
        'no_log': False, 'playbook_file': 'test.yaml',
        'retries': 0, 'deprecation': None,
        'tags': [], 'action': 'setup'
    }

    # Create a mock module object

# Generated at 2022-06-23 08:03:11.073995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import copy
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

    actionBase = ActionBase()
    actionBase._task = TaskInclude()
    actionBase._task._block = list()
    actionBase._task._role = None
    actionBase._task._parent = None
    actionBase._task._play = None
    actionBase._task._handler = Handler()
    actionBase._task._args = dict()
    actionBase._task._role = None
    actionBase._templar = None

    actionBase._shared_loader_obj = None


    # the action module returns a set of facts that are modified
    # by the user, by adding 'ansible_facts' and the modified key
    # then taking

# Generated at 2022-06-23 08:03:23.747542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible import errors
    from ansible.utils.vars import merge_hash

    task_vars = {
        'ansible_facts_parallel': None,
        'ansible_facts': {},
        'ansible_network_os': 'ios',
        'ansible_connection': 'network_cli',
        'ansible_env': 'fake_env',
        'ansible_host': 'test.invalid',
        'ansible_user': 'fake_user',
        'ansible_shell_executable': 'fake_shell',
    }

    module_value = {
        'ansible_facts': {
            'module_facts': 1,
        },
        'warnings': ['module_facts'],
        'deprecations': ['module_facts'],
    }

   

# Generated at 2022-06-23 08:03:26.484106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    params = dict()
    action_module = ActionModule(params, {})
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:03:37.430184
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # initialization
    task = dict(
        module_defaults=dict,
        args=dict(
            smart='smart'
        )
    )
    self = dict()
    self['_connection'] = dict()
    self['_display'] = dict()
    self['_task'] = task
    self['_templar'] = dict()
    self['_connection']['_load_name'] = 'network_cli'
    self['_templar'] = dict()
    self['_templar']['template'] = lambda str: str
    self['_task']['collections'] = ['ansible.builtin']
    self['_display']['warning'] = lambda str: str
    self['_shared_loader_obj'] = dict()

# Generated at 2022-06-23 08:03:48.081099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict(module_name='shell', module_args=dict(cmd='/bin/true'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    result = action.run(tmp='/path/to/tmp', task_vars=dict(ansible_facts_parallel='yes', ansible_facts_gathered='no'))
    assert result['ansible_facts']['_ansible_facts_gathered']
    assert result['_ansible_facts_gathered']
    assert result['ansible_facts']['_ansible_facts_gathered']
    assert result['_ansible_verbose_override']

# Generated at 2022-06-23 08:03:52.786523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    By providing a specific module and fact module, we can simulate the "connection" of a host
    to a module (fact module) and then execute the method run of ActionModule to collect facts.
    Note that this simple test is based on the use of the module "ansible.legacy.setup" (setup module)
    to collect facts.
    """

    # create a test playbook with a mock task
    test_playbook = dict(
        hosts=dict(
            localhost=dict(
                gather_facts=dict(
                    module='ansible.legacy.setup',
                    parallel=False,
                ),
            )
        )
    )

    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_utils_loader
    from ansible.plugins.loader import modules_loader

# Generated at 2022-06-23 08:03:53.372309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-23 08:03:57.613480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = module.run()
    assert result['ansible_facts'] == {}
    assert result['ansible_facts']['_ansible_facts_gathered'] == True


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 08:04:03.752698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of ActionModule class
    obj = ActionModule(connection=None, module_name='setup', task_vars=None, play_context=None)
    # create task_vars dictionary
    task_vars = {'ansible_facts': {}}
    # call method run
    obj.run(tmp='', task_vars=task_vars)

# Generated at 2022-06-23 08:04:13.528410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Mock_loader(object):
        def find_plugin_with_context(loader, name, collection_list=None):
            class Mock_plugin():
                class Mock_find():
                    class Mock_resolved_fqcn():
                        pass

                def resolved_fqcn(self):
                    return self.Mock_find.Mock_resolved_fqcn()

            class Mock_plugin_find():
                def find_plugin(name, collection_list=None):
                    plugin = Mock_plugin()
                    return plugin
            plugin_find = Mock_plugin_find()
            plugin = plugin_find.find_plugin(name, collection_list)
            return plugin

    class Mock_task(object):
        def __init__(self, parent_task):
            self._parent = parent_task


# Generated at 2022-06-23 08:04:25.035701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pprint
    mock_loader = _mock_loader()
    mock_templar = _mock_templar()
    mock_task = _mock_task()
    mock_task._parent = _mock_task()
    mock_task._parent._play = _mock_task()
    mock_task._parent._play._action_groups = _mock_task()
    mock_task._parent._play._action_groups._play = _mock_task()
    mock_task._parent._play._action_groups._play._action_gather_facts = _mock_task()
    mock_task._parent._play._action_groups._play._action_gather_facts._play = _mock_task()
    mock_task._parent._play._action_groups._play._action_gather_facts._

# Generated at 2022-06-23 08:04:25.498532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:04:36.434159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.plugins import PluginLoader
    from ansible import context
    import ansible.constants as C
    import os
    import tempfile
    import json

    # set up basic objects needed for PlaybookExecutor

# Generated at 2022-06-23 08:04:46.080921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from .test_setup import test_class

    modules = ['ansible.legacy.setup']

    args = {
        'filter': 'ansible_eth*',
        'gather_subset': 'all',
    }


# Generated at 2022-06-23 08:04:52.471527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(action=dict(module_name="setup", valid=True)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-23 08:05:03.297136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    requires = {
        'FACTS_MODULES': ['ansible.legacy.setup'],
        'CONNECTION_FACTS_MODULES': {'linux': 'ansible.legacy.linux'}
    }
    executor = ActionModule(requires, None, None, None, None, {})
    executor._execute_module = lambda *args: {'ansible_facts': {'%s_fact' % args[0]: True}}

    res = executor.run(None, {'ansible_network_os': 'linux'})
    assert len(res.keys()) == 3
    assert res['ansible_facts']['ansible.legacy.setup_fact']
    assert res['ansible_facts']['ansible.legacy.linux_fact']

# Generated at 2022-06-23 08:05:12.518311
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:05:21.584164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create mock object
    action_base = ActionBase()

    action_module = ActionModule(action_base)

    result = action_module.run()

    assert result['failed'] == True
    assert result['msg'] == 'The following modules failed to execute: ansible.legacy.setup\n'

# Generated at 2022-06-23 08:05:22.587511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-23 08:05:23.329343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:05:35.380630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import module_loader
    from ansible.plugins.action.setup import ActionModule as SetupActionModule

    add_all_plugin_dirs()

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict())),
        ]
    )

    play = Play().load(play_source, variable_manager={}, loader=module_loader)


# Generated at 2022-06-23 08:05:45.462602
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # mock for class ActionBase
    class MockActionBase:
        module_name = "setup"
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

    # create an instance of class ActionModule
    actionmodule_instance = ActionModule(
        task={},
        connection={},
        play_context={},
        loader={},
        templar={},
        shared_loader_obj={},
    )

    # compare actual class name (actionmodule_instance.__class__.__name__) with given class name

# Generated at 2022-06-23 08:05:48.019611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert True

# Test for method run of class ActionModule

# Generated at 2022-06-23 08:05:59.939053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with FACTS_MODULES being a list
    modules = ['setup', 'network_facts']
    parallel = True
    task_vars = {}
    module = ActionModule()
    result = module.run(C.DEFAULT_LOCAL_TMP, task_vars)
    assert result['ansible_facts'] == {'_ansible_facts_gathered': True}
    assert result['_ansible_verbose_override'] is True
    assert result['deprecations'] == []
    assert result['failed_modules'] == {}
    assert result['failed'] is False
    assert result['msg'] == ''
    assert result['skipped_modules'] == {}
    assert result['skipped'] is False
    assert result['warnings'] == []

    # Test with FACTS_MODULES being a string
    modules

# Generated at 2022-06-23 08:06:06.384888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ModuleMock(object):
        pass

    class TaskMock(object):
        pass

    class PlaybookMock(object):
        pass

    class TaskResultMock(object):
        pass

    class PlayContextMock(object):
        pass

    class ConnectionMock(object):
        pass

    class RunnerConnectionMock(object):
        pass

    class SharedLoaderObjMock(object):
        pass

    # TODO: add unit test

# Generated at 2022-06-23 08:06:09.695944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Mock module and connection for the constructor
    module = 'test_module_name'
    connection = 'test_connection'

    # Instantiate a ActionModule.  This should fail and raise an exception.
    try:
        test_action_module = ActionModule(module_name=module, connection=connection)
    except Exception:
        pass

    # If it failed as expected, then we're all good
    assert True

# Generated at 2022-06-23 08:06:20.914554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import shutil
    action = ActionModule()

    # initialize
    action._supports_check_mode = True
    action._task = None
    action._shared_loader_obj = None
    action._connection = None
    action._play_context = None
    action._display = None
    action._loader = None
    action._templar = None
    action._task_vars = None
    action._templar = None
    action.task_vars = None
    action.tmp = None
    assert action.run(tmp=None, task_vars=None) == {'ansible_facts': {}, 'failed': True, 'msg': "The following modules failed to execute: \n"}

    # initialize
    action._supports_check_mode = True
    action._task = 'os-name'


# Generated at 2022-06-23 08:06:28.179890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule({}, {}, {}, {})

    # Test positive cases
    positive_cases = [
        # normal case (valid input, return expected output)
        {'input': {'module_name': 'fake-module-name'}, 'expected_output': {'failed': False}},
    ]

    for c in positive_cases:
        output = m.run(c['input'])
        assert output == c['expected_output']

# Generated at 2022-06-23 08:06:34.363498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test run method of class ActionModule'''
    # create dummy 'self' object
    actionmodule = ActionModule()

    # create dummy 'tmp' object
    tmp = '/tmp/ansible-module-setup/ansible_local'

    # create dummy 'task_vars' object
    task_vars = {
        'ansible_facts': {}
    }

    # run method
    actionmodule.run(tmp, task_vars)

# Generated at 2022-06-23 08:06:44.547615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    fact_module = "ansible.legacy.setup"
    connection_map = {}
    self = ActionModule()
    self._task.args = {
        'fact_module': fact_module,
        'connection_map': connection_map,
        'network_os': None
    }
    modules = [fact_module]
    parallel = boolean(None)
    task_vars = {}
    tmp = None
    result = {
        'failed': False,
        'failed_modules': {
        },
        'msg': '',
        'ansible_facts': {
        },
        'skipped': False,
        'skipped_modules': {
        },
        '_ansible_verbose_override': True
    }

# Generated at 2022-06-23 08:06:46.618731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actual_result = ActionModule.__init__(ActionModule)
    assert actual_result is not None

# Generated at 2022-06-23 08:06:48.061997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:06:56.228187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actions = ['ansible.legacy.setup']
    task = {'args': {'network_os': 'ios'}, 'vars': {'ansible_network_os': 'ios'}}
    base = ActionModule(task, None, C.config.get_config_value('DEFAULT_MODULE_UTILS'), None, None, None, None)
    fact_modules = base._get_fact_modules(actions, task['vars'])
    assert fact_modules == ['ansible.legacy.setup']

# Generated at 2022-06-23 08:07:05.001554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('/tmp', dict())
    assert isinstance(action_module, ActionBase)
    # test interface methods
    assert action_module.run() == dict()
    assert action_module._task == dict()
    action_module._add_host_vars_from_inventory({
        'hosts': [
            dict(name='test', groups=['group1', 'group2'])
        ]
    })

# Generated at 2022-06-23 08:07:16.833842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.context import CLIContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.parsing.convert_bool import boolean
    
    ansible_module_path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules')
    context.CLIARGS._ansible_module_paths.append(ansible_module_path)
    context.CLIARGS._ansible_private_module_paths.append(ansible_module_path)

    context.CLIARGS['module_path'] = []
    context.CLIARGS['private_module_path'] = []

# Generated at 2022-06-23 08:07:18.312751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._supports_check_mode == True

# Generated at 2022-06-23 08:07:29.045141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup the class instance for unit testing
    # Because this is a class full of 'buisness logic', there is
    # no reason to do anything other than check the that the
    # class is working as expected.
    file_name = 'ActionModule_test_run.txt'
    facts = ['all', 'network']
    with open(file_name, 'w') as file_handle:
        file_handle.writelines(facts)

    with open(file_name, 'r') as file_handle:
        modules = file_handle.readlines()

    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    obj._display = None
    obj._task = None
    obj._connection = None
    obj._supports_

# Generated at 2022-06-23 08:07:32.242049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''returns the class object for action module'''
    mod = ActionModule()
    # mod.run()
    # mod._execute_module()
    mod._execute_module.__name__


if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-23 08:07:38.315685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a task and a task object
    task = DummyTask()
    task.action = 'setup'
    task.args = {'setup_gather_subset': 'all'}
    task_object = ActionModule(task, {})

    # create three temp directories, they will be removed automatically
    tmp = tempfile.TemporaryDirectory()
    task_object._connection._shell.tmpdir = tempfile.TemporaryDirectory().name
    task_object._shared_loader_obj.module_loader.module_basedir = tempfile.TemporaryDirectory().name

    # create a task_vars object
    task_vars = {'ansible_facts_parallel': False}

    # create a 'mock' module, which will be executed.
    # The methods 'execute_module' and 'execute_module_async' will be

# Generated at 2022-06-23 08:07:41.508643
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = AnsibleModule(
        argument_spec = dict(
            modules=dict(type='list', elements='str')
        )
    )

    # TODO: implement unit test for ActionModule.run

# Generated at 2022-06-23 08:07:43.999374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule("x", "y", "z"), ActionModule)

# Generated at 2022-06-23 08:07:44.668740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:07:46.093851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:07:54.238459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    context = PlayContext()
    a = ActionModule(dict(name='test'),
                     VariableManager(),
                     ImmutableDict({'action': 'test'}),
                     context,
                     )

    assert a.name == 'test'
    assert a._task.action == 'test'
    assert a.task_vars == ImmutableDict()