

# Generated at 2022-06-23 07:57:51.129618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 07:58:02.462062
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    o = ActionModule(connection=None, task=None, play_context=None)
    task_vars = {}

    tmp = None

    # Uses parallelism with no modules.
    result = o.run(tmp=tmp, task_vars=task_vars)
    assert result['ansible_facts'].get('_ansible_facts_gathered') is None

    # Doesn't use parallelism with a single module
    C.config.set_config_value("FACTS_MODULES", ['test1'])
    result = o.run(tmp=tmp, task_vars=task_vars)
    assert result['ansible_facts'].get('_ansible_facts_gathered') is True

    # Doesn't use parallelism because the user explicity says not to
    C.config.set_config_value

# Generated at 2022-06-23 07:58:12.458332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    import ansible.plugins.loader
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import ansible.inventory
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts import MegacliDiskFacts, DmidecodeFacts
    from ansible.module_utils.network import NetworkModule
    from ansible.module_utils.network.common.facts.bonding import BondingFacts

# Generated at 2022-06-23 07:58:22.231529
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action.setup import ActionModule as SetupActionModule
    from ansible.module_utils.facts.system.network.base import Network
    from ansible.module_utils.facts.system.base import BaseFactCollector

    import mock
    import unittest

    def dummy_exec_module(module_name, module_args, *kwargs):
        return {'msg': 'This is a test'}


# Generated at 2022-06-23 07:58:34.936261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_result
    from ansible.playbook import task

    mock_play_context = MagicMock()
    mock_play_context.connection = 'local'
    mock_play_context.become = False
    mock_play_context.become_method = 'sudo'
    mock_play_context.become_user = 'nobody'
    mock_play_context.module_name = 'setup'

    mock_connection = MagicMock()
    mock_connection.get_options.return_value = {'remote_tmp': '/tmp'}

    mock_loader = MagicMock()
    mock_loader.module_loader.find_plugin_with_context.return_value.resolved_fqcn = 'builtin.setup'


# Generated at 2022-06-23 07:58:40.608440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init action_module, mock injected class
    action_module = ActionModule()

    mocked_task = mock.MagicMock()
    action_module._task = mocked_task

    mocked_task._parent = mock.MagicMock()
    mocked_task._parent._play = mock.MagicMock()
    mocked_task._parent._play._action_groups = ['setup']

    mocked_task.args = {'parallel': 'yes'}

    mocked_connection = mock.MagicMock()
    mocked_connection._load_name = 'faked_connection'
    action_module._connection = mocked_connection

    mocked_display = mock.MagicMock()
    action_module._display = mocked_display

    mocked_templar = mock.MagicMock()
    action_module._templar = mocked_templar

   

# Generated at 2022-06-23 07:58:43.230193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""
    module = ActionModule()
    assert module.NAME == 'setup'
    assert module._supports_check_mode is True

# Generated at 2022-06-23 07:58:43.873256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_run()

# Generated at 2022-06-23 07:58:58.652350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.callback.default import CallbackModule


# Generated at 2022-06-23 07:59:09.517926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    class FakeTask():

        def __init__(self):
            self.block = block = Block()
            self.task_include = TaskInclude()
            self._parent = block
            self._role = Role()
            self.args = {}

        def copy(self):
            new_task = FakeTask()
            new_task.block = self.block
            new_task._parent = self

# Generated at 2022-06-23 07:59:18.544369
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    from ansible.plugins.task import TaskBase
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars, load_options_vars, load_options_vars_files
    from ansible.vars.manager import VariableManager
    # Defining blocks and task
    block = Block()
    task = TaskBase()

    task.register(block, 'setup')
    # New Task Queue Manager

# Generated at 2022-06-23 07:59:27.686797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'ansible_setup'
    task_vars={'ansible_network_os':'action_module_network_os', 'ansible_facts':{'network_os':'network_os'}}
    task_name='setup'
    injected_vars=dict()
    play_context=None
    loader=None
    shared_loader_obj=None
    templar=None
    task_action=dict(setup=dict(action='setup', args=dict(fetch=['all'])))
    result=dict()
    action_base=ActionBase()
    temp_result=action_base._get_module_args(module_name, task_vars)

# Generated at 2022-06-23 07:59:38.683180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    from ansible.module_utils.facts.virtual.base import BaseFactCollector
    from ansible.plugins.action import ActionModule

    class fake_module:
        def __init__(self, module_name, module_args, inside_task=None):
            self._shared_loader_obj = '_shared_loader_obj'
            self._display = '_display'
            self._task = inside_task or fake_task('setup')
            self._task.module_defaults = 'module_defaults'
            self._connection = '_connection'
            self._templar = '_templar'

    class fake_task:
        def __init__(self, name, task_module_name=None):
            self.name = name
            self.args = {}
            self.module_defaults

# Generated at 2022-06-23 07:59:50.736123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import callback_loader
    from ansible.inventory.host import Host
    import ansible.constants as C

    C.HOST_KEY_CHECKING = False
    pbex = PlaybookExecutor(playbooks=['playbook.yml'], inventory=InventoryManager(['localhost']), variable_manager=VariableManager(), loader=DataLoader(), options=None, passwords=None)

# Generated at 2022-06-23 07:59:51.771675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-23 07:59:52.655282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_plugin = ActionModule()

# Generated at 2022-06-23 07:59:57.391303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule('setup', 'localhost', 'test'), ActionModule)


# Unit tests for private methods of class ActionModule

# Generated at 2022-06-23 08:00:00.337509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # ActionModule.run() called directly
    print('\nTesting ActionModule.run() called directly')
    action_module = ActionModule()
    print(action_module._supports_check_mode)

# Generated at 2022-06-23 08:00:12.330416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeTask:
        class FakeAction:
            @property
            def run(self):
                return "def_run"
    class FakeConnection:
        class FakeShell:
            def __init__(self):
                self.tmpdir = "def_tmpdir"
        def __init__(self):
            self._shell = FakeConnection.FakeShell()
            self._load_name = "def_load_name"
    fake_task = FakeTask()
    fake_task._parent = FakeTask()
    fake_task._parent._play = FakeTask()
    fake_task._parent._play._action_groups = "def_action_groups"
    fake_task._task_vars = "def_task_vars"
    fake_task._templar = "def_templar"
    fake_task.args = {}

# Generated at 2022-06-23 08:00:26.394029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {'ansible_facts_parallel': 'True', 'ansible_network_os': 'arista_eos'}
    action = ActionModule({'args': {'gather_subset': ['all'], 'gather_network_resources': ['all']}}, {}, {}, {}, task_vars)
    assert len(action._task.args) == 2
    action = ActionModule({'args': {'gather_subset': 'all', 'gather_network_resources': 'all'}}, {}, {}, {}, task_vars)
    assert len(action._task.args) == 2
    action = ActionModule({'args': {'gather_subset': 'all', 'gather_network_resources': 'all'}}, {}, {}, {}, task_vars)
   

# Generated at 2022-06-23 08:00:35.373572
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import yaml
    from ansible.module_utils import basic
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase

    def _load_params(self):
        self.argument_spec = {
            'filter': {'type': 'list'},
            'parallel': {'type': 'bool', 'default': boolean(C.DEFAULT_GATHER_SUBSET)},
            'gather_subset': {'type': 'list'},
            'gather_timeout': {'type': 'int', 'default': C.DEFAULT_GATHER_TIMEOUT},
            'network_os': {'type': 'str'},
        }


# Generated at 2022-06-23 08:00:36.036592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:00:46.252997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.constants as C
    import ansible.executor.module_common as _module_common
    import ansible.executor.task_executor as _task_executor
    import ansible.plugins.action as _action
    import ansible.plugins.action.setup as _setup
    import ansible.utils.vars as _vars
    import os

    # set up some fake variables
    constants.DEFAULT_MODULE_NAME = 'fake'
    constants.DEFAULT_MODULE_PATH = ['box']
    constants.DEFAULT_TRANSFORM_NAME = 'fake'
    constants.DEFAULT_TRANSFORM_PATH = ['box']

    # construct a mock object to test on
    class fake_loader_obj():
        module_loader = fake_module_loader()

# Generated at 2022-06-23 08:00:54.551530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_runner.connection import Connection
    from ansible_runner.loader import PluginLoader
    from ansible_runner.utils import get_config
    from ansible.utils.vars import combine_vars


    task = {}
    task['args'] = {}
    task['args']['parallel'] = None
    task['collections'] = []

    _task = {}
    _task['module_defaults'] = [{}]


    _parent = {}
    _parent['_action_groups'] = [{}]

    _play = {}
    _play['_action_groups'] = [{}]

    _task['_parent'] = _parent

    _parent['_play'] = _play

    connection = Connection('network_cli')
    connection._shell = get_config()
    connection._shell.tmp

# Generated at 2022-06-23 08:01:05.487147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTaskExecutor:
        def __init__(self):
            self._shared_loader_obj = FakeSharedLoaderer()
            self._action = 'setup'
            self._args = {'a':'10'}
            self._task_vars = {'install_version':'16.04'}
    class FakeSharedLoaderer:
        def get_vars(self, loader, play=None, task=None, shared_loader_obj=None, variable_manager=None, loader_cache=False):
            return {'install_version': '16.04'}
        def module_loader(self):
            return FakeModuleLoader()
    class FakeModuleLoader:
        # Return fake resolved FQCN module
        def find_plugin_with_context(self, name, collection_list=None):
            return FakeRes

# Generated at 2022-06-23 08:01:07.258964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = ActionModule(load_name='', connection=None)
  module._display = Display()
  module.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:01:07.845355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:01:17.216710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m._shared_loader_obj = None
    m._connection = None
    m._play_context = None
    m._loader = None
    m._templar = None
    m._task = None
    m._supports_check_mode = True
    m._display = None
    m._task_vars = {}
    m._tmp = '/tmp'
    m._remove_tmp_path = lambda x: False
    m._execute_module = lambda x, y, z, a: {'failed': False, 'skipped': False, 'ansible_facts': {'result': 'value'}}
    # The test will fail if there is not a result['failed'] or result['skipped']
    assert not m.run()['failed'] and not m.run()['skipped']


# Unit test

# Generated at 2022-06-23 08:01:28.911665
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    def _task_queue(task, host_list=None, play_context=None):
        mgr = TaskQueueManager(
            inventory=InventoryManager(loader=DataLoader()),
            variable_manager=None,
            loader=DataLoader(),
            passwords={},
            stdout_callback=None,
        )

        list(mgr._queue_task(host_list=host_list, task=task, play_context=play_context))

    task = Task()
    task.action = 'setup'
    task

# Generated at 2022-06-23 08:01:33.719762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    import ansible.module_utils.parsing.dataloader
    from ansible.parsing.vault import VaultLib

    loader = ansible.module_utils.parsing.dataloader.DataLoader()

    vault = VaultLib('password')

# Generated at 2022-06-23 08:01:36.409365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule()
    t.run()

# Generated at 2022-06-23 08:01:46.407054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.setup import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.cli.arguments import AnsibleCLIArguments
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    
    class TestExecutor:
        def __init__(self):
            pass

        def __enter__(self):
            self._task_queue_manager = None
            self._tqm = None
           

# Generated at 2022-06-23 08:01:48.691181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: write unit test
    assert False


# Generated at 2022-06-23 08:01:59.472243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from unittest import mock
    from ansible.module_utils.facts.collector import Collector

    mod = ActionModule()
    mod._connection = mock.MagicMock()
    mod._connection._load_name = 'a_fake_load'
    mod._task = mock.MagicMock()
    mod._task.args = {}
    mod._shared_loader_obj = mock.MagicMock()
    mod._shared_loader_obj.module_loader = mock.MagicMock()
    mod._shared_loader_obj.module_loader.find_plugin_with_context = mock.MagicMock(return_value=Collector())
    mod._templar = mock.MagicMock()
    mod._task._parent = mock.MagicMock()
    mod._task._parent._play = mock.MagicMock()
    mod._

# Generated at 2022-06-23 08:02:03.182239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Construct a mock for the ActionModule class, and construct an instance of this class.
    action_module = ActionModule()
    result = action_module.run(tmp=None, task_vars=None)
    assert result.get("failed") is not None, "The result must be failed, but received result is " + str(result)

# Generated at 2022-06-23 08:02:15.062747
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest.mock as mock

    module_mock = mock.Mock()
    module_mock.configure_mock(name='test.py')
    module_mock.resolved_fqcn = 'test.py'
    # module_mock._shared_loader_obj = mock.Mock()
    # module_mock._execute_module = mock.Mock()
    module_mock._shared_loader_obj = None
    module_mock._execute_module = None
    module_mock.return_value = 'test_result'

    module_loader_mock = mock.Mock()
    module_loader_mock.find_plugin_with_context.return_value = module_mock


# Generated at 2022-06-23 08:02:25.519446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import playbook_executor

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor


    C.config.load_config_file()
    C.config.initialize_formatter()
    C.config.initialize_logger()
    C.config.initialize_deprecation_warnings()

    # Setup playbook executor, and add

# Generated at 2022-06-23 08:02:36.708633
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:02:45.741086
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ActionModule_object = ActionModule()

    #method run - parameters:
    # tmp
    # task_vars

    # testcase tests method run with parameter tmp = None and task_vars = None

    # mock modules passed as parameters
    # initialize test variables
    expected_result = {'ansible_facts': {}, '_ansible_verbose_override': True}
    tmp = None
    task_vars = None

    # call method under test
    actual_result = ActionModule_object.run(tmp, task_vars)

    assert actual_result == expected_result, "ActionModule_object.run() did not return expected value"



    # testcase tests method run with parameter tmp = None and task_vars = {'ansible_check_mode': True}

    # mock modules passed as parameters
    # initialize test

# Generated at 2022-06-23 08:02:55.268673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.setup import ActionModule
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars
    from ansible.vars.manager import VariableManager
    from unittest.case import TestCase
    import common_unit_test
    import os

    class MockConfig(object):
        def __init__(self):
            self.var = dict()

# Generated at 2022-06-23 08:03:02.177112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionBase(ActionBase):
        def __init__(self):
            self.name = "MockActionBase"

        def run(self, tmp=None, task_vars=None):
            return 'actionbase'

    class MockActionModule(ActionModule):
        def __init__(self):
            self.actionbase = MockActionBase()

    actionmodule = MockActionModule()
    assert actionmodule.run() == 'actionbase'

# Generated at 2022-06-23 08:03:03.148601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # @TODO: Add test
    pass

# Generated at 2022-06-23 08:03:14.308322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader

    connection_1 = FakeConnection()
    connection_2 = FakeConnection()
    connection_3 = FakeConnection()
    connection_4 = FakeConnection()

    task_1 = FakeTask('setup', {}, connection_1)
    task_2 = FakeTask('setup', {}, connection_2)
    task_3 = FakeTask('setup', {}, connection_3)
    task_4 = FakeTask('setup', {}, connection_4)

    # use constructor of class ActionModule
    action_module_1 = action_loader.get('setup', task=task_1)
    action_module_2 = action_loader.get('setup', task=task_2)
    action_module_3 = action_loader.get('setup', task=task_3)

# Generated at 2022-06-23 08:03:25.243364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture = ActionModule()
    fixture._task = Mock()
    fixture._task.args = {}
    fixture._task._parent = Mock()
    fixture._task._parent._play = Mock()
    fixture._task._parent._play._action_groups = {}
    fixture._shared_loader_obj = Mock()
    fixture._shared_loader_obj.module_loader = Mock()
    fixture._shared_loader_obj.module_loader.find_plugin_with_context = Mock(return_value=Mock())
    fixture._shared_loader_obj.module_loader.find_plugin_with_context.return_value.resolved_fqcn = 'test'
    fixture._templar = Mock()
    fixture._task.collections = []
    fixture._display = Mock()
    fixture._execute_module = Mock()
    fixture._execute_

# Generated at 2022-06-23 08:03:32.981148
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # instantiation of arguments.
    dict_args = {'parallel': 'False' }

    # instantiation of class ActionModule.
    class_action_module = ActionModule('setup', {}, dict_args, True)

    # execution of run():
    result = class_action_module.run(None, {'ansible_facts': {'foo': 'bar'}})

    assert result
    # TODO: Add assert for the content of result

# Generated at 2022-06-23 08:03:34.464712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement test
    pass

# Generated at 2022-06-23 08:03:41.864845
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Prepare the attributes
    action_base = ActionBase()
    task = "task"
    connection = "connection"
    play_context = "play_context"
    loader = "loader"
    templar = "templar"
    shared_loader_obj = "shared_loader_obj"

    # Create the object
    am = ActionModule(action_base, task, connection, play_context, loader, templar, shared_loader_obj)

    # Return the attributes
    return (am)

# Generated at 2022-06-23 08:03:46.214327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    result = action_module_obj.run(tmp='tmp_path', task_vars={})
    assert result['ansible_facts']['_ansible_facts_gathered'] == True
    assert result['_ansible_verbose_override'] == True

# Generated at 2022-06-23 08:03:47.393705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ansible.legacy.setup' == ActionModule.__name__

# Generated at 2022-06-23 08:03:48.836331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing with empty constructor
    action_module = ActionModule()
    assert action_module._supports_check_mode is True

# Generated at 2022-06-23 08:03:59.971028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import yaml

    FAKE_INVENTORY = yaml.safe_load('''
    [{"_ansible_no_log": true, "_ansible_parsed": true, "ines": "hab", "o": {"ansible_architecture": "ansible_architecture"}}, {"o": "p", "ines": {"ansible_architecture": "ansible_architecture"}}]
    ''')
    FAKE_INVENTORY_2 = [json.loads('{"_ansible_no_log": true, "_ansible_parsed": true, "ines": "hab", "o": {"ansible_architecture": "ansible_architecture"}}')]

# Generated at 2022-06-23 08:04:04.478302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play_context
    import ansible.utils.vars

    ab = ansible.plugins.action.ActionBase()
    am = ansible.plugins.action.ActionModule(ab._play_context, ab._task, ab._connection, ab._loader, ab._templar, ab._shared_loader_obj)

# Generated at 2022-06-23 08:04:13.962448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_data = """
    {
        "ansible_job_id": "23782905",
        "ansible_facts": {},
        "ansible_facts_modules": ["loom_facts"],
        "changed": false,
        "invocation": {
            "module_args": {
                "ansible_facts": {
                    "ansible_distribution": "Fedora",
                    "ansible_distribution_major_version": "28",
                    "ansible_distribution_version": "28"
                },
                "gather_subset": ["!all", "min"],
                "filter": "ansible_.*"
            },
            "module_name": "setup"
        }
    }
    """
    mock_connection = MockConnection()
    mock_task = MockTask(test_data)

# Generated at 2022-06-23 08:04:25.187416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We need to mock the class
    # pylint: disable=unused-variable
    mock_shared_loader_obj = 'mock_shared_loader_obj'
    mock_connection = 'mock_connection'
    mock_task = 'mock_task'
    mock_loader = 'mock_loader'
    mock_templar = 'mock_templar'
    mock_play_context = 'mock_play_context'
    mock_new_stdin = 'mock_new_stdin'

    # create the instance of the class
    am = ActionModule(mock_shared_loader_obj, mock_connection, mock_task, mock_loader,
                      mock_templar, mock_play_context, mock_new_stdin)
    # check if the instance is created properly
    assert am

# Generated at 2022-06-23 08:04:26.413768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule('action_module/test', {}).run()

# Generated at 2022-06-23 08:04:38.275394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture_loader = get_fixture_loader(action_module_fixtures)
    setup_module_action_obj = fixture_loader.load_fixture('setup_module_action',
                                                          action_module_fixtures)

# Generated at 2022-06-23 08:04:48.651268
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.constants as C
    import ansible.module_utils.parsing.convert_bool as convert_bool

    from ansible.plugins.action import ActionBase
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.utils.vars import merge_hash
    from ansible.utils.display import Display

    from .utils import _FactResult, _ExecutorConfig, _create_async_dir, get_temp_path

    # Create a test action module

    class TestAction(ActionBase):

        def __init__(self):

            super(TestAction, self).__init__((), load_fn=None)

            self._supports_check_mode = True

            # Define temporary variables

            self._task = None
            self._display = Display()

# Generated at 2022-06-23 08:04:50.228835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:05:00.829867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing a blank ActionModule object for testing
    class TestActionModule(ActionModule):
        def __init__(self, task_queue_manager, connections, play_context, loader, templar, shared_loader_obj):
            super(TestActionModule, self).__init__(task_queue_manager, connections, play_context, loader, templar, shared_loader_obj)
            self._shared_loader_obj = shared_loader_obj
            self._task = None
            self._task_queue_manager = task_queue_manager
            self._loader = loader
            self._templar = templar
            self._connection = None
            self._play_context = play_context
            self._needed_by = None
            self._supports_check_mode = True
            self._supports_async = True
           

# Generated at 2022-06-23 08:05:02.102983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None)
    action_module.run()

# Generated at 2022-06-23 08:05:07.237479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit tests for constructor of class ActionModule'''
    act = ActionModule(
        task=dict(action="setup", args=dict(filter="*")),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict()
    )
    assert act


# Generated at 2022-06-23 08:05:13.942500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_name = 'setup'
    action_path = '/root/git/ansible/lib/ansible/modules/system/setup.py'
    action_shared_loader_obj = None
    action_task = None
    action_connection = None
    action_play_context = None
    action_loader = None
    action_templar = '_templar'

    # constructor
    setup = ActionModule(
        action_name,
        action_path,
        action_shared_loader_obj,
        action_task,
        action_connection,
        action_play_context,
        action_loader,
        action_templar
    )
    return setup

# Generated at 2022-06-23 08:05:24.430687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.executor.executor
    import ansible.inventory
    import ansible.playbook.play
    import ansible.playbook.playbook
    import ansible.plugins.loader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    executor = ansible.executor.executor.Executor()
    loader = ansible.plugins.loader.ActionModuleLoader(executor=executor)
    loader._load_one_plugin('setup')
    hosts = ansible.inventory.Host('localhost')
    play_source = dict(name="Ansible Play", hosts='localhost', gather_facts='smart', tasks=[])
    play = ansible.playbook.play.Play().load(play_source, variable_manager=VariableManager(), loader=loader)
   

# Generated at 2022-06-23 08:05:25.978213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1

# Generated at 2022-06-23 08:05:29.959978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:05:31.000172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    assert issubclass(action_module.__class__, ActionBase)

# Generated at 2022-06-23 08:05:40.549377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None)
    module._execute_module = lambda module_name, module_args, task_vars: module_args
    module._task = {'args': {'parallel': False, 'gather_subset': 'all', 'gather_timeout': 5, 'filter': 'filter'}}
    module._display = None
    module._supports_check_mode = True
    module._connection = {'_load_name': 'ssh'}
    module._play = {'action_groups': {}}

    class ModLoader(object):
        def find_plugin(self, name, mod_type=2, ignore_deprecated=False, collection_list=None):
            return 'collection.plugins.module_utils.network.common.tools.basic'


# Generated at 2022-06-23 08:05:44.784005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(loader=None,
                     connection=None,
                     play_context=None,
                     options=dict(connection='network_cli',
                                  module_defaults=dict(use_ssl=dict(default=False))),
                     passwords=None)
    assert x._task.args.get('use_ssl') == False

# Generated at 2022-06-23 08:05:52.471931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.hardware import Hardware
    # create a dummy class to be able to test method run of class ActionModule
    _display = object()
    _loader = object()
    _task = object()
    _connection = object()
    _shell = object()
    _shell_type = 'pshell'
    _shell.tmpdir = 'tmpdir'
    _shell.type = _shell_type
    _connection._shell = _shell
    _action_base = object()
    _shared_loader_obj = object()
    _action_module = ActionModule(_display, _loader, _task, _connection, _shared_loader_obj, _action_base)
    assert isinstance(_action_module, object)

# Generated at 2022-06-23 08:06:04.687440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Ensure that a module run is successful."""
    class TaskMock(object):
        def __init__(self, values):
            self.__dict__ = values
    class MyActionModule(ActionModule):
        def _execute_module(self, module_name=None, module_args=None, task_vars=None, wrap_async=None):
            return {'ansible_facts': {'gathered': True}}
    my_action_module = MyActionModule()

# Generated at 2022-06-23 08:06:11.106514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as plugin_loader
    action_plugin = plugin_loader.action_loader.get('setup')
    assert action_plugin is not None
    assert isinstance(action_plugin, ActionModule)

# Generated at 2022-06-23 08:06:12.256052
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-23 08:06:22.260248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_connection = MagicMock()
    mock_connection.plugin_type = "shell"
    mock_connection.loader = MagicMock()
    mock_connection.loader.get_basedir.return_value = "/lib/ansible/modules/"


# Generated at 2022-06-23 08:06:25.251278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        {},
        {'playbook_dir': '/'},
        {}
    )

# Generated at 2022-06-23 08:06:29.171305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_mod = ActionModule(load_name='setup')
    action_mod.run()

# Generated at 2022-06-23 08:06:36.514592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = os.path.dirname(os.path.abspath(__file__))
    action = os.path.splitext(os.path.basename(__file__))[0]
    unit_test = AnsibleAction(module_name=module,
                              action_name=action,
                              action_args={'a': '1'})
    assert unit_test.action_name == action
    assert unit_test.action_args == {'a': '1'}


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:06:45.474102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    action_module=ActionModule()
    args = {'ansible_facts_parallel': None, 'ansible_facts': None, 'ansible_network_os': None}
    task_vars = {'ansible_facts_parallel': None, 'ansible_facts': None, 'ansible_network_os': None}
    tmp = None
    res = action_module.run(tmp=tmp, task_vars=task_vars)
    assert isinstance(res, Mapping)
    for k in ['ansible_facts', 'warnings', 'deprecations']:
        assert k in res

# Generated at 2022-06-23 08:06:56.878359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.module_utils._text import to_text
    from ansible.plugins.action.setup import ActionModule as action_plugin


# Generated at 2022-06-23 08:07:01.469689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None)
    assert type(a).__name__ == 'ActionModule'

# Generated at 2022-06-23 08:07:12.851139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.system.setup
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.facts.system.distribution import Distribution

    ansible_facts = AnsibleUnsafeText(Distribution(ansible_os_family='RedHat').get_distribution().lower())
    fake_module = ansible.modules.system.setup.SetupModule()
    with mock.patch.object(fake_module, 'get_distribution') as mock_distro:
        mock_distro.return_value = ansible_facts
        res = {}
        task_vars = {}
        tmp = {}
        instance = ActionModule()
        result = instance.run(tmp, task_vars)
        expected_result = {}
        expected_result['ansible_facts'] = {}
       

# Generated at 2022-06-23 08:07:13.597406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:07:20.384088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible import constants
    from ansible.plugins.action.setup import ActionModule as setup_ActionModule
    from ansible.plugins.action.ping import ActionModule as ping_ActionModule
    from ansible.module_utils.parsing.convert_bool import boolean

    # mock
    ansible = namedtuple('ansible', ['plugins'])
    plugins = namedtuple('plugins', ['action'])
    action = namedtuple('action', ['setup', 'ping'])
    constants_ = namedtuple('constants', ['config'])
    config = namedtuple('config', ['get_config_value'])
    config.get_config_value.return_value = ['smart', 'ping']


# Generated at 2022-06-23 08:07:22.774267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call the method run of class ActionModule with appropriate parameters
    # Create ActionModule object
    am = ActionModule()
    # Set the required instance attribute
    am._connection = "network_cli"
    # Execute the method run
    result = am.run()

    assert result["failed"] is True
    assert result["changed"] is False

# Generated at 2022-06-23 08:07:32.058704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.stats import AggregateStats
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.attributes import Attributes
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

# Generated at 2022-06-23 08:07:32.563717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:07:42.631625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    basepath = os.path.dirname(os.path.dirname(__file__))
    fixture_path = os.path.join(basepath, 'test', 'fixtures', 'test_runner')
    test_file_path = os.path.join(fixture_path, 'test_playbook.yml')
    with open(test_file_path, 'r') as the_file:
        lines = [line.strip() for line in the_file.readlines()]
    new_lines = []
    for line in lines:
        if line.startswith('---'):
            new_lines.append('  gather_facts: true')
        new_lines.append(line)
    lines = new_lines
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-23 08:07:54.479825
# Unit test for method run of class ActionModule